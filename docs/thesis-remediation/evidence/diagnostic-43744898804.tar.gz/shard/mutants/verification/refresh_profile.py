"""Attach the current coverage and revision to the verification profile."""

from __future__ import annotations

import argparse
import copy
import json
import subprocess
from datetime import UTC, datetime
from pathlib import Path


from mutmut.mutation.trampoline import wrap_in_trampoline as _mutmut_mutated, MutantDict
mutants_x_build_profile__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_build_profile__mutmut)
def build_profile(template: dict, coverage: dict, *, revision: str, generated_at: str) -> dict:
    """Build a fresh profile without changing its policy or scope."""
    result = copy.deepcopy(template)
    result["source_revision"] = revision
    result["generated_at"] = generated_at
    totals = coverage["totals"]
    result["coverage"]["line"] = {
        "covered": totals["covered_lines"],
        "coverable": totals["num_statements"],
    }
    result["coverage"]["branch"] = {
        "covered": totals["covered_branches"],
        "coverable": totals["num_branches"],
    }
    result["coverage"]["per_unit"] = [
        {
            "unit": path,
            "line": {
                "covered": values["summary"]["covered_lines"],
                "coverable": values["summary"]["num_statements"],
            },
            "branch": {
                "covered": values["summary"]["covered_branches"],
                "coverable": values["summary"]["num_branches"],
            },
        }
        for path, values in sorted(coverage["files"].items())
    ]
    return result


def x_build_profile__mutmut_orig(template: dict, coverage: dict, *, revision: str, generated_at: str) -> dict:
    """Build a fresh profile without changing its policy or scope."""
    result = copy.deepcopy(template)
    result["source_revision"] = revision
    result["generated_at"] = generated_at
    totals = coverage["totals"]
    result["coverage"]["line"] = {
        "covered": totals["covered_lines"],
        "coverable": totals["num_statements"],
    }
    result["coverage"]["branch"] = {
        "covered": totals["covered_branches"],
        "coverable": totals["num_branches"],
    }
    result["coverage"]["per_unit"] = [
        {
            "unit": path,
            "line": {
                "covered": values["summary"]["covered_lines"],
                "coverable": values["summary"]["num_statements"],
            },
            "branch": {
                "covered": values["summary"]["covered_branches"],
                "coverable": values["summary"]["num_branches"],
            },
        }
        for path, values in sorted(coverage["files"].items())
    ]
    return result


def x_build_profile__mutmut_1(template: dict, coverage: dict, *, revision: str, generated_at: str) -> dict:
    """Build a fresh profile without changing its policy or scope."""
    result = None
    result["source_revision"] = revision
    result["generated_at"] = generated_at
    totals = coverage["totals"]
    result["coverage"]["line"] = {
        "covered": totals["covered_lines"],
        "coverable": totals["num_statements"],
    }
    result["coverage"]["branch"] = {
        "covered": totals["covered_branches"],
        "coverable": totals["num_branches"],
    }
    result["coverage"]["per_unit"] = [
        {
            "unit": path,
            "line": {
                "covered": values["summary"]["covered_lines"],
                "coverable": values["summary"]["num_statements"],
            },
            "branch": {
                "covered": values["summary"]["covered_branches"],
                "coverable": values["summary"]["num_branches"],
            },
        }
        for path, values in sorted(coverage["files"].items())
    ]
    return result


def x_build_profile__mutmut_2(template: dict, coverage: dict, *, revision: str, generated_at: str) -> dict:
    """Build a fresh profile without changing its policy or scope."""
    result = copy.deepcopy(None)
    result["source_revision"] = revision
    result["generated_at"] = generated_at
    totals = coverage["totals"]
    result["coverage"]["line"] = {
        "covered": totals["covered_lines"],
        "coverable": totals["num_statements"],
    }
    result["coverage"]["branch"] = {
        "covered": totals["covered_branches"],
        "coverable": totals["num_branches"],
    }
    result["coverage"]["per_unit"] = [
        {
            "unit": path,
            "line": {
                "covered": values["summary"]["covered_lines"],
                "coverable": values["summary"]["num_statements"],
            },
            "branch": {
                "covered": values["summary"]["covered_branches"],
                "coverable": values["summary"]["num_branches"],
            },
        }
        for path, values in sorted(coverage["files"].items())
    ]
    return result


def x_build_profile__mutmut_3(template: dict, coverage: dict, *, revision: str, generated_at: str) -> dict:
    """Build a fresh profile without changing its policy or scope."""
    result = copy.copy(template)
    result["source_revision"] = revision
    result["generated_at"] = generated_at
    totals = coverage["totals"]
    result["coverage"]["line"] = {
        "covered": totals["covered_lines"],
        "coverable": totals["num_statements"],
    }
    result["coverage"]["branch"] = {
        "covered": totals["covered_branches"],
        "coverable": totals["num_branches"],
    }
    result["coverage"]["per_unit"] = [
        {
            "unit": path,
            "line": {
                "covered": values["summary"]["covered_lines"],
                "coverable": values["summary"]["num_statements"],
            },
            "branch": {
                "covered": values["summary"]["covered_branches"],
                "coverable": values["summary"]["num_branches"],
            },
        }
        for path, values in sorted(coverage["files"].items())
    ]
    return result


def x_build_profile__mutmut_4(template: dict, coverage: dict, *, revision: str, generated_at: str) -> dict:
    """Build a fresh profile without changing its policy or scope."""
    result = copy.deepcopy(template)
    result["source_revision"] = None
    result["generated_at"] = generated_at
    totals = coverage["totals"]
    result["coverage"]["line"] = {
        "covered": totals["covered_lines"],
        "coverable": totals["num_statements"],
    }
    result["coverage"]["branch"] = {
        "covered": totals["covered_branches"],
        "coverable": totals["num_branches"],
    }
    result["coverage"]["per_unit"] = [
        {
            "unit": path,
            "line": {
                "covered": values["summary"]["covered_lines"],
                "coverable": values["summary"]["num_statements"],
            },
            "branch": {
                "covered": values["summary"]["covered_branches"],
                "coverable": values["summary"]["num_branches"],
            },
        }
        for path, values in sorted(coverage["files"].items())
    ]
    return result


def x_build_profile__mutmut_5(template: dict, coverage: dict, *, revision: str, generated_at: str) -> dict:
    """Build a fresh profile without changing its policy or scope."""
    result = copy.deepcopy(template)
    result["XXsource_revisionXX"] = revision
    result["generated_at"] = generated_at
    totals = coverage["totals"]
    result["coverage"]["line"] = {
        "covered": totals["covered_lines"],
        "coverable": totals["num_statements"],
    }
    result["coverage"]["branch"] = {
        "covered": totals["covered_branches"],
        "coverable": totals["num_branches"],
    }
    result["coverage"]["per_unit"] = [
        {
            "unit": path,
            "line": {
                "covered": values["summary"]["covered_lines"],
                "coverable": values["summary"]["num_statements"],
            },
            "branch": {
                "covered": values["summary"]["covered_branches"],
                "coverable": values["summary"]["num_branches"],
            },
        }
        for path, values in sorted(coverage["files"].items())
    ]
    return result


def x_build_profile__mutmut_6(template: dict, coverage: dict, *, revision: str, generated_at: str) -> dict:
    """Build a fresh profile without changing its policy or scope."""
    result = copy.deepcopy(template)
    result["SOURCE_REVISION"] = revision
    result["generated_at"] = generated_at
    totals = coverage["totals"]
    result["coverage"]["line"] = {
        "covered": totals["covered_lines"],
        "coverable": totals["num_statements"],
    }
    result["coverage"]["branch"] = {
        "covered": totals["covered_branches"],
        "coverable": totals["num_branches"],
    }
    result["coverage"]["per_unit"] = [
        {
            "unit": path,
            "line": {
                "covered": values["summary"]["covered_lines"],
                "coverable": values["summary"]["num_statements"],
            },
            "branch": {
                "covered": values["summary"]["covered_branches"],
                "coverable": values["summary"]["num_branches"],
            },
        }
        for path, values in sorted(coverage["files"].items())
    ]
    return result


def x_build_profile__mutmut_7(template: dict, coverage: dict, *, revision: str, generated_at: str) -> dict:
    """Build a fresh profile without changing its policy or scope."""
    result = copy.deepcopy(template)
    result["source_revision"] = revision
    result["generated_at"] = None
    totals = coverage["totals"]
    result["coverage"]["line"] = {
        "covered": totals["covered_lines"],
        "coverable": totals["num_statements"],
    }
    result["coverage"]["branch"] = {
        "covered": totals["covered_branches"],
        "coverable": totals["num_branches"],
    }
    result["coverage"]["per_unit"] = [
        {
            "unit": path,
            "line": {
                "covered": values["summary"]["covered_lines"],
                "coverable": values["summary"]["num_statements"],
            },
            "branch": {
                "covered": values["summary"]["covered_branches"],
                "coverable": values["summary"]["num_branches"],
            },
        }
        for path, values in sorted(coverage["files"].items())
    ]
    return result


def x_build_profile__mutmut_8(template: dict, coverage: dict, *, revision: str, generated_at: str) -> dict:
    """Build a fresh profile without changing its policy or scope."""
    result = copy.deepcopy(template)
    result["source_revision"] = revision
    result["XXgenerated_atXX"] = generated_at
    totals = coverage["totals"]
    result["coverage"]["line"] = {
        "covered": totals["covered_lines"],
        "coverable": totals["num_statements"],
    }
    result["coverage"]["branch"] = {
        "covered": totals["covered_branches"],
        "coverable": totals["num_branches"],
    }
    result["coverage"]["per_unit"] = [
        {
            "unit": path,
            "line": {
                "covered": values["summary"]["covered_lines"],
                "coverable": values["summary"]["num_statements"],
            },
            "branch": {
                "covered": values["summary"]["covered_branches"],
                "coverable": values["summary"]["num_branches"],
            },
        }
        for path, values in sorted(coverage["files"].items())
    ]
    return result


def x_build_profile__mutmut_9(template: dict, coverage: dict, *, revision: str, generated_at: str) -> dict:
    """Build a fresh profile without changing its policy or scope."""
    result = copy.deepcopy(template)
    result["source_revision"] = revision
    result["GENERATED_AT"] = generated_at
    totals = coverage["totals"]
    result["coverage"]["line"] = {
        "covered": totals["covered_lines"],
        "coverable": totals["num_statements"],
    }
    result["coverage"]["branch"] = {
        "covered": totals["covered_branches"],
        "coverable": totals["num_branches"],
    }
    result["coverage"]["per_unit"] = [
        {
            "unit": path,
            "line": {
                "covered": values["summary"]["covered_lines"],
                "coverable": values["summary"]["num_statements"],
            },
            "branch": {
                "covered": values["summary"]["covered_branches"],
                "coverable": values["summary"]["num_branches"],
            },
        }
        for path, values in sorted(coverage["files"].items())
    ]
    return result


def x_build_profile__mutmut_10(template: dict, coverage: dict, *, revision: str, generated_at: str) -> dict:
    """Build a fresh profile without changing its policy or scope."""
    result = copy.deepcopy(template)
    result["source_revision"] = revision
    result["generated_at"] = generated_at
    totals = None
    result["coverage"]["line"] = {
        "covered": totals["covered_lines"],
        "coverable": totals["num_statements"],
    }
    result["coverage"]["branch"] = {
        "covered": totals["covered_branches"],
        "coverable": totals["num_branches"],
    }
    result["coverage"]["per_unit"] = [
        {
            "unit": path,
            "line": {
                "covered": values["summary"]["covered_lines"],
                "coverable": values["summary"]["num_statements"],
            },
            "branch": {
                "covered": values["summary"]["covered_branches"],
                "coverable": values["summary"]["num_branches"],
            },
        }
        for path, values in sorted(coverage["files"].items())
    ]
    return result


def x_build_profile__mutmut_11(template: dict, coverage: dict, *, revision: str, generated_at: str) -> dict:
    """Build a fresh profile without changing its policy or scope."""
    result = copy.deepcopy(template)
    result["source_revision"] = revision
    result["generated_at"] = generated_at
    totals = coverage["XXtotalsXX"]
    result["coverage"]["line"] = {
        "covered": totals["covered_lines"],
        "coverable": totals["num_statements"],
    }
    result["coverage"]["branch"] = {
        "covered": totals["covered_branches"],
        "coverable": totals["num_branches"],
    }
    result["coverage"]["per_unit"] = [
        {
            "unit": path,
            "line": {
                "covered": values["summary"]["covered_lines"],
                "coverable": values["summary"]["num_statements"],
            },
            "branch": {
                "covered": values["summary"]["covered_branches"],
                "coverable": values["summary"]["num_branches"],
            },
        }
        for path, values in sorted(coverage["files"].items())
    ]
    return result


def x_build_profile__mutmut_12(template: dict, coverage: dict, *, revision: str, generated_at: str) -> dict:
    """Build a fresh profile without changing its policy or scope."""
    result = copy.deepcopy(template)
    result["source_revision"] = revision
    result["generated_at"] = generated_at
    totals = coverage["TOTALS"]
    result["coverage"]["line"] = {
        "covered": totals["covered_lines"],
        "coverable": totals["num_statements"],
    }
    result["coverage"]["branch"] = {
        "covered": totals["covered_branches"],
        "coverable": totals["num_branches"],
    }
    result["coverage"]["per_unit"] = [
        {
            "unit": path,
            "line": {
                "covered": values["summary"]["covered_lines"],
                "coverable": values["summary"]["num_statements"],
            },
            "branch": {
                "covered": values["summary"]["covered_branches"],
                "coverable": values["summary"]["num_branches"],
            },
        }
        for path, values in sorted(coverage["files"].items())
    ]
    return result


def x_build_profile__mutmut_13(template: dict, coverage: dict, *, revision: str, generated_at: str) -> dict:
    """Build a fresh profile without changing its policy or scope."""
    result = copy.deepcopy(template)
    result["source_revision"] = revision
    result["generated_at"] = generated_at
    totals = coverage["totals"]
    result["coverage"]["line"] = None
    result["coverage"]["branch"] = {
        "covered": totals["covered_branches"],
        "coverable": totals["num_branches"],
    }
    result["coverage"]["per_unit"] = [
        {
            "unit": path,
            "line": {
                "covered": values["summary"]["covered_lines"],
                "coverable": values["summary"]["num_statements"],
            },
            "branch": {
                "covered": values["summary"]["covered_branches"],
                "coverable": values["summary"]["num_branches"],
            },
        }
        for path, values in sorted(coverage["files"].items())
    ]
    return result


def x_build_profile__mutmut_14(template: dict, coverage: dict, *, revision: str, generated_at: str) -> dict:
    """Build a fresh profile without changing its policy or scope."""
    result = copy.deepcopy(template)
    result["source_revision"] = revision
    result["generated_at"] = generated_at
    totals = coverage["totals"]
    result["XXcoverageXX"]["line"] = {
        "covered": totals["covered_lines"],
        "coverable": totals["num_statements"],
    }
    result["coverage"]["branch"] = {
        "covered": totals["covered_branches"],
        "coverable": totals["num_branches"],
    }
    result["coverage"]["per_unit"] = [
        {
            "unit": path,
            "line": {
                "covered": values["summary"]["covered_lines"],
                "coverable": values["summary"]["num_statements"],
            },
            "branch": {
                "covered": values["summary"]["covered_branches"],
                "coverable": values["summary"]["num_branches"],
            },
        }
        for path, values in sorted(coverage["files"].items())
    ]
    return result


def x_build_profile__mutmut_15(template: dict, coverage: dict, *, revision: str, generated_at: str) -> dict:
    """Build a fresh profile without changing its policy or scope."""
    result = copy.deepcopy(template)
    result["source_revision"] = revision
    result["generated_at"] = generated_at
    totals = coverage["totals"]
    result["COVERAGE"]["line"] = {
        "covered": totals["covered_lines"],
        "coverable": totals["num_statements"],
    }
    result["coverage"]["branch"] = {
        "covered": totals["covered_branches"],
        "coverable": totals["num_branches"],
    }
    result["coverage"]["per_unit"] = [
        {
            "unit": path,
            "line": {
                "covered": values["summary"]["covered_lines"],
                "coverable": values["summary"]["num_statements"],
            },
            "branch": {
                "covered": values["summary"]["covered_branches"],
                "coverable": values["summary"]["num_branches"],
            },
        }
        for path, values in sorted(coverage["files"].items())
    ]
    return result


def x_build_profile__mutmut_16(template: dict, coverage: dict, *, revision: str, generated_at: str) -> dict:
    """Build a fresh profile without changing its policy or scope."""
    result = copy.deepcopy(template)
    result["source_revision"] = revision
    result["generated_at"] = generated_at
    totals = coverage["totals"]
    result["coverage"]["XXlineXX"] = {
        "covered": totals["covered_lines"],
        "coverable": totals["num_statements"],
    }
    result["coverage"]["branch"] = {
        "covered": totals["covered_branches"],
        "coverable": totals["num_branches"],
    }
    result["coverage"]["per_unit"] = [
        {
            "unit": path,
            "line": {
                "covered": values["summary"]["covered_lines"],
                "coverable": values["summary"]["num_statements"],
            },
            "branch": {
                "covered": values["summary"]["covered_branches"],
                "coverable": values["summary"]["num_branches"],
            },
        }
        for path, values in sorted(coverage["files"].items())
    ]
    return result


def x_build_profile__mutmut_17(template: dict, coverage: dict, *, revision: str, generated_at: str) -> dict:
    """Build a fresh profile without changing its policy or scope."""
    result = copy.deepcopy(template)
    result["source_revision"] = revision
    result["generated_at"] = generated_at
    totals = coverage["totals"]
    result["coverage"]["LINE"] = {
        "covered": totals["covered_lines"],
        "coverable": totals["num_statements"],
    }
    result["coverage"]["branch"] = {
        "covered": totals["covered_branches"],
        "coverable": totals["num_branches"],
    }
    result["coverage"]["per_unit"] = [
        {
            "unit": path,
            "line": {
                "covered": values["summary"]["covered_lines"],
                "coverable": values["summary"]["num_statements"],
            },
            "branch": {
                "covered": values["summary"]["covered_branches"],
                "coverable": values["summary"]["num_branches"],
            },
        }
        for path, values in sorted(coverage["files"].items())
    ]
    return result


def x_build_profile__mutmut_18(template: dict, coverage: dict, *, revision: str, generated_at: str) -> dict:
    """Build a fresh profile without changing its policy or scope."""
    result = copy.deepcopy(template)
    result["source_revision"] = revision
    result["generated_at"] = generated_at
    totals = coverage["totals"]
    result["coverage"]["line"] = {
        "XXcoveredXX": totals["covered_lines"],
        "coverable": totals["num_statements"],
    }
    result["coverage"]["branch"] = {
        "covered": totals["covered_branches"],
        "coverable": totals["num_branches"],
    }
    result["coverage"]["per_unit"] = [
        {
            "unit": path,
            "line": {
                "covered": values["summary"]["covered_lines"],
                "coverable": values["summary"]["num_statements"],
            },
            "branch": {
                "covered": values["summary"]["covered_branches"],
                "coverable": values["summary"]["num_branches"],
            },
        }
        for path, values in sorted(coverage["files"].items())
    ]
    return result


def x_build_profile__mutmut_19(template: dict, coverage: dict, *, revision: str, generated_at: str) -> dict:
    """Build a fresh profile without changing its policy or scope."""
    result = copy.deepcopy(template)
    result["source_revision"] = revision
    result["generated_at"] = generated_at
    totals = coverage["totals"]
    result["coverage"]["line"] = {
        "COVERED": totals["covered_lines"],
        "coverable": totals["num_statements"],
    }
    result["coverage"]["branch"] = {
        "covered": totals["covered_branches"],
        "coverable": totals["num_branches"],
    }
    result["coverage"]["per_unit"] = [
        {
            "unit": path,
            "line": {
                "covered": values["summary"]["covered_lines"],
                "coverable": values["summary"]["num_statements"],
            },
            "branch": {
                "covered": values["summary"]["covered_branches"],
                "coverable": values["summary"]["num_branches"],
            },
        }
        for path, values in sorted(coverage["files"].items())
    ]
    return result


def x_build_profile__mutmut_20(template: dict, coverage: dict, *, revision: str, generated_at: str) -> dict:
    """Build a fresh profile without changing its policy or scope."""
    result = copy.deepcopy(template)
    result["source_revision"] = revision
    result["generated_at"] = generated_at
    totals = coverage["totals"]
    result["coverage"]["line"] = {
        "covered": totals["XXcovered_linesXX"],
        "coverable": totals["num_statements"],
    }
    result["coverage"]["branch"] = {
        "covered": totals["covered_branches"],
        "coverable": totals["num_branches"],
    }
    result["coverage"]["per_unit"] = [
        {
            "unit": path,
            "line": {
                "covered": values["summary"]["covered_lines"],
                "coverable": values["summary"]["num_statements"],
            },
            "branch": {
                "covered": values["summary"]["covered_branches"],
                "coverable": values["summary"]["num_branches"],
            },
        }
        for path, values in sorted(coverage["files"].items())
    ]
    return result


def x_build_profile__mutmut_21(template: dict, coverage: dict, *, revision: str, generated_at: str) -> dict:
    """Build a fresh profile without changing its policy or scope."""
    result = copy.deepcopy(template)
    result["source_revision"] = revision
    result["generated_at"] = generated_at
    totals = coverage["totals"]
    result["coverage"]["line"] = {
        "covered": totals["COVERED_LINES"],
        "coverable": totals["num_statements"],
    }
    result["coverage"]["branch"] = {
        "covered": totals["covered_branches"],
        "coverable": totals["num_branches"],
    }
    result["coverage"]["per_unit"] = [
        {
            "unit": path,
            "line": {
                "covered": values["summary"]["covered_lines"],
                "coverable": values["summary"]["num_statements"],
            },
            "branch": {
                "covered": values["summary"]["covered_branches"],
                "coverable": values["summary"]["num_branches"],
            },
        }
        for path, values in sorted(coverage["files"].items())
    ]
    return result


def x_build_profile__mutmut_22(template: dict, coverage: dict, *, revision: str, generated_at: str) -> dict:
    """Build a fresh profile without changing its policy or scope."""
    result = copy.deepcopy(template)
    result["source_revision"] = revision
    result["generated_at"] = generated_at
    totals = coverage["totals"]
    result["coverage"]["line"] = {
        "covered": totals["covered_lines"],
        "XXcoverableXX": totals["num_statements"],
    }
    result["coverage"]["branch"] = {
        "covered": totals["covered_branches"],
        "coverable": totals["num_branches"],
    }
    result["coverage"]["per_unit"] = [
        {
            "unit": path,
            "line": {
                "covered": values["summary"]["covered_lines"],
                "coverable": values["summary"]["num_statements"],
            },
            "branch": {
                "covered": values["summary"]["covered_branches"],
                "coverable": values["summary"]["num_branches"],
            },
        }
        for path, values in sorted(coverage["files"].items())
    ]
    return result


def x_build_profile__mutmut_23(template: dict, coverage: dict, *, revision: str, generated_at: str) -> dict:
    """Build a fresh profile without changing its policy or scope."""
    result = copy.deepcopy(template)
    result["source_revision"] = revision
    result["generated_at"] = generated_at
    totals = coverage["totals"]
    result["coverage"]["line"] = {
        "covered": totals["covered_lines"],
        "COVERABLE": totals["num_statements"],
    }
    result["coverage"]["branch"] = {
        "covered": totals["covered_branches"],
        "coverable": totals["num_branches"],
    }
    result["coverage"]["per_unit"] = [
        {
            "unit": path,
            "line": {
                "covered": values["summary"]["covered_lines"],
                "coverable": values["summary"]["num_statements"],
            },
            "branch": {
                "covered": values["summary"]["covered_branches"],
                "coverable": values["summary"]["num_branches"],
            },
        }
        for path, values in sorted(coverage["files"].items())
    ]
    return result


def x_build_profile__mutmut_24(template: dict, coverage: dict, *, revision: str, generated_at: str) -> dict:
    """Build a fresh profile without changing its policy or scope."""
    result = copy.deepcopy(template)
    result["source_revision"] = revision
    result["generated_at"] = generated_at
    totals = coverage["totals"]
    result["coverage"]["line"] = {
        "covered": totals["covered_lines"],
        "coverable": totals["XXnum_statementsXX"],
    }
    result["coverage"]["branch"] = {
        "covered": totals["covered_branches"],
        "coverable": totals["num_branches"],
    }
    result["coverage"]["per_unit"] = [
        {
            "unit": path,
            "line": {
                "covered": values["summary"]["covered_lines"],
                "coverable": values["summary"]["num_statements"],
            },
            "branch": {
                "covered": values["summary"]["covered_branches"],
                "coverable": values["summary"]["num_branches"],
            },
        }
        for path, values in sorted(coverage["files"].items())
    ]
    return result


def x_build_profile__mutmut_25(template: dict, coverage: dict, *, revision: str, generated_at: str) -> dict:
    """Build a fresh profile without changing its policy or scope."""
    result = copy.deepcopy(template)
    result["source_revision"] = revision
    result["generated_at"] = generated_at
    totals = coverage["totals"]
    result["coverage"]["line"] = {
        "covered": totals["covered_lines"],
        "coverable": totals["NUM_STATEMENTS"],
    }
    result["coverage"]["branch"] = {
        "covered": totals["covered_branches"],
        "coverable": totals["num_branches"],
    }
    result["coverage"]["per_unit"] = [
        {
            "unit": path,
            "line": {
                "covered": values["summary"]["covered_lines"],
                "coverable": values["summary"]["num_statements"],
            },
            "branch": {
                "covered": values["summary"]["covered_branches"],
                "coverable": values["summary"]["num_branches"],
            },
        }
        for path, values in sorted(coverage["files"].items())
    ]
    return result


def x_build_profile__mutmut_26(template: dict, coverage: dict, *, revision: str, generated_at: str) -> dict:
    """Build a fresh profile without changing its policy or scope."""
    result = copy.deepcopy(template)
    result["source_revision"] = revision
    result["generated_at"] = generated_at
    totals = coverage["totals"]
    result["coverage"]["line"] = {
        "covered": totals["covered_lines"],
        "coverable": totals["num_statements"],
    }
    result["coverage"]["branch"] = None
    result["coverage"]["per_unit"] = [
        {
            "unit": path,
            "line": {
                "covered": values["summary"]["covered_lines"],
                "coverable": values["summary"]["num_statements"],
            },
            "branch": {
                "covered": values["summary"]["covered_branches"],
                "coverable": values["summary"]["num_branches"],
            },
        }
        for path, values in sorted(coverage["files"].items())
    ]
    return result


def x_build_profile__mutmut_27(template: dict, coverage: dict, *, revision: str, generated_at: str) -> dict:
    """Build a fresh profile without changing its policy or scope."""
    result = copy.deepcopy(template)
    result["source_revision"] = revision
    result["generated_at"] = generated_at
    totals = coverage["totals"]
    result["coverage"]["line"] = {
        "covered": totals["covered_lines"],
        "coverable": totals["num_statements"],
    }
    result["XXcoverageXX"]["branch"] = {
        "covered": totals["covered_branches"],
        "coverable": totals["num_branches"],
    }
    result["coverage"]["per_unit"] = [
        {
            "unit": path,
            "line": {
                "covered": values["summary"]["covered_lines"],
                "coverable": values["summary"]["num_statements"],
            },
            "branch": {
                "covered": values["summary"]["covered_branches"],
                "coverable": values["summary"]["num_branches"],
            },
        }
        for path, values in sorted(coverage["files"].items())
    ]
    return result


def x_build_profile__mutmut_28(template: dict, coverage: dict, *, revision: str, generated_at: str) -> dict:
    """Build a fresh profile without changing its policy or scope."""
    result = copy.deepcopy(template)
    result["source_revision"] = revision
    result["generated_at"] = generated_at
    totals = coverage["totals"]
    result["coverage"]["line"] = {
        "covered": totals["covered_lines"],
        "coverable": totals["num_statements"],
    }
    result["COVERAGE"]["branch"] = {
        "covered": totals["covered_branches"],
        "coverable": totals["num_branches"],
    }
    result["coverage"]["per_unit"] = [
        {
            "unit": path,
            "line": {
                "covered": values["summary"]["covered_lines"],
                "coverable": values["summary"]["num_statements"],
            },
            "branch": {
                "covered": values["summary"]["covered_branches"],
                "coverable": values["summary"]["num_branches"],
            },
        }
        for path, values in sorted(coverage["files"].items())
    ]
    return result


def x_build_profile__mutmut_29(template: dict, coverage: dict, *, revision: str, generated_at: str) -> dict:
    """Build a fresh profile without changing its policy or scope."""
    result = copy.deepcopy(template)
    result["source_revision"] = revision
    result["generated_at"] = generated_at
    totals = coverage["totals"]
    result["coverage"]["line"] = {
        "covered": totals["covered_lines"],
        "coverable": totals["num_statements"],
    }
    result["coverage"]["XXbranchXX"] = {
        "covered": totals["covered_branches"],
        "coverable": totals["num_branches"],
    }
    result["coverage"]["per_unit"] = [
        {
            "unit": path,
            "line": {
                "covered": values["summary"]["covered_lines"],
                "coverable": values["summary"]["num_statements"],
            },
            "branch": {
                "covered": values["summary"]["covered_branches"],
                "coverable": values["summary"]["num_branches"],
            },
        }
        for path, values in sorted(coverage["files"].items())
    ]
    return result


def x_build_profile__mutmut_30(template: dict, coverage: dict, *, revision: str, generated_at: str) -> dict:
    """Build a fresh profile without changing its policy or scope."""
    result = copy.deepcopy(template)
    result["source_revision"] = revision
    result["generated_at"] = generated_at
    totals = coverage["totals"]
    result["coverage"]["line"] = {
        "covered": totals["covered_lines"],
        "coverable": totals["num_statements"],
    }
    result["coverage"]["BRANCH"] = {
        "covered": totals["covered_branches"],
        "coverable": totals["num_branches"],
    }
    result["coverage"]["per_unit"] = [
        {
            "unit": path,
            "line": {
                "covered": values["summary"]["covered_lines"],
                "coverable": values["summary"]["num_statements"],
            },
            "branch": {
                "covered": values["summary"]["covered_branches"],
                "coverable": values["summary"]["num_branches"],
            },
        }
        for path, values in sorted(coverage["files"].items())
    ]
    return result


def x_build_profile__mutmut_31(template: dict, coverage: dict, *, revision: str, generated_at: str) -> dict:
    """Build a fresh profile without changing its policy or scope."""
    result = copy.deepcopy(template)
    result["source_revision"] = revision
    result["generated_at"] = generated_at
    totals = coverage["totals"]
    result["coverage"]["line"] = {
        "covered": totals["covered_lines"],
        "coverable": totals["num_statements"],
    }
    result["coverage"]["branch"] = {
        "XXcoveredXX": totals["covered_branches"],
        "coverable": totals["num_branches"],
    }
    result["coverage"]["per_unit"] = [
        {
            "unit": path,
            "line": {
                "covered": values["summary"]["covered_lines"],
                "coverable": values["summary"]["num_statements"],
            },
            "branch": {
                "covered": values["summary"]["covered_branches"],
                "coverable": values["summary"]["num_branches"],
            },
        }
        for path, values in sorted(coverage["files"].items())
    ]
    return result


def x_build_profile__mutmut_32(template: dict, coverage: dict, *, revision: str, generated_at: str) -> dict:
    """Build a fresh profile without changing its policy or scope."""
    result = copy.deepcopy(template)
    result["source_revision"] = revision
    result["generated_at"] = generated_at
    totals = coverage["totals"]
    result["coverage"]["line"] = {
        "covered": totals["covered_lines"],
        "coverable": totals["num_statements"],
    }
    result["coverage"]["branch"] = {
        "COVERED": totals["covered_branches"],
        "coverable": totals["num_branches"],
    }
    result["coverage"]["per_unit"] = [
        {
            "unit": path,
            "line": {
                "covered": values["summary"]["covered_lines"],
                "coverable": values["summary"]["num_statements"],
            },
            "branch": {
                "covered": values["summary"]["covered_branches"],
                "coverable": values["summary"]["num_branches"],
            },
        }
        for path, values in sorted(coverage["files"].items())
    ]
    return result


def x_build_profile__mutmut_33(template: dict, coverage: dict, *, revision: str, generated_at: str) -> dict:
    """Build a fresh profile without changing its policy or scope."""
    result = copy.deepcopy(template)
    result["source_revision"] = revision
    result["generated_at"] = generated_at
    totals = coverage["totals"]
    result["coverage"]["line"] = {
        "covered": totals["covered_lines"],
        "coverable": totals["num_statements"],
    }
    result["coverage"]["branch"] = {
        "covered": totals["XXcovered_branchesXX"],
        "coverable": totals["num_branches"],
    }
    result["coverage"]["per_unit"] = [
        {
            "unit": path,
            "line": {
                "covered": values["summary"]["covered_lines"],
                "coverable": values["summary"]["num_statements"],
            },
            "branch": {
                "covered": values["summary"]["covered_branches"],
                "coverable": values["summary"]["num_branches"],
            },
        }
        for path, values in sorted(coverage["files"].items())
    ]
    return result


def x_build_profile__mutmut_34(template: dict, coverage: dict, *, revision: str, generated_at: str) -> dict:
    """Build a fresh profile without changing its policy or scope."""
    result = copy.deepcopy(template)
    result["source_revision"] = revision
    result["generated_at"] = generated_at
    totals = coverage["totals"]
    result["coverage"]["line"] = {
        "covered": totals["covered_lines"],
        "coverable": totals["num_statements"],
    }
    result["coverage"]["branch"] = {
        "covered": totals["COVERED_BRANCHES"],
        "coverable": totals["num_branches"],
    }
    result["coverage"]["per_unit"] = [
        {
            "unit": path,
            "line": {
                "covered": values["summary"]["covered_lines"],
                "coverable": values["summary"]["num_statements"],
            },
            "branch": {
                "covered": values["summary"]["covered_branches"],
                "coverable": values["summary"]["num_branches"],
            },
        }
        for path, values in sorted(coverage["files"].items())
    ]
    return result


def x_build_profile__mutmut_35(template: dict, coverage: dict, *, revision: str, generated_at: str) -> dict:
    """Build a fresh profile without changing its policy or scope."""
    result = copy.deepcopy(template)
    result["source_revision"] = revision
    result["generated_at"] = generated_at
    totals = coverage["totals"]
    result["coverage"]["line"] = {
        "covered": totals["covered_lines"],
        "coverable": totals["num_statements"],
    }
    result["coverage"]["branch"] = {
        "covered": totals["covered_branches"],
        "XXcoverableXX": totals["num_branches"],
    }
    result["coverage"]["per_unit"] = [
        {
            "unit": path,
            "line": {
                "covered": values["summary"]["covered_lines"],
                "coverable": values["summary"]["num_statements"],
            },
            "branch": {
                "covered": values["summary"]["covered_branches"],
                "coverable": values["summary"]["num_branches"],
            },
        }
        for path, values in sorted(coverage["files"].items())
    ]
    return result


def x_build_profile__mutmut_36(template: dict, coverage: dict, *, revision: str, generated_at: str) -> dict:
    """Build a fresh profile without changing its policy or scope."""
    result = copy.deepcopy(template)
    result["source_revision"] = revision
    result["generated_at"] = generated_at
    totals = coverage["totals"]
    result["coverage"]["line"] = {
        "covered": totals["covered_lines"],
        "coverable": totals["num_statements"],
    }
    result["coverage"]["branch"] = {
        "covered": totals["covered_branches"],
        "COVERABLE": totals["num_branches"],
    }
    result["coverage"]["per_unit"] = [
        {
            "unit": path,
            "line": {
                "covered": values["summary"]["covered_lines"],
                "coverable": values["summary"]["num_statements"],
            },
            "branch": {
                "covered": values["summary"]["covered_branches"],
                "coverable": values["summary"]["num_branches"],
            },
        }
        for path, values in sorted(coverage["files"].items())
    ]
    return result


def x_build_profile__mutmut_37(template: dict, coverage: dict, *, revision: str, generated_at: str) -> dict:
    """Build a fresh profile without changing its policy or scope."""
    result = copy.deepcopy(template)
    result["source_revision"] = revision
    result["generated_at"] = generated_at
    totals = coverage["totals"]
    result["coverage"]["line"] = {
        "covered": totals["covered_lines"],
        "coverable": totals["num_statements"],
    }
    result["coverage"]["branch"] = {
        "covered": totals["covered_branches"],
        "coverable": totals["XXnum_branchesXX"],
    }
    result["coverage"]["per_unit"] = [
        {
            "unit": path,
            "line": {
                "covered": values["summary"]["covered_lines"],
                "coverable": values["summary"]["num_statements"],
            },
            "branch": {
                "covered": values["summary"]["covered_branches"],
                "coverable": values["summary"]["num_branches"],
            },
        }
        for path, values in sorted(coverage["files"].items())
    ]
    return result


def x_build_profile__mutmut_38(template: dict, coverage: dict, *, revision: str, generated_at: str) -> dict:
    """Build a fresh profile without changing its policy or scope."""
    result = copy.deepcopy(template)
    result["source_revision"] = revision
    result["generated_at"] = generated_at
    totals = coverage["totals"]
    result["coverage"]["line"] = {
        "covered": totals["covered_lines"],
        "coverable": totals["num_statements"],
    }
    result["coverage"]["branch"] = {
        "covered": totals["covered_branches"],
        "coverable": totals["NUM_BRANCHES"],
    }
    result["coverage"]["per_unit"] = [
        {
            "unit": path,
            "line": {
                "covered": values["summary"]["covered_lines"],
                "coverable": values["summary"]["num_statements"],
            },
            "branch": {
                "covered": values["summary"]["covered_branches"],
                "coverable": values["summary"]["num_branches"],
            },
        }
        for path, values in sorted(coverage["files"].items())
    ]
    return result


def x_build_profile__mutmut_39(template: dict, coverage: dict, *, revision: str, generated_at: str) -> dict:
    """Build a fresh profile without changing its policy or scope."""
    result = copy.deepcopy(template)
    result["source_revision"] = revision
    result["generated_at"] = generated_at
    totals = coverage["totals"]
    result["coverage"]["line"] = {
        "covered": totals["covered_lines"],
        "coverable": totals["num_statements"],
    }
    result["coverage"]["branch"] = {
        "covered": totals["covered_branches"],
        "coverable": totals["num_branches"],
    }
    result["coverage"]["per_unit"] = None
    return result


def x_build_profile__mutmut_40(template: dict, coverage: dict, *, revision: str, generated_at: str) -> dict:
    """Build a fresh profile without changing its policy or scope."""
    result = copy.deepcopy(template)
    result["source_revision"] = revision
    result["generated_at"] = generated_at
    totals = coverage["totals"]
    result["coverage"]["line"] = {
        "covered": totals["covered_lines"],
        "coverable": totals["num_statements"],
    }
    result["coverage"]["branch"] = {
        "covered": totals["covered_branches"],
        "coverable": totals["num_branches"],
    }
    result["XXcoverageXX"]["per_unit"] = [
        {
            "unit": path,
            "line": {
                "covered": values["summary"]["covered_lines"],
                "coverable": values["summary"]["num_statements"],
            },
            "branch": {
                "covered": values["summary"]["covered_branches"],
                "coverable": values["summary"]["num_branches"],
            },
        }
        for path, values in sorted(coverage["files"].items())
    ]
    return result


def x_build_profile__mutmut_41(template: dict, coverage: dict, *, revision: str, generated_at: str) -> dict:
    """Build a fresh profile without changing its policy or scope."""
    result = copy.deepcopy(template)
    result["source_revision"] = revision
    result["generated_at"] = generated_at
    totals = coverage["totals"]
    result["coverage"]["line"] = {
        "covered": totals["covered_lines"],
        "coverable": totals["num_statements"],
    }
    result["coverage"]["branch"] = {
        "covered": totals["covered_branches"],
        "coverable": totals["num_branches"],
    }
    result["COVERAGE"]["per_unit"] = [
        {
            "unit": path,
            "line": {
                "covered": values["summary"]["covered_lines"],
                "coverable": values["summary"]["num_statements"],
            },
            "branch": {
                "covered": values["summary"]["covered_branches"],
                "coverable": values["summary"]["num_branches"],
            },
        }
        for path, values in sorted(coverage["files"].items())
    ]
    return result


def x_build_profile__mutmut_42(template: dict, coverage: dict, *, revision: str, generated_at: str) -> dict:
    """Build a fresh profile without changing its policy or scope."""
    result = copy.deepcopy(template)
    result["source_revision"] = revision
    result["generated_at"] = generated_at
    totals = coverage["totals"]
    result["coverage"]["line"] = {
        "covered": totals["covered_lines"],
        "coverable": totals["num_statements"],
    }
    result["coverage"]["branch"] = {
        "covered": totals["covered_branches"],
        "coverable": totals["num_branches"],
    }
    result["coverage"]["XXper_unitXX"] = [
        {
            "unit": path,
            "line": {
                "covered": values["summary"]["covered_lines"],
                "coverable": values["summary"]["num_statements"],
            },
            "branch": {
                "covered": values["summary"]["covered_branches"],
                "coverable": values["summary"]["num_branches"],
            },
        }
        for path, values in sorted(coverage["files"].items())
    ]
    return result


def x_build_profile__mutmut_43(template: dict, coverage: dict, *, revision: str, generated_at: str) -> dict:
    """Build a fresh profile without changing its policy or scope."""
    result = copy.deepcopy(template)
    result["source_revision"] = revision
    result["generated_at"] = generated_at
    totals = coverage["totals"]
    result["coverage"]["line"] = {
        "covered": totals["covered_lines"],
        "coverable": totals["num_statements"],
    }
    result["coverage"]["branch"] = {
        "covered": totals["covered_branches"],
        "coverable": totals["num_branches"],
    }
    result["coverage"]["PER_UNIT"] = [
        {
            "unit": path,
            "line": {
                "covered": values["summary"]["covered_lines"],
                "coverable": values["summary"]["num_statements"],
            },
            "branch": {
                "covered": values["summary"]["covered_branches"],
                "coverable": values["summary"]["num_branches"],
            },
        }
        for path, values in sorted(coverage["files"].items())
    ]
    return result


def x_build_profile__mutmut_44(template: dict, coverage: dict, *, revision: str, generated_at: str) -> dict:
    """Build a fresh profile without changing its policy or scope."""
    result = copy.deepcopy(template)
    result["source_revision"] = revision
    result["generated_at"] = generated_at
    totals = coverage["totals"]
    result["coverage"]["line"] = {
        "covered": totals["covered_lines"],
        "coverable": totals["num_statements"],
    }
    result["coverage"]["branch"] = {
        "covered": totals["covered_branches"],
        "coverable": totals["num_branches"],
    }
    result["coverage"]["per_unit"] = [
        {
            "XXunitXX": path,
            "line": {
                "covered": values["summary"]["covered_lines"],
                "coverable": values["summary"]["num_statements"],
            },
            "branch": {
                "covered": values["summary"]["covered_branches"],
                "coverable": values["summary"]["num_branches"],
            },
        }
        for path, values in sorted(coverage["files"].items())
    ]
    return result


def x_build_profile__mutmut_45(template: dict, coverage: dict, *, revision: str, generated_at: str) -> dict:
    """Build a fresh profile without changing its policy or scope."""
    result = copy.deepcopy(template)
    result["source_revision"] = revision
    result["generated_at"] = generated_at
    totals = coverage["totals"]
    result["coverage"]["line"] = {
        "covered": totals["covered_lines"],
        "coverable": totals["num_statements"],
    }
    result["coverage"]["branch"] = {
        "covered": totals["covered_branches"],
        "coverable": totals["num_branches"],
    }
    result["coverage"]["per_unit"] = [
        {
            "UNIT": path,
            "line": {
                "covered": values["summary"]["covered_lines"],
                "coverable": values["summary"]["num_statements"],
            },
            "branch": {
                "covered": values["summary"]["covered_branches"],
                "coverable": values["summary"]["num_branches"],
            },
        }
        for path, values in sorted(coverage["files"].items())
    ]
    return result


def x_build_profile__mutmut_46(template: dict, coverage: dict, *, revision: str, generated_at: str) -> dict:
    """Build a fresh profile without changing its policy or scope."""
    result = copy.deepcopy(template)
    result["source_revision"] = revision
    result["generated_at"] = generated_at
    totals = coverage["totals"]
    result["coverage"]["line"] = {
        "covered": totals["covered_lines"],
        "coverable": totals["num_statements"],
    }
    result["coverage"]["branch"] = {
        "covered": totals["covered_branches"],
        "coverable": totals["num_branches"],
    }
    result["coverage"]["per_unit"] = [
        {
            "unit": path,
            "XXlineXX": {
                "covered": values["summary"]["covered_lines"],
                "coverable": values["summary"]["num_statements"],
            },
            "branch": {
                "covered": values["summary"]["covered_branches"],
                "coverable": values["summary"]["num_branches"],
            },
        }
        for path, values in sorted(coverage["files"].items())
    ]
    return result


def x_build_profile__mutmut_47(template: dict, coverage: dict, *, revision: str, generated_at: str) -> dict:
    """Build a fresh profile without changing its policy or scope."""
    result = copy.deepcopy(template)
    result["source_revision"] = revision
    result["generated_at"] = generated_at
    totals = coverage["totals"]
    result["coverage"]["line"] = {
        "covered": totals["covered_lines"],
        "coverable": totals["num_statements"],
    }
    result["coverage"]["branch"] = {
        "covered": totals["covered_branches"],
        "coverable": totals["num_branches"],
    }
    result["coverage"]["per_unit"] = [
        {
            "unit": path,
            "LINE": {
                "covered": values["summary"]["covered_lines"],
                "coverable": values["summary"]["num_statements"],
            },
            "branch": {
                "covered": values["summary"]["covered_branches"],
                "coverable": values["summary"]["num_branches"],
            },
        }
        for path, values in sorted(coverage["files"].items())
    ]
    return result


def x_build_profile__mutmut_48(template: dict, coverage: dict, *, revision: str, generated_at: str) -> dict:
    """Build a fresh profile without changing its policy or scope."""
    result = copy.deepcopy(template)
    result["source_revision"] = revision
    result["generated_at"] = generated_at
    totals = coverage["totals"]
    result["coverage"]["line"] = {
        "covered": totals["covered_lines"],
        "coverable": totals["num_statements"],
    }
    result["coverage"]["branch"] = {
        "covered": totals["covered_branches"],
        "coverable": totals["num_branches"],
    }
    result["coverage"]["per_unit"] = [
        {
            "unit": path,
            "line": {
                "XXcoveredXX": values["summary"]["covered_lines"],
                "coverable": values["summary"]["num_statements"],
            },
            "branch": {
                "covered": values["summary"]["covered_branches"],
                "coverable": values["summary"]["num_branches"],
            },
        }
        for path, values in sorted(coverage["files"].items())
    ]
    return result


def x_build_profile__mutmut_49(template: dict, coverage: dict, *, revision: str, generated_at: str) -> dict:
    """Build a fresh profile without changing its policy or scope."""
    result = copy.deepcopy(template)
    result["source_revision"] = revision
    result["generated_at"] = generated_at
    totals = coverage["totals"]
    result["coverage"]["line"] = {
        "covered": totals["covered_lines"],
        "coverable": totals["num_statements"],
    }
    result["coverage"]["branch"] = {
        "covered": totals["covered_branches"],
        "coverable": totals["num_branches"],
    }
    result["coverage"]["per_unit"] = [
        {
            "unit": path,
            "line": {
                "COVERED": values["summary"]["covered_lines"],
                "coverable": values["summary"]["num_statements"],
            },
            "branch": {
                "covered": values["summary"]["covered_branches"],
                "coverable": values["summary"]["num_branches"],
            },
        }
        for path, values in sorted(coverage["files"].items())
    ]
    return result


def x_build_profile__mutmut_50(template: dict, coverage: dict, *, revision: str, generated_at: str) -> dict:
    """Build a fresh profile without changing its policy or scope."""
    result = copy.deepcopy(template)
    result["source_revision"] = revision
    result["generated_at"] = generated_at
    totals = coverage["totals"]
    result["coverage"]["line"] = {
        "covered": totals["covered_lines"],
        "coverable": totals["num_statements"],
    }
    result["coverage"]["branch"] = {
        "covered": totals["covered_branches"],
        "coverable": totals["num_branches"],
    }
    result["coverage"]["per_unit"] = [
        {
            "unit": path,
            "line": {
                "covered": values["XXsummaryXX"]["covered_lines"],
                "coverable": values["summary"]["num_statements"],
            },
            "branch": {
                "covered": values["summary"]["covered_branches"],
                "coverable": values["summary"]["num_branches"],
            },
        }
        for path, values in sorted(coverage["files"].items())
    ]
    return result


def x_build_profile__mutmut_51(template: dict, coverage: dict, *, revision: str, generated_at: str) -> dict:
    """Build a fresh profile without changing its policy or scope."""
    result = copy.deepcopy(template)
    result["source_revision"] = revision
    result["generated_at"] = generated_at
    totals = coverage["totals"]
    result["coverage"]["line"] = {
        "covered": totals["covered_lines"],
        "coverable": totals["num_statements"],
    }
    result["coverage"]["branch"] = {
        "covered": totals["covered_branches"],
        "coverable": totals["num_branches"],
    }
    result["coverage"]["per_unit"] = [
        {
            "unit": path,
            "line": {
                "covered": values["SUMMARY"]["covered_lines"],
                "coverable": values["summary"]["num_statements"],
            },
            "branch": {
                "covered": values["summary"]["covered_branches"],
                "coverable": values["summary"]["num_branches"],
            },
        }
        for path, values in sorted(coverage["files"].items())
    ]
    return result


def x_build_profile__mutmut_52(template: dict, coverage: dict, *, revision: str, generated_at: str) -> dict:
    """Build a fresh profile without changing its policy or scope."""
    result = copy.deepcopy(template)
    result["source_revision"] = revision
    result["generated_at"] = generated_at
    totals = coverage["totals"]
    result["coverage"]["line"] = {
        "covered": totals["covered_lines"],
        "coverable": totals["num_statements"],
    }
    result["coverage"]["branch"] = {
        "covered": totals["covered_branches"],
        "coverable": totals["num_branches"],
    }
    result["coverage"]["per_unit"] = [
        {
            "unit": path,
            "line": {
                "covered": values["summary"]["XXcovered_linesXX"],
                "coverable": values["summary"]["num_statements"],
            },
            "branch": {
                "covered": values["summary"]["covered_branches"],
                "coverable": values["summary"]["num_branches"],
            },
        }
        for path, values in sorted(coverage["files"].items())
    ]
    return result


def x_build_profile__mutmut_53(template: dict, coverage: dict, *, revision: str, generated_at: str) -> dict:
    """Build a fresh profile without changing its policy or scope."""
    result = copy.deepcopy(template)
    result["source_revision"] = revision
    result["generated_at"] = generated_at
    totals = coverage["totals"]
    result["coverage"]["line"] = {
        "covered": totals["covered_lines"],
        "coverable": totals["num_statements"],
    }
    result["coverage"]["branch"] = {
        "covered": totals["covered_branches"],
        "coverable": totals["num_branches"],
    }
    result["coverage"]["per_unit"] = [
        {
            "unit": path,
            "line": {
                "covered": values["summary"]["COVERED_LINES"],
                "coverable": values["summary"]["num_statements"],
            },
            "branch": {
                "covered": values["summary"]["covered_branches"],
                "coverable": values["summary"]["num_branches"],
            },
        }
        for path, values in sorted(coverage["files"].items())
    ]
    return result


def x_build_profile__mutmut_54(template: dict, coverage: dict, *, revision: str, generated_at: str) -> dict:
    """Build a fresh profile without changing its policy or scope."""
    result = copy.deepcopy(template)
    result["source_revision"] = revision
    result["generated_at"] = generated_at
    totals = coverage["totals"]
    result["coverage"]["line"] = {
        "covered": totals["covered_lines"],
        "coverable": totals["num_statements"],
    }
    result["coverage"]["branch"] = {
        "covered": totals["covered_branches"],
        "coverable": totals["num_branches"],
    }
    result["coverage"]["per_unit"] = [
        {
            "unit": path,
            "line": {
                "covered": values["summary"]["covered_lines"],
                "XXcoverableXX": values["summary"]["num_statements"],
            },
            "branch": {
                "covered": values["summary"]["covered_branches"],
                "coverable": values["summary"]["num_branches"],
            },
        }
        for path, values in sorted(coverage["files"].items())
    ]
    return result


def x_build_profile__mutmut_55(template: dict, coverage: dict, *, revision: str, generated_at: str) -> dict:
    """Build a fresh profile without changing its policy or scope."""
    result = copy.deepcopy(template)
    result["source_revision"] = revision
    result["generated_at"] = generated_at
    totals = coverage["totals"]
    result["coverage"]["line"] = {
        "covered": totals["covered_lines"],
        "coverable": totals["num_statements"],
    }
    result["coverage"]["branch"] = {
        "covered": totals["covered_branches"],
        "coverable": totals["num_branches"],
    }
    result["coverage"]["per_unit"] = [
        {
            "unit": path,
            "line": {
                "covered": values["summary"]["covered_lines"],
                "COVERABLE": values["summary"]["num_statements"],
            },
            "branch": {
                "covered": values["summary"]["covered_branches"],
                "coverable": values["summary"]["num_branches"],
            },
        }
        for path, values in sorted(coverage["files"].items())
    ]
    return result


def x_build_profile__mutmut_56(template: dict, coverage: dict, *, revision: str, generated_at: str) -> dict:
    """Build a fresh profile without changing its policy or scope."""
    result = copy.deepcopy(template)
    result["source_revision"] = revision
    result["generated_at"] = generated_at
    totals = coverage["totals"]
    result["coverage"]["line"] = {
        "covered": totals["covered_lines"],
        "coverable": totals["num_statements"],
    }
    result["coverage"]["branch"] = {
        "covered": totals["covered_branches"],
        "coverable": totals["num_branches"],
    }
    result["coverage"]["per_unit"] = [
        {
            "unit": path,
            "line": {
                "covered": values["summary"]["covered_lines"],
                "coverable": values["XXsummaryXX"]["num_statements"],
            },
            "branch": {
                "covered": values["summary"]["covered_branches"],
                "coverable": values["summary"]["num_branches"],
            },
        }
        for path, values in sorted(coverage["files"].items())
    ]
    return result


def x_build_profile__mutmut_57(template: dict, coverage: dict, *, revision: str, generated_at: str) -> dict:
    """Build a fresh profile without changing its policy or scope."""
    result = copy.deepcopy(template)
    result["source_revision"] = revision
    result["generated_at"] = generated_at
    totals = coverage["totals"]
    result["coverage"]["line"] = {
        "covered": totals["covered_lines"],
        "coverable": totals["num_statements"],
    }
    result["coverage"]["branch"] = {
        "covered": totals["covered_branches"],
        "coverable": totals["num_branches"],
    }
    result["coverage"]["per_unit"] = [
        {
            "unit": path,
            "line": {
                "covered": values["summary"]["covered_lines"],
                "coverable": values["SUMMARY"]["num_statements"],
            },
            "branch": {
                "covered": values["summary"]["covered_branches"],
                "coverable": values["summary"]["num_branches"],
            },
        }
        for path, values in sorted(coverage["files"].items())
    ]
    return result


def x_build_profile__mutmut_58(template: dict, coverage: dict, *, revision: str, generated_at: str) -> dict:
    """Build a fresh profile without changing its policy or scope."""
    result = copy.deepcopy(template)
    result["source_revision"] = revision
    result["generated_at"] = generated_at
    totals = coverage["totals"]
    result["coverage"]["line"] = {
        "covered": totals["covered_lines"],
        "coverable": totals["num_statements"],
    }
    result["coverage"]["branch"] = {
        "covered": totals["covered_branches"],
        "coverable": totals["num_branches"],
    }
    result["coverage"]["per_unit"] = [
        {
            "unit": path,
            "line": {
                "covered": values["summary"]["covered_lines"],
                "coverable": values["summary"]["XXnum_statementsXX"],
            },
            "branch": {
                "covered": values["summary"]["covered_branches"],
                "coverable": values["summary"]["num_branches"],
            },
        }
        for path, values in sorted(coverage["files"].items())
    ]
    return result


def x_build_profile__mutmut_59(template: dict, coverage: dict, *, revision: str, generated_at: str) -> dict:
    """Build a fresh profile without changing its policy or scope."""
    result = copy.deepcopy(template)
    result["source_revision"] = revision
    result["generated_at"] = generated_at
    totals = coverage["totals"]
    result["coverage"]["line"] = {
        "covered": totals["covered_lines"],
        "coverable": totals["num_statements"],
    }
    result["coverage"]["branch"] = {
        "covered": totals["covered_branches"],
        "coverable": totals["num_branches"],
    }
    result["coverage"]["per_unit"] = [
        {
            "unit": path,
            "line": {
                "covered": values["summary"]["covered_lines"],
                "coverable": values["summary"]["NUM_STATEMENTS"],
            },
            "branch": {
                "covered": values["summary"]["covered_branches"],
                "coverable": values["summary"]["num_branches"],
            },
        }
        for path, values in sorted(coverage["files"].items())
    ]
    return result


def x_build_profile__mutmut_60(template: dict, coverage: dict, *, revision: str, generated_at: str) -> dict:
    """Build a fresh profile without changing its policy or scope."""
    result = copy.deepcopy(template)
    result["source_revision"] = revision
    result["generated_at"] = generated_at
    totals = coverage["totals"]
    result["coverage"]["line"] = {
        "covered": totals["covered_lines"],
        "coverable": totals["num_statements"],
    }
    result["coverage"]["branch"] = {
        "covered": totals["covered_branches"],
        "coverable": totals["num_branches"],
    }
    result["coverage"]["per_unit"] = [
        {
            "unit": path,
            "line": {
                "covered": values["summary"]["covered_lines"],
                "coverable": values["summary"]["num_statements"],
            },
            "XXbranchXX": {
                "covered": values["summary"]["covered_branches"],
                "coverable": values["summary"]["num_branches"],
            },
        }
        for path, values in sorted(coverage["files"].items())
    ]
    return result


def x_build_profile__mutmut_61(template: dict, coverage: dict, *, revision: str, generated_at: str) -> dict:
    """Build a fresh profile without changing its policy or scope."""
    result = copy.deepcopy(template)
    result["source_revision"] = revision
    result["generated_at"] = generated_at
    totals = coverage["totals"]
    result["coverage"]["line"] = {
        "covered": totals["covered_lines"],
        "coverable": totals["num_statements"],
    }
    result["coverage"]["branch"] = {
        "covered": totals["covered_branches"],
        "coverable": totals["num_branches"],
    }
    result["coverage"]["per_unit"] = [
        {
            "unit": path,
            "line": {
                "covered": values["summary"]["covered_lines"],
                "coverable": values["summary"]["num_statements"],
            },
            "BRANCH": {
                "covered": values["summary"]["covered_branches"],
                "coverable": values["summary"]["num_branches"],
            },
        }
        for path, values in sorted(coverage["files"].items())
    ]
    return result


def x_build_profile__mutmut_62(template: dict, coverage: dict, *, revision: str, generated_at: str) -> dict:
    """Build a fresh profile without changing its policy or scope."""
    result = copy.deepcopy(template)
    result["source_revision"] = revision
    result["generated_at"] = generated_at
    totals = coverage["totals"]
    result["coverage"]["line"] = {
        "covered": totals["covered_lines"],
        "coverable": totals["num_statements"],
    }
    result["coverage"]["branch"] = {
        "covered": totals["covered_branches"],
        "coverable": totals["num_branches"],
    }
    result["coverage"]["per_unit"] = [
        {
            "unit": path,
            "line": {
                "covered": values["summary"]["covered_lines"],
                "coverable": values["summary"]["num_statements"],
            },
            "branch": {
                "XXcoveredXX": values["summary"]["covered_branches"],
                "coverable": values["summary"]["num_branches"],
            },
        }
        for path, values in sorted(coverage["files"].items())
    ]
    return result


def x_build_profile__mutmut_63(template: dict, coverage: dict, *, revision: str, generated_at: str) -> dict:
    """Build a fresh profile without changing its policy or scope."""
    result = copy.deepcopy(template)
    result["source_revision"] = revision
    result["generated_at"] = generated_at
    totals = coverage["totals"]
    result["coverage"]["line"] = {
        "covered": totals["covered_lines"],
        "coverable": totals["num_statements"],
    }
    result["coverage"]["branch"] = {
        "covered": totals["covered_branches"],
        "coverable": totals["num_branches"],
    }
    result["coverage"]["per_unit"] = [
        {
            "unit": path,
            "line": {
                "covered": values["summary"]["covered_lines"],
                "coverable": values["summary"]["num_statements"],
            },
            "branch": {
                "COVERED": values["summary"]["covered_branches"],
                "coverable": values["summary"]["num_branches"],
            },
        }
        for path, values in sorted(coverage["files"].items())
    ]
    return result


def x_build_profile__mutmut_64(template: dict, coverage: dict, *, revision: str, generated_at: str) -> dict:
    """Build a fresh profile without changing its policy or scope."""
    result = copy.deepcopy(template)
    result["source_revision"] = revision
    result["generated_at"] = generated_at
    totals = coverage["totals"]
    result["coverage"]["line"] = {
        "covered": totals["covered_lines"],
        "coverable": totals["num_statements"],
    }
    result["coverage"]["branch"] = {
        "covered": totals["covered_branches"],
        "coverable": totals["num_branches"],
    }
    result["coverage"]["per_unit"] = [
        {
            "unit": path,
            "line": {
                "covered": values["summary"]["covered_lines"],
                "coverable": values["summary"]["num_statements"],
            },
            "branch": {
                "covered": values["XXsummaryXX"]["covered_branches"],
                "coverable": values["summary"]["num_branches"],
            },
        }
        for path, values in sorted(coverage["files"].items())
    ]
    return result


def x_build_profile__mutmut_65(template: dict, coverage: dict, *, revision: str, generated_at: str) -> dict:
    """Build a fresh profile without changing its policy or scope."""
    result = copy.deepcopy(template)
    result["source_revision"] = revision
    result["generated_at"] = generated_at
    totals = coverage["totals"]
    result["coverage"]["line"] = {
        "covered": totals["covered_lines"],
        "coverable": totals["num_statements"],
    }
    result["coverage"]["branch"] = {
        "covered": totals["covered_branches"],
        "coverable": totals["num_branches"],
    }
    result["coverage"]["per_unit"] = [
        {
            "unit": path,
            "line": {
                "covered": values["summary"]["covered_lines"],
                "coverable": values["summary"]["num_statements"],
            },
            "branch": {
                "covered": values["SUMMARY"]["covered_branches"],
                "coverable": values["summary"]["num_branches"],
            },
        }
        for path, values in sorted(coverage["files"].items())
    ]
    return result


def x_build_profile__mutmut_66(template: dict, coverage: dict, *, revision: str, generated_at: str) -> dict:
    """Build a fresh profile without changing its policy or scope."""
    result = copy.deepcopy(template)
    result["source_revision"] = revision
    result["generated_at"] = generated_at
    totals = coverage["totals"]
    result["coverage"]["line"] = {
        "covered": totals["covered_lines"],
        "coverable": totals["num_statements"],
    }
    result["coverage"]["branch"] = {
        "covered": totals["covered_branches"],
        "coverable": totals["num_branches"],
    }
    result["coverage"]["per_unit"] = [
        {
            "unit": path,
            "line": {
                "covered": values["summary"]["covered_lines"],
                "coverable": values["summary"]["num_statements"],
            },
            "branch": {
                "covered": values["summary"]["XXcovered_branchesXX"],
                "coverable": values["summary"]["num_branches"],
            },
        }
        for path, values in sorted(coverage["files"].items())
    ]
    return result


def x_build_profile__mutmut_67(template: dict, coverage: dict, *, revision: str, generated_at: str) -> dict:
    """Build a fresh profile without changing its policy or scope."""
    result = copy.deepcopy(template)
    result["source_revision"] = revision
    result["generated_at"] = generated_at
    totals = coverage["totals"]
    result["coverage"]["line"] = {
        "covered": totals["covered_lines"],
        "coverable": totals["num_statements"],
    }
    result["coverage"]["branch"] = {
        "covered": totals["covered_branches"],
        "coverable": totals["num_branches"],
    }
    result["coverage"]["per_unit"] = [
        {
            "unit": path,
            "line": {
                "covered": values["summary"]["covered_lines"],
                "coverable": values["summary"]["num_statements"],
            },
            "branch": {
                "covered": values["summary"]["COVERED_BRANCHES"],
                "coverable": values["summary"]["num_branches"],
            },
        }
        for path, values in sorted(coverage["files"].items())
    ]
    return result


def x_build_profile__mutmut_68(template: dict, coverage: dict, *, revision: str, generated_at: str) -> dict:
    """Build a fresh profile without changing its policy or scope."""
    result = copy.deepcopy(template)
    result["source_revision"] = revision
    result["generated_at"] = generated_at
    totals = coverage["totals"]
    result["coverage"]["line"] = {
        "covered": totals["covered_lines"],
        "coverable": totals["num_statements"],
    }
    result["coverage"]["branch"] = {
        "covered": totals["covered_branches"],
        "coverable": totals["num_branches"],
    }
    result["coverage"]["per_unit"] = [
        {
            "unit": path,
            "line": {
                "covered": values["summary"]["covered_lines"],
                "coverable": values["summary"]["num_statements"],
            },
            "branch": {
                "covered": values["summary"]["covered_branches"],
                "XXcoverableXX": values["summary"]["num_branches"],
            },
        }
        for path, values in sorted(coverage["files"].items())
    ]
    return result


def x_build_profile__mutmut_69(template: dict, coverage: dict, *, revision: str, generated_at: str) -> dict:
    """Build a fresh profile without changing its policy or scope."""
    result = copy.deepcopy(template)
    result["source_revision"] = revision
    result["generated_at"] = generated_at
    totals = coverage["totals"]
    result["coverage"]["line"] = {
        "covered": totals["covered_lines"],
        "coverable": totals["num_statements"],
    }
    result["coverage"]["branch"] = {
        "covered": totals["covered_branches"],
        "coverable": totals["num_branches"],
    }
    result["coverage"]["per_unit"] = [
        {
            "unit": path,
            "line": {
                "covered": values["summary"]["covered_lines"],
                "coverable": values["summary"]["num_statements"],
            },
            "branch": {
                "covered": values["summary"]["covered_branches"],
                "COVERABLE": values["summary"]["num_branches"],
            },
        }
        for path, values in sorted(coverage["files"].items())
    ]
    return result


def x_build_profile__mutmut_70(template: dict, coverage: dict, *, revision: str, generated_at: str) -> dict:
    """Build a fresh profile without changing its policy or scope."""
    result = copy.deepcopy(template)
    result["source_revision"] = revision
    result["generated_at"] = generated_at
    totals = coverage["totals"]
    result["coverage"]["line"] = {
        "covered": totals["covered_lines"],
        "coverable": totals["num_statements"],
    }
    result["coverage"]["branch"] = {
        "covered": totals["covered_branches"],
        "coverable": totals["num_branches"],
    }
    result["coverage"]["per_unit"] = [
        {
            "unit": path,
            "line": {
                "covered": values["summary"]["covered_lines"],
                "coverable": values["summary"]["num_statements"],
            },
            "branch": {
                "covered": values["summary"]["covered_branches"],
                "coverable": values["XXsummaryXX"]["num_branches"],
            },
        }
        for path, values in sorted(coverage["files"].items())
    ]
    return result


def x_build_profile__mutmut_71(template: dict, coverage: dict, *, revision: str, generated_at: str) -> dict:
    """Build a fresh profile without changing its policy or scope."""
    result = copy.deepcopy(template)
    result["source_revision"] = revision
    result["generated_at"] = generated_at
    totals = coverage["totals"]
    result["coverage"]["line"] = {
        "covered": totals["covered_lines"],
        "coverable": totals["num_statements"],
    }
    result["coverage"]["branch"] = {
        "covered": totals["covered_branches"],
        "coverable": totals["num_branches"],
    }
    result["coverage"]["per_unit"] = [
        {
            "unit": path,
            "line": {
                "covered": values["summary"]["covered_lines"],
                "coverable": values["summary"]["num_statements"],
            },
            "branch": {
                "covered": values["summary"]["covered_branches"],
                "coverable": values["SUMMARY"]["num_branches"],
            },
        }
        for path, values in sorted(coverage["files"].items())
    ]
    return result


def x_build_profile__mutmut_72(template: dict, coverage: dict, *, revision: str, generated_at: str) -> dict:
    """Build a fresh profile without changing its policy or scope."""
    result = copy.deepcopy(template)
    result["source_revision"] = revision
    result["generated_at"] = generated_at
    totals = coverage["totals"]
    result["coverage"]["line"] = {
        "covered": totals["covered_lines"],
        "coverable": totals["num_statements"],
    }
    result["coverage"]["branch"] = {
        "covered": totals["covered_branches"],
        "coverable": totals["num_branches"],
    }
    result["coverage"]["per_unit"] = [
        {
            "unit": path,
            "line": {
                "covered": values["summary"]["covered_lines"],
                "coverable": values["summary"]["num_statements"],
            },
            "branch": {
                "covered": values["summary"]["covered_branches"],
                "coverable": values["summary"]["XXnum_branchesXX"],
            },
        }
        for path, values in sorted(coverage["files"].items())
    ]
    return result


def x_build_profile__mutmut_73(template: dict, coverage: dict, *, revision: str, generated_at: str) -> dict:
    """Build a fresh profile without changing its policy or scope."""
    result = copy.deepcopy(template)
    result["source_revision"] = revision
    result["generated_at"] = generated_at
    totals = coverage["totals"]
    result["coverage"]["line"] = {
        "covered": totals["covered_lines"],
        "coverable": totals["num_statements"],
    }
    result["coverage"]["branch"] = {
        "covered": totals["covered_branches"],
        "coverable": totals["num_branches"],
    }
    result["coverage"]["per_unit"] = [
        {
            "unit": path,
            "line": {
                "covered": values["summary"]["covered_lines"],
                "coverable": values["summary"]["num_statements"],
            },
            "branch": {
                "covered": values["summary"]["covered_branches"],
                "coverable": values["summary"]["NUM_BRANCHES"],
            },
        }
        for path, values in sorted(coverage["files"].items())
    ]
    return result


def x_build_profile__mutmut_74(template: dict, coverage: dict, *, revision: str, generated_at: str) -> dict:
    """Build a fresh profile without changing its policy or scope."""
    result = copy.deepcopy(template)
    result["source_revision"] = revision
    result["generated_at"] = generated_at
    totals = coverage["totals"]
    result["coverage"]["line"] = {
        "covered": totals["covered_lines"],
        "coverable": totals["num_statements"],
    }
    result["coverage"]["branch"] = {
        "covered": totals["covered_branches"],
        "coverable": totals["num_branches"],
    }
    result["coverage"]["per_unit"] = [
        {
            "unit": path,
            "line": {
                "covered": values["summary"]["covered_lines"],
                "coverable": values["summary"]["num_statements"],
            },
            "branch": {
                "covered": values["summary"]["covered_branches"],
                "coverable": values["summary"]["num_branches"],
            },
        }
        for path, values in sorted(None)
    ]
    return result


def x_build_profile__mutmut_75(template: dict, coverage: dict, *, revision: str, generated_at: str) -> dict:
    """Build a fresh profile without changing its policy or scope."""
    result = copy.deepcopy(template)
    result["source_revision"] = revision
    result["generated_at"] = generated_at
    totals = coverage["totals"]
    result["coverage"]["line"] = {
        "covered": totals["covered_lines"],
        "coverable": totals["num_statements"],
    }
    result["coverage"]["branch"] = {
        "covered": totals["covered_branches"],
        "coverable": totals["num_branches"],
    }
    result["coverage"]["per_unit"] = [
        {
            "unit": path,
            "line": {
                "covered": values["summary"]["covered_lines"],
                "coverable": values["summary"]["num_statements"],
            },
            "branch": {
                "covered": values["summary"]["covered_branches"],
                "coverable": values["summary"]["num_branches"],
            },
        }
        for path, values in sorted(coverage["XXfilesXX"].items())
    ]
    return result


def x_build_profile__mutmut_76(template: dict, coverage: dict, *, revision: str, generated_at: str) -> dict:
    """Build a fresh profile without changing its policy or scope."""
    result = copy.deepcopy(template)
    result["source_revision"] = revision
    result["generated_at"] = generated_at
    totals = coverage["totals"]
    result["coverage"]["line"] = {
        "covered": totals["covered_lines"],
        "coverable": totals["num_statements"],
    }
    result["coverage"]["branch"] = {
        "covered": totals["covered_branches"],
        "coverable": totals["num_branches"],
    }
    result["coverage"]["per_unit"] = [
        {
            "unit": path,
            "line": {
                "covered": values["summary"]["covered_lines"],
                "coverable": values["summary"]["num_statements"],
            },
            "branch": {
                "covered": values["summary"]["covered_branches"],
                "coverable": values["summary"]["num_branches"],
            },
        }
        for path, values in sorted(coverage["FILES"].items())
    ]
    return result

mutants_x_build_profile__mutmut['_mutmut_orig'] = x_build_profile__mutmut_orig # type: ignore # mutmut generated
mutants_x_build_profile__mutmut['x_build_profile__mutmut_1'] = x_build_profile__mutmut_1 # type: ignore # mutmut generated
mutants_x_build_profile__mutmut['x_build_profile__mutmut_2'] = x_build_profile__mutmut_2 # type: ignore # mutmut generated
mutants_x_build_profile__mutmut['x_build_profile__mutmut_3'] = x_build_profile__mutmut_3 # type: ignore # mutmut generated
mutants_x_build_profile__mutmut['x_build_profile__mutmut_4'] = x_build_profile__mutmut_4 # type: ignore # mutmut generated
mutants_x_build_profile__mutmut['x_build_profile__mutmut_5'] = x_build_profile__mutmut_5 # type: ignore # mutmut generated
mutants_x_build_profile__mutmut['x_build_profile__mutmut_6'] = x_build_profile__mutmut_6 # type: ignore # mutmut generated
mutants_x_build_profile__mutmut['x_build_profile__mutmut_7'] = x_build_profile__mutmut_7 # type: ignore # mutmut generated
mutants_x_build_profile__mutmut['x_build_profile__mutmut_8'] = x_build_profile__mutmut_8 # type: ignore # mutmut generated
mutants_x_build_profile__mutmut['x_build_profile__mutmut_9'] = x_build_profile__mutmut_9 # type: ignore # mutmut generated
mutants_x_build_profile__mutmut['x_build_profile__mutmut_10'] = x_build_profile__mutmut_10 # type: ignore # mutmut generated
mutants_x_build_profile__mutmut['x_build_profile__mutmut_11'] = x_build_profile__mutmut_11 # type: ignore # mutmut generated
mutants_x_build_profile__mutmut['x_build_profile__mutmut_12'] = x_build_profile__mutmut_12 # type: ignore # mutmut generated
mutants_x_build_profile__mutmut['x_build_profile__mutmut_13'] = x_build_profile__mutmut_13 # type: ignore # mutmut generated
mutants_x_build_profile__mutmut['x_build_profile__mutmut_14'] = x_build_profile__mutmut_14 # type: ignore # mutmut generated
mutants_x_build_profile__mutmut['x_build_profile__mutmut_15'] = x_build_profile__mutmut_15 # type: ignore # mutmut generated
mutants_x_build_profile__mutmut['x_build_profile__mutmut_16'] = x_build_profile__mutmut_16 # type: ignore # mutmut generated
mutants_x_build_profile__mutmut['x_build_profile__mutmut_17'] = x_build_profile__mutmut_17 # type: ignore # mutmut generated
mutants_x_build_profile__mutmut['x_build_profile__mutmut_18'] = x_build_profile__mutmut_18 # type: ignore # mutmut generated
mutants_x_build_profile__mutmut['x_build_profile__mutmut_19'] = x_build_profile__mutmut_19 # type: ignore # mutmut generated
mutants_x_build_profile__mutmut['x_build_profile__mutmut_20'] = x_build_profile__mutmut_20 # type: ignore # mutmut generated
mutants_x_build_profile__mutmut['x_build_profile__mutmut_21'] = x_build_profile__mutmut_21 # type: ignore # mutmut generated
mutants_x_build_profile__mutmut['x_build_profile__mutmut_22'] = x_build_profile__mutmut_22 # type: ignore # mutmut generated
mutants_x_build_profile__mutmut['x_build_profile__mutmut_23'] = x_build_profile__mutmut_23 # type: ignore # mutmut generated
mutants_x_build_profile__mutmut['x_build_profile__mutmut_24'] = x_build_profile__mutmut_24 # type: ignore # mutmut generated
mutants_x_build_profile__mutmut['x_build_profile__mutmut_25'] = x_build_profile__mutmut_25 # type: ignore # mutmut generated
mutants_x_build_profile__mutmut['x_build_profile__mutmut_26'] = x_build_profile__mutmut_26 # type: ignore # mutmut generated
mutants_x_build_profile__mutmut['x_build_profile__mutmut_27'] = x_build_profile__mutmut_27 # type: ignore # mutmut generated
mutants_x_build_profile__mutmut['x_build_profile__mutmut_28'] = x_build_profile__mutmut_28 # type: ignore # mutmut generated
mutants_x_build_profile__mutmut['x_build_profile__mutmut_29'] = x_build_profile__mutmut_29 # type: ignore # mutmut generated
mutants_x_build_profile__mutmut['x_build_profile__mutmut_30'] = x_build_profile__mutmut_30 # type: ignore # mutmut generated
mutants_x_build_profile__mutmut['x_build_profile__mutmut_31'] = x_build_profile__mutmut_31 # type: ignore # mutmut generated
mutants_x_build_profile__mutmut['x_build_profile__mutmut_32'] = x_build_profile__mutmut_32 # type: ignore # mutmut generated
mutants_x_build_profile__mutmut['x_build_profile__mutmut_33'] = x_build_profile__mutmut_33 # type: ignore # mutmut generated
mutants_x_build_profile__mutmut['x_build_profile__mutmut_34'] = x_build_profile__mutmut_34 # type: ignore # mutmut generated
mutants_x_build_profile__mutmut['x_build_profile__mutmut_35'] = x_build_profile__mutmut_35 # type: ignore # mutmut generated
mutants_x_build_profile__mutmut['x_build_profile__mutmut_36'] = x_build_profile__mutmut_36 # type: ignore # mutmut generated
mutants_x_build_profile__mutmut['x_build_profile__mutmut_37'] = x_build_profile__mutmut_37 # type: ignore # mutmut generated
mutants_x_build_profile__mutmut['x_build_profile__mutmut_38'] = x_build_profile__mutmut_38 # type: ignore # mutmut generated
mutants_x_build_profile__mutmut['x_build_profile__mutmut_39'] = x_build_profile__mutmut_39 # type: ignore # mutmut generated
mutants_x_build_profile__mutmut['x_build_profile__mutmut_40'] = x_build_profile__mutmut_40 # type: ignore # mutmut generated
mutants_x_build_profile__mutmut['x_build_profile__mutmut_41'] = x_build_profile__mutmut_41 # type: ignore # mutmut generated
mutants_x_build_profile__mutmut['x_build_profile__mutmut_42'] = x_build_profile__mutmut_42 # type: ignore # mutmut generated
mutants_x_build_profile__mutmut['x_build_profile__mutmut_43'] = x_build_profile__mutmut_43 # type: ignore # mutmut generated
mutants_x_build_profile__mutmut['x_build_profile__mutmut_44'] = x_build_profile__mutmut_44 # type: ignore # mutmut generated
mutants_x_build_profile__mutmut['x_build_profile__mutmut_45'] = x_build_profile__mutmut_45 # type: ignore # mutmut generated
mutants_x_build_profile__mutmut['x_build_profile__mutmut_46'] = x_build_profile__mutmut_46 # type: ignore # mutmut generated
mutants_x_build_profile__mutmut['x_build_profile__mutmut_47'] = x_build_profile__mutmut_47 # type: ignore # mutmut generated
mutants_x_build_profile__mutmut['x_build_profile__mutmut_48'] = x_build_profile__mutmut_48 # type: ignore # mutmut generated
mutants_x_build_profile__mutmut['x_build_profile__mutmut_49'] = x_build_profile__mutmut_49 # type: ignore # mutmut generated
mutants_x_build_profile__mutmut['x_build_profile__mutmut_50'] = x_build_profile__mutmut_50 # type: ignore # mutmut generated
mutants_x_build_profile__mutmut['x_build_profile__mutmut_51'] = x_build_profile__mutmut_51 # type: ignore # mutmut generated
mutants_x_build_profile__mutmut['x_build_profile__mutmut_52'] = x_build_profile__mutmut_52 # type: ignore # mutmut generated
mutants_x_build_profile__mutmut['x_build_profile__mutmut_53'] = x_build_profile__mutmut_53 # type: ignore # mutmut generated
mutants_x_build_profile__mutmut['x_build_profile__mutmut_54'] = x_build_profile__mutmut_54 # type: ignore # mutmut generated
mutants_x_build_profile__mutmut['x_build_profile__mutmut_55'] = x_build_profile__mutmut_55 # type: ignore # mutmut generated
mutants_x_build_profile__mutmut['x_build_profile__mutmut_56'] = x_build_profile__mutmut_56 # type: ignore # mutmut generated
mutants_x_build_profile__mutmut['x_build_profile__mutmut_57'] = x_build_profile__mutmut_57 # type: ignore # mutmut generated
mutants_x_build_profile__mutmut['x_build_profile__mutmut_58'] = x_build_profile__mutmut_58 # type: ignore # mutmut generated
mutants_x_build_profile__mutmut['x_build_profile__mutmut_59'] = x_build_profile__mutmut_59 # type: ignore # mutmut generated
mutants_x_build_profile__mutmut['x_build_profile__mutmut_60'] = x_build_profile__mutmut_60 # type: ignore # mutmut generated
mutants_x_build_profile__mutmut['x_build_profile__mutmut_61'] = x_build_profile__mutmut_61 # type: ignore # mutmut generated
mutants_x_build_profile__mutmut['x_build_profile__mutmut_62'] = x_build_profile__mutmut_62 # type: ignore # mutmut generated
mutants_x_build_profile__mutmut['x_build_profile__mutmut_63'] = x_build_profile__mutmut_63 # type: ignore # mutmut generated
mutants_x_build_profile__mutmut['x_build_profile__mutmut_64'] = x_build_profile__mutmut_64 # type: ignore # mutmut generated
mutants_x_build_profile__mutmut['x_build_profile__mutmut_65'] = x_build_profile__mutmut_65 # type: ignore # mutmut generated
mutants_x_build_profile__mutmut['x_build_profile__mutmut_66'] = x_build_profile__mutmut_66 # type: ignore # mutmut generated
mutants_x_build_profile__mutmut['x_build_profile__mutmut_67'] = x_build_profile__mutmut_67 # type: ignore # mutmut generated
mutants_x_build_profile__mutmut['x_build_profile__mutmut_68'] = x_build_profile__mutmut_68 # type: ignore # mutmut generated
mutants_x_build_profile__mutmut['x_build_profile__mutmut_69'] = x_build_profile__mutmut_69 # type: ignore # mutmut generated
mutants_x_build_profile__mutmut['x_build_profile__mutmut_70'] = x_build_profile__mutmut_70 # type: ignore # mutmut generated
mutants_x_build_profile__mutmut['x_build_profile__mutmut_71'] = x_build_profile__mutmut_71 # type: ignore # mutmut generated
mutants_x_build_profile__mutmut['x_build_profile__mutmut_72'] = x_build_profile__mutmut_72 # type: ignore # mutmut generated
mutants_x_build_profile__mutmut['x_build_profile__mutmut_73'] = x_build_profile__mutmut_73 # type: ignore # mutmut generated
mutants_x_build_profile__mutmut['x_build_profile__mutmut_74'] = x_build_profile__mutmut_74 # type: ignore # mutmut generated
mutants_x_build_profile__mutmut['x_build_profile__mutmut_75'] = x_build_profile__mutmut_75 # type: ignore # mutmut generated
mutants_x_build_profile__mutmut['x_build_profile__mutmut_76'] = x_build_profile__mutmut_76 # type: ignore # mutmut generated
mutants_x_main__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_main__mutmut)
def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--coverage", type=Path, required=True)
    parser.add_argument("--template", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    revision = subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip()
    result = build_profile(
        json.loads(args.template.read_text()),
        json.loads(args.coverage.read_text()),
        revision=revision,
        generated_at=datetime.now(UTC).isoformat(),
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")


def x_main__mutmut_orig() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--coverage", type=Path, required=True)
    parser.add_argument("--template", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    revision = subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip()
    result = build_profile(
        json.loads(args.template.read_text()),
        json.loads(args.coverage.read_text()),
        revision=revision,
        generated_at=datetime.now(UTC).isoformat(),
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")


def x_main__mutmut_1() -> None:
    parser = None
    parser.add_argument("--coverage", type=Path, required=True)
    parser.add_argument("--template", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    revision = subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip()
    result = build_profile(
        json.loads(args.template.read_text()),
        json.loads(args.coverage.read_text()),
        revision=revision,
        generated_at=datetime.now(UTC).isoformat(),
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")


def x_main__mutmut_2() -> None:
    parser = argparse.ArgumentParser(description=None)
    parser.add_argument("--coverage", type=Path, required=True)
    parser.add_argument("--template", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    revision = subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip()
    result = build_profile(
        json.loads(args.template.read_text()),
        json.loads(args.coverage.read_text()),
        revision=revision,
        generated_at=datetime.now(UTC).isoformat(),
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")


def x_main__mutmut_3() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(None, type=Path, required=True)
    parser.add_argument("--template", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    revision = subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip()
    result = build_profile(
        json.loads(args.template.read_text()),
        json.loads(args.coverage.read_text()),
        revision=revision,
        generated_at=datetime.now(UTC).isoformat(),
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")


def x_main__mutmut_4() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--coverage", type=None, required=True)
    parser.add_argument("--template", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    revision = subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip()
    result = build_profile(
        json.loads(args.template.read_text()),
        json.loads(args.coverage.read_text()),
        revision=revision,
        generated_at=datetime.now(UTC).isoformat(),
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")


def x_main__mutmut_5() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--coverage", type=Path, required=None)
    parser.add_argument("--template", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    revision = subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip()
    result = build_profile(
        json.loads(args.template.read_text()),
        json.loads(args.coverage.read_text()),
        revision=revision,
        generated_at=datetime.now(UTC).isoformat(),
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")


def x_main__mutmut_6() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(type=Path, required=True)
    parser.add_argument("--template", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    revision = subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip()
    result = build_profile(
        json.loads(args.template.read_text()),
        json.loads(args.coverage.read_text()),
        revision=revision,
        generated_at=datetime.now(UTC).isoformat(),
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")


def x_main__mutmut_7() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--coverage", required=True)
    parser.add_argument("--template", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    revision = subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip()
    result = build_profile(
        json.loads(args.template.read_text()),
        json.loads(args.coverage.read_text()),
        revision=revision,
        generated_at=datetime.now(UTC).isoformat(),
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")


def x_main__mutmut_8() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--coverage", type=Path, )
    parser.add_argument("--template", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    revision = subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip()
    result = build_profile(
        json.loads(args.template.read_text()),
        json.loads(args.coverage.read_text()),
        revision=revision,
        generated_at=datetime.now(UTC).isoformat(),
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")


def x_main__mutmut_9() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("XX--coverageXX", type=Path, required=True)
    parser.add_argument("--template", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    revision = subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip()
    result = build_profile(
        json.loads(args.template.read_text()),
        json.loads(args.coverage.read_text()),
        revision=revision,
        generated_at=datetime.now(UTC).isoformat(),
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")


def x_main__mutmut_10() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--COVERAGE", type=Path, required=True)
    parser.add_argument("--template", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    revision = subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip()
    result = build_profile(
        json.loads(args.template.read_text()),
        json.loads(args.coverage.read_text()),
        revision=revision,
        generated_at=datetime.now(UTC).isoformat(),
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")


def x_main__mutmut_11() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--coverage", type=Path, required=False)
    parser.add_argument("--template", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    revision = subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip()
    result = build_profile(
        json.loads(args.template.read_text()),
        json.loads(args.coverage.read_text()),
        revision=revision,
        generated_at=datetime.now(UTC).isoformat(),
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")


def x_main__mutmut_12() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--coverage", type=Path, required=True)
    parser.add_argument(None, type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    revision = subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip()
    result = build_profile(
        json.loads(args.template.read_text()),
        json.loads(args.coverage.read_text()),
        revision=revision,
        generated_at=datetime.now(UTC).isoformat(),
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")


def x_main__mutmut_13() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--coverage", type=Path, required=True)
    parser.add_argument("--template", type=None, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    revision = subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip()
    result = build_profile(
        json.loads(args.template.read_text()),
        json.loads(args.coverage.read_text()),
        revision=revision,
        generated_at=datetime.now(UTC).isoformat(),
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")


def x_main__mutmut_14() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--coverage", type=Path, required=True)
    parser.add_argument("--template", type=Path, required=None)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    revision = subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip()
    result = build_profile(
        json.loads(args.template.read_text()),
        json.loads(args.coverage.read_text()),
        revision=revision,
        generated_at=datetime.now(UTC).isoformat(),
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")


def x_main__mutmut_15() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--coverage", type=Path, required=True)
    parser.add_argument(type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    revision = subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip()
    result = build_profile(
        json.loads(args.template.read_text()),
        json.loads(args.coverage.read_text()),
        revision=revision,
        generated_at=datetime.now(UTC).isoformat(),
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")


def x_main__mutmut_16() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--coverage", type=Path, required=True)
    parser.add_argument("--template", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    revision = subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip()
    result = build_profile(
        json.loads(args.template.read_text()),
        json.loads(args.coverage.read_text()),
        revision=revision,
        generated_at=datetime.now(UTC).isoformat(),
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")


def x_main__mutmut_17() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--coverage", type=Path, required=True)
    parser.add_argument("--template", type=Path, )
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    revision = subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip()
    result = build_profile(
        json.loads(args.template.read_text()),
        json.loads(args.coverage.read_text()),
        revision=revision,
        generated_at=datetime.now(UTC).isoformat(),
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")


def x_main__mutmut_18() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--coverage", type=Path, required=True)
    parser.add_argument("XX--templateXX", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    revision = subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip()
    result = build_profile(
        json.loads(args.template.read_text()),
        json.loads(args.coverage.read_text()),
        revision=revision,
        generated_at=datetime.now(UTC).isoformat(),
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")


def x_main__mutmut_19() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--coverage", type=Path, required=True)
    parser.add_argument("--TEMPLATE", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    revision = subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip()
    result = build_profile(
        json.loads(args.template.read_text()),
        json.loads(args.coverage.read_text()),
        revision=revision,
        generated_at=datetime.now(UTC).isoformat(),
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")


def x_main__mutmut_20() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--coverage", type=Path, required=True)
    parser.add_argument("--template", type=Path, required=False)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    revision = subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip()
    result = build_profile(
        json.loads(args.template.read_text()),
        json.loads(args.coverage.read_text()),
        revision=revision,
        generated_at=datetime.now(UTC).isoformat(),
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")


def x_main__mutmut_21() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--coverage", type=Path, required=True)
    parser.add_argument("--template", type=Path, required=True)
    parser.add_argument(None, type=Path, required=True)
    args = parser.parse_args()
    revision = subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip()
    result = build_profile(
        json.loads(args.template.read_text()),
        json.loads(args.coverage.read_text()),
        revision=revision,
        generated_at=datetime.now(UTC).isoformat(),
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")


def x_main__mutmut_22() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--coverage", type=Path, required=True)
    parser.add_argument("--template", type=Path, required=True)
    parser.add_argument("--output", type=None, required=True)
    args = parser.parse_args()
    revision = subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip()
    result = build_profile(
        json.loads(args.template.read_text()),
        json.loads(args.coverage.read_text()),
        revision=revision,
        generated_at=datetime.now(UTC).isoformat(),
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")


def x_main__mutmut_23() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--coverage", type=Path, required=True)
    parser.add_argument("--template", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=None)
    args = parser.parse_args()
    revision = subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip()
    result = build_profile(
        json.loads(args.template.read_text()),
        json.loads(args.coverage.read_text()),
        revision=revision,
        generated_at=datetime.now(UTC).isoformat(),
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")


def x_main__mutmut_24() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--coverage", type=Path, required=True)
    parser.add_argument("--template", type=Path, required=True)
    parser.add_argument(type=Path, required=True)
    args = parser.parse_args()
    revision = subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip()
    result = build_profile(
        json.loads(args.template.read_text()),
        json.loads(args.coverage.read_text()),
        revision=revision,
        generated_at=datetime.now(UTC).isoformat(),
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")


def x_main__mutmut_25() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--coverage", type=Path, required=True)
    parser.add_argument("--template", type=Path, required=True)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    revision = subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip()
    result = build_profile(
        json.loads(args.template.read_text()),
        json.loads(args.coverage.read_text()),
        revision=revision,
        generated_at=datetime.now(UTC).isoformat(),
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")


def x_main__mutmut_26() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--coverage", type=Path, required=True)
    parser.add_argument("--template", type=Path, required=True)
    parser.add_argument("--output", type=Path, )
    args = parser.parse_args()
    revision = subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip()
    result = build_profile(
        json.loads(args.template.read_text()),
        json.loads(args.coverage.read_text()),
        revision=revision,
        generated_at=datetime.now(UTC).isoformat(),
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")


def x_main__mutmut_27() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--coverage", type=Path, required=True)
    parser.add_argument("--template", type=Path, required=True)
    parser.add_argument("XX--outputXX", type=Path, required=True)
    args = parser.parse_args()
    revision = subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip()
    result = build_profile(
        json.loads(args.template.read_text()),
        json.loads(args.coverage.read_text()),
        revision=revision,
        generated_at=datetime.now(UTC).isoformat(),
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")


def x_main__mutmut_28() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--coverage", type=Path, required=True)
    parser.add_argument("--template", type=Path, required=True)
    parser.add_argument("--OUTPUT", type=Path, required=True)
    args = parser.parse_args()
    revision = subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip()
    result = build_profile(
        json.loads(args.template.read_text()),
        json.loads(args.coverage.read_text()),
        revision=revision,
        generated_at=datetime.now(UTC).isoformat(),
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")


def x_main__mutmut_29() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--coverage", type=Path, required=True)
    parser.add_argument("--template", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=False)
    args = parser.parse_args()
    revision = subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip()
    result = build_profile(
        json.loads(args.template.read_text()),
        json.loads(args.coverage.read_text()),
        revision=revision,
        generated_at=datetime.now(UTC).isoformat(),
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")


def x_main__mutmut_30() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--coverage", type=Path, required=True)
    parser.add_argument("--template", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = None
    revision = subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip()
    result = build_profile(
        json.loads(args.template.read_text()),
        json.loads(args.coverage.read_text()),
        revision=revision,
        generated_at=datetime.now(UTC).isoformat(),
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")


def x_main__mutmut_31() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--coverage", type=Path, required=True)
    parser.add_argument("--template", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    revision = None
    result = build_profile(
        json.loads(args.template.read_text()),
        json.loads(args.coverage.read_text()),
        revision=revision,
        generated_at=datetime.now(UTC).isoformat(),
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")


def x_main__mutmut_32() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--coverage", type=Path, required=True)
    parser.add_argument("--template", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    revision = subprocess.check_output(None, text=True).strip()
    result = build_profile(
        json.loads(args.template.read_text()),
        json.loads(args.coverage.read_text()),
        revision=revision,
        generated_at=datetime.now(UTC).isoformat(),
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")


def x_main__mutmut_33() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--coverage", type=Path, required=True)
    parser.add_argument("--template", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    revision = subprocess.check_output(["git", "rev-parse", "HEAD"], text=None).strip()
    result = build_profile(
        json.loads(args.template.read_text()),
        json.loads(args.coverage.read_text()),
        revision=revision,
        generated_at=datetime.now(UTC).isoformat(),
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")


def x_main__mutmut_34() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--coverage", type=Path, required=True)
    parser.add_argument("--template", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    revision = subprocess.check_output(text=True).strip()
    result = build_profile(
        json.loads(args.template.read_text()),
        json.loads(args.coverage.read_text()),
        revision=revision,
        generated_at=datetime.now(UTC).isoformat(),
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")


def x_main__mutmut_35() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--coverage", type=Path, required=True)
    parser.add_argument("--template", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    revision = subprocess.check_output(["git", "rev-parse", "HEAD"], ).strip()
    result = build_profile(
        json.loads(args.template.read_text()),
        json.loads(args.coverage.read_text()),
        revision=revision,
        generated_at=datetime.now(UTC).isoformat(),
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")


def x_main__mutmut_36() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--coverage", type=Path, required=True)
    parser.add_argument("--template", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    revision = subprocess.check_output(["XXgitXX", "rev-parse", "HEAD"], text=True).strip()
    result = build_profile(
        json.loads(args.template.read_text()),
        json.loads(args.coverage.read_text()),
        revision=revision,
        generated_at=datetime.now(UTC).isoformat(),
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")


def x_main__mutmut_37() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--coverage", type=Path, required=True)
    parser.add_argument("--template", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    revision = subprocess.check_output(["GIT", "rev-parse", "HEAD"], text=True).strip()
    result = build_profile(
        json.loads(args.template.read_text()),
        json.loads(args.coverage.read_text()),
        revision=revision,
        generated_at=datetime.now(UTC).isoformat(),
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")


def x_main__mutmut_38() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--coverage", type=Path, required=True)
    parser.add_argument("--template", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    revision = subprocess.check_output(["git", "XXrev-parseXX", "HEAD"], text=True).strip()
    result = build_profile(
        json.loads(args.template.read_text()),
        json.loads(args.coverage.read_text()),
        revision=revision,
        generated_at=datetime.now(UTC).isoformat(),
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")


def x_main__mutmut_39() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--coverage", type=Path, required=True)
    parser.add_argument("--template", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    revision = subprocess.check_output(["git", "REV-PARSE", "HEAD"], text=True).strip()
    result = build_profile(
        json.loads(args.template.read_text()),
        json.loads(args.coverage.read_text()),
        revision=revision,
        generated_at=datetime.now(UTC).isoformat(),
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")


def x_main__mutmut_40() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--coverage", type=Path, required=True)
    parser.add_argument("--template", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    revision = subprocess.check_output(["git", "rev-parse", "XXHEADXX"], text=True).strip()
    result = build_profile(
        json.loads(args.template.read_text()),
        json.loads(args.coverage.read_text()),
        revision=revision,
        generated_at=datetime.now(UTC).isoformat(),
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")


def x_main__mutmut_41() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--coverage", type=Path, required=True)
    parser.add_argument("--template", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    revision = subprocess.check_output(["git", "rev-parse", "head"], text=True).strip()
    result = build_profile(
        json.loads(args.template.read_text()),
        json.loads(args.coverage.read_text()),
        revision=revision,
        generated_at=datetime.now(UTC).isoformat(),
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")


def x_main__mutmut_42() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--coverage", type=Path, required=True)
    parser.add_argument("--template", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    revision = subprocess.check_output(["git", "rev-parse", "HEAD"], text=False).strip()
    result = build_profile(
        json.loads(args.template.read_text()),
        json.loads(args.coverage.read_text()),
        revision=revision,
        generated_at=datetime.now(UTC).isoformat(),
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")


def x_main__mutmut_43() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--coverage", type=Path, required=True)
    parser.add_argument("--template", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    revision = subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip()
    result = None
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")


def x_main__mutmut_44() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--coverage", type=Path, required=True)
    parser.add_argument("--template", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    revision = subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip()
    result = build_profile(
        None,
        json.loads(args.coverage.read_text()),
        revision=revision,
        generated_at=datetime.now(UTC).isoformat(),
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")


def x_main__mutmut_45() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--coverage", type=Path, required=True)
    parser.add_argument("--template", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    revision = subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip()
    result = build_profile(
        json.loads(args.template.read_text()),
        None,
        revision=revision,
        generated_at=datetime.now(UTC).isoformat(),
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")


def x_main__mutmut_46() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--coverage", type=Path, required=True)
    parser.add_argument("--template", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    revision = subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip()
    result = build_profile(
        json.loads(args.template.read_text()),
        json.loads(args.coverage.read_text()),
        revision=None,
        generated_at=datetime.now(UTC).isoformat(),
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")


def x_main__mutmut_47() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--coverage", type=Path, required=True)
    parser.add_argument("--template", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    revision = subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip()
    result = build_profile(
        json.loads(args.template.read_text()),
        json.loads(args.coverage.read_text()),
        revision=revision,
        generated_at=None,
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")


def x_main__mutmut_48() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--coverage", type=Path, required=True)
    parser.add_argument("--template", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    revision = subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip()
    result = build_profile(
        json.loads(args.coverage.read_text()),
        revision=revision,
        generated_at=datetime.now(UTC).isoformat(),
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")


def x_main__mutmut_49() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--coverage", type=Path, required=True)
    parser.add_argument("--template", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    revision = subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip()
    result = build_profile(
        json.loads(args.template.read_text()),
        revision=revision,
        generated_at=datetime.now(UTC).isoformat(),
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")


def x_main__mutmut_50() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--coverage", type=Path, required=True)
    parser.add_argument("--template", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    revision = subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip()
    result = build_profile(
        json.loads(args.template.read_text()),
        json.loads(args.coverage.read_text()),
        generated_at=datetime.now(UTC).isoformat(),
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")


def x_main__mutmut_51() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--coverage", type=Path, required=True)
    parser.add_argument("--template", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    revision = subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip()
    result = build_profile(
        json.loads(args.template.read_text()),
        json.loads(args.coverage.read_text()),
        revision=revision,
        )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")


def x_main__mutmut_52() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--coverage", type=Path, required=True)
    parser.add_argument("--template", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    revision = subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip()
    result = build_profile(
        json.loads(None),
        json.loads(args.coverage.read_text()),
        revision=revision,
        generated_at=datetime.now(UTC).isoformat(),
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")


def x_main__mutmut_53() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--coverage", type=Path, required=True)
    parser.add_argument("--template", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    revision = subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip()
    result = build_profile(
        json.loads(args.template.read_text()),
        json.loads(None),
        revision=revision,
        generated_at=datetime.now(UTC).isoformat(),
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")


def x_main__mutmut_54() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--coverage", type=Path, required=True)
    parser.add_argument("--template", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    revision = subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip()
    result = build_profile(
        json.loads(args.template.read_text()),
        json.loads(args.coverage.read_text()),
        revision=revision,
        generated_at=datetime.now(None).isoformat(),
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")


def x_main__mutmut_55() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--coverage", type=Path, required=True)
    parser.add_argument("--template", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    revision = subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip()
    result = build_profile(
        json.loads(args.template.read_text()),
        json.loads(args.coverage.read_text()),
        revision=revision,
        generated_at=datetime.now(UTC).isoformat(),
    )
    args.output.parent.mkdir(parents=None, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")


def x_main__mutmut_56() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--coverage", type=Path, required=True)
    parser.add_argument("--template", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    revision = subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip()
    result = build_profile(
        json.loads(args.template.read_text()),
        json.loads(args.coverage.read_text()),
        revision=revision,
        generated_at=datetime.now(UTC).isoformat(),
    )
    args.output.parent.mkdir(parents=True, exist_ok=None)
    args.output.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")


def x_main__mutmut_57() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--coverage", type=Path, required=True)
    parser.add_argument("--template", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    revision = subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip()
    result = build_profile(
        json.loads(args.template.read_text()),
        json.loads(args.coverage.read_text()),
        revision=revision,
        generated_at=datetime.now(UTC).isoformat(),
    )
    args.output.parent.mkdir(exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")


def x_main__mutmut_58() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--coverage", type=Path, required=True)
    parser.add_argument("--template", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    revision = subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip()
    result = build_profile(
        json.loads(args.template.read_text()),
        json.loads(args.coverage.read_text()),
        revision=revision,
        generated_at=datetime.now(UTC).isoformat(),
    )
    args.output.parent.mkdir(parents=True, )
    args.output.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")


def x_main__mutmut_59() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--coverage", type=Path, required=True)
    parser.add_argument("--template", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    revision = subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip()
    result = build_profile(
        json.loads(args.template.read_text()),
        json.loads(args.coverage.read_text()),
        revision=revision,
        generated_at=datetime.now(UTC).isoformat(),
    )
    args.output.parent.mkdir(parents=False, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")


def x_main__mutmut_60() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--coverage", type=Path, required=True)
    parser.add_argument("--template", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    revision = subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip()
    result = build_profile(
        json.loads(args.template.read_text()),
        json.loads(args.coverage.read_text()),
        revision=revision,
        generated_at=datetime.now(UTC).isoformat(),
    )
    args.output.parent.mkdir(parents=True, exist_ok=False)
    args.output.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")


def x_main__mutmut_61() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--coverage", type=Path, required=True)
    parser.add_argument("--template", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    revision = subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip()
    result = build_profile(
        json.loads(args.template.read_text()),
        json.loads(args.coverage.read_text()),
        revision=revision,
        generated_at=datetime.now(UTC).isoformat(),
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(None)


def x_main__mutmut_62() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--coverage", type=Path, required=True)
    parser.add_argument("--template", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    revision = subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip()
    result = build_profile(
        json.loads(args.template.read_text()),
        json.loads(args.coverage.read_text()),
        revision=revision,
        generated_at=datetime.now(UTC).isoformat(),
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2, sort_keys=True) - "\n")


def x_main__mutmut_63() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--coverage", type=Path, required=True)
    parser.add_argument("--template", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    revision = subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip()
    result = build_profile(
        json.loads(args.template.read_text()),
        json.loads(args.coverage.read_text()),
        revision=revision,
        generated_at=datetime.now(UTC).isoformat(),
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(None, indent=2, sort_keys=True) + "\n")


def x_main__mutmut_64() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--coverage", type=Path, required=True)
    parser.add_argument("--template", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    revision = subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip()
    result = build_profile(
        json.loads(args.template.read_text()),
        json.loads(args.coverage.read_text()),
        revision=revision,
        generated_at=datetime.now(UTC).isoformat(),
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=None, sort_keys=True) + "\n")


def x_main__mutmut_65() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--coverage", type=Path, required=True)
    parser.add_argument("--template", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    revision = subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip()
    result = build_profile(
        json.loads(args.template.read_text()),
        json.loads(args.coverage.read_text()),
        revision=revision,
        generated_at=datetime.now(UTC).isoformat(),
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2, sort_keys=None) + "\n")


def x_main__mutmut_66() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--coverage", type=Path, required=True)
    parser.add_argument("--template", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    revision = subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip()
    result = build_profile(
        json.loads(args.template.read_text()),
        json.loads(args.coverage.read_text()),
        revision=revision,
        generated_at=datetime.now(UTC).isoformat(),
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(indent=2, sort_keys=True) + "\n")


def x_main__mutmut_67() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--coverage", type=Path, required=True)
    parser.add_argument("--template", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    revision = subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip()
    result = build_profile(
        json.loads(args.template.read_text()),
        json.loads(args.coverage.read_text()),
        revision=revision,
        generated_at=datetime.now(UTC).isoformat(),
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, sort_keys=True) + "\n")


def x_main__mutmut_68() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--coverage", type=Path, required=True)
    parser.add_argument("--template", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    revision = subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip()
    result = build_profile(
        json.loads(args.template.read_text()),
        json.loads(args.coverage.read_text()),
        revision=revision,
        generated_at=datetime.now(UTC).isoformat(),
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2, ) + "\n")


def x_main__mutmut_69() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--coverage", type=Path, required=True)
    parser.add_argument("--template", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    revision = subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip()
    result = build_profile(
        json.loads(args.template.read_text()),
        json.loads(args.coverage.read_text()),
        revision=revision,
        generated_at=datetime.now(UTC).isoformat(),
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=3, sort_keys=True) + "\n")


def x_main__mutmut_70() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--coverage", type=Path, required=True)
    parser.add_argument("--template", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    revision = subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip()
    result = build_profile(
        json.loads(args.template.read_text()),
        json.loads(args.coverage.read_text()),
        revision=revision,
        generated_at=datetime.now(UTC).isoformat(),
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2, sort_keys=False) + "\n")


def x_main__mutmut_71() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--coverage", type=Path, required=True)
    parser.add_argument("--template", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    revision = subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip()
    result = build_profile(
        json.loads(args.template.read_text()),
        json.loads(args.coverage.read_text()),
        revision=revision,
        generated_at=datetime.now(UTC).isoformat(),
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2, sort_keys=True) + "XX\nXX")

mutants_x_main__mutmut['_mutmut_orig'] = x_main__mutmut_orig # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_1'] = x_main__mutmut_1 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_2'] = x_main__mutmut_2 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_3'] = x_main__mutmut_3 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_4'] = x_main__mutmut_4 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_5'] = x_main__mutmut_5 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_6'] = x_main__mutmut_6 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_7'] = x_main__mutmut_7 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_8'] = x_main__mutmut_8 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_9'] = x_main__mutmut_9 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_10'] = x_main__mutmut_10 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_11'] = x_main__mutmut_11 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_12'] = x_main__mutmut_12 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_13'] = x_main__mutmut_13 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_14'] = x_main__mutmut_14 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_15'] = x_main__mutmut_15 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_16'] = x_main__mutmut_16 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_17'] = x_main__mutmut_17 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_18'] = x_main__mutmut_18 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_19'] = x_main__mutmut_19 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_20'] = x_main__mutmut_20 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_21'] = x_main__mutmut_21 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_22'] = x_main__mutmut_22 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_23'] = x_main__mutmut_23 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_24'] = x_main__mutmut_24 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_25'] = x_main__mutmut_25 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_26'] = x_main__mutmut_26 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_27'] = x_main__mutmut_27 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_28'] = x_main__mutmut_28 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_29'] = x_main__mutmut_29 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_30'] = x_main__mutmut_30 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_31'] = x_main__mutmut_31 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_32'] = x_main__mutmut_32 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_33'] = x_main__mutmut_33 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_34'] = x_main__mutmut_34 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_35'] = x_main__mutmut_35 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_36'] = x_main__mutmut_36 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_37'] = x_main__mutmut_37 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_38'] = x_main__mutmut_38 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_39'] = x_main__mutmut_39 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_40'] = x_main__mutmut_40 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_41'] = x_main__mutmut_41 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_42'] = x_main__mutmut_42 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_43'] = x_main__mutmut_43 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_44'] = x_main__mutmut_44 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_45'] = x_main__mutmut_45 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_46'] = x_main__mutmut_46 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_47'] = x_main__mutmut_47 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_48'] = x_main__mutmut_48 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_49'] = x_main__mutmut_49 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_50'] = x_main__mutmut_50 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_51'] = x_main__mutmut_51 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_52'] = x_main__mutmut_52 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_53'] = x_main__mutmut_53 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_54'] = x_main__mutmut_54 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_55'] = x_main__mutmut_55 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_56'] = x_main__mutmut_56 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_57'] = x_main__mutmut_57 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_58'] = x_main__mutmut_58 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_59'] = x_main__mutmut_59 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_60'] = x_main__mutmut_60 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_61'] = x_main__mutmut_61 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_62'] = x_main__mutmut_62 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_63'] = x_main__mutmut_63 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_64'] = x_main__mutmut_64 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_65'] = x_main__mutmut_65 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_66'] = x_main__mutmut_66 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_67'] = x_main__mutmut_67 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_68'] = x_main__mutmut_68 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_69'] = x_main__mutmut_69 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_70'] = x_main__mutmut_70 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_71'] = x_main__mutmut_71 # type: ignore # mutmut generated


if __name__ == "__main__":
    main()
