import gzip
import hashlib
import json
import subprocess
from pathlib import Path

import pytest

pytestmark = pytest.mark.end_to_end


def test_archived_tables_and_figures_match_manifest():
    root = Path(__file__).resolve().parents[1]
    manifest = json.loads((root / "verification/evidence/manifest.json").read_text())
    assert manifest["datasets"]
    assert manifest["artifacts"]
    for name, expected in manifest["artifacts"].items():
        artifact = root / name
        assert artifact.is_file(), name
        assert hashlib.sha256(artifact.read_bytes()).hexdigest() == expected, name


def _lineage_problems(name):
    from verification import lineage

    record = json.loads((Path(lineage.ROOT) / "verification/evidence" / f"{name}.json").read_text())
    anchor = lineage.files_at(lineage.anchor_revision())
    return lineage.check_record(record, anchor, lineage.worktree_files())


def test_archived_runs_match_current_scientific_source():
    # Historical integrity (anchor reproduces the stored fingerprint) and
    # current-source reproducibility (result-affecting code unchanged since).
    for name in (
        "run_synthetic",
        "run_severity",
        "run_curves",
        "run_benchmark_credit_card",
        "run_benchmark_water_quality",
        "run_benchmark_cardio",
    ):
        assert _lineage_problems(name) == [], name


def test_archived_real_split_ids_cover_each_post_transform_population():
    root = Path(__file__).resolve().parents[1]
    manifest = json.loads((root / "verification/evidence/manifest.json").read_text())
    for name in ("credit_card", "water_quality", "cardio"):
        archive = root / "verification/evidence" / f"split_ids_{name}.json.gz"
        with gzip.open(archive, "rt") as stream:
            split_ids = json.load(stream)
        record = json.loads(
            (root / "verification/evidence" / f"run_benchmark_{name}.json").read_text()
        )
        assert split_ids["row_count"] == manifest["datasets"][name]["rows_after_transform"]
        assert set(split_ids["seeds"]) == {str(seed) for seed in record["seeds"]}
        for parts in split_ids["seeds"].values():
            assert sorted(parts["train"] + parts["validation"] + parts["test"]) == list(
                range(split_ids["row_count"])
            )
            if "fit" in parts:
                assert set(parts["fit"]) <= set(parts["train"])


def test_fixed_calibration_reuses_baseline_partitions_and_current_source():
    root = Path(__file__).resolve().parents[1]
    for name in ("credit_card", "water_quality", "cardio"):
        base = root / "verification/evidence"
        fixed = json.loads((base / f"run_fixed_benchmark_{name}.json").read_text())
        baseline = json.loads((base / f"run_benchmark_{name}.json").read_text())
        assert fixed["settings"]["calibration"] == "fixed"
        assert fixed["settings"]["fixed_contamination"] == 0.02
        assert baseline["settings"]["calibration"] == "train_prevalence"
        assert fixed["seeds"] == baseline["seeds"]
        assert fixed["source_fingerprint"] == baseline["source_fingerprint"]
        assert _lineage_problems(f"run_fixed_benchmark_{name}") == []
        with gzip.open(base / f"fixed_split_ids_{name}.json.gz", "rb") as stream:
            fixed_ids = stream.read()
        with gzip.open(base / f"split_ids_{name}.json.gz", "rb") as stream:
            assert fixed_ids == stream.read()


def test_lineage_anchor_is_a_commit_that_reproduces_the_archived_recipe_1_fingerprint():
    from verification import lineage

    root = Path(__file__).resolve().parents[1]
    # The recipe-1 records were replaced by a clean replay; the originals stay in
    # the history of the anchor commit and must still be reproduced by its tree.
    revision = lineage.anchor_revision()
    anchor = lineage.files_at(revision)
    old = subprocess.check_output(
        ["git", "show", f"{revision}:verification/evidence/run_benchmark_cardio.json"], cwd=root
    )
    stored = json.loads(old)
    assert stored.get("fingerprint_recipe", 1) == 1
    assert lineage.fingerprint_v1_of(anchor) == stored["source_fingerprint"]
    current = json.loads((root / "verification/evidence/run_benchmark_cardio.json").read_text())
    assert current["fingerprint_recipe"] == 2 and current["worktree_dirty"] is False
