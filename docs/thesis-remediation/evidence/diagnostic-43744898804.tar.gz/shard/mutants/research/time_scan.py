"""Find the pool datasets that carry a genuine time variable (pool_extension.md, study 5).

A column qualifies when it is readable as a date or a time and the rows are not all equal. The
scan only reports candidates: whether the row order is chronological is decided from the sorted
column, never assumed, and a dataset is kept for the chronological study only if it is labelled
and large enough.
"""

from __future__ import annotations

import json
import re
import sys
from pathlib import Path
from typing import Any

import pandas as pd

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import uci_loader as ul  # noqa: E402

NAME = re.compile(r"(date|time|timestamp|datetime|year|month|day|hour|week)", re.I)
MIN_PARSED = 0.95


from mutmut.mutation.trampoline import wrap_in_trampoline as _mutmut_mutated, MutantDict
mutants_x_candidate_columns__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_candidate_columns__mutmut)
def candidate_columns(frame: pd.DataFrame) -> list[dict[str, Any]]:
    """Columns that can be ordered in time, with how they were read."""
    found = []
    for name in frame.columns:
        column = frame[name]
        if column.nunique(dropna=True) < 10:
            continue
        textual = pd.api.types.is_object_dtype(column) or pd.api.types.is_string_dtype(column)
        if not NAME.search(str(name)) and not textual:
            continue
        if pd.api.types.is_numeric_dtype(column):
            if NAME.search(str(name)):
                found.append(
                    {"column": str(name), "kind": "numeric", "distinct": int(column.nunique())}
                )
            continue
        parsed = pd.to_datetime(column, errors="coerce", format="mixed")
        if parsed.notna().mean() >= MIN_PARSED and parsed.nunique() >= 10:
            found.append(
                {"column": str(name), "kind": "datetime", "distinct": int(parsed.nunique())}
            )
    return found


def x_candidate_columns__mutmut_orig(frame: pd.DataFrame) -> list[dict[str, Any]]:
    """Columns that can be ordered in time, with how they were read."""
    found = []
    for name in frame.columns:
        column = frame[name]
        if column.nunique(dropna=True) < 10:
            continue
        textual = pd.api.types.is_object_dtype(column) or pd.api.types.is_string_dtype(column)
        if not NAME.search(str(name)) and not textual:
            continue
        if pd.api.types.is_numeric_dtype(column):
            if NAME.search(str(name)):
                found.append(
                    {"column": str(name), "kind": "numeric", "distinct": int(column.nunique())}
                )
            continue
        parsed = pd.to_datetime(column, errors="coerce", format="mixed")
        if parsed.notna().mean() >= MIN_PARSED and parsed.nunique() >= 10:
            found.append(
                {"column": str(name), "kind": "datetime", "distinct": int(parsed.nunique())}
            )
    return found


def x_candidate_columns__mutmut_1(frame: pd.DataFrame) -> list[dict[str, Any]]:
    """Columns that can be ordered in time, with how they were read."""
    found = None
    for name in frame.columns:
        column = frame[name]
        if column.nunique(dropna=True) < 10:
            continue
        textual = pd.api.types.is_object_dtype(column) or pd.api.types.is_string_dtype(column)
        if not NAME.search(str(name)) and not textual:
            continue
        if pd.api.types.is_numeric_dtype(column):
            if NAME.search(str(name)):
                found.append(
                    {"column": str(name), "kind": "numeric", "distinct": int(column.nunique())}
                )
            continue
        parsed = pd.to_datetime(column, errors="coerce", format="mixed")
        if parsed.notna().mean() >= MIN_PARSED and parsed.nunique() >= 10:
            found.append(
                {"column": str(name), "kind": "datetime", "distinct": int(parsed.nunique())}
            )
    return found


def x_candidate_columns__mutmut_2(frame: pd.DataFrame) -> list[dict[str, Any]]:
    """Columns that can be ordered in time, with how they were read."""
    found = []
    for name in frame.columns:
        column = None
        if column.nunique(dropna=True) < 10:
            continue
        textual = pd.api.types.is_object_dtype(column) or pd.api.types.is_string_dtype(column)
        if not NAME.search(str(name)) and not textual:
            continue
        if pd.api.types.is_numeric_dtype(column):
            if NAME.search(str(name)):
                found.append(
                    {"column": str(name), "kind": "numeric", "distinct": int(column.nunique())}
                )
            continue
        parsed = pd.to_datetime(column, errors="coerce", format="mixed")
        if parsed.notna().mean() >= MIN_PARSED and parsed.nunique() >= 10:
            found.append(
                {"column": str(name), "kind": "datetime", "distinct": int(parsed.nunique())}
            )
    return found


def x_candidate_columns__mutmut_3(frame: pd.DataFrame) -> list[dict[str, Any]]:
    """Columns that can be ordered in time, with how they were read."""
    found = []
    for name in frame.columns:
        column = frame[name]
        if column.nunique(dropna=None) < 10:
            continue
        textual = pd.api.types.is_object_dtype(column) or pd.api.types.is_string_dtype(column)
        if not NAME.search(str(name)) and not textual:
            continue
        if pd.api.types.is_numeric_dtype(column):
            if NAME.search(str(name)):
                found.append(
                    {"column": str(name), "kind": "numeric", "distinct": int(column.nunique())}
                )
            continue
        parsed = pd.to_datetime(column, errors="coerce", format="mixed")
        if parsed.notna().mean() >= MIN_PARSED and parsed.nunique() >= 10:
            found.append(
                {"column": str(name), "kind": "datetime", "distinct": int(parsed.nunique())}
            )
    return found


def x_candidate_columns__mutmut_4(frame: pd.DataFrame) -> list[dict[str, Any]]:
    """Columns that can be ordered in time, with how they were read."""
    found = []
    for name in frame.columns:
        column = frame[name]
        if column.nunique(dropna=False) < 10:
            continue
        textual = pd.api.types.is_object_dtype(column) or pd.api.types.is_string_dtype(column)
        if not NAME.search(str(name)) and not textual:
            continue
        if pd.api.types.is_numeric_dtype(column):
            if NAME.search(str(name)):
                found.append(
                    {"column": str(name), "kind": "numeric", "distinct": int(column.nunique())}
                )
            continue
        parsed = pd.to_datetime(column, errors="coerce", format="mixed")
        if parsed.notna().mean() >= MIN_PARSED and parsed.nunique() >= 10:
            found.append(
                {"column": str(name), "kind": "datetime", "distinct": int(parsed.nunique())}
            )
    return found


def x_candidate_columns__mutmut_5(frame: pd.DataFrame) -> list[dict[str, Any]]:
    """Columns that can be ordered in time, with how they were read."""
    found = []
    for name in frame.columns:
        column = frame[name]
        if column.nunique(dropna=True) <= 10:
            continue
        textual = pd.api.types.is_object_dtype(column) or pd.api.types.is_string_dtype(column)
        if not NAME.search(str(name)) and not textual:
            continue
        if pd.api.types.is_numeric_dtype(column):
            if NAME.search(str(name)):
                found.append(
                    {"column": str(name), "kind": "numeric", "distinct": int(column.nunique())}
                )
            continue
        parsed = pd.to_datetime(column, errors="coerce", format="mixed")
        if parsed.notna().mean() >= MIN_PARSED and parsed.nunique() >= 10:
            found.append(
                {"column": str(name), "kind": "datetime", "distinct": int(parsed.nunique())}
            )
    return found


def x_candidate_columns__mutmut_6(frame: pd.DataFrame) -> list[dict[str, Any]]:
    """Columns that can be ordered in time, with how they were read."""
    found = []
    for name in frame.columns:
        column = frame[name]
        if column.nunique(dropna=True) < 11:
            continue
        textual = pd.api.types.is_object_dtype(column) or pd.api.types.is_string_dtype(column)
        if not NAME.search(str(name)) and not textual:
            continue
        if pd.api.types.is_numeric_dtype(column):
            if NAME.search(str(name)):
                found.append(
                    {"column": str(name), "kind": "numeric", "distinct": int(column.nunique())}
                )
            continue
        parsed = pd.to_datetime(column, errors="coerce", format="mixed")
        if parsed.notna().mean() >= MIN_PARSED and parsed.nunique() >= 10:
            found.append(
                {"column": str(name), "kind": "datetime", "distinct": int(parsed.nunique())}
            )
    return found


def x_candidate_columns__mutmut_7(frame: pd.DataFrame) -> list[dict[str, Any]]:
    """Columns that can be ordered in time, with how they were read."""
    found = []
    for name in frame.columns:
        column = frame[name]
        if column.nunique(dropna=True) < 10:
            break
        textual = pd.api.types.is_object_dtype(column) or pd.api.types.is_string_dtype(column)
        if not NAME.search(str(name)) and not textual:
            continue
        if pd.api.types.is_numeric_dtype(column):
            if NAME.search(str(name)):
                found.append(
                    {"column": str(name), "kind": "numeric", "distinct": int(column.nunique())}
                )
            continue
        parsed = pd.to_datetime(column, errors="coerce", format="mixed")
        if parsed.notna().mean() >= MIN_PARSED and parsed.nunique() >= 10:
            found.append(
                {"column": str(name), "kind": "datetime", "distinct": int(parsed.nunique())}
            )
    return found


def x_candidate_columns__mutmut_8(frame: pd.DataFrame) -> list[dict[str, Any]]:
    """Columns that can be ordered in time, with how they were read."""
    found = []
    for name in frame.columns:
        column = frame[name]
        if column.nunique(dropna=True) < 10:
            continue
        textual = None
        if not NAME.search(str(name)) and not textual:
            continue
        if pd.api.types.is_numeric_dtype(column):
            if NAME.search(str(name)):
                found.append(
                    {"column": str(name), "kind": "numeric", "distinct": int(column.nunique())}
                )
            continue
        parsed = pd.to_datetime(column, errors="coerce", format="mixed")
        if parsed.notna().mean() >= MIN_PARSED and parsed.nunique() >= 10:
            found.append(
                {"column": str(name), "kind": "datetime", "distinct": int(parsed.nunique())}
            )
    return found


def x_candidate_columns__mutmut_9(frame: pd.DataFrame) -> list[dict[str, Any]]:
    """Columns that can be ordered in time, with how they were read."""
    found = []
    for name in frame.columns:
        column = frame[name]
        if column.nunique(dropna=True) < 10:
            continue
        textual = pd.api.types.is_object_dtype(column) and pd.api.types.is_string_dtype(column)
        if not NAME.search(str(name)) and not textual:
            continue
        if pd.api.types.is_numeric_dtype(column):
            if NAME.search(str(name)):
                found.append(
                    {"column": str(name), "kind": "numeric", "distinct": int(column.nunique())}
                )
            continue
        parsed = pd.to_datetime(column, errors="coerce", format="mixed")
        if parsed.notna().mean() >= MIN_PARSED and parsed.nunique() >= 10:
            found.append(
                {"column": str(name), "kind": "datetime", "distinct": int(parsed.nunique())}
            )
    return found


def x_candidate_columns__mutmut_10(frame: pd.DataFrame) -> list[dict[str, Any]]:
    """Columns that can be ordered in time, with how they were read."""
    found = []
    for name in frame.columns:
        column = frame[name]
        if column.nunique(dropna=True) < 10:
            continue
        textual = pd.api.types.is_object_dtype(None) or pd.api.types.is_string_dtype(column)
        if not NAME.search(str(name)) and not textual:
            continue
        if pd.api.types.is_numeric_dtype(column):
            if NAME.search(str(name)):
                found.append(
                    {"column": str(name), "kind": "numeric", "distinct": int(column.nunique())}
                )
            continue
        parsed = pd.to_datetime(column, errors="coerce", format="mixed")
        if parsed.notna().mean() >= MIN_PARSED and parsed.nunique() >= 10:
            found.append(
                {"column": str(name), "kind": "datetime", "distinct": int(parsed.nunique())}
            )
    return found


def x_candidate_columns__mutmut_11(frame: pd.DataFrame) -> list[dict[str, Any]]:
    """Columns that can be ordered in time, with how they were read."""
    found = []
    for name in frame.columns:
        column = frame[name]
        if column.nunique(dropna=True) < 10:
            continue
        textual = pd.api.types.is_object_dtype(column) or pd.api.types.is_string_dtype(None)
        if not NAME.search(str(name)) and not textual:
            continue
        if pd.api.types.is_numeric_dtype(column):
            if NAME.search(str(name)):
                found.append(
                    {"column": str(name), "kind": "numeric", "distinct": int(column.nunique())}
                )
            continue
        parsed = pd.to_datetime(column, errors="coerce", format="mixed")
        if parsed.notna().mean() >= MIN_PARSED and parsed.nunique() >= 10:
            found.append(
                {"column": str(name), "kind": "datetime", "distinct": int(parsed.nunique())}
            )
    return found


def x_candidate_columns__mutmut_12(frame: pd.DataFrame) -> list[dict[str, Any]]:
    """Columns that can be ordered in time, with how they were read."""
    found = []
    for name in frame.columns:
        column = frame[name]
        if column.nunique(dropna=True) < 10:
            continue
        textual = pd.api.types.is_object_dtype(column) or pd.api.types.is_string_dtype(column)
        if not NAME.search(str(name)) or not textual:
            continue
        if pd.api.types.is_numeric_dtype(column):
            if NAME.search(str(name)):
                found.append(
                    {"column": str(name), "kind": "numeric", "distinct": int(column.nunique())}
                )
            continue
        parsed = pd.to_datetime(column, errors="coerce", format="mixed")
        if parsed.notna().mean() >= MIN_PARSED and parsed.nunique() >= 10:
            found.append(
                {"column": str(name), "kind": "datetime", "distinct": int(parsed.nunique())}
            )
    return found


def x_candidate_columns__mutmut_13(frame: pd.DataFrame) -> list[dict[str, Any]]:
    """Columns that can be ordered in time, with how they were read."""
    found = []
    for name in frame.columns:
        column = frame[name]
        if column.nunique(dropna=True) < 10:
            continue
        textual = pd.api.types.is_object_dtype(column) or pd.api.types.is_string_dtype(column)
        if NAME.search(str(name)) and not textual:
            continue
        if pd.api.types.is_numeric_dtype(column):
            if NAME.search(str(name)):
                found.append(
                    {"column": str(name), "kind": "numeric", "distinct": int(column.nunique())}
                )
            continue
        parsed = pd.to_datetime(column, errors="coerce", format="mixed")
        if parsed.notna().mean() >= MIN_PARSED and parsed.nunique() >= 10:
            found.append(
                {"column": str(name), "kind": "datetime", "distinct": int(parsed.nunique())}
            )
    return found


def x_candidate_columns__mutmut_14(frame: pd.DataFrame) -> list[dict[str, Any]]:
    """Columns that can be ordered in time, with how they were read."""
    found = []
    for name in frame.columns:
        column = frame[name]
        if column.nunique(dropna=True) < 10:
            continue
        textual = pd.api.types.is_object_dtype(column) or pd.api.types.is_string_dtype(column)
        if not NAME.search(None) and not textual:
            continue
        if pd.api.types.is_numeric_dtype(column):
            if NAME.search(str(name)):
                found.append(
                    {"column": str(name), "kind": "numeric", "distinct": int(column.nunique())}
                )
            continue
        parsed = pd.to_datetime(column, errors="coerce", format="mixed")
        if parsed.notna().mean() >= MIN_PARSED and parsed.nunique() >= 10:
            found.append(
                {"column": str(name), "kind": "datetime", "distinct": int(parsed.nunique())}
            )
    return found


def x_candidate_columns__mutmut_15(frame: pd.DataFrame) -> list[dict[str, Any]]:
    """Columns that can be ordered in time, with how they were read."""
    found = []
    for name in frame.columns:
        column = frame[name]
        if column.nunique(dropna=True) < 10:
            continue
        textual = pd.api.types.is_object_dtype(column) or pd.api.types.is_string_dtype(column)
        if not NAME.search(str(None)) and not textual:
            continue
        if pd.api.types.is_numeric_dtype(column):
            if NAME.search(str(name)):
                found.append(
                    {"column": str(name), "kind": "numeric", "distinct": int(column.nunique())}
                )
            continue
        parsed = pd.to_datetime(column, errors="coerce", format="mixed")
        if parsed.notna().mean() >= MIN_PARSED and parsed.nunique() >= 10:
            found.append(
                {"column": str(name), "kind": "datetime", "distinct": int(parsed.nunique())}
            )
    return found


def x_candidate_columns__mutmut_16(frame: pd.DataFrame) -> list[dict[str, Any]]:
    """Columns that can be ordered in time, with how they were read."""
    found = []
    for name in frame.columns:
        column = frame[name]
        if column.nunique(dropna=True) < 10:
            continue
        textual = pd.api.types.is_object_dtype(column) or pd.api.types.is_string_dtype(column)
        if not NAME.search(str(name)) and textual:
            continue
        if pd.api.types.is_numeric_dtype(column):
            if NAME.search(str(name)):
                found.append(
                    {"column": str(name), "kind": "numeric", "distinct": int(column.nunique())}
                )
            continue
        parsed = pd.to_datetime(column, errors="coerce", format="mixed")
        if parsed.notna().mean() >= MIN_PARSED and parsed.nunique() >= 10:
            found.append(
                {"column": str(name), "kind": "datetime", "distinct": int(parsed.nunique())}
            )
    return found


def x_candidate_columns__mutmut_17(frame: pd.DataFrame) -> list[dict[str, Any]]:
    """Columns that can be ordered in time, with how they were read."""
    found = []
    for name in frame.columns:
        column = frame[name]
        if column.nunique(dropna=True) < 10:
            continue
        textual = pd.api.types.is_object_dtype(column) or pd.api.types.is_string_dtype(column)
        if not NAME.search(str(name)) and not textual:
            break
        if pd.api.types.is_numeric_dtype(column):
            if NAME.search(str(name)):
                found.append(
                    {"column": str(name), "kind": "numeric", "distinct": int(column.nunique())}
                )
            continue
        parsed = pd.to_datetime(column, errors="coerce", format="mixed")
        if parsed.notna().mean() >= MIN_PARSED and parsed.nunique() >= 10:
            found.append(
                {"column": str(name), "kind": "datetime", "distinct": int(parsed.nunique())}
            )
    return found


def x_candidate_columns__mutmut_18(frame: pd.DataFrame) -> list[dict[str, Any]]:
    """Columns that can be ordered in time, with how they were read."""
    found = []
    for name in frame.columns:
        column = frame[name]
        if column.nunique(dropna=True) < 10:
            continue
        textual = pd.api.types.is_object_dtype(column) or pd.api.types.is_string_dtype(column)
        if not NAME.search(str(name)) and not textual:
            continue
        if pd.api.types.is_numeric_dtype(None):
            if NAME.search(str(name)):
                found.append(
                    {"column": str(name), "kind": "numeric", "distinct": int(column.nunique())}
                )
            continue
        parsed = pd.to_datetime(column, errors="coerce", format="mixed")
        if parsed.notna().mean() >= MIN_PARSED and parsed.nunique() >= 10:
            found.append(
                {"column": str(name), "kind": "datetime", "distinct": int(parsed.nunique())}
            )
    return found


def x_candidate_columns__mutmut_19(frame: pd.DataFrame) -> list[dict[str, Any]]:
    """Columns that can be ordered in time, with how they were read."""
    found = []
    for name in frame.columns:
        column = frame[name]
        if column.nunique(dropna=True) < 10:
            continue
        textual = pd.api.types.is_object_dtype(column) or pd.api.types.is_string_dtype(column)
        if not NAME.search(str(name)) and not textual:
            continue
        if pd.api.types.is_numeric_dtype(column):
            if NAME.search(None):
                found.append(
                    {"column": str(name), "kind": "numeric", "distinct": int(column.nunique())}
                )
            continue
        parsed = pd.to_datetime(column, errors="coerce", format="mixed")
        if parsed.notna().mean() >= MIN_PARSED and parsed.nunique() >= 10:
            found.append(
                {"column": str(name), "kind": "datetime", "distinct": int(parsed.nunique())}
            )
    return found


def x_candidate_columns__mutmut_20(frame: pd.DataFrame) -> list[dict[str, Any]]:
    """Columns that can be ordered in time, with how they were read."""
    found = []
    for name in frame.columns:
        column = frame[name]
        if column.nunique(dropna=True) < 10:
            continue
        textual = pd.api.types.is_object_dtype(column) or pd.api.types.is_string_dtype(column)
        if not NAME.search(str(name)) and not textual:
            continue
        if pd.api.types.is_numeric_dtype(column):
            if NAME.search(str(None)):
                found.append(
                    {"column": str(name), "kind": "numeric", "distinct": int(column.nunique())}
                )
            continue
        parsed = pd.to_datetime(column, errors="coerce", format="mixed")
        if parsed.notna().mean() >= MIN_PARSED and parsed.nunique() >= 10:
            found.append(
                {"column": str(name), "kind": "datetime", "distinct": int(parsed.nunique())}
            )
    return found


def x_candidate_columns__mutmut_21(frame: pd.DataFrame) -> list[dict[str, Any]]:
    """Columns that can be ordered in time, with how they were read."""
    found = []
    for name in frame.columns:
        column = frame[name]
        if column.nunique(dropna=True) < 10:
            continue
        textual = pd.api.types.is_object_dtype(column) or pd.api.types.is_string_dtype(column)
        if not NAME.search(str(name)) and not textual:
            continue
        if pd.api.types.is_numeric_dtype(column):
            if NAME.search(str(name)):
                found.append(
                    None
                )
            continue
        parsed = pd.to_datetime(column, errors="coerce", format="mixed")
        if parsed.notna().mean() >= MIN_PARSED and parsed.nunique() >= 10:
            found.append(
                {"column": str(name), "kind": "datetime", "distinct": int(parsed.nunique())}
            )
    return found


def x_candidate_columns__mutmut_22(frame: pd.DataFrame) -> list[dict[str, Any]]:
    """Columns that can be ordered in time, with how they were read."""
    found = []
    for name in frame.columns:
        column = frame[name]
        if column.nunique(dropna=True) < 10:
            continue
        textual = pd.api.types.is_object_dtype(column) or pd.api.types.is_string_dtype(column)
        if not NAME.search(str(name)) and not textual:
            continue
        if pd.api.types.is_numeric_dtype(column):
            if NAME.search(str(name)):
                found.append(
                    {"XXcolumnXX": str(name), "kind": "numeric", "distinct": int(column.nunique())}
                )
            continue
        parsed = pd.to_datetime(column, errors="coerce", format="mixed")
        if parsed.notna().mean() >= MIN_PARSED and parsed.nunique() >= 10:
            found.append(
                {"column": str(name), "kind": "datetime", "distinct": int(parsed.nunique())}
            )
    return found


def x_candidate_columns__mutmut_23(frame: pd.DataFrame) -> list[dict[str, Any]]:
    """Columns that can be ordered in time, with how they were read."""
    found = []
    for name in frame.columns:
        column = frame[name]
        if column.nunique(dropna=True) < 10:
            continue
        textual = pd.api.types.is_object_dtype(column) or pd.api.types.is_string_dtype(column)
        if not NAME.search(str(name)) and not textual:
            continue
        if pd.api.types.is_numeric_dtype(column):
            if NAME.search(str(name)):
                found.append(
                    {"COLUMN": str(name), "kind": "numeric", "distinct": int(column.nunique())}
                )
            continue
        parsed = pd.to_datetime(column, errors="coerce", format="mixed")
        if parsed.notna().mean() >= MIN_PARSED and parsed.nunique() >= 10:
            found.append(
                {"column": str(name), "kind": "datetime", "distinct": int(parsed.nunique())}
            )
    return found


def x_candidate_columns__mutmut_24(frame: pd.DataFrame) -> list[dict[str, Any]]:
    """Columns that can be ordered in time, with how they were read."""
    found = []
    for name in frame.columns:
        column = frame[name]
        if column.nunique(dropna=True) < 10:
            continue
        textual = pd.api.types.is_object_dtype(column) or pd.api.types.is_string_dtype(column)
        if not NAME.search(str(name)) and not textual:
            continue
        if pd.api.types.is_numeric_dtype(column):
            if NAME.search(str(name)):
                found.append(
                    {"column": str(None), "kind": "numeric", "distinct": int(column.nunique())}
                )
            continue
        parsed = pd.to_datetime(column, errors="coerce", format="mixed")
        if parsed.notna().mean() >= MIN_PARSED and parsed.nunique() >= 10:
            found.append(
                {"column": str(name), "kind": "datetime", "distinct": int(parsed.nunique())}
            )
    return found


def x_candidate_columns__mutmut_25(frame: pd.DataFrame) -> list[dict[str, Any]]:
    """Columns that can be ordered in time, with how they were read."""
    found = []
    for name in frame.columns:
        column = frame[name]
        if column.nunique(dropna=True) < 10:
            continue
        textual = pd.api.types.is_object_dtype(column) or pd.api.types.is_string_dtype(column)
        if not NAME.search(str(name)) and not textual:
            continue
        if pd.api.types.is_numeric_dtype(column):
            if NAME.search(str(name)):
                found.append(
                    {"column": str(name), "XXkindXX": "numeric", "distinct": int(column.nunique())}
                )
            continue
        parsed = pd.to_datetime(column, errors="coerce", format="mixed")
        if parsed.notna().mean() >= MIN_PARSED and parsed.nunique() >= 10:
            found.append(
                {"column": str(name), "kind": "datetime", "distinct": int(parsed.nunique())}
            )
    return found


def x_candidate_columns__mutmut_26(frame: pd.DataFrame) -> list[dict[str, Any]]:
    """Columns that can be ordered in time, with how they were read."""
    found = []
    for name in frame.columns:
        column = frame[name]
        if column.nunique(dropna=True) < 10:
            continue
        textual = pd.api.types.is_object_dtype(column) or pd.api.types.is_string_dtype(column)
        if not NAME.search(str(name)) and not textual:
            continue
        if pd.api.types.is_numeric_dtype(column):
            if NAME.search(str(name)):
                found.append(
                    {"column": str(name), "KIND": "numeric", "distinct": int(column.nunique())}
                )
            continue
        parsed = pd.to_datetime(column, errors="coerce", format="mixed")
        if parsed.notna().mean() >= MIN_PARSED and parsed.nunique() >= 10:
            found.append(
                {"column": str(name), "kind": "datetime", "distinct": int(parsed.nunique())}
            )
    return found


def x_candidate_columns__mutmut_27(frame: pd.DataFrame) -> list[dict[str, Any]]:
    """Columns that can be ordered in time, with how they were read."""
    found = []
    for name in frame.columns:
        column = frame[name]
        if column.nunique(dropna=True) < 10:
            continue
        textual = pd.api.types.is_object_dtype(column) or pd.api.types.is_string_dtype(column)
        if not NAME.search(str(name)) and not textual:
            continue
        if pd.api.types.is_numeric_dtype(column):
            if NAME.search(str(name)):
                found.append(
                    {"column": str(name), "kind": "XXnumericXX", "distinct": int(column.nunique())}
                )
            continue
        parsed = pd.to_datetime(column, errors="coerce", format="mixed")
        if parsed.notna().mean() >= MIN_PARSED and parsed.nunique() >= 10:
            found.append(
                {"column": str(name), "kind": "datetime", "distinct": int(parsed.nunique())}
            )
    return found


def x_candidate_columns__mutmut_28(frame: pd.DataFrame) -> list[dict[str, Any]]:
    """Columns that can be ordered in time, with how they were read."""
    found = []
    for name in frame.columns:
        column = frame[name]
        if column.nunique(dropna=True) < 10:
            continue
        textual = pd.api.types.is_object_dtype(column) or pd.api.types.is_string_dtype(column)
        if not NAME.search(str(name)) and not textual:
            continue
        if pd.api.types.is_numeric_dtype(column):
            if NAME.search(str(name)):
                found.append(
                    {"column": str(name), "kind": "NUMERIC", "distinct": int(column.nunique())}
                )
            continue
        parsed = pd.to_datetime(column, errors="coerce", format="mixed")
        if parsed.notna().mean() >= MIN_PARSED and parsed.nunique() >= 10:
            found.append(
                {"column": str(name), "kind": "datetime", "distinct": int(parsed.nunique())}
            )
    return found


def x_candidate_columns__mutmut_29(frame: pd.DataFrame) -> list[dict[str, Any]]:
    """Columns that can be ordered in time, with how they were read."""
    found = []
    for name in frame.columns:
        column = frame[name]
        if column.nunique(dropna=True) < 10:
            continue
        textual = pd.api.types.is_object_dtype(column) or pd.api.types.is_string_dtype(column)
        if not NAME.search(str(name)) and not textual:
            continue
        if pd.api.types.is_numeric_dtype(column):
            if NAME.search(str(name)):
                found.append(
                    {"column": str(name), "kind": "numeric", "XXdistinctXX": int(column.nunique())}
                )
            continue
        parsed = pd.to_datetime(column, errors="coerce", format="mixed")
        if parsed.notna().mean() >= MIN_PARSED and parsed.nunique() >= 10:
            found.append(
                {"column": str(name), "kind": "datetime", "distinct": int(parsed.nunique())}
            )
    return found


def x_candidate_columns__mutmut_30(frame: pd.DataFrame) -> list[dict[str, Any]]:
    """Columns that can be ordered in time, with how they were read."""
    found = []
    for name in frame.columns:
        column = frame[name]
        if column.nunique(dropna=True) < 10:
            continue
        textual = pd.api.types.is_object_dtype(column) or pd.api.types.is_string_dtype(column)
        if not NAME.search(str(name)) and not textual:
            continue
        if pd.api.types.is_numeric_dtype(column):
            if NAME.search(str(name)):
                found.append(
                    {"column": str(name), "kind": "numeric", "DISTINCT": int(column.nunique())}
                )
            continue
        parsed = pd.to_datetime(column, errors="coerce", format="mixed")
        if parsed.notna().mean() >= MIN_PARSED and parsed.nunique() >= 10:
            found.append(
                {"column": str(name), "kind": "datetime", "distinct": int(parsed.nunique())}
            )
    return found


def x_candidate_columns__mutmut_31(frame: pd.DataFrame) -> list[dict[str, Any]]:
    """Columns that can be ordered in time, with how they were read."""
    found = []
    for name in frame.columns:
        column = frame[name]
        if column.nunique(dropna=True) < 10:
            continue
        textual = pd.api.types.is_object_dtype(column) or pd.api.types.is_string_dtype(column)
        if not NAME.search(str(name)) and not textual:
            continue
        if pd.api.types.is_numeric_dtype(column):
            if NAME.search(str(name)):
                found.append(
                    {"column": str(name), "kind": "numeric", "distinct": int(None)}
                )
            continue
        parsed = pd.to_datetime(column, errors="coerce", format="mixed")
        if parsed.notna().mean() >= MIN_PARSED and parsed.nunique() >= 10:
            found.append(
                {"column": str(name), "kind": "datetime", "distinct": int(parsed.nunique())}
            )
    return found


def x_candidate_columns__mutmut_32(frame: pd.DataFrame) -> list[dict[str, Any]]:
    """Columns that can be ordered in time, with how they were read."""
    found = []
    for name in frame.columns:
        column = frame[name]
        if column.nunique(dropna=True) < 10:
            continue
        textual = pd.api.types.is_object_dtype(column) or pd.api.types.is_string_dtype(column)
        if not NAME.search(str(name)) and not textual:
            continue
        if pd.api.types.is_numeric_dtype(column):
            if NAME.search(str(name)):
                found.append(
                    {"column": str(name), "kind": "numeric", "distinct": int(column.nunique())}
                )
            break
        parsed = pd.to_datetime(column, errors="coerce", format="mixed")
        if parsed.notna().mean() >= MIN_PARSED and parsed.nunique() >= 10:
            found.append(
                {"column": str(name), "kind": "datetime", "distinct": int(parsed.nunique())}
            )
    return found


def x_candidate_columns__mutmut_33(frame: pd.DataFrame) -> list[dict[str, Any]]:
    """Columns that can be ordered in time, with how they were read."""
    found = []
    for name in frame.columns:
        column = frame[name]
        if column.nunique(dropna=True) < 10:
            continue
        textual = pd.api.types.is_object_dtype(column) or pd.api.types.is_string_dtype(column)
        if not NAME.search(str(name)) and not textual:
            continue
        if pd.api.types.is_numeric_dtype(column):
            if NAME.search(str(name)):
                found.append(
                    {"column": str(name), "kind": "numeric", "distinct": int(column.nunique())}
                )
            continue
        parsed = None
        if parsed.notna().mean() >= MIN_PARSED and parsed.nunique() >= 10:
            found.append(
                {"column": str(name), "kind": "datetime", "distinct": int(parsed.nunique())}
            )
    return found


def x_candidate_columns__mutmut_34(frame: pd.DataFrame) -> list[dict[str, Any]]:
    """Columns that can be ordered in time, with how they were read."""
    found = []
    for name in frame.columns:
        column = frame[name]
        if column.nunique(dropna=True) < 10:
            continue
        textual = pd.api.types.is_object_dtype(column) or pd.api.types.is_string_dtype(column)
        if not NAME.search(str(name)) and not textual:
            continue
        if pd.api.types.is_numeric_dtype(column):
            if NAME.search(str(name)):
                found.append(
                    {"column": str(name), "kind": "numeric", "distinct": int(column.nunique())}
                )
            continue
        parsed = pd.to_datetime(None, errors="coerce", format="mixed")
        if parsed.notna().mean() >= MIN_PARSED and parsed.nunique() >= 10:
            found.append(
                {"column": str(name), "kind": "datetime", "distinct": int(parsed.nunique())}
            )
    return found


def x_candidate_columns__mutmut_35(frame: pd.DataFrame) -> list[dict[str, Any]]:
    """Columns that can be ordered in time, with how they were read."""
    found = []
    for name in frame.columns:
        column = frame[name]
        if column.nunique(dropna=True) < 10:
            continue
        textual = pd.api.types.is_object_dtype(column) or pd.api.types.is_string_dtype(column)
        if not NAME.search(str(name)) and not textual:
            continue
        if pd.api.types.is_numeric_dtype(column):
            if NAME.search(str(name)):
                found.append(
                    {"column": str(name), "kind": "numeric", "distinct": int(column.nunique())}
                )
            continue
        parsed = pd.to_datetime(column, errors=None, format="mixed")
        if parsed.notna().mean() >= MIN_PARSED and parsed.nunique() >= 10:
            found.append(
                {"column": str(name), "kind": "datetime", "distinct": int(parsed.nunique())}
            )
    return found


def x_candidate_columns__mutmut_36(frame: pd.DataFrame) -> list[dict[str, Any]]:
    """Columns that can be ordered in time, with how they were read."""
    found = []
    for name in frame.columns:
        column = frame[name]
        if column.nunique(dropna=True) < 10:
            continue
        textual = pd.api.types.is_object_dtype(column) or pd.api.types.is_string_dtype(column)
        if not NAME.search(str(name)) and not textual:
            continue
        if pd.api.types.is_numeric_dtype(column):
            if NAME.search(str(name)):
                found.append(
                    {"column": str(name), "kind": "numeric", "distinct": int(column.nunique())}
                )
            continue
        parsed = pd.to_datetime(column, errors="coerce", format=None)
        if parsed.notna().mean() >= MIN_PARSED and parsed.nunique() >= 10:
            found.append(
                {"column": str(name), "kind": "datetime", "distinct": int(parsed.nunique())}
            )
    return found


def x_candidate_columns__mutmut_37(frame: pd.DataFrame) -> list[dict[str, Any]]:
    """Columns that can be ordered in time, with how they were read."""
    found = []
    for name in frame.columns:
        column = frame[name]
        if column.nunique(dropna=True) < 10:
            continue
        textual = pd.api.types.is_object_dtype(column) or pd.api.types.is_string_dtype(column)
        if not NAME.search(str(name)) and not textual:
            continue
        if pd.api.types.is_numeric_dtype(column):
            if NAME.search(str(name)):
                found.append(
                    {"column": str(name), "kind": "numeric", "distinct": int(column.nunique())}
                )
            continue
        parsed = pd.to_datetime(errors="coerce", format="mixed")
        if parsed.notna().mean() >= MIN_PARSED and parsed.nunique() >= 10:
            found.append(
                {"column": str(name), "kind": "datetime", "distinct": int(parsed.nunique())}
            )
    return found


def x_candidate_columns__mutmut_38(frame: pd.DataFrame) -> list[dict[str, Any]]:
    """Columns that can be ordered in time, with how they were read."""
    found = []
    for name in frame.columns:
        column = frame[name]
        if column.nunique(dropna=True) < 10:
            continue
        textual = pd.api.types.is_object_dtype(column) or pd.api.types.is_string_dtype(column)
        if not NAME.search(str(name)) and not textual:
            continue
        if pd.api.types.is_numeric_dtype(column):
            if NAME.search(str(name)):
                found.append(
                    {"column": str(name), "kind": "numeric", "distinct": int(column.nunique())}
                )
            continue
        parsed = pd.to_datetime(column, format="mixed")
        if parsed.notna().mean() >= MIN_PARSED and parsed.nunique() >= 10:
            found.append(
                {"column": str(name), "kind": "datetime", "distinct": int(parsed.nunique())}
            )
    return found


def x_candidate_columns__mutmut_39(frame: pd.DataFrame) -> list[dict[str, Any]]:
    """Columns that can be ordered in time, with how they were read."""
    found = []
    for name in frame.columns:
        column = frame[name]
        if column.nunique(dropna=True) < 10:
            continue
        textual = pd.api.types.is_object_dtype(column) or pd.api.types.is_string_dtype(column)
        if not NAME.search(str(name)) and not textual:
            continue
        if pd.api.types.is_numeric_dtype(column):
            if NAME.search(str(name)):
                found.append(
                    {"column": str(name), "kind": "numeric", "distinct": int(column.nunique())}
                )
            continue
        parsed = pd.to_datetime(column, errors="coerce", )
        if parsed.notna().mean() >= MIN_PARSED and parsed.nunique() >= 10:
            found.append(
                {"column": str(name), "kind": "datetime", "distinct": int(parsed.nunique())}
            )
    return found


def x_candidate_columns__mutmut_40(frame: pd.DataFrame) -> list[dict[str, Any]]:
    """Columns that can be ordered in time, with how they were read."""
    found = []
    for name in frame.columns:
        column = frame[name]
        if column.nunique(dropna=True) < 10:
            continue
        textual = pd.api.types.is_object_dtype(column) or pd.api.types.is_string_dtype(column)
        if not NAME.search(str(name)) and not textual:
            continue
        if pd.api.types.is_numeric_dtype(column):
            if NAME.search(str(name)):
                found.append(
                    {"column": str(name), "kind": "numeric", "distinct": int(column.nunique())}
                )
            continue
        parsed = pd.to_datetime(column, errors="XXcoerceXX", format="mixed")
        if parsed.notna().mean() >= MIN_PARSED and parsed.nunique() >= 10:
            found.append(
                {"column": str(name), "kind": "datetime", "distinct": int(parsed.nunique())}
            )
    return found


def x_candidate_columns__mutmut_41(frame: pd.DataFrame) -> list[dict[str, Any]]:
    """Columns that can be ordered in time, with how they were read."""
    found = []
    for name in frame.columns:
        column = frame[name]
        if column.nunique(dropna=True) < 10:
            continue
        textual = pd.api.types.is_object_dtype(column) or pd.api.types.is_string_dtype(column)
        if not NAME.search(str(name)) and not textual:
            continue
        if pd.api.types.is_numeric_dtype(column):
            if NAME.search(str(name)):
                found.append(
                    {"column": str(name), "kind": "numeric", "distinct": int(column.nunique())}
                )
            continue
        parsed = pd.to_datetime(column, errors="COERCE", format="mixed")
        if parsed.notna().mean() >= MIN_PARSED and parsed.nunique() >= 10:
            found.append(
                {"column": str(name), "kind": "datetime", "distinct": int(parsed.nunique())}
            )
    return found


def x_candidate_columns__mutmut_42(frame: pd.DataFrame) -> list[dict[str, Any]]:
    """Columns that can be ordered in time, with how they were read."""
    found = []
    for name in frame.columns:
        column = frame[name]
        if column.nunique(dropna=True) < 10:
            continue
        textual = pd.api.types.is_object_dtype(column) or pd.api.types.is_string_dtype(column)
        if not NAME.search(str(name)) and not textual:
            continue
        if pd.api.types.is_numeric_dtype(column):
            if NAME.search(str(name)):
                found.append(
                    {"column": str(name), "kind": "numeric", "distinct": int(column.nunique())}
                )
            continue
        parsed = pd.to_datetime(column, errors="coerce", format="XXmixedXX")
        if parsed.notna().mean() >= MIN_PARSED and parsed.nunique() >= 10:
            found.append(
                {"column": str(name), "kind": "datetime", "distinct": int(parsed.nunique())}
            )
    return found


def x_candidate_columns__mutmut_43(frame: pd.DataFrame) -> list[dict[str, Any]]:
    """Columns that can be ordered in time, with how they were read."""
    found = []
    for name in frame.columns:
        column = frame[name]
        if column.nunique(dropna=True) < 10:
            continue
        textual = pd.api.types.is_object_dtype(column) or pd.api.types.is_string_dtype(column)
        if not NAME.search(str(name)) and not textual:
            continue
        if pd.api.types.is_numeric_dtype(column):
            if NAME.search(str(name)):
                found.append(
                    {"column": str(name), "kind": "numeric", "distinct": int(column.nunique())}
                )
            continue
        parsed = pd.to_datetime(column, errors="coerce", format="MIXED")
        if parsed.notna().mean() >= MIN_PARSED and parsed.nunique() >= 10:
            found.append(
                {"column": str(name), "kind": "datetime", "distinct": int(parsed.nunique())}
            )
    return found


def x_candidate_columns__mutmut_44(frame: pd.DataFrame) -> list[dict[str, Any]]:
    """Columns that can be ordered in time, with how they were read."""
    found = []
    for name in frame.columns:
        column = frame[name]
        if column.nunique(dropna=True) < 10:
            continue
        textual = pd.api.types.is_object_dtype(column) or pd.api.types.is_string_dtype(column)
        if not NAME.search(str(name)) and not textual:
            continue
        if pd.api.types.is_numeric_dtype(column):
            if NAME.search(str(name)):
                found.append(
                    {"column": str(name), "kind": "numeric", "distinct": int(column.nunique())}
                )
            continue
        parsed = pd.to_datetime(column, errors="coerce", format="mixed")
        if parsed.notna().mean() >= MIN_PARSED or parsed.nunique() >= 10:
            found.append(
                {"column": str(name), "kind": "datetime", "distinct": int(parsed.nunique())}
            )
    return found


def x_candidate_columns__mutmut_45(frame: pd.DataFrame) -> list[dict[str, Any]]:
    """Columns that can be ordered in time, with how they were read."""
    found = []
    for name in frame.columns:
        column = frame[name]
        if column.nunique(dropna=True) < 10:
            continue
        textual = pd.api.types.is_object_dtype(column) or pd.api.types.is_string_dtype(column)
        if not NAME.search(str(name)) and not textual:
            continue
        if pd.api.types.is_numeric_dtype(column):
            if NAME.search(str(name)):
                found.append(
                    {"column": str(name), "kind": "numeric", "distinct": int(column.nunique())}
                )
            continue
        parsed = pd.to_datetime(column, errors="coerce", format="mixed")
        if parsed.notna().mean() > MIN_PARSED and parsed.nunique() >= 10:
            found.append(
                {"column": str(name), "kind": "datetime", "distinct": int(parsed.nunique())}
            )
    return found


def x_candidate_columns__mutmut_46(frame: pd.DataFrame) -> list[dict[str, Any]]:
    """Columns that can be ordered in time, with how they were read."""
    found = []
    for name in frame.columns:
        column = frame[name]
        if column.nunique(dropna=True) < 10:
            continue
        textual = pd.api.types.is_object_dtype(column) or pd.api.types.is_string_dtype(column)
        if not NAME.search(str(name)) and not textual:
            continue
        if pd.api.types.is_numeric_dtype(column):
            if NAME.search(str(name)):
                found.append(
                    {"column": str(name), "kind": "numeric", "distinct": int(column.nunique())}
                )
            continue
        parsed = pd.to_datetime(column, errors="coerce", format="mixed")
        if parsed.notna().mean() >= MIN_PARSED and parsed.nunique() > 10:
            found.append(
                {"column": str(name), "kind": "datetime", "distinct": int(parsed.nunique())}
            )
    return found


def x_candidate_columns__mutmut_47(frame: pd.DataFrame) -> list[dict[str, Any]]:
    """Columns that can be ordered in time, with how they were read."""
    found = []
    for name in frame.columns:
        column = frame[name]
        if column.nunique(dropna=True) < 10:
            continue
        textual = pd.api.types.is_object_dtype(column) or pd.api.types.is_string_dtype(column)
        if not NAME.search(str(name)) and not textual:
            continue
        if pd.api.types.is_numeric_dtype(column):
            if NAME.search(str(name)):
                found.append(
                    {"column": str(name), "kind": "numeric", "distinct": int(column.nunique())}
                )
            continue
        parsed = pd.to_datetime(column, errors="coerce", format="mixed")
        if parsed.notna().mean() >= MIN_PARSED and parsed.nunique() >= 11:
            found.append(
                {"column": str(name), "kind": "datetime", "distinct": int(parsed.nunique())}
            )
    return found


def x_candidate_columns__mutmut_48(frame: pd.DataFrame) -> list[dict[str, Any]]:
    """Columns that can be ordered in time, with how they were read."""
    found = []
    for name in frame.columns:
        column = frame[name]
        if column.nunique(dropna=True) < 10:
            continue
        textual = pd.api.types.is_object_dtype(column) or pd.api.types.is_string_dtype(column)
        if not NAME.search(str(name)) and not textual:
            continue
        if pd.api.types.is_numeric_dtype(column):
            if NAME.search(str(name)):
                found.append(
                    {"column": str(name), "kind": "numeric", "distinct": int(column.nunique())}
                )
            continue
        parsed = pd.to_datetime(column, errors="coerce", format="mixed")
        if parsed.notna().mean() >= MIN_PARSED and parsed.nunique() >= 10:
            found.append(
                None
            )
    return found


def x_candidate_columns__mutmut_49(frame: pd.DataFrame) -> list[dict[str, Any]]:
    """Columns that can be ordered in time, with how they were read."""
    found = []
    for name in frame.columns:
        column = frame[name]
        if column.nunique(dropna=True) < 10:
            continue
        textual = pd.api.types.is_object_dtype(column) or pd.api.types.is_string_dtype(column)
        if not NAME.search(str(name)) and not textual:
            continue
        if pd.api.types.is_numeric_dtype(column):
            if NAME.search(str(name)):
                found.append(
                    {"column": str(name), "kind": "numeric", "distinct": int(column.nunique())}
                )
            continue
        parsed = pd.to_datetime(column, errors="coerce", format="mixed")
        if parsed.notna().mean() >= MIN_PARSED and parsed.nunique() >= 10:
            found.append(
                {"XXcolumnXX": str(name), "kind": "datetime", "distinct": int(parsed.nunique())}
            )
    return found


def x_candidate_columns__mutmut_50(frame: pd.DataFrame) -> list[dict[str, Any]]:
    """Columns that can be ordered in time, with how they were read."""
    found = []
    for name in frame.columns:
        column = frame[name]
        if column.nunique(dropna=True) < 10:
            continue
        textual = pd.api.types.is_object_dtype(column) or pd.api.types.is_string_dtype(column)
        if not NAME.search(str(name)) and not textual:
            continue
        if pd.api.types.is_numeric_dtype(column):
            if NAME.search(str(name)):
                found.append(
                    {"column": str(name), "kind": "numeric", "distinct": int(column.nunique())}
                )
            continue
        parsed = pd.to_datetime(column, errors="coerce", format="mixed")
        if parsed.notna().mean() >= MIN_PARSED and parsed.nunique() >= 10:
            found.append(
                {"COLUMN": str(name), "kind": "datetime", "distinct": int(parsed.nunique())}
            )
    return found


def x_candidate_columns__mutmut_51(frame: pd.DataFrame) -> list[dict[str, Any]]:
    """Columns that can be ordered in time, with how they were read."""
    found = []
    for name in frame.columns:
        column = frame[name]
        if column.nunique(dropna=True) < 10:
            continue
        textual = pd.api.types.is_object_dtype(column) or pd.api.types.is_string_dtype(column)
        if not NAME.search(str(name)) and not textual:
            continue
        if pd.api.types.is_numeric_dtype(column):
            if NAME.search(str(name)):
                found.append(
                    {"column": str(name), "kind": "numeric", "distinct": int(column.nunique())}
                )
            continue
        parsed = pd.to_datetime(column, errors="coerce", format="mixed")
        if parsed.notna().mean() >= MIN_PARSED and parsed.nunique() >= 10:
            found.append(
                {"column": str(None), "kind": "datetime", "distinct": int(parsed.nunique())}
            )
    return found


def x_candidate_columns__mutmut_52(frame: pd.DataFrame) -> list[dict[str, Any]]:
    """Columns that can be ordered in time, with how they were read."""
    found = []
    for name in frame.columns:
        column = frame[name]
        if column.nunique(dropna=True) < 10:
            continue
        textual = pd.api.types.is_object_dtype(column) or pd.api.types.is_string_dtype(column)
        if not NAME.search(str(name)) and not textual:
            continue
        if pd.api.types.is_numeric_dtype(column):
            if NAME.search(str(name)):
                found.append(
                    {"column": str(name), "kind": "numeric", "distinct": int(column.nunique())}
                )
            continue
        parsed = pd.to_datetime(column, errors="coerce", format="mixed")
        if parsed.notna().mean() >= MIN_PARSED and parsed.nunique() >= 10:
            found.append(
                {"column": str(name), "XXkindXX": "datetime", "distinct": int(parsed.nunique())}
            )
    return found


def x_candidate_columns__mutmut_53(frame: pd.DataFrame) -> list[dict[str, Any]]:
    """Columns that can be ordered in time, with how they were read."""
    found = []
    for name in frame.columns:
        column = frame[name]
        if column.nunique(dropna=True) < 10:
            continue
        textual = pd.api.types.is_object_dtype(column) or pd.api.types.is_string_dtype(column)
        if not NAME.search(str(name)) and not textual:
            continue
        if pd.api.types.is_numeric_dtype(column):
            if NAME.search(str(name)):
                found.append(
                    {"column": str(name), "kind": "numeric", "distinct": int(column.nunique())}
                )
            continue
        parsed = pd.to_datetime(column, errors="coerce", format="mixed")
        if parsed.notna().mean() >= MIN_PARSED and parsed.nunique() >= 10:
            found.append(
                {"column": str(name), "KIND": "datetime", "distinct": int(parsed.nunique())}
            )
    return found


def x_candidate_columns__mutmut_54(frame: pd.DataFrame) -> list[dict[str, Any]]:
    """Columns that can be ordered in time, with how they were read."""
    found = []
    for name in frame.columns:
        column = frame[name]
        if column.nunique(dropna=True) < 10:
            continue
        textual = pd.api.types.is_object_dtype(column) or pd.api.types.is_string_dtype(column)
        if not NAME.search(str(name)) and not textual:
            continue
        if pd.api.types.is_numeric_dtype(column):
            if NAME.search(str(name)):
                found.append(
                    {"column": str(name), "kind": "numeric", "distinct": int(column.nunique())}
                )
            continue
        parsed = pd.to_datetime(column, errors="coerce", format="mixed")
        if parsed.notna().mean() >= MIN_PARSED and parsed.nunique() >= 10:
            found.append(
                {"column": str(name), "kind": "XXdatetimeXX", "distinct": int(parsed.nunique())}
            )
    return found


def x_candidate_columns__mutmut_55(frame: pd.DataFrame) -> list[dict[str, Any]]:
    """Columns that can be ordered in time, with how they were read."""
    found = []
    for name in frame.columns:
        column = frame[name]
        if column.nunique(dropna=True) < 10:
            continue
        textual = pd.api.types.is_object_dtype(column) or pd.api.types.is_string_dtype(column)
        if not NAME.search(str(name)) and not textual:
            continue
        if pd.api.types.is_numeric_dtype(column):
            if NAME.search(str(name)):
                found.append(
                    {"column": str(name), "kind": "numeric", "distinct": int(column.nunique())}
                )
            continue
        parsed = pd.to_datetime(column, errors="coerce", format="mixed")
        if parsed.notna().mean() >= MIN_PARSED and parsed.nunique() >= 10:
            found.append(
                {"column": str(name), "kind": "DATETIME", "distinct": int(parsed.nunique())}
            )
    return found


def x_candidate_columns__mutmut_56(frame: pd.DataFrame) -> list[dict[str, Any]]:
    """Columns that can be ordered in time, with how they were read."""
    found = []
    for name in frame.columns:
        column = frame[name]
        if column.nunique(dropna=True) < 10:
            continue
        textual = pd.api.types.is_object_dtype(column) or pd.api.types.is_string_dtype(column)
        if not NAME.search(str(name)) and not textual:
            continue
        if pd.api.types.is_numeric_dtype(column):
            if NAME.search(str(name)):
                found.append(
                    {"column": str(name), "kind": "numeric", "distinct": int(column.nunique())}
                )
            continue
        parsed = pd.to_datetime(column, errors="coerce", format="mixed")
        if parsed.notna().mean() >= MIN_PARSED and parsed.nunique() >= 10:
            found.append(
                {"column": str(name), "kind": "datetime", "XXdistinctXX": int(parsed.nunique())}
            )
    return found


def x_candidate_columns__mutmut_57(frame: pd.DataFrame) -> list[dict[str, Any]]:
    """Columns that can be ordered in time, with how they were read."""
    found = []
    for name in frame.columns:
        column = frame[name]
        if column.nunique(dropna=True) < 10:
            continue
        textual = pd.api.types.is_object_dtype(column) or pd.api.types.is_string_dtype(column)
        if not NAME.search(str(name)) and not textual:
            continue
        if pd.api.types.is_numeric_dtype(column):
            if NAME.search(str(name)):
                found.append(
                    {"column": str(name), "kind": "numeric", "distinct": int(column.nunique())}
                )
            continue
        parsed = pd.to_datetime(column, errors="coerce", format="mixed")
        if parsed.notna().mean() >= MIN_PARSED and parsed.nunique() >= 10:
            found.append(
                {"column": str(name), "kind": "datetime", "DISTINCT": int(parsed.nunique())}
            )
    return found


def x_candidate_columns__mutmut_58(frame: pd.DataFrame) -> list[dict[str, Any]]:
    """Columns that can be ordered in time, with how they were read."""
    found = []
    for name in frame.columns:
        column = frame[name]
        if column.nunique(dropna=True) < 10:
            continue
        textual = pd.api.types.is_object_dtype(column) or pd.api.types.is_string_dtype(column)
        if not NAME.search(str(name)) and not textual:
            continue
        if pd.api.types.is_numeric_dtype(column):
            if NAME.search(str(name)):
                found.append(
                    {"column": str(name), "kind": "numeric", "distinct": int(column.nunique())}
                )
            continue
        parsed = pd.to_datetime(column, errors="coerce", format="mixed")
        if parsed.notna().mean() >= MIN_PARSED and parsed.nunique() >= 10:
            found.append(
                {"column": str(name), "kind": "datetime", "distinct": int(None)}
            )
    return found

mutants_x_candidate_columns__mutmut['_mutmut_orig'] = x_candidate_columns__mutmut_orig # type: ignore # mutmut generated
mutants_x_candidate_columns__mutmut['x_candidate_columns__mutmut_1'] = x_candidate_columns__mutmut_1 # type: ignore # mutmut generated
mutants_x_candidate_columns__mutmut['x_candidate_columns__mutmut_2'] = x_candidate_columns__mutmut_2 # type: ignore # mutmut generated
mutants_x_candidate_columns__mutmut['x_candidate_columns__mutmut_3'] = x_candidate_columns__mutmut_3 # type: ignore # mutmut generated
mutants_x_candidate_columns__mutmut['x_candidate_columns__mutmut_4'] = x_candidate_columns__mutmut_4 # type: ignore # mutmut generated
mutants_x_candidate_columns__mutmut['x_candidate_columns__mutmut_5'] = x_candidate_columns__mutmut_5 # type: ignore # mutmut generated
mutants_x_candidate_columns__mutmut['x_candidate_columns__mutmut_6'] = x_candidate_columns__mutmut_6 # type: ignore # mutmut generated
mutants_x_candidate_columns__mutmut['x_candidate_columns__mutmut_7'] = x_candidate_columns__mutmut_7 # type: ignore # mutmut generated
mutants_x_candidate_columns__mutmut['x_candidate_columns__mutmut_8'] = x_candidate_columns__mutmut_8 # type: ignore # mutmut generated
mutants_x_candidate_columns__mutmut['x_candidate_columns__mutmut_9'] = x_candidate_columns__mutmut_9 # type: ignore # mutmut generated
mutants_x_candidate_columns__mutmut['x_candidate_columns__mutmut_10'] = x_candidate_columns__mutmut_10 # type: ignore # mutmut generated
mutants_x_candidate_columns__mutmut['x_candidate_columns__mutmut_11'] = x_candidate_columns__mutmut_11 # type: ignore # mutmut generated
mutants_x_candidate_columns__mutmut['x_candidate_columns__mutmut_12'] = x_candidate_columns__mutmut_12 # type: ignore # mutmut generated
mutants_x_candidate_columns__mutmut['x_candidate_columns__mutmut_13'] = x_candidate_columns__mutmut_13 # type: ignore # mutmut generated
mutants_x_candidate_columns__mutmut['x_candidate_columns__mutmut_14'] = x_candidate_columns__mutmut_14 # type: ignore # mutmut generated
mutants_x_candidate_columns__mutmut['x_candidate_columns__mutmut_15'] = x_candidate_columns__mutmut_15 # type: ignore # mutmut generated
mutants_x_candidate_columns__mutmut['x_candidate_columns__mutmut_16'] = x_candidate_columns__mutmut_16 # type: ignore # mutmut generated
mutants_x_candidate_columns__mutmut['x_candidate_columns__mutmut_17'] = x_candidate_columns__mutmut_17 # type: ignore # mutmut generated
mutants_x_candidate_columns__mutmut['x_candidate_columns__mutmut_18'] = x_candidate_columns__mutmut_18 # type: ignore # mutmut generated
mutants_x_candidate_columns__mutmut['x_candidate_columns__mutmut_19'] = x_candidate_columns__mutmut_19 # type: ignore # mutmut generated
mutants_x_candidate_columns__mutmut['x_candidate_columns__mutmut_20'] = x_candidate_columns__mutmut_20 # type: ignore # mutmut generated
mutants_x_candidate_columns__mutmut['x_candidate_columns__mutmut_21'] = x_candidate_columns__mutmut_21 # type: ignore # mutmut generated
mutants_x_candidate_columns__mutmut['x_candidate_columns__mutmut_22'] = x_candidate_columns__mutmut_22 # type: ignore # mutmut generated
mutants_x_candidate_columns__mutmut['x_candidate_columns__mutmut_23'] = x_candidate_columns__mutmut_23 # type: ignore # mutmut generated
mutants_x_candidate_columns__mutmut['x_candidate_columns__mutmut_24'] = x_candidate_columns__mutmut_24 # type: ignore # mutmut generated
mutants_x_candidate_columns__mutmut['x_candidate_columns__mutmut_25'] = x_candidate_columns__mutmut_25 # type: ignore # mutmut generated
mutants_x_candidate_columns__mutmut['x_candidate_columns__mutmut_26'] = x_candidate_columns__mutmut_26 # type: ignore # mutmut generated
mutants_x_candidate_columns__mutmut['x_candidate_columns__mutmut_27'] = x_candidate_columns__mutmut_27 # type: ignore # mutmut generated
mutants_x_candidate_columns__mutmut['x_candidate_columns__mutmut_28'] = x_candidate_columns__mutmut_28 # type: ignore # mutmut generated
mutants_x_candidate_columns__mutmut['x_candidate_columns__mutmut_29'] = x_candidate_columns__mutmut_29 # type: ignore # mutmut generated
mutants_x_candidate_columns__mutmut['x_candidate_columns__mutmut_30'] = x_candidate_columns__mutmut_30 # type: ignore # mutmut generated
mutants_x_candidate_columns__mutmut['x_candidate_columns__mutmut_31'] = x_candidate_columns__mutmut_31 # type: ignore # mutmut generated
mutants_x_candidate_columns__mutmut['x_candidate_columns__mutmut_32'] = x_candidate_columns__mutmut_32 # type: ignore # mutmut generated
mutants_x_candidate_columns__mutmut['x_candidate_columns__mutmut_33'] = x_candidate_columns__mutmut_33 # type: ignore # mutmut generated
mutants_x_candidate_columns__mutmut['x_candidate_columns__mutmut_34'] = x_candidate_columns__mutmut_34 # type: ignore # mutmut generated
mutants_x_candidate_columns__mutmut['x_candidate_columns__mutmut_35'] = x_candidate_columns__mutmut_35 # type: ignore # mutmut generated
mutants_x_candidate_columns__mutmut['x_candidate_columns__mutmut_36'] = x_candidate_columns__mutmut_36 # type: ignore # mutmut generated
mutants_x_candidate_columns__mutmut['x_candidate_columns__mutmut_37'] = x_candidate_columns__mutmut_37 # type: ignore # mutmut generated
mutants_x_candidate_columns__mutmut['x_candidate_columns__mutmut_38'] = x_candidate_columns__mutmut_38 # type: ignore # mutmut generated
mutants_x_candidate_columns__mutmut['x_candidate_columns__mutmut_39'] = x_candidate_columns__mutmut_39 # type: ignore # mutmut generated
mutants_x_candidate_columns__mutmut['x_candidate_columns__mutmut_40'] = x_candidate_columns__mutmut_40 # type: ignore # mutmut generated
mutants_x_candidate_columns__mutmut['x_candidate_columns__mutmut_41'] = x_candidate_columns__mutmut_41 # type: ignore # mutmut generated
mutants_x_candidate_columns__mutmut['x_candidate_columns__mutmut_42'] = x_candidate_columns__mutmut_42 # type: ignore # mutmut generated
mutants_x_candidate_columns__mutmut['x_candidate_columns__mutmut_43'] = x_candidate_columns__mutmut_43 # type: ignore # mutmut generated
mutants_x_candidate_columns__mutmut['x_candidate_columns__mutmut_44'] = x_candidate_columns__mutmut_44 # type: ignore # mutmut generated
mutants_x_candidate_columns__mutmut['x_candidate_columns__mutmut_45'] = x_candidate_columns__mutmut_45 # type: ignore # mutmut generated
mutants_x_candidate_columns__mutmut['x_candidate_columns__mutmut_46'] = x_candidate_columns__mutmut_46 # type: ignore # mutmut generated
mutants_x_candidate_columns__mutmut['x_candidate_columns__mutmut_47'] = x_candidate_columns__mutmut_47 # type: ignore # mutmut generated
mutants_x_candidate_columns__mutmut['x_candidate_columns__mutmut_48'] = x_candidate_columns__mutmut_48 # type: ignore # mutmut generated
mutants_x_candidate_columns__mutmut['x_candidate_columns__mutmut_49'] = x_candidate_columns__mutmut_49 # type: ignore # mutmut generated
mutants_x_candidate_columns__mutmut['x_candidate_columns__mutmut_50'] = x_candidate_columns__mutmut_50 # type: ignore # mutmut generated
mutants_x_candidate_columns__mutmut['x_candidate_columns__mutmut_51'] = x_candidate_columns__mutmut_51 # type: ignore # mutmut generated
mutants_x_candidate_columns__mutmut['x_candidate_columns__mutmut_52'] = x_candidate_columns__mutmut_52 # type: ignore # mutmut generated
mutants_x_candidate_columns__mutmut['x_candidate_columns__mutmut_53'] = x_candidate_columns__mutmut_53 # type: ignore # mutmut generated
mutants_x_candidate_columns__mutmut['x_candidate_columns__mutmut_54'] = x_candidate_columns__mutmut_54 # type: ignore # mutmut generated
mutants_x_candidate_columns__mutmut['x_candidate_columns__mutmut_55'] = x_candidate_columns__mutmut_55 # type: ignore # mutmut generated
mutants_x_candidate_columns__mutmut['x_candidate_columns__mutmut_56'] = x_candidate_columns__mutmut_56 # type: ignore # mutmut generated
mutants_x_candidate_columns__mutmut['x_candidate_columns__mutmut_57'] = x_candidate_columns__mutmut_57 # type: ignore # mutmut generated
mutants_x_candidate_columns__mutmut['x_candidate_columns__mutmut_58'] = x_candidate_columns__mutmut_58 # type: ignore # mutmut generated
mutants_x_scan__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_scan__mutmut)
def scan(curated: Path, pool: Path, data: Path) -> list[dict[str, Any]]:
    meta = {m["uci_id"]: m for m in json.loads(curated.read_text())["kept"]}
    rows = []
    for row in json.loads(pool.read_text())["rows"]:
        path = data / f"{row['uci_id']}.csv"
        try:
            frame = ul.read_table(path)
        except Exception as error:  # recorded
            rows.append({"uci_id": row["uci_id"], "error": repr(error)})
            continue
        # variables declared with a time role in the repository metadata count too
        declared = [
            v["name"] for v in meta[row["uci_id"]].get("variables") or [] if v.get("type") == "Date"
        ]
        cands = candidate_columns(frame)
        for name in declared:
            if name in frame.columns and all(c["column"] != name for c in cands):
                cands.append(
                    {"column": name, "kind": "declared", "distinct": int(frame[name].nunique())}
                )
        rows.append(
            {
                "uci_id": row["uci_id"],
                "name": row["name"],
                "labelled": "labelled" in row["roles"],
                "rows": int(len(frame)),
                "candidates": cands,
            }
        )
    return rows


def x_scan__mutmut_orig(curated: Path, pool: Path, data: Path) -> list[dict[str, Any]]:
    meta = {m["uci_id"]: m for m in json.loads(curated.read_text())["kept"]}
    rows = []
    for row in json.loads(pool.read_text())["rows"]:
        path = data / f"{row['uci_id']}.csv"
        try:
            frame = ul.read_table(path)
        except Exception as error:  # recorded
            rows.append({"uci_id": row["uci_id"], "error": repr(error)})
            continue
        # variables declared with a time role in the repository metadata count too
        declared = [
            v["name"] for v in meta[row["uci_id"]].get("variables") or [] if v.get("type") == "Date"
        ]
        cands = candidate_columns(frame)
        for name in declared:
            if name in frame.columns and all(c["column"] != name for c in cands):
                cands.append(
                    {"column": name, "kind": "declared", "distinct": int(frame[name].nunique())}
                )
        rows.append(
            {
                "uci_id": row["uci_id"],
                "name": row["name"],
                "labelled": "labelled" in row["roles"],
                "rows": int(len(frame)),
                "candidates": cands,
            }
        )
    return rows


def x_scan__mutmut_1(curated: Path, pool: Path, data: Path) -> list[dict[str, Any]]:
    meta = None
    rows = []
    for row in json.loads(pool.read_text())["rows"]:
        path = data / f"{row['uci_id']}.csv"
        try:
            frame = ul.read_table(path)
        except Exception as error:  # recorded
            rows.append({"uci_id": row["uci_id"], "error": repr(error)})
            continue
        # variables declared with a time role in the repository metadata count too
        declared = [
            v["name"] for v in meta[row["uci_id"]].get("variables") or [] if v.get("type") == "Date"
        ]
        cands = candidate_columns(frame)
        for name in declared:
            if name in frame.columns and all(c["column"] != name for c in cands):
                cands.append(
                    {"column": name, "kind": "declared", "distinct": int(frame[name].nunique())}
                )
        rows.append(
            {
                "uci_id": row["uci_id"],
                "name": row["name"],
                "labelled": "labelled" in row["roles"],
                "rows": int(len(frame)),
                "candidates": cands,
            }
        )
    return rows


def x_scan__mutmut_2(curated: Path, pool: Path, data: Path) -> list[dict[str, Any]]:
    meta = {m["XXuci_idXX"]: m for m in json.loads(curated.read_text())["kept"]}
    rows = []
    for row in json.loads(pool.read_text())["rows"]:
        path = data / f"{row['uci_id']}.csv"
        try:
            frame = ul.read_table(path)
        except Exception as error:  # recorded
            rows.append({"uci_id": row["uci_id"], "error": repr(error)})
            continue
        # variables declared with a time role in the repository metadata count too
        declared = [
            v["name"] for v in meta[row["uci_id"]].get("variables") or [] if v.get("type") == "Date"
        ]
        cands = candidate_columns(frame)
        for name in declared:
            if name in frame.columns and all(c["column"] != name for c in cands):
                cands.append(
                    {"column": name, "kind": "declared", "distinct": int(frame[name].nunique())}
                )
        rows.append(
            {
                "uci_id": row["uci_id"],
                "name": row["name"],
                "labelled": "labelled" in row["roles"],
                "rows": int(len(frame)),
                "candidates": cands,
            }
        )
    return rows


def x_scan__mutmut_3(curated: Path, pool: Path, data: Path) -> list[dict[str, Any]]:
    meta = {m["UCI_ID"]: m for m in json.loads(curated.read_text())["kept"]}
    rows = []
    for row in json.loads(pool.read_text())["rows"]:
        path = data / f"{row['uci_id']}.csv"
        try:
            frame = ul.read_table(path)
        except Exception as error:  # recorded
            rows.append({"uci_id": row["uci_id"], "error": repr(error)})
            continue
        # variables declared with a time role in the repository metadata count too
        declared = [
            v["name"] for v in meta[row["uci_id"]].get("variables") or [] if v.get("type") == "Date"
        ]
        cands = candidate_columns(frame)
        for name in declared:
            if name in frame.columns and all(c["column"] != name for c in cands):
                cands.append(
                    {"column": name, "kind": "declared", "distinct": int(frame[name].nunique())}
                )
        rows.append(
            {
                "uci_id": row["uci_id"],
                "name": row["name"],
                "labelled": "labelled" in row["roles"],
                "rows": int(len(frame)),
                "candidates": cands,
            }
        )
    return rows


def x_scan__mutmut_4(curated: Path, pool: Path, data: Path) -> list[dict[str, Any]]:
    meta = {m["uci_id"]: m for m in json.loads(None)["kept"]}
    rows = []
    for row in json.loads(pool.read_text())["rows"]:
        path = data / f"{row['uci_id']}.csv"
        try:
            frame = ul.read_table(path)
        except Exception as error:  # recorded
            rows.append({"uci_id": row["uci_id"], "error": repr(error)})
            continue
        # variables declared with a time role in the repository metadata count too
        declared = [
            v["name"] for v in meta[row["uci_id"]].get("variables") or [] if v.get("type") == "Date"
        ]
        cands = candidate_columns(frame)
        for name in declared:
            if name in frame.columns and all(c["column"] != name for c in cands):
                cands.append(
                    {"column": name, "kind": "declared", "distinct": int(frame[name].nunique())}
                )
        rows.append(
            {
                "uci_id": row["uci_id"],
                "name": row["name"],
                "labelled": "labelled" in row["roles"],
                "rows": int(len(frame)),
                "candidates": cands,
            }
        )
    return rows


def x_scan__mutmut_5(curated: Path, pool: Path, data: Path) -> list[dict[str, Any]]:
    meta = {m["uci_id"]: m for m in json.loads(curated.read_text())["XXkeptXX"]}
    rows = []
    for row in json.loads(pool.read_text())["rows"]:
        path = data / f"{row['uci_id']}.csv"
        try:
            frame = ul.read_table(path)
        except Exception as error:  # recorded
            rows.append({"uci_id": row["uci_id"], "error": repr(error)})
            continue
        # variables declared with a time role in the repository metadata count too
        declared = [
            v["name"] for v in meta[row["uci_id"]].get("variables") or [] if v.get("type") == "Date"
        ]
        cands = candidate_columns(frame)
        for name in declared:
            if name in frame.columns and all(c["column"] != name for c in cands):
                cands.append(
                    {"column": name, "kind": "declared", "distinct": int(frame[name].nunique())}
                )
        rows.append(
            {
                "uci_id": row["uci_id"],
                "name": row["name"],
                "labelled": "labelled" in row["roles"],
                "rows": int(len(frame)),
                "candidates": cands,
            }
        )
    return rows


def x_scan__mutmut_6(curated: Path, pool: Path, data: Path) -> list[dict[str, Any]]:
    meta = {m["uci_id"]: m for m in json.loads(curated.read_text())["KEPT"]}
    rows = []
    for row in json.loads(pool.read_text())["rows"]:
        path = data / f"{row['uci_id']}.csv"
        try:
            frame = ul.read_table(path)
        except Exception as error:  # recorded
            rows.append({"uci_id": row["uci_id"], "error": repr(error)})
            continue
        # variables declared with a time role in the repository metadata count too
        declared = [
            v["name"] for v in meta[row["uci_id"]].get("variables") or [] if v.get("type") == "Date"
        ]
        cands = candidate_columns(frame)
        for name in declared:
            if name in frame.columns and all(c["column"] != name for c in cands):
                cands.append(
                    {"column": name, "kind": "declared", "distinct": int(frame[name].nunique())}
                )
        rows.append(
            {
                "uci_id": row["uci_id"],
                "name": row["name"],
                "labelled": "labelled" in row["roles"],
                "rows": int(len(frame)),
                "candidates": cands,
            }
        )
    return rows


def x_scan__mutmut_7(curated: Path, pool: Path, data: Path) -> list[dict[str, Any]]:
    meta = {m["uci_id"]: m for m in json.loads(curated.read_text())["kept"]}
    rows = None
    for row in json.loads(pool.read_text())["rows"]:
        path = data / f"{row['uci_id']}.csv"
        try:
            frame = ul.read_table(path)
        except Exception as error:  # recorded
            rows.append({"uci_id": row["uci_id"], "error": repr(error)})
            continue
        # variables declared with a time role in the repository metadata count too
        declared = [
            v["name"] for v in meta[row["uci_id"]].get("variables") or [] if v.get("type") == "Date"
        ]
        cands = candidate_columns(frame)
        for name in declared:
            if name in frame.columns and all(c["column"] != name for c in cands):
                cands.append(
                    {"column": name, "kind": "declared", "distinct": int(frame[name].nunique())}
                )
        rows.append(
            {
                "uci_id": row["uci_id"],
                "name": row["name"],
                "labelled": "labelled" in row["roles"],
                "rows": int(len(frame)),
                "candidates": cands,
            }
        )
    return rows


def x_scan__mutmut_8(curated: Path, pool: Path, data: Path) -> list[dict[str, Any]]:
    meta = {m["uci_id"]: m for m in json.loads(curated.read_text())["kept"]}
    rows = []
    for row in json.loads(None)["rows"]:
        path = data / f"{row['uci_id']}.csv"
        try:
            frame = ul.read_table(path)
        except Exception as error:  # recorded
            rows.append({"uci_id": row["uci_id"], "error": repr(error)})
            continue
        # variables declared with a time role in the repository metadata count too
        declared = [
            v["name"] for v in meta[row["uci_id"]].get("variables") or [] if v.get("type") == "Date"
        ]
        cands = candidate_columns(frame)
        for name in declared:
            if name in frame.columns and all(c["column"] != name for c in cands):
                cands.append(
                    {"column": name, "kind": "declared", "distinct": int(frame[name].nunique())}
                )
        rows.append(
            {
                "uci_id": row["uci_id"],
                "name": row["name"],
                "labelled": "labelled" in row["roles"],
                "rows": int(len(frame)),
                "candidates": cands,
            }
        )
    return rows


def x_scan__mutmut_9(curated: Path, pool: Path, data: Path) -> list[dict[str, Any]]:
    meta = {m["uci_id"]: m for m in json.loads(curated.read_text())["kept"]}
    rows = []
    for row in json.loads(pool.read_text())["XXrowsXX"]:
        path = data / f"{row['uci_id']}.csv"
        try:
            frame = ul.read_table(path)
        except Exception as error:  # recorded
            rows.append({"uci_id": row["uci_id"], "error": repr(error)})
            continue
        # variables declared with a time role in the repository metadata count too
        declared = [
            v["name"] for v in meta[row["uci_id"]].get("variables") or [] if v.get("type") == "Date"
        ]
        cands = candidate_columns(frame)
        for name in declared:
            if name in frame.columns and all(c["column"] != name for c in cands):
                cands.append(
                    {"column": name, "kind": "declared", "distinct": int(frame[name].nunique())}
                )
        rows.append(
            {
                "uci_id": row["uci_id"],
                "name": row["name"],
                "labelled": "labelled" in row["roles"],
                "rows": int(len(frame)),
                "candidates": cands,
            }
        )
    return rows


def x_scan__mutmut_10(curated: Path, pool: Path, data: Path) -> list[dict[str, Any]]:
    meta = {m["uci_id"]: m for m in json.loads(curated.read_text())["kept"]}
    rows = []
    for row in json.loads(pool.read_text())["ROWS"]:
        path = data / f"{row['uci_id']}.csv"
        try:
            frame = ul.read_table(path)
        except Exception as error:  # recorded
            rows.append({"uci_id": row["uci_id"], "error": repr(error)})
            continue
        # variables declared with a time role in the repository metadata count too
        declared = [
            v["name"] for v in meta[row["uci_id"]].get("variables") or [] if v.get("type") == "Date"
        ]
        cands = candidate_columns(frame)
        for name in declared:
            if name in frame.columns and all(c["column"] != name for c in cands):
                cands.append(
                    {"column": name, "kind": "declared", "distinct": int(frame[name].nunique())}
                )
        rows.append(
            {
                "uci_id": row["uci_id"],
                "name": row["name"],
                "labelled": "labelled" in row["roles"],
                "rows": int(len(frame)),
                "candidates": cands,
            }
        )
    return rows


def x_scan__mutmut_11(curated: Path, pool: Path, data: Path) -> list[dict[str, Any]]:
    meta = {m["uci_id"]: m for m in json.loads(curated.read_text())["kept"]}
    rows = []
    for row in json.loads(pool.read_text())["rows"]:
        path = None
        try:
            frame = ul.read_table(path)
        except Exception as error:  # recorded
            rows.append({"uci_id": row["uci_id"], "error": repr(error)})
            continue
        # variables declared with a time role in the repository metadata count too
        declared = [
            v["name"] for v in meta[row["uci_id"]].get("variables") or [] if v.get("type") == "Date"
        ]
        cands = candidate_columns(frame)
        for name in declared:
            if name in frame.columns and all(c["column"] != name for c in cands):
                cands.append(
                    {"column": name, "kind": "declared", "distinct": int(frame[name].nunique())}
                )
        rows.append(
            {
                "uci_id": row["uci_id"],
                "name": row["name"],
                "labelled": "labelled" in row["roles"],
                "rows": int(len(frame)),
                "candidates": cands,
            }
        )
    return rows


def x_scan__mutmut_12(curated: Path, pool: Path, data: Path) -> list[dict[str, Any]]:
    meta = {m["uci_id"]: m for m in json.loads(curated.read_text())["kept"]}
    rows = []
    for row in json.loads(pool.read_text())["rows"]:
        path = data * f"{row['uci_id']}.csv"
        try:
            frame = ul.read_table(path)
        except Exception as error:  # recorded
            rows.append({"uci_id": row["uci_id"], "error": repr(error)})
            continue
        # variables declared with a time role in the repository metadata count too
        declared = [
            v["name"] for v in meta[row["uci_id"]].get("variables") or [] if v.get("type") == "Date"
        ]
        cands = candidate_columns(frame)
        for name in declared:
            if name in frame.columns and all(c["column"] != name for c in cands):
                cands.append(
                    {"column": name, "kind": "declared", "distinct": int(frame[name].nunique())}
                )
        rows.append(
            {
                "uci_id": row["uci_id"],
                "name": row["name"],
                "labelled": "labelled" in row["roles"],
                "rows": int(len(frame)),
                "candidates": cands,
            }
        )
    return rows


def x_scan__mutmut_13(curated: Path, pool: Path, data: Path) -> list[dict[str, Any]]:
    meta = {m["uci_id"]: m for m in json.loads(curated.read_text())["kept"]}
    rows = []
    for row in json.loads(pool.read_text())["rows"]:
        path = data / f"{row['XXuci_idXX']}.csv"
        try:
            frame = ul.read_table(path)
        except Exception as error:  # recorded
            rows.append({"uci_id": row["uci_id"], "error": repr(error)})
            continue
        # variables declared with a time role in the repository metadata count too
        declared = [
            v["name"] for v in meta[row["uci_id"]].get("variables") or [] if v.get("type") == "Date"
        ]
        cands = candidate_columns(frame)
        for name in declared:
            if name in frame.columns and all(c["column"] != name for c in cands):
                cands.append(
                    {"column": name, "kind": "declared", "distinct": int(frame[name].nunique())}
                )
        rows.append(
            {
                "uci_id": row["uci_id"],
                "name": row["name"],
                "labelled": "labelled" in row["roles"],
                "rows": int(len(frame)),
                "candidates": cands,
            }
        )
    return rows


def x_scan__mutmut_14(curated: Path, pool: Path, data: Path) -> list[dict[str, Any]]:
    meta = {m["uci_id"]: m for m in json.loads(curated.read_text())["kept"]}
    rows = []
    for row in json.loads(pool.read_text())["rows"]:
        path = data / f"{row['UCI_ID']}.csv"
        try:
            frame = ul.read_table(path)
        except Exception as error:  # recorded
            rows.append({"uci_id": row["uci_id"], "error": repr(error)})
            continue
        # variables declared with a time role in the repository metadata count too
        declared = [
            v["name"] for v in meta[row["uci_id"]].get("variables") or [] if v.get("type") == "Date"
        ]
        cands = candidate_columns(frame)
        for name in declared:
            if name in frame.columns and all(c["column"] != name for c in cands):
                cands.append(
                    {"column": name, "kind": "declared", "distinct": int(frame[name].nunique())}
                )
        rows.append(
            {
                "uci_id": row["uci_id"],
                "name": row["name"],
                "labelled": "labelled" in row["roles"],
                "rows": int(len(frame)),
                "candidates": cands,
            }
        )
    return rows


def x_scan__mutmut_15(curated: Path, pool: Path, data: Path) -> list[dict[str, Any]]:
    meta = {m["uci_id"]: m for m in json.loads(curated.read_text())["kept"]}
    rows = []
    for row in json.loads(pool.read_text())["rows"]:
        path = data / f"{row['uci_id']}.csv"
        try:
            frame = None
        except Exception as error:  # recorded
            rows.append({"uci_id": row["uci_id"], "error": repr(error)})
            continue
        # variables declared with a time role in the repository metadata count too
        declared = [
            v["name"] for v in meta[row["uci_id"]].get("variables") or [] if v.get("type") == "Date"
        ]
        cands = candidate_columns(frame)
        for name in declared:
            if name in frame.columns and all(c["column"] != name for c in cands):
                cands.append(
                    {"column": name, "kind": "declared", "distinct": int(frame[name].nunique())}
                )
        rows.append(
            {
                "uci_id": row["uci_id"],
                "name": row["name"],
                "labelled": "labelled" in row["roles"],
                "rows": int(len(frame)),
                "candidates": cands,
            }
        )
    return rows


def x_scan__mutmut_16(curated: Path, pool: Path, data: Path) -> list[dict[str, Any]]:
    meta = {m["uci_id"]: m for m in json.loads(curated.read_text())["kept"]}
    rows = []
    for row in json.loads(pool.read_text())["rows"]:
        path = data / f"{row['uci_id']}.csv"
        try:
            frame = ul.read_table(None)
        except Exception as error:  # recorded
            rows.append({"uci_id": row["uci_id"], "error": repr(error)})
            continue
        # variables declared with a time role in the repository metadata count too
        declared = [
            v["name"] for v in meta[row["uci_id"]].get("variables") or [] if v.get("type") == "Date"
        ]
        cands = candidate_columns(frame)
        for name in declared:
            if name in frame.columns and all(c["column"] != name for c in cands):
                cands.append(
                    {"column": name, "kind": "declared", "distinct": int(frame[name].nunique())}
                )
        rows.append(
            {
                "uci_id": row["uci_id"],
                "name": row["name"],
                "labelled": "labelled" in row["roles"],
                "rows": int(len(frame)),
                "candidates": cands,
            }
        )
    return rows


def x_scan__mutmut_17(curated: Path, pool: Path, data: Path) -> list[dict[str, Any]]:
    meta = {m["uci_id"]: m for m in json.loads(curated.read_text())["kept"]}
    rows = []
    for row in json.loads(pool.read_text())["rows"]:
        path = data / f"{row['uci_id']}.csv"
        try:
            frame = ul.read_table(path)
        except Exception as error:  # recorded
            rows.append(None)
            continue
        # variables declared with a time role in the repository metadata count too
        declared = [
            v["name"] for v in meta[row["uci_id"]].get("variables") or [] if v.get("type") == "Date"
        ]
        cands = candidate_columns(frame)
        for name in declared:
            if name in frame.columns and all(c["column"] != name for c in cands):
                cands.append(
                    {"column": name, "kind": "declared", "distinct": int(frame[name].nunique())}
                )
        rows.append(
            {
                "uci_id": row["uci_id"],
                "name": row["name"],
                "labelled": "labelled" in row["roles"],
                "rows": int(len(frame)),
                "candidates": cands,
            }
        )
    return rows


def x_scan__mutmut_18(curated: Path, pool: Path, data: Path) -> list[dict[str, Any]]:
    meta = {m["uci_id"]: m for m in json.loads(curated.read_text())["kept"]}
    rows = []
    for row in json.loads(pool.read_text())["rows"]:
        path = data / f"{row['uci_id']}.csv"
        try:
            frame = ul.read_table(path)
        except Exception as error:  # recorded
            rows.append({"XXuci_idXX": row["uci_id"], "error": repr(error)})
            continue
        # variables declared with a time role in the repository metadata count too
        declared = [
            v["name"] for v in meta[row["uci_id"]].get("variables") or [] if v.get("type") == "Date"
        ]
        cands = candidate_columns(frame)
        for name in declared:
            if name in frame.columns and all(c["column"] != name for c in cands):
                cands.append(
                    {"column": name, "kind": "declared", "distinct": int(frame[name].nunique())}
                )
        rows.append(
            {
                "uci_id": row["uci_id"],
                "name": row["name"],
                "labelled": "labelled" in row["roles"],
                "rows": int(len(frame)),
                "candidates": cands,
            }
        )
    return rows


def x_scan__mutmut_19(curated: Path, pool: Path, data: Path) -> list[dict[str, Any]]:
    meta = {m["uci_id"]: m for m in json.loads(curated.read_text())["kept"]}
    rows = []
    for row in json.loads(pool.read_text())["rows"]:
        path = data / f"{row['uci_id']}.csv"
        try:
            frame = ul.read_table(path)
        except Exception as error:  # recorded
            rows.append({"UCI_ID": row["uci_id"], "error": repr(error)})
            continue
        # variables declared with a time role in the repository metadata count too
        declared = [
            v["name"] for v in meta[row["uci_id"]].get("variables") or [] if v.get("type") == "Date"
        ]
        cands = candidate_columns(frame)
        for name in declared:
            if name in frame.columns and all(c["column"] != name for c in cands):
                cands.append(
                    {"column": name, "kind": "declared", "distinct": int(frame[name].nunique())}
                )
        rows.append(
            {
                "uci_id": row["uci_id"],
                "name": row["name"],
                "labelled": "labelled" in row["roles"],
                "rows": int(len(frame)),
                "candidates": cands,
            }
        )
    return rows


def x_scan__mutmut_20(curated: Path, pool: Path, data: Path) -> list[dict[str, Any]]:
    meta = {m["uci_id"]: m for m in json.loads(curated.read_text())["kept"]}
    rows = []
    for row in json.loads(pool.read_text())["rows"]:
        path = data / f"{row['uci_id']}.csv"
        try:
            frame = ul.read_table(path)
        except Exception as error:  # recorded
            rows.append({"uci_id": row["XXuci_idXX"], "error": repr(error)})
            continue
        # variables declared with a time role in the repository metadata count too
        declared = [
            v["name"] for v in meta[row["uci_id"]].get("variables") or [] if v.get("type") == "Date"
        ]
        cands = candidate_columns(frame)
        for name in declared:
            if name in frame.columns and all(c["column"] != name for c in cands):
                cands.append(
                    {"column": name, "kind": "declared", "distinct": int(frame[name].nunique())}
                )
        rows.append(
            {
                "uci_id": row["uci_id"],
                "name": row["name"],
                "labelled": "labelled" in row["roles"],
                "rows": int(len(frame)),
                "candidates": cands,
            }
        )
    return rows


def x_scan__mutmut_21(curated: Path, pool: Path, data: Path) -> list[dict[str, Any]]:
    meta = {m["uci_id"]: m for m in json.loads(curated.read_text())["kept"]}
    rows = []
    for row in json.loads(pool.read_text())["rows"]:
        path = data / f"{row['uci_id']}.csv"
        try:
            frame = ul.read_table(path)
        except Exception as error:  # recorded
            rows.append({"uci_id": row["UCI_ID"], "error": repr(error)})
            continue
        # variables declared with a time role in the repository metadata count too
        declared = [
            v["name"] for v in meta[row["uci_id"]].get("variables") or [] if v.get("type") == "Date"
        ]
        cands = candidate_columns(frame)
        for name in declared:
            if name in frame.columns and all(c["column"] != name for c in cands):
                cands.append(
                    {"column": name, "kind": "declared", "distinct": int(frame[name].nunique())}
                )
        rows.append(
            {
                "uci_id": row["uci_id"],
                "name": row["name"],
                "labelled": "labelled" in row["roles"],
                "rows": int(len(frame)),
                "candidates": cands,
            }
        )
    return rows


def x_scan__mutmut_22(curated: Path, pool: Path, data: Path) -> list[dict[str, Any]]:
    meta = {m["uci_id"]: m for m in json.loads(curated.read_text())["kept"]}
    rows = []
    for row in json.loads(pool.read_text())["rows"]:
        path = data / f"{row['uci_id']}.csv"
        try:
            frame = ul.read_table(path)
        except Exception as error:  # recorded
            rows.append({"uci_id": row["uci_id"], "XXerrorXX": repr(error)})
            continue
        # variables declared with a time role in the repository metadata count too
        declared = [
            v["name"] for v in meta[row["uci_id"]].get("variables") or [] if v.get("type") == "Date"
        ]
        cands = candidate_columns(frame)
        for name in declared:
            if name in frame.columns and all(c["column"] != name for c in cands):
                cands.append(
                    {"column": name, "kind": "declared", "distinct": int(frame[name].nunique())}
                )
        rows.append(
            {
                "uci_id": row["uci_id"],
                "name": row["name"],
                "labelled": "labelled" in row["roles"],
                "rows": int(len(frame)),
                "candidates": cands,
            }
        )
    return rows


def x_scan__mutmut_23(curated: Path, pool: Path, data: Path) -> list[dict[str, Any]]:
    meta = {m["uci_id"]: m for m in json.loads(curated.read_text())["kept"]}
    rows = []
    for row in json.loads(pool.read_text())["rows"]:
        path = data / f"{row['uci_id']}.csv"
        try:
            frame = ul.read_table(path)
        except Exception as error:  # recorded
            rows.append({"uci_id": row["uci_id"], "ERROR": repr(error)})
            continue
        # variables declared with a time role in the repository metadata count too
        declared = [
            v["name"] for v in meta[row["uci_id"]].get("variables") or [] if v.get("type") == "Date"
        ]
        cands = candidate_columns(frame)
        for name in declared:
            if name in frame.columns and all(c["column"] != name for c in cands):
                cands.append(
                    {"column": name, "kind": "declared", "distinct": int(frame[name].nunique())}
                )
        rows.append(
            {
                "uci_id": row["uci_id"],
                "name": row["name"],
                "labelled": "labelled" in row["roles"],
                "rows": int(len(frame)),
                "candidates": cands,
            }
        )
    return rows


def x_scan__mutmut_24(curated: Path, pool: Path, data: Path) -> list[dict[str, Any]]:
    meta = {m["uci_id"]: m for m in json.loads(curated.read_text())["kept"]}
    rows = []
    for row in json.loads(pool.read_text())["rows"]:
        path = data / f"{row['uci_id']}.csv"
        try:
            frame = ul.read_table(path)
        except Exception as error:  # recorded
            rows.append({"uci_id": row["uci_id"], "error": repr(None)})
            continue
        # variables declared with a time role in the repository metadata count too
        declared = [
            v["name"] for v in meta[row["uci_id"]].get("variables") or [] if v.get("type") == "Date"
        ]
        cands = candidate_columns(frame)
        for name in declared:
            if name in frame.columns and all(c["column"] != name for c in cands):
                cands.append(
                    {"column": name, "kind": "declared", "distinct": int(frame[name].nunique())}
                )
        rows.append(
            {
                "uci_id": row["uci_id"],
                "name": row["name"],
                "labelled": "labelled" in row["roles"],
                "rows": int(len(frame)),
                "candidates": cands,
            }
        )
    return rows


def x_scan__mutmut_25(curated: Path, pool: Path, data: Path) -> list[dict[str, Any]]:
    meta = {m["uci_id"]: m for m in json.loads(curated.read_text())["kept"]}
    rows = []
    for row in json.loads(pool.read_text())["rows"]:
        path = data / f"{row['uci_id']}.csv"
        try:
            frame = ul.read_table(path)
        except Exception as error:  # recorded
            rows.append({"uci_id": row["uci_id"], "error": repr(error)})
            break
        # variables declared with a time role in the repository metadata count too
        declared = [
            v["name"] for v in meta[row["uci_id"]].get("variables") or [] if v.get("type") == "Date"
        ]
        cands = candidate_columns(frame)
        for name in declared:
            if name in frame.columns and all(c["column"] != name for c in cands):
                cands.append(
                    {"column": name, "kind": "declared", "distinct": int(frame[name].nunique())}
                )
        rows.append(
            {
                "uci_id": row["uci_id"],
                "name": row["name"],
                "labelled": "labelled" in row["roles"],
                "rows": int(len(frame)),
                "candidates": cands,
            }
        )
    return rows


def x_scan__mutmut_26(curated: Path, pool: Path, data: Path) -> list[dict[str, Any]]:
    meta = {m["uci_id"]: m for m in json.loads(curated.read_text())["kept"]}
    rows = []
    for row in json.loads(pool.read_text())["rows"]:
        path = data / f"{row['uci_id']}.csv"
        try:
            frame = ul.read_table(path)
        except Exception as error:  # recorded
            rows.append({"uci_id": row["uci_id"], "error": repr(error)})
            continue
        # variables declared with a time role in the repository metadata count too
        declared = None
        cands = candidate_columns(frame)
        for name in declared:
            if name in frame.columns and all(c["column"] != name for c in cands):
                cands.append(
                    {"column": name, "kind": "declared", "distinct": int(frame[name].nunique())}
                )
        rows.append(
            {
                "uci_id": row["uci_id"],
                "name": row["name"],
                "labelled": "labelled" in row["roles"],
                "rows": int(len(frame)),
                "candidates": cands,
            }
        )
    return rows


def x_scan__mutmut_27(curated: Path, pool: Path, data: Path) -> list[dict[str, Any]]:
    meta = {m["uci_id"]: m for m in json.loads(curated.read_text())["kept"]}
    rows = []
    for row in json.loads(pool.read_text())["rows"]:
        path = data / f"{row['uci_id']}.csv"
        try:
            frame = ul.read_table(path)
        except Exception as error:  # recorded
            rows.append({"uci_id": row["uci_id"], "error": repr(error)})
            continue
        # variables declared with a time role in the repository metadata count too
        declared = [
            v["XXnameXX"] for v in meta[row["uci_id"]].get("variables") or [] if v.get("type") == "Date"
        ]
        cands = candidate_columns(frame)
        for name in declared:
            if name in frame.columns and all(c["column"] != name for c in cands):
                cands.append(
                    {"column": name, "kind": "declared", "distinct": int(frame[name].nunique())}
                )
        rows.append(
            {
                "uci_id": row["uci_id"],
                "name": row["name"],
                "labelled": "labelled" in row["roles"],
                "rows": int(len(frame)),
                "candidates": cands,
            }
        )
    return rows


def x_scan__mutmut_28(curated: Path, pool: Path, data: Path) -> list[dict[str, Any]]:
    meta = {m["uci_id"]: m for m in json.loads(curated.read_text())["kept"]}
    rows = []
    for row in json.loads(pool.read_text())["rows"]:
        path = data / f"{row['uci_id']}.csv"
        try:
            frame = ul.read_table(path)
        except Exception as error:  # recorded
            rows.append({"uci_id": row["uci_id"], "error": repr(error)})
            continue
        # variables declared with a time role in the repository metadata count too
        declared = [
            v["NAME"] for v in meta[row["uci_id"]].get("variables") or [] if v.get("type") == "Date"
        ]
        cands = candidate_columns(frame)
        for name in declared:
            if name in frame.columns and all(c["column"] != name for c in cands):
                cands.append(
                    {"column": name, "kind": "declared", "distinct": int(frame[name].nunique())}
                )
        rows.append(
            {
                "uci_id": row["uci_id"],
                "name": row["name"],
                "labelled": "labelled" in row["roles"],
                "rows": int(len(frame)),
                "candidates": cands,
            }
        )
    return rows


def x_scan__mutmut_29(curated: Path, pool: Path, data: Path) -> list[dict[str, Any]]:
    meta = {m["uci_id"]: m for m in json.loads(curated.read_text())["kept"]}
    rows = []
    for row in json.loads(pool.read_text())["rows"]:
        path = data / f"{row['uci_id']}.csv"
        try:
            frame = ul.read_table(path)
        except Exception as error:  # recorded
            rows.append({"uci_id": row["uci_id"], "error": repr(error)})
            continue
        # variables declared with a time role in the repository metadata count too
        declared = [
            v["name"] for v in meta[row["uci_id"]].get("variables") and [] if v.get("type") == "Date"
        ]
        cands = candidate_columns(frame)
        for name in declared:
            if name in frame.columns and all(c["column"] != name for c in cands):
                cands.append(
                    {"column": name, "kind": "declared", "distinct": int(frame[name].nunique())}
                )
        rows.append(
            {
                "uci_id": row["uci_id"],
                "name": row["name"],
                "labelled": "labelled" in row["roles"],
                "rows": int(len(frame)),
                "candidates": cands,
            }
        )
    return rows


def x_scan__mutmut_30(curated: Path, pool: Path, data: Path) -> list[dict[str, Any]]:
    meta = {m["uci_id"]: m for m in json.loads(curated.read_text())["kept"]}
    rows = []
    for row in json.loads(pool.read_text())["rows"]:
        path = data / f"{row['uci_id']}.csv"
        try:
            frame = ul.read_table(path)
        except Exception as error:  # recorded
            rows.append({"uci_id": row["uci_id"], "error": repr(error)})
            continue
        # variables declared with a time role in the repository metadata count too
        declared = [
            v["name"] for v in meta[row["uci_id"]].get(None) or [] if v.get("type") == "Date"
        ]
        cands = candidate_columns(frame)
        for name in declared:
            if name in frame.columns and all(c["column"] != name for c in cands):
                cands.append(
                    {"column": name, "kind": "declared", "distinct": int(frame[name].nunique())}
                )
        rows.append(
            {
                "uci_id": row["uci_id"],
                "name": row["name"],
                "labelled": "labelled" in row["roles"],
                "rows": int(len(frame)),
                "candidates": cands,
            }
        )
    return rows


def x_scan__mutmut_31(curated: Path, pool: Path, data: Path) -> list[dict[str, Any]]:
    meta = {m["uci_id"]: m for m in json.loads(curated.read_text())["kept"]}
    rows = []
    for row in json.loads(pool.read_text())["rows"]:
        path = data / f"{row['uci_id']}.csv"
        try:
            frame = ul.read_table(path)
        except Exception as error:  # recorded
            rows.append({"uci_id": row["uci_id"], "error": repr(error)})
            continue
        # variables declared with a time role in the repository metadata count too
        declared = [
            v["name"] for v in meta[row["XXuci_idXX"]].get("variables") or [] if v.get("type") == "Date"
        ]
        cands = candidate_columns(frame)
        for name in declared:
            if name in frame.columns and all(c["column"] != name for c in cands):
                cands.append(
                    {"column": name, "kind": "declared", "distinct": int(frame[name].nunique())}
                )
        rows.append(
            {
                "uci_id": row["uci_id"],
                "name": row["name"],
                "labelled": "labelled" in row["roles"],
                "rows": int(len(frame)),
                "candidates": cands,
            }
        )
    return rows


def x_scan__mutmut_32(curated: Path, pool: Path, data: Path) -> list[dict[str, Any]]:
    meta = {m["uci_id"]: m for m in json.loads(curated.read_text())["kept"]}
    rows = []
    for row in json.loads(pool.read_text())["rows"]:
        path = data / f"{row['uci_id']}.csv"
        try:
            frame = ul.read_table(path)
        except Exception as error:  # recorded
            rows.append({"uci_id": row["uci_id"], "error": repr(error)})
            continue
        # variables declared with a time role in the repository metadata count too
        declared = [
            v["name"] for v in meta[row["UCI_ID"]].get("variables") or [] if v.get("type") == "Date"
        ]
        cands = candidate_columns(frame)
        for name in declared:
            if name in frame.columns and all(c["column"] != name for c in cands):
                cands.append(
                    {"column": name, "kind": "declared", "distinct": int(frame[name].nunique())}
                )
        rows.append(
            {
                "uci_id": row["uci_id"],
                "name": row["name"],
                "labelled": "labelled" in row["roles"],
                "rows": int(len(frame)),
                "candidates": cands,
            }
        )
    return rows


def x_scan__mutmut_33(curated: Path, pool: Path, data: Path) -> list[dict[str, Any]]:
    meta = {m["uci_id"]: m for m in json.loads(curated.read_text())["kept"]}
    rows = []
    for row in json.loads(pool.read_text())["rows"]:
        path = data / f"{row['uci_id']}.csv"
        try:
            frame = ul.read_table(path)
        except Exception as error:  # recorded
            rows.append({"uci_id": row["uci_id"], "error": repr(error)})
            continue
        # variables declared with a time role in the repository metadata count too
        declared = [
            v["name"] for v in meta[row["uci_id"]].get("XXvariablesXX") or [] if v.get("type") == "Date"
        ]
        cands = candidate_columns(frame)
        for name in declared:
            if name in frame.columns and all(c["column"] != name for c in cands):
                cands.append(
                    {"column": name, "kind": "declared", "distinct": int(frame[name].nunique())}
                )
        rows.append(
            {
                "uci_id": row["uci_id"],
                "name": row["name"],
                "labelled": "labelled" in row["roles"],
                "rows": int(len(frame)),
                "candidates": cands,
            }
        )
    return rows


def x_scan__mutmut_34(curated: Path, pool: Path, data: Path) -> list[dict[str, Any]]:
    meta = {m["uci_id"]: m for m in json.loads(curated.read_text())["kept"]}
    rows = []
    for row in json.loads(pool.read_text())["rows"]:
        path = data / f"{row['uci_id']}.csv"
        try:
            frame = ul.read_table(path)
        except Exception as error:  # recorded
            rows.append({"uci_id": row["uci_id"], "error": repr(error)})
            continue
        # variables declared with a time role in the repository metadata count too
        declared = [
            v["name"] for v in meta[row["uci_id"]].get("VARIABLES") or [] if v.get("type") == "Date"
        ]
        cands = candidate_columns(frame)
        for name in declared:
            if name in frame.columns and all(c["column"] != name for c in cands):
                cands.append(
                    {"column": name, "kind": "declared", "distinct": int(frame[name].nunique())}
                )
        rows.append(
            {
                "uci_id": row["uci_id"],
                "name": row["name"],
                "labelled": "labelled" in row["roles"],
                "rows": int(len(frame)),
                "candidates": cands,
            }
        )
    return rows


def x_scan__mutmut_35(curated: Path, pool: Path, data: Path) -> list[dict[str, Any]]:
    meta = {m["uci_id"]: m for m in json.loads(curated.read_text())["kept"]}
    rows = []
    for row in json.loads(pool.read_text())["rows"]:
        path = data / f"{row['uci_id']}.csv"
        try:
            frame = ul.read_table(path)
        except Exception as error:  # recorded
            rows.append({"uci_id": row["uci_id"], "error": repr(error)})
            continue
        # variables declared with a time role in the repository metadata count too
        declared = [
            v["name"] for v in meta[row["uci_id"]].get("variables") or [] if v.get(None) == "Date"
        ]
        cands = candidate_columns(frame)
        for name in declared:
            if name in frame.columns and all(c["column"] != name for c in cands):
                cands.append(
                    {"column": name, "kind": "declared", "distinct": int(frame[name].nunique())}
                )
        rows.append(
            {
                "uci_id": row["uci_id"],
                "name": row["name"],
                "labelled": "labelled" in row["roles"],
                "rows": int(len(frame)),
                "candidates": cands,
            }
        )
    return rows


def x_scan__mutmut_36(curated: Path, pool: Path, data: Path) -> list[dict[str, Any]]:
    meta = {m["uci_id"]: m for m in json.loads(curated.read_text())["kept"]}
    rows = []
    for row in json.loads(pool.read_text())["rows"]:
        path = data / f"{row['uci_id']}.csv"
        try:
            frame = ul.read_table(path)
        except Exception as error:  # recorded
            rows.append({"uci_id": row["uci_id"], "error": repr(error)})
            continue
        # variables declared with a time role in the repository metadata count too
        declared = [
            v["name"] for v in meta[row["uci_id"]].get("variables") or [] if v.get("XXtypeXX") == "Date"
        ]
        cands = candidate_columns(frame)
        for name in declared:
            if name in frame.columns and all(c["column"] != name for c in cands):
                cands.append(
                    {"column": name, "kind": "declared", "distinct": int(frame[name].nunique())}
                )
        rows.append(
            {
                "uci_id": row["uci_id"],
                "name": row["name"],
                "labelled": "labelled" in row["roles"],
                "rows": int(len(frame)),
                "candidates": cands,
            }
        )
    return rows


def x_scan__mutmut_37(curated: Path, pool: Path, data: Path) -> list[dict[str, Any]]:
    meta = {m["uci_id"]: m for m in json.loads(curated.read_text())["kept"]}
    rows = []
    for row in json.loads(pool.read_text())["rows"]:
        path = data / f"{row['uci_id']}.csv"
        try:
            frame = ul.read_table(path)
        except Exception as error:  # recorded
            rows.append({"uci_id": row["uci_id"], "error": repr(error)})
            continue
        # variables declared with a time role in the repository metadata count too
        declared = [
            v["name"] for v in meta[row["uci_id"]].get("variables") or [] if v.get("TYPE") == "Date"
        ]
        cands = candidate_columns(frame)
        for name in declared:
            if name in frame.columns and all(c["column"] != name for c in cands):
                cands.append(
                    {"column": name, "kind": "declared", "distinct": int(frame[name].nunique())}
                )
        rows.append(
            {
                "uci_id": row["uci_id"],
                "name": row["name"],
                "labelled": "labelled" in row["roles"],
                "rows": int(len(frame)),
                "candidates": cands,
            }
        )
    return rows


def x_scan__mutmut_38(curated: Path, pool: Path, data: Path) -> list[dict[str, Any]]:
    meta = {m["uci_id"]: m for m in json.loads(curated.read_text())["kept"]}
    rows = []
    for row in json.loads(pool.read_text())["rows"]:
        path = data / f"{row['uci_id']}.csv"
        try:
            frame = ul.read_table(path)
        except Exception as error:  # recorded
            rows.append({"uci_id": row["uci_id"], "error": repr(error)})
            continue
        # variables declared with a time role in the repository metadata count too
        declared = [
            v["name"] for v in meta[row["uci_id"]].get("variables") or [] if v.get("type") != "Date"
        ]
        cands = candidate_columns(frame)
        for name in declared:
            if name in frame.columns and all(c["column"] != name for c in cands):
                cands.append(
                    {"column": name, "kind": "declared", "distinct": int(frame[name].nunique())}
                )
        rows.append(
            {
                "uci_id": row["uci_id"],
                "name": row["name"],
                "labelled": "labelled" in row["roles"],
                "rows": int(len(frame)),
                "candidates": cands,
            }
        )
    return rows


def x_scan__mutmut_39(curated: Path, pool: Path, data: Path) -> list[dict[str, Any]]:
    meta = {m["uci_id"]: m for m in json.loads(curated.read_text())["kept"]}
    rows = []
    for row in json.loads(pool.read_text())["rows"]:
        path = data / f"{row['uci_id']}.csv"
        try:
            frame = ul.read_table(path)
        except Exception as error:  # recorded
            rows.append({"uci_id": row["uci_id"], "error": repr(error)})
            continue
        # variables declared with a time role in the repository metadata count too
        declared = [
            v["name"] for v in meta[row["uci_id"]].get("variables") or [] if v.get("type") == "XXDateXX"
        ]
        cands = candidate_columns(frame)
        for name in declared:
            if name in frame.columns and all(c["column"] != name for c in cands):
                cands.append(
                    {"column": name, "kind": "declared", "distinct": int(frame[name].nunique())}
                )
        rows.append(
            {
                "uci_id": row["uci_id"],
                "name": row["name"],
                "labelled": "labelled" in row["roles"],
                "rows": int(len(frame)),
                "candidates": cands,
            }
        )
    return rows


def x_scan__mutmut_40(curated: Path, pool: Path, data: Path) -> list[dict[str, Any]]:
    meta = {m["uci_id"]: m for m in json.loads(curated.read_text())["kept"]}
    rows = []
    for row in json.loads(pool.read_text())["rows"]:
        path = data / f"{row['uci_id']}.csv"
        try:
            frame = ul.read_table(path)
        except Exception as error:  # recorded
            rows.append({"uci_id": row["uci_id"], "error": repr(error)})
            continue
        # variables declared with a time role in the repository metadata count too
        declared = [
            v["name"] for v in meta[row["uci_id"]].get("variables") or [] if v.get("type") == "date"
        ]
        cands = candidate_columns(frame)
        for name in declared:
            if name in frame.columns and all(c["column"] != name for c in cands):
                cands.append(
                    {"column": name, "kind": "declared", "distinct": int(frame[name].nunique())}
                )
        rows.append(
            {
                "uci_id": row["uci_id"],
                "name": row["name"],
                "labelled": "labelled" in row["roles"],
                "rows": int(len(frame)),
                "candidates": cands,
            }
        )
    return rows


def x_scan__mutmut_41(curated: Path, pool: Path, data: Path) -> list[dict[str, Any]]:
    meta = {m["uci_id"]: m for m in json.loads(curated.read_text())["kept"]}
    rows = []
    for row in json.loads(pool.read_text())["rows"]:
        path = data / f"{row['uci_id']}.csv"
        try:
            frame = ul.read_table(path)
        except Exception as error:  # recorded
            rows.append({"uci_id": row["uci_id"], "error": repr(error)})
            continue
        # variables declared with a time role in the repository metadata count too
        declared = [
            v["name"] for v in meta[row["uci_id"]].get("variables") or [] if v.get("type") == "DATE"
        ]
        cands = candidate_columns(frame)
        for name in declared:
            if name in frame.columns and all(c["column"] != name for c in cands):
                cands.append(
                    {"column": name, "kind": "declared", "distinct": int(frame[name].nunique())}
                )
        rows.append(
            {
                "uci_id": row["uci_id"],
                "name": row["name"],
                "labelled": "labelled" in row["roles"],
                "rows": int(len(frame)),
                "candidates": cands,
            }
        )
    return rows


def x_scan__mutmut_42(curated: Path, pool: Path, data: Path) -> list[dict[str, Any]]:
    meta = {m["uci_id"]: m for m in json.loads(curated.read_text())["kept"]}
    rows = []
    for row in json.loads(pool.read_text())["rows"]:
        path = data / f"{row['uci_id']}.csv"
        try:
            frame = ul.read_table(path)
        except Exception as error:  # recorded
            rows.append({"uci_id": row["uci_id"], "error": repr(error)})
            continue
        # variables declared with a time role in the repository metadata count too
        declared = [
            v["name"] for v in meta[row["uci_id"]].get("variables") or [] if v.get("type") == "Date"
        ]
        cands = None
        for name in declared:
            if name in frame.columns and all(c["column"] != name for c in cands):
                cands.append(
                    {"column": name, "kind": "declared", "distinct": int(frame[name].nunique())}
                )
        rows.append(
            {
                "uci_id": row["uci_id"],
                "name": row["name"],
                "labelled": "labelled" in row["roles"],
                "rows": int(len(frame)),
                "candidates": cands,
            }
        )
    return rows


def x_scan__mutmut_43(curated: Path, pool: Path, data: Path) -> list[dict[str, Any]]:
    meta = {m["uci_id"]: m for m in json.loads(curated.read_text())["kept"]}
    rows = []
    for row in json.loads(pool.read_text())["rows"]:
        path = data / f"{row['uci_id']}.csv"
        try:
            frame = ul.read_table(path)
        except Exception as error:  # recorded
            rows.append({"uci_id": row["uci_id"], "error": repr(error)})
            continue
        # variables declared with a time role in the repository metadata count too
        declared = [
            v["name"] for v in meta[row["uci_id"]].get("variables") or [] if v.get("type") == "Date"
        ]
        cands = candidate_columns(None)
        for name in declared:
            if name in frame.columns and all(c["column"] != name for c in cands):
                cands.append(
                    {"column": name, "kind": "declared", "distinct": int(frame[name].nunique())}
                )
        rows.append(
            {
                "uci_id": row["uci_id"],
                "name": row["name"],
                "labelled": "labelled" in row["roles"],
                "rows": int(len(frame)),
                "candidates": cands,
            }
        )
    return rows


def x_scan__mutmut_44(curated: Path, pool: Path, data: Path) -> list[dict[str, Any]]:
    meta = {m["uci_id"]: m for m in json.loads(curated.read_text())["kept"]}
    rows = []
    for row in json.loads(pool.read_text())["rows"]:
        path = data / f"{row['uci_id']}.csv"
        try:
            frame = ul.read_table(path)
        except Exception as error:  # recorded
            rows.append({"uci_id": row["uci_id"], "error": repr(error)})
            continue
        # variables declared with a time role in the repository metadata count too
        declared = [
            v["name"] for v in meta[row["uci_id"]].get("variables") or [] if v.get("type") == "Date"
        ]
        cands = candidate_columns(frame)
        for name in declared:
            if name in frame.columns or all(c["column"] != name for c in cands):
                cands.append(
                    {"column": name, "kind": "declared", "distinct": int(frame[name].nunique())}
                )
        rows.append(
            {
                "uci_id": row["uci_id"],
                "name": row["name"],
                "labelled": "labelled" in row["roles"],
                "rows": int(len(frame)),
                "candidates": cands,
            }
        )
    return rows


def x_scan__mutmut_45(curated: Path, pool: Path, data: Path) -> list[dict[str, Any]]:
    meta = {m["uci_id"]: m for m in json.loads(curated.read_text())["kept"]}
    rows = []
    for row in json.loads(pool.read_text())["rows"]:
        path = data / f"{row['uci_id']}.csv"
        try:
            frame = ul.read_table(path)
        except Exception as error:  # recorded
            rows.append({"uci_id": row["uci_id"], "error": repr(error)})
            continue
        # variables declared with a time role in the repository metadata count too
        declared = [
            v["name"] for v in meta[row["uci_id"]].get("variables") or [] if v.get("type") == "Date"
        ]
        cands = candidate_columns(frame)
        for name in declared:
            if name not in frame.columns and all(c["column"] != name for c in cands):
                cands.append(
                    {"column": name, "kind": "declared", "distinct": int(frame[name].nunique())}
                )
        rows.append(
            {
                "uci_id": row["uci_id"],
                "name": row["name"],
                "labelled": "labelled" in row["roles"],
                "rows": int(len(frame)),
                "candidates": cands,
            }
        )
    return rows


def x_scan__mutmut_46(curated: Path, pool: Path, data: Path) -> list[dict[str, Any]]:
    meta = {m["uci_id"]: m for m in json.loads(curated.read_text())["kept"]}
    rows = []
    for row in json.loads(pool.read_text())["rows"]:
        path = data / f"{row['uci_id']}.csv"
        try:
            frame = ul.read_table(path)
        except Exception as error:  # recorded
            rows.append({"uci_id": row["uci_id"], "error": repr(error)})
            continue
        # variables declared with a time role in the repository metadata count too
        declared = [
            v["name"] for v in meta[row["uci_id"]].get("variables") or [] if v.get("type") == "Date"
        ]
        cands = candidate_columns(frame)
        for name in declared:
            if name in frame.columns and all(None):
                cands.append(
                    {"column": name, "kind": "declared", "distinct": int(frame[name].nunique())}
                )
        rows.append(
            {
                "uci_id": row["uci_id"],
                "name": row["name"],
                "labelled": "labelled" in row["roles"],
                "rows": int(len(frame)),
                "candidates": cands,
            }
        )
    return rows


def x_scan__mutmut_47(curated: Path, pool: Path, data: Path) -> list[dict[str, Any]]:
    meta = {m["uci_id"]: m for m in json.loads(curated.read_text())["kept"]}
    rows = []
    for row in json.loads(pool.read_text())["rows"]:
        path = data / f"{row['uci_id']}.csv"
        try:
            frame = ul.read_table(path)
        except Exception as error:  # recorded
            rows.append({"uci_id": row["uci_id"], "error": repr(error)})
            continue
        # variables declared with a time role in the repository metadata count too
        declared = [
            v["name"] for v in meta[row["uci_id"]].get("variables") or [] if v.get("type") == "Date"
        ]
        cands = candidate_columns(frame)
        for name in declared:
            if name in frame.columns and all(c["XXcolumnXX"] != name for c in cands):
                cands.append(
                    {"column": name, "kind": "declared", "distinct": int(frame[name].nunique())}
                )
        rows.append(
            {
                "uci_id": row["uci_id"],
                "name": row["name"],
                "labelled": "labelled" in row["roles"],
                "rows": int(len(frame)),
                "candidates": cands,
            }
        )
    return rows


def x_scan__mutmut_48(curated: Path, pool: Path, data: Path) -> list[dict[str, Any]]:
    meta = {m["uci_id"]: m for m in json.loads(curated.read_text())["kept"]}
    rows = []
    for row in json.loads(pool.read_text())["rows"]:
        path = data / f"{row['uci_id']}.csv"
        try:
            frame = ul.read_table(path)
        except Exception as error:  # recorded
            rows.append({"uci_id": row["uci_id"], "error": repr(error)})
            continue
        # variables declared with a time role in the repository metadata count too
        declared = [
            v["name"] for v in meta[row["uci_id"]].get("variables") or [] if v.get("type") == "Date"
        ]
        cands = candidate_columns(frame)
        for name in declared:
            if name in frame.columns and all(c["COLUMN"] != name for c in cands):
                cands.append(
                    {"column": name, "kind": "declared", "distinct": int(frame[name].nunique())}
                )
        rows.append(
            {
                "uci_id": row["uci_id"],
                "name": row["name"],
                "labelled": "labelled" in row["roles"],
                "rows": int(len(frame)),
                "candidates": cands,
            }
        )
    return rows


def x_scan__mutmut_49(curated: Path, pool: Path, data: Path) -> list[dict[str, Any]]:
    meta = {m["uci_id"]: m for m in json.loads(curated.read_text())["kept"]}
    rows = []
    for row in json.loads(pool.read_text())["rows"]:
        path = data / f"{row['uci_id']}.csv"
        try:
            frame = ul.read_table(path)
        except Exception as error:  # recorded
            rows.append({"uci_id": row["uci_id"], "error": repr(error)})
            continue
        # variables declared with a time role in the repository metadata count too
        declared = [
            v["name"] for v in meta[row["uci_id"]].get("variables") or [] if v.get("type") == "Date"
        ]
        cands = candidate_columns(frame)
        for name in declared:
            if name in frame.columns and all(c["column"] == name for c in cands):
                cands.append(
                    {"column": name, "kind": "declared", "distinct": int(frame[name].nunique())}
                )
        rows.append(
            {
                "uci_id": row["uci_id"],
                "name": row["name"],
                "labelled": "labelled" in row["roles"],
                "rows": int(len(frame)),
                "candidates": cands,
            }
        )
    return rows


def x_scan__mutmut_50(curated: Path, pool: Path, data: Path) -> list[dict[str, Any]]:
    meta = {m["uci_id"]: m for m in json.loads(curated.read_text())["kept"]}
    rows = []
    for row in json.loads(pool.read_text())["rows"]:
        path = data / f"{row['uci_id']}.csv"
        try:
            frame = ul.read_table(path)
        except Exception as error:  # recorded
            rows.append({"uci_id": row["uci_id"], "error": repr(error)})
            continue
        # variables declared with a time role in the repository metadata count too
        declared = [
            v["name"] for v in meta[row["uci_id"]].get("variables") or [] if v.get("type") == "Date"
        ]
        cands = candidate_columns(frame)
        for name in declared:
            if name in frame.columns and all(c["column"] != name for c in cands):
                cands.append(
                    None
                )
        rows.append(
            {
                "uci_id": row["uci_id"],
                "name": row["name"],
                "labelled": "labelled" in row["roles"],
                "rows": int(len(frame)),
                "candidates": cands,
            }
        )
    return rows


def x_scan__mutmut_51(curated: Path, pool: Path, data: Path) -> list[dict[str, Any]]:
    meta = {m["uci_id"]: m for m in json.loads(curated.read_text())["kept"]}
    rows = []
    for row in json.loads(pool.read_text())["rows"]:
        path = data / f"{row['uci_id']}.csv"
        try:
            frame = ul.read_table(path)
        except Exception as error:  # recorded
            rows.append({"uci_id": row["uci_id"], "error": repr(error)})
            continue
        # variables declared with a time role in the repository metadata count too
        declared = [
            v["name"] for v in meta[row["uci_id"]].get("variables") or [] if v.get("type") == "Date"
        ]
        cands = candidate_columns(frame)
        for name in declared:
            if name in frame.columns and all(c["column"] != name for c in cands):
                cands.append(
                    {"XXcolumnXX": name, "kind": "declared", "distinct": int(frame[name].nunique())}
                )
        rows.append(
            {
                "uci_id": row["uci_id"],
                "name": row["name"],
                "labelled": "labelled" in row["roles"],
                "rows": int(len(frame)),
                "candidates": cands,
            }
        )
    return rows


def x_scan__mutmut_52(curated: Path, pool: Path, data: Path) -> list[dict[str, Any]]:
    meta = {m["uci_id"]: m for m in json.loads(curated.read_text())["kept"]}
    rows = []
    for row in json.loads(pool.read_text())["rows"]:
        path = data / f"{row['uci_id']}.csv"
        try:
            frame = ul.read_table(path)
        except Exception as error:  # recorded
            rows.append({"uci_id": row["uci_id"], "error": repr(error)})
            continue
        # variables declared with a time role in the repository metadata count too
        declared = [
            v["name"] for v in meta[row["uci_id"]].get("variables") or [] if v.get("type") == "Date"
        ]
        cands = candidate_columns(frame)
        for name in declared:
            if name in frame.columns and all(c["column"] != name for c in cands):
                cands.append(
                    {"COLUMN": name, "kind": "declared", "distinct": int(frame[name].nunique())}
                )
        rows.append(
            {
                "uci_id": row["uci_id"],
                "name": row["name"],
                "labelled": "labelled" in row["roles"],
                "rows": int(len(frame)),
                "candidates": cands,
            }
        )
    return rows


def x_scan__mutmut_53(curated: Path, pool: Path, data: Path) -> list[dict[str, Any]]:
    meta = {m["uci_id"]: m for m in json.loads(curated.read_text())["kept"]}
    rows = []
    for row in json.loads(pool.read_text())["rows"]:
        path = data / f"{row['uci_id']}.csv"
        try:
            frame = ul.read_table(path)
        except Exception as error:  # recorded
            rows.append({"uci_id": row["uci_id"], "error": repr(error)})
            continue
        # variables declared with a time role in the repository metadata count too
        declared = [
            v["name"] for v in meta[row["uci_id"]].get("variables") or [] if v.get("type") == "Date"
        ]
        cands = candidate_columns(frame)
        for name in declared:
            if name in frame.columns and all(c["column"] != name for c in cands):
                cands.append(
                    {"column": name, "XXkindXX": "declared", "distinct": int(frame[name].nunique())}
                )
        rows.append(
            {
                "uci_id": row["uci_id"],
                "name": row["name"],
                "labelled": "labelled" in row["roles"],
                "rows": int(len(frame)),
                "candidates": cands,
            }
        )
    return rows


def x_scan__mutmut_54(curated: Path, pool: Path, data: Path) -> list[dict[str, Any]]:
    meta = {m["uci_id"]: m for m in json.loads(curated.read_text())["kept"]}
    rows = []
    for row in json.loads(pool.read_text())["rows"]:
        path = data / f"{row['uci_id']}.csv"
        try:
            frame = ul.read_table(path)
        except Exception as error:  # recorded
            rows.append({"uci_id": row["uci_id"], "error": repr(error)})
            continue
        # variables declared with a time role in the repository metadata count too
        declared = [
            v["name"] for v in meta[row["uci_id"]].get("variables") or [] if v.get("type") == "Date"
        ]
        cands = candidate_columns(frame)
        for name in declared:
            if name in frame.columns and all(c["column"] != name for c in cands):
                cands.append(
                    {"column": name, "KIND": "declared", "distinct": int(frame[name].nunique())}
                )
        rows.append(
            {
                "uci_id": row["uci_id"],
                "name": row["name"],
                "labelled": "labelled" in row["roles"],
                "rows": int(len(frame)),
                "candidates": cands,
            }
        )
    return rows


def x_scan__mutmut_55(curated: Path, pool: Path, data: Path) -> list[dict[str, Any]]:
    meta = {m["uci_id"]: m for m in json.loads(curated.read_text())["kept"]}
    rows = []
    for row in json.loads(pool.read_text())["rows"]:
        path = data / f"{row['uci_id']}.csv"
        try:
            frame = ul.read_table(path)
        except Exception as error:  # recorded
            rows.append({"uci_id": row["uci_id"], "error": repr(error)})
            continue
        # variables declared with a time role in the repository metadata count too
        declared = [
            v["name"] for v in meta[row["uci_id"]].get("variables") or [] if v.get("type") == "Date"
        ]
        cands = candidate_columns(frame)
        for name in declared:
            if name in frame.columns and all(c["column"] != name for c in cands):
                cands.append(
                    {"column": name, "kind": "XXdeclaredXX", "distinct": int(frame[name].nunique())}
                )
        rows.append(
            {
                "uci_id": row["uci_id"],
                "name": row["name"],
                "labelled": "labelled" in row["roles"],
                "rows": int(len(frame)),
                "candidates": cands,
            }
        )
    return rows


def x_scan__mutmut_56(curated: Path, pool: Path, data: Path) -> list[dict[str, Any]]:
    meta = {m["uci_id"]: m for m in json.loads(curated.read_text())["kept"]}
    rows = []
    for row in json.loads(pool.read_text())["rows"]:
        path = data / f"{row['uci_id']}.csv"
        try:
            frame = ul.read_table(path)
        except Exception as error:  # recorded
            rows.append({"uci_id": row["uci_id"], "error": repr(error)})
            continue
        # variables declared with a time role in the repository metadata count too
        declared = [
            v["name"] for v in meta[row["uci_id"]].get("variables") or [] if v.get("type") == "Date"
        ]
        cands = candidate_columns(frame)
        for name in declared:
            if name in frame.columns and all(c["column"] != name for c in cands):
                cands.append(
                    {"column": name, "kind": "DECLARED", "distinct": int(frame[name].nunique())}
                )
        rows.append(
            {
                "uci_id": row["uci_id"],
                "name": row["name"],
                "labelled": "labelled" in row["roles"],
                "rows": int(len(frame)),
                "candidates": cands,
            }
        )
    return rows


def x_scan__mutmut_57(curated: Path, pool: Path, data: Path) -> list[dict[str, Any]]:
    meta = {m["uci_id"]: m for m in json.loads(curated.read_text())["kept"]}
    rows = []
    for row in json.loads(pool.read_text())["rows"]:
        path = data / f"{row['uci_id']}.csv"
        try:
            frame = ul.read_table(path)
        except Exception as error:  # recorded
            rows.append({"uci_id": row["uci_id"], "error": repr(error)})
            continue
        # variables declared with a time role in the repository metadata count too
        declared = [
            v["name"] for v in meta[row["uci_id"]].get("variables") or [] if v.get("type") == "Date"
        ]
        cands = candidate_columns(frame)
        for name in declared:
            if name in frame.columns and all(c["column"] != name for c in cands):
                cands.append(
                    {"column": name, "kind": "declared", "XXdistinctXX": int(frame[name].nunique())}
                )
        rows.append(
            {
                "uci_id": row["uci_id"],
                "name": row["name"],
                "labelled": "labelled" in row["roles"],
                "rows": int(len(frame)),
                "candidates": cands,
            }
        )
    return rows


def x_scan__mutmut_58(curated: Path, pool: Path, data: Path) -> list[dict[str, Any]]:
    meta = {m["uci_id"]: m for m in json.loads(curated.read_text())["kept"]}
    rows = []
    for row in json.loads(pool.read_text())["rows"]:
        path = data / f"{row['uci_id']}.csv"
        try:
            frame = ul.read_table(path)
        except Exception as error:  # recorded
            rows.append({"uci_id": row["uci_id"], "error": repr(error)})
            continue
        # variables declared with a time role in the repository metadata count too
        declared = [
            v["name"] for v in meta[row["uci_id"]].get("variables") or [] if v.get("type") == "Date"
        ]
        cands = candidate_columns(frame)
        for name in declared:
            if name in frame.columns and all(c["column"] != name for c in cands):
                cands.append(
                    {"column": name, "kind": "declared", "DISTINCT": int(frame[name].nunique())}
                )
        rows.append(
            {
                "uci_id": row["uci_id"],
                "name": row["name"],
                "labelled": "labelled" in row["roles"],
                "rows": int(len(frame)),
                "candidates": cands,
            }
        )
    return rows


def x_scan__mutmut_59(curated: Path, pool: Path, data: Path) -> list[dict[str, Any]]:
    meta = {m["uci_id"]: m for m in json.loads(curated.read_text())["kept"]}
    rows = []
    for row in json.loads(pool.read_text())["rows"]:
        path = data / f"{row['uci_id']}.csv"
        try:
            frame = ul.read_table(path)
        except Exception as error:  # recorded
            rows.append({"uci_id": row["uci_id"], "error": repr(error)})
            continue
        # variables declared with a time role in the repository metadata count too
        declared = [
            v["name"] for v in meta[row["uci_id"]].get("variables") or [] if v.get("type") == "Date"
        ]
        cands = candidate_columns(frame)
        for name in declared:
            if name in frame.columns and all(c["column"] != name for c in cands):
                cands.append(
                    {"column": name, "kind": "declared", "distinct": int(None)}
                )
        rows.append(
            {
                "uci_id": row["uci_id"],
                "name": row["name"],
                "labelled": "labelled" in row["roles"],
                "rows": int(len(frame)),
                "candidates": cands,
            }
        )
    return rows


def x_scan__mutmut_60(curated: Path, pool: Path, data: Path) -> list[dict[str, Any]]:
    meta = {m["uci_id"]: m for m in json.loads(curated.read_text())["kept"]}
    rows = []
    for row in json.loads(pool.read_text())["rows"]:
        path = data / f"{row['uci_id']}.csv"
        try:
            frame = ul.read_table(path)
        except Exception as error:  # recorded
            rows.append({"uci_id": row["uci_id"], "error": repr(error)})
            continue
        # variables declared with a time role in the repository metadata count too
        declared = [
            v["name"] for v in meta[row["uci_id"]].get("variables") or [] if v.get("type") == "Date"
        ]
        cands = candidate_columns(frame)
        for name in declared:
            if name in frame.columns and all(c["column"] != name for c in cands):
                cands.append(
                    {"column": name, "kind": "declared", "distinct": int(frame[name].nunique())}
                )
        rows.append(
            None
        )
    return rows


def x_scan__mutmut_61(curated: Path, pool: Path, data: Path) -> list[dict[str, Any]]:
    meta = {m["uci_id"]: m for m in json.loads(curated.read_text())["kept"]}
    rows = []
    for row in json.loads(pool.read_text())["rows"]:
        path = data / f"{row['uci_id']}.csv"
        try:
            frame = ul.read_table(path)
        except Exception as error:  # recorded
            rows.append({"uci_id": row["uci_id"], "error": repr(error)})
            continue
        # variables declared with a time role in the repository metadata count too
        declared = [
            v["name"] for v in meta[row["uci_id"]].get("variables") or [] if v.get("type") == "Date"
        ]
        cands = candidate_columns(frame)
        for name in declared:
            if name in frame.columns and all(c["column"] != name for c in cands):
                cands.append(
                    {"column": name, "kind": "declared", "distinct": int(frame[name].nunique())}
                )
        rows.append(
            {
                "XXuci_idXX": row["uci_id"],
                "name": row["name"],
                "labelled": "labelled" in row["roles"],
                "rows": int(len(frame)),
                "candidates": cands,
            }
        )
    return rows


def x_scan__mutmut_62(curated: Path, pool: Path, data: Path) -> list[dict[str, Any]]:
    meta = {m["uci_id"]: m for m in json.loads(curated.read_text())["kept"]}
    rows = []
    for row in json.loads(pool.read_text())["rows"]:
        path = data / f"{row['uci_id']}.csv"
        try:
            frame = ul.read_table(path)
        except Exception as error:  # recorded
            rows.append({"uci_id": row["uci_id"], "error": repr(error)})
            continue
        # variables declared with a time role in the repository metadata count too
        declared = [
            v["name"] for v in meta[row["uci_id"]].get("variables") or [] if v.get("type") == "Date"
        ]
        cands = candidate_columns(frame)
        for name in declared:
            if name in frame.columns and all(c["column"] != name for c in cands):
                cands.append(
                    {"column": name, "kind": "declared", "distinct": int(frame[name].nunique())}
                )
        rows.append(
            {
                "UCI_ID": row["uci_id"],
                "name": row["name"],
                "labelled": "labelled" in row["roles"],
                "rows": int(len(frame)),
                "candidates": cands,
            }
        )
    return rows


def x_scan__mutmut_63(curated: Path, pool: Path, data: Path) -> list[dict[str, Any]]:
    meta = {m["uci_id"]: m for m in json.loads(curated.read_text())["kept"]}
    rows = []
    for row in json.loads(pool.read_text())["rows"]:
        path = data / f"{row['uci_id']}.csv"
        try:
            frame = ul.read_table(path)
        except Exception as error:  # recorded
            rows.append({"uci_id": row["uci_id"], "error": repr(error)})
            continue
        # variables declared with a time role in the repository metadata count too
        declared = [
            v["name"] for v in meta[row["uci_id"]].get("variables") or [] if v.get("type") == "Date"
        ]
        cands = candidate_columns(frame)
        for name in declared:
            if name in frame.columns and all(c["column"] != name for c in cands):
                cands.append(
                    {"column": name, "kind": "declared", "distinct": int(frame[name].nunique())}
                )
        rows.append(
            {
                "uci_id": row["XXuci_idXX"],
                "name": row["name"],
                "labelled": "labelled" in row["roles"],
                "rows": int(len(frame)),
                "candidates": cands,
            }
        )
    return rows


def x_scan__mutmut_64(curated: Path, pool: Path, data: Path) -> list[dict[str, Any]]:
    meta = {m["uci_id"]: m for m in json.loads(curated.read_text())["kept"]}
    rows = []
    for row in json.loads(pool.read_text())["rows"]:
        path = data / f"{row['uci_id']}.csv"
        try:
            frame = ul.read_table(path)
        except Exception as error:  # recorded
            rows.append({"uci_id": row["uci_id"], "error": repr(error)})
            continue
        # variables declared with a time role in the repository metadata count too
        declared = [
            v["name"] for v in meta[row["uci_id"]].get("variables") or [] if v.get("type") == "Date"
        ]
        cands = candidate_columns(frame)
        for name in declared:
            if name in frame.columns and all(c["column"] != name for c in cands):
                cands.append(
                    {"column": name, "kind": "declared", "distinct": int(frame[name].nunique())}
                )
        rows.append(
            {
                "uci_id": row["UCI_ID"],
                "name": row["name"],
                "labelled": "labelled" in row["roles"],
                "rows": int(len(frame)),
                "candidates": cands,
            }
        )
    return rows


def x_scan__mutmut_65(curated: Path, pool: Path, data: Path) -> list[dict[str, Any]]:
    meta = {m["uci_id"]: m for m in json.loads(curated.read_text())["kept"]}
    rows = []
    for row in json.loads(pool.read_text())["rows"]:
        path = data / f"{row['uci_id']}.csv"
        try:
            frame = ul.read_table(path)
        except Exception as error:  # recorded
            rows.append({"uci_id": row["uci_id"], "error": repr(error)})
            continue
        # variables declared with a time role in the repository metadata count too
        declared = [
            v["name"] for v in meta[row["uci_id"]].get("variables") or [] if v.get("type") == "Date"
        ]
        cands = candidate_columns(frame)
        for name in declared:
            if name in frame.columns and all(c["column"] != name for c in cands):
                cands.append(
                    {"column": name, "kind": "declared", "distinct": int(frame[name].nunique())}
                )
        rows.append(
            {
                "uci_id": row["uci_id"],
                "XXnameXX": row["name"],
                "labelled": "labelled" in row["roles"],
                "rows": int(len(frame)),
                "candidates": cands,
            }
        )
    return rows


def x_scan__mutmut_66(curated: Path, pool: Path, data: Path) -> list[dict[str, Any]]:
    meta = {m["uci_id"]: m for m in json.loads(curated.read_text())["kept"]}
    rows = []
    for row in json.loads(pool.read_text())["rows"]:
        path = data / f"{row['uci_id']}.csv"
        try:
            frame = ul.read_table(path)
        except Exception as error:  # recorded
            rows.append({"uci_id": row["uci_id"], "error": repr(error)})
            continue
        # variables declared with a time role in the repository metadata count too
        declared = [
            v["name"] for v in meta[row["uci_id"]].get("variables") or [] if v.get("type") == "Date"
        ]
        cands = candidate_columns(frame)
        for name in declared:
            if name in frame.columns and all(c["column"] != name for c in cands):
                cands.append(
                    {"column": name, "kind": "declared", "distinct": int(frame[name].nunique())}
                )
        rows.append(
            {
                "uci_id": row["uci_id"],
                "NAME": row["name"],
                "labelled": "labelled" in row["roles"],
                "rows": int(len(frame)),
                "candidates": cands,
            }
        )
    return rows


def x_scan__mutmut_67(curated: Path, pool: Path, data: Path) -> list[dict[str, Any]]:
    meta = {m["uci_id"]: m for m in json.loads(curated.read_text())["kept"]}
    rows = []
    for row in json.loads(pool.read_text())["rows"]:
        path = data / f"{row['uci_id']}.csv"
        try:
            frame = ul.read_table(path)
        except Exception as error:  # recorded
            rows.append({"uci_id": row["uci_id"], "error": repr(error)})
            continue
        # variables declared with a time role in the repository metadata count too
        declared = [
            v["name"] for v in meta[row["uci_id"]].get("variables") or [] if v.get("type") == "Date"
        ]
        cands = candidate_columns(frame)
        for name in declared:
            if name in frame.columns and all(c["column"] != name for c in cands):
                cands.append(
                    {"column": name, "kind": "declared", "distinct": int(frame[name].nunique())}
                )
        rows.append(
            {
                "uci_id": row["uci_id"],
                "name": row["XXnameXX"],
                "labelled": "labelled" in row["roles"],
                "rows": int(len(frame)),
                "candidates": cands,
            }
        )
    return rows


def x_scan__mutmut_68(curated: Path, pool: Path, data: Path) -> list[dict[str, Any]]:
    meta = {m["uci_id"]: m for m in json.loads(curated.read_text())["kept"]}
    rows = []
    for row in json.loads(pool.read_text())["rows"]:
        path = data / f"{row['uci_id']}.csv"
        try:
            frame = ul.read_table(path)
        except Exception as error:  # recorded
            rows.append({"uci_id": row["uci_id"], "error": repr(error)})
            continue
        # variables declared with a time role in the repository metadata count too
        declared = [
            v["name"] for v in meta[row["uci_id"]].get("variables") or [] if v.get("type") == "Date"
        ]
        cands = candidate_columns(frame)
        for name in declared:
            if name in frame.columns and all(c["column"] != name for c in cands):
                cands.append(
                    {"column": name, "kind": "declared", "distinct": int(frame[name].nunique())}
                )
        rows.append(
            {
                "uci_id": row["uci_id"],
                "name": row["NAME"],
                "labelled": "labelled" in row["roles"],
                "rows": int(len(frame)),
                "candidates": cands,
            }
        )
    return rows


def x_scan__mutmut_69(curated: Path, pool: Path, data: Path) -> list[dict[str, Any]]:
    meta = {m["uci_id"]: m for m in json.loads(curated.read_text())["kept"]}
    rows = []
    for row in json.loads(pool.read_text())["rows"]:
        path = data / f"{row['uci_id']}.csv"
        try:
            frame = ul.read_table(path)
        except Exception as error:  # recorded
            rows.append({"uci_id": row["uci_id"], "error": repr(error)})
            continue
        # variables declared with a time role in the repository metadata count too
        declared = [
            v["name"] for v in meta[row["uci_id"]].get("variables") or [] if v.get("type") == "Date"
        ]
        cands = candidate_columns(frame)
        for name in declared:
            if name in frame.columns and all(c["column"] != name for c in cands):
                cands.append(
                    {"column": name, "kind": "declared", "distinct": int(frame[name].nunique())}
                )
        rows.append(
            {
                "uci_id": row["uci_id"],
                "name": row["name"],
                "XXlabelledXX": "labelled" in row["roles"],
                "rows": int(len(frame)),
                "candidates": cands,
            }
        )
    return rows


def x_scan__mutmut_70(curated: Path, pool: Path, data: Path) -> list[dict[str, Any]]:
    meta = {m["uci_id"]: m for m in json.loads(curated.read_text())["kept"]}
    rows = []
    for row in json.loads(pool.read_text())["rows"]:
        path = data / f"{row['uci_id']}.csv"
        try:
            frame = ul.read_table(path)
        except Exception as error:  # recorded
            rows.append({"uci_id": row["uci_id"], "error": repr(error)})
            continue
        # variables declared with a time role in the repository metadata count too
        declared = [
            v["name"] for v in meta[row["uci_id"]].get("variables") or [] if v.get("type") == "Date"
        ]
        cands = candidate_columns(frame)
        for name in declared:
            if name in frame.columns and all(c["column"] != name for c in cands):
                cands.append(
                    {"column": name, "kind": "declared", "distinct": int(frame[name].nunique())}
                )
        rows.append(
            {
                "uci_id": row["uci_id"],
                "name": row["name"],
                "LABELLED": "labelled" in row["roles"],
                "rows": int(len(frame)),
                "candidates": cands,
            }
        )
    return rows


def x_scan__mutmut_71(curated: Path, pool: Path, data: Path) -> list[dict[str, Any]]:
    meta = {m["uci_id"]: m for m in json.loads(curated.read_text())["kept"]}
    rows = []
    for row in json.loads(pool.read_text())["rows"]:
        path = data / f"{row['uci_id']}.csv"
        try:
            frame = ul.read_table(path)
        except Exception as error:  # recorded
            rows.append({"uci_id": row["uci_id"], "error": repr(error)})
            continue
        # variables declared with a time role in the repository metadata count too
        declared = [
            v["name"] for v in meta[row["uci_id"]].get("variables") or [] if v.get("type") == "Date"
        ]
        cands = candidate_columns(frame)
        for name in declared:
            if name in frame.columns and all(c["column"] != name for c in cands):
                cands.append(
                    {"column": name, "kind": "declared", "distinct": int(frame[name].nunique())}
                )
        rows.append(
            {
                "uci_id": row["uci_id"],
                "name": row["name"],
                "labelled": "XXlabelledXX" in row["roles"],
                "rows": int(len(frame)),
                "candidates": cands,
            }
        )
    return rows


def x_scan__mutmut_72(curated: Path, pool: Path, data: Path) -> list[dict[str, Any]]:
    meta = {m["uci_id"]: m for m in json.loads(curated.read_text())["kept"]}
    rows = []
    for row in json.loads(pool.read_text())["rows"]:
        path = data / f"{row['uci_id']}.csv"
        try:
            frame = ul.read_table(path)
        except Exception as error:  # recorded
            rows.append({"uci_id": row["uci_id"], "error": repr(error)})
            continue
        # variables declared with a time role in the repository metadata count too
        declared = [
            v["name"] for v in meta[row["uci_id"]].get("variables") or [] if v.get("type") == "Date"
        ]
        cands = candidate_columns(frame)
        for name in declared:
            if name in frame.columns and all(c["column"] != name for c in cands):
                cands.append(
                    {"column": name, "kind": "declared", "distinct": int(frame[name].nunique())}
                )
        rows.append(
            {
                "uci_id": row["uci_id"],
                "name": row["name"],
                "labelled": "LABELLED" in row["roles"],
                "rows": int(len(frame)),
                "candidates": cands,
            }
        )
    return rows


def x_scan__mutmut_73(curated: Path, pool: Path, data: Path) -> list[dict[str, Any]]:
    meta = {m["uci_id"]: m for m in json.loads(curated.read_text())["kept"]}
    rows = []
    for row in json.loads(pool.read_text())["rows"]:
        path = data / f"{row['uci_id']}.csv"
        try:
            frame = ul.read_table(path)
        except Exception as error:  # recorded
            rows.append({"uci_id": row["uci_id"], "error": repr(error)})
            continue
        # variables declared with a time role in the repository metadata count too
        declared = [
            v["name"] for v in meta[row["uci_id"]].get("variables") or [] if v.get("type") == "Date"
        ]
        cands = candidate_columns(frame)
        for name in declared:
            if name in frame.columns and all(c["column"] != name for c in cands):
                cands.append(
                    {"column": name, "kind": "declared", "distinct": int(frame[name].nunique())}
                )
        rows.append(
            {
                "uci_id": row["uci_id"],
                "name": row["name"],
                "labelled": "labelled" not in row["roles"],
                "rows": int(len(frame)),
                "candidates": cands,
            }
        )
    return rows


def x_scan__mutmut_74(curated: Path, pool: Path, data: Path) -> list[dict[str, Any]]:
    meta = {m["uci_id"]: m for m in json.loads(curated.read_text())["kept"]}
    rows = []
    for row in json.loads(pool.read_text())["rows"]:
        path = data / f"{row['uci_id']}.csv"
        try:
            frame = ul.read_table(path)
        except Exception as error:  # recorded
            rows.append({"uci_id": row["uci_id"], "error": repr(error)})
            continue
        # variables declared with a time role in the repository metadata count too
        declared = [
            v["name"] for v in meta[row["uci_id"]].get("variables") or [] if v.get("type") == "Date"
        ]
        cands = candidate_columns(frame)
        for name in declared:
            if name in frame.columns and all(c["column"] != name for c in cands):
                cands.append(
                    {"column": name, "kind": "declared", "distinct": int(frame[name].nunique())}
                )
        rows.append(
            {
                "uci_id": row["uci_id"],
                "name": row["name"],
                "labelled": "labelled" in row["XXrolesXX"],
                "rows": int(len(frame)),
                "candidates": cands,
            }
        )
    return rows


def x_scan__mutmut_75(curated: Path, pool: Path, data: Path) -> list[dict[str, Any]]:
    meta = {m["uci_id"]: m for m in json.loads(curated.read_text())["kept"]}
    rows = []
    for row in json.loads(pool.read_text())["rows"]:
        path = data / f"{row['uci_id']}.csv"
        try:
            frame = ul.read_table(path)
        except Exception as error:  # recorded
            rows.append({"uci_id": row["uci_id"], "error": repr(error)})
            continue
        # variables declared with a time role in the repository metadata count too
        declared = [
            v["name"] for v in meta[row["uci_id"]].get("variables") or [] if v.get("type") == "Date"
        ]
        cands = candidate_columns(frame)
        for name in declared:
            if name in frame.columns and all(c["column"] != name for c in cands):
                cands.append(
                    {"column": name, "kind": "declared", "distinct": int(frame[name].nunique())}
                )
        rows.append(
            {
                "uci_id": row["uci_id"],
                "name": row["name"],
                "labelled": "labelled" in row["ROLES"],
                "rows": int(len(frame)),
                "candidates": cands,
            }
        )
    return rows


def x_scan__mutmut_76(curated: Path, pool: Path, data: Path) -> list[dict[str, Any]]:
    meta = {m["uci_id"]: m for m in json.loads(curated.read_text())["kept"]}
    rows = []
    for row in json.loads(pool.read_text())["rows"]:
        path = data / f"{row['uci_id']}.csv"
        try:
            frame = ul.read_table(path)
        except Exception as error:  # recorded
            rows.append({"uci_id": row["uci_id"], "error": repr(error)})
            continue
        # variables declared with a time role in the repository metadata count too
        declared = [
            v["name"] for v in meta[row["uci_id"]].get("variables") or [] if v.get("type") == "Date"
        ]
        cands = candidate_columns(frame)
        for name in declared:
            if name in frame.columns and all(c["column"] != name for c in cands):
                cands.append(
                    {"column": name, "kind": "declared", "distinct": int(frame[name].nunique())}
                )
        rows.append(
            {
                "uci_id": row["uci_id"],
                "name": row["name"],
                "labelled": "labelled" in row["roles"],
                "XXrowsXX": int(len(frame)),
                "candidates": cands,
            }
        )
    return rows


def x_scan__mutmut_77(curated: Path, pool: Path, data: Path) -> list[dict[str, Any]]:
    meta = {m["uci_id"]: m for m in json.loads(curated.read_text())["kept"]}
    rows = []
    for row in json.loads(pool.read_text())["rows"]:
        path = data / f"{row['uci_id']}.csv"
        try:
            frame = ul.read_table(path)
        except Exception as error:  # recorded
            rows.append({"uci_id": row["uci_id"], "error": repr(error)})
            continue
        # variables declared with a time role in the repository metadata count too
        declared = [
            v["name"] for v in meta[row["uci_id"]].get("variables") or [] if v.get("type") == "Date"
        ]
        cands = candidate_columns(frame)
        for name in declared:
            if name in frame.columns and all(c["column"] != name for c in cands):
                cands.append(
                    {"column": name, "kind": "declared", "distinct": int(frame[name].nunique())}
                )
        rows.append(
            {
                "uci_id": row["uci_id"],
                "name": row["name"],
                "labelled": "labelled" in row["roles"],
                "ROWS": int(len(frame)),
                "candidates": cands,
            }
        )
    return rows


def x_scan__mutmut_78(curated: Path, pool: Path, data: Path) -> list[dict[str, Any]]:
    meta = {m["uci_id"]: m for m in json.loads(curated.read_text())["kept"]}
    rows = []
    for row in json.loads(pool.read_text())["rows"]:
        path = data / f"{row['uci_id']}.csv"
        try:
            frame = ul.read_table(path)
        except Exception as error:  # recorded
            rows.append({"uci_id": row["uci_id"], "error": repr(error)})
            continue
        # variables declared with a time role in the repository metadata count too
        declared = [
            v["name"] for v in meta[row["uci_id"]].get("variables") or [] if v.get("type") == "Date"
        ]
        cands = candidate_columns(frame)
        for name in declared:
            if name in frame.columns and all(c["column"] != name for c in cands):
                cands.append(
                    {"column": name, "kind": "declared", "distinct": int(frame[name].nunique())}
                )
        rows.append(
            {
                "uci_id": row["uci_id"],
                "name": row["name"],
                "labelled": "labelled" in row["roles"],
                "rows": int(None),
                "candidates": cands,
            }
        )
    return rows


def x_scan__mutmut_79(curated: Path, pool: Path, data: Path) -> list[dict[str, Any]]:
    meta = {m["uci_id"]: m for m in json.loads(curated.read_text())["kept"]}
    rows = []
    for row in json.loads(pool.read_text())["rows"]:
        path = data / f"{row['uci_id']}.csv"
        try:
            frame = ul.read_table(path)
        except Exception as error:  # recorded
            rows.append({"uci_id": row["uci_id"], "error": repr(error)})
            continue
        # variables declared with a time role in the repository metadata count too
        declared = [
            v["name"] for v in meta[row["uci_id"]].get("variables") or [] if v.get("type") == "Date"
        ]
        cands = candidate_columns(frame)
        for name in declared:
            if name in frame.columns and all(c["column"] != name for c in cands):
                cands.append(
                    {"column": name, "kind": "declared", "distinct": int(frame[name].nunique())}
                )
        rows.append(
            {
                "uci_id": row["uci_id"],
                "name": row["name"],
                "labelled": "labelled" in row["roles"],
                "rows": int(len(frame)),
                "XXcandidatesXX": cands,
            }
        )
    return rows


def x_scan__mutmut_80(curated: Path, pool: Path, data: Path) -> list[dict[str, Any]]:
    meta = {m["uci_id"]: m for m in json.loads(curated.read_text())["kept"]}
    rows = []
    for row in json.loads(pool.read_text())["rows"]:
        path = data / f"{row['uci_id']}.csv"
        try:
            frame = ul.read_table(path)
        except Exception as error:  # recorded
            rows.append({"uci_id": row["uci_id"], "error": repr(error)})
            continue
        # variables declared with a time role in the repository metadata count too
        declared = [
            v["name"] for v in meta[row["uci_id"]].get("variables") or [] if v.get("type") == "Date"
        ]
        cands = candidate_columns(frame)
        for name in declared:
            if name in frame.columns and all(c["column"] != name for c in cands):
                cands.append(
                    {"column": name, "kind": "declared", "distinct": int(frame[name].nunique())}
                )
        rows.append(
            {
                "uci_id": row["uci_id"],
                "name": row["name"],
                "labelled": "labelled" in row["roles"],
                "rows": int(len(frame)),
                "CANDIDATES": cands,
            }
        )
    return rows

mutants_x_scan__mutmut['_mutmut_orig'] = x_scan__mutmut_orig # type: ignore # mutmut generated
mutants_x_scan__mutmut['x_scan__mutmut_1'] = x_scan__mutmut_1 # type: ignore # mutmut generated
mutants_x_scan__mutmut['x_scan__mutmut_2'] = x_scan__mutmut_2 # type: ignore # mutmut generated
mutants_x_scan__mutmut['x_scan__mutmut_3'] = x_scan__mutmut_3 # type: ignore # mutmut generated
mutants_x_scan__mutmut['x_scan__mutmut_4'] = x_scan__mutmut_4 # type: ignore # mutmut generated
mutants_x_scan__mutmut['x_scan__mutmut_5'] = x_scan__mutmut_5 # type: ignore # mutmut generated
mutants_x_scan__mutmut['x_scan__mutmut_6'] = x_scan__mutmut_6 # type: ignore # mutmut generated
mutants_x_scan__mutmut['x_scan__mutmut_7'] = x_scan__mutmut_7 # type: ignore # mutmut generated
mutants_x_scan__mutmut['x_scan__mutmut_8'] = x_scan__mutmut_8 # type: ignore # mutmut generated
mutants_x_scan__mutmut['x_scan__mutmut_9'] = x_scan__mutmut_9 # type: ignore # mutmut generated
mutants_x_scan__mutmut['x_scan__mutmut_10'] = x_scan__mutmut_10 # type: ignore # mutmut generated
mutants_x_scan__mutmut['x_scan__mutmut_11'] = x_scan__mutmut_11 # type: ignore # mutmut generated
mutants_x_scan__mutmut['x_scan__mutmut_12'] = x_scan__mutmut_12 # type: ignore # mutmut generated
mutants_x_scan__mutmut['x_scan__mutmut_13'] = x_scan__mutmut_13 # type: ignore # mutmut generated
mutants_x_scan__mutmut['x_scan__mutmut_14'] = x_scan__mutmut_14 # type: ignore # mutmut generated
mutants_x_scan__mutmut['x_scan__mutmut_15'] = x_scan__mutmut_15 # type: ignore # mutmut generated
mutants_x_scan__mutmut['x_scan__mutmut_16'] = x_scan__mutmut_16 # type: ignore # mutmut generated
mutants_x_scan__mutmut['x_scan__mutmut_17'] = x_scan__mutmut_17 # type: ignore # mutmut generated
mutants_x_scan__mutmut['x_scan__mutmut_18'] = x_scan__mutmut_18 # type: ignore # mutmut generated
mutants_x_scan__mutmut['x_scan__mutmut_19'] = x_scan__mutmut_19 # type: ignore # mutmut generated
mutants_x_scan__mutmut['x_scan__mutmut_20'] = x_scan__mutmut_20 # type: ignore # mutmut generated
mutants_x_scan__mutmut['x_scan__mutmut_21'] = x_scan__mutmut_21 # type: ignore # mutmut generated
mutants_x_scan__mutmut['x_scan__mutmut_22'] = x_scan__mutmut_22 # type: ignore # mutmut generated
mutants_x_scan__mutmut['x_scan__mutmut_23'] = x_scan__mutmut_23 # type: ignore # mutmut generated
mutants_x_scan__mutmut['x_scan__mutmut_24'] = x_scan__mutmut_24 # type: ignore # mutmut generated
mutants_x_scan__mutmut['x_scan__mutmut_25'] = x_scan__mutmut_25 # type: ignore # mutmut generated
mutants_x_scan__mutmut['x_scan__mutmut_26'] = x_scan__mutmut_26 # type: ignore # mutmut generated
mutants_x_scan__mutmut['x_scan__mutmut_27'] = x_scan__mutmut_27 # type: ignore # mutmut generated
mutants_x_scan__mutmut['x_scan__mutmut_28'] = x_scan__mutmut_28 # type: ignore # mutmut generated
mutants_x_scan__mutmut['x_scan__mutmut_29'] = x_scan__mutmut_29 # type: ignore # mutmut generated
mutants_x_scan__mutmut['x_scan__mutmut_30'] = x_scan__mutmut_30 # type: ignore # mutmut generated
mutants_x_scan__mutmut['x_scan__mutmut_31'] = x_scan__mutmut_31 # type: ignore # mutmut generated
mutants_x_scan__mutmut['x_scan__mutmut_32'] = x_scan__mutmut_32 # type: ignore # mutmut generated
mutants_x_scan__mutmut['x_scan__mutmut_33'] = x_scan__mutmut_33 # type: ignore # mutmut generated
mutants_x_scan__mutmut['x_scan__mutmut_34'] = x_scan__mutmut_34 # type: ignore # mutmut generated
mutants_x_scan__mutmut['x_scan__mutmut_35'] = x_scan__mutmut_35 # type: ignore # mutmut generated
mutants_x_scan__mutmut['x_scan__mutmut_36'] = x_scan__mutmut_36 # type: ignore # mutmut generated
mutants_x_scan__mutmut['x_scan__mutmut_37'] = x_scan__mutmut_37 # type: ignore # mutmut generated
mutants_x_scan__mutmut['x_scan__mutmut_38'] = x_scan__mutmut_38 # type: ignore # mutmut generated
mutants_x_scan__mutmut['x_scan__mutmut_39'] = x_scan__mutmut_39 # type: ignore # mutmut generated
mutants_x_scan__mutmut['x_scan__mutmut_40'] = x_scan__mutmut_40 # type: ignore # mutmut generated
mutants_x_scan__mutmut['x_scan__mutmut_41'] = x_scan__mutmut_41 # type: ignore # mutmut generated
mutants_x_scan__mutmut['x_scan__mutmut_42'] = x_scan__mutmut_42 # type: ignore # mutmut generated
mutants_x_scan__mutmut['x_scan__mutmut_43'] = x_scan__mutmut_43 # type: ignore # mutmut generated
mutants_x_scan__mutmut['x_scan__mutmut_44'] = x_scan__mutmut_44 # type: ignore # mutmut generated
mutants_x_scan__mutmut['x_scan__mutmut_45'] = x_scan__mutmut_45 # type: ignore # mutmut generated
mutants_x_scan__mutmut['x_scan__mutmut_46'] = x_scan__mutmut_46 # type: ignore # mutmut generated
mutants_x_scan__mutmut['x_scan__mutmut_47'] = x_scan__mutmut_47 # type: ignore # mutmut generated
mutants_x_scan__mutmut['x_scan__mutmut_48'] = x_scan__mutmut_48 # type: ignore # mutmut generated
mutants_x_scan__mutmut['x_scan__mutmut_49'] = x_scan__mutmut_49 # type: ignore # mutmut generated
mutants_x_scan__mutmut['x_scan__mutmut_50'] = x_scan__mutmut_50 # type: ignore # mutmut generated
mutants_x_scan__mutmut['x_scan__mutmut_51'] = x_scan__mutmut_51 # type: ignore # mutmut generated
mutants_x_scan__mutmut['x_scan__mutmut_52'] = x_scan__mutmut_52 # type: ignore # mutmut generated
mutants_x_scan__mutmut['x_scan__mutmut_53'] = x_scan__mutmut_53 # type: ignore # mutmut generated
mutants_x_scan__mutmut['x_scan__mutmut_54'] = x_scan__mutmut_54 # type: ignore # mutmut generated
mutants_x_scan__mutmut['x_scan__mutmut_55'] = x_scan__mutmut_55 # type: ignore # mutmut generated
mutants_x_scan__mutmut['x_scan__mutmut_56'] = x_scan__mutmut_56 # type: ignore # mutmut generated
mutants_x_scan__mutmut['x_scan__mutmut_57'] = x_scan__mutmut_57 # type: ignore # mutmut generated
mutants_x_scan__mutmut['x_scan__mutmut_58'] = x_scan__mutmut_58 # type: ignore # mutmut generated
mutants_x_scan__mutmut['x_scan__mutmut_59'] = x_scan__mutmut_59 # type: ignore # mutmut generated
mutants_x_scan__mutmut['x_scan__mutmut_60'] = x_scan__mutmut_60 # type: ignore # mutmut generated
mutants_x_scan__mutmut['x_scan__mutmut_61'] = x_scan__mutmut_61 # type: ignore # mutmut generated
mutants_x_scan__mutmut['x_scan__mutmut_62'] = x_scan__mutmut_62 # type: ignore # mutmut generated
mutants_x_scan__mutmut['x_scan__mutmut_63'] = x_scan__mutmut_63 # type: ignore # mutmut generated
mutants_x_scan__mutmut['x_scan__mutmut_64'] = x_scan__mutmut_64 # type: ignore # mutmut generated
mutants_x_scan__mutmut['x_scan__mutmut_65'] = x_scan__mutmut_65 # type: ignore # mutmut generated
mutants_x_scan__mutmut['x_scan__mutmut_66'] = x_scan__mutmut_66 # type: ignore # mutmut generated
mutants_x_scan__mutmut['x_scan__mutmut_67'] = x_scan__mutmut_67 # type: ignore # mutmut generated
mutants_x_scan__mutmut['x_scan__mutmut_68'] = x_scan__mutmut_68 # type: ignore # mutmut generated
mutants_x_scan__mutmut['x_scan__mutmut_69'] = x_scan__mutmut_69 # type: ignore # mutmut generated
mutants_x_scan__mutmut['x_scan__mutmut_70'] = x_scan__mutmut_70 # type: ignore # mutmut generated
mutants_x_scan__mutmut['x_scan__mutmut_71'] = x_scan__mutmut_71 # type: ignore # mutmut generated
mutants_x_scan__mutmut['x_scan__mutmut_72'] = x_scan__mutmut_72 # type: ignore # mutmut generated
mutants_x_scan__mutmut['x_scan__mutmut_73'] = x_scan__mutmut_73 # type: ignore # mutmut generated
mutants_x_scan__mutmut['x_scan__mutmut_74'] = x_scan__mutmut_74 # type: ignore # mutmut generated
mutants_x_scan__mutmut['x_scan__mutmut_75'] = x_scan__mutmut_75 # type: ignore # mutmut generated
mutants_x_scan__mutmut['x_scan__mutmut_76'] = x_scan__mutmut_76 # type: ignore # mutmut generated
mutants_x_scan__mutmut['x_scan__mutmut_77'] = x_scan__mutmut_77 # type: ignore # mutmut generated
mutants_x_scan__mutmut['x_scan__mutmut_78'] = x_scan__mutmut_78 # type: ignore # mutmut generated
mutants_x_scan__mutmut['x_scan__mutmut_79'] = x_scan__mutmut_79 # type: ignore # mutmut generated
mutants_x_scan__mutmut['x_scan__mutmut_80'] = x_scan__mutmut_80 # type: ignore # mutmut generated


if __name__ == "__main__":
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    result = scan(registry / "uci_curated.json", registry / "uci_pool.json", root / "data" / "pool")
    out = Path(sys.argv[1])
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(result, indent=1) + "\n")
    with_time = [r for r in result if r.get("candidates")]
    print(len(result), "datasets,", len(with_time), "with a time candidate")
    for r in with_time:
        print(
            r["uci_id"], r["name"], r["labelled"], r["rows"], [c["column"] for c in r["candidates"]]
        )
