"""CPU LSTM autoencoder over causal windows of a time-ordered stream (issue 52).

Protocol: verification/lstm_pilot.md. Statistics (median, scale) and the flag threshold come
from the training rows only; windows are built one partition at a time with
``quality.windows.causal_windows``; the score of an event is the reconstruction error of the
last row of the window that closes on it. Validation rows serve early stopping only, through an
unlabelled reconstruction loss. Lives outside the detector registry and the scientific
fingerprint; it needs PyTorch (research/requirements-lstm.txt).
"""

from __future__ import annotations

import sys
from importlib.metadata import version
from pathlib import Path
from typing import Any, Self

import numpy as np
import pandas as pd
import torch
from torch import nn

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
from etl_benchmark.quality.windows import causal_windows, scores_to_events  # noqa: E402


from mutmut.mutation.trampoline import wrap_in_trampoline as _mutmut_mutated, MutantDict
mutants_xǁ_Networkǁ__init____mutmut: MutantDict = {}  # type: ignore
mutants_xǁ_Networkǁforward__mutmut: MutantDict = {}  # type: ignore


class _Network(nn.Module):
    @_mutmut_mutated(mutants_xǁ_Networkǁ__init____mutmut)
    def __init__(self, features: int, hidden: int) -> None:
        super().__init__()
        self.encoder = nn.LSTM(features, hidden, batch_first=True)
        self.decoder = nn.LSTM(hidden, hidden, batch_first=True)
        self.output = nn.Linear(hidden, features)
    def xǁ_Networkǁ__init____mutmut_orig(self, features: int, hidden: int) -> None:
        super().__init__()
        self.encoder = nn.LSTM(features, hidden, batch_first=True)
        self.decoder = nn.LSTM(hidden, hidden, batch_first=True)
        self.output = nn.Linear(hidden, features)
    def xǁ_Networkǁ__init____mutmut_1(self, features: int, hidden: int) -> None:
        super().__init__()
        self.encoder = None
        self.decoder = nn.LSTM(hidden, hidden, batch_first=True)
        self.output = nn.Linear(hidden, features)
    def xǁ_Networkǁ__init____mutmut_2(self, features: int, hidden: int) -> None:
        super().__init__()
        self.encoder = nn.LSTM(None, hidden, batch_first=True)
        self.decoder = nn.LSTM(hidden, hidden, batch_first=True)
        self.output = nn.Linear(hidden, features)
    def xǁ_Networkǁ__init____mutmut_3(self, features: int, hidden: int) -> None:
        super().__init__()
        self.encoder = nn.LSTM(features, None, batch_first=True)
        self.decoder = nn.LSTM(hidden, hidden, batch_first=True)
        self.output = nn.Linear(hidden, features)
    def xǁ_Networkǁ__init____mutmut_4(self, features: int, hidden: int) -> None:
        super().__init__()
        self.encoder = nn.LSTM(features, hidden, batch_first=None)
        self.decoder = nn.LSTM(hidden, hidden, batch_first=True)
        self.output = nn.Linear(hidden, features)
    def xǁ_Networkǁ__init____mutmut_5(self, features: int, hidden: int) -> None:
        super().__init__()
        self.encoder = nn.LSTM(hidden, batch_first=True)
        self.decoder = nn.LSTM(hidden, hidden, batch_first=True)
        self.output = nn.Linear(hidden, features)
    def xǁ_Networkǁ__init____mutmut_6(self, features: int, hidden: int) -> None:
        super().__init__()
        self.encoder = nn.LSTM(features, batch_first=True)
        self.decoder = nn.LSTM(hidden, hidden, batch_first=True)
        self.output = nn.Linear(hidden, features)
    def xǁ_Networkǁ__init____mutmut_7(self, features: int, hidden: int) -> None:
        super().__init__()
        self.encoder = nn.LSTM(features, hidden, )
        self.decoder = nn.LSTM(hidden, hidden, batch_first=True)
        self.output = nn.Linear(hidden, features)
    def xǁ_Networkǁ__init____mutmut_8(self, features: int, hidden: int) -> None:
        super().__init__()
        self.encoder = nn.LSTM(features, hidden, batch_first=False)
        self.decoder = nn.LSTM(hidden, hidden, batch_first=True)
        self.output = nn.Linear(hidden, features)
    def xǁ_Networkǁ__init____mutmut_9(self, features: int, hidden: int) -> None:
        super().__init__()
        self.encoder = nn.LSTM(features, hidden, batch_first=True)
        self.decoder = None
        self.output = nn.Linear(hidden, features)
    def xǁ_Networkǁ__init____mutmut_10(self, features: int, hidden: int) -> None:
        super().__init__()
        self.encoder = nn.LSTM(features, hidden, batch_first=True)
        self.decoder = nn.LSTM(None, hidden, batch_first=True)
        self.output = nn.Linear(hidden, features)
    def xǁ_Networkǁ__init____mutmut_11(self, features: int, hidden: int) -> None:
        super().__init__()
        self.encoder = nn.LSTM(features, hidden, batch_first=True)
        self.decoder = nn.LSTM(hidden, None, batch_first=True)
        self.output = nn.Linear(hidden, features)
    def xǁ_Networkǁ__init____mutmut_12(self, features: int, hidden: int) -> None:
        super().__init__()
        self.encoder = nn.LSTM(features, hidden, batch_first=True)
        self.decoder = nn.LSTM(hidden, hidden, batch_first=None)
        self.output = nn.Linear(hidden, features)
    def xǁ_Networkǁ__init____mutmut_13(self, features: int, hidden: int) -> None:
        super().__init__()
        self.encoder = nn.LSTM(features, hidden, batch_first=True)
        self.decoder = nn.LSTM(hidden, batch_first=True)
        self.output = nn.Linear(hidden, features)
    def xǁ_Networkǁ__init____mutmut_14(self, features: int, hidden: int) -> None:
        super().__init__()
        self.encoder = nn.LSTM(features, hidden, batch_first=True)
        self.decoder = nn.LSTM(hidden, batch_first=True)
        self.output = nn.Linear(hidden, features)
    def xǁ_Networkǁ__init____mutmut_15(self, features: int, hidden: int) -> None:
        super().__init__()
        self.encoder = nn.LSTM(features, hidden, batch_first=True)
        self.decoder = nn.LSTM(hidden, hidden, )
        self.output = nn.Linear(hidden, features)
    def xǁ_Networkǁ__init____mutmut_16(self, features: int, hidden: int) -> None:
        super().__init__()
        self.encoder = nn.LSTM(features, hidden, batch_first=True)
        self.decoder = nn.LSTM(hidden, hidden, batch_first=False)
        self.output = nn.Linear(hidden, features)
    def xǁ_Networkǁ__init____mutmut_17(self, features: int, hidden: int) -> None:
        super().__init__()
        self.encoder = nn.LSTM(features, hidden, batch_first=True)
        self.decoder = nn.LSTM(hidden, hidden, batch_first=True)
        self.output = None
    def xǁ_Networkǁ__init____mutmut_18(self, features: int, hidden: int) -> None:
        super().__init__()
        self.encoder = nn.LSTM(features, hidden, batch_first=True)
        self.decoder = nn.LSTM(hidden, hidden, batch_first=True)
        self.output = nn.Linear(None, features)
    def xǁ_Networkǁ__init____mutmut_19(self, features: int, hidden: int) -> None:
        super().__init__()
        self.encoder = nn.LSTM(features, hidden, batch_first=True)
        self.decoder = nn.LSTM(hidden, hidden, batch_first=True)
        self.output = nn.Linear(hidden, None)
    def xǁ_Networkǁ__init____mutmut_20(self, features: int, hidden: int) -> None:
        super().__init__()
        self.encoder = nn.LSTM(features, hidden, batch_first=True)
        self.decoder = nn.LSTM(hidden, hidden, batch_first=True)
        self.output = nn.Linear(features)
    def xǁ_Networkǁ__init____mutmut_21(self, features: int, hidden: int) -> None:
        super().__init__()
        self.encoder = nn.LSTM(features, hidden, batch_first=True)
        self.decoder = nn.LSTM(hidden, hidden, batch_first=True)
        self.output = nn.Linear(hidden, )

    @_mutmut_mutated(mutants_xǁ_Networkǁforward__mutmut)
    def forward(self, windows: torch.Tensor) -> torch.Tensor:
        _, (state, _) = self.encoder(windows)
        repeated = state[-1].unsqueeze(1).repeat(1, windows.shape[1], 1)
        decoded, _ = self.decoder(repeated)
        return self.output(decoded)

    def xǁ_Networkǁforward__mutmut_orig(self, windows: torch.Tensor) -> torch.Tensor:
        _, (state, _) = self.encoder(windows)
        repeated = state[-1].unsqueeze(1).repeat(1, windows.shape[1], 1)
        decoded, _ = self.decoder(repeated)
        return self.output(decoded)

    def xǁ_Networkǁforward__mutmut_1(self, windows: torch.Tensor) -> torch.Tensor:
        _, (state, _) = None
        repeated = state[-1].unsqueeze(1).repeat(1, windows.shape[1], 1)
        decoded, _ = self.decoder(repeated)
        return self.output(decoded)

    def xǁ_Networkǁforward__mutmut_2(self, windows: torch.Tensor) -> torch.Tensor:
        _, (state, _) = self.encoder(None)
        repeated = state[-1].unsqueeze(1).repeat(1, windows.shape[1], 1)
        decoded, _ = self.decoder(repeated)
        return self.output(decoded)

    def xǁ_Networkǁforward__mutmut_3(self, windows: torch.Tensor) -> torch.Tensor:
        _, (state, _) = self.encoder(windows)
        repeated = None
        decoded, _ = self.decoder(repeated)
        return self.output(decoded)

    def xǁ_Networkǁforward__mutmut_4(self, windows: torch.Tensor) -> torch.Tensor:
        _, (state, _) = self.encoder(windows)
        repeated = state[-1].unsqueeze(1).repeat(None, windows.shape[1], 1)
        decoded, _ = self.decoder(repeated)
        return self.output(decoded)

    def xǁ_Networkǁforward__mutmut_5(self, windows: torch.Tensor) -> torch.Tensor:
        _, (state, _) = self.encoder(windows)
        repeated = state[-1].unsqueeze(1).repeat(1, None, 1)
        decoded, _ = self.decoder(repeated)
        return self.output(decoded)

    def xǁ_Networkǁforward__mutmut_6(self, windows: torch.Tensor) -> torch.Tensor:
        _, (state, _) = self.encoder(windows)
        repeated = state[-1].unsqueeze(1).repeat(1, windows.shape[1], None)
        decoded, _ = self.decoder(repeated)
        return self.output(decoded)

    def xǁ_Networkǁforward__mutmut_7(self, windows: torch.Tensor) -> torch.Tensor:
        _, (state, _) = self.encoder(windows)
        repeated = state[-1].unsqueeze(1).repeat(windows.shape[1], 1)
        decoded, _ = self.decoder(repeated)
        return self.output(decoded)

    def xǁ_Networkǁforward__mutmut_8(self, windows: torch.Tensor) -> torch.Tensor:
        _, (state, _) = self.encoder(windows)
        repeated = state[-1].unsqueeze(1).repeat(1, 1)
        decoded, _ = self.decoder(repeated)
        return self.output(decoded)

    def xǁ_Networkǁforward__mutmut_9(self, windows: torch.Tensor) -> torch.Tensor:
        _, (state, _) = self.encoder(windows)
        repeated = state[-1].unsqueeze(1).repeat(1, windows.shape[1], )
        decoded, _ = self.decoder(repeated)
        return self.output(decoded)

    def xǁ_Networkǁforward__mutmut_10(self, windows: torch.Tensor) -> torch.Tensor:
        _, (state, _) = self.encoder(windows)
        repeated = state[-1].unsqueeze(None).repeat(1, windows.shape[1], 1)
        decoded, _ = self.decoder(repeated)
        return self.output(decoded)

    def xǁ_Networkǁforward__mutmut_11(self, windows: torch.Tensor) -> torch.Tensor:
        _, (state, _) = self.encoder(windows)
        repeated = state[+1].unsqueeze(1).repeat(1, windows.shape[1], 1)
        decoded, _ = self.decoder(repeated)
        return self.output(decoded)

    def xǁ_Networkǁforward__mutmut_12(self, windows: torch.Tensor) -> torch.Tensor:
        _, (state, _) = self.encoder(windows)
        repeated = state[-2].unsqueeze(1).repeat(1, windows.shape[1], 1)
        decoded, _ = self.decoder(repeated)
        return self.output(decoded)

    def xǁ_Networkǁforward__mutmut_13(self, windows: torch.Tensor) -> torch.Tensor:
        _, (state, _) = self.encoder(windows)
        repeated = state[-1].unsqueeze(2).repeat(1, windows.shape[1], 1)
        decoded, _ = self.decoder(repeated)
        return self.output(decoded)

    def xǁ_Networkǁforward__mutmut_14(self, windows: torch.Tensor) -> torch.Tensor:
        _, (state, _) = self.encoder(windows)
        repeated = state[-1].unsqueeze(1).repeat(2, windows.shape[1], 1)
        decoded, _ = self.decoder(repeated)
        return self.output(decoded)

    def xǁ_Networkǁforward__mutmut_15(self, windows: torch.Tensor) -> torch.Tensor:
        _, (state, _) = self.encoder(windows)
        repeated = state[-1].unsqueeze(1).repeat(1, windows.shape[2], 1)
        decoded, _ = self.decoder(repeated)
        return self.output(decoded)

    def xǁ_Networkǁforward__mutmut_16(self, windows: torch.Tensor) -> torch.Tensor:
        _, (state, _) = self.encoder(windows)
        repeated = state[-1].unsqueeze(1).repeat(1, windows.shape[1], 2)
        decoded, _ = self.decoder(repeated)
        return self.output(decoded)

    def xǁ_Networkǁforward__mutmut_17(self, windows: torch.Tensor) -> torch.Tensor:
        _, (state, _) = self.encoder(windows)
        repeated = state[-1].unsqueeze(1).repeat(1, windows.shape[1], 1)
        decoded, _ = None
        return self.output(decoded)

    def xǁ_Networkǁforward__mutmut_18(self, windows: torch.Tensor) -> torch.Tensor:
        _, (state, _) = self.encoder(windows)
        repeated = state[-1].unsqueeze(1).repeat(1, windows.shape[1], 1)
        decoded, _ = self.decoder(None)
        return self.output(decoded)

    def xǁ_Networkǁforward__mutmut_19(self, windows: torch.Tensor) -> torch.Tensor:
        _, (state, _) = self.encoder(windows)
        repeated = state[-1].unsqueeze(1).repeat(1, windows.shape[1], 1)
        decoded, _ = self.decoder(repeated)
        return self.output(None)

mutants_xǁ_Networkǁ__init____mutmut['_mutmut_orig'] = _Network.xǁ_Networkǁ__init____mutmut_orig # type: ignore # mutmut generated
mutants_xǁ_Networkǁ__init____mutmut['xǁ_Networkǁ__init____mutmut_1'] = _Network.xǁ_Networkǁ__init____mutmut_1 # type: ignore # mutmut generated
mutants_xǁ_Networkǁ__init____mutmut['xǁ_Networkǁ__init____mutmut_2'] = _Network.xǁ_Networkǁ__init____mutmut_2 # type: ignore # mutmut generated
mutants_xǁ_Networkǁ__init____mutmut['xǁ_Networkǁ__init____mutmut_3'] = _Network.xǁ_Networkǁ__init____mutmut_3 # type: ignore # mutmut generated
mutants_xǁ_Networkǁ__init____mutmut['xǁ_Networkǁ__init____mutmut_4'] = _Network.xǁ_Networkǁ__init____mutmut_4 # type: ignore # mutmut generated
mutants_xǁ_Networkǁ__init____mutmut['xǁ_Networkǁ__init____mutmut_5'] = _Network.xǁ_Networkǁ__init____mutmut_5 # type: ignore # mutmut generated
mutants_xǁ_Networkǁ__init____mutmut['xǁ_Networkǁ__init____mutmut_6'] = _Network.xǁ_Networkǁ__init____mutmut_6 # type: ignore # mutmut generated
mutants_xǁ_Networkǁ__init____mutmut['xǁ_Networkǁ__init____mutmut_7'] = _Network.xǁ_Networkǁ__init____mutmut_7 # type: ignore # mutmut generated
mutants_xǁ_Networkǁ__init____mutmut['xǁ_Networkǁ__init____mutmut_8'] = _Network.xǁ_Networkǁ__init____mutmut_8 # type: ignore # mutmut generated
mutants_xǁ_Networkǁ__init____mutmut['xǁ_Networkǁ__init____mutmut_9'] = _Network.xǁ_Networkǁ__init____mutmut_9 # type: ignore # mutmut generated
mutants_xǁ_Networkǁ__init____mutmut['xǁ_Networkǁ__init____mutmut_10'] = _Network.xǁ_Networkǁ__init____mutmut_10 # type: ignore # mutmut generated
mutants_xǁ_Networkǁ__init____mutmut['xǁ_Networkǁ__init____mutmut_11'] = _Network.xǁ_Networkǁ__init____mutmut_11 # type: ignore # mutmut generated
mutants_xǁ_Networkǁ__init____mutmut['xǁ_Networkǁ__init____mutmut_12'] = _Network.xǁ_Networkǁ__init____mutmut_12 # type: ignore # mutmut generated
mutants_xǁ_Networkǁ__init____mutmut['xǁ_Networkǁ__init____mutmut_13'] = _Network.xǁ_Networkǁ__init____mutmut_13 # type: ignore # mutmut generated
mutants_xǁ_Networkǁ__init____mutmut['xǁ_Networkǁ__init____mutmut_14'] = _Network.xǁ_Networkǁ__init____mutmut_14 # type: ignore # mutmut generated
mutants_xǁ_Networkǁ__init____mutmut['xǁ_Networkǁ__init____mutmut_15'] = _Network.xǁ_Networkǁ__init____mutmut_15 # type: ignore # mutmut generated
mutants_xǁ_Networkǁ__init____mutmut['xǁ_Networkǁ__init____mutmut_16'] = _Network.xǁ_Networkǁ__init____mutmut_16 # type: ignore # mutmut generated
mutants_xǁ_Networkǁ__init____mutmut['xǁ_Networkǁ__init____mutmut_17'] = _Network.xǁ_Networkǁ__init____mutmut_17 # type: ignore # mutmut generated
mutants_xǁ_Networkǁ__init____mutmut['xǁ_Networkǁ__init____mutmut_18'] = _Network.xǁ_Networkǁ__init____mutmut_18 # type: ignore # mutmut generated
mutants_xǁ_Networkǁ__init____mutmut['xǁ_Networkǁ__init____mutmut_19'] = _Network.xǁ_Networkǁ__init____mutmut_19 # type: ignore # mutmut generated
mutants_xǁ_Networkǁ__init____mutmut['xǁ_Networkǁ__init____mutmut_20'] = _Network.xǁ_Networkǁ__init____mutmut_20 # type: ignore # mutmut generated
mutants_xǁ_Networkǁ__init____mutmut['xǁ_Networkǁ__init____mutmut_21'] = _Network.xǁ_Networkǁ__init____mutmut_21 # type: ignore # mutmut generated

mutants_xǁ_Networkǁforward__mutmut['_mutmut_orig'] = _Network.xǁ_Networkǁforward__mutmut_orig # type: ignore # mutmut generated
mutants_xǁ_Networkǁforward__mutmut['xǁ_Networkǁforward__mutmut_1'] = _Network.xǁ_Networkǁforward__mutmut_1 # type: ignore # mutmut generated
mutants_xǁ_Networkǁforward__mutmut['xǁ_Networkǁforward__mutmut_2'] = _Network.xǁ_Networkǁforward__mutmut_2 # type: ignore # mutmut generated
mutants_xǁ_Networkǁforward__mutmut['xǁ_Networkǁforward__mutmut_3'] = _Network.xǁ_Networkǁforward__mutmut_3 # type: ignore # mutmut generated
mutants_xǁ_Networkǁforward__mutmut['xǁ_Networkǁforward__mutmut_4'] = _Network.xǁ_Networkǁforward__mutmut_4 # type: ignore # mutmut generated
mutants_xǁ_Networkǁforward__mutmut['xǁ_Networkǁforward__mutmut_5'] = _Network.xǁ_Networkǁforward__mutmut_5 # type: ignore # mutmut generated
mutants_xǁ_Networkǁforward__mutmut['xǁ_Networkǁforward__mutmut_6'] = _Network.xǁ_Networkǁforward__mutmut_6 # type: ignore # mutmut generated
mutants_xǁ_Networkǁforward__mutmut['xǁ_Networkǁforward__mutmut_7'] = _Network.xǁ_Networkǁforward__mutmut_7 # type: ignore # mutmut generated
mutants_xǁ_Networkǁforward__mutmut['xǁ_Networkǁforward__mutmut_8'] = _Network.xǁ_Networkǁforward__mutmut_8 # type: ignore # mutmut generated
mutants_xǁ_Networkǁforward__mutmut['xǁ_Networkǁforward__mutmut_9'] = _Network.xǁ_Networkǁforward__mutmut_9 # type: ignore # mutmut generated
mutants_xǁ_Networkǁforward__mutmut['xǁ_Networkǁforward__mutmut_10'] = _Network.xǁ_Networkǁforward__mutmut_10 # type: ignore # mutmut generated
mutants_xǁ_Networkǁforward__mutmut['xǁ_Networkǁforward__mutmut_11'] = _Network.xǁ_Networkǁforward__mutmut_11 # type: ignore # mutmut generated
mutants_xǁ_Networkǁforward__mutmut['xǁ_Networkǁforward__mutmut_12'] = _Network.xǁ_Networkǁforward__mutmut_12 # type: ignore # mutmut generated
mutants_xǁ_Networkǁforward__mutmut['xǁ_Networkǁforward__mutmut_13'] = _Network.xǁ_Networkǁforward__mutmut_13 # type: ignore # mutmut generated
mutants_xǁ_Networkǁforward__mutmut['xǁ_Networkǁforward__mutmut_14'] = _Network.xǁ_Networkǁforward__mutmut_14 # type: ignore # mutmut generated
mutants_xǁ_Networkǁforward__mutmut['xǁ_Networkǁforward__mutmut_15'] = _Network.xǁ_Networkǁforward__mutmut_15 # type: ignore # mutmut generated
mutants_xǁ_Networkǁforward__mutmut['xǁ_Networkǁforward__mutmut_16'] = _Network.xǁ_Networkǁforward__mutmut_16 # type: ignore # mutmut generated
mutants_xǁ_Networkǁforward__mutmut['xǁ_Networkǁforward__mutmut_17'] = _Network.xǁ_Networkǁforward__mutmut_17 # type: ignore # mutmut generated
mutants_xǁ_Networkǁforward__mutmut['xǁ_Networkǁforward__mutmut_18'] = _Network.xǁ_Networkǁforward__mutmut_18 # type: ignore # mutmut generated
mutants_xǁ_Networkǁforward__mutmut['xǁ_Networkǁforward__mutmut_19'] = _Network.xǁ_Networkǁforward__mutmut_19 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁ__init____mutmut: MutantDict = {}  # type: ignore
mutants_xǁLSTMAutoencoderǁ_windows__mutmut: MutantDict = {}  # type: ignore
mutants_xǁLSTMAutoencoderǁ_reconstruction_error__mutmut: MutantDict = {}  # type: ignore
mutants_xǁLSTMAutoencoderǁfit__mutmut: MutantDict = {}  # type: ignore
mutants_xǁLSTMAutoencoderǁvalidation_loss_now__mutmut: MutantDict = {}  # type: ignore
mutants_xǁLSTMAutoencoderǁscore__mutmut: MutantDict = {}  # type: ignore
mutants_xǁLSTMAutoencoderǁflags__mutmut: MutantDict = {}  # type: ignore
mutants_xǁLSTMAutoencoderǁsettings__mutmut: MutantDict = {}  # type: ignore


class LSTMAutoencoder:
    @_mutmut_mutated(mutants_xǁLSTMAutoencoderǁ__init____mutmut)
    def __init__(
        self,
        columns: list[str],
        time_column: str,
        *,
        window: int = 10,
        hidden: int = 32,
        max_epochs: int = 20,
        patience: int = 3,
        batch_size: int = 256,
        learning_rate: float = 1e-3,
        fit_rows: int = 50_000,
        validation_rows: int = 20_000,
        seed: int = 42,
        threads: int = 1,
    ) -> None:
        if window < 1 or hidden < 1 or max_epochs < 1 or patience < 1:
            raise ValueError("window, hidden, max_epochs and patience must be positive")
        self.columns = list(columns)
        self.time_column = time_column
        self.window, self.hidden = window, hidden
        self.max_epochs, self.patience = max_epochs, patience
        self.batch_size, self.learning_rate = batch_size, learning_rate
        self.fit_rows, self.validation_rows = fit_rows, validation_rows
        self.seed, self.threads = seed, threads
        self.center_: np.ndarray | None = None
        self.scale_: np.ndarray | None = None
        self.threshold_: float | None = None
        self._net: _Network | None = None
        self._history: dict[str, Any] = {}
        self._validation: torch.Tensor | None = None
    def xǁLSTMAutoencoderǁ__init____mutmut_orig(
        self,
        columns: list[str],
        time_column: str,
        *,
        window: int = 10,
        hidden: int = 32,
        max_epochs: int = 20,
        patience: int = 3,
        batch_size: int = 256,
        learning_rate: float = 1e-3,
        fit_rows: int = 50_000,
        validation_rows: int = 20_000,
        seed: int = 42,
        threads: int = 1,
    ) -> None:
        if window < 1 or hidden < 1 or max_epochs < 1 or patience < 1:
            raise ValueError("window, hidden, max_epochs and patience must be positive")
        self.columns = list(columns)
        self.time_column = time_column
        self.window, self.hidden = window, hidden
        self.max_epochs, self.patience = max_epochs, patience
        self.batch_size, self.learning_rate = batch_size, learning_rate
        self.fit_rows, self.validation_rows = fit_rows, validation_rows
        self.seed, self.threads = seed, threads
        self.center_: np.ndarray | None = None
        self.scale_: np.ndarray | None = None
        self.threshold_: float | None = None
        self._net: _Network | None = None
        self._history: dict[str, Any] = {}
        self._validation: torch.Tensor | None = None
    def xǁLSTMAutoencoderǁ__init____mutmut_1(
        self,
        columns: list[str],
        time_column: str,
        *,
        window: int = 11,
        hidden: int = 32,
        max_epochs: int = 20,
        patience: int = 3,
        batch_size: int = 256,
        learning_rate: float = 1e-3,
        fit_rows: int = 50_000,
        validation_rows: int = 20_000,
        seed: int = 42,
        threads: int = 1,
    ) -> None:
        if window < 1 or hidden < 1 or max_epochs < 1 or patience < 1:
            raise ValueError("window, hidden, max_epochs and patience must be positive")
        self.columns = list(columns)
        self.time_column = time_column
        self.window, self.hidden = window, hidden
        self.max_epochs, self.patience = max_epochs, patience
        self.batch_size, self.learning_rate = batch_size, learning_rate
        self.fit_rows, self.validation_rows = fit_rows, validation_rows
        self.seed, self.threads = seed, threads
        self.center_: np.ndarray | None = None
        self.scale_: np.ndarray | None = None
        self.threshold_: float | None = None
        self._net: _Network | None = None
        self._history: dict[str, Any] = {}
        self._validation: torch.Tensor | None = None
    def xǁLSTMAutoencoderǁ__init____mutmut_2(
        self,
        columns: list[str],
        time_column: str,
        *,
        window: int = 10,
        hidden: int = 33,
        max_epochs: int = 20,
        patience: int = 3,
        batch_size: int = 256,
        learning_rate: float = 1e-3,
        fit_rows: int = 50_000,
        validation_rows: int = 20_000,
        seed: int = 42,
        threads: int = 1,
    ) -> None:
        if window < 1 or hidden < 1 or max_epochs < 1 or patience < 1:
            raise ValueError("window, hidden, max_epochs and patience must be positive")
        self.columns = list(columns)
        self.time_column = time_column
        self.window, self.hidden = window, hidden
        self.max_epochs, self.patience = max_epochs, patience
        self.batch_size, self.learning_rate = batch_size, learning_rate
        self.fit_rows, self.validation_rows = fit_rows, validation_rows
        self.seed, self.threads = seed, threads
        self.center_: np.ndarray | None = None
        self.scale_: np.ndarray | None = None
        self.threshold_: float | None = None
        self._net: _Network | None = None
        self._history: dict[str, Any] = {}
        self._validation: torch.Tensor | None = None
    def xǁLSTMAutoencoderǁ__init____mutmut_3(
        self,
        columns: list[str],
        time_column: str,
        *,
        window: int = 10,
        hidden: int = 32,
        max_epochs: int = 21,
        patience: int = 3,
        batch_size: int = 256,
        learning_rate: float = 1e-3,
        fit_rows: int = 50_000,
        validation_rows: int = 20_000,
        seed: int = 42,
        threads: int = 1,
    ) -> None:
        if window < 1 or hidden < 1 or max_epochs < 1 or patience < 1:
            raise ValueError("window, hidden, max_epochs and patience must be positive")
        self.columns = list(columns)
        self.time_column = time_column
        self.window, self.hidden = window, hidden
        self.max_epochs, self.patience = max_epochs, patience
        self.batch_size, self.learning_rate = batch_size, learning_rate
        self.fit_rows, self.validation_rows = fit_rows, validation_rows
        self.seed, self.threads = seed, threads
        self.center_: np.ndarray | None = None
        self.scale_: np.ndarray | None = None
        self.threshold_: float | None = None
        self._net: _Network | None = None
        self._history: dict[str, Any] = {}
        self._validation: torch.Tensor | None = None
    def xǁLSTMAutoencoderǁ__init____mutmut_4(
        self,
        columns: list[str],
        time_column: str,
        *,
        window: int = 10,
        hidden: int = 32,
        max_epochs: int = 20,
        patience: int = 4,
        batch_size: int = 256,
        learning_rate: float = 1e-3,
        fit_rows: int = 50_000,
        validation_rows: int = 20_000,
        seed: int = 42,
        threads: int = 1,
    ) -> None:
        if window < 1 or hidden < 1 or max_epochs < 1 or patience < 1:
            raise ValueError("window, hidden, max_epochs and patience must be positive")
        self.columns = list(columns)
        self.time_column = time_column
        self.window, self.hidden = window, hidden
        self.max_epochs, self.patience = max_epochs, patience
        self.batch_size, self.learning_rate = batch_size, learning_rate
        self.fit_rows, self.validation_rows = fit_rows, validation_rows
        self.seed, self.threads = seed, threads
        self.center_: np.ndarray | None = None
        self.scale_: np.ndarray | None = None
        self.threshold_: float | None = None
        self._net: _Network | None = None
        self._history: dict[str, Any] = {}
        self._validation: torch.Tensor | None = None
    def xǁLSTMAutoencoderǁ__init____mutmut_5(
        self,
        columns: list[str],
        time_column: str,
        *,
        window: int = 10,
        hidden: int = 32,
        max_epochs: int = 20,
        patience: int = 3,
        batch_size: int = 257,
        learning_rate: float = 1e-3,
        fit_rows: int = 50_000,
        validation_rows: int = 20_000,
        seed: int = 42,
        threads: int = 1,
    ) -> None:
        if window < 1 or hidden < 1 or max_epochs < 1 or patience < 1:
            raise ValueError("window, hidden, max_epochs and patience must be positive")
        self.columns = list(columns)
        self.time_column = time_column
        self.window, self.hidden = window, hidden
        self.max_epochs, self.patience = max_epochs, patience
        self.batch_size, self.learning_rate = batch_size, learning_rate
        self.fit_rows, self.validation_rows = fit_rows, validation_rows
        self.seed, self.threads = seed, threads
        self.center_: np.ndarray | None = None
        self.scale_: np.ndarray | None = None
        self.threshold_: float | None = None
        self._net: _Network | None = None
        self._history: dict[str, Any] = {}
        self._validation: torch.Tensor | None = None
    def xǁLSTMAutoencoderǁ__init____mutmut_6(
        self,
        columns: list[str],
        time_column: str,
        *,
        window: int = 10,
        hidden: int = 32,
        max_epochs: int = 20,
        patience: int = 3,
        batch_size: int = 256,
        learning_rate: float = 1.001,
        fit_rows: int = 50_000,
        validation_rows: int = 20_000,
        seed: int = 42,
        threads: int = 1,
    ) -> None:
        if window < 1 or hidden < 1 or max_epochs < 1 or patience < 1:
            raise ValueError("window, hidden, max_epochs and patience must be positive")
        self.columns = list(columns)
        self.time_column = time_column
        self.window, self.hidden = window, hidden
        self.max_epochs, self.patience = max_epochs, patience
        self.batch_size, self.learning_rate = batch_size, learning_rate
        self.fit_rows, self.validation_rows = fit_rows, validation_rows
        self.seed, self.threads = seed, threads
        self.center_: np.ndarray | None = None
        self.scale_: np.ndarray | None = None
        self.threshold_: float | None = None
        self._net: _Network | None = None
        self._history: dict[str, Any] = {}
        self._validation: torch.Tensor | None = None
    def xǁLSTMAutoencoderǁ__init____mutmut_7(
        self,
        columns: list[str],
        time_column: str,
        *,
        window: int = 10,
        hidden: int = 32,
        max_epochs: int = 20,
        patience: int = 3,
        batch_size: int = 256,
        learning_rate: float = 1e-3,
        fit_rows: int = 50001,
        validation_rows: int = 20_000,
        seed: int = 42,
        threads: int = 1,
    ) -> None:
        if window < 1 or hidden < 1 or max_epochs < 1 or patience < 1:
            raise ValueError("window, hidden, max_epochs and patience must be positive")
        self.columns = list(columns)
        self.time_column = time_column
        self.window, self.hidden = window, hidden
        self.max_epochs, self.patience = max_epochs, patience
        self.batch_size, self.learning_rate = batch_size, learning_rate
        self.fit_rows, self.validation_rows = fit_rows, validation_rows
        self.seed, self.threads = seed, threads
        self.center_: np.ndarray | None = None
        self.scale_: np.ndarray | None = None
        self.threshold_: float | None = None
        self._net: _Network | None = None
        self._history: dict[str, Any] = {}
        self._validation: torch.Tensor | None = None
    def xǁLSTMAutoencoderǁ__init____mutmut_8(
        self,
        columns: list[str],
        time_column: str,
        *,
        window: int = 10,
        hidden: int = 32,
        max_epochs: int = 20,
        patience: int = 3,
        batch_size: int = 256,
        learning_rate: float = 1e-3,
        fit_rows: int = 50_000,
        validation_rows: int = 20001,
        seed: int = 42,
        threads: int = 1,
    ) -> None:
        if window < 1 or hidden < 1 or max_epochs < 1 or patience < 1:
            raise ValueError("window, hidden, max_epochs and patience must be positive")
        self.columns = list(columns)
        self.time_column = time_column
        self.window, self.hidden = window, hidden
        self.max_epochs, self.patience = max_epochs, patience
        self.batch_size, self.learning_rate = batch_size, learning_rate
        self.fit_rows, self.validation_rows = fit_rows, validation_rows
        self.seed, self.threads = seed, threads
        self.center_: np.ndarray | None = None
        self.scale_: np.ndarray | None = None
        self.threshold_: float | None = None
        self._net: _Network | None = None
        self._history: dict[str, Any] = {}
        self._validation: torch.Tensor | None = None
    def xǁLSTMAutoencoderǁ__init____mutmut_9(
        self,
        columns: list[str],
        time_column: str,
        *,
        window: int = 10,
        hidden: int = 32,
        max_epochs: int = 20,
        patience: int = 3,
        batch_size: int = 256,
        learning_rate: float = 1e-3,
        fit_rows: int = 50_000,
        validation_rows: int = 20_000,
        seed: int = 43,
        threads: int = 1,
    ) -> None:
        if window < 1 or hidden < 1 or max_epochs < 1 or patience < 1:
            raise ValueError("window, hidden, max_epochs and patience must be positive")
        self.columns = list(columns)
        self.time_column = time_column
        self.window, self.hidden = window, hidden
        self.max_epochs, self.patience = max_epochs, patience
        self.batch_size, self.learning_rate = batch_size, learning_rate
        self.fit_rows, self.validation_rows = fit_rows, validation_rows
        self.seed, self.threads = seed, threads
        self.center_: np.ndarray | None = None
        self.scale_: np.ndarray | None = None
        self.threshold_: float | None = None
        self._net: _Network | None = None
        self._history: dict[str, Any] = {}
        self._validation: torch.Tensor | None = None
    def xǁLSTMAutoencoderǁ__init____mutmut_10(
        self,
        columns: list[str],
        time_column: str,
        *,
        window: int = 10,
        hidden: int = 32,
        max_epochs: int = 20,
        patience: int = 3,
        batch_size: int = 256,
        learning_rate: float = 1e-3,
        fit_rows: int = 50_000,
        validation_rows: int = 20_000,
        seed: int = 42,
        threads: int = 2,
    ) -> None:
        if window < 1 or hidden < 1 or max_epochs < 1 or patience < 1:
            raise ValueError("window, hidden, max_epochs and patience must be positive")
        self.columns = list(columns)
        self.time_column = time_column
        self.window, self.hidden = window, hidden
        self.max_epochs, self.patience = max_epochs, patience
        self.batch_size, self.learning_rate = batch_size, learning_rate
        self.fit_rows, self.validation_rows = fit_rows, validation_rows
        self.seed, self.threads = seed, threads
        self.center_: np.ndarray | None = None
        self.scale_: np.ndarray | None = None
        self.threshold_: float | None = None
        self._net: _Network | None = None
        self._history: dict[str, Any] = {}
        self._validation: torch.Tensor | None = None
    def xǁLSTMAutoencoderǁ__init____mutmut_11(
        self,
        columns: list[str],
        time_column: str,
        *,
        window: int = 10,
        hidden: int = 32,
        max_epochs: int = 20,
        patience: int = 3,
        batch_size: int = 256,
        learning_rate: float = 1e-3,
        fit_rows: int = 50_000,
        validation_rows: int = 20_000,
        seed: int = 42,
        threads: int = 1,
    ) -> None:
        if window < 1 or hidden < 1 or max_epochs < 1 and patience < 1:
            raise ValueError("window, hidden, max_epochs and patience must be positive")
        self.columns = list(columns)
        self.time_column = time_column
        self.window, self.hidden = window, hidden
        self.max_epochs, self.patience = max_epochs, patience
        self.batch_size, self.learning_rate = batch_size, learning_rate
        self.fit_rows, self.validation_rows = fit_rows, validation_rows
        self.seed, self.threads = seed, threads
        self.center_: np.ndarray | None = None
        self.scale_: np.ndarray | None = None
        self.threshold_: float | None = None
        self._net: _Network | None = None
        self._history: dict[str, Any] = {}
        self._validation: torch.Tensor | None = None
    def xǁLSTMAutoencoderǁ__init____mutmut_12(
        self,
        columns: list[str],
        time_column: str,
        *,
        window: int = 10,
        hidden: int = 32,
        max_epochs: int = 20,
        patience: int = 3,
        batch_size: int = 256,
        learning_rate: float = 1e-3,
        fit_rows: int = 50_000,
        validation_rows: int = 20_000,
        seed: int = 42,
        threads: int = 1,
    ) -> None:
        if window < 1 or hidden < 1 and max_epochs < 1 or patience < 1:
            raise ValueError("window, hidden, max_epochs and patience must be positive")
        self.columns = list(columns)
        self.time_column = time_column
        self.window, self.hidden = window, hidden
        self.max_epochs, self.patience = max_epochs, patience
        self.batch_size, self.learning_rate = batch_size, learning_rate
        self.fit_rows, self.validation_rows = fit_rows, validation_rows
        self.seed, self.threads = seed, threads
        self.center_: np.ndarray | None = None
        self.scale_: np.ndarray | None = None
        self.threshold_: float | None = None
        self._net: _Network | None = None
        self._history: dict[str, Any] = {}
        self._validation: torch.Tensor | None = None
    def xǁLSTMAutoencoderǁ__init____mutmut_13(
        self,
        columns: list[str],
        time_column: str,
        *,
        window: int = 10,
        hidden: int = 32,
        max_epochs: int = 20,
        patience: int = 3,
        batch_size: int = 256,
        learning_rate: float = 1e-3,
        fit_rows: int = 50_000,
        validation_rows: int = 20_000,
        seed: int = 42,
        threads: int = 1,
    ) -> None:
        if window < 1 and hidden < 1 or max_epochs < 1 or patience < 1:
            raise ValueError("window, hidden, max_epochs and patience must be positive")
        self.columns = list(columns)
        self.time_column = time_column
        self.window, self.hidden = window, hidden
        self.max_epochs, self.patience = max_epochs, patience
        self.batch_size, self.learning_rate = batch_size, learning_rate
        self.fit_rows, self.validation_rows = fit_rows, validation_rows
        self.seed, self.threads = seed, threads
        self.center_: np.ndarray | None = None
        self.scale_: np.ndarray | None = None
        self.threshold_: float | None = None
        self._net: _Network | None = None
        self._history: dict[str, Any] = {}
        self._validation: torch.Tensor | None = None
    def xǁLSTMAutoencoderǁ__init____mutmut_14(
        self,
        columns: list[str],
        time_column: str,
        *,
        window: int = 10,
        hidden: int = 32,
        max_epochs: int = 20,
        patience: int = 3,
        batch_size: int = 256,
        learning_rate: float = 1e-3,
        fit_rows: int = 50_000,
        validation_rows: int = 20_000,
        seed: int = 42,
        threads: int = 1,
    ) -> None:
        if window <= 1 or hidden < 1 or max_epochs < 1 or patience < 1:
            raise ValueError("window, hidden, max_epochs and patience must be positive")
        self.columns = list(columns)
        self.time_column = time_column
        self.window, self.hidden = window, hidden
        self.max_epochs, self.patience = max_epochs, patience
        self.batch_size, self.learning_rate = batch_size, learning_rate
        self.fit_rows, self.validation_rows = fit_rows, validation_rows
        self.seed, self.threads = seed, threads
        self.center_: np.ndarray | None = None
        self.scale_: np.ndarray | None = None
        self.threshold_: float | None = None
        self._net: _Network | None = None
        self._history: dict[str, Any] = {}
        self._validation: torch.Tensor | None = None
    def xǁLSTMAutoencoderǁ__init____mutmut_15(
        self,
        columns: list[str],
        time_column: str,
        *,
        window: int = 10,
        hidden: int = 32,
        max_epochs: int = 20,
        patience: int = 3,
        batch_size: int = 256,
        learning_rate: float = 1e-3,
        fit_rows: int = 50_000,
        validation_rows: int = 20_000,
        seed: int = 42,
        threads: int = 1,
    ) -> None:
        if window < 2 or hidden < 1 or max_epochs < 1 or patience < 1:
            raise ValueError("window, hidden, max_epochs and patience must be positive")
        self.columns = list(columns)
        self.time_column = time_column
        self.window, self.hidden = window, hidden
        self.max_epochs, self.patience = max_epochs, patience
        self.batch_size, self.learning_rate = batch_size, learning_rate
        self.fit_rows, self.validation_rows = fit_rows, validation_rows
        self.seed, self.threads = seed, threads
        self.center_: np.ndarray | None = None
        self.scale_: np.ndarray | None = None
        self.threshold_: float | None = None
        self._net: _Network | None = None
        self._history: dict[str, Any] = {}
        self._validation: torch.Tensor | None = None
    def xǁLSTMAutoencoderǁ__init____mutmut_16(
        self,
        columns: list[str],
        time_column: str,
        *,
        window: int = 10,
        hidden: int = 32,
        max_epochs: int = 20,
        patience: int = 3,
        batch_size: int = 256,
        learning_rate: float = 1e-3,
        fit_rows: int = 50_000,
        validation_rows: int = 20_000,
        seed: int = 42,
        threads: int = 1,
    ) -> None:
        if window < 1 or hidden <= 1 or max_epochs < 1 or patience < 1:
            raise ValueError("window, hidden, max_epochs and patience must be positive")
        self.columns = list(columns)
        self.time_column = time_column
        self.window, self.hidden = window, hidden
        self.max_epochs, self.patience = max_epochs, patience
        self.batch_size, self.learning_rate = batch_size, learning_rate
        self.fit_rows, self.validation_rows = fit_rows, validation_rows
        self.seed, self.threads = seed, threads
        self.center_: np.ndarray | None = None
        self.scale_: np.ndarray | None = None
        self.threshold_: float | None = None
        self._net: _Network | None = None
        self._history: dict[str, Any] = {}
        self._validation: torch.Tensor | None = None
    def xǁLSTMAutoencoderǁ__init____mutmut_17(
        self,
        columns: list[str],
        time_column: str,
        *,
        window: int = 10,
        hidden: int = 32,
        max_epochs: int = 20,
        patience: int = 3,
        batch_size: int = 256,
        learning_rate: float = 1e-3,
        fit_rows: int = 50_000,
        validation_rows: int = 20_000,
        seed: int = 42,
        threads: int = 1,
    ) -> None:
        if window < 1 or hidden < 2 or max_epochs < 1 or patience < 1:
            raise ValueError("window, hidden, max_epochs and patience must be positive")
        self.columns = list(columns)
        self.time_column = time_column
        self.window, self.hidden = window, hidden
        self.max_epochs, self.patience = max_epochs, patience
        self.batch_size, self.learning_rate = batch_size, learning_rate
        self.fit_rows, self.validation_rows = fit_rows, validation_rows
        self.seed, self.threads = seed, threads
        self.center_: np.ndarray | None = None
        self.scale_: np.ndarray | None = None
        self.threshold_: float | None = None
        self._net: _Network | None = None
        self._history: dict[str, Any] = {}
        self._validation: torch.Tensor | None = None
    def xǁLSTMAutoencoderǁ__init____mutmut_18(
        self,
        columns: list[str],
        time_column: str,
        *,
        window: int = 10,
        hidden: int = 32,
        max_epochs: int = 20,
        patience: int = 3,
        batch_size: int = 256,
        learning_rate: float = 1e-3,
        fit_rows: int = 50_000,
        validation_rows: int = 20_000,
        seed: int = 42,
        threads: int = 1,
    ) -> None:
        if window < 1 or hidden < 1 or max_epochs <= 1 or patience < 1:
            raise ValueError("window, hidden, max_epochs and patience must be positive")
        self.columns = list(columns)
        self.time_column = time_column
        self.window, self.hidden = window, hidden
        self.max_epochs, self.patience = max_epochs, patience
        self.batch_size, self.learning_rate = batch_size, learning_rate
        self.fit_rows, self.validation_rows = fit_rows, validation_rows
        self.seed, self.threads = seed, threads
        self.center_: np.ndarray | None = None
        self.scale_: np.ndarray | None = None
        self.threshold_: float | None = None
        self._net: _Network | None = None
        self._history: dict[str, Any] = {}
        self._validation: torch.Tensor | None = None
    def xǁLSTMAutoencoderǁ__init____mutmut_19(
        self,
        columns: list[str],
        time_column: str,
        *,
        window: int = 10,
        hidden: int = 32,
        max_epochs: int = 20,
        patience: int = 3,
        batch_size: int = 256,
        learning_rate: float = 1e-3,
        fit_rows: int = 50_000,
        validation_rows: int = 20_000,
        seed: int = 42,
        threads: int = 1,
    ) -> None:
        if window < 1 or hidden < 1 or max_epochs < 2 or patience < 1:
            raise ValueError("window, hidden, max_epochs and patience must be positive")
        self.columns = list(columns)
        self.time_column = time_column
        self.window, self.hidden = window, hidden
        self.max_epochs, self.patience = max_epochs, patience
        self.batch_size, self.learning_rate = batch_size, learning_rate
        self.fit_rows, self.validation_rows = fit_rows, validation_rows
        self.seed, self.threads = seed, threads
        self.center_: np.ndarray | None = None
        self.scale_: np.ndarray | None = None
        self.threshold_: float | None = None
        self._net: _Network | None = None
        self._history: dict[str, Any] = {}
        self._validation: torch.Tensor | None = None
    def xǁLSTMAutoencoderǁ__init____mutmut_20(
        self,
        columns: list[str],
        time_column: str,
        *,
        window: int = 10,
        hidden: int = 32,
        max_epochs: int = 20,
        patience: int = 3,
        batch_size: int = 256,
        learning_rate: float = 1e-3,
        fit_rows: int = 50_000,
        validation_rows: int = 20_000,
        seed: int = 42,
        threads: int = 1,
    ) -> None:
        if window < 1 or hidden < 1 or max_epochs < 1 or patience <= 1:
            raise ValueError("window, hidden, max_epochs and patience must be positive")
        self.columns = list(columns)
        self.time_column = time_column
        self.window, self.hidden = window, hidden
        self.max_epochs, self.patience = max_epochs, patience
        self.batch_size, self.learning_rate = batch_size, learning_rate
        self.fit_rows, self.validation_rows = fit_rows, validation_rows
        self.seed, self.threads = seed, threads
        self.center_: np.ndarray | None = None
        self.scale_: np.ndarray | None = None
        self.threshold_: float | None = None
        self._net: _Network | None = None
        self._history: dict[str, Any] = {}
        self._validation: torch.Tensor | None = None
    def xǁLSTMAutoencoderǁ__init____mutmut_21(
        self,
        columns: list[str],
        time_column: str,
        *,
        window: int = 10,
        hidden: int = 32,
        max_epochs: int = 20,
        patience: int = 3,
        batch_size: int = 256,
        learning_rate: float = 1e-3,
        fit_rows: int = 50_000,
        validation_rows: int = 20_000,
        seed: int = 42,
        threads: int = 1,
    ) -> None:
        if window < 1 or hidden < 1 or max_epochs < 1 or patience < 2:
            raise ValueError("window, hidden, max_epochs and patience must be positive")
        self.columns = list(columns)
        self.time_column = time_column
        self.window, self.hidden = window, hidden
        self.max_epochs, self.patience = max_epochs, patience
        self.batch_size, self.learning_rate = batch_size, learning_rate
        self.fit_rows, self.validation_rows = fit_rows, validation_rows
        self.seed, self.threads = seed, threads
        self.center_: np.ndarray | None = None
        self.scale_: np.ndarray | None = None
        self.threshold_: float | None = None
        self._net: _Network | None = None
        self._history: dict[str, Any] = {}
        self._validation: torch.Tensor | None = None
    def xǁLSTMAutoencoderǁ__init____mutmut_22(
        self,
        columns: list[str],
        time_column: str,
        *,
        window: int = 10,
        hidden: int = 32,
        max_epochs: int = 20,
        patience: int = 3,
        batch_size: int = 256,
        learning_rate: float = 1e-3,
        fit_rows: int = 50_000,
        validation_rows: int = 20_000,
        seed: int = 42,
        threads: int = 1,
    ) -> None:
        if window < 1 or hidden < 1 or max_epochs < 1 or patience < 1:
            raise ValueError(None)
        self.columns = list(columns)
        self.time_column = time_column
        self.window, self.hidden = window, hidden
        self.max_epochs, self.patience = max_epochs, patience
        self.batch_size, self.learning_rate = batch_size, learning_rate
        self.fit_rows, self.validation_rows = fit_rows, validation_rows
        self.seed, self.threads = seed, threads
        self.center_: np.ndarray | None = None
        self.scale_: np.ndarray | None = None
        self.threshold_: float | None = None
        self._net: _Network | None = None
        self._history: dict[str, Any] = {}
        self._validation: torch.Tensor | None = None
    def xǁLSTMAutoencoderǁ__init____mutmut_23(
        self,
        columns: list[str],
        time_column: str,
        *,
        window: int = 10,
        hidden: int = 32,
        max_epochs: int = 20,
        patience: int = 3,
        batch_size: int = 256,
        learning_rate: float = 1e-3,
        fit_rows: int = 50_000,
        validation_rows: int = 20_000,
        seed: int = 42,
        threads: int = 1,
    ) -> None:
        if window < 1 or hidden < 1 or max_epochs < 1 or patience < 1:
            raise ValueError("XXwindow, hidden, max_epochs and patience must be positiveXX")
        self.columns = list(columns)
        self.time_column = time_column
        self.window, self.hidden = window, hidden
        self.max_epochs, self.patience = max_epochs, patience
        self.batch_size, self.learning_rate = batch_size, learning_rate
        self.fit_rows, self.validation_rows = fit_rows, validation_rows
        self.seed, self.threads = seed, threads
        self.center_: np.ndarray | None = None
        self.scale_: np.ndarray | None = None
        self.threshold_: float | None = None
        self._net: _Network | None = None
        self._history: dict[str, Any] = {}
        self._validation: torch.Tensor | None = None
    def xǁLSTMAutoencoderǁ__init____mutmut_24(
        self,
        columns: list[str],
        time_column: str,
        *,
        window: int = 10,
        hidden: int = 32,
        max_epochs: int = 20,
        patience: int = 3,
        batch_size: int = 256,
        learning_rate: float = 1e-3,
        fit_rows: int = 50_000,
        validation_rows: int = 20_000,
        seed: int = 42,
        threads: int = 1,
    ) -> None:
        if window < 1 or hidden < 1 or max_epochs < 1 or patience < 1:
            raise ValueError("WINDOW, HIDDEN, MAX_EPOCHS AND PATIENCE MUST BE POSITIVE")
        self.columns = list(columns)
        self.time_column = time_column
        self.window, self.hidden = window, hidden
        self.max_epochs, self.patience = max_epochs, patience
        self.batch_size, self.learning_rate = batch_size, learning_rate
        self.fit_rows, self.validation_rows = fit_rows, validation_rows
        self.seed, self.threads = seed, threads
        self.center_: np.ndarray | None = None
        self.scale_: np.ndarray | None = None
        self.threshold_: float | None = None
        self._net: _Network | None = None
        self._history: dict[str, Any] = {}
        self._validation: torch.Tensor | None = None
    def xǁLSTMAutoencoderǁ__init____mutmut_25(
        self,
        columns: list[str],
        time_column: str,
        *,
        window: int = 10,
        hidden: int = 32,
        max_epochs: int = 20,
        patience: int = 3,
        batch_size: int = 256,
        learning_rate: float = 1e-3,
        fit_rows: int = 50_000,
        validation_rows: int = 20_000,
        seed: int = 42,
        threads: int = 1,
    ) -> None:
        if window < 1 or hidden < 1 or max_epochs < 1 or patience < 1:
            raise ValueError("window, hidden, max_epochs and patience must be positive")
        self.columns = None
        self.time_column = time_column
        self.window, self.hidden = window, hidden
        self.max_epochs, self.patience = max_epochs, patience
        self.batch_size, self.learning_rate = batch_size, learning_rate
        self.fit_rows, self.validation_rows = fit_rows, validation_rows
        self.seed, self.threads = seed, threads
        self.center_: np.ndarray | None = None
        self.scale_: np.ndarray | None = None
        self.threshold_: float | None = None
        self._net: _Network | None = None
        self._history: dict[str, Any] = {}
        self._validation: torch.Tensor | None = None
    def xǁLSTMAutoencoderǁ__init____mutmut_26(
        self,
        columns: list[str],
        time_column: str,
        *,
        window: int = 10,
        hidden: int = 32,
        max_epochs: int = 20,
        patience: int = 3,
        batch_size: int = 256,
        learning_rate: float = 1e-3,
        fit_rows: int = 50_000,
        validation_rows: int = 20_000,
        seed: int = 42,
        threads: int = 1,
    ) -> None:
        if window < 1 or hidden < 1 or max_epochs < 1 or patience < 1:
            raise ValueError("window, hidden, max_epochs and patience must be positive")
        self.columns = list(None)
        self.time_column = time_column
        self.window, self.hidden = window, hidden
        self.max_epochs, self.patience = max_epochs, patience
        self.batch_size, self.learning_rate = batch_size, learning_rate
        self.fit_rows, self.validation_rows = fit_rows, validation_rows
        self.seed, self.threads = seed, threads
        self.center_: np.ndarray | None = None
        self.scale_: np.ndarray | None = None
        self.threshold_: float | None = None
        self._net: _Network | None = None
        self._history: dict[str, Any] = {}
        self._validation: torch.Tensor | None = None
    def xǁLSTMAutoencoderǁ__init____mutmut_27(
        self,
        columns: list[str],
        time_column: str,
        *,
        window: int = 10,
        hidden: int = 32,
        max_epochs: int = 20,
        patience: int = 3,
        batch_size: int = 256,
        learning_rate: float = 1e-3,
        fit_rows: int = 50_000,
        validation_rows: int = 20_000,
        seed: int = 42,
        threads: int = 1,
    ) -> None:
        if window < 1 or hidden < 1 or max_epochs < 1 or patience < 1:
            raise ValueError("window, hidden, max_epochs and patience must be positive")
        self.columns = list(columns)
        self.time_column = None
        self.window, self.hidden = window, hidden
        self.max_epochs, self.patience = max_epochs, patience
        self.batch_size, self.learning_rate = batch_size, learning_rate
        self.fit_rows, self.validation_rows = fit_rows, validation_rows
        self.seed, self.threads = seed, threads
        self.center_: np.ndarray | None = None
        self.scale_: np.ndarray | None = None
        self.threshold_: float | None = None
        self._net: _Network | None = None
        self._history: dict[str, Any] = {}
        self._validation: torch.Tensor | None = None
    def xǁLSTMAutoencoderǁ__init____mutmut_28(
        self,
        columns: list[str],
        time_column: str,
        *,
        window: int = 10,
        hidden: int = 32,
        max_epochs: int = 20,
        patience: int = 3,
        batch_size: int = 256,
        learning_rate: float = 1e-3,
        fit_rows: int = 50_000,
        validation_rows: int = 20_000,
        seed: int = 42,
        threads: int = 1,
    ) -> None:
        if window < 1 or hidden < 1 or max_epochs < 1 or patience < 1:
            raise ValueError("window, hidden, max_epochs and patience must be positive")
        self.columns = list(columns)
        self.time_column = time_column
        self.window, self.hidden = None
        self.max_epochs, self.patience = max_epochs, patience
        self.batch_size, self.learning_rate = batch_size, learning_rate
        self.fit_rows, self.validation_rows = fit_rows, validation_rows
        self.seed, self.threads = seed, threads
        self.center_: np.ndarray | None = None
        self.scale_: np.ndarray | None = None
        self.threshold_: float | None = None
        self._net: _Network | None = None
        self._history: dict[str, Any] = {}
        self._validation: torch.Tensor | None = None
    def xǁLSTMAutoencoderǁ__init____mutmut_29(
        self,
        columns: list[str],
        time_column: str,
        *,
        window: int = 10,
        hidden: int = 32,
        max_epochs: int = 20,
        patience: int = 3,
        batch_size: int = 256,
        learning_rate: float = 1e-3,
        fit_rows: int = 50_000,
        validation_rows: int = 20_000,
        seed: int = 42,
        threads: int = 1,
    ) -> None:
        if window < 1 or hidden < 1 or max_epochs < 1 or patience < 1:
            raise ValueError("window, hidden, max_epochs and patience must be positive")
        self.columns = list(columns)
        self.time_column = time_column
        self.window, self.hidden = window, hidden
        self.max_epochs, self.patience = None
        self.batch_size, self.learning_rate = batch_size, learning_rate
        self.fit_rows, self.validation_rows = fit_rows, validation_rows
        self.seed, self.threads = seed, threads
        self.center_: np.ndarray | None = None
        self.scale_: np.ndarray | None = None
        self.threshold_: float | None = None
        self._net: _Network | None = None
        self._history: dict[str, Any] = {}
        self._validation: torch.Tensor | None = None
    def xǁLSTMAutoencoderǁ__init____mutmut_30(
        self,
        columns: list[str],
        time_column: str,
        *,
        window: int = 10,
        hidden: int = 32,
        max_epochs: int = 20,
        patience: int = 3,
        batch_size: int = 256,
        learning_rate: float = 1e-3,
        fit_rows: int = 50_000,
        validation_rows: int = 20_000,
        seed: int = 42,
        threads: int = 1,
    ) -> None:
        if window < 1 or hidden < 1 or max_epochs < 1 or patience < 1:
            raise ValueError("window, hidden, max_epochs and patience must be positive")
        self.columns = list(columns)
        self.time_column = time_column
        self.window, self.hidden = window, hidden
        self.max_epochs, self.patience = max_epochs, patience
        self.batch_size, self.learning_rate = None
        self.fit_rows, self.validation_rows = fit_rows, validation_rows
        self.seed, self.threads = seed, threads
        self.center_: np.ndarray | None = None
        self.scale_: np.ndarray | None = None
        self.threshold_: float | None = None
        self._net: _Network | None = None
        self._history: dict[str, Any] = {}
        self._validation: torch.Tensor | None = None
    def xǁLSTMAutoencoderǁ__init____mutmut_31(
        self,
        columns: list[str],
        time_column: str,
        *,
        window: int = 10,
        hidden: int = 32,
        max_epochs: int = 20,
        patience: int = 3,
        batch_size: int = 256,
        learning_rate: float = 1e-3,
        fit_rows: int = 50_000,
        validation_rows: int = 20_000,
        seed: int = 42,
        threads: int = 1,
    ) -> None:
        if window < 1 or hidden < 1 or max_epochs < 1 or patience < 1:
            raise ValueError("window, hidden, max_epochs and patience must be positive")
        self.columns = list(columns)
        self.time_column = time_column
        self.window, self.hidden = window, hidden
        self.max_epochs, self.patience = max_epochs, patience
        self.batch_size, self.learning_rate = batch_size, learning_rate
        self.fit_rows, self.validation_rows = None
        self.seed, self.threads = seed, threads
        self.center_: np.ndarray | None = None
        self.scale_: np.ndarray | None = None
        self.threshold_: float | None = None
        self._net: _Network | None = None
        self._history: dict[str, Any] = {}
        self._validation: torch.Tensor | None = None
    def xǁLSTMAutoencoderǁ__init____mutmut_32(
        self,
        columns: list[str],
        time_column: str,
        *,
        window: int = 10,
        hidden: int = 32,
        max_epochs: int = 20,
        patience: int = 3,
        batch_size: int = 256,
        learning_rate: float = 1e-3,
        fit_rows: int = 50_000,
        validation_rows: int = 20_000,
        seed: int = 42,
        threads: int = 1,
    ) -> None:
        if window < 1 or hidden < 1 or max_epochs < 1 or patience < 1:
            raise ValueError("window, hidden, max_epochs and patience must be positive")
        self.columns = list(columns)
        self.time_column = time_column
        self.window, self.hidden = window, hidden
        self.max_epochs, self.patience = max_epochs, patience
        self.batch_size, self.learning_rate = batch_size, learning_rate
        self.fit_rows, self.validation_rows = fit_rows, validation_rows
        self.seed, self.threads = None
        self.center_: np.ndarray | None = None
        self.scale_: np.ndarray | None = None
        self.threshold_: float | None = None
        self._net: _Network | None = None
        self._history: dict[str, Any] = {}
        self._validation: torch.Tensor | None = None
    def xǁLSTMAutoencoderǁ__init____mutmut_33(
        self,
        columns: list[str],
        time_column: str,
        *,
        window: int = 10,
        hidden: int = 32,
        max_epochs: int = 20,
        patience: int = 3,
        batch_size: int = 256,
        learning_rate: float = 1e-3,
        fit_rows: int = 50_000,
        validation_rows: int = 20_000,
        seed: int = 42,
        threads: int = 1,
    ) -> None:
        if window < 1 or hidden < 1 or max_epochs < 1 or patience < 1:
            raise ValueError("window, hidden, max_epochs and patience must be positive")
        self.columns = list(columns)
        self.time_column = time_column
        self.window, self.hidden = window, hidden
        self.max_epochs, self.patience = max_epochs, patience
        self.batch_size, self.learning_rate = batch_size, learning_rate
        self.fit_rows, self.validation_rows = fit_rows, validation_rows
        self.seed, self.threads = seed, threads
        self.center_: np.ndarray | None = ""
        self.scale_: np.ndarray | None = None
        self.threshold_: float | None = None
        self._net: _Network | None = None
        self._history: dict[str, Any] = {}
        self._validation: torch.Tensor | None = None
    def xǁLSTMAutoencoderǁ__init____mutmut_34(
        self,
        columns: list[str],
        time_column: str,
        *,
        window: int = 10,
        hidden: int = 32,
        max_epochs: int = 20,
        patience: int = 3,
        batch_size: int = 256,
        learning_rate: float = 1e-3,
        fit_rows: int = 50_000,
        validation_rows: int = 20_000,
        seed: int = 42,
        threads: int = 1,
    ) -> None:
        if window < 1 or hidden < 1 or max_epochs < 1 or patience < 1:
            raise ValueError("window, hidden, max_epochs and patience must be positive")
        self.columns = list(columns)
        self.time_column = time_column
        self.window, self.hidden = window, hidden
        self.max_epochs, self.patience = max_epochs, patience
        self.batch_size, self.learning_rate = batch_size, learning_rate
        self.fit_rows, self.validation_rows = fit_rows, validation_rows
        self.seed, self.threads = seed, threads
        self.center_: np.ndarray | None = None
        self.scale_: np.ndarray | None = ""
        self.threshold_: float | None = None
        self._net: _Network | None = None
        self._history: dict[str, Any] = {}
        self._validation: torch.Tensor | None = None
    def xǁLSTMAutoencoderǁ__init____mutmut_35(
        self,
        columns: list[str],
        time_column: str,
        *,
        window: int = 10,
        hidden: int = 32,
        max_epochs: int = 20,
        patience: int = 3,
        batch_size: int = 256,
        learning_rate: float = 1e-3,
        fit_rows: int = 50_000,
        validation_rows: int = 20_000,
        seed: int = 42,
        threads: int = 1,
    ) -> None:
        if window < 1 or hidden < 1 or max_epochs < 1 or patience < 1:
            raise ValueError("window, hidden, max_epochs and patience must be positive")
        self.columns = list(columns)
        self.time_column = time_column
        self.window, self.hidden = window, hidden
        self.max_epochs, self.patience = max_epochs, patience
        self.batch_size, self.learning_rate = batch_size, learning_rate
        self.fit_rows, self.validation_rows = fit_rows, validation_rows
        self.seed, self.threads = seed, threads
        self.center_: np.ndarray | None = None
        self.scale_: np.ndarray | None = None
        self.threshold_: float | None = ""
        self._net: _Network | None = None
        self._history: dict[str, Any] = {}
        self._validation: torch.Tensor | None = None
    def xǁLSTMAutoencoderǁ__init____mutmut_36(
        self,
        columns: list[str],
        time_column: str,
        *,
        window: int = 10,
        hidden: int = 32,
        max_epochs: int = 20,
        patience: int = 3,
        batch_size: int = 256,
        learning_rate: float = 1e-3,
        fit_rows: int = 50_000,
        validation_rows: int = 20_000,
        seed: int = 42,
        threads: int = 1,
    ) -> None:
        if window < 1 or hidden < 1 or max_epochs < 1 or patience < 1:
            raise ValueError("window, hidden, max_epochs and patience must be positive")
        self.columns = list(columns)
        self.time_column = time_column
        self.window, self.hidden = window, hidden
        self.max_epochs, self.patience = max_epochs, patience
        self.batch_size, self.learning_rate = batch_size, learning_rate
        self.fit_rows, self.validation_rows = fit_rows, validation_rows
        self.seed, self.threads = seed, threads
        self.center_: np.ndarray | None = None
        self.scale_: np.ndarray | None = None
        self.threshold_: float | None = None
        self._net: _Network | None = ""
        self._history: dict[str, Any] = {}
        self._validation: torch.Tensor | None = None
    def xǁLSTMAutoencoderǁ__init____mutmut_37(
        self,
        columns: list[str],
        time_column: str,
        *,
        window: int = 10,
        hidden: int = 32,
        max_epochs: int = 20,
        patience: int = 3,
        batch_size: int = 256,
        learning_rate: float = 1e-3,
        fit_rows: int = 50_000,
        validation_rows: int = 20_000,
        seed: int = 42,
        threads: int = 1,
    ) -> None:
        if window < 1 or hidden < 1 or max_epochs < 1 or patience < 1:
            raise ValueError("window, hidden, max_epochs and patience must be positive")
        self.columns = list(columns)
        self.time_column = time_column
        self.window, self.hidden = window, hidden
        self.max_epochs, self.patience = max_epochs, patience
        self.batch_size, self.learning_rate = batch_size, learning_rate
        self.fit_rows, self.validation_rows = fit_rows, validation_rows
        self.seed, self.threads = seed, threads
        self.center_: np.ndarray | None = None
        self.scale_: np.ndarray | None = None
        self.threshold_: float | None = None
        self._net: _Network | None = None
        self._history: dict[str, Any] = None
        self._validation: torch.Tensor | None = None
    def xǁLSTMAutoencoderǁ__init____mutmut_38(
        self,
        columns: list[str],
        time_column: str,
        *,
        window: int = 10,
        hidden: int = 32,
        max_epochs: int = 20,
        patience: int = 3,
        batch_size: int = 256,
        learning_rate: float = 1e-3,
        fit_rows: int = 50_000,
        validation_rows: int = 20_000,
        seed: int = 42,
        threads: int = 1,
    ) -> None:
        if window < 1 or hidden < 1 or max_epochs < 1 or patience < 1:
            raise ValueError("window, hidden, max_epochs and patience must be positive")
        self.columns = list(columns)
        self.time_column = time_column
        self.window, self.hidden = window, hidden
        self.max_epochs, self.patience = max_epochs, patience
        self.batch_size, self.learning_rate = batch_size, learning_rate
        self.fit_rows, self.validation_rows = fit_rows, validation_rows
        self.seed, self.threads = seed, threads
        self.center_: np.ndarray | None = None
        self.scale_: np.ndarray | None = None
        self.threshold_: float | None = None
        self._net: _Network | None = None
        self._history: dict[str, Any] = {}
        self._validation: torch.Tensor | None = ""

    # -- data ---------------------------------------------------------------------------
    @_mutmut_mutated(mutants_xǁLSTMAutoencoderǁ_windows__mutmut)
    def _windows(self, frame: pd.DataFrame) -> tuple[np.ndarray, np.ndarray]:
        values = frame[self.columns].astype(float).to_numpy()
        values = np.where(np.isnan(values), self.center_, values)
        scaled = pd.DataFrame((values - self.center_) / self.scale_, columns=self.columns)
        scaled[self.time_column] = frame[self.time_column].to_numpy()
        return causal_windows(scaled, self.time_column, self.columns, self.window)

    # -- data ---------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁ_windows__mutmut_orig(self, frame: pd.DataFrame) -> tuple[np.ndarray, np.ndarray]:
        values = frame[self.columns].astype(float).to_numpy()
        values = np.where(np.isnan(values), self.center_, values)
        scaled = pd.DataFrame((values - self.center_) / self.scale_, columns=self.columns)
        scaled[self.time_column] = frame[self.time_column].to_numpy()
        return causal_windows(scaled, self.time_column, self.columns, self.window)

    # -- data ---------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁ_windows__mutmut_1(self, frame: pd.DataFrame) -> tuple[np.ndarray, np.ndarray]:
        values = None
        values = np.where(np.isnan(values), self.center_, values)
        scaled = pd.DataFrame((values - self.center_) / self.scale_, columns=self.columns)
        scaled[self.time_column] = frame[self.time_column].to_numpy()
        return causal_windows(scaled, self.time_column, self.columns, self.window)

    # -- data ---------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁ_windows__mutmut_2(self, frame: pd.DataFrame) -> tuple[np.ndarray, np.ndarray]:
        values = frame[self.columns].astype(None).to_numpy()
        values = np.where(np.isnan(values), self.center_, values)
        scaled = pd.DataFrame((values - self.center_) / self.scale_, columns=self.columns)
        scaled[self.time_column] = frame[self.time_column].to_numpy()
        return causal_windows(scaled, self.time_column, self.columns, self.window)

    # -- data ---------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁ_windows__mutmut_3(self, frame: pd.DataFrame) -> tuple[np.ndarray, np.ndarray]:
        values = frame[self.columns].astype(float).to_numpy()
        values = None
        scaled = pd.DataFrame((values - self.center_) / self.scale_, columns=self.columns)
        scaled[self.time_column] = frame[self.time_column].to_numpy()
        return causal_windows(scaled, self.time_column, self.columns, self.window)

    # -- data ---------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁ_windows__mutmut_4(self, frame: pd.DataFrame) -> tuple[np.ndarray, np.ndarray]:
        values = frame[self.columns].astype(float).to_numpy()
        values = np.where(None, self.center_, values)
        scaled = pd.DataFrame((values - self.center_) / self.scale_, columns=self.columns)
        scaled[self.time_column] = frame[self.time_column].to_numpy()
        return causal_windows(scaled, self.time_column, self.columns, self.window)

    # -- data ---------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁ_windows__mutmut_5(self, frame: pd.DataFrame) -> tuple[np.ndarray, np.ndarray]:
        values = frame[self.columns].astype(float).to_numpy()
        values = np.where(np.isnan(values), None, values)
        scaled = pd.DataFrame((values - self.center_) / self.scale_, columns=self.columns)
        scaled[self.time_column] = frame[self.time_column].to_numpy()
        return causal_windows(scaled, self.time_column, self.columns, self.window)

    # -- data ---------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁ_windows__mutmut_6(self, frame: pd.DataFrame) -> tuple[np.ndarray, np.ndarray]:
        values = frame[self.columns].astype(float).to_numpy()
        values = np.where(np.isnan(values), self.center_, None)
        scaled = pd.DataFrame((values - self.center_) / self.scale_, columns=self.columns)
        scaled[self.time_column] = frame[self.time_column].to_numpy()
        return causal_windows(scaled, self.time_column, self.columns, self.window)

    # -- data ---------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁ_windows__mutmut_7(self, frame: pd.DataFrame) -> tuple[np.ndarray, np.ndarray]:
        values = frame[self.columns].astype(float).to_numpy()
        values = np.where(self.center_, values)
        scaled = pd.DataFrame((values - self.center_) / self.scale_, columns=self.columns)
        scaled[self.time_column] = frame[self.time_column].to_numpy()
        return causal_windows(scaled, self.time_column, self.columns, self.window)

    # -- data ---------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁ_windows__mutmut_8(self, frame: pd.DataFrame) -> tuple[np.ndarray, np.ndarray]:
        values = frame[self.columns].astype(float).to_numpy()
        values = np.where(np.isnan(values), values)
        scaled = pd.DataFrame((values - self.center_) / self.scale_, columns=self.columns)
        scaled[self.time_column] = frame[self.time_column].to_numpy()
        return causal_windows(scaled, self.time_column, self.columns, self.window)

    # -- data ---------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁ_windows__mutmut_9(self, frame: pd.DataFrame) -> tuple[np.ndarray, np.ndarray]:
        values = frame[self.columns].astype(float).to_numpy()
        values = np.where(np.isnan(values), self.center_, )
        scaled = pd.DataFrame((values - self.center_) / self.scale_, columns=self.columns)
        scaled[self.time_column] = frame[self.time_column].to_numpy()
        return causal_windows(scaled, self.time_column, self.columns, self.window)

    # -- data ---------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁ_windows__mutmut_10(self, frame: pd.DataFrame) -> tuple[np.ndarray, np.ndarray]:
        values = frame[self.columns].astype(float).to_numpy()
        values = np.where(np.isnan(None), self.center_, values)
        scaled = pd.DataFrame((values - self.center_) / self.scale_, columns=self.columns)
        scaled[self.time_column] = frame[self.time_column].to_numpy()
        return causal_windows(scaled, self.time_column, self.columns, self.window)

    # -- data ---------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁ_windows__mutmut_11(self, frame: pd.DataFrame) -> tuple[np.ndarray, np.ndarray]:
        values = frame[self.columns].astype(float).to_numpy()
        values = np.where(np.isnan(values), self.center_, values)
        scaled = None
        scaled[self.time_column] = frame[self.time_column].to_numpy()
        return causal_windows(scaled, self.time_column, self.columns, self.window)

    # -- data ---------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁ_windows__mutmut_12(self, frame: pd.DataFrame) -> tuple[np.ndarray, np.ndarray]:
        values = frame[self.columns].astype(float).to_numpy()
        values = np.where(np.isnan(values), self.center_, values)
        scaled = pd.DataFrame(None, columns=self.columns)
        scaled[self.time_column] = frame[self.time_column].to_numpy()
        return causal_windows(scaled, self.time_column, self.columns, self.window)

    # -- data ---------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁ_windows__mutmut_13(self, frame: pd.DataFrame) -> tuple[np.ndarray, np.ndarray]:
        values = frame[self.columns].astype(float).to_numpy()
        values = np.where(np.isnan(values), self.center_, values)
        scaled = pd.DataFrame((values - self.center_) / self.scale_, columns=None)
        scaled[self.time_column] = frame[self.time_column].to_numpy()
        return causal_windows(scaled, self.time_column, self.columns, self.window)

    # -- data ---------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁ_windows__mutmut_14(self, frame: pd.DataFrame) -> tuple[np.ndarray, np.ndarray]:
        values = frame[self.columns].astype(float).to_numpy()
        values = np.where(np.isnan(values), self.center_, values)
        scaled = pd.DataFrame(columns=self.columns)
        scaled[self.time_column] = frame[self.time_column].to_numpy()
        return causal_windows(scaled, self.time_column, self.columns, self.window)

    # -- data ---------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁ_windows__mutmut_15(self, frame: pd.DataFrame) -> tuple[np.ndarray, np.ndarray]:
        values = frame[self.columns].astype(float).to_numpy()
        values = np.where(np.isnan(values), self.center_, values)
        scaled = pd.DataFrame((values - self.center_) / self.scale_, )
        scaled[self.time_column] = frame[self.time_column].to_numpy()
        return causal_windows(scaled, self.time_column, self.columns, self.window)

    # -- data ---------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁ_windows__mutmut_16(self, frame: pd.DataFrame) -> tuple[np.ndarray, np.ndarray]:
        values = frame[self.columns].astype(float).to_numpy()
        values = np.where(np.isnan(values), self.center_, values)
        scaled = pd.DataFrame((values - self.center_) * self.scale_, columns=self.columns)
        scaled[self.time_column] = frame[self.time_column].to_numpy()
        return causal_windows(scaled, self.time_column, self.columns, self.window)

    # -- data ---------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁ_windows__mutmut_17(self, frame: pd.DataFrame) -> tuple[np.ndarray, np.ndarray]:
        values = frame[self.columns].astype(float).to_numpy()
        values = np.where(np.isnan(values), self.center_, values)
        scaled = pd.DataFrame((values + self.center_) / self.scale_, columns=self.columns)
        scaled[self.time_column] = frame[self.time_column].to_numpy()
        return causal_windows(scaled, self.time_column, self.columns, self.window)

    # -- data ---------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁ_windows__mutmut_18(self, frame: pd.DataFrame) -> tuple[np.ndarray, np.ndarray]:
        values = frame[self.columns].astype(float).to_numpy()
        values = np.where(np.isnan(values), self.center_, values)
        scaled = pd.DataFrame((values - self.center_) / self.scale_, columns=self.columns)
        scaled[self.time_column] = None
        return causal_windows(scaled, self.time_column, self.columns, self.window)

    # -- data ---------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁ_windows__mutmut_19(self, frame: pd.DataFrame) -> tuple[np.ndarray, np.ndarray]:
        values = frame[self.columns].astype(float).to_numpy()
        values = np.where(np.isnan(values), self.center_, values)
        scaled = pd.DataFrame((values - self.center_) / self.scale_, columns=self.columns)
        scaled[self.time_column] = frame[self.time_column].to_numpy()
        return causal_windows(None, self.time_column, self.columns, self.window)

    # -- data ---------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁ_windows__mutmut_20(self, frame: pd.DataFrame) -> tuple[np.ndarray, np.ndarray]:
        values = frame[self.columns].astype(float).to_numpy()
        values = np.where(np.isnan(values), self.center_, values)
        scaled = pd.DataFrame((values - self.center_) / self.scale_, columns=self.columns)
        scaled[self.time_column] = frame[self.time_column].to_numpy()
        return causal_windows(scaled, None, self.columns, self.window)

    # -- data ---------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁ_windows__mutmut_21(self, frame: pd.DataFrame) -> tuple[np.ndarray, np.ndarray]:
        values = frame[self.columns].astype(float).to_numpy()
        values = np.where(np.isnan(values), self.center_, values)
        scaled = pd.DataFrame((values - self.center_) / self.scale_, columns=self.columns)
        scaled[self.time_column] = frame[self.time_column].to_numpy()
        return causal_windows(scaled, self.time_column, None, self.window)

    # -- data ---------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁ_windows__mutmut_22(self, frame: pd.DataFrame) -> tuple[np.ndarray, np.ndarray]:
        values = frame[self.columns].astype(float).to_numpy()
        values = np.where(np.isnan(values), self.center_, values)
        scaled = pd.DataFrame((values - self.center_) / self.scale_, columns=self.columns)
        scaled[self.time_column] = frame[self.time_column].to_numpy()
        return causal_windows(scaled, self.time_column, self.columns, None)

    # -- data ---------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁ_windows__mutmut_23(self, frame: pd.DataFrame) -> tuple[np.ndarray, np.ndarray]:
        values = frame[self.columns].astype(float).to_numpy()
        values = np.where(np.isnan(values), self.center_, values)
        scaled = pd.DataFrame((values - self.center_) / self.scale_, columns=self.columns)
        scaled[self.time_column] = frame[self.time_column].to_numpy()
        return causal_windows(self.time_column, self.columns, self.window)

    # -- data ---------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁ_windows__mutmut_24(self, frame: pd.DataFrame) -> tuple[np.ndarray, np.ndarray]:
        values = frame[self.columns].astype(float).to_numpy()
        values = np.where(np.isnan(values), self.center_, values)
        scaled = pd.DataFrame((values - self.center_) / self.scale_, columns=self.columns)
        scaled[self.time_column] = frame[self.time_column].to_numpy()
        return causal_windows(scaled, self.columns, self.window)

    # -- data ---------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁ_windows__mutmut_25(self, frame: pd.DataFrame) -> tuple[np.ndarray, np.ndarray]:
        values = frame[self.columns].astype(float).to_numpy()
        values = np.where(np.isnan(values), self.center_, values)
        scaled = pd.DataFrame((values - self.center_) / self.scale_, columns=self.columns)
        scaled[self.time_column] = frame[self.time_column].to_numpy()
        return causal_windows(scaled, self.time_column, self.window)

    # -- data ---------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁ_windows__mutmut_26(self, frame: pd.DataFrame) -> tuple[np.ndarray, np.ndarray]:
        values = frame[self.columns].astype(float).to_numpy()
        values = np.where(np.isnan(values), self.center_, values)
        scaled = pd.DataFrame((values - self.center_) / self.scale_, columns=self.columns)
        scaled[self.time_column] = frame[self.time_column].to_numpy()
        return causal_windows(scaled, self.time_column, self.columns, )

    @_mutmut_mutated(mutants_xǁLSTMAutoencoderǁ_reconstruction_error__mutmut)
    def _reconstruction_error(self, windows: np.ndarray, last_only: bool) -> np.ndarray:
        assert self._net is not None
        self._net.eval()
        out = []
        with torch.no_grad():
            for start in range(0, len(windows), 2048):
                batch = torch.as_tensor(windows[start : start + 2048], dtype=torch.float32)
                error = (self._net(batch) - batch) ** 2
                out.append(
                    (error[:, -1] if last_only else error).mean(dim=-1 if last_only else (1, 2))
                )
        return torch.cat(out).numpy().astype(float)

    def xǁLSTMAutoencoderǁ_reconstruction_error__mutmut_orig(self, windows: np.ndarray, last_only: bool) -> np.ndarray:
        assert self._net is not None
        self._net.eval()
        out = []
        with torch.no_grad():
            for start in range(0, len(windows), 2048):
                batch = torch.as_tensor(windows[start : start + 2048], dtype=torch.float32)
                error = (self._net(batch) - batch) ** 2
                out.append(
                    (error[:, -1] if last_only else error).mean(dim=-1 if last_only else (1, 2))
                )
        return torch.cat(out).numpy().astype(float)

    def xǁLSTMAutoencoderǁ_reconstruction_error__mutmut_1(self, windows: np.ndarray, last_only: bool) -> np.ndarray:
        assert self._net is None
        self._net.eval()
        out = []
        with torch.no_grad():
            for start in range(0, len(windows), 2048):
                batch = torch.as_tensor(windows[start : start + 2048], dtype=torch.float32)
                error = (self._net(batch) - batch) ** 2
                out.append(
                    (error[:, -1] if last_only else error).mean(dim=-1 if last_only else (1, 2))
                )
        return torch.cat(out).numpy().astype(float)

    def xǁLSTMAutoencoderǁ_reconstruction_error__mutmut_2(self, windows: np.ndarray, last_only: bool) -> np.ndarray:
        assert self._net is not None
        self._net.eval()
        out = None
        with torch.no_grad():
            for start in range(0, len(windows), 2048):
                batch = torch.as_tensor(windows[start : start + 2048], dtype=torch.float32)
                error = (self._net(batch) - batch) ** 2
                out.append(
                    (error[:, -1] if last_only else error).mean(dim=-1 if last_only else (1, 2))
                )
        return torch.cat(out).numpy().astype(float)

    def xǁLSTMAutoencoderǁ_reconstruction_error__mutmut_3(self, windows: np.ndarray, last_only: bool) -> np.ndarray:
        assert self._net is not None
        self._net.eval()
        out = []
        with torch.no_grad():
            for start in range(None, len(windows), 2048):
                batch = torch.as_tensor(windows[start : start + 2048], dtype=torch.float32)
                error = (self._net(batch) - batch) ** 2
                out.append(
                    (error[:, -1] if last_only else error).mean(dim=-1 if last_only else (1, 2))
                )
        return torch.cat(out).numpy().astype(float)

    def xǁLSTMAutoencoderǁ_reconstruction_error__mutmut_4(self, windows: np.ndarray, last_only: bool) -> np.ndarray:
        assert self._net is not None
        self._net.eval()
        out = []
        with torch.no_grad():
            for start in range(0, None, 2048):
                batch = torch.as_tensor(windows[start : start + 2048], dtype=torch.float32)
                error = (self._net(batch) - batch) ** 2
                out.append(
                    (error[:, -1] if last_only else error).mean(dim=-1 if last_only else (1, 2))
                )
        return torch.cat(out).numpy().astype(float)

    def xǁLSTMAutoencoderǁ_reconstruction_error__mutmut_5(self, windows: np.ndarray, last_only: bool) -> np.ndarray:
        assert self._net is not None
        self._net.eval()
        out = []
        with torch.no_grad():
            for start in range(0, len(windows), None):
                batch = torch.as_tensor(windows[start : start + 2048], dtype=torch.float32)
                error = (self._net(batch) - batch) ** 2
                out.append(
                    (error[:, -1] if last_only else error).mean(dim=-1 if last_only else (1, 2))
                )
        return torch.cat(out).numpy().astype(float)

    def xǁLSTMAutoencoderǁ_reconstruction_error__mutmut_6(self, windows: np.ndarray, last_only: bool) -> np.ndarray:
        assert self._net is not None
        self._net.eval()
        out = []
        with torch.no_grad():
            for start in range(len(windows), 2048):
                batch = torch.as_tensor(windows[start : start + 2048], dtype=torch.float32)
                error = (self._net(batch) - batch) ** 2
                out.append(
                    (error[:, -1] if last_only else error).mean(dim=-1 if last_only else (1, 2))
                )
        return torch.cat(out).numpy().astype(float)

    def xǁLSTMAutoencoderǁ_reconstruction_error__mutmut_7(self, windows: np.ndarray, last_only: bool) -> np.ndarray:
        assert self._net is not None
        self._net.eval()
        out = []
        with torch.no_grad():
            for start in range(0, 2048):
                batch = torch.as_tensor(windows[start : start + 2048], dtype=torch.float32)
                error = (self._net(batch) - batch) ** 2
                out.append(
                    (error[:, -1] if last_only else error).mean(dim=-1 if last_only else (1, 2))
                )
        return torch.cat(out).numpy().astype(float)

    def xǁLSTMAutoencoderǁ_reconstruction_error__mutmut_8(self, windows: np.ndarray, last_only: bool) -> np.ndarray:
        assert self._net is not None
        self._net.eval()
        out = []
        with torch.no_grad():
            for start in range(0, len(windows), ):
                batch = torch.as_tensor(windows[start : start + 2048], dtype=torch.float32)
                error = (self._net(batch) - batch) ** 2
                out.append(
                    (error[:, -1] if last_only else error).mean(dim=-1 if last_only else (1, 2))
                )
        return torch.cat(out).numpy().astype(float)

    def xǁLSTMAutoencoderǁ_reconstruction_error__mutmut_9(self, windows: np.ndarray, last_only: bool) -> np.ndarray:
        assert self._net is not None
        self._net.eval()
        out = []
        with torch.no_grad():
            for start in range(1, len(windows), 2048):
                batch = torch.as_tensor(windows[start : start + 2048], dtype=torch.float32)
                error = (self._net(batch) - batch) ** 2
                out.append(
                    (error[:, -1] if last_only else error).mean(dim=-1 if last_only else (1, 2))
                )
        return torch.cat(out).numpy().astype(float)

    def xǁLSTMAutoencoderǁ_reconstruction_error__mutmut_10(self, windows: np.ndarray, last_only: bool) -> np.ndarray:
        assert self._net is not None
        self._net.eval()
        out = []
        with torch.no_grad():
            for start in range(0, len(windows), 2049):
                batch = torch.as_tensor(windows[start : start + 2048], dtype=torch.float32)
                error = (self._net(batch) - batch) ** 2
                out.append(
                    (error[:, -1] if last_only else error).mean(dim=-1 if last_only else (1, 2))
                )
        return torch.cat(out).numpy().astype(float)

    def xǁLSTMAutoencoderǁ_reconstruction_error__mutmut_11(self, windows: np.ndarray, last_only: bool) -> np.ndarray:
        assert self._net is not None
        self._net.eval()
        out = []
        with torch.no_grad():
            for start in range(0, len(windows), 2048):
                batch = None
                error = (self._net(batch) - batch) ** 2
                out.append(
                    (error[:, -1] if last_only else error).mean(dim=-1 if last_only else (1, 2))
                )
        return torch.cat(out).numpy().astype(float)

    def xǁLSTMAutoencoderǁ_reconstruction_error__mutmut_12(self, windows: np.ndarray, last_only: bool) -> np.ndarray:
        assert self._net is not None
        self._net.eval()
        out = []
        with torch.no_grad():
            for start in range(0, len(windows), 2048):
                batch = torch.as_tensor(None, dtype=torch.float32)
                error = (self._net(batch) - batch) ** 2
                out.append(
                    (error[:, -1] if last_only else error).mean(dim=-1 if last_only else (1, 2))
                )
        return torch.cat(out).numpy().astype(float)

    def xǁLSTMAutoencoderǁ_reconstruction_error__mutmut_13(self, windows: np.ndarray, last_only: bool) -> np.ndarray:
        assert self._net is not None
        self._net.eval()
        out = []
        with torch.no_grad():
            for start in range(0, len(windows), 2048):
                batch = torch.as_tensor(windows[start : start + 2048], dtype=None)
                error = (self._net(batch) - batch) ** 2
                out.append(
                    (error[:, -1] if last_only else error).mean(dim=-1 if last_only else (1, 2))
                )
        return torch.cat(out).numpy().astype(float)

    def xǁLSTMAutoencoderǁ_reconstruction_error__mutmut_14(self, windows: np.ndarray, last_only: bool) -> np.ndarray:
        assert self._net is not None
        self._net.eval()
        out = []
        with torch.no_grad():
            for start in range(0, len(windows), 2048):
                batch = torch.as_tensor(dtype=torch.float32)
                error = (self._net(batch) - batch) ** 2
                out.append(
                    (error[:, -1] if last_only else error).mean(dim=-1 if last_only else (1, 2))
                )
        return torch.cat(out).numpy().astype(float)

    def xǁLSTMAutoencoderǁ_reconstruction_error__mutmut_15(self, windows: np.ndarray, last_only: bool) -> np.ndarray:
        assert self._net is not None
        self._net.eval()
        out = []
        with torch.no_grad():
            for start in range(0, len(windows), 2048):
                batch = torch.as_tensor(windows[start : start + 2048], )
                error = (self._net(batch) - batch) ** 2
                out.append(
                    (error[:, -1] if last_only else error).mean(dim=-1 if last_only else (1, 2))
                )
        return torch.cat(out).numpy().astype(float)

    def xǁLSTMAutoencoderǁ_reconstruction_error__mutmut_16(self, windows: np.ndarray, last_only: bool) -> np.ndarray:
        assert self._net is not None
        self._net.eval()
        out = []
        with torch.no_grad():
            for start in range(0, len(windows), 2048):
                batch = torch.as_tensor(windows[start : start - 2048], dtype=torch.float32)
                error = (self._net(batch) - batch) ** 2
                out.append(
                    (error[:, -1] if last_only else error).mean(dim=-1 if last_only else (1, 2))
                )
        return torch.cat(out).numpy().astype(float)

    def xǁLSTMAutoencoderǁ_reconstruction_error__mutmut_17(self, windows: np.ndarray, last_only: bool) -> np.ndarray:
        assert self._net is not None
        self._net.eval()
        out = []
        with torch.no_grad():
            for start in range(0, len(windows), 2048):
                batch = torch.as_tensor(windows[start : start + 2049], dtype=torch.float32)
                error = (self._net(batch) - batch) ** 2
                out.append(
                    (error[:, -1] if last_only else error).mean(dim=-1 if last_only else (1, 2))
                )
        return torch.cat(out).numpy().astype(float)

    def xǁLSTMAutoencoderǁ_reconstruction_error__mutmut_18(self, windows: np.ndarray, last_only: bool) -> np.ndarray:
        assert self._net is not None
        self._net.eval()
        out = []
        with torch.no_grad():
            for start in range(0, len(windows), 2048):
                batch = torch.as_tensor(windows[start : start + 2048], dtype=torch.float32)
                error = None
                out.append(
                    (error[:, -1] if last_only else error).mean(dim=-1 if last_only else (1, 2))
                )
        return torch.cat(out).numpy().astype(float)

    def xǁLSTMAutoencoderǁ_reconstruction_error__mutmut_19(self, windows: np.ndarray, last_only: bool) -> np.ndarray:
        assert self._net is not None
        self._net.eval()
        out = []
        with torch.no_grad():
            for start in range(0, len(windows), 2048):
                batch = torch.as_tensor(windows[start : start + 2048], dtype=torch.float32)
                error = (self._net(batch) - batch) * 2
                out.append(
                    (error[:, -1] if last_only else error).mean(dim=-1 if last_only else (1, 2))
                )
        return torch.cat(out).numpy().astype(float)

    def xǁLSTMAutoencoderǁ_reconstruction_error__mutmut_20(self, windows: np.ndarray, last_only: bool) -> np.ndarray:
        assert self._net is not None
        self._net.eval()
        out = []
        with torch.no_grad():
            for start in range(0, len(windows), 2048):
                batch = torch.as_tensor(windows[start : start + 2048], dtype=torch.float32)
                error = (self._net(batch) + batch) ** 2
                out.append(
                    (error[:, -1] if last_only else error).mean(dim=-1 if last_only else (1, 2))
                )
        return torch.cat(out).numpy().astype(float)

    def xǁLSTMAutoencoderǁ_reconstruction_error__mutmut_21(self, windows: np.ndarray, last_only: bool) -> np.ndarray:
        assert self._net is not None
        self._net.eval()
        out = []
        with torch.no_grad():
            for start in range(0, len(windows), 2048):
                batch = torch.as_tensor(windows[start : start + 2048], dtype=torch.float32)
                error = (self._net(None) - batch) ** 2
                out.append(
                    (error[:, -1] if last_only else error).mean(dim=-1 if last_only else (1, 2))
                )
        return torch.cat(out).numpy().astype(float)

    def xǁLSTMAutoencoderǁ_reconstruction_error__mutmut_22(self, windows: np.ndarray, last_only: bool) -> np.ndarray:
        assert self._net is not None
        self._net.eval()
        out = []
        with torch.no_grad():
            for start in range(0, len(windows), 2048):
                batch = torch.as_tensor(windows[start : start + 2048], dtype=torch.float32)
                error = (self._net(batch) - batch) ** 3
                out.append(
                    (error[:, -1] if last_only else error).mean(dim=-1 if last_only else (1, 2))
                )
        return torch.cat(out).numpy().astype(float)

    def xǁLSTMAutoencoderǁ_reconstruction_error__mutmut_23(self, windows: np.ndarray, last_only: bool) -> np.ndarray:
        assert self._net is not None
        self._net.eval()
        out = []
        with torch.no_grad():
            for start in range(0, len(windows), 2048):
                batch = torch.as_tensor(windows[start : start + 2048], dtype=torch.float32)
                error = (self._net(batch) - batch) ** 2
                out.append(
                    None
                )
        return torch.cat(out).numpy().astype(float)

    def xǁLSTMAutoencoderǁ_reconstruction_error__mutmut_24(self, windows: np.ndarray, last_only: bool) -> np.ndarray:
        assert self._net is not None
        self._net.eval()
        out = []
        with torch.no_grad():
            for start in range(0, len(windows), 2048):
                batch = torch.as_tensor(windows[start : start + 2048], dtype=torch.float32)
                error = (self._net(batch) - batch) ** 2
                out.append(
                    (error[:, -1] if last_only else error).mean(dim=None)
                )
        return torch.cat(out).numpy().astype(float)

    def xǁLSTMAutoencoderǁ_reconstruction_error__mutmut_25(self, windows: np.ndarray, last_only: bool) -> np.ndarray:
        assert self._net is not None
        self._net.eval()
        out = []
        with torch.no_grad():
            for start in range(0, len(windows), 2048):
                batch = torch.as_tensor(windows[start : start + 2048], dtype=torch.float32)
                error = (self._net(batch) - batch) ** 2
                out.append(
                    (error[:, -1] if (last_only) and False else error).mean(dim=-1 if last_only else (1, 2))
                )
        return torch.cat(out).numpy().astype(float)

    def xǁLSTMAutoencoderǁ_reconstruction_error__mutmut_26(self, windows: np.ndarray, last_only: bool) -> np.ndarray:
        assert self._net is not None
        self._net.eval()
        out = []
        with torch.no_grad():
            for start in range(0, len(windows), 2048):
                batch = torch.as_tensor(windows[start : start + 2048], dtype=torch.float32)
                error = (self._net(batch) - batch) ** 2
                out.append(
                    (error[:, -1] if (last_only) or True else error).mean(dim=-1 if last_only else (1, 2))
                )
        return torch.cat(out).numpy().astype(float)

    def xǁLSTMAutoencoderǁ_reconstruction_error__mutmut_27(self, windows: np.ndarray, last_only: bool) -> np.ndarray:
        assert self._net is not None
        self._net.eval()
        out = []
        with torch.no_grad():
            for start in range(0, len(windows), 2048):
                batch = torch.as_tensor(windows[start : start + 2048], dtype=torch.float32)
                error = (self._net(batch) - batch) ** 2
                out.append(
                    (error[:, +1] if last_only else error).mean(dim=-1 if last_only else (1, 2))
                )
        return torch.cat(out).numpy().astype(float)

    def xǁLSTMAutoencoderǁ_reconstruction_error__mutmut_28(self, windows: np.ndarray, last_only: bool) -> np.ndarray:
        assert self._net is not None
        self._net.eval()
        out = []
        with torch.no_grad():
            for start in range(0, len(windows), 2048):
                batch = torch.as_tensor(windows[start : start + 2048], dtype=torch.float32)
                error = (self._net(batch) - batch) ** 2
                out.append(
                    (error[:, -2] if last_only else error).mean(dim=-1 if last_only else (1, 2))
                )
        return torch.cat(out).numpy().astype(float)

    def xǁLSTMAutoencoderǁ_reconstruction_error__mutmut_29(self, windows: np.ndarray, last_only: bool) -> np.ndarray:
        assert self._net is not None
        self._net.eval()
        out = []
        with torch.no_grad():
            for start in range(0, len(windows), 2048):
                batch = torch.as_tensor(windows[start : start + 2048], dtype=torch.float32)
                error = (self._net(batch) - batch) ** 2
                out.append(
                    (error[:, -1] if last_only else error).mean(dim=-1 if (last_only) and False else (1, 2))
                )
        return torch.cat(out).numpy().astype(float)

    def xǁLSTMAutoencoderǁ_reconstruction_error__mutmut_30(self, windows: np.ndarray, last_only: bool) -> np.ndarray:
        assert self._net is not None
        self._net.eval()
        out = []
        with torch.no_grad():
            for start in range(0, len(windows), 2048):
                batch = torch.as_tensor(windows[start : start + 2048], dtype=torch.float32)
                error = (self._net(batch) - batch) ** 2
                out.append(
                    (error[:, -1] if last_only else error).mean(dim=-1 if (last_only) or True else (1, 2))
                )
        return torch.cat(out).numpy().astype(float)

    def xǁLSTMAutoencoderǁ_reconstruction_error__mutmut_31(self, windows: np.ndarray, last_only: bool) -> np.ndarray:
        assert self._net is not None
        self._net.eval()
        out = []
        with torch.no_grad():
            for start in range(0, len(windows), 2048):
                batch = torch.as_tensor(windows[start : start + 2048], dtype=torch.float32)
                error = (self._net(batch) - batch) ** 2
                out.append(
                    (error[:, -1] if last_only else error).mean(dim=+1 if last_only else (1, 2))
                )
        return torch.cat(out).numpy().astype(float)

    def xǁLSTMAutoencoderǁ_reconstruction_error__mutmut_32(self, windows: np.ndarray, last_only: bool) -> np.ndarray:
        assert self._net is not None
        self._net.eval()
        out = []
        with torch.no_grad():
            for start in range(0, len(windows), 2048):
                batch = torch.as_tensor(windows[start : start + 2048], dtype=torch.float32)
                error = (self._net(batch) - batch) ** 2
                out.append(
                    (error[:, -1] if last_only else error).mean(dim=-2 if last_only else (1, 2))
                )
        return torch.cat(out).numpy().astype(float)

    def xǁLSTMAutoencoderǁ_reconstruction_error__mutmut_33(self, windows: np.ndarray, last_only: bool) -> np.ndarray:
        assert self._net is not None
        self._net.eval()
        out = []
        with torch.no_grad():
            for start in range(0, len(windows), 2048):
                batch = torch.as_tensor(windows[start : start + 2048], dtype=torch.float32)
                error = (self._net(batch) - batch) ** 2
                out.append(
                    (error[:, -1] if last_only else error).mean(dim=-1 if last_only else (2, 2))
                )
        return torch.cat(out).numpy().astype(float)

    def xǁLSTMAutoencoderǁ_reconstruction_error__mutmut_34(self, windows: np.ndarray, last_only: bool) -> np.ndarray:
        assert self._net is not None
        self._net.eval()
        out = []
        with torch.no_grad():
            for start in range(0, len(windows), 2048):
                batch = torch.as_tensor(windows[start : start + 2048], dtype=torch.float32)
                error = (self._net(batch) - batch) ** 2
                out.append(
                    (error[:, -1] if last_only else error).mean(dim=-1 if last_only else (1, 3))
                )
        return torch.cat(out).numpy().astype(float)

    def xǁLSTMAutoencoderǁ_reconstruction_error__mutmut_35(self, windows: np.ndarray, last_only: bool) -> np.ndarray:
        assert self._net is not None
        self._net.eval()
        out = []
        with torch.no_grad():
            for start in range(0, len(windows), 2048):
                batch = torch.as_tensor(windows[start : start + 2048], dtype=torch.float32)
                error = (self._net(batch) - batch) ** 2
                out.append(
                    (error[:, -1] if last_only else error).mean(dim=-1 if last_only else (1, 2))
                )
        return torch.cat(out).numpy().astype(None)

    def xǁLSTMAutoencoderǁ_reconstruction_error__mutmut_36(self, windows: np.ndarray, last_only: bool) -> np.ndarray:
        assert self._net is not None
        self._net.eval()
        out = []
        with torch.no_grad():
            for start in range(0, len(windows), 2048):
                batch = torch.as_tensor(windows[start : start + 2048], dtype=torch.float32)
                error = (self._net(batch) - batch) ** 2
                out.append(
                    (error[:, -1] if last_only else error).mean(dim=-1 if last_only else (1, 2))
                )
        return torch.cat(None).numpy().astype(float)

    # -- fitting ------------------------------------------------------------------------
    @_mutmut_mutated(mutants_xǁLSTMAutoencoderǁfit__mutmut)
    def fit(self, train: pd.DataFrame, validation: pd.DataFrame, contamination: float) -> Self:
        if not 0.0 < contamination < 0.5:
            raise ValueError("contamination must be in (0, 0.5)")
        if len(train) < self.window or len(validation) < self.window:
            raise ValueError("the training and validation rows must fill at least one window")
        values = train[self.columns].astype(float)
        self.center_ = values.median().to_numpy()
        spread = values.std(ddof=0).to_numpy()
        self.scale_ = np.where(spread > 0, spread, 1.0)
        torch.manual_seed(self.seed)
        torch.set_num_threads(self.threads)
        torch.use_deterministic_algorithms(True)
        rng = np.random.default_rng(self.seed)
        fit_windows, _ = self._windows(train)
        if len(fit_windows) > self.fit_rows:
            fit_windows = fit_windows[rng.choice(len(fit_windows), self.fit_rows, replace=False)]
        val_windows, _ = self._windows(validation)
        if len(val_windows) > self.validation_rows:
            keep = np.sort(rng.choice(len(val_windows), self.validation_rows, replace=False))
            val_windows = val_windows[keep]
        self._validation = torch.as_tensor(val_windows, dtype=torch.float32)
        self._net = _Network(len(self.columns), self.hidden)
        optimiser = torch.optim.Adam(self._net.parameters(), lr=self.learning_rate)
        data = torch.as_tensor(fit_windows, dtype=torch.float32)
        shuffler = torch.Generator().manual_seed(self.seed)
        train_loss: list[float] = []
        validation_loss: list[float] = []
        best, best_state, stale = np.inf, None, 0
        for _epoch in range(self.max_epochs):
            self._net.train()
            order = torch.randperm(len(data), generator=shuffler)
            total = 0.0
            for start in range(0, len(data), self.batch_size):
                batch = data[order[start : start + self.batch_size]]
                optimiser.zero_grad()
                loss = nn.functional.mse_loss(self._net(batch), batch)
                loss.backward()
                optimiser.step()
                total += float(loss.detach()) * len(batch)
            train_loss.append(total / len(data))
            validation_loss.append(self.validation_loss_now())
            if validation_loss[-1] < best:
                best, stale = validation_loss[-1], 0
                best_state = {k: v.clone() for k, v in self._net.state_dict().items()}
            else:
                stale += 1
                if stale >= self.patience:
                    break
        assert best_state is not None
        self._net.load_state_dict(best_state)
        scores = self._reconstruction_error(fit_windows, last_only=True)
        self.threshold_ = float(np.quantile(scores, 1.0 - contamination))
        self._history = {
            "train_loss": train_loss,
            "validation_loss": validation_loss,
            "epochs_run": len(train_loss),
            "best_epoch": int(np.argmin(validation_loss)) + 1,
        }
        return self

    # -- fitting ------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁfit__mutmut_orig(self, train: pd.DataFrame, validation: pd.DataFrame, contamination: float) -> Self:
        if not 0.0 < contamination < 0.5:
            raise ValueError("contamination must be in (0, 0.5)")
        if len(train) < self.window or len(validation) < self.window:
            raise ValueError("the training and validation rows must fill at least one window")
        values = train[self.columns].astype(float)
        self.center_ = values.median().to_numpy()
        spread = values.std(ddof=0).to_numpy()
        self.scale_ = np.where(spread > 0, spread, 1.0)
        torch.manual_seed(self.seed)
        torch.set_num_threads(self.threads)
        torch.use_deterministic_algorithms(True)
        rng = np.random.default_rng(self.seed)
        fit_windows, _ = self._windows(train)
        if len(fit_windows) > self.fit_rows:
            fit_windows = fit_windows[rng.choice(len(fit_windows), self.fit_rows, replace=False)]
        val_windows, _ = self._windows(validation)
        if len(val_windows) > self.validation_rows:
            keep = np.sort(rng.choice(len(val_windows), self.validation_rows, replace=False))
            val_windows = val_windows[keep]
        self._validation = torch.as_tensor(val_windows, dtype=torch.float32)
        self._net = _Network(len(self.columns), self.hidden)
        optimiser = torch.optim.Adam(self._net.parameters(), lr=self.learning_rate)
        data = torch.as_tensor(fit_windows, dtype=torch.float32)
        shuffler = torch.Generator().manual_seed(self.seed)
        train_loss: list[float] = []
        validation_loss: list[float] = []
        best, best_state, stale = np.inf, None, 0
        for _epoch in range(self.max_epochs):
            self._net.train()
            order = torch.randperm(len(data), generator=shuffler)
            total = 0.0
            for start in range(0, len(data), self.batch_size):
                batch = data[order[start : start + self.batch_size]]
                optimiser.zero_grad()
                loss = nn.functional.mse_loss(self._net(batch), batch)
                loss.backward()
                optimiser.step()
                total += float(loss.detach()) * len(batch)
            train_loss.append(total / len(data))
            validation_loss.append(self.validation_loss_now())
            if validation_loss[-1] < best:
                best, stale = validation_loss[-1], 0
                best_state = {k: v.clone() for k, v in self._net.state_dict().items()}
            else:
                stale += 1
                if stale >= self.patience:
                    break
        assert best_state is not None
        self._net.load_state_dict(best_state)
        scores = self._reconstruction_error(fit_windows, last_only=True)
        self.threshold_ = float(np.quantile(scores, 1.0 - contamination))
        self._history = {
            "train_loss": train_loss,
            "validation_loss": validation_loss,
            "epochs_run": len(train_loss),
            "best_epoch": int(np.argmin(validation_loss)) + 1,
        }
        return self

    # -- fitting ------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁfit__mutmut_1(self, train: pd.DataFrame, validation: pd.DataFrame, contamination: float) -> Self:
        if 0.0 < contamination < 0.5:
            raise ValueError("contamination must be in (0, 0.5)")
        if len(train) < self.window or len(validation) < self.window:
            raise ValueError("the training and validation rows must fill at least one window")
        values = train[self.columns].astype(float)
        self.center_ = values.median().to_numpy()
        spread = values.std(ddof=0).to_numpy()
        self.scale_ = np.where(spread > 0, spread, 1.0)
        torch.manual_seed(self.seed)
        torch.set_num_threads(self.threads)
        torch.use_deterministic_algorithms(True)
        rng = np.random.default_rng(self.seed)
        fit_windows, _ = self._windows(train)
        if len(fit_windows) > self.fit_rows:
            fit_windows = fit_windows[rng.choice(len(fit_windows), self.fit_rows, replace=False)]
        val_windows, _ = self._windows(validation)
        if len(val_windows) > self.validation_rows:
            keep = np.sort(rng.choice(len(val_windows), self.validation_rows, replace=False))
            val_windows = val_windows[keep]
        self._validation = torch.as_tensor(val_windows, dtype=torch.float32)
        self._net = _Network(len(self.columns), self.hidden)
        optimiser = torch.optim.Adam(self._net.parameters(), lr=self.learning_rate)
        data = torch.as_tensor(fit_windows, dtype=torch.float32)
        shuffler = torch.Generator().manual_seed(self.seed)
        train_loss: list[float] = []
        validation_loss: list[float] = []
        best, best_state, stale = np.inf, None, 0
        for _epoch in range(self.max_epochs):
            self._net.train()
            order = torch.randperm(len(data), generator=shuffler)
            total = 0.0
            for start in range(0, len(data), self.batch_size):
                batch = data[order[start : start + self.batch_size]]
                optimiser.zero_grad()
                loss = nn.functional.mse_loss(self._net(batch), batch)
                loss.backward()
                optimiser.step()
                total += float(loss.detach()) * len(batch)
            train_loss.append(total / len(data))
            validation_loss.append(self.validation_loss_now())
            if validation_loss[-1] < best:
                best, stale = validation_loss[-1], 0
                best_state = {k: v.clone() for k, v in self._net.state_dict().items()}
            else:
                stale += 1
                if stale >= self.patience:
                    break
        assert best_state is not None
        self._net.load_state_dict(best_state)
        scores = self._reconstruction_error(fit_windows, last_only=True)
        self.threshold_ = float(np.quantile(scores, 1.0 - contamination))
        self._history = {
            "train_loss": train_loss,
            "validation_loss": validation_loss,
            "epochs_run": len(train_loss),
            "best_epoch": int(np.argmin(validation_loss)) + 1,
        }
        return self

    # -- fitting ------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁfit__mutmut_2(self, train: pd.DataFrame, validation: pd.DataFrame, contamination: float) -> Self:
        if not 1.0 < contamination < 0.5:
            raise ValueError("contamination must be in (0, 0.5)")
        if len(train) < self.window or len(validation) < self.window:
            raise ValueError("the training and validation rows must fill at least one window")
        values = train[self.columns].astype(float)
        self.center_ = values.median().to_numpy()
        spread = values.std(ddof=0).to_numpy()
        self.scale_ = np.where(spread > 0, spread, 1.0)
        torch.manual_seed(self.seed)
        torch.set_num_threads(self.threads)
        torch.use_deterministic_algorithms(True)
        rng = np.random.default_rng(self.seed)
        fit_windows, _ = self._windows(train)
        if len(fit_windows) > self.fit_rows:
            fit_windows = fit_windows[rng.choice(len(fit_windows), self.fit_rows, replace=False)]
        val_windows, _ = self._windows(validation)
        if len(val_windows) > self.validation_rows:
            keep = np.sort(rng.choice(len(val_windows), self.validation_rows, replace=False))
            val_windows = val_windows[keep]
        self._validation = torch.as_tensor(val_windows, dtype=torch.float32)
        self._net = _Network(len(self.columns), self.hidden)
        optimiser = torch.optim.Adam(self._net.parameters(), lr=self.learning_rate)
        data = torch.as_tensor(fit_windows, dtype=torch.float32)
        shuffler = torch.Generator().manual_seed(self.seed)
        train_loss: list[float] = []
        validation_loss: list[float] = []
        best, best_state, stale = np.inf, None, 0
        for _epoch in range(self.max_epochs):
            self._net.train()
            order = torch.randperm(len(data), generator=shuffler)
            total = 0.0
            for start in range(0, len(data), self.batch_size):
                batch = data[order[start : start + self.batch_size]]
                optimiser.zero_grad()
                loss = nn.functional.mse_loss(self._net(batch), batch)
                loss.backward()
                optimiser.step()
                total += float(loss.detach()) * len(batch)
            train_loss.append(total / len(data))
            validation_loss.append(self.validation_loss_now())
            if validation_loss[-1] < best:
                best, stale = validation_loss[-1], 0
                best_state = {k: v.clone() for k, v in self._net.state_dict().items()}
            else:
                stale += 1
                if stale >= self.patience:
                    break
        assert best_state is not None
        self._net.load_state_dict(best_state)
        scores = self._reconstruction_error(fit_windows, last_only=True)
        self.threshold_ = float(np.quantile(scores, 1.0 - contamination))
        self._history = {
            "train_loss": train_loss,
            "validation_loss": validation_loss,
            "epochs_run": len(train_loss),
            "best_epoch": int(np.argmin(validation_loss)) + 1,
        }
        return self

    # -- fitting ------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁfit__mutmut_3(self, train: pd.DataFrame, validation: pd.DataFrame, contamination: float) -> Self:
        if not 0.0 <= contamination < 0.5:
            raise ValueError("contamination must be in (0, 0.5)")
        if len(train) < self.window or len(validation) < self.window:
            raise ValueError("the training and validation rows must fill at least one window")
        values = train[self.columns].astype(float)
        self.center_ = values.median().to_numpy()
        spread = values.std(ddof=0).to_numpy()
        self.scale_ = np.where(spread > 0, spread, 1.0)
        torch.manual_seed(self.seed)
        torch.set_num_threads(self.threads)
        torch.use_deterministic_algorithms(True)
        rng = np.random.default_rng(self.seed)
        fit_windows, _ = self._windows(train)
        if len(fit_windows) > self.fit_rows:
            fit_windows = fit_windows[rng.choice(len(fit_windows), self.fit_rows, replace=False)]
        val_windows, _ = self._windows(validation)
        if len(val_windows) > self.validation_rows:
            keep = np.sort(rng.choice(len(val_windows), self.validation_rows, replace=False))
            val_windows = val_windows[keep]
        self._validation = torch.as_tensor(val_windows, dtype=torch.float32)
        self._net = _Network(len(self.columns), self.hidden)
        optimiser = torch.optim.Adam(self._net.parameters(), lr=self.learning_rate)
        data = torch.as_tensor(fit_windows, dtype=torch.float32)
        shuffler = torch.Generator().manual_seed(self.seed)
        train_loss: list[float] = []
        validation_loss: list[float] = []
        best, best_state, stale = np.inf, None, 0
        for _epoch in range(self.max_epochs):
            self._net.train()
            order = torch.randperm(len(data), generator=shuffler)
            total = 0.0
            for start in range(0, len(data), self.batch_size):
                batch = data[order[start : start + self.batch_size]]
                optimiser.zero_grad()
                loss = nn.functional.mse_loss(self._net(batch), batch)
                loss.backward()
                optimiser.step()
                total += float(loss.detach()) * len(batch)
            train_loss.append(total / len(data))
            validation_loss.append(self.validation_loss_now())
            if validation_loss[-1] < best:
                best, stale = validation_loss[-1], 0
                best_state = {k: v.clone() for k, v in self._net.state_dict().items()}
            else:
                stale += 1
                if stale >= self.patience:
                    break
        assert best_state is not None
        self._net.load_state_dict(best_state)
        scores = self._reconstruction_error(fit_windows, last_only=True)
        self.threshold_ = float(np.quantile(scores, 1.0 - contamination))
        self._history = {
            "train_loss": train_loss,
            "validation_loss": validation_loss,
            "epochs_run": len(train_loss),
            "best_epoch": int(np.argmin(validation_loss)) + 1,
        }
        return self

    # -- fitting ------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁfit__mutmut_4(self, train: pd.DataFrame, validation: pd.DataFrame, contamination: float) -> Self:
        if not 0.0 < contamination <= 0.5:
            raise ValueError("contamination must be in (0, 0.5)")
        if len(train) < self.window or len(validation) < self.window:
            raise ValueError("the training and validation rows must fill at least one window")
        values = train[self.columns].astype(float)
        self.center_ = values.median().to_numpy()
        spread = values.std(ddof=0).to_numpy()
        self.scale_ = np.where(spread > 0, spread, 1.0)
        torch.manual_seed(self.seed)
        torch.set_num_threads(self.threads)
        torch.use_deterministic_algorithms(True)
        rng = np.random.default_rng(self.seed)
        fit_windows, _ = self._windows(train)
        if len(fit_windows) > self.fit_rows:
            fit_windows = fit_windows[rng.choice(len(fit_windows), self.fit_rows, replace=False)]
        val_windows, _ = self._windows(validation)
        if len(val_windows) > self.validation_rows:
            keep = np.sort(rng.choice(len(val_windows), self.validation_rows, replace=False))
            val_windows = val_windows[keep]
        self._validation = torch.as_tensor(val_windows, dtype=torch.float32)
        self._net = _Network(len(self.columns), self.hidden)
        optimiser = torch.optim.Adam(self._net.parameters(), lr=self.learning_rate)
        data = torch.as_tensor(fit_windows, dtype=torch.float32)
        shuffler = torch.Generator().manual_seed(self.seed)
        train_loss: list[float] = []
        validation_loss: list[float] = []
        best, best_state, stale = np.inf, None, 0
        for _epoch in range(self.max_epochs):
            self._net.train()
            order = torch.randperm(len(data), generator=shuffler)
            total = 0.0
            for start in range(0, len(data), self.batch_size):
                batch = data[order[start : start + self.batch_size]]
                optimiser.zero_grad()
                loss = nn.functional.mse_loss(self._net(batch), batch)
                loss.backward()
                optimiser.step()
                total += float(loss.detach()) * len(batch)
            train_loss.append(total / len(data))
            validation_loss.append(self.validation_loss_now())
            if validation_loss[-1] < best:
                best, stale = validation_loss[-1], 0
                best_state = {k: v.clone() for k, v in self._net.state_dict().items()}
            else:
                stale += 1
                if stale >= self.patience:
                    break
        assert best_state is not None
        self._net.load_state_dict(best_state)
        scores = self._reconstruction_error(fit_windows, last_only=True)
        self.threshold_ = float(np.quantile(scores, 1.0 - contamination))
        self._history = {
            "train_loss": train_loss,
            "validation_loss": validation_loss,
            "epochs_run": len(train_loss),
            "best_epoch": int(np.argmin(validation_loss)) + 1,
        }
        return self

    # -- fitting ------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁfit__mutmut_5(self, train: pd.DataFrame, validation: pd.DataFrame, contamination: float) -> Self:
        if not 0.0 < contamination < 1.5:
            raise ValueError("contamination must be in (0, 0.5)")
        if len(train) < self.window or len(validation) < self.window:
            raise ValueError("the training and validation rows must fill at least one window")
        values = train[self.columns].astype(float)
        self.center_ = values.median().to_numpy()
        spread = values.std(ddof=0).to_numpy()
        self.scale_ = np.where(spread > 0, spread, 1.0)
        torch.manual_seed(self.seed)
        torch.set_num_threads(self.threads)
        torch.use_deterministic_algorithms(True)
        rng = np.random.default_rng(self.seed)
        fit_windows, _ = self._windows(train)
        if len(fit_windows) > self.fit_rows:
            fit_windows = fit_windows[rng.choice(len(fit_windows), self.fit_rows, replace=False)]
        val_windows, _ = self._windows(validation)
        if len(val_windows) > self.validation_rows:
            keep = np.sort(rng.choice(len(val_windows), self.validation_rows, replace=False))
            val_windows = val_windows[keep]
        self._validation = torch.as_tensor(val_windows, dtype=torch.float32)
        self._net = _Network(len(self.columns), self.hidden)
        optimiser = torch.optim.Adam(self._net.parameters(), lr=self.learning_rate)
        data = torch.as_tensor(fit_windows, dtype=torch.float32)
        shuffler = torch.Generator().manual_seed(self.seed)
        train_loss: list[float] = []
        validation_loss: list[float] = []
        best, best_state, stale = np.inf, None, 0
        for _epoch in range(self.max_epochs):
            self._net.train()
            order = torch.randperm(len(data), generator=shuffler)
            total = 0.0
            for start in range(0, len(data), self.batch_size):
                batch = data[order[start : start + self.batch_size]]
                optimiser.zero_grad()
                loss = nn.functional.mse_loss(self._net(batch), batch)
                loss.backward()
                optimiser.step()
                total += float(loss.detach()) * len(batch)
            train_loss.append(total / len(data))
            validation_loss.append(self.validation_loss_now())
            if validation_loss[-1] < best:
                best, stale = validation_loss[-1], 0
                best_state = {k: v.clone() for k, v in self._net.state_dict().items()}
            else:
                stale += 1
                if stale >= self.patience:
                    break
        assert best_state is not None
        self._net.load_state_dict(best_state)
        scores = self._reconstruction_error(fit_windows, last_only=True)
        self.threshold_ = float(np.quantile(scores, 1.0 - contamination))
        self._history = {
            "train_loss": train_loss,
            "validation_loss": validation_loss,
            "epochs_run": len(train_loss),
            "best_epoch": int(np.argmin(validation_loss)) + 1,
        }
        return self

    # -- fitting ------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁfit__mutmut_6(self, train: pd.DataFrame, validation: pd.DataFrame, contamination: float) -> Self:
        if not 0.0 < contamination < 0.5:
            raise ValueError(None)
        if len(train) < self.window or len(validation) < self.window:
            raise ValueError("the training and validation rows must fill at least one window")
        values = train[self.columns].astype(float)
        self.center_ = values.median().to_numpy()
        spread = values.std(ddof=0).to_numpy()
        self.scale_ = np.where(spread > 0, spread, 1.0)
        torch.manual_seed(self.seed)
        torch.set_num_threads(self.threads)
        torch.use_deterministic_algorithms(True)
        rng = np.random.default_rng(self.seed)
        fit_windows, _ = self._windows(train)
        if len(fit_windows) > self.fit_rows:
            fit_windows = fit_windows[rng.choice(len(fit_windows), self.fit_rows, replace=False)]
        val_windows, _ = self._windows(validation)
        if len(val_windows) > self.validation_rows:
            keep = np.sort(rng.choice(len(val_windows), self.validation_rows, replace=False))
            val_windows = val_windows[keep]
        self._validation = torch.as_tensor(val_windows, dtype=torch.float32)
        self._net = _Network(len(self.columns), self.hidden)
        optimiser = torch.optim.Adam(self._net.parameters(), lr=self.learning_rate)
        data = torch.as_tensor(fit_windows, dtype=torch.float32)
        shuffler = torch.Generator().manual_seed(self.seed)
        train_loss: list[float] = []
        validation_loss: list[float] = []
        best, best_state, stale = np.inf, None, 0
        for _epoch in range(self.max_epochs):
            self._net.train()
            order = torch.randperm(len(data), generator=shuffler)
            total = 0.0
            for start in range(0, len(data), self.batch_size):
                batch = data[order[start : start + self.batch_size]]
                optimiser.zero_grad()
                loss = nn.functional.mse_loss(self._net(batch), batch)
                loss.backward()
                optimiser.step()
                total += float(loss.detach()) * len(batch)
            train_loss.append(total / len(data))
            validation_loss.append(self.validation_loss_now())
            if validation_loss[-1] < best:
                best, stale = validation_loss[-1], 0
                best_state = {k: v.clone() for k, v in self._net.state_dict().items()}
            else:
                stale += 1
                if stale >= self.patience:
                    break
        assert best_state is not None
        self._net.load_state_dict(best_state)
        scores = self._reconstruction_error(fit_windows, last_only=True)
        self.threshold_ = float(np.quantile(scores, 1.0 - contamination))
        self._history = {
            "train_loss": train_loss,
            "validation_loss": validation_loss,
            "epochs_run": len(train_loss),
            "best_epoch": int(np.argmin(validation_loss)) + 1,
        }
        return self

    # -- fitting ------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁfit__mutmut_7(self, train: pd.DataFrame, validation: pd.DataFrame, contamination: float) -> Self:
        if not 0.0 < contamination < 0.5:
            raise ValueError("XXcontamination must be in (0, 0.5)XX")
        if len(train) < self.window or len(validation) < self.window:
            raise ValueError("the training and validation rows must fill at least one window")
        values = train[self.columns].astype(float)
        self.center_ = values.median().to_numpy()
        spread = values.std(ddof=0).to_numpy()
        self.scale_ = np.where(spread > 0, spread, 1.0)
        torch.manual_seed(self.seed)
        torch.set_num_threads(self.threads)
        torch.use_deterministic_algorithms(True)
        rng = np.random.default_rng(self.seed)
        fit_windows, _ = self._windows(train)
        if len(fit_windows) > self.fit_rows:
            fit_windows = fit_windows[rng.choice(len(fit_windows), self.fit_rows, replace=False)]
        val_windows, _ = self._windows(validation)
        if len(val_windows) > self.validation_rows:
            keep = np.sort(rng.choice(len(val_windows), self.validation_rows, replace=False))
            val_windows = val_windows[keep]
        self._validation = torch.as_tensor(val_windows, dtype=torch.float32)
        self._net = _Network(len(self.columns), self.hidden)
        optimiser = torch.optim.Adam(self._net.parameters(), lr=self.learning_rate)
        data = torch.as_tensor(fit_windows, dtype=torch.float32)
        shuffler = torch.Generator().manual_seed(self.seed)
        train_loss: list[float] = []
        validation_loss: list[float] = []
        best, best_state, stale = np.inf, None, 0
        for _epoch in range(self.max_epochs):
            self._net.train()
            order = torch.randperm(len(data), generator=shuffler)
            total = 0.0
            for start in range(0, len(data), self.batch_size):
                batch = data[order[start : start + self.batch_size]]
                optimiser.zero_grad()
                loss = nn.functional.mse_loss(self._net(batch), batch)
                loss.backward()
                optimiser.step()
                total += float(loss.detach()) * len(batch)
            train_loss.append(total / len(data))
            validation_loss.append(self.validation_loss_now())
            if validation_loss[-1] < best:
                best, stale = validation_loss[-1], 0
                best_state = {k: v.clone() for k, v in self._net.state_dict().items()}
            else:
                stale += 1
                if stale >= self.patience:
                    break
        assert best_state is not None
        self._net.load_state_dict(best_state)
        scores = self._reconstruction_error(fit_windows, last_only=True)
        self.threshold_ = float(np.quantile(scores, 1.0 - contamination))
        self._history = {
            "train_loss": train_loss,
            "validation_loss": validation_loss,
            "epochs_run": len(train_loss),
            "best_epoch": int(np.argmin(validation_loss)) + 1,
        }
        return self

    # -- fitting ------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁfit__mutmut_8(self, train: pd.DataFrame, validation: pd.DataFrame, contamination: float) -> Self:
        if not 0.0 < contamination < 0.5:
            raise ValueError("CONTAMINATION MUST BE IN (0, 0.5)")
        if len(train) < self.window or len(validation) < self.window:
            raise ValueError("the training and validation rows must fill at least one window")
        values = train[self.columns].astype(float)
        self.center_ = values.median().to_numpy()
        spread = values.std(ddof=0).to_numpy()
        self.scale_ = np.where(spread > 0, spread, 1.0)
        torch.manual_seed(self.seed)
        torch.set_num_threads(self.threads)
        torch.use_deterministic_algorithms(True)
        rng = np.random.default_rng(self.seed)
        fit_windows, _ = self._windows(train)
        if len(fit_windows) > self.fit_rows:
            fit_windows = fit_windows[rng.choice(len(fit_windows), self.fit_rows, replace=False)]
        val_windows, _ = self._windows(validation)
        if len(val_windows) > self.validation_rows:
            keep = np.sort(rng.choice(len(val_windows), self.validation_rows, replace=False))
            val_windows = val_windows[keep]
        self._validation = torch.as_tensor(val_windows, dtype=torch.float32)
        self._net = _Network(len(self.columns), self.hidden)
        optimiser = torch.optim.Adam(self._net.parameters(), lr=self.learning_rate)
        data = torch.as_tensor(fit_windows, dtype=torch.float32)
        shuffler = torch.Generator().manual_seed(self.seed)
        train_loss: list[float] = []
        validation_loss: list[float] = []
        best, best_state, stale = np.inf, None, 0
        for _epoch in range(self.max_epochs):
            self._net.train()
            order = torch.randperm(len(data), generator=shuffler)
            total = 0.0
            for start in range(0, len(data), self.batch_size):
                batch = data[order[start : start + self.batch_size]]
                optimiser.zero_grad()
                loss = nn.functional.mse_loss(self._net(batch), batch)
                loss.backward()
                optimiser.step()
                total += float(loss.detach()) * len(batch)
            train_loss.append(total / len(data))
            validation_loss.append(self.validation_loss_now())
            if validation_loss[-1] < best:
                best, stale = validation_loss[-1], 0
                best_state = {k: v.clone() for k, v in self._net.state_dict().items()}
            else:
                stale += 1
                if stale >= self.patience:
                    break
        assert best_state is not None
        self._net.load_state_dict(best_state)
        scores = self._reconstruction_error(fit_windows, last_only=True)
        self.threshold_ = float(np.quantile(scores, 1.0 - contamination))
        self._history = {
            "train_loss": train_loss,
            "validation_loss": validation_loss,
            "epochs_run": len(train_loss),
            "best_epoch": int(np.argmin(validation_loss)) + 1,
        }
        return self

    # -- fitting ------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁfit__mutmut_9(self, train: pd.DataFrame, validation: pd.DataFrame, contamination: float) -> Self:
        if not 0.0 < contamination < 0.5:
            raise ValueError("contamination must be in (0, 0.5)")
        if len(train) < self.window and len(validation) < self.window:
            raise ValueError("the training and validation rows must fill at least one window")
        values = train[self.columns].astype(float)
        self.center_ = values.median().to_numpy()
        spread = values.std(ddof=0).to_numpy()
        self.scale_ = np.where(spread > 0, spread, 1.0)
        torch.manual_seed(self.seed)
        torch.set_num_threads(self.threads)
        torch.use_deterministic_algorithms(True)
        rng = np.random.default_rng(self.seed)
        fit_windows, _ = self._windows(train)
        if len(fit_windows) > self.fit_rows:
            fit_windows = fit_windows[rng.choice(len(fit_windows), self.fit_rows, replace=False)]
        val_windows, _ = self._windows(validation)
        if len(val_windows) > self.validation_rows:
            keep = np.sort(rng.choice(len(val_windows), self.validation_rows, replace=False))
            val_windows = val_windows[keep]
        self._validation = torch.as_tensor(val_windows, dtype=torch.float32)
        self._net = _Network(len(self.columns), self.hidden)
        optimiser = torch.optim.Adam(self._net.parameters(), lr=self.learning_rate)
        data = torch.as_tensor(fit_windows, dtype=torch.float32)
        shuffler = torch.Generator().manual_seed(self.seed)
        train_loss: list[float] = []
        validation_loss: list[float] = []
        best, best_state, stale = np.inf, None, 0
        for _epoch in range(self.max_epochs):
            self._net.train()
            order = torch.randperm(len(data), generator=shuffler)
            total = 0.0
            for start in range(0, len(data), self.batch_size):
                batch = data[order[start : start + self.batch_size]]
                optimiser.zero_grad()
                loss = nn.functional.mse_loss(self._net(batch), batch)
                loss.backward()
                optimiser.step()
                total += float(loss.detach()) * len(batch)
            train_loss.append(total / len(data))
            validation_loss.append(self.validation_loss_now())
            if validation_loss[-1] < best:
                best, stale = validation_loss[-1], 0
                best_state = {k: v.clone() for k, v in self._net.state_dict().items()}
            else:
                stale += 1
                if stale >= self.patience:
                    break
        assert best_state is not None
        self._net.load_state_dict(best_state)
        scores = self._reconstruction_error(fit_windows, last_only=True)
        self.threshold_ = float(np.quantile(scores, 1.0 - contamination))
        self._history = {
            "train_loss": train_loss,
            "validation_loss": validation_loss,
            "epochs_run": len(train_loss),
            "best_epoch": int(np.argmin(validation_loss)) + 1,
        }
        return self

    # -- fitting ------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁfit__mutmut_10(self, train: pd.DataFrame, validation: pd.DataFrame, contamination: float) -> Self:
        if not 0.0 < contamination < 0.5:
            raise ValueError("contamination must be in (0, 0.5)")
        if len(train) <= self.window or len(validation) < self.window:
            raise ValueError("the training and validation rows must fill at least one window")
        values = train[self.columns].astype(float)
        self.center_ = values.median().to_numpy()
        spread = values.std(ddof=0).to_numpy()
        self.scale_ = np.where(spread > 0, spread, 1.0)
        torch.manual_seed(self.seed)
        torch.set_num_threads(self.threads)
        torch.use_deterministic_algorithms(True)
        rng = np.random.default_rng(self.seed)
        fit_windows, _ = self._windows(train)
        if len(fit_windows) > self.fit_rows:
            fit_windows = fit_windows[rng.choice(len(fit_windows), self.fit_rows, replace=False)]
        val_windows, _ = self._windows(validation)
        if len(val_windows) > self.validation_rows:
            keep = np.sort(rng.choice(len(val_windows), self.validation_rows, replace=False))
            val_windows = val_windows[keep]
        self._validation = torch.as_tensor(val_windows, dtype=torch.float32)
        self._net = _Network(len(self.columns), self.hidden)
        optimiser = torch.optim.Adam(self._net.parameters(), lr=self.learning_rate)
        data = torch.as_tensor(fit_windows, dtype=torch.float32)
        shuffler = torch.Generator().manual_seed(self.seed)
        train_loss: list[float] = []
        validation_loss: list[float] = []
        best, best_state, stale = np.inf, None, 0
        for _epoch in range(self.max_epochs):
            self._net.train()
            order = torch.randperm(len(data), generator=shuffler)
            total = 0.0
            for start in range(0, len(data), self.batch_size):
                batch = data[order[start : start + self.batch_size]]
                optimiser.zero_grad()
                loss = nn.functional.mse_loss(self._net(batch), batch)
                loss.backward()
                optimiser.step()
                total += float(loss.detach()) * len(batch)
            train_loss.append(total / len(data))
            validation_loss.append(self.validation_loss_now())
            if validation_loss[-1] < best:
                best, stale = validation_loss[-1], 0
                best_state = {k: v.clone() for k, v in self._net.state_dict().items()}
            else:
                stale += 1
                if stale >= self.patience:
                    break
        assert best_state is not None
        self._net.load_state_dict(best_state)
        scores = self._reconstruction_error(fit_windows, last_only=True)
        self.threshold_ = float(np.quantile(scores, 1.0 - contamination))
        self._history = {
            "train_loss": train_loss,
            "validation_loss": validation_loss,
            "epochs_run": len(train_loss),
            "best_epoch": int(np.argmin(validation_loss)) + 1,
        }
        return self

    # -- fitting ------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁfit__mutmut_11(self, train: pd.DataFrame, validation: pd.DataFrame, contamination: float) -> Self:
        if not 0.0 < contamination < 0.5:
            raise ValueError("contamination must be in (0, 0.5)")
        if len(train) < self.window or len(validation) <= self.window:
            raise ValueError("the training and validation rows must fill at least one window")
        values = train[self.columns].astype(float)
        self.center_ = values.median().to_numpy()
        spread = values.std(ddof=0).to_numpy()
        self.scale_ = np.where(spread > 0, spread, 1.0)
        torch.manual_seed(self.seed)
        torch.set_num_threads(self.threads)
        torch.use_deterministic_algorithms(True)
        rng = np.random.default_rng(self.seed)
        fit_windows, _ = self._windows(train)
        if len(fit_windows) > self.fit_rows:
            fit_windows = fit_windows[rng.choice(len(fit_windows), self.fit_rows, replace=False)]
        val_windows, _ = self._windows(validation)
        if len(val_windows) > self.validation_rows:
            keep = np.sort(rng.choice(len(val_windows), self.validation_rows, replace=False))
            val_windows = val_windows[keep]
        self._validation = torch.as_tensor(val_windows, dtype=torch.float32)
        self._net = _Network(len(self.columns), self.hidden)
        optimiser = torch.optim.Adam(self._net.parameters(), lr=self.learning_rate)
        data = torch.as_tensor(fit_windows, dtype=torch.float32)
        shuffler = torch.Generator().manual_seed(self.seed)
        train_loss: list[float] = []
        validation_loss: list[float] = []
        best, best_state, stale = np.inf, None, 0
        for _epoch in range(self.max_epochs):
            self._net.train()
            order = torch.randperm(len(data), generator=shuffler)
            total = 0.0
            for start in range(0, len(data), self.batch_size):
                batch = data[order[start : start + self.batch_size]]
                optimiser.zero_grad()
                loss = nn.functional.mse_loss(self._net(batch), batch)
                loss.backward()
                optimiser.step()
                total += float(loss.detach()) * len(batch)
            train_loss.append(total / len(data))
            validation_loss.append(self.validation_loss_now())
            if validation_loss[-1] < best:
                best, stale = validation_loss[-1], 0
                best_state = {k: v.clone() for k, v in self._net.state_dict().items()}
            else:
                stale += 1
                if stale >= self.patience:
                    break
        assert best_state is not None
        self._net.load_state_dict(best_state)
        scores = self._reconstruction_error(fit_windows, last_only=True)
        self.threshold_ = float(np.quantile(scores, 1.0 - contamination))
        self._history = {
            "train_loss": train_loss,
            "validation_loss": validation_loss,
            "epochs_run": len(train_loss),
            "best_epoch": int(np.argmin(validation_loss)) + 1,
        }
        return self

    # -- fitting ------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁfit__mutmut_12(self, train: pd.DataFrame, validation: pd.DataFrame, contamination: float) -> Self:
        if not 0.0 < contamination < 0.5:
            raise ValueError("contamination must be in (0, 0.5)")
        if len(train) < self.window or len(validation) < self.window:
            raise ValueError(None)
        values = train[self.columns].astype(float)
        self.center_ = values.median().to_numpy()
        spread = values.std(ddof=0).to_numpy()
        self.scale_ = np.where(spread > 0, spread, 1.0)
        torch.manual_seed(self.seed)
        torch.set_num_threads(self.threads)
        torch.use_deterministic_algorithms(True)
        rng = np.random.default_rng(self.seed)
        fit_windows, _ = self._windows(train)
        if len(fit_windows) > self.fit_rows:
            fit_windows = fit_windows[rng.choice(len(fit_windows), self.fit_rows, replace=False)]
        val_windows, _ = self._windows(validation)
        if len(val_windows) > self.validation_rows:
            keep = np.sort(rng.choice(len(val_windows), self.validation_rows, replace=False))
            val_windows = val_windows[keep]
        self._validation = torch.as_tensor(val_windows, dtype=torch.float32)
        self._net = _Network(len(self.columns), self.hidden)
        optimiser = torch.optim.Adam(self._net.parameters(), lr=self.learning_rate)
        data = torch.as_tensor(fit_windows, dtype=torch.float32)
        shuffler = torch.Generator().manual_seed(self.seed)
        train_loss: list[float] = []
        validation_loss: list[float] = []
        best, best_state, stale = np.inf, None, 0
        for _epoch in range(self.max_epochs):
            self._net.train()
            order = torch.randperm(len(data), generator=shuffler)
            total = 0.0
            for start in range(0, len(data), self.batch_size):
                batch = data[order[start : start + self.batch_size]]
                optimiser.zero_grad()
                loss = nn.functional.mse_loss(self._net(batch), batch)
                loss.backward()
                optimiser.step()
                total += float(loss.detach()) * len(batch)
            train_loss.append(total / len(data))
            validation_loss.append(self.validation_loss_now())
            if validation_loss[-1] < best:
                best, stale = validation_loss[-1], 0
                best_state = {k: v.clone() for k, v in self._net.state_dict().items()}
            else:
                stale += 1
                if stale >= self.patience:
                    break
        assert best_state is not None
        self._net.load_state_dict(best_state)
        scores = self._reconstruction_error(fit_windows, last_only=True)
        self.threshold_ = float(np.quantile(scores, 1.0 - contamination))
        self._history = {
            "train_loss": train_loss,
            "validation_loss": validation_loss,
            "epochs_run": len(train_loss),
            "best_epoch": int(np.argmin(validation_loss)) + 1,
        }
        return self

    # -- fitting ------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁfit__mutmut_13(self, train: pd.DataFrame, validation: pd.DataFrame, contamination: float) -> Self:
        if not 0.0 < contamination < 0.5:
            raise ValueError("contamination must be in (0, 0.5)")
        if len(train) < self.window or len(validation) < self.window:
            raise ValueError("XXthe training and validation rows must fill at least one windowXX")
        values = train[self.columns].astype(float)
        self.center_ = values.median().to_numpy()
        spread = values.std(ddof=0).to_numpy()
        self.scale_ = np.where(spread > 0, spread, 1.0)
        torch.manual_seed(self.seed)
        torch.set_num_threads(self.threads)
        torch.use_deterministic_algorithms(True)
        rng = np.random.default_rng(self.seed)
        fit_windows, _ = self._windows(train)
        if len(fit_windows) > self.fit_rows:
            fit_windows = fit_windows[rng.choice(len(fit_windows), self.fit_rows, replace=False)]
        val_windows, _ = self._windows(validation)
        if len(val_windows) > self.validation_rows:
            keep = np.sort(rng.choice(len(val_windows), self.validation_rows, replace=False))
            val_windows = val_windows[keep]
        self._validation = torch.as_tensor(val_windows, dtype=torch.float32)
        self._net = _Network(len(self.columns), self.hidden)
        optimiser = torch.optim.Adam(self._net.parameters(), lr=self.learning_rate)
        data = torch.as_tensor(fit_windows, dtype=torch.float32)
        shuffler = torch.Generator().manual_seed(self.seed)
        train_loss: list[float] = []
        validation_loss: list[float] = []
        best, best_state, stale = np.inf, None, 0
        for _epoch in range(self.max_epochs):
            self._net.train()
            order = torch.randperm(len(data), generator=shuffler)
            total = 0.0
            for start in range(0, len(data), self.batch_size):
                batch = data[order[start : start + self.batch_size]]
                optimiser.zero_grad()
                loss = nn.functional.mse_loss(self._net(batch), batch)
                loss.backward()
                optimiser.step()
                total += float(loss.detach()) * len(batch)
            train_loss.append(total / len(data))
            validation_loss.append(self.validation_loss_now())
            if validation_loss[-1] < best:
                best, stale = validation_loss[-1], 0
                best_state = {k: v.clone() for k, v in self._net.state_dict().items()}
            else:
                stale += 1
                if stale >= self.patience:
                    break
        assert best_state is not None
        self._net.load_state_dict(best_state)
        scores = self._reconstruction_error(fit_windows, last_only=True)
        self.threshold_ = float(np.quantile(scores, 1.0 - contamination))
        self._history = {
            "train_loss": train_loss,
            "validation_loss": validation_loss,
            "epochs_run": len(train_loss),
            "best_epoch": int(np.argmin(validation_loss)) + 1,
        }
        return self

    # -- fitting ------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁfit__mutmut_14(self, train: pd.DataFrame, validation: pd.DataFrame, contamination: float) -> Self:
        if not 0.0 < contamination < 0.5:
            raise ValueError("contamination must be in (0, 0.5)")
        if len(train) < self.window or len(validation) < self.window:
            raise ValueError("THE TRAINING AND VALIDATION ROWS MUST FILL AT LEAST ONE WINDOW")
        values = train[self.columns].astype(float)
        self.center_ = values.median().to_numpy()
        spread = values.std(ddof=0).to_numpy()
        self.scale_ = np.where(spread > 0, spread, 1.0)
        torch.manual_seed(self.seed)
        torch.set_num_threads(self.threads)
        torch.use_deterministic_algorithms(True)
        rng = np.random.default_rng(self.seed)
        fit_windows, _ = self._windows(train)
        if len(fit_windows) > self.fit_rows:
            fit_windows = fit_windows[rng.choice(len(fit_windows), self.fit_rows, replace=False)]
        val_windows, _ = self._windows(validation)
        if len(val_windows) > self.validation_rows:
            keep = np.sort(rng.choice(len(val_windows), self.validation_rows, replace=False))
            val_windows = val_windows[keep]
        self._validation = torch.as_tensor(val_windows, dtype=torch.float32)
        self._net = _Network(len(self.columns), self.hidden)
        optimiser = torch.optim.Adam(self._net.parameters(), lr=self.learning_rate)
        data = torch.as_tensor(fit_windows, dtype=torch.float32)
        shuffler = torch.Generator().manual_seed(self.seed)
        train_loss: list[float] = []
        validation_loss: list[float] = []
        best, best_state, stale = np.inf, None, 0
        for _epoch in range(self.max_epochs):
            self._net.train()
            order = torch.randperm(len(data), generator=shuffler)
            total = 0.0
            for start in range(0, len(data), self.batch_size):
                batch = data[order[start : start + self.batch_size]]
                optimiser.zero_grad()
                loss = nn.functional.mse_loss(self._net(batch), batch)
                loss.backward()
                optimiser.step()
                total += float(loss.detach()) * len(batch)
            train_loss.append(total / len(data))
            validation_loss.append(self.validation_loss_now())
            if validation_loss[-1] < best:
                best, stale = validation_loss[-1], 0
                best_state = {k: v.clone() for k, v in self._net.state_dict().items()}
            else:
                stale += 1
                if stale >= self.patience:
                    break
        assert best_state is not None
        self._net.load_state_dict(best_state)
        scores = self._reconstruction_error(fit_windows, last_only=True)
        self.threshold_ = float(np.quantile(scores, 1.0 - contamination))
        self._history = {
            "train_loss": train_loss,
            "validation_loss": validation_loss,
            "epochs_run": len(train_loss),
            "best_epoch": int(np.argmin(validation_loss)) + 1,
        }
        return self

    # -- fitting ------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁfit__mutmut_15(self, train: pd.DataFrame, validation: pd.DataFrame, contamination: float) -> Self:
        if not 0.0 < contamination < 0.5:
            raise ValueError("contamination must be in (0, 0.5)")
        if len(train) < self.window or len(validation) < self.window:
            raise ValueError("the training and validation rows must fill at least one window")
        values = None
        self.center_ = values.median().to_numpy()
        spread = values.std(ddof=0).to_numpy()
        self.scale_ = np.where(spread > 0, spread, 1.0)
        torch.manual_seed(self.seed)
        torch.set_num_threads(self.threads)
        torch.use_deterministic_algorithms(True)
        rng = np.random.default_rng(self.seed)
        fit_windows, _ = self._windows(train)
        if len(fit_windows) > self.fit_rows:
            fit_windows = fit_windows[rng.choice(len(fit_windows), self.fit_rows, replace=False)]
        val_windows, _ = self._windows(validation)
        if len(val_windows) > self.validation_rows:
            keep = np.sort(rng.choice(len(val_windows), self.validation_rows, replace=False))
            val_windows = val_windows[keep]
        self._validation = torch.as_tensor(val_windows, dtype=torch.float32)
        self._net = _Network(len(self.columns), self.hidden)
        optimiser = torch.optim.Adam(self._net.parameters(), lr=self.learning_rate)
        data = torch.as_tensor(fit_windows, dtype=torch.float32)
        shuffler = torch.Generator().manual_seed(self.seed)
        train_loss: list[float] = []
        validation_loss: list[float] = []
        best, best_state, stale = np.inf, None, 0
        for _epoch in range(self.max_epochs):
            self._net.train()
            order = torch.randperm(len(data), generator=shuffler)
            total = 0.0
            for start in range(0, len(data), self.batch_size):
                batch = data[order[start : start + self.batch_size]]
                optimiser.zero_grad()
                loss = nn.functional.mse_loss(self._net(batch), batch)
                loss.backward()
                optimiser.step()
                total += float(loss.detach()) * len(batch)
            train_loss.append(total / len(data))
            validation_loss.append(self.validation_loss_now())
            if validation_loss[-1] < best:
                best, stale = validation_loss[-1], 0
                best_state = {k: v.clone() for k, v in self._net.state_dict().items()}
            else:
                stale += 1
                if stale >= self.patience:
                    break
        assert best_state is not None
        self._net.load_state_dict(best_state)
        scores = self._reconstruction_error(fit_windows, last_only=True)
        self.threshold_ = float(np.quantile(scores, 1.0 - contamination))
        self._history = {
            "train_loss": train_loss,
            "validation_loss": validation_loss,
            "epochs_run": len(train_loss),
            "best_epoch": int(np.argmin(validation_loss)) + 1,
        }
        return self

    # -- fitting ------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁfit__mutmut_16(self, train: pd.DataFrame, validation: pd.DataFrame, contamination: float) -> Self:
        if not 0.0 < contamination < 0.5:
            raise ValueError("contamination must be in (0, 0.5)")
        if len(train) < self.window or len(validation) < self.window:
            raise ValueError("the training and validation rows must fill at least one window")
        values = train[self.columns].astype(None)
        self.center_ = values.median().to_numpy()
        spread = values.std(ddof=0).to_numpy()
        self.scale_ = np.where(spread > 0, spread, 1.0)
        torch.manual_seed(self.seed)
        torch.set_num_threads(self.threads)
        torch.use_deterministic_algorithms(True)
        rng = np.random.default_rng(self.seed)
        fit_windows, _ = self._windows(train)
        if len(fit_windows) > self.fit_rows:
            fit_windows = fit_windows[rng.choice(len(fit_windows), self.fit_rows, replace=False)]
        val_windows, _ = self._windows(validation)
        if len(val_windows) > self.validation_rows:
            keep = np.sort(rng.choice(len(val_windows), self.validation_rows, replace=False))
            val_windows = val_windows[keep]
        self._validation = torch.as_tensor(val_windows, dtype=torch.float32)
        self._net = _Network(len(self.columns), self.hidden)
        optimiser = torch.optim.Adam(self._net.parameters(), lr=self.learning_rate)
        data = torch.as_tensor(fit_windows, dtype=torch.float32)
        shuffler = torch.Generator().manual_seed(self.seed)
        train_loss: list[float] = []
        validation_loss: list[float] = []
        best, best_state, stale = np.inf, None, 0
        for _epoch in range(self.max_epochs):
            self._net.train()
            order = torch.randperm(len(data), generator=shuffler)
            total = 0.0
            for start in range(0, len(data), self.batch_size):
                batch = data[order[start : start + self.batch_size]]
                optimiser.zero_grad()
                loss = nn.functional.mse_loss(self._net(batch), batch)
                loss.backward()
                optimiser.step()
                total += float(loss.detach()) * len(batch)
            train_loss.append(total / len(data))
            validation_loss.append(self.validation_loss_now())
            if validation_loss[-1] < best:
                best, stale = validation_loss[-1], 0
                best_state = {k: v.clone() for k, v in self._net.state_dict().items()}
            else:
                stale += 1
                if stale >= self.patience:
                    break
        assert best_state is not None
        self._net.load_state_dict(best_state)
        scores = self._reconstruction_error(fit_windows, last_only=True)
        self.threshold_ = float(np.quantile(scores, 1.0 - contamination))
        self._history = {
            "train_loss": train_loss,
            "validation_loss": validation_loss,
            "epochs_run": len(train_loss),
            "best_epoch": int(np.argmin(validation_loss)) + 1,
        }
        return self

    # -- fitting ------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁfit__mutmut_17(self, train: pd.DataFrame, validation: pd.DataFrame, contamination: float) -> Self:
        if not 0.0 < contamination < 0.5:
            raise ValueError("contamination must be in (0, 0.5)")
        if len(train) < self.window or len(validation) < self.window:
            raise ValueError("the training and validation rows must fill at least one window")
        values = train[self.columns].astype(float)
        self.center_ = None
        spread = values.std(ddof=0).to_numpy()
        self.scale_ = np.where(spread > 0, spread, 1.0)
        torch.manual_seed(self.seed)
        torch.set_num_threads(self.threads)
        torch.use_deterministic_algorithms(True)
        rng = np.random.default_rng(self.seed)
        fit_windows, _ = self._windows(train)
        if len(fit_windows) > self.fit_rows:
            fit_windows = fit_windows[rng.choice(len(fit_windows), self.fit_rows, replace=False)]
        val_windows, _ = self._windows(validation)
        if len(val_windows) > self.validation_rows:
            keep = np.sort(rng.choice(len(val_windows), self.validation_rows, replace=False))
            val_windows = val_windows[keep]
        self._validation = torch.as_tensor(val_windows, dtype=torch.float32)
        self._net = _Network(len(self.columns), self.hidden)
        optimiser = torch.optim.Adam(self._net.parameters(), lr=self.learning_rate)
        data = torch.as_tensor(fit_windows, dtype=torch.float32)
        shuffler = torch.Generator().manual_seed(self.seed)
        train_loss: list[float] = []
        validation_loss: list[float] = []
        best, best_state, stale = np.inf, None, 0
        for _epoch in range(self.max_epochs):
            self._net.train()
            order = torch.randperm(len(data), generator=shuffler)
            total = 0.0
            for start in range(0, len(data), self.batch_size):
                batch = data[order[start : start + self.batch_size]]
                optimiser.zero_grad()
                loss = nn.functional.mse_loss(self._net(batch), batch)
                loss.backward()
                optimiser.step()
                total += float(loss.detach()) * len(batch)
            train_loss.append(total / len(data))
            validation_loss.append(self.validation_loss_now())
            if validation_loss[-1] < best:
                best, stale = validation_loss[-1], 0
                best_state = {k: v.clone() for k, v in self._net.state_dict().items()}
            else:
                stale += 1
                if stale >= self.patience:
                    break
        assert best_state is not None
        self._net.load_state_dict(best_state)
        scores = self._reconstruction_error(fit_windows, last_only=True)
        self.threshold_ = float(np.quantile(scores, 1.0 - contamination))
        self._history = {
            "train_loss": train_loss,
            "validation_loss": validation_loss,
            "epochs_run": len(train_loss),
            "best_epoch": int(np.argmin(validation_loss)) + 1,
        }
        return self

    # -- fitting ------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁfit__mutmut_18(self, train: pd.DataFrame, validation: pd.DataFrame, contamination: float) -> Self:
        if not 0.0 < contamination < 0.5:
            raise ValueError("contamination must be in (0, 0.5)")
        if len(train) < self.window or len(validation) < self.window:
            raise ValueError("the training and validation rows must fill at least one window")
        values = train[self.columns].astype(float)
        self.center_ = values.median().to_numpy()
        spread = None
        self.scale_ = np.where(spread > 0, spread, 1.0)
        torch.manual_seed(self.seed)
        torch.set_num_threads(self.threads)
        torch.use_deterministic_algorithms(True)
        rng = np.random.default_rng(self.seed)
        fit_windows, _ = self._windows(train)
        if len(fit_windows) > self.fit_rows:
            fit_windows = fit_windows[rng.choice(len(fit_windows), self.fit_rows, replace=False)]
        val_windows, _ = self._windows(validation)
        if len(val_windows) > self.validation_rows:
            keep = np.sort(rng.choice(len(val_windows), self.validation_rows, replace=False))
            val_windows = val_windows[keep]
        self._validation = torch.as_tensor(val_windows, dtype=torch.float32)
        self._net = _Network(len(self.columns), self.hidden)
        optimiser = torch.optim.Adam(self._net.parameters(), lr=self.learning_rate)
        data = torch.as_tensor(fit_windows, dtype=torch.float32)
        shuffler = torch.Generator().manual_seed(self.seed)
        train_loss: list[float] = []
        validation_loss: list[float] = []
        best, best_state, stale = np.inf, None, 0
        for _epoch in range(self.max_epochs):
            self._net.train()
            order = torch.randperm(len(data), generator=shuffler)
            total = 0.0
            for start in range(0, len(data), self.batch_size):
                batch = data[order[start : start + self.batch_size]]
                optimiser.zero_grad()
                loss = nn.functional.mse_loss(self._net(batch), batch)
                loss.backward()
                optimiser.step()
                total += float(loss.detach()) * len(batch)
            train_loss.append(total / len(data))
            validation_loss.append(self.validation_loss_now())
            if validation_loss[-1] < best:
                best, stale = validation_loss[-1], 0
                best_state = {k: v.clone() for k, v in self._net.state_dict().items()}
            else:
                stale += 1
                if stale >= self.patience:
                    break
        assert best_state is not None
        self._net.load_state_dict(best_state)
        scores = self._reconstruction_error(fit_windows, last_only=True)
        self.threshold_ = float(np.quantile(scores, 1.0 - contamination))
        self._history = {
            "train_loss": train_loss,
            "validation_loss": validation_loss,
            "epochs_run": len(train_loss),
            "best_epoch": int(np.argmin(validation_loss)) + 1,
        }
        return self

    # -- fitting ------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁfit__mutmut_19(self, train: pd.DataFrame, validation: pd.DataFrame, contamination: float) -> Self:
        if not 0.0 < contamination < 0.5:
            raise ValueError("contamination must be in (0, 0.5)")
        if len(train) < self.window or len(validation) < self.window:
            raise ValueError("the training and validation rows must fill at least one window")
        values = train[self.columns].astype(float)
        self.center_ = values.median().to_numpy()
        spread = values.std(ddof=None).to_numpy()
        self.scale_ = np.where(spread > 0, spread, 1.0)
        torch.manual_seed(self.seed)
        torch.set_num_threads(self.threads)
        torch.use_deterministic_algorithms(True)
        rng = np.random.default_rng(self.seed)
        fit_windows, _ = self._windows(train)
        if len(fit_windows) > self.fit_rows:
            fit_windows = fit_windows[rng.choice(len(fit_windows), self.fit_rows, replace=False)]
        val_windows, _ = self._windows(validation)
        if len(val_windows) > self.validation_rows:
            keep = np.sort(rng.choice(len(val_windows), self.validation_rows, replace=False))
            val_windows = val_windows[keep]
        self._validation = torch.as_tensor(val_windows, dtype=torch.float32)
        self._net = _Network(len(self.columns), self.hidden)
        optimiser = torch.optim.Adam(self._net.parameters(), lr=self.learning_rate)
        data = torch.as_tensor(fit_windows, dtype=torch.float32)
        shuffler = torch.Generator().manual_seed(self.seed)
        train_loss: list[float] = []
        validation_loss: list[float] = []
        best, best_state, stale = np.inf, None, 0
        for _epoch in range(self.max_epochs):
            self._net.train()
            order = torch.randperm(len(data), generator=shuffler)
            total = 0.0
            for start in range(0, len(data), self.batch_size):
                batch = data[order[start : start + self.batch_size]]
                optimiser.zero_grad()
                loss = nn.functional.mse_loss(self._net(batch), batch)
                loss.backward()
                optimiser.step()
                total += float(loss.detach()) * len(batch)
            train_loss.append(total / len(data))
            validation_loss.append(self.validation_loss_now())
            if validation_loss[-1] < best:
                best, stale = validation_loss[-1], 0
                best_state = {k: v.clone() for k, v in self._net.state_dict().items()}
            else:
                stale += 1
                if stale >= self.patience:
                    break
        assert best_state is not None
        self._net.load_state_dict(best_state)
        scores = self._reconstruction_error(fit_windows, last_only=True)
        self.threshold_ = float(np.quantile(scores, 1.0 - contamination))
        self._history = {
            "train_loss": train_loss,
            "validation_loss": validation_loss,
            "epochs_run": len(train_loss),
            "best_epoch": int(np.argmin(validation_loss)) + 1,
        }
        return self

    # -- fitting ------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁfit__mutmut_20(self, train: pd.DataFrame, validation: pd.DataFrame, contamination: float) -> Self:
        if not 0.0 < contamination < 0.5:
            raise ValueError("contamination must be in (0, 0.5)")
        if len(train) < self.window or len(validation) < self.window:
            raise ValueError("the training and validation rows must fill at least one window")
        values = train[self.columns].astype(float)
        self.center_ = values.median().to_numpy()
        spread = values.std(ddof=1).to_numpy()
        self.scale_ = np.where(spread > 0, spread, 1.0)
        torch.manual_seed(self.seed)
        torch.set_num_threads(self.threads)
        torch.use_deterministic_algorithms(True)
        rng = np.random.default_rng(self.seed)
        fit_windows, _ = self._windows(train)
        if len(fit_windows) > self.fit_rows:
            fit_windows = fit_windows[rng.choice(len(fit_windows), self.fit_rows, replace=False)]
        val_windows, _ = self._windows(validation)
        if len(val_windows) > self.validation_rows:
            keep = np.sort(rng.choice(len(val_windows), self.validation_rows, replace=False))
            val_windows = val_windows[keep]
        self._validation = torch.as_tensor(val_windows, dtype=torch.float32)
        self._net = _Network(len(self.columns), self.hidden)
        optimiser = torch.optim.Adam(self._net.parameters(), lr=self.learning_rate)
        data = torch.as_tensor(fit_windows, dtype=torch.float32)
        shuffler = torch.Generator().manual_seed(self.seed)
        train_loss: list[float] = []
        validation_loss: list[float] = []
        best, best_state, stale = np.inf, None, 0
        for _epoch in range(self.max_epochs):
            self._net.train()
            order = torch.randperm(len(data), generator=shuffler)
            total = 0.0
            for start in range(0, len(data), self.batch_size):
                batch = data[order[start : start + self.batch_size]]
                optimiser.zero_grad()
                loss = nn.functional.mse_loss(self._net(batch), batch)
                loss.backward()
                optimiser.step()
                total += float(loss.detach()) * len(batch)
            train_loss.append(total / len(data))
            validation_loss.append(self.validation_loss_now())
            if validation_loss[-1] < best:
                best, stale = validation_loss[-1], 0
                best_state = {k: v.clone() for k, v in self._net.state_dict().items()}
            else:
                stale += 1
                if stale >= self.patience:
                    break
        assert best_state is not None
        self._net.load_state_dict(best_state)
        scores = self._reconstruction_error(fit_windows, last_only=True)
        self.threshold_ = float(np.quantile(scores, 1.0 - contamination))
        self._history = {
            "train_loss": train_loss,
            "validation_loss": validation_loss,
            "epochs_run": len(train_loss),
            "best_epoch": int(np.argmin(validation_loss)) + 1,
        }
        return self

    # -- fitting ------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁfit__mutmut_21(self, train: pd.DataFrame, validation: pd.DataFrame, contamination: float) -> Self:
        if not 0.0 < contamination < 0.5:
            raise ValueError("contamination must be in (0, 0.5)")
        if len(train) < self.window or len(validation) < self.window:
            raise ValueError("the training and validation rows must fill at least one window")
        values = train[self.columns].astype(float)
        self.center_ = values.median().to_numpy()
        spread = values.std(ddof=0).to_numpy()
        self.scale_ = None
        torch.manual_seed(self.seed)
        torch.set_num_threads(self.threads)
        torch.use_deterministic_algorithms(True)
        rng = np.random.default_rng(self.seed)
        fit_windows, _ = self._windows(train)
        if len(fit_windows) > self.fit_rows:
            fit_windows = fit_windows[rng.choice(len(fit_windows), self.fit_rows, replace=False)]
        val_windows, _ = self._windows(validation)
        if len(val_windows) > self.validation_rows:
            keep = np.sort(rng.choice(len(val_windows), self.validation_rows, replace=False))
            val_windows = val_windows[keep]
        self._validation = torch.as_tensor(val_windows, dtype=torch.float32)
        self._net = _Network(len(self.columns), self.hidden)
        optimiser = torch.optim.Adam(self._net.parameters(), lr=self.learning_rate)
        data = torch.as_tensor(fit_windows, dtype=torch.float32)
        shuffler = torch.Generator().manual_seed(self.seed)
        train_loss: list[float] = []
        validation_loss: list[float] = []
        best, best_state, stale = np.inf, None, 0
        for _epoch in range(self.max_epochs):
            self._net.train()
            order = torch.randperm(len(data), generator=shuffler)
            total = 0.0
            for start in range(0, len(data), self.batch_size):
                batch = data[order[start : start + self.batch_size]]
                optimiser.zero_grad()
                loss = nn.functional.mse_loss(self._net(batch), batch)
                loss.backward()
                optimiser.step()
                total += float(loss.detach()) * len(batch)
            train_loss.append(total / len(data))
            validation_loss.append(self.validation_loss_now())
            if validation_loss[-1] < best:
                best, stale = validation_loss[-1], 0
                best_state = {k: v.clone() for k, v in self._net.state_dict().items()}
            else:
                stale += 1
                if stale >= self.patience:
                    break
        assert best_state is not None
        self._net.load_state_dict(best_state)
        scores = self._reconstruction_error(fit_windows, last_only=True)
        self.threshold_ = float(np.quantile(scores, 1.0 - contamination))
        self._history = {
            "train_loss": train_loss,
            "validation_loss": validation_loss,
            "epochs_run": len(train_loss),
            "best_epoch": int(np.argmin(validation_loss)) + 1,
        }
        return self

    # -- fitting ------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁfit__mutmut_22(self, train: pd.DataFrame, validation: pd.DataFrame, contamination: float) -> Self:
        if not 0.0 < contamination < 0.5:
            raise ValueError("contamination must be in (0, 0.5)")
        if len(train) < self.window or len(validation) < self.window:
            raise ValueError("the training and validation rows must fill at least one window")
        values = train[self.columns].astype(float)
        self.center_ = values.median().to_numpy()
        spread = values.std(ddof=0).to_numpy()
        self.scale_ = np.where(None, spread, 1.0)
        torch.manual_seed(self.seed)
        torch.set_num_threads(self.threads)
        torch.use_deterministic_algorithms(True)
        rng = np.random.default_rng(self.seed)
        fit_windows, _ = self._windows(train)
        if len(fit_windows) > self.fit_rows:
            fit_windows = fit_windows[rng.choice(len(fit_windows), self.fit_rows, replace=False)]
        val_windows, _ = self._windows(validation)
        if len(val_windows) > self.validation_rows:
            keep = np.sort(rng.choice(len(val_windows), self.validation_rows, replace=False))
            val_windows = val_windows[keep]
        self._validation = torch.as_tensor(val_windows, dtype=torch.float32)
        self._net = _Network(len(self.columns), self.hidden)
        optimiser = torch.optim.Adam(self._net.parameters(), lr=self.learning_rate)
        data = torch.as_tensor(fit_windows, dtype=torch.float32)
        shuffler = torch.Generator().manual_seed(self.seed)
        train_loss: list[float] = []
        validation_loss: list[float] = []
        best, best_state, stale = np.inf, None, 0
        for _epoch in range(self.max_epochs):
            self._net.train()
            order = torch.randperm(len(data), generator=shuffler)
            total = 0.0
            for start in range(0, len(data), self.batch_size):
                batch = data[order[start : start + self.batch_size]]
                optimiser.zero_grad()
                loss = nn.functional.mse_loss(self._net(batch), batch)
                loss.backward()
                optimiser.step()
                total += float(loss.detach()) * len(batch)
            train_loss.append(total / len(data))
            validation_loss.append(self.validation_loss_now())
            if validation_loss[-1] < best:
                best, stale = validation_loss[-1], 0
                best_state = {k: v.clone() for k, v in self._net.state_dict().items()}
            else:
                stale += 1
                if stale >= self.patience:
                    break
        assert best_state is not None
        self._net.load_state_dict(best_state)
        scores = self._reconstruction_error(fit_windows, last_only=True)
        self.threshold_ = float(np.quantile(scores, 1.0 - contamination))
        self._history = {
            "train_loss": train_loss,
            "validation_loss": validation_loss,
            "epochs_run": len(train_loss),
            "best_epoch": int(np.argmin(validation_loss)) + 1,
        }
        return self

    # -- fitting ------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁfit__mutmut_23(self, train: pd.DataFrame, validation: pd.DataFrame, contamination: float) -> Self:
        if not 0.0 < contamination < 0.5:
            raise ValueError("contamination must be in (0, 0.5)")
        if len(train) < self.window or len(validation) < self.window:
            raise ValueError("the training and validation rows must fill at least one window")
        values = train[self.columns].astype(float)
        self.center_ = values.median().to_numpy()
        spread = values.std(ddof=0).to_numpy()
        self.scale_ = np.where(spread > 0, None, 1.0)
        torch.manual_seed(self.seed)
        torch.set_num_threads(self.threads)
        torch.use_deterministic_algorithms(True)
        rng = np.random.default_rng(self.seed)
        fit_windows, _ = self._windows(train)
        if len(fit_windows) > self.fit_rows:
            fit_windows = fit_windows[rng.choice(len(fit_windows), self.fit_rows, replace=False)]
        val_windows, _ = self._windows(validation)
        if len(val_windows) > self.validation_rows:
            keep = np.sort(rng.choice(len(val_windows), self.validation_rows, replace=False))
            val_windows = val_windows[keep]
        self._validation = torch.as_tensor(val_windows, dtype=torch.float32)
        self._net = _Network(len(self.columns), self.hidden)
        optimiser = torch.optim.Adam(self._net.parameters(), lr=self.learning_rate)
        data = torch.as_tensor(fit_windows, dtype=torch.float32)
        shuffler = torch.Generator().manual_seed(self.seed)
        train_loss: list[float] = []
        validation_loss: list[float] = []
        best, best_state, stale = np.inf, None, 0
        for _epoch in range(self.max_epochs):
            self._net.train()
            order = torch.randperm(len(data), generator=shuffler)
            total = 0.0
            for start in range(0, len(data), self.batch_size):
                batch = data[order[start : start + self.batch_size]]
                optimiser.zero_grad()
                loss = nn.functional.mse_loss(self._net(batch), batch)
                loss.backward()
                optimiser.step()
                total += float(loss.detach()) * len(batch)
            train_loss.append(total / len(data))
            validation_loss.append(self.validation_loss_now())
            if validation_loss[-1] < best:
                best, stale = validation_loss[-1], 0
                best_state = {k: v.clone() for k, v in self._net.state_dict().items()}
            else:
                stale += 1
                if stale >= self.patience:
                    break
        assert best_state is not None
        self._net.load_state_dict(best_state)
        scores = self._reconstruction_error(fit_windows, last_only=True)
        self.threshold_ = float(np.quantile(scores, 1.0 - contamination))
        self._history = {
            "train_loss": train_loss,
            "validation_loss": validation_loss,
            "epochs_run": len(train_loss),
            "best_epoch": int(np.argmin(validation_loss)) + 1,
        }
        return self

    # -- fitting ------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁfit__mutmut_24(self, train: pd.DataFrame, validation: pd.DataFrame, contamination: float) -> Self:
        if not 0.0 < contamination < 0.5:
            raise ValueError("contamination must be in (0, 0.5)")
        if len(train) < self.window or len(validation) < self.window:
            raise ValueError("the training and validation rows must fill at least one window")
        values = train[self.columns].astype(float)
        self.center_ = values.median().to_numpy()
        spread = values.std(ddof=0).to_numpy()
        self.scale_ = np.where(spread > 0, spread, None)
        torch.manual_seed(self.seed)
        torch.set_num_threads(self.threads)
        torch.use_deterministic_algorithms(True)
        rng = np.random.default_rng(self.seed)
        fit_windows, _ = self._windows(train)
        if len(fit_windows) > self.fit_rows:
            fit_windows = fit_windows[rng.choice(len(fit_windows), self.fit_rows, replace=False)]
        val_windows, _ = self._windows(validation)
        if len(val_windows) > self.validation_rows:
            keep = np.sort(rng.choice(len(val_windows), self.validation_rows, replace=False))
            val_windows = val_windows[keep]
        self._validation = torch.as_tensor(val_windows, dtype=torch.float32)
        self._net = _Network(len(self.columns), self.hidden)
        optimiser = torch.optim.Adam(self._net.parameters(), lr=self.learning_rate)
        data = torch.as_tensor(fit_windows, dtype=torch.float32)
        shuffler = torch.Generator().manual_seed(self.seed)
        train_loss: list[float] = []
        validation_loss: list[float] = []
        best, best_state, stale = np.inf, None, 0
        for _epoch in range(self.max_epochs):
            self._net.train()
            order = torch.randperm(len(data), generator=shuffler)
            total = 0.0
            for start in range(0, len(data), self.batch_size):
                batch = data[order[start : start + self.batch_size]]
                optimiser.zero_grad()
                loss = nn.functional.mse_loss(self._net(batch), batch)
                loss.backward()
                optimiser.step()
                total += float(loss.detach()) * len(batch)
            train_loss.append(total / len(data))
            validation_loss.append(self.validation_loss_now())
            if validation_loss[-1] < best:
                best, stale = validation_loss[-1], 0
                best_state = {k: v.clone() for k, v in self._net.state_dict().items()}
            else:
                stale += 1
                if stale >= self.patience:
                    break
        assert best_state is not None
        self._net.load_state_dict(best_state)
        scores = self._reconstruction_error(fit_windows, last_only=True)
        self.threshold_ = float(np.quantile(scores, 1.0 - contamination))
        self._history = {
            "train_loss": train_loss,
            "validation_loss": validation_loss,
            "epochs_run": len(train_loss),
            "best_epoch": int(np.argmin(validation_loss)) + 1,
        }
        return self

    # -- fitting ------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁfit__mutmut_25(self, train: pd.DataFrame, validation: pd.DataFrame, contamination: float) -> Self:
        if not 0.0 < contamination < 0.5:
            raise ValueError("contamination must be in (0, 0.5)")
        if len(train) < self.window or len(validation) < self.window:
            raise ValueError("the training and validation rows must fill at least one window")
        values = train[self.columns].astype(float)
        self.center_ = values.median().to_numpy()
        spread = values.std(ddof=0).to_numpy()
        self.scale_ = np.where(spread, 1.0)
        torch.manual_seed(self.seed)
        torch.set_num_threads(self.threads)
        torch.use_deterministic_algorithms(True)
        rng = np.random.default_rng(self.seed)
        fit_windows, _ = self._windows(train)
        if len(fit_windows) > self.fit_rows:
            fit_windows = fit_windows[rng.choice(len(fit_windows), self.fit_rows, replace=False)]
        val_windows, _ = self._windows(validation)
        if len(val_windows) > self.validation_rows:
            keep = np.sort(rng.choice(len(val_windows), self.validation_rows, replace=False))
            val_windows = val_windows[keep]
        self._validation = torch.as_tensor(val_windows, dtype=torch.float32)
        self._net = _Network(len(self.columns), self.hidden)
        optimiser = torch.optim.Adam(self._net.parameters(), lr=self.learning_rate)
        data = torch.as_tensor(fit_windows, dtype=torch.float32)
        shuffler = torch.Generator().manual_seed(self.seed)
        train_loss: list[float] = []
        validation_loss: list[float] = []
        best, best_state, stale = np.inf, None, 0
        for _epoch in range(self.max_epochs):
            self._net.train()
            order = torch.randperm(len(data), generator=shuffler)
            total = 0.0
            for start in range(0, len(data), self.batch_size):
                batch = data[order[start : start + self.batch_size]]
                optimiser.zero_grad()
                loss = nn.functional.mse_loss(self._net(batch), batch)
                loss.backward()
                optimiser.step()
                total += float(loss.detach()) * len(batch)
            train_loss.append(total / len(data))
            validation_loss.append(self.validation_loss_now())
            if validation_loss[-1] < best:
                best, stale = validation_loss[-1], 0
                best_state = {k: v.clone() for k, v in self._net.state_dict().items()}
            else:
                stale += 1
                if stale >= self.patience:
                    break
        assert best_state is not None
        self._net.load_state_dict(best_state)
        scores = self._reconstruction_error(fit_windows, last_only=True)
        self.threshold_ = float(np.quantile(scores, 1.0 - contamination))
        self._history = {
            "train_loss": train_loss,
            "validation_loss": validation_loss,
            "epochs_run": len(train_loss),
            "best_epoch": int(np.argmin(validation_loss)) + 1,
        }
        return self

    # -- fitting ------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁfit__mutmut_26(self, train: pd.DataFrame, validation: pd.DataFrame, contamination: float) -> Self:
        if not 0.0 < contamination < 0.5:
            raise ValueError("contamination must be in (0, 0.5)")
        if len(train) < self.window or len(validation) < self.window:
            raise ValueError("the training and validation rows must fill at least one window")
        values = train[self.columns].astype(float)
        self.center_ = values.median().to_numpy()
        spread = values.std(ddof=0).to_numpy()
        self.scale_ = np.where(spread > 0, 1.0)
        torch.manual_seed(self.seed)
        torch.set_num_threads(self.threads)
        torch.use_deterministic_algorithms(True)
        rng = np.random.default_rng(self.seed)
        fit_windows, _ = self._windows(train)
        if len(fit_windows) > self.fit_rows:
            fit_windows = fit_windows[rng.choice(len(fit_windows), self.fit_rows, replace=False)]
        val_windows, _ = self._windows(validation)
        if len(val_windows) > self.validation_rows:
            keep = np.sort(rng.choice(len(val_windows), self.validation_rows, replace=False))
            val_windows = val_windows[keep]
        self._validation = torch.as_tensor(val_windows, dtype=torch.float32)
        self._net = _Network(len(self.columns), self.hidden)
        optimiser = torch.optim.Adam(self._net.parameters(), lr=self.learning_rate)
        data = torch.as_tensor(fit_windows, dtype=torch.float32)
        shuffler = torch.Generator().manual_seed(self.seed)
        train_loss: list[float] = []
        validation_loss: list[float] = []
        best, best_state, stale = np.inf, None, 0
        for _epoch in range(self.max_epochs):
            self._net.train()
            order = torch.randperm(len(data), generator=shuffler)
            total = 0.0
            for start in range(0, len(data), self.batch_size):
                batch = data[order[start : start + self.batch_size]]
                optimiser.zero_grad()
                loss = nn.functional.mse_loss(self._net(batch), batch)
                loss.backward()
                optimiser.step()
                total += float(loss.detach()) * len(batch)
            train_loss.append(total / len(data))
            validation_loss.append(self.validation_loss_now())
            if validation_loss[-1] < best:
                best, stale = validation_loss[-1], 0
                best_state = {k: v.clone() for k, v in self._net.state_dict().items()}
            else:
                stale += 1
                if stale >= self.patience:
                    break
        assert best_state is not None
        self._net.load_state_dict(best_state)
        scores = self._reconstruction_error(fit_windows, last_only=True)
        self.threshold_ = float(np.quantile(scores, 1.0 - contamination))
        self._history = {
            "train_loss": train_loss,
            "validation_loss": validation_loss,
            "epochs_run": len(train_loss),
            "best_epoch": int(np.argmin(validation_loss)) + 1,
        }
        return self

    # -- fitting ------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁfit__mutmut_27(self, train: pd.DataFrame, validation: pd.DataFrame, contamination: float) -> Self:
        if not 0.0 < contamination < 0.5:
            raise ValueError("contamination must be in (0, 0.5)")
        if len(train) < self.window or len(validation) < self.window:
            raise ValueError("the training and validation rows must fill at least one window")
        values = train[self.columns].astype(float)
        self.center_ = values.median().to_numpy()
        spread = values.std(ddof=0).to_numpy()
        self.scale_ = np.where(spread > 0, spread, )
        torch.manual_seed(self.seed)
        torch.set_num_threads(self.threads)
        torch.use_deterministic_algorithms(True)
        rng = np.random.default_rng(self.seed)
        fit_windows, _ = self._windows(train)
        if len(fit_windows) > self.fit_rows:
            fit_windows = fit_windows[rng.choice(len(fit_windows), self.fit_rows, replace=False)]
        val_windows, _ = self._windows(validation)
        if len(val_windows) > self.validation_rows:
            keep = np.sort(rng.choice(len(val_windows), self.validation_rows, replace=False))
            val_windows = val_windows[keep]
        self._validation = torch.as_tensor(val_windows, dtype=torch.float32)
        self._net = _Network(len(self.columns), self.hidden)
        optimiser = torch.optim.Adam(self._net.parameters(), lr=self.learning_rate)
        data = torch.as_tensor(fit_windows, dtype=torch.float32)
        shuffler = torch.Generator().manual_seed(self.seed)
        train_loss: list[float] = []
        validation_loss: list[float] = []
        best, best_state, stale = np.inf, None, 0
        for _epoch in range(self.max_epochs):
            self._net.train()
            order = torch.randperm(len(data), generator=shuffler)
            total = 0.0
            for start in range(0, len(data), self.batch_size):
                batch = data[order[start : start + self.batch_size]]
                optimiser.zero_grad()
                loss = nn.functional.mse_loss(self._net(batch), batch)
                loss.backward()
                optimiser.step()
                total += float(loss.detach()) * len(batch)
            train_loss.append(total / len(data))
            validation_loss.append(self.validation_loss_now())
            if validation_loss[-1] < best:
                best, stale = validation_loss[-1], 0
                best_state = {k: v.clone() for k, v in self._net.state_dict().items()}
            else:
                stale += 1
                if stale >= self.patience:
                    break
        assert best_state is not None
        self._net.load_state_dict(best_state)
        scores = self._reconstruction_error(fit_windows, last_only=True)
        self.threshold_ = float(np.quantile(scores, 1.0 - contamination))
        self._history = {
            "train_loss": train_loss,
            "validation_loss": validation_loss,
            "epochs_run": len(train_loss),
            "best_epoch": int(np.argmin(validation_loss)) + 1,
        }
        return self

    # -- fitting ------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁfit__mutmut_28(self, train: pd.DataFrame, validation: pd.DataFrame, contamination: float) -> Self:
        if not 0.0 < contamination < 0.5:
            raise ValueError("contamination must be in (0, 0.5)")
        if len(train) < self.window or len(validation) < self.window:
            raise ValueError("the training and validation rows must fill at least one window")
        values = train[self.columns].astype(float)
        self.center_ = values.median().to_numpy()
        spread = values.std(ddof=0).to_numpy()
        self.scale_ = np.where(spread >= 0, spread, 1.0)
        torch.manual_seed(self.seed)
        torch.set_num_threads(self.threads)
        torch.use_deterministic_algorithms(True)
        rng = np.random.default_rng(self.seed)
        fit_windows, _ = self._windows(train)
        if len(fit_windows) > self.fit_rows:
            fit_windows = fit_windows[rng.choice(len(fit_windows), self.fit_rows, replace=False)]
        val_windows, _ = self._windows(validation)
        if len(val_windows) > self.validation_rows:
            keep = np.sort(rng.choice(len(val_windows), self.validation_rows, replace=False))
            val_windows = val_windows[keep]
        self._validation = torch.as_tensor(val_windows, dtype=torch.float32)
        self._net = _Network(len(self.columns), self.hidden)
        optimiser = torch.optim.Adam(self._net.parameters(), lr=self.learning_rate)
        data = torch.as_tensor(fit_windows, dtype=torch.float32)
        shuffler = torch.Generator().manual_seed(self.seed)
        train_loss: list[float] = []
        validation_loss: list[float] = []
        best, best_state, stale = np.inf, None, 0
        for _epoch in range(self.max_epochs):
            self._net.train()
            order = torch.randperm(len(data), generator=shuffler)
            total = 0.0
            for start in range(0, len(data), self.batch_size):
                batch = data[order[start : start + self.batch_size]]
                optimiser.zero_grad()
                loss = nn.functional.mse_loss(self._net(batch), batch)
                loss.backward()
                optimiser.step()
                total += float(loss.detach()) * len(batch)
            train_loss.append(total / len(data))
            validation_loss.append(self.validation_loss_now())
            if validation_loss[-1] < best:
                best, stale = validation_loss[-1], 0
                best_state = {k: v.clone() for k, v in self._net.state_dict().items()}
            else:
                stale += 1
                if stale >= self.patience:
                    break
        assert best_state is not None
        self._net.load_state_dict(best_state)
        scores = self._reconstruction_error(fit_windows, last_only=True)
        self.threshold_ = float(np.quantile(scores, 1.0 - contamination))
        self._history = {
            "train_loss": train_loss,
            "validation_loss": validation_loss,
            "epochs_run": len(train_loss),
            "best_epoch": int(np.argmin(validation_loss)) + 1,
        }
        return self

    # -- fitting ------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁfit__mutmut_29(self, train: pd.DataFrame, validation: pd.DataFrame, contamination: float) -> Self:
        if not 0.0 < contamination < 0.5:
            raise ValueError("contamination must be in (0, 0.5)")
        if len(train) < self.window or len(validation) < self.window:
            raise ValueError("the training and validation rows must fill at least one window")
        values = train[self.columns].astype(float)
        self.center_ = values.median().to_numpy()
        spread = values.std(ddof=0).to_numpy()
        self.scale_ = np.where(spread > 1, spread, 1.0)
        torch.manual_seed(self.seed)
        torch.set_num_threads(self.threads)
        torch.use_deterministic_algorithms(True)
        rng = np.random.default_rng(self.seed)
        fit_windows, _ = self._windows(train)
        if len(fit_windows) > self.fit_rows:
            fit_windows = fit_windows[rng.choice(len(fit_windows), self.fit_rows, replace=False)]
        val_windows, _ = self._windows(validation)
        if len(val_windows) > self.validation_rows:
            keep = np.sort(rng.choice(len(val_windows), self.validation_rows, replace=False))
            val_windows = val_windows[keep]
        self._validation = torch.as_tensor(val_windows, dtype=torch.float32)
        self._net = _Network(len(self.columns), self.hidden)
        optimiser = torch.optim.Adam(self._net.parameters(), lr=self.learning_rate)
        data = torch.as_tensor(fit_windows, dtype=torch.float32)
        shuffler = torch.Generator().manual_seed(self.seed)
        train_loss: list[float] = []
        validation_loss: list[float] = []
        best, best_state, stale = np.inf, None, 0
        for _epoch in range(self.max_epochs):
            self._net.train()
            order = torch.randperm(len(data), generator=shuffler)
            total = 0.0
            for start in range(0, len(data), self.batch_size):
                batch = data[order[start : start + self.batch_size]]
                optimiser.zero_grad()
                loss = nn.functional.mse_loss(self._net(batch), batch)
                loss.backward()
                optimiser.step()
                total += float(loss.detach()) * len(batch)
            train_loss.append(total / len(data))
            validation_loss.append(self.validation_loss_now())
            if validation_loss[-1] < best:
                best, stale = validation_loss[-1], 0
                best_state = {k: v.clone() for k, v in self._net.state_dict().items()}
            else:
                stale += 1
                if stale >= self.patience:
                    break
        assert best_state is not None
        self._net.load_state_dict(best_state)
        scores = self._reconstruction_error(fit_windows, last_only=True)
        self.threshold_ = float(np.quantile(scores, 1.0 - contamination))
        self._history = {
            "train_loss": train_loss,
            "validation_loss": validation_loss,
            "epochs_run": len(train_loss),
            "best_epoch": int(np.argmin(validation_loss)) + 1,
        }
        return self

    # -- fitting ------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁfit__mutmut_30(self, train: pd.DataFrame, validation: pd.DataFrame, contamination: float) -> Self:
        if not 0.0 < contamination < 0.5:
            raise ValueError("contamination must be in (0, 0.5)")
        if len(train) < self.window or len(validation) < self.window:
            raise ValueError("the training and validation rows must fill at least one window")
        values = train[self.columns].astype(float)
        self.center_ = values.median().to_numpy()
        spread = values.std(ddof=0).to_numpy()
        self.scale_ = np.where(spread > 0, spread, 2.0)
        torch.manual_seed(self.seed)
        torch.set_num_threads(self.threads)
        torch.use_deterministic_algorithms(True)
        rng = np.random.default_rng(self.seed)
        fit_windows, _ = self._windows(train)
        if len(fit_windows) > self.fit_rows:
            fit_windows = fit_windows[rng.choice(len(fit_windows), self.fit_rows, replace=False)]
        val_windows, _ = self._windows(validation)
        if len(val_windows) > self.validation_rows:
            keep = np.sort(rng.choice(len(val_windows), self.validation_rows, replace=False))
            val_windows = val_windows[keep]
        self._validation = torch.as_tensor(val_windows, dtype=torch.float32)
        self._net = _Network(len(self.columns), self.hidden)
        optimiser = torch.optim.Adam(self._net.parameters(), lr=self.learning_rate)
        data = torch.as_tensor(fit_windows, dtype=torch.float32)
        shuffler = torch.Generator().manual_seed(self.seed)
        train_loss: list[float] = []
        validation_loss: list[float] = []
        best, best_state, stale = np.inf, None, 0
        for _epoch in range(self.max_epochs):
            self._net.train()
            order = torch.randperm(len(data), generator=shuffler)
            total = 0.0
            for start in range(0, len(data), self.batch_size):
                batch = data[order[start : start + self.batch_size]]
                optimiser.zero_grad()
                loss = nn.functional.mse_loss(self._net(batch), batch)
                loss.backward()
                optimiser.step()
                total += float(loss.detach()) * len(batch)
            train_loss.append(total / len(data))
            validation_loss.append(self.validation_loss_now())
            if validation_loss[-1] < best:
                best, stale = validation_loss[-1], 0
                best_state = {k: v.clone() for k, v in self._net.state_dict().items()}
            else:
                stale += 1
                if stale >= self.patience:
                    break
        assert best_state is not None
        self._net.load_state_dict(best_state)
        scores = self._reconstruction_error(fit_windows, last_only=True)
        self.threshold_ = float(np.quantile(scores, 1.0 - contamination))
        self._history = {
            "train_loss": train_loss,
            "validation_loss": validation_loss,
            "epochs_run": len(train_loss),
            "best_epoch": int(np.argmin(validation_loss)) + 1,
        }
        return self

    # -- fitting ------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁfit__mutmut_31(self, train: pd.DataFrame, validation: pd.DataFrame, contamination: float) -> Self:
        if not 0.0 < contamination < 0.5:
            raise ValueError("contamination must be in (0, 0.5)")
        if len(train) < self.window or len(validation) < self.window:
            raise ValueError("the training and validation rows must fill at least one window")
        values = train[self.columns].astype(float)
        self.center_ = values.median().to_numpy()
        spread = values.std(ddof=0).to_numpy()
        self.scale_ = np.where(spread > 0, spread, 1.0)
        torch.manual_seed(None)
        torch.set_num_threads(self.threads)
        torch.use_deterministic_algorithms(True)
        rng = np.random.default_rng(self.seed)
        fit_windows, _ = self._windows(train)
        if len(fit_windows) > self.fit_rows:
            fit_windows = fit_windows[rng.choice(len(fit_windows), self.fit_rows, replace=False)]
        val_windows, _ = self._windows(validation)
        if len(val_windows) > self.validation_rows:
            keep = np.sort(rng.choice(len(val_windows), self.validation_rows, replace=False))
            val_windows = val_windows[keep]
        self._validation = torch.as_tensor(val_windows, dtype=torch.float32)
        self._net = _Network(len(self.columns), self.hidden)
        optimiser = torch.optim.Adam(self._net.parameters(), lr=self.learning_rate)
        data = torch.as_tensor(fit_windows, dtype=torch.float32)
        shuffler = torch.Generator().manual_seed(self.seed)
        train_loss: list[float] = []
        validation_loss: list[float] = []
        best, best_state, stale = np.inf, None, 0
        for _epoch in range(self.max_epochs):
            self._net.train()
            order = torch.randperm(len(data), generator=shuffler)
            total = 0.0
            for start in range(0, len(data), self.batch_size):
                batch = data[order[start : start + self.batch_size]]
                optimiser.zero_grad()
                loss = nn.functional.mse_loss(self._net(batch), batch)
                loss.backward()
                optimiser.step()
                total += float(loss.detach()) * len(batch)
            train_loss.append(total / len(data))
            validation_loss.append(self.validation_loss_now())
            if validation_loss[-1] < best:
                best, stale = validation_loss[-1], 0
                best_state = {k: v.clone() for k, v in self._net.state_dict().items()}
            else:
                stale += 1
                if stale >= self.patience:
                    break
        assert best_state is not None
        self._net.load_state_dict(best_state)
        scores = self._reconstruction_error(fit_windows, last_only=True)
        self.threshold_ = float(np.quantile(scores, 1.0 - contamination))
        self._history = {
            "train_loss": train_loss,
            "validation_loss": validation_loss,
            "epochs_run": len(train_loss),
            "best_epoch": int(np.argmin(validation_loss)) + 1,
        }
        return self

    # -- fitting ------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁfit__mutmut_32(self, train: pd.DataFrame, validation: pd.DataFrame, contamination: float) -> Self:
        if not 0.0 < contamination < 0.5:
            raise ValueError("contamination must be in (0, 0.5)")
        if len(train) < self.window or len(validation) < self.window:
            raise ValueError("the training and validation rows must fill at least one window")
        values = train[self.columns].astype(float)
        self.center_ = values.median().to_numpy()
        spread = values.std(ddof=0).to_numpy()
        self.scale_ = np.where(spread > 0, spread, 1.0)
        torch.manual_seed(self.seed)
        torch.set_num_threads(None)
        torch.use_deterministic_algorithms(True)
        rng = np.random.default_rng(self.seed)
        fit_windows, _ = self._windows(train)
        if len(fit_windows) > self.fit_rows:
            fit_windows = fit_windows[rng.choice(len(fit_windows), self.fit_rows, replace=False)]
        val_windows, _ = self._windows(validation)
        if len(val_windows) > self.validation_rows:
            keep = np.sort(rng.choice(len(val_windows), self.validation_rows, replace=False))
            val_windows = val_windows[keep]
        self._validation = torch.as_tensor(val_windows, dtype=torch.float32)
        self._net = _Network(len(self.columns), self.hidden)
        optimiser = torch.optim.Adam(self._net.parameters(), lr=self.learning_rate)
        data = torch.as_tensor(fit_windows, dtype=torch.float32)
        shuffler = torch.Generator().manual_seed(self.seed)
        train_loss: list[float] = []
        validation_loss: list[float] = []
        best, best_state, stale = np.inf, None, 0
        for _epoch in range(self.max_epochs):
            self._net.train()
            order = torch.randperm(len(data), generator=shuffler)
            total = 0.0
            for start in range(0, len(data), self.batch_size):
                batch = data[order[start : start + self.batch_size]]
                optimiser.zero_grad()
                loss = nn.functional.mse_loss(self._net(batch), batch)
                loss.backward()
                optimiser.step()
                total += float(loss.detach()) * len(batch)
            train_loss.append(total / len(data))
            validation_loss.append(self.validation_loss_now())
            if validation_loss[-1] < best:
                best, stale = validation_loss[-1], 0
                best_state = {k: v.clone() for k, v in self._net.state_dict().items()}
            else:
                stale += 1
                if stale >= self.patience:
                    break
        assert best_state is not None
        self._net.load_state_dict(best_state)
        scores = self._reconstruction_error(fit_windows, last_only=True)
        self.threshold_ = float(np.quantile(scores, 1.0 - contamination))
        self._history = {
            "train_loss": train_loss,
            "validation_loss": validation_loss,
            "epochs_run": len(train_loss),
            "best_epoch": int(np.argmin(validation_loss)) + 1,
        }
        return self

    # -- fitting ------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁfit__mutmut_33(self, train: pd.DataFrame, validation: pd.DataFrame, contamination: float) -> Self:
        if not 0.0 < contamination < 0.5:
            raise ValueError("contamination must be in (0, 0.5)")
        if len(train) < self.window or len(validation) < self.window:
            raise ValueError("the training and validation rows must fill at least one window")
        values = train[self.columns].astype(float)
        self.center_ = values.median().to_numpy()
        spread = values.std(ddof=0).to_numpy()
        self.scale_ = np.where(spread > 0, spread, 1.0)
        torch.manual_seed(self.seed)
        torch.set_num_threads(self.threads)
        torch.use_deterministic_algorithms(None)
        rng = np.random.default_rng(self.seed)
        fit_windows, _ = self._windows(train)
        if len(fit_windows) > self.fit_rows:
            fit_windows = fit_windows[rng.choice(len(fit_windows), self.fit_rows, replace=False)]
        val_windows, _ = self._windows(validation)
        if len(val_windows) > self.validation_rows:
            keep = np.sort(rng.choice(len(val_windows), self.validation_rows, replace=False))
            val_windows = val_windows[keep]
        self._validation = torch.as_tensor(val_windows, dtype=torch.float32)
        self._net = _Network(len(self.columns), self.hidden)
        optimiser = torch.optim.Adam(self._net.parameters(), lr=self.learning_rate)
        data = torch.as_tensor(fit_windows, dtype=torch.float32)
        shuffler = torch.Generator().manual_seed(self.seed)
        train_loss: list[float] = []
        validation_loss: list[float] = []
        best, best_state, stale = np.inf, None, 0
        for _epoch in range(self.max_epochs):
            self._net.train()
            order = torch.randperm(len(data), generator=shuffler)
            total = 0.0
            for start in range(0, len(data), self.batch_size):
                batch = data[order[start : start + self.batch_size]]
                optimiser.zero_grad()
                loss = nn.functional.mse_loss(self._net(batch), batch)
                loss.backward()
                optimiser.step()
                total += float(loss.detach()) * len(batch)
            train_loss.append(total / len(data))
            validation_loss.append(self.validation_loss_now())
            if validation_loss[-1] < best:
                best, stale = validation_loss[-1], 0
                best_state = {k: v.clone() for k, v in self._net.state_dict().items()}
            else:
                stale += 1
                if stale >= self.patience:
                    break
        assert best_state is not None
        self._net.load_state_dict(best_state)
        scores = self._reconstruction_error(fit_windows, last_only=True)
        self.threshold_ = float(np.quantile(scores, 1.0 - contamination))
        self._history = {
            "train_loss": train_loss,
            "validation_loss": validation_loss,
            "epochs_run": len(train_loss),
            "best_epoch": int(np.argmin(validation_loss)) + 1,
        }
        return self

    # -- fitting ------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁfit__mutmut_34(self, train: pd.DataFrame, validation: pd.DataFrame, contamination: float) -> Self:
        if not 0.0 < contamination < 0.5:
            raise ValueError("contamination must be in (0, 0.5)")
        if len(train) < self.window or len(validation) < self.window:
            raise ValueError("the training and validation rows must fill at least one window")
        values = train[self.columns].astype(float)
        self.center_ = values.median().to_numpy()
        spread = values.std(ddof=0).to_numpy()
        self.scale_ = np.where(spread > 0, spread, 1.0)
        torch.manual_seed(self.seed)
        torch.set_num_threads(self.threads)
        torch.use_deterministic_algorithms(False)
        rng = np.random.default_rng(self.seed)
        fit_windows, _ = self._windows(train)
        if len(fit_windows) > self.fit_rows:
            fit_windows = fit_windows[rng.choice(len(fit_windows), self.fit_rows, replace=False)]
        val_windows, _ = self._windows(validation)
        if len(val_windows) > self.validation_rows:
            keep = np.sort(rng.choice(len(val_windows), self.validation_rows, replace=False))
            val_windows = val_windows[keep]
        self._validation = torch.as_tensor(val_windows, dtype=torch.float32)
        self._net = _Network(len(self.columns), self.hidden)
        optimiser = torch.optim.Adam(self._net.parameters(), lr=self.learning_rate)
        data = torch.as_tensor(fit_windows, dtype=torch.float32)
        shuffler = torch.Generator().manual_seed(self.seed)
        train_loss: list[float] = []
        validation_loss: list[float] = []
        best, best_state, stale = np.inf, None, 0
        for _epoch in range(self.max_epochs):
            self._net.train()
            order = torch.randperm(len(data), generator=shuffler)
            total = 0.0
            for start in range(0, len(data), self.batch_size):
                batch = data[order[start : start + self.batch_size]]
                optimiser.zero_grad()
                loss = nn.functional.mse_loss(self._net(batch), batch)
                loss.backward()
                optimiser.step()
                total += float(loss.detach()) * len(batch)
            train_loss.append(total / len(data))
            validation_loss.append(self.validation_loss_now())
            if validation_loss[-1] < best:
                best, stale = validation_loss[-1], 0
                best_state = {k: v.clone() for k, v in self._net.state_dict().items()}
            else:
                stale += 1
                if stale >= self.patience:
                    break
        assert best_state is not None
        self._net.load_state_dict(best_state)
        scores = self._reconstruction_error(fit_windows, last_only=True)
        self.threshold_ = float(np.quantile(scores, 1.0 - contamination))
        self._history = {
            "train_loss": train_loss,
            "validation_loss": validation_loss,
            "epochs_run": len(train_loss),
            "best_epoch": int(np.argmin(validation_loss)) + 1,
        }
        return self

    # -- fitting ------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁfit__mutmut_35(self, train: pd.DataFrame, validation: pd.DataFrame, contamination: float) -> Self:
        if not 0.0 < contamination < 0.5:
            raise ValueError("contamination must be in (0, 0.5)")
        if len(train) < self.window or len(validation) < self.window:
            raise ValueError("the training and validation rows must fill at least one window")
        values = train[self.columns].astype(float)
        self.center_ = values.median().to_numpy()
        spread = values.std(ddof=0).to_numpy()
        self.scale_ = np.where(spread > 0, spread, 1.0)
        torch.manual_seed(self.seed)
        torch.set_num_threads(self.threads)
        torch.use_deterministic_algorithms(True)
        rng = None
        fit_windows, _ = self._windows(train)
        if len(fit_windows) > self.fit_rows:
            fit_windows = fit_windows[rng.choice(len(fit_windows), self.fit_rows, replace=False)]
        val_windows, _ = self._windows(validation)
        if len(val_windows) > self.validation_rows:
            keep = np.sort(rng.choice(len(val_windows), self.validation_rows, replace=False))
            val_windows = val_windows[keep]
        self._validation = torch.as_tensor(val_windows, dtype=torch.float32)
        self._net = _Network(len(self.columns), self.hidden)
        optimiser = torch.optim.Adam(self._net.parameters(), lr=self.learning_rate)
        data = torch.as_tensor(fit_windows, dtype=torch.float32)
        shuffler = torch.Generator().manual_seed(self.seed)
        train_loss: list[float] = []
        validation_loss: list[float] = []
        best, best_state, stale = np.inf, None, 0
        for _epoch in range(self.max_epochs):
            self._net.train()
            order = torch.randperm(len(data), generator=shuffler)
            total = 0.0
            for start in range(0, len(data), self.batch_size):
                batch = data[order[start : start + self.batch_size]]
                optimiser.zero_grad()
                loss = nn.functional.mse_loss(self._net(batch), batch)
                loss.backward()
                optimiser.step()
                total += float(loss.detach()) * len(batch)
            train_loss.append(total / len(data))
            validation_loss.append(self.validation_loss_now())
            if validation_loss[-1] < best:
                best, stale = validation_loss[-1], 0
                best_state = {k: v.clone() for k, v in self._net.state_dict().items()}
            else:
                stale += 1
                if stale >= self.patience:
                    break
        assert best_state is not None
        self._net.load_state_dict(best_state)
        scores = self._reconstruction_error(fit_windows, last_only=True)
        self.threshold_ = float(np.quantile(scores, 1.0 - contamination))
        self._history = {
            "train_loss": train_loss,
            "validation_loss": validation_loss,
            "epochs_run": len(train_loss),
            "best_epoch": int(np.argmin(validation_loss)) + 1,
        }
        return self

    # -- fitting ------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁfit__mutmut_36(self, train: pd.DataFrame, validation: pd.DataFrame, contamination: float) -> Self:
        if not 0.0 < contamination < 0.5:
            raise ValueError("contamination must be in (0, 0.5)")
        if len(train) < self.window or len(validation) < self.window:
            raise ValueError("the training and validation rows must fill at least one window")
        values = train[self.columns].astype(float)
        self.center_ = values.median().to_numpy()
        spread = values.std(ddof=0).to_numpy()
        self.scale_ = np.where(spread > 0, spread, 1.0)
        torch.manual_seed(self.seed)
        torch.set_num_threads(self.threads)
        torch.use_deterministic_algorithms(True)
        rng = np.random.default_rng(None)
        fit_windows, _ = self._windows(train)
        if len(fit_windows) > self.fit_rows:
            fit_windows = fit_windows[rng.choice(len(fit_windows), self.fit_rows, replace=False)]
        val_windows, _ = self._windows(validation)
        if len(val_windows) > self.validation_rows:
            keep = np.sort(rng.choice(len(val_windows), self.validation_rows, replace=False))
            val_windows = val_windows[keep]
        self._validation = torch.as_tensor(val_windows, dtype=torch.float32)
        self._net = _Network(len(self.columns), self.hidden)
        optimiser = torch.optim.Adam(self._net.parameters(), lr=self.learning_rate)
        data = torch.as_tensor(fit_windows, dtype=torch.float32)
        shuffler = torch.Generator().manual_seed(self.seed)
        train_loss: list[float] = []
        validation_loss: list[float] = []
        best, best_state, stale = np.inf, None, 0
        for _epoch in range(self.max_epochs):
            self._net.train()
            order = torch.randperm(len(data), generator=shuffler)
            total = 0.0
            for start in range(0, len(data), self.batch_size):
                batch = data[order[start : start + self.batch_size]]
                optimiser.zero_grad()
                loss = nn.functional.mse_loss(self._net(batch), batch)
                loss.backward()
                optimiser.step()
                total += float(loss.detach()) * len(batch)
            train_loss.append(total / len(data))
            validation_loss.append(self.validation_loss_now())
            if validation_loss[-1] < best:
                best, stale = validation_loss[-1], 0
                best_state = {k: v.clone() for k, v in self._net.state_dict().items()}
            else:
                stale += 1
                if stale >= self.patience:
                    break
        assert best_state is not None
        self._net.load_state_dict(best_state)
        scores = self._reconstruction_error(fit_windows, last_only=True)
        self.threshold_ = float(np.quantile(scores, 1.0 - contamination))
        self._history = {
            "train_loss": train_loss,
            "validation_loss": validation_loss,
            "epochs_run": len(train_loss),
            "best_epoch": int(np.argmin(validation_loss)) + 1,
        }
        return self

    # -- fitting ------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁfit__mutmut_37(self, train: pd.DataFrame, validation: pd.DataFrame, contamination: float) -> Self:
        if not 0.0 < contamination < 0.5:
            raise ValueError("contamination must be in (0, 0.5)")
        if len(train) < self.window or len(validation) < self.window:
            raise ValueError("the training and validation rows must fill at least one window")
        values = train[self.columns].astype(float)
        self.center_ = values.median().to_numpy()
        spread = values.std(ddof=0).to_numpy()
        self.scale_ = np.where(spread > 0, spread, 1.0)
        torch.manual_seed(self.seed)
        torch.set_num_threads(self.threads)
        torch.use_deterministic_algorithms(True)
        rng = np.random.default_rng(self.seed)
        fit_windows, _ = None
        if len(fit_windows) > self.fit_rows:
            fit_windows = fit_windows[rng.choice(len(fit_windows), self.fit_rows, replace=False)]
        val_windows, _ = self._windows(validation)
        if len(val_windows) > self.validation_rows:
            keep = np.sort(rng.choice(len(val_windows), self.validation_rows, replace=False))
            val_windows = val_windows[keep]
        self._validation = torch.as_tensor(val_windows, dtype=torch.float32)
        self._net = _Network(len(self.columns), self.hidden)
        optimiser = torch.optim.Adam(self._net.parameters(), lr=self.learning_rate)
        data = torch.as_tensor(fit_windows, dtype=torch.float32)
        shuffler = torch.Generator().manual_seed(self.seed)
        train_loss: list[float] = []
        validation_loss: list[float] = []
        best, best_state, stale = np.inf, None, 0
        for _epoch in range(self.max_epochs):
            self._net.train()
            order = torch.randperm(len(data), generator=shuffler)
            total = 0.0
            for start in range(0, len(data), self.batch_size):
                batch = data[order[start : start + self.batch_size]]
                optimiser.zero_grad()
                loss = nn.functional.mse_loss(self._net(batch), batch)
                loss.backward()
                optimiser.step()
                total += float(loss.detach()) * len(batch)
            train_loss.append(total / len(data))
            validation_loss.append(self.validation_loss_now())
            if validation_loss[-1] < best:
                best, stale = validation_loss[-1], 0
                best_state = {k: v.clone() for k, v in self._net.state_dict().items()}
            else:
                stale += 1
                if stale >= self.patience:
                    break
        assert best_state is not None
        self._net.load_state_dict(best_state)
        scores = self._reconstruction_error(fit_windows, last_only=True)
        self.threshold_ = float(np.quantile(scores, 1.0 - contamination))
        self._history = {
            "train_loss": train_loss,
            "validation_loss": validation_loss,
            "epochs_run": len(train_loss),
            "best_epoch": int(np.argmin(validation_loss)) + 1,
        }
        return self

    # -- fitting ------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁfit__mutmut_38(self, train: pd.DataFrame, validation: pd.DataFrame, contamination: float) -> Self:
        if not 0.0 < contamination < 0.5:
            raise ValueError("contamination must be in (0, 0.5)")
        if len(train) < self.window or len(validation) < self.window:
            raise ValueError("the training and validation rows must fill at least one window")
        values = train[self.columns].astype(float)
        self.center_ = values.median().to_numpy()
        spread = values.std(ddof=0).to_numpy()
        self.scale_ = np.where(spread > 0, spread, 1.0)
        torch.manual_seed(self.seed)
        torch.set_num_threads(self.threads)
        torch.use_deterministic_algorithms(True)
        rng = np.random.default_rng(self.seed)
        fit_windows, _ = self._windows(None)
        if len(fit_windows) > self.fit_rows:
            fit_windows = fit_windows[rng.choice(len(fit_windows), self.fit_rows, replace=False)]
        val_windows, _ = self._windows(validation)
        if len(val_windows) > self.validation_rows:
            keep = np.sort(rng.choice(len(val_windows), self.validation_rows, replace=False))
            val_windows = val_windows[keep]
        self._validation = torch.as_tensor(val_windows, dtype=torch.float32)
        self._net = _Network(len(self.columns), self.hidden)
        optimiser = torch.optim.Adam(self._net.parameters(), lr=self.learning_rate)
        data = torch.as_tensor(fit_windows, dtype=torch.float32)
        shuffler = torch.Generator().manual_seed(self.seed)
        train_loss: list[float] = []
        validation_loss: list[float] = []
        best, best_state, stale = np.inf, None, 0
        for _epoch in range(self.max_epochs):
            self._net.train()
            order = torch.randperm(len(data), generator=shuffler)
            total = 0.0
            for start in range(0, len(data), self.batch_size):
                batch = data[order[start : start + self.batch_size]]
                optimiser.zero_grad()
                loss = nn.functional.mse_loss(self._net(batch), batch)
                loss.backward()
                optimiser.step()
                total += float(loss.detach()) * len(batch)
            train_loss.append(total / len(data))
            validation_loss.append(self.validation_loss_now())
            if validation_loss[-1] < best:
                best, stale = validation_loss[-1], 0
                best_state = {k: v.clone() for k, v in self._net.state_dict().items()}
            else:
                stale += 1
                if stale >= self.patience:
                    break
        assert best_state is not None
        self._net.load_state_dict(best_state)
        scores = self._reconstruction_error(fit_windows, last_only=True)
        self.threshold_ = float(np.quantile(scores, 1.0 - contamination))
        self._history = {
            "train_loss": train_loss,
            "validation_loss": validation_loss,
            "epochs_run": len(train_loss),
            "best_epoch": int(np.argmin(validation_loss)) + 1,
        }
        return self

    # -- fitting ------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁfit__mutmut_39(self, train: pd.DataFrame, validation: pd.DataFrame, contamination: float) -> Self:
        if not 0.0 < contamination < 0.5:
            raise ValueError("contamination must be in (0, 0.5)")
        if len(train) < self.window or len(validation) < self.window:
            raise ValueError("the training and validation rows must fill at least one window")
        values = train[self.columns].astype(float)
        self.center_ = values.median().to_numpy()
        spread = values.std(ddof=0).to_numpy()
        self.scale_ = np.where(spread > 0, spread, 1.0)
        torch.manual_seed(self.seed)
        torch.set_num_threads(self.threads)
        torch.use_deterministic_algorithms(True)
        rng = np.random.default_rng(self.seed)
        fit_windows, _ = self._windows(train)
        if len(fit_windows) >= self.fit_rows:
            fit_windows = fit_windows[rng.choice(len(fit_windows), self.fit_rows, replace=False)]
        val_windows, _ = self._windows(validation)
        if len(val_windows) > self.validation_rows:
            keep = np.sort(rng.choice(len(val_windows), self.validation_rows, replace=False))
            val_windows = val_windows[keep]
        self._validation = torch.as_tensor(val_windows, dtype=torch.float32)
        self._net = _Network(len(self.columns), self.hidden)
        optimiser = torch.optim.Adam(self._net.parameters(), lr=self.learning_rate)
        data = torch.as_tensor(fit_windows, dtype=torch.float32)
        shuffler = torch.Generator().manual_seed(self.seed)
        train_loss: list[float] = []
        validation_loss: list[float] = []
        best, best_state, stale = np.inf, None, 0
        for _epoch in range(self.max_epochs):
            self._net.train()
            order = torch.randperm(len(data), generator=shuffler)
            total = 0.0
            for start in range(0, len(data), self.batch_size):
                batch = data[order[start : start + self.batch_size]]
                optimiser.zero_grad()
                loss = nn.functional.mse_loss(self._net(batch), batch)
                loss.backward()
                optimiser.step()
                total += float(loss.detach()) * len(batch)
            train_loss.append(total / len(data))
            validation_loss.append(self.validation_loss_now())
            if validation_loss[-1] < best:
                best, stale = validation_loss[-1], 0
                best_state = {k: v.clone() for k, v in self._net.state_dict().items()}
            else:
                stale += 1
                if stale >= self.patience:
                    break
        assert best_state is not None
        self._net.load_state_dict(best_state)
        scores = self._reconstruction_error(fit_windows, last_only=True)
        self.threshold_ = float(np.quantile(scores, 1.0 - contamination))
        self._history = {
            "train_loss": train_loss,
            "validation_loss": validation_loss,
            "epochs_run": len(train_loss),
            "best_epoch": int(np.argmin(validation_loss)) + 1,
        }
        return self

    # -- fitting ------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁfit__mutmut_40(self, train: pd.DataFrame, validation: pd.DataFrame, contamination: float) -> Self:
        if not 0.0 < contamination < 0.5:
            raise ValueError("contamination must be in (0, 0.5)")
        if len(train) < self.window or len(validation) < self.window:
            raise ValueError("the training and validation rows must fill at least one window")
        values = train[self.columns].astype(float)
        self.center_ = values.median().to_numpy()
        spread = values.std(ddof=0).to_numpy()
        self.scale_ = np.where(spread > 0, spread, 1.0)
        torch.manual_seed(self.seed)
        torch.set_num_threads(self.threads)
        torch.use_deterministic_algorithms(True)
        rng = np.random.default_rng(self.seed)
        fit_windows, _ = self._windows(train)
        if len(fit_windows) > self.fit_rows:
            fit_windows = None
        val_windows, _ = self._windows(validation)
        if len(val_windows) > self.validation_rows:
            keep = np.sort(rng.choice(len(val_windows), self.validation_rows, replace=False))
            val_windows = val_windows[keep]
        self._validation = torch.as_tensor(val_windows, dtype=torch.float32)
        self._net = _Network(len(self.columns), self.hidden)
        optimiser = torch.optim.Adam(self._net.parameters(), lr=self.learning_rate)
        data = torch.as_tensor(fit_windows, dtype=torch.float32)
        shuffler = torch.Generator().manual_seed(self.seed)
        train_loss: list[float] = []
        validation_loss: list[float] = []
        best, best_state, stale = np.inf, None, 0
        for _epoch in range(self.max_epochs):
            self._net.train()
            order = torch.randperm(len(data), generator=shuffler)
            total = 0.0
            for start in range(0, len(data), self.batch_size):
                batch = data[order[start : start + self.batch_size]]
                optimiser.zero_grad()
                loss = nn.functional.mse_loss(self._net(batch), batch)
                loss.backward()
                optimiser.step()
                total += float(loss.detach()) * len(batch)
            train_loss.append(total / len(data))
            validation_loss.append(self.validation_loss_now())
            if validation_loss[-1] < best:
                best, stale = validation_loss[-1], 0
                best_state = {k: v.clone() for k, v in self._net.state_dict().items()}
            else:
                stale += 1
                if stale >= self.patience:
                    break
        assert best_state is not None
        self._net.load_state_dict(best_state)
        scores = self._reconstruction_error(fit_windows, last_only=True)
        self.threshold_ = float(np.quantile(scores, 1.0 - contamination))
        self._history = {
            "train_loss": train_loss,
            "validation_loss": validation_loss,
            "epochs_run": len(train_loss),
            "best_epoch": int(np.argmin(validation_loss)) + 1,
        }
        return self

    # -- fitting ------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁfit__mutmut_41(self, train: pd.DataFrame, validation: pd.DataFrame, contamination: float) -> Self:
        if not 0.0 < contamination < 0.5:
            raise ValueError("contamination must be in (0, 0.5)")
        if len(train) < self.window or len(validation) < self.window:
            raise ValueError("the training and validation rows must fill at least one window")
        values = train[self.columns].astype(float)
        self.center_ = values.median().to_numpy()
        spread = values.std(ddof=0).to_numpy()
        self.scale_ = np.where(spread > 0, spread, 1.0)
        torch.manual_seed(self.seed)
        torch.set_num_threads(self.threads)
        torch.use_deterministic_algorithms(True)
        rng = np.random.default_rng(self.seed)
        fit_windows, _ = self._windows(train)
        if len(fit_windows) > self.fit_rows:
            fit_windows = fit_windows[rng.choice(None, self.fit_rows, replace=False)]
        val_windows, _ = self._windows(validation)
        if len(val_windows) > self.validation_rows:
            keep = np.sort(rng.choice(len(val_windows), self.validation_rows, replace=False))
            val_windows = val_windows[keep]
        self._validation = torch.as_tensor(val_windows, dtype=torch.float32)
        self._net = _Network(len(self.columns), self.hidden)
        optimiser = torch.optim.Adam(self._net.parameters(), lr=self.learning_rate)
        data = torch.as_tensor(fit_windows, dtype=torch.float32)
        shuffler = torch.Generator().manual_seed(self.seed)
        train_loss: list[float] = []
        validation_loss: list[float] = []
        best, best_state, stale = np.inf, None, 0
        for _epoch in range(self.max_epochs):
            self._net.train()
            order = torch.randperm(len(data), generator=shuffler)
            total = 0.0
            for start in range(0, len(data), self.batch_size):
                batch = data[order[start : start + self.batch_size]]
                optimiser.zero_grad()
                loss = nn.functional.mse_loss(self._net(batch), batch)
                loss.backward()
                optimiser.step()
                total += float(loss.detach()) * len(batch)
            train_loss.append(total / len(data))
            validation_loss.append(self.validation_loss_now())
            if validation_loss[-1] < best:
                best, stale = validation_loss[-1], 0
                best_state = {k: v.clone() for k, v in self._net.state_dict().items()}
            else:
                stale += 1
                if stale >= self.patience:
                    break
        assert best_state is not None
        self._net.load_state_dict(best_state)
        scores = self._reconstruction_error(fit_windows, last_only=True)
        self.threshold_ = float(np.quantile(scores, 1.0 - contamination))
        self._history = {
            "train_loss": train_loss,
            "validation_loss": validation_loss,
            "epochs_run": len(train_loss),
            "best_epoch": int(np.argmin(validation_loss)) + 1,
        }
        return self

    # -- fitting ------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁfit__mutmut_42(self, train: pd.DataFrame, validation: pd.DataFrame, contamination: float) -> Self:
        if not 0.0 < contamination < 0.5:
            raise ValueError("contamination must be in (0, 0.5)")
        if len(train) < self.window or len(validation) < self.window:
            raise ValueError("the training and validation rows must fill at least one window")
        values = train[self.columns].astype(float)
        self.center_ = values.median().to_numpy()
        spread = values.std(ddof=0).to_numpy()
        self.scale_ = np.where(spread > 0, spread, 1.0)
        torch.manual_seed(self.seed)
        torch.set_num_threads(self.threads)
        torch.use_deterministic_algorithms(True)
        rng = np.random.default_rng(self.seed)
        fit_windows, _ = self._windows(train)
        if len(fit_windows) > self.fit_rows:
            fit_windows = fit_windows[rng.choice(len(fit_windows), None, replace=False)]
        val_windows, _ = self._windows(validation)
        if len(val_windows) > self.validation_rows:
            keep = np.sort(rng.choice(len(val_windows), self.validation_rows, replace=False))
            val_windows = val_windows[keep]
        self._validation = torch.as_tensor(val_windows, dtype=torch.float32)
        self._net = _Network(len(self.columns), self.hidden)
        optimiser = torch.optim.Adam(self._net.parameters(), lr=self.learning_rate)
        data = torch.as_tensor(fit_windows, dtype=torch.float32)
        shuffler = torch.Generator().manual_seed(self.seed)
        train_loss: list[float] = []
        validation_loss: list[float] = []
        best, best_state, stale = np.inf, None, 0
        for _epoch in range(self.max_epochs):
            self._net.train()
            order = torch.randperm(len(data), generator=shuffler)
            total = 0.0
            for start in range(0, len(data), self.batch_size):
                batch = data[order[start : start + self.batch_size]]
                optimiser.zero_grad()
                loss = nn.functional.mse_loss(self._net(batch), batch)
                loss.backward()
                optimiser.step()
                total += float(loss.detach()) * len(batch)
            train_loss.append(total / len(data))
            validation_loss.append(self.validation_loss_now())
            if validation_loss[-1] < best:
                best, stale = validation_loss[-1], 0
                best_state = {k: v.clone() for k, v in self._net.state_dict().items()}
            else:
                stale += 1
                if stale >= self.patience:
                    break
        assert best_state is not None
        self._net.load_state_dict(best_state)
        scores = self._reconstruction_error(fit_windows, last_only=True)
        self.threshold_ = float(np.quantile(scores, 1.0 - contamination))
        self._history = {
            "train_loss": train_loss,
            "validation_loss": validation_loss,
            "epochs_run": len(train_loss),
            "best_epoch": int(np.argmin(validation_loss)) + 1,
        }
        return self

    # -- fitting ------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁfit__mutmut_43(self, train: pd.DataFrame, validation: pd.DataFrame, contamination: float) -> Self:
        if not 0.0 < contamination < 0.5:
            raise ValueError("contamination must be in (0, 0.5)")
        if len(train) < self.window or len(validation) < self.window:
            raise ValueError("the training and validation rows must fill at least one window")
        values = train[self.columns].astype(float)
        self.center_ = values.median().to_numpy()
        spread = values.std(ddof=0).to_numpy()
        self.scale_ = np.where(spread > 0, spread, 1.0)
        torch.manual_seed(self.seed)
        torch.set_num_threads(self.threads)
        torch.use_deterministic_algorithms(True)
        rng = np.random.default_rng(self.seed)
        fit_windows, _ = self._windows(train)
        if len(fit_windows) > self.fit_rows:
            fit_windows = fit_windows[rng.choice(len(fit_windows), self.fit_rows, replace=None)]
        val_windows, _ = self._windows(validation)
        if len(val_windows) > self.validation_rows:
            keep = np.sort(rng.choice(len(val_windows), self.validation_rows, replace=False))
            val_windows = val_windows[keep]
        self._validation = torch.as_tensor(val_windows, dtype=torch.float32)
        self._net = _Network(len(self.columns), self.hidden)
        optimiser = torch.optim.Adam(self._net.parameters(), lr=self.learning_rate)
        data = torch.as_tensor(fit_windows, dtype=torch.float32)
        shuffler = torch.Generator().manual_seed(self.seed)
        train_loss: list[float] = []
        validation_loss: list[float] = []
        best, best_state, stale = np.inf, None, 0
        for _epoch in range(self.max_epochs):
            self._net.train()
            order = torch.randperm(len(data), generator=shuffler)
            total = 0.0
            for start in range(0, len(data), self.batch_size):
                batch = data[order[start : start + self.batch_size]]
                optimiser.zero_grad()
                loss = nn.functional.mse_loss(self._net(batch), batch)
                loss.backward()
                optimiser.step()
                total += float(loss.detach()) * len(batch)
            train_loss.append(total / len(data))
            validation_loss.append(self.validation_loss_now())
            if validation_loss[-1] < best:
                best, stale = validation_loss[-1], 0
                best_state = {k: v.clone() for k, v in self._net.state_dict().items()}
            else:
                stale += 1
                if stale >= self.patience:
                    break
        assert best_state is not None
        self._net.load_state_dict(best_state)
        scores = self._reconstruction_error(fit_windows, last_only=True)
        self.threshold_ = float(np.quantile(scores, 1.0 - contamination))
        self._history = {
            "train_loss": train_loss,
            "validation_loss": validation_loss,
            "epochs_run": len(train_loss),
            "best_epoch": int(np.argmin(validation_loss)) + 1,
        }
        return self

    # -- fitting ------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁfit__mutmut_44(self, train: pd.DataFrame, validation: pd.DataFrame, contamination: float) -> Self:
        if not 0.0 < contamination < 0.5:
            raise ValueError("contamination must be in (0, 0.5)")
        if len(train) < self.window or len(validation) < self.window:
            raise ValueError("the training and validation rows must fill at least one window")
        values = train[self.columns].astype(float)
        self.center_ = values.median().to_numpy()
        spread = values.std(ddof=0).to_numpy()
        self.scale_ = np.where(spread > 0, spread, 1.0)
        torch.manual_seed(self.seed)
        torch.set_num_threads(self.threads)
        torch.use_deterministic_algorithms(True)
        rng = np.random.default_rng(self.seed)
        fit_windows, _ = self._windows(train)
        if len(fit_windows) > self.fit_rows:
            fit_windows = fit_windows[rng.choice(self.fit_rows, replace=False)]
        val_windows, _ = self._windows(validation)
        if len(val_windows) > self.validation_rows:
            keep = np.sort(rng.choice(len(val_windows), self.validation_rows, replace=False))
            val_windows = val_windows[keep]
        self._validation = torch.as_tensor(val_windows, dtype=torch.float32)
        self._net = _Network(len(self.columns), self.hidden)
        optimiser = torch.optim.Adam(self._net.parameters(), lr=self.learning_rate)
        data = torch.as_tensor(fit_windows, dtype=torch.float32)
        shuffler = torch.Generator().manual_seed(self.seed)
        train_loss: list[float] = []
        validation_loss: list[float] = []
        best, best_state, stale = np.inf, None, 0
        for _epoch in range(self.max_epochs):
            self._net.train()
            order = torch.randperm(len(data), generator=shuffler)
            total = 0.0
            for start in range(0, len(data), self.batch_size):
                batch = data[order[start : start + self.batch_size]]
                optimiser.zero_grad()
                loss = nn.functional.mse_loss(self._net(batch), batch)
                loss.backward()
                optimiser.step()
                total += float(loss.detach()) * len(batch)
            train_loss.append(total / len(data))
            validation_loss.append(self.validation_loss_now())
            if validation_loss[-1] < best:
                best, stale = validation_loss[-1], 0
                best_state = {k: v.clone() for k, v in self._net.state_dict().items()}
            else:
                stale += 1
                if stale >= self.patience:
                    break
        assert best_state is not None
        self._net.load_state_dict(best_state)
        scores = self._reconstruction_error(fit_windows, last_only=True)
        self.threshold_ = float(np.quantile(scores, 1.0 - contamination))
        self._history = {
            "train_loss": train_loss,
            "validation_loss": validation_loss,
            "epochs_run": len(train_loss),
            "best_epoch": int(np.argmin(validation_loss)) + 1,
        }
        return self

    # -- fitting ------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁfit__mutmut_45(self, train: pd.DataFrame, validation: pd.DataFrame, contamination: float) -> Self:
        if not 0.0 < contamination < 0.5:
            raise ValueError("contamination must be in (0, 0.5)")
        if len(train) < self.window or len(validation) < self.window:
            raise ValueError("the training and validation rows must fill at least one window")
        values = train[self.columns].astype(float)
        self.center_ = values.median().to_numpy()
        spread = values.std(ddof=0).to_numpy()
        self.scale_ = np.where(spread > 0, spread, 1.0)
        torch.manual_seed(self.seed)
        torch.set_num_threads(self.threads)
        torch.use_deterministic_algorithms(True)
        rng = np.random.default_rng(self.seed)
        fit_windows, _ = self._windows(train)
        if len(fit_windows) > self.fit_rows:
            fit_windows = fit_windows[rng.choice(len(fit_windows), replace=False)]
        val_windows, _ = self._windows(validation)
        if len(val_windows) > self.validation_rows:
            keep = np.sort(rng.choice(len(val_windows), self.validation_rows, replace=False))
            val_windows = val_windows[keep]
        self._validation = torch.as_tensor(val_windows, dtype=torch.float32)
        self._net = _Network(len(self.columns), self.hidden)
        optimiser = torch.optim.Adam(self._net.parameters(), lr=self.learning_rate)
        data = torch.as_tensor(fit_windows, dtype=torch.float32)
        shuffler = torch.Generator().manual_seed(self.seed)
        train_loss: list[float] = []
        validation_loss: list[float] = []
        best, best_state, stale = np.inf, None, 0
        for _epoch in range(self.max_epochs):
            self._net.train()
            order = torch.randperm(len(data), generator=shuffler)
            total = 0.0
            for start in range(0, len(data), self.batch_size):
                batch = data[order[start : start + self.batch_size]]
                optimiser.zero_grad()
                loss = nn.functional.mse_loss(self._net(batch), batch)
                loss.backward()
                optimiser.step()
                total += float(loss.detach()) * len(batch)
            train_loss.append(total / len(data))
            validation_loss.append(self.validation_loss_now())
            if validation_loss[-1] < best:
                best, stale = validation_loss[-1], 0
                best_state = {k: v.clone() for k, v in self._net.state_dict().items()}
            else:
                stale += 1
                if stale >= self.patience:
                    break
        assert best_state is not None
        self._net.load_state_dict(best_state)
        scores = self._reconstruction_error(fit_windows, last_only=True)
        self.threshold_ = float(np.quantile(scores, 1.0 - contamination))
        self._history = {
            "train_loss": train_loss,
            "validation_loss": validation_loss,
            "epochs_run": len(train_loss),
            "best_epoch": int(np.argmin(validation_loss)) + 1,
        }
        return self

    # -- fitting ------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁfit__mutmut_46(self, train: pd.DataFrame, validation: pd.DataFrame, contamination: float) -> Self:
        if not 0.0 < contamination < 0.5:
            raise ValueError("contamination must be in (0, 0.5)")
        if len(train) < self.window or len(validation) < self.window:
            raise ValueError("the training and validation rows must fill at least one window")
        values = train[self.columns].astype(float)
        self.center_ = values.median().to_numpy()
        spread = values.std(ddof=0).to_numpy()
        self.scale_ = np.where(spread > 0, spread, 1.0)
        torch.manual_seed(self.seed)
        torch.set_num_threads(self.threads)
        torch.use_deterministic_algorithms(True)
        rng = np.random.default_rng(self.seed)
        fit_windows, _ = self._windows(train)
        if len(fit_windows) > self.fit_rows:
            fit_windows = fit_windows[rng.choice(len(fit_windows), self.fit_rows, )]
        val_windows, _ = self._windows(validation)
        if len(val_windows) > self.validation_rows:
            keep = np.sort(rng.choice(len(val_windows), self.validation_rows, replace=False))
            val_windows = val_windows[keep]
        self._validation = torch.as_tensor(val_windows, dtype=torch.float32)
        self._net = _Network(len(self.columns), self.hidden)
        optimiser = torch.optim.Adam(self._net.parameters(), lr=self.learning_rate)
        data = torch.as_tensor(fit_windows, dtype=torch.float32)
        shuffler = torch.Generator().manual_seed(self.seed)
        train_loss: list[float] = []
        validation_loss: list[float] = []
        best, best_state, stale = np.inf, None, 0
        for _epoch in range(self.max_epochs):
            self._net.train()
            order = torch.randperm(len(data), generator=shuffler)
            total = 0.0
            for start in range(0, len(data), self.batch_size):
                batch = data[order[start : start + self.batch_size]]
                optimiser.zero_grad()
                loss = nn.functional.mse_loss(self._net(batch), batch)
                loss.backward()
                optimiser.step()
                total += float(loss.detach()) * len(batch)
            train_loss.append(total / len(data))
            validation_loss.append(self.validation_loss_now())
            if validation_loss[-1] < best:
                best, stale = validation_loss[-1], 0
                best_state = {k: v.clone() for k, v in self._net.state_dict().items()}
            else:
                stale += 1
                if stale >= self.patience:
                    break
        assert best_state is not None
        self._net.load_state_dict(best_state)
        scores = self._reconstruction_error(fit_windows, last_only=True)
        self.threshold_ = float(np.quantile(scores, 1.0 - contamination))
        self._history = {
            "train_loss": train_loss,
            "validation_loss": validation_loss,
            "epochs_run": len(train_loss),
            "best_epoch": int(np.argmin(validation_loss)) + 1,
        }
        return self

    # -- fitting ------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁfit__mutmut_47(self, train: pd.DataFrame, validation: pd.DataFrame, contamination: float) -> Self:
        if not 0.0 < contamination < 0.5:
            raise ValueError("contamination must be in (0, 0.5)")
        if len(train) < self.window or len(validation) < self.window:
            raise ValueError("the training and validation rows must fill at least one window")
        values = train[self.columns].astype(float)
        self.center_ = values.median().to_numpy()
        spread = values.std(ddof=0).to_numpy()
        self.scale_ = np.where(spread > 0, spread, 1.0)
        torch.manual_seed(self.seed)
        torch.set_num_threads(self.threads)
        torch.use_deterministic_algorithms(True)
        rng = np.random.default_rng(self.seed)
        fit_windows, _ = self._windows(train)
        if len(fit_windows) > self.fit_rows:
            fit_windows = fit_windows[rng.choice(len(fit_windows), self.fit_rows, replace=True)]
        val_windows, _ = self._windows(validation)
        if len(val_windows) > self.validation_rows:
            keep = np.sort(rng.choice(len(val_windows), self.validation_rows, replace=False))
            val_windows = val_windows[keep]
        self._validation = torch.as_tensor(val_windows, dtype=torch.float32)
        self._net = _Network(len(self.columns), self.hidden)
        optimiser = torch.optim.Adam(self._net.parameters(), lr=self.learning_rate)
        data = torch.as_tensor(fit_windows, dtype=torch.float32)
        shuffler = torch.Generator().manual_seed(self.seed)
        train_loss: list[float] = []
        validation_loss: list[float] = []
        best, best_state, stale = np.inf, None, 0
        for _epoch in range(self.max_epochs):
            self._net.train()
            order = torch.randperm(len(data), generator=shuffler)
            total = 0.0
            for start in range(0, len(data), self.batch_size):
                batch = data[order[start : start + self.batch_size]]
                optimiser.zero_grad()
                loss = nn.functional.mse_loss(self._net(batch), batch)
                loss.backward()
                optimiser.step()
                total += float(loss.detach()) * len(batch)
            train_loss.append(total / len(data))
            validation_loss.append(self.validation_loss_now())
            if validation_loss[-1] < best:
                best, stale = validation_loss[-1], 0
                best_state = {k: v.clone() for k, v in self._net.state_dict().items()}
            else:
                stale += 1
                if stale >= self.patience:
                    break
        assert best_state is not None
        self._net.load_state_dict(best_state)
        scores = self._reconstruction_error(fit_windows, last_only=True)
        self.threshold_ = float(np.quantile(scores, 1.0 - contamination))
        self._history = {
            "train_loss": train_loss,
            "validation_loss": validation_loss,
            "epochs_run": len(train_loss),
            "best_epoch": int(np.argmin(validation_loss)) + 1,
        }
        return self

    # -- fitting ------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁfit__mutmut_48(self, train: pd.DataFrame, validation: pd.DataFrame, contamination: float) -> Self:
        if not 0.0 < contamination < 0.5:
            raise ValueError("contamination must be in (0, 0.5)")
        if len(train) < self.window or len(validation) < self.window:
            raise ValueError("the training and validation rows must fill at least one window")
        values = train[self.columns].astype(float)
        self.center_ = values.median().to_numpy()
        spread = values.std(ddof=0).to_numpy()
        self.scale_ = np.where(spread > 0, spread, 1.0)
        torch.manual_seed(self.seed)
        torch.set_num_threads(self.threads)
        torch.use_deterministic_algorithms(True)
        rng = np.random.default_rng(self.seed)
        fit_windows, _ = self._windows(train)
        if len(fit_windows) > self.fit_rows:
            fit_windows = fit_windows[rng.choice(len(fit_windows), self.fit_rows, replace=False)]
        val_windows, _ = None
        if len(val_windows) > self.validation_rows:
            keep = np.sort(rng.choice(len(val_windows), self.validation_rows, replace=False))
            val_windows = val_windows[keep]
        self._validation = torch.as_tensor(val_windows, dtype=torch.float32)
        self._net = _Network(len(self.columns), self.hidden)
        optimiser = torch.optim.Adam(self._net.parameters(), lr=self.learning_rate)
        data = torch.as_tensor(fit_windows, dtype=torch.float32)
        shuffler = torch.Generator().manual_seed(self.seed)
        train_loss: list[float] = []
        validation_loss: list[float] = []
        best, best_state, stale = np.inf, None, 0
        for _epoch in range(self.max_epochs):
            self._net.train()
            order = torch.randperm(len(data), generator=shuffler)
            total = 0.0
            for start in range(0, len(data), self.batch_size):
                batch = data[order[start : start + self.batch_size]]
                optimiser.zero_grad()
                loss = nn.functional.mse_loss(self._net(batch), batch)
                loss.backward()
                optimiser.step()
                total += float(loss.detach()) * len(batch)
            train_loss.append(total / len(data))
            validation_loss.append(self.validation_loss_now())
            if validation_loss[-1] < best:
                best, stale = validation_loss[-1], 0
                best_state = {k: v.clone() for k, v in self._net.state_dict().items()}
            else:
                stale += 1
                if stale >= self.patience:
                    break
        assert best_state is not None
        self._net.load_state_dict(best_state)
        scores = self._reconstruction_error(fit_windows, last_only=True)
        self.threshold_ = float(np.quantile(scores, 1.0 - contamination))
        self._history = {
            "train_loss": train_loss,
            "validation_loss": validation_loss,
            "epochs_run": len(train_loss),
            "best_epoch": int(np.argmin(validation_loss)) + 1,
        }
        return self

    # -- fitting ------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁfit__mutmut_49(self, train: pd.DataFrame, validation: pd.DataFrame, contamination: float) -> Self:
        if not 0.0 < contamination < 0.5:
            raise ValueError("contamination must be in (0, 0.5)")
        if len(train) < self.window or len(validation) < self.window:
            raise ValueError("the training and validation rows must fill at least one window")
        values = train[self.columns].astype(float)
        self.center_ = values.median().to_numpy()
        spread = values.std(ddof=0).to_numpy()
        self.scale_ = np.where(spread > 0, spread, 1.0)
        torch.manual_seed(self.seed)
        torch.set_num_threads(self.threads)
        torch.use_deterministic_algorithms(True)
        rng = np.random.default_rng(self.seed)
        fit_windows, _ = self._windows(train)
        if len(fit_windows) > self.fit_rows:
            fit_windows = fit_windows[rng.choice(len(fit_windows), self.fit_rows, replace=False)]
        val_windows, _ = self._windows(None)
        if len(val_windows) > self.validation_rows:
            keep = np.sort(rng.choice(len(val_windows), self.validation_rows, replace=False))
            val_windows = val_windows[keep]
        self._validation = torch.as_tensor(val_windows, dtype=torch.float32)
        self._net = _Network(len(self.columns), self.hidden)
        optimiser = torch.optim.Adam(self._net.parameters(), lr=self.learning_rate)
        data = torch.as_tensor(fit_windows, dtype=torch.float32)
        shuffler = torch.Generator().manual_seed(self.seed)
        train_loss: list[float] = []
        validation_loss: list[float] = []
        best, best_state, stale = np.inf, None, 0
        for _epoch in range(self.max_epochs):
            self._net.train()
            order = torch.randperm(len(data), generator=shuffler)
            total = 0.0
            for start in range(0, len(data), self.batch_size):
                batch = data[order[start : start + self.batch_size]]
                optimiser.zero_grad()
                loss = nn.functional.mse_loss(self._net(batch), batch)
                loss.backward()
                optimiser.step()
                total += float(loss.detach()) * len(batch)
            train_loss.append(total / len(data))
            validation_loss.append(self.validation_loss_now())
            if validation_loss[-1] < best:
                best, stale = validation_loss[-1], 0
                best_state = {k: v.clone() for k, v in self._net.state_dict().items()}
            else:
                stale += 1
                if stale >= self.patience:
                    break
        assert best_state is not None
        self._net.load_state_dict(best_state)
        scores = self._reconstruction_error(fit_windows, last_only=True)
        self.threshold_ = float(np.quantile(scores, 1.0 - contamination))
        self._history = {
            "train_loss": train_loss,
            "validation_loss": validation_loss,
            "epochs_run": len(train_loss),
            "best_epoch": int(np.argmin(validation_loss)) + 1,
        }
        return self

    # -- fitting ------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁfit__mutmut_50(self, train: pd.DataFrame, validation: pd.DataFrame, contamination: float) -> Self:
        if not 0.0 < contamination < 0.5:
            raise ValueError("contamination must be in (0, 0.5)")
        if len(train) < self.window or len(validation) < self.window:
            raise ValueError("the training and validation rows must fill at least one window")
        values = train[self.columns].astype(float)
        self.center_ = values.median().to_numpy()
        spread = values.std(ddof=0).to_numpy()
        self.scale_ = np.where(spread > 0, spread, 1.0)
        torch.manual_seed(self.seed)
        torch.set_num_threads(self.threads)
        torch.use_deterministic_algorithms(True)
        rng = np.random.default_rng(self.seed)
        fit_windows, _ = self._windows(train)
        if len(fit_windows) > self.fit_rows:
            fit_windows = fit_windows[rng.choice(len(fit_windows), self.fit_rows, replace=False)]
        val_windows, _ = self._windows(validation)
        if len(val_windows) >= self.validation_rows:
            keep = np.sort(rng.choice(len(val_windows), self.validation_rows, replace=False))
            val_windows = val_windows[keep]
        self._validation = torch.as_tensor(val_windows, dtype=torch.float32)
        self._net = _Network(len(self.columns), self.hidden)
        optimiser = torch.optim.Adam(self._net.parameters(), lr=self.learning_rate)
        data = torch.as_tensor(fit_windows, dtype=torch.float32)
        shuffler = torch.Generator().manual_seed(self.seed)
        train_loss: list[float] = []
        validation_loss: list[float] = []
        best, best_state, stale = np.inf, None, 0
        for _epoch in range(self.max_epochs):
            self._net.train()
            order = torch.randperm(len(data), generator=shuffler)
            total = 0.0
            for start in range(0, len(data), self.batch_size):
                batch = data[order[start : start + self.batch_size]]
                optimiser.zero_grad()
                loss = nn.functional.mse_loss(self._net(batch), batch)
                loss.backward()
                optimiser.step()
                total += float(loss.detach()) * len(batch)
            train_loss.append(total / len(data))
            validation_loss.append(self.validation_loss_now())
            if validation_loss[-1] < best:
                best, stale = validation_loss[-1], 0
                best_state = {k: v.clone() for k, v in self._net.state_dict().items()}
            else:
                stale += 1
                if stale >= self.patience:
                    break
        assert best_state is not None
        self._net.load_state_dict(best_state)
        scores = self._reconstruction_error(fit_windows, last_only=True)
        self.threshold_ = float(np.quantile(scores, 1.0 - contamination))
        self._history = {
            "train_loss": train_loss,
            "validation_loss": validation_loss,
            "epochs_run": len(train_loss),
            "best_epoch": int(np.argmin(validation_loss)) + 1,
        }
        return self

    # -- fitting ------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁfit__mutmut_51(self, train: pd.DataFrame, validation: pd.DataFrame, contamination: float) -> Self:
        if not 0.0 < contamination < 0.5:
            raise ValueError("contamination must be in (0, 0.5)")
        if len(train) < self.window or len(validation) < self.window:
            raise ValueError("the training and validation rows must fill at least one window")
        values = train[self.columns].astype(float)
        self.center_ = values.median().to_numpy()
        spread = values.std(ddof=0).to_numpy()
        self.scale_ = np.where(spread > 0, spread, 1.0)
        torch.manual_seed(self.seed)
        torch.set_num_threads(self.threads)
        torch.use_deterministic_algorithms(True)
        rng = np.random.default_rng(self.seed)
        fit_windows, _ = self._windows(train)
        if len(fit_windows) > self.fit_rows:
            fit_windows = fit_windows[rng.choice(len(fit_windows), self.fit_rows, replace=False)]
        val_windows, _ = self._windows(validation)
        if len(val_windows) > self.validation_rows:
            keep = None
            val_windows = val_windows[keep]
        self._validation = torch.as_tensor(val_windows, dtype=torch.float32)
        self._net = _Network(len(self.columns), self.hidden)
        optimiser = torch.optim.Adam(self._net.parameters(), lr=self.learning_rate)
        data = torch.as_tensor(fit_windows, dtype=torch.float32)
        shuffler = torch.Generator().manual_seed(self.seed)
        train_loss: list[float] = []
        validation_loss: list[float] = []
        best, best_state, stale = np.inf, None, 0
        for _epoch in range(self.max_epochs):
            self._net.train()
            order = torch.randperm(len(data), generator=shuffler)
            total = 0.0
            for start in range(0, len(data), self.batch_size):
                batch = data[order[start : start + self.batch_size]]
                optimiser.zero_grad()
                loss = nn.functional.mse_loss(self._net(batch), batch)
                loss.backward()
                optimiser.step()
                total += float(loss.detach()) * len(batch)
            train_loss.append(total / len(data))
            validation_loss.append(self.validation_loss_now())
            if validation_loss[-1] < best:
                best, stale = validation_loss[-1], 0
                best_state = {k: v.clone() for k, v in self._net.state_dict().items()}
            else:
                stale += 1
                if stale >= self.patience:
                    break
        assert best_state is not None
        self._net.load_state_dict(best_state)
        scores = self._reconstruction_error(fit_windows, last_only=True)
        self.threshold_ = float(np.quantile(scores, 1.0 - contamination))
        self._history = {
            "train_loss": train_loss,
            "validation_loss": validation_loss,
            "epochs_run": len(train_loss),
            "best_epoch": int(np.argmin(validation_loss)) + 1,
        }
        return self

    # -- fitting ------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁfit__mutmut_52(self, train: pd.DataFrame, validation: pd.DataFrame, contamination: float) -> Self:
        if not 0.0 < contamination < 0.5:
            raise ValueError("contamination must be in (0, 0.5)")
        if len(train) < self.window or len(validation) < self.window:
            raise ValueError("the training and validation rows must fill at least one window")
        values = train[self.columns].astype(float)
        self.center_ = values.median().to_numpy()
        spread = values.std(ddof=0).to_numpy()
        self.scale_ = np.where(spread > 0, spread, 1.0)
        torch.manual_seed(self.seed)
        torch.set_num_threads(self.threads)
        torch.use_deterministic_algorithms(True)
        rng = np.random.default_rng(self.seed)
        fit_windows, _ = self._windows(train)
        if len(fit_windows) > self.fit_rows:
            fit_windows = fit_windows[rng.choice(len(fit_windows), self.fit_rows, replace=False)]
        val_windows, _ = self._windows(validation)
        if len(val_windows) > self.validation_rows:
            keep = np.sort(None)
            val_windows = val_windows[keep]
        self._validation = torch.as_tensor(val_windows, dtype=torch.float32)
        self._net = _Network(len(self.columns), self.hidden)
        optimiser = torch.optim.Adam(self._net.parameters(), lr=self.learning_rate)
        data = torch.as_tensor(fit_windows, dtype=torch.float32)
        shuffler = torch.Generator().manual_seed(self.seed)
        train_loss: list[float] = []
        validation_loss: list[float] = []
        best, best_state, stale = np.inf, None, 0
        for _epoch in range(self.max_epochs):
            self._net.train()
            order = torch.randperm(len(data), generator=shuffler)
            total = 0.0
            for start in range(0, len(data), self.batch_size):
                batch = data[order[start : start + self.batch_size]]
                optimiser.zero_grad()
                loss = nn.functional.mse_loss(self._net(batch), batch)
                loss.backward()
                optimiser.step()
                total += float(loss.detach()) * len(batch)
            train_loss.append(total / len(data))
            validation_loss.append(self.validation_loss_now())
            if validation_loss[-1] < best:
                best, stale = validation_loss[-1], 0
                best_state = {k: v.clone() for k, v in self._net.state_dict().items()}
            else:
                stale += 1
                if stale >= self.patience:
                    break
        assert best_state is not None
        self._net.load_state_dict(best_state)
        scores = self._reconstruction_error(fit_windows, last_only=True)
        self.threshold_ = float(np.quantile(scores, 1.0 - contamination))
        self._history = {
            "train_loss": train_loss,
            "validation_loss": validation_loss,
            "epochs_run": len(train_loss),
            "best_epoch": int(np.argmin(validation_loss)) + 1,
        }
        return self

    # -- fitting ------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁfit__mutmut_53(self, train: pd.DataFrame, validation: pd.DataFrame, contamination: float) -> Self:
        if not 0.0 < contamination < 0.5:
            raise ValueError("contamination must be in (0, 0.5)")
        if len(train) < self.window or len(validation) < self.window:
            raise ValueError("the training and validation rows must fill at least one window")
        values = train[self.columns].astype(float)
        self.center_ = values.median().to_numpy()
        spread = values.std(ddof=0).to_numpy()
        self.scale_ = np.where(spread > 0, spread, 1.0)
        torch.manual_seed(self.seed)
        torch.set_num_threads(self.threads)
        torch.use_deterministic_algorithms(True)
        rng = np.random.default_rng(self.seed)
        fit_windows, _ = self._windows(train)
        if len(fit_windows) > self.fit_rows:
            fit_windows = fit_windows[rng.choice(len(fit_windows), self.fit_rows, replace=False)]
        val_windows, _ = self._windows(validation)
        if len(val_windows) > self.validation_rows:
            keep = np.sort(rng.choice(None, self.validation_rows, replace=False))
            val_windows = val_windows[keep]
        self._validation = torch.as_tensor(val_windows, dtype=torch.float32)
        self._net = _Network(len(self.columns), self.hidden)
        optimiser = torch.optim.Adam(self._net.parameters(), lr=self.learning_rate)
        data = torch.as_tensor(fit_windows, dtype=torch.float32)
        shuffler = torch.Generator().manual_seed(self.seed)
        train_loss: list[float] = []
        validation_loss: list[float] = []
        best, best_state, stale = np.inf, None, 0
        for _epoch in range(self.max_epochs):
            self._net.train()
            order = torch.randperm(len(data), generator=shuffler)
            total = 0.0
            for start in range(0, len(data), self.batch_size):
                batch = data[order[start : start + self.batch_size]]
                optimiser.zero_grad()
                loss = nn.functional.mse_loss(self._net(batch), batch)
                loss.backward()
                optimiser.step()
                total += float(loss.detach()) * len(batch)
            train_loss.append(total / len(data))
            validation_loss.append(self.validation_loss_now())
            if validation_loss[-1] < best:
                best, stale = validation_loss[-1], 0
                best_state = {k: v.clone() for k, v in self._net.state_dict().items()}
            else:
                stale += 1
                if stale >= self.patience:
                    break
        assert best_state is not None
        self._net.load_state_dict(best_state)
        scores = self._reconstruction_error(fit_windows, last_only=True)
        self.threshold_ = float(np.quantile(scores, 1.0 - contamination))
        self._history = {
            "train_loss": train_loss,
            "validation_loss": validation_loss,
            "epochs_run": len(train_loss),
            "best_epoch": int(np.argmin(validation_loss)) + 1,
        }
        return self

    # -- fitting ------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁfit__mutmut_54(self, train: pd.DataFrame, validation: pd.DataFrame, contamination: float) -> Self:
        if not 0.0 < contamination < 0.5:
            raise ValueError("contamination must be in (0, 0.5)")
        if len(train) < self.window or len(validation) < self.window:
            raise ValueError("the training and validation rows must fill at least one window")
        values = train[self.columns].astype(float)
        self.center_ = values.median().to_numpy()
        spread = values.std(ddof=0).to_numpy()
        self.scale_ = np.where(spread > 0, spread, 1.0)
        torch.manual_seed(self.seed)
        torch.set_num_threads(self.threads)
        torch.use_deterministic_algorithms(True)
        rng = np.random.default_rng(self.seed)
        fit_windows, _ = self._windows(train)
        if len(fit_windows) > self.fit_rows:
            fit_windows = fit_windows[rng.choice(len(fit_windows), self.fit_rows, replace=False)]
        val_windows, _ = self._windows(validation)
        if len(val_windows) > self.validation_rows:
            keep = np.sort(rng.choice(len(val_windows), None, replace=False))
            val_windows = val_windows[keep]
        self._validation = torch.as_tensor(val_windows, dtype=torch.float32)
        self._net = _Network(len(self.columns), self.hidden)
        optimiser = torch.optim.Adam(self._net.parameters(), lr=self.learning_rate)
        data = torch.as_tensor(fit_windows, dtype=torch.float32)
        shuffler = torch.Generator().manual_seed(self.seed)
        train_loss: list[float] = []
        validation_loss: list[float] = []
        best, best_state, stale = np.inf, None, 0
        for _epoch in range(self.max_epochs):
            self._net.train()
            order = torch.randperm(len(data), generator=shuffler)
            total = 0.0
            for start in range(0, len(data), self.batch_size):
                batch = data[order[start : start + self.batch_size]]
                optimiser.zero_grad()
                loss = nn.functional.mse_loss(self._net(batch), batch)
                loss.backward()
                optimiser.step()
                total += float(loss.detach()) * len(batch)
            train_loss.append(total / len(data))
            validation_loss.append(self.validation_loss_now())
            if validation_loss[-1] < best:
                best, stale = validation_loss[-1], 0
                best_state = {k: v.clone() for k, v in self._net.state_dict().items()}
            else:
                stale += 1
                if stale >= self.patience:
                    break
        assert best_state is not None
        self._net.load_state_dict(best_state)
        scores = self._reconstruction_error(fit_windows, last_only=True)
        self.threshold_ = float(np.quantile(scores, 1.0 - contamination))
        self._history = {
            "train_loss": train_loss,
            "validation_loss": validation_loss,
            "epochs_run": len(train_loss),
            "best_epoch": int(np.argmin(validation_loss)) + 1,
        }
        return self

    # -- fitting ------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁfit__mutmut_55(self, train: pd.DataFrame, validation: pd.DataFrame, contamination: float) -> Self:
        if not 0.0 < contamination < 0.5:
            raise ValueError("contamination must be in (0, 0.5)")
        if len(train) < self.window or len(validation) < self.window:
            raise ValueError("the training and validation rows must fill at least one window")
        values = train[self.columns].astype(float)
        self.center_ = values.median().to_numpy()
        spread = values.std(ddof=0).to_numpy()
        self.scale_ = np.where(spread > 0, spread, 1.0)
        torch.manual_seed(self.seed)
        torch.set_num_threads(self.threads)
        torch.use_deterministic_algorithms(True)
        rng = np.random.default_rng(self.seed)
        fit_windows, _ = self._windows(train)
        if len(fit_windows) > self.fit_rows:
            fit_windows = fit_windows[rng.choice(len(fit_windows), self.fit_rows, replace=False)]
        val_windows, _ = self._windows(validation)
        if len(val_windows) > self.validation_rows:
            keep = np.sort(rng.choice(len(val_windows), self.validation_rows, replace=None))
            val_windows = val_windows[keep]
        self._validation = torch.as_tensor(val_windows, dtype=torch.float32)
        self._net = _Network(len(self.columns), self.hidden)
        optimiser = torch.optim.Adam(self._net.parameters(), lr=self.learning_rate)
        data = torch.as_tensor(fit_windows, dtype=torch.float32)
        shuffler = torch.Generator().manual_seed(self.seed)
        train_loss: list[float] = []
        validation_loss: list[float] = []
        best, best_state, stale = np.inf, None, 0
        for _epoch in range(self.max_epochs):
            self._net.train()
            order = torch.randperm(len(data), generator=shuffler)
            total = 0.0
            for start in range(0, len(data), self.batch_size):
                batch = data[order[start : start + self.batch_size]]
                optimiser.zero_grad()
                loss = nn.functional.mse_loss(self._net(batch), batch)
                loss.backward()
                optimiser.step()
                total += float(loss.detach()) * len(batch)
            train_loss.append(total / len(data))
            validation_loss.append(self.validation_loss_now())
            if validation_loss[-1] < best:
                best, stale = validation_loss[-1], 0
                best_state = {k: v.clone() for k, v in self._net.state_dict().items()}
            else:
                stale += 1
                if stale >= self.patience:
                    break
        assert best_state is not None
        self._net.load_state_dict(best_state)
        scores = self._reconstruction_error(fit_windows, last_only=True)
        self.threshold_ = float(np.quantile(scores, 1.0 - contamination))
        self._history = {
            "train_loss": train_loss,
            "validation_loss": validation_loss,
            "epochs_run": len(train_loss),
            "best_epoch": int(np.argmin(validation_loss)) + 1,
        }
        return self

    # -- fitting ------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁfit__mutmut_56(self, train: pd.DataFrame, validation: pd.DataFrame, contamination: float) -> Self:
        if not 0.0 < contamination < 0.5:
            raise ValueError("contamination must be in (0, 0.5)")
        if len(train) < self.window or len(validation) < self.window:
            raise ValueError("the training and validation rows must fill at least one window")
        values = train[self.columns].astype(float)
        self.center_ = values.median().to_numpy()
        spread = values.std(ddof=0).to_numpy()
        self.scale_ = np.where(spread > 0, spread, 1.0)
        torch.manual_seed(self.seed)
        torch.set_num_threads(self.threads)
        torch.use_deterministic_algorithms(True)
        rng = np.random.default_rng(self.seed)
        fit_windows, _ = self._windows(train)
        if len(fit_windows) > self.fit_rows:
            fit_windows = fit_windows[rng.choice(len(fit_windows), self.fit_rows, replace=False)]
        val_windows, _ = self._windows(validation)
        if len(val_windows) > self.validation_rows:
            keep = np.sort(rng.choice(self.validation_rows, replace=False))
            val_windows = val_windows[keep]
        self._validation = torch.as_tensor(val_windows, dtype=torch.float32)
        self._net = _Network(len(self.columns), self.hidden)
        optimiser = torch.optim.Adam(self._net.parameters(), lr=self.learning_rate)
        data = torch.as_tensor(fit_windows, dtype=torch.float32)
        shuffler = torch.Generator().manual_seed(self.seed)
        train_loss: list[float] = []
        validation_loss: list[float] = []
        best, best_state, stale = np.inf, None, 0
        for _epoch in range(self.max_epochs):
            self._net.train()
            order = torch.randperm(len(data), generator=shuffler)
            total = 0.0
            for start in range(0, len(data), self.batch_size):
                batch = data[order[start : start + self.batch_size]]
                optimiser.zero_grad()
                loss = nn.functional.mse_loss(self._net(batch), batch)
                loss.backward()
                optimiser.step()
                total += float(loss.detach()) * len(batch)
            train_loss.append(total / len(data))
            validation_loss.append(self.validation_loss_now())
            if validation_loss[-1] < best:
                best, stale = validation_loss[-1], 0
                best_state = {k: v.clone() for k, v in self._net.state_dict().items()}
            else:
                stale += 1
                if stale >= self.patience:
                    break
        assert best_state is not None
        self._net.load_state_dict(best_state)
        scores = self._reconstruction_error(fit_windows, last_only=True)
        self.threshold_ = float(np.quantile(scores, 1.0 - contamination))
        self._history = {
            "train_loss": train_loss,
            "validation_loss": validation_loss,
            "epochs_run": len(train_loss),
            "best_epoch": int(np.argmin(validation_loss)) + 1,
        }
        return self

    # -- fitting ------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁfit__mutmut_57(self, train: pd.DataFrame, validation: pd.DataFrame, contamination: float) -> Self:
        if not 0.0 < contamination < 0.5:
            raise ValueError("contamination must be in (0, 0.5)")
        if len(train) < self.window or len(validation) < self.window:
            raise ValueError("the training and validation rows must fill at least one window")
        values = train[self.columns].astype(float)
        self.center_ = values.median().to_numpy()
        spread = values.std(ddof=0).to_numpy()
        self.scale_ = np.where(spread > 0, spread, 1.0)
        torch.manual_seed(self.seed)
        torch.set_num_threads(self.threads)
        torch.use_deterministic_algorithms(True)
        rng = np.random.default_rng(self.seed)
        fit_windows, _ = self._windows(train)
        if len(fit_windows) > self.fit_rows:
            fit_windows = fit_windows[rng.choice(len(fit_windows), self.fit_rows, replace=False)]
        val_windows, _ = self._windows(validation)
        if len(val_windows) > self.validation_rows:
            keep = np.sort(rng.choice(len(val_windows), replace=False))
            val_windows = val_windows[keep]
        self._validation = torch.as_tensor(val_windows, dtype=torch.float32)
        self._net = _Network(len(self.columns), self.hidden)
        optimiser = torch.optim.Adam(self._net.parameters(), lr=self.learning_rate)
        data = torch.as_tensor(fit_windows, dtype=torch.float32)
        shuffler = torch.Generator().manual_seed(self.seed)
        train_loss: list[float] = []
        validation_loss: list[float] = []
        best, best_state, stale = np.inf, None, 0
        for _epoch in range(self.max_epochs):
            self._net.train()
            order = torch.randperm(len(data), generator=shuffler)
            total = 0.0
            for start in range(0, len(data), self.batch_size):
                batch = data[order[start : start + self.batch_size]]
                optimiser.zero_grad()
                loss = nn.functional.mse_loss(self._net(batch), batch)
                loss.backward()
                optimiser.step()
                total += float(loss.detach()) * len(batch)
            train_loss.append(total / len(data))
            validation_loss.append(self.validation_loss_now())
            if validation_loss[-1] < best:
                best, stale = validation_loss[-1], 0
                best_state = {k: v.clone() for k, v in self._net.state_dict().items()}
            else:
                stale += 1
                if stale >= self.patience:
                    break
        assert best_state is not None
        self._net.load_state_dict(best_state)
        scores = self._reconstruction_error(fit_windows, last_only=True)
        self.threshold_ = float(np.quantile(scores, 1.0 - contamination))
        self._history = {
            "train_loss": train_loss,
            "validation_loss": validation_loss,
            "epochs_run": len(train_loss),
            "best_epoch": int(np.argmin(validation_loss)) + 1,
        }
        return self

    # -- fitting ------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁfit__mutmut_58(self, train: pd.DataFrame, validation: pd.DataFrame, contamination: float) -> Self:
        if not 0.0 < contamination < 0.5:
            raise ValueError("contamination must be in (0, 0.5)")
        if len(train) < self.window or len(validation) < self.window:
            raise ValueError("the training and validation rows must fill at least one window")
        values = train[self.columns].astype(float)
        self.center_ = values.median().to_numpy()
        spread = values.std(ddof=0).to_numpy()
        self.scale_ = np.where(spread > 0, spread, 1.0)
        torch.manual_seed(self.seed)
        torch.set_num_threads(self.threads)
        torch.use_deterministic_algorithms(True)
        rng = np.random.default_rng(self.seed)
        fit_windows, _ = self._windows(train)
        if len(fit_windows) > self.fit_rows:
            fit_windows = fit_windows[rng.choice(len(fit_windows), self.fit_rows, replace=False)]
        val_windows, _ = self._windows(validation)
        if len(val_windows) > self.validation_rows:
            keep = np.sort(rng.choice(len(val_windows), self.validation_rows, ))
            val_windows = val_windows[keep]
        self._validation = torch.as_tensor(val_windows, dtype=torch.float32)
        self._net = _Network(len(self.columns), self.hidden)
        optimiser = torch.optim.Adam(self._net.parameters(), lr=self.learning_rate)
        data = torch.as_tensor(fit_windows, dtype=torch.float32)
        shuffler = torch.Generator().manual_seed(self.seed)
        train_loss: list[float] = []
        validation_loss: list[float] = []
        best, best_state, stale = np.inf, None, 0
        for _epoch in range(self.max_epochs):
            self._net.train()
            order = torch.randperm(len(data), generator=shuffler)
            total = 0.0
            for start in range(0, len(data), self.batch_size):
                batch = data[order[start : start + self.batch_size]]
                optimiser.zero_grad()
                loss = nn.functional.mse_loss(self._net(batch), batch)
                loss.backward()
                optimiser.step()
                total += float(loss.detach()) * len(batch)
            train_loss.append(total / len(data))
            validation_loss.append(self.validation_loss_now())
            if validation_loss[-1] < best:
                best, stale = validation_loss[-1], 0
                best_state = {k: v.clone() for k, v in self._net.state_dict().items()}
            else:
                stale += 1
                if stale >= self.patience:
                    break
        assert best_state is not None
        self._net.load_state_dict(best_state)
        scores = self._reconstruction_error(fit_windows, last_only=True)
        self.threshold_ = float(np.quantile(scores, 1.0 - contamination))
        self._history = {
            "train_loss": train_loss,
            "validation_loss": validation_loss,
            "epochs_run": len(train_loss),
            "best_epoch": int(np.argmin(validation_loss)) + 1,
        }
        return self

    # -- fitting ------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁfit__mutmut_59(self, train: pd.DataFrame, validation: pd.DataFrame, contamination: float) -> Self:
        if not 0.0 < contamination < 0.5:
            raise ValueError("contamination must be in (0, 0.5)")
        if len(train) < self.window or len(validation) < self.window:
            raise ValueError("the training and validation rows must fill at least one window")
        values = train[self.columns].astype(float)
        self.center_ = values.median().to_numpy()
        spread = values.std(ddof=0).to_numpy()
        self.scale_ = np.where(spread > 0, spread, 1.0)
        torch.manual_seed(self.seed)
        torch.set_num_threads(self.threads)
        torch.use_deterministic_algorithms(True)
        rng = np.random.default_rng(self.seed)
        fit_windows, _ = self._windows(train)
        if len(fit_windows) > self.fit_rows:
            fit_windows = fit_windows[rng.choice(len(fit_windows), self.fit_rows, replace=False)]
        val_windows, _ = self._windows(validation)
        if len(val_windows) > self.validation_rows:
            keep = np.sort(rng.choice(len(val_windows), self.validation_rows, replace=True))
            val_windows = val_windows[keep]
        self._validation = torch.as_tensor(val_windows, dtype=torch.float32)
        self._net = _Network(len(self.columns), self.hidden)
        optimiser = torch.optim.Adam(self._net.parameters(), lr=self.learning_rate)
        data = torch.as_tensor(fit_windows, dtype=torch.float32)
        shuffler = torch.Generator().manual_seed(self.seed)
        train_loss: list[float] = []
        validation_loss: list[float] = []
        best, best_state, stale = np.inf, None, 0
        for _epoch in range(self.max_epochs):
            self._net.train()
            order = torch.randperm(len(data), generator=shuffler)
            total = 0.0
            for start in range(0, len(data), self.batch_size):
                batch = data[order[start : start + self.batch_size]]
                optimiser.zero_grad()
                loss = nn.functional.mse_loss(self._net(batch), batch)
                loss.backward()
                optimiser.step()
                total += float(loss.detach()) * len(batch)
            train_loss.append(total / len(data))
            validation_loss.append(self.validation_loss_now())
            if validation_loss[-1] < best:
                best, stale = validation_loss[-1], 0
                best_state = {k: v.clone() for k, v in self._net.state_dict().items()}
            else:
                stale += 1
                if stale >= self.patience:
                    break
        assert best_state is not None
        self._net.load_state_dict(best_state)
        scores = self._reconstruction_error(fit_windows, last_only=True)
        self.threshold_ = float(np.quantile(scores, 1.0 - contamination))
        self._history = {
            "train_loss": train_loss,
            "validation_loss": validation_loss,
            "epochs_run": len(train_loss),
            "best_epoch": int(np.argmin(validation_loss)) + 1,
        }
        return self

    # -- fitting ------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁfit__mutmut_60(self, train: pd.DataFrame, validation: pd.DataFrame, contamination: float) -> Self:
        if not 0.0 < contamination < 0.5:
            raise ValueError("contamination must be in (0, 0.5)")
        if len(train) < self.window or len(validation) < self.window:
            raise ValueError("the training and validation rows must fill at least one window")
        values = train[self.columns].astype(float)
        self.center_ = values.median().to_numpy()
        spread = values.std(ddof=0).to_numpy()
        self.scale_ = np.where(spread > 0, spread, 1.0)
        torch.manual_seed(self.seed)
        torch.set_num_threads(self.threads)
        torch.use_deterministic_algorithms(True)
        rng = np.random.default_rng(self.seed)
        fit_windows, _ = self._windows(train)
        if len(fit_windows) > self.fit_rows:
            fit_windows = fit_windows[rng.choice(len(fit_windows), self.fit_rows, replace=False)]
        val_windows, _ = self._windows(validation)
        if len(val_windows) > self.validation_rows:
            keep = np.sort(rng.choice(len(val_windows), self.validation_rows, replace=False))
            val_windows = None
        self._validation = torch.as_tensor(val_windows, dtype=torch.float32)
        self._net = _Network(len(self.columns), self.hidden)
        optimiser = torch.optim.Adam(self._net.parameters(), lr=self.learning_rate)
        data = torch.as_tensor(fit_windows, dtype=torch.float32)
        shuffler = torch.Generator().manual_seed(self.seed)
        train_loss: list[float] = []
        validation_loss: list[float] = []
        best, best_state, stale = np.inf, None, 0
        for _epoch in range(self.max_epochs):
            self._net.train()
            order = torch.randperm(len(data), generator=shuffler)
            total = 0.0
            for start in range(0, len(data), self.batch_size):
                batch = data[order[start : start + self.batch_size]]
                optimiser.zero_grad()
                loss = nn.functional.mse_loss(self._net(batch), batch)
                loss.backward()
                optimiser.step()
                total += float(loss.detach()) * len(batch)
            train_loss.append(total / len(data))
            validation_loss.append(self.validation_loss_now())
            if validation_loss[-1] < best:
                best, stale = validation_loss[-1], 0
                best_state = {k: v.clone() for k, v in self._net.state_dict().items()}
            else:
                stale += 1
                if stale >= self.patience:
                    break
        assert best_state is not None
        self._net.load_state_dict(best_state)
        scores = self._reconstruction_error(fit_windows, last_only=True)
        self.threshold_ = float(np.quantile(scores, 1.0 - contamination))
        self._history = {
            "train_loss": train_loss,
            "validation_loss": validation_loss,
            "epochs_run": len(train_loss),
            "best_epoch": int(np.argmin(validation_loss)) + 1,
        }
        return self

    # -- fitting ------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁfit__mutmut_61(self, train: pd.DataFrame, validation: pd.DataFrame, contamination: float) -> Self:
        if not 0.0 < contamination < 0.5:
            raise ValueError("contamination must be in (0, 0.5)")
        if len(train) < self.window or len(validation) < self.window:
            raise ValueError("the training and validation rows must fill at least one window")
        values = train[self.columns].astype(float)
        self.center_ = values.median().to_numpy()
        spread = values.std(ddof=0).to_numpy()
        self.scale_ = np.where(spread > 0, spread, 1.0)
        torch.manual_seed(self.seed)
        torch.set_num_threads(self.threads)
        torch.use_deterministic_algorithms(True)
        rng = np.random.default_rng(self.seed)
        fit_windows, _ = self._windows(train)
        if len(fit_windows) > self.fit_rows:
            fit_windows = fit_windows[rng.choice(len(fit_windows), self.fit_rows, replace=False)]
        val_windows, _ = self._windows(validation)
        if len(val_windows) > self.validation_rows:
            keep = np.sort(rng.choice(len(val_windows), self.validation_rows, replace=False))
            val_windows = val_windows[keep]
        self._validation = None
        self._net = _Network(len(self.columns), self.hidden)
        optimiser = torch.optim.Adam(self._net.parameters(), lr=self.learning_rate)
        data = torch.as_tensor(fit_windows, dtype=torch.float32)
        shuffler = torch.Generator().manual_seed(self.seed)
        train_loss: list[float] = []
        validation_loss: list[float] = []
        best, best_state, stale = np.inf, None, 0
        for _epoch in range(self.max_epochs):
            self._net.train()
            order = torch.randperm(len(data), generator=shuffler)
            total = 0.0
            for start in range(0, len(data), self.batch_size):
                batch = data[order[start : start + self.batch_size]]
                optimiser.zero_grad()
                loss = nn.functional.mse_loss(self._net(batch), batch)
                loss.backward()
                optimiser.step()
                total += float(loss.detach()) * len(batch)
            train_loss.append(total / len(data))
            validation_loss.append(self.validation_loss_now())
            if validation_loss[-1] < best:
                best, stale = validation_loss[-1], 0
                best_state = {k: v.clone() for k, v in self._net.state_dict().items()}
            else:
                stale += 1
                if stale >= self.patience:
                    break
        assert best_state is not None
        self._net.load_state_dict(best_state)
        scores = self._reconstruction_error(fit_windows, last_only=True)
        self.threshold_ = float(np.quantile(scores, 1.0 - contamination))
        self._history = {
            "train_loss": train_loss,
            "validation_loss": validation_loss,
            "epochs_run": len(train_loss),
            "best_epoch": int(np.argmin(validation_loss)) + 1,
        }
        return self

    # -- fitting ------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁfit__mutmut_62(self, train: pd.DataFrame, validation: pd.DataFrame, contamination: float) -> Self:
        if not 0.0 < contamination < 0.5:
            raise ValueError("contamination must be in (0, 0.5)")
        if len(train) < self.window or len(validation) < self.window:
            raise ValueError("the training and validation rows must fill at least one window")
        values = train[self.columns].astype(float)
        self.center_ = values.median().to_numpy()
        spread = values.std(ddof=0).to_numpy()
        self.scale_ = np.where(spread > 0, spread, 1.0)
        torch.manual_seed(self.seed)
        torch.set_num_threads(self.threads)
        torch.use_deterministic_algorithms(True)
        rng = np.random.default_rng(self.seed)
        fit_windows, _ = self._windows(train)
        if len(fit_windows) > self.fit_rows:
            fit_windows = fit_windows[rng.choice(len(fit_windows), self.fit_rows, replace=False)]
        val_windows, _ = self._windows(validation)
        if len(val_windows) > self.validation_rows:
            keep = np.sort(rng.choice(len(val_windows), self.validation_rows, replace=False))
            val_windows = val_windows[keep]
        self._validation = torch.as_tensor(None, dtype=torch.float32)
        self._net = _Network(len(self.columns), self.hidden)
        optimiser = torch.optim.Adam(self._net.parameters(), lr=self.learning_rate)
        data = torch.as_tensor(fit_windows, dtype=torch.float32)
        shuffler = torch.Generator().manual_seed(self.seed)
        train_loss: list[float] = []
        validation_loss: list[float] = []
        best, best_state, stale = np.inf, None, 0
        for _epoch in range(self.max_epochs):
            self._net.train()
            order = torch.randperm(len(data), generator=shuffler)
            total = 0.0
            for start in range(0, len(data), self.batch_size):
                batch = data[order[start : start + self.batch_size]]
                optimiser.zero_grad()
                loss = nn.functional.mse_loss(self._net(batch), batch)
                loss.backward()
                optimiser.step()
                total += float(loss.detach()) * len(batch)
            train_loss.append(total / len(data))
            validation_loss.append(self.validation_loss_now())
            if validation_loss[-1] < best:
                best, stale = validation_loss[-1], 0
                best_state = {k: v.clone() for k, v in self._net.state_dict().items()}
            else:
                stale += 1
                if stale >= self.patience:
                    break
        assert best_state is not None
        self._net.load_state_dict(best_state)
        scores = self._reconstruction_error(fit_windows, last_only=True)
        self.threshold_ = float(np.quantile(scores, 1.0 - contamination))
        self._history = {
            "train_loss": train_loss,
            "validation_loss": validation_loss,
            "epochs_run": len(train_loss),
            "best_epoch": int(np.argmin(validation_loss)) + 1,
        }
        return self

    # -- fitting ------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁfit__mutmut_63(self, train: pd.DataFrame, validation: pd.DataFrame, contamination: float) -> Self:
        if not 0.0 < contamination < 0.5:
            raise ValueError("contamination must be in (0, 0.5)")
        if len(train) < self.window or len(validation) < self.window:
            raise ValueError("the training and validation rows must fill at least one window")
        values = train[self.columns].astype(float)
        self.center_ = values.median().to_numpy()
        spread = values.std(ddof=0).to_numpy()
        self.scale_ = np.where(spread > 0, spread, 1.0)
        torch.manual_seed(self.seed)
        torch.set_num_threads(self.threads)
        torch.use_deterministic_algorithms(True)
        rng = np.random.default_rng(self.seed)
        fit_windows, _ = self._windows(train)
        if len(fit_windows) > self.fit_rows:
            fit_windows = fit_windows[rng.choice(len(fit_windows), self.fit_rows, replace=False)]
        val_windows, _ = self._windows(validation)
        if len(val_windows) > self.validation_rows:
            keep = np.sort(rng.choice(len(val_windows), self.validation_rows, replace=False))
            val_windows = val_windows[keep]
        self._validation = torch.as_tensor(val_windows, dtype=None)
        self._net = _Network(len(self.columns), self.hidden)
        optimiser = torch.optim.Adam(self._net.parameters(), lr=self.learning_rate)
        data = torch.as_tensor(fit_windows, dtype=torch.float32)
        shuffler = torch.Generator().manual_seed(self.seed)
        train_loss: list[float] = []
        validation_loss: list[float] = []
        best, best_state, stale = np.inf, None, 0
        for _epoch in range(self.max_epochs):
            self._net.train()
            order = torch.randperm(len(data), generator=shuffler)
            total = 0.0
            for start in range(0, len(data), self.batch_size):
                batch = data[order[start : start + self.batch_size]]
                optimiser.zero_grad()
                loss = nn.functional.mse_loss(self._net(batch), batch)
                loss.backward()
                optimiser.step()
                total += float(loss.detach()) * len(batch)
            train_loss.append(total / len(data))
            validation_loss.append(self.validation_loss_now())
            if validation_loss[-1] < best:
                best, stale = validation_loss[-1], 0
                best_state = {k: v.clone() for k, v in self._net.state_dict().items()}
            else:
                stale += 1
                if stale >= self.patience:
                    break
        assert best_state is not None
        self._net.load_state_dict(best_state)
        scores = self._reconstruction_error(fit_windows, last_only=True)
        self.threshold_ = float(np.quantile(scores, 1.0 - contamination))
        self._history = {
            "train_loss": train_loss,
            "validation_loss": validation_loss,
            "epochs_run": len(train_loss),
            "best_epoch": int(np.argmin(validation_loss)) + 1,
        }
        return self

    # -- fitting ------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁfit__mutmut_64(self, train: pd.DataFrame, validation: pd.DataFrame, contamination: float) -> Self:
        if not 0.0 < contamination < 0.5:
            raise ValueError("contamination must be in (0, 0.5)")
        if len(train) < self.window or len(validation) < self.window:
            raise ValueError("the training and validation rows must fill at least one window")
        values = train[self.columns].astype(float)
        self.center_ = values.median().to_numpy()
        spread = values.std(ddof=0).to_numpy()
        self.scale_ = np.where(spread > 0, spread, 1.0)
        torch.manual_seed(self.seed)
        torch.set_num_threads(self.threads)
        torch.use_deterministic_algorithms(True)
        rng = np.random.default_rng(self.seed)
        fit_windows, _ = self._windows(train)
        if len(fit_windows) > self.fit_rows:
            fit_windows = fit_windows[rng.choice(len(fit_windows), self.fit_rows, replace=False)]
        val_windows, _ = self._windows(validation)
        if len(val_windows) > self.validation_rows:
            keep = np.sort(rng.choice(len(val_windows), self.validation_rows, replace=False))
            val_windows = val_windows[keep]
        self._validation = torch.as_tensor(dtype=torch.float32)
        self._net = _Network(len(self.columns), self.hidden)
        optimiser = torch.optim.Adam(self._net.parameters(), lr=self.learning_rate)
        data = torch.as_tensor(fit_windows, dtype=torch.float32)
        shuffler = torch.Generator().manual_seed(self.seed)
        train_loss: list[float] = []
        validation_loss: list[float] = []
        best, best_state, stale = np.inf, None, 0
        for _epoch in range(self.max_epochs):
            self._net.train()
            order = torch.randperm(len(data), generator=shuffler)
            total = 0.0
            for start in range(0, len(data), self.batch_size):
                batch = data[order[start : start + self.batch_size]]
                optimiser.zero_grad()
                loss = nn.functional.mse_loss(self._net(batch), batch)
                loss.backward()
                optimiser.step()
                total += float(loss.detach()) * len(batch)
            train_loss.append(total / len(data))
            validation_loss.append(self.validation_loss_now())
            if validation_loss[-1] < best:
                best, stale = validation_loss[-1], 0
                best_state = {k: v.clone() for k, v in self._net.state_dict().items()}
            else:
                stale += 1
                if stale >= self.patience:
                    break
        assert best_state is not None
        self._net.load_state_dict(best_state)
        scores = self._reconstruction_error(fit_windows, last_only=True)
        self.threshold_ = float(np.quantile(scores, 1.0 - contamination))
        self._history = {
            "train_loss": train_loss,
            "validation_loss": validation_loss,
            "epochs_run": len(train_loss),
            "best_epoch": int(np.argmin(validation_loss)) + 1,
        }
        return self

    # -- fitting ------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁfit__mutmut_65(self, train: pd.DataFrame, validation: pd.DataFrame, contamination: float) -> Self:
        if not 0.0 < contamination < 0.5:
            raise ValueError("contamination must be in (0, 0.5)")
        if len(train) < self.window or len(validation) < self.window:
            raise ValueError("the training and validation rows must fill at least one window")
        values = train[self.columns].astype(float)
        self.center_ = values.median().to_numpy()
        spread = values.std(ddof=0).to_numpy()
        self.scale_ = np.where(spread > 0, spread, 1.0)
        torch.manual_seed(self.seed)
        torch.set_num_threads(self.threads)
        torch.use_deterministic_algorithms(True)
        rng = np.random.default_rng(self.seed)
        fit_windows, _ = self._windows(train)
        if len(fit_windows) > self.fit_rows:
            fit_windows = fit_windows[rng.choice(len(fit_windows), self.fit_rows, replace=False)]
        val_windows, _ = self._windows(validation)
        if len(val_windows) > self.validation_rows:
            keep = np.sort(rng.choice(len(val_windows), self.validation_rows, replace=False))
            val_windows = val_windows[keep]
        self._validation = torch.as_tensor(val_windows, )
        self._net = _Network(len(self.columns), self.hidden)
        optimiser = torch.optim.Adam(self._net.parameters(), lr=self.learning_rate)
        data = torch.as_tensor(fit_windows, dtype=torch.float32)
        shuffler = torch.Generator().manual_seed(self.seed)
        train_loss: list[float] = []
        validation_loss: list[float] = []
        best, best_state, stale = np.inf, None, 0
        for _epoch in range(self.max_epochs):
            self._net.train()
            order = torch.randperm(len(data), generator=shuffler)
            total = 0.0
            for start in range(0, len(data), self.batch_size):
                batch = data[order[start : start + self.batch_size]]
                optimiser.zero_grad()
                loss = nn.functional.mse_loss(self._net(batch), batch)
                loss.backward()
                optimiser.step()
                total += float(loss.detach()) * len(batch)
            train_loss.append(total / len(data))
            validation_loss.append(self.validation_loss_now())
            if validation_loss[-1] < best:
                best, stale = validation_loss[-1], 0
                best_state = {k: v.clone() for k, v in self._net.state_dict().items()}
            else:
                stale += 1
                if stale >= self.patience:
                    break
        assert best_state is not None
        self._net.load_state_dict(best_state)
        scores = self._reconstruction_error(fit_windows, last_only=True)
        self.threshold_ = float(np.quantile(scores, 1.0 - contamination))
        self._history = {
            "train_loss": train_loss,
            "validation_loss": validation_loss,
            "epochs_run": len(train_loss),
            "best_epoch": int(np.argmin(validation_loss)) + 1,
        }
        return self

    # -- fitting ------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁfit__mutmut_66(self, train: pd.DataFrame, validation: pd.DataFrame, contamination: float) -> Self:
        if not 0.0 < contamination < 0.5:
            raise ValueError("contamination must be in (0, 0.5)")
        if len(train) < self.window or len(validation) < self.window:
            raise ValueError("the training and validation rows must fill at least one window")
        values = train[self.columns].astype(float)
        self.center_ = values.median().to_numpy()
        spread = values.std(ddof=0).to_numpy()
        self.scale_ = np.where(spread > 0, spread, 1.0)
        torch.manual_seed(self.seed)
        torch.set_num_threads(self.threads)
        torch.use_deterministic_algorithms(True)
        rng = np.random.default_rng(self.seed)
        fit_windows, _ = self._windows(train)
        if len(fit_windows) > self.fit_rows:
            fit_windows = fit_windows[rng.choice(len(fit_windows), self.fit_rows, replace=False)]
        val_windows, _ = self._windows(validation)
        if len(val_windows) > self.validation_rows:
            keep = np.sort(rng.choice(len(val_windows), self.validation_rows, replace=False))
            val_windows = val_windows[keep]
        self._validation = torch.as_tensor(val_windows, dtype=torch.float32)
        self._net = None
        optimiser = torch.optim.Adam(self._net.parameters(), lr=self.learning_rate)
        data = torch.as_tensor(fit_windows, dtype=torch.float32)
        shuffler = torch.Generator().manual_seed(self.seed)
        train_loss: list[float] = []
        validation_loss: list[float] = []
        best, best_state, stale = np.inf, None, 0
        for _epoch in range(self.max_epochs):
            self._net.train()
            order = torch.randperm(len(data), generator=shuffler)
            total = 0.0
            for start in range(0, len(data), self.batch_size):
                batch = data[order[start : start + self.batch_size]]
                optimiser.zero_grad()
                loss = nn.functional.mse_loss(self._net(batch), batch)
                loss.backward()
                optimiser.step()
                total += float(loss.detach()) * len(batch)
            train_loss.append(total / len(data))
            validation_loss.append(self.validation_loss_now())
            if validation_loss[-1] < best:
                best, stale = validation_loss[-1], 0
                best_state = {k: v.clone() for k, v in self._net.state_dict().items()}
            else:
                stale += 1
                if stale >= self.patience:
                    break
        assert best_state is not None
        self._net.load_state_dict(best_state)
        scores = self._reconstruction_error(fit_windows, last_only=True)
        self.threshold_ = float(np.quantile(scores, 1.0 - contamination))
        self._history = {
            "train_loss": train_loss,
            "validation_loss": validation_loss,
            "epochs_run": len(train_loss),
            "best_epoch": int(np.argmin(validation_loss)) + 1,
        }
        return self

    # -- fitting ------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁfit__mutmut_67(self, train: pd.DataFrame, validation: pd.DataFrame, contamination: float) -> Self:
        if not 0.0 < contamination < 0.5:
            raise ValueError("contamination must be in (0, 0.5)")
        if len(train) < self.window or len(validation) < self.window:
            raise ValueError("the training and validation rows must fill at least one window")
        values = train[self.columns].astype(float)
        self.center_ = values.median().to_numpy()
        spread = values.std(ddof=0).to_numpy()
        self.scale_ = np.where(spread > 0, spread, 1.0)
        torch.manual_seed(self.seed)
        torch.set_num_threads(self.threads)
        torch.use_deterministic_algorithms(True)
        rng = np.random.default_rng(self.seed)
        fit_windows, _ = self._windows(train)
        if len(fit_windows) > self.fit_rows:
            fit_windows = fit_windows[rng.choice(len(fit_windows), self.fit_rows, replace=False)]
        val_windows, _ = self._windows(validation)
        if len(val_windows) > self.validation_rows:
            keep = np.sort(rng.choice(len(val_windows), self.validation_rows, replace=False))
            val_windows = val_windows[keep]
        self._validation = torch.as_tensor(val_windows, dtype=torch.float32)
        self._net = _Network(None, self.hidden)
        optimiser = torch.optim.Adam(self._net.parameters(), lr=self.learning_rate)
        data = torch.as_tensor(fit_windows, dtype=torch.float32)
        shuffler = torch.Generator().manual_seed(self.seed)
        train_loss: list[float] = []
        validation_loss: list[float] = []
        best, best_state, stale = np.inf, None, 0
        for _epoch in range(self.max_epochs):
            self._net.train()
            order = torch.randperm(len(data), generator=shuffler)
            total = 0.0
            for start in range(0, len(data), self.batch_size):
                batch = data[order[start : start + self.batch_size]]
                optimiser.zero_grad()
                loss = nn.functional.mse_loss(self._net(batch), batch)
                loss.backward()
                optimiser.step()
                total += float(loss.detach()) * len(batch)
            train_loss.append(total / len(data))
            validation_loss.append(self.validation_loss_now())
            if validation_loss[-1] < best:
                best, stale = validation_loss[-1], 0
                best_state = {k: v.clone() for k, v in self._net.state_dict().items()}
            else:
                stale += 1
                if stale >= self.patience:
                    break
        assert best_state is not None
        self._net.load_state_dict(best_state)
        scores = self._reconstruction_error(fit_windows, last_only=True)
        self.threshold_ = float(np.quantile(scores, 1.0 - contamination))
        self._history = {
            "train_loss": train_loss,
            "validation_loss": validation_loss,
            "epochs_run": len(train_loss),
            "best_epoch": int(np.argmin(validation_loss)) + 1,
        }
        return self

    # -- fitting ------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁfit__mutmut_68(self, train: pd.DataFrame, validation: pd.DataFrame, contamination: float) -> Self:
        if not 0.0 < contamination < 0.5:
            raise ValueError("contamination must be in (0, 0.5)")
        if len(train) < self.window or len(validation) < self.window:
            raise ValueError("the training and validation rows must fill at least one window")
        values = train[self.columns].astype(float)
        self.center_ = values.median().to_numpy()
        spread = values.std(ddof=0).to_numpy()
        self.scale_ = np.where(spread > 0, spread, 1.0)
        torch.manual_seed(self.seed)
        torch.set_num_threads(self.threads)
        torch.use_deterministic_algorithms(True)
        rng = np.random.default_rng(self.seed)
        fit_windows, _ = self._windows(train)
        if len(fit_windows) > self.fit_rows:
            fit_windows = fit_windows[rng.choice(len(fit_windows), self.fit_rows, replace=False)]
        val_windows, _ = self._windows(validation)
        if len(val_windows) > self.validation_rows:
            keep = np.sort(rng.choice(len(val_windows), self.validation_rows, replace=False))
            val_windows = val_windows[keep]
        self._validation = torch.as_tensor(val_windows, dtype=torch.float32)
        self._net = _Network(len(self.columns), None)
        optimiser = torch.optim.Adam(self._net.parameters(), lr=self.learning_rate)
        data = torch.as_tensor(fit_windows, dtype=torch.float32)
        shuffler = torch.Generator().manual_seed(self.seed)
        train_loss: list[float] = []
        validation_loss: list[float] = []
        best, best_state, stale = np.inf, None, 0
        for _epoch in range(self.max_epochs):
            self._net.train()
            order = torch.randperm(len(data), generator=shuffler)
            total = 0.0
            for start in range(0, len(data), self.batch_size):
                batch = data[order[start : start + self.batch_size]]
                optimiser.zero_grad()
                loss = nn.functional.mse_loss(self._net(batch), batch)
                loss.backward()
                optimiser.step()
                total += float(loss.detach()) * len(batch)
            train_loss.append(total / len(data))
            validation_loss.append(self.validation_loss_now())
            if validation_loss[-1] < best:
                best, stale = validation_loss[-1], 0
                best_state = {k: v.clone() for k, v in self._net.state_dict().items()}
            else:
                stale += 1
                if stale >= self.patience:
                    break
        assert best_state is not None
        self._net.load_state_dict(best_state)
        scores = self._reconstruction_error(fit_windows, last_only=True)
        self.threshold_ = float(np.quantile(scores, 1.0 - contamination))
        self._history = {
            "train_loss": train_loss,
            "validation_loss": validation_loss,
            "epochs_run": len(train_loss),
            "best_epoch": int(np.argmin(validation_loss)) + 1,
        }
        return self

    # -- fitting ------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁfit__mutmut_69(self, train: pd.DataFrame, validation: pd.DataFrame, contamination: float) -> Self:
        if not 0.0 < contamination < 0.5:
            raise ValueError("contamination must be in (0, 0.5)")
        if len(train) < self.window or len(validation) < self.window:
            raise ValueError("the training and validation rows must fill at least one window")
        values = train[self.columns].astype(float)
        self.center_ = values.median().to_numpy()
        spread = values.std(ddof=0).to_numpy()
        self.scale_ = np.where(spread > 0, spread, 1.0)
        torch.manual_seed(self.seed)
        torch.set_num_threads(self.threads)
        torch.use_deterministic_algorithms(True)
        rng = np.random.default_rng(self.seed)
        fit_windows, _ = self._windows(train)
        if len(fit_windows) > self.fit_rows:
            fit_windows = fit_windows[rng.choice(len(fit_windows), self.fit_rows, replace=False)]
        val_windows, _ = self._windows(validation)
        if len(val_windows) > self.validation_rows:
            keep = np.sort(rng.choice(len(val_windows), self.validation_rows, replace=False))
            val_windows = val_windows[keep]
        self._validation = torch.as_tensor(val_windows, dtype=torch.float32)
        self._net = _Network(self.hidden)
        optimiser = torch.optim.Adam(self._net.parameters(), lr=self.learning_rate)
        data = torch.as_tensor(fit_windows, dtype=torch.float32)
        shuffler = torch.Generator().manual_seed(self.seed)
        train_loss: list[float] = []
        validation_loss: list[float] = []
        best, best_state, stale = np.inf, None, 0
        for _epoch in range(self.max_epochs):
            self._net.train()
            order = torch.randperm(len(data), generator=shuffler)
            total = 0.0
            for start in range(0, len(data), self.batch_size):
                batch = data[order[start : start + self.batch_size]]
                optimiser.zero_grad()
                loss = nn.functional.mse_loss(self._net(batch), batch)
                loss.backward()
                optimiser.step()
                total += float(loss.detach()) * len(batch)
            train_loss.append(total / len(data))
            validation_loss.append(self.validation_loss_now())
            if validation_loss[-1] < best:
                best, stale = validation_loss[-1], 0
                best_state = {k: v.clone() for k, v in self._net.state_dict().items()}
            else:
                stale += 1
                if stale >= self.patience:
                    break
        assert best_state is not None
        self._net.load_state_dict(best_state)
        scores = self._reconstruction_error(fit_windows, last_only=True)
        self.threshold_ = float(np.quantile(scores, 1.0 - contamination))
        self._history = {
            "train_loss": train_loss,
            "validation_loss": validation_loss,
            "epochs_run": len(train_loss),
            "best_epoch": int(np.argmin(validation_loss)) + 1,
        }
        return self

    # -- fitting ------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁfit__mutmut_70(self, train: pd.DataFrame, validation: pd.DataFrame, contamination: float) -> Self:
        if not 0.0 < contamination < 0.5:
            raise ValueError("contamination must be in (0, 0.5)")
        if len(train) < self.window or len(validation) < self.window:
            raise ValueError("the training and validation rows must fill at least one window")
        values = train[self.columns].astype(float)
        self.center_ = values.median().to_numpy()
        spread = values.std(ddof=0).to_numpy()
        self.scale_ = np.where(spread > 0, spread, 1.0)
        torch.manual_seed(self.seed)
        torch.set_num_threads(self.threads)
        torch.use_deterministic_algorithms(True)
        rng = np.random.default_rng(self.seed)
        fit_windows, _ = self._windows(train)
        if len(fit_windows) > self.fit_rows:
            fit_windows = fit_windows[rng.choice(len(fit_windows), self.fit_rows, replace=False)]
        val_windows, _ = self._windows(validation)
        if len(val_windows) > self.validation_rows:
            keep = np.sort(rng.choice(len(val_windows), self.validation_rows, replace=False))
            val_windows = val_windows[keep]
        self._validation = torch.as_tensor(val_windows, dtype=torch.float32)
        self._net = _Network(len(self.columns), )
        optimiser = torch.optim.Adam(self._net.parameters(), lr=self.learning_rate)
        data = torch.as_tensor(fit_windows, dtype=torch.float32)
        shuffler = torch.Generator().manual_seed(self.seed)
        train_loss: list[float] = []
        validation_loss: list[float] = []
        best, best_state, stale = np.inf, None, 0
        for _epoch in range(self.max_epochs):
            self._net.train()
            order = torch.randperm(len(data), generator=shuffler)
            total = 0.0
            for start in range(0, len(data), self.batch_size):
                batch = data[order[start : start + self.batch_size]]
                optimiser.zero_grad()
                loss = nn.functional.mse_loss(self._net(batch), batch)
                loss.backward()
                optimiser.step()
                total += float(loss.detach()) * len(batch)
            train_loss.append(total / len(data))
            validation_loss.append(self.validation_loss_now())
            if validation_loss[-1] < best:
                best, stale = validation_loss[-1], 0
                best_state = {k: v.clone() for k, v in self._net.state_dict().items()}
            else:
                stale += 1
                if stale >= self.patience:
                    break
        assert best_state is not None
        self._net.load_state_dict(best_state)
        scores = self._reconstruction_error(fit_windows, last_only=True)
        self.threshold_ = float(np.quantile(scores, 1.0 - contamination))
        self._history = {
            "train_loss": train_loss,
            "validation_loss": validation_loss,
            "epochs_run": len(train_loss),
            "best_epoch": int(np.argmin(validation_loss)) + 1,
        }
        return self

    # -- fitting ------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁfit__mutmut_71(self, train: pd.DataFrame, validation: pd.DataFrame, contamination: float) -> Self:
        if not 0.0 < contamination < 0.5:
            raise ValueError("contamination must be in (0, 0.5)")
        if len(train) < self.window or len(validation) < self.window:
            raise ValueError("the training and validation rows must fill at least one window")
        values = train[self.columns].astype(float)
        self.center_ = values.median().to_numpy()
        spread = values.std(ddof=0).to_numpy()
        self.scale_ = np.where(spread > 0, spread, 1.0)
        torch.manual_seed(self.seed)
        torch.set_num_threads(self.threads)
        torch.use_deterministic_algorithms(True)
        rng = np.random.default_rng(self.seed)
        fit_windows, _ = self._windows(train)
        if len(fit_windows) > self.fit_rows:
            fit_windows = fit_windows[rng.choice(len(fit_windows), self.fit_rows, replace=False)]
        val_windows, _ = self._windows(validation)
        if len(val_windows) > self.validation_rows:
            keep = np.sort(rng.choice(len(val_windows), self.validation_rows, replace=False))
            val_windows = val_windows[keep]
        self._validation = torch.as_tensor(val_windows, dtype=torch.float32)
        self._net = _Network(len(self.columns), self.hidden)
        optimiser = None
        data = torch.as_tensor(fit_windows, dtype=torch.float32)
        shuffler = torch.Generator().manual_seed(self.seed)
        train_loss: list[float] = []
        validation_loss: list[float] = []
        best, best_state, stale = np.inf, None, 0
        for _epoch in range(self.max_epochs):
            self._net.train()
            order = torch.randperm(len(data), generator=shuffler)
            total = 0.0
            for start in range(0, len(data), self.batch_size):
                batch = data[order[start : start + self.batch_size]]
                optimiser.zero_grad()
                loss = nn.functional.mse_loss(self._net(batch), batch)
                loss.backward()
                optimiser.step()
                total += float(loss.detach()) * len(batch)
            train_loss.append(total / len(data))
            validation_loss.append(self.validation_loss_now())
            if validation_loss[-1] < best:
                best, stale = validation_loss[-1], 0
                best_state = {k: v.clone() for k, v in self._net.state_dict().items()}
            else:
                stale += 1
                if stale >= self.patience:
                    break
        assert best_state is not None
        self._net.load_state_dict(best_state)
        scores = self._reconstruction_error(fit_windows, last_only=True)
        self.threshold_ = float(np.quantile(scores, 1.0 - contamination))
        self._history = {
            "train_loss": train_loss,
            "validation_loss": validation_loss,
            "epochs_run": len(train_loss),
            "best_epoch": int(np.argmin(validation_loss)) + 1,
        }
        return self

    # -- fitting ------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁfit__mutmut_72(self, train: pd.DataFrame, validation: pd.DataFrame, contamination: float) -> Self:
        if not 0.0 < contamination < 0.5:
            raise ValueError("contamination must be in (0, 0.5)")
        if len(train) < self.window or len(validation) < self.window:
            raise ValueError("the training and validation rows must fill at least one window")
        values = train[self.columns].astype(float)
        self.center_ = values.median().to_numpy()
        spread = values.std(ddof=0).to_numpy()
        self.scale_ = np.where(spread > 0, spread, 1.0)
        torch.manual_seed(self.seed)
        torch.set_num_threads(self.threads)
        torch.use_deterministic_algorithms(True)
        rng = np.random.default_rng(self.seed)
        fit_windows, _ = self._windows(train)
        if len(fit_windows) > self.fit_rows:
            fit_windows = fit_windows[rng.choice(len(fit_windows), self.fit_rows, replace=False)]
        val_windows, _ = self._windows(validation)
        if len(val_windows) > self.validation_rows:
            keep = np.sort(rng.choice(len(val_windows), self.validation_rows, replace=False))
            val_windows = val_windows[keep]
        self._validation = torch.as_tensor(val_windows, dtype=torch.float32)
        self._net = _Network(len(self.columns), self.hidden)
        optimiser = torch.optim.Adam(None, lr=self.learning_rate)
        data = torch.as_tensor(fit_windows, dtype=torch.float32)
        shuffler = torch.Generator().manual_seed(self.seed)
        train_loss: list[float] = []
        validation_loss: list[float] = []
        best, best_state, stale = np.inf, None, 0
        for _epoch in range(self.max_epochs):
            self._net.train()
            order = torch.randperm(len(data), generator=shuffler)
            total = 0.0
            for start in range(0, len(data), self.batch_size):
                batch = data[order[start : start + self.batch_size]]
                optimiser.zero_grad()
                loss = nn.functional.mse_loss(self._net(batch), batch)
                loss.backward()
                optimiser.step()
                total += float(loss.detach()) * len(batch)
            train_loss.append(total / len(data))
            validation_loss.append(self.validation_loss_now())
            if validation_loss[-1] < best:
                best, stale = validation_loss[-1], 0
                best_state = {k: v.clone() for k, v in self._net.state_dict().items()}
            else:
                stale += 1
                if stale >= self.patience:
                    break
        assert best_state is not None
        self._net.load_state_dict(best_state)
        scores = self._reconstruction_error(fit_windows, last_only=True)
        self.threshold_ = float(np.quantile(scores, 1.0 - contamination))
        self._history = {
            "train_loss": train_loss,
            "validation_loss": validation_loss,
            "epochs_run": len(train_loss),
            "best_epoch": int(np.argmin(validation_loss)) + 1,
        }
        return self

    # -- fitting ------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁfit__mutmut_73(self, train: pd.DataFrame, validation: pd.DataFrame, contamination: float) -> Self:
        if not 0.0 < contamination < 0.5:
            raise ValueError("contamination must be in (0, 0.5)")
        if len(train) < self.window or len(validation) < self.window:
            raise ValueError("the training and validation rows must fill at least one window")
        values = train[self.columns].astype(float)
        self.center_ = values.median().to_numpy()
        spread = values.std(ddof=0).to_numpy()
        self.scale_ = np.where(spread > 0, spread, 1.0)
        torch.manual_seed(self.seed)
        torch.set_num_threads(self.threads)
        torch.use_deterministic_algorithms(True)
        rng = np.random.default_rng(self.seed)
        fit_windows, _ = self._windows(train)
        if len(fit_windows) > self.fit_rows:
            fit_windows = fit_windows[rng.choice(len(fit_windows), self.fit_rows, replace=False)]
        val_windows, _ = self._windows(validation)
        if len(val_windows) > self.validation_rows:
            keep = np.sort(rng.choice(len(val_windows), self.validation_rows, replace=False))
            val_windows = val_windows[keep]
        self._validation = torch.as_tensor(val_windows, dtype=torch.float32)
        self._net = _Network(len(self.columns), self.hidden)
        optimiser = torch.optim.Adam(self._net.parameters(), lr=None)
        data = torch.as_tensor(fit_windows, dtype=torch.float32)
        shuffler = torch.Generator().manual_seed(self.seed)
        train_loss: list[float] = []
        validation_loss: list[float] = []
        best, best_state, stale = np.inf, None, 0
        for _epoch in range(self.max_epochs):
            self._net.train()
            order = torch.randperm(len(data), generator=shuffler)
            total = 0.0
            for start in range(0, len(data), self.batch_size):
                batch = data[order[start : start + self.batch_size]]
                optimiser.zero_grad()
                loss = nn.functional.mse_loss(self._net(batch), batch)
                loss.backward()
                optimiser.step()
                total += float(loss.detach()) * len(batch)
            train_loss.append(total / len(data))
            validation_loss.append(self.validation_loss_now())
            if validation_loss[-1] < best:
                best, stale = validation_loss[-1], 0
                best_state = {k: v.clone() for k, v in self._net.state_dict().items()}
            else:
                stale += 1
                if stale >= self.patience:
                    break
        assert best_state is not None
        self._net.load_state_dict(best_state)
        scores = self._reconstruction_error(fit_windows, last_only=True)
        self.threshold_ = float(np.quantile(scores, 1.0 - contamination))
        self._history = {
            "train_loss": train_loss,
            "validation_loss": validation_loss,
            "epochs_run": len(train_loss),
            "best_epoch": int(np.argmin(validation_loss)) + 1,
        }
        return self

    # -- fitting ------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁfit__mutmut_74(self, train: pd.DataFrame, validation: pd.DataFrame, contamination: float) -> Self:
        if not 0.0 < contamination < 0.5:
            raise ValueError("contamination must be in (0, 0.5)")
        if len(train) < self.window or len(validation) < self.window:
            raise ValueError("the training and validation rows must fill at least one window")
        values = train[self.columns].astype(float)
        self.center_ = values.median().to_numpy()
        spread = values.std(ddof=0).to_numpy()
        self.scale_ = np.where(spread > 0, spread, 1.0)
        torch.manual_seed(self.seed)
        torch.set_num_threads(self.threads)
        torch.use_deterministic_algorithms(True)
        rng = np.random.default_rng(self.seed)
        fit_windows, _ = self._windows(train)
        if len(fit_windows) > self.fit_rows:
            fit_windows = fit_windows[rng.choice(len(fit_windows), self.fit_rows, replace=False)]
        val_windows, _ = self._windows(validation)
        if len(val_windows) > self.validation_rows:
            keep = np.sort(rng.choice(len(val_windows), self.validation_rows, replace=False))
            val_windows = val_windows[keep]
        self._validation = torch.as_tensor(val_windows, dtype=torch.float32)
        self._net = _Network(len(self.columns), self.hidden)
        optimiser = torch.optim.Adam(lr=self.learning_rate)
        data = torch.as_tensor(fit_windows, dtype=torch.float32)
        shuffler = torch.Generator().manual_seed(self.seed)
        train_loss: list[float] = []
        validation_loss: list[float] = []
        best, best_state, stale = np.inf, None, 0
        for _epoch in range(self.max_epochs):
            self._net.train()
            order = torch.randperm(len(data), generator=shuffler)
            total = 0.0
            for start in range(0, len(data), self.batch_size):
                batch = data[order[start : start + self.batch_size]]
                optimiser.zero_grad()
                loss = nn.functional.mse_loss(self._net(batch), batch)
                loss.backward()
                optimiser.step()
                total += float(loss.detach()) * len(batch)
            train_loss.append(total / len(data))
            validation_loss.append(self.validation_loss_now())
            if validation_loss[-1] < best:
                best, stale = validation_loss[-1], 0
                best_state = {k: v.clone() for k, v in self._net.state_dict().items()}
            else:
                stale += 1
                if stale >= self.patience:
                    break
        assert best_state is not None
        self._net.load_state_dict(best_state)
        scores = self._reconstruction_error(fit_windows, last_only=True)
        self.threshold_ = float(np.quantile(scores, 1.0 - contamination))
        self._history = {
            "train_loss": train_loss,
            "validation_loss": validation_loss,
            "epochs_run": len(train_loss),
            "best_epoch": int(np.argmin(validation_loss)) + 1,
        }
        return self

    # -- fitting ------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁfit__mutmut_75(self, train: pd.DataFrame, validation: pd.DataFrame, contamination: float) -> Self:
        if not 0.0 < contamination < 0.5:
            raise ValueError("contamination must be in (0, 0.5)")
        if len(train) < self.window or len(validation) < self.window:
            raise ValueError("the training and validation rows must fill at least one window")
        values = train[self.columns].astype(float)
        self.center_ = values.median().to_numpy()
        spread = values.std(ddof=0).to_numpy()
        self.scale_ = np.where(spread > 0, spread, 1.0)
        torch.manual_seed(self.seed)
        torch.set_num_threads(self.threads)
        torch.use_deterministic_algorithms(True)
        rng = np.random.default_rng(self.seed)
        fit_windows, _ = self._windows(train)
        if len(fit_windows) > self.fit_rows:
            fit_windows = fit_windows[rng.choice(len(fit_windows), self.fit_rows, replace=False)]
        val_windows, _ = self._windows(validation)
        if len(val_windows) > self.validation_rows:
            keep = np.sort(rng.choice(len(val_windows), self.validation_rows, replace=False))
            val_windows = val_windows[keep]
        self._validation = torch.as_tensor(val_windows, dtype=torch.float32)
        self._net = _Network(len(self.columns), self.hidden)
        optimiser = torch.optim.Adam(self._net.parameters(), )
        data = torch.as_tensor(fit_windows, dtype=torch.float32)
        shuffler = torch.Generator().manual_seed(self.seed)
        train_loss: list[float] = []
        validation_loss: list[float] = []
        best, best_state, stale = np.inf, None, 0
        for _epoch in range(self.max_epochs):
            self._net.train()
            order = torch.randperm(len(data), generator=shuffler)
            total = 0.0
            for start in range(0, len(data), self.batch_size):
                batch = data[order[start : start + self.batch_size]]
                optimiser.zero_grad()
                loss = nn.functional.mse_loss(self._net(batch), batch)
                loss.backward()
                optimiser.step()
                total += float(loss.detach()) * len(batch)
            train_loss.append(total / len(data))
            validation_loss.append(self.validation_loss_now())
            if validation_loss[-1] < best:
                best, stale = validation_loss[-1], 0
                best_state = {k: v.clone() for k, v in self._net.state_dict().items()}
            else:
                stale += 1
                if stale >= self.patience:
                    break
        assert best_state is not None
        self._net.load_state_dict(best_state)
        scores = self._reconstruction_error(fit_windows, last_only=True)
        self.threshold_ = float(np.quantile(scores, 1.0 - contamination))
        self._history = {
            "train_loss": train_loss,
            "validation_loss": validation_loss,
            "epochs_run": len(train_loss),
            "best_epoch": int(np.argmin(validation_loss)) + 1,
        }
        return self

    # -- fitting ------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁfit__mutmut_76(self, train: pd.DataFrame, validation: pd.DataFrame, contamination: float) -> Self:
        if not 0.0 < contamination < 0.5:
            raise ValueError("contamination must be in (0, 0.5)")
        if len(train) < self.window or len(validation) < self.window:
            raise ValueError("the training and validation rows must fill at least one window")
        values = train[self.columns].astype(float)
        self.center_ = values.median().to_numpy()
        spread = values.std(ddof=0).to_numpy()
        self.scale_ = np.where(spread > 0, spread, 1.0)
        torch.manual_seed(self.seed)
        torch.set_num_threads(self.threads)
        torch.use_deterministic_algorithms(True)
        rng = np.random.default_rng(self.seed)
        fit_windows, _ = self._windows(train)
        if len(fit_windows) > self.fit_rows:
            fit_windows = fit_windows[rng.choice(len(fit_windows), self.fit_rows, replace=False)]
        val_windows, _ = self._windows(validation)
        if len(val_windows) > self.validation_rows:
            keep = np.sort(rng.choice(len(val_windows), self.validation_rows, replace=False))
            val_windows = val_windows[keep]
        self._validation = torch.as_tensor(val_windows, dtype=torch.float32)
        self._net = _Network(len(self.columns), self.hidden)
        optimiser = torch.optim.Adam(self._net.parameters(), lr=self.learning_rate)
        data = None
        shuffler = torch.Generator().manual_seed(self.seed)
        train_loss: list[float] = []
        validation_loss: list[float] = []
        best, best_state, stale = np.inf, None, 0
        for _epoch in range(self.max_epochs):
            self._net.train()
            order = torch.randperm(len(data), generator=shuffler)
            total = 0.0
            for start in range(0, len(data), self.batch_size):
                batch = data[order[start : start + self.batch_size]]
                optimiser.zero_grad()
                loss = nn.functional.mse_loss(self._net(batch), batch)
                loss.backward()
                optimiser.step()
                total += float(loss.detach()) * len(batch)
            train_loss.append(total / len(data))
            validation_loss.append(self.validation_loss_now())
            if validation_loss[-1] < best:
                best, stale = validation_loss[-1], 0
                best_state = {k: v.clone() for k, v in self._net.state_dict().items()}
            else:
                stale += 1
                if stale >= self.patience:
                    break
        assert best_state is not None
        self._net.load_state_dict(best_state)
        scores = self._reconstruction_error(fit_windows, last_only=True)
        self.threshold_ = float(np.quantile(scores, 1.0 - contamination))
        self._history = {
            "train_loss": train_loss,
            "validation_loss": validation_loss,
            "epochs_run": len(train_loss),
            "best_epoch": int(np.argmin(validation_loss)) + 1,
        }
        return self

    # -- fitting ------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁfit__mutmut_77(self, train: pd.DataFrame, validation: pd.DataFrame, contamination: float) -> Self:
        if not 0.0 < contamination < 0.5:
            raise ValueError("contamination must be in (0, 0.5)")
        if len(train) < self.window or len(validation) < self.window:
            raise ValueError("the training and validation rows must fill at least one window")
        values = train[self.columns].astype(float)
        self.center_ = values.median().to_numpy()
        spread = values.std(ddof=0).to_numpy()
        self.scale_ = np.where(spread > 0, spread, 1.0)
        torch.manual_seed(self.seed)
        torch.set_num_threads(self.threads)
        torch.use_deterministic_algorithms(True)
        rng = np.random.default_rng(self.seed)
        fit_windows, _ = self._windows(train)
        if len(fit_windows) > self.fit_rows:
            fit_windows = fit_windows[rng.choice(len(fit_windows), self.fit_rows, replace=False)]
        val_windows, _ = self._windows(validation)
        if len(val_windows) > self.validation_rows:
            keep = np.sort(rng.choice(len(val_windows), self.validation_rows, replace=False))
            val_windows = val_windows[keep]
        self._validation = torch.as_tensor(val_windows, dtype=torch.float32)
        self._net = _Network(len(self.columns), self.hidden)
        optimiser = torch.optim.Adam(self._net.parameters(), lr=self.learning_rate)
        data = torch.as_tensor(None, dtype=torch.float32)
        shuffler = torch.Generator().manual_seed(self.seed)
        train_loss: list[float] = []
        validation_loss: list[float] = []
        best, best_state, stale = np.inf, None, 0
        for _epoch in range(self.max_epochs):
            self._net.train()
            order = torch.randperm(len(data), generator=shuffler)
            total = 0.0
            for start in range(0, len(data), self.batch_size):
                batch = data[order[start : start + self.batch_size]]
                optimiser.zero_grad()
                loss = nn.functional.mse_loss(self._net(batch), batch)
                loss.backward()
                optimiser.step()
                total += float(loss.detach()) * len(batch)
            train_loss.append(total / len(data))
            validation_loss.append(self.validation_loss_now())
            if validation_loss[-1] < best:
                best, stale = validation_loss[-1], 0
                best_state = {k: v.clone() for k, v in self._net.state_dict().items()}
            else:
                stale += 1
                if stale >= self.patience:
                    break
        assert best_state is not None
        self._net.load_state_dict(best_state)
        scores = self._reconstruction_error(fit_windows, last_only=True)
        self.threshold_ = float(np.quantile(scores, 1.0 - contamination))
        self._history = {
            "train_loss": train_loss,
            "validation_loss": validation_loss,
            "epochs_run": len(train_loss),
            "best_epoch": int(np.argmin(validation_loss)) + 1,
        }
        return self

    # -- fitting ------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁfit__mutmut_78(self, train: pd.DataFrame, validation: pd.DataFrame, contamination: float) -> Self:
        if not 0.0 < contamination < 0.5:
            raise ValueError("contamination must be in (0, 0.5)")
        if len(train) < self.window or len(validation) < self.window:
            raise ValueError("the training and validation rows must fill at least one window")
        values = train[self.columns].astype(float)
        self.center_ = values.median().to_numpy()
        spread = values.std(ddof=0).to_numpy()
        self.scale_ = np.where(spread > 0, spread, 1.0)
        torch.manual_seed(self.seed)
        torch.set_num_threads(self.threads)
        torch.use_deterministic_algorithms(True)
        rng = np.random.default_rng(self.seed)
        fit_windows, _ = self._windows(train)
        if len(fit_windows) > self.fit_rows:
            fit_windows = fit_windows[rng.choice(len(fit_windows), self.fit_rows, replace=False)]
        val_windows, _ = self._windows(validation)
        if len(val_windows) > self.validation_rows:
            keep = np.sort(rng.choice(len(val_windows), self.validation_rows, replace=False))
            val_windows = val_windows[keep]
        self._validation = torch.as_tensor(val_windows, dtype=torch.float32)
        self._net = _Network(len(self.columns), self.hidden)
        optimiser = torch.optim.Adam(self._net.parameters(), lr=self.learning_rate)
        data = torch.as_tensor(fit_windows, dtype=None)
        shuffler = torch.Generator().manual_seed(self.seed)
        train_loss: list[float] = []
        validation_loss: list[float] = []
        best, best_state, stale = np.inf, None, 0
        for _epoch in range(self.max_epochs):
            self._net.train()
            order = torch.randperm(len(data), generator=shuffler)
            total = 0.0
            for start in range(0, len(data), self.batch_size):
                batch = data[order[start : start + self.batch_size]]
                optimiser.zero_grad()
                loss = nn.functional.mse_loss(self._net(batch), batch)
                loss.backward()
                optimiser.step()
                total += float(loss.detach()) * len(batch)
            train_loss.append(total / len(data))
            validation_loss.append(self.validation_loss_now())
            if validation_loss[-1] < best:
                best, stale = validation_loss[-1], 0
                best_state = {k: v.clone() for k, v in self._net.state_dict().items()}
            else:
                stale += 1
                if stale >= self.patience:
                    break
        assert best_state is not None
        self._net.load_state_dict(best_state)
        scores = self._reconstruction_error(fit_windows, last_only=True)
        self.threshold_ = float(np.quantile(scores, 1.0 - contamination))
        self._history = {
            "train_loss": train_loss,
            "validation_loss": validation_loss,
            "epochs_run": len(train_loss),
            "best_epoch": int(np.argmin(validation_loss)) + 1,
        }
        return self

    # -- fitting ------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁfit__mutmut_79(self, train: pd.DataFrame, validation: pd.DataFrame, contamination: float) -> Self:
        if not 0.0 < contamination < 0.5:
            raise ValueError("contamination must be in (0, 0.5)")
        if len(train) < self.window or len(validation) < self.window:
            raise ValueError("the training and validation rows must fill at least one window")
        values = train[self.columns].astype(float)
        self.center_ = values.median().to_numpy()
        spread = values.std(ddof=0).to_numpy()
        self.scale_ = np.where(spread > 0, spread, 1.0)
        torch.manual_seed(self.seed)
        torch.set_num_threads(self.threads)
        torch.use_deterministic_algorithms(True)
        rng = np.random.default_rng(self.seed)
        fit_windows, _ = self._windows(train)
        if len(fit_windows) > self.fit_rows:
            fit_windows = fit_windows[rng.choice(len(fit_windows), self.fit_rows, replace=False)]
        val_windows, _ = self._windows(validation)
        if len(val_windows) > self.validation_rows:
            keep = np.sort(rng.choice(len(val_windows), self.validation_rows, replace=False))
            val_windows = val_windows[keep]
        self._validation = torch.as_tensor(val_windows, dtype=torch.float32)
        self._net = _Network(len(self.columns), self.hidden)
        optimiser = torch.optim.Adam(self._net.parameters(), lr=self.learning_rate)
        data = torch.as_tensor(dtype=torch.float32)
        shuffler = torch.Generator().manual_seed(self.seed)
        train_loss: list[float] = []
        validation_loss: list[float] = []
        best, best_state, stale = np.inf, None, 0
        for _epoch in range(self.max_epochs):
            self._net.train()
            order = torch.randperm(len(data), generator=shuffler)
            total = 0.0
            for start in range(0, len(data), self.batch_size):
                batch = data[order[start : start + self.batch_size]]
                optimiser.zero_grad()
                loss = nn.functional.mse_loss(self._net(batch), batch)
                loss.backward()
                optimiser.step()
                total += float(loss.detach()) * len(batch)
            train_loss.append(total / len(data))
            validation_loss.append(self.validation_loss_now())
            if validation_loss[-1] < best:
                best, stale = validation_loss[-1], 0
                best_state = {k: v.clone() for k, v in self._net.state_dict().items()}
            else:
                stale += 1
                if stale >= self.patience:
                    break
        assert best_state is not None
        self._net.load_state_dict(best_state)
        scores = self._reconstruction_error(fit_windows, last_only=True)
        self.threshold_ = float(np.quantile(scores, 1.0 - contamination))
        self._history = {
            "train_loss": train_loss,
            "validation_loss": validation_loss,
            "epochs_run": len(train_loss),
            "best_epoch": int(np.argmin(validation_loss)) + 1,
        }
        return self

    # -- fitting ------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁfit__mutmut_80(self, train: pd.DataFrame, validation: pd.DataFrame, contamination: float) -> Self:
        if not 0.0 < contamination < 0.5:
            raise ValueError("contamination must be in (0, 0.5)")
        if len(train) < self.window or len(validation) < self.window:
            raise ValueError("the training and validation rows must fill at least one window")
        values = train[self.columns].astype(float)
        self.center_ = values.median().to_numpy()
        spread = values.std(ddof=0).to_numpy()
        self.scale_ = np.where(spread > 0, spread, 1.0)
        torch.manual_seed(self.seed)
        torch.set_num_threads(self.threads)
        torch.use_deterministic_algorithms(True)
        rng = np.random.default_rng(self.seed)
        fit_windows, _ = self._windows(train)
        if len(fit_windows) > self.fit_rows:
            fit_windows = fit_windows[rng.choice(len(fit_windows), self.fit_rows, replace=False)]
        val_windows, _ = self._windows(validation)
        if len(val_windows) > self.validation_rows:
            keep = np.sort(rng.choice(len(val_windows), self.validation_rows, replace=False))
            val_windows = val_windows[keep]
        self._validation = torch.as_tensor(val_windows, dtype=torch.float32)
        self._net = _Network(len(self.columns), self.hidden)
        optimiser = torch.optim.Adam(self._net.parameters(), lr=self.learning_rate)
        data = torch.as_tensor(fit_windows, )
        shuffler = torch.Generator().manual_seed(self.seed)
        train_loss: list[float] = []
        validation_loss: list[float] = []
        best, best_state, stale = np.inf, None, 0
        for _epoch in range(self.max_epochs):
            self._net.train()
            order = torch.randperm(len(data), generator=shuffler)
            total = 0.0
            for start in range(0, len(data), self.batch_size):
                batch = data[order[start : start + self.batch_size]]
                optimiser.zero_grad()
                loss = nn.functional.mse_loss(self._net(batch), batch)
                loss.backward()
                optimiser.step()
                total += float(loss.detach()) * len(batch)
            train_loss.append(total / len(data))
            validation_loss.append(self.validation_loss_now())
            if validation_loss[-1] < best:
                best, stale = validation_loss[-1], 0
                best_state = {k: v.clone() for k, v in self._net.state_dict().items()}
            else:
                stale += 1
                if stale >= self.patience:
                    break
        assert best_state is not None
        self._net.load_state_dict(best_state)
        scores = self._reconstruction_error(fit_windows, last_only=True)
        self.threshold_ = float(np.quantile(scores, 1.0 - contamination))
        self._history = {
            "train_loss": train_loss,
            "validation_loss": validation_loss,
            "epochs_run": len(train_loss),
            "best_epoch": int(np.argmin(validation_loss)) + 1,
        }
        return self

    # -- fitting ------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁfit__mutmut_81(self, train: pd.DataFrame, validation: pd.DataFrame, contamination: float) -> Self:
        if not 0.0 < contamination < 0.5:
            raise ValueError("contamination must be in (0, 0.5)")
        if len(train) < self.window or len(validation) < self.window:
            raise ValueError("the training and validation rows must fill at least one window")
        values = train[self.columns].astype(float)
        self.center_ = values.median().to_numpy()
        spread = values.std(ddof=0).to_numpy()
        self.scale_ = np.where(spread > 0, spread, 1.0)
        torch.manual_seed(self.seed)
        torch.set_num_threads(self.threads)
        torch.use_deterministic_algorithms(True)
        rng = np.random.default_rng(self.seed)
        fit_windows, _ = self._windows(train)
        if len(fit_windows) > self.fit_rows:
            fit_windows = fit_windows[rng.choice(len(fit_windows), self.fit_rows, replace=False)]
        val_windows, _ = self._windows(validation)
        if len(val_windows) > self.validation_rows:
            keep = np.sort(rng.choice(len(val_windows), self.validation_rows, replace=False))
            val_windows = val_windows[keep]
        self._validation = torch.as_tensor(val_windows, dtype=torch.float32)
        self._net = _Network(len(self.columns), self.hidden)
        optimiser = torch.optim.Adam(self._net.parameters(), lr=self.learning_rate)
        data = torch.as_tensor(fit_windows, dtype=torch.float32)
        shuffler = None
        train_loss: list[float] = []
        validation_loss: list[float] = []
        best, best_state, stale = np.inf, None, 0
        for _epoch in range(self.max_epochs):
            self._net.train()
            order = torch.randperm(len(data), generator=shuffler)
            total = 0.0
            for start in range(0, len(data), self.batch_size):
                batch = data[order[start : start + self.batch_size]]
                optimiser.zero_grad()
                loss = nn.functional.mse_loss(self._net(batch), batch)
                loss.backward()
                optimiser.step()
                total += float(loss.detach()) * len(batch)
            train_loss.append(total / len(data))
            validation_loss.append(self.validation_loss_now())
            if validation_loss[-1] < best:
                best, stale = validation_loss[-1], 0
                best_state = {k: v.clone() for k, v in self._net.state_dict().items()}
            else:
                stale += 1
                if stale >= self.patience:
                    break
        assert best_state is not None
        self._net.load_state_dict(best_state)
        scores = self._reconstruction_error(fit_windows, last_only=True)
        self.threshold_ = float(np.quantile(scores, 1.0 - contamination))
        self._history = {
            "train_loss": train_loss,
            "validation_loss": validation_loss,
            "epochs_run": len(train_loss),
            "best_epoch": int(np.argmin(validation_loss)) + 1,
        }
        return self

    # -- fitting ------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁfit__mutmut_82(self, train: pd.DataFrame, validation: pd.DataFrame, contamination: float) -> Self:
        if not 0.0 < contamination < 0.5:
            raise ValueError("contamination must be in (0, 0.5)")
        if len(train) < self.window or len(validation) < self.window:
            raise ValueError("the training and validation rows must fill at least one window")
        values = train[self.columns].astype(float)
        self.center_ = values.median().to_numpy()
        spread = values.std(ddof=0).to_numpy()
        self.scale_ = np.where(spread > 0, spread, 1.0)
        torch.manual_seed(self.seed)
        torch.set_num_threads(self.threads)
        torch.use_deterministic_algorithms(True)
        rng = np.random.default_rng(self.seed)
        fit_windows, _ = self._windows(train)
        if len(fit_windows) > self.fit_rows:
            fit_windows = fit_windows[rng.choice(len(fit_windows), self.fit_rows, replace=False)]
        val_windows, _ = self._windows(validation)
        if len(val_windows) > self.validation_rows:
            keep = np.sort(rng.choice(len(val_windows), self.validation_rows, replace=False))
            val_windows = val_windows[keep]
        self._validation = torch.as_tensor(val_windows, dtype=torch.float32)
        self._net = _Network(len(self.columns), self.hidden)
        optimiser = torch.optim.Adam(self._net.parameters(), lr=self.learning_rate)
        data = torch.as_tensor(fit_windows, dtype=torch.float32)
        shuffler = torch.Generator().manual_seed(None)
        train_loss: list[float] = []
        validation_loss: list[float] = []
        best, best_state, stale = np.inf, None, 0
        for _epoch in range(self.max_epochs):
            self._net.train()
            order = torch.randperm(len(data), generator=shuffler)
            total = 0.0
            for start in range(0, len(data), self.batch_size):
                batch = data[order[start : start + self.batch_size]]
                optimiser.zero_grad()
                loss = nn.functional.mse_loss(self._net(batch), batch)
                loss.backward()
                optimiser.step()
                total += float(loss.detach()) * len(batch)
            train_loss.append(total / len(data))
            validation_loss.append(self.validation_loss_now())
            if validation_loss[-1] < best:
                best, stale = validation_loss[-1], 0
                best_state = {k: v.clone() for k, v in self._net.state_dict().items()}
            else:
                stale += 1
                if stale >= self.patience:
                    break
        assert best_state is not None
        self._net.load_state_dict(best_state)
        scores = self._reconstruction_error(fit_windows, last_only=True)
        self.threshold_ = float(np.quantile(scores, 1.0 - contamination))
        self._history = {
            "train_loss": train_loss,
            "validation_loss": validation_loss,
            "epochs_run": len(train_loss),
            "best_epoch": int(np.argmin(validation_loss)) + 1,
        }
        return self

    # -- fitting ------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁfit__mutmut_83(self, train: pd.DataFrame, validation: pd.DataFrame, contamination: float) -> Self:
        if not 0.0 < contamination < 0.5:
            raise ValueError("contamination must be in (0, 0.5)")
        if len(train) < self.window or len(validation) < self.window:
            raise ValueError("the training and validation rows must fill at least one window")
        values = train[self.columns].astype(float)
        self.center_ = values.median().to_numpy()
        spread = values.std(ddof=0).to_numpy()
        self.scale_ = np.where(spread > 0, spread, 1.0)
        torch.manual_seed(self.seed)
        torch.set_num_threads(self.threads)
        torch.use_deterministic_algorithms(True)
        rng = np.random.default_rng(self.seed)
        fit_windows, _ = self._windows(train)
        if len(fit_windows) > self.fit_rows:
            fit_windows = fit_windows[rng.choice(len(fit_windows), self.fit_rows, replace=False)]
        val_windows, _ = self._windows(validation)
        if len(val_windows) > self.validation_rows:
            keep = np.sort(rng.choice(len(val_windows), self.validation_rows, replace=False))
            val_windows = val_windows[keep]
        self._validation = torch.as_tensor(val_windows, dtype=torch.float32)
        self._net = _Network(len(self.columns), self.hidden)
        optimiser = torch.optim.Adam(self._net.parameters(), lr=self.learning_rate)
        data = torch.as_tensor(fit_windows, dtype=torch.float32)
        shuffler = torch.Generator().manual_seed(self.seed)
        train_loss: list[float] = None
        validation_loss: list[float] = []
        best, best_state, stale = np.inf, None, 0
        for _epoch in range(self.max_epochs):
            self._net.train()
            order = torch.randperm(len(data), generator=shuffler)
            total = 0.0
            for start in range(0, len(data), self.batch_size):
                batch = data[order[start : start + self.batch_size]]
                optimiser.zero_grad()
                loss = nn.functional.mse_loss(self._net(batch), batch)
                loss.backward()
                optimiser.step()
                total += float(loss.detach()) * len(batch)
            train_loss.append(total / len(data))
            validation_loss.append(self.validation_loss_now())
            if validation_loss[-1] < best:
                best, stale = validation_loss[-1], 0
                best_state = {k: v.clone() for k, v in self._net.state_dict().items()}
            else:
                stale += 1
                if stale >= self.patience:
                    break
        assert best_state is not None
        self._net.load_state_dict(best_state)
        scores = self._reconstruction_error(fit_windows, last_only=True)
        self.threshold_ = float(np.quantile(scores, 1.0 - contamination))
        self._history = {
            "train_loss": train_loss,
            "validation_loss": validation_loss,
            "epochs_run": len(train_loss),
            "best_epoch": int(np.argmin(validation_loss)) + 1,
        }
        return self

    # -- fitting ------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁfit__mutmut_84(self, train: pd.DataFrame, validation: pd.DataFrame, contamination: float) -> Self:
        if not 0.0 < contamination < 0.5:
            raise ValueError("contamination must be in (0, 0.5)")
        if len(train) < self.window or len(validation) < self.window:
            raise ValueError("the training and validation rows must fill at least one window")
        values = train[self.columns].astype(float)
        self.center_ = values.median().to_numpy()
        spread = values.std(ddof=0).to_numpy()
        self.scale_ = np.where(spread > 0, spread, 1.0)
        torch.manual_seed(self.seed)
        torch.set_num_threads(self.threads)
        torch.use_deterministic_algorithms(True)
        rng = np.random.default_rng(self.seed)
        fit_windows, _ = self._windows(train)
        if len(fit_windows) > self.fit_rows:
            fit_windows = fit_windows[rng.choice(len(fit_windows), self.fit_rows, replace=False)]
        val_windows, _ = self._windows(validation)
        if len(val_windows) > self.validation_rows:
            keep = np.sort(rng.choice(len(val_windows), self.validation_rows, replace=False))
            val_windows = val_windows[keep]
        self._validation = torch.as_tensor(val_windows, dtype=torch.float32)
        self._net = _Network(len(self.columns), self.hidden)
        optimiser = torch.optim.Adam(self._net.parameters(), lr=self.learning_rate)
        data = torch.as_tensor(fit_windows, dtype=torch.float32)
        shuffler = torch.Generator().manual_seed(self.seed)
        train_loss: list[float] = []
        validation_loss: list[float] = None
        best, best_state, stale = np.inf, None, 0
        for _epoch in range(self.max_epochs):
            self._net.train()
            order = torch.randperm(len(data), generator=shuffler)
            total = 0.0
            for start in range(0, len(data), self.batch_size):
                batch = data[order[start : start + self.batch_size]]
                optimiser.zero_grad()
                loss = nn.functional.mse_loss(self._net(batch), batch)
                loss.backward()
                optimiser.step()
                total += float(loss.detach()) * len(batch)
            train_loss.append(total / len(data))
            validation_loss.append(self.validation_loss_now())
            if validation_loss[-1] < best:
                best, stale = validation_loss[-1], 0
                best_state = {k: v.clone() for k, v in self._net.state_dict().items()}
            else:
                stale += 1
                if stale >= self.patience:
                    break
        assert best_state is not None
        self._net.load_state_dict(best_state)
        scores = self._reconstruction_error(fit_windows, last_only=True)
        self.threshold_ = float(np.quantile(scores, 1.0 - contamination))
        self._history = {
            "train_loss": train_loss,
            "validation_loss": validation_loss,
            "epochs_run": len(train_loss),
            "best_epoch": int(np.argmin(validation_loss)) + 1,
        }
        return self

    # -- fitting ------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁfit__mutmut_85(self, train: pd.DataFrame, validation: pd.DataFrame, contamination: float) -> Self:
        if not 0.0 < contamination < 0.5:
            raise ValueError("contamination must be in (0, 0.5)")
        if len(train) < self.window or len(validation) < self.window:
            raise ValueError("the training and validation rows must fill at least one window")
        values = train[self.columns].astype(float)
        self.center_ = values.median().to_numpy()
        spread = values.std(ddof=0).to_numpy()
        self.scale_ = np.where(spread > 0, spread, 1.0)
        torch.manual_seed(self.seed)
        torch.set_num_threads(self.threads)
        torch.use_deterministic_algorithms(True)
        rng = np.random.default_rng(self.seed)
        fit_windows, _ = self._windows(train)
        if len(fit_windows) > self.fit_rows:
            fit_windows = fit_windows[rng.choice(len(fit_windows), self.fit_rows, replace=False)]
        val_windows, _ = self._windows(validation)
        if len(val_windows) > self.validation_rows:
            keep = np.sort(rng.choice(len(val_windows), self.validation_rows, replace=False))
            val_windows = val_windows[keep]
        self._validation = torch.as_tensor(val_windows, dtype=torch.float32)
        self._net = _Network(len(self.columns), self.hidden)
        optimiser = torch.optim.Adam(self._net.parameters(), lr=self.learning_rate)
        data = torch.as_tensor(fit_windows, dtype=torch.float32)
        shuffler = torch.Generator().manual_seed(self.seed)
        train_loss: list[float] = []
        validation_loss: list[float] = []
        best, best_state, stale = None
        for _epoch in range(self.max_epochs):
            self._net.train()
            order = torch.randperm(len(data), generator=shuffler)
            total = 0.0
            for start in range(0, len(data), self.batch_size):
                batch = data[order[start : start + self.batch_size]]
                optimiser.zero_grad()
                loss = nn.functional.mse_loss(self._net(batch), batch)
                loss.backward()
                optimiser.step()
                total += float(loss.detach()) * len(batch)
            train_loss.append(total / len(data))
            validation_loss.append(self.validation_loss_now())
            if validation_loss[-1] < best:
                best, stale = validation_loss[-1], 0
                best_state = {k: v.clone() for k, v in self._net.state_dict().items()}
            else:
                stale += 1
                if stale >= self.patience:
                    break
        assert best_state is not None
        self._net.load_state_dict(best_state)
        scores = self._reconstruction_error(fit_windows, last_only=True)
        self.threshold_ = float(np.quantile(scores, 1.0 - contamination))
        self._history = {
            "train_loss": train_loss,
            "validation_loss": validation_loss,
            "epochs_run": len(train_loss),
            "best_epoch": int(np.argmin(validation_loss)) + 1,
        }
        return self

    # -- fitting ------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁfit__mutmut_86(self, train: pd.DataFrame, validation: pd.DataFrame, contamination: float) -> Self:
        if not 0.0 < contamination < 0.5:
            raise ValueError("contamination must be in (0, 0.5)")
        if len(train) < self.window or len(validation) < self.window:
            raise ValueError("the training and validation rows must fill at least one window")
        values = train[self.columns].astype(float)
        self.center_ = values.median().to_numpy()
        spread = values.std(ddof=0).to_numpy()
        self.scale_ = np.where(spread > 0, spread, 1.0)
        torch.manual_seed(self.seed)
        torch.set_num_threads(self.threads)
        torch.use_deterministic_algorithms(True)
        rng = np.random.default_rng(self.seed)
        fit_windows, _ = self._windows(train)
        if len(fit_windows) > self.fit_rows:
            fit_windows = fit_windows[rng.choice(len(fit_windows), self.fit_rows, replace=False)]
        val_windows, _ = self._windows(validation)
        if len(val_windows) > self.validation_rows:
            keep = np.sort(rng.choice(len(val_windows), self.validation_rows, replace=False))
            val_windows = val_windows[keep]
        self._validation = torch.as_tensor(val_windows, dtype=torch.float32)
        self._net = _Network(len(self.columns), self.hidden)
        optimiser = torch.optim.Adam(self._net.parameters(), lr=self.learning_rate)
        data = torch.as_tensor(fit_windows, dtype=torch.float32)
        shuffler = torch.Generator().manual_seed(self.seed)
        train_loss: list[float] = []
        validation_loss: list[float] = []
        best, best_state, stale = np.inf, None, 1
        for _epoch in range(self.max_epochs):
            self._net.train()
            order = torch.randperm(len(data), generator=shuffler)
            total = 0.0
            for start in range(0, len(data), self.batch_size):
                batch = data[order[start : start + self.batch_size]]
                optimiser.zero_grad()
                loss = nn.functional.mse_loss(self._net(batch), batch)
                loss.backward()
                optimiser.step()
                total += float(loss.detach()) * len(batch)
            train_loss.append(total / len(data))
            validation_loss.append(self.validation_loss_now())
            if validation_loss[-1] < best:
                best, stale = validation_loss[-1], 0
                best_state = {k: v.clone() for k, v in self._net.state_dict().items()}
            else:
                stale += 1
                if stale >= self.patience:
                    break
        assert best_state is not None
        self._net.load_state_dict(best_state)
        scores = self._reconstruction_error(fit_windows, last_only=True)
        self.threshold_ = float(np.quantile(scores, 1.0 - contamination))
        self._history = {
            "train_loss": train_loss,
            "validation_loss": validation_loss,
            "epochs_run": len(train_loss),
            "best_epoch": int(np.argmin(validation_loss)) + 1,
        }
        return self

    # -- fitting ------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁfit__mutmut_87(self, train: pd.DataFrame, validation: pd.DataFrame, contamination: float) -> Self:
        if not 0.0 < contamination < 0.5:
            raise ValueError("contamination must be in (0, 0.5)")
        if len(train) < self.window or len(validation) < self.window:
            raise ValueError("the training and validation rows must fill at least one window")
        values = train[self.columns].astype(float)
        self.center_ = values.median().to_numpy()
        spread = values.std(ddof=0).to_numpy()
        self.scale_ = np.where(spread > 0, spread, 1.0)
        torch.manual_seed(self.seed)
        torch.set_num_threads(self.threads)
        torch.use_deterministic_algorithms(True)
        rng = np.random.default_rng(self.seed)
        fit_windows, _ = self._windows(train)
        if len(fit_windows) > self.fit_rows:
            fit_windows = fit_windows[rng.choice(len(fit_windows), self.fit_rows, replace=False)]
        val_windows, _ = self._windows(validation)
        if len(val_windows) > self.validation_rows:
            keep = np.sort(rng.choice(len(val_windows), self.validation_rows, replace=False))
            val_windows = val_windows[keep]
        self._validation = torch.as_tensor(val_windows, dtype=torch.float32)
        self._net = _Network(len(self.columns), self.hidden)
        optimiser = torch.optim.Adam(self._net.parameters(), lr=self.learning_rate)
        data = torch.as_tensor(fit_windows, dtype=torch.float32)
        shuffler = torch.Generator().manual_seed(self.seed)
        train_loss: list[float] = []
        validation_loss: list[float] = []
        best, best_state, stale = np.inf, None, 0
        for _epoch in range(None):
            self._net.train()
            order = torch.randperm(len(data), generator=shuffler)
            total = 0.0
            for start in range(0, len(data), self.batch_size):
                batch = data[order[start : start + self.batch_size]]
                optimiser.zero_grad()
                loss = nn.functional.mse_loss(self._net(batch), batch)
                loss.backward()
                optimiser.step()
                total += float(loss.detach()) * len(batch)
            train_loss.append(total / len(data))
            validation_loss.append(self.validation_loss_now())
            if validation_loss[-1] < best:
                best, stale = validation_loss[-1], 0
                best_state = {k: v.clone() for k, v in self._net.state_dict().items()}
            else:
                stale += 1
                if stale >= self.patience:
                    break
        assert best_state is not None
        self._net.load_state_dict(best_state)
        scores = self._reconstruction_error(fit_windows, last_only=True)
        self.threshold_ = float(np.quantile(scores, 1.0 - contamination))
        self._history = {
            "train_loss": train_loss,
            "validation_loss": validation_loss,
            "epochs_run": len(train_loss),
            "best_epoch": int(np.argmin(validation_loss)) + 1,
        }
        return self

    # -- fitting ------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁfit__mutmut_88(self, train: pd.DataFrame, validation: pd.DataFrame, contamination: float) -> Self:
        if not 0.0 < contamination < 0.5:
            raise ValueError("contamination must be in (0, 0.5)")
        if len(train) < self.window or len(validation) < self.window:
            raise ValueError("the training and validation rows must fill at least one window")
        values = train[self.columns].astype(float)
        self.center_ = values.median().to_numpy()
        spread = values.std(ddof=0).to_numpy()
        self.scale_ = np.where(spread > 0, spread, 1.0)
        torch.manual_seed(self.seed)
        torch.set_num_threads(self.threads)
        torch.use_deterministic_algorithms(True)
        rng = np.random.default_rng(self.seed)
        fit_windows, _ = self._windows(train)
        if len(fit_windows) > self.fit_rows:
            fit_windows = fit_windows[rng.choice(len(fit_windows), self.fit_rows, replace=False)]
        val_windows, _ = self._windows(validation)
        if len(val_windows) > self.validation_rows:
            keep = np.sort(rng.choice(len(val_windows), self.validation_rows, replace=False))
            val_windows = val_windows[keep]
        self._validation = torch.as_tensor(val_windows, dtype=torch.float32)
        self._net = _Network(len(self.columns), self.hidden)
        optimiser = torch.optim.Adam(self._net.parameters(), lr=self.learning_rate)
        data = torch.as_tensor(fit_windows, dtype=torch.float32)
        shuffler = torch.Generator().manual_seed(self.seed)
        train_loss: list[float] = []
        validation_loss: list[float] = []
        best, best_state, stale = np.inf, None, 0
        for _epoch in range(self.max_epochs):
            self._net.train()
            order = None
            total = 0.0
            for start in range(0, len(data), self.batch_size):
                batch = data[order[start : start + self.batch_size]]
                optimiser.zero_grad()
                loss = nn.functional.mse_loss(self._net(batch), batch)
                loss.backward()
                optimiser.step()
                total += float(loss.detach()) * len(batch)
            train_loss.append(total / len(data))
            validation_loss.append(self.validation_loss_now())
            if validation_loss[-1] < best:
                best, stale = validation_loss[-1], 0
                best_state = {k: v.clone() for k, v in self._net.state_dict().items()}
            else:
                stale += 1
                if stale >= self.patience:
                    break
        assert best_state is not None
        self._net.load_state_dict(best_state)
        scores = self._reconstruction_error(fit_windows, last_only=True)
        self.threshold_ = float(np.quantile(scores, 1.0 - contamination))
        self._history = {
            "train_loss": train_loss,
            "validation_loss": validation_loss,
            "epochs_run": len(train_loss),
            "best_epoch": int(np.argmin(validation_loss)) + 1,
        }
        return self

    # -- fitting ------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁfit__mutmut_89(self, train: pd.DataFrame, validation: pd.DataFrame, contamination: float) -> Self:
        if not 0.0 < contamination < 0.5:
            raise ValueError("contamination must be in (0, 0.5)")
        if len(train) < self.window or len(validation) < self.window:
            raise ValueError("the training and validation rows must fill at least one window")
        values = train[self.columns].astype(float)
        self.center_ = values.median().to_numpy()
        spread = values.std(ddof=0).to_numpy()
        self.scale_ = np.where(spread > 0, spread, 1.0)
        torch.manual_seed(self.seed)
        torch.set_num_threads(self.threads)
        torch.use_deterministic_algorithms(True)
        rng = np.random.default_rng(self.seed)
        fit_windows, _ = self._windows(train)
        if len(fit_windows) > self.fit_rows:
            fit_windows = fit_windows[rng.choice(len(fit_windows), self.fit_rows, replace=False)]
        val_windows, _ = self._windows(validation)
        if len(val_windows) > self.validation_rows:
            keep = np.sort(rng.choice(len(val_windows), self.validation_rows, replace=False))
            val_windows = val_windows[keep]
        self._validation = torch.as_tensor(val_windows, dtype=torch.float32)
        self._net = _Network(len(self.columns), self.hidden)
        optimiser = torch.optim.Adam(self._net.parameters(), lr=self.learning_rate)
        data = torch.as_tensor(fit_windows, dtype=torch.float32)
        shuffler = torch.Generator().manual_seed(self.seed)
        train_loss: list[float] = []
        validation_loss: list[float] = []
        best, best_state, stale = np.inf, None, 0
        for _epoch in range(self.max_epochs):
            self._net.train()
            order = torch.randperm(None, generator=shuffler)
            total = 0.0
            for start in range(0, len(data), self.batch_size):
                batch = data[order[start : start + self.batch_size]]
                optimiser.zero_grad()
                loss = nn.functional.mse_loss(self._net(batch), batch)
                loss.backward()
                optimiser.step()
                total += float(loss.detach()) * len(batch)
            train_loss.append(total / len(data))
            validation_loss.append(self.validation_loss_now())
            if validation_loss[-1] < best:
                best, stale = validation_loss[-1], 0
                best_state = {k: v.clone() for k, v in self._net.state_dict().items()}
            else:
                stale += 1
                if stale >= self.patience:
                    break
        assert best_state is not None
        self._net.load_state_dict(best_state)
        scores = self._reconstruction_error(fit_windows, last_only=True)
        self.threshold_ = float(np.quantile(scores, 1.0 - contamination))
        self._history = {
            "train_loss": train_loss,
            "validation_loss": validation_loss,
            "epochs_run": len(train_loss),
            "best_epoch": int(np.argmin(validation_loss)) + 1,
        }
        return self

    # -- fitting ------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁfit__mutmut_90(self, train: pd.DataFrame, validation: pd.DataFrame, contamination: float) -> Self:
        if not 0.0 < contamination < 0.5:
            raise ValueError("contamination must be in (0, 0.5)")
        if len(train) < self.window or len(validation) < self.window:
            raise ValueError("the training and validation rows must fill at least one window")
        values = train[self.columns].astype(float)
        self.center_ = values.median().to_numpy()
        spread = values.std(ddof=0).to_numpy()
        self.scale_ = np.where(spread > 0, spread, 1.0)
        torch.manual_seed(self.seed)
        torch.set_num_threads(self.threads)
        torch.use_deterministic_algorithms(True)
        rng = np.random.default_rng(self.seed)
        fit_windows, _ = self._windows(train)
        if len(fit_windows) > self.fit_rows:
            fit_windows = fit_windows[rng.choice(len(fit_windows), self.fit_rows, replace=False)]
        val_windows, _ = self._windows(validation)
        if len(val_windows) > self.validation_rows:
            keep = np.sort(rng.choice(len(val_windows), self.validation_rows, replace=False))
            val_windows = val_windows[keep]
        self._validation = torch.as_tensor(val_windows, dtype=torch.float32)
        self._net = _Network(len(self.columns), self.hidden)
        optimiser = torch.optim.Adam(self._net.parameters(), lr=self.learning_rate)
        data = torch.as_tensor(fit_windows, dtype=torch.float32)
        shuffler = torch.Generator().manual_seed(self.seed)
        train_loss: list[float] = []
        validation_loss: list[float] = []
        best, best_state, stale = np.inf, None, 0
        for _epoch in range(self.max_epochs):
            self._net.train()
            order = torch.randperm(len(data), generator=None)
            total = 0.0
            for start in range(0, len(data), self.batch_size):
                batch = data[order[start : start + self.batch_size]]
                optimiser.zero_grad()
                loss = nn.functional.mse_loss(self._net(batch), batch)
                loss.backward()
                optimiser.step()
                total += float(loss.detach()) * len(batch)
            train_loss.append(total / len(data))
            validation_loss.append(self.validation_loss_now())
            if validation_loss[-1] < best:
                best, stale = validation_loss[-1], 0
                best_state = {k: v.clone() for k, v in self._net.state_dict().items()}
            else:
                stale += 1
                if stale >= self.patience:
                    break
        assert best_state is not None
        self._net.load_state_dict(best_state)
        scores = self._reconstruction_error(fit_windows, last_only=True)
        self.threshold_ = float(np.quantile(scores, 1.0 - contamination))
        self._history = {
            "train_loss": train_loss,
            "validation_loss": validation_loss,
            "epochs_run": len(train_loss),
            "best_epoch": int(np.argmin(validation_loss)) + 1,
        }
        return self

    # -- fitting ------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁfit__mutmut_91(self, train: pd.DataFrame, validation: pd.DataFrame, contamination: float) -> Self:
        if not 0.0 < contamination < 0.5:
            raise ValueError("contamination must be in (0, 0.5)")
        if len(train) < self.window or len(validation) < self.window:
            raise ValueError("the training and validation rows must fill at least one window")
        values = train[self.columns].astype(float)
        self.center_ = values.median().to_numpy()
        spread = values.std(ddof=0).to_numpy()
        self.scale_ = np.where(spread > 0, spread, 1.0)
        torch.manual_seed(self.seed)
        torch.set_num_threads(self.threads)
        torch.use_deterministic_algorithms(True)
        rng = np.random.default_rng(self.seed)
        fit_windows, _ = self._windows(train)
        if len(fit_windows) > self.fit_rows:
            fit_windows = fit_windows[rng.choice(len(fit_windows), self.fit_rows, replace=False)]
        val_windows, _ = self._windows(validation)
        if len(val_windows) > self.validation_rows:
            keep = np.sort(rng.choice(len(val_windows), self.validation_rows, replace=False))
            val_windows = val_windows[keep]
        self._validation = torch.as_tensor(val_windows, dtype=torch.float32)
        self._net = _Network(len(self.columns), self.hidden)
        optimiser = torch.optim.Adam(self._net.parameters(), lr=self.learning_rate)
        data = torch.as_tensor(fit_windows, dtype=torch.float32)
        shuffler = torch.Generator().manual_seed(self.seed)
        train_loss: list[float] = []
        validation_loss: list[float] = []
        best, best_state, stale = np.inf, None, 0
        for _epoch in range(self.max_epochs):
            self._net.train()
            order = torch.randperm(generator=shuffler)
            total = 0.0
            for start in range(0, len(data), self.batch_size):
                batch = data[order[start : start + self.batch_size]]
                optimiser.zero_grad()
                loss = nn.functional.mse_loss(self._net(batch), batch)
                loss.backward()
                optimiser.step()
                total += float(loss.detach()) * len(batch)
            train_loss.append(total / len(data))
            validation_loss.append(self.validation_loss_now())
            if validation_loss[-1] < best:
                best, stale = validation_loss[-1], 0
                best_state = {k: v.clone() for k, v in self._net.state_dict().items()}
            else:
                stale += 1
                if stale >= self.patience:
                    break
        assert best_state is not None
        self._net.load_state_dict(best_state)
        scores = self._reconstruction_error(fit_windows, last_only=True)
        self.threshold_ = float(np.quantile(scores, 1.0 - contamination))
        self._history = {
            "train_loss": train_loss,
            "validation_loss": validation_loss,
            "epochs_run": len(train_loss),
            "best_epoch": int(np.argmin(validation_loss)) + 1,
        }
        return self

    # -- fitting ------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁfit__mutmut_92(self, train: pd.DataFrame, validation: pd.DataFrame, contamination: float) -> Self:
        if not 0.0 < contamination < 0.5:
            raise ValueError("contamination must be in (0, 0.5)")
        if len(train) < self.window or len(validation) < self.window:
            raise ValueError("the training and validation rows must fill at least one window")
        values = train[self.columns].astype(float)
        self.center_ = values.median().to_numpy()
        spread = values.std(ddof=0).to_numpy()
        self.scale_ = np.where(spread > 0, spread, 1.0)
        torch.manual_seed(self.seed)
        torch.set_num_threads(self.threads)
        torch.use_deterministic_algorithms(True)
        rng = np.random.default_rng(self.seed)
        fit_windows, _ = self._windows(train)
        if len(fit_windows) > self.fit_rows:
            fit_windows = fit_windows[rng.choice(len(fit_windows), self.fit_rows, replace=False)]
        val_windows, _ = self._windows(validation)
        if len(val_windows) > self.validation_rows:
            keep = np.sort(rng.choice(len(val_windows), self.validation_rows, replace=False))
            val_windows = val_windows[keep]
        self._validation = torch.as_tensor(val_windows, dtype=torch.float32)
        self._net = _Network(len(self.columns), self.hidden)
        optimiser = torch.optim.Adam(self._net.parameters(), lr=self.learning_rate)
        data = torch.as_tensor(fit_windows, dtype=torch.float32)
        shuffler = torch.Generator().manual_seed(self.seed)
        train_loss: list[float] = []
        validation_loss: list[float] = []
        best, best_state, stale = np.inf, None, 0
        for _epoch in range(self.max_epochs):
            self._net.train()
            order = torch.randperm(len(data), )
            total = 0.0
            for start in range(0, len(data), self.batch_size):
                batch = data[order[start : start + self.batch_size]]
                optimiser.zero_grad()
                loss = nn.functional.mse_loss(self._net(batch), batch)
                loss.backward()
                optimiser.step()
                total += float(loss.detach()) * len(batch)
            train_loss.append(total / len(data))
            validation_loss.append(self.validation_loss_now())
            if validation_loss[-1] < best:
                best, stale = validation_loss[-1], 0
                best_state = {k: v.clone() for k, v in self._net.state_dict().items()}
            else:
                stale += 1
                if stale >= self.patience:
                    break
        assert best_state is not None
        self._net.load_state_dict(best_state)
        scores = self._reconstruction_error(fit_windows, last_only=True)
        self.threshold_ = float(np.quantile(scores, 1.0 - contamination))
        self._history = {
            "train_loss": train_loss,
            "validation_loss": validation_loss,
            "epochs_run": len(train_loss),
            "best_epoch": int(np.argmin(validation_loss)) + 1,
        }
        return self

    # -- fitting ------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁfit__mutmut_93(self, train: pd.DataFrame, validation: pd.DataFrame, contamination: float) -> Self:
        if not 0.0 < contamination < 0.5:
            raise ValueError("contamination must be in (0, 0.5)")
        if len(train) < self.window or len(validation) < self.window:
            raise ValueError("the training and validation rows must fill at least one window")
        values = train[self.columns].astype(float)
        self.center_ = values.median().to_numpy()
        spread = values.std(ddof=0).to_numpy()
        self.scale_ = np.where(spread > 0, spread, 1.0)
        torch.manual_seed(self.seed)
        torch.set_num_threads(self.threads)
        torch.use_deterministic_algorithms(True)
        rng = np.random.default_rng(self.seed)
        fit_windows, _ = self._windows(train)
        if len(fit_windows) > self.fit_rows:
            fit_windows = fit_windows[rng.choice(len(fit_windows), self.fit_rows, replace=False)]
        val_windows, _ = self._windows(validation)
        if len(val_windows) > self.validation_rows:
            keep = np.sort(rng.choice(len(val_windows), self.validation_rows, replace=False))
            val_windows = val_windows[keep]
        self._validation = torch.as_tensor(val_windows, dtype=torch.float32)
        self._net = _Network(len(self.columns), self.hidden)
        optimiser = torch.optim.Adam(self._net.parameters(), lr=self.learning_rate)
        data = torch.as_tensor(fit_windows, dtype=torch.float32)
        shuffler = torch.Generator().manual_seed(self.seed)
        train_loss: list[float] = []
        validation_loss: list[float] = []
        best, best_state, stale = np.inf, None, 0
        for _epoch in range(self.max_epochs):
            self._net.train()
            order = torch.randperm(len(data), generator=shuffler)
            total = None
            for start in range(0, len(data), self.batch_size):
                batch = data[order[start : start + self.batch_size]]
                optimiser.zero_grad()
                loss = nn.functional.mse_loss(self._net(batch), batch)
                loss.backward()
                optimiser.step()
                total += float(loss.detach()) * len(batch)
            train_loss.append(total / len(data))
            validation_loss.append(self.validation_loss_now())
            if validation_loss[-1] < best:
                best, stale = validation_loss[-1], 0
                best_state = {k: v.clone() for k, v in self._net.state_dict().items()}
            else:
                stale += 1
                if stale >= self.patience:
                    break
        assert best_state is not None
        self._net.load_state_dict(best_state)
        scores = self._reconstruction_error(fit_windows, last_only=True)
        self.threshold_ = float(np.quantile(scores, 1.0 - contamination))
        self._history = {
            "train_loss": train_loss,
            "validation_loss": validation_loss,
            "epochs_run": len(train_loss),
            "best_epoch": int(np.argmin(validation_loss)) + 1,
        }
        return self

    # -- fitting ------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁfit__mutmut_94(self, train: pd.DataFrame, validation: pd.DataFrame, contamination: float) -> Self:
        if not 0.0 < contamination < 0.5:
            raise ValueError("contamination must be in (0, 0.5)")
        if len(train) < self.window or len(validation) < self.window:
            raise ValueError("the training and validation rows must fill at least one window")
        values = train[self.columns].astype(float)
        self.center_ = values.median().to_numpy()
        spread = values.std(ddof=0).to_numpy()
        self.scale_ = np.where(spread > 0, spread, 1.0)
        torch.manual_seed(self.seed)
        torch.set_num_threads(self.threads)
        torch.use_deterministic_algorithms(True)
        rng = np.random.default_rng(self.seed)
        fit_windows, _ = self._windows(train)
        if len(fit_windows) > self.fit_rows:
            fit_windows = fit_windows[rng.choice(len(fit_windows), self.fit_rows, replace=False)]
        val_windows, _ = self._windows(validation)
        if len(val_windows) > self.validation_rows:
            keep = np.sort(rng.choice(len(val_windows), self.validation_rows, replace=False))
            val_windows = val_windows[keep]
        self._validation = torch.as_tensor(val_windows, dtype=torch.float32)
        self._net = _Network(len(self.columns), self.hidden)
        optimiser = torch.optim.Adam(self._net.parameters(), lr=self.learning_rate)
        data = torch.as_tensor(fit_windows, dtype=torch.float32)
        shuffler = torch.Generator().manual_seed(self.seed)
        train_loss: list[float] = []
        validation_loss: list[float] = []
        best, best_state, stale = np.inf, None, 0
        for _epoch in range(self.max_epochs):
            self._net.train()
            order = torch.randperm(len(data), generator=shuffler)
            total = 1.0
            for start in range(0, len(data), self.batch_size):
                batch = data[order[start : start + self.batch_size]]
                optimiser.zero_grad()
                loss = nn.functional.mse_loss(self._net(batch), batch)
                loss.backward()
                optimiser.step()
                total += float(loss.detach()) * len(batch)
            train_loss.append(total / len(data))
            validation_loss.append(self.validation_loss_now())
            if validation_loss[-1] < best:
                best, stale = validation_loss[-1], 0
                best_state = {k: v.clone() for k, v in self._net.state_dict().items()}
            else:
                stale += 1
                if stale >= self.patience:
                    break
        assert best_state is not None
        self._net.load_state_dict(best_state)
        scores = self._reconstruction_error(fit_windows, last_only=True)
        self.threshold_ = float(np.quantile(scores, 1.0 - contamination))
        self._history = {
            "train_loss": train_loss,
            "validation_loss": validation_loss,
            "epochs_run": len(train_loss),
            "best_epoch": int(np.argmin(validation_loss)) + 1,
        }
        return self

    # -- fitting ------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁfit__mutmut_95(self, train: pd.DataFrame, validation: pd.DataFrame, contamination: float) -> Self:
        if not 0.0 < contamination < 0.5:
            raise ValueError("contamination must be in (0, 0.5)")
        if len(train) < self.window or len(validation) < self.window:
            raise ValueError("the training and validation rows must fill at least one window")
        values = train[self.columns].astype(float)
        self.center_ = values.median().to_numpy()
        spread = values.std(ddof=0).to_numpy()
        self.scale_ = np.where(spread > 0, spread, 1.0)
        torch.manual_seed(self.seed)
        torch.set_num_threads(self.threads)
        torch.use_deterministic_algorithms(True)
        rng = np.random.default_rng(self.seed)
        fit_windows, _ = self._windows(train)
        if len(fit_windows) > self.fit_rows:
            fit_windows = fit_windows[rng.choice(len(fit_windows), self.fit_rows, replace=False)]
        val_windows, _ = self._windows(validation)
        if len(val_windows) > self.validation_rows:
            keep = np.sort(rng.choice(len(val_windows), self.validation_rows, replace=False))
            val_windows = val_windows[keep]
        self._validation = torch.as_tensor(val_windows, dtype=torch.float32)
        self._net = _Network(len(self.columns), self.hidden)
        optimiser = torch.optim.Adam(self._net.parameters(), lr=self.learning_rate)
        data = torch.as_tensor(fit_windows, dtype=torch.float32)
        shuffler = torch.Generator().manual_seed(self.seed)
        train_loss: list[float] = []
        validation_loss: list[float] = []
        best, best_state, stale = np.inf, None, 0
        for _epoch in range(self.max_epochs):
            self._net.train()
            order = torch.randperm(len(data), generator=shuffler)
            total = 0.0
            for start in range(None, len(data), self.batch_size):
                batch = data[order[start : start + self.batch_size]]
                optimiser.zero_grad()
                loss = nn.functional.mse_loss(self._net(batch), batch)
                loss.backward()
                optimiser.step()
                total += float(loss.detach()) * len(batch)
            train_loss.append(total / len(data))
            validation_loss.append(self.validation_loss_now())
            if validation_loss[-1] < best:
                best, stale = validation_loss[-1], 0
                best_state = {k: v.clone() for k, v in self._net.state_dict().items()}
            else:
                stale += 1
                if stale >= self.patience:
                    break
        assert best_state is not None
        self._net.load_state_dict(best_state)
        scores = self._reconstruction_error(fit_windows, last_only=True)
        self.threshold_ = float(np.quantile(scores, 1.0 - contamination))
        self._history = {
            "train_loss": train_loss,
            "validation_loss": validation_loss,
            "epochs_run": len(train_loss),
            "best_epoch": int(np.argmin(validation_loss)) + 1,
        }
        return self

    # -- fitting ------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁfit__mutmut_96(self, train: pd.DataFrame, validation: pd.DataFrame, contamination: float) -> Self:
        if not 0.0 < contamination < 0.5:
            raise ValueError("contamination must be in (0, 0.5)")
        if len(train) < self.window or len(validation) < self.window:
            raise ValueError("the training and validation rows must fill at least one window")
        values = train[self.columns].astype(float)
        self.center_ = values.median().to_numpy()
        spread = values.std(ddof=0).to_numpy()
        self.scale_ = np.where(spread > 0, spread, 1.0)
        torch.manual_seed(self.seed)
        torch.set_num_threads(self.threads)
        torch.use_deterministic_algorithms(True)
        rng = np.random.default_rng(self.seed)
        fit_windows, _ = self._windows(train)
        if len(fit_windows) > self.fit_rows:
            fit_windows = fit_windows[rng.choice(len(fit_windows), self.fit_rows, replace=False)]
        val_windows, _ = self._windows(validation)
        if len(val_windows) > self.validation_rows:
            keep = np.sort(rng.choice(len(val_windows), self.validation_rows, replace=False))
            val_windows = val_windows[keep]
        self._validation = torch.as_tensor(val_windows, dtype=torch.float32)
        self._net = _Network(len(self.columns), self.hidden)
        optimiser = torch.optim.Adam(self._net.parameters(), lr=self.learning_rate)
        data = torch.as_tensor(fit_windows, dtype=torch.float32)
        shuffler = torch.Generator().manual_seed(self.seed)
        train_loss: list[float] = []
        validation_loss: list[float] = []
        best, best_state, stale = np.inf, None, 0
        for _epoch in range(self.max_epochs):
            self._net.train()
            order = torch.randperm(len(data), generator=shuffler)
            total = 0.0
            for start in range(0, None, self.batch_size):
                batch = data[order[start : start + self.batch_size]]
                optimiser.zero_grad()
                loss = nn.functional.mse_loss(self._net(batch), batch)
                loss.backward()
                optimiser.step()
                total += float(loss.detach()) * len(batch)
            train_loss.append(total / len(data))
            validation_loss.append(self.validation_loss_now())
            if validation_loss[-1] < best:
                best, stale = validation_loss[-1], 0
                best_state = {k: v.clone() for k, v in self._net.state_dict().items()}
            else:
                stale += 1
                if stale >= self.patience:
                    break
        assert best_state is not None
        self._net.load_state_dict(best_state)
        scores = self._reconstruction_error(fit_windows, last_only=True)
        self.threshold_ = float(np.quantile(scores, 1.0 - contamination))
        self._history = {
            "train_loss": train_loss,
            "validation_loss": validation_loss,
            "epochs_run": len(train_loss),
            "best_epoch": int(np.argmin(validation_loss)) + 1,
        }
        return self

    # -- fitting ------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁfit__mutmut_97(self, train: pd.DataFrame, validation: pd.DataFrame, contamination: float) -> Self:
        if not 0.0 < contamination < 0.5:
            raise ValueError("contamination must be in (0, 0.5)")
        if len(train) < self.window or len(validation) < self.window:
            raise ValueError("the training and validation rows must fill at least one window")
        values = train[self.columns].astype(float)
        self.center_ = values.median().to_numpy()
        spread = values.std(ddof=0).to_numpy()
        self.scale_ = np.where(spread > 0, spread, 1.0)
        torch.manual_seed(self.seed)
        torch.set_num_threads(self.threads)
        torch.use_deterministic_algorithms(True)
        rng = np.random.default_rng(self.seed)
        fit_windows, _ = self._windows(train)
        if len(fit_windows) > self.fit_rows:
            fit_windows = fit_windows[rng.choice(len(fit_windows), self.fit_rows, replace=False)]
        val_windows, _ = self._windows(validation)
        if len(val_windows) > self.validation_rows:
            keep = np.sort(rng.choice(len(val_windows), self.validation_rows, replace=False))
            val_windows = val_windows[keep]
        self._validation = torch.as_tensor(val_windows, dtype=torch.float32)
        self._net = _Network(len(self.columns), self.hidden)
        optimiser = torch.optim.Adam(self._net.parameters(), lr=self.learning_rate)
        data = torch.as_tensor(fit_windows, dtype=torch.float32)
        shuffler = torch.Generator().manual_seed(self.seed)
        train_loss: list[float] = []
        validation_loss: list[float] = []
        best, best_state, stale = np.inf, None, 0
        for _epoch in range(self.max_epochs):
            self._net.train()
            order = torch.randperm(len(data), generator=shuffler)
            total = 0.0
            for start in range(0, len(data), None):
                batch = data[order[start : start + self.batch_size]]
                optimiser.zero_grad()
                loss = nn.functional.mse_loss(self._net(batch), batch)
                loss.backward()
                optimiser.step()
                total += float(loss.detach()) * len(batch)
            train_loss.append(total / len(data))
            validation_loss.append(self.validation_loss_now())
            if validation_loss[-1] < best:
                best, stale = validation_loss[-1], 0
                best_state = {k: v.clone() for k, v in self._net.state_dict().items()}
            else:
                stale += 1
                if stale >= self.patience:
                    break
        assert best_state is not None
        self._net.load_state_dict(best_state)
        scores = self._reconstruction_error(fit_windows, last_only=True)
        self.threshold_ = float(np.quantile(scores, 1.0 - contamination))
        self._history = {
            "train_loss": train_loss,
            "validation_loss": validation_loss,
            "epochs_run": len(train_loss),
            "best_epoch": int(np.argmin(validation_loss)) + 1,
        }
        return self

    # -- fitting ------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁfit__mutmut_98(self, train: pd.DataFrame, validation: pd.DataFrame, contamination: float) -> Self:
        if not 0.0 < contamination < 0.5:
            raise ValueError("contamination must be in (0, 0.5)")
        if len(train) < self.window or len(validation) < self.window:
            raise ValueError("the training and validation rows must fill at least one window")
        values = train[self.columns].astype(float)
        self.center_ = values.median().to_numpy()
        spread = values.std(ddof=0).to_numpy()
        self.scale_ = np.where(spread > 0, spread, 1.0)
        torch.manual_seed(self.seed)
        torch.set_num_threads(self.threads)
        torch.use_deterministic_algorithms(True)
        rng = np.random.default_rng(self.seed)
        fit_windows, _ = self._windows(train)
        if len(fit_windows) > self.fit_rows:
            fit_windows = fit_windows[rng.choice(len(fit_windows), self.fit_rows, replace=False)]
        val_windows, _ = self._windows(validation)
        if len(val_windows) > self.validation_rows:
            keep = np.sort(rng.choice(len(val_windows), self.validation_rows, replace=False))
            val_windows = val_windows[keep]
        self._validation = torch.as_tensor(val_windows, dtype=torch.float32)
        self._net = _Network(len(self.columns), self.hidden)
        optimiser = torch.optim.Adam(self._net.parameters(), lr=self.learning_rate)
        data = torch.as_tensor(fit_windows, dtype=torch.float32)
        shuffler = torch.Generator().manual_seed(self.seed)
        train_loss: list[float] = []
        validation_loss: list[float] = []
        best, best_state, stale = np.inf, None, 0
        for _epoch in range(self.max_epochs):
            self._net.train()
            order = torch.randperm(len(data), generator=shuffler)
            total = 0.0
            for start in range(len(data), self.batch_size):
                batch = data[order[start : start + self.batch_size]]
                optimiser.zero_grad()
                loss = nn.functional.mse_loss(self._net(batch), batch)
                loss.backward()
                optimiser.step()
                total += float(loss.detach()) * len(batch)
            train_loss.append(total / len(data))
            validation_loss.append(self.validation_loss_now())
            if validation_loss[-1] < best:
                best, stale = validation_loss[-1], 0
                best_state = {k: v.clone() for k, v in self._net.state_dict().items()}
            else:
                stale += 1
                if stale >= self.patience:
                    break
        assert best_state is not None
        self._net.load_state_dict(best_state)
        scores = self._reconstruction_error(fit_windows, last_only=True)
        self.threshold_ = float(np.quantile(scores, 1.0 - contamination))
        self._history = {
            "train_loss": train_loss,
            "validation_loss": validation_loss,
            "epochs_run": len(train_loss),
            "best_epoch": int(np.argmin(validation_loss)) + 1,
        }
        return self

    # -- fitting ------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁfit__mutmut_99(self, train: pd.DataFrame, validation: pd.DataFrame, contamination: float) -> Self:
        if not 0.0 < contamination < 0.5:
            raise ValueError("contamination must be in (0, 0.5)")
        if len(train) < self.window or len(validation) < self.window:
            raise ValueError("the training and validation rows must fill at least one window")
        values = train[self.columns].astype(float)
        self.center_ = values.median().to_numpy()
        spread = values.std(ddof=0).to_numpy()
        self.scale_ = np.where(spread > 0, spread, 1.0)
        torch.manual_seed(self.seed)
        torch.set_num_threads(self.threads)
        torch.use_deterministic_algorithms(True)
        rng = np.random.default_rng(self.seed)
        fit_windows, _ = self._windows(train)
        if len(fit_windows) > self.fit_rows:
            fit_windows = fit_windows[rng.choice(len(fit_windows), self.fit_rows, replace=False)]
        val_windows, _ = self._windows(validation)
        if len(val_windows) > self.validation_rows:
            keep = np.sort(rng.choice(len(val_windows), self.validation_rows, replace=False))
            val_windows = val_windows[keep]
        self._validation = torch.as_tensor(val_windows, dtype=torch.float32)
        self._net = _Network(len(self.columns), self.hidden)
        optimiser = torch.optim.Adam(self._net.parameters(), lr=self.learning_rate)
        data = torch.as_tensor(fit_windows, dtype=torch.float32)
        shuffler = torch.Generator().manual_seed(self.seed)
        train_loss: list[float] = []
        validation_loss: list[float] = []
        best, best_state, stale = np.inf, None, 0
        for _epoch in range(self.max_epochs):
            self._net.train()
            order = torch.randperm(len(data), generator=shuffler)
            total = 0.0
            for start in range(0, self.batch_size):
                batch = data[order[start : start + self.batch_size]]
                optimiser.zero_grad()
                loss = nn.functional.mse_loss(self._net(batch), batch)
                loss.backward()
                optimiser.step()
                total += float(loss.detach()) * len(batch)
            train_loss.append(total / len(data))
            validation_loss.append(self.validation_loss_now())
            if validation_loss[-1] < best:
                best, stale = validation_loss[-1], 0
                best_state = {k: v.clone() for k, v in self._net.state_dict().items()}
            else:
                stale += 1
                if stale >= self.patience:
                    break
        assert best_state is not None
        self._net.load_state_dict(best_state)
        scores = self._reconstruction_error(fit_windows, last_only=True)
        self.threshold_ = float(np.quantile(scores, 1.0 - contamination))
        self._history = {
            "train_loss": train_loss,
            "validation_loss": validation_loss,
            "epochs_run": len(train_loss),
            "best_epoch": int(np.argmin(validation_loss)) + 1,
        }
        return self

    # -- fitting ------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁfit__mutmut_100(self, train: pd.DataFrame, validation: pd.DataFrame, contamination: float) -> Self:
        if not 0.0 < contamination < 0.5:
            raise ValueError("contamination must be in (0, 0.5)")
        if len(train) < self.window or len(validation) < self.window:
            raise ValueError("the training and validation rows must fill at least one window")
        values = train[self.columns].astype(float)
        self.center_ = values.median().to_numpy()
        spread = values.std(ddof=0).to_numpy()
        self.scale_ = np.where(spread > 0, spread, 1.0)
        torch.manual_seed(self.seed)
        torch.set_num_threads(self.threads)
        torch.use_deterministic_algorithms(True)
        rng = np.random.default_rng(self.seed)
        fit_windows, _ = self._windows(train)
        if len(fit_windows) > self.fit_rows:
            fit_windows = fit_windows[rng.choice(len(fit_windows), self.fit_rows, replace=False)]
        val_windows, _ = self._windows(validation)
        if len(val_windows) > self.validation_rows:
            keep = np.sort(rng.choice(len(val_windows), self.validation_rows, replace=False))
            val_windows = val_windows[keep]
        self._validation = torch.as_tensor(val_windows, dtype=torch.float32)
        self._net = _Network(len(self.columns), self.hidden)
        optimiser = torch.optim.Adam(self._net.parameters(), lr=self.learning_rate)
        data = torch.as_tensor(fit_windows, dtype=torch.float32)
        shuffler = torch.Generator().manual_seed(self.seed)
        train_loss: list[float] = []
        validation_loss: list[float] = []
        best, best_state, stale = np.inf, None, 0
        for _epoch in range(self.max_epochs):
            self._net.train()
            order = torch.randperm(len(data), generator=shuffler)
            total = 0.0
            for start in range(0, len(data), ):
                batch = data[order[start : start + self.batch_size]]
                optimiser.zero_grad()
                loss = nn.functional.mse_loss(self._net(batch), batch)
                loss.backward()
                optimiser.step()
                total += float(loss.detach()) * len(batch)
            train_loss.append(total / len(data))
            validation_loss.append(self.validation_loss_now())
            if validation_loss[-1] < best:
                best, stale = validation_loss[-1], 0
                best_state = {k: v.clone() for k, v in self._net.state_dict().items()}
            else:
                stale += 1
                if stale >= self.patience:
                    break
        assert best_state is not None
        self._net.load_state_dict(best_state)
        scores = self._reconstruction_error(fit_windows, last_only=True)
        self.threshold_ = float(np.quantile(scores, 1.0 - contamination))
        self._history = {
            "train_loss": train_loss,
            "validation_loss": validation_loss,
            "epochs_run": len(train_loss),
            "best_epoch": int(np.argmin(validation_loss)) + 1,
        }
        return self

    # -- fitting ------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁfit__mutmut_101(self, train: pd.DataFrame, validation: pd.DataFrame, contamination: float) -> Self:
        if not 0.0 < contamination < 0.5:
            raise ValueError("contamination must be in (0, 0.5)")
        if len(train) < self.window or len(validation) < self.window:
            raise ValueError("the training and validation rows must fill at least one window")
        values = train[self.columns].astype(float)
        self.center_ = values.median().to_numpy()
        spread = values.std(ddof=0).to_numpy()
        self.scale_ = np.where(spread > 0, spread, 1.0)
        torch.manual_seed(self.seed)
        torch.set_num_threads(self.threads)
        torch.use_deterministic_algorithms(True)
        rng = np.random.default_rng(self.seed)
        fit_windows, _ = self._windows(train)
        if len(fit_windows) > self.fit_rows:
            fit_windows = fit_windows[rng.choice(len(fit_windows), self.fit_rows, replace=False)]
        val_windows, _ = self._windows(validation)
        if len(val_windows) > self.validation_rows:
            keep = np.sort(rng.choice(len(val_windows), self.validation_rows, replace=False))
            val_windows = val_windows[keep]
        self._validation = torch.as_tensor(val_windows, dtype=torch.float32)
        self._net = _Network(len(self.columns), self.hidden)
        optimiser = torch.optim.Adam(self._net.parameters(), lr=self.learning_rate)
        data = torch.as_tensor(fit_windows, dtype=torch.float32)
        shuffler = torch.Generator().manual_seed(self.seed)
        train_loss: list[float] = []
        validation_loss: list[float] = []
        best, best_state, stale = np.inf, None, 0
        for _epoch in range(self.max_epochs):
            self._net.train()
            order = torch.randperm(len(data), generator=shuffler)
            total = 0.0
            for start in range(1, len(data), self.batch_size):
                batch = data[order[start : start + self.batch_size]]
                optimiser.zero_grad()
                loss = nn.functional.mse_loss(self._net(batch), batch)
                loss.backward()
                optimiser.step()
                total += float(loss.detach()) * len(batch)
            train_loss.append(total / len(data))
            validation_loss.append(self.validation_loss_now())
            if validation_loss[-1] < best:
                best, stale = validation_loss[-1], 0
                best_state = {k: v.clone() for k, v in self._net.state_dict().items()}
            else:
                stale += 1
                if stale >= self.patience:
                    break
        assert best_state is not None
        self._net.load_state_dict(best_state)
        scores = self._reconstruction_error(fit_windows, last_only=True)
        self.threshold_ = float(np.quantile(scores, 1.0 - contamination))
        self._history = {
            "train_loss": train_loss,
            "validation_loss": validation_loss,
            "epochs_run": len(train_loss),
            "best_epoch": int(np.argmin(validation_loss)) + 1,
        }
        return self

    # -- fitting ------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁfit__mutmut_102(self, train: pd.DataFrame, validation: pd.DataFrame, contamination: float) -> Self:
        if not 0.0 < contamination < 0.5:
            raise ValueError("contamination must be in (0, 0.5)")
        if len(train) < self.window or len(validation) < self.window:
            raise ValueError("the training and validation rows must fill at least one window")
        values = train[self.columns].astype(float)
        self.center_ = values.median().to_numpy()
        spread = values.std(ddof=0).to_numpy()
        self.scale_ = np.where(spread > 0, spread, 1.0)
        torch.manual_seed(self.seed)
        torch.set_num_threads(self.threads)
        torch.use_deterministic_algorithms(True)
        rng = np.random.default_rng(self.seed)
        fit_windows, _ = self._windows(train)
        if len(fit_windows) > self.fit_rows:
            fit_windows = fit_windows[rng.choice(len(fit_windows), self.fit_rows, replace=False)]
        val_windows, _ = self._windows(validation)
        if len(val_windows) > self.validation_rows:
            keep = np.sort(rng.choice(len(val_windows), self.validation_rows, replace=False))
            val_windows = val_windows[keep]
        self._validation = torch.as_tensor(val_windows, dtype=torch.float32)
        self._net = _Network(len(self.columns), self.hidden)
        optimiser = torch.optim.Adam(self._net.parameters(), lr=self.learning_rate)
        data = torch.as_tensor(fit_windows, dtype=torch.float32)
        shuffler = torch.Generator().manual_seed(self.seed)
        train_loss: list[float] = []
        validation_loss: list[float] = []
        best, best_state, stale = np.inf, None, 0
        for _epoch in range(self.max_epochs):
            self._net.train()
            order = torch.randperm(len(data), generator=shuffler)
            total = 0.0
            for start in range(0, len(data), self.batch_size):
                batch = None
                optimiser.zero_grad()
                loss = nn.functional.mse_loss(self._net(batch), batch)
                loss.backward()
                optimiser.step()
                total += float(loss.detach()) * len(batch)
            train_loss.append(total / len(data))
            validation_loss.append(self.validation_loss_now())
            if validation_loss[-1] < best:
                best, stale = validation_loss[-1], 0
                best_state = {k: v.clone() for k, v in self._net.state_dict().items()}
            else:
                stale += 1
                if stale >= self.patience:
                    break
        assert best_state is not None
        self._net.load_state_dict(best_state)
        scores = self._reconstruction_error(fit_windows, last_only=True)
        self.threshold_ = float(np.quantile(scores, 1.0 - contamination))
        self._history = {
            "train_loss": train_loss,
            "validation_loss": validation_loss,
            "epochs_run": len(train_loss),
            "best_epoch": int(np.argmin(validation_loss)) + 1,
        }
        return self

    # -- fitting ------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁfit__mutmut_103(self, train: pd.DataFrame, validation: pd.DataFrame, contamination: float) -> Self:
        if not 0.0 < contamination < 0.5:
            raise ValueError("contamination must be in (0, 0.5)")
        if len(train) < self.window or len(validation) < self.window:
            raise ValueError("the training and validation rows must fill at least one window")
        values = train[self.columns].astype(float)
        self.center_ = values.median().to_numpy()
        spread = values.std(ddof=0).to_numpy()
        self.scale_ = np.where(spread > 0, spread, 1.0)
        torch.manual_seed(self.seed)
        torch.set_num_threads(self.threads)
        torch.use_deterministic_algorithms(True)
        rng = np.random.default_rng(self.seed)
        fit_windows, _ = self._windows(train)
        if len(fit_windows) > self.fit_rows:
            fit_windows = fit_windows[rng.choice(len(fit_windows), self.fit_rows, replace=False)]
        val_windows, _ = self._windows(validation)
        if len(val_windows) > self.validation_rows:
            keep = np.sort(rng.choice(len(val_windows), self.validation_rows, replace=False))
            val_windows = val_windows[keep]
        self._validation = torch.as_tensor(val_windows, dtype=torch.float32)
        self._net = _Network(len(self.columns), self.hidden)
        optimiser = torch.optim.Adam(self._net.parameters(), lr=self.learning_rate)
        data = torch.as_tensor(fit_windows, dtype=torch.float32)
        shuffler = torch.Generator().manual_seed(self.seed)
        train_loss: list[float] = []
        validation_loss: list[float] = []
        best, best_state, stale = np.inf, None, 0
        for _epoch in range(self.max_epochs):
            self._net.train()
            order = torch.randperm(len(data), generator=shuffler)
            total = 0.0
            for start in range(0, len(data), self.batch_size):
                batch = data[order[start : start - self.batch_size]]
                optimiser.zero_grad()
                loss = nn.functional.mse_loss(self._net(batch), batch)
                loss.backward()
                optimiser.step()
                total += float(loss.detach()) * len(batch)
            train_loss.append(total / len(data))
            validation_loss.append(self.validation_loss_now())
            if validation_loss[-1] < best:
                best, stale = validation_loss[-1], 0
                best_state = {k: v.clone() for k, v in self._net.state_dict().items()}
            else:
                stale += 1
                if stale >= self.patience:
                    break
        assert best_state is not None
        self._net.load_state_dict(best_state)
        scores = self._reconstruction_error(fit_windows, last_only=True)
        self.threshold_ = float(np.quantile(scores, 1.0 - contamination))
        self._history = {
            "train_loss": train_loss,
            "validation_loss": validation_loss,
            "epochs_run": len(train_loss),
            "best_epoch": int(np.argmin(validation_loss)) + 1,
        }
        return self

    # -- fitting ------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁfit__mutmut_104(self, train: pd.DataFrame, validation: pd.DataFrame, contamination: float) -> Self:
        if not 0.0 < contamination < 0.5:
            raise ValueError("contamination must be in (0, 0.5)")
        if len(train) < self.window or len(validation) < self.window:
            raise ValueError("the training and validation rows must fill at least one window")
        values = train[self.columns].astype(float)
        self.center_ = values.median().to_numpy()
        spread = values.std(ddof=0).to_numpy()
        self.scale_ = np.where(spread > 0, spread, 1.0)
        torch.manual_seed(self.seed)
        torch.set_num_threads(self.threads)
        torch.use_deterministic_algorithms(True)
        rng = np.random.default_rng(self.seed)
        fit_windows, _ = self._windows(train)
        if len(fit_windows) > self.fit_rows:
            fit_windows = fit_windows[rng.choice(len(fit_windows), self.fit_rows, replace=False)]
        val_windows, _ = self._windows(validation)
        if len(val_windows) > self.validation_rows:
            keep = np.sort(rng.choice(len(val_windows), self.validation_rows, replace=False))
            val_windows = val_windows[keep]
        self._validation = torch.as_tensor(val_windows, dtype=torch.float32)
        self._net = _Network(len(self.columns), self.hidden)
        optimiser = torch.optim.Adam(self._net.parameters(), lr=self.learning_rate)
        data = torch.as_tensor(fit_windows, dtype=torch.float32)
        shuffler = torch.Generator().manual_seed(self.seed)
        train_loss: list[float] = []
        validation_loss: list[float] = []
        best, best_state, stale = np.inf, None, 0
        for _epoch in range(self.max_epochs):
            self._net.train()
            order = torch.randperm(len(data), generator=shuffler)
            total = 0.0
            for start in range(0, len(data), self.batch_size):
                batch = data[order[start : start + self.batch_size]]
                optimiser.zero_grad()
                loss = None
                loss.backward()
                optimiser.step()
                total += float(loss.detach()) * len(batch)
            train_loss.append(total / len(data))
            validation_loss.append(self.validation_loss_now())
            if validation_loss[-1] < best:
                best, stale = validation_loss[-1], 0
                best_state = {k: v.clone() for k, v in self._net.state_dict().items()}
            else:
                stale += 1
                if stale >= self.patience:
                    break
        assert best_state is not None
        self._net.load_state_dict(best_state)
        scores = self._reconstruction_error(fit_windows, last_only=True)
        self.threshold_ = float(np.quantile(scores, 1.0 - contamination))
        self._history = {
            "train_loss": train_loss,
            "validation_loss": validation_loss,
            "epochs_run": len(train_loss),
            "best_epoch": int(np.argmin(validation_loss)) + 1,
        }
        return self

    # -- fitting ------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁfit__mutmut_105(self, train: pd.DataFrame, validation: pd.DataFrame, contamination: float) -> Self:
        if not 0.0 < contamination < 0.5:
            raise ValueError("contamination must be in (0, 0.5)")
        if len(train) < self.window or len(validation) < self.window:
            raise ValueError("the training and validation rows must fill at least one window")
        values = train[self.columns].astype(float)
        self.center_ = values.median().to_numpy()
        spread = values.std(ddof=0).to_numpy()
        self.scale_ = np.where(spread > 0, spread, 1.0)
        torch.manual_seed(self.seed)
        torch.set_num_threads(self.threads)
        torch.use_deterministic_algorithms(True)
        rng = np.random.default_rng(self.seed)
        fit_windows, _ = self._windows(train)
        if len(fit_windows) > self.fit_rows:
            fit_windows = fit_windows[rng.choice(len(fit_windows), self.fit_rows, replace=False)]
        val_windows, _ = self._windows(validation)
        if len(val_windows) > self.validation_rows:
            keep = np.sort(rng.choice(len(val_windows), self.validation_rows, replace=False))
            val_windows = val_windows[keep]
        self._validation = torch.as_tensor(val_windows, dtype=torch.float32)
        self._net = _Network(len(self.columns), self.hidden)
        optimiser = torch.optim.Adam(self._net.parameters(), lr=self.learning_rate)
        data = torch.as_tensor(fit_windows, dtype=torch.float32)
        shuffler = torch.Generator().manual_seed(self.seed)
        train_loss: list[float] = []
        validation_loss: list[float] = []
        best, best_state, stale = np.inf, None, 0
        for _epoch in range(self.max_epochs):
            self._net.train()
            order = torch.randperm(len(data), generator=shuffler)
            total = 0.0
            for start in range(0, len(data), self.batch_size):
                batch = data[order[start : start + self.batch_size]]
                optimiser.zero_grad()
                loss = nn.functional.mse_loss(None, batch)
                loss.backward()
                optimiser.step()
                total += float(loss.detach()) * len(batch)
            train_loss.append(total / len(data))
            validation_loss.append(self.validation_loss_now())
            if validation_loss[-1] < best:
                best, stale = validation_loss[-1], 0
                best_state = {k: v.clone() for k, v in self._net.state_dict().items()}
            else:
                stale += 1
                if stale >= self.patience:
                    break
        assert best_state is not None
        self._net.load_state_dict(best_state)
        scores = self._reconstruction_error(fit_windows, last_only=True)
        self.threshold_ = float(np.quantile(scores, 1.0 - contamination))
        self._history = {
            "train_loss": train_loss,
            "validation_loss": validation_loss,
            "epochs_run": len(train_loss),
            "best_epoch": int(np.argmin(validation_loss)) + 1,
        }
        return self

    # -- fitting ------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁfit__mutmut_106(self, train: pd.DataFrame, validation: pd.DataFrame, contamination: float) -> Self:
        if not 0.0 < contamination < 0.5:
            raise ValueError("contamination must be in (0, 0.5)")
        if len(train) < self.window or len(validation) < self.window:
            raise ValueError("the training and validation rows must fill at least one window")
        values = train[self.columns].astype(float)
        self.center_ = values.median().to_numpy()
        spread = values.std(ddof=0).to_numpy()
        self.scale_ = np.where(spread > 0, spread, 1.0)
        torch.manual_seed(self.seed)
        torch.set_num_threads(self.threads)
        torch.use_deterministic_algorithms(True)
        rng = np.random.default_rng(self.seed)
        fit_windows, _ = self._windows(train)
        if len(fit_windows) > self.fit_rows:
            fit_windows = fit_windows[rng.choice(len(fit_windows), self.fit_rows, replace=False)]
        val_windows, _ = self._windows(validation)
        if len(val_windows) > self.validation_rows:
            keep = np.sort(rng.choice(len(val_windows), self.validation_rows, replace=False))
            val_windows = val_windows[keep]
        self._validation = torch.as_tensor(val_windows, dtype=torch.float32)
        self._net = _Network(len(self.columns), self.hidden)
        optimiser = torch.optim.Adam(self._net.parameters(), lr=self.learning_rate)
        data = torch.as_tensor(fit_windows, dtype=torch.float32)
        shuffler = torch.Generator().manual_seed(self.seed)
        train_loss: list[float] = []
        validation_loss: list[float] = []
        best, best_state, stale = np.inf, None, 0
        for _epoch in range(self.max_epochs):
            self._net.train()
            order = torch.randperm(len(data), generator=shuffler)
            total = 0.0
            for start in range(0, len(data), self.batch_size):
                batch = data[order[start : start + self.batch_size]]
                optimiser.zero_grad()
                loss = nn.functional.mse_loss(self._net(batch), None)
                loss.backward()
                optimiser.step()
                total += float(loss.detach()) * len(batch)
            train_loss.append(total / len(data))
            validation_loss.append(self.validation_loss_now())
            if validation_loss[-1] < best:
                best, stale = validation_loss[-1], 0
                best_state = {k: v.clone() for k, v in self._net.state_dict().items()}
            else:
                stale += 1
                if stale >= self.patience:
                    break
        assert best_state is not None
        self._net.load_state_dict(best_state)
        scores = self._reconstruction_error(fit_windows, last_only=True)
        self.threshold_ = float(np.quantile(scores, 1.0 - contamination))
        self._history = {
            "train_loss": train_loss,
            "validation_loss": validation_loss,
            "epochs_run": len(train_loss),
            "best_epoch": int(np.argmin(validation_loss)) + 1,
        }
        return self

    # -- fitting ------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁfit__mutmut_107(self, train: pd.DataFrame, validation: pd.DataFrame, contamination: float) -> Self:
        if not 0.0 < contamination < 0.5:
            raise ValueError("contamination must be in (0, 0.5)")
        if len(train) < self.window or len(validation) < self.window:
            raise ValueError("the training and validation rows must fill at least one window")
        values = train[self.columns].astype(float)
        self.center_ = values.median().to_numpy()
        spread = values.std(ddof=0).to_numpy()
        self.scale_ = np.where(spread > 0, spread, 1.0)
        torch.manual_seed(self.seed)
        torch.set_num_threads(self.threads)
        torch.use_deterministic_algorithms(True)
        rng = np.random.default_rng(self.seed)
        fit_windows, _ = self._windows(train)
        if len(fit_windows) > self.fit_rows:
            fit_windows = fit_windows[rng.choice(len(fit_windows), self.fit_rows, replace=False)]
        val_windows, _ = self._windows(validation)
        if len(val_windows) > self.validation_rows:
            keep = np.sort(rng.choice(len(val_windows), self.validation_rows, replace=False))
            val_windows = val_windows[keep]
        self._validation = torch.as_tensor(val_windows, dtype=torch.float32)
        self._net = _Network(len(self.columns), self.hidden)
        optimiser = torch.optim.Adam(self._net.parameters(), lr=self.learning_rate)
        data = torch.as_tensor(fit_windows, dtype=torch.float32)
        shuffler = torch.Generator().manual_seed(self.seed)
        train_loss: list[float] = []
        validation_loss: list[float] = []
        best, best_state, stale = np.inf, None, 0
        for _epoch in range(self.max_epochs):
            self._net.train()
            order = torch.randperm(len(data), generator=shuffler)
            total = 0.0
            for start in range(0, len(data), self.batch_size):
                batch = data[order[start : start + self.batch_size]]
                optimiser.zero_grad()
                loss = nn.functional.mse_loss(batch)
                loss.backward()
                optimiser.step()
                total += float(loss.detach()) * len(batch)
            train_loss.append(total / len(data))
            validation_loss.append(self.validation_loss_now())
            if validation_loss[-1] < best:
                best, stale = validation_loss[-1], 0
                best_state = {k: v.clone() for k, v in self._net.state_dict().items()}
            else:
                stale += 1
                if stale >= self.patience:
                    break
        assert best_state is not None
        self._net.load_state_dict(best_state)
        scores = self._reconstruction_error(fit_windows, last_only=True)
        self.threshold_ = float(np.quantile(scores, 1.0 - contamination))
        self._history = {
            "train_loss": train_loss,
            "validation_loss": validation_loss,
            "epochs_run": len(train_loss),
            "best_epoch": int(np.argmin(validation_loss)) + 1,
        }
        return self

    # -- fitting ------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁfit__mutmut_108(self, train: pd.DataFrame, validation: pd.DataFrame, contamination: float) -> Self:
        if not 0.0 < contamination < 0.5:
            raise ValueError("contamination must be in (0, 0.5)")
        if len(train) < self.window or len(validation) < self.window:
            raise ValueError("the training and validation rows must fill at least one window")
        values = train[self.columns].astype(float)
        self.center_ = values.median().to_numpy()
        spread = values.std(ddof=0).to_numpy()
        self.scale_ = np.where(spread > 0, spread, 1.0)
        torch.manual_seed(self.seed)
        torch.set_num_threads(self.threads)
        torch.use_deterministic_algorithms(True)
        rng = np.random.default_rng(self.seed)
        fit_windows, _ = self._windows(train)
        if len(fit_windows) > self.fit_rows:
            fit_windows = fit_windows[rng.choice(len(fit_windows), self.fit_rows, replace=False)]
        val_windows, _ = self._windows(validation)
        if len(val_windows) > self.validation_rows:
            keep = np.sort(rng.choice(len(val_windows), self.validation_rows, replace=False))
            val_windows = val_windows[keep]
        self._validation = torch.as_tensor(val_windows, dtype=torch.float32)
        self._net = _Network(len(self.columns), self.hidden)
        optimiser = torch.optim.Adam(self._net.parameters(), lr=self.learning_rate)
        data = torch.as_tensor(fit_windows, dtype=torch.float32)
        shuffler = torch.Generator().manual_seed(self.seed)
        train_loss: list[float] = []
        validation_loss: list[float] = []
        best, best_state, stale = np.inf, None, 0
        for _epoch in range(self.max_epochs):
            self._net.train()
            order = torch.randperm(len(data), generator=shuffler)
            total = 0.0
            for start in range(0, len(data), self.batch_size):
                batch = data[order[start : start + self.batch_size]]
                optimiser.zero_grad()
                loss = nn.functional.mse_loss(self._net(batch), )
                loss.backward()
                optimiser.step()
                total += float(loss.detach()) * len(batch)
            train_loss.append(total / len(data))
            validation_loss.append(self.validation_loss_now())
            if validation_loss[-1] < best:
                best, stale = validation_loss[-1], 0
                best_state = {k: v.clone() for k, v in self._net.state_dict().items()}
            else:
                stale += 1
                if stale >= self.patience:
                    break
        assert best_state is not None
        self._net.load_state_dict(best_state)
        scores = self._reconstruction_error(fit_windows, last_only=True)
        self.threshold_ = float(np.quantile(scores, 1.0 - contamination))
        self._history = {
            "train_loss": train_loss,
            "validation_loss": validation_loss,
            "epochs_run": len(train_loss),
            "best_epoch": int(np.argmin(validation_loss)) + 1,
        }
        return self

    # -- fitting ------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁfit__mutmut_109(self, train: pd.DataFrame, validation: pd.DataFrame, contamination: float) -> Self:
        if not 0.0 < contamination < 0.5:
            raise ValueError("contamination must be in (0, 0.5)")
        if len(train) < self.window or len(validation) < self.window:
            raise ValueError("the training and validation rows must fill at least one window")
        values = train[self.columns].astype(float)
        self.center_ = values.median().to_numpy()
        spread = values.std(ddof=0).to_numpy()
        self.scale_ = np.where(spread > 0, spread, 1.0)
        torch.manual_seed(self.seed)
        torch.set_num_threads(self.threads)
        torch.use_deterministic_algorithms(True)
        rng = np.random.default_rng(self.seed)
        fit_windows, _ = self._windows(train)
        if len(fit_windows) > self.fit_rows:
            fit_windows = fit_windows[rng.choice(len(fit_windows), self.fit_rows, replace=False)]
        val_windows, _ = self._windows(validation)
        if len(val_windows) > self.validation_rows:
            keep = np.sort(rng.choice(len(val_windows), self.validation_rows, replace=False))
            val_windows = val_windows[keep]
        self._validation = torch.as_tensor(val_windows, dtype=torch.float32)
        self._net = _Network(len(self.columns), self.hidden)
        optimiser = torch.optim.Adam(self._net.parameters(), lr=self.learning_rate)
        data = torch.as_tensor(fit_windows, dtype=torch.float32)
        shuffler = torch.Generator().manual_seed(self.seed)
        train_loss: list[float] = []
        validation_loss: list[float] = []
        best, best_state, stale = np.inf, None, 0
        for _epoch in range(self.max_epochs):
            self._net.train()
            order = torch.randperm(len(data), generator=shuffler)
            total = 0.0
            for start in range(0, len(data), self.batch_size):
                batch = data[order[start : start + self.batch_size]]
                optimiser.zero_grad()
                loss = nn.functional.mse_loss(self._net(None), batch)
                loss.backward()
                optimiser.step()
                total += float(loss.detach()) * len(batch)
            train_loss.append(total / len(data))
            validation_loss.append(self.validation_loss_now())
            if validation_loss[-1] < best:
                best, stale = validation_loss[-1], 0
                best_state = {k: v.clone() for k, v in self._net.state_dict().items()}
            else:
                stale += 1
                if stale >= self.patience:
                    break
        assert best_state is not None
        self._net.load_state_dict(best_state)
        scores = self._reconstruction_error(fit_windows, last_only=True)
        self.threshold_ = float(np.quantile(scores, 1.0 - contamination))
        self._history = {
            "train_loss": train_loss,
            "validation_loss": validation_loss,
            "epochs_run": len(train_loss),
            "best_epoch": int(np.argmin(validation_loss)) + 1,
        }
        return self

    # -- fitting ------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁfit__mutmut_110(self, train: pd.DataFrame, validation: pd.DataFrame, contamination: float) -> Self:
        if not 0.0 < contamination < 0.5:
            raise ValueError("contamination must be in (0, 0.5)")
        if len(train) < self.window or len(validation) < self.window:
            raise ValueError("the training and validation rows must fill at least one window")
        values = train[self.columns].astype(float)
        self.center_ = values.median().to_numpy()
        spread = values.std(ddof=0).to_numpy()
        self.scale_ = np.where(spread > 0, spread, 1.0)
        torch.manual_seed(self.seed)
        torch.set_num_threads(self.threads)
        torch.use_deterministic_algorithms(True)
        rng = np.random.default_rng(self.seed)
        fit_windows, _ = self._windows(train)
        if len(fit_windows) > self.fit_rows:
            fit_windows = fit_windows[rng.choice(len(fit_windows), self.fit_rows, replace=False)]
        val_windows, _ = self._windows(validation)
        if len(val_windows) > self.validation_rows:
            keep = np.sort(rng.choice(len(val_windows), self.validation_rows, replace=False))
            val_windows = val_windows[keep]
        self._validation = torch.as_tensor(val_windows, dtype=torch.float32)
        self._net = _Network(len(self.columns), self.hidden)
        optimiser = torch.optim.Adam(self._net.parameters(), lr=self.learning_rate)
        data = torch.as_tensor(fit_windows, dtype=torch.float32)
        shuffler = torch.Generator().manual_seed(self.seed)
        train_loss: list[float] = []
        validation_loss: list[float] = []
        best, best_state, stale = np.inf, None, 0
        for _epoch in range(self.max_epochs):
            self._net.train()
            order = torch.randperm(len(data), generator=shuffler)
            total = 0.0
            for start in range(0, len(data), self.batch_size):
                batch = data[order[start : start + self.batch_size]]
                optimiser.zero_grad()
                loss = nn.functional.mse_loss(self._net(batch), batch)
                loss.backward()
                optimiser.step()
                total = float(loss.detach()) * len(batch)
            train_loss.append(total / len(data))
            validation_loss.append(self.validation_loss_now())
            if validation_loss[-1] < best:
                best, stale = validation_loss[-1], 0
                best_state = {k: v.clone() for k, v in self._net.state_dict().items()}
            else:
                stale += 1
                if stale >= self.patience:
                    break
        assert best_state is not None
        self._net.load_state_dict(best_state)
        scores = self._reconstruction_error(fit_windows, last_only=True)
        self.threshold_ = float(np.quantile(scores, 1.0 - contamination))
        self._history = {
            "train_loss": train_loss,
            "validation_loss": validation_loss,
            "epochs_run": len(train_loss),
            "best_epoch": int(np.argmin(validation_loss)) + 1,
        }
        return self

    # -- fitting ------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁfit__mutmut_111(self, train: pd.DataFrame, validation: pd.DataFrame, contamination: float) -> Self:
        if not 0.0 < contamination < 0.5:
            raise ValueError("contamination must be in (0, 0.5)")
        if len(train) < self.window or len(validation) < self.window:
            raise ValueError("the training and validation rows must fill at least one window")
        values = train[self.columns].astype(float)
        self.center_ = values.median().to_numpy()
        spread = values.std(ddof=0).to_numpy()
        self.scale_ = np.where(spread > 0, spread, 1.0)
        torch.manual_seed(self.seed)
        torch.set_num_threads(self.threads)
        torch.use_deterministic_algorithms(True)
        rng = np.random.default_rng(self.seed)
        fit_windows, _ = self._windows(train)
        if len(fit_windows) > self.fit_rows:
            fit_windows = fit_windows[rng.choice(len(fit_windows), self.fit_rows, replace=False)]
        val_windows, _ = self._windows(validation)
        if len(val_windows) > self.validation_rows:
            keep = np.sort(rng.choice(len(val_windows), self.validation_rows, replace=False))
            val_windows = val_windows[keep]
        self._validation = torch.as_tensor(val_windows, dtype=torch.float32)
        self._net = _Network(len(self.columns), self.hidden)
        optimiser = torch.optim.Adam(self._net.parameters(), lr=self.learning_rate)
        data = torch.as_tensor(fit_windows, dtype=torch.float32)
        shuffler = torch.Generator().manual_seed(self.seed)
        train_loss: list[float] = []
        validation_loss: list[float] = []
        best, best_state, stale = np.inf, None, 0
        for _epoch in range(self.max_epochs):
            self._net.train()
            order = torch.randperm(len(data), generator=shuffler)
            total = 0.0
            for start in range(0, len(data), self.batch_size):
                batch = data[order[start : start + self.batch_size]]
                optimiser.zero_grad()
                loss = nn.functional.mse_loss(self._net(batch), batch)
                loss.backward()
                optimiser.step()
                total -= float(loss.detach()) * len(batch)
            train_loss.append(total / len(data))
            validation_loss.append(self.validation_loss_now())
            if validation_loss[-1] < best:
                best, stale = validation_loss[-1], 0
                best_state = {k: v.clone() for k, v in self._net.state_dict().items()}
            else:
                stale += 1
                if stale >= self.patience:
                    break
        assert best_state is not None
        self._net.load_state_dict(best_state)
        scores = self._reconstruction_error(fit_windows, last_only=True)
        self.threshold_ = float(np.quantile(scores, 1.0 - contamination))
        self._history = {
            "train_loss": train_loss,
            "validation_loss": validation_loss,
            "epochs_run": len(train_loss),
            "best_epoch": int(np.argmin(validation_loss)) + 1,
        }
        return self

    # -- fitting ------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁfit__mutmut_112(self, train: pd.DataFrame, validation: pd.DataFrame, contamination: float) -> Self:
        if not 0.0 < contamination < 0.5:
            raise ValueError("contamination must be in (0, 0.5)")
        if len(train) < self.window or len(validation) < self.window:
            raise ValueError("the training and validation rows must fill at least one window")
        values = train[self.columns].astype(float)
        self.center_ = values.median().to_numpy()
        spread = values.std(ddof=0).to_numpy()
        self.scale_ = np.where(spread > 0, spread, 1.0)
        torch.manual_seed(self.seed)
        torch.set_num_threads(self.threads)
        torch.use_deterministic_algorithms(True)
        rng = np.random.default_rng(self.seed)
        fit_windows, _ = self._windows(train)
        if len(fit_windows) > self.fit_rows:
            fit_windows = fit_windows[rng.choice(len(fit_windows), self.fit_rows, replace=False)]
        val_windows, _ = self._windows(validation)
        if len(val_windows) > self.validation_rows:
            keep = np.sort(rng.choice(len(val_windows), self.validation_rows, replace=False))
            val_windows = val_windows[keep]
        self._validation = torch.as_tensor(val_windows, dtype=torch.float32)
        self._net = _Network(len(self.columns), self.hidden)
        optimiser = torch.optim.Adam(self._net.parameters(), lr=self.learning_rate)
        data = torch.as_tensor(fit_windows, dtype=torch.float32)
        shuffler = torch.Generator().manual_seed(self.seed)
        train_loss: list[float] = []
        validation_loss: list[float] = []
        best, best_state, stale = np.inf, None, 0
        for _epoch in range(self.max_epochs):
            self._net.train()
            order = torch.randperm(len(data), generator=shuffler)
            total = 0.0
            for start in range(0, len(data), self.batch_size):
                batch = data[order[start : start + self.batch_size]]
                optimiser.zero_grad()
                loss = nn.functional.mse_loss(self._net(batch), batch)
                loss.backward()
                optimiser.step()
                total += float(loss.detach()) / len(batch)
            train_loss.append(total / len(data))
            validation_loss.append(self.validation_loss_now())
            if validation_loss[-1] < best:
                best, stale = validation_loss[-1], 0
                best_state = {k: v.clone() for k, v in self._net.state_dict().items()}
            else:
                stale += 1
                if stale >= self.patience:
                    break
        assert best_state is not None
        self._net.load_state_dict(best_state)
        scores = self._reconstruction_error(fit_windows, last_only=True)
        self.threshold_ = float(np.quantile(scores, 1.0 - contamination))
        self._history = {
            "train_loss": train_loss,
            "validation_loss": validation_loss,
            "epochs_run": len(train_loss),
            "best_epoch": int(np.argmin(validation_loss)) + 1,
        }
        return self

    # -- fitting ------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁfit__mutmut_113(self, train: pd.DataFrame, validation: pd.DataFrame, contamination: float) -> Self:
        if not 0.0 < contamination < 0.5:
            raise ValueError("contamination must be in (0, 0.5)")
        if len(train) < self.window or len(validation) < self.window:
            raise ValueError("the training and validation rows must fill at least one window")
        values = train[self.columns].astype(float)
        self.center_ = values.median().to_numpy()
        spread = values.std(ddof=0).to_numpy()
        self.scale_ = np.where(spread > 0, spread, 1.0)
        torch.manual_seed(self.seed)
        torch.set_num_threads(self.threads)
        torch.use_deterministic_algorithms(True)
        rng = np.random.default_rng(self.seed)
        fit_windows, _ = self._windows(train)
        if len(fit_windows) > self.fit_rows:
            fit_windows = fit_windows[rng.choice(len(fit_windows), self.fit_rows, replace=False)]
        val_windows, _ = self._windows(validation)
        if len(val_windows) > self.validation_rows:
            keep = np.sort(rng.choice(len(val_windows), self.validation_rows, replace=False))
            val_windows = val_windows[keep]
        self._validation = torch.as_tensor(val_windows, dtype=torch.float32)
        self._net = _Network(len(self.columns), self.hidden)
        optimiser = torch.optim.Adam(self._net.parameters(), lr=self.learning_rate)
        data = torch.as_tensor(fit_windows, dtype=torch.float32)
        shuffler = torch.Generator().manual_seed(self.seed)
        train_loss: list[float] = []
        validation_loss: list[float] = []
        best, best_state, stale = np.inf, None, 0
        for _epoch in range(self.max_epochs):
            self._net.train()
            order = torch.randperm(len(data), generator=shuffler)
            total = 0.0
            for start in range(0, len(data), self.batch_size):
                batch = data[order[start : start + self.batch_size]]
                optimiser.zero_grad()
                loss = nn.functional.mse_loss(self._net(batch), batch)
                loss.backward()
                optimiser.step()
                total += float(None) * len(batch)
            train_loss.append(total / len(data))
            validation_loss.append(self.validation_loss_now())
            if validation_loss[-1] < best:
                best, stale = validation_loss[-1], 0
                best_state = {k: v.clone() for k, v in self._net.state_dict().items()}
            else:
                stale += 1
                if stale >= self.patience:
                    break
        assert best_state is not None
        self._net.load_state_dict(best_state)
        scores = self._reconstruction_error(fit_windows, last_only=True)
        self.threshold_ = float(np.quantile(scores, 1.0 - contamination))
        self._history = {
            "train_loss": train_loss,
            "validation_loss": validation_loss,
            "epochs_run": len(train_loss),
            "best_epoch": int(np.argmin(validation_loss)) + 1,
        }
        return self

    # -- fitting ------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁfit__mutmut_114(self, train: pd.DataFrame, validation: pd.DataFrame, contamination: float) -> Self:
        if not 0.0 < contamination < 0.5:
            raise ValueError("contamination must be in (0, 0.5)")
        if len(train) < self.window or len(validation) < self.window:
            raise ValueError("the training and validation rows must fill at least one window")
        values = train[self.columns].astype(float)
        self.center_ = values.median().to_numpy()
        spread = values.std(ddof=0).to_numpy()
        self.scale_ = np.where(spread > 0, spread, 1.0)
        torch.manual_seed(self.seed)
        torch.set_num_threads(self.threads)
        torch.use_deterministic_algorithms(True)
        rng = np.random.default_rng(self.seed)
        fit_windows, _ = self._windows(train)
        if len(fit_windows) > self.fit_rows:
            fit_windows = fit_windows[rng.choice(len(fit_windows), self.fit_rows, replace=False)]
        val_windows, _ = self._windows(validation)
        if len(val_windows) > self.validation_rows:
            keep = np.sort(rng.choice(len(val_windows), self.validation_rows, replace=False))
            val_windows = val_windows[keep]
        self._validation = torch.as_tensor(val_windows, dtype=torch.float32)
        self._net = _Network(len(self.columns), self.hidden)
        optimiser = torch.optim.Adam(self._net.parameters(), lr=self.learning_rate)
        data = torch.as_tensor(fit_windows, dtype=torch.float32)
        shuffler = torch.Generator().manual_seed(self.seed)
        train_loss: list[float] = []
        validation_loss: list[float] = []
        best, best_state, stale = np.inf, None, 0
        for _epoch in range(self.max_epochs):
            self._net.train()
            order = torch.randperm(len(data), generator=shuffler)
            total = 0.0
            for start in range(0, len(data), self.batch_size):
                batch = data[order[start : start + self.batch_size]]
                optimiser.zero_grad()
                loss = nn.functional.mse_loss(self._net(batch), batch)
                loss.backward()
                optimiser.step()
                total += float(loss.detach()) * len(batch)
            train_loss.append(None)
            validation_loss.append(self.validation_loss_now())
            if validation_loss[-1] < best:
                best, stale = validation_loss[-1], 0
                best_state = {k: v.clone() for k, v in self._net.state_dict().items()}
            else:
                stale += 1
                if stale >= self.patience:
                    break
        assert best_state is not None
        self._net.load_state_dict(best_state)
        scores = self._reconstruction_error(fit_windows, last_only=True)
        self.threshold_ = float(np.quantile(scores, 1.0 - contamination))
        self._history = {
            "train_loss": train_loss,
            "validation_loss": validation_loss,
            "epochs_run": len(train_loss),
            "best_epoch": int(np.argmin(validation_loss)) + 1,
        }
        return self

    # -- fitting ------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁfit__mutmut_115(self, train: pd.DataFrame, validation: pd.DataFrame, contamination: float) -> Self:
        if not 0.0 < contamination < 0.5:
            raise ValueError("contamination must be in (0, 0.5)")
        if len(train) < self.window or len(validation) < self.window:
            raise ValueError("the training and validation rows must fill at least one window")
        values = train[self.columns].astype(float)
        self.center_ = values.median().to_numpy()
        spread = values.std(ddof=0).to_numpy()
        self.scale_ = np.where(spread > 0, spread, 1.0)
        torch.manual_seed(self.seed)
        torch.set_num_threads(self.threads)
        torch.use_deterministic_algorithms(True)
        rng = np.random.default_rng(self.seed)
        fit_windows, _ = self._windows(train)
        if len(fit_windows) > self.fit_rows:
            fit_windows = fit_windows[rng.choice(len(fit_windows), self.fit_rows, replace=False)]
        val_windows, _ = self._windows(validation)
        if len(val_windows) > self.validation_rows:
            keep = np.sort(rng.choice(len(val_windows), self.validation_rows, replace=False))
            val_windows = val_windows[keep]
        self._validation = torch.as_tensor(val_windows, dtype=torch.float32)
        self._net = _Network(len(self.columns), self.hidden)
        optimiser = torch.optim.Adam(self._net.parameters(), lr=self.learning_rate)
        data = torch.as_tensor(fit_windows, dtype=torch.float32)
        shuffler = torch.Generator().manual_seed(self.seed)
        train_loss: list[float] = []
        validation_loss: list[float] = []
        best, best_state, stale = np.inf, None, 0
        for _epoch in range(self.max_epochs):
            self._net.train()
            order = torch.randperm(len(data), generator=shuffler)
            total = 0.0
            for start in range(0, len(data), self.batch_size):
                batch = data[order[start : start + self.batch_size]]
                optimiser.zero_grad()
                loss = nn.functional.mse_loss(self._net(batch), batch)
                loss.backward()
                optimiser.step()
                total += float(loss.detach()) * len(batch)
            train_loss.append(total * len(data))
            validation_loss.append(self.validation_loss_now())
            if validation_loss[-1] < best:
                best, stale = validation_loss[-1], 0
                best_state = {k: v.clone() for k, v in self._net.state_dict().items()}
            else:
                stale += 1
                if stale >= self.patience:
                    break
        assert best_state is not None
        self._net.load_state_dict(best_state)
        scores = self._reconstruction_error(fit_windows, last_only=True)
        self.threshold_ = float(np.quantile(scores, 1.0 - contamination))
        self._history = {
            "train_loss": train_loss,
            "validation_loss": validation_loss,
            "epochs_run": len(train_loss),
            "best_epoch": int(np.argmin(validation_loss)) + 1,
        }
        return self

    # -- fitting ------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁfit__mutmut_116(self, train: pd.DataFrame, validation: pd.DataFrame, contamination: float) -> Self:
        if not 0.0 < contamination < 0.5:
            raise ValueError("contamination must be in (0, 0.5)")
        if len(train) < self.window or len(validation) < self.window:
            raise ValueError("the training and validation rows must fill at least one window")
        values = train[self.columns].astype(float)
        self.center_ = values.median().to_numpy()
        spread = values.std(ddof=0).to_numpy()
        self.scale_ = np.where(spread > 0, spread, 1.0)
        torch.manual_seed(self.seed)
        torch.set_num_threads(self.threads)
        torch.use_deterministic_algorithms(True)
        rng = np.random.default_rng(self.seed)
        fit_windows, _ = self._windows(train)
        if len(fit_windows) > self.fit_rows:
            fit_windows = fit_windows[rng.choice(len(fit_windows), self.fit_rows, replace=False)]
        val_windows, _ = self._windows(validation)
        if len(val_windows) > self.validation_rows:
            keep = np.sort(rng.choice(len(val_windows), self.validation_rows, replace=False))
            val_windows = val_windows[keep]
        self._validation = torch.as_tensor(val_windows, dtype=torch.float32)
        self._net = _Network(len(self.columns), self.hidden)
        optimiser = torch.optim.Adam(self._net.parameters(), lr=self.learning_rate)
        data = torch.as_tensor(fit_windows, dtype=torch.float32)
        shuffler = torch.Generator().manual_seed(self.seed)
        train_loss: list[float] = []
        validation_loss: list[float] = []
        best, best_state, stale = np.inf, None, 0
        for _epoch in range(self.max_epochs):
            self._net.train()
            order = torch.randperm(len(data), generator=shuffler)
            total = 0.0
            for start in range(0, len(data), self.batch_size):
                batch = data[order[start : start + self.batch_size]]
                optimiser.zero_grad()
                loss = nn.functional.mse_loss(self._net(batch), batch)
                loss.backward()
                optimiser.step()
                total += float(loss.detach()) * len(batch)
            train_loss.append(total / len(data))
            validation_loss.append(None)
            if validation_loss[-1] < best:
                best, stale = validation_loss[-1], 0
                best_state = {k: v.clone() for k, v in self._net.state_dict().items()}
            else:
                stale += 1
                if stale >= self.patience:
                    break
        assert best_state is not None
        self._net.load_state_dict(best_state)
        scores = self._reconstruction_error(fit_windows, last_only=True)
        self.threshold_ = float(np.quantile(scores, 1.0 - contamination))
        self._history = {
            "train_loss": train_loss,
            "validation_loss": validation_loss,
            "epochs_run": len(train_loss),
            "best_epoch": int(np.argmin(validation_loss)) + 1,
        }
        return self

    # -- fitting ------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁfit__mutmut_117(self, train: pd.DataFrame, validation: pd.DataFrame, contamination: float) -> Self:
        if not 0.0 < contamination < 0.5:
            raise ValueError("contamination must be in (0, 0.5)")
        if len(train) < self.window or len(validation) < self.window:
            raise ValueError("the training and validation rows must fill at least one window")
        values = train[self.columns].astype(float)
        self.center_ = values.median().to_numpy()
        spread = values.std(ddof=0).to_numpy()
        self.scale_ = np.where(spread > 0, spread, 1.0)
        torch.manual_seed(self.seed)
        torch.set_num_threads(self.threads)
        torch.use_deterministic_algorithms(True)
        rng = np.random.default_rng(self.seed)
        fit_windows, _ = self._windows(train)
        if len(fit_windows) > self.fit_rows:
            fit_windows = fit_windows[rng.choice(len(fit_windows), self.fit_rows, replace=False)]
        val_windows, _ = self._windows(validation)
        if len(val_windows) > self.validation_rows:
            keep = np.sort(rng.choice(len(val_windows), self.validation_rows, replace=False))
            val_windows = val_windows[keep]
        self._validation = torch.as_tensor(val_windows, dtype=torch.float32)
        self._net = _Network(len(self.columns), self.hidden)
        optimiser = torch.optim.Adam(self._net.parameters(), lr=self.learning_rate)
        data = torch.as_tensor(fit_windows, dtype=torch.float32)
        shuffler = torch.Generator().manual_seed(self.seed)
        train_loss: list[float] = []
        validation_loss: list[float] = []
        best, best_state, stale = np.inf, None, 0
        for _epoch in range(self.max_epochs):
            self._net.train()
            order = torch.randperm(len(data), generator=shuffler)
            total = 0.0
            for start in range(0, len(data), self.batch_size):
                batch = data[order[start : start + self.batch_size]]
                optimiser.zero_grad()
                loss = nn.functional.mse_loss(self._net(batch), batch)
                loss.backward()
                optimiser.step()
                total += float(loss.detach()) * len(batch)
            train_loss.append(total / len(data))
            validation_loss.append(self.validation_loss_now())
            if validation_loss[+1] < best:
                best, stale = validation_loss[-1], 0
                best_state = {k: v.clone() for k, v in self._net.state_dict().items()}
            else:
                stale += 1
                if stale >= self.patience:
                    break
        assert best_state is not None
        self._net.load_state_dict(best_state)
        scores = self._reconstruction_error(fit_windows, last_only=True)
        self.threshold_ = float(np.quantile(scores, 1.0 - contamination))
        self._history = {
            "train_loss": train_loss,
            "validation_loss": validation_loss,
            "epochs_run": len(train_loss),
            "best_epoch": int(np.argmin(validation_loss)) + 1,
        }
        return self

    # -- fitting ------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁfit__mutmut_118(self, train: pd.DataFrame, validation: pd.DataFrame, contamination: float) -> Self:
        if not 0.0 < contamination < 0.5:
            raise ValueError("contamination must be in (0, 0.5)")
        if len(train) < self.window or len(validation) < self.window:
            raise ValueError("the training and validation rows must fill at least one window")
        values = train[self.columns].astype(float)
        self.center_ = values.median().to_numpy()
        spread = values.std(ddof=0).to_numpy()
        self.scale_ = np.where(spread > 0, spread, 1.0)
        torch.manual_seed(self.seed)
        torch.set_num_threads(self.threads)
        torch.use_deterministic_algorithms(True)
        rng = np.random.default_rng(self.seed)
        fit_windows, _ = self._windows(train)
        if len(fit_windows) > self.fit_rows:
            fit_windows = fit_windows[rng.choice(len(fit_windows), self.fit_rows, replace=False)]
        val_windows, _ = self._windows(validation)
        if len(val_windows) > self.validation_rows:
            keep = np.sort(rng.choice(len(val_windows), self.validation_rows, replace=False))
            val_windows = val_windows[keep]
        self._validation = torch.as_tensor(val_windows, dtype=torch.float32)
        self._net = _Network(len(self.columns), self.hidden)
        optimiser = torch.optim.Adam(self._net.parameters(), lr=self.learning_rate)
        data = torch.as_tensor(fit_windows, dtype=torch.float32)
        shuffler = torch.Generator().manual_seed(self.seed)
        train_loss: list[float] = []
        validation_loss: list[float] = []
        best, best_state, stale = np.inf, None, 0
        for _epoch in range(self.max_epochs):
            self._net.train()
            order = torch.randperm(len(data), generator=shuffler)
            total = 0.0
            for start in range(0, len(data), self.batch_size):
                batch = data[order[start : start + self.batch_size]]
                optimiser.zero_grad()
                loss = nn.functional.mse_loss(self._net(batch), batch)
                loss.backward()
                optimiser.step()
                total += float(loss.detach()) * len(batch)
            train_loss.append(total / len(data))
            validation_loss.append(self.validation_loss_now())
            if validation_loss[-2] < best:
                best, stale = validation_loss[-1], 0
                best_state = {k: v.clone() for k, v in self._net.state_dict().items()}
            else:
                stale += 1
                if stale >= self.patience:
                    break
        assert best_state is not None
        self._net.load_state_dict(best_state)
        scores = self._reconstruction_error(fit_windows, last_only=True)
        self.threshold_ = float(np.quantile(scores, 1.0 - contamination))
        self._history = {
            "train_loss": train_loss,
            "validation_loss": validation_loss,
            "epochs_run": len(train_loss),
            "best_epoch": int(np.argmin(validation_loss)) + 1,
        }
        return self

    # -- fitting ------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁfit__mutmut_119(self, train: pd.DataFrame, validation: pd.DataFrame, contamination: float) -> Self:
        if not 0.0 < contamination < 0.5:
            raise ValueError("contamination must be in (0, 0.5)")
        if len(train) < self.window or len(validation) < self.window:
            raise ValueError("the training and validation rows must fill at least one window")
        values = train[self.columns].astype(float)
        self.center_ = values.median().to_numpy()
        spread = values.std(ddof=0).to_numpy()
        self.scale_ = np.where(spread > 0, spread, 1.0)
        torch.manual_seed(self.seed)
        torch.set_num_threads(self.threads)
        torch.use_deterministic_algorithms(True)
        rng = np.random.default_rng(self.seed)
        fit_windows, _ = self._windows(train)
        if len(fit_windows) > self.fit_rows:
            fit_windows = fit_windows[rng.choice(len(fit_windows), self.fit_rows, replace=False)]
        val_windows, _ = self._windows(validation)
        if len(val_windows) > self.validation_rows:
            keep = np.sort(rng.choice(len(val_windows), self.validation_rows, replace=False))
            val_windows = val_windows[keep]
        self._validation = torch.as_tensor(val_windows, dtype=torch.float32)
        self._net = _Network(len(self.columns), self.hidden)
        optimiser = torch.optim.Adam(self._net.parameters(), lr=self.learning_rate)
        data = torch.as_tensor(fit_windows, dtype=torch.float32)
        shuffler = torch.Generator().manual_seed(self.seed)
        train_loss: list[float] = []
        validation_loss: list[float] = []
        best, best_state, stale = np.inf, None, 0
        for _epoch in range(self.max_epochs):
            self._net.train()
            order = torch.randperm(len(data), generator=shuffler)
            total = 0.0
            for start in range(0, len(data), self.batch_size):
                batch = data[order[start : start + self.batch_size]]
                optimiser.zero_grad()
                loss = nn.functional.mse_loss(self._net(batch), batch)
                loss.backward()
                optimiser.step()
                total += float(loss.detach()) * len(batch)
            train_loss.append(total / len(data))
            validation_loss.append(self.validation_loss_now())
            if validation_loss[-1] <= best:
                best, stale = validation_loss[-1], 0
                best_state = {k: v.clone() for k, v in self._net.state_dict().items()}
            else:
                stale += 1
                if stale >= self.patience:
                    break
        assert best_state is not None
        self._net.load_state_dict(best_state)
        scores = self._reconstruction_error(fit_windows, last_only=True)
        self.threshold_ = float(np.quantile(scores, 1.0 - contamination))
        self._history = {
            "train_loss": train_loss,
            "validation_loss": validation_loss,
            "epochs_run": len(train_loss),
            "best_epoch": int(np.argmin(validation_loss)) + 1,
        }
        return self

    # -- fitting ------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁfit__mutmut_120(self, train: pd.DataFrame, validation: pd.DataFrame, contamination: float) -> Self:
        if not 0.0 < contamination < 0.5:
            raise ValueError("contamination must be in (0, 0.5)")
        if len(train) < self.window or len(validation) < self.window:
            raise ValueError("the training and validation rows must fill at least one window")
        values = train[self.columns].astype(float)
        self.center_ = values.median().to_numpy()
        spread = values.std(ddof=0).to_numpy()
        self.scale_ = np.where(spread > 0, spread, 1.0)
        torch.manual_seed(self.seed)
        torch.set_num_threads(self.threads)
        torch.use_deterministic_algorithms(True)
        rng = np.random.default_rng(self.seed)
        fit_windows, _ = self._windows(train)
        if len(fit_windows) > self.fit_rows:
            fit_windows = fit_windows[rng.choice(len(fit_windows), self.fit_rows, replace=False)]
        val_windows, _ = self._windows(validation)
        if len(val_windows) > self.validation_rows:
            keep = np.sort(rng.choice(len(val_windows), self.validation_rows, replace=False))
            val_windows = val_windows[keep]
        self._validation = torch.as_tensor(val_windows, dtype=torch.float32)
        self._net = _Network(len(self.columns), self.hidden)
        optimiser = torch.optim.Adam(self._net.parameters(), lr=self.learning_rate)
        data = torch.as_tensor(fit_windows, dtype=torch.float32)
        shuffler = torch.Generator().manual_seed(self.seed)
        train_loss: list[float] = []
        validation_loss: list[float] = []
        best, best_state, stale = np.inf, None, 0
        for _epoch in range(self.max_epochs):
            self._net.train()
            order = torch.randperm(len(data), generator=shuffler)
            total = 0.0
            for start in range(0, len(data), self.batch_size):
                batch = data[order[start : start + self.batch_size]]
                optimiser.zero_grad()
                loss = nn.functional.mse_loss(self._net(batch), batch)
                loss.backward()
                optimiser.step()
                total += float(loss.detach()) * len(batch)
            train_loss.append(total / len(data))
            validation_loss.append(self.validation_loss_now())
            if validation_loss[-1] < best:
                best, stale = None
                best_state = {k: v.clone() for k, v in self._net.state_dict().items()}
            else:
                stale += 1
                if stale >= self.patience:
                    break
        assert best_state is not None
        self._net.load_state_dict(best_state)
        scores = self._reconstruction_error(fit_windows, last_only=True)
        self.threshold_ = float(np.quantile(scores, 1.0 - contamination))
        self._history = {
            "train_loss": train_loss,
            "validation_loss": validation_loss,
            "epochs_run": len(train_loss),
            "best_epoch": int(np.argmin(validation_loss)) + 1,
        }
        return self

    # -- fitting ------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁfit__mutmut_121(self, train: pd.DataFrame, validation: pd.DataFrame, contamination: float) -> Self:
        if not 0.0 < contamination < 0.5:
            raise ValueError("contamination must be in (0, 0.5)")
        if len(train) < self.window or len(validation) < self.window:
            raise ValueError("the training and validation rows must fill at least one window")
        values = train[self.columns].astype(float)
        self.center_ = values.median().to_numpy()
        spread = values.std(ddof=0).to_numpy()
        self.scale_ = np.where(spread > 0, spread, 1.0)
        torch.manual_seed(self.seed)
        torch.set_num_threads(self.threads)
        torch.use_deterministic_algorithms(True)
        rng = np.random.default_rng(self.seed)
        fit_windows, _ = self._windows(train)
        if len(fit_windows) > self.fit_rows:
            fit_windows = fit_windows[rng.choice(len(fit_windows), self.fit_rows, replace=False)]
        val_windows, _ = self._windows(validation)
        if len(val_windows) > self.validation_rows:
            keep = np.sort(rng.choice(len(val_windows), self.validation_rows, replace=False))
            val_windows = val_windows[keep]
        self._validation = torch.as_tensor(val_windows, dtype=torch.float32)
        self._net = _Network(len(self.columns), self.hidden)
        optimiser = torch.optim.Adam(self._net.parameters(), lr=self.learning_rate)
        data = torch.as_tensor(fit_windows, dtype=torch.float32)
        shuffler = torch.Generator().manual_seed(self.seed)
        train_loss: list[float] = []
        validation_loss: list[float] = []
        best, best_state, stale = np.inf, None, 0
        for _epoch in range(self.max_epochs):
            self._net.train()
            order = torch.randperm(len(data), generator=shuffler)
            total = 0.0
            for start in range(0, len(data), self.batch_size):
                batch = data[order[start : start + self.batch_size]]
                optimiser.zero_grad()
                loss = nn.functional.mse_loss(self._net(batch), batch)
                loss.backward()
                optimiser.step()
                total += float(loss.detach()) * len(batch)
            train_loss.append(total / len(data))
            validation_loss.append(self.validation_loss_now())
            if validation_loss[-1] < best:
                best, stale = validation_loss[+1], 0
                best_state = {k: v.clone() for k, v in self._net.state_dict().items()}
            else:
                stale += 1
                if stale >= self.patience:
                    break
        assert best_state is not None
        self._net.load_state_dict(best_state)
        scores = self._reconstruction_error(fit_windows, last_only=True)
        self.threshold_ = float(np.quantile(scores, 1.0 - contamination))
        self._history = {
            "train_loss": train_loss,
            "validation_loss": validation_loss,
            "epochs_run": len(train_loss),
            "best_epoch": int(np.argmin(validation_loss)) + 1,
        }
        return self

    # -- fitting ------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁfit__mutmut_122(self, train: pd.DataFrame, validation: pd.DataFrame, contamination: float) -> Self:
        if not 0.0 < contamination < 0.5:
            raise ValueError("contamination must be in (0, 0.5)")
        if len(train) < self.window or len(validation) < self.window:
            raise ValueError("the training and validation rows must fill at least one window")
        values = train[self.columns].astype(float)
        self.center_ = values.median().to_numpy()
        spread = values.std(ddof=0).to_numpy()
        self.scale_ = np.where(spread > 0, spread, 1.0)
        torch.manual_seed(self.seed)
        torch.set_num_threads(self.threads)
        torch.use_deterministic_algorithms(True)
        rng = np.random.default_rng(self.seed)
        fit_windows, _ = self._windows(train)
        if len(fit_windows) > self.fit_rows:
            fit_windows = fit_windows[rng.choice(len(fit_windows), self.fit_rows, replace=False)]
        val_windows, _ = self._windows(validation)
        if len(val_windows) > self.validation_rows:
            keep = np.sort(rng.choice(len(val_windows), self.validation_rows, replace=False))
            val_windows = val_windows[keep]
        self._validation = torch.as_tensor(val_windows, dtype=torch.float32)
        self._net = _Network(len(self.columns), self.hidden)
        optimiser = torch.optim.Adam(self._net.parameters(), lr=self.learning_rate)
        data = torch.as_tensor(fit_windows, dtype=torch.float32)
        shuffler = torch.Generator().manual_seed(self.seed)
        train_loss: list[float] = []
        validation_loss: list[float] = []
        best, best_state, stale = np.inf, None, 0
        for _epoch in range(self.max_epochs):
            self._net.train()
            order = torch.randperm(len(data), generator=shuffler)
            total = 0.0
            for start in range(0, len(data), self.batch_size):
                batch = data[order[start : start + self.batch_size]]
                optimiser.zero_grad()
                loss = nn.functional.mse_loss(self._net(batch), batch)
                loss.backward()
                optimiser.step()
                total += float(loss.detach()) * len(batch)
            train_loss.append(total / len(data))
            validation_loss.append(self.validation_loss_now())
            if validation_loss[-1] < best:
                best, stale = validation_loss[-2], 0
                best_state = {k: v.clone() for k, v in self._net.state_dict().items()}
            else:
                stale += 1
                if stale >= self.patience:
                    break
        assert best_state is not None
        self._net.load_state_dict(best_state)
        scores = self._reconstruction_error(fit_windows, last_only=True)
        self.threshold_ = float(np.quantile(scores, 1.0 - contamination))
        self._history = {
            "train_loss": train_loss,
            "validation_loss": validation_loss,
            "epochs_run": len(train_loss),
            "best_epoch": int(np.argmin(validation_loss)) + 1,
        }
        return self

    # -- fitting ------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁfit__mutmut_123(self, train: pd.DataFrame, validation: pd.DataFrame, contamination: float) -> Self:
        if not 0.0 < contamination < 0.5:
            raise ValueError("contamination must be in (0, 0.5)")
        if len(train) < self.window or len(validation) < self.window:
            raise ValueError("the training and validation rows must fill at least one window")
        values = train[self.columns].astype(float)
        self.center_ = values.median().to_numpy()
        spread = values.std(ddof=0).to_numpy()
        self.scale_ = np.where(spread > 0, spread, 1.0)
        torch.manual_seed(self.seed)
        torch.set_num_threads(self.threads)
        torch.use_deterministic_algorithms(True)
        rng = np.random.default_rng(self.seed)
        fit_windows, _ = self._windows(train)
        if len(fit_windows) > self.fit_rows:
            fit_windows = fit_windows[rng.choice(len(fit_windows), self.fit_rows, replace=False)]
        val_windows, _ = self._windows(validation)
        if len(val_windows) > self.validation_rows:
            keep = np.sort(rng.choice(len(val_windows), self.validation_rows, replace=False))
            val_windows = val_windows[keep]
        self._validation = torch.as_tensor(val_windows, dtype=torch.float32)
        self._net = _Network(len(self.columns), self.hidden)
        optimiser = torch.optim.Adam(self._net.parameters(), lr=self.learning_rate)
        data = torch.as_tensor(fit_windows, dtype=torch.float32)
        shuffler = torch.Generator().manual_seed(self.seed)
        train_loss: list[float] = []
        validation_loss: list[float] = []
        best, best_state, stale = np.inf, None, 0
        for _epoch in range(self.max_epochs):
            self._net.train()
            order = torch.randperm(len(data), generator=shuffler)
            total = 0.0
            for start in range(0, len(data), self.batch_size):
                batch = data[order[start : start + self.batch_size]]
                optimiser.zero_grad()
                loss = nn.functional.mse_loss(self._net(batch), batch)
                loss.backward()
                optimiser.step()
                total += float(loss.detach()) * len(batch)
            train_loss.append(total / len(data))
            validation_loss.append(self.validation_loss_now())
            if validation_loss[-1] < best:
                best, stale = validation_loss[-1], 1
                best_state = {k: v.clone() for k, v in self._net.state_dict().items()}
            else:
                stale += 1
                if stale >= self.patience:
                    break
        assert best_state is not None
        self._net.load_state_dict(best_state)
        scores = self._reconstruction_error(fit_windows, last_only=True)
        self.threshold_ = float(np.quantile(scores, 1.0 - contamination))
        self._history = {
            "train_loss": train_loss,
            "validation_loss": validation_loss,
            "epochs_run": len(train_loss),
            "best_epoch": int(np.argmin(validation_loss)) + 1,
        }
        return self

    # -- fitting ------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁfit__mutmut_124(self, train: pd.DataFrame, validation: pd.DataFrame, contamination: float) -> Self:
        if not 0.0 < contamination < 0.5:
            raise ValueError("contamination must be in (0, 0.5)")
        if len(train) < self.window or len(validation) < self.window:
            raise ValueError("the training and validation rows must fill at least one window")
        values = train[self.columns].astype(float)
        self.center_ = values.median().to_numpy()
        spread = values.std(ddof=0).to_numpy()
        self.scale_ = np.where(spread > 0, spread, 1.0)
        torch.manual_seed(self.seed)
        torch.set_num_threads(self.threads)
        torch.use_deterministic_algorithms(True)
        rng = np.random.default_rng(self.seed)
        fit_windows, _ = self._windows(train)
        if len(fit_windows) > self.fit_rows:
            fit_windows = fit_windows[rng.choice(len(fit_windows), self.fit_rows, replace=False)]
        val_windows, _ = self._windows(validation)
        if len(val_windows) > self.validation_rows:
            keep = np.sort(rng.choice(len(val_windows), self.validation_rows, replace=False))
            val_windows = val_windows[keep]
        self._validation = torch.as_tensor(val_windows, dtype=torch.float32)
        self._net = _Network(len(self.columns), self.hidden)
        optimiser = torch.optim.Adam(self._net.parameters(), lr=self.learning_rate)
        data = torch.as_tensor(fit_windows, dtype=torch.float32)
        shuffler = torch.Generator().manual_seed(self.seed)
        train_loss: list[float] = []
        validation_loss: list[float] = []
        best, best_state, stale = np.inf, None, 0
        for _epoch in range(self.max_epochs):
            self._net.train()
            order = torch.randperm(len(data), generator=shuffler)
            total = 0.0
            for start in range(0, len(data), self.batch_size):
                batch = data[order[start : start + self.batch_size]]
                optimiser.zero_grad()
                loss = nn.functional.mse_loss(self._net(batch), batch)
                loss.backward()
                optimiser.step()
                total += float(loss.detach()) * len(batch)
            train_loss.append(total / len(data))
            validation_loss.append(self.validation_loss_now())
            if validation_loss[-1] < best:
                best, stale = validation_loss[-1], 0
                best_state = None
            else:
                stale += 1
                if stale >= self.patience:
                    break
        assert best_state is not None
        self._net.load_state_dict(best_state)
        scores = self._reconstruction_error(fit_windows, last_only=True)
        self.threshold_ = float(np.quantile(scores, 1.0 - contamination))
        self._history = {
            "train_loss": train_loss,
            "validation_loss": validation_loss,
            "epochs_run": len(train_loss),
            "best_epoch": int(np.argmin(validation_loss)) + 1,
        }
        return self

    # -- fitting ------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁfit__mutmut_125(self, train: pd.DataFrame, validation: pd.DataFrame, contamination: float) -> Self:
        if not 0.0 < contamination < 0.5:
            raise ValueError("contamination must be in (0, 0.5)")
        if len(train) < self.window or len(validation) < self.window:
            raise ValueError("the training and validation rows must fill at least one window")
        values = train[self.columns].astype(float)
        self.center_ = values.median().to_numpy()
        spread = values.std(ddof=0).to_numpy()
        self.scale_ = np.where(spread > 0, spread, 1.0)
        torch.manual_seed(self.seed)
        torch.set_num_threads(self.threads)
        torch.use_deterministic_algorithms(True)
        rng = np.random.default_rng(self.seed)
        fit_windows, _ = self._windows(train)
        if len(fit_windows) > self.fit_rows:
            fit_windows = fit_windows[rng.choice(len(fit_windows), self.fit_rows, replace=False)]
        val_windows, _ = self._windows(validation)
        if len(val_windows) > self.validation_rows:
            keep = np.sort(rng.choice(len(val_windows), self.validation_rows, replace=False))
            val_windows = val_windows[keep]
        self._validation = torch.as_tensor(val_windows, dtype=torch.float32)
        self._net = _Network(len(self.columns), self.hidden)
        optimiser = torch.optim.Adam(self._net.parameters(), lr=self.learning_rate)
        data = torch.as_tensor(fit_windows, dtype=torch.float32)
        shuffler = torch.Generator().manual_seed(self.seed)
        train_loss: list[float] = []
        validation_loss: list[float] = []
        best, best_state, stale = np.inf, None, 0
        for _epoch in range(self.max_epochs):
            self._net.train()
            order = torch.randperm(len(data), generator=shuffler)
            total = 0.0
            for start in range(0, len(data), self.batch_size):
                batch = data[order[start : start + self.batch_size]]
                optimiser.zero_grad()
                loss = nn.functional.mse_loss(self._net(batch), batch)
                loss.backward()
                optimiser.step()
                total += float(loss.detach()) * len(batch)
            train_loss.append(total / len(data))
            validation_loss.append(self.validation_loss_now())
            if validation_loss[-1] < best:
                best, stale = validation_loss[-1], 0
                best_state = {k: v.clone() for k, v in self._net.state_dict().items()}
            else:
                stale = 1
                if stale >= self.patience:
                    break
        assert best_state is not None
        self._net.load_state_dict(best_state)
        scores = self._reconstruction_error(fit_windows, last_only=True)
        self.threshold_ = float(np.quantile(scores, 1.0 - contamination))
        self._history = {
            "train_loss": train_loss,
            "validation_loss": validation_loss,
            "epochs_run": len(train_loss),
            "best_epoch": int(np.argmin(validation_loss)) + 1,
        }
        return self

    # -- fitting ------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁfit__mutmut_126(self, train: pd.DataFrame, validation: pd.DataFrame, contamination: float) -> Self:
        if not 0.0 < contamination < 0.5:
            raise ValueError("contamination must be in (0, 0.5)")
        if len(train) < self.window or len(validation) < self.window:
            raise ValueError("the training and validation rows must fill at least one window")
        values = train[self.columns].astype(float)
        self.center_ = values.median().to_numpy()
        spread = values.std(ddof=0).to_numpy()
        self.scale_ = np.where(spread > 0, spread, 1.0)
        torch.manual_seed(self.seed)
        torch.set_num_threads(self.threads)
        torch.use_deterministic_algorithms(True)
        rng = np.random.default_rng(self.seed)
        fit_windows, _ = self._windows(train)
        if len(fit_windows) > self.fit_rows:
            fit_windows = fit_windows[rng.choice(len(fit_windows), self.fit_rows, replace=False)]
        val_windows, _ = self._windows(validation)
        if len(val_windows) > self.validation_rows:
            keep = np.sort(rng.choice(len(val_windows), self.validation_rows, replace=False))
            val_windows = val_windows[keep]
        self._validation = torch.as_tensor(val_windows, dtype=torch.float32)
        self._net = _Network(len(self.columns), self.hidden)
        optimiser = torch.optim.Adam(self._net.parameters(), lr=self.learning_rate)
        data = torch.as_tensor(fit_windows, dtype=torch.float32)
        shuffler = torch.Generator().manual_seed(self.seed)
        train_loss: list[float] = []
        validation_loss: list[float] = []
        best, best_state, stale = np.inf, None, 0
        for _epoch in range(self.max_epochs):
            self._net.train()
            order = torch.randperm(len(data), generator=shuffler)
            total = 0.0
            for start in range(0, len(data), self.batch_size):
                batch = data[order[start : start + self.batch_size]]
                optimiser.zero_grad()
                loss = nn.functional.mse_loss(self._net(batch), batch)
                loss.backward()
                optimiser.step()
                total += float(loss.detach()) * len(batch)
            train_loss.append(total / len(data))
            validation_loss.append(self.validation_loss_now())
            if validation_loss[-1] < best:
                best, stale = validation_loss[-1], 0
                best_state = {k: v.clone() for k, v in self._net.state_dict().items()}
            else:
                stale -= 1
                if stale >= self.patience:
                    break
        assert best_state is not None
        self._net.load_state_dict(best_state)
        scores = self._reconstruction_error(fit_windows, last_only=True)
        self.threshold_ = float(np.quantile(scores, 1.0 - contamination))
        self._history = {
            "train_loss": train_loss,
            "validation_loss": validation_loss,
            "epochs_run": len(train_loss),
            "best_epoch": int(np.argmin(validation_loss)) + 1,
        }
        return self

    # -- fitting ------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁfit__mutmut_127(self, train: pd.DataFrame, validation: pd.DataFrame, contamination: float) -> Self:
        if not 0.0 < contamination < 0.5:
            raise ValueError("contamination must be in (0, 0.5)")
        if len(train) < self.window or len(validation) < self.window:
            raise ValueError("the training and validation rows must fill at least one window")
        values = train[self.columns].astype(float)
        self.center_ = values.median().to_numpy()
        spread = values.std(ddof=0).to_numpy()
        self.scale_ = np.where(spread > 0, spread, 1.0)
        torch.manual_seed(self.seed)
        torch.set_num_threads(self.threads)
        torch.use_deterministic_algorithms(True)
        rng = np.random.default_rng(self.seed)
        fit_windows, _ = self._windows(train)
        if len(fit_windows) > self.fit_rows:
            fit_windows = fit_windows[rng.choice(len(fit_windows), self.fit_rows, replace=False)]
        val_windows, _ = self._windows(validation)
        if len(val_windows) > self.validation_rows:
            keep = np.sort(rng.choice(len(val_windows), self.validation_rows, replace=False))
            val_windows = val_windows[keep]
        self._validation = torch.as_tensor(val_windows, dtype=torch.float32)
        self._net = _Network(len(self.columns), self.hidden)
        optimiser = torch.optim.Adam(self._net.parameters(), lr=self.learning_rate)
        data = torch.as_tensor(fit_windows, dtype=torch.float32)
        shuffler = torch.Generator().manual_seed(self.seed)
        train_loss: list[float] = []
        validation_loss: list[float] = []
        best, best_state, stale = np.inf, None, 0
        for _epoch in range(self.max_epochs):
            self._net.train()
            order = torch.randperm(len(data), generator=shuffler)
            total = 0.0
            for start in range(0, len(data), self.batch_size):
                batch = data[order[start : start + self.batch_size]]
                optimiser.zero_grad()
                loss = nn.functional.mse_loss(self._net(batch), batch)
                loss.backward()
                optimiser.step()
                total += float(loss.detach()) * len(batch)
            train_loss.append(total / len(data))
            validation_loss.append(self.validation_loss_now())
            if validation_loss[-1] < best:
                best, stale = validation_loss[-1], 0
                best_state = {k: v.clone() for k, v in self._net.state_dict().items()}
            else:
                stale += 2
                if stale >= self.patience:
                    break
        assert best_state is not None
        self._net.load_state_dict(best_state)
        scores = self._reconstruction_error(fit_windows, last_only=True)
        self.threshold_ = float(np.quantile(scores, 1.0 - contamination))
        self._history = {
            "train_loss": train_loss,
            "validation_loss": validation_loss,
            "epochs_run": len(train_loss),
            "best_epoch": int(np.argmin(validation_loss)) + 1,
        }
        return self

    # -- fitting ------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁfit__mutmut_128(self, train: pd.DataFrame, validation: pd.DataFrame, contamination: float) -> Self:
        if not 0.0 < contamination < 0.5:
            raise ValueError("contamination must be in (0, 0.5)")
        if len(train) < self.window or len(validation) < self.window:
            raise ValueError("the training and validation rows must fill at least one window")
        values = train[self.columns].astype(float)
        self.center_ = values.median().to_numpy()
        spread = values.std(ddof=0).to_numpy()
        self.scale_ = np.where(spread > 0, spread, 1.0)
        torch.manual_seed(self.seed)
        torch.set_num_threads(self.threads)
        torch.use_deterministic_algorithms(True)
        rng = np.random.default_rng(self.seed)
        fit_windows, _ = self._windows(train)
        if len(fit_windows) > self.fit_rows:
            fit_windows = fit_windows[rng.choice(len(fit_windows), self.fit_rows, replace=False)]
        val_windows, _ = self._windows(validation)
        if len(val_windows) > self.validation_rows:
            keep = np.sort(rng.choice(len(val_windows), self.validation_rows, replace=False))
            val_windows = val_windows[keep]
        self._validation = torch.as_tensor(val_windows, dtype=torch.float32)
        self._net = _Network(len(self.columns), self.hidden)
        optimiser = torch.optim.Adam(self._net.parameters(), lr=self.learning_rate)
        data = torch.as_tensor(fit_windows, dtype=torch.float32)
        shuffler = torch.Generator().manual_seed(self.seed)
        train_loss: list[float] = []
        validation_loss: list[float] = []
        best, best_state, stale = np.inf, None, 0
        for _epoch in range(self.max_epochs):
            self._net.train()
            order = torch.randperm(len(data), generator=shuffler)
            total = 0.0
            for start in range(0, len(data), self.batch_size):
                batch = data[order[start : start + self.batch_size]]
                optimiser.zero_grad()
                loss = nn.functional.mse_loss(self._net(batch), batch)
                loss.backward()
                optimiser.step()
                total += float(loss.detach()) * len(batch)
            train_loss.append(total / len(data))
            validation_loss.append(self.validation_loss_now())
            if validation_loss[-1] < best:
                best, stale = validation_loss[-1], 0
                best_state = {k: v.clone() for k, v in self._net.state_dict().items()}
            else:
                stale += 1
                if stale > self.patience:
                    break
        assert best_state is not None
        self._net.load_state_dict(best_state)
        scores = self._reconstruction_error(fit_windows, last_only=True)
        self.threshold_ = float(np.quantile(scores, 1.0 - contamination))
        self._history = {
            "train_loss": train_loss,
            "validation_loss": validation_loss,
            "epochs_run": len(train_loss),
            "best_epoch": int(np.argmin(validation_loss)) + 1,
        }
        return self

    # -- fitting ------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁfit__mutmut_129(self, train: pd.DataFrame, validation: pd.DataFrame, contamination: float) -> Self:
        if not 0.0 < contamination < 0.5:
            raise ValueError("contamination must be in (0, 0.5)")
        if len(train) < self.window or len(validation) < self.window:
            raise ValueError("the training and validation rows must fill at least one window")
        values = train[self.columns].astype(float)
        self.center_ = values.median().to_numpy()
        spread = values.std(ddof=0).to_numpy()
        self.scale_ = np.where(spread > 0, spread, 1.0)
        torch.manual_seed(self.seed)
        torch.set_num_threads(self.threads)
        torch.use_deterministic_algorithms(True)
        rng = np.random.default_rng(self.seed)
        fit_windows, _ = self._windows(train)
        if len(fit_windows) > self.fit_rows:
            fit_windows = fit_windows[rng.choice(len(fit_windows), self.fit_rows, replace=False)]
        val_windows, _ = self._windows(validation)
        if len(val_windows) > self.validation_rows:
            keep = np.sort(rng.choice(len(val_windows), self.validation_rows, replace=False))
            val_windows = val_windows[keep]
        self._validation = torch.as_tensor(val_windows, dtype=torch.float32)
        self._net = _Network(len(self.columns), self.hidden)
        optimiser = torch.optim.Adam(self._net.parameters(), lr=self.learning_rate)
        data = torch.as_tensor(fit_windows, dtype=torch.float32)
        shuffler = torch.Generator().manual_seed(self.seed)
        train_loss: list[float] = []
        validation_loss: list[float] = []
        best, best_state, stale = np.inf, None, 0
        for _epoch in range(self.max_epochs):
            self._net.train()
            order = torch.randperm(len(data), generator=shuffler)
            total = 0.0
            for start in range(0, len(data), self.batch_size):
                batch = data[order[start : start + self.batch_size]]
                optimiser.zero_grad()
                loss = nn.functional.mse_loss(self._net(batch), batch)
                loss.backward()
                optimiser.step()
                total += float(loss.detach()) * len(batch)
            train_loss.append(total / len(data))
            validation_loss.append(self.validation_loss_now())
            if validation_loss[-1] < best:
                best, stale = validation_loss[-1], 0
                best_state = {k: v.clone() for k, v in self._net.state_dict().items()}
            else:
                stale += 1
                if stale >= self.patience:
                    return
        assert best_state is not None
        self._net.load_state_dict(best_state)
        scores = self._reconstruction_error(fit_windows, last_only=True)
        self.threshold_ = float(np.quantile(scores, 1.0 - contamination))
        self._history = {
            "train_loss": train_loss,
            "validation_loss": validation_loss,
            "epochs_run": len(train_loss),
            "best_epoch": int(np.argmin(validation_loss)) + 1,
        }
        return self

    # -- fitting ------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁfit__mutmut_130(self, train: pd.DataFrame, validation: pd.DataFrame, contamination: float) -> Self:
        if not 0.0 < contamination < 0.5:
            raise ValueError("contamination must be in (0, 0.5)")
        if len(train) < self.window or len(validation) < self.window:
            raise ValueError("the training and validation rows must fill at least one window")
        values = train[self.columns].astype(float)
        self.center_ = values.median().to_numpy()
        spread = values.std(ddof=0).to_numpy()
        self.scale_ = np.where(spread > 0, spread, 1.0)
        torch.manual_seed(self.seed)
        torch.set_num_threads(self.threads)
        torch.use_deterministic_algorithms(True)
        rng = np.random.default_rng(self.seed)
        fit_windows, _ = self._windows(train)
        if len(fit_windows) > self.fit_rows:
            fit_windows = fit_windows[rng.choice(len(fit_windows), self.fit_rows, replace=False)]
        val_windows, _ = self._windows(validation)
        if len(val_windows) > self.validation_rows:
            keep = np.sort(rng.choice(len(val_windows), self.validation_rows, replace=False))
            val_windows = val_windows[keep]
        self._validation = torch.as_tensor(val_windows, dtype=torch.float32)
        self._net = _Network(len(self.columns), self.hidden)
        optimiser = torch.optim.Adam(self._net.parameters(), lr=self.learning_rate)
        data = torch.as_tensor(fit_windows, dtype=torch.float32)
        shuffler = torch.Generator().manual_seed(self.seed)
        train_loss: list[float] = []
        validation_loss: list[float] = []
        best, best_state, stale = np.inf, None, 0
        for _epoch in range(self.max_epochs):
            self._net.train()
            order = torch.randperm(len(data), generator=shuffler)
            total = 0.0
            for start in range(0, len(data), self.batch_size):
                batch = data[order[start : start + self.batch_size]]
                optimiser.zero_grad()
                loss = nn.functional.mse_loss(self._net(batch), batch)
                loss.backward()
                optimiser.step()
                total += float(loss.detach()) * len(batch)
            train_loss.append(total / len(data))
            validation_loss.append(self.validation_loss_now())
            if validation_loss[-1] < best:
                best, stale = validation_loss[-1], 0
                best_state = {k: v.clone() for k, v in self._net.state_dict().items()}
            else:
                stale += 1
                if stale >= self.patience:
                    break
        assert best_state is None
        self._net.load_state_dict(best_state)
        scores = self._reconstruction_error(fit_windows, last_only=True)
        self.threshold_ = float(np.quantile(scores, 1.0 - contamination))
        self._history = {
            "train_loss": train_loss,
            "validation_loss": validation_loss,
            "epochs_run": len(train_loss),
            "best_epoch": int(np.argmin(validation_loss)) + 1,
        }
        return self

    # -- fitting ------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁfit__mutmut_131(self, train: pd.DataFrame, validation: pd.DataFrame, contamination: float) -> Self:
        if not 0.0 < contamination < 0.5:
            raise ValueError("contamination must be in (0, 0.5)")
        if len(train) < self.window or len(validation) < self.window:
            raise ValueError("the training and validation rows must fill at least one window")
        values = train[self.columns].astype(float)
        self.center_ = values.median().to_numpy()
        spread = values.std(ddof=0).to_numpy()
        self.scale_ = np.where(spread > 0, spread, 1.0)
        torch.manual_seed(self.seed)
        torch.set_num_threads(self.threads)
        torch.use_deterministic_algorithms(True)
        rng = np.random.default_rng(self.seed)
        fit_windows, _ = self._windows(train)
        if len(fit_windows) > self.fit_rows:
            fit_windows = fit_windows[rng.choice(len(fit_windows), self.fit_rows, replace=False)]
        val_windows, _ = self._windows(validation)
        if len(val_windows) > self.validation_rows:
            keep = np.sort(rng.choice(len(val_windows), self.validation_rows, replace=False))
            val_windows = val_windows[keep]
        self._validation = torch.as_tensor(val_windows, dtype=torch.float32)
        self._net = _Network(len(self.columns), self.hidden)
        optimiser = torch.optim.Adam(self._net.parameters(), lr=self.learning_rate)
        data = torch.as_tensor(fit_windows, dtype=torch.float32)
        shuffler = torch.Generator().manual_seed(self.seed)
        train_loss: list[float] = []
        validation_loss: list[float] = []
        best, best_state, stale = np.inf, None, 0
        for _epoch in range(self.max_epochs):
            self._net.train()
            order = torch.randperm(len(data), generator=shuffler)
            total = 0.0
            for start in range(0, len(data), self.batch_size):
                batch = data[order[start : start + self.batch_size]]
                optimiser.zero_grad()
                loss = nn.functional.mse_loss(self._net(batch), batch)
                loss.backward()
                optimiser.step()
                total += float(loss.detach()) * len(batch)
            train_loss.append(total / len(data))
            validation_loss.append(self.validation_loss_now())
            if validation_loss[-1] < best:
                best, stale = validation_loss[-1], 0
                best_state = {k: v.clone() for k, v in self._net.state_dict().items()}
            else:
                stale += 1
                if stale >= self.patience:
                    break
        assert best_state is not None
        self._net.load_state_dict(None)
        scores = self._reconstruction_error(fit_windows, last_only=True)
        self.threshold_ = float(np.quantile(scores, 1.0 - contamination))
        self._history = {
            "train_loss": train_loss,
            "validation_loss": validation_loss,
            "epochs_run": len(train_loss),
            "best_epoch": int(np.argmin(validation_loss)) + 1,
        }
        return self

    # -- fitting ------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁfit__mutmut_132(self, train: pd.DataFrame, validation: pd.DataFrame, contamination: float) -> Self:
        if not 0.0 < contamination < 0.5:
            raise ValueError("contamination must be in (0, 0.5)")
        if len(train) < self.window or len(validation) < self.window:
            raise ValueError("the training and validation rows must fill at least one window")
        values = train[self.columns].astype(float)
        self.center_ = values.median().to_numpy()
        spread = values.std(ddof=0).to_numpy()
        self.scale_ = np.where(spread > 0, spread, 1.0)
        torch.manual_seed(self.seed)
        torch.set_num_threads(self.threads)
        torch.use_deterministic_algorithms(True)
        rng = np.random.default_rng(self.seed)
        fit_windows, _ = self._windows(train)
        if len(fit_windows) > self.fit_rows:
            fit_windows = fit_windows[rng.choice(len(fit_windows), self.fit_rows, replace=False)]
        val_windows, _ = self._windows(validation)
        if len(val_windows) > self.validation_rows:
            keep = np.sort(rng.choice(len(val_windows), self.validation_rows, replace=False))
            val_windows = val_windows[keep]
        self._validation = torch.as_tensor(val_windows, dtype=torch.float32)
        self._net = _Network(len(self.columns), self.hidden)
        optimiser = torch.optim.Adam(self._net.parameters(), lr=self.learning_rate)
        data = torch.as_tensor(fit_windows, dtype=torch.float32)
        shuffler = torch.Generator().manual_seed(self.seed)
        train_loss: list[float] = []
        validation_loss: list[float] = []
        best, best_state, stale = np.inf, None, 0
        for _epoch in range(self.max_epochs):
            self._net.train()
            order = torch.randperm(len(data), generator=shuffler)
            total = 0.0
            for start in range(0, len(data), self.batch_size):
                batch = data[order[start : start + self.batch_size]]
                optimiser.zero_grad()
                loss = nn.functional.mse_loss(self._net(batch), batch)
                loss.backward()
                optimiser.step()
                total += float(loss.detach()) * len(batch)
            train_loss.append(total / len(data))
            validation_loss.append(self.validation_loss_now())
            if validation_loss[-1] < best:
                best, stale = validation_loss[-1], 0
                best_state = {k: v.clone() for k, v in self._net.state_dict().items()}
            else:
                stale += 1
                if stale >= self.patience:
                    break
        assert best_state is not None
        self._net.load_state_dict(best_state)
        scores = None
        self.threshold_ = float(np.quantile(scores, 1.0 - contamination))
        self._history = {
            "train_loss": train_loss,
            "validation_loss": validation_loss,
            "epochs_run": len(train_loss),
            "best_epoch": int(np.argmin(validation_loss)) + 1,
        }
        return self

    # -- fitting ------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁfit__mutmut_133(self, train: pd.DataFrame, validation: pd.DataFrame, contamination: float) -> Self:
        if not 0.0 < contamination < 0.5:
            raise ValueError("contamination must be in (0, 0.5)")
        if len(train) < self.window or len(validation) < self.window:
            raise ValueError("the training and validation rows must fill at least one window")
        values = train[self.columns].astype(float)
        self.center_ = values.median().to_numpy()
        spread = values.std(ddof=0).to_numpy()
        self.scale_ = np.where(spread > 0, spread, 1.0)
        torch.manual_seed(self.seed)
        torch.set_num_threads(self.threads)
        torch.use_deterministic_algorithms(True)
        rng = np.random.default_rng(self.seed)
        fit_windows, _ = self._windows(train)
        if len(fit_windows) > self.fit_rows:
            fit_windows = fit_windows[rng.choice(len(fit_windows), self.fit_rows, replace=False)]
        val_windows, _ = self._windows(validation)
        if len(val_windows) > self.validation_rows:
            keep = np.sort(rng.choice(len(val_windows), self.validation_rows, replace=False))
            val_windows = val_windows[keep]
        self._validation = torch.as_tensor(val_windows, dtype=torch.float32)
        self._net = _Network(len(self.columns), self.hidden)
        optimiser = torch.optim.Adam(self._net.parameters(), lr=self.learning_rate)
        data = torch.as_tensor(fit_windows, dtype=torch.float32)
        shuffler = torch.Generator().manual_seed(self.seed)
        train_loss: list[float] = []
        validation_loss: list[float] = []
        best, best_state, stale = np.inf, None, 0
        for _epoch in range(self.max_epochs):
            self._net.train()
            order = torch.randperm(len(data), generator=shuffler)
            total = 0.0
            for start in range(0, len(data), self.batch_size):
                batch = data[order[start : start + self.batch_size]]
                optimiser.zero_grad()
                loss = nn.functional.mse_loss(self._net(batch), batch)
                loss.backward()
                optimiser.step()
                total += float(loss.detach()) * len(batch)
            train_loss.append(total / len(data))
            validation_loss.append(self.validation_loss_now())
            if validation_loss[-1] < best:
                best, stale = validation_loss[-1], 0
                best_state = {k: v.clone() for k, v in self._net.state_dict().items()}
            else:
                stale += 1
                if stale >= self.patience:
                    break
        assert best_state is not None
        self._net.load_state_dict(best_state)
        scores = self._reconstruction_error(None, last_only=True)
        self.threshold_ = float(np.quantile(scores, 1.0 - contamination))
        self._history = {
            "train_loss": train_loss,
            "validation_loss": validation_loss,
            "epochs_run": len(train_loss),
            "best_epoch": int(np.argmin(validation_loss)) + 1,
        }
        return self

    # -- fitting ------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁfit__mutmut_134(self, train: pd.DataFrame, validation: pd.DataFrame, contamination: float) -> Self:
        if not 0.0 < contamination < 0.5:
            raise ValueError("contamination must be in (0, 0.5)")
        if len(train) < self.window or len(validation) < self.window:
            raise ValueError("the training and validation rows must fill at least one window")
        values = train[self.columns].astype(float)
        self.center_ = values.median().to_numpy()
        spread = values.std(ddof=0).to_numpy()
        self.scale_ = np.where(spread > 0, spread, 1.0)
        torch.manual_seed(self.seed)
        torch.set_num_threads(self.threads)
        torch.use_deterministic_algorithms(True)
        rng = np.random.default_rng(self.seed)
        fit_windows, _ = self._windows(train)
        if len(fit_windows) > self.fit_rows:
            fit_windows = fit_windows[rng.choice(len(fit_windows), self.fit_rows, replace=False)]
        val_windows, _ = self._windows(validation)
        if len(val_windows) > self.validation_rows:
            keep = np.sort(rng.choice(len(val_windows), self.validation_rows, replace=False))
            val_windows = val_windows[keep]
        self._validation = torch.as_tensor(val_windows, dtype=torch.float32)
        self._net = _Network(len(self.columns), self.hidden)
        optimiser = torch.optim.Adam(self._net.parameters(), lr=self.learning_rate)
        data = torch.as_tensor(fit_windows, dtype=torch.float32)
        shuffler = torch.Generator().manual_seed(self.seed)
        train_loss: list[float] = []
        validation_loss: list[float] = []
        best, best_state, stale = np.inf, None, 0
        for _epoch in range(self.max_epochs):
            self._net.train()
            order = torch.randperm(len(data), generator=shuffler)
            total = 0.0
            for start in range(0, len(data), self.batch_size):
                batch = data[order[start : start + self.batch_size]]
                optimiser.zero_grad()
                loss = nn.functional.mse_loss(self._net(batch), batch)
                loss.backward()
                optimiser.step()
                total += float(loss.detach()) * len(batch)
            train_loss.append(total / len(data))
            validation_loss.append(self.validation_loss_now())
            if validation_loss[-1] < best:
                best, stale = validation_loss[-1], 0
                best_state = {k: v.clone() for k, v in self._net.state_dict().items()}
            else:
                stale += 1
                if stale >= self.patience:
                    break
        assert best_state is not None
        self._net.load_state_dict(best_state)
        scores = self._reconstruction_error(fit_windows, last_only=None)
        self.threshold_ = float(np.quantile(scores, 1.0 - contamination))
        self._history = {
            "train_loss": train_loss,
            "validation_loss": validation_loss,
            "epochs_run": len(train_loss),
            "best_epoch": int(np.argmin(validation_loss)) + 1,
        }
        return self

    # -- fitting ------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁfit__mutmut_135(self, train: pd.DataFrame, validation: pd.DataFrame, contamination: float) -> Self:
        if not 0.0 < contamination < 0.5:
            raise ValueError("contamination must be in (0, 0.5)")
        if len(train) < self.window or len(validation) < self.window:
            raise ValueError("the training and validation rows must fill at least one window")
        values = train[self.columns].astype(float)
        self.center_ = values.median().to_numpy()
        spread = values.std(ddof=0).to_numpy()
        self.scale_ = np.where(spread > 0, spread, 1.0)
        torch.manual_seed(self.seed)
        torch.set_num_threads(self.threads)
        torch.use_deterministic_algorithms(True)
        rng = np.random.default_rng(self.seed)
        fit_windows, _ = self._windows(train)
        if len(fit_windows) > self.fit_rows:
            fit_windows = fit_windows[rng.choice(len(fit_windows), self.fit_rows, replace=False)]
        val_windows, _ = self._windows(validation)
        if len(val_windows) > self.validation_rows:
            keep = np.sort(rng.choice(len(val_windows), self.validation_rows, replace=False))
            val_windows = val_windows[keep]
        self._validation = torch.as_tensor(val_windows, dtype=torch.float32)
        self._net = _Network(len(self.columns), self.hidden)
        optimiser = torch.optim.Adam(self._net.parameters(), lr=self.learning_rate)
        data = torch.as_tensor(fit_windows, dtype=torch.float32)
        shuffler = torch.Generator().manual_seed(self.seed)
        train_loss: list[float] = []
        validation_loss: list[float] = []
        best, best_state, stale = np.inf, None, 0
        for _epoch in range(self.max_epochs):
            self._net.train()
            order = torch.randperm(len(data), generator=shuffler)
            total = 0.0
            for start in range(0, len(data), self.batch_size):
                batch = data[order[start : start + self.batch_size]]
                optimiser.zero_grad()
                loss = nn.functional.mse_loss(self._net(batch), batch)
                loss.backward()
                optimiser.step()
                total += float(loss.detach()) * len(batch)
            train_loss.append(total / len(data))
            validation_loss.append(self.validation_loss_now())
            if validation_loss[-1] < best:
                best, stale = validation_loss[-1], 0
                best_state = {k: v.clone() for k, v in self._net.state_dict().items()}
            else:
                stale += 1
                if stale >= self.patience:
                    break
        assert best_state is not None
        self._net.load_state_dict(best_state)
        scores = self._reconstruction_error(last_only=True)
        self.threshold_ = float(np.quantile(scores, 1.0 - contamination))
        self._history = {
            "train_loss": train_loss,
            "validation_loss": validation_loss,
            "epochs_run": len(train_loss),
            "best_epoch": int(np.argmin(validation_loss)) + 1,
        }
        return self

    # -- fitting ------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁfit__mutmut_136(self, train: pd.DataFrame, validation: pd.DataFrame, contamination: float) -> Self:
        if not 0.0 < contamination < 0.5:
            raise ValueError("contamination must be in (0, 0.5)")
        if len(train) < self.window or len(validation) < self.window:
            raise ValueError("the training and validation rows must fill at least one window")
        values = train[self.columns].astype(float)
        self.center_ = values.median().to_numpy()
        spread = values.std(ddof=0).to_numpy()
        self.scale_ = np.where(spread > 0, spread, 1.0)
        torch.manual_seed(self.seed)
        torch.set_num_threads(self.threads)
        torch.use_deterministic_algorithms(True)
        rng = np.random.default_rng(self.seed)
        fit_windows, _ = self._windows(train)
        if len(fit_windows) > self.fit_rows:
            fit_windows = fit_windows[rng.choice(len(fit_windows), self.fit_rows, replace=False)]
        val_windows, _ = self._windows(validation)
        if len(val_windows) > self.validation_rows:
            keep = np.sort(rng.choice(len(val_windows), self.validation_rows, replace=False))
            val_windows = val_windows[keep]
        self._validation = torch.as_tensor(val_windows, dtype=torch.float32)
        self._net = _Network(len(self.columns), self.hidden)
        optimiser = torch.optim.Adam(self._net.parameters(), lr=self.learning_rate)
        data = torch.as_tensor(fit_windows, dtype=torch.float32)
        shuffler = torch.Generator().manual_seed(self.seed)
        train_loss: list[float] = []
        validation_loss: list[float] = []
        best, best_state, stale = np.inf, None, 0
        for _epoch in range(self.max_epochs):
            self._net.train()
            order = torch.randperm(len(data), generator=shuffler)
            total = 0.0
            for start in range(0, len(data), self.batch_size):
                batch = data[order[start : start + self.batch_size]]
                optimiser.zero_grad()
                loss = nn.functional.mse_loss(self._net(batch), batch)
                loss.backward()
                optimiser.step()
                total += float(loss.detach()) * len(batch)
            train_loss.append(total / len(data))
            validation_loss.append(self.validation_loss_now())
            if validation_loss[-1] < best:
                best, stale = validation_loss[-1], 0
                best_state = {k: v.clone() for k, v in self._net.state_dict().items()}
            else:
                stale += 1
                if stale >= self.patience:
                    break
        assert best_state is not None
        self._net.load_state_dict(best_state)
        scores = self._reconstruction_error(fit_windows, )
        self.threshold_ = float(np.quantile(scores, 1.0 - contamination))
        self._history = {
            "train_loss": train_loss,
            "validation_loss": validation_loss,
            "epochs_run": len(train_loss),
            "best_epoch": int(np.argmin(validation_loss)) + 1,
        }
        return self

    # -- fitting ------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁfit__mutmut_137(self, train: pd.DataFrame, validation: pd.DataFrame, contamination: float) -> Self:
        if not 0.0 < contamination < 0.5:
            raise ValueError("contamination must be in (0, 0.5)")
        if len(train) < self.window or len(validation) < self.window:
            raise ValueError("the training and validation rows must fill at least one window")
        values = train[self.columns].astype(float)
        self.center_ = values.median().to_numpy()
        spread = values.std(ddof=0).to_numpy()
        self.scale_ = np.where(spread > 0, spread, 1.0)
        torch.manual_seed(self.seed)
        torch.set_num_threads(self.threads)
        torch.use_deterministic_algorithms(True)
        rng = np.random.default_rng(self.seed)
        fit_windows, _ = self._windows(train)
        if len(fit_windows) > self.fit_rows:
            fit_windows = fit_windows[rng.choice(len(fit_windows), self.fit_rows, replace=False)]
        val_windows, _ = self._windows(validation)
        if len(val_windows) > self.validation_rows:
            keep = np.sort(rng.choice(len(val_windows), self.validation_rows, replace=False))
            val_windows = val_windows[keep]
        self._validation = torch.as_tensor(val_windows, dtype=torch.float32)
        self._net = _Network(len(self.columns), self.hidden)
        optimiser = torch.optim.Adam(self._net.parameters(), lr=self.learning_rate)
        data = torch.as_tensor(fit_windows, dtype=torch.float32)
        shuffler = torch.Generator().manual_seed(self.seed)
        train_loss: list[float] = []
        validation_loss: list[float] = []
        best, best_state, stale = np.inf, None, 0
        for _epoch in range(self.max_epochs):
            self._net.train()
            order = torch.randperm(len(data), generator=shuffler)
            total = 0.0
            for start in range(0, len(data), self.batch_size):
                batch = data[order[start : start + self.batch_size]]
                optimiser.zero_grad()
                loss = nn.functional.mse_loss(self._net(batch), batch)
                loss.backward()
                optimiser.step()
                total += float(loss.detach()) * len(batch)
            train_loss.append(total / len(data))
            validation_loss.append(self.validation_loss_now())
            if validation_loss[-1] < best:
                best, stale = validation_loss[-1], 0
                best_state = {k: v.clone() for k, v in self._net.state_dict().items()}
            else:
                stale += 1
                if stale >= self.patience:
                    break
        assert best_state is not None
        self._net.load_state_dict(best_state)
        scores = self._reconstruction_error(fit_windows, last_only=False)
        self.threshold_ = float(np.quantile(scores, 1.0 - contamination))
        self._history = {
            "train_loss": train_loss,
            "validation_loss": validation_loss,
            "epochs_run": len(train_loss),
            "best_epoch": int(np.argmin(validation_loss)) + 1,
        }
        return self

    # -- fitting ------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁfit__mutmut_138(self, train: pd.DataFrame, validation: pd.DataFrame, contamination: float) -> Self:
        if not 0.0 < contamination < 0.5:
            raise ValueError("contamination must be in (0, 0.5)")
        if len(train) < self.window or len(validation) < self.window:
            raise ValueError("the training and validation rows must fill at least one window")
        values = train[self.columns].astype(float)
        self.center_ = values.median().to_numpy()
        spread = values.std(ddof=0).to_numpy()
        self.scale_ = np.where(spread > 0, spread, 1.0)
        torch.manual_seed(self.seed)
        torch.set_num_threads(self.threads)
        torch.use_deterministic_algorithms(True)
        rng = np.random.default_rng(self.seed)
        fit_windows, _ = self._windows(train)
        if len(fit_windows) > self.fit_rows:
            fit_windows = fit_windows[rng.choice(len(fit_windows), self.fit_rows, replace=False)]
        val_windows, _ = self._windows(validation)
        if len(val_windows) > self.validation_rows:
            keep = np.sort(rng.choice(len(val_windows), self.validation_rows, replace=False))
            val_windows = val_windows[keep]
        self._validation = torch.as_tensor(val_windows, dtype=torch.float32)
        self._net = _Network(len(self.columns), self.hidden)
        optimiser = torch.optim.Adam(self._net.parameters(), lr=self.learning_rate)
        data = torch.as_tensor(fit_windows, dtype=torch.float32)
        shuffler = torch.Generator().manual_seed(self.seed)
        train_loss: list[float] = []
        validation_loss: list[float] = []
        best, best_state, stale = np.inf, None, 0
        for _epoch in range(self.max_epochs):
            self._net.train()
            order = torch.randperm(len(data), generator=shuffler)
            total = 0.0
            for start in range(0, len(data), self.batch_size):
                batch = data[order[start : start + self.batch_size]]
                optimiser.zero_grad()
                loss = nn.functional.mse_loss(self._net(batch), batch)
                loss.backward()
                optimiser.step()
                total += float(loss.detach()) * len(batch)
            train_loss.append(total / len(data))
            validation_loss.append(self.validation_loss_now())
            if validation_loss[-1] < best:
                best, stale = validation_loss[-1], 0
                best_state = {k: v.clone() for k, v in self._net.state_dict().items()}
            else:
                stale += 1
                if stale >= self.patience:
                    break
        assert best_state is not None
        self._net.load_state_dict(best_state)
        scores = self._reconstruction_error(fit_windows, last_only=True)
        self.threshold_ = None
        self._history = {
            "train_loss": train_loss,
            "validation_loss": validation_loss,
            "epochs_run": len(train_loss),
            "best_epoch": int(np.argmin(validation_loss)) + 1,
        }
        return self

    # -- fitting ------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁfit__mutmut_139(self, train: pd.DataFrame, validation: pd.DataFrame, contamination: float) -> Self:
        if not 0.0 < contamination < 0.5:
            raise ValueError("contamination must be in (0, 0.5)")
        if len(train) < self.window or len(validation) < self.window:
            raise ValueError("the training and validation rows must fill at least one window")
        values = train[self.columns].astype(float)
        self.center_ = values.median().to_numpy()
        spread = values.std(ddof=0).to_numpy()
        self.scale_ = np.where(spread > 0, spread, 1.0)
        torch.manual_seed(self.seed)
        torch.set_num_threads(self.threads)
        torch.use_deterministic_algorithms(True)
        rng = np.random.default_rng(self.seed)
        fit_windows, _ = self._windows(train)
        if len(fit_windows) > self.fit_rows:
            fit_windows = fit_windows[rng.choice(len(fit_windows), self.fit_rows, replace=False)]
        val_windows, _ = self._windows(validation)
        if len(val_windows) > self.validation_rows:
            keep = np.sort(rng.choice(len(val_windows), self.validation_rows, replace=False))
            val_windows = val_windows[keep]
        self._validation = torch.as_tensor(val_windows, dtype=torch.float32)
        self._net = _Network(len(self.columns), self.hidden)
        optimiser = torch.optim.Adam(self._net.parameters(), lr=self.learning_rate)
        data = torch.as_tensor(fit_windows, dtype=torch.float32)
        shuffler = torch.Generator().manual_seed(self.seed)
        train_loss: list[float] = []
        validation_loss: list[float] = []
        best, best_state, stale = np.inf, None, 0
        for _epoch in range(self.max_epochs):
            self._net.train()
            order = torch.randperm(len(data), generator=shuffler)
            total = 0.0
            for start in range(0, len(data), self.batch_size):
                batch = data[order[start : start + self.batch_size]]
                optimiser.zero_grad()
                loss = nn.functional.mse_loss(self._net(batch), batch)
                loss.backward()
                optimiser.step()
                total += float(loss.detach()) * len(batch)
            train_loss.append(total / len(data))
            validation_loss.append(self.validation_loss_now())
            if validation_loss[-1] < best:
                best, stale = validation_loss[-1], 0
                best_state = {k: v.clone() for k, v in self._net.state_dict().items()}
            else:
                stale += 1
                if stale >= self.patience:
                    break
        assert best_state is not None
        self._net.load_state_dict(best_state)
        scores = self._reconstruction_error(fit_windows, last_only=True)
        self.threshold_ = float(None)
        self._history = {
            "train_loss": train_loss,
            "validation_loss": validation_loss,
            "epochs_run": len(train_loss),
            "best_epoch": int(np.argmin(validation_loss)) + 1,
        }
        return self

    # -- fitting ------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁfit__mutmut_140(self, train: pd.DataFrame, validation: pd.DataFrame, contamination: float) -> Self:
        if not 0.0 < contamination < 0.5:
            raise ValueError("contamination must be in (0, 0.5)")
        if len(train) < self.window or len(validation) < self.window:
            raise ValueError("the training and validation rows must fill at least one window")
        values = train[self.columns].astype(float)
        self.center_ = values.median().to_numpy()
        spread = values.std(ddof=0).to_numpy()
        self.scale_ = np.where(spread > 0, spread, 1.0)
        torch.manual_seed(self.seed)
        torch.set_num_threads(self.threads)
        torch.use_deterministic_algorithms(True)
        rng = np.random.default_rng(self.seed)
        fit_windows, _ = self._windows(train)
        if len(fit_windows) > self.fit_rows:
            fit_windows = fit_windows[rng.choice(len(fit_windows), self.fit_rows, replace=False)]
        val_windows, _ = self._windows(validation)
        if len(val_windows) > self.validation_rows:
            keep = np.sort(rng.choice(len(val_windows), self.validation_rows, replace=False))
            val_windows = val_windows[keep]
        self._validation = torch.as_tensor(val_windows, dtype=torch.float32)
        self._net = _Network(len(self.columns), self.hidden)
        optimiser = torch.optim.Adam(self._net.parameters(), lr=self.learning_rate)
        data = torch.as_tensor(fit_windows, dtype=torch.float32)
        shuffler = torch.Generator().manual_seed(self.seed)
        train_loss: list[float] = []
        validation_loss: list[float] = []
        best, best_state, stale = np.inf, None, 0
        for _epoch in range(self.max_epochs):
            self._net.train()
            order = torch.randperm(len(data), generator=shuffler)
            total = 0.0
            for start in range(0, len(data), self.batch_size):
                batch = data[order[start : start + self.batch_size]]
                optimiser.zero_grad()
                loss = nn.functional.mse_loss(self._net(batch), batch)
                loss.backward()
                optimiser.step()
                total += float(loss.detach()) * len(batch)
            train_loss.append(total / len(data))
            validation_loss.append(self.validation_loss_now())
            if validation_loss[-1] < best:
                best, stale = validation_loss[-1], 0
                best_state = {k: v.clone() for k, v in self._net.state_dict().items()}
            else:
                stale += 1
                if stale >= self.patience:
                    break
        assert best_state is not None
        self._net.load_state_dict(best_state)
        scores = self._reconstruction_error(fit_windows, last_only=True)
        self.threshold_ = float(np.quantile(None, 1.0 - contamination))
        self._history = {
            "train_loss": train_loss,
            "validation_loss": validation_loss,
            "epochs_run": len(train_loss),
            "best_epoch": int(np.argmin(validation_loss)) + 1,
        }
        return self

    # -- fitting ------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁfit__mutmut_141(self, train: pd.DataFrame, validation: pd.DataFrame, contamination: float) -> Self:
        if not 0.0 < contamination < 0.5:
            raise ValueError("contamination must be in (0, 0.5)")
        if len(train) < self.window or len(validation) < self.window:
            raise ValueError("the training and validation rows must fill at least one window")
        values = train[self.columns].astype(float)
        self.center_ = values.median().to_numpy()
        spread = values.std(ddof=0).to_numpy()
        self.scale_ = np.where(spread > 0, spread, 1.0)
        torch.manual_seed(self.seed)
        torch.set_num_threads(self.threads)
        torch.use_deterministic_algorithms(True)
        rng = np.random.default_rng(self.seed)
        fit_windows, _ = self._windows(train)
        if len(fit_windows) > self.fit_rows:
            fit_windows = fit_windows[rng.choice(len(fit_windows), self.fit_rows, replace=False)]
        val_windows, _ = self._windows(validation)
        if len(val_windows) > self.validation_rows:
            keep = np.sort(rng.choice(len(val_windows), self.validation_rows, replace=False))
            val_windows = val_windows[keep]
        self._validation = torch.as_tensor(val_windows, dtype=torch.float32)
        self._net = _Network(len(self.columns), self.hidden)
        optimiser = torch.optim.Adam(self._net.parameters(), lr=self.learning_rate)
        data = torch.as_tensor(fit_windows, dtype=torch.float32)
        shuffler = torch.Generator().manual_seed(self.seed)
        train_loss: list[float] = []
        validation_loss: list[float] = []
        best, best_state, stale = np.inf, None, 0
        for _epoch in range(self.max_epochs):
            self._net.train()
            order = torch.randperm(len(data), generator=shuffler)
            total = 0.0
            for start in range(0, len(data), self.batch_size):
                batch = data[order[start : start + self.batch_size]]
                optimiser.zero_grad()
                loss = nn.functional.mse_loss(self._net(batch), batch)
                loss.backward()
                optimiser.step()
                total += float(loss.detach()) * len(batch)
            train_loss.append(total / len(data))
            validation_loss.append(self.validation_loss_now())
            if validation_loss[-1] < best:
                best, stale = validation_loss[-1], 0
                best_state = {k: v.clone() for k, v in self._net.state_dict().items()}
            else:
                stale += 1
                if stale >= self.patience:
                    break
        assert best_state is not None
        self._net.load_state_dict(best_state)
        scores = self._reconstruction_error(fit_windows, last_only=True)
        self.threshold_ = float(np.quantile(scores, None))
        self._history = {
            "train_loss": train_loss,
            "validation_loss": validation_loss,
            "epochs_run": len(train_loss),
            "best_epoch": int(np.argmin(validation_loss)) + 1,
        }
        return self

    # -- fitting ------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁfit__mutmut_142(self, train: pd.DataFrame, validation: pd.DataFrame, contamination: float) -> Self:
        if not 0.0 < contamination < 0.5:
            raise ValueError("contamination must be in (0, 0.5)")
        if len(train) < self.window or len(validation) < self.window:
            raise ValueError("the training and validation rows must fill at least one window")
        values = train[self.columns].astype(float)
        self.center_ = values.median().to_numpy()
        spread = values.std(ddof=0).to_numpy()
        self.scale_ = np.where(spread > 0, spread, 1.0)
        torch.manual_seed(self.seed)
        torch.set_num_threads(self.threads)
        torch.use_deterministic_algorithms(True)
        rng = np.random.default_rng(self.seed)
        fit_windows, _ = self._windows(train)
        if len(fit_windows) > self.fit_rows:
            fit_windows = fit_windows[rng.choice(len(fit_windows), self.fit_rows, replace=False)]
        val_windows, _ = self._windows(validation)
        if len(val_windows) > self.validation_rows:
            keep = np.sort(rng.choice(len(val_windows), self.validation_rows, replace=False))
            val_windows = val_windows[keep]
        self._validation = torch.as_tensor(val_windows, dtype=torch.float32)
        self._net = _Network(len(self.columns), self.hidden)
        optimiser = torch.optim.Adam(self._net.parameters(), lr=self.learning_rate)
        data = torch.as_tensor(fit_windows, dtype=torch.float32)
        shuffler = torch.Generator().manual_seed(self.seed)
        train_loss: list[float] = []
        validation_loss: list[float] = []
        best, best_state, stale = np.inf, None, 0
        for _epoch in range(self.max_epochs):
            self._net.train()
            order = torch.randperm(len(data), generator=shuffler)
            total = 0.0
            for start in range(0, len(data), self.batch_size):
                batch = data[order[start : start + self.batch_size]]
                optimiser.zero_grad()
                loss = nn.functional.mse_loss(self._net(batch), batch)
                loss.backward()
                optimiser.step()
                total += float(loss.detach()) * len(batch)
            train_loss.append(total / len(data))
            validation_loss.append(self.validation_loss_now())
            if validation_loss[-1] < best:
                best, stale = validation_loss[-1], 0
                best_state = {k: v.clone() for k, v in self._net.state_dict().items()}
            else:
                stale += 1
                if stale >= self.patience:
                    break
        assert best_state is not None
        self._net.load_state_dict(best_state)
        scores = self._reconstruction_error(fit_windows, last_only=True)
        self.threshold_ = float(np.quantile(1.0 - contamination))
        self._history = {
            "train_loss": train_loss,
            "validation_loss": validation_loss,
            "epochs_run": len(train_loss),
            "best_epoch": int(np.argmin(validation_loss)) + 1,
        }
        return self

    # -- fitting ------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁfit__mutmut_143(self, train: pd.DataFrame, validation: pd.DataFrame, contamination: float) -> Self:
        if not 0.0 < contamination < 0.5:
            raise ValueError("contamination must be in (0, 0.5)")
        if len(train) < self.window or len(validation) < self.window:
            raise ValueError("the training and validation rows must fill at least one window")
        values = train[self.columns].astype(float)
        self.center_ = values.median().to_numpy()
        spread = values.std(ddof=0).to_numpy()
        self.scale_ = np.where(spread > 0, spread, 1.0)
        torch.manual_seed(self.seed)
        torch.set_num_threads(self.threads)
        torch.use_deterministic_algorithms(True)
        rng = np.random.default_rng(self.seed)
        fit_windows, _ = self._windows(train)
        if len(fit_windows) > self.fit_rows:
            fit_windows = fit_windows[rng.choice(len(fit_windows), self.fit_rows, replace=False)]
        val_windows, _ = self._windows(validation)
        if len(val_windows) > self.validation_rows:
            keep = np.sort(rng.choice(len(val_windows), self.validation_rows, replace=False))
            val_windows = val_windows[keep]
        self._validation = torch.as_tensor(val_windows, dtype=torch.float32)
        self._net = _Network(len(self.columns), self.hidden)
        optimiser = torch.optim.Adam(self._net.parameters(), lr=self.learning_rate)
        data = torch.as_tensor(fit_windows, dtype=torch.float32)
        shuffler = torch.Generator().manual_seed(self.seed)
        train_loss: list[float] = []
        validation_loss: list[float] = []
        best, best_state, stale = np.inf, None, 0
        for _epoch in range(self.max_epochs):
            self._net.train()
            order = torch.randperm(len(data), generator=shuffler)
            total = 0.0
            for start in range(0, len(data), self.batch_size):
                batch = data[order[start : start + self.batch_size]]
                optimiser.zero_grad()
                loss = nn.functional.mse_loss(self._net(batch), batch)
                loss.backward()
                optimiser.step()
                total += float(loss.detach()) * len(batch)
            train_loss.append(total / len(data))
            validation_loss.append(self.validation_loss_now())
            if validation_loss[-1] < best:
                best, stale = validation_loss[-1], 0
                best_state = {k: v.clone() for k, v in self._net.state_dict().items()}
            else:
                stale += 1
                if stale >= self.patience:
                    break
        assert best_state is not None
        self._net.load_state_dict(best_state)
        scores = self._reconstruction_error(fit_windows, last_only=True)
        self.threshold_ = float(np.quantile(scores, ))
        self._history = {
            "train_loss": train_loss,
            "validation_loss": validation_loss,
            "epochs_run": len(train_loss),
            "best_epoch": int(np.argmin(validation_loss)) + 1,
        }
        return self

    # -- fitting ------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁfit__mutmut_144(self, train: pd.DataFrame, validation: pd.DataFrame, contamination: float) -> Self:
        if not 0.0 < contamination < 0.5:
            raise ValueError("contamination must be in (0, 0.5)")
        if len(train) < self.window or len(validation) < self.window:
            raise ValueError("the training and validation rows must fill at least one window")
        values = train[self.columns].astype(float)
        self.center_ = values.median().to_numpy()
        spread = values.std(ddof=0).to_numpy()
        self.scale_ = np.where(spread > 0, spread, 1.0)
        torch.manual_seed(self.seed)
        torch.set_num_threads(self.threads)
        torch.use_deterministic_algorithms(True)
        rng = np.random.default_rng(self.seed)
        fit_windows, _ = self._windows(train)
        if len(fit_windows) > self.fit_rows:
            fit_windows = fit_windows[rng.choice(len(fit_windows), self.fit_rows, replace=False)]
        val_windows, _ = self._windows(validation)
        if len(val_windows) > self.validation_rows:
            keep = np.sort(rng.choice(len(val_windows), self.validation_rows, replace=False))
            val_windows = val_windows[keep]
        self._validation = torch.as_tensor(val_windows, dtype=torch.float32)
        self._net = _Network(len(self.columns), self.hidden)
        optimiser = torch.optim.Adam(self._net.parameters(), lr=self.learning_rate)
        data = torch.as_tensor(fit_windows, dtype=torch.float32)
        shuffler = torch.Generator().manual_seed(self.seed)
        train_loss: list[float] = []
        validation_loss: list[float] = []
        best, best_state, stale = np.inf, None, 0
        for _epoch in range(self.max_epochs):
            self._net.train()
            order = torch.randperm(len(data), generator=shuffler)
            total = 0.0
            for start in range(0, len(data), self.batch_size):
                batch = data[order[start : start + self.batch_size]]
                optimiser.zero_grad()
                loss = nn.functional.mse_loss(self._net(batch), batch)
                loss.backward()
                optimiser.step()
                total += float(loss.detach()) * len(batch)
            train_loss.append(total / len(data))
            validation_loss.append(self.validation_loss_now())
            if validation_loss[-1] < best:
                best, stale = validation_loss[-1], 0
                best_state = {k: v.clone() for k, v in self._net.state_dict().items()}
            else:
                stale += 1
                if stale >= self.patience:
                    break
        assert best_state is not None
        self._net.load_state_dict(best_state)
        scores = self._reconstruction_error(fit_windows, last_only=True)
        self.threshold_ = float(np.quantile(scores, 1.0 + contamination))
        self._history = {
            "train_loss": train_loss,
            "validation_loss": validation_loss,
            "epochs_run": len(train_loss),
            "best_epoch": int(np.argmin(validation_loss)) + 1,
        }
        return self

    # -- fitting ------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁfit__mutmut_145(self, train: pd.DataFrame, validation: pd.DataFrame, contamination: float) -> Self:
        if not 0.0 < contamination < 0.5:
            raise ValueError("contamination must be in (0, 0.5)")
        if len(train) < self.window or len(validation) < self.window:
            raise ValueError("the training and validation rows must fill at least one window")
        values = train[self.columns].astype(float)
        self.center_ = values.median().to_numpy()
        spread = values.std(ddof=0).to_numpy()
        self.scale_ = np.where(spread > 0, spread, 1.0)
        torch.manual_seed(self.seed)
        torch.set_num_threads(self.threads)
        torch.use_deterministic_algorithms(True)
        rng = np.random.default_rng(self.seed)
        fit_windows, _ = self._windows(train)
        if len(fit_windows) > self.fit_rows:
            fit_windows = fit_windows[rng.choice(len(fit_windows), self.fit_rows, replace=False)]
        val_windows, _ = self._windows(validation)
        if len(val_windows) > self.validation_rows:
            keep = np.sort(rng.choice(len(val_windows), self.validation_rows, replace=False))
            val_windows = val_windows[keep]
        self._validation = torch.as_tensor(val_windows, dtype=torch.float32)
        self._net = _Network(len(self.columns), self.hidden)
        optimiser = torch.optim.Adam(self._net.parameters(), lr=self.learning_rate)
        data = torch.as_tensor(fit_windows, dtype=torch.float32)
        shuffler = torch.Generator().manual_seed(self.seed)
        train_loss: list[float] = []
        validation_loss: list[float] = []
        best, best_state, stale = np.inf, None, 0
        for _epoch in range(self.max_epochs):
            self._net.train()
            order = torch.randperm(len(data), generator=shuffler)
            total = 0.0
            for start in range(0, len(data), self.batch_size):
                batch = data[order[start : start + self.batch_size]]
                optimiser.zero_grad()
                loss = nn.functional.mse_loss(self._net(batch), batch)
                loss.backward()
                optimiser.step()
                total += float(loss.detach()) * len(batch)
            train_loss.append(total / len(data))
            validation_loss.append(self.validation_loss_now())
            if validation_loss[-1] < best:
                best, stale = validation_loss[-1], 0
                best_state = {k: v.clone() for k, v in self._net.state_dict().items()}
            else:
                stale += 1
                if stale >= self.patience:
                    break
        assert best_state is not None
        self._net.load_state_dict(best_state)
        scores = self._reconstruction_error(fit_windows, last_only=True)
        self.threshold_ = float(np.quantile(scores, 2.0 - contamination))
        self._history = {
            "train_loss": train_loss,
            "validation_loss": validation_loss,
            "epochs_run": len(train_loss),
            "best_epoch": int(np.argmin(validation_loss)) + 1,
        }
        return self

    # -- fitting ------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁfit__mutmut_146(self, train: pd.DataFrame, validation: pd.DataFrame, contamination: float) -> Self:
        if not 0.0 < contamination < 0.5:
            raise ValueError("contamination must be in (0, 0.5)")
        if len(train) < self.window or len(validation) < self.window:
            raise ValueError("the training and validation rows must fill at least one window")
        values = train[self.columns].astype(float)
        self.center_ = values.median().to_numpy()
        spread = values.std(ddof=0).to_numpy()
        self.scale_ = np.where(spread > 0, spread, 1.0)
        torch.manual_seed(self.seed)
        torch.set_num_threads(self.threads)
        torch.use_deterministic_algorithms(True)
        rng = np.random.default_rng(self.seed)
        fit_windows, _ = self._windows(train)
        if len(fit_windows) > self.fit_rows:
            fit_windows = fit_windows[rng.choice(len(fit_windows), self.fit_rows, replace=False)]
        val_windows, _ = self._windows(validation)
        if len(val_windows) > self.validation_rows:
            keep = np.sort(rng.choice(len(val_windows), self.validation_rows, replace=False))
            val_windows = val_windows[keep]
        self._validation = torch.as_tensor(val_windows, dtype=torch.float32)
        self._net = _Network(len(self.columns), self.hidden)
        optimiser = torch.optim.Adam(self._net.parameters(), lr=self.learning_rate)
        data = torch.as_tensor(fit_windows, dtype=torch.float32)
        shuffler = torch.Generator().manual_seed(self.seed)
        train_loss: list[float] = []
        validation_loss: list[float] = []
        best, best_state, stale = np.inf, None, 0
        for _epoch in range(self.max_epochs):
            self._net.train()
            order = torch.randperm(len(data), generator=shuffler)
            total = 0.0
            for start in range(0, len(data), self.batch_size):
                batch = data[order[start : start + self.batch_size]]
                optimiser.zero_grad()
                loss = nn.functional.mse_loss(self._net(batch), batch)
                loss.backward()
                optimiser.step()
                total += float(loss.detach()) * len(batch)
            train_loss.append(total / len(data))
            validation_loss.append(self.validation_loss_now())
            if validation_loss[-1] < best:
                best, stale = validation_loss[-1], 0
                best_state = {k: v.clone() for k, v in self._net.state_dict().items()}
            else:
                stale += 1
                if stale >= self.patience:
                    break
        assert best_state is not None
        self._net.load_state_dict(best_state)
        scores = self._reconstruction_error(fit_windows, last_only=True)
        self.threshold_ = float(np.quantile(scores, 1.0 - contamination))
        self._history = None
        return self

    # -- fitting ------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁfit__mutmut_147(self, train: pd.DataFrame, validation: pd.DataFrame, contamination: float) -> Self:
        if not 0.0 < contamination < 0.5:
            raise ValueError("contamination must be in (0, 0.5)")
        if len(train) < self.window or len(validation) < self.window:
            raise ValueError("the training and validation rows must fill at least one window")
        values = train[self.columns].astype(float)
        self.center_ = values.median().to_numpy()
        spread = values.std(ddof=0).to_numpy()
        self.scale_ = np.where(spread > 0, spread, 1.0)
        torch.manual_seed(self.seed)
        torch.set_num_threads(self.threads)
        torch.use_deterministic_algorithms(True)
        rng = np.random.default_rng(self.seed)
        fit_windows, _ = self._windows(train)
        if len(fit_windows) > self.fit_rows:
            fit_windows = fit_windows[rng.choice(len(fit_windows), self.fit_rows, replace=False)]
        val_windows, _ = self._windows(validation)
        if len(val_windows) > self.validation_rows:
            keep = np.sort(rng.choice(len(val_windows), self.validation_rows, replace=False))
            val_windows = val_windows[keep]
        self._validation = torch.as_tensor(val_windows, dtype=torch.float32)
        self._net = _Network(len(self.columns), self.hidden)
        optimiser = torch.optim.Adam(self._net.parameters(), lr=self.learning_rate)
        data = torch.as_tensor(fit_windows, dtype=torch.float32)
        shuffler = torch.Generator().manual_seed(self.seed)
        train_loss: list[float] = []
        validation_loss: list[float] = []
        best, best_state, stale = np.inf, None, 0
        for _epoch in range(self.max_epochs):
            self._net.train()
            order = torch.randperm(len(data), generator=shuffler)
            total = 0.0
            for start in range(0, len(data), self.batch_size):
                batch = data[order[start : start + self.batch_size]]
                optimiser.zero_grad()
                loss = nn.functional.mse_loss(self._net(batch), batch)
                loss.backward()
                optimiser.step()
                total += float(loss.detach()) * len(batch)
            train_loss.append(total / len(data))
            validation_loss.append(self.validation_loss_now())
            if validation_loss[-1] < best:
                best, stale = validation_loss[-1], 0
                best_state = {k: v.clone() for k, v in self._net.state_dict().items()}
            else:
                stale += 1
                if stale >= self.patience:
                    break
        assert best_state is not None
        self._net.load_state_dict(best_state)
        scores = self._reconstruction_error(fit_windows, last_only=True)
        self.threshold_ = float(np.quantile(scores, 1.0 - contamination))
        self._history = {
            "XXtrain_lossXX": train_loss,
            "validation_loss": validation_loss,
            "epochs_run": len(train_loss),
            "best_epoch": int(np.argmin(validation_loss)) + 1,
        }
        return self

    # -- fitting ------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁfit__mutmut_148(self, train: pd.DataFrame, validation: pd.DataFrame, contamination: float) -> Self:
        if not 0.0 < contamination < 0.5:
            raise ValueError("contamination must be in (0, 0.5)")
        if len(train) < self.window or len(validation) < self.window:
            raise ValueError("the training and validation rows must fill at least one window")
        values = train[self.columns].astype(float)
        self.center_ = values.median().to_numpy()
        spread = values.std(ddof=0).to_numpy()
        self.scale_ = np.where(spread > 0, spread, 1.0)
        torch.manual_seed(self.seed)
        torch.set_num_threads(self.threads)
        torch.use_deterministic_algorithms(True)
        rng = np.random.default_rng(self.seed)
        fit_windows, _ = self._windows(train)
        if len(fit_windows) > self.fit_rows:
            fit_windows = fit_windows[rng.choice(len(fit_windows), self.fit_rows, replace=False)]
        val_windows, _ = self._windows(validation)
        if len(val_windows) > self.validation_rows:
            keep = np.sort(rng.choice(len(val_windows), self.validation_rows, replace=False))
            val_windows = val_windows[keep]
        self._validation = torch.as_tensor(val_windows, dtype=torch.float32)
        self._net = _Network(len(self.columns), self.hidden)
        optimiser = torch.optim.Adam(self._net.parameters(), lr=self.learning_rate)
        data = torch.as_tensor(fit_windows, dtype=torch.float32)
        shuffler = torch.Generator().manual_seed(self.seed)
        train_loss: list[float] = []
        validation_loss: list[float] = []
        best, best_state, stale = np.inf, None, 0
        for _epoch in range(self.max_epochs):
            self._net.train()
            order = torch.randperm(len(data), generator=shuffler)
            total = 0.0
            for start in range(0, len(data), self.batch_size):
                batch = data[order[start : start + self.batch_size]]
                optimiser.zero_grad()
                loss = nn.functional.mse_loss(self._net(batch), batch)
                loss.backward()
                optimiser.step()
                total += float(loss.detach()) * len(batch)
            train_loss.append(total / len(data))
            validation_loss.append(self.validation_loss_now())
            if validation_loss[-1] < best:
                best, stale = validation_loss[-1], 0
                best_state = {k: v.clone() for k, v in self._net.state_dict().items()}
            else:
                stale += 1
                if stale >= self.patience:
                    break
        assert best_state is not None
        self._net.load_state_dict(best_state)
        scores = self._reconstruction_error(fit_windows, last_only=True)
        self.threshold_ = float(np.quantile(scores, 1.0 - contamination))
        self._history = {
            "TRAIN_LOSS": train_loss,
            "validation_loss": validation_loss,
            "epochs_run": len(train_loss),
            "best_epoch": int(np.argmin(validation_loss)) + 1,
        }
        return self

    # -- fitting ------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁfit__mutmut_149(self, train: pd.DataFrame, validation: pd.DataFrame, contamination: float) -> Self:
        if not 0.0 < contamination < 0.5:
            raise ValueError("contamination must be in (0, 0.5)")
        if len(train) < self.window or len(validation) < self.window:
            raise ValueError("the training and validation rows must fill at least one window")
        values = train[self.columns].astype(float)
        self.center_ = values.median().to_numpy()
        spread = values.std(ddof=0).to_numpy()
        self.scale_ = np.where(spread > 0, spread, 1.0)
        torch.manual_seed(self.seed)
        torch.set_num_threads(self.threads)
        torch.use_deterministic_algorithms(True)
        rng = np.random.default_rng(self.seed)
        fit_windows, _ = self._windows(train)
        if len(fit_windows) > self.fit_rows:
            fit_windows = fit_windows[rng.choice(len(fit_windows), self.fit_rows, replace=False)]
        val_windows, _ = self._windows(validation)
        if len(val_windows) > self.validation_rows:
            keep = np.sort(rng.choice(len(val_windows), self.validation_rows, replace=False))
            val_windows = val_windows[keep]
        self._validation = torch.as_tensor(val_windows, dtype=torch.float32)
        self._net = _Network(len(self.columns), self.hidden)
        optimiser = torch.optim.Adam(self._net.parameters(), lr=self.learning_rate)
        data = torch.as_tensor(fit_windows, dtype=torch.float32)
        shuffler = torch.Generator().manual_seed(self.seed)
        train_loss: list[float] = []
        validation_loss: list[float] = []
        best, best_state, stale = np.inf, None, 0
        for _epoch in range(self.max_epochs):
            self._net.train()
            order = torch.randperm(len(data), generator=shuffler)
            total = 0.0
            for start in range(0, len(data), self.batch_size):
                batch = data[order[start : start + self.batch_size]]
                optimiser.zero_grad()
                loss = nn.functional.mse_loss(self._net(batch), batch)
                loss.backward()
                optimiser.step()
                total += float(loss.detach()) * len(batch)
            train_loss.append(total / len(data))
            validation_loss.append(self.validation_loss_now())
            if validation_loss[-1] < best:
                best, stale = validation_loss[-1], 0
                best_state = {k: v.clone() for k, v in self._net.state_dict().items()}
            else:
                stale += 1
                if stale >= self.patience:
                    break
        assert best_state is not None
        self._net.load_state_dict(best_state)
        scores = self._reconstruction_error(fit_windows, last_only=True)
        self.threshold_ = float(np.quantile(scores, 1.0 - contamination))
        self._history = {
            "train_loss": train_loss,
            "XXvalidation_lossXX": validation_loss,
            "epochs_run": len(train_loss),
            "best_epoch": int(np.argmin(validation_loss)) + 1,
        }
        return self

    # -- fitting ------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁfit__mutmut_150(self, train: pd.DataFrame, validation: pd.DataFrame, contamination: float) -> Self:
        if not 0.0 < contamination < 0.5:
            raise ValueError("contamination must be in (0, 0.5)")
        if len(train) < self.window or len(validation) < self.window:
            raise ValueError("the training and validation rows must fill at least one window")
        values = train[self.columns].astype(float)
        self.center_ = values.median().to_numpy()
        spread = values.std(ddof=0).to_numpy()
        self.scale_ = np.where(spread > 0, spread, 1.0)
        torch.manual_seed(self.seed)
        torch.set_num_threads(self.threads)
        torch.use_deterministic_algorithms(True)
        rng = np.random.default_rng(self.seed)
        fit_windows, _ = self._windows(train)
        if len(fit_windows) > self.fit_rows:
            fit_windows = fit_windows[rng.choice(len(fit_windows), self.fit_rows, replace=False)]
        val_windows, _ = self._windows(validation)
        if len(val_windows) > self.validation_rows:
            keep = np.sort(rng.choice(len(val_windows), self.validation_rows, replace=False))
            val_windows = val_windows[keep]
        self._validation = torch.as_tensor(val_windows, dtype=torch.float32)
        self._net = _Network(len(self.columns), self.hidden)
        optimiser = torch.optim.Adam(self._net.parameters(), lr=self.learning_rate)
        data = torch.as_tensor(fit_windows, dtype=torch.float32)
        shuffler = torch.Generator().manual_seed(self.seed)
        train_loss: list[float] = []
        validation_loss: list[float] = []
        best, best_state, stale = np.inf, None, 0
        for _epoch in range(self.max_epochs):
            self._net.train()
            order = torch.randperm(len(data), generator=shuffler)
            total = 0.0
            for start in range(0, len(data), self.batch_size):
                batch = data[order[start : start + self.batch_size]]
                optimiser.zero_grad()
                loss = nn.functional.mse_loss(self._net(batch), batch)
                loss.backward()
                optimiser.step()
                total += float(loss.detach()) * len(batch)
            train_loss.append(total / len(data))
            validation_loss.append(self.validation_loss_now())
            if validation_loss[-1] < best:
                best, stale = validation_loss[-1], 0
                best_state = {k: v.clone() for k, v in self._net.state_dict().items()}
            else:
                stale += 1
                if stale >= self.patience:
                    break
        assert best_state is not None
        self._net.load_state_dict(best_state)
        scores = self._reconstruction_error(fit_windows, last_only=True)
        self.threshold_ = float(np.quantile(scores, 1.0 - contamination))
        self._history = {
            "train_loss": train_loss,
            "VALIDATION_LOSS": validation_loss,
            "epochs_run": len(train_loss),
            "best_epoch": int(np.argmin(validation_loss)) + 1,
        }
        return self

    # -- fitting ------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁfit__mutmut_151(self, train: pd.DataFrame, validation: pd.DataFrame, contamination: float) -> Self:
        if not 0.0 < contamination < 0.5:
            raise ValueError("contamination must be in (0, 0.5)")
        if len(train) < self.window or len(validation) < self.window:
            raise ValueError("the training and validation rows must fill at least one window")
        values = train[self.columns].astype(float)
        self.center_ = values.median().to_numpy()
        spread = values.std(ddof=0).to_numpy()
        self.scale_ = np.where(spread > 0, spread, 1.0)
        torch.manual_seed(self.seed)
        torch.set_num_threads(self.threads)
        torch.use_deterministic_algorithms(True)
        rng = np.random.default_rng(self.seed)
        fit_windows, _ = self._windows(train)
        if len(fit_windows) > self.fit_rows:
            fit_windows = fit_windows[rng.choice(len(fit_windows), self.fit_rows, replace=False)]
        val_windows, _ = self._windows(validation)
        if len(val_windows) > self.validation_rows:
            keep = np.sort(rng.choice(len(val_windows), self.validation_rows, replace=False))
            val_windows = val_windows[keep]
        self._validation = torch.as_tensor(val_windows, dtype=torch.float32)
        self._net = _Network(len(self.columns), self.hidden)
        optimiser = torch.optim.Adam(self._net.parameters(), lr=self.learning_rate)
        data = torch.as_tensor(fit_windows, dtype=torch.float32)
        shuffler = torch.Generator().manual_seed(self.seed)
        train_loss: list[float] = []
        validation_loss: list[float] = []
        best, best_state, stale = np.inf, None, 0
        for _epoch in range(self.max_epochs):
            self._net.train()
            order = torch.randperm(len(data), generator=shuffler)
            total = 0.0
            for start in range(0, len(data), self.batch_size):
                batch = data[order[start : start + self.batch_size]]
                optimiser.zero_grad()
                loss = nn.functional.mse_loss(self._net(batch), batch)
                loss.backward()
                optimiser.step()
                total += float(loss.detach()) * len(batch)
            train_loss.append(total / len(data))
            validation_loss.append(self.validation_loss_now())
            if validation_loss[-1] < best:
                best, stale = validation_loss[-1], 0
                best_state = {k: v.clone() for k, v in self._net.state_dict().items()}
            else:
                stale += 1
                if stale >= self.patience:
                    break
        assert best_state is not None
        self._net.load_state_dict(best_state)
        scores = self._reconstruction_error(fit_windows, last_only=True)
        self.threshold_ = float(np.quantile(scores, 1.0 - contamination))
        self._history = {
            "train_loss": train_loss,
            "validation_loss": validation_loss,
            "XXepochs_runXX": len(train_loss),
            "best_epoch": int(np.argmin(validation_loss)) + 1,
        }
        return self

    # -- fitting ------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁfit__mutmut_152(self, train: pd.DataFrame, validation: pd.DataFrame, contamination: float) -> Self:
        if not 0.0 < contamination < 0.5:
            raise ValueError("contamination must be in (0, 0.5)")
        if len(train) < self.window or len(validation) < self.window:
            raise ValueError("the training and validation rows must fill at least one window")
        values = train[self.columns].astype(float)
        self.center_ = values.median().to_numpy()
        spread = values.std(ddof=0).to_numpy()
        self.scale_ = np.where(spread > 0, spread, 1.0)
        torch.manual_seed(self.seed)
        torch.set_num_threads(self.threads)
        torch.use_deterministic_algorithms(True)
        rng = np.random.default_rng(self.seed)
        fit_windows, _ = self._windows(train)
        if len(fit_windows) > self.fit_rows:
            fit_windows = fit_windows[rng.choice(len(fit_windows), self.fit_rows, replace=False)]
        val_windows, _ = self._windows(validation)
        if len(val_windows) > self.validation_rows:
            keep = np.sort(rng.choice(len(val_windows), self.validation_rows, replace=False))
            val_windows = val_windows[keep]
        self._validation = torch.as_tensor(val_windows, dtype=torch.float32)
        self._net = _Network(len(self.columns), self.hidden)
        optimiser = torch.optim.Adam(self._net.parameters(), lr=self.learning_rate)
        data = torch.as_tensor(fit_windows, dtype=torch.float32)
        shuffler = torch.Generator().manual_seed(self.seed)
        train_loss: list[float] = []
        validation_loss: list[float] = []
        best, best_state, stale = np.inf, None, 0
        for _epoch in range(self.max_epochs):
            self._net.train()
            order = torch.randperm(len(data), generator=shuffler)
            total = 0.0
            for start in range(0, len(data), self.batch_size):
                batch = data[order[start : start + self.batch_size]]
                optimiser.zero_grad()
                loss = nn.functional.mse_loss(self._net(batch), batch)
                loss.backward()
                optimiser.step()
                total += float(loss.detach()) * len(batch)
            train_loss.append(total / len(data))
            validation_loss.append(self.validation_loss_now())
            if validation_loss[-1] < best:
                best, stale = validation_loss[-1], 0
                best_state = {k: v.clone() for k, v in self._net.state_dict().items()}
            else:
                stale += 1
                if stale >= self.patience:
                    break
        assert best_state is not None
        self._net.load_state_dict(best_state)
        scores = self._reconstruction_error(fit_windows, last_only=True)
        self.threshold_ = float(np.quantile(scores, 1.0 - contamination))
        self._history = {
            "train_loss": train_loss,
            "validation_loss": validation_loss,
            "EPOCHS_RUN": len(train_loss),
            "best_epoch": int(np.argmin(validation_loss)) + 1,
        }
        return self

    # -- fitting ------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁfit__mutmut_153(self, train: pd.DataFrame, validation: pd.DataFrame, contamination: float) -> Self:
        if not 0.0 < contamination < 0.5:
            raise ValueError("contamination must be in (0, 0.5)")
        if len(train) < self.window or len(validation) < self.window:
            raise ValueError("the training and validation rows must fill at least one window")
        values = train[self.columns].astype(float)
        self.center_ = values.median().to_numpy()
        spread = values.std(ddof=0).to_numpy()
        self.scale_ = np.where(spread > 0, spread, 1.0)
        torch.manual_seed(self.seed)
        torch.set_num_threads(self.threads)
        torch.use_deterministic_algorithms(True)
        rng = np.random.default_rng(self.seed)
        fit_windows, _ = self._windows(train)
        if len(fit_windows) > self.fit_rows:
            fit_windows = fit_windows[rng.choice(len(fit_windows), self.fit_rows, replace=False)]
        val_windows, _ = self._windows(validation)
        if len(val_windows) > self.validation_rows:
            keep = np.sort(rng.choice(len(val_windows), self.validation_rows, replace=False))
            val_windows = val_windows[keep]
        self._validation = torch.as_tensor(val_windows, dtype=torch.float32)
        self._net = _Network(len(self.columns), self.hidden)
        optimiser = torch.optim.Adam(self._net.parameters(), lr=self.learning_rate)
        data = torch.as_tensor(fit_windows, dtype=torch.float32)
        shuffler = torch.Generator().manual_seed(self.seed)
        train_loss: list[float] = []
        validation_loss: list[float] = []
        best, best_state, stale = np.inf, None, 0
        for _epoch in range(self.max_epochs):
            self._net.train()
            order = torch.randperm(len(data), generator=shuffler)
            total = 0.0
            for start in range(0, len(data), self.batch_size):
                batch = data[order[start : start + self.batch_size]]
                optimiser.zero_grad()
                loss = nn.functional.mse_loss(self._net(batch), batch)
                loss.backward()
                optimiser.step()
                total += float(loss.detach()) * len(batch)
            train_loss.append(total / len(data))
            validation_loss.append(self.validation_loss_now())
            if validation_loss[-1] < best:
                best, stale = validation_loss[-1], 0
                best_state = {k: v.clone() for k, v in self._net.state_dict().items()}
            else:
                stale += 1
                if stale >= self.patience:
                    break
        assert best_state is not None
        self._net.load_state_dict(best_state)
        scores = self._reconstruction_error(fit_windows, last_only=True)
        self.threshold_ = float(np.quantile(scores, 1.0 - contamination))
        self._history = {
            "train_loss": train_loss,
            "validation_loss": validation_loss,
            "epochs_run": len(train_loss),
            "XXbest_epochXX": int(np.argmin(validation_loss)) + 1,
        }
        return self

    # -- fitting ------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁfit__mutmut_154(self, train: pd.DataFrame, validation: pd.DataFrame, contamination: float) -> Self:
        if not 0.0 < contamination < 0.5:
            raise ValueError("contamination must be in (0, 0.5)")
        if len(train) < self.window or len(validation) < self.window:
            raise ValueError("the training and validation rows must fill at least one window")
        values = train[self.columns].astype(float)
        self.center_ = values.median().to_numpy()
        spread = values.std(ddof=0).to_numpy()
        self.scale_ = np.where(spread > 0, spread, 1.0)
        torch.manual_seed(self.seed)
        torch.set_num_threads(self.threads)
        torch.use_deterministic_algorithms(True)
        rng = np.random.default_rng(self.seed)
        fit_windows, _ = self._windows(train)
        if len(fit_windows) > self.fit_rows:
            fit_windows = fit_windows[rng.choice(len(fit_windows), self.fit_rows, replace=False)]
        val_windows, _ = self._windows(validation)
        if len(val_windows) > self.validation_rows:
            keep = np.sort(rng.choice(len(val_windows), self.validation_rows, replace=False))
            val_windows = val_windows[keep]
        self._validation = torch.as_tensor(val_windows, dtype=torch.float32)
        self._net = _Network(len(self.columns), self.hidden)
        optimiser = torch.optim.Adam(self._net.parameters(), lr=self.learning_rate)
        data = torch.as_tensor(fit_windows, dtype=torch.float32)
        shuffler = torch.Generator().manual_seed(self.seed)
        train_loss: list[float] = []
        validation_loss: list[float] = []
        best, best_state, stale = np.inf, None, 0
        for _epoch in range(self.max_epochs):
            self._net.train()
            order = torch.randperm(len(data), generator=shuffler)
            total = 0.0
            for start in range(0, len(data), self.batch_size):
                batch = data[order[start : start + self.batch_size]]
                optimiser.zero_grad()
                loss = nn.functional.mse_loss(self._net(batch), batch)
                loss.backward()
                optimiser.step()
                total += float(loss.detach()) * len(batch)
            train_loss.append(total / len(data))
            validation_loss.append(self.validation_loss_now())
            if validation_loss[-1] < best:
                best, stale = validation_loss[-1], 0
                best_state = {k: v.clone() for k, v in self._net.state_dict().items()}
            else:
                stale += 1
                if stale >= self.patience:
                    break
        assert best_state is not None
        self._net.load_state_dict(best_state)
        scores = self._reconstruction_error(fit_windows, last_only=True)
        self.threshold_ = float(np.quantile(scores, 1.0 - contamination))
        self._history = {
            "train_loss": train_loss,
            "validation_loss": validation_loss,
            "epochs_run": len(train_loss),
            "BEST_EPOCH": int(np.argmin(validation_loss)) + 1,
        }
        return self

    # -- fitting ------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁfit__mutmut_155(self, train: pd.DataFrame, validation: pd.DataFrame, contamination: float) -> Self:
        if not 0.0 < contamination < 0.5:
            raise ValueError("contamination must be in (0, 0.5)")
        if len(train) < self.window or len(validation) < self.window:
            raise ValueError("the training and validation rows must fill at least one window")
        values = train[self.columns].astype(float)
        self.center_ = values.median().to_numpy()
        spread = values.std(ddof=0).to_numpy()
        self.scale_ = np.where(spread > 0, spread, 1.0)
        torch.manual_seed(self.seed)
        torch.set_num_threads(self.threads)
        torch.use_deterministic_algorithms(True)
        rng = np.random.default_rng(self.seed)
        fit_windows, _ = self._windows(train)
        if len(fit_windows) > self.fit_rows:
            fit_windows = fit_windows[rng.choice(len(fit_windows), self.fit_rows, replace=False)]
        val_windows, _ = self._windows(validation)
        if len(val_windows) > self.validation_rows:
            keep = np.sort(rng.choice(len(val_windows), self.validation_rows, replace=False))
            val_windows = val_windows[keep]
        self._validation = torch.as_tensor(val_windows, dtype=torch.float32)
        self._net = _Network(len(self.columns), self.hidden)
        optimiser = torch.optim.Adam(self._net.parameters(), lr=self.learning_rate)
        data = torch.as_tensor(fit_windows, dtype=torch.float32)
        shuffler = torch.Generator().manual_seed(self.seed)
        train_loss: list[float] = []
        validation_loss: list[float] = []
        best, best_state, stale = np.inf, None, 0
        for _epoch in range(self.max_epochs):
            self._net.train()
            order = torch.randperm(len(data), generator=shuffler)
            total = 0.0
            for start in range(0, len(data), self.batch_size):
                batch = data[order[start : start + self.batch_size]]
                optimiser.zero_grad()
                loss = nn.functional.mse_loss(self._net(batch), batch)
                loss.backward()
                optimiser.step()
                total += float(loss.detach()) * len(batch)
            train_loss.append(total / len(data))
            validation_loss.append(self.validation_loss_now())
            if validation_loss[-1] < best:
                best, stale = validation_loss[-1], 0
                best_state = {k: v.clone() for k, v in self._net.state_dict().items()}
            else:
                stale += 1
                if stale >= self.patience:
                    break
        assert best_state is not None
        self._net.load_state_dict(best_state)
        scores = self._reconstruction_error(fit_windows, last_only=True)
        self.threshold_ = float(np.quantile(scores, 1.0 - contamination))
        self._history = {
            "train_loss": train_loss,
            "validation_loss": validation_loss,
            "epochs_run": len(train_loss),
            "best_epoch": int(np.argmin(validation_loss)) - 1,
        }
        return self

    # -- fitting ------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁfit__mutmut_156(self, train: pd.DataFrame, validation: pd.DataFrame, contamination: float) -> Self:
        if not 0.0 < contamination < 0.5:
            raise ValueError("contamination must be in (0, 0.5)")
        if len(train) < self.window or len(validation) < self.window:
            raise ValueError("the training and validation rows must fill at least one window")
        values = train[self.columns].astype(float)
        self.center_ = values.median().to_numpy()
        spread = values.std(ddof=0).to_numpy()
        self.scale_ = np.where(spread > 0, spread, 1.0)
        torch.manual_seed(self.seed)
        torch.set_num_threads(self.threads)
        torch.use_deterministic_algorithms(True)
        rng = np.random.default_rng(self.seed)
        fit_windows, _ = self._windows(train)
        if len(fit_windows) > self.fit_rows:
            fit_windows = fit_windows[rng.choice(len(fit_windows), self.fit_rows, replace=False)]
        val_windows, _ = self._windows(validation)
        if len(val_windows) > self.validation_rows:
            keep = np.sort(rng.choice(len(val_windows), self.validation_rows, replace=False))
            val_windows = val_windows[keep]
        self._validation = torch.as_tensor(val_windows, dtype=torch.float32)
        self._net = _Network(len(self.columns), self.hidden)
        optimiser = torch.optim.Adam(self._net.parameters(), lr=self.learning_rate)
        data = torch.as_tensor(fit_windows, dtype=torch.float32)
        shuffler = torch.Generator().manual_seed(self.seed)
        train_loss: list[float] = []
        validation_loss: list[float] = []
        best, best_state, stale = np.inf, None, 0
        for _epoch in range(self.max_epochs):
            self._net.train()
            order = torch.randperm(len(data), generator=shuffler)
            total = 0.0
            for start in range(0, len(data), self.batch_size):
                batch = data[order[start : start + self.batch_size]]
                optimiser.zero_grad()
                loss = nn.functional.mse_loss(self._net(batch), batch)
                loss.backward()
                optimiser.step()
                total += float(loss.detach()) * len(batch)
            train_loss.append(total / len(data))
            validation_loss.append(self.validation_loss_now())
            if validation_loss[-1] < best:
                best, stale = validation_loss[-1], 0
                best_state = {k: v.clone() for k, v in self._net.state_dict().items()}
            else:
                stale += 1
                if stale >= self.patience:
                    break
        assert best_state is not None
        self._net.load_state_dict(best_state)
        scores = self._reconstruction_error(fit_windows, last_only=True)
        self.threshold_ = float(np.quantile(scores, 1.0 - contamination))
        self._history = {
            "train_loss": train_loss,
            "validation_loss": validation_loss,
            "epochs_run": len(train_loss),
            "best_epoch": int(None) + 1,
        }
        return self

    # -- fitting ------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁfit__mutmut_157(self, train: pd.DataFrame, validation: pd.DataFrame, contamination: float) -> Self:
        if not 0.0 < contamination < 0.5:
            raise ValueError("contamination must be in (0, 0.5)")
        if len(train) < self.window or len(validation) < self.window:
            raise ValueError("the training and validation rows must fill at least one window")
        values = train[self.columns].astype(float)
        self.center_ = values.median().to_numpy()
        spread = values.std(ddof=0).to_numpy()
        self.scale_ = np.where(spread > 0, spread, 1.0)
        torch.manual_seed(self.seed)
        torch.set_num_threads(self.threads)
        torch.use_deterministic_algorithms(True)
        rng = np.random.default_rng(self.seed)
        fit_windows, _ = self._windows(train)
        if len(fit_windows) > self.fit_rows:
            fit_windows = fit_windows[rng.choice(len(fit_windows), self.fit_rows, replace=False)]
        val_windows, _ = self._windows(validation)
        if len(val_windows) > self.validation_rows:
            keep = np.sort(rng.choice(len(val_windows), self.validation_rows, replace=False))
            val_windows = val_windows[keep]
        self._validation = torch.as_tensor(val_windows, dtype=torch.float32)
        self._net = _Network(len(self.columns), self.hidden)
        optimiser = torch.optim.Adam(self._net.parameters(), lr=self.learning_rate)
        data = torch.as_tensor(fit_windows, dtype=torch.float32)
        shuffler = torch.Generator().manual_seed(self.seed)
        train_loss: list[float] = []
        validation_loss: list[float] = []
        best, best_state, stale = np.inf, None, 0
        for _epoch in range(self.max_epochs):
            self._net.train()
            order = torch.randperm(len(data), generator=shuffler)
            total = 0.0
            for start in range(0, len(data), self.batch_size):
                batch = data[order[start : start + self.batch_size]]
                optimiser.zero_grad()
                loss = nn.functional.mse_loss(self._net(batch), batch)
                loss.backward()
                optimiser.step()
                total += float(loss.detach()) * len(batch)
            train_loss.append(total / len(data))
            validation_loss.append(self.validation_loss_now())
            if validation_loss[-1] < best:
                best, stale = validation_loss[-1], 0
                best_state = {k: v.clone() for k, v in self._net.state_dict().items()}
            else:
                stale += 1
                if stale >= self.patience:
                    break
        assert best_state is not None
        self._net.load_state_dict(best_state)
        scores = self._reconstruction_error(fit_windows, last_only=True)
        self.threshold_ = float(np.quantile(scores, 1.0 - contamination))
        self._history = {
            "train_loss": train_loss,
            "validation_loss": validation_loss,
            "epochs_run": len(train_loss),
            "best_epoch": int(np.argmin(None)) + 1,
        }
        return self

    # -- fitting ------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁfit__mutmut_158(self, train: pd.DataFrame, validation: pd.DataFrame, contamination: float) -> Self:
        if not 0.0 < contamination < 0.5:
            raise ValueError("contamination must be in (0, 0.5)")
        if len(train) < self.window or len(validation) < self.window:
            raise ValueError("the training and validation rows must fill at least one window")
        values = train[self.columns].astype(float)
        self.center_ = values.median().to_numpy()
        spread = values.std(ddof=0).to_numpy()
        self.scale_ = np.where(spread > 0, spread, 1.0)
        torch.manual_seed(self.seed)
        torch.set_num_threads(self.threads)
        torch.use_deterministic_algorithms(True)
        rng = np.random.default_rng(self.seed)
        fit_windows, _ = self._windows(train)
        if len(fit_windows) > self.fit_rows:
            fit_windows = fit_windows[rng.choice(len(fit_windows), self.fit_rows, replace=False)]
        val_windows, _ = self._windows(validation)
        if len(val_windows) > self.validation_rows:
            keep = np.sort(rng.choice(len(val_windows), self.validation_rows, replace=False))
            val_windows = val_windows[keep]
        self._validation = torch.as_tensor(val_windows, dtype=torch.float32)
        self._net = _Network(len(self.columns), self.hidden)
        optimiser = torch.optim.Adam(self._net.parameters(), lr=self.learning_rate)
        data = torch.as_tensor(fit_windows, dtype=torch.float32)
        shuffler = torch.Generator().manual_seed(self.seed)
        train_loss: list[float] = []
        validation_loss: list[float] = []
        best, best_state, stale = np.inf, None, 0
        for _epoch in range(self.max_epochs):
            self._net.train()
            order = torch.randperm(len(data), generator=shuffler)
            total = 0.0
            for start in range(0, len(data), self.batch_size):
                batch = data[order[start : start + self.batch_size]]
                optimiser.zero_grad()
                loss = nn.functional.mse_loss(self._net(batch), batch)
                loss.backward()
                optimiser.step()
                total += float(loss.detach()) * len(batch)
            train_loss.append(total / len(data))
            validation_loss.append(self.validation_loss_now())
            if validation_loss[-1] < best:
                best, stale = validation_loss[-1], 0
                best_state = {k: v.clone() for k, v in self._net.state_dict().items()}
            else:
                stale += 1
                if stale >= self.patience:
                    break
        assert best_state is not None
        self._net.load_state_dict(best_state)
        scores = self._reconstruction_error(fit_windows, last_only=True)
        self.threshold_ = float(np.quantile(scores, 1.0 - contamination))
        self._history = {
            "train_loss": train_loss,
            "validation_loss": validation_loss,
            "epochs_run": len(train_loss),
            "best_epoch": int(np.argmin(validation_loss)) + 2,
        }
        return self

    @_mutmut_mutated(mutants_xǁLSTMAutoencoderǁvalidation_loss_now__mutmut)
    def validation_loss_now(self) -> float:
        if self._net is None or self._validation is None:
            raise RuntimeError("the model is not fitted")
        self._net.eval()
        with torch.no_grad():
            return float(nn.functional.mse_loss(self._net(self._validation), self._validation))

    def xǁLSTMAutoencoderǁvalidation_loss_now__mutmut_orig(self) -> float:
        if self._net is None or self._validation is None:
            raise RuntimeError("the model is not fitted")
        self._net.eval()
        with torch.no_grad():
            return float(nn.functional.mse_loss(self._net(self._validation), self._validation))

    def xǁLSTMAutoencoderǁvalidation_loss_now__mutmut_1(self) -> float:
        if self._net is None and self._validation is None:
            raise RuntimeError("the model is not fitted")
        self._net.eval()
        with torch.no_grad():
            return float(nn.functional.mse_loss(self._net(self._validation), self._validation))

    def xǁLSTMAutoencoderǁvalidation_loss_now__mutmut_2(self) -> float:
        if self._net is not None or self._validation is None:
            raise RuntimeError("the model is not fitted")
        self._net.eval()
        with torch.no_grad():
            return float(nn.functional.mse_loss(self._net(self._validation), self._validation))

    def xǁLSTMAutoencoderǁvalidation_loss_now__mutmut_3(self) -> float:
        if self._net is None or self._validation is not None:
            raise RuntimeError("the model is not fitted")
        self._net.eval()
        with torch.no_grad():
            return float(nn.functional.mse_loss(self._net(self._validation), self._validation))

    def xǁLSTMAutoencoderǁvalidation_loss_now__mutmut_4(self) -> float:
        if self._net is None or self._validation is None:
            raise RuntimeError(None)
        self._net.eval()
        with torch.no_grad():
            return float(nn.functional.mse_loss(self._net(self._validation), self._validation))

    def xǁLSTMAutoencoderǁvalidation_loss_now__mutmut_5(self) -> float:
        if self._net is None or self._validation is None:
            raise RuntimeError("XXthe model is not fittedXX")
        self._net.eval()
        with torch.no_grad():
            return float(nn.functional.mse_loss(self._net(self._validation), self._validation))

    def xǁLSTMAutoencoderǁvalidation_loss_now__mutmut_6(self) -> float:
        if self._net is None or self._validation is None:
            raise RuntimeError("THE MODEL IS NOT FITTED")
        self._net.eval()
        with torch.no_grad():
            return float(nn.functional.mse_loss(self._net(self._validation), self._validation))

    def xǁLSTMAutoencoderǁvalidation_loss_now__mutmut_7(self) -> float:
        if self._net is None or self._validation is None:
            raise RuntimeError("the model is not fitted")
        self._net.eval()
        with torch.no_grad():
            return float(None)

    def xǁLSTMAutoencoderǁvalidation_loss_now__mutmut_8(self) -> float:
        if self._net is None or self._validation is None:
            raise RuntimeError("the model is not fitted")
        self._net.eval()
        with torch.no_grad():
            return float(nn.functional.mse_loss(None, self._validation))

    def xǁLSTMAutoencoderǁvalidation_loss_now__mutmut_9(self) -> float:
        if self._net is None or self._validation is None:
            raise RuntimeError("the model is not fitted")
        self._net.eval()
        with torch.no_grad():
            return float(nn.functional.mse_loss(self._net(self._validation), None))

    def xǁLSTMAutoencoderǁvalidation_loss_now__mutmut_10(self) -> float:
        if self._net is None or self._validation is None:
            raise RuntimeError("the model is not fitted")
        self._net.eval()
        with torch.no_grad():
            return float(nn.functional.mse_loss(self._validation))

    def xǁLSTMAutoencoderǁvalidation_loss_now__mutmut_11(self) -> float:
        if self._net is None or self._validation is None:
            raise RuntimeError("the model is not fitted")
        self._net.eval()
        with torch.no_grad():
            return float(nn.functional.mse_loss(self._net(self._validation), ))

    def xǁLSTMAutoencoderǁvalidation_loss_now__mutmut_12(self) -> float:
        if self._net is None or self._validation is None:
            raise RuntimeError("the model is not fitted")
        self._net.eval()
        with torch.no_grad():
            return float(nn.functional.mse_loss(self._net(None), self._validation))

    # -- scoring ------------------------------------------------------------------------
    @_mutmut_mutated(mutants_xǁLSTMAutoencoderǁscore__mutmut)
    def score(self, frame: pd.DataFrame) -> pd.Series:
        if self._net is None or self.center_ is None:
            raise RuntimeError("the model is not fitted")
        windows, order = self._windows(frame)
        return scores_to_events(self._reconstruction_error(windows, True), order, frame.index)

    # -- scoring ------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁscore__mutmut_orig(self, frame: pd.DataFrame) -> pd.Series:
        if self._net is None or self.center_ is None:
            raise RuntimeError("the model is not fitted")
        windows, order = self._windows(frame)
        return scores_to_events(self._reconstruction_error(windows, True), order, frame.index)

    # -- scoring ------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁscore__mutmut_1(self, frame: pd.DataFrame) -> pd.Series:
        if self._net is None and self.center_ is None:
            raise RuntimeError("the model is not fitted")
        windows, order = self._windows(frame)
        return scores_to_events(self._reconstruction_error(windows, True), order, frame.index)

    # -- scoring ------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁscore__mutmut_2(self, frame: pd.DataFrame) -> pd.Series:
        if self._net is not None or self.center_ is None:
            raise RuntimeError("the model is not fitted")
        windows, order = self._windows(frame)
        return scores_to_events(self._reconstruction_error(windows, True), order, frame.index)

    # -- scoring ------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁscore__mutmut_3(self, frame: pd.DataFrame) -> pd.Series:
        if self._net is None or self.center_ is not None:
            raise RuntimeError("the model is not fitted")
        windows, order = self._windows(frame)
        return scores_to_events(self._reconstruction_error(windows, True), order, frame.index)

    # -- scoring ------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁscore__mutmut_4(self, frame: pd.DataFrame) -> pd.Series:
        if self._net is None or self.center_ is None:
            raise RuntimeError(None)
        windows, order = self._windows(frame)
        return scores_to_events(self._reconstruction_error(windows, True), order, frame.index)

    # -- scoring ------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁscore__mutmut_5(self, frame: pd.DataFrame) -> pd.Series:
        if self._net is None or self.center_ is None:
            raise RuntimeError("XXthe model is not fittedXX")
        windows, order = self._windows(frame)
        return scores_to_events(self._reconstruction_error(windows, True), order, frame.index)

    # -- scoring ------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁscore__mutmut_6(self, frame: pd.DataFrame) -> pd.Series:
        if self._net is None or self.center_ is None:
            raise RuntimeError("THE MODEL IS NOT FITTED")
        windows, order = self._windows(frame)
        return scores_to_events(self._reconstruction_error(windows, True), order, frame.index)

    # -- scoring ------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁscore__mutmut_7(self, frame: pd.DataFrame) -> pd.Series:
        if self._net is None or self.center_ is None:
            raise RuntimeError("the model is not fitted")
        windows, order = None
        return scores_to_events(self._reconstruction_error(windows, True), order, frame.index)

    # -- scoring ------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁscore__mutmut_8(self, frame: pd.DataFrame) -> pd.Series:
        if self._net is None or self.center_ is None:
            raise RuntimeError("the model is not fitted")
        windows, order = self._windows(None)
        return scores_to_events(self._reconstruction_error(windows, True), order, frame.index)

    # -- scoring ------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁscore__mutmut_9(self, frame: pd.DataFrame) -> pd.Series:
        if self._net is None or self.center_ is None:
            raise RuntimeError("the model is not fitted")
        windows, order = self._windows(frame)
        return scores_to_events(None, order, frame.index)

    # -- scoring ------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁscore__mutmut_10(self, frame: pd.DataFrame) -> pd.Series:
        if self._net is None or self.center_ is None:
            raise RuntimeError("the model is not fitted")
        windows, order = self._windows(frame)
        return scores_to_events(self._reconstruction_error(windows, True), None, frame.index)

    # -- scoring ------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁscore__mutmut_11(self, frame: pd.DataFrame) -> pd.Series:
        if self._net is None or self.center_ is None:
            raise RuntimeError("the model is not fitted")
        windows, order = self._windows(frame)
        return scores_to_events(self._reconstruction_error(windows, True), order, None)

    # -- scoring ------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁscore__mutmut_12(self, frame: pd.DataFrame) -> pd.Series:
        if self._net is None or self.center_ is None:
            raise RuntimeError("the model is not fitted")
        windows, order = self._windows(frame)
        return scores_to_events(order, frame.index)

    # -- scoring ------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁscore__mutmut_13(self, frame: pd.DataFrame) -> pd.Series:
        if self._net is None or self.center_ is None:
            raise RuntimeError("the model is not fitted")
        windows, order = self._windows(frame)
        return scores_to_events(self._reconstruction_error(windows, True), frame.index)

    # -- scoring ------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁscore__mutmut_14(self, frame: pd.DataFrame) -> pd.Series:
        if self._net is None or self.center_ is None:
            raise RuntimeError("the model is not fitted")
        windows, order = self._windows(frame)
        return scores_to_events(self._reconstruction_error(windows, True), order, )

    # -- scoring ------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁscore__mutmut_15(self, frame: pd.DataFrame) -> pd.Series:
        if self._net is None or self.center_ is None:
            raise RuntimeError("the model is not fitted")
        windows, order = self._windows(frame)
        return scores_to_events(self._reconstruction_error(None, True), order, frame.index)

    # -- scoring ------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁscore__mutmut_16(self, frame: pd.DataFrame) -> pd.Series:
        if self._net is None or self.center_ is None:
            raise RuntimeError("the model is not fitted")
        windows, order = self._windows(frame)
        return scores_to_events(self._reconstruction_error(windows, None), order, frame.index)

    # -- scoring ------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁscore__mutmut_17(self, frame: pd.DataFrame) -> pd.Series:
        if self._net is None or self.center_ is None:
            raise RuntimeError("the model is not fitted")
        windows, order = self._windows(frame)
        return scores_to_events(self._reconstruction_error(True), order, frame.index)

    # -- scoring ------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁscore__mutmut_18(self, frame: pd.DataFrame) -> pd.Series:
        if self._net is None or self.center_ is None:
            raise RuntimeError("the model is not fitted")
        windows, order = self._windows(frame)
        return scores_to_events(self._reconstruction_error(windows, ), order, frame.index)

    # -- scoring ------------------------------------------------------------------------
    def xǁLSTMAutoencoderǁscore__mutmut_19(self, frame: pd.DataFrame) -> pd.Series:
        if self._net is None or self.center_ is None:
            raise RuntimeError("the model is not fitted")
        windows, order = self._windows(frame)
        return scores_to_events(self._reconstruction_error(windows, False), order, frame.index)

    @_mutmut_mutated(mutants_xǁLSTMAutoencoderǁflags__mutmut)
    def flags(self, frame: pd.DataFrame) -> pd.Series:
        return self.score(frame) > self.threshold_

    def xǁLSTMAutoencoderǁflags__mutmut_orig(self, frame: pd.DataFrame) -> pd.Series:
        return self.score(frame) > self.threshold_

    def xǁLSTMAutoencoderǁflags__mutmut_1(self, frame: pd.DataFrame) -> pd.Series:
        return self.score(None) > self.threshold_

    def xǁLSTMAutoencoderǁflags__mutmut_2(self, frame: pd.DataFrame) -> pd.Series:
        return self.score(frame) >= self.threshold_

    @_mutmut_mutated(mutants_xǁLSTMAutoencoderǁsettings__mutmut)
    def settings(self) -> dict[str, Any]:
        if self._net is None:
            raise RuntimeError("the model is not fitted")
        return {
            **self._history,
            "converged": self._history["epochs_run"] < self.max_epochs,
            "window": self.window,
            "hidden": self.hidden,
            "max_epochs": self.max_epochs,
            "patience": self.patience,
            "batch_size": self.batch_size,
            "learning_rate": self.learning_rate,
            "fit_rows": self.fit_rows,
            "seed": self.seed,
            "threads": self.threads,
            "device": "cpu",
            "deterministic_algorithms": True,
            "versions": {"torch": version("torch"), "numpy": version("numpy")},
        }

    def xǁLSTMAutoencoderǁsettings__mutmut_orig(self) -> dict[str, Any]:
        if self._net is None:
            raise RuntimeError("the model is not fitted")
        return {
            **self._history,
            "converged": self._history["epochs_run"] < self.max_epochs,
            "window": self.window,
            "hidden": self.hidden,
            "max_epochs": self.max_epochs,
            "patience": self.patience,
            "batch_size": self.batch_size,
            "learning_rate": self.learning_rate,
            "fit_rows": self.fit_rows,
            "seed": self.seed,
            "threads": self.threads,
            "device": "cpu",
            "deterministic_algorithms": True,
            "versions": {"torch": version("torch"), "numpy": version("numpy")},
        }

    def xǁLSTMAutoencoderǁsettings__mutmut_1(self) -> dict[str, Any]:
        if self._net is not None:
            raise RuntimeError("the model is not fitted")
        return {
            **self._history,
            "converged": self._history["epochs_run"] < self.max_epochs,
            "window": self.window,
            "hidden": self.hidden,
            "max_epochs": self.max_epochs,
            "patience": self.patience,
            "batch_size": self.batch_size,
            "learning_rate": self.learning_rate,
            "fit_rows": self.fit_rows,
            "seed": self.seed,
            "threads": self.threads,
            "device": "cpu",
            "deterministic_algorithms": True,
            "versions": {"torch": version("torch"), "numpy": version("numpy")},
        }

    def xǁLSTMAutoencoderǁsettings__mutmut_2(self) -> dict[str, Any]:
        if self._net is None:
            raise RuntimeError(None)
        return {
            **self._history,
            "converged": self._history["epochs_run"] < self.max_epochs,
            "window": self.window,
            "hidden": self.hidden,
            "max_epochs": self.max_epochs,
            "patience": self.patience,
            "batch_size": self.batch_size,
            "learning_rate": self.learning_rate,
            "fit_rows": self.fit_rows,
            "seed": self.seed,
            "threads": self.threads,
            "device": "cpu",
            "deterministic_algorithms": True,
            "versions": {"torch": version("torch"), "numpy": version("numpy")},
        }

    def xǁLSTMAutoencoderǁsettings__mutmut_3(self) -> dict[str, Any]:
        if self._net is None:
            raise RuntimeError("XXthe model is not fittedXX")
        return {
            **self._history,
            "converged": self._history["epochs_run"] < self.max_epochs,
            "window": self.window,
            "hidden": self.hidden,
            "max_epochs": self.max_epochs,
            "patience": self.patience,
            "batch_size": self.batch_size,
            "learning_rate": self.learning_rate,
            "fit_rows": self.fit_rows,
            "seed": self.seed,
            "threads": self.threads,
            "device": "cpu",
            "deterministic_algorithms": True,
            "versions": {"torch": version("torch"), "numpy": version("numpy")},
        }

    def xǁLSTMAutoencoderǁsettings__mutmut_4(self) -> dict[str, Any]:
        if self._net is None:
            raise RuntimeError("THE MODEL IS NOT FITTED")
        return {
            **self._history,
            "converged": self._history["epochs_run"] < self.max_epochs,
            "window": self.window,
            "hidden": self.hidden,
            "max_epochs": self.max_epochs,
            "patience": self.patience,
            "batch_size": self.batch_size,
            "learning_rate": self.learning_rate,
            "fit_rows": self.fit_rows,
            "seed": self.seed,
            "threads": self.threads,
            "device": "cpu",
            "deterministic_algorithms": True,
            "versions": {"torch": version("torch"), "numpy": version("numpy")},
        }

    def xǁLSTMAutoencoderǁsettings__mutmut_5(self) -> dict[str, Any]:
        if self._net is None:
            raise RuntimeError("the model is not fitted")
        return {
            **self._history,
            "XXconvergedXX": self._history["epochs_run"] < self.max_epochs,
            "window": self.window,
            "hidden": self.hidden,
            "max_epochs": self.max_epochs,
            "patience": self.patience,
            "batch_size": self.batch_size,
            "learning_rate": self.learning_rate,
            "fit_rows": self.fit_rows,
            "seed": self.seed,
            "threads": self.threads,
            "device": "cpu",
            "deterministic_algorithms": True,
            "versions": {"torch": version("torch"), "numpy": version("numpy")},
        }

    def xǁLSTMAutoencoderǁsettings__mutmut_6(self) -> dict[str, Any]:
        if self._net is None:
            raise RuntimeError("the model is not fitted")
        return {
            **self._history,
            "CONVERGED": self._history["epochs_run"] < self.max_epochs,
            "window": self.window,
            "hidden": self.hidden,
            "max_epochs": self.max_epochs,
            "patience": self.patience,
            "batch_size": self.batch_size,
            "learning_rate": self.learning_rate,
            "fit_rows": self.fit_rows,
            "seed": self.seed,
            "threads": self.threads,
            "device": "cpu",
            "deterministic_algorithms": True,
            "versions": {"torch": version("torch"), "numpy": version("numpy")},
        }

    def xǁLSTMAutoencoderǁsettings__mutmut_7(self) -> dict[str, Any]:
        if self._net is None:
            raise RuntimeError("the model is not fitted")
        return {
            **self._history,
            "converged": self._history["XXepochs_runXX"] < self.max_epochs,
            "window": self.window,
            "hidden": self.hidden,
            "max_epochs": self.max_epochs,
            "patience": self.patience,
            "batch_size": self.batch_size,
            "learning_rate": self.learning_rate,
            "fit_rows": self.fit_rows,
            "seed": self.seed,
            "threads": self.threads,
            "device": "cpu",
            "deterministic_algorithms": True,
            "versions": {"torch": version("torch"), "numpy": version("numpy")},
        }

    def xǁLSTMAutoencoderǁsettings__mutmut_8(self) -> dict[str, Any]:
        if self._net is None:
            raise RuntimeError("the model is not fitted")
        return {
            **self._history,
            "converged": self._history["EPOCHS_RUN"] < self.max_epochs,
            "window": self.window,
            "hidden": self.hidden,
            "max_epochs": self.max_epochs,
            "patience": self.patience,
            "batch_size": self.batch_size,
            "learning_rate": self.learning_rate,
            "fit_rows": self.fit_rows,
            "seed": self.seed,
            "threads": self.threads,
            "device": "cpu",
            "deterministic_algorithms": True,
            "versions": {"torch": version("torch"), "numpy": version("numpy")},
        }

    def xǁLSTMAutoencoderǁsettings__mutmut_9(self) -> dict[str, Any]:
        if self._net is None:
            raise RuntimeError("the model is not fitted")
        return {
            **self._history,
            "converged": self._history["epochs_run"] <= self.max_epochs,
            "window": self.window,
            "hidden": self.hidden,
            "max_epochs": self.max_epochs,
            "patience": self.patience,
            "batch_size": self.batch_size,
            "learning_rate": self.learning_rate,
            "fit_rows": self.fit_rows,
            "seed": self.seed,
            "threads": self.threads,
            "device": "cpu",
            "deterministic_algorithms": True,
            "versions": {"torch": version("torch"), "numpy": version("numpy")},
        }

    def xǁLSTMAutoencoderǁsettings__mutmut_10(self) -> dict[str, Any]:
        if self._net is None:
            raise RuntimeError("the model is not fitted")
        return {
            **self._history,
            "converged": self._history["epochs_run"] < self.max_epochs,
            "XXwindowXX": self.window,
            "hidden": self.hidden,
            "max_epochs": self.max_epochs,
            "patience": self.patience,
            "batch_size": self.batch_size,
            "learning_rate": self.learning_rate,
            "fit_rows": self.fit_rows,
            "seed": self.seed,
            "threads": self.threads,
            "device": "cpu",
            "deterministic_algorithms": True,
            "versions": {"torch": version("torch"), "numpy": version("numpy")},
        }

    def xǁLSTMAutoencoderǁsettings__mutmut_11(self) -> dict[str, Any]:
        if self._net is None:
            raise RuntimeError("the model is not fitted")
        return {
            **self._history,
            "converged": self._history["epochs_run"] < self.max_epochs,
            "WINDOW": self.window,
            "hidden": self.hidden,
            "max_epochs": self.max_epochs,
            "patience": self.patience,
            "batch_size": self.batch_size,
            "learning_rate": self.learning_rate,
            "fit_rows": self.fit_rows,
            "seed": self.seed,
            "threads": self.threads,
            "device": "cpu",
            "deterministic_algorithms": True,
            "versions": {"torch": version("torch"), "numpy": version("numpy")},
        }

    def xǁLSTMAutoencoderǁsettings__mutmut_12(self) -> dict[str, Any]:
        if self._net is None:
            raise RuntimeError("the model is not fitted")
        return {
            **self._history,
            "converged": self._history["epochs_run"] < self.max_epochs,
            "window": self.window,
            "XXhiddenXX": self.hidden,
            "max_epochs": self.max_epochs,
            "patience": self.patience,
            "batch_size": self.batch_size,
            "learning_rate": self.learning_rate,
            "fit_rows": self.fit_rows,
            "seed": self.seed,
            "threads": self.threads,
            "device": "cpu",
            "deterministic_algorithms": True,
            "versions": {"torch": version("torch"), "numpy": version("numpy")},
        }

    def xǁLSTMAutoencoderǁsettings__mutmut_13(self) -> dict[str, Any]:
        if self._net is None:
            raise RuntimeError("the model is not fitted")
        return {
            **self._history,
            "converged": self._history["epochs_run"] < self.max_epochs,
            "window": self.window,
            "HIDDEN": self.hidden,
            "max_epochs": self.max_epochs,
            "patience": self.patience,
            "batch_size": self.batch_size,
            "learning_rate": self.learning_rate,
            "fit_rows": self.fit_rows,
            "seed": self.seed,
            "threads": self.threads,
            "device": "cpu",
            "deterministic_algorithms": True,
            "versions": {"torch": version("torch"), "numpy": version("numpy")},
        }

    def xǁLSTMAutoencoderǁsettings__mutmut_14(self) -> dict[str, Any]:
        if self._net is None:
            raise RuntimeError("the model is not fitted")
        return {
            **self._history,
            "converged": self._history["epochs_run"] < self.max_epochs,
            "window": self.window,
            "hidden": self.hidden,
            "XXmax_epochsXX": self.max_epochs,
            "patience": self.patience,
            "batch_size": self.batch_size,
            "learning_rate": self.learning_rate,
            "fit_rows": self.fit_rows,
            "seed": self.seed,
            "threads": self.threads,
            "device": "cpu",
            "deterministic_algorithms": True,
            "versions": {"torch": version("torch"), "numpy": version("numpy")},
        }

    def xǁLSTMAutoencoderǁsettings__mutmut_15(self) -> dict[str, Any]:
        if self._net is None:
            raise RuntimeError("the model is not fitted")
        return {
            **self._history,
            "converged": self._history["epochs_run"] < self.max_epochs,
            "window": self.window,
            "hidden": self.hidden,
            "MAX_EPOCHS": self.max_epochs,
            "patience": self.patience,
            "batch_size": self.batch_size,
            "learning_rate": self.learning_rate,
            "fit_rows": self.fit_rows,
            "seed": self.seed,
            "threads": self.threads,
            "device": "cpu",
            "deterministic_algorithms": True,
            "versions": {"torch": version("torch"), "numpy": version("numpy")},
        }

    def xǁLSTMAutoencoderǁsettings__mutmut_16(self) -> dict[str, Any]:
        if self._net is None:
            raise RuntimeError("the model is not fitted")
        return {
            **self._history,
            "converged": self._history["epochs_run"] < self.max_epochs,
            "window": self.window,
            "hidden": self.hidden,
            "max_epochs": self.max_epochs,
            "XXpatienceXX": self.patience,
            "batch_size": self.batch_size,
            "learning_rate": self.learning_rate,
            "fit_rows": self.fit_rows,
            "seed": self.seed,
            "threads": self.threads,
            "device": "cpu",
            "deterministic_algorithms": True,
            "versions": {"torch": version("torch"), "numpy": version("numpy")},
        }

    def xǁLSTMAutoencoderǁsettings__mutmut_17(self) -> dict[str, Any]:
        if self._net is None:
            raise RuntimeError("the model is not fitted")
        return {
            **self._history,
            "converged": self._history["epochs_run"] < self.max_epochs,
            "window": self.window,
            "hidden": self.hidden,
            "max_epochs": self.max_epochs,
            "PATIENCE": self.patience,
            "batch_size": self.batch_size,
            "learning_rate": self.learning_rate,
            "fit_rows": self.fit_rows,
            "seed": self.seed,
            "threads": self.threads,
            "device": "cpu",
            "deterministic_algorithms": True,
            "versions": {"torch": version("torch"), "numpy": version("numpy")},
        }

    def xǁLSTMAutoencoderǁsettings__mutmut_18(self) -> dict[str, Any]:
        if self._net is None:
            raise RuntimeError("the model is not fitted")
        return {
            **self._history,
            "converged": self._history["epochs_run"] < self.max_epochs,
            "window": self.window,
            "hidden": self.hidden,
            "max_epochs": self.max_epochs,
            "patience": self.patience,
            "XXbatch_sizeXX": self.batch_size,
            "learning_rate": self.learning_rate,
            "fit_rows": self.fit_rows,
            "seed": self.seed,
            "threads": self.threads,
            "device": "cpu",
            "deterministic_algorithms": True,
            "versions": {"torch": version("torch"), "numpy": version("numpy")},
        }

    def xǁLSTMAutoencoderǁsettings__mutmut_19(self) -> dict[str, Any]:
        if self._net is None:
            raise RuntimeError("the model is not fitted")
        return {
            **self._history,
            "converged": self._history["epochs_run"] < self.max_epochs,
            "window": self.window,
            "hidden": self.hidden,
            "max_epochs": self.max_epochs,
            "patience": self.patience,
            "BATCH_SIZE": self.batch_size,
            "learning_rate": self.learning_rate,
            "fit_rows": self.fit_rows,
            "seed": self.seed,
            "threads": self.threads,
            "device": "cpu",
            "deterministic_algorithms": True,
            "versions": {"torch": version("torch"), "numpy": version("numpy")},
        }

    def xǁLSTMAutoencoderǁsettings__mutmut_20(self) -> dict[str, Any]:
        if self._net is None:
            raise RuntimeError("the model is not fitted")
        return {
            **self._history,
            "converged": self._history["epochs_run"] < self.max_epochs,
            "window": self.window,
            "hidden": self.hidden,
            "max_epochs": self.max_epochs,
            "patience": self.patience,
            "batch_size": self.batch_size,
            "XXlearning_rateXX": self.learning_rate,
            "fit_rows": self.fit_rows,
            "seed": self.seed,
            "threads": self.threads,
            "device": "cpu",
            "deterministic_algorithms": True,
            "versions": {"torch": version("torch"), "numpy": version("numpy")},
        }

    def xǁLSTMAutoencoderǁsettings__mutmut_21(self) -> dict[str, Any]:
        if self._net is None:
            raise RuntimeError("the model is not fitted")
        return {
            **self._history,
            "converged": self._history["epochs_run"] < self.max_epochs,
            "window": self.window,
            "hidden": self.hidden,
            "max_epochs": self.max_epochs,
            "patience": self.patience,
            "batch_size": self.batch_size,
            "LEARNING_RATE": self.learning_rate,
            "fit_rows": self.fit_rows,
            "seed": self.seed,
            "threads": self.threads,
            "device": "cpu",
            "deterministic_algorithms": True,
            "versions": {"torch": version("torch"), "numpy": version("numpy")},
        }

    def xǁLSTMAutoencoderǁsettings__mutmut_22(self) -> dict[str, Any]:
        if self._net is None:
            raise RuntimeError("the model is not fitted")
        return {
            **self._history,
            "converged": self._history["epochs_run"] < self.max_epochs,
            "window": self.window,
            "hidden": self.hidden,
            "max_epochs": self.max_epochs,
            "patience": self.patience,
            "batch_size": self.batch_size,
            "learning_rate": self.learning_rate,
            "XXfit_rowsXX": self.fit_rows,
            "seed": self.seed,
            "threads": self.threads,
            "device": "cpu",
            "deterministic_algorithms": True,
            "versions": {"torch": version("torch"), "numpy": version("numpy")},
        }

    def xǁLSTMAutoencoderǁsettings__mutmut_23(self) -> dict[str, Any]:
        if self._net is None:
            raise RuntimeError("the model is not fitted")
        return {
            **self._history,
            "converged": self._history["epochs_run"] < self.max_epochs,
            "window": self.window,
            "hidden": self.hidden,
            "max_epochs": self.max_epochs,
            "patience": self.patience,
            "batch_size": self.batch_size,
            "learning_rate": self.learning_rate,
            "FIT_ROWS": self.fit_rows,
            "seed": self.seed,
            "threads": self.threads,
            "device": "cpu",
            "deterministic_algorithms": True,
            "versions": {"torch": version("torch"), "numpy": version("numpy")},
        }

    def xǁLSTMAutoencoderǁsettings__mutmut_24(self) -> dict[str, Any]:
        if self._net is None:
            raise RuntimeError("the model is not fitted")
        return {
            **self._history,
            "converged": self._history["epochs_run"] < self.max_epochs,
            "window": self.window,
            "hidden": self.hidden,
            "max_epochs": self.max_epochs,
            "patience": self.patience,
            "batch_size": self.batch_size,
            "learning_rate": self.learning_rate,
            "fit_rows": self.fit_rows,
            "XXseedXX": self.seed,
            "threads": self.threads,
            "device": "cpu",
            "deterministic_algorithms": True,
            "versions": {"torch": version("torch"), "numpy": version("numpy")},
        }

    def xǁLSTMAutoencoderǁsettings__mutmut_25(self) -> dict[str, Any]:
        if self._net is None:
            raise RuntimeError("the model is not fitted")
        return {
            **self._history,
            "converged": self._history["epochs_run"] < self.max_epochs,
            "window": self.window,
            "hidden": self.hidden,
            "max_epochs": self.max_epochs,
            "patience": self.patience,
            "batch_size": self.batch_size,
            "learning_rate": self.learning_rate,
            "fit_rows": self.fit_rows,
            "SEED": self.seed,
            "threads": self.threads,
            "device": "cpu",
            "deterministic_algorithms": True,
            "versions": {"torch": version("torch"), "numpy": version("numpy")},
        }

    def xǁLSTMAutoencoderǁsettings__mutmut_26(self) -> dict[str, Any]:
        if self._net is None:
            raise RuntimeError("the model is not fitted")
        return {
            **self._history,
            "converged": self._history["epochs_run"] < self.max_epochs,
            "window": self.window,
            "hidden": self.hidden,
            "max_epochs": self.max_epochs,
            "patience": self.patience,
            "batch_size": self.batch_size,
            "learning_rate": self.learning_rate,
            "fit_rows": self.fit_rows,
            "seed": self.seed,
            "XXthreadsXX": self.threads,
            "device": "cpu",
            "deterministic_algorithms": True,
            "versions": {"torch": version("torch"), "numpy": version("numpy")},
        }

    def xǁLSTMAutoencoderǁsettings__mutmut_27(self) -> dict[str, Any]:
        if self._net is None:
            raise RuntimeError("the model is not fitted")
        return {
            **self._history,
            "converged": self._history["epochs_run"] < self.max_epochs,
            "window": self.window,
            "hidden": self.hidden,
            "max_epochs": self.max_epochs,
            "patience": self.patience,
            "batch_size": self.batch_size,
            "learning_rate": self.learning_rate,
            "fit_rows": self.fit_rows,
            "seed": self.seed,
            "THREADS": self.threads,
            "device": "cpu",
            "deterministic_algorithms": True,
            "versions": {"torch": version("torch"), "numpy": version("numpy")},
        }

    def xǁLSTMAutoencoderǁsettings__mutmut_28(self) -> dict[str, Any]:
        if self._net is None:
            raise RuntimeError("the model is not fitted")
        return {
            **self._history,
            "converged": self._history["epochs_run"] < self.max_epochs,
            "window": self.window,
            "hidden": self.hidden,
            "max_epochs": self.max_epochs,
            "patience": self.patience,
            "batch_size": self.batch_size,
            "learning_rate": self.learning_rate,
            "fit_rows": self.fit_rows,
            "seed": self.seed,
            "threads": self.threads,
            "XXdeviceXX": "cpu",
            "deterministic_algorithms": True,
            "versions": {"torch": version("torch"), "numpy": version("numpy")},
        }

    def xǁLSTMAutoencoderǁsettings__mutmut_29(self) -> dict[str, Any]:
        if self._net is None:
            raise RuntimeError("the model is not fitted")
        return {
            **self._history,
            "converged": self._history["epochs_run"] < self.max_epochs,
            "window": self.window,
            "hidden": self.hidden,
            "max_epochs": self.max_epochs,
            "patience": self.patience,
            "batch_size": self.batch_size,
            "learning_rate": self.learning_rate,
            "fit_rows": self.fit_rows,
            "seed": self.seed,
            "threads": self.threads,
            "DEVICE": "cpu",
            "deterministic_algorithms": True,
            "versions": {"torch": version("torch"), "numpy": version("numpy")},
        }

    def xǁLSTMAutoencoderǁsettings__mutmut_30(self) -> dict[str, Any]:
        if self._net is None:
            raise RuntimeError("the model is not fitted")
        return {
            **self._history,
            "converged": self._history["epochs_run"] < self.max_epochs,
            "window": self.window,
            "hidden": self.hidden,
            "max_epochs": self.max_epochs,
            "patience": self.patience,
            "batch_size": self.batch_size,
            "learning_rate": self.learning_rate,
            "fit_rows": self.fit_rows,
            "seed": self.seed,
            "threads": self.threads,
            "device": "XXcpuXX",
            "deterministic_algorithms": True,
            "versions": {"torch": version("torch"), "numpy": version("numpy")},
        }

    def xǁLSTMAutoencoderǁsettings__mutmut_31(self) -> dict[str, Any]:
        if self._net is None:
            raise RuntimeError("the model is not fitted")
        return {
            **self._history,
            "converged": self._history["epochs_run"] < self.max_epochs,
            "window": self.window,
            "hidden": self.hidden,
            "max_epochs": self.max_epochs,
            "patience": self.patience,
            "batch_size": self.batch_size,
            "learning_rate": self.learning_rate,
            "fit_rows": self.fit_rows,
            "seed": self.seed,
            "threads": self.threads,
            "device": "CPU",
            "deterministic_algorithms": True,
            "versions": {"torch": version("torch"), "numpy": version("numpy")},
        }

    def xǁLSTMAutoencoderǁsettings__mutmut_32(self) -> dict[str, Any]:
        if self._net is None:
            raise RuntimeError("the model is not fitted")
        return {
            **self._history,
            "converged": self._history["epochs_run"] < self.max_epochs,
            "window": self.window,
            "hidden": self.hidden,
            "max_epochs": self.max_epochs,
            "patience": self.patience,
            "batch_size": self.batch_size,
            "learning_rate": self.learning_rate,
            "fit_rows": self.fit_rows,
            "seed": self.seed,
            "threads": self.threads,
            "device": "cpu",
            "XXdeterministic_algorithmsXX": True,
            "versions": {"torch": version("torch"), "numpy": version("numpy")},
        }

    def xǁLSTMAutoencoderǁsettings__mutmut_33(self) -> dict[str, Any]:
        if self._net is None:
            raise RuntimeError("the model is not fitted")
        return {
            **self._history,
            "converged": self._history["epochs_run"] < self.max_epochs,
            "window": self.window,
            "hidden": self.hidden,
            "max_epochs": self.max_epochs,
            "patience": self.patience,
            "batch_size": self.batch_size,
            "learning_rate": self.learning_rate,
            "fit_rows": self.fit_rows,
            "seed": self.seed,
            "threads": self.threads,
            "device": "cpu",
            "DETERMINISTIC_ALGORITHMS": True,
            "versions": {"torch": version("torch"), "numpy": version("numpy")},
        }

    def xǁLSTMAutoencoderǁsettings__mutmut_34(self) -> dict[str, Any]:
        if self._net is None:
            raise RuntimeError("the model is not fitted")
        return {
            **self._history,
            "converged": self._history["epochs_run"] < self.max_epochs,
            "window": self.window,
            "hidden": self.hidden,
            "max_epochs": self.max_epochs,
            "patience": self.patience,
            "batch_size": self.batch_size,
            "learning_rate": self.learning_rate,
            "fit_rows": self.fit_rows,
            "seed": self.seed,
            "threads": self.threads,
            "device": "cpu",
            "deterministic_algorithms": False,
            "versions": {"torch": version("torch"), "numpy": version("numpy")},
        }

    def xǁLSTMAutoencoderǁsettings__mutmut_35(self) -> dict[str, Any]:
        if self._net is None:
            raise RuntimeError("the model is not fitted")
        return {
            **self._history,
            "converged": self._history["epochs_run"] < self.max_epochs,
            "window": self.window,
            "hidden": self.hidden,
            "max_epochs": self.max_epochs,
            "patience": self.patience,
            "batch_size": self.batch_size,
            "learning_rate": self.learning_rate,
            "fit_rows": self.fit_rows,
            "seed": self.seed,
            "threads": self.threads,
            "device": "cpu",
            "deterministic_algorithms": True,
            "XXversionsXX": {"torch": version("torch"), "numpy": version("numpy")},
        }

    def xǁLSTMAutoencoderǁsettings__mutmut_36(self) -> dict[str, Any]:
        if self._net is None:
            raise RuntimeError("the model is not fitted")
        return {
            **self._history,
            "converged": self._history["epochs_run"] < self.max_epochs,
            "window": self.window,
            "hidden": self.hidden,
            "max_epochs": self.max_epochs,
            "patience": self.patience,
            "batch_size": self.batch_size,
            "learning_rate": self.learning_rate,
            "fit_rows": self.fit_rows,
            "seed": self.seed,
            "threads": self.threads,
            "device": "cpu",
            "deterministic_algorithms": True,
            "VERSIONS": {"torch": version("torch"), "numpy": version("numpy")},
        }

    def xǁLSTMAutoencoderǁsettings__mutmut_37(self) -> dict[str, Any]:
        if self._net is None:
            raise RuntimeError("the model is not fitted")
        return {
            **self._history,
            "converged": self._history["epochs_run"] < self.max_epochs,
            "window": self.window,
            "hidden": self.hidden,
            "max_epochs": self.max_epochs,
            "patience": self.patience,
            "batch_size": self.batch_size,
            "learning_rate": self.learning_rate,
            "fit_rows": self.fit_rows,
            "seed": self.seed,
            "threads": self.threads,
            "device": "cpu",
            "deterministic_algorithms": True,
            "versions": {"XXtorchXX": version("torch"), "numpy": version("numpy")},
        }

    def xǁLSTMAutoencoderǁsettings__mutmut_38(self) -> dict[str, Any]:
        if self._net is None:
            raise RuntimeError("the model is not fitted")
        return {
            **self._history,
            "converged": self._history["epochs_run"] < self.max_epochs,
            "window": self.window,
            "hidden": self.hidden,
            "max_epochs": self.max_epochs,
            "patience": self.patience,
            "batch_size": self.batch_size,
            "learning_rate": self.learning_rate,
            "fit_rows": self.fit_rows,
            "seed": self.seed,
            "threads": self.threads,
            "device": "cpu",
            "deterministic_algorithms": True,
            "versions": {"TORCH": version("torch"), "numpy": version("numpy")},
        }

    def xǁLSTMAutoencoderǁsettings__mutmut_39(self) -> dict[str, Any]:
        if self._net is None:
            raise RuntimeError("the model is not fitted")
        return {
            **self._history,
            "converged": self._history["epochs_run"] < self.max_epochs,
            "window": self.window,
            "hidden": self.hidden,
            "max_epochs": self.max_epochs,
            "patience": self.patience,
            "batch_size": self.batch_size,
            "learning_rate": self.learning_rate,
            "fit_rows": self.fit_rows,
            "seed": self.seed,
            "threads": self.threads,
            "device": "cpu",
            "deterministic_algorithms": True,
            "versions": {"torch": version(None), "numpy": version("numpy")},
        }

    def xǁLSTMAutoencoderǁsettings__mutmut_40(self) -> dict[str, Any]:
        if self._net is None:
            raise RuntimeError("the model is not fitted")
        return {
            **self._history,
            "converged": self._history["epochs_run"] < self.max_epochs,
            "window": self.window,
            "hidden": self.hidden,
            "max_epochs": self.max_epochs,
            "patience": self.patience,
            "batch_size": self.batch_size,
            "learning_rate": self.learning_rate,
            "fit_rows": self.fit_rows,
            "seed": self.seed,
            "threads": self.threads,
            "device": "cpu",
            "deterministic_algorithms": True,
            "versions": {"torch": version("XXtorchXX"), "numpy": version("numpy")},
        }

    def xǁLSTMAutoencoderǁsettings__mutmut_41(self) -> dict[str, Any]:
        if self._net is None:
            raise RuntimeError("the model is not fitted")
        return {
            **self._history,
            "converged": self._history["epochs_run"] < self.max_epochs,
            "window": self.window,
            "hidden": self.hidden,
            "max_epochs": self.max_epochs,
            "patience": self.patience,
            "batch_size": self.batch_size,
            "learning_rate": self.learning_rate,
            "fit_rows": self.fit_rows,
            "seed": self.seed,
            "threads": self.threads,
            "device": "cpu",
            "deterministic_algorithms": True,
            "versions": {"torch": version("TORCH"), "numpy": version("numpy")},
        }

    def xǁLSTMAutoencoderǁsettings__mutmut_42(self) -> dict[str, Any]:
        if self._net is None:
            raise RuntimeError("the model is not fitted")
        return {
            **self._history,
            "converged": self._history["epochs_run"] < self.max_epochs,
            "window": self.window,
            "hidden": self.hidden,
            "max_epochs": self.max_epochs,
            "patience": self.patience,
            "batch_size": self.batch_size,
            "learning_rate": self.learning_rate,
            "fit_rows": self.fit_rows,
            "seed": self.seed,
            "threads": self.threads,
            "device": "cpu",
            "deterministic_algorithms": True,
            "versions": {"torch": version("torch"), "XXnumpyXX": version("numpy")},
        }

    def xǁLSTMAutoencoderǁsettings__mutmut_43(self) -> dict[str, Any]:
        if self._net is None:
            raise RuntimeError("the model is not fitted")
        return {
            **self._history,
            "converged": self._history["epochs_run"] < self.max_epochs,
            "window": self.window,
            "hidden": self.hidden,
            "max_epochs": self.max_epochs,
            "patience": self.patience,
            "batch_size": self.batch_size,
            "learning_rate": self.learning_rate,
            "fit_rows": self.fit_rows,
            "seed": self.seed,
            "threads": self.threads,
            "device": "cpu",
            "deterministic_algorithms": True,
            "versions": {"torch": version("torch"), "NUMPY": version("numpy")},
        }

    def xǁLSTMAutoencoderǁsettings__mutmut_44(self) -> dict[str, Any]:
        if self._net is None:
            raise RuntimeError("the model is not fitted")
        return {
            **self._history,
            "converged": self._history["epochs_run"] < self.max_epochs,
            "window": self.window,
            "hidden": self.hidden,
            "max_epochs": self.max_epochs,
            "patience": self.patience,
            "batch_size": self.batch_size,
            "learning_rate": self.learning_rate,
            "fit_rows": self.fit_rows,
            "seed": self.seed,
            "threads": self.threads,
            "device": "cpu",
            "deterministic_algorithms": True,
            "versions": {"torch": version("torch"), "numpy": version(None)},
        }

    def xǁLSTMAutoencoderǁsettings__mutmut_45(self) -> dict[str, Any]:
        if self._net is None:
            raise RuntimeError("the model is not fitted")
        return {
            **self._history,
            "converged": self._history["epochs_run"] < self.max_epochs,
            "window": self.window,
            "hidden": self.hidden,
            "max_epochs": self.max_epochs,
            "patience": self.patience,
            "batch_size": self.batch_size,
            "learning_rate": self.learning_rate,
            "fit_rows": self.fit_rows,
            "seed": self.seed,
            "threads": self.threads,
            "device": "cpu",
            "deterministic_algorithms": True,
            "versions": {"torch": version("torch"), "numpy": version("XXnumpyXX")},
        }

    def xǁLSTMAutoencoderǁsettings__mutmut_46(self) -> dict[str, Any]:
        if self._net is None:
            raise RuntimeError("the model is not fitted")
        return {
            **self._history,
            "converged": self._history["epochs_run"] < self.max_epochs,
            "window": self.window,
            "hidden": self.hidden,
            "max_epochs": self.max_epochs,
            "patience": self.patience,
            "batch_size": self.batch_size,
            "learning_rate": self.learning_rate,
            "fit_rows": self.fit_rows,
            "seed": self.seed,
            "threads": self.threads,
            "device": "cpu",
            "deterministic_algorithms": True,
            "versions": {"torch": version("torch"), "numpy": version("NUMPY")},
        }

mutants_xǁLSTMAutoencoderǁ__init____mutmut['_mutmut_orig'] = LSTMAutoencoder.xǁLSTMAutoencoderǁ__init____mutmut_orig # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁ__init____mutmut['xǁLSTMAutoencoderǁ__init____mutmut_1'] = LSTMAutoencoder.xǁLSTMAutoencoderǁ__init____mutmut_1 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁ__init____mutmut['xǁLSTMAutoencoderǁ__init____mutmut_2'] = LSTMAutoencoder.xǁLSTMAutoencoderǁ__init____mutmut_2 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁ__init____mutmut['xǁLSTMAutoencoderǁ__init____mutmut_3'] = LSTMAutoencoder.xǁLSTMAutoencoderǁ__init____mutmut_3 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁ__init____mutmut['xǁLSTMAutoencoderǁ__init____mutmut_4'] = LSTMAutoencoder.xǁLSTMAutoencoderǁ__init____mutmut_4 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁ__init____mutmut['xǁLSTMAutoencoderǁ__init____mutmut_5'] = LSTMAutoencoder.xǁLSTMAutoencoderǁ__init____mutmut_5 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁ__init____mutmut['xǁLSTMAutoencoderǁ__init____mutmut_6'] = LSTMAutoencoder.xǁLSTMAutoencoderǁ__init____mutmut_6 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁ__init____mutmut['xǁLSTMAutoencoderǁ__init____mutmut_7'] = LSTMAutoencoder.xǁLSTMAutoencoderǁ__init____mutmut_7 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁ__init____mutmut['xǁLSTMAutoencoderǁ__init____mutmut_8'] = LSTMAutoencoder.xǁLSTMAutoencoderǁ__init____mutmut_8 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁ__init____mutmut['xǁLSTMAutoencoderǁ__init____mutmut_9'] = LSTMAutoencoder.xǁLSTMAutoencoderǁ__init____mutmut_9 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁ__init____mutmut['xǁLSTMAutoencoderǁ__init____mutmut_10'] = LSTMAutoencoder.xǁLSTMAutoencoderǁ__init____mutmut_10 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁ__init____mutmut['xǁLSTMAutoencoderǁ__init____mutmut_11'] = LSTMAutoencoder.xǁLSTMAutoencoderǁ__init____mutmut_11 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁ__init____mutmut['xǁLSTMAutoencoderǁ__init____mutmut_12'] = LSTMAutoencoder.xǁLSTMAutoencoderǁ__init____mutmut_12 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁ__init____mutmut['xǁLSTMAutoencoderǁ__init____mutmut_13'] = LSTMAutoencoder.xǁLSTMAutoencoderǁ__init____mutmut_13 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁ__init____mutmut['xǁLSTMAutoencoderǁ__init____mutmut_14'] = LSTMAutoencoder.xǁLSTMAutoencoderǁ__init____mutmut_14 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁ__init____mutmut['xǁLSTMAutoencoderǁ__init____mutmut_15'] = LSTMAutoencoder.xǁLSTMAutoencoderǁ__init____mutmut_15 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁ__init____mutmut['xǁLSTMAutoencoderǁ__init____mutmut_16'] = LSTMAutoencoder.xǁLSTMAutoencoderǁ__init____mutmut_16 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁ__init____mutmut['xǁLSTMAutoencoderǁ__init____mutmut_17'] = LSTMAutoencoder.xǁLSTMAutoencoderǁ__init____mutmut_17 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁ__init____mutmut['xǁLSTMAutoencoderǁ__init____mutmut_18'] = LSTMAutoencoder.xǁLSTMAutoencoderǁ__init____mutmut_18 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁ__init____mutmut['xǁLSTMAutoencoderǁ__init____mutmut_19'] = LSTMAutoencoder.xǁLSTMAutoencoderǁ__init____mutmut_19 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁ__init____mutmut['xǁLSTMAutoencoderǁ__init____mutmut_20'] = LSTMAutoencoder.xǁLSTMAutoencoderǁ__init____mutmut_20 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁ__init____mutmut['xǁLSTMAutoencoderǁ__init____mutmut_21'] = LSTMAutoencoder.xǁLSTMAutoencoderǁ__init____mutmut_21 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁ__init____mutmut['xǁLSTMAutoencoderǁ__init____mutmut_22'] = LSTMAutoencoder.xǁLSTMAutoencoderǁ__init____mutmut_22 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁ__init____mutmut['xǁLSTMAutoencoderǁ__init____mutmut_23'] = LSTMAutoencoder.xǁLSTMAutoencoderǁ__init____mutmut_23 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁ__init____mutmut['xǁLSTMAutoencoderǁ__init____mutmut_24'] = LSTMAutoencoder.xǁLSTMAutoencoderǁ__init____mutmut_24 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁ__init____mutmut['xǁLSTMAutoencoderǁ__init____mutmut_25'] = LSTMAutoencoder.xǁLSTMAutoencoderǁ__init____mutmut_25 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁ__init____mutmut['xǁLSTMAutoencoderǁ__init____mutmut_26'] = LSTMAutoencoder.xǁLSTMAutoencoderǁ__init____mutmut_26 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁ__init____mutmut['xǁLSTMAutoencoderǁ__init____mutmut_27'] = LSTMAutoencoder.xǁLSTMAutoencoderǁ__init____mutmut_27 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁ__init____mutmut['xǁLSTMAutoencoderǁ__init____mutmut_28'] = LSTMAutoencoder.xǁLSTMAutoencoderǁ__init____mutmut_28 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁ__init____mutmut['xǁLSTMAutoencoderǁ__init____mutmut_29'] = LSTMAutoencoder.xǁLSTMAutoencoderǁ__init____mutmut_29 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁ__init____mutmut['xǁLSTMAutoencoderǁ__init____mutmut_30'] = LSTMAutoencoder.xǁLSTMAutoencoderǁ__init____mutmut_30 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁ__init____mutmut['xǁLSTMAutoencoderǁ__init____mutmut_31'] = LSTMAutoencoder.xǁLSTMAutoencoderǁ__init____mutmut_31 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁ__init____mutmut['xǁLSTMAutoencoderǁ__init____mutmut_32'] = LSTMAutoencoder.xǁLSTMAutoencoderǁ__init____mutmut_32 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁ__init____mutmut['xǁLSTMAutoencoderǁ__init____mutmut_33'] = LSTMAutoencoder.xǁLSTMAutoencoderǁ__init____mutmut_33 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁ__init____mutmut['xǁLSTMAutoencoderǁ__init____mutmut_34'] = LSTMAutoencoder.xǁLSTMAutoencoderǁ__init____mutmut_34 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁ__init____mutmut['xǁLSTMAutoencoderǁ__init____mutmut_35'] = LSTMAutoencoder.xǁLSTMAutoencoderǁ__init____mutmut_35 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁ__init____mutmut['xǁLSTMAutoencoderǁ__init____mutmut_36'] = LSTMAutoencoder.xǁLSTMAutoencoderǁ__init____mutmut_36 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁ__init____mutmut['xǁLSTMAutoencoderǁ__init____mutmut_37'] = LSTMAutoencoder.xǁLSTMAutoencoderǁ__init____mutmut_37 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁ__init____mutmut['xǁLSTMAutoencoderǁ__init____mutmut_38'] = LSTMAutoencoder.xǁLSTMAutoencoderǁ__init____mutmut_38 # type: ignore # mutmut generated

mutants_xǁLSTMAutoencoderǁ_windows__mutmut['_mutmut_orig'] = LSTMAutoencoder.xǁLSTMAutoencoderǁ_windows__mutmut_orig # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁ_windows__mutmut['xǁLSTMAutoencoderǁ_windows__mutmut_1'] = LSTMAutoencoder.xǁLSTMAutoencoderǁ_windows__mutmut_1 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁ_windows__mutmut['xǁLSTMAutoencoderǁ_windows__mutmut_2'] = LSTMAutoencoder.xǁLSTMAutoencoderǁ_windows__mutmut_2 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁ_windows__mutmut['xǁLSTMAutoencoderǁ_windows__mutmut_3'] = LSTMAutoencoder.xǁLSTMAutoencoderǁ_windows__mutmut_3 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁ_windows__mutmut['xǁLSTMAutoencoderǁ_windows__mutmut_4'] = LSTMAutoencoder.xǁLSTMAutoencoderǁ_windows__mutmut_4 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁ_windows__mutmut['xǁLSTMAutoencoderǁ_windows__mutmut_5'] = LSTMAutoencoder.xǁLSTMAutoencoderǁ_windows__mutmut_5 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁ_windows__mutmut['xǁLSTMAutoencoderǁ_windows__mutmut_6'] = LSTMAutoencoder.xǁLSTMAutoencoderǁ_windows__mutmut_6 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁ_windows__mutmut['xǁLSTMAutoencoderǁ_windows__mutmut_7'] = LSTMAutoencoder.xǁLSTMAutoencoderǁ_windows__mutmut_7 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁ_windows__mutmut['xǁLSTMAutoencoderǁ_windows__mutmut_8'] = LSTMAutoencoder.xǁLSTMAutoencoderǁ_windows__mutmut_8 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁ_windows__mutmut['xǁLSTMAutoencoderǁ_windows__mutmut_9'] = LSTMAutoencoder.xǁLSTMAutoencoderǁ_windows__mutmut_9 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁ_windows__mutmut['xǁLSTMAutoencoderǁ_windows__mutmut_10'] = LSTMAutoencoder.xǁLSTMAutoencoderǁ_windows__mutmut_10 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁ_windows__mutmut['xǁLSTMAutoencoderǁ_windows__mutmut_11'] = LSTMAutoencoder.xǁLSTMAutoencoderǁ_windows__mutmut_11 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁ_windows__mutmut['xǁLSTMAutoencoderǁ_windows__mutmut_12'] = LSTMAutoencoder.xǁLSTMAutoencoderǁ_windows__mutmut_12 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁ_windows__mutmut['xǁLSTMAutoencoderǁ_windows__mutmut_13'] = LSTMAutoencoder.xǁLSTMAutoencoderǁ_windows__mutmut_13 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁ_windows__mutmut['xǁLSTMAutoencoderǁ_windows__mutmut_14'] = LSTMAutoencoder.xǁLSTMAutoencoderǁ_windows__mutmut_14 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁ_windows__mutmut['xǁLSTMAutoencoderǁ_windows__mutmut_15'] = LSTMAutoencoder.xǁLSTMAutoencoderǁ_windows__mutmut_15 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁ_windows__mutmut['xǁLSTMAutoencoderǁ_windows__mutmut_16'] = LSTMAutoencoder.xǁLSTMAutoencoderǁ_windows__mutmut_16 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁ_windows__mutmut['xǁLSTMAutoencoderǁ_windows__mutmut_17'] = LSTMAutoencoder.xǁLSTMAutoencoderǁ_windows__mutmut_17 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁ_windows__mutmut['xǁLSTMAutoencoderǁ_windows__mutmut_18'] = LSTMAutoencoder.xǁLSTMAutoencoderǁ_windows__mutmut_18 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁ_windows__mutmut['xǁLSTMAutoencoderǁ_windows__mutmut_19'] = LSTMAutoencoder.xǁLSTMAutoencoderǁ_windows__mutmut_19 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁ_windows__mutmut['xǁLSTMAutoencoderǁ_windows__mutmut_20'] = LSTMAutoencoder.xǁLSTMAutoencoderǁ_windows__mutmut_20 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁ_windows__mutmut['xǁLSTMAutoencoderǁ_windows__mutmut_21'] = LSTMAutoencoder.xǁLSTMAutoencoderǁ_windows__mutmut_21 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁ_windows__mutmut['xǁLSTMAutoencoderǁ_windows__mutmut_22'] = LSTMAutoencoder.xǁLSTMAutoencoderǁ_windows__mutmut_22 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁ_windows__mutmut['xǁLSTMAutoencoderǁ_windows__mutmut_23'] = LSTMAutoencoder.xǁLSTMAutoencoderǁ_windows__mutmut_23 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁ_windows__mutmut['xǁLSTMAutoencoderǁ_windows__mutmut_24'] = LSTMAutoencoder.xǁLSTMAutoencoderǁ_windows__mutmut_24 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁ_windows__mutmut['xǁLSTMAutoencoderǁ_windows__mutmut_25'] = LSTMAutoencoder.xǁLSTMAutoencoderǁ_windows__mutmut_25 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁ_windows__mutmut['xǁLSTMAutoencoderǁ_windows__mutmut_26'] = LSTMAutoencoder.xǁLSTMAutoencoderǁ_windows__mutmut_26 # type: ignore # mutmut generated

mutants_xǁLSTMAutoencoderǁ_reconstruction_error__mutmut['_mutmut_orig'] = LSTMAutoencoder.xǁLSTMAutoencoderǁ_reconstruction_error__mutmut_orig # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁ_reconstruction_error__mutmut['xǁLSTMAutoencoderǁ_reconstruction_error__mutmut_1'] = LSTMAutoencoder.xǁLSTMAutoencoderǁ_reconstruction_error__mutmut_1 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁ_reconstruction_error__mutmut['xǁLSTMAutoencoderǁ_reconstruction_error__mutmut_2'] = LSTMAutoencoder.xǁLSTMAutoencoderǁ_reconstruction_error__mutmut_2 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁ_reconstruction_error__mutmut['xǁLSTMAutoencoderǁ_reconstruction_error__mutmut_3'] = LSTMAutoencoder.xǁLSTMAutoencoderǁ_reconstruction_error__mutmut_3 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁ_reconstruction_error__mutmut['xǁLSTMAutoencoderǁ_reconstruction_error__mutmut_4'] = LSTMAutoencoder.xǁLSTMAutoencoderǁ_reconstruction_error__mutmut_4 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁ_reconstruction_error__mutmut['xǁLSTMAutoencoderǁ_reconstruction_error__mutmut_5'] = LSTMAutoencoder.xǁLSTMAutoencoderǁ_reconstruction_error__mutmut_5 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁ_reconstruction_error__mutmut['xǁLSTMAutoencoderǁ_reconstruction_error__mutmut_6'] = LSTMAutoencoder.xǁLSTMAutoencoderǁ_reconstruction_error__mutmut_6 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁ_reconstruction_error__mutmut['xǁLSTMAutoencoderǁ_reconstruction_error__mutmut_7'] = LSTMAutoencoder.xǁLSTMAutoencoderǁ_reconstruction_error__mutmut_7 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁ_reconstruction_error__mutmut['xǁLSTMAutoencoderǁ_reconstruction_error__mutmut_8'] = LSTMAutoencoder.xǁLSTMAutoencoderǁ_reconstruction_error__mutmut_8 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁ_reconstruction_error__mutmut['xǁLSTMAutoencoderǁ_reconstruction_error__mutmut_9'] = LSTMAutoencoder.xǁLSTMAutoencoderǁ_reconstruction_error__mutmut_9 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁ_reconstruction_error__mutmut['xǁLSTMAutoencoderǁ_reconstruction_error__mutmut_10'] = LSTMAutoencoder.xǁLSTMAutoencoderǁ_reconstruction_error__mutmut_10 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁ_reconstruction_error__mutmut['xǁLSTMAutoencoderǁ_reconstruction_error__mutmut_11'] = LSTMAutoencoder.xǁLSTMAutoencoderǁ_reconstruction_error__mutmut_11 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁ_reconstruction_error__mutmut['xǁLSTMAutoencoderǁ_reconstruction_error__mutmut_12'] = LSTMAutoencoder.xǁLSTMAutoencoderǁ_reconstruction_error__mutmut_12 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁ_reconstruction_error__mutmut['xǁLSTMAutoencoderǁ_reconstruction_error__mutmut_13'] = LSTMAutoencoder.xǁLSTMAutoencoderǁ_reconstruction_error__mutmut_13 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁ_reconstruction_error__mutmut['xǁLSTMAutoencoderǁ_reconstruction_error__mutmut_14'] = LSTMAutoencoder.xǁLSTMAutoencoderǁ_reconstruction_error__mutmut_14 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁ_reconstruction_error__mutmut['xǁLSTMAutoencoderǁ_reconstruction_error__mutmut_15'] = LSTMAutoencoder.xǁLSTMAutoencoderǁ_reconstruction_error__mutmut_15 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁ_reconstruction_error__mutmut['xǁLSTMAutoencoderǁ_reconstruction_error__mutmut_16'] = LSTMAutoencoder.xǁLSTMAutoencoderǁ_reconstruction_error__mutmut_16 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁ_reconstruction_error__mutmut['xǁLSTMAutoencoderǁ_reconstruction_error__mutmut_17'] = LSTMAutoencoder.xǁLSTMAutoencoderǁ_reconstruction_error__mutmut_17 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁ_reconstruction_error__mutmut['xǁLSTMAutoencoderǁ_reconstruction_error__mutmut_18'] = LSTMAutoencoder.xǁLSTMAutoencoderǁ_reconstruction_error__mutmut_18 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁ_reconstruction_error__mutmut['xǁLSTMAutoencoderǁ_reconstruction_error__mutmut_19'] = LSTMAutoencoder.xǁLSTMAutoencoderǁ_reconstruction_error__mutmut_19 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁ_reconstruction_error__mutmut['xǁLSTMAutoencoderǁ_reconstruction_error__mutmut_20'] = LSTMAutoencoder.xǁLSTMAutoencoderǁ_reconstruction_error__mutmut_20 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁ_reconstruction_error__mutmut['xǁLSTMAutoencoderǁ_reconstruction_error__mutmut_21'] = LSTMAutoencoder.xǁLSTMAutoencoderǁ_reconstruction_error__mutmut_21 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁ_reconstruction_error__mutmut['xǁLSTMAutoencoderǁ_reconstruction_error__mutmut_22'] = LSTMAutoencoder.xǁLSTMAutoencoderǁ_reconstruction_error__mutmut_22 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁ_reconstruction_error__mutmut['xǁLSTMAutoencoderǁ_reconstruction_error__mutmut_23'] = LSTMAutoencoder.xǁLSTMAutoencoderǁ_reconstruction_error__mutmut_23 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁ_reconstruction_error__mutmut['xǁLSTMAutoencoderǁ_reconstruction_error__mutmut_24'] = LSTMAutoencoder.xǁLSTMAutoencoderǁ_reconstruction_error__mutmut_24 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁ_reconstruction_error__mutmut['xǁLSTMAutoencoderǁ_reconstruction_error__mutmut_25'] = LSTMAutoencoder.xǁLSTMAutoencoderǁ_reconstruction_error__mutmut_25 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁ_reconstruction_error__mutmut['xǁLSTMAutoencoderǁ_reconstruction_error__mutmut_26'] = LSTMAutoencoder.xǁLSTMAutoencoderǁ_reconstruction_error__mutmut_26 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁ_reconstruction_error__mutmut['xǁLSTMAutoencoderǁ_reconstruction_error__mutmut_27'] = LSTMAutoencoder.xǁLSTMAutoencoderǁ_reconstruction_error__mutmut_27 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁ_reconstruction_error__mutmut['xǁLSTMAutoencoderǁ_reconstruction_error__mutmut_28'] = LSTMAutoencoder.xǁLSTMAutoencoderǁ_reconstruction_error__mutmut_28 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁ_reconstruction_error__mutmut['xǁLSTMAutoencoderǁ_reconstruction_error__mutmut_29'] = LSTMAutoencoder.xǁLSTMAutoencoderǁ_reconstruction_error__mutmut_29 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁ_reconstruction_error__mutmut['xǁLSTMAutoencoderǁ_reconstruction_error__mutmut_30'] = LSTMAutoencoder.xǁLSTMAutoencoderǁ_reconstruction_error__mutmut_30 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁ_reconstruction_error__mutmut['xǁLSTMAutoencoderǁ_reconstruction_error__mutmut_31'] = LSTMAutoencoder.xǁLSTMAutoencoderǁ_reconstruction_error__mutmut_31 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁ_reconstruction_error__mutmut['xǁLSTMAutoencoderǁ_reconstruction_error__mutmut_32'] = LSTMAutoencoder.xǁLSTMAutoencoderǁ_reconstruction_error__mutmut_32 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁ_reconstruction_error__mutmut['xǁLSTMAutoencoderǁ_reconstruction_error__mutmut_33'] = LSTMAutoencoder.xǁLSTMAutoencoderǁ_reconstruction_error__mutmut_33 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁ_reconstruction_error__mutmut['xǁLSTMAutoencoderǁ_reconstruction_error__mutmut_34'] = LSTMAutoencoder.xǁLSTMAutoencoderǁ_reconstruction_error__mutmut_34 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁ_reconstruction_error__mutmut['xǁLSTMAutoencoderǁ_reconstruction_error__mutmut_35'] = LSTMAutoencoder.xǁLSTMAutoencoderǁ_reconstruction_error__mutmut_35 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁ_reconstruction_error__mutmut['xǁLSTMAutoencoderǁ_reconstruction_error__mutmut_36'] = LSTMAutoencoder.xǁLSTMAutoencoderǁ_reconstruction_error__mutmut_36 # type: ignore # mutmut generated

mutants_xǁLSTMAutoencoderǁfit__mutmut['_mutmut_orig'] = LSTMAutoencoder.xǁLSTMAutoencoderǁfit__mutmut_orig # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁfit__mutmut['xǁLSTMAutoencoderǁfit__mutmut_1'] = LSTMAutoencoder.xǁLSTMAutoencoderǁfit__mutmut_1 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁfit__mutmut['xǁLSTMAutoencoderǁfit__mutmut_2'] = LSTMAutoencoder.xǁLSTMAutoencoderǁfit__mutmut_2 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁfit__mutmut['xǁLSTMAutoencoderǁfit__mutmut_3'] = LSTMAutoencoder.xǁLSTMAutoencoderǁfit__mutmut_3 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁfit__mutmut['xǁLSTMAutoencoderǁfit__mutmut_4'] = LSTMAutoencoder.xǁLSTMAutoencoderǁfit__mutmut_4 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁfit__mutmut['xǁLSTMAutoencoderǁfit__mutmut_5'] = LSTMAutoencoder.xǁLSTMAutoencoderǁfit__mutmut_5 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁfit__mutmut['xǁLSTMAutoencoderǁfit__mutmut_6'] = LSTMAutoencoder.xǁLSTMAutoencoderǁfit__mutmut_6 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁfit__mutmut['xǁLSTMAutoencoderǁfit__mutmut_7'] = LSTMAutoencoder.xǁLSTMAutoencoderǁfit__mutmut_7 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁfit__mutmut['xǁLSTMAutoencoderǁfit__mutmut_8'] = LSTMAutoencoder.xǁLSTMAutoencoderǁfit__mutmut_8 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁfit__mutmut['xǁLSTMAutoencoderǁfit__mutmut_9'] = LSTMAutoencoder.xǁLSTMAutoencoderǁfit__mutmut_9 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁfit__mutmut['xǁLSTMAutoencoderǁfit__mutmut_10'] = LSTMAutoencoder.xǁLSTMAutoencoderǁfit__mutmut_10 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁfit__mutmut['xǁLSTMAutoencoderǁfit__mutmut_11'] = LSTMAutoencoder.xǁLSTMAutoencoderǁfit__mutmut_11 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁfit__mutmut['xǁLSTMAutoencoderǁfit__mutmut_12'] = LSTMAutoencoder.xǁLSTMAutoencoderǁfit__mutmut_12 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁfit__mutmut['xǁLSTMAutoencoderǁfit__mutmut_13'] = LSTMAutoencoder.xǁLSTMAutoencoderǁfit__mutmut_13 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁfit__mutmut['xǁLSTMAutoencoderǁfit__mutmut_14'] = LSTMAutoencoder.xǁLSTMAutoencoderǁfit__mutmut_14 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁfit__mutmut['xǁLSTMAutoencoderǁfit__mutmut_15'] = LSTMAutoencoder.xǁLSTMAutoencoderǁfit__mutmut_15 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁfit__mutmut['xǁLSTMAutoencoderǁfit__mutmut_16'] = LSTMAutoencoder.xǁLSTMAutoencoderǁfit__mutmut_16 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁfit__mutmut['xǁLSTMAutoencoderǁfit__mutmut_17'] = LSTMAutoencoder.xǁLSTMAutoencoderǁfit__mutmut_17 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁfit__mutmut['xǁLSTMAutoencoderǁfit__mutmut_18'] = LSTMAutoencoder.xǁLSTMAutoencoderǁfit__mutmut_18 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁfit__mutmut['xǁLSTMAutoencoderǁfit__mutmut_19'] = LSTMAutoencoder.xǁLSTMAutoencoderǁfit__mutmut_19 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁfit__mutmut['xǁLSTMAutoencoderǁfit__mutmut_20'] = LSTMAutoencoder.xǁLSTMAutoencoderǁfit__mutmut_20 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁfit__mutmut['xǁLSTMAutoencoderǁfit__mutmut_21'] = LSTMAutoencoder.xǁLSTMAutoencoderǁfit__mutmut_21 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁfit__mutmut['xǁLSTMAutoencoderǁfit__mutmut_22'] = LSTMAutoencoder.xǁLSTMAutoencoderǁfit__mutmut_22 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁfit__mutmut['xǁLSTMAutoencoderǁfit__mutmut_23'] = LSTMAutoencoder.xǁLSTMAutoencoderǁfit__mutmut_23 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁfit__mutmut['xǁLSTMAutoencoderǁfit__mutmut_24'] = LSTMAutoencoder.xǁLSTMAutoencoderǁfit__mutmut_24 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁfit__mutmut['xǁLSTMAutoencoderǁfit__mutmut_25'] = LSTMAutoencoder.xǁLSTMAutoencoderǁfit__mutmut_25 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁfit__mutmut['xǁLSTMAutoencoderǁfit__mutmut_26'] = LSTMAutoencoder.xǁLSTMAutoencoderǁfit__mutmut_26 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁfit__mutmut['xǁLSTMAutoencoderǁfit__mutmut_27'] = LSTMAutoencoder.xǁLSTMAutoencoderǁfit__mutmut_27 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁfit__mutmut['xǁLSTMAutoencoderǁfit__mutmut_28'] = LSTMAutoencoder.xǁLSTMAutoencoderǁfit__mutmut_28 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁfit__mutmut['xǁLSTMAutoencoderǁfit__mutmut_29'] = LSTMAutoencoder.xǁLSTMAutoencoderǁfit__mutmut_29 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁfit__mutmut['xǁLSTMAutoencoderǁfit__mutmut_30'] = LSTMAutoencoder.xǁLSTMAutoencoderǁfit__mutmut_30 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁfit__mutmut['xǁLSTMAutoencoderǁfit__mutmut_31'] = LSTMAutoencoder.xǁLSTMAutoencoderǁfit__mutmut_31 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁfit__mutmut['xǁLSTMAutoencoderǁfit__mutmut_32'] = LSTMAutoencoder.xǁLSTMAutoencoderǁfit__mutmut_32 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁfit__mutmut['xǁLSTMAutoencoderǁfit__mutmut_33'] = LSTMAutoencoder.xǁLSTMAutoencoderǁfit__mutmut_33 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁfit__mutmut['xǁLSTMAutoencoderǁfit__mutmut_34'] = LSTMAutoencoder.xǁLSTMAutoencoderǁfit__mutmut_34 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁfit__mutmut['xǁLSTMAutoencoderǁfit__mutmut_35'] = LSTMAutoencoder.xǁLSTMAutoencoderǁfit__mutmut_35 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁfit__mutmut['xǁLSTMAutoencoderǁfit__mutmut_36'] = LSTMAutoencoder.xǁLSTMAutoencoderǁfit__mutmut_36 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁfit__mutmut['xǁLSTMAutoencoderǁfit__mutmut_37'] = LSTMAutoencoder.xǁLSTMAutoencoderǁfit__mutmut_37 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁfit__mutmut['xǁLSTMAutoencoderǁfit__mutmut_38'] = LSTMAutoencoder.xǁLSTMAutoencoderǁfit__mutmut_38 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁfit__mutmut['xǁLSTMAutoencoderǁfit__mutmut_39'] = LSTMAutoencoder.xǁLSTMAutoencoderǁfit__mutmut_39 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁfit__mutmut['xǁLSTMAutoencoderǁfit__mutmut_40'] = LSTMAutoencoder.xǁLSTMAutoencoderǁfit__mutmut_40 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁfit__mutmut['xǁLSTMAutoencoderǁfit__mutmut_41'] = LSTMAutoencoder.xǁLSTMAutoencoderǁfit__mutmut_41 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁfit__mutmut['xǁLSTMAutoencoderǁfit__mutmut_42'] = LSTMAutoencoder.xǁLSTMAutoencoderǁfit__mutmut_42 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁfit__mutmut['xǁLSTMAutoencoderǁfit__mutmut_43'] = LSTMAutoencoder.xǁLSTMAutoencoderǁfit__mutmut_43 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁfit__mutmut['xǁLSTMAutoencoderǁfit__mutmut_44'] = LSTMAutoencoder.xǁLSTMAutoencoderǁfit__mutmut_44 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁfit__mutmut['xǁLSTMAutoencoderǁfit__mutmut_45'] = LSTMAutoencoder.xǁLSTMAutoencoderǁfit__mutmut_45 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁfit__mutmut['xǁLSTMAutoencoderǁfit__mutmut_46'] = LSTMAutoencoder.xǁLSTMAutoencoderǁfit__mutmut_46 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁfit__mutmut['xǁLSTMAutoencoderǁfit__mutmut_47'] = LSTMAutoencoder.xǁLSTMAutoencoderǁfit__mutmut_47 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁfit__mutmut['xǁLSTMAutoencoderǁfit__mutmut_48'] = LSTMAutoencoder.xǁLSTMAutoencoderǁfit__mutmut_48 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁfit__mutmut['xǁLSTMAutoencoderǁfit__mutmut_49'] = LSTMAutoencoder.xǁLSTMAutoencoderǁfit__mutmut_49 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁfit__mutmut['xǁLSTMAutoencoderǁfit__mutmut_50'] = LSTMAutoencoder.xǁLSTMAutoencoderǁfit__mutmut_50 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁfit__mutmut['xǁLSTMAutoencoderǁfit__mutmut_51'] = LSTMAutoencoder.xǁLSTMAutoencoderǁfit__mutmut_51 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁfit__mutmut['xǁLSTMAutoencoderǁfit__mutmut_52'] = LSTMAutoencoder.xǁLSTMAutoencoderǁfit__mutmut_52 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁfit__mutmut['xǁLSTMAutoencoderǁfit__mutmut_53'] = LSTMAutoencoder.xǁLSTMAutoencoderǁfit__mutmut_53 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁfit__mutmut['xǁLSTMAutoencoderǁfit__mutmut_54'] = LSTMAutoencoder.xǁLSTMAutoencoderǁfit__mutmut_54 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁfit__mutmut['xǁLSTMAutoencoderǁfit__mutmut_55'] = LSTMAutoencoder.xǁLSTMAutoencoderǁfit__mutmut_55 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁfit__mutmut['xǁLSTMAutoencoderǁfit__mutmut_56'] = LSTMAutoencoder.xǁLSTMAutoencoderǁfit__mutmut_56 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁfit__mutmut['xǁLSTMAutoencoderǁfit__mutmut_57'] = LSTMAutoencoder.xǁLSTMAutoencoderǁfit__mutmut_57 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁfit__mutmut['xǁLSTMAutoencoderǁfit__mutmut_58'] = LSTMAutoencoder.xǁLSTMAutoencoderǁfit__mutmut_58 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁfit__mutmut['xǁLSTMAutoencoderǁfit__mutmut_59'] = LSTMAutoencoder.xǁLSTMAutoencoderǁfit__mutmut_59 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁfit__mutmut['xǁLSTMAutoencoderǁfit__mutmut_60'] = LSTMAutoencoder.xǁLSTMAutoencoderǁfit__mutmut_60 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁfit__mutmut['xǁLSTMAutoencoderǁfit__mutmut_61'] = LSTMAutoencoder.xǁLSTMAutoencoderǁfit__mutmut_61 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁfit__mutmut['xǁLSTMAutoencoderǁfit__mutmut_62'] = LSTMAutoencoder.xǁLSTMAutoencoderǁfit__mutmut_62 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁfit__mutmut['xǁLSTMAutoencoderǁfit__mutmut_63'] = LSTMAutoencoder.xǁLSTMAutoencoderǁfit__mutmut_63 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁfit__mutmut['xǁLSTMAutoencoderǁfit__mutmut_64'] = LSTMAutoencoder.xǁLSTMAutoencoderǁfit__mutmut_64 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁfit__mutmut['xǁLSTMAutoencoderǁfit__mutmut_65'] = LSTMAutoencoder.xǁLSTMAutoencoderǁfit__mutmut_65 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁfit__mutmut['xǁLSTMAutoencoderǁfit__mutmut_66'] = LSTMAutoencoder.xǁLSTMAutoencoderǁfit__mutmut_66 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁfit__mutmut['xǁLSTMAutoencoderǁfit__mutmut_67'] = LSTMAutoencoder.xǁLSTMAutoencoderǁfit__mutmut_67 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁfit__mutmut['xǁLSTMAutoencoderǁfit__mutmut_68'] = LSTMAutoencoder.xǁLSTMAutoencoderǁfit__mutmut_68 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁfit__mutmut['xǁLSTMAutoencoderǁfit__mutmut_69'] = LSTMAutoencoder.xǁLSTMAutoencoderǁfit__mutmut_69 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁfit__mutmut['xǁLSTMAutoencoderǁfit__mutmut_70'] = LSTMAutoencoder.xǁLSTMAutoencoderǁfit__mutmut_70 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁfit__mutmut['xǁLSTMAutoencoderǁfit__mutmut_71'] = LSTMAutoencoder.xǁLSTMAutoencoderǁfit__mutmut_71 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁfit__mutmut['xǁLSTMAutoencoderǁfit__mutmut_72'] = LSTMAutoencoder.xǁLSTMAutoencoderǁfit__mutmut_72 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁfit__mutmut['xǁLSTMAutoencoderǁfit__mutmut_73'] = LSTMAutoencoder.xǁLSTMAutoencoderǁfit__mutmut_73 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁfit__mutmut['xǁLSTMAutoencoderǁfit__mutmut_74'] = LSTMAutoencoder.xǁLSTMAutoencoderǁfit__mutmut_74 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁfit__mutmut['xǁLSTMAutoencoderǁfit__mutmut_75'] = LSTMAutoencoder.xǁLSTMAutoencoderǁfit__mutmut_75 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁfit__mutmut['xǁLSTMAutoencoderǁfit__mutmut_76'] = LSTMAutoencoder.xǁLSTMAutoencoderǁfit__mutmut_76 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁfit__mutmut['xǁLSTMAutoencoderǁfit__mutmut_77'] = LSTMAutoencoder.xǁLSTMAutoencoderǁfit__mutmut_77 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁfit__mutmut['xǁLSTMAutoencoderǁfit__mutmut_78'] = LSTMAutoencoder.xǁLSTMAutoencoderǁfit__mutmut_78 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁfit__mutmut['xǁLSTMAutoencoderǁfit__mutmut_79'] = LSTMAutoencoder.xǁLSTMAutoencoderǁfit__mutmut_79 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁfit__mutmut['xǁLSTMAutoencoderǁfit__mutmut_80'] = LSTMAutoencoder.xǁLSTMAutoencoderǁfit__mutmut_80 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁfit__mutmut['xǁLSTMAutoencoderǁfit__mutmut_81'] = LSTMAutoencoder.xǁLSTMAutoencoderǁfit__mutmut_81 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁfit__mutmut['xǁLSTMAutoencoderǁfit__mutmut_82'] = LSTMAutoencoder.xǁLSTMAutoencoderǁfit__mutmut_82 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁfit__mutmut['xǁLSTMAutoencoderǁfit__mutmut_83'] = LSTMAutoencoder.xǁLSTMAutoencoderǁfit__mutmut_83 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁfit__mutmut['xǁLSTMAutoencoderǁfit__mutmut_84'] = LSTMAutoencoder.xǁLSTMAutoencoderǁfit__mutmut_84 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁfit__mutmut['xǁLSTMAutoencoderǁfit__mutmut_85'] = LSTMAutoencoder.xǁLSTMAutoencoderǁfit__mutmut_85 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁfit__mutmut['xǁLSTMAutoencoderǁfit__mutmut_86'] = LSTMAutoencoder.xǁLSTMAutoencoderǁfit__mutmut_86 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁfit__mutmut['xǁLSTMAutoencoderǁfit__mutmut_87'] = LSTMAutoencoder.xǁLSTMAutoencoderǁfit__mutmut_87 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁfit__mutmut['xǁLSTMAutoencoderǁfit__mutmut_88'] = LSTMAutoencoder.xǁLSTMAutoencoderǁfit__mutmut_88 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁfit__mutmut['xǁLSTMAutoencoderǁfit__mutmut_89'] = LSTMAutoencoder.xǁLSTMAutoencoderǁfit__mutmut_89 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁfit__mutmut['xǁLSTMAutoencoderǁfit__mutmut_90'] = LSTMAutoencoder.xǁLSTMAutoencoderǁfit__mutmut_90 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁfit__mutmut['xǁLSTMAutoencoderǁfit__mutmut_91'] = LSTMAutoencoder.xǁLSTMAutoencoderǁfit__mutmut_91 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁfit__mutmut['xǁLSTMAutoencoderǁfit__mutmut_92'] = LSTMAutoencoder.xǁLSTMAutoencoderǁfit__mutmut_92 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁfit__mutmut['xǁLSTMAutoencoderǁfit__mutmut_93'] = LSTMAutoencoder.xǁLSTMAutoencoderǁfit__mutmut_93 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁfit__mutmut['xǁLSTMAutoencoderǁfit__mutmut_94'] = LSTMAutoencoder.xǁLSTMAutoencoderǁfit__mutmut_94 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁfit__mutmut['xǁLSTMAutoencoderǁfit__mutmut_95'] = LSTMAutoencoder.xǁLSTMAutoencoderǁfit__mutmut_95 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁfit__mutmut['xǁLSTMAutoencoderǁfit__mutmut_96'] = LSTMAutoencoder.xǁLSTMAutoencoderǁfit__mutmut_96 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁfit__mutmut['xǁLSTMAutoencoderǁfit__mutmut_97'] = LSTMAutoencoder.xǁLSTMAutoencoderǁfit__mutmut_97 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁfit__mutmut['xǁLSTMAutoencoderǁfit__mutmut_98'] = LSTMAutoencoder.xǁLSTMAutoencoderǁfit__mutmut_98 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁfit__mutmut['xǁLSTMAutoencoderǁfit__mutmut_99'] = LSTMAutoencoder.xǁLSTMAutoencoderǁfit__mutmut_99 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁfit__mutmut['xǁLSTMAutoencoderǁfit__mutmut_100'] = LSTMAutoencoder.xǁLSTMAutoencoderǁfit__mutmut_100 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁfit__mutmut['xǁLSTMAutoencoderǁfit__mutmut_101'] = LSTMAutoencoder.xǁLSTMAutoencoderǁfit__mutmut_101 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁfit__mutmut['xǁLSTMAutoencoderǁfit__mutmut_102'] = LSTMAutoencoder.xǁLSTMAutoencoderǁfit__mutmut_102 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁfit__mutmut['xǁLSTMAutoencoderǁfit__mutmut_103'] = LSTMAutoencoder.xǁLSTMAutoencoderǁfit__mutmut_103 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁfit__mutmut['xǁLSTMAutoencoderǁfit__mutmut_104'] = LSTMAutoencoder.xǁLSTMAutoencoderǁfit__mutmut_104 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁfit__mutmut['xǁLSTMAutoencoderǁfit__mutmut_105'] = LSTMAutoencoder.xǁLSTMAutoencoderǁfit__mutmut_105 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁfit__mutmut['xǁLSTMAutoencoderǁfit__mutmut_106'] = LSTMAutoencoder.xǁLSTMAutoencoderǁfit__mutmut_106 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁfit__mutmut['xǁLSTMAutoencoderǁfit__mutmut_107'] = LSTMAutoencoder.xǁLSTMAutoencoderǁfit__mutmut_107 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁfit__mutmut['xǁLSTMAutoencoderǁfit__mutmut_108'] = LSTMAutoencoder.xǁLSTMAutoencoderǁfit__mutmut_108 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁfit__mutmut['xǁLSTMAutoencoderǁfit__mutmut_109'] = LSTMAutoencoder.xǁLSTMAutoencoderǁfit__mutmut_109 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁfit__mutmut['xǁLSTMAutoencoderǁfit__mutmut_110'] = LSTMAutoencoder.xǁLSTMAutoencoderǁfit__mutmut_110 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁfit__mutmut['xǁLSTMAutoencoderǁfit__mutmut_111'] = LSTMAutoencoder.xǁLSTMAutoencoderǁfit__mutmut_111 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁfit__mutmut['xǁLSTMAutoencoderǁfit__mutmut_112'] = LSTMAutoencoder.xǁLSTMAutoencoderǁfit__mutmut_112 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁfit__mutmut['xǁLSTMAutoencoderǁfit__mutmut_113'] = LSTMAutoencoder.xǁLSTMAutoencoderǁfit__mutmut_113 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁfit__mutmut['xǁLSTMAutoencoderǁfit__mutmut_114'] = LSTMAutoencoder.xǁLSTMAutoencoderǁfit__mutmut_114 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁfit__mutmut['xǁLSTMAutoencoderǁfit__mutmut_115'] = LSTMAutoencoder.xǁLSTMAutoencoderǁfit__mutmut_115 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁfit__mutmut['xǁLSTMAutoencoderǁfit__mutmut_116'] = LSTMAutoencoder.xǁLSTMAutoencoderǁfit__mutmut_116 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁfit__mutmut['xǁLSTMAutoencoderǁfit__mutmut_117'] = LSTMAutoencoder.xǁLSTMAutoencoderǁfit__mutmut_117 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁfit__mutmut['xǁLSTMAutoencoderǁfit__mutmut_118'] = LSTMAutoencoder.xǁLSTMAutoencoderǁfit__mutmut_118 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁfit__mutmut['xǁLSTMAutoencoderǁfit__mutmut_119'] = LSTMAutoencoder.xǁLSTMAutoencoderǁfit__mutmut_119 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁfit__mutmut['xǁLSTMAutoencoderǁfit__mutmut_120'] = LSTMAutoencoder.xǁLSTMAutoencoderǁfit__mutmut_120 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁfit__mutmut['xǁLSTMAutoencoderǁfit__mutmut_121'] = LSTMAutoencoder.xǁLSTMAutoencoderǁfit__mutmut_121 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁfit__mutmut['xǁLSTMAutoencoderǁfit__mutmut_122'] = LSTMAutoencoder.xǁLSTMAutoencoderǁfit__mutmut_122 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁfit__mutmut['xǁLSTMAutoencoderǁfit__mutmut_123'] = LSTMAutoencoder.xǁLSTMAutoencoderǁfit__mutmut_123 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁfit__mutmut['xǁLSTMAutoencoderǁfit__mutmut_124'] = LSTMAutoencoder.xǁLSTMAutoencoderǁfit__mutmut_124 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁfit__mutmut['xǁLSTMAutoencoderǁfit__mutmut_125'] = LSTMAutoencoder.xǁLSTMAutoencoderǁfit__mutmut_125 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁfit__mutmut['xǁLSTMAutoencoderǁfit__mutmut_126'] = LSTMAutoencoder.xǁLSTMAutoencoderǁfit__mutmut_126 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁfit__mutmut['xǁLSTMAutoencoderǁfit__mutmut_127'] = LSTMAutoencoder.xǁLSTMAutoencoderǁfit__mutmut_127 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁfit__mutmut['xǁLSTMAutoencoderǁfit__mutmut_128'] = LSTMAutoencoder.xǁLSTMAutoencoderǁfit__mutmut_128 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁfit__mutmut['xǁLSTMAutoencoderǁfit__mutmut_129'] = LSTMAutoencoder.xǁLSTMAutoencoderǁfit__mutmut_129 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁfit__mutmut['xǁLSTMAutoencoderǁfit__mutmut_130'] = LSTMAutoencoder.xǁLSTMAutoencoderǁfit__mutmut_130 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁfit__mutmut['xǁLSTMAutoencoderǁfit__mutmut_131'] = LSTMAutoencoder.xǁLSTMAutoencoderǁfit__mutmut_131 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁfit__mutmut['xǁLSTMAutoencoderǁfit__mutmut_132'] = LSTMAutoencoder.xǁLSTMAutoencoderǁfit__mutmut_132 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁfit__mutmut['xǁLSTMAutoencoderǁfit__mutmut_133'] = LSTMAutoencoder.xǁLSTMAutoencoderǁfit__mutmut_133 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁfit__mutmut['xǁLSTMAutoencoderǁfit__mutmut_134'] = LSTMAutoencoder.xǁLSTMAutoencoderǁfit__mutmut_134 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁfit__mutmut['xǁLSTMAutoencoderǁfit__mutmut_135'] = LSTMAutoencoder.xǁLSTMAutoencoderǁfit__mutmut_135 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁfit__mutmut['xǁLSTMAutoencoderǁfit__mutmut_136'] = LSTMAutoencoder.xǁLSTMAutoencoderǁfit__mutmut_136 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁfit__mutmut['xǁLSTMAutoencoderǁfit__mutmut_137'] = LSTMAutoencoder.xǁLSTMAutoencoderǁfit__mutmut_137 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁfit__mutmut['xǁLSTMAutoencoderǁfit__mutmut_138'] = LSTMAutoencoder.xǁLSTMAutoencoderǁfit__mutmut_138 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁfit__mutmut['xǁLSTMAutoencoderǁfit__mutmut_139'] = LSTMAutoencoder.xǁLSTMAutoencoderǁfit__mutmut_139 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁfit__mutmut['xǁLSTMAutoencoderǁfit__mutmut_140'] = LSTMAutoencoder.xǁLSTMAutoencoderǁfit__mutmut_140 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁfit__mutmut['xǁLSTMAutoencoderǁfit__mutmut_141'] = LSTMAutoencoder.xǁLSTMAutoencoderǁfit__mutmut_141 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁfit__mutmut['xǁLSTMAutoencoderǁfit__mutmut_142'] = LSTMAutoencoder.xǁLSTMAutoencoderǁfit__mutmut_142 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁfit__mutmut['xǁLSTMAutoencoderǁfit__mutmut_143'] = LSTMAutoencoder.xǁLSTMAutoencoderǁfit__mutmut_143 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁfit__mutmut['xǁLSTMAutoencoderǁfit__mutmut_144'] = LSTMAutoencoder.xǁLSTMAutoencoderǁfit__mutmut_144 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁfit__mutmut['xǁLSTMAutoencoderǁfit__mutmut_145'] = LSTMAutoencoder.xǁLSTMAutoencoderǁfit__mutmut_145 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁfit__mutmut['xǁLSTMAutoencoderǁfit__mutmut_146'] = LSTMAutoencoder.xǁLSTMAutoencoderǁfit__mutmut_146 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁfit__mutmut['xǁLSTMAutoencoderǁfit__mutmut_147'] = LSTMAutoencoder.xǁLSTMAutoencoderǁfit__mutmut_147 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁfit__mutmut['xǁLSTMAutoencoderǁfit__mutmut_148'] = LSTMAutoencoder.xǁLSTMAutoencoderǁfit__mutmut_148 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁfit__mutmut['xǁLSTMAutoencoderǁfit__mutmut_149'] = LSTMAutoencoder.xǁLSTMAutoencoderǁfit__mutmut_149 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁfit__mutmut['xǁLSTMAutoencoderǁfit__mutmut_150'] = LSTMAutoencoder.xǁLSTMAutoencoderǁfit__mutmut_150 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁfit__mutmut['xǁLSTMAutoencoderǁfit__mutmut_151'] = LSTMAutoencoder.xǁLSTMAutoencoderǁfit__mutmut_151 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁfit__mutmut['xǁLSTMAutoencoderǁfit__mutmut_152'] = LSTMAutoencoder.xǁLSTMAutoencoderǁfit__mutmut_152 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁfit__mutmut['xǁLSTMAutoencoderǁfit__mutmut_153'] = LSTMAutoencoder.xǁLSTMAutoencoderǁfit__mutmut_153 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁfit__mutmut['xǁLSTMAutoencoderǁfit__mutmut_154'] = LSTMAutoencoder.xǁLSTMAutoencoderǁfit__mutmut_154 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁfit__mutmut['xǁLSTMAutoencoderǁfit__mutmut_155'] = LSTMAutoencoder.xǁLSTMAutoencoderǁfit__mutmut_155 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁfit__mutmut['xǁLSTMAutoencoderǁfit__mutmut_156'] = LSTMAutoencoder.xǁLSTMAutoencoderǁfit__mutmut_156 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁfit__mutmut['xǁLSTMAutoencoderǁfit__mutmut_157'] = LSTMAutoencoder.xǁLSTMAutoencoderǁfit__mutmut_157 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁfit__mutmut['xǁLSTMAutoencoderǁfit__mutmut_158'] = LSTMAutoencoder.xǁLSTMAutoencoderǁfit__mutmut_158 # type: ignore # mutmut generated

mutants_xǁLSTMAutoencoderǁvalidation_loss_now__mutmut['_mutmut_orig'] = LSTMAutoencoder.xǁLSTMAutoencoderǁvalidation_loss_now__mutmut_orig # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁvalidation_loss_now__mutmut['xǁLSTMAutoencoderǁvalidation_loss_now__mutmut_1'] = LSTMAutoencoder.xǁLSTMAutoencoderǁvalidation_loss_now__mutmut_1 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁvalidation_loss_now__mutmut['xǁLSTMAutoencoderǁvalidation_loss_now__mutmut_2'] = LSTMAutoencoder.xǁLSTMAutoencoderǁvalidation_loss_now__mutmut_2 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁvalidation_loss_now__mutmut['xǁLSTMAutoencoderǁvalidation_loss_now__mutmut_3'] = LSTMAutoencoder.xǁLSTMAutoencoderǁvalidation_loss_now__mutmut_3 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁvalidation_loss_now__mutmut['xǁLSTMAutoencoderǁvalidation_loss_now__mutmut_4'] = LSTMAutoencoder.xǁLSTMAutoencoderǁvalidation_loss_now__mutmut_4 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁvalidation_loss_now__mutmut['xǁLSTMAutoencoderǁvalidation_loss_now__mutmut_5'] = LSTMAutoencoder.xǁLSTMAutoencoderǁvalidation_loss_now__mutmut_5 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁvalidation_loss_now__mutmut['xǁLSTMAutoencoderǁvalidation_loss_now__mutmut_6'] = LSTMAutoencoder.xǁLSTMAutoencoderǁvalidation_loss_now__mutmut_6 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁvalidation_loss_now__mutmut['xǁLSTMAutoencoderǁvalidation_loss_now__mutmut_7'] = LSTMAutoencoder.xǁLSTMAutoencoderǁvalidation_loss_now__mutmut_7 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁvalidation_loss_now__mutmut['xǁLSTMAutoencoderǁvalidation_loss_now__mutmut_8'] = LSTMAutoencoder.xǁLSTMAutoencoderǁvalidation_loss_now__mutmut_8 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁvalidation_loss_now__mutmut['xǁLSTMAutoencoderǁvalidation_loss_now__mutmut_9'] = LSTMAutoencoder.xǁLSTMAutoencoderǁvalidation_loss_now__mutmut_9 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁvalidation_loss_now__mutmut['xǁLSTMAutoencoderǁvalidation_loss_now__mutmut_10'] = LSTMAutoencoder.xǁLSTMAutoencoderǁvalidation_loss_now__mutmut_10 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁvalidation_loss_now__mutmut['xǁLSTMAutoencoderǁvalidation_loss_now__mutmut_11'] = LSTMAutoencoder.xǁLSTMAutoencoderǁvalidation_loss_now__mutmut_11 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁvalidation_loss_now__mutmut['xǁLSTMAutoencoderǁvalidation_loss_now__mutmut_12'] = LSTMAutoencoder.xǁLSTMAutoencoderǁvalidation_loss_now__mutmut_12 # type: ignore # mutmut generated

mutants_xǁLSTMAutoencoderǁscore__mutmut['_mutmut_orig'] = LSTMAutoencoder.xǁLSTMAutoencoderǁscore__mutmut_orig # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁscore__mutmut['xǁLSTMAutoencoderǁscore__mutmut_1'] = LSTMAutoencoder.xǁLSTMAutoencoderǁscore__mutmut_1 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁscore__mutmut['xǁLSTMAutoencoderǁscore__mutmut_2'] = LSTMAutoencoder.xǁLSTMAutoencoderǁscore__mutmut_2 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁscore__mutmut['xǁLSTMAutoencoderǁscore__mutmut_3'] = LSTMAutoencoder.xǁLSTMAutoencoderǁscore__mutmut_3 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁscore__mutmut['xǁLSTMAutoencoderǁscore__mutmut_4'] = LSTMAutoencoder.xǁLSTMAutoencoderǁscore__mutmut_4 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁscore__mutmut['xǁLSTMAutoencoderǁscore__mutmut_5'] = LSTMAutoencoder.xǁLSTMAutoencoderǁscore__mutmut_5 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁscore__mutmut['xǁLSTMAutoencoderǁscore__mutmut_6'] = LSTMAutoencoder.xǁLSTMAutoencoderǁscore__mutmut_6 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁscore__mutmut['xǁLSTMAutoencoderǁscore__mutmut_7'] = LSTMAutoencoder.xǁLSTMAutoencoderǁscore__mutmut_7 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁscore__mutmut['xǁLSTMAutoencoderǁscore__mutmut_8'] = LSTMAutoencoder.xǁLSTMAutoencoderǁscore__mutmut_8 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁscore__mutmut['xǁLSTMAutoencoderǁscore__mutmut_9'] = LSTMAutoencoder.xǁLSTMAutoencoderǁscore__mutmut_9 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁscore__mutmut['xǁLSTMAutoencoderǁscore__mutmut_10'] = LSTMAutoencoder.xǁLSTMAutoencoderǁscore__mutmut_10 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁscore__mutmut['xǁLSTMAutoencoderǁscore__mutmut_11'] = LSTMAutoencoder.xǁLSTMAutoencoderǁscore__mutmut_11 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁscore__mutmut['xǁLSTMAutoencoderǁscore__mutmut_12'] = LSTMAutoencoder.xǁLSTMAutoencoderǁscore__mutmut_12 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁscore__mutmut['xǁLSTMAutoencoderǁscore__mutmut_13'] = LSTMAutoencoder.xǁLSTMAutoencoderǁscore__mutmut_13 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁscore__mutmut['xǁLSTMAutoencoderǁscore__mutmut_14'] = LSTMAutoencoder.xǁLSTMAutoencoderǁscore__mutmut_14 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁscore__mutmut['xǁLSTMAutoencoderǁscore__mutmut_15'] = LSTMAutoencoder.xǁLSTMAutoencoderǁscore__mutmut_15 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁscore__mutmut['xǁLSTMAutoencoderǁscore__mutmut_16'] = LSTMAutoencoder.xǁLSTMAutoencoderǁscore__mutmut_16 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁscore__mutmut['xǁLSTMAutoencoderǁscore__mutmut_17'] = LSTMAutoencoder.xǁLSTMAutoencoderǁscore__mutmut_17 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁscore__mutmut['xǁLSTMAutoencoderǁscore__mutmut_18'] = LSTMAutoencoder.xǁLSTMAutoencoderǁscore__mutmut_18 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁscore__mutmut['xǁLSTMAutoencoderǁscore__mutmut_19'] = LSTMAutoencoder.xǁLSTMAutoencoderǁscore__mutmut_19 # type: ignore # mutmut generated

mutants_xǁLSTMAutoencoderǁflags__mutmut['_mutmut_orig'] = LSTMAutoencoder.xǁLSTMAutoencoderǁflags__mutmut_orig # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁflags__mutmut['xǁLSTMAutoencoderǁflags__mutmut_1'] = LSTMAutoencoder.xǁLSTMAutoencoderǁflags__mutmut_1 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁflags__mutmut['xǁLSTMAutoencoderǁflags__mutmut_2'] = LSTMAutoencoder.xǁLSTMAutoencoderǁflags__mutmut_2 # type: ignore # mutmut generated

mutants_xǁLSTMAutoencoderǁsettings__mutmut['_mutmut_orig'] = LSTMAutoencoder.xǁLSTMAutoencoderǁsettings__mutmut_orig # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁsettings__mutmut['xǁLSTMAutoencoderǁsettings__mutmut_1'] = LSTMAutoencoder.xǁLSTMAutoencoderǁsettings__mutmut_1 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁsettings__mutmut['xǁLSTMAutoencoderǁsettings__mutmut_2'] = LSTMAutoencoder.xǁLSTMAutoencoderǁsettings__mutmut_2 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁsettings__mutmut['xǁLSTMAutoencoderǁsettings__mutmut_3'] = LSTMAutoencoder.xǁLSTMAutoencoderǁsettings__mutmut_3 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁsettings__mutmut['xǁLSTMAutoencoderǁsettings__mutmut_4'] = LSTMAutoencoder.xǁLSTMAutoencoderǁsettings__mutmut_4 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁsettings__mutmut['xǁLSTMAutoencoderǁsettings__mutmut_5'] = LSTMAutoencoder.xǁLSTMAutoencoderǁsettings__mutmut_5 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁsettings__mutmut['xǁLSTMAutoencoderǁsettings__mutmut_6'] = LSTMAutoencoder.xǁLSTMAutoencoderǁsettings__mutmut_6 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁsettings__mutmut['xǁLSTMAutoencoderǁsettings__mutmut_7'] = LSTMAutoencoder.xǁLSTMAutoencoderǁsettings__mutmut_7 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁsettings__mutmut['xǁLSTMAutoencoderǁsettings__mutmut_8'] = LSTMAutoencoder.xǁLSTMAutoencoderǁsettings__mutmut_8 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁsettings__mutmut['xǁLSTMAutoencoderǁsettings__mutmut_9'] = LSTMAutoencoder.xǁLSTMAutoencoderǁsettings__mutmut_9 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁsettings__mutmut['xǁLSTMAutoencoderǁsettings__mutmut_10'] = LSTMAutoencoder.xǁLSTMAutoencoderǁsettings__mutmut_10 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁsettings__mutmut['xǁLSTMAutoencoderǁsettings__mutmut_11'] = LSTMAutoencoder.xǁLSTMAutoencoderǁsettings__mutmut_11 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁsettings__mutmut['xǁLSTMAutoencoderǁsettings__mutmut_12'] = LSTMAutoencoder.xǁLSTMAutoencoderǁsettings__mutmut_12 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁsettings__mutmut['xǁLSTMAutoencoderǁsettings__mutmut_13'] = LSTMAutoencoder.xǁLSTMAutoencoderǁsettings__mutmut_13 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁsettings__mutmut['xǁLSTMAutoencoderǁsettings__mutmut_14'] = LSTMAutoencoder.xǁLSTMAutoencoderǁsettings__mutmut_14 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁsettings__mutmut['xǁLSTMAutoencoderǁsettings__mutmut_15'] = LSTMAutoencoder.xǁLSTMAutoencoderǁsettings__mutmut_15 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁsettings__mutmut['xǁLSTMAutoencoderǁsettings__mutmut_16'] = LSTMAutoencoder.xǁLSTMAutoencoderǁsettings__mutmut_16 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁsettings__mutmut['xǁLSTMAutoencoderǁsettings__mutmut_17'] = LSTMAutoencoder.xǁLSTMAutoencoderǁsettings__mutmut_17 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁsettings__mutmut['xǁLSTMAutoencoderǁsettings__mutmut_18'] = LSTMAutoencoder.xǁLSTMAutoencoderǁsettings__mutmut_18 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁsettings__mutmut['xǁLSTMAutoencoderǁsettings__mutmut_19'] = LSTMAutoencoder.xǁLSTMAutoencoderǁsettings__mutmut_19 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁsettings__mutmut['xǁLSTMAutoencoderǁsettings__mutmut_20'] = LSTMAutoencoder.xǁLSTMAutoencoderǁsettings__mutmut_20 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁsettings__mutmut['xǁLSTMAutoencoderǁsettings__mutmut_21'] = LSTMAutoencoder.xǁLSTMAutoencoderǁsettings__mutmut_21 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁsettings__mutmut['xǁLSTMAutoencoderǁsettings__mutmut_22'] = LSTMAutoencoder.xǁLSTMAutoencoderǁsettings__mutmut_22 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁsettings__mutmut['xǁLSTMAutoencoderǁsettings__mutmut_23'] = LSTMAutoencoder.xǁLSTMAutoencoderǁsettings__mutmut_23 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁsettings__mutmut['xǁLSTMAutoencoderǁsettings__mutmut_24'] = LSTMAutoencoder.xǁLSTMAutoencoderǁsettings__mutmut_24 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁsettings__mutmut['xǁLSTMAutoencoderǁsettings__mutmut_25'] = LSTMAutoencoder.xǁLSTMAutoencoderǁsettings__mutmut_25 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁsettings__mutmut['xǁLSTMAutoencoderǁsettings__mutmut_26'] = LSTMAutoencoder.xǁLSTMAutoencoderǁsettings__mutmut_26 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁsettings__mutmut['xǁLSTMAutoencoderǁsettings__mutmut_27'] = LSTMAutoencoder.xǁLSTMAutoencoderǁsettings__mutmut_27 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁsettings__mutmut['xǁLSTMAutoencoderǁsettings__mutmut_28'] = LSTMAutoencoder.xǁLSTMAutoencoderǁsettings__mutmut_28 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁsettings__mutmut['xǁLSTMAutoencoderǁsettings__mutmut_29'] = LSTMAutoencoder.xǁLSTMAutoencoderǁsettings__mutmut_29 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁsettings__mutmut['xǁLSTMAutoencoderǁsettings__mutmut_30'] = LSTMAutoencoder.xǁLSTMAutoencoderǁsettings__mutmut_30 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁsettings__mutmut['xǁLSTMAutoencoderǁsettings__mutmut_31'] = LSTMAutoencoder.xǁLSTMAutoencoderǁsettings__mutmut_31 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁsettings__mutmut['xǁLSTMAutoencoderǁsettings__mutmut_32'] = LSTMAutoencoder.xǁLSTMAutoencoderǁsettings__mutmut_32 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁsettings__mutmut['xǁLSTMAutoencoderǁsettings__mutmut_33'] = LSTMAutoencoder.xǁLSTMAutoencoderǁsettings__mutmut_33 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁsettings__mutmut['xǁLSTMAutoencoderǁsettings__mutmut_34'] = LSTMAutoencoder.xǁLSTMAutoencoderǁsettings__mutmut_34 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁsettings__mutmut['xǁLSTMAutoencoderǁsettings__mutmut_35'] = LSTMAutoencoder.xǁLSTMAutoencoderǁsettings__mutmut_35 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁsettings__mutmut['xǁLSTMAutoencoderǁsettings__mutmut_36'] = LSTMAutoencoder.xǁLSTMAutoencoderǁsettings__mutmut_36 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁsettings__mutmut['xǁLSTMAutoencoderǁsettings__mutmut_37'] = LSTMAutoencoder.xǁLSTMAutoencoderǁsettings__mutmut_37 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁsettings__mutmut['xǁLSTMAutoencoderǁsettings__mutmut_38'] = LSTMAutoencoder.xǁLSTMAutoencoderǁsettings__mutmut_38 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁsettings__mutmut['xǁLSTMAutoencoderǁsettings__mutmut_39'] = LSTMAutoencoder.xǁLSTMAutoencoderǁsettings__mutmut_39 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁsettings__mutmut['xǁLSTMAutoencoderǁsettings__mutmut_40'] = LSTMAutoencoder.xǁLSTMAutoencoderǁsettings__mutmut_40 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁsettings__mutmut['xǁLSTMAutoencoderǁsettings__mutmut_41'] = LSTMAutoencoder.xǁLSTMAutoencoderǁsettings__mutmut_41 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁsettings__mutmut['xǁLSTMAutoencoderǁsettings__mutmut_42'] = LSTMAutoencoder.xǁLSTMAutoencoderǁsettings__mutmut_42 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁsettings__mutmut['xǁLSTMAutoencoderǁsettings__mutmut_43'] = LSTMAutoencoder.xǁLSTMAutoencoderǁsettings__mutmut_43 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁsettings__mutmut['xǁLSTMAutoencoderǁsettings__mutmut_44'] = LSTMAutoencoder.xǁLSTMAutoencoderǁsettings__mutmut_44 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁsettings__mutmut['xǁLSTMAutoencoderǁsettings__mutmut_45'] = LSTMAutoencoder.xǁLSTMAutoencoderǁsettings__mutmut_45 # type: ignore # mutmut generated
mutants_xǁLSTMAutoencoderǁsettings__mutmut['xǁLSTMAutoencoderǁsettings__mutmut_46'] = LSTMAutoencoder.xǁLSTMAutoencoderǁsettings__mutmut_46 # type: ignore # mutmut generated
