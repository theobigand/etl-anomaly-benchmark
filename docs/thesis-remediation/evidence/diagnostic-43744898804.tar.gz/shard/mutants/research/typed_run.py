"""Run the typed-injection benchmark over the eligible carriers of the pool (issue #65)."""

from __future__ import annotations

import argparse
import json
import sys
import warnings
from concurrent.futures import ProcessPoolExecutor
from functools import partial as bind
from pathlib import Path
from typing import Any

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import injection as inj  # noqa: E402
import uci_loader as ul  # noqa: E402

from etl_benchmark.registry import DEEP_NAMES  # noqa: E402

SEEDS = (42, 1, 2, 3, 4)


from mutmut.mutation.trampoline import wrap_in_trampoline as _mutmut_mutated, MutantDict
mutants_x_load_carrier__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_load_carrier__mutmut)
def load_carrier(meta: dict[str, Any], path: Path, seed: int):
    frame = ul.read_table(path)
    try:
        features, labels, _ = ul.derive_labels(frame, meta)
        features = features[labels == 0]
        normal_only = True
    except ul.NoLabels:
        features, _ = ul.split_columns(frame, meta)
        normal_only = False
    carrier, report = inj.prepare(features, seed=0)
    report.update(source_rows=len(features), normal_class_only=normal_only)
    return carrier, report


def x_load_carrier__mutmut_orig(meta: dict[str, Any], path: Path, seed: int):
    frame = ul.read_table(path)
    try:
        features, labels, _ = ul.derive_labels(frame, meta)
        features = features[labels == 0]
        normal_only = True
    except ul.NoLabels:
        features, _ = ul.split_columns(frame, meta)
        normal_only = False
    carrier, report = inj.prepare(features, seed=0)
    report.update(source_rows=len(features), normal_class_only=normal_only)
    return carrier, report


def x_load_carrier__mutmut_1(meta: dict[str, Any], path: Path, seed: int):
    frame = None
    try:
        features, labels, _ = ul.derive_labels(frame, meta)
        features = features[labels == 0]
        normal_only = True
    except ul.NoLabels:
        features, _ = ul.split_columns(frame, meta)
        normal_only = False
    carrier, report = inj.prepare(features, seed=0)
    report.update(source_rows=len(features), normal_class_only=normal_only)
    return carrier, report


def x_load_carrier__mutmut_2(meta: dict[str, Any], path: Path, seed: int):
    frame = ul.read_table(None)
    try:
        features, labels, _ = ul.derive_labels(frame, meta)
        features = features[labels == 0]
        normal_only = True
    except ul.NoLabels:
        features, _ = ul.split_columns(frame, meta)
        normal_only = False
    carrier, report = inj.prepare(features, seed=0)
    report.update(source_rows=len(features), normal_class_only=normal_only)
    return carrier, report


def x_load_carrier__mutmut_3(meta: dict[str, Any], path: Path, seed: int):
    frame = ul.read_table(path)
    try:
        features, labels, _ = None
        features = features[labels == 0]
        normal_only = True
    except ul.NoLabels:
        features, _ = ul.split_columns(frame, meta)
        normal_only = False
    carrier, report = inj.prepare(features, seed=0)
    report.update(source_rows=len(features), normal_class_only=normal_only)
    return carrier, report


def x_load_carrier__mutmut_4(meta: dict[str, Any], path: Path, seed: int):
    frame = ul.read_table(path)
    try:
        features, labels, _ = ul.derive_labels(None, meta)
        features = features[labels == 0]
        normal_only = True
    except ul.NoLabels:
        features, _ = ul.split_columns(frame, meta)
        normal_only = False
    carrier, report = inj.prepare(features, seed=0)
    report.update(source_rows=len(features), normal_class_only=normal_only)
    return carrier, report


def x_load_carrier__mutmut_5(meta: dict[str, Any], path: Path, seed: int):
    frame = ul.read_table(path)
    try:
        features, labels, _ = ul.derive_labels(frame, None)
        features = features[labels == 0]
        normal_only = True
    except ul.NoLabels:
        features, _ = ul.split_columns(frame, meta)
        normal_only = False
    carrier, report = inj.prepare(features, seed=0)
    report.update(source_rows=len(features), normal_class_only=normal_only)
    return carrier, report


def x_load_carrier__mutmut_6(meta: dict[str, Any], path: Path, seed: int):
    frame = ul.read_table(path)
    try:
        features, labels, _ = ul.derive_labels(meta)
        features = features[labels == 0]
        normal_only = True
    except ul.NoLabels:
        features, _ = ul.split_columns(frame, meta)
        normal_only = False
    carrier, report = inj.prepare(features, seed=0)
    report.update(source_rows=len(features), normal_class_only=normal_only)
    return carrier, report


def x_load_carrier__mutmut_7(meta: dict[str, Any], path: Path, seed: int):
    frame = ul.read_table(path)
    try:
        features, labels, _ = ul.derive_labels(frame, )
        features = features[labels == 0]
        normal_only = True
    except ul.NoLabels:
        features, _ = ul.split_columns(frame, meta)
        normal_only = False
    carrier, report = inj.prepare(features, seed=0)
    report.update(source_rows=len(features), normal_class_only=normal_only)
    return carrier, report


def x_load_carrier__mutmut_8(meta: dict[str, Any], path: Path, seed: int):
    frame = ul.read_table(path)
    try:
        features, labels, _ = ul.derive_labels(frame, meta)
        features = None
        normal_only = True
    except ul.NoLabels:
        features, _ = ul.split_columns(frame, meta)
        normal_only = False
    carrier, report = inj.prepare(features, seed=0)
    report.update(source_rows=len(features), normal_class_only=normal_only)
    return carrier, report


def x_load_carrier__mutmut_9(meta: dict[str, Any], path: Path, seed: int):
    frame = ul.read_table(path)
    try:
        features, labels, _ = ul.derive_labels(frame, meta)
        features = features[labels != 0]
        normal_only = True
    except ul.NoLabels:
        features, _ = ul.split_columns(frame, meta)
        normal_only = False
    carrier, report = inj.prepare(features, seed=0)
    report.update(source_rows=len(features), normal_class_only=normal_only)
    return carrier, report


def x_load_carrier__mutmut_10(meta: dict[str, Any], path: Path, seed: int):
    frame = ul.read_table(path)
    try:
        features, labels, _ = ul.derive_labels(frame, meta)
        features = features[labels == 1]
        normal_only = True
    except ul.NoLabels:
        features, _ = ul.split_columns(frame, meta)
        normal_only = False
    carrier, report = inj.prepare(features, seed=0)
    report.update(source_rows=len(features), normal_class_only=normal_only)
    return carrier, report


def x_load_carrier__mutmut_11(meta: dict[str, Any], path: Path, seed: int):
    frame = ul.read_table(path)
    try:
        features, labels, _ = ul.derive_labels(frame, meta)
        features = features[labels == 0]
        normal_only = None
    except ul.NoLabels:
        features, _ = ul.split_columns(frame, meta)
        normal_only = False
    carrier, report = inj.prepare(features, seed=0)
    report.update(source_rows=len(features), normal_class_only=normal_only)
    return carrier, report


def x_load_carrier__mutmut_12(meta: dict[str, Any], path: Path, seed: int):
    frame = ul.read_table(path)
    try:
        features, labels, _ = ul.derive_labels(frame, meta)
        features = features[labels == 0]
        normal_only = False
    except ul.NoLabels:
        features, _ = ul.split_columns(frame, meta)
        normal_only = False
    carrier, report = inj.prepare(features, seed=0)
    report.update(source_rows=len(features), normal_class_only=normal_only)
    return carrier, report


def x_load_carrier__mutmut_13(meta: dict[str, Any], path: Path, seed: int):
    frame = ul.read_table(path)
    try:
        features, labels, _ = ul.derive_labels(frame, meta)
        features = features[labels == 0]
        normal_only = True
    except ul.NoLabels:
        features, _ = None
        normal_only = False
    carrier, report = inj.prepare(features, seed=0)
    report.update(source_rows=len(features), normal_class_only=normal_only)
    return carrier, report


def x_load_carrier__mutmut_14(meta: dict[str, Any], path: Path, seed: int):
    frame = ul.read_table(path)
    try:
        features, labels, _ = ul.derive_labels(frame, meta)
        features = features[labels == 0]
        normal_only = True
    except ul.NoLabels:
        features, _ = ul.split_columns(None, meta)
        normal_only = False
    carrier, report = inj.prepare(features, seed=0)
    report.update(source_rows=len(features), normal_class_only=normal_only)
    return carrier, report


def x_load_carrier__mutmut_15(meta: dict[str, Any], path: Path, seed: int):
    frame = ul.read_table(path)
    try:
        features, labels, _ = ul.derive_labels(frame, meta)
        features = features[labels == 0]
        normal_only = True
    except ul.NoLabels:
        features, _ = ul.split_columns(frame, None)
        normal_only = False
    carrier, report = inj.prepare(features, seed=0)
    report.update(source_rows=len(features), normal_class_only=normal_only)
    return carrier, report


def x_load_carrier__mutmut_16(meta: dict[str, Any], path: Path, seed: int):
    frame = ul.read_table(path)
    try:
        features, labels, _ = ul.derive_labels(frame, meta)
        features = features[labels == 0]
        normal_only = True
    except ul.NoLabels:
        features, _ = ul.split_columns(meta)
        normal_only = False
    carrier, report = inj.prepare(features, seed=0)
    report.update(source_rows=len(features), normal_class_only=normal_only)
    return carrier, report


def x_load_carrier__mutmut_17(meta: dict[str, Any], path: Path, seed: int):
    frame = ul.read_table(path)
    try:
        features, labels, _ = ul.derive_labels(frame, meta)
        features = features[labels == 0]
        normal_only = True
    except ul.NoLabels:
        features, _ = ul.split_columns(frame, )
        normal_only = False
    carrier, report = inj.prepare(features, seed=0)
    report.update(source_rows=len(features), normal_class_only=normal_only)
    return carrier, report


def x_load_carrier__mutmut_18(meta: dict[str, Any], path: Path, seed: int):
    frame = ul.read_table(path)
    try:
        features, labels, _ = ul.derive_labels(frame, meta)
        features = features[labels == 0]
        normal_only = True
    except ul.NoLabels:
        features, _ = ul.split_columns(frame, meta)
        normal_only = None
    carrier, report = inj.prepare(features, seed=0)
    report.update(source_rows=len(features), normal_class_only=normal_only)
    return carrier, report


def x_load_carrier__mutmut_19(meta: dict[str, Any], path: Path, seed: int):
    frame = ul.read_table(path)
    try:
        features, labels, _ = ul.derive_labels(frame, meta)
        features = features[labels == 0]
        normal_only = True
    except ul.NoLabels:
        features, _ = ul.split_columns(frame, meta)
        normal_only = True
    carrier, report = inj.prepare(features, seed=0)
    report.update(source_rows=len(features), normal_class_only=normal_only)
    return carrier, report


def x_load_carrier__mutmut_20(meta: dict[str, Any], path: Path, seed: int):
    frame = ul.read_table(path)
    try:
        features, labels, _ = ul.derive_labels(frame, meta)
        features = features[labels == 0]
        normal_only = True
    except ul.NoLabels:
        features, _ = ul.split_columns(frame, meta)
        normal_only = False
    carrier, report = None
    report.update(source_rows=len(features), normal_class_only=normal_only)
    return carrier, report


def x_load_carrier__mutmut_21(meta: dict[str, Any], path: Path, seed: int):
    frame = ul.read_table(path)
    try:
        features, labels, _ = ul.derive_labels(frame, meta)
        features = features[labels == 0]
        normal_only = True
    except ul.NoLabels:
        features, _ = ul.split_columns(frame, meta)
        normal_only = False
    carrier, report = inj.prepare(None, seed=0)
    report.update(source_rows=len(features), normal_class_only=normal_only)
    return carrier, report


def x_load_carrier__mutmut_22(meta: dict[str, Any], path: Path, seed: int):
    frame = ul.read_table(path)
    try:
        features, labels, _ = ul.derive_labels(frame, meta)
        features = features[labels == 0]
        normal_only = True
    except ul.NoLabels:
        features, _ = ul.split_columns(frame, meta)
        normal_only = False
    carrier, report = inj.prepare(features, seed=None)
    report.update(source_rows=len(features), normal_class_only=normal_only)
    return carrier, report


def x_load_carrier__mutmut_23(meta: dict[str, Any], path: Path, seed: int):
    frame = ul.read_table(path)
    try:
        features, labels, _ = ul.derive_labels(frame, meta)
        features = features[labels == 0]
        normal_only = True
    except ul.NoLabels:
        features, _ = ul.split_columns(frame, meta)
        normal_only = False
    carrier, report = inj.prepare(seed=0)
    report.update(source_rows=len(features), normal_class_only=normal_only)
    return carrier, report


def x_load_carrier__mutmut_24(meta: dict[str, Any], path: Path, seed: int):
    frame = ul.read_table(path)
    try:
        features, labels, _ = ul.derive_labels(frame, meta)
        features = features[labels == 0]
        normal_only = True
    except ul.NoLabels:
        features, _ = ul.split_columns(frame, meta)
        normal_only = False
    carrier, report = inj.prepare(features, )
    report.update(source_rows=len(features), normal_class_only=normal_only)
    return carrier, report


def x_load_carrier__mutmut_25(meta: dict[str, Any], path: Path, seed: int):
    frame = ul.read_table(path)
    try:
        features, labels, _ = ul.derive_labels(frame, meta)
        features = features[labels == 0]
        normal_only = True
    except ul.NoLabels:
        features, _ = ul.split_columns(frame, meta)
        normal_only = False
    carrier, report = inj.prepare(features, seed=1)
    report.update(source_rows=len(features), normal_class_only=normal_only)
    return carrier, report


def x_load_carrier__mutmut_26(meta: dict[str, Any], path: Path, seed: int):
    frame = ul.read_table(path)
    try:
        features, labels, _ = ul.derive_labels(frame, meta)
        features = features[labels == 0]
        normal_only = True
    except ul.NoLabels:
        features, _ = ul.split_columns(frame, meta)
        normal_only = False
    carrier, report = inj.prepare(features, seed=0)
    report.update(source_rows=None, normal_class_only=normal_only)
    return carrier, report


def x_load_carrier__mutmut_27(meta: dict[str, Any], path: Path, seed: int):
    frame = ul.read_table(path)
    try:
        features, labels, _ = ul.derive_labels(frame, meta)
        features = features[labels == 0]
        normal_only = True
    except ul.NoLabels:
        features, _ = ul.split_columns(frame, meta)
        normal_only = False
    carrier, report = inj.prepare(features, seed=0)
    report.update(source_rows=len(features), normal_class_only=None)
    return carrier, report


def x_load_carrier__mutmut_28(meta: dict[str, Any], path: Path, seed: int):
    frame = ul.read_table(path)
    try:
        features, labels, _ = ul.derive_labels(frame, meta)
        features = features[labels == 0]
        normal_only = True
    except ul.NoLabels:
        features, _ = ul.split_columns(frame, meta)
        normal_only = False
    carrier, report = inj.prepare(features, seed=0)
    report.update(normal_class_only=normal_only)
    return carrier, report


def x_load_carrier__mutmut_29(meta: dict[str, Any], path: Path, seed: int):
    frame = ul.read_table(path)
    try:
        features, labels, _ = ul.derive_labels(frame, meta)
        features = features[labels == 0]
        normal_only = True
    except ul.NoLabels:
        features, _ = ul.split_columns(frame, meta)
        normal_only = False
    carrier, report = inj.prepare(features, seed=0)
    report.update(source_rows=len(features), )
    return carrier, report

mutants_x_load_carrier__mutmut['_mutmut_orig'] = x_load_carrier__mutmut_orig # type: ignore # mutmut generated
mutants_x_load_carrier__mutmut['x_load_carrier__mutmut_1'] = x_load_carrier__mutmut_1 # type: ignore # mutmut generated
mutants_x_load_carrier__mutmut['x_load_carrier__mutmut_2'] = x_load_carrier__mutmut_2 # type: ignore # mutmut generated
mutants_x_load_carrier__mutmut['x_load_carrier__mutmut_3'] = x_load_carrier__mutmut_3 # type: ignore # mutmut generated
mutants_x_load_carrier__mutmut['x_load_carrier__mutmut_4'] = x_load_carrier__mutmut_4 # type: ignore # mutmut generated
mutants_x_load_carrier__mutmut['x_load_carrier__mutmut_5'] = x_load_carrier__mutmut_5 # type: ignore # mutmut generated
mutants_x_load_carrier__mutmut['x_load_carrier__mutmut_6'] = x_load_carrier__mutmut_6 # type: ignore # mutmut generated
mutants_x_load_carrier__mutmut['x_load_carrier__mutmut_7'] = x_load_carrier__mutmut_7 # type: ignore # mutmut generated
mutants_x_load_carrier__mutmut['x_load_carrier__mutmut_8'] = x_load_carrier__mutmut_8 # type: ignore # mutmut generated
mutants_x_load_carrier__mutmut['x_load_carrier__mutmut_9'] = x_load_carrier__mutmut_9 # type: ignore # mutmut generated
mutants_x_load_carrier__mutmut['x_load_carrier__mutmut_10'] = x_load_carrier__mutmut_10 # type: ignore # mutmut generated
mutants_x_load_carrier__mutmut['x_load_carrier__mutmut_11'] = x_load_carrier__mutmut_11 # type: ignore # mutmut generated
mutants_x_load_carrier__mutmut['x_load_carrier__mutmut_12'] = x_load_carrier__mutmut_12 # type: ignore # mutmut generated
mutants_x_load_carrier__mutmut['x_load_carrier__mutmut_13'] = x_load_carrier__mutmut_13 # type: ignore # mutmut generated
mutants_x_load_carrier__mutmut['x_load_carrier__mutmut_14'] = x_load_carrier__mutmut_14 # type: ignore # mutmut generated
mutants_x_load_carrier__mutmut['x_load_carrier__mutmut_15'] = x_load_carrier__mutmut_15 # type: ignore # mutmut generated
mutants_x_load_carrier__mutmut['x_load_carrier__mutmut_16'] = x_load_carrier__mutmut_16 # type: ignore # mutmut generated
mutants_x_load_carrier__mutmut['x_load_carrier__mutmut_17'] = x_load_carrier__mutmut_17 # type: ignore # mutmut generated
mutants_x_load_carrier__mutmut['x_load_carrier__mutmut_18'] = x_load_carrier__mutmut_18 # type: ignore # mutmut generated
mutants_x_load_carrier__mutmut['x_load_carrier__mutmut_19'] = x_load_carrier__mutmut_19 # type: ignore # mutmut generated
mutants_x_load_carrier__mutmut['x_load_carrier__mutmut_20'] = x_load_carrier__mutmut_20 # type: ignore # mutmut generated
mutants_x_load_carrier__mutmut['x_load_carrier__mutmut_21'] = x_load_carrier__mutmut_21 # type: ignore # mutmut generated
mutants_x_load_carrier__mutmut['x_load_carrier__mutmut_22'] = x_load_carrier__mutmut_22 # type: ignore # mutmut generated
mutants_x_load_carrier__mutmut['x_load_carrier__mutmut_23'] = x_load_carrier__mutmut_23 # type: ignore # mutmut generated
mutants_x_load_carrier__mutmut['x_load_carrier__mutmut_24'] = x_load_carrier__mutmut_24 # type: ignore # mutmut generated
mutants_x_load_carrier__mutmut['x_load_carrier__mutmut_25'] = x_load_carrier__mutmut_25 # type: ignore # mutmut generated
mutants_x_load_carrier__mutmut['x_load_carrier__mutmut_26'] = x_load_carrier__mutmut_26 # type: ignore # mutmut generated
mutants_x_load_carrier__mutmut['x_load_carrier__mutmut_27'] = x_load_carrier__mutmut_27 # type: ignore # mutmut generated
mutants_x_load_carrier__mutmut['x_load_carrier__mutmut_28'] = x_load_carrier__mutmut_28 # type: ignore # mutmut generated
mutants_x_load_carrier__mutmut['x_load_carrier__mutmut_29'] = x_load_carrier__mutmut_29 # type: ignore # mutmut generated
mutants_x_run_one__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_run_one__mutmut)
def run_one(job: tuple[dict[str, Any], str, str], names: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    meta, path, digest = job
    carrier, report = load_carrier(meta, Path(path), seed=0)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        df = inj.inject(carrier, seed=seed)
        result = tb.evaluate(df, cols, seed, names)
        recalls.append(result["recall"])
        precisions.append(result["precision"])
        fprs.append(result["fpr"])
    import pandas as pd

    stack = pd.concat(recalls, keys=range(len(recalls)))
    mean = stack.groupby(level=1, sort=False).mean()
    precision = (
        pd.concat(precisions, keys=range(len(precisions))).groupby(level=1, sort=False).mean()
    )
    fpr = pd.concat(fprs, axis=1).mean(axis=1)
    return {
        "uci_id": meta["uci_id"],
        "name": meta["name"],
        "sha256": digest,
        "carrier": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="split")),
        "precision_mean": json.loads(precision.to_json(orient="split")),
        "fpr_mean": json.loads(fpr.to_json()),
        "recall_seeds": [json.loads(r.to_json(orient="split")) for r in recalls],
    }


def x_run_one__mutmut_orig(job: tuple[dict[str, Any], str, str], names: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    meta, path, digest = job
    carrier, report = load_carrier(meta, Path(path), seed=0)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        df = inj.inject(carrier, seed=seed)
        result = tb.evaluate(df, cols, seed, names)
        recalls.append(result["recall"])
        precisions.append(result["precision"])
        fprs.append(result["fpr"])
    import pandas as pd

    stack = pd.concat(recalls, keys=range(len(recalls)))
    mean = stack.groupby(level=1, sort=False).mean()
    precision = (
        pd.concat(precisions, keys=range(len(precisions))).groupby(level=1, sort=False).mean()
    )
    fpr = pd.concat(fprs, axis=1).mean(axis=1)
    return {
        "uci_id": meta["uci_id"],
        "name": meta["name"],
        "sha256": digest,
        "carrier": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="split")),
        "precision_mean": json.loads(precision.to_json(orient="split")),
        "fpr_mean": json.loads(fpr.to_json()),
        "recall_seeds": [json.loads(r.to_json(orient="split")) for r in recalls],
    }


def x_run_one__mutmut_1(job: tuple[dict[str, Any], str, str], names: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings(None)
    import typed_benchmark as tb

    meta, path, digest = job
    carrier, report = load_carrier(meta, Path(path), seed=0)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        df = inj.inject(carrier, seed=seed)
        result = tb.evaluate(df, cols, seed, names)
        recalls.append(result["recall"])
        precisions.append(result["precision"])
        fprs.append(result["fpr"])
    import pandas as pd

    stack = pd.concat(recalls, keys=range(len(recalls)))
    mean = stack.groupby(level=1, sort=False).mean()
    precision = (
        pd.concat(precisions, keys=range(len(precisions))).groupby(level=1, sort=False).mean()
    )
    fpr = pd.concat(fprs, axis=1).mean(axis=1)
    return {
        "uci_id": meta["uci_id"],
        "name": meta["name"],
        "sha256": digest,
        "carrier": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="split")),
        "precision_mean": json.loads(precision.to_json(orient="split")),
        "fpr_mean": json.loads(fpr.to_json()),
        "recall_seeds": [json.loads(r.to_json(orient="split")) for r in recalls],
    }


def x_run_one__mutmut_2(job: tuple[dict[str, Any], str, str], names: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("XXignoreXX")
    import typed_benchmark as tb

    meta, path, digest = job
    carrier, report = load_carrier(meta, Path(path), seed=0)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        df = inj.inject(carrier, seed=seed)
        result = tb.evaluate(df, cols, seed, names)
        recalls.append(result["recall"])
        precisions.append(result["precision"])
        fprs.append(result["fpr"])
    import pandas as pd

    stack = pd.concat(recalls, keys=range(len(recalls)))
    mean = stack.groupby(level=1, sort=False).mean()
    precision = (
        pd.concat(precisions, keys=range(len(precisions))).groupby(level=1, sort=False).mean()
    )
    fpr = pd.concat(fprs, axis=1).mean(axis=1)
    return {
        "uci_id": meta["uci_id"],
        "name": meta["name"],
        "sha256": digest,
        "carrier": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="split")),
        "precision_mean": json.loads(precision.to_json(orient="split")),
        "fpr_mean": json.loads(fpr.to_json()),
        "recall_seeds": [json.loads(r.to_json(orient="split")) for r in recalls],
    }


def x_run_one__mutmut_3(job: tuple[dict[str, Any], str, str], names: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("IGNORE")
    import typed_benchmark as tb

    meta, path, digest = job
    carrier, report = load_carrier(meta, Path(path), seed=0)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        df = inj.inject(carrier, seed=seed)
        result = tb.evaluate(df, cols, seed, names)
        recalls.append(result["recall"])
        precisions.append(result["precision"])
        fprs.append(result["fpr"])
    import pandas as pd

    stack = pd.concat(recalls, keys=range(len(recalls)))
    mean = stack.groupby(level=1, sort=False).mean()
    precision = (
        pd.concat(precisions, keys=range(len(precisions))).groupby(level=1, sort=False).mean()
    )
    fpr = pd.concat(fprs, axis=1).mean(axis=1)
    return {
        "uci_id": meta["uci_id"],
        "name": meta["name"],
        "sha256": digest,
        "carrier": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="split")),
        "precision_mean": json.loads(precision.to_json(orient="split")),
        "fpr_mean": json.loads(fpr.to_json()),
        "recall_seeds": [json.loads(r.to_json(orient="split")) for r in recalls],
    }


def x_run_one__mutmut_4(job: tuple[dict[str, Any], str, str], names: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    meta, path, digest = None
    carrier, report = load_carrier(meta, Path(path), seed=0)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        df = inj.inject(carrier, seed=seed)
        result = tb.evaluate(df, cols, seed, names)
        recalls.append(result["recall"])
        precisions.append(result["precision"])
        fprs.append(result["fpr"])
    import pandas as pd

    stack = pd.concat(recalls, keys=range(len(recalls)))
    mean = stack.groupby(level=1, sort=False).mean()
    precision = (
        pd.concat(precisions, keys=range(len(precisions))).groupby(level=1, sort=False).mean()
    )
    fpr = pd.concat(fprs, axis=1).mean(axis=1)
    return {
        "uci_id": meta["uci_id"],
        "name": meta["name"],
        "sha256": digest,
        "carrier": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="split")),
        "precision_mean": json.loads(precision.to_json(orient="split")),
        "fpr_mean": json.loads(fpr.to_json()),
        "recall_seeds": [json.loads(r.to_json(orient="split")) for r in recalls],
    }


def x_run_one__mutmut_5(job: tuple[dict[str, Any], str, str], names: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    meta, path, digest = job
    carrier, report = None
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        df = inj.inject(carrier, seed=seed)
        result = tb.evaluate(df, cols, seed, names)
        recalls.append(result["recall"])
        precisions.append(result["precision"])
        fprs.append(result["fpr"])
    import pandas as pd

    stack = pd.concat(recalls, keys=range(len(recalls)))
    mean = stack.groupby(level=1, sort=False).mean()
    precision = (
        pd.concat(precisions, keys=range(len(precisions))).groupby(level=1, sort=False).mean()
    )
    fpr = pd.concat(fprs, axis=1).mean(axis=1)
    return {
        "uci_id": meta["uci_id"],
        "name": meta["name"],
        "sha256": digest,
        "carrier": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="split")),
        "precision_mean": json.loads(precision.to_json(orient="split")),
        "fpr_mean": json.loads(fpr.to_json()),
        "recall_seeds": [json.loads(r.to_json(orient="split")) for r in recalls],
    }


def x_run_one__mutmut_6(job: tuple[dict[str, Any], str, str], names: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    meta, path, digest = job
    carrier, report = load_carrier(None, Path(path), seed=0)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        df = inj.inject(carrier, seed=seed)
        result = tb.evaluate(df, cols, seed, names)
        recalls.append(result["recall"])
        precisions.append(result["precision"])
        fprs.append(result["fpr"])
    import pandas as pd

    stack = pd.concat(recalls, keys=range(len(recalls)))
    mean = stack.groupby(level=1, sort=False).mean()
    precision = (
        pd.concat(precisions, keys=range(len(precisions))).groupby(level=1, sort=False).mean()
    )
    fpr = pd.concat(fprs, axis=1).mean(axis=1)
    return {
        "uci_id": meta["uci_id"],
        "name": meta["name"],
        "sha256": digest,
        "carrier": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="split")),
        "precision_mean": json.loads(precision.to_json(orient="split")),
        "fpr_mean": json.loads(fpr.to_json()),
        "recall_seeds": [json.loads(r.to_json(orient="split")) for r in recalls],
    }


def x_run_one__mutmut_7(job: tuple[dict[str, Any], str, str], names: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    meta, path, digest = job
    carrier, report = load_carrier(meta, None, seed=0)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        df = inj.inject(carrier, seed=seed)
        result = tb.evaluate(df, cols, seed, names)
        recalls.append(result["recall"])
        precisions.append(result["precision"])
        fprs.append(result["fpr"])
    import pandas as pd

    stack = pd.concat(recalls, keys=range(len(recalls)))
    mean = stack.groupby(level=1, sort=False).mean()
    precision = (
        pd.concat(precisions, keys=range(len(precisions))).groupby(level=1, sort=False).mean()
    )
    fpr = pd.concat(fprs, axis=1).mean(axis=1)
    return {
        "uci_id": meta["uci_id"],
        "name": meta["name"],
        "sha256": digest,
        "carrier": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="split")),
        "precision_mean": json.loads(precision.to_json(orient="split")),
        "fpr_mean": json.loads(fpr.to_json()),
        "recall_seeds": [json.loads(r.to_json(orient="split")) for r in recalls],
    }


def x_run_one__mutmut_8(job: tuple[dict[str, Any], str, str], names: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    meta, path, digest = job
    carrier, report = load_carrier(meta, Path(path), seed=None)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        df = inj.inject(carrier, seed=seed)
        result = tb.evaluate(df, cols, seed, names)
        recalls.append(result["recall"])
        precisions.append(result["precision"])
        fprs.append(result["fpr"])
    import pandas as pd

    stack = pd.concat(recalls, keys=range(len(recalls)))
    mean = stack.groupby(level=1, sort=False).mean()
    precision = (
        pd.concat(precisions, keys=range(len(precisions))).groupby(level=1, sort=False).mean()
    )
    fpr = pd.concat(fprs, axis=1).mean(axis=1)
    return {
        "uci_id": meta["uci_id"],
        "name": meta["name"],
        "sha256": digest,
        "carrier": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="split")),
        "precision_mean": json.loads(precision.to_json(orient="split")),
        "fpr_mean": json.loads(fpr.to_json()),
        "recall_seeds": [json.loads(r.to_json(orient="split")) for r in recalls],
    }


def x_run_one__mutmut_9(job: tuple[dict[str, Any], str, str], names: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    meta, path, digest = job
    carrier, report = load_carrier(Path(path), seed=0)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        df = inj.inject(carrier, seed=seed)
        result = tb.evaluate(df, cols, seed, names)
        recalls.append(result["recall"])
        precisions.append(result["precision"])
        fprs.append(result["fpr"])
    import pandas as pd

    stack = pd.concat(recalls, keys=range(len(recalls)))
    mean = stack.groupby(level=1, sort=False).mean()
    precision = (
        pd.concat(precisions, keys=range(len(precisions))).groupby(level=1, sort=False).mean()
    )
    fpr = pd.concat(fprs, axis=1).mean(axis=1)
    return {
        "uci_id": meta["uci_id"],
        "name": meta["name"],
        "sha256": digest,
        "carrier": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="split")),
        "precision_mean": json.loads(precision.to_json(orient="split")),
        "fpr_mean": json.loads(fpr.to_json()),
        "recall_seeds": [json.loads(r.to_json(orient="split")) for r in recalls],
    }


def x_run_one__mutmut_10(job: tuple[dict[str, Any], str, str], names: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    meta, path, digest = job
    carrier, report = load_carrier(meta, seed=0)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        df = inj.inject(carrier, seed=seed)
        result = tb.evaluate(df, cols, seed, names)
        recalls.append(result["recall"])
        precisions.append(result["precision"])
        fprs.append(result["fpr"])
    import pandas as pd

    stack = pd.concat(recalls, keys=range(len(recalls)))
    mean = stack.groupby(level=1, sort=False).mean()
    precision = (
        pd.concat(precisions, keys=range(len(precisions))).groupby(level=1, sort=False).mean()
    )
    fpr = pd.concat(fprs, axis=1).mean(axis=1)
    return {
        "uci_id": meta["uci_id"],
        "name": meta["name"],
        "sha256": digest,
        "carrier": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="split")),
        "precision_mean": json.loads(precision.to_json(orient="split")),
        "fpr_mean": json.loads(fpr.to_json()),
        "recall_seeds": [json.loads(r.to_json(orient="split")) for r in recalls],
    }


def x_run_one__mutmut_11(job: tuple[dict[str, Any], str, str], names: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    meta, path, digest = job
    carrier, report = load_carrier(meta, Path(path), )
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        df = inj.inject(carrier, seed=seed)
        result = tb.evaluate(df, cols, seed, names)
        recalls.append(result["recall"])
        precisions.append(result["precision"])
        fprs.append(result["fpr"])
    import pandas as pd

    stack = pd.concat(recalls, keys=range(len(recalls)))
    mean = stack.groupby(level=1, sort=False).mean()
    precision = (
        pd.concat(precisions, keys=range(len(precisions))).groupby(level=1, sort=False).mean()
    )
    fpr = pd.concat(fprs, axis=1).mean(axis=1)
    return {
        "uci_id": meta["uci_id"],
        "name": meta["name"],
        "sha256": digest,
        "carrier": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="split")),
        "precision_mean": json.loads(precision.to_json(orient="split")),
        "fpr_mean": json.loads(fpr.to_json()),
        "recall_seeds": [json.loads(r.to_json(orient="split")) for r in recalls],
    }


def x_run_one__mutmut_12(job: tuple[dict[str, Any], str, str], names: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    meta, path, digest = job
    carrier, report = load_carrier(meta, Path(None), seed=0)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        df = inj.inject(carrier, seed=seed)
        result = tb.evaluate(df, cols, seed, names)
        recalls.append(result["recall"])
        precisions.append(result["precision"])
        fprs.append(result["fpr"])
    import pandas as pd

    stack = pd.concat(recalls, keys=range(len(recalls)))
    mean = stack.groupby(level=1, sort=False).mean()
    precision = (
        pd.concat(precisions, keys=range(len(precisions))).groupby(level=1, sort=False).mean()
    )
    fpr = pd.concat(fprs, axis=1).mean(axis=1)
    return {
        "uci_id": meta["uci_id"],
        "name": meta["name"],
        "sha256": digest,
        "carrier": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="split")),
        "precision_mean": json.loads(precision.to_json(orient="split")),
        "fpr_mean": json.loads(fpr.to_json()),
        "recall_seeds": [json.loads(r.to_json(orient="split")) for r in recalls],
    }


def x_run_one__mutmut_13(job: tuple[dict[str, Any], str, str], names: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    meta, path, digest = job
    carrier, report = load_carrier(meta, Path(path), seed=1)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        df = inj.inject(carrier, seed=seed)
        result = tb.evaluate(df, cols, seed, names)
        recalls.append(result["recall"])
        precisions.append(result["precision"])
        fprs.append(result["fpr"])
    import pandas as pd

    stack = pd.concat(recalls, keys=range(len(recalls)))
    mean = stack.groupby(level=1, sort=False).mean()
    precision = (
        pd.concat(precisions, keys=range(len(precisions))).groupby(level=1, sort=False).mean()
    )
    fpr = pd.concat(fprs, axis=1).mean(axis=1)
    return {
        "uci_id": meta["uci_id"],
        "name": meta["name"],
        "sha256": digest,
        "carrier": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="split")),
        "precision_mean": json.loads(precision.to_json(orient="split")),
        "fpr_mean": json.loads(fpr.to_json()),
        "recall_seeds": [json.loads(r.to_json(orient="split")) for r in recalls],
    }


def x_run_one__mutmut_14(job: tuple[dict[str, Any], str, str], names: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    meta, path, digest = job
    carrier, report = load_carrier(meta, Path(path), seed=0)
    cols = None
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        df = inj.inject(carrier, seed=seed)
        result = tb.evaluate(df, cols, seed, names)
        recalls.append(result["recall"])
        precisions.append(result["precision"])
        fprs.append(result["fpr"])
    import pandas as pd

    stack = pd.concat(recalls, keys=range(len(recalls)))
    mean = stack.groupby(level=1, sort=False).mean()
    precision = (
        pd.concat(precisions, keys=range(len(precisions))).groupby(level=1, sort=False).mean()
    )
    fpr = pd.concat(fprs, axis=1).mean(axis=1)
    return {
        "uci_id": meta["uci_id"],
        "name": meta["name"],
        "sha256": digest,
        "carrier": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="split")),
        "precision_mean": json.loads(precision.to_json(orient="split")),
        "fpr_mean": json.loads(fpr.to_json()),
        "recall_seeds": [json.loads(r.to_json(orient="split")) for r in recalls],
    }


def x_run_one__mutmut_15(job: tuple[dict[str, Any], str, str], names: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    meta, path, digest = job
    carrier, report = load_carrier(meta, Path(path), seed=0)
    cols = list(None)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        df = inj.inject(carrier, seed=seed)
        result = tb.evaluate(df, cols, seed, names)
        recalls.append(result["recall"])
        precisions.append(result["precision"])
        fprs.append(result["fpr"])
    import pandas as pd

    stack = pd.concat(recalls, keys=range(len(recalls)))
    mean = stack.groupby(level=1, sort=False).mean()
    precision = (
        pd.concat(precisions, keys=range(len(precisions))).groupby(level=1, sort=False).mean()
    )
    fpr = pd.concat(fprs, axis=1).mean(axis=1)
    return {
        "uci_id": meta["uci_id"],
        "name": meta["name"],
        "sha256": digest,
        "carrier": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="split")),
        "precision_mean": json.loads(precision.to_json(orient="split")),
        "fpr_mean": json.loads(fpr.to_json()),
        "recall_seeds": [json.loads(r.to_json(orient="split")) for r in recalls],
    }


def x_run_one__mutmut_16(job: tuple[dict[str, Any], str, str], names: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    meta, path, digest = job
    carrier, report = load_carrier(meta, Path(path), seed=0)
    cols = list(carrier.columns)
    recalls, precisions, fprs = None
    for seed in SEEDS:
        df = inj.inject(carrier, seed=seed)
        result = tb.evaluate(df, cols, seed, names)
        recalls.append(result["recall"])
        precisions.append(result["precision"])
        fprs.append(result["fpr"])
    import pandas as pd

    stack = pd.concat(recalls, keys=range(len(recalls)))
    mean = stack.groupby(level=1, sort=False).mean()
    precision = (
        pd.concat(precisions, keys=range(len(precisions))).groupby(level=1, sort=False).mean()
    )
    fpr = pd.concat(fprs, axis=1).mean(axis=1)
    return {
        "uci_id": meta["uci_id"],
        "name": meta["name"],
        "sha256": digest,
        "carrier": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="split")),
        "precision_mean": json.loads(precision.to_json(orient="split")),
        "fpr_mean": json.loads(fpr.to_json()),
        "recall_seeds": [json.loads(r.to_json(orient="split")) for r in recalls],
    }


def x_run_one__mutmut_17(job: tuple[dict[str, Any], str, str], names: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    meta, path, digest = job
    carrier, report = load_carrier(meta, Path(path), seed=0)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        df = None
        result = tb.evaluate(df, cols, seed, names)
        recalls.append(result["recall"])
        precisions.append(result["precision"])
        fprs.append(result["fpr"])
    import pandas as pd

    stack = pd.concat(recalls, keys=range(len(recalls)))
    mean = stack.groupby(level=1, sort=False).mean()
    precision = (
        pd.concat(precisions, keys=range(len(precisions))).groupby(level=1, sort=False).mean()
    )
    fpr = pd.concat(fprs, axis=1).mean(axis=1)
    return {
        "uci_id": meta["uci_id"],
        "name": meta["name"],
        "sha256": digest,
        "carrier": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="split")),
        "precision_mean": json.loads(precision.to_json(orient="split")),
        "fpr_mean": json.loads(fpr.to_json()),
        "recall_seeds": [json.loads(r.to_json(orient="split")) for r in recalls],
    }


def x_run_one__mutmut_18(job: tuple[dict[str, Any], str, str], names: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    meta, path, digest = job
    carrier, report = load_carrier(meta, Path(path), seed=0)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        df = inj.inject(None, seed=seed)
        result = tb.evaluate(df, cols, seed, names)
        recalls.append(result["recall"])
        precisions.append(result["precision"])
        fprs.append(result["fpr"])
    import pandas as pd

    stack = pd.concat(recalls, keys=range(len(recalls)))
    mean = stack.groupby(level=1, sort=False).mean()
    precision = (
        pd.concat(precisions, keys=range(len(precisions))).groupby(level=1, sort=False).mean()
    )
    fpr = pd.concat(fprs, axis=1).mean(axis=1)
    return {
        "uci_id": meta["uci_id"],
        "name": meta["name"],
        "sha256": digest,
        "carrier": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="split")),
        "precision_mean": json.loads(precision.to_json(orient="split")),
        "fpr_mean": json.loads(fpr.to_json()),
        "recall_seeds": [json.loads(r.to_json(orient="split")) for r in recalls],
    }


def x_run_one__mutmut_19(job: tuple[dict[str, Any], str, str], names: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    meta, path, digest = job
    carrier, report = load_carrier(meta, Path(path), seed=0)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        df = inj.inject(carrier, seed=None)
        result = tb.evaluate(df, cols, seed, names)
        recalls.append(result["recall"])
        precisions.append(result["precision"])
        fprs.append(result["fpr"])
    import pandas as pd

    stack = pd.concat(recalls, keys=range(len(recalls)))
    mean = stack.groupby(level=1, sort=False).mean()
    precision = (
        pd.concat(precisions, keys=range(len(precisions))).groupby(level=1, sort=False).mean()
    )
    fpr = pd.concat(fprs, axis=1).mean(axis=1)
    return {
        "uci_id": meta["uci_id"],
        "name": meta["name"],
        "sha256": digest,
        "carrier": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="split")),
        "precision_mean": json.loads(precision.to_json(orient="split")),
        "fpr_mean": json.loads(fpr.to_json()),
        "recall_seeds": [json.loads(r.to_json(orient="split")) for r in recalls],
    }


def x_run_one__mutmut_20(job: tuple[dict[str, Any], str, str], names: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    meta, path, digest = job
    carrier, report = load_carrier(meta, Path(path), seed=0)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        df = inj.inject(seed=seed)
        result = tb.evaluate(df, cols, seed, names)
        recalls.append(result["recall"])
        precisions.append(result["precision"])
        fprs.append(result["fpr"])
    import pandas as pd

    stack = pd.concat(recalls, keys=range(len(recalls)))
    mean = stack.groupby(level=1, sort=False).mean()
    precision = (
        pd.concat(precisions, keys=range(len(precisions))).groupby(level=1, sort=False).mean()
    )
    fpr = pd.concat(fprs, axis=1).mean(axis=1)
    return {
        "uci_id": meta["uci_id"],
        "name": meta["name"],
        "sha256": digest,
        "carrier": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="split")),
        "precision_mean": json.loads(precision.to_json(orient="split")),
        "fpr_mean": json.loads(fpr.to_json()),
        "recall_seeds": [json.loads(r.to_json(orient="split")) for r in recalls],
    }


def x_run_one__mutmut_21(job: tuple[dict[str, Any], str, str], names: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    meta, path, digest = job
    carrier, report = load_carrier(meta, Path(path), seed=0)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        df = inj.inject(carrier, )
        result = tb.evaluate(df, cols, seed, names)
        recalls.append(result["recall"])
        precisions.append(result["precision"])
        fprs.append(result["fpr"])
    import pandas as pd

    stack = pd.concat(recalls, keys=range(len(recalls)))
    mean = stack.groupby(level=1, sort=False).mean()
    precision = (
        pd.concat(precisions, keys=range(len(precisions))).groupby(level=1, sort=False).mean()
    )
    fpr = pd.concat(fprs, axis=1).mean(axis=1)
    return {
        "uci_id": meta["uci_id"],
        "name": meta["name"],
        "sha256": digest,
        "carrier": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="split")),
        "precision_mean": json.loads(precision.to_json(orient="split")),
        "fpr_mean": json.loads(fpr.to_json()),
        "recall_seeds": [json.loads(r.to_json(orient="split")) for r in recalls],
    }


def x_run_one__mutmut_22(job: tuple[dict[str, Any], str, str], names: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    meta, path, digest = job
    carrier, report = load_carrier(meta, Path(path), seed=0)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        df = inj.inject(carrier, seed=seed)
        result = None
        recalls.append(result["recall"])
        precisions.append(result["precision"])
        fprs.append(result["fpr"])
    import pandas as pd

    stack = pd.concat(recalls, keys=range(len(recalls)))
    mean = stack.groupby(level=1, sort=False).mean()
    precision = (
        pd.concat(precisions, keys=range(len(precisions))).groupby(level=1, sort=False).mean()
    )
    fpr = pd.concat(fprs, axis=1).mean(axis=1)
    return {
        "uci_id": meta["uci_id"],
        "name": meta["name"],
        "sha256": digest,
        "carrier": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="split")),
        "precision_mean": json.loads(precision.to_json(orient="split")),
        "fpr_mean": json.loads(fpr.to_json()),
        "recall_seeds": [json.loads(r.to_json(orient="split")) for r in recalls],
    }


def x_run_one__mutmut_23(job: tuple[dict[str, Any], str, str], names: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    meta, path, digest = job
    carrier, report = load_carrier(meta, Path(path), seed=0)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        df = inj.inject(carrier, seed=seed)
        result = tb.evaluate(None, cols, seed, names)
        recalls.append(result["recall"])
        precisions.append(result["precision"])
        fprs.append(result["fpr"])
    import pandas as pd

    stack = pd.concat(recalls, keys=range(len(recalls)))
    mean = stack.groupby(level=1, sort=False).mean()
    precision = (
        pd.concat(precisions, keys=range(len(precisions))).groupby(level=1, sort=False).mean()
    )
    fpr = pd.concat(fprs, axis=1).mean(axis=1)
    return {
        "uci_id": meta["uci_id"],
        "name": meta["name"],
        "sha256": digest,
        "carrier": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="split")),
        "precision_mean": json.loads(precision.to_json(orient="split")),
        "fpr_mean": json.loads(fpr.to_json()),
        "recall_seeds": [json.loads(r.to_json(orient="split")) for r in recalls],
    }


def x_run_one__mutmut_24(job: tuple[dict[str, Any], str, str], names: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    meta, path, digest = job
    carrier, report = load_carrier(meta, Path(path), seed=0)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        df = inj.inject(carrier, seed=seed)
        result = tb.evaluate(df, None, seed, names)
        recalls.append(result["recall"])
        precisions.append(result["precision"])
        fprs.append(result["fpr"])
    import pandas as pd

    stack = pd.concat(recalls, keys=range(len(recalls)))
    mean = stack.groupby(level=1, sort=False).mean()
    precision = (
        pd.concat(precisions, keys=range(len(precisions))).groupby(level=1, sort=False).mean()
    )
    fpr = pd.concat(fprs, axis=1).mean(axis=1)
    return {
        "uci_id": meta["uci_id"],
        "name": meta["name"],
        "sha256": digest,
        "carrier": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="split")),
        "precision_mean": json.loads(precision.to_json(orient="split")),
        "fpr_mean": json.loads(fpr.to_json()),
        "recall_seeds": [json.loads(r.to_json(orient="split")) for r in recalls],
    }


def x_run_one__mutmut_25(job: tuple[dict[str, Any], str, str], names: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    meta, path, digest = job
    carrier, report = load_carrier(meta, Path(path), seed=0)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        df = inj.inject(carrier, seed=seed)
        result = tb.evaluate(df, cols, None, names)
        recalls.append(result["recall"])
        precisions.append(result["precision"])
        fprs.append(result["fpr"])
    import pandas as pd

    stack = pd.concat(recalls, keys=range(len(recalls)))
    mean = stack.groupby(level=1, sort=False).mean()
    precision = (
        pd.concat(precisions, keys=range(len(precisions))).groupby(level=1, sort=False).mean()
    )
    fpr = pd.concat(fprs, axis=1).mean(axis=1)
    return {
        "uci_id": meta["uci_id"],
        "name": meta["name"],
        "sha256": digest,
        "carrier": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="split")),
        "precision_mean": json.loads(precision.to_json(orient="split")),
        "fpr_mean": json.loads(fpr.to_json()),
        "recall_seeds": [json.loads(r.to_json(orient="split")) for r in recalls],
    }


def x_run_one__mutmut_26(job: tuple[dict[str, Any], str, str], names: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    meta, path, digest = job
    carrier, report = load_carrier(meta, Path(path), seed=0)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        df = inj.inject(carrier, seed=seed)
        result = tb.evaluate(df, cols, seed, None)
        recalls.append(result["recall"])
        precisions.append(result["precision"])
        fprs.append(result["fpr"])
    import pandas as pd

    stack = pd.concat(recalls, keys=range(len(recalls)))
    mean = stack.groupby(level=1, sort=False).mean()
    precision = (
        pd.concat(precisions, keys=range(len(precisions))).groupby(level=1, sort=False).mean()
    )
    fpr = pd.concat(fprs, axis=1).mean(axis=1)
    return {
        "uci_id": meta["uci_id"],
        "name": meta["name"],
        "sha256": digest,
        "carrier": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="split")),
        "precision_mean": json.loads(precision.to_json(orient="split")),
        "fpr_mean": json.loads(fpr.to_json()),
        "recall_seeds": [json.loads(r.to_json(orient="split")) for r in recalls],
    }


def x_run_one__mutmut_27(job: tuple[dict[str, Any], str, str], names: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    meta, path, digest = job
    carrier, report = load_carrier(meta, Path(path), seed=0)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        df = inj.inject(carrier, seed=seed)
        result = tb.evaluate(cols, seed, names)
        recalls.append(result["recall"])
        precisions.append(result["precision"])
        fprs.append(result["fpr"])
    import pandas as pd

    stack = pd.concat(recalls, keys=range(len(recalls)))
    mean = stack.groupby(level=1, sort=False).mean()
    precision = (
        pd.concat(precisions, keys=range(len(precisions))).groupby(level=1, sort=False).mean()
    )
    fpr = pd.concat(fprs, axis=1).mean(axis=1)
    return {
        "uci_id": meta["uci_id"],
        "name": meta["name"],
        "sha256": digest,
        "carrier": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="split")),
        "precision_mean": json.loads(precision.to_json(orient="split")),
        "fpr_mean": json.loads(fpr.to_json()),
        "recall_seeds": [json.loads(r.to_json(orient="split")) for r in recalls],
    }


def x_run_one__mutmut_28(job: tuple[dict[str, Any], str, str], names: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    meta, path, digest = job
    carrier, report = load_carrier(meta, Path(path), seed=0)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        df = inj.inject(carrier, seed=seed)
        result = tb.evaluate(df, seed, names)
        recalls.append(result["recall"])
        precisions.append(result["precision"])
        fprs.append(result["fpr"])
    import pandas as pd

    stack = pd.concat(recalls, keys=range(len(recalls)))
    mean = stack.groupby(level=1, sort=False).mean()
    precision = (
        pd.concat(precisions, keys=range(len(precisions))).groupby(level=1, sort=False).mean()
    )
    fpr = pd.concat(fprs, axis=1).mean(axis=1)
    return {
        "uci_id": meta["uci_id"],
        "name": meta["name"],
        "sha256": digest,
        "carrier": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="split")),
        "precision_mean": json.loads(precision.to_json(orient="split")),
        "fpr_mean": json.loads(fpr.to_json()),
        "recall_seeds": [json.loads(r.to_json(orient="split")) for r in recalls],
    }


def x_run_one__mutmut_29(job: tuple[dict[str, Any], str, str], names: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    meta, path, digest = job
    carrier, report = load_carrier(meta, Path(path), seed=0)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        df = inj.inject(carrier, seed=seed)
        result = tb.evaluate(df, cols, names)
        recalls.append(result["recall"])
        precisions.append(result["precision"])
        fprs.append(result["fpr"])
    import pandas as pd

    stack = pd.concat(recalls, keys=range(len(recalls)))
    mean = stack.groupby(level=1, sort=False).mean()
    precision = (
        pd.concat(precisions, keys=range(len(precisions))).groupby(level=1, sort=False).mean()
    )
    fpr = pd.concat(fprs, axis=1).mean(axis=1)
    return {
        "uci_id": meta["uci_id"],
        "name": meta["name"],
        "sha256": digest,
        "carrier": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="split")),
        "precision_mean": json.loads(precision.to_json(orient="split")),
        "fpr_mean": json.loads(fpr.to_json()),
        "recall_seeds": [json.loads(r.to_json(orient="split")) for r in recalls],
    }


def x_run_one__mutmut_30(job: tuple[dict[str, Any], str, str], names: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    meta, path, digest = job
    carrier, report = load_carrier(meta, Path(path), seed=0)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        df = inj.inject(carrier, seed=seed)
        result = tb.evaluate(df, cols, seed, )
        recalls.append(result["recall"])
        precisions.append(result["precision"])
        fprs.append(result["fpr"])
    import pandas as pd

    stack = pd.concat(recalls, keys=range(len(recalls)))
    mean = stack.groupby(level=1, sort=False).mean()
    precision = (
        pd.concat(precisions, keys=range(len(precisions))).groupby(level=1, sort=False).mean()
    )
    fpr = pd.concat(fprs, axis=1).mean(axis=1)
    return {
        "uci_id": meta["uci_id"],
        "name": meta["name"],
        "sha256": digest,
        "carrier": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="split")),
        "precision_mean": json.loads(precision.to_json(orient="split")),
        "fpr_mean": json.loads(fpr.to_json()),
        "recall_seeds": [json.loads(r.to_json(orient="split")) for r in recalls],
    }


def x_run_one__mutmut_31(job: tuple[dict[str, Any], str, str], names: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    meta, path, digest = job
    carrier, report = load_carrier(meta, Path(path), seed=0)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        df = inj.inject(carrier, seed=seed)
        result = tb.evaluate(df, cols, seed, names)
        recalls.append(None)
        precisions.append(result["precision"])
        fprs.append(result["fpr"])
    import pandas as pd

    stack = pd.concat(recalls, keys=range(len(recalls)))
    mean = stack.groupby(level=1, sort=False).mean()
    precision = (
        pd.concat(precisions, keys=range(len(precisions))).groupby(level=1, sort=False).mean()
    )
    fpr = pd.concat(fprs, axis=1).mean(axis=1)
    return {
        "uci_id": meta["uci_id"],
        "name": meta["name"],
        "sha256": digest,
        "carrier": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="split")),
        "precision_mean": json.loads(precision.to_json(orient="split")),
        "fpr_mean": json.loads(fpr.to_json()),
        "recall_seeds": [json.loads(r.to_json(orient="split")) for r in recalls],
    }


def x_run_one__mutmut_32(job: tuple[dict[str, Any], str, str], names: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    meta, path, digest = job
    carrier, report = load_carrier(meta, Path(path), seed=0)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        df = inj.inject(carrier, seed=seed)
        result = tb.evaluate(df, cols, seed, names)
        recalls.append(result["XXrecallXX"])
        precisions.append(result["precision"])
        fprs.append(result["fpr"])
    import pandas as pd

    stack = pd.concat(recalls, keys=range(len(recalls)))
    mean = stack.groupby(level=1, sort=False).mean()
    precision = (
        pd.concat(precisions, keys=range(len(precisions))).groupby(level=1, sort=False).mean()
    )
    fpr = pd.concat(fprs, axis=1).mean(axis=1)
    return {
        "uci_id": meta["uci_id"],
        "name": meta["name"],
        "sha256": digest,
        "carrier": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="split")),
        "precision_mean": json.loads(precision.to_json(orient="split")),
        "fpr_mean": json.loads(fpr.to_json()),
        "recall_seeds": [json.loads(r.to_json(orient="split")) for r in recalls],
    }


def x_run_one__mutmut_33(job: tuple[dict[str, Any], str, str], names: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    meta, path, digest = job
    carrier, report = load_carrier(meta, Path(path), seed=0)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        df = inj.inject(carrier, seed=seed)
        result = tb.evaluate(df, cols, seed, names)
        recalls.append(result["RECALL"])
        precisions.append(result["precision"])
        fprs.append(result["fpr"])
    import pandas as pd

    stack = pd.concat(recalls, keys=range(len(recalls)))
    mean = stack.groupby(level=1, sort=False).mean()
    precision = (
        pd.concat(precisions, keys=range(len(precisions))).groupby(level=1, sort=False).mean()
    )
    fpr = pd.concat(fprs, axis=1).mean(axis=1)
    return {
        "uci_id": meta["uci_id"],
        "name": meta["name"],
        "sha256": digest,
        "carrier": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="split")),
        "precision_mean": json.loads(precision.to_json(orient="split")),
        "fpr_mean": json.loads(fpr.to_json()),
        "recall_seeds": [json.loads(r.to_json(orient="split")) for r in recalls],
    }


def x_run_one__mutmut_34(job: tuple[dict[str, Any], str, str], names: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    meta, path, digest = job
    carrier, report = load_carrier(meta, Path(path), seed=0)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        df = inj.inject(carrier, seed=seed)
        result = tb.evaluate(df, cols, seed, names)
        recalls.append(result["recall"])
        precisions.append(None)
        fprs.append(result["fpr"])
    import pandas as pd

    stack = pd.concat(recalls, keys=range(len(recalls)))
    mean = stack.groupby(level=1, sort=False).mean()
    precision = (
        pd.concat(precisions, keys=range(len(precisions))).groupby(level=1, sort=False).mean()
    )
    fpr = pd.concat(fprs, axis=1).mean(axis=1)
    return {
        "uci_id": meta["uci_id"],
        "name": meta["name"],
        "sha256": digest,
        "carrier": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="split")),
        "precision_mean": json.loads(precision.to_json(orient="split")),
        "fpr_mean": json.loads(fpr.to_json()),
        "recall_seeds": [json.loads(r.to_json(orient="split")) for r in recalls],
    }


def x_run_one__mutmut_35(job: tuple[dict[str, Any], str, str], names: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    meta, path, digest = job
    carrier, report = load_carrier(meta, Path(path), seed=0)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        df = inj.inject(carrier, seed=seed)
        result = tb.evaluate(df, cols, seed, names)
        recalls.append(result["recall"])
        precisions.append(result["XXprecisionXX"])
        fprs.append(result["fpr"])
    import pandas as pd

    stack = pd.concat(recalls, keys=range(len(recalls)))
    mean = stack.groupby(level=1, sort=False).mean()
    precision = (
        pd.concat(precisions, keys=range(len(precisions))).groupby(level=1, sort=False).mean()
    )
    fpr = pd.concat(fprs, axis=1).mean(axis=1)
    return {
        "uci_id": meta["uci_id"],
        "name": meta["name"],
        "sha256": digest,
        "carrier": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="split")),
        "precision_mean": json.loads(precision.to_json(orient="split")),
        "fpr_mean": json.loads(fpr.to_json()),
        "recall_seeds": [json.loads(r.to_json(orient="split")) for r in recalls],
    }


def x_run_one__mutmut_36(job: tuple[dict[str, Any], str, str], names: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    meta, path, digest = job
    carrier, report = load_carrier(meta, Path(path), seed=0)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        df = inj.inject(carrier, seed=seed)
        result = tb.evaluate(df, cols, seed, names)
        recalls.append(result["recall"])
        precisions.append(result["PRECISION"])
        fprs.append(result["fpr"])
    import pandas as pd

    stack = pd.concat(recalls, keys=range(len(recalls)))
    mean = stack.groupby(level=1, sort=False).mean()
    precision = (
        pd.concat(precisions, keys=range(len(precisions))).groupby(level=1, sort=False).mean()
    )
    fpr = pd.concat(fprs, axis=1).mean(axis=1)
    return {
        "uci_id": meta["uci_id"],
        "name": meta["name"],
        "sha256": digest,
        "carrier": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="split")),
        "precision_mean": json.loads(precision.to_json(orient="split")),
        "fpr_mean": json.loads(fpr.to_json()),
        "recall_seeds": [json.loads(r.to_json(orient="split")) for r in recalls],
    }


def x_run_one__mutmut_37(job: tuple[dict[str, Any], str, str], names: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    meta, path, digest = job
    carrier, report = load_carrier(meta, Path(path), seed=0)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        df = inj.inject(carrier, seed=seed)
        result = tb.evaluate(df, cols, seed, names)
        recalls.append(result["recall"])
        precisions.append(result["precision"])
        fprs.append(None)
    import pandas as pd

    stack = pd.concat(recalls, keys=range(len(recalls)))
    mean = stack.groupby(level=1, sort=False).mean()
    precision = (
        pd.concat(precisions, keys=range(len(precisions))).groupby(level=1, sort=False).mean()
    )
    fpr = pd.concat(fprs, axis=1).mean(axis=1)
    return {
        "uci_id": meta["uci_id"],
        "name": meta["name"],
        "sha256": digest,
        "carrier": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="split")),
        "precision_mean": json.loads(precision.to_json(orient="split")),
        "fpr_mean": json.loads(fpr.to_json()),
        "recall_seeds": [json.loads(r.to_json(orient="split")) for r in recalls],
    }


def x_run_one__mutmut_38(job: tuple[dict[str, Any], str, str], names: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    meta, path, digest = job
    carrier, report = load_carrier(meta, Path(path), seed=0)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        df = inj.inject(carrier, seed=seed)
        result = tb.evaluate(df, cols, seed, names)
        recalls.append(result["recall"])
        precisions.append(result["precision"])
        fprs.append(result["XXfprXX"])
    import pandas as pd

    stack = pd.concat(recalls, keys=range(len(recalls)))
    mean = stack.groupby(level=1, sort=False).mean()
    precision = (
        pd.concat(precisions, keys=range(len(precisions))).groupby(level=1, sort=False).mean()
    )
    fpr = pd.concat(fprs, axis=1).mean(axis=1)
    return {
        "uci_id": meta["uci_id"],
        "name": meta["name"],
        "sha256": digest,
        "carrier": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="split")),
        "precision_mean": json.loads(precision.to_json(orient="split")),
        "fpr_mean": json.loads(fpr.to_json()),
        "recall_seeds": [json.loads(r.to_json(orient="split")) for r in recalls],
    }


def x_run_one__mutmut_39(job: tuple[dict[str, Any], str, str], names: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    meta, path, digest = job
    carrier, report = load_carrier(meta, Path(path), seed=0)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        df = inj.inject(carrier, seed=seed)
        result = tb.evaluate(df, cols, seed, names)
        recalls.append(result["recall"])
        precisions.append(result["precision"])
        fprs.append(result["FPR"])
    import pandas as pd

    stack = pd.concat(recalls, keys=range(len(recalls)))
    mean = stack.groupby(level=1, sort=False).mean()
    precision = (
        pd.concat(precisions, keys=range(len(precisions))).groupby(level=1, sort=False).mean()
    )
    fpr = pd.concat(fprs, axis=1).mean(axis=1)
    return {
        "uci_id": meta["uci_id"],
        "name": meta["name"],
        "sha256": digest,
        "carrier": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="split")),
        "precision_mean": json.loads(precision.to_json(orient="split")),
        "fpr_mean": json.loads(fpr.to_json()),
        "recall_seeds": [json.loads(r.to_json(orient="split")) for r in recalls],
    }


def x_run_one__mutmut_40(job: tuple[dict[str, Any], str, str], names: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    meta, path, digest = job
    carrier, report = load_carrier(meta, Path(path), seed=0)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        df = inj.inject(carrier, seed=seed)
        result = tb.evaluate(df, cols, seed, names)
        recalls.append(result["recall"])
        precisions.append(result["precision"])
        fprs.append(result["fpr"])
    import pandas as pd

    stack = None
    mean = stack.groupby(level=1, sort=False).mean()
    precision = (
        pd.concat(precisions, keys=range(len(precisions))).groupby(level=1, sort=False).mean()
    )
    fpr = pd.concat(fprs, axis=1).mean(axis=1)
    return {
        "uci_id": meta["uci_id"],
        "name": meta["name"],
        "sha256": digest,
        "carrier": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="split")),
        "precision_mean": json.loads(precision.to_json(orient="split")),
        "fpr_mean": json.loads(fpr.to_json()),
        "recall_seeds": [json.loads(r.to_json(orient="split")) for r in recalls],
    }


def x_run_one__mutmut_41(job: tuple[dict[str, Any], str, str], names: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    meta, path, digest = job
    carrier, report = load_carrier(meta, Path(path), seed=0)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        df = inj.inject(carrier, seed=seed)
        result = tb.evaluate(df, cols, seed, names)
        recalls.append(result["recall"])
        precisions.append(result["precision"])
        fprs.append(result["fpr"])
    import pandas as pd

    stack = pd.concat(None, keys=range(len(recalls)))
    mean = stack.groupby(level=1, sort=False).mean()
    precision = (
        pd.concat(precisions, keys=range(len(precisions))).groupby(level=1, sort=False).mean()
    )
    fpr = pd.concat(fprs, axis=1).mean(axis=1)
    return {
        "uci_id": meta["uci_id"],
        "name": meta["name"],
        "sha256": digest,
        "carrier": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="split")),
        "precision_mean": json.loads(precision.to_json(orient="split")),
        "fpr_mean": json.loads(fpr.to_json()),
        "recall_seeds": [json.loads(r.to_json(orient="split")) for r in recalls],
    }


def x_run_one__mutmut_42(job: tuple[dict[str, Any], str, str], names: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    meta, path, digest = job
    carrier, report = load_carrier(meta, Path(path), seed=0)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        df = inj.inject(carrier, seed=seed)
        result = tb.evaluate(df, cols, seed, names)
        recalls.append(result["recall"])
        precisions.append(result["precision"])
        fprs.append(result["fpr"])
    import pandas as pd

    stack = pd.concat(recalls, keys=None)
    mean = stack.groupby(level=1, sort=False).mean()
    precision = (
        pd.concat(precisions, keys=range(len(precisions))).groupby(level=1, sort=False).mean()
    )
    fpr = pd.concat(fprs, axis=1).mean(axis=1)
    return {
        "uci_id": meta["uci_id"],
        "name": meta["name"],
        "sha256": digest,
        "carrier": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="split")),
        "precision_mean": json.loads(precision.to_json(orient="split")),
        "fpr_mean": json.loads(fpr.to_json()),
        "recall_seeds": [json.loads(r.to_json(orient="split")) for r in recalls],
    }


def x_run_one__mutmut_43(job: tuple[dict[str, Any], str, str], names: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    meta, path, digest = job
    carrier, report = load_carrier(meta, Path(path), seed=0)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        df = inj.inject(carrier, seed=seed)
        result = tb.evaluate(df, cols, seed, names)
        recalls.append(result["recall"])
        precisions.append(result["precision"])
        fprs.append(result["fpr"])
    import pandas as pd

    stack = pd.concat(keys=range(len(recalls)))
    mean = stack.groupby(level=1, sort=False).mean()
    precision = (
        pd.concat(precisions, keys=range(len(precisions))).groupby(level=1, sort=False).mean()
    )
    fpr = pd.concat(fprs, axis=1).mean(axis=1)
    return {
        "uci_id": meta["uci_id"],
        "name": meta["name"],
        "sha256": digest,
        "carrier": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="split")),
        "precision_mean": json.loads(precision.to_json(orient="split")),
        "fpr_mean": json.loads(fpr.to_json()),
        "recall_seeds": [json.loads(r.to_json(orient="split")) for r in recalls],
    }


def x_run_one__mutmut_44(job: tuple[dict[str, Any], str, str], names: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    meta, path, digest = job
    carrier, report = load_carrier(meta, Path(path), seed=0)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        df = inj.inject(carrier, seed=seed)
        result = tb.evaluate(df, cols, seed, names)
        recalls.append(result["recall"])
        precisions.append(result["precision"])
        fprs.append(result["fpr"])
    import pandas as pd

    stack = pd.concat(recalls, )
    mean = stack.groupby(level=1, sort=False).mean()
    precision = (
        pd.concat(precisions, keys=range(len(precisions))).groupby(level=1, sort=False).mean()
    )
    fpr = pd.concat(fprs, axis=1).mean(axis=1)
    return {
        "uci_id": meta["uci_id"],
        "name": meta["name"],
        "sha256": digest,
        "carrier": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="split")),
        "precision_mean": json.loads(precision.to_json(orient="split")),
        "fpr_mean": json.loads(fpr.to_json()),
        "recall_seeds": [json.loads(r.to_json(orient="split")) for r in recalls],
    }


def x_run_one__mutmut_45(job: tuple[dict[str, Any], str, str], names: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    meta, path, digest = job
    carrier, report = load_carrier(meta, Path(path), seed=0)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        df = inj.inject(carrier, seed=seed)
        result = tb.evaluate(df, cols, seed, names)
        recalls.append(result["recall"])
        precisions.append(result["precision"])
        fprs.append(result["fpr"])
    import pandas as pd

    stack = pd.concat(recalls, keys=range(None))
    mean = stack.groupby(level=1, sort=False).mean()
    precision = (
        pd.concat(precisions, keys=range(len(precisions))).groupby(level=1, sort=False).mean()
    )
    fpr = pd.concat(fprs, axis=1).mean(axis=1)
    return {
        "uci_id": meta["uci_id"],
        "name": meta["name"],
        "sha256": digest,
        "carrier": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="split")),
        "precision_mean": json.loads(precision.to_json(orient="split")),
        "fpr_mean": json.loads(fpr.to_json()),
        "recall_seeds": [json.loads(r.to_json(orient="split")) for r in recalls],
    }


def x_run_one__mutmut_46(job: tuple[dict[str, Any], str, str], names: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    meta, path, digest = job
    carrier, report = load_carrier(meta, Path(path), seed=0)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        df = inj.inject(carrier, seed=seed)
        result = tb.evaluate(df, cols, seed, names)
        recalls.append(result["recall"])
        precisions.append(result["precision"])
        fprs.append(result["fpr"])
    import pandas as pd

    stack = pd.concat(recalls, keys=range(len(recalls)))
    mean = None
    precision = (
        pd.concat(precisions, keys=range(len(precisions))).groupby(level=1, sort=False).mean()
    )
    fpr = pd.concat(fprs, axis=1).mean(axis=1)
    return {
        "uci_id": meta["uci_id"],
        "name": meta["name"],
        "sha256": digest,
        "carrier": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="split")),
        "precision_mean": json.loads(precision.to_json(orient="split")),
        "fpr_mean": json.loads(fpr.to_json()),
        "recall_seeds": [json.loads(r.to_json(orient="split")) for r in recalls],
    }


def x_run_one__mutmut_47(job: tuple[dict[str, Any], str, str], names: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    meta, path, digest = job
    carrier, report = load_carrier(meta, Path(path), seed=0)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        df = inj.inject(carrier, seed=seed)
        result = tb.evaluate(df, cols, seed, names)
        recalls.append(result["recall"])
        precisions.append(result["precision"])
        fprs.append(result["fpr"])
    import pandas as pd

    stack = pd.concat(recalls, keys=range(len(recalls)))
    mean = stack.groupby(level=None, sort=False).mean()
    precision = (
        pd.concat(precisions, keys=range(len(precisions))).groupby(level=1, sort=False).mean()
    )
    fpr = pd.concat(fprs, axis=1).mean(axis=1)
    return {
        "uci_id": meta["uci_id"],
        "name": meta["name"],
        "sha256": digest,
        "carrier": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="split")),
        "precision_mean": json.loads(precision.to_json(orient="split")),
        "fpr_mean": json.loads(fpr.to_json()),
        "recall_seeds": [json.loads(r.to_json(orient="split")) for r in recalls],
    }


def x_run_one__mutmut_48(job: tuple[dict[str, Any], str, str], names: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    meta, path, digest = job
    carrier, report = load_carrier(meta, Path(path), seed=0)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        df = inj.inject(carrier, seed=seed)
        result = tb.evaluate(df, cols, seed, names)
        recalls.append(result["recall"])
        precisions.append(result["precision"])
        fprs.append(result["fpr"])
    import pandas as pd

    stack = pd.concat(recalls, keys=range(len(recalls)))
    mean = stack.groupby(level=1, sort=None).mean()
    precision = (
        pd.concat(precisions, keys=range(len(precisions))).groupby(level=1, sort=False).mean()
    )
    fpr = pd.concat(fprs, axis=1).mean(axis=1)
    return {
        "uci_id": meta["uci_id"],
        "name": meta["name"],
        "sha256": digest,
        "carrier": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="split")),
        "precision_mean": json.loads(precision.to_json(orient="split")),
        "fpr_mean": json.loads(fpr.to_json()),
        "recall_seeds": [json.loads(r.to_json(orient="split")) for r in recalls],
    }


def x_run_one__mutmut_49(job: tuple[dict[str, Any], str, str], names: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    meta, path, digest = job
    carrier, report = load_carrier(meta, Path(path), seed=0)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        df = inj.inject(carrier, seed=seed)
        result = tb.evaluate(df, cols, seed, names)
        recalls.append(result["recall"])
        precisions.append(result["precision"])
        fprs.append(result["fpr"])
    import pandas as pd

    stack = pd.concat(recalls, keys=range(len(recalls)))
    mean = stack.groupby(sort=False).mean()
    precision = (
        pd.concat(precisions, keys=range(len(precisions))).groupby(level=1, sort=False).mean()
    )
    fpr = pd.concat(fprs, axis=1).mean(axis=1)
    return {
        "uci_id": meta["uci_id"],
        "name": meta["name"],
        "sha256": digest,
        "carrier": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="split")),
        "precision_mean": json.loads(precision.to_json(orient="split")),
        "fpr_mean": json.loads(fpr.to_json()),
        "recall_seeds": [json.loads(r.to_json(orient="split")) for r in recalls],
    }


def x_run_one__mutmut_50(job: tuple[dict[str, Any], str, str], names: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    meta, path, digest = job
    carrier, report = load_carrier(meta, Path(path), seed=0)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        df = inj.inject(carrier, seed=seed)
        result = tb.evaluate(df, cols, seed, names)
        recalls.append(result["recall"])
        precisions.append(result["precision"])
        fprs.append(result["fpr"])
    import pandas as pd

    stack = pd.concat(recalls, keys=range(len(recalls)))
    mean = stack.groupby(level=1, ).mean()
    precision = (
        pd.concat(precisions, keys=range(len(precisions))).groupby(level=1, sort=False).mean()
    )
    fpr = pd.concat(fprs, axis=1).mean(axis=1)
    return {
        "uci_id": meta["uci_id"],
        "name": meta["name"],
        "sha256": digest,
        "carrier": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="split")),
        "precision_mean": json.loads(precision.to_json(orient="split")),
        "fpr_mean": json.loads(fpr.to_json()),
        "recall_seeds": [json.loads(r.to_json(orient="split")) for r in recalls],
    }


def x_run_one__mutmut_51(job: tuple[dict[str, Any], str, str], names: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    meta, path, digest = job
    carrier, report = load_carrier(meta, Path(path), seed=0)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        df = inj.inject(carrier, seed=seed)
        result = tb.evaluate(df, cols, seed, names)
        recalls.append(result["recall"])
        precisions.append(result["precision"])
        fprs.append(result["fpr"])
    import pandas as pd

    stack = pd.concat(recalls, keys=range(len(recalls)))
    mean = stack.groupby(level=2, sort=False).mean()
    precision = (
        pd.concat(precisions, keys=range(len(precisions))).groupby(level=1, sort=False).mean()
    )
    fpr = pd.concat(fprs, axis=1).mean(axis=1)
    return {
        "uci_id": meta["uci_id"],
        "name": meta["name"],
        "sha256": digest,
        "carrier": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="split")),
        "precision_mean": json.loads(precision.to_json(orient="split")),
        "fpr_mean": json.loads(fpr.to_json()),
        "recall_seeds": [json.loads(r.to_json(orient="split")) for r in recalls],
    }


def x_run_one__mutmut_52(job: tuple[dict[str, Any], str, str], names: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    meta, path, digest = job
    carrier, report = load_carrier(meta, Path(path), seed=0)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        df = inj.inject(carrier, seed=seed)
        result = tb.evaluate(df, cols, seed, names)
        recalls.append(result["recall"])
        precisions.append(result["precision"])
        fprs.append(result["fpr"])
    import pandas as pd

    stack = pd.concat(recalls, keys=range(len(recalls)))
    mean = stack.groupby(level=1, sort=True).mean()
    precision = (
        pd.concat(precisions, keys=range(len(precisions))).groupby(level=1, sort=False).mean()
    )
    fpr = pd.concat(fprs, axis=1).mean(axis=1)
    return {
        "uci_id": meta["uci_id"],
        "name": meta["name"],
        "sha256": digest,
        "carrier": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="split")),
        "precision_mean": json.loads(precision.to_json(orient="split")),
        "fpr_mean": json.loads(fpr.to_json()),
        "recall_seeds": [json.loads(r.to_json(orient="split")) for r in recalls],
    }


def x_run_one__mutmut_53(job: tuple[dict[str, Any], str, str], names: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    meta, path, digest = job
    carrier, report = load_carrier(meta, Path(path), seed=0)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        df = inj.inject(carrier, seed=seed)
        result = tb.evaluate(df, cols, seed, names)
        recalls.append(result["recall"])
        precisions.append(result["precision"])
        fprs.append(result["fpr"])
    import pandas as pd

    stack = pd.concat(recalls, keys=range(len(recalls)))
    mean = stack.groupby(level=1, sort=False).mean()
    precision = None
    fpr = pd.concat(fprs, axis=1).mean(axis=1)
    return {
        "uci_id": meta["uci_id"],
        "name": meta["name"],
        "sha256": digest,
        "carrier": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="split")),
        "precision_mean": json.loads(precision.to_json(orient="split")),
        "fpr_mean": json.loads(fpr.to_json()),
        "recall_seeds": [json.loads(r.to_json(orient="split")) for r in recalls],
    }


def x_run_one__mutmut_54(job: tuple[dict[str, Any], str, str], names: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    meta, path, digest = job
    carrier, report = load_carrier(meta, Path(path), seed=0)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        df = inj.inject(carrier, seed=seed)
        result = tb.evaluate(df, cols, seed, names)
        recalls.append(result["recall"])
        precisions.append(result["precision"])
        fprs.append(result["fpr"])
    import pandas as pd

    stack = pd.concat(recalls, keys=range(len(recalls)))
    mean = stack.groupby(level=1, sort=False).mean()
    precision = (
        pd.concat(precisions, keys=range(len(precisions))).groupby(level=None, sort=False).mean()
    )
    fpr = pd.concat(fprs, axis=1).mean(axis=1)
    return {
        "uci_id": meta["uci_id"],
        "name": meta["name"],
        "sha256": digest,
        "carrier": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="split")),
        "precision_mean": json.loads(precision.to_json(orient="split")),
        "fpr_mean": json.loads(fpr.to_json()),
        "recall_seeds": [json.loads(r.to_json(orient="split")) for r in recalls],
    }


def x_run_one__mutmut_55(job: tuple[dict[str, Any], str, str], names: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    meta, path, digest = job
    carrier, report = load_carrier(meta, Path(path), seed=0)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        df = inj.inject(carrier, seed=seed)
        result = tb.evaluate(df, cols, seed, names)
        recalls.append(result["recall"])
        precisions.append(result["precision"])
        fprs.append(result["fpr"])
    import pandas as pd

    stack = pd.concat(recalls, keys=range(len(recalls)))
    mean = stack.groupby(level=1, sort=False).mean()
    precision = (
        pd.concat(precisions, keys=range(len(precisions))).groupby(level=1, sort=None).mean()
    )
    fpr = pd.concat(fprs, axis=1).mean(axis=1)
    return {
        "uci_id": meta["uci_id"],
        "name": meta["name"],
        "sha256": digest,
        "carrier": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="split")),
        "precision_mean": json.loads(precision.to_json(orient="split")),
        "fpr_mean": json.loads(fpr.to_json()),
        "recall_seeds": [json.loads(r.to_json(orient="split")) for r in recalls],
    }


def x_run_one__mutmut_56(job: tuple[dict[str, Any], str, str], names: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    meta, path, digest = job
    carrier, report = load_carrier(meta, Path(path), seed=0)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        df = inj.inject(carrier, seed=seed)
        result = tb.evaluate(df, cols, seed, names)
        recalls.append(result["recall"])
        precisions.append(result["precision"])
        fprs.append(result["fpr"])
    import pandas as pd

    stack = pd.concat(recalls, keys=range(len(recalls)))
    mean = stack.groupby(level=1, sort=False).mean()
    precision = (
        pd.concat(precisions, keys=range(len(precisions))).groupby(sort=False).mean()
    )
    fpr = pd.concat(fprs, axis=1).mean(axis=1)
    return {
        "uci_id": meta["uci_id"],
        "name": meta["name"],
        "sha256": digest,
        "carrier": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="split")),
        "precision_mean": json.loads(precision.to_json(orient="split")),
        "fpr_mean": json.loads(fpr.to_json()),
        "recall_seeds": [json.loads(r.to_json(orient="split")) for r in recalls],
    }


def x_run_one__mutmut_57(job: tuple[dict[str, Any], str, str], names: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    meta, path, digest = job
    carrier, report = load_carrier(meta, Path(path), seed=0)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        df = inj.inject(carrier, seed=seed)
        result = tb.evaluate(df, cols, seed, names)
        recalls.append(result["recall"])
        precisions.append(result["precision"])
        fprs.append(result["fpr"])
    import pandas as pd

    stack = pd.concat(recalls, keys=range(len(recalls)))
    mean = stack.groupby(level=1, sort=False).mean()
    precision = (
        pd.concat(precisions, keys=range(len(precisions))).groupby(level=1, ).mean()
    )
    fpr = pd.concat(fprs, axis=1).mean(axis=1)
    return {
        "uci_id": meta["uci_id"],
        "name": meta["name"],
        "sha256": digest,
        "carrier": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="split")),
        "precision_mean": json.loads(precision.to_json(orient="split")),
        "fpr_mean": json.loads(fpr.to_json()),
        "recall_seeds": [json.loads(r.to_json(orient="split")) for r in recalls],
    }


def x_run_one__mutmut_58(job: tuple[dict[str, Any], str, str], names: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    meta, path, digest = job
    carrier, report = load_carrier(meta, Path(path), seed=0)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        df = inj.inject(carrier, seed=seed)
        result = tb.evaluate(df, cols, seed, names)
        recalls.append(result["recall"])
        precisions.append(result["precision"])
        fprs.append(result["fpr"])
    import pandas as pd

    stack = pd.concat(recalls, keys=range(len(recalls)))
    mean = stack.groupby(level=1, sort=False).mean()
    precision = (
        pd.concat(None, keys=range(len(precisions))).groupby(level=1, sort=False).mean()
    )
    fpr = pd.concat(fprs, axis=1).mean(axis=1)
    return {
        "uci_id": meta["uci_id"],
        "name": meta["name"],
        "sha256": digest,
        "carrier": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="split")),
        "precision_mean": json.loads(precision.to_json(orient="split")),
        "fpr_mean": json.loads(fpr.to_json()),
        "recall_seeds": [json.loads(r.to_json(orient="split")) for r in recalls],
    }


def x_run_one__mutmut_59(job: tuple[dict[str, Any], str, str], names: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    meta, path, digest = job
    carrier, report = load_carrier(meta, Path(path), seed=0)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        df = inj.inject(carrier, seed=seed)
        result = tb.evaluate(df, cols, seed, names)
        recalls.append(result["recall"])
        precisions.append(result["precision"])
        fprs.append(result["fpr"])
    import pandas as pd

    stack = pd.concat(recalls, keys=range(len(recalls)))
    mean = stack.groupby(level=1, sort=False).mean()
    precision = (
        pd.concat(precisions, keys=None).groupby(level=1, sort=False).mean()
    )
    fpr = pd.concat(fprs, axis=1).mean(axis=1)
    return {
        "uci_id": meta["uci_id"],
        "name": meta["name"],
        "sha256": digest,
        "carrier": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="split")),
        "precision_mean": json.loads(precision.to_json(orient="split")),
        "fpr_mean": json.loads(fpr.to_json()),
        "recall_seeds": [json.loads(r.to_json(orient="split")) for r in recalls],
    }


def x_run_one__mutmut_60(job: tuple[dict[str, Any], str, str], names: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    meta, path, digest = job
    carrier, report = load_carrier(meta, Path(path), seed=0)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        df = inj.inject(carrier, seed=seed)
        result = tb.evaluate(df, cols, seed, names)
        recalls.append(result["recall"])
        precisions.append(result["precision"])
        fprs.append(result["fpr"])
    import pandas as pd

    stack = pd.concat(recalls, keys=range(len(recalls)))
    mean = stack.groupby(level=1, sort=False).mean()
    precision = (
        pd.concat(keys=range(len(precisions))).groupby(level=1, sort=False).mean()
    )
    fpr = pd.concat(fprs, axis=1).mean(axis=1)
    return {
        "uci_id": meta["uci_id"],
        "name": meta["name"],
        "sha256": digest,
        "carrier": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="split")),
        "precision_mean": json.loads(precision.to_json(orient="split")),
        "fpr_mean": json.loads(fpr.to_json()),
        "recall_seeds": [json.loads(r.to_json(orient="split")) for r in recalls],
    }


def x_run_one__mutmut_61(job: tuple[dict[str, Any], str, str], names: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    meta, path, digest = job
    carrier, report = load_carrier(meta, Path(path), seed=0)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        df = inj.inject(carrier, seed=seed)
        result = tb.evaluate(df, cols, seed, names)
        recalls.append(result["recall"])
        precisions.append(result["precision"])
        fprs.append(result["fpr"])
    import pandas as pd

    stack = pd.concat(recalls, keys=range(len(recalls)))
    mean = stack.groupby(level=1, sort=False).mean()
    precision = (
        pd.concat(precisions, ).groupby(level=1, sort=False).mean()
    )
    fpr = pd.concat(fprs, axis=1).mean(axis=1)
    return {
        "uci_id": meta["uci_id"],
        "name": meta["name"],
        "sha256": digest,
        "carrier": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="split")),
        "precision_mean": json.loads(precision.to_json(orient="split")),
        "fpr_mean": json.loads(fpr.to_json()),
        "recall_seeds": [json.loads(r.to_json(orient="split")) for r in recalls],
    }


def x_run_one__mutmut_62(job: tuple[dict[str, Any], str, str], names: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    meta, path, digest = job
    carrier, report = load_carrier(meta, Path(path), seed=0)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        df = inj.inject(carrier, seed=seed)
        result = tb.evaluate(df, cols, seed, names)
        recalls.append(result["recall"])
        precisions.append(result["precision"])
        fprs.append(result["fpr"])
    import pandas as pd

    stack = pd.concat(recalls, keys=range(len(recalls)))
    mean = stack.groupby(level=1, sort=False).mean()
    precision = (
        pd.concat(precisions, keys=range(None)).groupby(level=1, sort=False).mean()
    )
    fpr = pd.concat(fprs, axis=1).mean(axis=1)
    return {
        "uci_id": meta["uci_id"],
        "name": meta["name"],
        "sha256": digest,
        "carrier": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="split")),
        "precision_mean": json.loads(precision.to_json(orient="split")),
        "fpr_mean": json.loads(fpr.to_json()),
        "recall_seeds": [json.loads(r.to_json(orient="split")) for r in recalls],
    }


def x_run_one__mutmut_63(job: tuple[dict[str, Any], str, str], names: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    meta, path, digest = job
    carrier, report = load_carrier(meta, Path(path), seed=0)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        df = inj.inject(carrier, seed=seed)
        result = tb.evaluate(df, cols, seed, names)
        recalls.append(result["recall"])
        precisions.append(result["precision"])
        fprs.append(result["fpr"])
    import pandas as pd

    stack = pd.concat(recalls, keys=range(len(recalls)))
    mean = stack.groupby(level=1, sort=False).mean()
    precision = (
        pd.concat(precisions, keys=range(len(precisions))).groupby(level=2, sort=False).mean()
    )
    fpr = pd.concat(fprs, axis=1).mean(axis=1)
    return {
        "uci_id": meta["uci_id"],
        "name": meta["name"],
        "sha256": digest,
        "carrier": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="split")),
        "precision_mean": json.loads(precision.to_json(orient="split")),
        "fpr_mean": json.loads(fpr.to_json()),
        "recall_seeds": [json.loads(r.to_json(orient="split")) for r in recalls],
    }


def x_run_one__mutmut_64(job: tuple[dict[str, Any], str, str], names: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    meta, path, digest = job
    carrier, report = load_carrier(meta, Path(path), seed=0)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        df = inj.inject(carrier, seed=seed)
        result = tb.evaluate(df, cols, seed, names)
        recalls.append(result["recall"])
        precisions.append(result["precision"])
        fprs.append(result["fpr"])
    import pandas as pd

    stack = pd.concat(recalls, keys=range(len(recalls)))
    mean = stack.groupby(level=1, sort=False).mean()
    precision = (
        pd.concat(precisions, keys=range(len(precisions))).groupby(level=1, sort=True).mean()
    )
    fpr = pd.concat(fprs, axis=1).mean(axis=1)
    return {
        "uci_id": meta["uci_id"],
        "name": meta["name"],
        "sha256": digest,
        "carrier": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="split")),
        "precision_mean": json.loads(precision.to_json(orient="split")),
        "fpr_mean": json.loads(fpr.to_json()),
        "recall_seeds": [json.loads(r.to_json(orient="split")) for r in recalls],
    }


def x_run_one__mutmut_65(job: tuple[dict[str, Any], str, str], names: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    meta, path, digest = job
    carrier, report = load_carrier(meta, Path(path), seed=0)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        df = inj.inject(carrier, seed=seed)
        result = tb.evaluate(df, cols, seed, names)
        recalls.append(result["recall"])
        precisions.append(result["precision"])
        fprs.append(result["fpr"])
    import pandas as pd

    stack = pd.concat(recalls, keys=range(len(recalls)))
    mean = stack.groupby(level=1, sort=False).mean()
    precision = (
        pd.concat(precisions, keys=range(len(precisions))).groupby(level=1, sort=False).mean()
    )
    fpr = None
    return {
        "uci_id": meta["uci_id"],
        "name": meta["name"],
        "sha256": digest,
        "carrier": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="split")),
        "precision_mean": json.loads(precision.to_json(orient="split")),
        "fpr_mean": json.loads(fpr.to_json()),
        "recall_seeds": [json.loads(r.to_json(orient="split")) for r in recalls],
    }


def x_run_one__mutmut_66(job: tuple[dict[str, Any], str, str], names: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    meta, path, digest = job
    carrier, report = load_carrier(meta, Path(path), seed=0)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        df = inj.inject(carrier, seed=seed)
        result = tb.evaluate(df, cols, seed, names)
        recalls.append(result["recall"])
        precisions.append(result["precision"])
        fprs.append(result["fpr"])
    import pandas as pd

    stack = pd.concat(recalls, keys=range(len(recalls)))
    mean = stack.groupby(level=1, sort=False).mean()
    precision = (
        pd.concat(precisions, keys=range(len(precisions))).groupby(level=1, sort=False).mean()
    )
    fpr = pd.concat(fprs, axis=1).mean(axis=None)
    return {
        "uci_id": meta["uci_id"],
        "name": meta["name"],
        "sha256": digest,
        "carrier": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="split")),
        "precision_mean": json.loads(precision.to_json(orient="split")),
        "fpr_mean": json.loads(fpr.to_json()),
        "recall_seeds": [json.loads(r.to_json(orient="split")) for r in recalls],
    }


def x_run_one__mutmut_67(job: tuple[dict[str, Any], str, str], names: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    meta, path, digest = job
    carrier, report = load_carrier(meta, Path(path), seed=0)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        df = inj.inject(carrier, seed=seed)
        result = tb.evaluate(df, cols, seed, names)
        recalls.append(result["recall"])
        precisions.append(result["precision"])
        fprs.append(result["fpr"])
    import pandas as pd

    stack = pd.concat(recalls, keys=range(len(recalls)))
    mean = stack.groupby(level=1, sort=False).mean()
    precision = (
        pd.concat(precisions, keys=range(len(precisions))).groupby(level=1, sort=False).mean()
    )
    fpr = pd.concat(None, axis=1).mean(axis=1)
    return {
        "uci_id": meta["uci_id"],
        "name": meta["name"],
        "sha256": digest,
        "carrier": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="split")),
        "precision_mean": json.loads(precision.to_json(orient="split")),
        "fpr_mean": json.loads(fpr.to_json()),
        "recall_seeds": [json.loads(r.to_json(orient="split")) for r in recalls],
    }


def x_run_one__mutmut_68(job: tuple[dict[str, Any], str, str], names: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    meta, path, digest = job
    carrier, report = load_carrier(meta, Path(path), seed=0)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        df = inj.inject(carrier, seed=seed)
        result = tb.evaluate(df, cols, seed, names)
        recalls.append(result["recall"])
        precisions.append(result["precision"])
        fprs.append(result["fpr"])
    import pandas as pd

    stack = pd.concat(recalls, keys=range(len(recalls)))
    mean = stack.groupby(level=1, sort=False).mean()
    precision = (
        pd.concat(precisions, keys=range(len(precisions))).groupby(level=1, sort=False).mean()
    )
    fpr = pd.concat(fprs, axis=None).mean(axis=1)
    return {
        "uci_id": meta["uci_id"],
        "name": meta["name"],
        "sha256": digest,
        "carrier": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="split")),
        "precision_mean": json.loads(precision.to_json(orient="split")),
        "fpr_mean": json.loads(fpr.to_json()),
        "recall_seeds": [json.loads(r.to_json(orient="split")) for r in recalls],
    }


def x_run_one__mutmut_69(job: tuple[dict[str, Any], str, str], names: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    meta, path, digest = job
    carrier, report = load_carrier(meta, Path(path), seed=0)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        df = inj.inject(carrier, seed=seed)
        result = tb.evaluate(df, cols, seed, names)
        recalls.append(result["recall"])
        precisions.append(result["precision"])
        fprs.append(result["fpr"])
    import pandas as pd

    stack = pd.concat(recalls, keys=range(len(recalls)))
    mean = stack.groupby(level=1, sort=False).mean()
    precision = (
        pd.concat(precisions, keys=range(len(precisions))).groupby(level=1, sort=False).mean()
    )
    fpr = pd.concat(axis=1).mean(axis=1)
    return {
        "uci_id": meta["uci_id"],
        "name": meta["name"],
        "sha256": digest,
        "carrier": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="split")),
        "precision_mean": json.loads(precision.to_json(orient="split")),
        "fpr_mean": json.loads(fpr.to_json()),
        "recall_seeds": [json.loads(r.to_json(orient="split")) for r in recalls],
    }


def x_run_one__mutmut_70(job: tuple[dict[str, Any], str, str], names: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    meta, path, digest = job
    carrier, report = load_carrier(meta, Path(path), seed=0)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        df = inj.inject(carrier, seed=seed)
        result = tb.evaluate(df, cols, seed, names)
        recalls.append(result["recall"])
        precisions.append(result["precision"])
        fprs.append(result["fpr"])
    import pandas as pd

    stack = pd.concat(recalls, keys=range(len(recalls)))
    mean = stack.groupby(level=1, sort=False).mean()
    precision = (
        pd.concat(precisions, keys=range(len(precisions))).groupby(level=1, sort=False).mean()
    )
    fpr = pd.concat(fprs, ).mean(axis=1)
    return {
        "uci_id": meta["uci_id"],
        "name": meta["name"],
        "sha256": digest,
        "carrier": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="split")),
        "precision_mean": json.loads(precision.to_json(orient="split")),
        "fpr_mean": json.loads(fpr.to_json()),
        "recall_seeds": [json.loads(r.to_json(orient="split")) for r in recalls],
    }


def x_run_one__mutmut_71(job: tuple[dict[str, Any], str, str], names: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    meta, path, digest = job
    carrier, report = load_carrier(meta, Path(path), seed=0)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        df = inj.inject(carrier, seed=seed)
        result = tb.evaluate(df, cols, seed, names)
        recalls.append(result["recall"])
        precisions.append(result["precision"])
        fprs.append(result["fpr"])
    import pandas as pd

    stack = pd.concat(recalls, keys=range(len(recalls)))
    mean = stack.groupby(level=1, sort=False).mean()
    precision = (
        pd.concat(precisions, keys=range(len(precisions))).groupby(level=1, sort=False).mean()
    )
    fpr = pd.concat(fprs, axis=2).mean(axis=1)
    return {
        "uci_id": meta["uci_id"],
        "name": meta["name"],
        "sha256": digest,
        "carrier": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="split")),
        "precision_mean": json.loads(precision.to_json(orient="split")),
        "fpr_mean": json.loads(fpr.to_json()),
        "recall_seeds": [json.loads(r.to_json(orient="split")) for r in recalls],
    }


def x_run_one__mutmut_72(job: tuple[dict[str, Any], str, str], names: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    meta, path, digest = job
    carrier, report = load_carrier(meta, Path(path), seed=0)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        df = inj.inject(carrier, seed=seed)
        result = tb.evaluate(df, cols, seed, names)
        recalls.append(result["recall"])
        precisions.append(result["precision"])
        fprs.append(result["fpr"])
    import pandas as pd

    stack = pd.concat(recalls, keys=range(len(recalls)))
    mean = stack.groupby(level=1, sort=False).mean()
    precision = (
        pd.concat(precisions, keys=range(len(precisions))).groupby(level=1, sort=False).mean()
    )
    fpr = pd.concat(fprs, axis=1).mean(axis=2)
    return {
        "uci_id": meta["uci_id"],
        "name": meta["name"],
        "sha256": digest,
        "carrier": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="split")),
        "precision_mean": json.loads(precision.to_json(orient="split")),
        "fpr_mean": json.loads(fpr.to_json()),
        "recall_seeds": [json.loads(r.to_json(orient="split")) for r in recalls],
    }


def x_run_one__mutmut_73(job: tuple[dict[str, Any], str, str], names: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    meta, path, digest = job
    carrier, report = load_carrier(meta, Path(path), seed=0)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        df = inj.inject(carrier, seed=seed)
        result = tb.evaluate(df, cols, seed, names)
        recalls.append(result["recall"])
        precisions.append(result["precision"])
        fprs.append(result["fpr"])
    import pandas as pd

    stack = pd.concat(recalls, keys=range(len(recalls)))
    mean = stack.groupby(level=1, sort=False).mean()
    precision = (
        pd.concat(precisions, keys=range(len(precisions))).groupby(level=1, sort=False).mean()
    )
    fpr = pd.concat(fprs, axis=1).mean(axis=1)
    return {
        "XXuci_idXX": meta["uci_id"],
        "name": meta["name"],
        "sha256": digest,
        "carrier": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="split")),
        "precision_mean": json.loads(precision.to_json(orient="split")),
        "fpr_mean": json.loads(fpr.to_json()),
        "recall_seeds": [json.loads(r.to_json(orient="split")) for r in recalls],
    }


def x_run_one__mutmut_74(job: tuple[dict[str, Any], str, str], names: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    meta, path, digest = job
    carrier, report = load_carrier(meta, Path(path), seed=0)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        df = inj.inject(carrier, seed=seed)
        result = tb.evaluate(df, cols, seed, names)
        recalls.append(result["recall"])
        precisions.append(result["precision"])
        fprs.append(result["fpr"])
    import pandas as pd

    stack = pd.concat(recalls, keys=range(len(recalls)))
    mean = stack.groupby(level=1, sort=False).mean()
    precision = (
        pd.concat(precisions, keys=range(len(precisions))).groupby(level=1, sort=False).mean()
    )
    fpr = pd.concat(fprs, axis=1).mean(axis=1)
    return {
        "UCI_ID": meta["uci_id"],
        "name": meta["name"],
        "sha256": digest,
        "carrier": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="split")),
        "precision_mean": json.loads(precision.to_json(orient="split")),
        "fpr_mean": json.loads(fpr.to_json()),
        "recall_seeds": [json.loads(r.to_json(orient="split")) for r in recalls],
    }


def x_run_one__mutmut_75(job: tuple[dict[str, Any], str, str], names: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    meta, path, digest = job
    carrier, report = load_carrier(meta, Path(path), seed=0)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        df = inj.inject(carrier, seed=seed)
        result = tb.evaluate(df, cols, seed, names)
        recalls.append(result["recall"])
        precisions.append(result["precision"])
        fprs.append(result["fpr"])
    import pandas as pd

    stack = pd.concat(recalls, keys=range(len(recalls)))
    mean = stack.groupby(level=1, sort=False).mean()
    precision = (
        pd.concat(precisions, keys=range(len(precisions))).groupby(level=1, sort=False).mean()
    )
    fpr = pd.concat(fprs, axis=1).mean(axis=1)
    return {
        "uci_id": meta["XXuci_idXX"],
        "name": meta["name"],
        "sha256": digest,
        "carrier": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="split")),
        "precision_mean": json.loads(precision.to_json(orient="split")),
        "fpr_mean": json.loads(fpr.to_json()),
        "recall_seeds": [json.loads(r.to_json(orient="split")) for r in recalls],
    }


def x_run_one__mutmut_76(job: tuple[dict[str, Any], str, str], names: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    meta, path, digest = job
    carrier, report = load_carrier(meta, Path(path), seed=0)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        df = inj.inject(carrier, seed=seed)
        result = tb.evaluate(df, cols, seed, names)
        recalls.append(result["recall"])
        precisions.append(result["precision"])
        fprs.append(result["fpr"])
    import pandas as pd

    stack = pd.concat(recalls, keys=range(len(recalls)))
    mean = stack.groupby(level=1, sort=False).mean()
    precision = (
        pd.concat(precisions, keys=range(len(precisions))).groupby(level=1, sort=False).mean()
    )
    fpr = pd.concat(fprs, axis=1).mean(axis=1)
    return {
        "uci_id": meta["UCI_ID"],
        "name": meta["name"],
        "sha256": digest,
        "carrier": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="split")),
        "precision_mean": json.loads(precision.to_json(orient="split")),
        "fpr_mean": json.loads(fpr.to_json()),
        "recall_seeds": [json.loads(r.to_json(orient="split")) for r in recalls],
    }


def x_run_one__mutmut_77(job: tuple[dict[str, Any], str, str], names: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    meta, path, digest = job
    carrier, report = load_carrier(meta, Path(path), seed=0)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        df = inj.inject(carrier, seed=seed)
        result = tb.evaluate(df, cols, seed, names)
        recalls.append(result["recall"])
        precisions.append(result["precision"])
        fprs.append(result["fpr"])
    import pandas as pd

    stack = pd.concat(recalls, keys=range(len(recalls)))
    mean = stack.groupby(level=1, sort=False).mean()
    precision = (
        pd.concat(precisions, keys=range(len(precisions))).groupby(level=1, sort=False).mean()
    )
    fpr = pd.concat(fprs, axis=1).mean(axis=1)
    return {
        "uci_id": meta["uci_id"],
        "XXnameXX": meta["name"],
        "sha256": digest,
        "carrier": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="split")),
        "precision_mean": json.loads(precision.to_json(orient="split")),
        "fpr_mean": json.loads(fpr.to_json()),
        "recall_seeds": [json.loads(r.to_json(orient="split")) for r in recalls],
    }


def x_run_one__mutmut_78(job: tuple[dict[str, Any], str, str], names: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    meta, path, digest = job
    carrier, report = load_carrier(meta, Path(path), seed=0)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        df = inj.inject(carrier, seed=seed)
        result = tb.evaluate(df, cols, seed, names)
        recalls.append(result["recall"])
        precisions.append(result["precision"])
        fprs.append(result["fpr"])
    import pandas as pd

    stack = pd.concat(recalls, keys=range(len(recalls)))
    mean = stack.groupby(level=1, sort=False).mean()
    precision = (
        pd.concat(precisions, keys=range(len(precisions))).groupby(level=1, sort=False).mean()
    )
    fpr = pd.concat(fprs, axis=1).mean(axis=1)
    return {
        "uci_id": meta["uci_id"],
        "NAME": meta["name"],
        "sha256": digest,
        "carrier": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="split")),
        "precision_mean": json.loads(precision.to_json(orient="split")),
        "fpr_mean": json.loads(fpr.to_json()),
        "recall_seeds": [json.loads(r.to_json(orient="split")) for r in recalls],
    }


def x_run_one__mutmut_79(job: tuple[dict[str, Any], str, str], names: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    meta, path, digest = job
    carrier, report = load_carrier(meta, Path(path), seed=0)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        df = inj.inject(carrier, seed=seed)
        result = tb.evaluate(df, cols, seed, names)
        recalls.append(result["recall"])
        precisions.append(result["precision"])
        fprs.append(result["fpr"])
    import pandas as pd

    stack = pd.concat(recalls, keys=range(len(recalls)))
    mean = stack.groupby(level=1, sort=False).mean()
    precision = (
        pd.concat(precisions, keys=range(len(precisions))).groupby(level=1, sort=False).mean()
    )
    fpr = pd.concat(fprs, axis=1).mean(axis=1)
    return {
        "uci_id": meta["uci_id"],
        "name": meta["XXnameXX"],
        "sha256": digest,
        "carrier": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="split")),
        "precision_mean": json.loads(precision.to_json(orient="split")),
        "fpr_mean": json.loads(fpr.to_json()),
        "recall_seeds": [json.loads(r.to_json(orient="split")) for r in recalls],
    }


def x_run_one__mutmut_80(job: tuple[dict[str, Any], str, str], names: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    meta, path, digest = job
    carrier, report = load_carrier(meta, Path(path), seed=0)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        df = inj.inject(carrier, seed=seed)
        result = tb.evaluate(df, cols, seed, names)
        recalls.append(result["recall"])
        precisions.append(result["precision"])
        fprs.append(result["fpr"])
    import pandas as pd

    stack = pd.concat(recalls, keys=range(len(recalls)))
    mean = stack.groupby(level=1, sort=False).mean()
    precision = (
        pd.concat(precisions, keys=range(len(precisions))).groupby(level=1, sort=False).mean()
    )
    fpr = pd.concat(fprs, axis=1).mean(axis=1)
    return {
        "uci_id": meta["uci_id"],
        "name": meta["NAME"],
        "sha256": digest,
        "carrier": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="split")),
        "precision_mean": json.loads(precision.to_json(orient="split")),
        "fpr_mean": json.loads(fpr.to_json()),
        "recall_seeds": [json.loads(r.to_json(orient="split")) for r in recalls],
    }


def x_run_one__mutmut_81(job: tuple[dict[str, Any], str, str], names: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    meta, path, digest = job
    carrier, report = load_carrier(meta, Path(path), seed=0)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        df = inj.inject(carrier, seed=seed)
        result = tb.evaluate(df, cols, seed, names)
        recalls.append(result["recall"])
        precisions.append(result["precision"])
        fprs.append(result["fpr"])
    import pandas as pd

    stack = pd.concat(recalls, keys=range(len(recalls)))
    mean = stack.groupby(level=1, sort=False).mean()
    precision = (
        pd.concat(precisions, keys=range(len(precisions))).groupby(level=1, sort=False).mean()
    )
    fpr = pd.concat(fprs, axis=1).mean(axis=1)
    return {
        "uci_id": meta["uci_id"],
        "name": meta["name"],
        "XXsha256XX": digest,
        "carrier": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="split")),
        "precision_mean": json.loads(precision.to_json(orient="split")),
        "fpr_mean": json.loads(fpr.to_json()),
        "recall_seeds": [json.loads(r.to_json(orient="split")) for r in recalls],
    }


def x_run_one__mutmut_82(job: tuple[dict[str, Any], str, str], names: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    meta, path, digest = job
    carrier, report = load_carrier(meta, Path(path), seed=0)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        df = inj.inject(carrier, seed=seed)
        result = tb.evaluate(df, cols, seed, names)
        recalls.append(result["recall"])
        precisions.append(result["precision"])
        fprs.append(result["fpr"])
    import pandas as pd

    stack = pd.concat(recalls, keys=range(len(recalls)))
    mean = stack.groupby(level=1, sort=False).mean()
    precision = (
        pd.concat(precisions, keys=range(len(precisions))).groupby(level=1, sort=False).mean()
    )
    fpr = pd.concat(fprs, axis=1).mean(axis=1)
    return {
        "uci_id": meta["uci_id"],
        "name": meta["name"],
        "SHA256": digest,
        "carrier": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="split")),
        "precision_mean": json.loads(precision.to_json(orient="split")),
        "fpr_mean": json.loads(fpr.to_json()),
        "recall_seeds": [json.loads(r.to_json(orient="split")) for r in recalls],
    }


def x_run_one__mutmut_83(job: tuple[dict[str, Any], str, str], names: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    meta, path, digest = job
    carrier, report = load_carrier(meta, Path(path), seed=0)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        df = inj.inject(carrier, seed=seed)
        result = tb.evaluate(df, cols, seed, names)
        recalls.append(result["recall"])
        precisions.append(result["precision"])
        fprs.append(result["fpr"])
    import pandas as pd

    stack = pd.concat(recalls, keys=range(len(recalls)))
    mean = stack.groupby(level=1, sort=False).mean()
    precision = (
        pd.concat(precisions, keys=range(len(precisions))).groupby(level=1, sort=False).mean()
    )
    fpr = pd.concat(fprs, axis=1).mean(axis=1)
    return {
        "uci_id": meta["uci_id"],
        "name": meta["name"],
        "sha256": digest,
        "XXcarrierXX": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="split")),
        "precision_mean": json.loads(precision.to_json(orient="split")),
        "fpr_mean": json.loads(fpr.to_json()),
        "recall_seeds": [json.loads(r.to_json(orient="split")) for r in recalls],
    }


def x_run_one__mutmut_84(job: tuple[dict[str, Any], str, str], names: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    meta, path, digest = job
    carrier, report = load_carrier(meta, Path(path), seed=0)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        df = inj.inject(carrier, seed=seed)
        result = tb.evaluate(df, cols, seed, names)
        recalls.append(result["recall"])
        precisions.append(result["precision"])
        fprs.append(result["fpr"])
    import pandas as pd

    stack = pd.concat(recalls, keys=range(len(recalls)))
    mean = stack.groupby(level=1, sort=False).mean()
    precision = (
        pd.concat(precisions, keys=range(len(precisions))).groupby(level=1, sort=False).mean()
    )
    fpr = pd.concat(fprs, axis=1).mean(axis=1)
    return {
        "uci_id": meta["uci_id"],
        "name": meta["name"],
        "sha256": digest,
        "CARRIER": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="split")),
        "precision_mean": json.loads(precision.to_json(orient="split")),
        "fpr_mean": json.loads(fpr.to_json()),
        "recall_seeds": [json.loads(r.to_json(orient="split")) for r in recalls],
    }


def x_run_one__mutmut_85(job: tuple[dict[str, Any], str, str], names: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    meta, path, digest = job
    carrier, report = load_carrier(meta, Path(path), seed=0)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        df = inj.inject(carrier, seed=seed)
        result = tb.evaluate(df, cols, seed, names)
        recalls.append(result["recall"])
        precisions.append(result["precision"])
        fprs.append(result["fpr"])
    import pandas as pd

    stack = pd.concat(recalls, keys=range(len(recalls)))
    mean = stack.groupby(level=1, sort=False).mean()
    precision = (
        pd.concat(precisions, keys=range(len(precisions))).groupby(level=1, sort=False).mean()
    )
    fpr = pd.concat(fprs, axis=1).mean(axis=1)
    return {
        "uci_id": meta["uci_id"],
        "name": meta["name"],
        "sha256": digest,
        "carrier": report,
        "XXseedsXX": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="split")),
        "precision_mean": json.loads(precision.to_json(orient="split")),
        "fpr_mean": json.loads(fpr.to_json()),
        "recall_seeds": [json.loads(r.to_json(orient="split")) for r in recalls],
    }


def x_run_one__mutmut_86(job: tuple[dict[str, Any], str, str], names: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    meta, path, digest = job
    carrier, report = load_carrier(meta, Path(path), seed=0)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        df = inj.inject(carrier, seed=seed)
        result = tb.evaluate(df, cols, seed, names)
        recalls.append(result["recall"])
        precisions.append(result["precision"])
        fprs.append(result["fpr"])
    import pandas as pd

    stack = pd.concat(recalls, keys=range(len(recalls)))
    mean = stack.groupby(level=1, sort=False).mean()
    precision = (
        pd.concat(precisions, keys=range(len(precisions))).groupby(level=1, sort=False).mean()
    )
    fpr = pd.concat(fprs, axis=1).mean(axis=1)
    return {
        "uci_id": meta["uci_id"],
        "name": meta["name"],
        "sha256": digest,
        "carrier": report,
        "SEEDS": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="split")),
        "precision_mean": json.loads(precision.to_json(orient="split")),
        "fpr_mean": json.loads(fpr.to_json()),
        "recall_seeds": [json.loads(r.to_json(orient="split")) for r in recalls],
    }


def x_run_one__mutmut_87(job: tuple[dict[str, Any], str, str], names: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    meta, path, digest = job
    carrier, report = load_carrier(meta, Path(path), seed=0)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        df = inj.inject(carrier, seed=seed)
        result = tb.evaluate(df, cols, seed, names)
        recalls.append(result["recall"])
        precisions.append(result["precision"])
        fprs.append(result["fpr"])
    import pandas as pd

    stack = pd.concat(recalls, keys=range(len(recalls)))
    mean = stack.groupby(level=1, sort=False).mean()
    precision = (
        pd.concat(precisions, keys=range(len(precisions))).groupby(level=1, sort=False).mean()
    )
    fpr = pd.concat(fprs, axis=1).mean(axis=1)
    return {
        "uci_id": meta["uci_id"],
        "name": meta["name"],
        "sha256": digest,
        "carrier": report,
        "seeds": list(None),
        "recall_mean": json.loads(mean.to_json(orient="split")),
        "precision_mean": json.loads(precision.to_json(orient="split")),
        "fpr_mean": json.loads(fpr.to_json()),
        "recall_seeds": [json.loads(r.to_json(orient="split")) for r in recalls],
    }


def x_run_one__mutmut_88(job: tuple[dict[str, Any], str, str], names: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    meta, path, digest = job
    carrier, report = load_carrier(meta, Path(path), seed=0)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        df = inj.inject(carrier, seed=seed)
        result = tb.evaluate(df, cols, seed, names)
        recalls.append(result["recall"])
        precisions.append(result["precision"])
        fprs.append(result["fpr"])
    import pandas as pd

    stack = pd.concat(recalls, keys=range(len(recalls)))
    mean = stack.groupby(level=1, sort=False).mean()
    precision = (
        pd.concat(precisions, keys=range(len(precisions))).groupby(level=1, sort=False).mean()
    )
    fpr = pd.concat(fprs, axis=1).mean(axis=1)
    return {
        "uci_id": meta["uci_id"],
        "name": meta["name"],
        "sha256": digest,
        "carrier": report,
        "seeds": list(SEEDS),
        "XXrecall_meanXX": json.loads(mean.to_json(orient="split")),
        "precision_mean": json.loads(precision.to_json(orient="split")),
        "fpr_mean": json.loads(fpr.to_json()),
        "recall_seeds": [json.loads(r.to_json(orient="split")) for r in recalls],
    }


def x_run_one__mutmut_89(job: tuple[dict[str, Any], str, str], names: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    meta, path, digest = job
    carrier, report = load_carrier(meta, Path(path), seed=0)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        df = inj.inject(carrier, seed=seed)
        result = tb.evaluate(df, cols, seed, names)
        recalls.append(result["recall"])
        precisions.append(result["precision"])
        fprs.append(result["fpr"])
    import pandas as pd

    stack = pd.concat(recalls, keys=range(len(recalls)))
    mean = stack.groupby(level=1, sort=False).mean()
    precision = (
        pd.concat(precisions, keys=range(len(precisions))).groupby(level=1, sort=False).mean()
    )
    fpr = pd.concat(fprs, axis=1).mean(axis=1)
    return {
        "uci_id": meta["uci_id"],
        "name": meta["name"],
        "sha256": digest,
        "carrier": report,
        "seeds": list(SEEDS),
        "RECALL_MEAN": json.loads(mean.to_json(orient="split")),
        "precision_mean": json.loads(precision.to_json(orient="split")),
        "fpr_mean": json.loads(fpr.to_json()),
        "recall_seeds": [json.loads(r.to_json(orient="split")) for r in recalls],
    }


def x_run_one__mutmut_90(job: tuple[dict[str, Any], str, str], names: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    meta, path, digest = job
    carrier, report = load_carrier(meta, Path(path), seed=0)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        df = inj.inject(carrier, seed=seed)
        result = tb.evaluate(df, cols, seed, names)
        recalls.append(result["recall"])
        precisions.append(result["precision"])
        fprs.append(result["fpr"])
    import pandas as pd

    stack = pd.concat(recalls, keys=range(len(recalls)))
    mean = stack.groupby(level=1, sort=False).mean()
    precision = (
        pd.concat(precisions, keys=range(len(precisions))).groupby(level=1, sort=False).mean()
    )
    fpr = pd.concat(fprs, axis=1).mean(axis=1)
    return {
        "uci_id": meta["uci_id"],
        "name": meta["name"],
        "sha256": digest,
        "carrier": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(None),
        "precision_mean": json.loads(precision.to_json(orient="split")),
        "fpr_mean": json.loads(fpr.to_json()),
        "recall_seeds": [json.loads(r.to_json(orient="split")) for r in recalls],
    }


def x_run_one__mutmut_91(job: tuple[dict[str, Any], str, str], names: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    meta, path, digest = job
    carrier, report = load_carrier(meta, Path(path), seed=0)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        df = inj.inject(carrier, seed=seed)
        result = tb.evaluate(df, cols, seed, names)
        recalls.append(result["recall"])
        precisions.append(result["precision"])
        fprs.append(result["fpr"])
    import pandas as pd

    stack = pd.concat(recalls, keys=range(len(recalls)))
    mean = stack.groupby(level=1, sort=False).mean()
    precision = (
        pd.concat(precisions, keys=range(len(precisions))).groupby(level=1, sort=False).mean()
    )
    fpr = pd.concat(fprs, axis=1).mean(axis=1)
    return {
        "uci_id": meta["uci_id"],
        "name": meta["name"],
        "sha256": digest,
        "carrier": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient=None)),
        "precision_mean": json.loads(precision.to_json(orient="split")),
        "fpr_mean": json.loads(fpr.to_json()),
        "recall_seeds": [json.loads(r.to_json(orient="split")) for r in recalls],
    }


def x_run_one__mutmut_92(job: tuple[dict[str, Any], str, str], names: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    meta, path, digest = job
    carrier, report = load_carrier(meta, Path(path), seed=0)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        df = inj.inject(carrier, seed=seed)
        result = tb.evaluate(df, cols, seed, names)
        recalls.append(result["recall"])
        precisions.append(result["precision"])
        fprs.append(result["fpr"])
    import pandas as pd

    stack = pd.concat(recalls, keys=range(len(recalls)))
    mean = stack.groupby(level=1, sort=False).mean()
    precision = (
        pd.concat(precisions, keys=range(len(precisions))).groupby(level=1, sort=False).mean()
    )
    fpr = pd.concat(fprs, axis=1).mean(axis=1)
    return {
        "uci_id": meta["uci_id"],
        "name": meta["name"],
        "sha256": digest,
        "carrier": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="XXsplitXX")),
        "precision_mean": json.loads(precision.to_json(orient="split")),
        "fpr_mean": json.loads(fpr.to_json()),
        "recall_seeds": [json.loads(r.to_json(orient="split")) for r in recalls],
    }


def x_run_one__mutmut_93(job: tuple[dict[str, Any], str, str], names: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    meta, path, digest = job
    carrier, report = load_carrier(meta, Path(path), seed=0)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        df = inj.inject(carrier, seed=seed)
        result = tb.evaluate(df, cols, seed, names)
        recalls.append(result["recall"])
        precisions.append(result["precision"])
        fprs.append(result["fpr"])
    import pandas as pd

    stack = pd.concat(recalls, keys=range(len(recalls)))
    mean = stack.groupby(level=1, sort=False).mean()
    precision = (
        pd.concat(precisions, keys=range(len(precisions))).groupby(level=1, sort=False).mean()
    )
    fpr = pd.concat(fprs, axis=1).mean(axis=1)
    return {
        "uci_id": meta["uci_id"],
        "name": meta["name"],
        "sha256": digest,
        "carrier": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="SPLIT")),
        "precision_mean": json.loads(precision.to_json(orient="split")),
        "fpr_mean": json.loads(fpr.to_json()),
        "recall_seeds": [json.loads(r.to_json(orient="split")) for r in recalls],
    }


def x_run_one__mutmut_94(job: tuple[dict[str, Any], str, str], names: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    meta, path, digest = job
    carrier, report = load_carrier(meta, Path(path), seed=0)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        df = inj.inject(carrier, seed=seed)
        result = tb.evaluate(df, cols, seed, names)
        recalls.append(result["recall"])
        precisions.append(result["precision"])
        fprs.append(result["fpr"])
    import pandas as pd

    stack = pd.concat(recalls, keys=range(len(recalls)))
    mean = stack.groupby(level=1, sort=False).mean()
    precision = (
        pd.concat(precisions, keys=range(len(precisions))).groupby(level=1, sort=False).mean()
    )
    fpr = pd.concat(fprs, axis=1).mean(axis=1)
    return {
        "uci_id": meta["uci_id"],
        "name": meta["name"],
        "sha256": digest,
        "carrier": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="split")),
        "XXprecision_meanXX": json.loads(precision.to_json(orient="split")),
        "fpr_mean": json.loads(fpr.to_json()),
        "recall_seeds": [json.loads(r.to_json(orient="split")) for r in recalls],
    }


def x_run_one__mutmut_95(job: tuple[dict[str, Any], str, str], names: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    meta, path, digest = job
    carrier, report = load_carrier(meta, Path(path), seed=0)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        df = inj.inject(carrier, seed=seed)
        result = tb.evaluate(df, cols, seed, names)
        recalls.append(result["recall"])
        precisions.append(result["precision"])
        fprs.append(result["fpr"])
    import pandas as pd

    stack = pd.concat(recalls, keys=range(len(recalls)))
    mean = stack.groupby(level=1, sort=False).mean()
    precision = (
        pd.concat(precisions, keys=range(len(precisions))).groupby(level=1, sort=False).mean()
    )
    fpr = pd.concat(fprs, axis=1).mean(axis=1)
    return {
        "uci_id": meta["uci_id"],
        "name": meta["name"],
        "sha256": digest,
        "carrier": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="split")),
        "PRECISION_MEAN": json.loads(precision.to_json(orient="split")),
        "fpr_mean": json.loads(fpr.to_json()),
        "recall_seeds": [json.loads(r.to_json(orient="split")) for r in recalls],
    }


def x_run_one__mutmut_96(job: tuple[dict[str, Any], str, str], names: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    meta, path, digest = job
    carrier, report = load_carrier(meta, Path(path), seed=0)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        df = inj.inject(carrier, seed=seed)
        result = tb.evaluate(df, cols, seed, names)
        recalls.append(result["recall"])
        precisions.append(result["precision"])
        fprs.append(result["fpr"])
    import pandas as pd

    stack = pd.concat(recalls, keys=range(len(recalls)))
    mean = stack.groupby(level=1, sort=False).mean()
    precision = (
        pd.concat(precisions, keys=range(len(precisions))).groupby(level=1, sort=False).mean()
    )
    fpr = pd.concat(fprs, axis=1).mean(axis=1)
    return {
        "uci_id": meta["uci_id"],
        "name": meta["name"],
        "sha256": digest,
        "carrier": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="split")),
        "precision_mean": json.loads(None),
        "fpr_mean": json.loads(fpr.to_json()),
        "recall_seeds": [json.loads(r.to_json(orient="split")) for r in recalls],
    }


def x_run_one__mutmut_97(job: tuple[dict[str, Any], str, str], names: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    meta, path, digest = job
    carrier, report = load_carrier(meta, Path(path), seed=0)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        df = inj.inject(carrier, seed=seed)
        result = tb.evaluate(df, cols, seed, names)
        recalls.append(result["recall"])
        precisions.append(result["precision"])
        fprs.append(result["fpr"])
    import pandas as pd

    stack = pd.concat(recalls, keys=range(len(recalls)))
    mean = stack.groupby(level=1, sort=False).mean()
    precision = (
        pd.concat(precisions, keys=range(len(precisions))).groupby(level=1, sort=False).mean()
    )
    fpr = pd.concat(fprs, axis=1).mean(axis=1)
    return {
        "uci_id": meta["uci_id"],
        "name": meta["name"],
        "sha256": digest,
        "carrier": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="split")),
        "precision_mean": json.loads(precision.to_json(orient=None)),
        "fpr_mean": json.loads(fpr.to_json()),
        "recall_seeds": [json.loads(r.to_json(orient="split")) for r in recalls],
    }


def x_run_one__mutmut_98(job: tuple[dict[str, Any], str, str], names: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    meta, path, digest = job
    carrier, report = load_carrier(meta, Path(path), seed=0)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        df = inj.inject(carrier, seed=seed)
        result = tb.evaluate(df, cols, seed, names)
        recalls.append(result["recall"])
        precisions.append(result["precision"])
        fprs.append(result["fpr"])
    import pandas as pd

    stack = pd.concat(recalls, keys=range(len(recalls)))
    mean = stack.groupby(level=1, sort=False).mean()
    precision = (
        pd.concat(precisions, keys=range(len(precisions))).groupby(level=1, sort=False).mean()
    )
    fpr = pd.concat(fprs, axis=1).mean(axis=1)
    return {
        "uci_id": meta["uci_id"],
        "name": meta["name"],
        "sha256": digest,
        "carrier": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="split")),
        "precision_mean": json.loads(precision.to_json(orient="XXsplitXX")),
        "fpr_mean": json.loads(fpr.to_json()),
        "recall_seeds": [json.loads(r.to_json(orient="split")) for r in recalls],
    }


def x_run_one__mutmut_99(job: tuple[dict[str, Any], str, str], names: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    meta, path, digest = job
    carrier, report = load_carrier(meta, Path(path), seed=0)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        df = inj.inject(carrier, seed=seed)
        result = tb.evaluate(df, cols, seed, names)
        recalls.append(result["recall"])
        precisions.append(result["precision"])
        fprs.append(result["fpr"])
    import pandas as pd

    stack = pd.concat(recalls, keys=range(len(recalls)))
    mean = stack.groupby(level=1, sort=False).mean()
    precision = (
        pd.concat(precisions, keys=range(len(precisions))).groupby(level=1, sort=False).mean()
    )
    fpr = pd.concat(fprs, axis=1).mean(axis=1)
    return {
        "uci_id": meta["uci_id"],
        "name": meta["name"],
        "sha256": digest,
        "carrier": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="split")),
        "precision_mean": json.loads(precision.to_json(orient="SPLIT")),
        "fpr_mean": json.loads(fpr.to_json()),
        "recall_seeds": [json.loads(r.to_json(orient="split")) for r in recalls],
    }


def x_run_one__mutmut_100(job: tuple[dict[str, Any], str, str], names: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    meta, path, digest = job
    carrier, report = load_carrier(meta, Path(path), seed=0)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        df = inj.inject(carrier, seed=seed)
        result = tb.evaluate(df, cols, seed, names)
        recalls.append(result["recall"])
        precisions.append(result["precision"])
        fprs.append(result["fpr"])
    import pandas as pd

    stack = pd.concat(recalls, keys=range(len(recalls)))
    mean = stack.groupby(level=1, sort=False).mean()
    precision = (
        pd.concat(precisions, keys=range(len(precisions))).groupby(level=1, sort=False).mean()
    )
    fpr = pd.concat(fprs, axis=1).mean(axis=1)
    return {
        "uci_id": meta["uci_id"],
        "name": meta["name"],
        "sha256": digest,
        "carrier": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="split")),
        "precision_mean": json.loads(precision.to_json(orient="split")),
        "XXfpr_meanXX": json.loads(fpr.to_json()),
        "recall_seeds": [json.loads(r.to_json(orient="split")) for r in recalls],
    }


def x_run_one__mutmut_101(job: tuple[dict[str, Any], str, str], names: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    meta, path, digest = job
    carrier, report = load_carrier(meta, Path(path), seed=0)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        df = inj.inject(carrier, seed=seed)
        result = tb.evaluate(df, cols, seed, names)
        recalls.append(result["recall"])
        precisions.append(result["precision"])
        fprs.append(result["fpr"])
    import pandas as pd

    stack = pd.concat(recalls, keys=range(len(recalls)))
    mean = stack.groupby(level=1, sort=False).mean()
    precision = (
        pd.concat(precisions, keys=range(len(precisions))).groupby(level=1, sort=False).mean()
    )
    fpr = pd.concat(fprs, axis=1).mean(axis=1)
    return {
        "uci_id": meta["uci_id"],
        "name": meta["name"],
        "sha256": digest,
        "carrier": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="split")),
        "precision_mean": json.loads(precision.to_json(orient="split")),
        "FPR_MEAN": json.loads(fpr.to_json()),
        "recall_seeds": [json.loads(r.to_json(orient="split")) for r in recalls],
    }


def x_run_one__mutmut_102(job: tuple[dict[str, Any], str, str], names: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    meta, path, digest = job
    carrier, report = load_carrier(meta, Path(path), seed=0)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        df = inj.inject(carrier, seed=seed)
        result = tb.evaluate(df, cols, seed, names)
        recalls.append(result["recall"])
        precisions.append(result["precision"])
        fprs.append(result["fpr"])
    import pandas as pd

    stack = pd.concat(recalls, keys=range(len(recalls)))
    mean = stack.groupby(level=1, sort=False).mean()
    precision = (
        pd.concat(precisions, keys=range(len(precisions))).groupby(level=1, sort=False).mean()
    )
    fpr = pd.concat(fprs, axis=1).mean(axis=1)
    return {
        "uci_id": meta["uci_id"],
        "name": meta["name"],
        "sha256": digest,
        "carrier": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="split")),
        "precision_mean": json.loads(precision.to_json(orient="split")),
        "fpr_mean": json.loads(None),
        "recall_seeds": [json.loads(r.to_json(orient="split")) for r in recalls],
    }


def x_run_one__mutmut_103(job: tuple[dict[str, Any], str, str], names: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    meta, path, digest = job
    carrier, report = load_carrier(meta, Path(path), seed=0)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        df = inj.inject(carrier, seed=seed)
        result = tb.evaluate(df, cols, seed, names)
        recalls.append(result["recall"])
        precisions.append(result["precision"])
        fprs.append(result["fpr"])
    import pandas as pd

    stack = pd.concat(recalls, keys=range(len(recalls)))
    mean = stack.groupby(level=1, sort=False).mean()
    precision = (
        pd.concat(precisions, keys=range(len(precisions))).groupby(level=1, sort=False).mean()
    )
    fpr = pd.concat(fprs, axis=1).mean(axis=1)
    return {
        "uci_id": meta["uci_id"],
        "name": meta["name"],
        "sha256": digest,
        "carrier": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="split")),
        "precision_mean": json.loads(precision.to_json(orient="split")),
        "fpr_mean": json.loads(fpr.to_json()),
        "XXrecall_seedsXX": [json.loads(r.to_json(orient="split")) for r in recalls],
    }


def x_run_one__mutmut_104(job: tuple[dict[str, Any], str, str], names: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    meta, path, digest = job
    carrier, report = load_carrier(meta, Path(path), seed=0)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        df = inj.inject(carrier, seed=seed)
        result = tb.evaluate(df, cols, seed, names)
        recalls.append(result["recall"])
        precisions.append(result["precision"])
        fprs.append(result["fpr"])
    import pandas as pd

    stack = pd.concat(recalls, keys=range(len(recalls)))
    mean = stack.groupby(level=1, sort=False).mean()
    precision = (
        pd.concat(precisions, keys=range(len(precisions))).groupby(level=1, sort=False).mean()
    )
    fpr = pd.concat(fprs, axis=1).mean(axis=1)
    return {
        "uci_id": meta["uci_id"],
        "name": meta["name"],
        "sha256": digest,
        "carrier": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="split")),
        "precision_mean": json.loads(precision.to_json(orient="split")),
        "fpr_mean": json.loads(fpr.to_json()),
        "RECALL_SEEDS": [json.loads(r.to_json(orient="split")) for r in recalls],
    }


def x_run_one__mutmut_105(job: tuple[dict[str, Any], str, str], names: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    meta, path, digest = job
    carrier, report = load_carrier(meta, Path(path), seed=0)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        df = inj.inject(carrier, seed=seed)
        result = tb.evaluate(df, cols, seed, names)
        recalls.append(result["recall"])
        precisions.append(result["precision"])
        fprs.append(result["fpr"])
    import pandas as pd

    stack = pd.concat(recalls, keys=range(len(recalls)))
    mean = stack.groupby(level=1, sort=False).mean()
    precision = (
        pd.concat(precisions, keys=range(len(precisions))).groupby(level=1, sort=False).mean()
    )
    fpr = pd.concat(fprs, axis=1).mean(axis=1)
    return {
        "uci_id": meta["uci_id"],
        "name": meta["name"],
        "sha256": digest,
        "carrier": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="split")),
        "precision_mean": json.loads(precision.to_json(orient="split")),
        "fpr_mean": json.loads(fpr.to_json()),
        "recall_seeds": [json.loads(None) for r in recalls],
    }


def x_run_one__mutmut_106(job: tuple[dict[str, Any], str, str], names: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    meta, path, digest = job
    carrier, report = load_carrier(meta, Path(path), seed=0)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        df = inj.inject(carrier, seed=seed)
        result = tb.evaluate(df, cols, seed, names)
        recalls.append(result["recall"])
        precisions.append(result["precision"])
        fprs.append(result["fpr"])
    import pandas as pd

    stack = pd.concat(recalls, keys=range(len(recalls)))
    mean = stack.groupby(level=1, sort=False).mean()
    precision = (
        pd.concat(precisions, keys=range(len(precisions))).groupby(level=1, sort=False).mean()
    )
    fpr = pd.concat(fprs, axis=1).mean(axis=1)
    return {
        "uci_id": meta["uci_id"],
        "name": meta["name"],
        "sha256": digest,
        "carrier": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="split")),
        "precision_mean": json.loads(precision.to_json(orient="split")),
        "fpr_mean": json.loads(fpr.to_json()),
        "recall_seeds": [json.loads(r.to_json(orient=None)) for r in recalls],
    }


def x_run_one__mutmut_107(job: tuple[dict[str, Any], str, str], names: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    meta, path, digest = job
    carrier, report = load_carrier(meta, Path(path), seed=0)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        df = inj.inject(carrier, seed=seed)
        result = tb.evaluate(df, cols, seed, names)
        recalls.append(result["recall"])
        precisions.append(result["precision"])
        fprs.append(result["fpr"])
    import pandas as pd

    stack = pd.concat(recalls, keys=range(len(recalls)))
    mean = stack.groupby(level=1, sort=False).mean()
    precision = (
        pd.concat(precisions, keys=range(len(precisions))).groupby(level=1, sort=False).mean()
    )
    fpr = pd.concat(fprs, axis=1).mean(axis=1)
    return {
        "uci_id": meta["uci_id"],
        "name": meta["name"],
        "sha256": digest,
        "carrier": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="split")),
        "precision_mean": json.loads(precision.to_json(orient="split")),
        "fpr_mean": json.loads(fpr.to_json()),
        "recall_seeds": [json.loads(r.to_json(orient="XXsplitXX")) for r in recalls],
    }


def x_run_one__mutmut_108(job: tuple[dict[str, Any], str, str], names: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    meta, path, digest = job
    carrier, report = load_carrier(meta, Path(path), seed=0)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        df = inj.inject(carrier, seed=seed)
        result = tb.evaluate(df, cols, seed, names)
        recalls.append(result["recall"])
        precisions.append(result["precision"])
        fprs.append(result["fpr"])
    import pandas as pd

    stack = pd.concat(recalls, keys=range(len(recalls)))
    mean = stack.groupby(level=1, sort=False).mean()
    precision = (
        pd.concat(precisions, keys=range(len(precisions))).groupby(level=1, sort=False).mean()
    )
    fpr = pd.concat(fprs, axis=1).mean(axis=1)
    return {
        "uci_id": meta["uci_id"],
        "name": meta["name"],
        "sha256": digest,
        "carrier": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="split")),
        "precision_mean": json.loads(precision.to_json(orient="split")),
        "fpr_mean": json.loads(fpr.to_json()),
        "recall_seeds": [json.loads(r.to_json(orient="SPLIT")) for r in recalls],
    }

mutants_x_run_one__mutmut['_mutmut_orig'] = x_run_one__mutmut_orig # type: ignore # mutmut generated
mutants_x_run_one__mutmut['x_run_one__mutmut_1'] = x_run_one__mutmut_1 # type: ignore # mutmut generated
mutants_x_run_one__mutmut['x_run_one__mutmut_2'] = x_run_one__mutmut_2 # type: ignore # mutmut generated
mutants_x_run_one__mutmut['x_run_one__mutmut_3'] = x_run_one__mutmut_3 # type: ignore # mutmut generated
mutants_x_run_one__mutmut['x_run_one__mutmut_4'] = x_run_one__mutmut_4 # type: ignore # mutmut generated
mutants_x_run_one__mutmut['x_run_one__mutmut_5'] = x_run_one__mutmut_5 # type: ignore # mutmut generated
mutants_x_run_one__mutmut['x_run_one__mutmut_6'] = x_run_one__mutmut_6 # type: ignore # mutmut generated
mutants_x_run_one__mutmut['x_run_one__mutmut_7'] = x_run_one__mutmut_7 # type: ignore # mutmut generated
mutants_x_run_one__mutmut['x_run_one__mutmut_8'] = x_run_one__mutmut_8 # type: ignore # mutmut generated
mutants_x_run_one__mutmut['x_run_one__mutmut_9'] = x_run_one__mutmut_9 # type: ignore # mutmut generated
mutants_x_run_one__mutmut['x_run_one__mutmut_10'] = x_run_one__mutmut_10 # type: ignore # mutmut generated
mutants_x_run_one__mutmut['x_run_one__mutmut_11'] = x_run_one__mutmut_11 # type: ignore # mutmut generated
mutants_x_run_one__mutmut['x_run_one__mutmut_12'] = x_run_one__mutmut_12 # type: ignore # mutmut generated
mutants_x_run_one__mutmut['x_run_one__mutmut_13'] = x_run_one__mutmut_13 # type: ignore # mutmut generated
mutants_x_run_one__mutmut['x_run_one__mutmut_14'] = x_run_one__mutmut_14 # type: ignore # mutmut generated
mutants_x_run_one__mutmut['x_run_one__mutmut_15'] = x_run_one__mutmut_15 # type: ignore # mutmut generated
mutants_x_run_one__mutmut['x_run_one__mutmut_16'] = x_run_one__mutmut_16 # type: ignore # mutmut generated
mutants_x_run_one__mutmut['x_run_one__mutmut_17'] = x_run_one__mutmut_17 # type: ignore # mutmut generated
mutants_x_run_one__mutmut['x_run_one__mutmut_18'] = x_run_one__mutmut_18 # type: ignore # mutmut generated
mutants_x_run_one__mutmut['x_run_one__mutmut_19'] = x_run_one__mutmut_19 # type: ignore # mutmut generated
mutants_x_run_one__mutmut['x_run_one__mutmut_20'] = x_run_one__mutmut_20 # type: ignore # mutmut generated
mutants_x_run_one__mutmut['x_run_one__mutmut_21'] = x_run_one__mutmut_21 # type: ignore # mutmut generated
mutants_x_run_one__mutmut['x_run_one__mutmut_22'] = x_run_one__mutmut_22 # type: ignore # mutmut generated
mutants_x_run_one__mutmut['x_run_one__mutmut_23'] = x_run_one__mutmut_23 # type: ignore # mutmut generated
mutants_x_run_one__mutmut['x_run_one__mutmut_24'] = x_run_one__mutmut_24 # type: ignore # mutmut generated
mutants_x_run_one__mutmut['x_run_one__mutmut_25'] = x_run_one__mutmut_25 # type: ignore # mutmut generated
mutants_x_run_one__mutmut['x_run_one__mutmut_26'] = x_run_one__mutmut_26 # type: ignore # mutmut generated
mutants_x_run_one__mutmut['x_run_one__mutmut_27'] = x_run_one__mutmut_27 # type: ignore # mutmut generated
mutants_x_run_one__mutmut['x_run_one__mutmut_28'] = x_run_one__mutmut_28 # type: ignore # mutmut generated
mutants_x_run_one__mutmut['x_run_one__mutmut_29'] = x_run_one__mutmut_29 # type: ignore # mutmut generated
mutants_x_run_one__mutmut['x_run_one__mutmut_30'] = x_run_one__mutmut_30 # type: ignore # mutmut generated
mutants_x_run_one__mutmut['x_run_one__mutmut_31'] = x_run_one__mutmut_31 # type: ignore # mutmut generated
mutants_x_run_one__mutmut['x_run_one__mutmut_32'] = x_run_one__mutmut_32 # type: ignore # mutmut generated
mutants_x_run_one__mutmut['x_run_one__mutmut_33'] = x_run_one__mutmut_33 # type: ignore # mutmut generated
mutants_x_run_one__mutmut['x_run_one__mutmut_34'] = x_run_one__mutmut_34 # type: ignore # mutmut generated
mutants_x_run_one__mutmut['x_run_one__mutmut_35'] = x_run_one__mutmut_35 # type: ignore # mutmut generated
mutants_x_run_one__mutmut['x_run_one__mutmut_36'] = x_run_one__mutmut_36 # type: ignore # mutmut generated
mutants_x_run_one__mutmut['x_run_one__mutmut_37'] = x_run_one__mutmut_37 # type: ignore # mutmut generated
mutants_x_run_one__mutmut['x_run_one__mutmut_38'] = x_run_one__mutmut_38 # type: ignore # mutmut generated
mutants_x_run_one__mutmut['x_run_one__mutmut_39'] = x_run_one__mutmut_39 # type: ignore # mutmut generated
mutants_x_run_one__mutmut['x_run_one__mutmut_40'] = x_run_one__mutmut_40 # type: ignore # mutmut generated
mutants_x_run_one__mutmut['x_run_one__mutmut_41'] = x_run_one__mutmut_41 # type: ignore # mutmut generated
mutants_x_run_one__mutmut['x_run_one__mutmut_42'] = x_run_one__mutmut_42 # type: ignore # mutmut generated
mutants_x_run_one__mutmut['x_run_one__mutmut_43'] = x_run_one__mutmut_43 # type: ignore # mutmut generated
mutants_x_run_one__mutmut['x_run_one__mutmut_44'] = x_run_one__mutmut_44 # type: ignore # mutmut generated
mutants_x_run_one__mutmut['x_run_one__mutmut_45'] = x_run_one__mutmut_45 # type: ignore # mutmut generated
mutants_x_run_one__mutmut['x_run_one__mutmut_46'] = x_run_one__mutmut_46 # type: ignore # mutmut generated
mutants_x_run_one__mutmut['x_run_one__mutmut_47'] = x_run_one__mutmut_47 # type: ignore # mutmut generated
mutants_x_run_one__mutmut['x_run_one__mutmut_48'] = x_run_one__mutmut_48 # type: ignore # mutmut generated
mutants_x_run_one__mutmut['x_run_one__mutmut_49'] = x_run_one__mutmut_49 # type: ignore # mutmut generated
mutants_x_run_one__mutmut['x_run_one__mutmut_50'] = x_run_one__mutmut_50 # type: ignore # mutmut generated
mutants_x_run_one__mutmut['x_run_one__mutmut_51'] = x_run_one__mutmut_51 # type: ignore # mutmut generated
mutants_x_run_one__mutmut['x_run_one__mutmut_52'] = x_run_one__mutmut_52 # type: ignore # mutmut generated
mutants_x_run_one__mutmut['x_run_one__mutmut_53'] = x_run_one__mutmut_53 # type: ignore # mutmut generated
mutants_x_run_one__mutmut['x_run_one__mutmut_54'] = x_run_one__mutmut_54 # type: ignore # mutmut generated
mutants_x_run_one__mutmut['x_run_one__mutmut_55'] = x_run_one__mutmut_55 # type: ignore # mutmut generated
mutants_x_run_one__mutmut['x_run_one__mutmut_56'] = x_run_one__mutmut_56 # type: ignore # mutmut generated
mutants_x_run_one__mutmut['x_run_one__mutmut_57'] = x_run_one__mutmut_57 # type: ignore # mutmut generated
mutants_x_run_one__mutmut['x_run_one__mutmut_58'] = x_run_one__mutmut_58 # type: ignore # mutmut generated
mutants_x_run_one__mutmut['x_run_one__mutmut_59'] = x_run_one__mutmut_59 # type: ignore # mutmut generated
mutants_x_run_one__mutmut['x_run_one__mutmut_60'] = x_run_one__mutmut_60 # type: ignore # mutmut generated
mutants_x_run_one__mutmut['x_run_one__mutmut_61'] = x_run_one__mutmut_61 # type: ignore # mutmut generated
mutants_x_run_one__mutmut['x_run_one__mutmut_62'] = x_run_one__mutmut_62 # type: ignore # mutmut generated
mutants_x_run_one__mutmut['x_run_one__mutmut_63'] = x_run_one__mutmut_63 # type: ignore # mutmut generated
mutants_x_run_one__mutmut['x_run_one__mutmut_64'] = x_run_one__mutmut_64 # type: ignore # mutmut generated
mutants_x_run_one__mutmut['x_run_one__mutmut_65'] = x_run_one__mutmut_65 # type: ignore # mutmut generated
mutants_x_run_one__mutmut['x_run_one__mutmut_66'] = x_run_one__mutmut_66 # type: ignore # mutmut generated
mutants_x_run_one__mutmut['x_run_one__mutmut_67'] = x_run_one__mutmut_67 # type: ignore # mutmut generated
mutants_x_run_one__mutmut['x_run_one__mutmut_68'] = x_run_one__mutmut_68 # type: ignore # mutmut generated
mutants_x_run_one__mutmut['x_run_one__mutmut_69'] = x_run_one__mutmut_69 # type: ignore # mutmut generated
mutants_x_run_one__mutmut['x_run_one__mutmut_70'] = x_run_one__mutmut_70 # type: ignore # mutmut generated
mutants_x_run_one__mutmut['x_run_one__mutmut_71'] = x_run_one__mutmut_71 # type: ignore # mutmut generated
mutants_x_run_one__mutmut['x_run_one__mutmut_72'] = x_run_one__mutmut_72 # type: ignore # mutmut generated
mutants_x_run_one__mutmut['x_run_one__mutmut_73'] = x_run_one__mutmut_73 # type: ignore # mutmut generated
mutants_x_run_one__mutmut['x_run_one__mutmut_74'] = x_run_one__mutmut_74 # type: ignore # mutmut generated
mutants_x_run_one__mutmut['x_run_one__mutmut_75'] = x_run_one__mutmut_75 # type: ignore # mutmut generated
mutants_x_run_one__mutmut['x_run_one__mutmut_76'] = x_run_one__mutmut_76 # type: ignore # mutmut generated
mutants_x_run_one__mutmut['x_run_one__mutmut_77'] = x_run_one__mutmut_77 # type: ignore # mutmut generated
mutants_x_run_one__mutmut['x_run_one__mutmut_78'] = x_run_one__mutmut_78 # type: ignore # mutmut generated
mutants_x_run_one__mutmut['x_run_one__mutmut_79'] = x_run_one__mutmut_79 # type: ignore # mutmut generated
mutants_x_run_one__mutmut['x_run_one__mutmut_80'] = x_run_one__mutmut_80 # type: ignore # mutmut generated
mutants_x_run_one__mutmut['x_run_one__mutmut_81'] = x_run_one__mutmut_81 # type: ignore # mutmut generated
mutants_x_run_one__mutmut['x_run_one__mutmut_82'] = x_run_one__mutmut_82 # type: ignore # mutmut generated
mutants_x_run_one__mutmut['x_run_one__mutmut_83'] = x_run_one__mutmut_83 # type: ignore # mutmut generated
mutants_x_run_one__mutmut['x_run_one__mutmut_84'] = x_run_one__mutmut_84 # type: ignore # mutmut generated
mutants_x_run_one__mutmut['x_run_one__mutmut_85'] = x_run_one__mutmut_85 # type: ignore # mutmut generated
mutants_x_run_one__mutmut['x_run_one__mutmut_86'] = x_run_one__mutmut_86 # type: ignore # mutmut generated
mutants_x_run_one__mutmut['x_run_one__mutmut_87'] = x_run_one__mutmut_87 # type: ignore # mutmut generated
mutants_x_run_one__mutmut['x_run_one__mutmut_88'] = x_run_one__mutmut_88 # type: ignore # mutmut generated
mutants_x_run_one__mutmut['x_run_one__mutmut_89'] = x_run_one__mutmut_89 # type: ignore # mutmut generated
mutants_x_run_one__mutmut['x_run_one__mutmut_90'] = x_run_one__mutmut_90 # type: ignore # mutmut generated
mutants_x_run_one__mutmut['x_run_one__mutmut_91'] = x_run_one__mutmut_91 # type: ignore # mutmut generated
mutants_x_run_one__mutmut['x_run_one__mutmut_92'] = x_run_one__mutmut_92 # type: ignore # mutmut generated
mutants_x_run_one__mutmut['x_run_one__mutmut_93'] = x_run_one__mutmut_93 # type: ignore # mutmut generated
mutants_x_run_one__mutmut['x_run_one__mutmut_94'] = x_run_one__mutmut_94 # type: ignore # mutmut generated
mutants_x_run_one__mutmut['x_run_one__mutmut_95'] = x_run_one__mutmut_95 # type: ignore # mutmut generated
mutants_x_run_one__mutmut['x_run_one__mutmut_96'] = x_run_one__mutmut_96 # type: ignore # mutmut generated
mutants_x_run_one__mutmut['x_run_one__mutmut_97'] = x_run_one__mutmut_97 # type: ignore # mutmut generated
mutants_x_run_one__mutmut['x_run_one__mutmut_98'] = x_run_one__mutmut_98 # type: ignore # mutmut generated
mutants_x_run_one__mutmut['x_run_one__mutmut_99'] = x_run_one__mutmut_99 # type: ignore # mutmut generated
mutants_x_run_one__mutmut['x_run_one__mutmut_100'] = x_run_one__mutmut_100 # type: ignore # mutmut generated
mutants_x_run_one__mutmut['x_run_one__mutmut_101'] = x_run_one__mutmut_101 # type: ignore # mutmut generated
mutants_x_run_one__mutmut['x_run_one__mutmut_102'] = x_run_one__mutmut_102 # type: ignore # mutmut generated
mutants_x_run_one__mutmut['x_run_one__mutmut_103'] = x_run_one__mutmut_103 # type: ignore # mutmut generated
mutants_x_run_one__mutmut['x_run_one__mutmut_104'] = x_run_one__mutmut_104 # type: ignore # mutmut generated
mutants_x_run_one__mutmut['x_run_one__mutmut_105'] = x_run_one__mutmut_105 # type: ignore # mutmut generated
mutants_x_run_one__mutmut['x_run_one__mutmut_106'] = x_run_one__mutmut_106 # type: ignore # mutmut generated
mutants_x_run_one__mutmut['x_run_one__mutmut_107'] = x_run_one__mutmut_107 # type: ignore # mutmut generated
mutants_x_run_one__mutmut['x_run_one__mutmut_108'] = x_run_one__mutmut_108 # type: ignore # mutmut generated
mutants_x_jobs__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_jobs__mutmut)
def jobs(curated: Path, pool: Path, data: Path) -> list[tuple]:
    meta = {m["uci_id"]: m for m in json.loads(curated.read_text())["kept"]}
    out = []
    for row in json.loads(pool.read_text())["rows"]:
        if "carrier" not in row["roles"]:
            continue
        path = data / f"{row['uci_id']}.csv"
        try:
            load_carrier(meta[row["uci_id"]], path, seed=0)
        except inj.NotEligible:
            continue
        out.append((meta[row["uci_id"]], str(path), row["sha256"]))
    return out


def x_jobs__mutmut_orig(curated: Path, pool: Path, data: Path) -> list[tuple]:
    meta = {m["uci_id"]: m for m in json.loads(curated.read_text())["kept"]}
    out = []
    for row in json.loads(pool.read_text())["rows"]:
        if "carrier" not in row["roles"]:
            continue
        path = data / f"{row['uci_id']}.csv"
        try:
            load_carrier(meta[row["uci_id"]], path, seed=0)
        except inj.NotEligible:
            continue
        out.append((meta[row["uci_id"]], str(path), row["sha256"]))
    return out


def x_jobs__mutmut_1(curated: Path, pool: Path, data: Path) -> list[tuple]:
    meta = None
    out = []
    for row in json.loads(pool.read_text())["rows"]:
        if "carrier" not in row["roles"]:
            continue
        path = data / f"{row['uci_id']}.csv"
        try:
            load_carrier(meta[row["uci_id"]], path, seed=0)
        except inj.NotEligible:
            continue
        out.append((meta[row["uci_id"]], str(path), row["sha256"]))
    return out


def x_jobs__mutmut_2(curated: Path, pool: Path, data: Path) -> list[tuple]:
    meta = {m["XXuci_idXX"]: m for m in json.loads(curated.read_text())["kept"]}
    out = []
    for row in json.loads(pool.read_text())["rows"]:
        if "carrier" not in row["roles"]:
            continue
        path = data / f"{row['uci_id']}.csv"
        try:
            load_carrier(meta[row["uci_id"]], path, seed=0)
        except inj.NotEligible:
            continue
        out.append((meta[row["uci_id"]], str(path), row["sha256"]))
    return out


def x_jobs__mutmut_3(curated: Path, pool: Path, data: Path) -> list[tuple]:
    meta = {m["UCI_ID"]: m for m in json.loads(curated.read_text())["kept"]}
    out = []
    for row in json.loads(pool.read_text())["rows"]:
        if "carrier" not in row["roles"]:
            continue
        path = data / f"{row['uci_id']}.csv"
        try:
            load_carrier(meta[row["uci_id"]], path, seed=0)
        except inj.NotEligible:
            continue
        out.append((meta[row["uci_id"]], str(path), row["sha256"]))
    return out


def x_jobs__mutmut_4(curated: Path, pool: Path, data: Path) -> list[tuple]:
    meta = {m["uci_id"]: m for m in json.loads(None)["kept"]}
    out = []
    for row in json.loads(pool.read_text())["rows"]:
        if "carrier" not in row["roles"]:
            continue
        path = data / f"{row['uci_id']}.csv"
        try:
            load_carrier(meta[row["uci_id"]], path, seed=0)
        except inj.NotEligible:
            continue
        out.append((meta[row["uci_id"]], str(path), row["sha256"]))
    return out


def x_jobs__mutmut_5(curated: Path, pool: Path, data: Path) -> list[tuple]:
    meta = {m["uci_id"]: m for m in json.loads(curated.read_text())["XXkeptXX"]}
    out = []
    for row in json.loads(pool.read_text())["rows"]:
        if "carrier" not in row["roles"]:
            continue
        path = data / f"{row['uci_id']}.csv"
        try:
            load_carrier(meta[row["uci_id"]], path, seed=0)
        except inj.NotEligible:
            continue
        out.append((meta[row["uci_id"]], str(path), row["sha256"]))
    return out


def x_jobs__mutmut_6(curated: Path, pool: Path, data: Path) -> list[tuple]:
    meta = {m["uci_id"]: m for m in json.loads(curated.read_text())["KEPT"]}
    out = []
    for row in json.loads(pool.read_text())["rows"]:
        if "carrier" not in row["roles"]:
            continue
        path = data / f"{row['uci_id']}.csv"
        try:
            load_carrier(meta[row["uci_id"]], path, seed=0)
        except inj.NotEligible:
            continue
        out.append((meta[row["uci_id"]], str(path), row["sha256"]))
    return out


def x_jobs__mutmut_7(curated: Path, pool: Path, data: Path) -> list[tuple]:
    meta = {m["uci_id"]: m for m in json.loads(curated.read_text())["kept"]}
    out = None
    for row in json.loads(pool.read_text())["rows"]:
        if "carrier" not in row["roles"]:
            continue
        path = data / f"{row['uci_id']}.csv"
        try:
            load_carrier(meta[row["uci_id"]], path, seed=0)
        except inj.NotEligible:
            continue
        out.append((meta[row["uci_id"]], str(path), row["sha256"]))
    return out


def x_jobs__mutmut_8(curated: Path, pool: Path, data: Path) -> list[tuple]:
    meta = {m["uci_id"]: m for m in json.loads(curated.read_text())["kept"]}
    out = []
    for row in json.loads(None)["rows"]:
        if "carrier" not in row["roles"]:
            continue
        path = data / f"{row['uci_id']}.csv"
        try:
            load_carrier(meta[row["uci_id"]], path, seed=0)
        except inj.NotEligible:
            continue
        out.append((meta[row["uci_id"]], str(path), row["sha256"]))
    return out


def x_jobs__mutmut_9(curated: Path, pool: Path, data: Path) -> list[tuple]:
    meta = {m["uci_id"]: m for m in json.loads(curated.read_text())["kept"]}
    out = []
    for row in json.loads(pool.read_text())["XXrowsXX"]:
        if "carrier" not in row["roles"]:
            continue
        path = data / f"{row['uci_id']}.csv"
        try:
            load_carrier(meta[row["uci_id"]], path, seed=0)
        except inj.NotEligible:
            continue
        out.append((meta[row["uci_id"]], str(path), row["sha256"]))
    return out


def x_jobs__mutmut_10(curated: Path, pool: Path, data: Path) -> list[tuple]:
    meta = {m["uci_id"]: m for m in json.loads(curated.read_text())["kept"]}
    out = []
    for row in json.loads(pool.read_text())["ROWS"]:
        if "carrier" not in row["roles"]:
            continue
        path = data / f"{row['uci_id']}.csv"
        try:
            load_carrier(meta[row["uci_id"]], path, seed=0)
        except inj.NotEligible:
            continue
        out.append((meta[row["uci_id"]], str(path), row["sha256"]))
    return out


def x_jobs__mutmut_11(curated: Path, pool: Path, data: Path) -> list[tuple]:
    meta = {m["uci_id"]: m for m in json.loads(curated.read_text())["kept"]}
    out = []
    for row in json.loads(pool.read_text())["rows"]:
        if "XXcarrierXX" not in row["roles"]:
            continue
        path = data / f"{row['uci_id']}.csv"
        try:
            load_carrier(meta[row["uci_id"]], path, seed=0)
        except inj.NotEligible:
            continue
        out.append((meta[row["uci_id"]], str(path), row["sha256"]))
    return out


def x_jobs__mutmut_12(curated: Path, pool: Path, data: Path) -> list[tuple]:
    meta = {m["uci_id"]: m for m in json.loads(curated.read_text())["kept"]}
    out = []
    for row in json.loads(pool.read_text())["rows"]:
        if "CARRIER" not in row["roles"]:
            continue
        path = data / f"{row['uci_id']}.csv"
        try:
            load_carrier(meta[row["uci_id"]], path, seed=0)
        except inj.NotEligible:
            continue
        out.append((meta[row["uci_id"]], str(path), row["sha256"]))
    return out


def x_jobs__mutmut_13(curated: Path, pool: Path, data: Path) -> list[tuple]:
    meta = {m["uci_id"]: m for m in json.loads(curated.read_text())["kept"]}
    out = []
    for row in json.loads(pool.read_text())["rows"]:
        if "carrier" in row["roles"]:
            continue
        path = data / f"{row['uci_id']}.csv"
        try:
            load_carrier(meta[row["uci_id"]], path, seed=0)
        except inj.NotEligible:
            continue
        out.append((meta[row["uci_id"]], str(path), row["sha256"]))
    return out


def x_jobs__mutmut_14(curated: Path, pool: Path, data: Path) -> list[tuple]:
    meta = {m["uci_id"]: m for m in json.loads(curated.read_text())["kept"]}
    out = []
    for row in json.loads(pool.read_text())["rows"]:
        if "carrier" not in row["XXrolesXX"]:
            continue
        path = data / f"{row['uci_id']}.csv"
        try:
            load_carrier(meta[row["uci_id"]], path, seed=0)
        except inj.NotEligible:
            continue
        out.append((meta[row["uci_id"]], str(path), row["sha256"]))
    return out


def x_jobs__mutmut_15(curated: Path, pool: Path, data: Path) -> list[tuple]:
    meta = {m["uci_id"]: m for m in json.loads(curated.read_text())["kept"]}
    out = []
    for row in json.loads(pool.read_text())["rows"]:
        if "carrier" not in row["ROLES"]:
            continue
        path = data / f"{row['uci_id']}.csv"
        try:
            load_carrier(meta[row["uci_id"]], path, seed=0)
        except inj.NotEligible:
            continue
        out.append((meta[row["uci_id"]], str(path), row["sha256"]))
    return out


def x_jobs__mutmut_16(curated: Path, pool: Path, data: Path) -> list[tuple]:
    meta = {m["uci_id"]: m for m in json.loads(curated.read_text())["kept"]}
    out = []
    for row in json.loads(pool.read_text())["rows"]:
        if "carrier" not in row["roles"]:
            break
        path = data / f"{row['uci_id']}.csv"
        try:
            load_carrier(meta[row["uci_id"]], path, seed=0)
        except inj.NotEligible:
            continue
        out.append((meta[row["uci_id"]], str(path), row["sha256"]))
    return out


def x_jobs__mutmut_17(curated: Path, pool: Path, data: Path) -> list[tuple]:
    meta = {m["uci_id"]: m for m in json.loads(curated.read_text())["kept"]}
    out = []
    for row in json.loads(pool.read_text())["rows"]:
        if "carrier" not in row["roles"]:
            continue
        path = None
        try:
            load_carrier(meta[row["uci_id"]], path, seed=0)
        except inj.NotEligible:
            continue
        out.append((meta[row["uci_id"]], str(path), row["sha256"]))
    return out


def x_jobs__mutmut_18(curated: Path, pool: Path, data: Path) -> list[tuple]:
    meta = {m["uci_id"]: m for m in json.loads(curated.read_text())["kept"]}
    out = []
    for row in json.loads(pool.read_text())["rows"]:
        if "carrier" not in row["roles"]:
            continue
        path = data * f"{row['uci_id']}.csv"
        try:
            load_carrier(meta[row["uci_id"]], path, seed=0)
        except inj.NotEligible:
            continue
        out.append((meta[row["uci_id"]], str(path), row["sha256"]))
    return out


def x_jobs__mutmut_19(curated: Path, pool: Path, data: Path) -> list[tuple]:
    meta = {m["uci_id"]: m for m in json.loads(curated.read_text())["kept"]}
    out = []
    for row in json.loads(pool.read_text())["rows"]:
        if "carrier" not in row["roles"]:
            continue
        path = data / f"{row['XXuci_idXX']}.csv"
        try:
            load_carrier(meta[row["uci_id"]], path, seed=0)
        except inj.NotEligible:
            continue
        out.append((meta[row["uci_id"]], str(path), row["sha256"]))
    return out


def x_jobs__mutmut_20(curated: Path, pool: Path, data: Path) -> list[tuple]:
    meta = {m["uci_id"]: m for m in json.loads(curated.read_text())["kept"]}
    out = []
    for row in json.loads(pool.read_text())["rows"]:
        if "carrier" not in row["roles"]:
            continue
        path = data / f"{row['UCI_ID']}.csv"
        try:
            load_carrier(meta[row["uci_id"]], path, seed=0)
        except inj.NotEligible:
            continue
        out.append((meta[row["uci_id"]], str(path), row["sha256"]))
    return out


def x_jobs__mutmut_21(curated: Path, pool: Path, data: Path) -> list[tuple]:
    meta = {m["uci_id"]: m for m in json.loads(curated.read_text())["kept"]}
    out = []
    for row in json.loads(pool.read_text())["rows"]:
        if "carrier" not in row["roles"]:
            continue
        path = data / f"{row['uci_id']}.csv"
        try:
            load_carrier(None, path, seed=0)
        except inj.NotEligible:
            continue
        out.append((meta[row["uci_id"]], str(path), row["sha256"]))
    return out


def x_jobs__mutmut_22(curated: Path, pool: Path, data: Path) -> list[tuple]:
    meta = {m["uci_id"]: m for m in json.loads(curated.read_text())["kept"]}
    out = []
    for row in json.loads(pool.read_text())["rows"]:
        if "carrier" not in row["roles"]:
            continue
        path = data / f"{row['uci_id']}.csv"
        try:
            load_carrier(meta[row["uci_id"]], None, seed=0)
        except inj.NotEligible:
            continue
        out.append((meta[row["uci_id"]], str(path), row["sha256"]))
    return out


def x_jobs__mutmut_23(curated: Path, pool: Path, data: Path) -> list[tuple]:
    meta = {m["uci_id"]: m for m in json.loads(curated.read_text())["kept"]}
    out = []
    for row in json.loads(pool.read_text())["rows"]:
        if "carrier" not in row["roles"]:
            continue
        path = data / f"{row['uci_id']}.csv"
        try:
            load_carrier(meta[row["uci_id"]], path, seed=None)
        except inj.NotEligible:
            continue
        out.append((meta[row["uci_id"]], str(path), row["sha256"]))
    return out


def x_jobs__mutmut_24(curated: Path, pool: Path, data: Path) -> list[tuple]:
    meta = {m["uci_id"]: m for m in json.loads(curated.read_text())["kept"]}
    out = []
    for row in json.loads(pool.read_text())["rows"]:
        if "carrier" not in row["roles"]:
            continue
        path = data / f"{row['uci_id']}.csv"
        try:
            load_carrier(path, seed=0)
        except inj.NotEligible:
            continue
        out.append((meta[row["uci_id"]], str(path), row["sha256"]))
    return out


def x_jobs__mutmut_25(curated: Path, pool: Path, data: Path) -> list[tuple]:
    meta = {m["uci_id"]: m for m in json.loads(curated.read_text())["kept"]}
    out = []
    for row in json.loads(pool.read_text())["rows"]:
        if "carrier" not in row["roles"]:
            continue
        path = data / f"{row['uci_id']}.csv"
        try:
            load_carrier(meta[row["uci_id"]], seed=0)
        except inj.NotEligible:
            continue
        out.append((meta[row["uci_id"]], str(path), row["sha256"]))
    return out


def x_jobs__mutmut_26(curated: Path, pool: Path, data: Path) -> list[tuple]:
    meta = {m["uci_id"]: m for m in json.loads(curated.read_text())["kept"]}
    out = []
    for row in json.loads(pool.read_text())["rows"]:
        if "carrier" not in row["roles"]:
            continue
        path = data / f"{row['uci_id']}.csv"
        try:
            load_carrier(meta[row["uci_id"]], path, )
        except inj.NotEligible:
            continue
        out.append((meta[row["uci_id"]], str(path), row["sha256"]))
    return out


def x_jobs__mutmut_27(curated: Path, pool: Path, data: Path) -> list[tuple]:
    meta = {m["uci_id"]: m for m in json.loads(curated.read_text())["kept"]}
    out = []
    for row in json.loads(pool.read_text())["rows"]:
        if "carrier" not in row["roles"]:
            continue
        path = data / f"{row['uci_id']}.csv"
        try:
            load_carrier(meta[row["XXuci_idXX"]], path, seed=0)
        except inj.NotEligible:
            continue
        out.append((meta[row["uci_id"]], str(path), row["sha256"]))
    return out


def x_jobs__mutmut_28(curated: Path, pool: Path, data: Path) -> list[tuple]:
    meta = {m["uci_id"]: m for m in json.loads(curated.read_text())["kept"]}
    out = []
    for row in json.loads(pool.read_text())["rows"]:
        if "carrier" not in row["roles"]:
            continue
        path = data / f"{row['uci_id']}.csv"
        try:
            load_carrier(meta[row["UCI_ID"]], path, seed=0)
        except inj.NotEligible:
            continue
        out.append((meta[row["uci_id"]], str(path), row["sha256"]))
    return out


def x_jobs__mutmut_29(curated: Path, pool: Path, data: Path) -> list[tuple]:
    meta = {m["uci_id"]: m for m in json.loads(curated.read_text())["kept"]}
    out = []
    for row in json.loads(pool.read_text())["rows"]:
        if "carrier" not in row["roles"]:
            continue
        path = data / f"{row['uci_id']}.csv"
        try:
            load_carrier(meta[row["uci_id"]], path, seed=1)
        except inj.NotEligible:
            continue
        out.append((meta[row["uci_id"]], str(path), row["sha256"]))
    return out


def x_jobs__mutmut_30(curated: Path, pool: Path, data: Path) -> list[tuple]:
    meta = {m["uci_id"]: m for m in json.loads(curated.read_text())["kept"]}
    out = []
    for row in json.loads(pool.read_text())["rows"]:
        if "carrier" not in row["roles"]:
            continue
        path = data / f"{row['uci_id']}.csv"
        try:
            load_carrier(meta[row["uci_id"]], path, seed=0)
        except inj.NotEligible:
            break
        out.append((meta[row["uci_id"]], str(path), row["sha256"]))
    return out


def x_jobs__mutmut_31(curated: Path, pool: Path, data: Path) -> list[tuple]:
    meta = {m["uci_id"]: m for m in json.loads(curated.read_text())["kept"]}
    out = []
    for row in json.loads(pool.read_text())["rows"]:
        if "carrier" not in row["roles"]:
            continue
        path = data / f"{row['uci_id']}.csv"
        try:
            load_carrier(meta[row["uci_id"]], path, seed=0)
        except inj.NotEligible:
            continue
        out.append(None)
    return out


def x_jobs__mutmut_32(curated: Path, pool: Path, data: Path) -> list[tuple]:
    meta = {m["uci_id"]: m for m in json.loads(curated.read_text())["kept"]}
    out = []
    for row in json.loads(pool.read_text())["rows"]:
        if "carrier" not in row["roles"]:
            continue
        path = data / f"{row['uci_id']}.csv"
        try:
            load_carrier(meta[row["uci_id"]], path, seed=0)
        except inj.NotEligible:
            continue
        out.append((meta[row["XXuci_idXX"]], str(path), row["sha256"]))
    return out


def x_jobs__mutmut_33(curated: Path, pool: Path, data: Path) -> list[tuple]:
    meta = {m["uci_id"]: m for m in json.loads(curated.read_text())["kept"]}
    out = []
    for row in json.loads(pool.read_text())["rows"]:
        if "carrier" not in row["roles"]:
            continue
        path = data / f"{row['uci_id']}.csv"
        try:
            load_carrier(meta[row["uci_id"]], path, seed=0)
        except inj.NotEligible:
            continue
        out.append((meta[row["UCI_ID"]], str(path), row["sha256"]))
    return out


def x_jobs__mutmut_34(curated: Path, pool: Path, data: Path) -> list[tuple]:
    meta = {m["uci_id"]: m for m in json.loads(curated.read_text())["kept"]}
    out = []
    for row in json.loads(pool.read_text())["rows"]:
        if "carrier" not in row["roles"]:
            continue
        path = data / f"{row['uci_id']}.csv"
        try:
            load_carrier(meta[row["uci_id"]], path, seed=0)
        except inj.NotEligible:
            continue
        out.append((meta[row["uci_id"]], str(None), row["sha256"]))
    return out


def x_jobs__mutmut_35(curated: Path, pool: Path, data: Path) -> list[tuple]:
    meta = {m["uci_id"]: m for m in json.loads(curated.read_text())["kept"]}
    out = []
    for row in json.loads(pool.read_text())["rows"]:
        if "carrier" not in row["roles"]:
            continue
        path = data / f"{row['uci_id']}.csv"
        try:
            load_carrier(meta[row["uci_id"]], path, seed=0)
        except inj.NotEligible:
            continue
        out.append((meta[row["uci_id"]], str(path), row["XXsha256XX"]))
    return out


def x_jobs__mutmut_36(curated: Path, pool: Path, data: Path) -> list[tuple]:
    meta = {m["uci_id"]: m for m in json.loads(curated.read_text())["kept"]}
    out = []
    for row in json.loads(pool.read_text())["rows"]:
        if "carrier" not in row["roles"]:
            continue
        path = data / f"{row['uci_id']}.csv"
        try:
            load_carrier(meta[row["uci_id"]], path, seed=0)
        except inj.NotEligible:
            continue
        out.append((meta[row["uci_id"]], str(path), row["SHA256"]))
    return out

mutants_x_jobs__mutmut['_mutmut_orig'] = x_jobs__mutmut_orig # type: ignore # mutmut generated
mutants_x_jobs__mutmut['x_jobs__mutmut_1'] = x_jobs__mutmut_1 # type: ignore # mutmut generated
mutants_x_jobs__mutmut['x_jobs__mutmut_2'] = x_jobs__mutmut_2 # type: ignore # mutmut generated
mutants_x_jobs__mutmut['x_jobs__mutmut_3'] = x_jobs__mutmut_3 # type: ignore # mutmut generated
mutants_x_jobs__mutmut['x_jobs__mutmut_4'] = x_jobs__mutmut_4 # type: ignore # mutmut generated
mutants_x_jobs__mutmut['x_jobs__mutmut_5'] = x_jobs__mutmut_5 # type: ignore # mutmut generated
mutants_x_jobs__mutmut['x_jobs__mutmut_6'] = x_jobs__mutmut_6 # type: ignore # mutmut generated
mutants_x_jobs__mutmut['x_jobs__mutmut_7'] = x_jobs__mutmut_7 # type: ignore # mutmut generated
mutants_x_jobs__mutmut['x_jobs__mutmut_8'] = x_jobs__mutmut_8 # type: ignore # mutmut generated
mutants_x_jobs__mutmut['x_jobs__mutmut_9'] = x_jobs__mutmut_9 # type: ignore # mutmut generated
mutants_x_jobs__mutmut['x_jobs__mutmut_10'] = x_jobs__mutmut_10 # type: ignore # mutmut generated
mutants_x_jobs__mutmut['x_jobs__mutmut_11'] = x_jobs__mutmut_11 # type: ignore # mutmut generated
mutants_x_jobs__mutmut['x_jobs__mutmut_12'] = x_jobs__mutmut_12 # type: ignore # mutmut generated
mutants_x_jobs__mutmut['x_jobs__mutmut_13'] = x_jobs__mutmut_13 # type: ignore # mutmut generated
mutants_x_jobs__mutmut['x_jobs__mutmut_14'] = x_jobs__mutmut_14 # type: ignore # mutmut generated
mutants_x_jobs__mutmut['x_jobs__mutmut_15'] = x_jobs__mutmut_15 # type: ignore # mutmut generated
mutants_x_jobs__mutmut['x_jobs__mutmut_16'] = x_jobs__mutmut_16 # type: ignore # mutmut generated
mutants_x_jobs__mutmut['x_jobs__mutmut_17'] = x_jobs__mutmut_17 # type: ignore # mutmut generated
mutants_x_jobs__mutmut['x_jobs__mutmut_18'] = x_jobs__mutmut_18 # type: ignore # mutmut generated
mutants_x_jobs__mutmut['x_jobs__mutmut_19'] = x_jobs__mutmut_19 # type: ignore # mutmut generated
mutants_x_jobs__mutmut['x_jobs__mutmut_20'] = x_jobs__mutmut_20 # type: ignore # mutmut generated
mutants_x_jobs__mutmut['x_jobs__mutmut_21'] = x_jobs__mutmut_21 # type: ignore # mutmut generated
mutants_x_jobs__mutmut['x_jobs__mutmut_22'] = x_jobs__mutmut_22 # type: ignore # mutmut generated
mutants_x_jobs__mutmut['x_jobs__mutmut_23'] = x_jobs__mutmut_23 # type: ignore # mutmut generated
mutants_x_jobs__mutmut['x_jobs__mutmut_24'] = x_jobs__mutmut_24 # type: ignore # mutmut generated
mutants_x_jobs__mutmut['x_jobs__mutmut_25'] = x_jobs__mutmut_25 # type: ignore # mutmut generated
mutants_x_jobs__mutmut['x_jobs__mutmut_26'] = x_jobs__mutmut_26 # type: ignore # mutmut generated
mutants_x_jobs__mutmut['x_jobs__mutmut_27'] = x_jobs__mutmut_27 # type: ignore # mutmut generated
mutants_x_jobs__mutmut['x_jobs__mutmut_28'] = x_jobs__mutmut_28 # type: ignore # mutmut generated
mutants_x_jobs__mutmut['x_jobs__mutmut_29'] = x_jobs__mutmut_29 # type: ignore # mutmut generated
mutants_x_jobs__mutmut['x_jobs__mutmut_30'] = x_jobs__mutmut_30 # type: ignore # mutmut generated
mutants_x_jobs__mutmut['x_jobs__mutmut_31'] = x_jobs__mutmut_31 # type: ignore # mutmut generated
mutants_x_jobs__mutmut['x_jobs__mutmut_32'] = x_jobs__mutmut_32 # type: ignore # mutmut generated
mutants_x_jobs__mutmut['x_jobs__mutmut_33'] = x_jobs__mutmut_33 # type: ignore # mutmut generated
mutants_x_jobs__mutmut['x_jobs__mutmut_34'] = x_jobs__mutmut_34 # type: ignore # mutmut generated
mutants_x_jobs__mutmut['x_jobs__mutmut_35'] = x_jobs__mutmut_35 # type: ignore # mutmut generated
mutants_x_jobs__mutmut['x_jobs__mutmut_36'] = x_jobs__mutmut_36 # type: ignore # mutmut generated
mutants_x_main__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_main__mutmut)
def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--curated", type=Path, default=registry / "uci_curated.json")
    parser.add_argument("--pool", type=Path, default=registry / "uci_pool.json")
    parser.add_argument("--data", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", type=int, nargs="*", help="UCI ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the datasets whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the registry sweep with drift, or the neural detectors",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.curated, args.pool, args.data)
        if not args.only or j[0]["uci_id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{j[0]['uci_id']}.json").exists()]
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_one, names=names), todo):
            with atomic_path(args.output / f"{result['uci_id']}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["name"], flush=True)
    print(f"{len(todo)} datasets")
    return 0


def x_main__mutmut_orig(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--curated", type=Path, default=registry / "uci_curated.json")
    parser.add_argument("--pool", type=Path, default=registry / "uci_pool.json")
    parser.add_argument("--data", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", type=int, nargs="*", help="UCI ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the datasets whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the registry sweep with drift, or the neural detectors",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.curated, args.pool, args.data)
        if not args.only or j[0]["uci_id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{j[0]['uci_id']}.json").exists()]
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_one, names=names), todo):
            with atomic_path(args.output / f"{result['uci_id']}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["name"], flush=True)
    print(f"{len(todo)} datasets")
    return 0


def x_main__mutmut_1(argv: list[str] | None = None) -> int:
    parser = None
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--curated", type=Path, default=registry / "uci_curated.json")
    parser.add_argument("--pool", type=Path, default=registry / "uci_pool.json")
    parser.add_argument("--data", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", type=int, nargs="*", help="UCI ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the datasets whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the registry sweep with drift, or the neural detectors",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.curated, args.pool, args.data)
        if not args.only or j[0]["uci_id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{j[0]['uci_id']}.json").exists()]
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_one, names=names), todo):
            with atomic_path(args.output / f"{result['uci_id']}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["name"], flush=True)
    print(f"{len(todo)} datasets")
    return 0


def x_main__mutmut_2(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=None)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--curated", type=Path, default=registry / "uci_curated.json")
    parser.add_argument("--pool", type=Path, default=registry / "uci_pool.json")
    parser.add_argument("--data", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", type=int, nargs="*", help="UCI ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the datasets whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the registry sweep with drift, or the neural detectors",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.curated, args.pool, args.data)
        if not args.only or j[0]["uci_id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{j[0]['uci_id']}.json").exists()]
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_one, names=names), todo):
            with atomic_path(args.output / f"{result['uci_id']}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["name"], flush=True)
    print(f"{len(todo)} datasets")
    return 0


def x_main__mutmut_3(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = None
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--curated", type=Path, default=registry / "uci_curated.json")
    parser.add_argument("--pool", type=Path, default=registry / "uci_pool.json")
    parser.add_argument("--data", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", type=int, nargs="*", help="UCI ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the datasets whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the registry sweep with drift, or the neural detectors",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.curated, args.pool, args.data)
        if not args.only or j[0]["uci_id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{j[0]['uci_id']}.json").exists()]
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_one, names=names), todo):
            with atomic_path(args.output / f"{result['uci_id']}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["name"], flush=True)
    print(f"{len(todo)} datasets")
    return 0


def x_main__mutmut_4(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = None
    parser.add_argument("--curated", type=Path, default=registry / "uci_curated.json")
    parser.add_argument("--pool", type=Path, default=registry / "uci_pool.json")
    parser.add_argument("--data", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", type=int, nargs="*", help="UCI ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the datasets whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the registry sweep with drift, or the neural detectors",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.curated, args.pool, args.data)
        if not args.only or j[0]["uci_id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{j[0]['uci_id']}.json").exists()]
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_one, names=names), todo):
            with atomic_path(args.output / f"{result['uci_id']}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["name"], flush=True)
    print(f"{len(todo)} datasets")
    return 0


def x_main__mutmut_5(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" * "dataset_registry"
    parser.add_argument("--curated", type=Path, default=registry / "uci_curated.json")
    parser.add_argument("--pool", type=Path, default=registry / "uci_pool.json")
    parser.add_argument("--data", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", type=int, nargs="*", help="UCI ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the datasets whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the registry sweep with drift, or the neural detectors",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.curated, args.pool, args.data)
        if not args.only or j[0]["uci_id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{j[0]['uci_id']}.json").exists()]
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_one, names=names), todo):
            with atomic_path(args.output / f"{result['uci_id']}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["name"], flush=True)
    print(f"{len(todo)} datasets")
    return 0


def x_main__mutmut_6(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" * "evidence" / "dataset_registry"
    parser.add_argument("--curated", type=Path, default=registry / "uci_curated.json")
    parser.add_argument("--pool", type=Path, default=registry / "uci_pool.json")
    parser.add_argument("--data", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", type=int, nargs="*", help="UCI ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the datasets whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the registry sweep with drift, or the neural detectors",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.curated, args.pool, args.data)
        if not args.only or j[0]["uci_id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{j[0]['uci_id']}.json").exists()]
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_one, names=names), todo):
            with atomic_path(args.output / f"{result['uci_id']}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["name"], flush=True)
    print(f"{len(todo)} datasets")
    return 0


def x_main__mutmut_7(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root * "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--curated", type=Path, default=registry / "uci_curated.json")
    parser.add_argument("--pool", type=Path, default=registry / "uci_pool.json")
    parser.add_argument("--data", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", type=int, nargs="*", help="UCI ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the datasets whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the registry sweep with drift, or the neural detectors",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.curated, args.pool, args.data)
        if not args.only or j[0]["uci_id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{j[0]['uci_id']}.json").exists()]
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_one, names=names), todo):
            with atomic_path(args.output / f"{result['uci_id']}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["name"], flush=True)
    print(f"{len(todo)} datasets")
    return 0


def x_main__mutmut_8(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "XXverificationXX" / "evidence" / "dataset_registry"
    parser.add_argument("--curated", type=Path, default=registry / "uci_curated.json")
    parser.add_argument("--pool", type=Path, default=registry / "uci_pool.json")
    parser.add_argument("--data", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", type=int, nargs="*", help="UCI ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the datasets whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the registry sweep with drift, or the neural detectors",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.curated, args.pool, args.data)
        if not args.only or j[0]["uci_id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{j[0]['uci_id']}.json").exists()]
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_one, names=names), todo):
            with atomic_path(args.output / f"{result['uci_id']}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["name"], flush=True)
    print(f"{len(todo)} datasets")
    return 0


def x_main__mutmut_9(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "VERIFICATION" / "evidence" / "dataset_registry"
    parser.add_argument("--curated", type=Path, default=registry / "uci_curated.json")
    parser.add_argument("--pool", type=Path, default=registry / "uci_pool.json")
    parser.add_argument("--data", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", type=int, nargs="*", help="UCI ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the datasets whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the registry sweep with drift, or the neural detectors",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.curated, args.pool, args.data)
        if not args.only or j[0]["uci_id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{j[0]['uci_id']}.json").exists()]
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_one, names=names), todo):
            with atomic_path(args.output / f"{result['uci_id']}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["name"], flush=True)
    print(f"{len(todo)} datasets")
    return 0


def x_main__mutmut_10(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "XXevidenceXX" / "dataset_registry"
    parser.add_argument("--curated", type=Path, default=registry / "uci_curated.json")
    parser.add_argument("--pool", type=Path, default=registry / "uci_pool.json")
    parser.add_argument("--data", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", type=int, nargs="*", help="UCI ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the datasets whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the registry sweep with drift, or the neural detectors",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.curated, args.pool, args.data)
        if not args.only or j[0]["uci_id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{j[0]['uci_id']}.json").exists()]
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_one, names=names), todo):
            with atomic_path(args.output / f"{result['uci_id']}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["name"], flush=True)
    print(f"{len(todo)} datasets")
    return 0


def x_main__mutmut_11(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "EVIDENCE" / "dataset_registry"
    parser.add_argument("--curated", type=Path, default=registry / "uci_curated.json")
    parser.add_argument("--pool", type=Path, default=registry / "uci_pool.json")
    parser.add_argument("--data", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", type=int, nargs="*", help="UCI ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the datasets whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the registry sweep with drift, or the neural detectors",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.curated, args.pool, args.data)
        if not args.only or j[0]["uci_id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{j[0]['uci_id']}.json").exists()]
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_one, names=names), todo):
            with atomic_path(args.output / f"{result['uci_id']}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["name"], flush=True)
    print(f"{len(todo)} datasets")
    return 0


def x_main__mutmut_12(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "XXdataset_registryXX"
    parser.add_argument("--curated", type=Path, default=registry / "uci_curated.json")
    parser.add_argument("--pool", type=Path, default=registry / "uci_pool.json")
    parser.add_argument("--data", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", type=int, nargs="*", help="UCI ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the datasets whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the registry sweep with drift, or the neural detectors",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.curated, args.pool, args.data)
        if not args.only or j[0]["uci_id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{j[0]['uci_id']}.json").exists()]
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_one, names=names), todo):
            with atomic_path(args.output / f"{result['uci_id']}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["name"], flush=True)
    print(f"{len(todo)} datasets")
    return 0


def x_main__mutmut_13(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "DATASET_REGISTRY"
    parser.add_argument("--curated", type=Path, default=registry / "uci_curated.json")
    parser.add_argument("--pool", type=Path, default=registry / "uci_pool.json")
    parser.add_argument("--data", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", type=int, nargs="*", help="UCI ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the datasets whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the registry sweep with drift, or the neural detectors",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.curated, args.pool, args.data)
        if not args.only or j[0]["uci_id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{j[0]['uci_id']}.json").exists()]
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_one, names=names), todo):
            with atomic_path(args.output / f"{result['uci_id']}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["name"], flush=True)
    print(f"{len(todo)} datasets")
    return 0


def x_main__mutmut_14(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument(None, type=Path, default=registry / "uci_curated.json")
    parser.add_argument("--pool", type=Path, default=registry / "uci_pool.json")
    parser.add_argument("--data", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", type=int, nargs="*", help="UCI ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the datasets whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the registry sweep with drift, or the neural detectors",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.curated, args.pool, args.data)
        if not args.only or j[0]["uci_id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{j[0]['uci_id']}.json").exists()]
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_one, names=names), todo):
            with atomic_path(args.output / f"{result['uci_id']}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["name"], flush=True)
    print(f"{len(todo)} datasets")
    return 0


def x_main__mutmut_15(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--curated", type=None, default=registry / "uci_curated.json")
    parser.add_argument("--pool", type=Path, default=registry / "uci_pool.json")
    parser.add_argument("--data", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", type=int, nargs="*", help="UCI ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the datasets whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the registry sweep with drift, or the neural detectors",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.curated, args.pool, args.data)
        if not args.only or j[0]["uci_id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{j[0]['uci_id']}.json").exists()]
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_one, names=names), todo):
            with atomic_path(args.output / f"{result['uci_id']}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["name"], flush=True)
    print(f"{len(todo)} datasets")
    return 0


def x_main__mutmut_16(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--curated", type=Path, default=None)
    parser.add_argument("--pool", type=Path, default=registry / "uci_pool.json")
    parser.add_argument("--data", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", type=int, nargs="*", help="UCI ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the datasets whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the registry sweep with drift, or the neural detectors",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.curated, args.pool, args.data)
        if not args.only or j[0]["uci_id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{j[0]['uci_id']}.json").exists()]
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_one, names=names), todo):
            with atomic_path(args.output / f"{result['uci_id']}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["name"], flush=True)
    print(f"{len(todo)} datasets")
    return 0


def x_main__mutmut_17(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument(type=Path, default=registry / "uci_curated.json")
    parser.add_argument("--pool", type=Path, default=registry / "uci_pool.json")
    parser.add_argument("--data", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", type=int, nargs="*", help="UCI ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the datasets whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the registry sweep with drift, or the neural detectors",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.curated, args.pool, args.data)
        if not args.only or j[0]["uci_id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{j[0]['uci_id']}.json").exists()]
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_one, names=names), todo):
            with atomic_path(args.output / f"{result['uci_id']}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["name"], flush=True)
    print(f"{len(todo)} datasets")
    return 0


def x_main__mutmut_18(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--curated", default=registry / "uci_curated.json")
    parser.add_argument("--pool", type=Path, default=registry / "uci_pool.json")
    parser.add_argument("--data", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", type=int, nargs="*", help="UCI ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the datasets whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the registry sweep with drift, or the neural detectors",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.curated, args.pool, args.data)
        if not args.only or j[0]["uci_id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{j[0]['uci_id']}.json").exists()]
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_one, names=names), todo):
            with atomic_path(args.output / f"{result['uci_id']}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["name"], flush=True)
    print(f"{len(todo)} datasets")
    return 0


def x_main__mutmut_19(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--curated", type=Path, )
    parser.add_argument("--pool", type=Path, default=registry / "uci_pool.json")
    parser.add_argument("--data", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", type=int, nargs="*", help="UCI ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the datasets whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the registry sweep with drift, or the neural detectors",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.curated, args.pool, args.data)
        if not args.only or j[0]["uci_id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{j[0]['uci_id']}.json").exists()]
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_one, names=names), todo):
            with atomic_path(args.output / f"{result['uci_id']}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["name"], flush=True)
    print(f"{len(todo)} datasets")
    return 0


def x_main__mutmut_20(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("XX--curatedXX", type=Path, default=registry / "uci_curated.json")
    parser.add_argument("--pool", type=Path, default=registry / "uci_pool.json")
    parser.add_argument("--data", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", type=int, nargs="*", help="UCI ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the datasets whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the registry sweep with drift, or the neural detectors",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.curated, args.pool, args.data)
        if not args.only or j[0]["uci_id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{j[0]['uci_id']}.json").exists()]
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_one, names=names), todo):
            with atomic_path(args.output / f"{result['uci_id']}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["name"], flush=True)
    print(f"{len(todo)} datasets")
    return 0


def x_main__mutmut_21(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--CURATED", type=Path, default=registry / "uci_curated.json")
    parser.add_argument("--pool", type=Path, default=registry / "uci_pool.json")
    parser.add_argument("--data", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", type=int, nargs="*", help="UCI ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the datasets whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the registry sweep with drift, or the neural detectors",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.curated, args.pool, args.data)
        if not args.only or j[0]["uci_id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{j[0]['uci_id']}.json").exists()]
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_one, names=names), todo):
            with atomic_path(args.output / f"{result['uci_id']}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["name"], flush=True)
    print(f"{len(todo)} datasets")
    return 0


def x_main__mutmut_22(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--curated", type=Path, default=registry * "uci_curated.json")
    parser.add_argument("--pool", type=Path, default=registry / "uci_pool.json")
    parser.add_argument("--data", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", type=int, nargs="*", help="UCI ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the datasets whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the registry sweep with drift, or the neural detectors",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.curated, args.pool, args.data)
        if not args.only or j[0]["uci_id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{j[0]['uci_id']}.json").exists()]
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_one, names=names), todo):
            with atomic_path(args.output / f"{result['uci_id']}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["name"], flush=True)
    print(f"{len(todo)} datasets")
    return 0


def x_main__mutmut_23(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--curated", type=Path, default=registry / "XXuci_curated.jsonXX")
    parser.add_argument("--pool", type=Path, default=registry / "uci_pool.json")
    parser.add_argument("--data", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", type=int, nargs="*", help="UCI ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the datasets whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the registry sweep with drift, or the neural detectors",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.curated, args.pool, args.data)
        if not args.only or j[0]["uci_id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{j[0]['uci_id']}.json").exists()]
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_one, names=names), todo):
            with atomic_path(args.output / f"{result['uci_id']}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["name"], flush=True)
    print(f"{len(todo)} datasets")
    return 0


def x_main__mutmut_24(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--curated", type=Path, default=registry / "UCI_CURATED.JSON")
    parser.add_argument("--pool", type=Path, default=registry / "uci_pool.json")
    parser.add_argument("--data", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", type=int, nargs="*", help="UCI ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the datasets whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the registry sweep with drift, or the neural detectors",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.curated, args.pool, args.data)
        if not args.only or j[0]["uci_id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{j[0]['uci_id']}.json").exists()]
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_one, names=names), todo):
            with atomic_path(args.output / f"{result['uci_id']}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["name"], flush=True)
    print(f"{len(todo)} datasets")
    return 0


def x_main__mutmut_25(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--curated", type=Path, default=registry / "uci_curated.json")
    parser.add_argument(None, type=Path, default=registry / "uci_pool.json")
    parser.add_argument("--data", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", type=int, nargs="*", help="UCI ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the datasets whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the registry sweep with drift, or the neural detectors",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.curated, args.pool, args.data)
        if not args.only or j[0]["uci_id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{j[0]['uci_id']}.json").exists()]
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_one, names=names), todo):
            with atomic_path(args.output / f"{result['uci_id']}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["name"], flush=True)
    print(f"{len(todo)} datasets")
    return 0


def x_main__mutmut_26(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--curated", type=Path, default=registry / "uci_curated.json")
    parser.add_argument("--pool", type=None, default=registry / "uci_pool.json")
    parser.add_argument("--data", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", type=int, nargs="*", help="UCI ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the datasets whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the registry sweep with drift, or the neural detectors",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.curated, args.pool, args.data)
        if not args.only or j[0]["uci_id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{j[0]['uci_id']}.json").exists()]
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_one, names=names), todo):
            with atomic_path(args.output / f"{result['uci_id']}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["name"], flush=True)
    print(f"{len(todo)} datasets")
    return 0


def x_main__mutmut_27(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--curated", type=Path, default=registry / "uci_curated.json")
    parser.add_argument("--pool", type=Path, default=None)
    parser.add_argument("--data", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", type=int, nargs="*", help="UCI ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the datasets whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the registry sweep with drift, or the neural detectors",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.curated, args.pool, args.data)
        if not args.only or j[0]["uci_id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{j[0]['uci_id']}.json").exists()]
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_one, names=names), todo):
            with atomic_path(args.output / f"{result['uci_id']}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["name"], flush=True)
    print(f"{len(todo)} datasets")
    return 0


def x_main__mutmut_28(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--curated", type=Path, default=registry / "uci_curated.json")
    parser.add_argument(type=Path, default=registry / "uci_pool.json")
    parser.add_argument("--data", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", type=int, nargs="*", help="UCI ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the datasets whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the registry sweep with drift, or the neural detectors",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.curated, args.pool, args.data)
        if not args.only or j[0]["uci_id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{j[0]['uci_id']}.json").exists()]
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_one, names=names), todo):
            with atomic_path(args.output / f"{result['uci_id']}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["name"], flush=True)
    print(f"{len(todo)} datasets")
    return 0


def x_main__mutmut_29(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--curated", type=Path, default=registry / "uci_curated.json")
    parser.add_argument("--pool", default=registry / "uci_pool.json")
    parser.add_argument("--data", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", type=int, nargs="*", help="UCI ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the datasets whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the registry sweep with drift, or the neural detectors",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.curated, args.pool, args.data)
        if not args.only or j[0]["uci_id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{j[0]['uci_id']}.json").exists()]
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_one, names=names), todo):
            with atomic_path(args.output / f"{result['uci_id']}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["name"], flush=True)
    print(f"{len(todo)} datasets")
    return 0


def x_main__mutmut_30(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--curated", type=Path, default=registry / "uci_curated.json")
    parser.add_argument("--pool", type=Path, )
    parser.add_argument("--data", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", type=int, nargs="*", help="UCI ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the datasets whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the registry sweep with drift, or the neural detectors",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.curated, args.pool, args.data)
        if not args.only or j[0]["uci_id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{j[0]['uci_id']}.json").exists()]
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_one, names=names), todo):
            with atomic_path(args.output / f"{result['uci_id']}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["name"], flush=True)
    print(f"{len(todo)} datasets")
    return 0


def x_main__mutmut_31(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--curated", type=Path, default=registry / "uci_curated.json")
    parser.add_argument("XX--poolXX", type=Path, default=registry / "uci_pool.json")
    parser.add_argument("--data", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", type=int, nargs="*", help="UCI ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the datasets whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the registry sweep with drift, or the neural detectors",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.curated, args.pool, args.data)
        if not args.only or j[0]["uci_id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{j[0]['uci_id']}.json").exists()]
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_one, names=names), todo):
            with atomic_path(args.output / f"{result['uci_id']}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["name"], flush=True)
    print(f"{len(todo)} datasets")
    return 0


def x_main__mutmut_32(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--curated", type=Path, default=registry / "uci_curated.json")
    parser.add_argument("--POOL", type=Path, default=registry / "uci_pool.json")
    parser.add_argument("--data", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", type=int, nargs="*", help="UCI ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the datasets whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the registry sweep with drift, or the neural detectors",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.curated, args.pool, args.data)
        if not args.only or j[0]["uci_id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{j[0]['uci_id']}.json").exists()]
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_one, names=names), todo):
            with atomic_path(args.output / f"{result['uci_id']}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["name"], flush=True)
    print(f"{len(todo)} datasets")
    return 0


def x_main__mutmut_33(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--curated", type=Path, default=registry / "uci_curated.json")
    parser.add_argument("--pool", type=Path, default=registry * "uci_pool.json")
    parser.add_argument("--data", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", type=int, nargs="*", help="UCI ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the datasets whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the registry sweep with drift, or the neural detectors",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.curated, args.pool, args.data)
        if not args.only or j[0]["uci_id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{j[0]['uci_id']}.json").exists()]
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_one, names=names), todo):
            with atomic_path(args.output / f"{result['uci_id']}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["name"], flush=True)
    print(f"{len(todo)} datasets")
    return 0


def x_main__mutmut_34(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--curated", type=Path, default=registry / "uci_curated.json")
    parser.add_argument("--pool", type=Path, default=registry / "XXuci_pool.jsonXX")
    parser.add_argument("--data", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", type=int, nargs="*", help="UCI ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the datasets whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the registry sweep with drift, or the neural detectors",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.curated, args.pool, args.data)
        if not args.only or j[0]["uci_id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{j[0]['uci_id']}.json").exists()]
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_one, names=names), todo):
            with atomic_path(args.output / f"{result['uci_id']}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["name"], flush=True)
    print(f"{len(todo)} datasets")
    return 0


def x_main__mutmut_35(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--curated", type=Path, default=registry / "uci_curated.json")
    parser.add_argument("--pool", type=Path, default=registry / "UCI_POOL.JSON")
    parser.add_argument("--data", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", type=int, nargs="*", help="UCI ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the datasets whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the registry sweep with drift, or the neural detectors",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.curated, args.pool, args.data)
        if not args.only or j[0]["uci_id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{j[0]['uci_id']}.json").exists()]
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_one, names=names), todo):
            with atomic_path(args.output / f"{result['uci_id']}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["name"], flush=True)
    print(f"{len(todo)} datasets")
    return 0


def x_main__mutmut_36(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--curated", type=Path, default=registry / "uci_curated.json")
    parser.add_argument("--pool", type=Path, default=registry / "uci_pool.json")
    parser.add_argument(None, type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", type=int, nargs="*", help="UCI ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the datasets whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the registry sweep with drift, or the neural detectors",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.curated, args.pool, args.data)
        if not args.only or j[0]["uci_id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{j[0]['uci_id']}.json").exists()]
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_one, names=names), todo):
            with atomic_path(args.output / f"{result['uci_id']}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["name"], flush=True)
    print(f"{len(todo)} datasets")
    return 0


def x_main__mutmut_37(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--curated", type=Path, default=registry / "uci_curated.json")
    parser.add_argument("--pool", type=Path, default=registry / "uci_pool.json")
    parser.add_argument("--data", type=None, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", type=int, nargs="*", help="UCI ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the datasets whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the registry sweep with drift, or the neural detectors",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.curated, args.pool, args.data)
        if not args.only or j[0]["uci_id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{j[0]['uci_id']}.json").exists()]
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_one, names=names), todo):
            with atomic_path(args.output / f"{result['uci_id']}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["name"], flush=True)
    print(f"{len(todo)} datasets")
    return 0


def x_main__mutmut_38(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--curated", type=Path, default=registry / "uci_curated.json")
    parser.add_argument("--pool", type=Path, default=registry / "uci_pool.json")
    parser.add_argument("--data", type=Path, default=None)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", type=int, nargs="*", help="UCI ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the datasets whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the registry sweep with drift, or the neural detectors",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.curated, args.pool, args.data)
        if not args.only or j[0]["uci_id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{j[0]['uci_id']}.json").exists()]
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_one, names=names), todo):
            with atomic_path(args.output / f"{result['uci_id']}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["name"], flush=True)
    print(f"{len(todo)} datasets")
    return 0


def x_main__mutmut_39(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--curated", type=Path, default=registry / "uci_curated.json")
    parser.add_argument("--pool", type=Path, default=registry / "uci_pool.json")
    parser.add_argument(type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", type=int, nargs="*", help="UCI ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the datasets whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the registry sweep with drift, or the neural detectors",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.curated, args.pool, args.data)
        if not args.only or j[0]["uci_id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{j[0]['uci_id']}.json").exists()]
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_one, names=names), todo):
            with atomic_path(args.output / f"{result['uci_id']}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["name"], flush=True)
    print(f"{len(todo)} datasets")
    return 0


def x_main__mutmut_40(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--curated", type=Path, default=registry / "uci_curated.json")
    parser.add_argument("--pool", type=Path, default=registry / "uci_pool.json")
    parser.add_argument("--data", default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", type=int, nargs="*", help="UCI ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the datasets whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the registry sweep with drift, or the neural detectors",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.curated, args.pool, args.data)
        if not args.only or j[0]["uci_id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{j[0]['uci_id']}.json").exists()]
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_one, names=names), todo):
            with atomic_path(args.output / f"{result['uci_id']}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["name"], flush=True)
    print(f"{len(todo)} datasets")
    return 0


def x_main__mutmut_41(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--curated", type=Path, default=registry / "uci_curated.json")
    parser.add_argument("--pool", type=Path, default=registry / "uci_pool.json")
    parser.add_argument("--data", type=Path, )
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", type=int, nargs="*", help="UCI ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the datasets whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the registry sweep with drift, or the neural detectors",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.curated, args.pool, args.data)
        if not args.only or j[0]["uci_id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{j[0]['uci_id']}.json").exists()]
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_one, names=names), todo):
            with atomic_path(args.output / f"{result['uci_id']}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["name"], flush=True)
    print(f"{len(todo)} datasets")
    return 0


def x_main__mutmut_42(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--curated", type=Path, default=registry / "uci_curated.json")
    parser.add_argument("--pool", type=Path, default=registry / "uci_pool.json")
    parser.add_argument("XX--dataXX", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", type=int, nargs="*", help="UCI ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the datasets whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the registry sweep with drift, or the neural detectors",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.curated, args.pool, args.data)
        if not args.only or j[0]["uci_id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{j[0]['uci_id']}.json").exists()]
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_one, names=names), todo):
            with atomic_path(args.output / f"{result['uci_id']}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["name"], flush=True)
    print(f"{len(todo)} datasets")
    return 0


def x_main__mutmut_43(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--curated", type=Path, default=registry / "uci_curated.json")
    parser.add_argument("--pool", type=Path, default=registry / "uci_pool.json")
    parser.add_argument("--DATA", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", type=int, nargs="*", help="UCI ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the datasets whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the registry sweep with drift, or the neural detectors",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.curated, args.pool, args.data)
        if not args.only or j[0]["uci_id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{j[0]['uci_id']}.json").exists()]
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_one, names=names), todo):
            with atomic_path(args.output / f"{result['uci_id']}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["name"], flush=True)
    print(f"{len(todo)} datasets")
    return 0


def x_main__mutmut_44(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--curated", type=Path, default=registry / "uci_curated.json")
    parser.add_argument("--pool", type=Path, default=registry / "uci_pool.json")
    parser.add_argument("--data", type=Path, default=root / "data" * "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", type=int, nargs="*", help="UCI ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the datasets whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the registry sweep with drift, or the neural detectors",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.curated, args.pool, args.data)
        if not args.only or j[0]["uci_id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{j[0]['uci_id']}.json").exists()]
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_one, names=names), todo):
            with atomic_path(args.output / f"{result['uci_id']}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["name"], flush=True)
    print(f"{len(todo)} datasets")
    return 0


def x_main__mutmut_45(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--curated", type=Path, default=registry / "uci_curated.json")
    parser.add_argument("--pool", type=Path, default=registry / "uci_pool.json")
    parser.add_argument("--data", type=Path, default=root * "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", type=int, nargs="*", help="UCI ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the datasets whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the registry sweep with drift, or the neural detectors",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.curated, args.pool, args.data)
        if not args.only or j[0]["uci_id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{j[0]['uci_id']}.json").exists()]
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_one, names=names), todo):
            with atomic_path(args.output / f"{result['uci_id']}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["name"], flush=True)
    print(f"{len(todo)} datasets")
    return 0


def x_main__mutmut_46(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--curated", type=Path, default=registry / "uci_curated.json")
    parser.add_argument("--pool", type=Path, default=registry / "uci_pool.json")
    parser.add_argument("--data", type=Path, default=root / "XXdataXX" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", type=int, nargs="*", help="UCI ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the datasets whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the registry sweep with drift, or the neural detectors",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.curated, args.pool, args.data)
        if not args.only or j[0]["uci_id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{j[0]['uci_id']}.json").exists()]
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_one, names=names), todo):
            with atomic_path(args.output / f"{result['uci_id']}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["name"], flush=True)
    print(f"{len(todo)} datasets")
    return 0


def x_main__mutmut_47(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--curated", type=Path, default=registry / "uci_curated.json")
    parser.add_argument("--pool", type=Path, default=registry / "uci_pool.json")
    parser.add_argument("--data", type=Path, default=root / "DATA" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", type=int, nargs="*", help="UCI ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the datasets whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the registry sweep with drift, or the neural detectors",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.curated, args.pool, args.data)
        if not args.only or j[0]["uci_id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{j[0]['uci_id']}.json").exists()]
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_one, names=names), todo):
            with atomic_path(args.output / f"{result['uci_id']}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["name"], flush=True)
    print(f"{len(todo)} datasets")
    return 0


def x_main__mutmut_48(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--curated", type=Path, default=registry / "uci_curated.json")
    parser.add_argument("--pool", type=Path, default=registry / "uci_pool.json")
    parser.add_argument("--data", type=Path, default=root / "data" / "XXpoolXX")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", type=int, nargs="*", help="UCI ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the datasets whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the registry sweep with drift, or the neural detectors",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.curated, args.pool, args.data)
        if not args.only or j[0]["uci_id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{j[0]['uci_id']}.json").exists()]
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_one, names=names), todo):
            with atomic_path(args.output / f"{result['uci_id']}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["name"], flush=True)
    print(f"{len(todo)} datasets")
    return 0


def x_main__mutmut_49(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--curated", type=Path, default=registry / "uci_curated.json")
    parser.add_argument("--pool", type=Path, default=registry / "uci_pool.json")
    parser.add_argument("--data", type=Path, default=root / "data" / "POOL")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", type=int, nargs="*", help="UCI ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the datasets whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the registry sweep with drift, or the neural detectors",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.curated, args.pool, args.data)
        if not args.only or j[0]["uci_id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{j[0]['uci_id']}.json").exists()]
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_one, names=names), todo):
            with atomic_path(args.output / f"{result['uci_id']}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["name"], flush=True)
    print(f"{len(todo)} datasets")
    return 0


def x_main__mutmut_50(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--curated", type=Path, default=registry / "uci_curated.json")
    parser.add_argument("--pool", type=Path, default=registry / "uci_pool.json")
    parser.add_argument("--data", type=Path, default=root / "data" / "pool")
    parser.add_argument(None, type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", type=int, nargs="*", help="UCI ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the datasets whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the registry sweep with drift, or the neural detectors",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.curated, args.pool, args.data)
        if not args.only or j[0]["uci_id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{j[0]['uci_id']}.json").exists()]
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_one, names=names), todo):
            with atomic_path(args.output / f"{result['uci_id']}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["name"], flush=True)
    print(f"{len(todo)} datasets")
    return 0


def x_main__mutmut_51(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--curated", type=Path, default=registry / "uci_curated.json")
    parser.add_argument("--pool", type=Path, default=registry / "uci_pool.json")
    parser.add_argument("--data", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=None, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", type=int, nargs="*", help="UCI ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the datasets whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the registry sweep with drift, or the neural detectors",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.curated, args.pool, args.data)
        if not args.only or j[0]["uci_id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{j[0]['uci_id']}.json").exists()]
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_one, names=names), todo):
            with atomic_path(args.output / f"{result['uci_id']}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["name"], flush=True)
    print(f"{len(todo)} datasets")
    return 0


def x_main__mutmut_52(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--curated", type=Path, default=registry / "uci_curated.json")
    parser.add_argument("--pool", type=Path, default=registry / "uci_pool.json")
    parser.add_argument("--data", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=None)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", type=int, nargs="*", help="UCI ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the datasets whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the registry sweep with drift, or the neural detectors",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.curated, args.pool, args.data)
        if not args.only or j[0]["uci_id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{j[0]['uci_id']}.json").exists()]
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_one, names=names), todo):
            with atomic_path(args.output / f"{result['uci_id']}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["name"], flush=True)
    print(f"{len(todo)} datasets")
    return 0


def x_main__mutmut_53(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--curated", type=Path, default=registry / "uci_curated.json")
    parser.add_argument("--pool", type=Path, default=registry / "uci_pool.json")
    parser.add_argument("--data", type=Path, default=root / "data" / "pool")
    parser.add_argument(type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", type=int, nargs="*", help="UCI ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the datasets whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the registry sweep with drift, or the neural detectors",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.curated, args.pool, args.data)
        if not args.only or j[0]["uci_id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{j[0]['uci_id']}.json").exists()]
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_one, names=names), todo):
            with atomic_path(args.output / f"{result['uci_id']}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["name"], flush=True)
    print(f"{len(todo)} datasets")
    return 0


def x_main__mutmut_54(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--curated", type=Path, default=registry / "uci_curated.json")
    parser.add_argument("--pool", type=Path, default=registry / "uci_pool.json")
    parser.add_argument("--data", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", type=int, nargs="*", help="UCI ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the datasets whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the registry sweep with drift, or the neural detectors",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.curated, args.pool, args.data)
        if not args.only or j[0]["uci_id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{j[0]['uci_id']}.json").exists()]
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_one, names=names), todo):
            with atomic_path(args.output / f"{result['uci_id']}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["name"], flush=True)
    print(f"{len(todo)} datasets")
    return 0


def x_main__mutmut_55(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--curated", type=Path, default=registry / "uci_curated.json")
    parser.add_argument("--pool", type=Path, default=registry / "uci_pool.json")
    parser.add_argument("--data", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, )
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", type=int, nargs="*", help="UCI ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the datasets whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the registry sweep with drift, or the neural detectors",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.curated, args.pool, args.data)
        if not args.only or j[0]["uci_id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{j[0]['uci_id']}.json").exists()]
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_one, names=names), todo):
            with atomic_path(args.output / f"{result['uci_id']}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["name"], flush=True)
    print(f"{len(todo)} datasets")
    return 0


def x_main__mutmut_56(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--curated", type=Path, default=registry / "uci_curated.json")
    parser.add_argument("--pool", type=Path, default=registry / "uci_pool.json")
    parser.add_argument("--data", type=Path, default=root / "data" / "pool")
    parser.add_argument("XX--outputXX", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", type=int, nargs="*", help="UCI ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the datasets whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the registry sweep with drift, or the neural detectors",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.curated, args.pool, args.data)
        if not args.only or j[0]["uci_id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{j[0]['uci_id']}.json").exists()]
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_one, names=names), todo):
            with atomic_path(args.output / f"{result['uci_id']}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["name"], flush=True)
    print(f"{len(todo)} datasets")
    return 0


def x_main__mutmut_57(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--curated", type=Path, default=registry / "uci_curated.json")
    parser.add_argument("--pool", type=Path, default=registry / "uci_pool.json")
    parser.add_argument("--data", type=Path, default=root / "data" / "pool")
    parser.add_argument("--OUTPUT", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", type=int, nargs="*", help="UCI ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the datasets whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the registry sweep with drift, or the neural detectors",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.curated, args.pool, args.data)
        if not args.only or j[0]["uci_id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{j[0]['uci_id']}.json").exists()]
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_one, names=names), todo):
            with atomic_path(args.output / f"{result['uci_id']}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["name"], flush=True)
    print(f"{len(todo)} datasets")
    return 0


def x_main__mutmut_58(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--curated", type=Path, default=registry / "uci_curated.json")
    parser.add_argument("--pool", type=Path, default=registry / "uci_pool.json")
    parser.add_argument("--data", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=False)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", type=int, nargs="*", help="UCI ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the datasets whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the registry sweep with drift, or the neural detectors",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.curated, args.pool, args.data)
        if not args.only or j[0]["uci_id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{j[0]['uci_id']}.json").exists()]
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_one, names=names), todo):
            with atomic_path(args.output / f"{result['uci_id']}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["name"], flush=True)
    print(f"{len(todo)} datasets")
    return 0


def x_main__mutmut_59(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--curated", type=Path, default=registry / "uci_curated.json")
    parser.add_argument("--pool", type=Path, default=registry / "uci_pool.json")
    parser.add_argument("--data", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument(None, type=int, default=4)
    parser.add_argument("--only", type=int, nargs="*", help="UCI ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the datasets whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the registry sweep with drift, or the neural detectors",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.curated, args.pool, args.data)
        if not args.only or j[0]["uci_id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{j[0]['uci_id']}.json").exists()]
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_one, names=names), todo):
            with atomic_path(args.output / f"{result['uci_id']}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["name"], flush=True)
    print(f"{len(todo)} datasets")
    return 0


def x_main__mutmut_60(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--curated", type=Path, default=registry / "uci_curated.json")
    parser.add_argument("--pool", type=Path, default=registry / "uci_pool.json")
    parser.add_argument("--data", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=None, default=4)
    parser.add_argument("--only", type=int, nargs="*", help="UCI ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the datasets whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the registry sweep with drift, or the neural detectors",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.curated, args.pool, args.data)
        if not args.only or j[0]["uci_id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{j[0]['uci_id']}.json").exists()]
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_one, names=names), todo):
            with atomic_path(args.output / f"{result['uci_id']}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["name"], flush=True)
    print(f"{len(todo)} datasets")
    return 0


def x_main__mutmut_61(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--curated", type=Path, default=registry / "uci_curated.json")
    parser.add_argument("--pool", type=Path, default=registry / "uci_pool.json")
    parser.add_argument("--data", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=None)
    parser.add_argument("--only", type=int, nargs="*", help="UCI ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the datasets whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the registry sweep with drift, or the neural detectors",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.curated, args.pool, args.data)
        if not args.only or j[0]["uci_id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{j[0]['uci_id']}.json").exists()]
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_one, names=names), todo):
            with atomic_path(args.output / f"{result['uci_id']}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["name"], flush=True)
    print(f"{len(todo)} datasets")
    return 0


def x_main__mutmut_62(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--curated", type=Path, default=registry / "uci_curated.json")
    parser.add_argument("--pool", type=Path, default=registry / "uci_pool.json")
    parser.add_argument("--data", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument(type=int, default=4)
    parser.add_argument("--only", type=int, nargs="*", help="UCI ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the datasets whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the registry sweep with drift, or the neural detectors",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.curated, args.pool, args.data)
        if not args.only or j[0]["uci_id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{j[0]['uci_id']}.json").exists()]
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_one, names=names), todo):
            with atomic_path(args.output / f"{result['uci_id']}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["name"], flush=True)
    print(f"{len(todo)} datasets")
    return 0


def x_main__mutmut_63(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--curated", type=Path, default=registry / "uci_curated.json")
    parser.add_argument("--pool", type=Path, default=registry / "uci_pool.json")
    parser.add_argument("--data", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", default=4)
    parser.add_argument("--only", type=int, nargs="*", help="UCI ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the datasets whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the registry sweep with drift, or the neural detectors",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.curated, args.pool, args.data)
        if not args.only or j[0]["uci_id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{j[0]['uci_id']}.json").exists()]
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_one, names=names), todo):
            with atomic_path(args.output / f"{result['uci_id']}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["name"], flush=True)
    print(f"{len(todo)} datasets")
    return 0


def x_main__mutmut_64(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--curated", type=Path, default=registry / "uci_curated.json")
    parser.add_argument("--pool", type=Path, default=registry / "uci_pool.json")
    parser.add_argument("--data", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, )
    parser.add_argument("--only", type=int, nargs="*", help="UCI ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the datasets whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the registry sweep with drift, or the neural detectors",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.curated, args.pool, args.data)
        if not args.only or j[0]["uci_id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{j[0]['uci_id']}.json").exists()]
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_one, names=names), todo):
            with atomic_path(args.output / f"{result['uci_id']}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["name"], flush=True)
    print(f"{len(todo)} datasets")
    return 0


def x_main__mutmut_65(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--curated", type=Path, default=registry / "uci_curated.json")
    parser.add_argument("--pool", type=Path, default=registry / "uci_pool.json")
    parser.add_argument("--data", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("XX--workersXX", type=int, default=4)
    parser.add_argument("--only", type=int, nargs="*", help="UCI ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the datasets whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the registry sweep with drift, or the neural detectors",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.curated, args.pool, args.data)
        if not args.only or j[0]["uci_id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{j[0]['uci_id']}.json").exists()]
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_one, names=names), todo):
            with atomic_path(args.output / f"{result['uci_id']}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["name"], flush=True)
    print(f"{len(todo)} datasets")
    return 0


def x_main__mutmut_66(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--curated", type=Path, default=registry / "uci_curated.json")
    parser.add_argument("--pool", type=Path, default=registry / "uci_pool.json")
    parser.add_argument("--data", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--WORKERS", type=int, default=4)
    parser.add_argument("--only", type=int, nargs="*", help="UCI ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the datasets whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the registry sweep with drift, or the neural detectors",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.curated, args.pool, args.data)
        if not args.only or j[0]["uci_id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{j[0]['uci_id']}.json").exists()]
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_one, names=names), todo):
            with atomic_path(args.output / f"{result['uci_id']}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["name"], flush=True)
    print(f"{len(todo)} datasets")
    return 0


def x_main__mutmut_67(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--curated", type=Path, default=registry / "uci_curated.json")
    parser.add_argument("--pool", type=Path, default=registry / "uci_pool.json")
    parser.add_argument("--data", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=5)
    parser.add_argument("--only", type=int, nargs="*", help="UCI ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the datasets whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the registry sweep with drift, or the neural detectors",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.curated, args.pool, args.data)
        if not args.only or j[0]["uci_id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{j[0]['uci_id']}.json").exists()]
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_one, names=names), todo):
            with atomic_path(args.output / f"{result['uci_id']}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["name"], flush=True)
    print(f"{len(todo)} datasets")
    return 0


def x_main__mutmut_68(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--curated", type=Path, default=registry / "uci_curated.json")
    parser.add_argument("--pool", type=Path, default=registry / "uci_pool.json")
    parser.add_argument("--data", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument(None, type=int, nargs="*", help="UCI ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the datasets whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the registry sweep with drift, or the neural detectors",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.curated, args.pool, args.data)
        if not args.only or j[0]["uci_id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{j[0]['uci_id']}.json").exists()]
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_one, names=names), todo):
            with atomic_path(args.output / f"{result['uci_id']}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["name"], flush=True)
    print(f"{len(todo)} datasets")
    return 0


def x_main__mutmut_69(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--curated", type=Path, default=registry / "uci_curated.json")
    parser.add_argument("--pool", type=Path, default=registry / "uci_pool.json")
    parser.add_argument("--data", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", type=None, nargs="*", help="UCI ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the datasets whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the registry sweep with drift, or the neural detectors",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.curated, args.pool, args.data)
        if not args.only or j[0]["uci_id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{j[0]['uci_id']}.json").exists()]
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_one, names=names), todo):
            with atomic_path(args.output / f"{result['uci_id']}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["name"], flush=True)
    print(f"{len(todo)} datasets")
    return 0


def x_main__mutmut_70(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--curated", type=Path, default=registry / "uci_curated.json")
    parser.add_argument("--pool", type=Path, default=registry / "uci_pool.json")
    parser.add_argument("--data", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", type=int, nargs=None, help="UCI ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the datasets whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the registry sweep with drift, or the neural detectors",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.curated, args.pool, args.data)
        if not args.only or j[0]["uci_id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{j[0]['uci_id']}.json").exists()]
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_one, names=names), todo):
            with atomic_path(args.output / f"{result['uci_id']}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["name"], flush=True)
    print(f"{len(todo)} datasets")
    return 0


def x_main__mutmut_71(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--curated", type=Path, default=registry / "uci_curated.json")
    parser.add_argument("--pool", type=Path, default=registry / "uci_pool.json")
    parser.add_argument("--data", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", type=int, nargs="*", help=None)
    parser.add_argument(
        "--resume", action="store_true", help="skip the datasets whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the registry sweep with drift, or the neural detectors",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.curated, args.pool, args.data)
        if not args.only or j[0]["uci_id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{j[0]['uci_id']}.json").exists()]
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_one, names=names), todo):
            with atomic_path(args.output / f"{result['uci_id']}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["name"], flush=True)
    print(f"{len(todo)} datasets")
    return 0


def x_main__mutmut_72(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--curated", type=Path, default=registry / "uci_curated.json")
    parser.add_argument("--pool", type=Path, default=registry / "uci_pool.json")
    parser.add_argument("--data", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument(type=int, nargs="*", help="UCI ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the datasets whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the registry sweep with drift, or the neural detectors",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.curated, args.pool, args.data)
        if not args.only or j[0]["uci_id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{j[0]['uci_id']}.json").exists()]
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_one, names=names), todo):
            with atomic_path(args.output / f"{result['uci_id']}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["name"], flush=True)
    print(f"{len(todo)} datasets")
    return 0


def x_main__mutmut_73(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--curated", type=Path, default=registry / "uci_curated.json")
    parser.add_argument("--pool", type=Path, default=registry / "uci_pool.json")
    parser.add_argument("--data", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="UCI ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the datasets whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the registry sweep with drift, or the neural detectors",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.curated, args.pool, args.data)
        if not args.only or j[0]["uci_id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{j[0]['uci_id']}.json").exists()]
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_one, names=names), todo):
            with atomic_path(args.output / f"{result['uci_id']}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["name"], flush=True)
    print(f"{len(todo)} datasets")
    return 0


def x_main__mutmut_74(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--curated", type=Path, default=registry / "uci_curated.json")
    parser.add_argument("--pool", type=Path, default=registry / "uci_pool.json")
    parser.add_argument("--data", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", type=int, help="UCI ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the datasets whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the registry sweep with drift, or the neural detectors",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.curated, args.pool, args.data)
        if not args.only or j[0]["uci_id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{j[0]['uci_id']}.json").exists()]
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_one, names=names), todo):
            with atomic_path(args.output / f"{result['uci_id']}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["name"], flush=True)
    print(f"{len(todo)} datasets")
    return 0


def x_main__mutmut_75(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--curated", type=Path, default=registry / "uci_curated.json")
    parser.add_argument("--pool", type=Path, default=registry / "uci_pool.json")
    parser.add_argument("--data", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", type=int, nargs="*", )
    parser.add_argument(
        "--resume", action="store_true", help="skip the datasets whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the registry sweep with drift, or the neural detectors",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.curated, args.pool, args.data)
        if not args.only or j[0]["uci_id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{j[0]['uci_id']}.json").exists()]
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_one, names=names), todo):
            with atomic_path(args.output / f"{result['uci_id']}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["name"], flush=True)
    print(f"{len(todo)} datasets")
    return 0


def x_main__mutmut_76(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--curated", type=Path, default=registry / "uci_curated.json")
    parser.add_argument("--pool", type=Path, default=registry / "uci_pool.json")
    parser.add_argument("--data", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("XX--onlyXX", type=int, nargs="*", help="UCI ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the datasets whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the registry sweep with drift, or the neural detectors",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.curated, args.pool, args.data)
        if not args.only or j[0]["uci_id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{j[0]['uci_id']}.json").exists()]
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_one, names=names), todo):
            with atomic_path(args.output / f"{result['uci_id']}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["name"], flush=True)
    print(f"{len(todo)} datasets")
    return 0


def x_main__mutmut_77(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--curated", type=Path, default=registry / "uci_curated.json")
    parser.add_argument("--pool", type=Path, default=registry / "uci_pool.json")
    parser.add_argument("--data", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--ONLY", type=int, nargs="*", help="UCI ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the datasets whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the registry sweep with drift, or the neural detectors",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.curated, args.pool, args.data)
        if not args.only or j[0]["uci_id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{j[0]['uci_id']}.json").exists()]
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_one, names=names), todo):
            with atomic_path(args.output / f"{result['uci_id']}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["name"], flush=True)
    print(f"{len(todo)} datasets")
    return 0


def x_main__mutmut_78(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--curated", type=Path, default=registry / "uci_curated.json")
    parser.add_argument("--pool", type=Path, default=registry / "uci_pool.json")
    parser.add_argument("--data", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", type=int, nargs="XX*XX", help="UCI ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the datasets whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the registry sweep with drift, or the neural detectors",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.curated, args.pool, args.data)
        if not args.only or j[0]["uci_id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{j[0]['uci_id']}.json").exists()]
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_one, names=names), todo):
            with atomic_path(args.output / f"{result['uci_id']}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["name"], flush=True)
    print(f"{len(todo)} datasets")
    return 0


def x_main__mutmut_79(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--curated", type=Path, default=registry / "uci_curated.json")
    parser.add_argument("--pool", type=Path, default=registry / "uci_pool.json")
    parser.add_argument("--data", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", type=int, nargs="*", help="XXUCI ids, for a quick checkXX")
    parser.add_argument(
        "--resume", action="store_true", help="skip the datasets whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the registry sweep with drift, or the neural detectors",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.curated, args.pool, args.data)
        if not args.only or j[0]["uci_id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{j[0]['uci_id']}.json").exists()]
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_one, names=names), todo):
            with atomic_path(args.output / f"{result['uci_id']}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["name"], flush=True)
    print(f"{len(todo)} datasets")
    return 0


def x_main__mutmut_80(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--curated", type=Path, default=registry / "uci_curated.json")
    parser.add_argument("--pool", type=Path, default=registry / "uci_pool.json")
    parser.add_argument("--data", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", type=int, nargs="*", help="uci ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the datasets whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the registry sweep with drift, or the neural detectors",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.curated, args.pool, args.data)
        if not args.only or j[0]["uci_id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{j[0]['uci_id']}.json").exists()]
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_one, names=names), todo):
            with atomic_path(args.output / f"{result['uci_id']}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["name"], flush=True)
    print(f"{len(todo)} datasets")
    return 0


def x_main__mutmut_81(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--curated", type=Path, default=registry / "uci_curated.json")
    parser.add_argument("--pool", type=Path, default=registry / "uci_pool.json")
    parser.add_argument("--data", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", type=int, nargs="*", help="UCI IDS, FOR A QUICK CHECK")
    parser.add_argument(
        "--resume", action="store_true", help="skip the datasets whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the registry sweep with drift, or the neural detectors",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.curated, args.pool, args.data)
        if not args.only or j[0]["uci_id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{j[0]['uci_id']}.json").exists()]
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_one, names=names), todo):
            with atomic_path(args.output / f"{result['uci_id']}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["name"], flush=True)
    print(f"{len(todo)} datasets")
    return 0


def x_main__mutmut_82(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--curated", type=Path, default=registry / "uci_curated.json")
    parser.add_argument("--pool", type=Path, default=registry / "uci_pool.json")
    parser.add_argument("--data", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", type=int, nargs="*", help="UCI ids, for a quick check")
    parser.add_argument(
        None, action="store_true", help="skip the datasets whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the registry sweep with drift, or the neural detectors",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.curated, args.pool, args.data)
        if not args.only or j[0]["uci_id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{j[0]['uci_id']}.json").exists()]
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_one, names=names), todo):
            with atomic_path(args.output / f"{result['uci_id']}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["name"], flush=True)
    print(f"{len(todo)} datasets")
    return 0


def x_main__mutmut_83(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--curated", type=Path, default=registry / "uci_curated.json")
    parser.add_argument("--pool", type=Path, default=registry / "uci_pool.json")
    parser.add_argument("--data", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", type=int, nargs="*", help="UCI ids, for a quick check")
    parser.add_argument(
        "--resume", action=None, help="skip the datasets whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the registry sweep with drift, or the neural detectors",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.curated, args.pool, args.data)
        if not args.only or j[0]["uci_id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{j[0]['uci_id']}.json").exists()]
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_one, names=names), todo):
            with atomic_path(args.output / f"{result['uci_id']}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["name"], flush=True)
    print(f"{len(todo)} datasets")
    return 0


def x_main__mutmut_84(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--curated", type=Path, default=registry / "uci_curated.json")
    parser.add_argument("--pool", type=Path, default=registry / "uci_pool.json")
    parser.add_argument("--data", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", type=int, nargs="*", help="UCI ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help=None
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the registry sweep with drift, or the neural detectors",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.curated, args.pool, args.data)
        if not args.only or j[0]["uci_id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{j[0]['uci_id']}.json").exists()]
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_one, names=names), todo):
            with atomic_path(args.output / f"{result['uci_id']}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["name"], flush=True)
    print(f"{len(todo)} datasets")
    return 0


def x_main__mutmut_85(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--curated", type=Path, default=registry / "uci_curated.json")
    parser.add_argument("--pool", type=Path, default=registry / "uci_pool.json")
    parser.add_argument("--data", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", type=int, nargs="*", help="UCI ids, for a quick check")
    parser.add_argument(
        action="store_true", help="skip the datasets whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the registry sweep with drift, or the neural detectors",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.curated, args.pool, args.data)
        if not args.only or j[0]["uci_id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{j[0]['uci_id']}.json").exists()]
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_one, names=names), todo):
            with atomic_path(args.output / f"{result['uci_id']}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["name"], flush=True)
    print(f"{len(todo)} datasets")
    return 0


def x_main__mutmut_86(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--curated", type=Path, default=registry / "uci_curated.json")
    parser.add_argument("--pool", type=Path, default=registry / "uci_pool.json")
    parser.add_argument("--data", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", type=int, nargs="*", help="UCI ids, for a quick check")
    parser.add_argument(
        "--resume", help="skip the datasets whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the registry sweep with drift, or the neural detectors",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.curated, args.pool, args.data)
        if not args.only or j[0]["uci_id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{j[0]['uci_id']}.json").exists()]
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_one, names=names), todo):
            with atomic_path(args.output / f"{result['uci_id']}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["name"], flush=True)
    print(f"{len(todo)} datasets")
    return 0


def x_main__mutmut_87(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--curated", type=Path, default=registry / "uci_curated.json")
    parser.add_argument("--pool", type=Path, default=registry / "uci_pool.json")
    parser.add_argument("--data", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", type=int, nargs="*", help="UCI ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the registry sweep with drift, or the neural detectors",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.curated, args.pool, args.data)
        if not args.only or j[0]["uci_id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{j[0]['uci_id']}.json").exists()]
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_one, names=names), todo):
            with atomic_path(args.output / f"{result['uci_id']}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["name"], flush=True)
    print(f"{len(todo)} datasets")
    return 0


def x_main__mutmut_88(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--curated", type=Path, default=registry / "uci_curated.json")
    parser.add_argument("--pool", type=Path, default=registry / "uci_pool.json")
    parser.add_argument("--data", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", type=int, nargs="*", help="UCI ids, for a quick check")
    parser.add_argument(
        "XX--resumeXX", action="store_true", help="skip the datasets whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the registry sweep with drift, or the neural detectors",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.curated, args.pool, args.data)
        if not args.only or j[0]["uci_id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{j[0]['uci_id']}.json").exists()]
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_one, names=names), todo):
            with atomic_path(args.output / f"{result['uci_id']}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["name"], flush=True)
    print(f"{len(todo)} datasets")
    return 0


def x_main__mutmut_89(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--curated", type=Path, default=registry / "uci_curated.json")
    parser.add_argument("--pool", type=Path, default=registry / "uci_pool.json")
    parser.add_argument("--data", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", type=int, nargs="*", help="UCI ids, for a quick check")
    parser.add_argument(
        "--RESUME", action="store_true", help="skip the datasets whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the registry sweep with drift, or the neural detectors",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.curated, args.pool, args.data)
        if not args.only or j[0]["uci_id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{j[0]['uci_id']}.json").exists()]
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_one, names=names), todo):
            with atomic_path(args.output / f"{result['uci_id']}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["name"], flush=True)
    print(f"{len(todo)} datasets")
    return 0


def x_main__mutmut_90(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--curated", type=Path, default=registry / "uci_curated.json")
    parser.add_argument("--pool", type=Path, default=registry / "uci_pool.json")
    parser.add_argument("--data", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", type=int, nargs="*", help="UCI ids, for a quick check")
    parser.add_argument(
        "--resume", action="XXstore_trueXX", help="skip the datasets whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the registry sweep with drift, or the neural detectors",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.curated, args.pool, args.data)
        if not args.only or j[0]["uci_id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{j[0]['uci_id']}.json").exists()]
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_one, names=names), todo):
            with atomic_path(args.output / f"{result['uci_id']}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["name"], flush=True)
    print(f"{len(todo)} datasets")
    return 0


def x_main__mutmut_91(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--curated", type=Path, default=registry / "uci_curated.json")
    parser.add_argument("--pool", type=Path, default=registry / "uci_pool.json")
    parser.add_argument("--data", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", type=int, nargs="*", help="UCI ids, for a quick check")
    parser.add_argument(
        "--resume", action="STORE_TRUE", help="skip the datasets whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the registry sweep with drift, or the neural detectors",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.curated, args.pool, args.data)
        if not args.only or j[0]["uci_id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{j[0]['uci_id']}.json").exists()]
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_one, names=names), todo):
            with atomic_path(args.output / f"{result['uci_id']}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["name"], flush=True)
    print(f"{len(todo)} datasets")
    return 0


def x_main__mutmut_92(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--curated", type=Path, default=registry / "uci_curated.json")
    parser.add_argument("--pool", type=Path, default=registry / "uci_pool.json")
    parser.add_argument("--data", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", type=int, nargs="*", help="UCI ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="XXskip the datasets whose result is already writtenXX"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the registry sweep with drift, or the neural detectors",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.curated, args.pool, args.data)
        if not args.only or j[0]["uci_id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{j[0]['uci_id']}.json").exists()]
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_one, names=names), todo):
            with atomic_path(args.output / f"{result['uci_id']}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["name"], flush=True)
    print(f"{len(todo)} datasets")
    return 0


def x_main__mutmut_93(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--curated", type=Path, default=registry / "uci_curated.json")
    parser.add_argument("--pool", type=Path, default=registry / "uci_pool.json")
    parser.add_argument("--data", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", type=int, nargs="*", help="UCI ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="SKIP THE DATASETS WHOSE RESULT IS ALREADY WRITTEN"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the registry sweep with drift, or the neural detectors",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.curated, args.pool, args.data)
        if not args.only or j[0]["uci_id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{j[0]['uci_id']}.json").exists()]
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_one, names=names), todo):
            with atomic_path(args.output / f"{result['uci_id']}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["name"], flush=True)
    print(f"{len(todo)} datasets")
    return 0


def x_main__mutmut_94(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--curated", type=Path, default=registry / "uci_curated.json")
    parser.add_argument("--pool", type=Path, default=registry / "uci_pool.json")
    parser.add_argument("--data", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", type=int, nargs="*", help="UCI ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the datasets whose result is already written"
    )
    parser.add_argument(
        None,
        choices=("classical", "deep"),
        default="classical",
        help="the registry sweep with drift, or the neural detectors",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.curated, args.pool, args.data)
        if not args.only or j[0]["uci_id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{j[0]['uci_id']}.json").exists()]
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_one, names=names), todo):
            with atomic_path(args.output / f"{result['uci_id']}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["name"], flush=True)
    print(f"{len(todo)} datasets")
    return 0


def x_main__mutmut_95(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--curated", type=Path, default=registry / "uci_curated.json")
    parser.add_argument("--pool", type=Path, default=registry / "uci_pool.json")
    parser.add_argument("--data", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", type=int, nargs="*", help="UCI ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the datasets whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=None,
        default="classical",
        help="the registry sweep with drift, or the neural detectors",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.curated, args.pool, args.data)
        if not args.only or j[0]["uci_id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{j[0]['uci_id']}.json").exists()]
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_one, names=names), todo):
            with atomic_path(args.output / f"{result['uci_id']}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["name"], flush=True)
    print(f"{len(todo)} datasets")
    return 0


def x_main__mutmut_96(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--curated", type=Path, default=registry / "uci_curated.json")
    parser.add_argument("--pool", type=Path, default=registry / "uci_pool.json")
    parser.add_argument("--data", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", type=int, nargs="*", help="UCI ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the datasets whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default=None,
        help="the registry sweep with drift, or the neural detectors",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.curated, args.pool, args.data)
        if not args.only or j[0]["uci_id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{j[0]['uci_id']}.json").exists()]
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_one, names=names), todo):
            with atomic_path(args.output / f"{result['uci_id']}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["name"], flush=True)
    print(f"{len(todo)} datasets")
    return 0


def x_main__mutmut_97(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--curated", type=Path, default=registry / "uci_curated.json")
    parser.add_argument("--pool", type=Path, default=registry / "uci_pool.json")
    parser.add_argument("--data", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", type=int, nargs="*", help="UCI ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the datasets whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help=None,
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.curated, args.pool, args.data)
        if not args.only or j[0]["uci_id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{j[0]['uci_id']}.json").exists()]
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_one, names=names), todo):
            with atomic_path(args.output / f"{result['uci_id']}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["name"], flush=True)
    print(f"{len(todo)} datasets")
    return 0


def x_main__mutmut_98(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--curated", type=Path, default=registry / "uci_curated.json")
    parser.add_argument("--pool", type=Path, default=registry / "uci_pool.json")
    parser.add_argument("--data", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", type=int, nargs="*", help="UCI ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the datasets whose result is already written"
    )
    parser.add_argument(
        choices=("classical", "deep"),
        default="classical",
        help="the registry sweep with drift, or the neural detectors",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.curated, args.pool, args.data)
        if not args.only or j[0]["uci_id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{j[0]['uci_id']}.json").exists()]
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_one, names=names), todo):
            with atomic_path(args.output / f"{result['uci_id']}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["name"], flush=True)
    print(f"{len(todo)} datasets")
    return 0


def x_main__mutmut_99(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--curated", type=Path, default=registry / "uci_curated.json")
    parser.add_argument("--pool", type=Path, default=registry / "uci_pool.json")
    parser.add_argument("--data", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", type=int, nargs="*", help="UCI ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the datasets whose result is already written"
    )
    parser.add_argument(
        "--methods",
        default="classical",
        help="the registry sweep with drift, or the neural detectors",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.curated, args.pool, args.data)
        if not args.only or j[0]["uci_id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{j[0]['uci_id']}.json").exists()]
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_one, names=names), todo):
            with atomic_path(args.output / f"{result['uci_id']}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["name"], flush=True)
    print(f"{len(todo)} datasets")
    return 0


def x_main__mutmut_100(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--curated", type=Path, default=registry / "uci_curated.json")
    parser.add_argument("--pool", type=Path, default=registry / "uci_pool.json")
    parser.add_argument("--data", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", type=int, nargs="*", help="UCI ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the datasets whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        help="the registry sweep with drift, or the neural detectors",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.curated, args.pool, args.data)
        if not args.only or j[0]["uci_id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{j[0]['uci_id']}.json").exists()]
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_one, names=names), todo):
            with atomic_path(args.output / f"{result['uci_id']}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["name"], flush=True)
    print(f"{len(todo)} datasets")
    return 0


def x_main__mutmut_101(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--curated", type=Path, default=registry / "uci_curated.json")
    parser.add_argument("--pool", type=Path, default=registry / "uci_pool.json")
    parser.add_argument("--data", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", type=int, nargs="*", help="UCI ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the datasets whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.curated, args.pool, args.data)
        if not args.only or j[0]["uci_id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{j[0]['uci_id']}.json").exists()]
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_one, names=names), todo):
            with atomic_path(args.output / f"{result['uci_id']}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["name"], flush=True)
    print(f"{len(todo)} datasets")
    return 0


def x_main__mutmut_102(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--curated", type=Path, default=registry / "uci_curated.json")
    parser.add_argument("--pool", type=Path, default=registry / "uci_pool.json")
    parser.add_argument("--data", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", type=int, nargs="*", help="UCI ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the datasets whose result is already written"
    )
    parser.add_argument(
        "XX--methodsXX",
        choices=("classical", "deep"),
        default="classical",
        help="the registry sweep with drift, or the neural detectors",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.curated, args.pool, args.data)
        if not args.only or j[0]["uci_id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{j[0]['uci_id']}.json").exists()]
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_one, names=names), todo):
            with atomic_path(args.output / f"{result['uci_id']}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["name"], flush=True)
    print(f"{len(todo)} datasets")
    return 0


def x_main__mutmut_103(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--curated", type=Path, default=registry / "uci_curated.json")
    parser.add_argument("--pool", type=Path, default=registry / "uci_pool.json")
    parser.add_argument("--data", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", type=int, nargs="*", help="UCI ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the datasets whose result is already written"
    )
    parser.add_argument(
        "--METHODS",
        choices=("classical", "deep"),
        default="classical",
        help="the registry sweep with drift, or the neural detectors",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.curated, args.pool, args.data)
        if not args.only or j[0]["uci_id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{j[0]['uci_id']}.json").exists()]
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_one, names=names), todo):
            with atomic_path(args.output / f"{result['uci_id']}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["name"], flush=True)
    print(f"{len(todo)} datasets")
    return 0


def x_main__mutmut_104(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--curated", type=Path, default=registry / "uci_curated.json")
    parser.add_argument("--pool", type=Path, default=registry / "uci_pool.json")
    parser.add_argument("--data", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", type=int, nargs="*", help="UCI ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the datasets whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("XXclassicalXX", "deep"),
        default="classical",
        help="the registry sweep with drift, or the neural detectors",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.curated, args.pool, args.data)
        if not args.only or j[0]["uci_id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{j[0]['uci_id']}.json").exists()]
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_one, names=names), todo):
            with atomic_path(args.output / f"{result['uci_id']}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["name"], flush=True)
    print(f"{len(todo)} datasets")
    return 0


def x_main__mutmut_105(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--curated", type=Path, default=registry / "uci_curated.json")
    parser.add_argument("--pool", type=Path, default=registry / "uci_pool.json")
    parser.add_argument("--data", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", type=int, nargs="*", help="UCI ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the datasets whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("CLASSICAL", "deep"),
        default="classical",
        help="the registry sweep with drift, or the neural detectors",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.curated, args.pool, args.data)
        if not args.only or j[0]["uci_id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{j[0]['uci_id']}.json").exists()]
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_one, names=names), todo):
            with atomic_path(args.output / f"{result['uci_id']}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["name"], flush=True)
    print(f"{len(todo)} datasets")
    return 0


def x_main__mutmut_106(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--curated", type=Path, default=registry / "uci_curated.json")
    parser.add_argument("--pool", type=Path, default=registry / "uci_pool.json")
    parser.add_argument("--data", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", type=int, nargs="*", help="UCI ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the datasets whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "XXdeepXX"),
        default="classical",
        help="the registry sweep with drift, or the neural detectors",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.curated, args.pool, args.data)
        if not args.only or j[0]["uci_id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{j[0]['uci_id']}.json").exists()]
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_one, names=names), todo):
            with atomic_path(args.output / f"{result['uci_id']}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["name"], flush=True)
    print(f"{len(todo)} datasets")
    return 0


def x_main__mutmut_107(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--curated", type=Path, default=registry / "uci_curated.json")
    parser.add_argument("--pool", type=Path, default=registry / "uci_pool.json")
    parser.add_argument("--data", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", type=int, nargs="*", help="UCI ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the datasets whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "DEEP"),
        default="classical",
        help="the registry sweep with drift, or the neural detectors",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.curated, args.pool, args.data)
        if not args.only or j[0]["uci_id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{j[0]['uci_id']}.json").exists()]
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_one, names=names), todo):
            with atomic_path(args.output / f"{result['uci_id']}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["name"], flush=True)
    print(f"{len(todo)} datasets")
    return 0


def x_main__mutmut_108(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--curated", type=Path, default=registry / "uci_curated.json")
    parser.add_argument("--pool", type=Path, default=registry / "uci_pool.json")
    parser.add_argument("--data", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", type=int, nargs="*", help="UCI ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the datasets whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="XXclassicalXX",
        help="the registry sweep with drift, or the neural detectors",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.curated, args.pool, args.data)
        if not args.only or j[0]["uci_id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{j[0]['uci_id']}.json").exists()]
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_one, names=names), todo):
            with atomic_path(args.output / f"{result['uci_id']}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["name"], flush=True)
    print(f"{len(todo)} datasets")
    return 0


def x_main__mutmut_109(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--curated", type=Path, default=registry / "uci_curated.json")
    parser.add_argument("--pool", type=Path, default=registry / "uci_pool.json")
    parser.add_argument("--data", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", type=int, nargs="*", help="UCI ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the datasets whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="CLASSICAL",
        help="the registry sweep with drift, or the neural detectors",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.curated, args.pool, args.data)
        if not args.only or j[0]["uci_id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{j[0]['uci_id']}.json").exists()]
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_one, names=names), todo):
            with atomic_path(args.output / f"{result['uci_id']}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["name"], flush=True)
    print(f"{len(todo)} datasets")
    return 0


def x_main__mutmut_110(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--curated", type=Path, default=registry / "uci_curated.json")
    parser.add_argument("--pool", type=Path, default=registry / "uci_pool.json")
    parser.add_argument("--data", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", type=int, nargs="*", help="UCI ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the datasets whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="XXthe registry sweep with drift, or the neural detectorsXX",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.curated, args.pool, args.data)
        if not args.only or j[0]["uci_id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{j[0]['uci_id']}.json").exists()]
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_one, names=names), todo):
            with atomic_path(args.output / f"{result['uci_id']}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["name"], flush=True)
    print(f"{len(todo)} datasets")
    return 0


def x_main__mutmut_111(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--curated", type=Path, default=registry / "uci_curated.json")
    parser.add_argument("--pool", type=Path, default=registry / "uci_pool.json")
    parser.add_argument("--data", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", type=int, nargs="*", help="UCI ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the datasets whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="THE REGISTRY SWEEP WITH DRIFT, OR THE NEURAL DETECTORS",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.curated, args.pool, args.data)
        if not args.only or j[0]["uci_id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{j[0]['uci_id']}.json").exists()]
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_one, names=names), todo):
            with atomic_path(args.output / f"{result['uci_id']}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["name"], flush=True)
    print(f"{len(todo)} datasets")
    return 0


def x_main__mutmut_112(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--curated", type=Path, default=registry / "uci_curated.json")
    parser.add_argument("--pool", type=Path, default=registry / "uci_pool.json")
    parser.add_argument("--data", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", type=int, nargs="*", help="UCI ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the datasets whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the registry sweep with drift, or the neural detectors",
    )
    args = None
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.curated, args.pool, args.data)
        if not args.only or j[0]["uci_id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{j[0]['uci_id']}.json").exists()]
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_one, names=names), todo):
            with atomic_path(args.output / f"{result['uci_id']}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["name"], flush=True)
    print(f"{len(todo)} datasets")
    return 0


def x_main__mutmut_113(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--curated", type=Path, default=registry / "uci_curated.json")
    parser.add_argument("--pool", type=Path, default=registry / "uci_pool.json")
    parser.add_argument("--data", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", type=int, nargs="*", help="UCI ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the datasets whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the registry sweep with drift, or the neural detectors",
    )
    args = parser.parse_args(None)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.curated, args.pool, args.data)
        if not args.only or j[0]["uci_id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{j[0]['uci_id']}.json").exists()]
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_one, names=names), todo):
            with atomic_path(args.output / f"{result['uci_id']}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["name"], flush=True)
    print(f"{len(todo)} datasets")
    return 0


def x_main__mutmut_114(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--curated", type=Path, default=registry / "uci_curated.json")
    parser.add_argument("--pool", type=Path, default=registry / "uci_pool.json")
    parser.add_argument("--data", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", type=int, nargs="*", help="UCI ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the datasets whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the registry sweep with drift, or the neural detectors",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = None
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{j[0]['uci_id']}.json").exists()]
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_one, names=names), todo):
            with atomic_path(args.output / f"{result['uci_id']}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["name"], flush=True)
    print(f"{len(todo)} datasets")
    return 0


def x_main__mutmut_115(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--curated", type=Path, default=registry / "uci_curated.json")
    parser.add_argument("--pool", type=Path, default=registry / "uci_pool.json")
    parser.add_argument("--data", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", type=int, nargs="*", help="UCI ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the datasets whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the registry sweep with drift, or the neural detectors",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(None, args.pool, args.data)
        if not args.only or j[0]["uci_id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{j[0]['uci_id']}.json").exists()]
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_one, names=names), todo):
            with atomic_path(args.output / f"{result['uci_id']}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["name"], flush=True)
    print(f"{len(todo)} datasets")
    return 0


def x_main__mutmut_116(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--curated", type=Path, default=registry / "uci_curated.json")
    parser.add_argument("--pool", type=Path, default=registry / "uci_pool.json")
    parser.add_argument("--data", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", type=int, nargs="*", help="UCI ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the datasets whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the registry sweep with drift, or the neural detectors",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.curated, None, args.data)
        if not args.only or j[0]["uci_id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{j[0]['uci_id']}.json").exists()]
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_one, names=names), todo):
            with atomic_path(args.output / f"{result['uci_id']}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["name"], flush=True)
    print(f"{len(todo)} datasets")
    return 0


def x_main__mutmut_117(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--curated", type=Path, default=registry / "uci_curated.json")
    parser.add_argument("--pool", type=Path, default=registry / "uci_pool.json")
    parser.add_argument("--data", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", type=int, nargs="*", help="UCI ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the datasets whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the registry sweep with drift, or the neural detectors",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.curated, args.pool, None)
        if not args.only or j[0]["uci_id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{j[0]['uci_id']}.json").exists()]
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_one, names=names), todo):
            with atomic_path(args.output / f"{result['uci_id']}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["name"], flush=True)
    print(f"{len(todo)} datasets")
    return 0


def x_main__mutmut_118(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--curated", type=Path, default=registry / "uci_curated.json")
    parser.add_argument("--pool", type=Path, default=registry / "uci_pool.json")
    parser.add_argument("--data", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", type=int, nargs="*", help="UCI ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the datasets whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the registry sweep with drift, or the neural detectors",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.pool, args.data)
        if not args.only or j[0]["uci_id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{j[0]['uci_id']}.json").exists()]
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_one, names=names), todo):
            with atomic_path(args.output / f"{result['uci_id']}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["name"], flush=True)
    print(f"{len(todo)} datasets")
    return 0


def x_main__mutmut_119(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--curated", type=Path, default=registry / "uci_curated.json")
    parser.add_argument("--pool", type=Path, default=registry / "uci_pool.json")
    parser.add_argument("--data", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", type=int, nargs="*", help="UCI ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the datasets whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the registry sweep with drift, or the neural detectors",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.curated, args.data)
        if not args.only or j[0]["uci_id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{j[0]['uci_id']}.json").exists()]
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_one, names=names), todo):
            with atomic_path(args.output / f"{result['uci_id']}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["name"], flush=True)
    print(f"{len(todo)} datasets")
    return 0


def x_main__mutmut_120(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--curated", type=Path, default=registry / "uci_curated.json")
    parser.add_argument("--pool", type=Path, default=registry / "uci_pool.json")
    parser.add_argument("--data", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", type=int, nargs="*", help="UCI ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the datasets whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the registry sweep with drift, or the neural detectors",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.curated, args.pool, )
        if not args.only or j[0]["uci_id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{j[0]['uci_id']}.json").exists()]
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_one, names=names), todo):
            with atomic_path(args.output / f"{result['uci_id']}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["name"], flush=True)
    print(f"{len(todo)} datasets")
    return 0


def x_main__mutmut_121(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--curated", type=Path, default=registry / "uci_curated.json")
    parser.add_argument("--pool", type=Path, default=registry / "uci_pool.json")
    parser.add_argument("--data", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", type=int, nargs="*", help="UCI ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the datasets whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the registry sweep with drift, or the neural detectors",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.curated, args.pool, args.data)
        if not args.only and j[0]["uci_id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{j[0]['uci_id']}.json").exists()]
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_one, names=names), todo):
            with atomic_path(args.output / f"{result['uci_id']}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["name"], flush=True)
    print(f"{len(todo)} datasets")
    return 0


def x_main__mutmut_122(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--curated", type=Path, default=registry / "uci_curated.json")
    parser.add_argument("--pool", type=Path, default=registry / "uci_pool.json")
    parser.add_argument("--data", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", type=int, nargs="*", help="UCI ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the datasets whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the registry sweep with drift, or the neural detectors",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.curated, args.pool, args.data)
        if args.only or j[0]["uci_id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{j[0]['uci_id']}.json").exists()]
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_one, names=names), todo):
            with atomic_path(args.output / f"{result['uci_id']}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["name"], flush=True)
    print(f"{len(todo)} datasets")
    return 0


def x_main__mutmut_123(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--curated", type=Path, default=registry / "uci_curated.json")
    parser.add_argument("--pool", type=Path, default=registry / "uci_pool.json")
    parser.add_argument("--data", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", type=int, nargs="*", help="UCI ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the datasets whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the registry sweep with drift, or the neural detectors",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.curated, args.pool, args.data)
        if not args.only or j[1]["uci_id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{j[0]['uci_id']}.json").exists()]
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_one, names=names), todo):
            with atomic_path(args.output / f"{result['uci_id']}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["name"], flush=True)
    print(f"{len(todo)} datasets")
    return 0


def x_main__mutmut_124(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--curated", type=Path, default=registry / "uci_curated.json")
    parser.add_argument("--pool", type=Path, default=registry / "uci_pool.json")
    parser.add_argument("--data", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", type=int, nargs="*", help="UCI ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the datasets whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the registry sweep with drift, or the neural detectors",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.curated, args.pool, args.data)
        if not args.only or j[0]["XXuci_idXX"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{j[0]['uci_id']}.json").exists()]
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_one, names=names), todo):
            with atomic_path(args.output / f"{result['uci_id']}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["name"], flush=True)
    print(f"{len(todo)} datasets")
    return 0


def x_main__mutmut_125(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--curated", type=Path, default=registry / "uci_curated.json")
    parser.add_argument("--pool", type=Path, default=registry / "uci_pool.json")
    parser.add_argument("--data", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", type=int, nargs="*", help="UCI ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the datasets whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the registry sweep with drift, or the neural detectors",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.curated, args.pool, args.data)
        if not args.only or j[0]["UCI_ID"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{j[0]['uci_id']}.json").exists()]
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_one, names=names), todo):
            with atomic_path(args.output / f"{result['uci_id']}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["name"], flush=True)
    print(f"{len(todo)} datasets")
    return 0


def x_main__mutmut_126(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--curated", type=Path, default=registry / "uci_curated.json")
    parser.add_argument("--pool", type=Path, default=registry / "uci_pool.json")
    parser.add_argument("--data", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", type=int, nargs="*", help="UCI ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the datasets whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the registry sweep with drift, or the neural detectors",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.curated, args.pool, args.data)
        if not args.only or j[0]["uci_id"] not in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{j[0]['uci_id']}.json").exists()]
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_one, names=names), todo):
            with atomic_path(args.output / f"{result['uci_id']}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["name"], flush=True)
    print(f"{len(todo)} datasets")
    return 0


def x_main__mutmut_127(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--curated", type=Path, default=registry / "uci_curated.json")
    parser.add_argument("--pool", type=Path, default=registry / "uci_pool.json")
    parser.add_argument("--data", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", type=int, nargs="*", help="UCI ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the datasets whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the registry sweep with drift, or the neural detectors",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.curated, args.pool, args.data)
        if not args.only or j[0]["uci_id"] in args.only
    ]
    args.output.mkdir(parents=None, exist_ok=True)
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{j[0]['uci_id']}.json").exists()]
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_one, names=names), todo):
            with atomic_path(args.output / f"{result['uci_id']}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["name"], flush=True)
    print(f"{len(todo)} datasets")
    return 0


def x_main__mutmut_128(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--curated", type=Path, default=registry / "uci_curated.json")
    parser.add_argument("--pool", type=Path, default=registry / "uci_pool.json")
    parser.add_argument("--data", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", type=int, nargs="*", help="UCI ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the datasets whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the registry sweep with drift, or the neural detectors",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.curated, args.pool, args.data)
        if not args.only or j[0]["uci_id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=None)
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{j[0]['uci_id']}.json").exists()]
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_one, names=names), todo):
            with atomic_path(args.output / f"{result['uci_id']}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["name"], flush=True)
    print(f"{len(todo)} datasets")
    return 0


def x_main__mutmut_129(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--curated", type=Path, default=registry / "uci_curated.json")
    parser.add_argument("--pool", type=Path, default=registry / "uci_pool.json")
    parser.add_argument("--data", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", type=int, nargs="*", help="UCI ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the datasets whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the registry sweep with drift, or the neural detectors",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.curated, args.pool, args.data)
        if not args.only or j[0]["uci_id"] in args.only
    ]
    args.output.mkdir(exist_ok=True)
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{j[0]['uci_id']}.json").exists()]
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_one, names=names), todo):
            with atomic_path(args.output / f"{result['uci_id']}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["name"], flush=True)
    print(f"{len(todo)} datasets")
    return 0


def x_main__mutmut_130(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--curated", type=Path, default=registry / "uci_curated.json")
    parser.add_argument("--pool", type=Path, default=registry / "uci_pool.json")
    parser.add_argument("--data", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", type=int, nargs="*", help="UCI ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the datasets whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the registry sweep with drift, or the neural detectors",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.curated, args.pool, args.data)
        if not args.only or j[0]["uci_id"] in args.only
    ]
    args.output.mkdir(parents=True, )
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{j[0]['uci_id']}.json").exists()]
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_one, names=names), todo):
            with atomic_path(args.output / f"{result['uci_id']}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["name"], flush=True)
    print(f"{len(todo)} datasets")
    return 0


def x_main__mutmut_131(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--curated", type=Path, default=registry / "uci_curated.json")
    parser.add_argument("--pool", type=Path, default=registry / "uci_pool.json")
    parser.add_argument("--data", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", type=int, nargs="*", help="UCI ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the datasets whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the registry sweep with drift, or the neural detectors",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.curated, args.pool, args.data)
        if not args.only or j[0]["uci_id"] in args.only
    ]
    args.output.mkdir(parents=False, exist_ok=True)
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{j[0]['uci_id']}.json").exists()]
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_one, names=names), todo):
            with atomic_path(args.output / f"{result['uci_id']}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["name"], flush=True)
    print(f"{len(todo)} datasets")
    return 0


def x_main__mutmut_132(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--curated", type=Path, default=registry / "uci_curated.json")
    parser.add_argument("--pool", type=Path, default=registry / "uci_pool.json")
    parser.add_argument("--data", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", type=int, nargs="*", help="UCI ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the datasets whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the registry sweep with drift, or the neural detectors",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.curated, args.pool, args.data)
        if not args.only or j[0]["uci_id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=False)
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{j[0]['uci_id']}.json").exists()]
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_one, names=names), todo):
            with atomic_path(args.output / f"{result['uci_id']}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["name"], flush=True)
    print(f"{len(todo)} datasets")
    return 0


def x_main__mutmut_133(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--curated", type=Path, default=registry / "uci_curated.json")
    parser.add_argument("--pool", type=Path, default=registry / "uci_pool.json")
    parser.add_argument("--data", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", type=int, nargs="*", help="UCI ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the datasets whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the registry sweep with drift, or the neural detectors",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.curated, args.pool, args.data)
        if not args.only or j[0]["uci_id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = None
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_one, names=names), todo):
            with atomic_path(args.output / f"{result['uci_id']}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["name"], flush=True)
    print(f"{len(todo)} datasets")
    return 0


def x_main__mutmut_134(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--curated", type=Path, default=registry / "uci_curated.json")
    parser.add_argument("--pool", type=Path, default=registry / "uci_pool.json")
    parser.add_argument("--data", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", type=int, nargs="*", help="UCI ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the datasets whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the registry sweep with drift, or the neural detectors",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.curated, args.pool, args.data)
        if not args.only or j[0]["uci_id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [j for j in todo if (args.output / f"{j[0]['uci_id']}.json").exists()]
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_one, names=names), todo):
            with atomic_path(args.output / f"{result['uci_id']}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["name"], flush=True)
    print(f"{len(todo)} datasets")
    return 0


def x_main__mutmut_135(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--curated", type=Path, default=registry / "uci_curated.json")
    parser.add_argument("--pool", type=Path, default=registry / "uci_pool.json")
    parser.add_argument("--data", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", type=int, nargs="*", help="UCI ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the datasets whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the registry sweep with drift, or the neural detectors",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.curated, args.pool, args.data)
        if not args.only or j[0]["uci_id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [j for j in todo if not (args.output * f"{j[0]['uci_id']}.json").exists()]
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_one, names=names), todo):
            with atomic_path(args.output / f"{result['uci_id']}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["name"], flush=True)
    print(f"{len(todo)} datasets")
    return 0


def x_main__mutmut_136(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--curated", type=Path, default=registry / "uci_curated.json")
    parser.add_argument("--pool", type=Path, default=registry / "uci_pool.json")
    parser.add_argument("--data", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", type=int, nargs="*", help="UCI ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the datasets whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the registry sweep with drift, or the neural detectors",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.curated, args.pool, args.data)
        if not args.only or j[0]["uci_id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{j[1]['uci_id']}.json").exists()]
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_one, names=names), todo):
            with atomic_path(args.output / f"{result['uci_id']}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["name"], flush=True)
    print(f"{len(todo)} datasets")
    return 0


def x_main__mutmut_137(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--curated", type=Path, default=registry / "uci_curated.json")
    parser.add_argument("--pool", type=Path, default=registry / "uci_pool.json")
    parser.add_argument("--data", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", type=int, nargs="*", help="UCI ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the datasets whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the registry sweep with drift, or the neural detectors",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.curated, args.pool, args.data)
        if not args.only or j[0]["uci_id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{j[0]['XXuci_idXX']}.json").exists()]
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_one, names=names), todo):
            with atomic_path(args.output / f"{result['uci_id']}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["name"], flush=True)
    print(f"{len(todo)} datasets")
    return 0


def x_main__mutmut_138(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--curated", type=Path, default=registry / "uci_curated.json")
    parser.add_argument("--pool", type=Path, default=registry / "uci_pool.json")
    parser.add_argument("--data", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", type=int, nargs="*", help="UCI ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the datasets whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the registry sweep with drift, or the neural detectors",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.curated, args.pool, args.data)
        if not args.only or j[0]["uci_id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{j[0]['UCI_ID']}.json").exists()]
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_one, names=names), todo):
            with atomic_path(args.output / f"{result['uci_id']}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["name"], flush=True)
    print(f"{len(todo)} datasets")
    return 0


def x_main__mutmut_139(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--curated", type=Path, default=registry / "uci_curated.json")
    parser.add_argument("--pool", type=Path, default=registry / "uci_pool.json")
    parser.add_argument("--data", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", type=int, nargs="*", help="UCI ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the datasets whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the registry sweep with drift, or the neural detectors",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.curated, args.pool, args.data)
        if not args.only or j[0]["uci_id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{j[0]['uci_id']}.json").exists()]
    names = None
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_one, names=names), todo):
            with atomic_path(args.output / f"{result['uci_id']}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["name"], flush=True)
    print(f"{len(todo)} datasets")
    return 0


def x_main__mutmut_140(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--curated", type=Path, default=registry / "uci_curated.json")
    parser.add_argument("--pool", type=Path, default=registry / "uci_pool.json")
    parser.add_argument("--data", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", type=int, nargs="*", help="UCI ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the datasets whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the registry sweep with drift, or the neural detectors",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.curated, args.pool, args.data)
        if not args.only or j[0]["uci_id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{j[0]['uci_id']}.json").exists()]
    names = list(DEEP_NAMES) if (args.methods == "deep") and False else None
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_one, names=names), todo):
            with atomic_path(args.output / f"{result['uci_id']}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["name"], flush=True)
    print(f"{len(todo)} datasets")
    return 0


def x_main__mutmut_141(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--curated", type=Path, default=registry / "uci_curated.json")
    parser.add_argument("--pool", type=Path, default=registry / "uci_pool.json")
    parser.add_argument("--data", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", type=int, nargs="*", help="UCI ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the datasets whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the registry sweep with drift, or the neural detectors",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.curated, args.pool, args.data)
        if not args.only or j[0]["uci_id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{j[0]['uci_id']}.json").exists()]
    names = list(DEEP_NAMES) if (args.methods == "deep") or True else None
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_one, names=names), todo):
            with atomic_path(args.output / f"{result['uci_id']}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["name"], flush=True)
    print(f"{len(todo)} datasets")
    return 0


def x_main__mutmut_142(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--curated", type=Path, default=registry / "uci_curated.json")
    parser.add_argument("--pool", type=Path, default=registry / "uci_pool.json")
    parser.add_argument("--data", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", type=int, nargs="*", help="UCI ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the datasets whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the registry sweep with drift, or the neural detectors",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.curated, args.pool, args.data)
        if not args.only or j[0]["uci_id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{j[0]['uci_id']}.json").exists()]
    names = list(None) if args.methods == "deep" else None
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_one, names=names), todo):
            with atomic_path(args.output / f"{result['uci_id']}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["name"], flush=True)
    print(f"{len(todo)} datasets")
    return 0


def x_main__mutmut_143(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--curated", type=Path, default=registry / "uci_curated.json")
    parser.add_argument("--pool", type=Path, default=registry / "uci_pool.json")
    parser.add_argument("--data", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", type=int, nargs="*", help="UCI ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the datasets whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the registry sweep with drift, or the neural detectors",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.curated, args.pool, args.data)
        if not args.only or j[0]["uci_id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{j[0]['uci_id']}.json").exists()]
    names = list(DEEP_NAMES) if args.methods != "deep" else None
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_one, names=names), todo):
            with atomic_path(args.output / f"{result['uci_id']}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["name"], flush=True)
    print(f"{len(todo)} datasets")
    return 0


def x_main__mutmut_144(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--curated", type=Path, default=registry / "uci_curated.json")
    parser.add_argument("--pool", type=Path, default=registry / "uci_pool.json")
    parser.add_argument("--data", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", type=int, nargs="*", help="UCI ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the datasets whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the registry sweep with drift, or the neural detectors",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.curated, args.pool, args.data)
        if not args.only or j[0]["uci_id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{j[0]['uci_id']}.json").exists()]
    names = list(DEEP_NAMES) if args.methods == "XXdeepXX" else None
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_one, names=names), todo):
            with atomic_path(args.output / f"{result['uci_id']}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["name"], flush=True)
    print(f"{len(todo)} datasets")
    return 0


def x_main__mutmut_145(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--curated", type=Path, default=registry / "uci_curated.json")
    parser.add_argument("--pool", type=Path, default=registry / "uci_pool.json")
    parser.add_argument("--data", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", type=int, nargs="*", help="UCI ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the datasets whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the registry sweep with drift, or the neural detectors",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.curated, args.pool, args.data)
        if not args.only or j[0]["uci_id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{j[0]['uci_id']}.json").exists()]
    names = list(DEEP_NAMES) if args.methods == "DEEP" else None
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_one, names=names), todo):
            with atomic_path(args.output / f"{result['uci_id']}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["name"], flush=True)
    print(f"{len(todo)} datasets")
    return 0


def x_main__mutmut_146(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--curated", type=Path, default=registry / "uci_curated.json")
    parser.add_argument("--pool", type=Path, default=registry / "uci_pool.json")
    parser.add_argument("--data", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", type=int, nargs="*", help="UCI ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the datasets whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the registry sweep with drift, or the neural detectors",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.curated, args.pool, args.data)
        if not args.only or j[0]["uci_id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{j[0]['uci_id']}.json").exists()]
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    with ProcessPoolExecutor(max_workers=None) as pool:
        for result in pool.map(bind(run_one, names=names), todo):
            with atomic_path(args.output / f"{result['uci_id']}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["name"], flush=True)
    print(f"{len(todo)} datasets")
    return 0


def x_main__mutmut_147(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--curated", type=Path, default=registry / "uci_curated.json")
    parser.add_argument("--pool", type=Path, default=registry / "uci_pool.json")
    parser.add_argument("--data", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", type=int, nargs="*", help="UCI ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the datasets whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the registry sweep with drift, or the neural detectors",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.curated, args.pool, args.data)
        if not args.only or j[0]["uci_id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{j[0]['uci_id']}.json").exists()]
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(None, todo):
            with atomic_path(args.output / f"{result['uci_id']}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["name"], flush=True)
    print(f"{len(todo)} datasets")
    return 0


def x_main__mutmut_148(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--curated", type=Path, default=registry / "uci_curated.json")
    parser.add_argument("--pool", type=Path, default=registry / "uci_pool.json")
    parser.add_argument("--data", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", type=int, nargs="*", help="UCI ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the datasets whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the registry sweep with drift, or the neural detectors",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.curated, args.pool, args.data)
        if not args.only or j[0]["uci_id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{j[0]['uci_id']}.json").exists()]
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_one, names=names), None):
            with atomic_path(args.output / f"{result['uci_id']}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["name"], flush=True)
    print(f"{len(todo)} datasets")
    return 0


def x_main__mutmut_149(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--curated", type=Path, default=registry / "uci_curated.json")
    parser.add_argument("--pool", type=Path, default=registry / "uci_pool.json")
    parser.add_argument("--data", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", type=int, nargs="*", help="UCI ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the datasets whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the registry sweep with drift, or the neural detectors",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.curated, args.pool, args.data)
        if not args.only or j[0]["uci_id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{j[0]['uci_id']}.json").exists()]
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(todo):
            with atomic_path(args.output / f"{result['uci_id']}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["name"], flush=True)
    print(f"{len(todo)} datasets")
    return 0


def x_main__mutmut_150(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--curated", type=Path, default=registry / "uci_curated.json")
    parser.add_argument("--pool", type=Path, default=registry / "uci_pool.json")
    parser.add_argument("--data", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", type=int, nargs="*", help="UCI ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the datasets whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the registry sweep with drift, or the neural detectors",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.curated, args.pool, args.data)
        if not args.only or j[0]["uci_id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{j[0]['uci_id']}.json").exists()]
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_one, names=names), ):
            with atomic_path(args.output / f"{result['uci_id']}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["name"], flush=True)
    print(f"{len(todo)} datasets")
    return 0


def x_main__mutmut_151(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--curated", type=Path, default=registry / "uci_curated.json")
    parser.add_argument("--pool", type=Path, default=registry / "uci_pool.json")
    parser.add_argument("--data", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", type=int, nargs="*", help="UCI ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the datasets whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the registry sweep with drift, or the neural detectors",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.curated, args.pool, args.data)
        if not args.only or j[0]["uci_id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{j[0]['uci_id']}.json").exists()]
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(None, names=names), todo):
            with atomic_path(args.output / f"{result['uci_id']}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["name"], flush=True)
    print(f"{len(todo)} datasets")
    return 0


def x_main__mutmut_152(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--curated", type=Path, default=registry / "uci_curated.json")
    parser.add_argument("--pool", type=Path, default=registry / "uci_pool.json")
    parser.add_argument("--data", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", type=int, nargs="*", help="UCI ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the datasets whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the registry sweep with drift, or the neural detectors",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.curated, args.pool, args.data)
        if not args.only or j[0]["uci_id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{j[0]['uci_id']}.json").exists()]
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_one, names=None), todo):
            with atomic_path(args.output / f"{result['uci_id']}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["name"], flush=True)
    print(f"{len(todo)} datasets")
    return 0


def x_main__mutmut_153(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--curated", type=Path, default=registry / "uci_curated.json")
    parser.add_argument("--pool", type=Path, default=registry / "uci_pool.json")
    parser.add_argument("--data", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", type=int, nargs="*", help="UCI ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the datasets whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the registry sweep with drift, or the neural detectors",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.curated, args.pool, args.data)
        if not args.only or j[0]["uci_id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{j[0]['uci_id']}.json").exists()]
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(names=names), todo):
            with atomic_path(args.output / f"{result['uci_id']}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["name"], flush=True)
    print(f"{len(todo)} datasets")
    return 0


def x_main__mutmut_154(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--curated", type=Path, default=registry / "uci_curated.json")
    parser.add_argument("--pool", type=Path, default=registry / "uci_pool.json")
    parser.add_argument("--data", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", type=int, nargs="*", help="UCI ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the datasets whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the registry sweep with drift, or the neural detectors",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.curated, args.pool, args.data)
        if not args.only or j[0]["uci_id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{j[0]['uci_id']}.json").exists()]
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_one, ), todo):
            with atomic_path(args.output / f"{result['uci_id']}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["name"], flush=True)
    print(f"{len(todo)} datasets")
    return 0


def x_main__mutmut_155(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--curated", type=Path, default=registry / "uci_curated.json")
    parser.add_argument("--pool", type=Path, default=registry / "uci_pool.json")
    parser.add_argument("--data", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", type=int, nargs="*", help="UCI ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the datasets whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the registry sweep with drift, or the neural detectors",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.curated, args.pool, args.data)
        if not args.only or j[0]["uci_id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{j[0]['uci_id']}.json").exists()]
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_one, names=names), todo):
            with atomic_path(None) as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["name"], flush=True)
    print(f"{len(todo)} datasets")
    return 0


def x_main__mutmut_156(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--curated", type=Path, default=registry / "uci_curated.json")
    parser.add_argument("--pool", type=Path, default=registry / "uci_pool.json")
    parser.add_argument("--data", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", type=int, nargs="*", help="UCI ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the datasets whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the registry sweep with drift, or the neural detectors",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.curated, args.pool, args.data)
        if not args.only or j[0]["uci_id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{j[0]['uci_id']}.json").exists()]
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_one, names=names), todo):
            with atomic_path(args.output * f"{result['uci_id']}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["name"], flush=True)
    print(f"{len(todo)} datasets")
    return 0


def x_main__mutmut_157(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--curated", type=Path, default=registry / "uci_curated.json")
    parser.add_argument("--pool", type=Path, default=registry / "uci_pool.json")
    parser.add_argument("--data", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", type=int, nargs="*", help="UCI ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the datasets whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the registry sweep with drift, or the neural detectors",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.curated, args.pool, args.data)
        if not args.only or j[0]["uci_id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{j[0]['uci_id']}.json").exists()]
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_one, names=names), todo):
            with atomic_path(args.output / f"{result['XXuci_idXX']}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["name"], flush=True)
    print(f"{len(todo)} datasets")
    return 0


def x_main__mutmut_158(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--curated", type=Path, default=registry / "uci_curated.json")
    parser.add_argument("--pool", type=Path, default=registry / "uci_pool.json")
    parser.add_argument("--data", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", type=int, nargs="*", help="UCI ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the datasets whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the registry sweep with drift, or the neural detectors",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.curated, args.pool, args.data)
        if not args.only or j[0]["uci_id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{j[0]['uci_id']}.json").exists()]
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_one, names=names), todo):
            with atomic_path(args.output / f"{result['UCI_ID']}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["name"], flush=True)
    print(f"{len(todo)} datasets")
    return 0


def x_main__mutmut_159(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--curated", type=Path, default=registry / "uci_curated.json")
    parser.add_argument("--pool", type=Path, default=registry / "uci_pool.json")
    parser.add_argument("--data", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", type=int, nargs="*", help="UCI ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the datasets whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the registry sweep with drift, or the neural detectors",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.curated, args.pool, args.data)
        if not args.only or j[0]["uci_id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{j[0]['uci_id']}.json").exists()]
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_one, names=names), todo):
            with atomic_path(args.output / f"{result['uci_id']}.json") as partial:
                partial.write_text(None)
            print(result["name"], flush=True)
    print(f"{len(todo)} datasets")
    return 0


def x_main__mutmut_160(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--curated", type=Path, default=registry / "uci_curated.json")
    parser.add_argument("--pool", type=Path, default=registry / "uci_pool.json")
    parser.add_argument("--data", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", type=int, nargs="*", help="UCI ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the datasets whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the registry sweep with drift, or the neural detectors",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.curated, args.pool, args.data)
        if not args.only or j[0]["uci_id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{j[0]['uci_id']}.json").exists()]
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_one, names=names), todo):
            with atomic_path(args.output / f"{result['uci_id']}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) - "\n")
            print(result["name"], flush=True)
    print(f"{len(todo)} datasets")
    return 0


def x_main__mutmut_161(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--curated", type=Path, default=registry / "uci_curated.json")
    parser.add_argument("--pool", type=Path, default=registry / "uci_pool.json")
    parser.add_argument("--data", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", type=int, nargs="*", help="UCI ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the datasets whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the registry sweep with drift, or the neural detectors",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.curated, args.pool, args.data)
        if not args.only or j[0]["uci_id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{j[0]['uci_id']}.json").exists()]
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_one, names=names), todo):
            with atomic_path(args.output / f"{result['uci_id']}.json") as partial:
                partial.write_text(json.dumps(None, indent=1, sort_keys=True) + "\n")
            print(result["name"], flush=True)
    print(f"{len(todo)} datasets")
    return 0


def x_main__mutmut_162(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--curated", type=Path, default=registry / "uci_curated.json")
    parser.add_argument("--pool", type=Path, default=registry / "uci_pool.json")
    parser.add_argument("--data", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", type=int, nargs="*", help="UCI ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the datasets whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the registry sweep with drift, or the neural detectors",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.curated, args.pool, args.data)
        if not args.only or j[0]["uci_id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{j[0]['uci_id']}.json").exists()]
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_one, names=names), todo):
            with atomic_path(args.output / f"{result['uci_id']}.json") as partial:
                partial.write_text(json.dumps(result, indent=None, sort_keys=True) + "\n")
            print(result["name"], flush=True)
    print(f"{len(todo)} datasets")
    return 0


def x_main__mutmut_163(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--curated", type=Path, default=registry / "uci_curated.json")
    parser.add_argument("--pool", type=Path, default=registry / "uci_pool.json")
    parser.add_argument("--data", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", type=int, nargs="*", help="UCI ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the datasets whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the registry sweep with drift, or the neural detectors",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.curated, args.pool, args.data)
        if not args.only or j[0]["uci_id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{j[0]['uci_id']}.json").exists()]
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_one, names=names), todo):
            with atomic_path(args.output / f"{result['uci_id']}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=None) + "\n")
            print(result["name"], flush=True)
    print(f"{len(todo)} datasets")
    return 0


def x_main__mutmut_164(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--curated", type=Path, default=registry / "uci_curated.json")
    parser.add_argument("--pool", type=Path, default=registry / "uci_pool.json")
    parser.add_argument("--data", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", type=int, nargs="*", help="UCI ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the datasets whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the registry sweep with drift, or the neural detectors",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.curated, args.pool, args.data)
        if not args.only or j[0]["uci_id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{j[0]['uci_id']}.json").exists()]
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_one, names=names), todo):
            with atomic_path(args.output / f"{result['uci_id']}.json") as partial:
                partial.write_text(json.dumps(indent=1, sort_keys=True) + "\n")
            print(result["name"], flush=True)
    print(f"{len(todo)} datasets")
    return 0


def x_main__mutmut_165(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--curated", type=Path, default=registry / "uci_curated.json")
    parser.add_argument("--pool", type=Path, default=registry / "uci_pool.json")
    parser.add_argument("--data", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", type=int, nargs="*", help="UCI ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the datasets whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the registry sweep with drift, or the neural detectors",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.curated, args.pool, args.data)
        if not args.only or j[0]["uci_id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{j[0]['uci_id']}.json").exists()]
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_one, names=names), todo):
            with atomic_path(args.output / f"{result['uci_id']}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["name"], flush=True)
    print(f"{len(todo)} datasets")
    return 0


def x_main__mutmut_166(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--curated", type=Path, default=registry / "uci_curated.json")
    parser.add_argument("--pool", type=Path, default=registry / "uci_pool.json")
    parser.add_argument("--data", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", type=int, nargs="*", help="UCI ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the datasets whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the registry sweep with drift, or the neural detectors",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.curated, args.pool, args.data)
        if not args.only or j[0]["uci_id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{j[0]['uci_id']}.json").exists()]
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_one, names=names), todo):
            with atomic_path(args.output / f"{result['uci_id']}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, ) + "\n")
            print(result["name"], flush=True)
    print(f"{len(todo)} datasets")
    return 0


def x_main__mutmut_167(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--curated", type=Path, default=registry / "uci_curated.json")
    parser.add_argument("--pool", type=Path, default=registry / "uci_pool.json")
    parser.add_argument("--data", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", type=int, nargs="*", help="UCI ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the datasets whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the registry sweep with drift, or the neural detectors",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.curated, args.pool, args.data)
        if not args.only or j[0]["uci_id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{j[0]['uci_id']}.json").exists()]
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_one, names=names), todo):
            with atomic_path(args.output / f"{result['uci_id']}.json") as partial:
                partial.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
            print(result["name"], flush=True)
    print(f"{len(todo)} datasets")
    return 0


def x_main__mutmut_168(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--curated", type=Path, default=registry / "uci_curated.json")
    parser.add_argument("--pool", type=Path, default=registry / "uci_pool.json")
    parser.add_argument("--data", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", type=int, nargs="*", help="UCI ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the datasets whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the registry sweep with drift, or the neural detectors",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.curated, args.pool, args.data)
        if not args.only or j[0]["uci_id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{j[0]['uci_id']}.json").exists()]
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_one, names=names), todo):
            with atomic_path(args.output / f"{result['uci_id']}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=False) + "\n")
            print(result["name"], flush=True)
    print(f"{len(todo)} datasets")
    return 0


def x_main__mutmut_169(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--curated", type=Path, default=registry / "uci_curated.json")
    parser.add_argument("--pool", type=Path, default=registry / "uci_pool.json")
    parser.add_argument("--data", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", type=int, nargs="*", help="UCI ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the datasets whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the registry sweep with drift, or the neural detectors",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.curated, args.pool, args.data)
        if not args.only or j[0]["uci_id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{j[0]['uci_id']}.json").exists()]
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_one, names=names), todo):
            with atomic_path(args.output / f"{result['uci_id']}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "XX\nXX")
            print(result["name"], flush=True)
    print(f"{len(todo)} datasets")
    return 0


def x_main__mutmut_170(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--curated", type=Path, default=registry / "uci_curated.json")
    parser.add_argument("--pool", type=Path, default=registry / "uci_pool.json")
    parser.add_argument("--data", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", type=int, nargs="*", help="UCI ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the datasets whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the registry sweep with drift, or the neural detectors",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.curated, args.pool, args.data)
        if not args.only or j[0]["uci_id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{j[0]['uci_id']}.json").exists()]
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_one, names=names), todo):
            with atomic_path(args.output / f"{result['uci_id']}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(None, flush=True)
    print(f"{len(todo)} datasets")
    return 0


def x_main__mutmut_171(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--curated", type=Path, default=registry / "uci_curated.json")
    parser.add_argument("--pool", type=Path, default=registry / "uci_pool.json")
    parser.add_argument("--data", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", type=int, nargs="*", help="UCI ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the datasets whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the registry sweep with drift, or the neural detectors",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.curated, args.pool, args.data)
        if not args.only or j[0]["uci_id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{j[0]['uci_id']}.json").exists()]
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_one, names=names), todo):
            with atomic_path(args.output / f"{result['uci_id']}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["name"], flush=None)
    print(f"{len(todo)} datasets")
    return 0


def x_main__mutmut_172(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--curated", type=Path, default=registry / "uci_curated.json")
    parser.add_argument("--pool", type=Path, default=registry / "uci_pool.json")
    parser.add_argument("--data", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", type=int, nargs="*", help="UCI ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the datasets whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the registry sweep with drift, or the neural detectors",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.curated, args.pool, args.data)
        if not args.only or j[0]["uci_id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{j[0]['uci_id']}.json").exists()]
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_one, names=names), todo):
            with atomic_path(args.output / f"{result['uci_id']}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(flush=True)
    print(f"{len(todo)} datasets")
    return 0


def x_main__mutmut_173(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--curated", type=Path, default=registry / "uci_curated.json")
    parser.add_argument("--pool", type=Path, default=registry / "uci_pool.json")
    parser.add_argument("--data", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", type=int, nargs="*", help="UCI ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the datasets whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the registry sweep with drift, or the neural detectors",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.curated, args.pool, args.data)
        if not args.only or j[0]["uci_id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{j[0]['uci_id']}.json").exists()]
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_one, names=names), todo):
            with atomic_path(args.output / f"{result['uci_id']}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["name"], )
    print(f"{len(todo)} datasets")
    return 0


def x_main__mutmut_174(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--curated", type=Path, default=registry / "uci_curated.json")
    parser.add_argument("--pool", type=Path, default=registry / "uci_pool.json")
    parser.add_argument("--data", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", type=int, nargs="*", help="UCI ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the datasets whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the registry sweep with drift, or the neural detectors",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.curated, args.pool, args.data)
        if not args.only or j[0]["uci_id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{j[0]['uci_id']}.json").exists()]
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_one, names=names), todo):
            with atomic_path(args.output / f"{result['uci_id']}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["XXnameXX"], flush=True)
    print(f"{len(todo)} datasets")
    return 0


def x_main__mutmut_175(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--curated", type=Path, default=registry / "uci_curated.json")
    parser.add_argument("--pool", type=Path, default=registry / "uci_pool.json")
    parser.add_argument("--data", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", type=int, nargs="*", help="UCI ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the datasets whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the registry sweep with drift, or the neural detectors",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.curated, args.pool, args.data)
        if not args.only or j[0]["uci_id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{j[0]['uci_id']}.json").exists()]
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_one, names=names), todo):
            with atomic_path(args.output / f"{result['uci_id']}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["NAME"], flush=True)
    print(f"{len(todo)} datasets")
    return 0


def x_main__mutmut_176(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--curated", type=Path, default=registry / "uci_curated.json")
    parser.add_argument("--pool", type=Path, default=registry / "uci_pool.json")
    parser.add_argument("--data", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", type=int, nargs="*", help="UCI ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the datasets whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the registry sweep with drift, or the neural detectors",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.curated, args.pool, args.data)
        if not args.only or j[0]["uci_id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{j[0]['uci_id']}.json").exists()]
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_one, names=names), todo):
            with atomic_path(args.output / f"{result['uci_id']}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["name"], flush=False)
    print(f"{len(todo)} datasets")
    return 0


def x_main__mutmut_177(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--curated", type=Path, default=registry / "uci_curated.json")
    parser.add_argument("--pool", type=Path, default=registry / "uci_pool.json")
    parser.add_argument("--data", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", type=int, nargs="*", help="UCI ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the datasets whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the registry sweep with drift, or the neural detectors",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.curated, args.pool, args.data)
        if not args.only or j[0]["uci_id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{j[0]['uci_id']}.json").exists()]
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_one, names=names), todo):
            with atomic_path(args.output / f"{result['uci_id']}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["name"], flush=True)
    print(None)
    return 0


def x_main__mutmut_178(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--curated", type=Path, default=registry / "uci_curated.json")
    parser.add_argument("--pool", type=Path, default=registry / "uci_pool.json")
    parser.add_argument("--data", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", type=int, nargs="*", help="UCI ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the datasets whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the registry sweep with drift, or the neural detectors",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.curated, args.pool, args.data)
        if not args.only or j[0]["uci_id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{j[0]['uci_id']}.json").exists()]
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_one, names=names), todo):
            with atomic_path(args.output / f"{result['uci_id']}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["name"], flush=True)
    print(f"{len(todo)} datasets")
    return 1

mutants_x_main__mutmut['_mutmut_orig'] = x_main__mutmut_orig # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_1'] = x_main__mutmut_1 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_2'] = x_main__mutmut_2 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_3'] = x_main__mutmut_3 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_4'] = x_main__mutmut_4 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_5'] = x_main__mutmut_5 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_6'] = x_main__mutmut_6 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_7'] = x_main__mutmut_7 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_8'] = x_main__mutmut_8 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_9'] = x_main__mutmut_9 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_10'] = x_main__mutmut_10 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_11'] = x_main__mutmut_11 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_12'] = x_main__mutmut_12 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_13'] = x_main__mutmut_13 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_14'] = x_main__mutmut_14 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_15'] = x_main__mutmut_15 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_16'] = x_main__mutmut_16 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_17'] = x_main__mutmut_17 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_18'] = x_main__mutmut_18 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_19'] = x_main__mutmut_19 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_20'] = x_main__mutmut_20 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_21'] = x_main__mutmut_21 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_22'] = x_main__mutmut_22 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_23'] = x_main__mutmut_23 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_24'] = x_main__mutmut_24 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_25'] = x_main__mutmut_25 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_26'] = x_main__mutmut_26 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_27'] = x_main__mutmut_27 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_28'] = x_main__mutmut_28 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_29'] = x_main__mutmut_29 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_30'] = x_main__mutmut_30 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_31'] = x_main__mutmut_31 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_32'] = x_main__mutmut_32 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_33'] = x_main__mutmut_33 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_34'] = x_main__mutmut_34 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_35'] = x_main__mutmut_35 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_36'] = x_main__mutmut_36 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_37'] = x_main__mutmut_37 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_38'] = x_main__mutmut_38 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_39'] = x_main__mutmut_39 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_40'] = x_main__mutmut_40 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_41'] = x_main__mutmut_41 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_42'] = x_main__mutmut_42 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_43'] = x_main__mutmut_43 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_44'] = x_main__mutmut_44 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_45'] = x_main__mutmut_45 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_46'] = x_main__mutmut_46 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_47'] = x_main__mutmut_47 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_48'] = x_main__mutmut_48 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_49'] = x_main__mutmut_49 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_50'] = x_main__mutmut_50 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_51'] = x_main__mutmut_51 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_52'] = x_main__mutmut_52 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_53'] = x_main__mutmut_53 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_54'] = x_main__mutmut_54 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_55'] = x_main__mutmut_55 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_56'] = x_main__mutmut_56 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_57'] = x_main__mutmut_57 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_58'] = x_main__mutmut_58 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_59'] = x_main__mutmut_59 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_60'] = x_main__mutmut_60 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_61'] = x_main__mutmut_61 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_62'] = x_main__mutmut_62 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_63'] = x_main__mutmut_63 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_64'] = x_main__mutmut_64 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_65'] = x_main__mutmut_65 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_66'] = x_main__mutmut_66 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_67'] = x_main__mutmut_67 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_68'] = x_main__mutmut_68 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_69'] = x_main__mutmut_69 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_70'] = x_main__mutmut_70 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_71'] = x_main__mutmut_71 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_72'] = x_main__mutmut_72 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_73'] = x_main__mutmut_73 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_74'] = x_main__mutmut_74 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_75'] = x_main__mutmut_75 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_76'] = x_main__mutmut_76 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_77'] = x_main__mutmut_77 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_78'] = x_main__mutmut_78 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_79'] = x_main__mutmut_79 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_80'] = x_main__mutmut_80 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_81'] = x_main__mutmut_81 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_82'] = x_main__mutmut_82 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_83'] = x_main__mutmut_83 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_84'] = x_main__mutmut_84 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_85'] = x_main__mutmut_85 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_86'] = x_main__mutmut_86 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_87'] = x_main__mutmut_87 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_88'] = x_main__mutmut_88 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_89'] = x_main__mutmut_89 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_90'] = x_main__mutmut_90 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_91'] = x_main__mutmut_91 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_92'] = x_main__mutmut_92 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_93'] = x_main__mutmut_93 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_94'] = x_main__mutmut_94 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_95'] = x_main__mutmut_95 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_96'] = x_main__mutmut_96 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_97'] = x_main__mutmut_97 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_98'] = x_main__mutmut_98 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_99'] = x_main__mutmut_99 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_100'] = x_main__mutmut_100 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_101'] = x_main__mutmut_101 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_102'] = x_main__mutmut_102 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_103'] = x_main__mutmut_103 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_104'] = x_main__mutmut_104 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_105'] = x_main__mutmut_105 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_106'] = x_main__mutmut_106 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_107'] = x_main__mutmut_107 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_108'] = x_main__mutmut_108 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_109'] = x_main__mutmut_109 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_110'] = x_main__mutmut_110 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_111'] = x_main__mutmut_111 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_112'] = x_main__mutmut_112 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_113'] = x_main__mutmut_113 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_114'] = x_main__mutmut_114 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_115'] = x_main__mutmut_115 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_116'] = x_main__mutmut_116 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_117'] = x_main__mutmut_117 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_118'] = x_main__mutmut_118 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_119'] = x_main__mutmut_119 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_120'] = x_main__mutmut_120 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_121'] = x_main__mutmut_121 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_122'] = x_main__mutmut_122 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_123'] = x_main__mutmut_123 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_124'] = x_main__mutmut_124 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_125'] = x_main__mutmut_125 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_126'] = x_main__mutmut_126 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_127'] = x_main__mutmut_127 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_128'] = x_main__mutmut_128 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_129'] = x_main__mutmut_129 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_130'] = x_main__mutmut_130 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_131'] = x_main__mutmut_131 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_132'] = x_main__mutmut_132 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_133'] = x_main__mutmut_133 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_134'] = x_main__mutmut_134 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_135'] = x_main__mutmut_135 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_136'] = x_main__mutmut_136 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_137'] = x_main__mutmut_137 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_138'] = x_main__mutmut_138 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_139'] = x_main__mutmut_139 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_140'] = x_main__mutmut_140 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_141'] = x_main__mutmut_141 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_142'] = x_main__mutmut_142 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_143'] = x_main__mutmut_143 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_144'] = x_main__mutmut_144 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_145'] = x_main__mutmut_145 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_146'] = x_main__mutmut_146 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_147'] = x_main__mutmut_147 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_148'] = x_main__mutmut_148 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_149'] = x_main__mutmut_149 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_150'] = x_main__mutmut_150 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_151'] = x_main__mutmut_151 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_152'] = x_main__mutmut_152 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_153'] = x_main__mutmut_153 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_154'] = x_main__mutmut_154 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_155'] = x_main__mutmut_155 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_156'] = x_main__mutmut_156 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_157'] = x_main__mutmut_157 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_158'] = x_main__mutmut_158 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_159'] = x_main__mutmut_159 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_160'] = x_main__mutmut_160 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_161'] = x_main__mutmut_161 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_162'] = x_main__mutmut_162 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_163'] = x_main__mutmut_163 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_164'] = x_main__mutmut_164 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_165'] = x_main__mutmut_165 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_166'] = x_main__mutmut_166 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_167'] = x_main__mutmut_167 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_168'] = x_main__mutmut_168 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_169'] = x_main__mutmut_169 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_170'] = x_main__mutmut_170 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_171'] = x_main__mutmut_171 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_172'] = x_main__mutmut_172 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_173'] = x_main__mutmut_173 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_174'] = x_main__mutmut_174 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_175'] = x_main__mutmut_175 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_176'] = x_main__mutmut_176 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_177'] = x_main__mutmut_177 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_178'] = x_main__mutmut_178 # type: ignore # mutmut generated


if __name__ == "__main__":
    raise SystemExit(main())
