"""Chronological pilot on Credit Card (issue 51); protocol in verification/temporal_pilot.md.

Compares, with identical rows, features and detectors, a chronological split (fit on the
past, score the future) with the stratified random split of the main benchmark, and runs
the window drift monitor on a known synthetic change. Not part of FAST or CI.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import logging
import os
import platform
import sys
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
from sklearn.metrics import average_precision_score

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "experiments"))

from etl_benchmark import config  # noqa: E402
from etl_benchmark.atomic import atomic_path  # noqa: E402
from etl_benchmark.datasets import ANOMALY_COLUMN, DATASETS, DatasetSpec  # noqa: E402
from etl_benchmark.metrics import compute_metrics  # noqa: E402
from etl_benchmark.pipeline import detect  # noqa: E402
from etl_benchmark.quality.window_drift import WindowDriftMonitor, event_metrics  # noqa: E402
from etl_benchmark.registry import all_detectors  # noqa: E402
from etl_benchmark.split import chronological_split, stratified_split  # noqa: E402

log = logging.getLogger(__name__)

TIME_UTC = "time_utc"
ORIGIN = pd.Timestamp("1970-01-01", tz="UTC")  # relative origin: the file has no calendar date
DRIFT_COLUMNS = ["V1", "V2", "V3", "V4", "V5"]
DELTAS = (0.0, 0.5, 1.0, 2.0)
WINDOW_SIZE = 1000
BLOCK_SECONDS = 1800
RESAMPLES = 1000
BOOTSTRAP_SEED = 42


from mutmut.mutation.trampoline import wrap_in_trampoline as _mutmut_mutated, MutantDict
mutants_x_to_timestamps__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_to_timestamps__mutmut)
def to_timestamps(seconds: pd.Series) -> pd.Series:
    """Elapsed seconds since the first transaction as UTC timestamps from a fixed origin."""
    values = pd.to_numeric(seconds, errors="coerce")
    if not np.isfinite(values.to_numpy(dtype=float)).all() or (values < 0).any():
        raise ValueError("elapsed times must be finite and non-negative")
    return ORIGIN + pd.to_timedelta(values, unit="s")


def x_to_timestamps__mutmut_orig(seconds: pd.Series) -> pd.Series:
    """Elapsed seconds since the first transaction as UTC timestamps from a fixed origin."""
    values = pd.to_numeric(seconds, errors="coerce")
    if not np.isfinite(values.to_numpy(dtype=float)).all() or (values < 0).any():
        raise ValueError("elapsed times must be finite and non-negative")
    return ORIGIN + pd.to_timedelta(values, unit="s")


def x_to_timestamps__mutmut_1(seconds: pd.Series) -> pd.Series:
    """Elapsed seconds since the first transaction as UTC timestamps from a fixed origin."""
    values = None
    if not np.isfinite(values.to_numpy(dtype=float)).all() or (values < 0).any():
        raise ValueError("elapsed times must be finite and non-negative")
    return ORIGIN + pd.to_timedelta(values, unit="s")


def x_to_timestamps__mutmut_2(seconds: pd.Series) -> pd.Series:
    """Elapsed seconds since the first transaction as UTC timestamps from a fixed origin."""
    values = pd.to_numeric(None, errors="coerce")
    if not np.isfinite(values.to_numpy(dtype=float)).all() or (values < 0).any():
        raise ValueError("elapsed times must be finite and non-negative")
    return ORIGIN + pd.to_timedelta(values, unit="s")


def x_to_timestamps__mutmut_3(seconds: pd.Series) -> pd.Series:
    """Elapsed seconds since the first transaction as UTC timestamps from a fixed origin."""
    values = pd.to_numeric(seconds, errors=None)
    if not np.isfinite(values.to_numpy(dtype=float)).all() or (values < 0).any():
        raise ValueError("elapsed times must be finite and non-negative")
    return ORIGIN + pd.to_timedelta(values, unit="s")


def x_to_timestamps__mutmut_4(seconds: pd.Series) -> pd.Series:
    """Elapsed seconds since the first transaction as UTC timestamps from a fixed origin."""
    values = pd.to_numeric(errors="coerce")
    if not np.isfinite(values.to_numpy(dtype=float)).all() or (values < 0).any():
        raise ValueError("elapsed times must be finite and non-negative")
    return ORIGIN + pd.to_timedelta(values, unit="s")


def x_to_timestamps__mutmut_5(seconds: pd.Series) -> pd.Series:
    """Elapsed seconds since the first transaction as UTC timestamps from a fixed origin."""
    values = pd.to_numeric(seconds, )
    if not np.isfinite(values.to_numpy(dtype=float)).all() or (values < 0).any():
        raise ValueError("elapsed times must be finite and non-negative")
    return ORIGIN + pd.to_timedelta(values, unit="s")


def x_to_timestamps__mutmut_6(seconds: pd.Series) -> pd.Series:
    """Elapsed seconds since the first transaction as UTC timestamps from a fixed origin."""
    values = pd.to_numeric(seconds, errors="XXcoerceXX")
    if not np.isfinite(values.to_numpy(dtype=float)).all() or (values < 0).any():
        raise ValueError("elapsed times must be finite and non-negative")
    return ORIGIN + pd.to_timedelta(values, unit="s")


def x_to_timestamps__mutmut_7(seconds: pd.Series) -> pd.Series:
    """Elapsed seconds since the first transaction as UTC timestamps from a fixed origin."""
    values = pd.to_numeric(seconds, errors="COERCE")
    if not np.isfinite(values.to_numpy(dtype=float)).all() or (values < 0).any():
        raise ValueError("elapsed times must be finite and non-negative")
    return ORIGIN + pd.to_timedelta(values, unit="s")


def x_to_timestamps__mutmut_8(seconds: pd.Series) -> pd.Series:
    """Elapsed seconds since the first transaction as UTC timestamps from a fixed origin."""
    values = pd.to_numeric(seconds, errors="coerce")
    if not np.isfinite(values.to_numpy(dtype=float)).all() and (values < 0).any():
        raise ValueError("elapsed times must be finite and non-negative")
    return ORIGIN + pd.to_timedelta(values, unit="s")


def x_to_timestamps__mutmut_9(seconds: pd.Series) -> pd.Series:
    """Elapsed seconds since the first transaction as UTC timestamps from a fixed origin."""
    values = pd.to_numeric(seconds, errors="coerce")
    if np.isfinite(values.to_numpy(dtype=float)).all() or (values < 0).any():
        raise ValueError("elapsed times must be finite and non-negative")
    return ORIGIN + pd.to_timedelta(values, unit="s")


def x_to_timestamps__mutmut_10(seconds: pd.Series) -> pd.Series:
    """Elapsed seconds since the first transaction as UTC timestamps from a fixed origin."""
    values = pd.to_numeric(seconds, errors="coerce")
    if not np.isfinite(None).all() or (values < 0).any():
        raise ValueError("elapsed times must be finite and non-negative")
    return ORIGIN + pd.to_timedelta(values, unit="s")


def x_to_timestamps__mutmut_11(seconds: pd.Series) -> pd.Series:
    """Elapsed seconds since the first transaction as UTC timestamps from a fixed origin."""
    values = pd.to_numeric(seconds, errors="coerce")
    if not np.isfinite(values.to_numpy(dtype=None)).all() or (values < 0).any():
        raise ValueError("elapsed times must be finite and non-negative")
    return ORIGIN + pd.to_timedelta(values, unit="s")


def x_to_timestamps__mutmut_12(seconds: pd.Series) -> pd.Series:
    """Elapsed seconds since the first transaction as UTC timestamps from a fixed origin."""
    values = pd.to_numeric(seconds, errors="coerce")
    if not np.isfinite(values.to_numpy(dtype=float)).all() or (values <= 0).any():
        raise ValueError("elapsed times must be finite and non-negative")
    return ORIGIN + pd.to_timedelta(values, unit="s")


def x_to_timestamps__mutmut_13(seconds: pd.Series) -> pd.Series:
    """Elapsed seconds since the first transaction as UTC timestamps from a fixed origin."""
    values = pd.to_numeric(seconds, errors="coerce")
    if not np.isfinite(values.to_numpy(dtype=float)).all() or (values < 1).any():
        raise ValueError("elapsed times must be finite and non-negative")
    return ORIGIN + pd.to_timedelta(values, unit="s")


def x_to_timestamps__mutmut_14(seconds: pd.Series) -> pd.Series:
    """Elapsed seconds since the first transaction as UTC timestamps from a fixed origin."""
    values = pd.to_numeric(seconds, errors="coerce")
    if not np.isfinite(values.to_numpy(dtype=float)).all() or (values < 0).any():
        raise ValueError(None)
    return ORIGIN + pd.to_timedelta(values, unit="s")


def x_to_timestamps__mutmut_15(seconds: pd.Series) -> pd.Series:
    """Elapsed seconds since the first transaction as UTC timestamps from a fixed origin."""
    values = pd.to_numeric(seconds, errors="coerce")
    if not np.isfinite(values.to_numpy(dtype=float)).all() or (values < 0).any():
        raise ValueError("XXelapsed times must be finite and non-negativeXX")
    return ORIGIN + pd.to_timedelta(values, unit="s")


def x_to_timestamps__mutmut_16(seconds: pd.Series) -> pd.Series:
    """Elapsed seconds since the first transaction as UTC timestamps from a fixed origin."""
    values = pd.to_numeric(seconds, errors="coerce")
    if not np.isfinite(values.to_numpy(dtype=float)).all() or (values < 0).any():
        raise ValueError("ELAPSED TIMES MUST BE FINITE AND NON-NEGATIVE")
    return ORIGIN + pd.to_timedelta(values, unit="s")


def x_to_timestamps__mutmut_17(seconds: pd.Series) -> pd.Series:
    """Elapsed seconds since the first transaction as UTC timestamps from a fixed origin."""
    values = pd.to_numeric(seconds, errors="coerce")
    if not np.isfinite(values.to_numpy(dtype=float)).all() or (values < 0).any():
        raise ValueError("elapsed times must be finite and non-negative")
    return ORIGIN - pd.to_timedelta(values, unit="s")


def x_to_timestamps__mutmut_18(seconds: pd.Series) -> pd.Series:
    """Elapsed seconds since the first transaction as UTC timestamps from a fixed origin."""
    values = pd.to_numeric(seconds, errors="coerce")
    if not np.isfinite(values.to_numpy(dtype=float)).all() or (values < 0).any():
        raise ValueError("elapsed times must be finite and non-negative")
    return ORIGIN + pd.to_timedelta(None, unit="s")


def x_to_timestamps__mutmut_19(seconds: pd.Series) -> pd.Series:
    """Elapsed seconds since the first transaction as UTC timestamps from a fixed origin."""
    values = pd.to_numeric(seconds, errors="coerce")
    if not np.isfinite(values.to_numpy(dtype=float)).all() or (values < 0).any():
        raise ValueError("elapsed times must be finite and non-negative")
    return ORIGIN + pd.to_timedelta(values, unit=None)


def x_to_timestamps__mutmut_20(seconds: pd.Series) -> pd.Series:
    """Elapsed seconds since the first transaction as UTC timestamps from a fixed origin."""
    values = pd.to_numeric(seconds, errors="coerce")
    if not np.isfinite(values.to_numpy(dtype=float)).all() or (values < 0).any():
        raise ValueError("elapsed times must be finite and non-negative")
    return ORIGIN + pd.to_timedelta(unit="s")


def x_to_timestamps__mutmut_21(seconds: pd.Series) -> pd.Series:
    """Elapsed seconds since the first transaction as UTC timestamps from a fixed origin."""
    values = pd.to_numeric(seconds, errors="coerce")
    if not np.isfinite(values.to_numpy(dtype=float)).all() or (values < 0).any():
        raise ValueError("elapsed times must be finite and non-negative")
    return ORIGIN + pd.to_timedelta(values, )


def x_to_timestamps__mutmut_22(seconds: pd.Series) -> pd.Series:
    """Elapsed seconds since the first transaction as UTC timestamps from a fixed origin."""
    values = pd.to_numeric(seconds, errors="coerce")
    if not np.isfinite(values.to_numpy(dtype=float)).all() or (values < 0).any():
        raise ValueError("elapsed times must be finite and non-negative")
    return ORIGIN + pd.to_timedelta(values, unit="XXsXX")


def x_to_timestamps__mutmut_23(seconds: pd.Series) -> pd.Series:
    """Elapsed seconds since the first transaction as UTC timestamps from a fixed origin."""
    values = pd.to_numeric(seconds, errors="coerce")
    if not np.isfinite(values.to_numpy(dtype=float)).all() or (values < 0).any():
        raise ValueError("elapsed times must be finite and non-negative")
    return ORIGIN + pd.to_timedelta(values, unit="S")

mutants_x_to_timestamps__mutmut['_mutmut_orig'] = x_to_timestamps__mutmut_orig # type: ignore # mutmut generated
mutants_x_to_timestamps__mutmut['x_to_timestamps__mutmut_1'] = x_to_timestamps__mutmut_1 # type: ignore # mutmut generated
mutants_x_to_timestamps__mutmut['x_to_timestamps__mutmut_2'] = x_to_timestamps__mutmut_2 # type: ignore # mutmut generated
mutants_x_to_timestamps__mutmut['x_to_timestamps__mutmut_3'] = x_to_timestamps__mutmut_3 # type: ignore # mutmut generated
mutants_x_to_timestamps__mutmut['x_to_timestamps__mutmut_4'] = x_to_timestamps__mutmut_4 # type: ignore # mutmut generated
mutants_x_to_timestamps__mutmut['x_to_timestamps__mutmut_5'] = x_to_timestamps__mutmut_5 # type: ignore # mutmut generated
mutants_x_to_timestamps__mutmut['x_to_timestamps__mutmut_6'] = x_to_timestamps__mutmut_6 # type: ignore # mutmut generated
mutants_x_to_timestamps__mutmut['x_to_timestamps__mutmut_7'] = x_to_timestamps__mutmut_7 # type: ignore # mutmut generated
mutants_x_to_timestamps__mutmut['x_to_timestamps__mutmut_8'] = x_to_timestamps__mutmut_8 # type: ignore # mutmut generated
mutants_x_to_timestamps__mutmut['x_to_timestamps__mutmut_9'] = x_to_timestamps__mutmut_9 # type: ignore # mutmut generated
mutants_x_to_timestamps__mutmut['x_to_timestamps__mutmut_10'] = x_to_timestamps__mutmut_10 # type: ignore # mutmut generated
mutants_x_to_timestamps__mutmut['x_to_timestamps__mutmut_11'] = x_to_timestamps__mutmut_11 # type: ignore # mutmut generated
mutants_x_to_timestamps__mutmut['x_to_timestamps__mutmut_12'] = x_to_timestamps__mutmut_12 # type: ignore # mutmut generated
mutants_x_to_timestamps__mutmut['x_to_timestamps__mutmut_13'] = x_to_timestamps__mutmut_13 # type: ignore # mutmut generated
mutants_x_to_timestamps__mutmut['x_to_timestamps__mutmut_14'] = x_to_timestamps__mutmut_14 # type: ignore # mutmut generated
mutants_x_to_timestamps__mutmut['x_to_timestamps__mutmut_15'] = x_to_timestamps__mutmut_15 # type: ignore # mutmut generated
mutants_x_to_timestamps__mutmut['x_to_timestamps__mutmut_16'] = x_to_timestamps__mutmut_16 # type: ignore # mutmut generated
mutants_x_to_timestamps__mutmut['x_to_timestamps__mutmut_17'] = x_to_timestamps__mutmut_17 # type: ignore # mutmut generated
mutants_x_to_timestamps__mutmut['x_to_timestamps__mutmut_18'] = x_to_timestamps__mutmut_18 # type: ignore # mutmut generated
mutants_x_to_timestamps__mutmut['x_to_timestamps__mutmut_19'] = x_to_timestamps__mutmut_19 # type: ignore # mutmut generated
mutants_x_to_timestamps__mutmut['x_to_timestamps__mutmut_20'] = x_to_timestamps__mutmut_20 # type: ignore # mutmut generated
mutants_x_to_timestamps__mutmut['x_to_timestamps__mutmut_21'] = x_to_timestamps__mutmut_21 # type: ignore # mutmut generated
mutants_x_to_timestamps__mutmut['x_to_timestamps__mutmut_22'] = x_to_timestamps__mutmut_22 # type: ignore # mutmut generated
mutants_x_to_timestamps__mutmut['x_to_timestamps__mutmut_23'] = x_to_timestamps__mutmut_23 # type: ignore # mutmut generated
mutants_x_load__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_load__mutmut)
def load(spec: DatasetSpec) -> pd.DataFrame:
    """The benchmark's cleaned rows (exact duplicates dropped) plus a timestamp column."""
    frame = spec.load()
    frame[TIME_UTC] = to_timestamps(frame["Time"])
    return frame


def x_load__mutmut_orig(spec: DatasetSpec) -> pd.DataFrame:
    """The benchmark's cleaned rows (exact duplicates dropped) plus a timestamp column."""
    frame = spec.load()
    frame[TIME_UTC] = to_timestamps(frame["Time"])
    return frame


def x_load__mutmut_1(spec: DatasetSpec) -> pd.DataFrame:
    """The benchmark's cleaned rows (exact duplicates dropped) plus a timestamp column."""
    frame = None
    frame[TIME_UTC] = to_timestamps(frame["Time"])
    return frame


def x_load__mutmut_2(spec: DatasetSpec) -> pd.DataFrame:
    """The benchmark's cleaned rows (exact duplicates dropped) plus a timestamp column."""
    frame = spec.load()
    frame[TIME_UTC] = None
    return frame


def x_load__mutmut_3(spec: DatasetSpec) -> pd.DataFrame:
    """The benchmark's cleaned rows (exact duplicates dropped) plus a timestamp column."""
    frame = spec.load()
    frame[TIME_UTC] = to_timestamps(None)
    return frame


def x_load__mutmut_4(spec: DatasetSpec) -> pd.DataFrame:
    """The benchmark's cleaned rows (exact duplicates dropped) plus a timestamp column."""
    frame = spec.load()
    frame[TIME_UTC] = to_timestamps(frame["XXTimeXX"])
    return frame


def x_load__mutmut_5(spec: DatasetSpec) -> pd.DataFrame:
    """The benchmark's cleaned rows (exact duplicates dropped) plus a timestamp column."""
    frame = spec.load()
    frame[TIME_UTC] = to_timestamps(frame["time"])
    return frame


def x_load__mutmut_6(spec: DatasetSpec) -> pd.DataFrame:
    """The benchmark's cleaned rows (exact duplicates dropped) plus a timestamp column."""
    frame = spec.load()
    frame[TIME_UTC] = to_timestamps(frame["TIME"])
    return frame

mutants_x_load__mutmut['_mutmut_orig'] = x_load__mutmut_orig # type: ignore # mutmut generated
mutants_x_load__mutmut['x_load__mutmut_1'] = x_load__mutmut_1 # type: ignore # mutmut generated
mutants_x_load__mutmut['x_load__mutmut_2'] = x_load__mutmut_2 # type: ignore # mutmut generated
mutants_x_load__mutmut['x_load__mutmut_3'] = x_load__mutmut_3 # type: ignore # mutmut generated
mutants_x_load__mutmut['x_load__mutmut_4'] = x_load__mutmut_4 # type: ignore # mutmut generated
mutants_x_load__mutmut['x_load__mutmut_5'] = x_load__mutmut_5 # type: ignore # mutmut generated
mutants_x_load__mutmut['x_load__mutmut_6'] = x_load__mutmut_6 # type: ignore # mutmut generated
mutants_x_features__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_features__mutmut)
def features(spec: DatasetSpec, frame: pd.DataFrame) -> pd.DataFrame:
    """Detector inputs: the benchmark's features without the clock."""
    return spec.features(frame).drop(columns=["Time", TIME_UTC], errors="ignore")


def x_features__mutmut_orig(spec: DatasetSpec, frame: pd.DataFrame) -> pd.DataFrame:
    """Detector inputs: the benchmark's features without the clock."""
    return spec.features(frame).drop(columns=["Time", TIME_UTC], errors="ignore")


def x_features__mutmut_1(spec: DatasetSpec, frame: pd.DataFrame) -> pd.DataFrame:
    """Detector inputs: the benchmark's features without the clock."""
    return spec.features(frame).drop(columns=None, errors="ignore")


def x_features__mutmut_2(spec: DatasetSpec, frame: pd.DataFrame) -> pd.DataFrame:
    """Detector inputs: the benchmark's features without the clock."""
    return spec.features(frame).drop(columns=["Time", TIME_UTC], errors=None)


def x_features__mutmut_3(spec: DatasetSpec, frame: pd.DataFrame) -> pd.DataFrame:
    """Detector inputs: the benchmark's features without the clock."""
    return spec.features(frame).drop(errors="ignore")


def x_features__mutmut_4(spec: DatasetSpec, frame: pd.DataFrame) -> pd.DataFrame:
    """Detector inputs: the benchmark's features without the clock."""
    return spec.features(frame).drop(columns=["Time", TIME_UTC], )


def x_features__mutmut_5(spec: DatasetSpec, frame: pd.DataFrame) -> pd.DataFrame:
    """Detector inputs: the benchmark's features without the clock."""
    return spec.features(None).drop(columns=["Time", TIME_UTC], errors="ignore")


def x_features__mutmut_6(spec: DatasetSpec, frame: pd.DataFrame) -> pd.DataFrame:
    """Detector inputs: the benchmark's features without the clock."""
    return spec.features(frame).drop(columns=["XXTimeXX", TIME_UTC], errors="ignore")


def x_features__mutmut_7(spec: DatasetSpec, frame: pd.DataFrame) -> pd.DataFrame:
    """Detector inputs: the benchmark's features without the clock."""
    return spec.features(frame).drop(columns=["time", TIME_UTC], errors="ignore")


def x_features__mutmut_8(spec: DatasetSpec, frame: pd.DataFrame) -> pd.DataFrame:
    """Detector inputs: the benchmark's features without the clock."""
    return spec.features(frame).drop(columns=["TIME", TIME_UTC], errors="ignore")


def x_features__mutmut_9(spec: DatasetSpec, frame: pd.DataFrame) -> pd.DataFrame:
    """Detector inputs: the benchmark's features without the clock."""
    return spec.features(frame).drop(columns=["Time", TIME_UTC], errors="XXignoreXX")


def x_features__mutmut_10(spec: DatasetSpec, frame: pd.DataFrame) -> pd.DataFrame:
    """Detector inputs: the benchmark's features without the clock."""
    return spec.features(frame).drop(columns=["Time", TIME_UTC], errors="IGNORE")

mutants_x_features__mutmut['_mutmut_orig'] = x_features__mutmut_orig # type: ignore # mutmut generated
mutants_x_features__mutmut['x_features__mutmut_1'] = x_features__mutmut_1 # type: ignore # mutmut generated
mutants_x_features__mutmut['x_features__mutmut_2'] = x_features__mutmut_2 # type: ignore # mutmut generated
mutants_x_features__mutmut['x_features__mutmut_3'] = x_features__mutmut_3 # type: ignore # mutmut generated
mutants_x_features__mutmut['x_features__mutmut_4'] = x_features__mutmut_4 # type: ignore # mutmut generated
mutants_x_features__mutmut['x_features__mutmut_5'] = x_features__mutmut_5 # type: ignore # mutmut generated
mutants_x_features__mutmut['x_features__mutmut_6'] = x_features__mutmut_6 # type: ignore # mutmut generated
mutants_x_features__mutmut['x_features__mutmut_7'] = x_features__mutmut_7 # type: ignore # mutmut generated
mutants_x_features__mutmut['x_features__mutmut_8'] = x_features__mutmut_8 # type: ignore # mutmut generated
mutants_x_features__mutmut['x_features__mutmut_9'] = x_features__mutmut_9 # type: ignore # mutmut generated
mutants_x_features__mutmut['x_features__mutmut_10'] = x_features__mutmut_10 # type: ignore # mutmut generated
mutants_x_chronological_partitions__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_chronological_partitions__mutmut)
def chronological_partitions(frame: pd.DataFrame):
    return chronological_split(frame, TIME_UTC, config.SPLIT_RATIOS)


def x_chronological_partitions__mutmut_orig(frame: pd.DataFrame):
    return chronological_split(frame, TIME_UTC, config.SPLIT_RATIOS)


def x_chronological_partitions__mutmut_1(frame: pd.DataFrame):
    return chronological_split(None, TIME_UTC, config.SPLIT_RATIOS)


def x_chronological_partitions__mutmut_2(frame: pd.DataFrame):
    return chronological_split(frame, None, config.SPLIT_RATIOS)


def x_chronological_partitions__mutmut_3(frame: pd.DataFrame):
    return chronological_split(frame, TIME_UTC, None)


def x_chronological_partitions__mutmut_4(frame: pd.DataFrame):
    return chronological_split(TIME_UTC, config.SPLIT_RATIOS)


def x_chronological_partitions__mutmut_5(frame: pd.DataFrame):
    return chronological_split(frame, config.SPLIT_RATIOS)


def x_chronological_partitions__mutmut_6(frame: pd.DataFrame):
    return chronological_split(frame, TIME_UTC, )

mutants_x_chronological_partitions__mutmut['_mutmut_orig'] = x_chronological_partitions__mutmut_orig # type: ignore # mutmut generated
mutants_x_chronological_partitions__mutmut['x_chronological_partitions__mutmut_1'] = x_chronological_partitions__mutmut_1 # type: ignore # mutmut generated
mutants_x_chronological_partitions__mutmut['x_chronological_partitions__mutmut_2'] = x_chronological_partitions__mutmut_2 # type: ignore # mutmut generated
mutants_x_chronological_partitions__mutmut['x_chronological_partitions__mutmut_3'] = x_chronological_partitions__mutmut_3 # type: ignore # mutmut generated
mutants_x_chronological_partitions__mutmut['x_chronological_partitions__mutmut_4'] = x_chronological_partitions__mutmut_4 # type: ignore # mutmut generated
mutants_x_chronological_partitions__mutmut['x_chronological_partitions__mutmut_5'] = x_chronological_partitions__mutmut_5 # type: ignore # mutmut generated
mutants_x_chronological_partitions__mutmut['x_chronological_partitions__mutmut_6'] = x_chronological_partitions__mutmut_6 # type: ignore # mutmut generated
mutants_x_stratified_partitions__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_stratified_partitions__mutmut)
def stratified_partitions(frame: pd.DataFrame, seed: int):
    return stratified_split(frame, ANOMALY_COLUMN, config.SPLIT_RATIOS, seed)


def x_stratified_partitions__mutmut_orig(frame: pd.DataFrame, seed: int):
    return stratified_split(frame, ANOMALY_COLUMN, config.SPLIT_RATIOS, seed)


def x_stratified_partitions__mutmut_1(frame: pd.DataFrame, seed: int):
    return stratified_split(None, ANOMALY_COLUMN, config.SPLIT_RATIOS, seed)


def x_stratified_partitions__mutmut_2(frame: pd.DataFrame, seed: int):
    return stratified_split(frame, None, config.SPLIT_RATIOS, seed)


def x_stratified_partitions__mutmut_3(frame: pd.DataFrame, seed: int):
    return stratified_split(frame, ANOMALY_COLUMN, None, seed)


def x_stratified_partitions__mutmut_4(frame: pd.DataFrame, seed: int):
    return stratified_split(frame, ANOMALY_COLUMN, config.SPLIT_RATIOS, None)


def x_stratified_partitions__mutmut_5(frame: pd.DataFrame, seed: int):
    return stratified_split(ANOMALY_COLUMN, config.SPLIT_RATIOS, seed)


def x_stratified_partitions__mutmut_6(frame: pd.DataFrame, seed: int):
    return stratified_split(frame, config.SPLIT_RATIOS, seed)


def x_stratified_partitions__mutmut_7(frame: pd.DataFrame, seed: int):
    return stratified_split(frame, ANOMALY_COLUMN, seed)


def x_stratified_partitions__mutmut_8(frame: pd.DataFrame, seed: int):
    return stratified_split(frame, ANOMALY_COLUMN, config.SPLIT_RATIOS, )

mutants_x_stratified_partitions__mutmut['_mutmut_orig'] = x_stratified_partitions__mutmut_orig # type: ignore # mutmut generated
mutants_x_stratified_partitions__mutmut['x_stratified_partitions__mutmut_1'] = x_stratified_partitions__mutmut_1 # type: ignore # mutmut generated
mutants_x_stratified_partitions__mutmut['x_stratified_partitions__mutmut_2'] = x_stratified_partitions__mutmut_2 # type: ignore # mutmut generated
mutants_x_stratified_partitions__mutmut['x_stratified_partitions__mutmut_3'] = x_stratified_partitions__mutmut_3 # type: ignore # mutmut generated
mutants_x_stratified_partitions__mutmut['x_stratified_partitions__mutmut_4'] = x_stratified_partitions__mutmut_4 # type: ignore # mutmut generated
mutants_x_stratified_partitions__mutmut['x_stratified_partitions__mutmut_5'] = x_stratified_partitions__mutmut_5 # type: ignore # mutmut generated
mutants_x_stratified_partitions__mutmut['x_stratified_partitions__mutmut_6'] = x_stratified_partitions__mutmut_6 # type: ignore # mutmut generated
mutants_x_stratified_partitions__mutmut['x_stratified_partitions__mutmut_7'] = x_stratified_partitions__mutmut_7 # type: ignore # mutmut generated
mutants_x_stratified_partitions__mutmut['x_stratified_partitions__mutmut_8'] = x_stratified_partitions__mutmut_8 # type: ignore # mutmut generated
mutants_x_score_partition__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_score_partition__mutmut)
def score_partition(spec: DatasetSpec, train: pd.DataFrame, test: pd.DataFrame) -> dict[str, Any]:
    """Fit every detector on ``train`` only and score ``test``."""
    contamination = float(train[ANOMALY_COLUMN].mean())
    fit_df, test_x = features(spec, train), features(spec, test)
    out: dict[str, Any] = {"y": test[ANOMALY_COLUMN].to_numpy(), "scores": {}, "flags": {}}
    for det in all_detectors(ml_contamination=contamination, names=spec.detector_names):
        result = detect(test_x, det, fit_df=fit_df)
        out["scores"][det.name] = np.asarray(result.scores, dtype=float)
        out["flags"][det.name] = np.asarray(result.flags, dtype=bool)
        log.info("scored %s", det.name)
    return out


def x_score_partition__mutmut_orig(spec: DatasetSpec, train: pd.DataFrame, test: pd.DataFrame) -> dict[str, Any]:
    """Fit every detector on ``train`` only and score ``test``."""
    contamination = float(train[ANOMALY_COLUMN].mean())
    fit_df, test_x = features(spec, train), features(spec, test)
    out: dict[str, Any] = {"y": test[ANOMALY_COLUMN].to_numpy(), "scores": {}, "flags": {}}
    for det in all_detectors(ml_contamination=contamination, names=spec.detector_names):
        result = detect(test_x, det, fit_df=fit_df)
        out["scores"][det.name] = np.asarray(result.scores, dtype=float)
        out["flags"][det.name] = np.asarray(result.flags, dtype=bool)
        log.info("scored %s", det.name)
    return out


def x_score_partition__mutmut_1(spec: DatasetSpec, train: pd.DataFrame, test: pd.DataFrame) -> dict[str, Any]:
    """Fit every detector on ``train`` only and score ``test``."""
    contamination = None
    fit_df, test_x = features(spec, train), features(spec, test)
    out: dict[str, Any] = {"y": test[ANOMALY_COLUMN].to_numpy(), "scores": {}, "flags": {}}
    for det in all_detectors(ml_contamination=contamination, names=spec.detector_names):
        result = detect(test_x, det, fit_df=fit_df)
        out["scores"][det.name] = np.asarray(result.scores, dtype=float)
        out["flags"][det.name] = np.asarray(result.flags, dtype=bool)
        log.info("scored %s", det.name)
    return out


def x_score_partition__mutmut_2(spec: DatasetSpec, train: pd.DataFrame, test: pd.DataFrame) -> dict[str, Any]:
    """Fit every detector on ``train`` only and score ``test``."""
    contamination = float(None)
    fit_df, test_x = features(spec, train), features(spec, test)
    out: dict[str, Any] = {"y": test[ANOMALY_COLUMN].to_numpy(), "scores": {}, "flags": {}}
    for det in all_detectors(ml_contamination=contamination, names=spec.detector_names):
        result = detect(test_x, det, fit_df=fit_df)
        out["scores"][det.name] = np.asarray(result.scores, dtype=float)
        out["flags"][det.name] = np.asarray(result.flags, dtype=bool)
        log.info("scored %s", det.name)
    return out


def x_score_partition__mutmut_3(spec: DatasetSpec, train: pd.DataFrame, test: pd.DataFrame) -> dict[str, Any]:
    """Fit every detector on ``train`` only and score ``test``."""
    contamination = float(train[ANOMALY_COLUMN].mean())
    fit_df, test_x = None
    out: dict[str, Any] = {"y": test[ANOMALY_COLUMN].to_numpy(), "scores": {}, "flags": {}}
    for det in all_detectors(ml_contamination=contamination, names=spec.detector_names):
        result = detect(test_x, det, fit_df=fit_df)
        out["scores"][det.name] = np.asarray(result.scores, dtype=float)
        out["flags"][det.name] = np.asarray(result.flags, dtype=bool)
        log.info("scored %s", det.name)
    return out


def x_score_partition__mutmut_4(spec: DatasetSpec, train: pd.DataFrame, test: pd.DataFrame) -> dict[str, Any]:
    """Fit every detector on ``train`` only and score ``test``."""
    contamination = float(train[ANOMALY_COLUMN].mean())
    fit_df, test_x = features(None, train), features(spec, test)
    out: dict[str, Any] = {"y": test[ANOMALY_COLUMN].to_numpy(), "scores": {}, "flags": {}}
    for det in all_detectors(ml_contamination=contamination, names=spec.detector_names):
        result = detect(test_x, det, fit_df=fit_df)
        out["scores"][det.name] = np.asarray(result.scores, dtype=float)
        out["flags"][det.name] = np.asarray(result.flags, dtype=bool)
        log.info("scored %s", det.name)
    return out


def x_score_partition__mutmut_5(spec: DatasetSpec, train: pd.DataFrame, test: pd.DataFrame) -> dict[str, Any]:
    """Fit every detector on ``train`` only and score ``test``."""
    contamination = float(train[ANOMALY_COLUMN].mean())
    fit_df, test_x = features(spec, None), features(spec, test)
    out: dict[str, Any] = {"y": test[ANOMALY_COLUMN].to_numpy(), "scores": {}, "flags": {}}
    for det in all_detectors(ml_contamination=contamination, names=spec.detector_names):
        result = detect(test_x, det, fit_df=fit_df)
        out["scores"][det.name] = np.asarray(result.scores, dtype=float)
        out["flags"][det.name] = np.asarray(result.flags, dtype=bool)
        log.info("scored %s", det.name)
    return out


def x_score_partition__mutmut_6(spec: DatasetSpec, train: pd.DataFrame, test: pd.DataFrame) -> dict[str, Any]:
    """Fit every detector on ``train`` only and score ``test``."""
    contamination = float(train[ANOMALY_COLUMN].mean())
    fit_df, test_x = features(train), features(spec, test)
    out: dict[str, Any] = {"y": test[ANOMALY_COLUMN].to_numpy(), "scores": {}, "flags": {}}
    for det in all_detectors(ml_contamination=contamination, names=spec.detector_names):
        result = detect(test_x, det, fit_df=fit_df)
        out["scores"][det.name] = np.asarray(result.scores, dtype=float)
        out["flags"][det.name] = np.asarray(result.flags, dtype=bool)
        log.info("scored %s", det.name)
    return out


def x_score_partition__mutmut_7(spec: DatasetSpec, train: pd.DataFrame, test: pd.DataFrame) -> dict[str, Any]:
    """Fit every detector on ``train`` only and score ``test``."""
    contamination = float(train[ANOMALY_COLUMN].mean())
    fit_df, test_x = features(spec, ), features(spec, test)
    out: dict[str, Any] = {"y": test[ANOMALY_COLUMN].to_numpy(), "scores": {}, "flags": {}}
    for det in all_detectors(ml_contamination=contamination, names=spec.detector_names):
        result = detect(test_x, det, fit_df=fit_df)
        out["scores"][det.name] = np.asarray(result.scores, dtype=float)
        out["flags"][det.name] = np.asarray(result.flags, dtype=bool)
        log.info("scored %s", det.name)
    return out


def x_score_partition__mutmut_8(spec: DatasetSpec, train: pd.DataFrame, test: pd.DataFrame) -> dict[str, Any]:
    """Fit every detector on ``train`` only and score ``test``."""
    contamination = float(train[ANOMALY_COLUMN].mean())
    fit_df, test_x = features(spec, train), features(None, test)
    out: dict[str, Any] = {"y": test[ANOMALY_COLUMN].to_numpy(), "scores": {}, "flags": {}}
    for det in all_detectors(ml_contamination=contamination, names=spec.detector_names):
        result = detect(test_x, det, fit_df=fit_df)
        out["scores"][det.name] = np.asarray(result.scores, dtype=float)
        out["flags"][det.name] = np.asarray(result.flags, dtype=bool)
        log.info("scored %s", det.name)
    return out


def x_score_partition__mutmut_9(spec: DatasetSpec, train: pd.DataFrame, test: pd.DataFrame) -> dict[str, Any]:
    """Fit every detector on ``train`` only and score ``test``."""
    contamination = float(train[ANOMALY_COLUMN].mean())
    fit_df, test_x = features(spec, train), features(spec, None)
    out: dict[str, Any] = {"y": test[ANOMALY_COLUMN].to_numpy(), "scores": {}, "flags": {}}
    for det in all_detectors(ml_contamination=contamination, names=spec.detector_names):
        result = detect(test_x, det, fit_df=fit_df)
        out["scores"][det.name] = np.asarray(result.scores, dtype=float)
        out["flags"][det.name] = np.asarray(result.flags, dtype=bool)
        log.info("scored %s", det.name)
    return out


def x_score_partition__mutmut_10(spec: DatasetSpec, train: pd.DataFrame, test: pd.DataFrame) -> dict[str, Any]:
    """Fit every detector on ``train`` only and score ``test``."""
    contamination = float(train[ANOMALY_COLUMN].mean())
    fit_df, test_x = features(spec, train), features(test)
    out: dict[str, Any] = {"y": test[ANOMALY_COLUMN].to_numpy(), "scores": {}, "flags": {}}
    for det in all_detectors(ml_contamination=contamination, names=spec.detector_names):
        result = detect(test_x, det, fit_df=fit_df)
        out["scores"][det.name] = np.asarray(result.scores, dtype=float)
        out["flags"][det.name] = np.asarray(result.flags, dtype=bool)
        log.info("scored %s", det.name)
    return out


def x_score_partition__mutmut_11(spec: DatasetSpec, train: pd.DataFrame, test: pd.DataFrame) -> dict[str, Any]:
    """Fit every detector on ``train`` only and score ``test``."""
    contamination = float(train[ANOMALY_COLUMN].mean())
    fit_df, test_x = features(spec, train), features(spec, )
    out: dict[str, Any] = {"y": test[ANOMALY_COLUMN].to_numpy(), "scores": {}, "flags": {}}
    for det in all_detectors(ml_contamination=contamination, names=spec.detector_names):
        result = detect(test_x, det, fit_df=fit_df)
        out["scores"][det.name] = np.asarray(result.scores, dtype=float)
        out["flags"][det.name] = np.asarray(result.flags, dtype=bool)
        log.info("scored %s", det.name)
    return out


def x_score_partition__mutmut_12(spec: DatasetSpec, train: pd.DataFrame, test: pd.DataFrame) -> dict[str, Any]:
    """Fit every detector on ``train`` only and score ``test``."""
    contamination = float(train[ANOMALY_COLUMN].mean())
    fit_df, test_x = features(spec, train), features(spec, test)
    out: dict[str, Any] = None
    for det in all_detectors(ml_contamination=contamination, names=spec.detector_names):
        result = detect(test_x, det, fit_df=fit_df)
        out["scores"][det.name] = np.asarray(result.scores, dtype=float)
        out["flags"][det.name] = np.asarray(result.flags, dtype=bool)
        log.info("scored %s", det.name)
    return out


def x_score_partition__mutmut_13(spec: DatasetSpec, train: pd.DataFrame, test: pd.DataFrame) -> dict[str, Any]:
    """Fit every detector on ``train`` only and score ``test``."""
    contamination = float(train[ANOMALY_COLUMN].mean())
    fit_df, test_x = features(spec, train), features(spec, test)
    out: dict[str, Any] = {"XXyXX": test[ANOMALY_COLUMN].to_numpy(), "scores": {}, "flags": {}}
    for det in all_detectors(ml_contamination=contamination, names=spec.detector_names):
        result = detect(test_x, det, fit_df=fit_df)
        out["scores"][det.name] = np.asarray(result.scores, dtype=float)
        out["flags"][det.name] = np.asarray(result.flags, dtype=bool)
        log.info("scored %s", det.name)
    return out


def x_score_partition__mutmut_14(spec: DatasetSpec, train: pd.DataFrame, test: pd.DataFrame) -> dict[str, Any]:
    """Fit every detector on ``train`` only and score ``test``."""
    contamination = float(train[ANOMALY_COLUMN].mean())
    fit_df, test_x = features(spec, train), features(spec, test)
    out: dict[str, Any] = {"Y": test[ANOMALY_COLUMN].to_numpy(), "scores": {}, "flags": {}}
    for det in all_detectors(ml_contamination=contamination, names=spec.detector_names):
        result = detect(test_x, det, fit_df=fit_df)
        out["scores"][det.name] = np.asarray(result.scores, dtype=float)
        out["flags"][det.name] = np.asarray(result.flags, dtype=bool)
        log.info("scored %s", det.name)
    return out


def x_score_partition__mutmut_15(spec: DatasetSpec, train: pd.DataFrame, test: pd.DataFrame) -> dict[str, Any]:
    """Fit every detector on ``train`` only and score ``test``."""
    contamination = float(train[ANOMALY_COLUMN].mean())
    fit_df, test_x = features(spec, train), features(spec, test)
    out: dict[str, Any] = {"y": test[ANOMALY_COLUMN].to_numpy(), "XXscoresXX": {}, "flags": {}}
    for det in all_detectors(ml_contamination=contamination, names=spec.detector_names):
        result = detect(test_x, det, fit_df=fit_df)
        out["scores"][det.name] = np.asarray(result.scores, dtype=float)
        out["flags"][det.name] = np.asarray(result.flags, dtype=bool)
        log.info("scored %s", det.name)
    return out


def x_score_partition__mutmut_16(spec: DatasetSpec, train: pd.DataFrame, test: pd.DataFrame) -> dict[str, Any]:
    """Fit every detector on ``train`` only and score ``test``."""
    contamination = float(train[ANOMALY_COLUMN].mean())
    fit_df, test_x = features(spec, train), features(spec, test)
    out: dict[str, Any] = {"y": test[ANOMALY_COLUMN].to_numpy(), "SCORES": {}, "flags": {}}
    for det in all_detectors(ml_contamination=contamination, names=spec.detector_names):
        result = detect(test_x, det, fit_df=fit_df)
        out["scores"][det.name] = np.asarray(result.scores, dtype=float)
        out["flags"][det.name] = np.asarray(result.flags, dtype=bool)
        log.info("scored %s", det.name)
    return out


def x_score_partition__mutmut_17(spec: DatasetSpec, train: pd.DataFrame, test: pd.DataFrame) -> dict[str, Any]:
    """Fit every detector on ``train`` only and score ``test``."""
    contamination = float(train[ANOMALY_COLUMN].mean())
    fit_df, test_x = features(spec, train), features(spec, test)
    out: dict[str, Any] = {"y": test[ANOMALY_COLUMN].to_numpy(), "scores": {}, "XXflagsXX": {}}
    for det in all_detectors(ml_contamination=contamination, names=spec.detector_names):
        result = detect(test_x, det, fit_df=fit_df)
        out["scores"][det.name] = np.asarray(result.scores, dtype=float)
        out["flags"][det.name] = np.asarray(result.flags, dtype=bool)
        log.info("scored %s", det.name)
    return out


def x_score_partition__mutmut_18(spec: DatasetSpec, train: pd.DataFrame, test: pd.DataFrame) -> dict[str, Any]:
    """Fit every detector on ``train`` only and score ``test``."""
    contamination = float(train[ANOMALY_COLUMN].mean())
    fit_df, test_x = features(spec, train), features(spec, test)
    out: dict[str, Any] = {"y": test[ANOMALY_COLUMN].to_numpy(), "scores": {}, "FLAGS": {}}
    for det in all_detectors(ml_contamination=contamination, names=spec.detector_names):
        result = detect(test_x, det, fit_df=fit_df)
        out["scores"][det.name] = np.asarray(result.scores, dtype=float)
        out["flags"][det.name] = np.asarray(result.flags, dtype=bool)
        log.info("scored %s", det.name)
    return out


def x_score_partition__mutmut_19(spec: DatasetSpec, train: pd.DataFrame, test: pd.DataFrame) -> dict[str, Any]:
    """Fit every detector on ``train`` only and score ``test``."""
    contamination = float(train[ANOMALY_COLUMN].mean())
    fit_df, test_x = features(spec, train), features(spec, test)
    out: dict[str, Any] = {"y": test[ANOMALY_COLUMN].to_numpy(), "scores": {}, "flags": {}}
    for det in all_detectors(ml_contamination=None, names=spec.detector_names):
        result = detect(test_x, det, fit_df=fit_df)
        out["scores"][det.name] = np.asarray(result.scores, dtype=float)
        out["flags"][det.name] = np.asarray(result.flags, dtype=bool)
        log.info("scored %s", det.name)
    return out


def x_score_partition__mutmut_20(spec: DatasetSpec, train: pd.DataFrame, test: pd.DataFrame) -> dict[str, Any]:
    """Fit every detector on ``train`` only and score ``test``."""
    contamination = float(train[ANOMALY_COLUMN].mean())
    fit_df, test_x = features(spec, train), features(spec, test)
    out: dict[str, Any] = {"y": test[ANOMALY_COLUMN].to_numpy(), "scores": {}, "flags": {}}
    for det in all_detectors(ml_contamination=contamination, names=None):
        result = detect(test_x, det, fit_df=fit_df)
        out["scores"][det.name] = np.asarray(result.scores, dtype=float)
        out["flags"][det.name] = np.asarray(result.flags, dtype=bool)
        log.info("scored %s", det.name)
    return out


def x_score_partition__mutmut_21(spec: DatasetSpec, train: pd.DataFrame, test: pd.DataFrame) -> dict[str, Any]:
    """Fit every detector on ``train`` only and score ``test``."""
    contamination = float(train[ANOMALY_COLUMN].mean())
    fit_df, test_x = features(spec, train), features(spec, test)
    out: dict[str, Any] = {"y": test[ANOMALY_COLUMN].to_numpy(), "scores": {}, "flags": {}}
    for det in all_detectors(names=spec.detector_names):
        result = detect(test_x, det, fit_df=fit_df)
        out["scores"][det.name] = np.asarray(result.scores, dtype=float)
        out["flags"][det.name] = np.asarray(result.flags, dtype=bool)
        log.info("scored %s", det.name)
    return out


def x_score_partition__mutmut_22(spec: DatasetSpec, train: pd.DataFrame, test: pd.DataFrame) -> dict[str, Any]:
    """Fit every detector on ``train`` only and score ``test``."""
    contamination = float(train[ANOMALY_COLUMN].mean())
    fit_df, test_x = features(spec, train), features(spec, test)
    out: dict[str, Any] = {"y": test[ANOMALY_COLUMN].to_numpy(), "scores": {}, "flags": {}}
    for det in all_detectors(ml_contamination=contamination, ):
        result = detect(test_x, det, fit_df=fit_df)
        out["scores"][det.name] = np.asarray(result.scores, dtype=float)
        out["flags"][det.name] = np.asarray(result.flags, dtype=bool)
        log.info("scored %s", det.name)
    return out


def x_score_partition__mutmut_23(spec: DatasetSpec, train: pd.DataFrame, test: pd.DataFrame) -> dict[str, Any]:
    """Fit every detector on ``train`` only and score ``test``."""
    contamination = float(train[ANOMALY_COLUMN].mean())
    fit_df, test_x = features(spec, train), features(spec, test)
    out: dict[str, Any] = {"y": test[ANOMALY_COLUMN].to_numpy(), "scores": {}, "flags": {}}
    for det in all_detectors(ml_contamination=contamination, names=spec.detector_names):
        result = None
        out["scores"][det.name] = np.asarray(result.scores, dtype=float)
        out["flags"][det.name] = np.asarray(result.flags, dtype=bool)
        log.info("scored %s", det.name)
    return out


def x_score_partition__mutmut_24(spec: DatasetSpec, train: pd.DataFrame, test: pd.DataFrame) -> dict[str, Any]:
    """Fit every detector on ``train`` only and score ``test``."""
    contamination = float(train[ANOMALY_COLUMN].mean())
    fit_df, test_x = features(spec, train), features(spec, test)
    out: dict[str, Any] = {"y": test[ANOMALY_COLUMN].to_numpy(), "scores": {}, "flags": {}}
    for det in all_detectors(ml_contamination=contamination, names=spec.detector_names):
        result = detect(None, det, fit_df=fit_df)
        out["scores"][det.name] = np.asarray(result.scores, dtype=float)
        out["flags"][det.name] = np.asarray(result.flags, dtype=bool)
        log.info("scored %s", det.name)
    return out


def x_score_partition__mutmut_25(spec: DatasetSpec, train: pd.DataFrame, test: pd.DataFrame) -> dict[str, Any]:
    """Fit every detector on ``train`` only and score ``test``."""
    contamination = float(train[ANOMALY_COLUMN].mean())
    fit_df, test_x = features(spec, train), features(spec, test)
    out: dict[str, Any] = {"y": test[ANOMALY_COLUMN].to_numpy(), "scores": {}, "flags": {}}
    for det in all_detectors(ml_contamination=contamination, names=spec.detector_names):
        result = detect(test_x, None, fit_df=fit_df)
        out["scores"][det.name] = np.asarray(result.scores, dtype=float)
        out["flags"][det.name] = np.asarray(result.flags, dtype=bool)
        log.info("scored %s", det.name)
    return out


def x_score_partition__mutmut_26(spec: DatasetSpec, train: pd.DataFrame, test: pd.DataFrame) -> dict[str, Any]:
    """Fit every detector on ``train`` only and score ``test``."""
    contamination = float(train[ANOMALY_COLUMN].mean())
    fit_df, test_x = features(spec, train), features(spec, test)
    out: dict[str, Any] = {"y": test[ANOMALY_COLUMN].to_numpy(), "scores": {}, "flags": {}}
    for det in all_detectors(ml_contamination=contamination, names=spec.detector_names):
        result = detect(test_x, det, fit_df=None)
        out["scores"][det.name] = np.asarray(result.scores, dtype=float)
        out["flags"][det.name] = np.asarray(result.flags, dtype=bool)
        log.info("scored %s", det.name)
    return out


def x_score_partition__mutmut_27(spec: DatasetSpec, train: pd.DataFrame, test: pd.DataFrame) -> dict[str, Any]:
    """Fit every detector on ``train`` only and score ``test``."""
    contamination = float(train[ANOMALY_COLUMN].mean())
    fit_df, test_x = features(spec, train), features(spec, test)
    out: dict[str, Any] = {"y": test[ANOMALY_COLUMN].to_numpy(), "scores": {}, "flags": {}}
    for det in all_detectors(ml_contamination=contamination, names=spec.detector_names):
        result = detect(det, fit_df=fit_df)
        out["scores"][det.name] = np.asarray(result.scores, dtype=float)
        out["flags"][det.name] = np.asarray(result.flags, dtype=bool)
        log.info("scored %s", det.name)
    return out


def x_score_partition__mutmut_28(spec: DatasetSpec, train: pd.DataFrame, test: pd.DataFrame) -> dict[str, Any]:
    """Fit every detector on ``train`` only and score ``test``."""
    contamination = float(train[ANOMALY_COLUMN].mean())
    fit_df, test_x = features(spec, train), features(spec, test)
    out: dict[str, Any] = {"y": test[ANOMALY_COLUMN].to_numpy(), "scores": {}, "flags": {}}
    for det in all_detectors(ml_contamination=contamination, names=spec.detector_names):
        result = detect(test_x, fit_df=fit_df)
        out["scores"][det.name] = np.asarray(result.scores, dtype=float)
        out["flags"][det.name] = np.asarray(result.flags, dtype=bool)
        log.info("scored %s", det.name)
    return out


def x_score_partition__mutmut_29(spec: DatasetSpec, train: pd.DataFrame, test: pd.DataFrame) -> dict[str, Any]:
    """Fit every detector on ``train`` only and score ``test``."""
    contamination = float(train[ANOMALY_COLUMN].mean())
    fit_df, test_x = features(spec, train), features(spec, test)
    out: dict[str, Any] = {"y": test[ANOMALY_COLUMN].to_numpy(), "scores": {}, "flags": {}}
    for det in all_detectors(ml_contamination=contamination, names=spec.detector_names):
        result = detect(test_x, det, )
        out["scores"][det.name] = np.asarray(result.scores, dtype=float)
        out["flags"][det.name] = np.asarray(result.flags, dtype=bool)
        log.info("scored %s", det.name)
    return out


def x_score_partition__mutmut_30(spec: DatasetSpec, train: pd.DataFrame, test: pd.DataFrame) -> dict[str, Any]:
    """Fit every detector on ``train`` only and score ``test``."""
    contamination = float(train[ANOMALY_COLUMN].mean())
    fit_df, test_x = features(spec, train), features(spec, test)
    out: dict[str, Any] = {"y": test[ANOMALY_COLUMN].to_numpy(), "scores": {}, "flags": {}}
    for det in all_detectors(ml_contamination=contamination, names=spec.detector_names):
        result = detect(test_x, det, fit_df=fit_df)
        out["scores"][det.name] = None
        out["flags"][det.name] = np.asarray(result.flags, dtype=bool)
        log.info("scored %s", det.name)
    return out


def x_score_partition__mutmut_31(spec: DatasetSpec, train: pd.DataFrame, test: pd.DataFrame) -> dict[str, Any]:
    """Fit every detector on ``train`` only and score ``test``."""
    contamination = float(train[ANOMALY_COLUMN].mean())
    fit_df, test_x = features(spec, train), features(spec, test)
    out: dict[str, Any] = {"y": test[ANOMALY_COLUMN].to_numpy(), "scores": {}, "flags": {}}
    for det in all_detectors(ml_contamination=contamination, names=spec.detector_names):
        result = detect(test_x, det, fit_df=fit_df)
        out["XXscoresXX"][det.name] = np.asarray(result.scores, dtype=float)
        out["flags"][det.name] = np.asarray(result.flags, dtype=bool)
        log.info("scored %s", det.name)
    return out


def x_score_partition__mutmut_32(spec: DatasetSpec, train: pd.DataFrame, test: pd.DataFrame) -> dict[str, Any]:
    """Fit every detector on ``train`` only and score ``test``."""
    contamination = float(train[ANOMALY_COLUMN].mean())
    fit_df, test_x = features(spec, train), features(spec, test)
    out: dict[str, Any] = {"y": test[ANOMALY_COLUMN].to_numpy(), "scores": {}, "flags": {}}
    for det in all_detectors(ml_contamination=contamination, names=spec.detector_names):
        result = detect(test_x, det, fit_df=fit_df)
        out["SCORES"][det.name] = np.asarray(result.scores, dtype=float)
        out["flags"][det.name] = np.asarray(result.flags, dtype=bool)
        log.info("scored %s", det.name)
    return out


def x_score_partition__mutmut_33(spec: DatasetSpec, train: pd.DataFrame, test: pd.DataFrame) -> dict[str, Any]:
    """Fit every detector on ``train`` only and score ``test``."""
    contamination = float(train[ANOMALY_COLUMN].mean())
    fit_df, test_x = features(spec, train), features(spec, test)
    out: dict[str, Any] = {"y": test[ANOMALY_COLUMN].to_numpy(), "scores": {}, "flags": {}}
    for det in all_detectors(ml_contamination=contamination, names=spec.detector_names):
        result = detect(test_x, det, fit_df=fit_df)
        out["scores"][det.name] = np.asarray(None, dtype=float)
        out["flags"][det.name] = np.asarray(result.flags, dtype=bool)
        log.info("scored %s", det.name)
    return out


def x_score_partition__mutmut_34(spec: DatasetSpec, train: pd.DataFrame, test: pd.DataFrame) -> dict[str, Any]:
    """Fit every detector on ``train`` only and score ``test``."""
    contamination = float(train[ANOMALY_COLUMN].mean())
    fit_df, test_x = features(spec, train), features(spec, test)
    out: dict[str, Any] = {"y": test[ANOMALY_COLUMN].to_numpy(), "scores": {}, "flags": {}}
    for det in all_detectors(ml_contamination=contamination, names=spec.detector_names):
        result = detect(test_x, det, fit_df=fit_df)
        out["scores"][det.name] = np.asarray(result.scores, dtype=None)
        out["flags"][det.name] = np.asarray(result.flags, dtype=bool)
        log.info("scored %s", det.name)
    return out


def x_score_partition__mutmut_35(spec: DatasetSpec, train: pd.DataFrame, test: pd.DataFrame) -> dict[str, Any]:
    """Fit every detector on ``train`` only and score ``test``."""
    contamination = float(train[ANOMALY_COLUMN].mean())
    fit_df, test_x = features(spec, train), features(spec, test)
    out: dict[str, Any] = {"y": test[ANOMALY_COLUMN].to_numpy(), "scores": {}, "flags": {}}
    for det in all_detectors(ml_contamination=contamination, names=spec.detector_names):
        result = detect(test_x, det, fit_df=fit_df)
        out["scores"][det.name] = np.asarray(dtype=float)
        out["flags"][det.name] = np.asarray(result.flags, dtype=bool)
        log.info("scored %s", det.name)
    return out


def x_score_partition__mutmut_36(spec: DatasetSpec, train: pd.DataFrame, test: pd.DataFrame) -> dict[str, Any]:
    """Fit every detector on ``train`` only and score ``test``."""
    contamination = float(train[ANOMALY_COLUMN].mean())
    fit_df, test_x = features(spec, train), features(spec, test)
    out: dict[str, Any] = {"y": test[ANOMALY_COLUMN].to_numpy(), "scores": {}, "flags": {}}
    for det in all_detectors(ml_contamination=contamination, names=spec.detector_names):
        result = detect(test_x, det, fit_df=fit_df)
        out["scores"][det.name] = np.asarray(result.scores, )
        out["flags"][det.name] = np.asarray(result.flags, dtype=bool)
        log.info("scored %s", det.name)
    return out


def x_score_partition__mutmut_37(spec: DatasetSpec, train: pd.DataFrame, test: pd.DataFrame) -> dict[str, Any]:
    """Fit every detector on ``train`` only and score ``test``."""
    contamination = float(train[ANOMALY_COLUMN].mean())
    fit_df, test_x = features(spec, train), features(spec, test)
    out: dict[str, Any] = {"y": test[ANOMALY_COLUMN].to_numpy(), "scores": {}, "flags": {}}
    for det in all_detectors(ml_contamination=contamination, names=spec.detector_names):
        result = detect(test_x, det, fit_df=fit_df)
        out["scores"][det.name] = np.asarray(result.scores, dtype=float)
        out["flags"][det.name] = None
        log.info("scored %s", det.name)
    return out


def x_score_partition__mutmut_38(spec: DatasetSpec, train: pd.DataFrame, test: pd.DataFrame) -> dict[str, Any]:
    """Fit every detector on ``train`` only and score ``test``."""
    contamination = float(train[ANOMALY_COLUMN].mean())
    fit_df, test_x = features(spec, train), features(spec, test)
    out: dict[str, Any] = {"y": test[ANOMALY_COLUMN].to_numpy(), "scores": {}, "flags": {}}
    for det in all_detectors(ml_contamination=contamination, names=spec.detector_names):
        result = detect(test_x, det, fit_df=fit_df)
        out["scores"][det.name] = np.asarray(result.scores, dtype=float)
        out["XXflagsXX"][det.name] = np.asarray(result.flags, dtype=bool)
        log.info("scored %s", det.name)
    return out


def x_score_partition__mutmut_39(spec: DatasetSpec, train: pd.DataFrame, test: pd.DataFrame) -> dict[str, Any]:
    """Fit every detector on ``train`` only and score ``test``."""
    contamination = float(train[ANOMALY_COLUMN].mean())
    fit_df, test_x = features(spec, train), features(spec, test)
    out: dict[str, Any] = {"y": test[ANOMALY_COLUMN].to_numpy(), "scores": {}, "flags": {}}
    for det in all_detectors(ml_contamination=contamination, names=spec.detector_names):
        result = detect(test_x, det, fit_df=fit_df)
        out["scores"][det.name] = np.asarray(result.scores, dtype=float)
        out["FLAGS"][det.name] = np.asarray(result.flags, dtype=bool)
        log.info("scored %s", det.name)
    return out


def x_score_partition__mutmut_40(spec: DatasetSpec, train: pd.DataFrame, test: pd.DataFrame) -> dict[str, Any]:
    """Fit every detector on ``train`` only and score ``test``."""
    contamination = float(train[ANOMALY_COLUMN].mean())
    fit_df, test_x = features(spec, train), features(spec, test)
    out: dict[str, Any] = {"y": test[ANOMALY_COLUMN].to_numpy(), "scores": {}, "flags": {}}
    for det in all_detectors(ml_contamination=contamination, names=spec.detector_names):
        result = detect(test_x, det, fit_df=fit_df)
        out["scores"][det.name] = np.asarray(result.scores, dtype=float)
        out["flags"][det.name] = np.asarray(None, dtype=bool)
        log.info("scored %s", det.name)
    return out


def x_score_partition__mutmut_41(spec: DatasetSpec, train: pd.DataFrame, test: pd.DataFrame) -> dict[str, Any]:
    """Fit every detector on ``train`` only and score ``test``."""
    contamination = float(train[ANOMALY_COLUMN].mean())
    fit_df, test_x = features(spec, train), features(spec, test)
    out: dict[str, Any] = {"y": test[ANOMALY_COLUMN].to_numpy(), "scores": {}, "flags": {}}
    for det in all_detectors(ml_contamination=contamination, names=spec.detector_names):
        result = detect(test_x, det, fit_df=fit_df)
        out["scores"][det.name] = np.asarray(result.scores, dtype=float)
        out["flags"][det.name] = np.asarray(result.flags, dtype=None)
        log.info("scored %s", det.name)
    return out


def x_score_partition__mutmut_42(spec: DatasetSpec, train: pd.DataFrame, test: pd.DataFrame) -> dict[str, Any]:
    """Fit every detector on ``train`` only and score ``test``."""
    contamination = float(train[ANOMALY_COLUMN].mean())
    fit_df, test_x = features(spec, train), features(spec, test)
    out: dict[str, Any] = {"y": test[ANOMALY_COLUMN].to_numpy(), "scores": {}, "flags": {}}
    for det in all_detectors(ml_contamination=contamination, names=spec.detector_names):
        result = detect(test_x, det, fit_df=fit_df)
        out["scores"][det.name] = np.asarray(result.scores, dtype=float)
        out["flags"][det.name] = np.asarray(dtype=bool)
        log.info("scored %s", det.name)
    return out


def x_score_partition__mutmut_43(spec: DatasetSpec, train: pd.DataFrame, test: pd.DataFrame) -> dict[str, Any]:
    """Fit every detector on ``train`` only and score ``test``."""
    contamination = float(train[ANOMALY_COLUMN].mean())
    fit_df, test_x = features(spec, train), features(spec, test)
    out: dict[str, Any] = {"y": test[ANOMALY_COLUMN].to_numpy(), "scores": {}, "flags": {}}
    for det in all_detectors(ml_contamination=contamination, names=spec.detector_names):
        result = detect(test_x, det, fit_df=fit_df)
        out["scores"][det.name] = np.asarray(result.scores, dtype=float)
        out["flags"][det.name] = np.asarray(result.flags, )
        log.info("scored %s", det.name)
    return out


def x_score_partition__mutmut_44(spec: DatasetSpec, train: pd.DataFrame, test: pd.DataFrame) -> dict[str, Any]:
    """Fit every detector on ``train`` only and score ``test``."""
    contamination = float(train[ANOMALY_COLUMN].mean())
    fit_df, test_x = features(spec, train), features(spec, test)
    out: dict[str, Any] = {"y": test[ANOMALY_COLUMN].to_numpy(), "scores": {}, "flags": {}}
    for det in all_detectors(ml_contamination=contamination, names=spec.detector_names):
        result = detect(test_x, det, fit_df=fit_df)
        out["scores"][det.name] = np.asarray(result.scores, dtype=float)
        out["flags"][det.name] = np.asarray(result.flags, dtype=bool)
        log.info(None, det.name)
    return out


def x_score_partition__mutmut_45(spec: DatasetSpec, train: pd.DataFrame, test: pd.DataFrame) -> dict[str, Any]:
    """Fit every detector on ``train`` only and score ``test``."""
    contamination = float(train[ANOMALY_COLUMN].mean())
    fit_df, test_x = features(spec, train), features(spec, test)
    out: dict[str, Any] = {"y": test[ANOMALY_COLUMN].to_numpy(), "scores": {}, "flags": {}}
    for det in all_detectors(ml_contamination=contamination, names=spec.detector_names):
        result = detect(test_x, det, fit_df=fit_df)
        out["scores"][det.name] = np.asarray(result.scores, dtype=float)
        out["flags"][det.name] = np.asarray(result.flags, dtype=bool)
        log.info("scored %s", None)
    return out


def x_score_partition__mutmut_46(spec: DatasetSpec, train: pd.DataFrame, test: pd.DataFrame) -> dict[str, Any]:
    """Fit every detector on ``train`` only and score ``test``."""
    contamination = float(train[ANOMALY_COLUMN].mean())
    fit_df, test_x = features(spec, train), features(spec, test)
    out: dict[str, Any] = {"y": test[ANOMALY_COLUMN].to_numpy(), "scores": {}, "flags": {}}
    for det in all_detectors(ml_contamination=contamination, names=spec.detector_names):
        result = detect(test_x, det, fit_df=fit_df)
        out["scores"][det.name] = np.asarray(result.scores, dtype=float)
        out["flags"][det.name] = np.asarray(result.flags, dtype=bool)
        log.info(det.name)
    return out


def x_score_partition__mutmut_47(spec: DatasetSpec, train: pd.DataFrame, test: pd.DataFrame) -> dict[str, Any]:
    """Fit every detector on ``train`` only and score ``test``."""
    contamination = float(train[ANOMALY_COLUMN].mean())
    fit_df, test_x = features(spec, train), features(spec, test)
    out: dict[str, Any] = {"y": test[ANOMALY_COLUMN].to_numpy(), "scores": {}, "flags": {}}
    for det in all_detectors(ml_contamination=contamination, names=spec.detector_names):
        result = detect(test_x, det, fit_df=fit_df)
        out["scores"][det.name] = np.asarray(result.scores, dtype=float)
        out["flags"][det.name] = np.asarray(result.flags, dtype=bool)
        log.info("scored %s", )
    return out


def x_score_partition__mutmut_48(spec: DatasetSpec, train: pd.DataFrame, test: pd.DataFrame) -> dict[str, Any]:
    """Fit every detector on ``train`` only and score ``test``."""
    contamination = float(train[ANOMALY_COLUMN].mean())
    fit_df, test_x = features(spec, train), features(spec, test)
    out: dict[str, Any] = {"y": test[ANOMALY_COLUMN].to_numpy(), "scores": {}, "flags": {}}
    for det in all_detectors(ml_contamination=contamination, names=spec.detector_names):
        result = detect(test_x, det, fit_df=fit_df)
        out["scores"][det.name] = np.asarray(result.scores, dtype=float)
        out["flags"][det.name] = np.asarray(result.flags, dtype=bool)
        log.info("XXscored %sXX", det.name)
    return out


def x_score_partition__mutmut_49(spec: DatasetSpec, train: pd.DataFrame, test: pd.DataFrame) -> dict[str, Any]:
    """Fit every detector on ``train`` only and score ``test``."""
    contamination = float(train[ANOMALY_COLUMN].mean())
    fit_df, test_x = features(spec, train), features(spec, test)
    out: dict[str, Any] = {"y": test[ANOMALY_COLUMN].to_numpy(), "scores": {}, "flags": {}}
    for det in all_detectors(ml_contamination=contamination, names=spec.detector_names):
        result = detect(test_x, det, fit_df=fit_df)
        out["scores"][det.name] = np.asarray(result.scores, dtype=float)
        out["flags"][det.name] = np.asarray(result.flags, dtype=bool)
        log.info("SCORED %S", det.name)
    return out

mutants_x_score_partition__mutmut['_mutmut_orig'] = x_score_partition__mutmut_orig # type: ignore # mutmut generated
mutants_x_score_partition__mutmut['x_score_partition__mutmut_1'] = x_score_partition__mutmut_1 # type: ignore # mutmut generated
mutants_x_score_partition__mutmut['x_score_partition__mutmut_2'] = x_score_partition__mutmut_2 # type: ignore # mutmut generated
mutants_x_score_partition__mutmut['x_score_partition__mutmut_3'] = x_score_partition__mutmut_3 # type: ignore # mutmut generated
mutants_x_score_partition__mutmut['x_score_partition__mutmut_4'] = x_score_partition__mutmut_4 # type: ignore # mutmut generated
mutants_x_score_partition__mutmut['x_score_partition__mutmut_5'] = x_score_partition__mutmut_5 # type: ignore # mutmut generated
mutants_x_score_partition__mutmut['x_score_partition__mutmut_6'] = x_score_partition__mutmut_6 # type: ignore # mutmut generated
mutants_x_score_partition__mutmut['x_score_partition__mutmut_7'] = x_score_partition__mutmut_7 # type: ignore # mutmut generated
mutants_x_score_partition__mutmut['x_score_partition__mutmut_8'] = x_score_partition__mutmut_8 # type: ignore # mutmut generated
mutants_x_score_partition__mutmut['x_score_partition__mutmut_9'] = x_score_partition__mutmut_9 # type: ignore # mutmut generated
mutants_x_score_partition__mutmut['x_score_partition__mutmut_10'] = x_score_partition__mutmut_10 # type: ignore # mutmut generated
mutants_x_score_partition__mutmut['x_score_partition__mutmut_11'] = x_score_partition__mutmut_11 # type: ignore # mutmut generated
mutants_x_score_partition__mutmut['x_score_partition__mutmut_12'] = x_score_partition__mutmut_12 # type: ignore # mutmut generated
mutants_x_score_partition__mutmut['x_score_partition__mutmut_13'] = x_score_partition__mutmut_13 # type: ignore # mutmut generated
mutants_x_score_partition__mutmut['x_score_partition__mutmut_14'] = x_score_partition__mutmut_14 # type: ignore # mutmut generated
mutants_x_score_partition__mutmut['x_score_partition__mutmut_15'] = x_score_partition__mutmut_15 # type: ignore # mutmut generated
mutants_x_score_partition__mutmut['x_score_partition__mutmut_16'] = x_score_partition__mutmut_16 # type: ignore # mutmut generated
mutants_x_score_partition__mutmut['x_score_partition__mutmut_17'] = x_score_partition__mutmut_17 # type: ignore # mutmut generated
mutants_x_score_partition__mutmut['x_score_partition__mutmut_18'] = x_score_partition__mutmut_18 # type: ignore # mutmut generated
mutants_x_score_partition__mutmut['x_score_partition__mutmut_19'] = x_score_partition__mutmut_19 # type: ignore # mutmut generated
mutants_x_score_partition__mutmut['x_score_partition__mutmut_20'] = x_score_partition__mutmut_20 # type: ignore # mutmut generated
mutants_x_score_partition__mutmut['x_score_partition__mutmut_21'] = x_score_partition__mutmut_21 # type: ignore # mutmut generated
mutants_x_score_partition__mutmut['x_score_partition__mutmut_22'] = x_score_partition__mutmut_22 # type: ignore # mutmut generated
mutants_x_score_partition__mutmut['x_score_partition__mutmut_23'] = x_score_partition__mutmut_23 # type: ignore # mutmut generated
mutants_x_score_partition__mutmut['x_score_partition__mutmut_24'] = x_score_partition__mutmut_24 # type: ignore # mutmut generated
mutants_x_score_partition__mutmut['x_score_partition__mutmut_25'] = x_score_partition__mutmut_25 # type: ignore # mutmut generated
mutants_x_score_partition__mutmut['x_score_partition__mutmut_26'] = x_score_partition__mutmut_26 # type: ignore # mutmut generated
mutants_x_score_partition__mutmut['x_score_partition__mutmut_27'] = x_score_partition__mutmut_27 # type: ignore # mutmut generated
mutants_x_score_partition__mutmut['x_score_partition__mutmut_28'] = x_score_partition__mutmut_28 # type: ignore # mutmut generated
mutants_x_score_partition__mutmut['x_score_partition__mutmut_29'] = x_score_partition__mutmut_29 # type: ignore # mutmut generated
mutants_x_score_partition__mutmut['x_score_partition__mutmut_30'] = x_score_partition__mutmut_30 # type: ignore # mutmut generated
mutants_x_score_partition__mutmut['x_score_partition__mutmut_31'] = x_score_partition__mutmut_31 # type: ignore # mutmut generated
mutants_x_score_partition__mutmut['x_score_partition__mutmut_32'] = x_score_partition__mutmut_32 # type: ignore # mutmut generated
mutants_x_score_partition__mutmut['x_score_partition__mutmut_33'] = x_score_partition__mutmut_33 # type: ignore # mutmut generated
mutants_x_score_partition__mutmut['x_score_partition__mutmut_34'] = x_score_partition__mutmut_34 # type: ignore # mutmut generated
mutants_x_score_partition__mutmut['x_score_partition__mutmut_35'] = x_score_partition__mutmut_35 # type: ignore # mutmut generated
mutants_x_score_partition__mutmut['x_score_partition__mutmut_36'] = x_score_partition__mutmut_36 # type: ignore # mutmut generated
mutants_x_score_partition__mutmut['x_score_partition__mutmut_37'] = x_score_partition__mutmut_37 # type: ignore # mutmut generated
mutants_x_score_partition__mutmut['x_score_partition__mutmut_38'] = x_score_partition__mutmut_38 # type: ignore # mutmut generated
mutants_x_score_partition__mutmut['x_score_partition__mutmut_39'] = x_score_partition__mutmut_39 # type: ignore # mutmut generated
mutants_x_score_partition__mutmut['x_score_partition__mutmut_40'] = x_score_partition__mutmut_40 # type: ignore # mutmut generated
mutants_x_score_partition__mutmut['x_score_partition__mutmut_41'] = x_score_partition__mutmut_41 # type: ignore # mutmut generated
mutants_x_score_partition__mutmut['x_score_partition__mutmut_42'] = x_score_partition__mutmut_42 # type: ignore # mutmut generated
mutants_x_score_partition__mutmut['x_score_partition__mutmut_43'] = x_score_partition__mutmut_43 # type: ignore # mutmut generated
mutants_x_score_partition__mutmut['x_score_partition__mutmut_44'] = x_score_partition__mutmut_44 # type: ignore # mutmut generated
mutants_x_score_partition__mutmut['x_score_partition__mutmut_45'] = x_score_partition__mutmut_45 # type: ignore # mutmut generated
mutants_x_score_partition__mutmut['x_score_partition__mutmut_46'] = x_score_partition__mutmut_46 # type: ignore # mutmut generated
mutants_x_score_partition__mutmut['x_score_partition__mutmut_47'] = x_score_partition__mutmut_47 # type: ignore # mutmut generated
mutants_x_score_partition__mutmut['x_score_partition__mutmut_48'] = x_score_partition__mutmut_48 # type: ignore # mutmut generated
mutants_x_score_partition__mutmut['x_score_partition__mutmut_49'] = x_score_partition__mutmut_49 # type: ignore # mutmut generated
mutants_x_time_blocks__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_time_blocks__mutmut)
def time_blocks(times: pd.Series, block_seconds: int) -> np.ndarray:
    seconds = (pd.to_datetime(times, utc=True) - ORIGIN).dt.total_seconds()
    return (seconds // block_seconds).astype(int).to_numpy()


def x_time_blocks__mutmut_orig(times: pd.Series, block_seconds: int) -> np.ndarray:
    seconds = (pd.to_datetime(times, utc=True) - ORIGIN).dt.total_seconds()
    return (seconds // block_seconds).astype(int).to_numpy()


def x_time_blocks__mutmut_1(times: pd.Series, block_seconds: int) -> np.ndarray:
    seconds = None
    return (seconds // block_seconds).astype(int).to_numpy()


def x_time_blocks__mutmut_2(times: pd.Series, block_seconds: int) -> np.ndarray:
    seconds = (pd.to_datetime(times, utc=True) + ORIGIN).dt.total_seconds()
    return (seconds // block_seconds).astype(int).to_numpy()


def x_time_blocks__mutmut_3(times: pd.Series, block_seconds: int) -> np.ndarray:
    seconds = (pd.to_datetime(None, utc=True) - ORIGIN).dt.total_seconds()
    return (seconds // block_seconds).astype(int).to_numpy()


def x_time_blocks__mutmut_4(times: pd.Series, block_seconds: int) -> np.ndarray:
    seconds = (pd.to_datetime(times, utc=None) - ORIGIN).dt.total_seconds()
    return (seconds // block_seconds).astype(int).to_numpy()


def x_time_blocks__mutmut_5(times: pd.Series, block_seconds: int) -> np.ndarray:
    seconds = (pd.to_datetime(utc=True) - ORIGIN).dt.total_seconds()
    return (seconds // block_seconds).astype(int).to_numpy()


def x_time_blocks__mutmut_6(times: pd.Series, block_seconds: int) -> np.ndarray:
    seconds = (pd.to_datetime(times, ) - ORIGIN).dt.total_seconds()
    return (seconds // block_seconds).astype(int).to_numpy()


def x_time_blocks__mutmut_7(times: pd.Series, block_seconds: int) -> np.ndarray:
    seconds = (pd.to_datetime(times, utc=False) - ORIGIN).dt.total_seconds()
    return (seconds // block_seconds).astype(int).to_numpy()


def x_time_blocks__mutmut_8(times: pd.Series, block_seconds: int) -> np.ndarray:
    seconds = (pd.to_datetime(times, utc=True) - ORIGIN).dt.total_seconds()
    return (seconds // block_seconds).astype(None).to_numpy()


def x_time_blocks__mutmut_9(times: pd.Series, block_seconds: int) -> np.ndarray:
    seconds = (pd.to_datetime(times, utc=True) - ORIGIN).dt.total_seconds()
    return (seconds / block_seconds).astype(int).to_numpy()

mutants_x_time_blocks__mutmut['_mutmut_orig'] = x_time_blocks__mutmut_orig # type: ignore # mutmut generated
mutants_x_time_blocks__mutmut['x_time_blocks__mutmut_1'] = x_time_blocks__mutmut_1 # type: ignore # mutmut generated
mutants_x_time_blocks__mutmut['x_time_blocks__mutmut_2'] = x_time_blocks__mutmut_2 # type: ignore # mutmut generated
mutants_x_time_blocks__mutmut['x_time_blocks__mutmut_3'] = x_time_blocks__mutmut_3 # type: ignore # mutmut generated
mutants_x_time_blocks__mutmut['x_time_blocks__mutmut_4'] = x_time_blocks__mutmut_4 # type: ignore # mutmut generated
mutants_x_time_blocks__mutmut['x_time_blocks__mutmut_5'] = x_time_blocks__mutmut_5 # type: ignore # mutmut generated
mutants_x_time_blocks__mutmut['x_time_blocks__mutmut_6'] = x_time_blocks__mutmut_6 # type: ignore # mutmut generated
mutants_x_time_blocks__mutmut['x_time_blocks__mutmut_7'] = x_time_blocks__mutmut_7 # type: ignore # mutmut generated
mutants_x_time_blocks__mutmut['x_time_blocks__mutmut_8'] = x_time_blocks__mutmut_8 # type: ignore # mutmut generated
mutants_x_time_blocks__mutmut['x_time_blocks__mutmut_9'] = x_time_blocks__mutmut_9 # type: ignore # mutmut generated
mutants_x_block_bootstrap_ci__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_block_bootstrap_ci__mutmut)
def block_bootstrap_ci(y, scores, times, block_seconds, resamples, seed) -> dict[str, float]:
    """Percentile interval of average precision, resampling whole blocks of time."""
    y, scores = np.asarray(y), np.asarray(scores, dtype=float)
    if len(y) != len(scores) or len(y) != len(times):
        raise ValueError("labels, scores and times must have equal length")
    if y.min() == y.max():
        raise ValueError("both classes are required")
    blocks = time_blocks(times, block_seconds)
    members = {b: np.flatnonzero(blocks == b) for b in np.unique(blocks)}
    keys = list(members)
    rng = np.random.default_rng(seed)
    values = []
    for _ in range(resamples):
        chosen = rng.choice(len(keys), size=len(keys), replace=True)
        index = np.concatenate([members[keys[k]] for k in chosen])
        if y[index].min() != y[index].max():
            values.append(average_precision_score(y[index], scores[index]))
    low, high = np.percentile(values, [2.5, 97.5])
    return {
        "estimate": float(average_precision_score(y, scores)),
        "ci_low": float(low),
        "ci_high": float(high),
        "resamples_used": len(values),
    }


def x_block_bootstrap_ci__mutmut_orig(y, scores, times, block_seconds, resamples, seed) -> dict[str, float]:
    """Percentile interval of average precision, resampling whole blocks of time."""
    y, scores = np.asarray(y), np.asarray(scores, dtype=float)
    if len(y) != len(scores) or len(y) != len(times):
        raise ValueError("labels, scores and times must have equal length")
    if y.min() == y.max():
        raise ValueError("both classes are required")
    blocks = time_blocks(times, block_seconds)
    members = {b: np.flatnonzero(blocks == b) for b in np.unique(blocks)}
    keys = list(members)
    rng = np.random.default_rng(seed)
    values = []
    for _ in range(resamples):
        chosen = rng.choice(len(keys), size=len(keys), replace=True)
        index = np.concatenate([members[keys[k]] for k in chosen])
        if y[index].min() != y[index].max():
            values.append(average_precision_score(y[index], scores[index]))
    low, high = np.percentile(values, [2.5, 97.5])
    return {
        "estimate": float(average_precision_score(y, scores)),
        "ci_low": float(low),
        "ci_high": float(high),
        "resamples_used": len(values),
    }


def x_block_bootstrap_ci__mutmut_1(y, scores, times, block_seconds, resamples, seed) -> dict[str, float]:
    """Percentile interval of average precision, resampling whole blocks of time."""
    y, scores = None
    if len(y) != len(scores) or len(y) != len(times):
        raise ValueError("labels, scores and times must have equal length")
    if y.min() == y.max():
        raise ValueError("both classes are required")
    blocks = time_blocks(times, block_seconds)
    members = {b: np.flatnonzero(blocks == b) for b in np.unique(blocks)}
    keys = list(members)
    rng = np.random.default_rng(seed)
    values = []
    for _ in range(resamples):
        chosen = rng.choice(len(keys), size=len(keys), replace=True)
        index = np.concatenate([members[keys[k]] for k in chosen])
        if y[index].min() != y[index].max():
            values.append(average_precision_score(y[index], scores[index]))
    low, high = np.percentile(values, [2.5, 97.5])
    return {
        "estimate": float(average_precision_score(y, scores)),
        "ci_low": float(low),
        "ci_high": float(high),
        "resamples_used": len(values),
    }


def x_block_bootstrap_ci__mutmut_2(y, scores, times, block_seconds, resamples, seed) -> dict[str, float]:
    """Percentile interval of average precision, resampling whole blocks of time."""
    y, scores = np.asarray(None), np.asarray(scores, dtype=float)
    if len(y) != len(scores) or len(y) != len(times):
        raise ValueError("labels, scores and times must have equal length")
    if y.min() == y.max():
        raise ValueError("both classes are required")
    blocks = time_blocks(times, block_seconds)
    members = {b: np.flatnonzero(blocks == b) for b in np.unique(blocks)}
    keys = list(members)
    rng = np.random.default_rng(seed)
    values = []
    for _ in range(resamples):
        chosen = rng.choice(len(keys), size=len(keys), replace=True)
        index = np.concatenate([members[keys[k]] for k in chosen])
        if y[index].min() != y[index].max():
            values.append(average_precision_score(y[index], scores[index]))
    low, high = np.percentile(values, [2.5, 97.5])
    return {
        "estimate": float(average_precision_score(y, scores)),
        "ci_low": float(low),
        "ci_high": float(high),
        "resamples_used": len(values),
    }


def x_block_bootstrap_ci__mutmut_3(y, scores, times, block_seconds, resamples, seed) -> dict[str, float]:
    """Percentile interval of average precision, resampling whole blocks of time."""
    y, scores = np.asarray(y), np.asarray(None, dtype=float)
    if len(y) != len(scores) or len(y) != len(times):
        raise ValueError("labels, scores and times must have equal length")
    if y.min() == y.max():
        raise ValueError("both classes are required")
    blocks = time_blocks(times, block_seconds)
    members = {b: np.flatnonzero(blocks == b) for b in np.unique(blocks)}
    keys = list(members)
    rng = np.random.default_rng(seed)
    values = []
    for _ in range(resamples):
        chosen = rng.choice(len(keys), size=len(keys), replace=True)
        index = np.concatenate([members[keys[k]] for k in chosen])
        if y[index].min() != y[index].max():
            values.append(average_precision_score(y[index], scores[index]))
    low, high = np.percentile(values, [2.5, 97.5])
    return {
        "estimate": float(average_precision_score(y, scores)),
        "ci_low": float(low),
        "ci_high": float(high),
        "resamples_used": len(values),
    }


def x_block_bootstrap_ci__mutmut_4(y, scores, times, block_seconds, resamples, seed) -> dict[str, float]:
    """Percentile interval of average precision, resampling whole blocks of time."""
    y, scores = np.asarray(y), np.asarray(scores, dtype=None)
    if len(y) != len(scores) or len(y) != len(times):
        raise ValueError("labels, scores and times must have equal length")
    if y.min() == y.max():
        raise ValueError("both classes are required")
    blocks = time_blocks(times, block_seconds)
    members = {b: np.flatnonzero(blocks == b) for b in np.unique(blocks)}
    keys = list(members)
    rng = np.random.default_rng(seed)
    values = []
    for _ in range(resamples):
        chosen = rng.choice(len(keys), size=len(keys), replace=True)
        index = np.concatenate([members[keys[k]] for k in chosen])
        if y[index].min() != y[index].max():
            values.append(average_precision_score(y[index], scores[index]))
    low, high = np.percentile(values, [2.5, 97.5])
    return {
        "estimate": float(average_precision_score(y, scores)),
        "ci_low": float(low),
        "ci_high": float(high),
        "resamples_used": len(values),
    }


def x_block_bootstrap_ci__mutmut_5(y, scores, times, block_seconds, resamples, seed) -> dict[str, float]:
    """Percentile interval of average precision, resampling whole blocks of time."""
    y, scores = np.asarray(y), np.asarray(dtype=float)
    if len(y) != len(scores) or len(y) != len(times):
        raise ValueError("labels, scores and times must have equal length")
    if y.min() == y.max():
        raise ValueError("both classes are required")
    blocks = time_blocks(times, block_seconds)
    members = {b: np.flatnonzero(blocks == b) for b in np.unique(blocks)}
    keys = list(members)
    rng = np.random.default_rng(seed)
    values = []
    for _ in range(resamples):
        chosen = rng.choice(len(keys), size=len(keys), replace=True)
        index = np.concatenate([members[keys[k]] for k in chosen])
        if y[index].min() != y[index].max():
            values.append(average_precision_score(y[index], scores[index]))
    low, high = np.percentile(values, [2.5, 97.5])
    return {
        "estimate": float(average_precision_score(y, scores)),
        "ci_low": float(low),
        "ci_high": float(high),
        "resamples_used": len(values),
    }


def x_block_bootstrap_ci__mutmut_6(y, scores, times, block_seconds, resamples, seed) -> dict[str, float]:
    """Percentile interval of average precision, resampling whole blocks of time."""
    y, scores = np.asarray(y), np.asarray(scores, )
    if len(y) != len(scores) or len(y) != len(times):
        raise ValueError("labels, scores and times must have equal length")
    if y.min() == y.max():
        raise ValueError("both classes are required")
    blocks = time_blocks(times, block_seconds)
    members = {b: np.flatnonzero(blocks == b) for b in np.unique(blocks)}
    keys = list(members)
    rng = np.random.default_rng(seed)
    values = []
    for _ in range(resamples):
        chosen = rng.choice(len(keys), size=len(keys), replace=True)
        index = np.concatenate([members[keys[k]] for k in chosen])
        if y[index].min() != y[index].max():
            values.append(average_precision_score(y[index], scores[index]))
    low, high = np.percentile(values, [2.5, 97.5])
    return {
        "estimate": float(average_precision_score(y, scores)),
        "ci_low": float(low),
        "ci_high": float(high),
        "resamples_used": len(values),
    }


def x_block_bootstrap_ci__mutmut_7(y, scores, times, block_seconds, resamples, seed) -> dict[str, float]:
    """Percentile interval of average precision, resampling whole blocks of time."""
    y, scores = np.asarray(y), np.asarray(scores, dtype=float)
    if len(y) != len(scores) and len(y) != len(times):
        raise ValueError("labels, scores and times must have equal length")
    if y.min() == y.max():
        raise ValueError("both classes are required")
    blocks = time_blocks(times, block_seconds)
    members = {b: np.flatnonzero(blocks == b) for b in np.unique(blocks)}
    keys = list(members)
    rng = np.random.default_rng(seed)
    values = []
    for _ in range(resamples):
        chosen = rng.choice(len(keys), size=len(keys), replace=True)
        index = np.concatenate([members[keys[k]] for k in chosen])
        if y[index].min() != y[index].max():
            values.append(average_precision_score(y[index], scores[index]))
    low, high = np.percentile(values, [2.5, 97.5])
    return {
        "estimate": float(average_precision_score(y, scores)),
        "ci_low": float(low),
        "ci_high": float(high),
        "resamples_used": len(values),
    }


def x_block_bootstrap_ci__mutmut_8(y, scores, times, block_seconds, resamples, seed) -> dict[str, float]:
    """Percentile interval of average precision, resampling whole blocks of time."""
    y, scores = np.asarray(y), np.asarray(scores, dtype=float)
    if len(y) == len(scores) or len(y) != len(times):
        raise ValueError("labels, scores and times must have equal length")
    if y.min() == y.max():
        raise ValueError("both classes are required")
    blocks = time_blocks(times, block_seconds)
    members = {b: np.flatnonzero(blocks == b) for b in np.unique(blocks)}
    keys = list(members)
    rng = np.random.default_rng(seed)
    values = []
    for _ in range(resamples):
        chosen = rng.choice(len(keys), size=len(keys), replace=True)
        index = np.concatenate([members[keys[k]] for k in chosen])
        if y[index].min() != y[index].max():
            values.append(average_precision_score(y[index], scores[index]))
    low, high = np.percentile(values, [2.5, 97.5])
    return {
        "estimate": float(average_precision_score(y, scores)),
        "ci_low": float(low),
        "ci_high": float(high),
        "resamples_used": len(values),
    }


def x_block_bootstrap_ci__mutmut_9(y, scores, times, block_seconds, resamples, seed) -> dict[str, float]:
    """Percentile interval of average precision, resampling whole blocks of time."""
    y, scores = np.asarray(y), np.asarray(scores, dtype=float)
    if len(y) != len(scores) or len(y) == len(times):
        raise ValueError("labels, scores and times must have equal length")
    if y.min() == y.max():
        raise ValueError("both classes are required")
    blocks = time_blocks(times, block_seconds)
    members = {b: np.flatnonzero(blocks == b) for b in np.unique(blocks)}
    keys = list(members)
    rng = np.random.default_rng(seed)
    values = []
    for _ in range(resamples):
        chosen = rng.choice(len(keys), size=len(keys), replace=True)
        index = np.concatenate([members[keys[k]] for k in chosen])
        if y[index].min() != y[index].max():
            values.append(average_precision_score(y[index], scores[index]))
    low, high = np.percentile(values, [2.5, 97.5])
    return {
        "estimate": float(average_precision_score(y, scores)),
        "ci_low": float(low),
        "ci_high": float(high),
        "resamples_used": len(values),
    }


def x_block_bootstrap_ci__mutmut_10(y, scores, times, block_seconds, resamples, seed) -> dict[str, float]:
    """Percentile interval of average precision, resampling whole blocks of time."""
    y, scores = np.asarray(y), np.asarray(scores, dtype=float)
    if len(y) != len(scores) or len(y) != len(times):
        raise ValueError(None)
    if y.min() == y.max():
        raise ValueError("both classes are required")
    blocks = time_blocks(times, block_seconds)
    members = {b: np.flatnonzero(blocks == b) for b in np.unique(blocks)}
    keys = list(members)
    rng = np.random.default_rng(seed)
    values = []
    for _ in range(resamples):
        chosen = rng.choice(len(keys), size=len(keys), replace=True)
        index = np.concatenate([members[keys[k]] for k in chosen])
        if y[index].min() != y[index].max():
            values.append(average_precision_score(y[index], scores[index]))
    low, high = np.percentile(values, [2.5, 97.5])
    return {
        "estimate": float(average_precision_score(y, scores)),
        "ci_low": float(low),
        "ci_high": float(high),
        "resamples_used": len(values),
    }


def x_block_bootstrap_ci__mutmut_11(y, scores, times, block_seconds, resamples, seed) -> dict[str, float]:
    """Percentile interval of average precision, resampling whole blocks of time."""
    y, scores = np.asarray(y), np.asarray(scores, dtype=float)
    if len(y) != len(scores) or len(y) != len(times):
        raise ValueError("XXlabels, scores and times must have equal lengthXX")
    if y.min() == y.max():
        raise ValueError("both classes are required")
    blocks = time_blocks(times, block_seconds)
    members = {b: np.flatnonzero(blocks == b) for b in np.unique(blocks)}
    keys = list(members)
    rng = np.random.default_rng(seed)
    values = []
    for _ in range(resamples):
        chosen = rng.choice(len(keys), size=len(keys), replace=True)
        index = np.concatenate([members[keys[k]] for k in chosen])
        if y[index].min() != y[index].max():
            values.append(average_precision_score(y[index], scores[index]))
    low, high = np.percentile(values, [2.5, 97.5])
    return {
        "estimate": float(average_precision_score(y, scores)),
        "ci_low": float(low),
        "ci_high": float(high),
        "resamples_used": len(values),
    }


def x_block_bootstrap_ci__mutmut_12(y, scores, times, block_seconds, resamples, seed) -> dict[str, float]:
    """Percentile interval of average precision, resampling whole blocks of time."""
    y, scores = np.asarray(y), np.asarray(scores, dtype=float)
    if len(y) != len(scores) or len(y) != len(times):
        raise ValueError("LABELS, SCORES AND TIMES MUST HAVE EQUAL LENGTH")
    if y.min() == y.max():
        raise ValueError("both classes are required")
    blocks = time_blocks(times, block_seconds)
    members = {b: np.flatnonzero(blocks == b) for b in np.unique(blocks)}
    keys = list(members)
    rng = np.random.default_rng(seed)
    values = []
    for _ in range(resamples):
        chosen = rng.choice(len(keys), size=len(keys), replace=True)
        index = np.concatenate([members[keys[k]] for k in chosen])
        if y[index].min() != y[index].max():
            values.append(average_precision_score(y[index], scores[index]))
    low, high = np.percentile(values, [2.5, 97.5])
    return {
        "estimate": float(average_precision_score(y, scores)),
        "ci_low": float(low),
        "ci_high": float(high),
        "resamples_used": len(values),
    }


def x_block_bootstrap_ci__mutmut_13(y, scores, times, block_seconds, resamples, seed) -> dict[str, float]:
    """Percentile interval of average precision, resampling whole blocks of time."""
    y, scores = np.asarray(y), np.asarray(scores, dtype=float)
    if len(y) != len(scores) or len(y) != len(times):
        raise ValueError("labels, scores and times must have equal length")
    if y.min() != y.max():
        raise ValueError("both classes are required")
    blocks = time_blocks(times, block_seconds)
    members = {b: np.flatnonzero(blocks == b) for b in np.unique(blocks)}
    keys = list(members)
    rng = np.random.default_rng(seed)
    values = []
    for _ in range(resamples):
        chosen = rng.choice(len(keys), size=len(keys), replace=True)
        index = np.concatenate([members[keys[k]] for k in chosen])
        if y[index].min() != y[index].max():
            values.append(average_precision_score(y[index], scores[index]))
    low, high = np.percentile(values, [2.5, 97.5])
    return {
        "estimate": float(average_precision_score(y, scores)),
        "ci_low": float(low),
        "ci_high": float(high),
        "resamples_used": len(values),
    }


def x_block_bootstrap_ci__mutmut_14(y, scores, times, block_seconds, resamples, seed) -> dict[str, float]:
    """Percentile interval of average precision, resampling whole blocks of time."""
    y, scores = np.asarray(y), np.asarray(scores, dtype=float)
    if len(y) != len(scores) or len(y) != len(times):
        raise ValueError("labels, scores and times must have equal length")
    if y.min() == y.max():
        raise ValueError(None)
    blocks = time_blocks(times, block_seconds)
    members = {b: np.flatnonzero(blocks == b) for b in np.unique(blocks)}
    keys = list(members)
    rng = np.random.default_rng(seed)
    values = []
    for _ in range(resamples):
        chosen = rng.choice(len(keys), size=len(keys), replace=True)
        index = np.concatenate([members[keys[k]] for k in chosen])
        if y[index].min() != y[index].max():
            values.append(average_precision_score(y[index], scores[index]))
    low, high = np.percentile(values, [2.5, 97.5])
    return {
        "estimate": float(average_precision_score(y, scores)),
        "ci_low": float(low),
        "ci_high": float(high),
        "resamples_used": len(values),
    }


def x_block_bootstrap_ci__mutmut_15(y, scores, times, block_seconds, resamples, seed) -> dict[str, float]:
    """Percentile interval of average precision, resampling whole blocks of time."""
    y, scores = np.asarray(y), np.asarray(scores, dtype=float)
    if len(y) != len(scores) or len(y) != len(times):
        raise ValueError("labels, scores and times must have equal length")
    if y.min() == y.max():
        raise ValueError("XXboth classes are requiredXX")
    blocks = time_blocks(times, block_seconds)
    members = {b: np.flatnonzero(blocks == b) for b in np.unique(blocks)}
    keys = list(members)
    rng = np.random.default_rng(seed)
    values = []
    for _ in range(resamples):
        chosen = rng.choice(len(keys), size=len(keys), replace=True)
        index = np.concatenate([members[keys[k]] for k in chosen])
        if y[index].min() != y[index].max():
            values.append(average_precision_score(y[index], scores[index]))
    low, high = np.percentile(values, [2.5, 97.5])
    return {
        "estimate": float(average_precision_score(y, scores)),
        "ci_low": float(low),
        "ci_high": float(high),
        "resamples_used": len(values),
    }


def x_block_bootstrap_ci__mutmut_16(y, scores, times, block_seconds, resamples, seed) -> dict[str, float]:
    """Percentile interval of average precision, resampling whole blocks of time."""
    y, scores = np.asarray(y), np.asarray(scores, dtype=float)
    if len(y) != len(scores) or len(y) != len(times):
        raise ValueError("labels, scores and times must have equal length")
    if y.min() == y.max():
        raise ValueError("BOTH CLASSES ARE REQUIRED")
    blocks = time_blocks(times, block_seconds)
    members = {b: np.flatnonzero(blocks == b) for b in np.unique(blocks)}
    keys = list(members)
    rng = np.random.default_rng(seed)
    values = []
    for _ in range(resamples):
        chosen = rng.choice(len(keys), size=len(keys), replace=True)
        index = np.concatenate([members[keys[k]] for k in chosen])
        if y[index].min() != y[index].max():
            values.append(average_precision_score(y[index], scores[index]))
    low, high = np.percentile(values, [2.5, 97.5])
    return {
        "estimate": float(average_precision_score(y, scores)),
        "ci_low": float(low),
        "ci_high": float(high),
        "resamples_used": len(values),
    }


def x_block_bootstrap_ci__mutmut_17(y, scores, times, block_seconds, resamples, seed) -> dict[str, float]:
    """Percentile interval of average precision, resampling whole blocks of time."""
    y, scores = np.asarray(y), np.asarray(scores, dtype=float)
    if len(y) != len(scores) or len(y) != len(times):
        raise ValueError("labels, scores and times must have equal length")
    if y.min() == y.max():
        raise ValueError("both classes are required")
    blocks = None
    members = {b: np.flatnonzero(blocks == b) for b in np.unique(blocks)}
    keys = list(members)
    rng = np.random.default_rng(seed)
    values = []
    for _ in range(resamples):
        chosen = rng.choice(len(keys), size=len(keys), replace=True)
        index = np.concatenate([members[keys[k]] for k in chosen])
        if y[index].min() != y[index].max():
            values.append(average_precision_score(y[index], scores[index]))
    low, high = np.percentile(values, [2.5, 97.5])
    return {
        "estimate": float(average_precision_score(y, scores)),
        "ci_low": float(low),
        "ci_high": float(high),
        "resamples_used": len(values),
    }


def x_block_bootstrap_ci__mutmut_18(y, scores, times, block_seconds, resamples, seed) -> dict[str, float]:
    """Percentile interval of average precision, resampling whole blocks of time."""
    y, scores = np.asarray(y), np.asarray(scores, dtype=float)
    if len(y) != len(scores) or len(y) != len(times):
        raise ValueError("labels, scores and times must have equal length")
    if y.min() == y.max():
        raise ValueError("both classes are required")
    blocks = time_blocks(None, block_seconds)
    members = {b: np.flatnonzero(blocks == b) for b in np.unique(blocks)}
    keys = list(members)
    rng = np.random.default_rng(seed)
    values = []
    for _ in range(resamples):
        chosen = rng.choice(len(keys), size=len(keys), replace=True)
        index = np.concatenate([members[keys[k]] for k in chosen])
        if y[index].min() != y[index].max():
            values.append(average_precision_score(y[index], scores[index]))
    low, high = np.percentile(values, [2.5, 97.5])
    return {
        "estimate": float(average_precision_score(y, scores)),
        "ci_low": float(low),
        "ci_high": float(high),
        "resamples_used": len(values),
    }


def x_block_bootstrap_ci__mutmut_19(y, scores, times, block_seconds, resamples, seed) -> dict[str, float]:
    """Percentile interval of average precision, resampling whole blocks of time."""
    y, scores = np.asarray(y), np.asarray(scores, dtype=float)
    if len(y) != len(scores) or len(y) != len(times):
        raise ValueError("labels, scores and times must have equal length")
    if y.min() == y.max():
        raise ValueError("both classes are required")
    blocks = time_blocks(times, None)
    members = {b: np.flatnonzero(blocks == b) for b in np.unique(blocks)}
    keys = list(members)
    rng = np.random.default_rng(seed)
    values = []
    for _ in range(resamples):
        chosen = rng.choice(len(keys), size=len(keys), replace=True)
        index = np.concatenate([members[keys[k]] for k in chosen])
        if y[index].min() != y[index].max():
            values.append(average_precision_score(y[index], scores[index]))
    low, high = np.percentile(values, [2.5, 97.5])
    return {
        "estimate": float(average_precision_score(y, scores)),
        "ci_low": float(low),
        "ci_high": float(high),
        "resamples_used": len(values),
    }


def x_block_bootstrap_ci__mutmut_20(y, scores, times, block_seconds, resamples, seed) -> dict[str, float]:
    """Percentile interval of average precision, resampling whole blocks of time."""
    y, scores = np.asarray(y), np.asarray(scores, dtype=float)
    if len(y) != len(scores) or len(y) != len(times):
        raise ValueError("labels, scores and times must have equal length")
    if y.min() == y.max():
        raise ValueError("both classes are required")
    blocks = time_blocks(block_seconds)
    members = {b: np.flatnonzero(blocks == b) for b in np.unique(blocks)}
    keys = list(members)
    rng = np.random.default_rng(seed)
    values = []
    for _ in range(resamples):
        chosen = rng.choice(len(keys), size=len(keys), replace=True)
        index = np.concatenate([members[keys[k]] for k in chosen])
        if y[index].min() != y[index].max():
            values.append(average_precision_score(y[index], scores[index]))
    low, high = np.percentile(values, [2.5, 97.5])
    return {
        "estimate": float(average_precision_score(y, scores)),
        "ci_low": float(low),
        "ci_high": float(high),
        "resamples_used": len(values),
    }


def x_block_bootstrap_ci__mutmut_21(y, scores, times, block_seconds, resamples, seed) -> dict[str, float]:
    """Percentile interval of average precision, resampling whole blocks of time."""
    y, scores = np.asarray(y), np.asarray(scores, dtype=float)
    if len(y) != len(scores) or len(y) != len(times):
        raise ValueError("labels, scores and times must have equal length")
    if y.min() == y.max():
        raise ValueError("both classes are required")
    blocks = time_blocks(times, )
    members = {b: np.flatnonzero(blocks == b) for b in np.unique(blocks)}
    keys = list(members)
    rng = np.random.default_rng(seed)
    values = []
    for _ in range(resamples):
        chosen = rng.choice(len(keys), size=len(keys), replace=True)
        index = np.concatenate([members[keys[k]] for k in chosen])
        if y[index].min() != y[index].max():
            values.append(average_precision_score(y[index], scores[index]))
    low, high = np.percentile(values, [2.5, 97.5])
    return {
        "estimate": float(average_precision_score(y, scores)),
        "ci_low": float(low),
        "ci_high": float(high),
        "resamples_used": len(values),
    }


def x_block_bootstrap_ci__mutmut_22(y, scores, times, block_seconds, resamples, seed) -> dict[str, float]:
    """Percentile interval of average precision, resampling whole blocks of time."""
    y, scores = np.asarray(y), np.asarray(scores, dtype=float)
    if len(y) != len(scores) or len(y) != len(times):
        raise ValueError("labels, scores and times must have equal length")
    if y.min() == y.max():
        raise ValueError("both classes are required")
    blocks = time_blocks(times, block_seconds)
    members = None
    keys = list(members)
    rng = np.random.default_rng(seed)
    values = []
    for _ in range(resamples):
        chosen = rng.choice(len(keys), size=len(keys), replace=True)
        index = np.concatenate([members[keys[k]] for k in chosen])
        if y[index].min() != y[index].max():
            values.append(average_precision_score(y[index], scores[index]))
    low, high = np.percentile(values, [2.5, 97.5])
    return {
        "estimate": float(average_precision_score(y, scores)),
        "ci_low": float(low),
        "ci_high": float(high),
        "resamples_used": len(values),
    }


def x_block_bootstrap_ci__mutmut_23(y, scores, times, block_seconds, resamples, seed) -> dict[str, float]:
    """Percentile interval of average precision, resampling whole blocks of time."""
    y, scores = np.asarray(y), np.asarray(scores, dtype=float)
    if len(y) != len(scores) or len(y) != len(times):
        raise ValueError("labels, scores and times must have equal length")
    if y.min() == y.max():
        raise ValueError("both classes are required")
    blocks = time_blocks(times, block_seconds)
    members = {b: np.flatnonzero(None) for b in np.unique(blocks)}
    keys = list(members)
    rng = np.random.default_rng(seed)
    values = []
    for _ in range(resamples):
        chosen = rng.choice(len(keys), size=len(keys), replace=True)
        index = np.concatenate([members[keys[k]] for k in chosen])
        if y[index].min() != y[index].max():
            values.append(average_precision_score(y[index], scores[index]))
    low, high = np.percentile(values, [2.5, 97.5])
    return {
        "estimate": float(average_precision_score(y, scores)),
        "ci_low": float(low),
        "ci_high": float(high),
        "resamples_used": len(values),
    }


def x_block_bootstrap_ci__mutmut_24(y, scores, times, block_seconds, resamples, seed) -> dict[str, float]:
    """Percentile interval of average precision, resampling whole blocks of time."""
    y, scores = np.asarray(y), np.asarray(scores, dtype=float)
    if len(y) != len(scores) or len(y) != len(times):
        raise ValueError("labels, scores and times must have equal length")
    if y.min() == y.max():
        raise ValueError("both classes are required")
    blocks = time_blocks(times, block_seconds)
    members = {b: np.flatnonzero(blocks != b) for b in np.unique(blocks)}
    keys = list(members)
    rng = np.random.default_rng(seed)
    values = []
    for _ in range(resamples):
        chosen = rng.choice(len(keys), size=len(keys), replace=True)
        index = np.concatenate([members[keys[k]] for k in chosen])
        if y[index].min() != y[index].max():
            values.append(average_precision_score(y[index], scores[index]))
    low, high = np.percentile(values, [2.5, 97.5])
    return {
        "estimate": float(average_precision_score(y, scores)),
        "ci_low": float(low),
        "ci_high": float(high),
        "resamples_used": len(values),
    }


def x_block_bootstrap_ci__mutmut_25(y, scores, times, block_seconds, resamples, seed) -> dict[str, float]:
    """Percentile interval of average precision, resampling whole blocks of time."""
    y, scores = np.asarray(y), np.asarray(scores, dtype=float)
    if len(y) != len(scores) or len(y) != len(times):
        raise ValueError("labels, scores and times must have equal length")
    if y.min() == y.max():
        raise ValueError("both classes are required")
    blocks = time_blocks(times, block_seconds)
    members = {b: np.flatnonzero(blocks == b) for b in np.unique(None)}
    keys = list(members)
    rng = np.random.default_rng(seed)
    values = []
    for _ in range(resamples):
        chosen = rng.choice(len(keys), size=len(keys), replace=True)
        index = np.concatenate([members[keys[k]] for k in chosen])
        if y[index].min() != y[index].max():
            values.append(average_precision_score(y[index], scores[index]))
    low, high = np.percentile(values, [2.5, 97.5])
    return {
        "estimate": float(average_precision_score(y, scores)),
        "ci_low": float(low),
        "ci_high": float(high),
        "resamples_used": len(values),
    }


def x_block_bootstrap_ci__mutmut_26(y, scores, times, block_seconds, resamples, seed) -> dict[str, float]:
    """Percentile interval of average precision, resampling whole blocks of time."""
    y, scores = np.asarray(y), np.asarray(scores, dtype=float)
    if len(y) != len(scores) or len(y) != len(times):
        raise ValueError("labels, scores and times must have equal length")
    if y.min() == y.max():
        raise ValueError("both classes are required")
    blocks = time_blocks(times, block_seconds)
    members = {b: np.flatnonzero(blocks == b) for b in np.unique(blocks)}
    keys = None
    rng = np.random.default_rng(seed)
    values = []
    for _ in range(resamples):
        chosen = rng.choice(len(keys), size=len(keys), replace=True)
        index = np.concatenate([members[keys[k]] for k in chosen])
        if y[index].min() != y[index].max():
            values.append(average_precision_score(y[index], scores[index]))
    low, high = np.percentile(values, [2.5, 97.5])
    return {
        "estimate": float(average_precision_score(y, scores)),
        "ci_low": float(low),
        "ci_high": float(high),
        "resamples_used": len(values),
    }


def x_block_bootstrap_ci__mutmut_27(y, scores, times, block_seconds, resamples, seed) -> dict[str, float]:
    """Percentile interval of average precision, resampling whole blocks of time."""
    y, scores = np.asarray(y), np.asarray(scores, dtype=float)
    if len(y) != len(scores) or len(y) != len(times):
        raise ValueError("labels, scores and times must have equal length")
    if y.min() == y.max():
        raise ValueError("both classes are required")
    blocks = time_blocks(times, block_seconds)
    members = {b: np.flatnonzero(blocks == b) for b in np.unique(blocks)}
    keys = list(None)
    rng = np.random.default_rng(seed)
    values = []
    for _ in range(resamples):
        chosen = rng.choice(len(keys), size=len(keys), replace=True)
        index = np.concatenate([members[keys[k]] for k in chosen])
        if y[index].min() != y[index].max():
            values.append(average_precision_score(y[index], scores[index]))
    low, high = np.percentile(values, [2.5, 97.5])
    return {
        "estimate": float(average_precision_score(y, scores)),
        "ci_low": float(low),
        "ci_high": float(high),
        "resamples_used": len(values),
    }


def x_block_bootstrap_ci__mutmut_28(y, scores, times, block_seconds, resamples, seed) -> dict[str, float]:
    """Percentile interval of average precision, resampling whole blocks of time."""
    y, scores = np.asarray(y), np.asarray(scores, dtype=float)
    if len(y) != len(scores) or len(y) != len(times):
        raise ValueError("labels, scores and times must have equal length")
    if y.min() == y.max():
        raise ValueError("both classes are required")
    blocks = time_blocks(times, block_seconds)
    members = {b: np.flatnonzero(blocks == b) for b in np.unique(blocks)}
    keys = list(members)
    rng = None
    values = []
    for _ in range(resamples):
        chosen = rng.choice(len(keys), size=len(keys), replace=True)
        index = np.concatenate([members[keys[k]] for k in chosen])
        if y[index].min() != y[index].max():
            values.append(average_precision_score(y[index], scores[index]))
    low, high = np.percentile(values, [2.5, 97.5])
    return {
        "estimate": float(average_precision_score(y, scores)),
        "ci_low": float(low),
        "ci_high": float(high),
        "resamples_used": len(values),
    }


def x_block_bootstrap_ci__mutmut_29(y, scores, times, block_seconds, resamples, seed) -> dict[str, float]:
    """Percentile interval of average precision, resampling whole blocks of time."""
    y, scores = np.asarray(y), np.asarray(scores, dtype=float)
    if len(y) != len(scores) or len(y) != len(times):
        raise ValueError("labels, scores and times must have equal length")
    if y.min() == y.max():
        raise ValueError("both classes are required")
    blocks = time_blocks(times, block_seconds)
    members = {b: np.flatnonzero(blocks == b) for b in np.unique(blocks)}
    keys = list(members)
    rng = np.random.default_rng(None)
    values = []
    for _ in range(resamples):
        chosen = rng.choice(len(keys), size=len(keys), replace=True)
        index = np.concatenate([members[keys[k]] for k in chosen])
        if y[index].min() != y[index].max():
            values.append(average_precision_score(y[index], scores[index]))
    low, high = np.percentile(values, [2.5, 97.5])
    return {
        "estimate": float(average_precision_score(y, scores)),
        "ci_low": float(low),
        "ci_high": float(high),
        "resamples_used": len(values),
    }


def x_block_bootstrap_ci__mutmut_30(y, scores, times, block_seconds, resamples, seed) -> dict[str, float]:
    """Percentile interval of average precision, resampling whole blocks of time."""
    y, scores = np.asarray(y), np.asarray(scores, dtype=float)
    if len(y) != len(scores) or len(y) != len(times):
        raise ValueError("labels, scores and times must have equal length")
    if y.min() == y.max():
        raise ValueError("both classes are required")
    blocks = time_blocks(times, block_seconds)
    members = {b: np.flatnonzero(blocks == b) for b in np.unique(blocks)}
    keys = list(members)
    rng = np.random.default_rng(seed)
    values = None
    for _ in range(resamples):
        chosen = rng.choice(len(keys), size=len(keys), replace=True)
        index = np.concatenate([members[keys[k]] for k in chosen])
        if y[index].min() != y[index].max():
            values.append(average_precision_score(y[index], scores[index]))
    low, high = np.percentile(values, [2.5, 97.5])
    return {
        "estimate": float(average_precision_score(y, scores)),
        "ci_low": float(low),
        "ci_high": float(high),
        "resamples_used": len(values),
    }


def x_block_bootstrap_ci__mutmut_31(y, scores, times, block_seconds, resamples, seed) -> dict[str, float]:
    """Percentile interval of average precision, resampling whole blocks of time."""
    y, scores = np.asarray(y), np.asarray(scores, dtype=float)
    if len(y) != len(scores) or len(y) != len(times):
        raise ValueError("labels, scores and times must have equal length")
    if y.min() == y.max():
        raise ValueError("both classes are required")
    blocks = time_blocks(times, block_seconds)
    members = {b: np.flatnonzero(blocks == b) for b in np.unique(blocks)}
    keys = list(members)
    rng = np.random.default_rng(seed)
    values = []
    for _ in range(None):
        chosen = rng.choice(len(keys), size=len(keys), replace=True)
        index = np.concatenate([members[keys[k]] for k in chosen])
        if y[index].min() != y[index].max():
            values.append(average_precision_score(y[index], scores[index]))
    low, high = np.percentile(values, [2.5, 97.5])
    return {
        "estimate": float(average_precision_score(y, scores)),
        "ci_low": float(low),
        "ci_high": float(high),
        "resamples_used": len(values),
    }


def x_block_bootstrap_ci__mutmut_32(y, scores, times, block_seconds, resamples, seed) -> dict[str, float]:
    """Percentile interval of average precision, resampling whole blocks of time."""
    y, scores = np.asarray(y), np.asarray(scores, dtype=float)
    if len(y) != len(scores) or len(y) != len(times):
        raise ValueError("labels, scores and times must have equal length")
    if y.min() == y.max():
        raise ValueError("both classes are required")
    blocks = time_blocks(times, block_seconds)
    members = {b: np.flatnonzero(blocks == b) for b in np.unique(blocks)}
    keys = list(members)
    rng = np.random.default_rng(seed)
    values = []
    for _ in range(resamples):
        chosen = None
        index = np.concatenate([members[keys[k]] for k in chosen])
        if y[index].min() != y[index].max():
            values.append(average_precision_score(y[index], scores[index]))
    low, high = np.percentile(values, [2.5, 97.5])
    return {
        "estimate": float(average_precision_score(y, scores)),
        "ci_low": float(low),
        "ci_high": float(high),
        "resamples_used": len(values),
    }


def x_block_bootstrap_ci__mutmut_33(y, scores, times, block_seconds, resamples, seed) -> dict[str, float]:
    """Percentile interval of average precision, resampling whole blocks of time."""
    y, scores = np.asarray(y), np.asarray(scores, dtype=float)
    if len(y) != len(scores) or len(y) != len(times):
        raise ValueError("labels, scores and times must have equal length")
    if y.min() == y.max():
        raise ValueError("both classes are required")
    blocks = time_blocks(times, block_seconds)
    members = {b: np.flatnonzero(blocks == b) for b in np.unique(blocks)}
    keys = list(members)
    rng = np.random.default_rng(seed)
    values = []
    for _ in range(resamples):
        chosen = rng.choice(None, size=len(keys), replace=True)
        index = np.concatenate([members[keys[k]] for k in chosen])
        if y[index].min() != y[index].max():
            values.append(average_precision_score(y[index], scores[index]))
    low, high = np.percentile(values, [2.5, 97.5])
    return {
        "estimate": float(average_precision_score(y, scores)),
        "ci_low": float(low),
        "ci_high": float(high),
        "resamples_used": len(values),
    }


def x_block_bootstrap_ci__mutmut_34(y, scores, times, block_seconds, resamples, seed) -> dict[str, float]:
    """Percentile interval of average precision, resampling whole blocks of time."""
    y, scores = np.asarray(y), np.asarray(scores, dtype=float)
    if len(y) != len(scores) or len(y) != len(times):
        raise ValueError("labels, scores and times must have equal length")
    if y.min() == y.max():
        raise ValueError("both classes are required")
    blocks = time_blocks(times, block_seconds)
    members = {b: np.flatnonzero(blocks == b) for b in np.unique(blocks)}
    keys = list(members)
    rng = np.random.default_rng(seed)
    values = []
    for _ in range(resamples):
        chosen = rng.choice(len(keys), size=None, replace=True)
        index = np.concatenate([members[keys[k]] for k in chosen])
        if y[index].min() != y[index].max():
            values.append(average_precision_score(y[index], scores[index]))
    low, high = np.percentile(values, [2.5, 97.5])
    return {
        "estimate": float(average_precision_score(y, scores)),
        "ci_low": float(low),
        "ci_high": float(high),
        "resamples_used": len(values),
    }


def x_block_bootstrap_ci__mutmut_35(y, scores, times, block_seconds, resamples, seed) -> dict[str, float]:
    """Percentile interval of average precision, resampling whole blocks of time."""
    y, scores = np.asarray(y), np.asarray(scores, dtype=float)
    if len(y) != len(scores) or len(y) != len(times):
        raise ValueError("labels, scores and times must have equal length")
    if y.min() == y.max():
        raise ValueError("both classes are required")
    blocks = time_blocks(times, block_seconds)
    members = {b: np.flatnonzero(blocks == b) for b in np.unique(blocks)}
    keys = list(members)
    rng = np.random.default_rng(seed)
    values = []
    for _ in range(resamples):
        chosen = rng.choice(len(keys), size=len(keys), replace=None)
        index = np.concatenate([members[keys[k]] for k in chosen])
        if y[index].min() != y[index].max():
            values.append(average_precision_score(y[index], scores[index]))
    low, high = np.percentile(values, [2.5, 97.5])
    return {
        "estimate": float(average_precision_score(y, scores)),
        "ci_low": float(low),
        "ci_high": float(high),
        "resamples_used": len(values),
    }


def x_block_bootstrap_ci__mutmut_36(y, scores, times, block_seconds, resamples, seed) -> dict[str, float]:
    """Percentile interval of average precision, resampling whole blocks of time."""
    y, scores = np.asarray(y), np.asarray(scores, dtype=float)
    if len(y) != len(scores) or len(y) != len(times):
        raise ValueError("labels, scores and times must have equal length")
    if y.min() == y.max():
        raise ValueError("both classes are required")
    blocks = time_blocks(times, block_seconds)
    members = {b: np.flatnonzero(blocks == b) for b in np.unique(blocks)}
    keys = list(members)
    rng = np.random.default_rng(seed)
    values = []
    for _ in range(resamples):
        chosen = rng.choice(size=len(keys), replace=True)
        index = np.concatenate([members[keys[k]] for k in chosen])
        if y[index].min() != y[index].max():
            values.append(average_precision_score(y[index], scores[index]))
    low, high = np.percentile(values, [2.5, 97.5])
    return {
        "estimate": float(average_precision_score(y, scores)),
        "ci_low": float(low),
        "ci_high": float(high),
        "resamples_used": len(values),
    }


def x_block_bootstrap_ci__mutmut_37(y, scores, times, block_seconds, resamples, seed) -> dict[str, float]:
    """Percentile interval of average precision, resampling whole blocks of time."""
    y, scores = np.asarray(y), np.asarray(scores, dtype=float)
    if len(y) != len(scores) or len(y) != len(times):
        raise ValueError("labels, scores and times must have equal length")
    if y.min() == y.max():
        raise ValueError("both classes are required")
    blocks = time_blocks(times, block_seconds)
    members = {b: np.flatnonzero(blocks == b) for b in np.unique(blocks)}
    keys = list(members)
    rng = np.random.default_rng(seed)
    values = []
    for _ in range(resamples):
        chosen = rng.choice(len(keys), replace=True)
        index = np.concatenate([members[keys[k]] for k in chosen])
        if y[index].min() != y[index].max():
            values.append(average_precision_score(y[index], scores[index]))
    low, high = np.percentile(values, [2.5, 97.5])
    return {
        "estimate": float(average_precision_score(y, scores)),
        "ci_low": float(low),
        "ci_high": float(high),
        "resamples_used": len(values),
    }


def x_block_bootstrap_ci__mutmut_38(y, scores, times, block_seconds, resamples, seed) -> dict[str, float]:
    """Percentile interval of average precision, resampling whole blocks of time."""
    y, scores = np.asarray(y), np.asarray(scores, dtype=float)
    if len(y) != len(scores) or len(y) != len(times):
        raise ValueError("labels, scores and times must have equal length")
    if y.min() == y.max():
        raise ValueError("both classes are required")
    blocks = time_blocks(times, block_seconds)
    members = {b: np.flatnonzero(blocks == b) for b in np.unique(blocks)}
    keys = list(members)
    rng = np.random.default_rng(seed)
    values = []
    for _ in range(resamples):
        chosen = rng.choice(len(keys), size=len(keys), )
        index = np.concatenate([members[keys[k]] for k in chosen])
        if y[index].min() != y[index].max():
            values.append(average_precision_score(y[index], scores[index]))
    low, high = np.percentile(values, [2.5, 97.5])
    return {
        "estimate": float(average_precision_score(y, scores)),
        "ci_low": float(low),
        "ci_high": float(high),
        "resamples_used": len(values),
    }


def x_block_bootstrap_ci__mutmut_39(y, scores, times, block_seconds, resamples, seed) -> dict[str, float]:
    """Percentile interval of average precision, resampling whole blocks of time."""
    y, scores = np.asarray(y), np.asarray(scores, dtype=float)
    if len(y) != len(scores) or len(y) != len(times):
        raise ValueError("labels, scores and times must have equal length")
    if y.min() == y.max():
        raise ValueError("both classes are required")
    blocks = time_blocks(times, block_seconds)
    members = {b: np.flatnonzero(blocks == b) for b in np.unique(blocks)}
    keys = list(members)
    rng = np.random.default_rng(seed)
    values = []
    for _ in range(resamples):
        chosen = rng.choice(len(keys), size=len(keys), replace=False)
        index = np.concatenate([members[keys[k]] for k in chosen])
        if y[index].min() != y[index].max():
            values.append(average_precision_score(y[index], scores[index]))
    low, high = np.percentile(values, [2.5, 97.5])
    return {
        "estimate": float(average_precision_score(y, scores)),
        "ci_low": float(low),
        "ci_high": float(high),
        "resamples_used": len(values),
    }


def x_block_bootstrap_ci__mutmut_40(y, scores, times, block_seconds, resamples, seed) -> dict[str, float]:
    """Percentile interval of average precision, resampling whole blocks of time."""
    y, scores = np.asarray(y), np.asarray(scores, dtype=float)
    if len(y) != len(scores) or len(y) != len(times):
        raise ValueError("labels, scores and times must have equal length")
    if y.min() == y.max():
        raise ValueError("both classes are required")
    blocks = time_blocks(times, block_seconds)
    members = {b: np.flatnonzero(blocks == b) for b in np.unique(blocks)}
    keys = list(members)
    rng = np.random.default_rng(seed)
    values = []
    for _ in range(resamples):
        chosen = rng.choice(len(keys), size=len(keys), replace=True)
        index = None
        if y[index].min() != y[index].max():
            values.append(average_precision_score(y[index], scores[index]))
    low, high = np.percentile(values, [2.5, 97.5])
    return {
        "estimate": float(average_precision_score(y, scores)),
        "ci_low": float(low),
        "ci_high": float(high),
        "resamples_used": len(values),
    }


def x_block_bootstrap_ci__mutmut_41(y, scores, times, block_seconds, resamples, seed) -> dict[str, float]:
    """Percentile interval of average precision, resampling whole blocks of time."""
    y, scores = np.asarray(y), np.asarray(scores, dtype=float)
    if len(y) != len(scores) or len(y) != len(times):
        raise ValueError("labels, scores and times must have equal length")
    if y.min() == y.max():
        raise ValueError("both classes are required")
    blocks = time_blocks(times, block_seconds)
    members = {b: np.flatnonzero(blocks == b) for b in np.unique(blocks)}
    keys = list(members)
    rng = np.random.default_rng(seed)
    values = []
    for _ in range(resamples):
        chosen = rng.choice(len(keys), size=len(keys), replace=True)
        index = np.concatenate(None)
        if y[index].min() != y[index].max():
            values.append(average_precision_score(y[index], scores[index]))
    low, high = np.percentile(values, [2.5, 97.5])
    return {
        "estimate": float(average_precision_score(y, scores)),
        "ci_low": float(low),
        "ci_high": float(high),
        "resamples_used": len(values),
    }


def x_block_bootstrap_ci__mutmut_42(y, scores, times, block_seconds, resamples, seed) -> dict[str, float]:
    """Percentile interval of average precision, resampling whole blocks of time."""
    y, scores = np.asarray(y), np.asarray(scores, dtype=float)
    if len(y) != len(scores) or len(y) != len(times):
        raise ValueError("labels, scores and times must have equal length")
    if y.min() == y.max():
        raise ValueError("both classes are required")
    blocks = time_blocks(times, block_seconds)
    members = {b: np.flatnonzero(blocks == b) for b in np.unique(blocks)}
    keys = list(members)
    rng = np.random.default_rng(seed)
    values = []
    for _ in range(resamples):
        chosen = rng.choice(len(keys), size=len(keys), replace=True)
        index = np.concatenate([members[keys[k]] for k in chosen])
        if y[index].min() == y[index].max():
            values.append(average_precision_score(y[index], scores[index]))
    low, high = np.percentile(values, [2.5, 97.5])
    return {
        "estimate": float(average_precision_score(y, scores)),
        "ci_low": float(low),
        "ci_high": float(high),
        "resamples_used": len(values),
    }


def x_block_bootstrap_ci__mutmut_43(y, scores, times, block_seconds, resamples, seed) -> dict[str, float]:
    """Percentile interval of average precision, resampling whole blocks of time."""
    y, scores = np.asarray(y), np.asarray(scores, dtype=float)
    if len(y) != len(scores) or len(y) != len(times):
        raise ValueError("labels, scores and times must have equal length")
    if y.min() == y.max():
        raise ValueError("both classes are required")
    blocks = time_blocks(times, block_seconds)
    members = {b: np.flatnonzero(blocks == b) for b in np.unique(blocks)}
    keys = list(members)
    rng = np.random.default_rng(seed)
    values = []
    for _ in range(resamples):
        chosen = rng.choice(len(keys), size=len(keys), replace=True)
        index = np.concatenate([members[keys[k]] for k in chosen])
        if y[index].min() != y[index].max():
            values.append(None)
    low, high = np.percentile(values, [2.5, 97.5])
    return {
        "estimate": float(average_precision_score(y, scores)),
        "ci_low": float(low),
        "ci_high": float(high),
        "resamples_used": len(values),
    }


def x_block_bootstrap_ci__mutmut_44(y, scores, times, block_seconds, resamples, seed) -> dict[str, float]:
    """Percentile interval of average precision, resampling whole blocks of time."""
    y, scores = np.asarray(y), np.asarray(scores, dtype=float)
    if len(y) != len(scores) or len(y) != len(times):
        raise ValueError("labels, scores and times must have equal length")
    if y.min() == y.max():
        raise ValueError("both classes are required")
    blocks = time_blocks(times, block_seconds)
    members = {b: np.flatnonzero(blocks == b) for b in np.unique(blocks)}
    keys = list(members)
    rng = np.random.default_rng(seed)
    values = []
    for _ in range(resamples):
        chosen = rng.choice(len(keys), size=len(keys), replace=True)
        index = np.concatenate([members[keys[k]] for k in chosen])
        if y[index].min() != y[index].max():
            values.append(average_precision_score(None, scores[index]))
    low, high = np.percentile(values, [2.5, 97.5])
    return {
        "estimate": float(average_precision_score(y, scores)),
        "ci_low": float(low),
        "ci_high": float(high),
        "resamples_used": len(values),
    }


def x_block_bootstrap_ci__mutmut_45(y, scores, times, block_seconds, resamples, seed) -> dict[str, float]:
    """Percentile interval of average precision, resampling whole blocks of time."""
    y, scores = np.asarray(y), np.asarray(scores, dtype=float)
    if len(y) != len(scores) or len(y) != len(times):
        raise ValueError("labels, scores and times must have equal length")
    if y.min() == y.max():
        raise ValueError("both classes are required")
    blocks = time_blocks(times, block_seconds)
    members = {b: np.flatnonzero(blocks == b) for b in np.unique(blocks)}
    keys = list(members)
    rng = np.random.default_rng(seed)
    values = []
    for _ in range(resamples):
        chosen = rng.choice(len(keys), size=len(keys), replace=True)
        index = np.concatenate([members[keys[k]] for k in chosen])
        if y[index].min() != y[index].max():
            values.append(average_precision_score(y[index], None))
    low, high = np.percentile(values, [2.5, 97.5])
    return {
        "estimate": float(average_precision_score(y, scores)),
        "ci_low": float(low),
        "ci_high": float(high),
        "resamples_used": len(values),
    }


def x_block_bootstrap_ci__mutmut_46(y, scores, times, block_seconds, resamples, seed) -> dict[str, float]:
    """Percentile interval of average precision, resampling whole blocks of time."""
    y, scores = np.asarray(y), np.asarray(scores, dtype=float)
    if len(y) != len(scores) or len(y) != len(times):
        raise ValueError("labels, scores and times must have equal length")
    if y.min() == y.max():
        raise ValueError("both classes are required")
    blocks = time_blocks(times, block_seconds)
    members = {b: np.flatnonzero(blocks == b) for b in np.unique(blocks)}
    keys = list(members)
    rng = np.random.default_rng(seed)
    values = []
    for _ in range(resamples):
        chosen = rng.choice(len(keys), size=len(keys), replace=True)
        index = np.concatenate([members[keys[k]] for k in chosen])
        if y[index].min() != y[index].max():
            values.append(average_precision_score(scores[index]))
    low, high = np.percentile(values, [2.5, 97.5])
    return {
        "estimate": float(average_precision_score(y, scores)),
        "ci_low": float(low),
        "ci_high": float(high),
        "resamples_used": len(values),
    }


def x_block_bootstrap_ci__mutmut_47(y, scores, times, block_seconds, resamples, seed) -> dict[str, float]:
    """Percentile interval of average precision, resampling whole blocks of time."""
    y, scores = np.asarray(y), np.asarray(scores, dtype=float)
    if len(y) != len(scores) or len(y) != len(times):
        raise ValueError("labels, scores and times must have equal length")
    if y.min() == y.max():
        raise ValueError("both classes are required")
    blocks = time_blocks(times, block_seconds)
    members = {b: np.flatnonzero(blocks == b) for b in np.unique(blocks)}
    keys = list(members)
    rng = np.random.default_rng(seed)
    values = []
    for _ in range(resamples):
        chosen = rng.choice(len(keys), size=len(keys), replace=True)
        index = np.concatenate([members[keys[k]] for k in chosen])
        if y[index].min() != y[index].max():
            values.append(average_precision_score(y[index], ))
    low, high = np.percentile(values, [2.5, 97.5])
    return {
        "estimate": float(average_precision_score(y, scores)),
        "ci_low": float(low),
        "ci_high": float(high),
        "resamples_used": len(values),
    }


def x_block_bootstrap_ci__mutmut_48(y, scores, times, block_seconds, resamples, seed) -> dict[str, float]:
    """Percentile interval of average precision, resampling whole blocks of time."""
    y, scores = np.asarray(y), np.asarray(scores, dtype=float)
    if len(y) != len(scores) or len(y) != len(times):
        raise ValueError("labels, scores and times must have equal length")
    if y.min() == y.max():
        raise ValueError("both classes are required")
    blocks = time_blocks(times, block_seconds)
    members = {b: np.flatnonzero(blocks == b) for b in np.unique(blocks)}
    keys = list(members)
    rng = np.random.default_rng(seed)
    values = []
    for _ in range(resamples):
        chosen = rng.choice(len(keys), size=len(keys), replace=True)
        index = np.concatenate([members[keys[k]] for k in chosen])
        if y[index].min() != y[index].max():
            values.append(average_precision_score(y[index], scores[index]))
    low, high = None
    return {
        "estimate": float(average_precision_score(y, scores)),
        "ci_low": float(low),
        "ci_high": float(high),
        "resamples_used": len(values),
    }


def x_block_bootstrap_ci__mutmut_49(y, scores, times, block_seconds, resamples, seed) -> dict[str, float]:
    """Percentile interval of average precision, resampling whole blocks of time."""
    y, scores = np.asarray(y), np.asarray(scores, dtype=float)
    if len(y) != len(scores) or len(y) != len(times):
        raise ValueError("labels, scores and times must have equal length")
    if y.min() == y.max():
        raise ValueError("both classes are required")
    blocks = time_blocks(times, block_seconds)
    members = {b: np.flatnonzero(blocks == b) for b in np.unique(blocks)}
    keys = list(members)
    rng = np.random.default_rng(seed)
    values = []
    for _ in range(resamples):
        chosen = rng.choice(len(keys), size=len(keys), replace=True)
        index = np.concatenate([members[keys[k]] for k in chosen])
        if y[index].min() != y[index].max():
            values.append(average_precision_score(y[index], scores[index]))
    low, high = np.percentile(None, [2.5, 97.5])
    return {
        "estimate": float(average_precision_score(y, scores)),
        "ci_low": float(low),
        "ci_high": float(high),
        "resamples_used": len(values),
    }


def x_block_bootstrap_ci__mutmut_50(y, scores, times, block_seconds, resamples, seed) -> dict[str, float]:
    """Percentile interval of average precision, resampling whole blocks of time."""
    y, scores = np.asarray(y), np.asarray(scores, dtype=float)
    if len(y) != len(scores) or len(y) != len(times):
        raise ValueError("labels, scores and times must have equal length")
    if y.min() == y.max():
        raise ValueError("both classes are required")
    blocks = time_blocks(times, block_seconds)
    members = {b: np.flatnonzero(blocks == b) for b in np.unique(blocks)}
    keys = list(members)
    rng = np.random.default_rng(seed)
    values = []
    for _ in range(resamples):
        chosen = rng.choice(len(keys), size=len(keys), replace=True)
        index = np.concatenate([members[keys[k]] for k in chosen])
        if y[index].min() != y[index].max():
            values.append(average_precision_score(y[index], scores[index]))
    low, high = np.percentile(values, None)
    return {
        "estimate": float(average_precision_score(y, scores)),
        "ci_low": float(low),
        "ci_high": float(high),
        "resamples_used": len(values),
    }


def x_block_bootstrap_ci__mutmut_51(y, scores, times, block_seconds, resamples, seed) -> dict[str, float]:
    """Percentile interval of average precision, resampling whole blocks of time."""
    y, scores = np.asarray(y), np.asarray(scores, dtype=float)
    if len(y) != len(scores) or len(y) != len(times):
        raise ValueError("labels, scores and times must have equal length")
    if y.min() == y.max():
        raise ValueError("both classes are required")
    blocks = time_blocks(times, block_seconds)
    members = {b: np.flatnonzero(blocks == b) for b in np.unique(blocks)}
    keys = list(members)
    rng = np.random.default_rng(seed)
    values = []
    for _ in range(resamples):
        chosen = rng.choice(len(keys), size=len(keys), replace=True)
        index = np.concatenate([members[keys[k]] for k in chosen])
        if y[index].min() != y[index].max():
            values.append(average_precision_score(y[index], scores[index]))
    low, high = np.percentile([2.5, 97.5])
    return {
        "estimate": float(average_precision_score(y, scores)),
        "ci_low": float(low),
        "ci_high": float(high),
        "resamples_used": len(values),
    }


def x_block_bootstrap_ci__mutmut_52(y, scores, times, block_seconds, resamples, seed) -> dict[str, float]:
    """Percentile interval of average precision, resampling whole blocks of time."""
    y, scores = np.asarray(y), np.asarray(scores, dtype=float)
    if len(y) != len(scores) or len(y) != len(times):
        raise ValueError("labels, scores and times must have equal length")
    if y.min() == y.max():
        raise ValueError("both classes are required")
    blocks = time_blocks(times, block_seconds)
    members = {b: np.flatnonzero(blocks == b) for b in np.unique(blocks)}
    keys = list(members)
    rng = np.random.default_rng(seed)
    values = []
    for _ in range(resamples):
        chosen = rng.choice(len(keys), size=len(keys), replace=True)
        index = np.concatenate([members[keys[k]] for k in chosen])
        if y[index].min() != y[index].max():
            values.append(average_precision_score(y[index], scores[index]))
    low, high = np.percentile(values, )
    return {
        "estimate": float(average_precision_score(y, scores)),
        "ci_low": float(low),
        "ci_high": float(high),
        "resamples_used": len(values),
    }


def x_block_bootstrap_ci__mutmut_53(y, scores, times, block_seconds, resamples, seed) -> dict[str, float]:
    """Percentile interval of average precision, resampling whole blocks of time."""
    y, scores = np.asarray(y), np.asarray(scores, dtype=float)
    if len(y) != len(scores) or len(y) != len(times):
        raise ValueError("labels, scores and times must have equal length")
    if y.min() == y.max():
        raise ValueError("both classes are required")
    blocks = time_blocks(times, block_seconds)
    members = {b: np.flatnonzero(blocks == b) for b in np.unique(blocks)}
    keys = list(members)
    rng = np.random.default_rng(seed)
    values = []
    for _ in range(resamples):
        chosen = rng.choice(len(keys), size=len(keys), replace=True)
        index = np.concatenate([members[keys[k]] for k in chosen])
        if y[index].min() != y[index].max():
            values.append(average_precision_score(y[index], scores[index]))
    low, high = np.percentile(values, [3.5, 97.5])
    return {
        "estimate": float(average_precision_score(y, scores)),
        "ci_low": float(low),
        "ci_high": float(high),
        "resamples_used": len(values),
    }


def x_block_bootstrap_ci__mutmut_54(y, scores, times, block_seconds, resamples, seed) -> dict[str, float]:
    """Percentile interval of average precision, resampling whole blocks of time."""
    y, scores = np.asarray(y), np.asarray(scores, dtype=float)
    if len(y) != len(scores) or len(y) != len(times):
        raise ValueError("labels, scores and times must have equal length")
    if y.min() == y.max():
        raise ValueError("both classes are required")
    blocks = time_blocks(times, block_seconds)
    members = {b: np.flatnonzero(blocks == b) for b in np.unique(blocks)}
    keys = list(members)
    rng = np.random.default_rng(seed)
    values = []
    for _ in range(resamples):
        chosen = rng.choice(len(keys), size=len(keys), replace=True)
        index = np.concatenate([members[keys[k]] for k in chosen])
        if y[index].min() != y[index].max():
            values.append(average_precision_score(y[index], scores[index]))
    low, high = np.percentile(values, [2.5, 98.5])
    return {
        "estimate": float(average_precision_score(y, scores)),
        "ci_low": float(low),
        "ci_high": float(high),
        "resamples_used": len(values),
    }


def x_block_bootstrap_ci__mutmut_55(y, scores, times, block_seconds, resamples, seed) -> dict[str, float]:
    """Percentile interval of average precision, resampling whole blocks of time."""
    y, scores = np.asarray(y), np.asarray(scores, dtype=float)
    if len(y) != len(scores) or len(y) != len(times):
        raise ValueError("labels, scores and times must have equal length")
    if y.min() == y.max():
        raise ValueError("both classes are required")
    blocks = time_blocks(times, block_seconds)
    members = {b: np.flatnonzero(blocks == b) for b in np.unique(blocks)}
    keys = list(members)
    rng = np.random.default_rng(seed)
    values = []
    for _ in range(resamples):
        chosen = rng.choice(len(keys), size=len(keys), replace=True)
        index = np.concatenate([members[keys[k]] for k in chosen])
        if y[index].min() != y[index].max():
            values.append(average_precision_score(y[index], scores[index]))
    low, high = np.percentile(values, [2.5, 97.5])
    return {
        "XXestimateXX": float(average_precision_score(y, scores)),
        "ci_low": float(low),
        "ci_high": float(high),
        "resamples_used": len(values),
    }


def x_block_bootstrap_ci__mutmut_56(y, scores, times, block_seconds, resamples, seed) -> dict[str, float]:
    """Percentile interval of average precision, resampling whole blocks of time."""
    y, scores = np.asarray(y), np.asarray(scores, dtype=float)
    if len(y) != len(scores) or len(y) != len(times):
        raise ValueError("labels, scores and times must have equal length")
    if y.min() == y.max():
        raise ValueError("both classes are required")
    blocks = time_blocks(times, block_seconds)
    members = {b: np.flatnonzero(blocks == b) for b in np.unique(blocks)}
    keys = list(members)
    rng = np.random.default_rng(seed)
    values = []
    for _ in range(resamples):
        chosen = rng.choice(len(keys), size=len(keys), replace=True)
        index = np.concatenate([members[keys[k]] for k in chosen])
        if y[index].min() != y[index].max():
            values.append(average_precision_score(y[index], scores[index]))
    low, high = np.percentile(values, [2.5, 97.5])
    return {
        "ESTIMATE": float(average_precision_score(y, scores)),
        "ci_low": float(low),
        "ci_high": float(high),
        "resamples_used": len(values),
    }


def x_block_bootstrap_ci__mutmut_57(y, scores, times, block_seconds, resamples, seed) -> dict[str, float]:
    """Percentile interval of average precision, resampling whole blocks of time."""
    y, scores = np.asarray(y), np.asarray(scores, dtype=float)
    if len(y) != len(scores) or len(y) != len(times):
        raise ValueError("labels, scores and times must have equal length")
    if y.min() == y.max():
        raise ValueError("both classes are required")
    blocks = time_blocks(times, block_seconds)
    members = {b: np.flatnonzero(blocks == b) for b in np.unique(blocks)}
    keys = list(members)
    rng = np.random.default_rng(seed)
    values = []
    for _ in range(resamples):
        chosen = rng.choice(len(keys), size=len(keys), replace=True)
        index = np.concatenate([members[keys[k]] for k in chosen])
        if y[index].min() != y[index].max():
            values.append(average_precision_score(y[index], scores[index]))
    low, high = np.percentile(values, [2.5, 97.5])
    return {
        "estimate": float(None),
        "ci_low": float(low),
        "ci_high": float(high),
        "resamples_used": len(values),
    }


def x_block_bootstrap_ci__mutmut_58(y, scores, times, block_seconds, resamples, seed) -> dict[str, float]:
    """Percentile interval of average precision, resampling whole blocks of time."""
    y, scores = np.asarray(y), np.asarray(scores, dtype=float)
    if len(y) != len(scores) or len(y) != len(times):
        raise ValueError("labels, scores and times must have equal length")
    if y.min() == y.max():
        raise ValueError("both classes are required")
    blocks = time_blocks(times, block_seconds)
    members = {b: np.flatnonzero(blocks == b) for b in np.unique(blocks)}
    keys = list(members)
    rng = np.random.default_rng(seed)
    values = []
    for _ in range(resamples):
        chosen = rng.choice(len(keys), size=len(keys), replace=True)
        index = np.concatenate([members[keys[k]] for k in chosen])
        if y[index].min() != y[index].max():
            values.append(average_precision_score(y[index], scores[index]))
    low, high = np.percentile(values, [2.5, 97.5])
    return {
        "estimate": float(average_precision_score(None, scores)),
        "ci_low": float(low),
        "ci_high": float(high),
        "resamples_used": len(values),
    }


def x_block_bootstrap_ci__mutmut_59(y, scores, times, block_seconds, resamples, seed) -> dict[str, float]:
    """Percentile interval of average precision, resampling whole blocks of time."""
    y, scores = np.asarray(y), np.asarray(scores, dtype=float)
    if len(y) != len(scores) or len(y) != len(times):
        raise ValueError("labels, scores and times must have equal length")
    if y.min() == y.max():
        raise ValueError("both classes are required")
    blocks = time_blocks(times, block_seconds)
    members = {b: np.flatnonzero(blocks == b) for b in np.unique(blocks)}
    keys = list(members)
    rng = np.random.default_rng(seed)
    values = []
    for _ in range(resamples):
        chosen = rng.choice(len(keys), size=len(keys), replace=True)
        index = np.concatenate([members[keys[k]] for k in chosen])
        if y[index].min() != y[index].max():
            values.append(average_precision_score(y[index], scores[index]))
    low, high = np.percentile(values, [2.5, 97.5])
    return {
        "estimate": float(average_precision_score(y, None)),
        "ci_low": float(low),
        "ci_high": float(high),
        "resamples_used": len(values),
    }


def x_block_bootstrap_ci__mutmut_60(y, scores, times, block_seconds, resamples, seed) -> dict[str, float]:
    """Percentile interval of average precision, resampling whole blocks of time."""
    y, scores = np.asarray(y), np.asarray(scores, dtype=float)
    if len(y) != len(scores) or len(y) != len(times):
        raise ValueError("labels, scores and times must have equal length")
    if y.min() == y.max():
        raise ValueError("both classes are required")
    blocks = time_blocks(times, block_seconds)
    members = {b: np.flatnonzero(blocks == b) for b in np.unique(blocks)}
    keys = list(members)
    rng = np.random.default_rng(seed)
    values = []
    for _ in range(resamples):
        chosen = rng.choice(len(keys), size=len(keys), replace=True)
        index = np.concatenate([members[keys[k]] for k in chosen])
        if y[index].min() != y[index].max():
            values.append(average_precision_score(y[index], scores[index]))
    low, high = np.percentile(values, [2.5, 97.5])
    return {
        "estimate": float(average_precision_score(scores)),
        "ci_low": float(low),
        "ci_high": float(high),
        "resamples_used": len(values),
    }


def x_block_bootstrap_ci__mutmut_61(y, scores, times, block_seconds, resamples, seed) -> dict[str, float]:
    """Percentile interval of average precision, resampling whole blocks of time."""
    y, scores = np.asarray(y), np.asarray(scores, dtype=float)
    if len(y) != len(scores) or len(y) != len(times):
        raise ValueError("labels, scores and times must have equal length")
    if y.min() == y.max():
        raise ValueError("both classes are required")
    blocks = time_blocks(times, block_seconds)
    members = {b: np.flatnonzero(blocks == b) for b in np.unique(blocks)}
    keys = list(members)
    rng = np.random.default_rng(seed)
    values = []
    for _ in range(resamples):
        chosen = rng.choice(len(keys), size=len(keys), replace=True)
        index = np.concatenate([members[keys[k]] for k in chosen])
        if y[index].min() != y[index].max():
            values.append(average_precision_score(y[index], scores[index]))
    low, high = np.percentile(values, [2.5, 97.5])
    return {
        "estimate": float(average_precision_score(y, )),
        "ci_low": float(low),
        "ci_high": float(high),
        "resamples_used": len(values),
    }


def x_block_bootstrap_ci__mutmut_62(y, scores, times, block_seconds, resamples, seed) -> dict[str, float]:
    """Percentile interval of average precision, resampling whole blocks of time."""
    y, scores = np.asarray(y), np.asarray(scores, dtype=float)
    if len(y) != len(scores) or len(y) != len(times):
        raise ValueError("labels, scores and times must have equal length")
    if y.min() == y.max():
        raise ValueError("both classes are required")
    blocks = time_blocks(times, block_seconds)
    members = {b: np.flatnonzero(blocks == b) for b in np.unique(blocks)}
    keys = list(members)
    rng = np.random.default_rng(seed)
    values = []
    for _ in range(resamples):
        chosen = rng.choice(len(keys), size=len(keys), replace=True)
        index = np.concatenate([members[keys[k]] for k in chosen])
        if y[index].min() != y[index].max():
            values.append(average_precision_score(y[index], scores[index]))
    low, high = np.percentile(values, [2.5, 97.5])
    return {
        "estimate": float(average_precision_score(y, scores)),
        "XXci_lowXX": float(low),
        "ci_high": float(high),
        "resamples_used": len(values),
    }


def x_block_bootstrap_ci__mutmut_63(y, scores, times, block_seconds, resamples, seed) -> dict[str, float]:
    """Percentile interval of average precision, resampling whole blocks of time."""
    y, scores = np.asarray(y), np.asarray(scores, dtype=float)
    if len(y) != len(scores) or len(y) != len(times):
        raise ValueError("labels, scores and times must have equal length")
    if y.min() == y.max():
        raise ValueError("both classes are required")
    blocks = time_blocks(times, block_seconds)
    members = {b: np.flatnonzero(blocks == b) for b in np.unique(blocks)}
    keys = list(members)
    rng = np.random.default_rng(seed)
    values = []
    for _ in range(resamples):
        chosen = rng.choice(len(keys), size=len(keys), replace=True)
        index = np.concatenate([members[keys[k]] for k in chosen])
        if y[index].min() != y[index].max():
            values.append(average_precision_score(y[index], scores[index]))
    low, high = np.percentile(values, [2.5, 97.5])
    return {
        "estimate": float(average_precision_score(y, scores)),
        "CI_LOW": float(low),
        "ci_high": float(high),
        "resamples_used": len(values),
    }


def x_block_bootstrap_ci__mutmut_64(y, scores, times, block_seconds, resamples, seed) -> dict[str, float]:
    """Percentile interval of average precision, resampling whole blocks of time."""
    y, scores = np.asarray(y), np.asarray(scores, dtype=float)
    if len(y) != len(scores) or len(y) != len(times):
        raise ValueError("labels, scores and times must have equal length")
    if y.min() == y.max():
        raise ValueError("both classes are required")
    blocks = time_blocks(times, block_seconds)
    members = {b: np.flatnonzero(blocks == b) for b in np.unique(blocks)}
    keys = list(members)
    rng = np.random.default_rng(seed)
    values = []
    for _ in range(resamples):
        chosen = rng.choice(len(keys), size=len(keys), replace=True)
        index = np.concatenate([members[keys[k]] for k in chosen])
        if y[index].min() != y[index].max():
            values.append(average_precision_score(y[index], scores[index]))
    low, high = np.percentile(values, [2.5, 97.5])
    return {
        "estimate": float(average_precision_score(y, scores)),
        "ci_low": float(None),
        "ci_high": float(high),
        "resamples_used": len(values),
    }


def x_block_bootstrap_ci__mutmut_65(y, scores, times, block_seconds, resamples, seed) -> dict[str, float]:
    """Percentile interval of average precision, resampling whole blocks of time."""
    y, scores = np.asarray(y), np.asarray(scores, dtype=float)
    if len(y) != len(scores) or len(y) != len(times):
        raise ValueError("labels, scores and times must have equal length")
    if y.min() == y.max():
        raise ValueError("both classes are required")
    blocks = time_blocks(times, block_seconds)
    members = {b: np.flatnonzero(blocks == b) for b in np.unique(blocks)}
    keys = list(members)
    rng = np.random.default_rng(seed)
    values = []
    for _ in range(resamples):
        chosen = rng.choice(len(keys), size=len(keys), replace=True)
        index = np.concatenate([members[keys[k]] for k in chosen])
        if y[index].min() != y[index].max():
            values.append(average_precision_score(y[index], scores[index]))
    low, high = np.percentile(values, [2.5, 97.5])
    return {
        "estimate": float(average_precision_score(y, scores)),
        "ci_low": float(low),
        "XXci_highXX": float(high),
        "resamples_used": len(values),
    }


def x_block_bootstrap_ci__mutmut_66(y, scores, times, block_seconds, resamples, seed) -> dict[str, float]:
    """Percentile interval of average precision, resampling whole blocks of time."""
    y, scores = np.asarray(y), np.asarray(scores, dtype=float)
    if len(y) != len(scores) or len(y) != len(times):
        raise ValueError("labels, scores and times must have equal length")
    if y.min() == y.max():
        raise ValueError("both classes are required")
    blocks = time_blocks(times, block_seconds)
    members = {b: np.flatnonzero(blocks == b) for b in np.unique(blocks)}
    keys = list(members)
    rng = np.random.default_rng(seed)
    values = []
    for _ in range(resamples):
        chosen = rng.choice(len(keys), size=len(keys), replace=True)
        index = np.concatenate([members[keys[k]] for k in chosen])
        if y[index].min() != y[index].max():
            values.append(average_precision_score(y[index], scores[index]))
    low, high = np.percentile(values, [2.5, 97.5])
    return {
        "estimate": float(average_precision_score(y, scores)),
        "ci_low": float(low),
        "CI_HIGH": float(high),
        "resamples_used": len(values),
    }


def x_block_bootstrap_ci__mutmut_67(y, scores, times, block_seconds, resamples, seed) -> dict[str, float]:
    """Percentile interval of average precision, resampling whole blocks of time."""
    y, scores = np.asarray(y), np.asarray(scores, dtype=float)
    if len(y) != len(scores) or len(y) != len(times):
        raise ValueError("labels, scores and times must have equal length")
    if y.min() == y.max():
        raise ValueError("both classes are required")
    blocks = time_blocks(times, block_seconds)
    members = {b: np.flatnonzero(blocks == b) for b in np.unique(blocks)}
    keys = list(members)
    rng = np.random.default_rng(seed)
    values = []
    for _ in range(resamples):
        chosen = rng.choice(len(keys), size=len(keys), replace=True)
        index = np.concatenate([members[keys[k]] for k in chosen])
        if y[index].min() != y[index].max():
            values.append(average_precision_score(y[index], scores[index]))
    low, high = np.percentile(values, [2.5, 97.5])
    return {
        "estimate": float(average_precision_score(y, scores)),
        "ci_low": float(low),
        "ci_high": float(None),
        "resamples_used": len(values),
    }


def x_block_bootstrap_ci__mutmut_68(y, scores, times, block_seconds, resamples, seed) -> dict[str, float]:
    """Percentile interval of average precision, resampling whole blocks of time."""
    y, scores = np.asarray(y), np.asarray(scores, dtype=float)
    if len(y) != len(scores) or len(y) != len(times):
        raise ValueError("labels, scores and times must have equal length")
    if y.min() == y.max():
        raise ValueError("both classes are required")
    blocks = time_blocks(times, block_seconds)
    members = {b: np.flatnonzero(blocks == b) for b in np.unique(blocks)}
    keys = list(members)
    rng = np.random.default_rng(seed)
    values = []
    for _ in range(resamples):
        chosen = rng.choice(len(keys), size=len(keys), replace=True)
        index = np.concatenate([members[keys[k]] for k in chosen])
        if y[index].min() != y[index].max():
            values.append(average_precision_score(y[index], scores[index]))
    low, high = np.percentile(values, [2.5, 97.5])
    return {
        "estimate": float(average_precision_score(y, scores)),
        "ci_low": float(low),
        "ci_high": float(high),
        "XXresamples_usedXX": len(values),
    }


def x_block_bootstrap_ci__mutmut_69(y, scores, times, block_seconds, resamples, seed) -> dict[str, float]:
    """Percentile interval of average precision, resampling whole blocks of time."""
    y, scores = np.asarray(y), np.asarray(scores, dtype=float)
    if len(y) != len(scores) or len(y) != len(times):
        raise ValueError("labels, scores and times must have equal length")
    if y.min() == y.max():
        raise ValueError("both classes are required")
    blocks = time_blocks(times, block_seconds)
    members = {b: np.flatnonzero(blocks == b) for b in np.unique(blocks)}
    keys = list(members)
    rng = np.random.default_rng(seed)
    values = []
    for _ in range(resamples):
        chosen = rng.choice(len(keys), size=len(keys), replace=True)
        index = np.concatenate([members[keys[k]] for k in chosen])
        if y[index].min() != y[index].max():
            values.append(average_precision_score(y[index], scores[index]))
    low, high = np.percentile(values, [2.5, 97.5])
    return {
        "estimate": float(average_precision_score(y, scores)),
        "ci_low": float(low),
        "ci_high": float(high),
        "RESAMPLES_USED": len(values),
    }

mutants_x_block_bootstrap_ci__mutmut['_mutmut_orig'] = x_block_bootstrap_ci__mutmut_orig # type: ignore # mutmut generated
mutants_x_block_bootstrap_ci__mutmut['x_block_bootstrap_ci__mutmut_1'] = x_block_bootstrap_ci__mutmut_1 # type: ignore # mutmut generated
mutants_x_block_bootstrap_ci__mutmut['x_block_bootstrap_ci__mutmut_2'] = x_block_bootstrap_ci__mutmut_2 # type: ignore # mutmut generated
mutants_x_block_bootstrap_ci__mutmut['x_block_bootstrap_ci__mutmut_3'] = x_block_bootstrap_ci__mutmut_3 # type: ignore # mutmut generated
mutants_x_block_bootstrap_ci__mutmut['x_block_bootstrap_ci__mutmut_4'] = x_block_bootstrap_ci__mutmut_4 # type: ignore # mutmut generated
mutants_x_block_bootstrap_ci__mutmut['x_block_bootstrap_ci__mutmut_5'] = x_block_bootstrap_ci__mutmut_5 # type: ignore # mutmut generated
mutants_x_block_bootstrap_ci__mutmut['x_block_bootstrap_ci__mutmut_6'] = x_block_bootstrap_ci__mutmut_6 # type: ignore # mutmut generated
mutants_x_block_bootstrap_ci__mutmut['x_block_bootstrap_ci__mutmut_7'] = x_block_bootstrap_ci__mutmut_7 # type: ignore # mutmut generated
mutants_x_block_bootstrap_ci__mutmut['x_block_bootstrap_ci__mutmut_8'] = x_block_bootstrap_ci__mutmut_8 # type: ignore # mutmut generated
mutants_x_block_bootstrap_ci__mutmut['x_block_bootstrap_ci__mutmut_9'] = x_block_bootstrap_ci__mutmut_9 # type: ignore # mutmut generated
mutants_x_block_bootstrap_ci__mutmut['x_block_bootstrap_ci__mutmut_10'] = x_block_bootstrap_ci__mutmut_10 # type: ignore # mutmut generated
mutants_x_block_bootstrap_ci__mutmut['x_block_bootstrap_ci__mutmut_11'] = x_block_bootstrap_ci__mutmut_11 # type: ignore # mutmut generated
mutants_x_block_bootstrap_ci__mutmut['x_block_bootstrap_ci__mutmut_12'] = x_block_bootstrap_ci__mutmut_12 # type: ignore # mutmut generated
mutants_x_block_bootstrap_ci__mutmut['x_block_bootstrap_ci__mutmut_13'] = x_block_bootstrap_ci__mutmut_13 # type: ignore # mutmut generated
mutants_x_block_bootstrap_ci__mutmut['x_block_bootstrap_ci__mutmut_14'] = x_block_bootstrap_ci__mutmut_14 # type: ignore # mutmut generated
mutants_x_block_bootstrap_ci__mutmut['x_block_bootstrap_ci__mutmut_15'] = x_block_bootstrap_ci__mutmut_15 # type: ignore # mutmut generated
mutants_x_block_bootstrap_ci__mutmut['x_block_bootstrap_ci__mutmut_16'] = x_block_bootstrap_ci__mutmut_16 # type: ignore # mutmut generated
mutants_x_block_bootstrap_ci__mutmut['x_block_bootstrap_ci__mutmut_17'] = x_block_bootstrap_ci__mutmut_17 # type: ignore # mutmut generated
mutants_x_block_bootstrap_ci__mutmut['x_block_bootstrap_ci__mutmut_18'] = x_block_bootstrap_ci__mutmut_18 # type: ignore # mutmut generated
mutants_x_block_bootstrap_ci__mutmut['x_block_bootstrap_ci__mutmut_19'] = x_block_bootstrap_ci__mutmut_19 # type: ignore # mutmut generated
mutants_x_block_bootstrap_ci__mutmut['x_block_bootstrap_ci__mutmut_20'] = x_block_bootstrap_ci__mutmut_20 # type: ignore # mutmut generated
mutants_x_block_bootstrap_ci__mutmut['x_block_bootstrap_ci__mutmut_21'] = x_block_bootstrap_ci__mutmut_21 # type: ignore # mutmut generated
mutants_x_block_bootstrap_ci__mutmut['x_block_bootstrap_ci__mutmut_22'] = x_block_bootstrap_ci__mutmut_22 # type: ignore # mutmut generated
mutants_x_block_bootstrap_ci__mutmut['x_block_bootstrap_ci__mutmut_23'] = x_block_bootstrap_ci__mutmut_23 # type: ignore # mutmut generated
mutants_x_block_bootstrap_ci__mutmut['x_block_bootstrap_ci__mutmut_24'] = x_block_bootstrap_ci__mutmut_24 # type: ignore # mutmut generated
mutants_x_block_bootstrap_ci__mutmut['x_block_bootstrap_ci__mutmut_25'] = x_block_bootstrap_ci__mutmut_25 # type: ignore # mutmut generated
mutants_x_block_bootstrap_ci__mutmut['x_block_bootstrap_ci__mutmut_26'] = x_block_bootstrap_ci__mutmut_26 # type: ignore # mutmut generated
mutants_x_block_bootstrap_ci__mutmut['x_block_bootstrap_ci__mutmut_27'] = x_block_bootstrap_ci__mutmut_27 # type: ignore # mutmut generated
mutants_x_block_bootstrap_ci__mutmut['x_block_bootstrap_ci__mutmut_28'] = x_block_bootstrap_ci__mutmut_28 # type: ignore # mutmut generated
mutants_x_block_bootstrap_ci__mutmut['x_block_bootstrap_ci__mutmut_29'] = x_block_bootstrap_ci__mutmut_29 # type: ignore # mutmut generated
mutants_x_block_bootstrap_ci__mutmut['x_block_bootstrap_ci__mutmut_30'] = x_block_bootstrap_ci__mutmut_30 # type: ignore # mutmut generated
mutants_x_block_bootstrap_ci__mutmut['x_block_bootstrap_ci__mutmut_31'] = x_block_bootstrap_ci__mutmut_31 # type: ignore # mutmut generated
mutants_x_block_bootstrap_ci__mutmut['x_block_bootstrap_ci__mutmut_32'] = x_block_bootstrap_ci__mutmut_32 # type: ignore # mutmut generated
mutants_x_block_bootstrap_ci__mutmut['x_block_bootstrap_ci__mutmut_33'] = x_block_bootstrap_ci__mutmut_33 # type: ignore # mutmut generated
mutants_x_block_bootstrap_ci__mutmut['x_block_bootstrap_ci__mutmut_34'] = x_block_bootstrap_ci__mutmut_34 # type: ignore # mutmut generated
mutants_x_block_bootstrap_ci__mutmut['x_block_bootstrap_ci__mutmut_35'] = x_block_bootstrap_ci__mutmut_35 # type: ignore # mutmut generated
mutants_x_block_bootstrap_ci__mutmut['x_block_bootstrap_ci__mutmut_36'] = x_block_bootstrap_ci__mutmut_36 # type: ignore # mutmut generated
mutants_x_block_bootstrap_ci__mutmut['x_block_bootstrap_ci__mutmut_37'] = x_block_bootstrap_ci__mutmut_37 # type: ignore # mutmut generated
mutants_x_block_bootstrap_ci__mutmut['x_block_bootstrap_ci__mutmut_38'] = x_block_bootstrap_ci__mutmut_38 # type: ignore # mutmut generated
mutants_x_block_bootstrap_ci__mutmut['x_block_bootstrap_ci__mutmut_39'] = x_block_bootstrap_ci__mutmut_39 # type: ignore # mutmut generated
mutants_x_block_bootstrap_ci__mutmut['x_block_bootstrap_ci__mutmut_40'] = x_block_bootstrap_ci__mutmut_40 # type: ignore # mutmut generated
mutants_x_block_bootstrap_ci__mutmut['x_block_bootstrap_ci__mutmut_41'] = x_block_bootstrap_ci__mutmut_41 # type: ignore # mutmut generated
mutants_x_block_bootstrap_ci__mutmut['x_block_bootstrap_ci__mutmut_42'] = x_block_bootstrap_ci__mutmut_42 # type: ignore # mutmut generated
mutants_x_block_bootstrap_ci__mutmut['x_block_bootstrap_ci__mutmut_43'] = x_block_bootstrap_ci__mutmut_43 # type: ignore # mutmut generated
mutants_x_block_bootstrap_ci__mutmut['x_block_bootstrap_ci__mutmut_44'] = x_block_bootstrap_ci__mutmut_44 # type: ignore # mutmut generated
mutants_x_block_bootstrap_ci__mutmut['x_block_bootstrap_ci__mutmut_45'] = x_block_bootstrap_ci__mutmut_45 # type: ignore # mutmut generated
mutants_x_block_bootstrap_ci__mutmut['x_block_bootstrap_ci__mutmut_46'] = x_block_bootstrap_ci__mutmut_46 # type: ignore # mutmut generated
mutants_x_block_bootstrap_ci__mutmut['x_block_bootstrap_ci__mutmut_47'] = x_block_bootstrap_ci__mutmut_47 # type: ignore # mutmut generated
mutants_x_block_bootstrap_ci__mutmut['x_block_bootstrap_ci__mutmut_48'] = x_block_bootstrap_ci__mutmut_48 # type: ignore # mutmut generated
mutants_x_block_bootstrap_ci__mutmut['x_block_bootstrap_ci__mutmut_49'] = x_block_bootstrap_ci__mutmut_49 # type: ignore # mutmut generated
mutants_x_block_bootstrap_ci__mutmut['x_block_bootstrap_ci__mutmut_50'] = x_block_bootstrap_ci__mutmut_50 # type: ignore # mutmut generated
mutants_x_block_bootstrap_ci__mutmut['x_block_bootstrap_ci__mutmut_51'] = x_block_bootstrap_ci__mutmut_51 # type: ignore # mutmut generated
mutants_x_block_bootstrap_ci__mutmut['x_block_bootstrap_ci__mutmut_52'] = x_block_bootstrap_ci__mutmut_52 # type: ignore # mutmut generated
mutants_x_block_bootstrap_ci__mutmut['x_block_bootstrap_ci__mutmut_53'] = x_block_bootstrap_ci__mutmut_53 # type: ignore # mutmut generated
mutants_x_block_bootstrap_ci__mutmut['x_block_bootstrap_ci__mutmut_54'] = x_block_bootstrap_ci__mutmut_54 # type: ignore # mutmut generated
mutants_x_block_bootstrap_ci__mutmut['x_block_bootstrap_ci__mutmut_55'] = x_block_bootstrap_ci__mutmut_55 # type: ignore # mutmut generated
mutants_x_block_bootstrap_ci__mutmut['x_block_bootstrap_ci__mutmut_56'] = x_block_bootstrap_ci__mutmut_56 # type: ignore # mutmut generated
mutants_x_block_bootstrap_ci__mutmut['x_block_bootstrap_ci__mutmut_57'] = x_block_bootstrap_ci__mutmut_57 # type: ignore # mutmut generated
mutants_x_block_bootstrap_ci__mutmut['x_block_bootstrap_ci__mutmut_58'] = x_block_bootstrap_ci__mutmut_58 # type: ignore # mutmut generated
mutants_x_block_bootstrap_ci__mutmut['x_block_bootstrap_ci__mutmut_59'] = x_block_bootstrap_ci__mutmut_59 # type: ignore # mutmut generated
mutants_x_block_bootstrap_ci__mutmut['x_block_bootstrap_ci__mutmut_60'] = x_block_bootstrap_ci__mutmut_60 # type: ignore # mutmut generated
mutants_x_block_bootstrap_ci__mutmut['x_block_bootstrap_ci__mutmut_61'] = x_block_bootstrap_ci__mutmut_61 # type: ignore # mutmut generated
mutants_x_block_bootstrap_ci__mutmut['x_block_bootstrap_ci__mutmut_62'] = x_block_bootstrap_ci__mutmut_62 # type: ignore # mutmut generated
mutants_x_block_bootstrap_ci__mutmut['x_block_bootstrap_ci__mutmut_63'] = x_block_bootstrap_ci__mutmut_63 # type: ignore # mutmut generated
mutants_x_block_bootstrap_ci__mutmut['x_block_bootstrap_ci__mutmut_64'] = x_block_bootstrap_ci__mutmut_64 # type: ignore # mutmut generated
mutants_x_block_bootstrap_ci__mutmut['x_block_bootstrap_ci__mutmut_65'] = x_block_bootstrap_ci__mutmut_65 # type: ignore # mutmut generated
mutants_x_block_bootstrap_ci__mutmut['x_block_bootstrap_ci__mutmut_66'] = x_block_bootstrap_ci__mutmut_66 # type: ignore # mutmut generated
mutants_x_block_bootstrap_ci__mutmut['x_block_bootstrap_ci__mutmut_67'] = x_block_bootstrap_ci__mutmut_67 # type: ignore # mutmut generated
mutants_x_block_bootstrap_ci__mutmut['x_block_bootstrap_ci__mutmut_68'] = x_block_bootstrap_ci__mutmut_68 # type: ignore # mutmut generated
mutants_x_block_bootstrap_ci__mutmut['x_block_bootstrap_ci__mutmut_69'] = x_block_bootstrap_ci__mutmut_69 # type: ignore # mutmut generated
mutants_x_inject_shift__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_inject_shift__mutmut)
def inject_shift(frame, columns, change_time, delta, scale) -> pd.DataFrame:
    """Add ``delta`` training standard deviations to ``columns`` from ``change_time`` on."""
    shifted = frame.copy()
    mask = pd.to_datetime(shifted[TIME_UTC], utc=True) >= pd.Timestamp(change_time)
    shifted.loc[mask, list(columns)] += delta * scale[list(columns)].to_numpy()
    return shifted


def x_inject_shift__mutmut_orig(frame, columns, change_time, delta, scale) -> pd.DataFrame:
    """Add ``delta`` training standard deviations to ``columns`` from ``change_time`` on."""
    shifted = frame.copy()
    mask = pd.to_datetime(shifted[TIME_UTC], utc=True) >= pd.Timestamp(change_time)
    shifted.loc[mask, list(columns)] += delta * scale[list(columns)].to_numpy()
    return shifted


def x_inject_shift__mutmut_1(frame, columns, change_time, delta, scale) -> pd.DataFrame:
    """Add ``delta`` training standard deviations to ``columns`` from ``change_time`` on."""
    shifted = None
    mask = pd.to_datetime(shifted[TIME_UTC], utc=True) >= pd.Timestamp(change_time)
    shifted.loc[mask, list(columns)] += delta * scale[list(columns)].to_numpy()
    return shifted


def x_inject_shift__mutmut_2(frame, columns, change_time, delta, scale) -> pd.DataFrame:
    """Add ``delta`` training standard deviations to ``columns`` from ``change_time`` on."""
    shifted = frame.copy()
    mask = None
    shifted.loc[mask, list(columns)] += delta * scale[list(columns)].to_numpy()
    return shifted


def x_inject_shift__mutmut_3(frame, columns, change_time, delta, scale) -> pd.DataFrame:
    """Add ``delta`` training standard deviations to ``columns`` from ``change_time`` on."""
    shifted = frame.copy()
    mask = pd.to_datetime(None, utc=True) >= pd.Timestamp(change_time)
    shifted.loc[mask, list(columns)] += delta * scale[list(columns)].to_numpy()
    return shifted


def x_inject_shift__mutmut_4(frame, columns, change_time, delta, scale) -> pd.DataFrame:
    """Add ``delta`` training standard deviations to ``columns`` from ``change_time`` on."""
    shifted = frame.copy()
    mask = pd.to_datetime(shifted[TIME_UTC], utc=None) >= pd.Timestamp(change_time)
    shifted.loc[mask, list(columns)] += delta * scale[list(columns)].to_numpy()
    return shifted


def x_inject_shift__mutmut_5(frame, columns, change_time, delta, scale) -> pd.DataFrame:
    """Add ``delta`` training standard deviations to ``columns`` from ``change_time`` on."""
    shifted = frame.copy()
    mask = pd.to_datetime(utc=True) >= pd.Timestamp(change_time)
    shifted.loc[mask, list(columns)] += delta * scale[list(columns)].to_numpy()
    return shifted


def x_inject_shift__mutmut_6(frame, columns, change_time, delta, scale) -> pd.DataFrame:
    """Add ``delta`` training standard deviations to ``columns`` from ``change_time`` on."""
    shifted = frame.copy()
    mask = pd.to_datetime(shifted[TIME_UTC], ) >= pd.Timestamp(change_time)
    shifted.loc[mask, list(columns)] += delta * scale[list(columns)].to_numpy()
    return shifted


def x_inject_shift__mutmut_7(frame, columns, change_time, delta, scale) -> pd.DataFrame:
    """Add ``delta`` training standard deviations to ``columns`` from ``change_time`` on."""
    shifted = frame.copy()
    mask = pd.to_datetime(shifted[TIME_UTC], utc=False) >= pd.Timestamp(change_time)
    shifted.loc[mask, list(columns)] += delta * scale[list(columns)].to_numpy()
    return shifted


def x_inject_shift__mutmut_8(frame, columns, change_time, delta, scale) -> pd.DataFrame:
    """Add ``delta`` training standard deviations to ``columns`` from ``change_time`` on."""
    shifted = frame.copy()
    mask = pd.to_datetime(shifted[TIME_UTC], utc=True) > pd.Timestamp(change_time)
    shifted.loc[mask, list(columns)] += delta * scale[list(columns)].to_numpy()
    return shifted


def x_inject_shift__mutmut_9(frame, columns, change_time, delta, scale) -> pd.DataFrame:
    """Add ``delta`` training standard deviations to ``columns`` from ``change_time`` on."""
    shifted = frame.copy()
    mask = pd.to_datetime(shifted[TIME_UTC], utc=True) >= pd.Timestamp(None)
    shifted.loc[mask, list(columns)] += delta * scale[list(columns)].to_numpy()
    return shifted


def x_inject_shift__mutmut_10(frame, columns, change_time, delta, scale) -> pd.DataFrame:
    """Add ``delta`` training standard deviations to ``columns`` from ``change_time`` on."""
    shifted = frame.copy()
    mask = pd.to_datetime(shifted[TIME_UTC], utc=True) >= pd.Timestamp(change_time)
    shifted.loc[mask, list(columns)] = delta * scale[list(columns)].to_numpy()
    return shifted


def x_inject_shift__mutmut_11(frame, columns, change_time, delta, scale) -> pd.DataFrame:
    """Add ``delta`` training standard deviations to ``columns`` from ``change_time`` on."""
    shifted = frame.copy()
    mask = pd.to_datetime(shifted[TIME_UTC], utc=True) >= pd.Timestamp(change_time)
    shifted.loc[mask, list(columns)] -= delta * scale[list(columns)].to_numpy()
    return shifted


def x_inject_shift__mutmut_12(frame, columns, change_time, delta, scale) -> pd.DataFrame:
    """Add ``delta`` training standard deviations to ``columns`` from ``change_time`` on."""
    shifted = frame.copy()
    mask = pd.to_datetime(shifted[TIME_UTC], utc=True) >= pd.Timestamp(change_time)
    shifted.loc[mask, list(None)] += delta * scale[list(columns)].to_numpy()
    return shifted


def x_inject_shift__mutmut_13(frame, columns, change_time, delta, scale) -> pd.DataFrame:
    """Add ``delta`` training standard deviations to ``columns`` from ``change_time`` on."""
    shifted = frame.copy()
    mask = pd.to_datetime(shifted[TIME_UTC], utc=True) >= pd.Timestamp(change_time)
    shifted.loc[mask, list(columns)] += delta / scale[list(columns)].to_numpy()
    return shifted


def x_inject_shift__mutmut_14(frame, columns, change_time, delta, scale) -> pd.DataFrame:
    """Add ``delta`` training standard deviations to ``columns`` from ``change_time`` on."""
    shifted = frame.copy()
    mask = pd.to_datetime(shifted[TIME_UTC], utc=True) >= pd.Timestamp(change_time)
    shifted.loc[mask, list(columns)] += delta * scale[list(None)].to_numpy()
    return shifted

mutants_x_inject_shift__mutmut['_mutmut_orig'] = x_inject_shift__mutmut_orig # type: ignore # mutmut generated
mutants_x_inject_shift__mutmut['x_inject_shift__mutmut_1'] = x_inject_shift__mutmut_1 # type: ignore # mutmut generated
mutants_x_inject_shift__mutmut['x_inject_shift__mutmut_2'] = x_inject_shift__mutmut_2 # type: ignore # mutmut generated
mutants_x_inject_shift__mutmut['x_inject_shift__mutmut_3'] = x_inject_shift__mutmut_3 # type: ignore # mutmut generated
mutants_x_inject_shift__mutmut['x_inject_shift__mutmut_4'] = x_inject_shift__mutmut_4 # type: ignore # mutmut generated
mutants_x_inject_shift__mutmut['x_inject_shift__mutmut_5'] = x_inject_shift__mutmut_5 # type: ignore # mutmut generated
mutants_x_inject_shift__mutmut['x_inject_shift__mutmut_6'] = x_inject_shift__mutmut_6 # type: ignore # mutmut generated
mutants_x_inject_shift__mutmut['x_inject_shift__mutmut_7'] = x_inject_shift__mutmut_7 # type: ignore # mutmut generated
mutants_x_inject_shift__mutmut['x_inject_shift__mutmut_8'] = x_inject_shift__mutmut_8 # type: ignore # mutmut generated
mutants_x_inject_shift__mutmut['x_inject_shift__mutmut_9'] = x_inject_shift__mutmut_9 # type: ignore # mutmut generated
mutants_x_inject_shift__mutmut['x_inject_shift__mutmut_10'] = x_inject_shift__mutmut_10 # type: ignore # mutmut generated
mutants_x_inject_shift__mutmut['x_inject_shift__mutmut_11'] = x_inject_shift__mutmut_11 # type: ignore # mutmut generated
mutants_x_inject_shift__mutmut['x_inject_shift__mutmut_12'] = x_inject_shift__mutmut_12 # type: ignore # mutmut generated
mutants_x_inject_shift__mutmut['x_inject_shift__mutmut_13'] = x_inject_shift__mutmut_13 # type: ignore # mutmut generated
mutants_x_inject_shift__mutmut['x_inject_shift__mutmut_14'] = x_inject_shift__mutmut_14 # type: ignore # mutmut generated
mutants_x_monitor_control__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_monitor_control__mutmut)
def monitor_control(train, val, test, columns, deltas=DELTAS, window_size=WINDOW_SIZE):
    """Known-change control: the threshold comes from validation, the change from the test."""
    scale = train[list(columns)].std(ddof=0).replace(0.0, 1.0)
    monitor = WindowDriftMonitor(TIME_UTC, columns, window_size=window_size, threshold=1e12)
    monitor.fit(train)
    threshold = float(monitor.evaluate(val)["score"].max())
    monitor.threshold = threshold
    val_windows = monitor.evaluate(val)
    ordered = sorted(test[TIME_UTC].unique())
    change = pd.Timestamp(ordered[len(ordered) // 2])
    controls = {}
    for delta in deltas:
        windows = monitor.evaluate(inject_shift(test, columns, change, delta, scale))
        metrics = event_metrics(windows, change)
        after = windows[pd.to_datetime(windows["window_end"], utc=True) >= change]
        alerts = np.flatnonzero(after["alert"].to_numpy())
        controls[str(float(delta))] = {
            "detected": metrics["detected"],
            "false_alarm_rate": metrics["false_alarm_rate"],
            "delay_seconds": (
                float(metrics["detection_delay"].total_seconds()) if metrics["detected"] else None
            ),
            "delay_windows": int(alerts[0]) + 1 if len(alerts) else None,
            "windows_before": int((pd.to_datetime(windows["window_end"], utc=True) < change).sum()),
            "windows_after": len(after),
        }
    return {
        "threshold": threshold,
        "validation_windows": len(val_windows),
        "validation_false_alarms": int(val_windows["alert"].sum()),
        "change_time": change.isoformat(),
        "window_size": window_size,
        "columns": list(columns),
        "controls": controls,
    }


def x_monitor_control__mutmut_orig(train, val, test, columns, deltas=DELTAS, window_size=WINDOW_SIZE):
    """Known-change control: the threshold comes from validation, the change from the test."""
    scale = train[list(columns)].std(ddof=0).replace(0.0, 1.0)
    monitor = WindowDriftMonitor(TIME_UTC, columns, window_size=window_size, threshold=1e12)
    monitor.fit(train)
    threshold = float(monitor.evaluate(val)["score"].max())
    monitor.threshold = threshold
    val_windows = monitor.evaluate(val)
    ordered = sorted(test[TIME_UTC].unique())
    change = pd.Timestamp(ordered[len(ordered) // 2])
    controls = {}
    for delta in deltas:
        windows = monitor.evaluate(inject_shift(test, columns, change, delta, scale))
        metrics = event_metrics(windows, change)
        after = windows[pd.to_datetime(windows["window_end"], utc=True) >= change]
        alerts = np.flatnonzero(after["alert"].to_numpy())
        controls[str(float(delta))] = {
            "detected": metrics["detected"],
            "false_alarm_rate": metrics["false_alarm_rate"],
            "delay_seconds": (
                float(metrics["detection_delay"].total_seconds()) if metrics["detected"] else None
            ),
            "delay_windows": int(alerts[0]) + 1 if len(alerts) else None,
            "windows_before": int((pd.to_datetime(windows["window_end"], utc=True) < change).sum()),
            "windows_after": len(after),
        }
    return {
        "threshold": threshold,
        "validation_windows": len(val_windows),
        "validation_false_alarms": int(val_windows["alert"].sum()),
        "change_time": change.isoformat(),
        "window_size": window_size,
        "columns": list(columns),
        "controls": controls,
    }


def x_monitor_control__mutmut_1(train, val, test, columns, deltas=DELTAS, window_size=WINDOW_SIZE):
    """Known-change control: the threshold comes from validation, the change from the test."""
    scale = None
    monitor = WindowDriftMonitor(TIME_UTC, columns, window_size=window_size, threshold=1e12)
    monitor.fit(train)
    threshold = float(monitor.evaluate(val)["score"].max())
    monitor.threshold = threshold
    val_windows = monitor.evaluate(val)
    ordered = sorted(test[TIME_UTC].unique())
    change = pd.Timestamp(ordered[len(ordered) // 2])
    controls = {}
    for delta in deltas:
        windows = monitor.evaluate(inject_shift(test, columns, change, delta, scale))
        metrics = event_metrics(windows, change)
        after = windows[pd.to_datetime(windows["window_end"], utc=True) >= change]
        alerts = np.flatnonzero(after["alert"].to_numpy())
        controls[str(float(delta))] = {
            "detected": metrics["detected"],
            "false_alarm_rate": metrics["false_alarm_rate"],
            "delay_seconds": (
                float(metrics["detection_delay"].total_seconds()) if metrics["detected"] else None
            ),
            "delay_windows": int(alerts[0]) + 1 if len(alerts) else None,
            "windows_before": int((pd.to_datetime(windows["window_end"], utc=True) < change).sum()),
            "windows_after": len(after),
        }
    return {
        "threshold": threshold,
        "validation_windows": len(val_windows),
        "validation_false_alarms": int(val_windows["alert"].sum()),
        "change_time": change.isoformat(),
        "window_size": window_size,
        "columns": list(columns),
        "controls": controls,
    }


def x_monitor_control__mutmut_2(train, val, test, columns, deltas=DELTAS, window_size=WINDOW_SIZE):
    """Known-change control: the threshold comes from validation, the change from the test."""
    scale = train[list(columns)].std(ddof=0).replace(None, 1.0)
    monitor = WindowDriftMonitor(TIME_UTC, columns, window_size=window_size, threshold=1e12)
    monitor.fit(train)
    threshold = float(monitor.evaluate(val)["score"].max())
    monitor.threshold = threshold
    val_windows = monitor.evaluate(val)
    ordered = sorted(test[TIME_UTC].unique())
    change = pd.Timestamp(ordered[len(ordered) // 2])
    controls = {}
    for delta in deltas:
        windows = monitor.evaluate(inject_shift(test, columns, change, delta, scale))
        metrics = event_metrics(windows, change)
        after = windows[pd.to_datetime(windows["window_end"], utc=True) >= change]
        alerts = np.flatnonzero(after["alert"].to_numpy())
        controls[str(float(delta))] = {
            "detected": metrics["detected"],
            "false_alarm_rate": metrics["false_alarm_rate"],
            "delay_seconds": (
                float(metrics["detection_delay"].total_seconds()) if metrics["detected"] else None
            ),
            "delay_windows": int(alerts[0]) + 1 if len(alerts) else None,
            "windows_before": int((pd.to_datetime(windows["window_end"], utc=True) < change).sum()),
            "windows_after": len(after),
        }
    return {
        "threshold": threshold,
        "validation_windows": len(val_windows),
        "validation_false_alarms": int(val_windows["alert"].sum()),
        "change_time": change.isoformat(),
        "window_size": window_size,
        "columns": list(columns),
        "controls": controls,
    }


def x_monitor_control__mutmut_3(train, val, test, columns, deltas=DELTAS, window_size=WINDOW_SIZE):
    """Known-change control: the threshold comes from validation, the change from the test."""
    scale = train[list(columns)].std(ddof=0).replace(0.0, None)
    monitor = WindowDriftMonitor(TIME_UTC, columns, window_size=window_size, threshold=1e12)
    monitor.fit(train)
    threshold = float(monitor.evaluate(val)["score"].max())
    monitor.threshold = threshold
    val_windows = monitor.evaluate(val)
    ordered = sorted(test[TIME_UTC].unique())
    change = pd.Timestamp(ordered[len(ordered) // 2])
    controls = {}
    for delta in deltas:
        windows = monitor.evaluate(inject_shift(test, columns, change, delta, scale))
        metrics = event_metrics(windows, change)
        after = windows[pd.to_datetime(windows["window_end"], utc=True) >= change]
        alerts = np.flatnonzero(after["alert"].to_numpy())
        controls[str(float(delta))] = {
            "detected": metrics["detected"],
            "false_alarm_rate": metrics["false_alarm_rate"],
            "delay_seconds": (
                float(metrics["detection_delay"].total_seconds()) if metrics["detected"] else None
            ),
            "delay_windows": int(alerts[0]) + 1 if len(alerts) else None,
            "windows_before": int((pd.to_datetime(windows["window_end"], utc=True) < change).sum()),
            "windows_after": len(after),
        }
    return {
        "threshold": threshold,
        "validation_windows": len(val_windows),
        "validation_false_alarms": int(val_windows["alert"].sum()),
        "change_time": change.isoformat(),
        "window_size": window_size,
        "columns": list(columns),
        "controls": controls,
    }


def x_monitor_control__mutmut_4(train, val, test, columns, deltas=DELTAS, window_size=WINDOW_SIZE):
    """Known-change control: the threshold comes from validation, the change from the test."""
    scale = train[list(columns)].std(ddof=0).replace(1.0)
    monitor = WindowDriftMonitor(TIME_UTC, columns, window_size=window_size, threshold=1e12)
    monitor.fit(train)
    threshold = float(monitor.evaluate(val)["score"].max())
    monitor.threshold = threshold
    val_windows = monitor.evaluate(val)
    ordered = sorted(test[TIME_UTC].unique())
    change = pd.Timestamp(ordered[len(ordered) // 2])
    controls = {}
    for delta in deltas:
        windows = monitor.evaluate(inject_shift(test, columns, change, delta, scale))
        metrics = event_metrics(windows, change)
        after = windows[pd.to_datetime(windows["window_end"], utc=True) >= change]
        alerts = np.flatnonzero(after["alert"].to_numpy())
        controls[str(float(delta))] = {
            "detected": metrics["detected"],
            "false_alarm_rate": metrics["false_alarm_rate"],
            "delay_seconds": (
                float(metrics["detection_delay"].total_seconds()) if metrics["detected"] else None
            ),
            "delay_windows": int(alerts[0]) + 1 if len(alerts) else None,
            "windows_before": int((pd.to_datetime(windows["window_end"], utc=True) < change).sum()),
            "windows_after": len(after),
        }
    return {
        "threshold": threshold,
        "validation_windows": len(val_windows),
        "validation_false_alarms": int(val_windows["alert"].sum()),
        "change_time": change.isoformat(),
        "window_size": window_size,
        "columns": list(columns),
        "controls": controls,
    }


def x_monitor_control__mutmut_5(train, val, test, columns, deltas=DELTAS, window_size=WINDOW_SIZE):
    """Known-change control: the threshold comes from validation, the change from the test."""
    scale = train[list(columns)].std(ddof=0).replace(0.0, )
    monitor = WindowDriftMonitor(TIME_UTC, columns, window_size=window_size, threshold=1e12)
    monitor.fit(train)
    threshold = float(monitor.evaluate(val)["score"].max())
    monitor.threshold = threshold
    val_windows = monitor.evaluate(val)
    ordered = sorted(test[TIME_UTC].unique())
    change = pd.Timestamp(ordered[len(ordered) // 2])
    controls = {}
    for delta in deltas:
        windows = monitor.evaluate(inject_shift(test, columns, change, delta, scale))
        metrics = event_metrics(windows, change)
        after = windows[pd.to_datetime(windows["window_end"], utc=True) >= change]
        alerts = np.flatnonzero(after["alert"].to_numpy())
        controls[str(float(delta))] = {
            "detected": metrics["detected"],
            "false_alarm_rate": metrics["false_alarm_rate"],
            "delay_seconds": (
                float(metrics["detection_delay"].total_seconds()) if metrics["detected"] else None
            ),
            "delay_windows": int(alerts[0]) + 1 if len(alerts) else None,
            "windows_before": int((pd.to_datetime(windows["window_end"], utc=True) < change).sum()),
            "windows_after": len(after),
        }
    return {
        "threshold": threshold,
        "validation_windows": len(val_windows),
        "validation_false_alarms": int(val_windows["alert"].sum()),
        "change_time": change.isoformat(),
        "window_size": window_size,
        "columns": list(columns),
        "controls": controls,
    }


def x_monitor_control__mutmut_6(train, val, test, columns, deltas=DELTAS, window_size=WINDOW_SIZE):
    """Known-change control: the threshold comes from validation, the change from the test."""
    scale = train[list(columns)].std(ddof=None).replace(0.0, 1.0)
    monitor = WindowDriftMonitor(TIME_UTC, columns, window_size=window_size, threshold=1e12)
    monitor.fit(train)
    threshold = float(monitor.evaluate(val)["score"].max())
    monitor.threshold = threshold
    val_windows = monitor.evaluate(val)
    ordered = sorted(test[TIME_UTC].unique())
    change = pd.Timestamp(ordered[len(ordered) // 2])
    controls = {}
    for delta in deltas:
        windows = monitor.evaluate(inject_shift(test, columns, change, delta, scale))
        metrics = event_metrics(windows, change)
        after = windows[pd.to_datetime(windows["window_end"], utc=True) >= change]
        alerts = np.flatnonzero(after["alert"].to_numpy())
        controls[str(float(delta))] = {
            "detected": metrics["detected"],
            "false_alarm_rate": metrics["false_alarm_rate"],
            "delay_seconds": (
                float(metrics["detection_delay"].total_seconds()) if metrics["detected"] else None
            ),
            "delay_windows": int(alerts[0]) + 1 if len(alerts) else None,
            "windows_before": int((pd.to_datetime(windows["window_end"], utc=True) < change).sum()),
            "windows_after": len(after),
        }
    return {
        "threshold": threshold,
        "validation_windows": len(val_windows),
        "validation_false_alarms": int(val_windows["alert"].sum()),
        "change_time": change.isoformat(),
        "window_size": window_size,
        "columns": list(columns),
        "controls": controls,
    }


def x_monitor_control__mutmut_7(train, val, test, columns, deltas=DELTAS, window_size=WINDOW_SIZE):
    """Known-change control: the threshold comes from validation, the change from the test."""
    scale = train[list(None)].std(ddof=0).replace(0.0, 1.0)
    monitor = WindowDriftMonitor(TIME_UTC, columns, window_size=window_size, threshold=1e12)
    monitor.fit(train)
    threshold = float(monitor.evaluate(val)["score"].max())
    monitor.threshold = threshold
    val_windows = monitor.evaluate(val)
    ordered = sorted(test[TIME_UTC].unique())
    change = pd.Timestamp(ordered[len(ordered) // 2])
    controls = {}
    for delta in deltas:
        windows = monitor.evaluate(inject_shift(test, columns, change, delta, scale))
        metrics = event_metrics(windows, change)
        after = windows[pd.to_datetime(windows["window_end"], utc=True) >= change]
        alerts = np.flatnonzero(after["alert"].to_numpy())
        controls[str(float(delta))] = {
            "detected": metrics["detected"],
            "false_alarm_rate": metrics["false_alarm_rate"],
            "delay_seconds": (
                float(metrics["detection_delay"].total_seconds()) if metrics["detected"] else None
            ),
            "delay_windows": int(alerts[0]) + 1 if len(alerts) else None,
            "windows_before": int((pd.to_datetime(windows["window_end"], utc=True) < change).sum()),
            "windows_after": len(after),
        }
    return {
        "threshold": threshold,
        "validation_windows": len(val_windows),
        "validation_false_alarms": int(val_windows["alert"].sum()),
        "change_time": change.isoformat(),
        "window_size": window_size,
        "columns": list(columns),
        "controls": controls,
    }


def x_monitor_control__mutmut_8(train, val, test, columns, deltas=DELTAS, window_size=WINDOW_SIZE):
    """Known-change control: the threshold comes from validation, the change from the test."""
    scale = train[list(columns)].std(ddof=1).replace(0.0, 1.0)
    monitor = WindowDriftMonitor(TIME_UTC, columns, window_size=window_size, threshold=1e12)
    monitor.fit(train)
    threshold = float(monitor.evaluate(val)["score"].max())
    monitor.threshold = threshold
    val_windows = monitor.evaluate(val)
    ordered = sorted(test[TIME_UTC].unique())
    change = pd.Timestamp(ordered[len(ordered) // 2])
    controls = {}
    for delta in deltas:
        windows = monitor.evaluate(inject_shift(test, columns, change, delta, scale))
        metrics = event_metrics(windows, change)
        after = windows[pd.to_datetime(windows["window_end"], utc=True) >= change]
        alerts = np.flatnonzero(after["alert"].to_numpy())
        controls[str(float(delta))] = {
            "detected": metrics["detected"],
            "false_alarm_rate": metrics["false_alarm_rate"],
            "delay_seconds": (
                float(metrics["detection_delay"].total_seconds()) if metrics["detected"] else None
            ),
            "delay_windows": int(alerts[0]) + 1 if len(alerts) else None,
            "windows_before": int((pd.to_datetime(windows["window_end"], utc=True) < change).sum()),
            "windows_after": len(after),
        }
    return {
        "threshold": threshold,
        "validation_windows": len(val_windows),
        "validation_false_alarms": int(val_windows["alert"].sum()),
        "change_time": change.isoformat(),
        "window_size": window_size,
        "columns": list(columns),
        "controls": controls,
    }


def x_monitor_control__mutmut_9(train, val, test, columns, deltas=DELTAS, window_size=WINDOW_SIZE):
    """Known-change control: the threshold comes from validation, the change from the test."""
    scale = train[list(columns)].std(ddof=0).replace(1.0, 1.0)
    monitor = WindowDriftMonitor(TIME_UTC, columns, window_size=window_size, threshold=1e12)
    monitor.fit(train)
    threshold = float(monitor.evaluate(val)["score"].max())
    monitor.threshold = threshold
    val_windows = monitor.evaluate(val)
    ordered = sorted(test[TIME_UTC].unique())
    change = pd.Timestamp(ordered[len(ordered) // 2])
    controls = {}
    for delta in deltas:
        windows = monitor.evaluate(inject_shift(test, columns, change, delta, scale))
        metrics = event_metrics(windows, change)
        after = windows[pd.to_datetime(windows["window_end"], utc=True) >= change]
        alerts = np.flatnonzero(after["alert"].to_numpy())
        controls[str(float(delta))] = {
            "detected": metrics["detected"],
            "false_alarm_rate": metrics["false_alarm_rate"],
            "delay_seconds": (
                float(metrics["detection_delay"].total_seconds()) if metrics["detected"] else None
            ),
            "delay_windows": int(alerts[0]) + 1 if len(alerts) else None,
            "windows_before": int((pd.to_datetime(windows["window_end"], utc=True) < change).sum()),
            "windows_after": len(after),
        }
    return {
        "threshold": threshold,
        "validation_windows": len(val_windows),
        "validation_false_alarms": int(val_windows["alert"].sum()),
        "change_time": change.isoformat(),
        "window_size": window_size,
        "columns": list(columns),
        "controls": controls,
    }


def x_monitor_control__mutmut_10(train, val, test, columns, deltas=DELTAS, window_size=WINDOW_SIZE):
    """Known-change control: the threshold comes from validation, the change from the test."""
    scale = train[list(columns)].std(ddof=0).replace(0.0, 2.0)
    monitor = WindowDriftMonitor(TIME_UTC, columns, window_size=window_size, threshold=1e12)
    monitor.fit(train)
    threshold = float(monitor.evaluate(val)["score"].max())
    monitor.threshold = threshold
    val_windows = monitor.evaluate(val)
    ordered = sorted(test[TIME_UTC].unique())
    change = pd.Timestamp(ordered[len(ordered) // 2])
    controls = {}
    for delta in deltas:
        windows = monitor.evaluate(inject_shift(test, columns, change, delta, scale))
        metrics = event_metrics(windows, change)
        after = windows[pd.to_datetime(windows["window_end"], utc=True) >= change]
        alerts = np.flatnonzero(after["alert"].to_numpy())
        controls[str(float(delta))] = {
            "detected": metrics["detected"],
            "false_alarm_rate": metrics["false_alarm_rate"],
            "delay_seconds": (
                float(metrics["detection_delay"].total_seconds()) if metrics["detected"] else None
            ),
            "delay_windows": int(alerts[0]) + 1 if len(alerts) else None,
            "windows_before": int((pd.to_datetime(windows["window_end"], utc=True) < change).sum()),
            "windows_after": len(after),
        }
    return {
        "threshold": threshold,
        "validation_windows": len(val_windows),
        "validation_false_alarms": int(val_windows["alert"].sum()),
        "change_time": change.isoformat(),
        "window_size": window_size,
        "columns": list(columns),
        "controls": controls,
    }


def x_monitor_control__mutmut_11(train, val, test, columns, deltas=DELTAS, window_size=WINDOW_SIZE):
    """Known-change control: the threshold comes from validation, the change from the test."""
    scale = train[list(columns)].std(ddof=0).replace(0.0, 1.0)
    monitor = None
    monitor.fit(train)
    threshold = float(monitor.evaluate(val)["score"].max())
    monitor.threshold = threshold
    val_windows = monitor.evaluate(val)
    ordered = sorted(test[TIME_UTC].unique())
    change = pd.Timestamp(ordered[len(ordered) // 2])
    controls = {}
    for delta in deltas:
        windows = monitor.evaluate(inject_shift(test, columns, change, delta, scale))
        metrics = event_metrics(windows, change)
        after = windows[pd.to_datetime(windows["window_end"], utc=True) >= change]
        alerts = np.flatnonzero(after["alert"].to_numpy())
        controls[str(float(delta))] = {
            "detected": metrics["detected"],
            "false_alarm_rate": metrics["false_alarm_rate"],
            "delay_seconds": (
                float(metrics["detection_delay"].total_seconds()) if metrics["detected"] else None
            ),
            "delay_windows": int(alerts[0]) + 1 if len(alerts) else None,
            "windows_before": int((pd.to_datetime(windows["window_end"], utc=True) < change).sum()),
            "windows_after": len(after),
        }
    return {
        "threshold": threshold,
        "validation_windows": len(val_windows),
        "validation_false_alarms": int(val_windows["alert"].sum()),
        "change_time": change.isoformat(),
        "window_size": window_size,
        "columns": list(columns),
        "controls": controls,
    }


def x_monitor_control__mutmut_12(train, val, test, columns, deltas=DELTAS, window_size=WINDOW_SIZE):
    """Known-change control: the threshold comes from validation, the change from the test."""
    scale = train[list(columns)].std(ddof=0).replace(0.0, 1.0)
    monitor = WindowDriftMonitor(None, columns, window_size=window_size, threshold=1e12)
    monitor.fit(train)
    threshold = float(monitor.evaluate(val)["score"].max())
    monitor.threshold = threshold
    val_windows = monitor.evaluate(val)
    ordered = sorted(test[TIME_UTC].unique())
    change = pd.Timestamp(ordered[len(ordered) // 2])
    controls = {}
    for delta in deltas:
        windows = monitor.evaluate(inject_shift(test, columns, change, delta, scale))
        metrics = event_metrics(windows, change)
        after = windows[pd.to_datetime(windows["window_end"], utc=True) >= change]
        alerts = np.flatnonzero(after["alert"].to_numpy())
        controls[str(float(delta))] = {
            "detected": metrics["detected"],
            "false_alarm_rate": metrics["false_alarm_rate"],
            "delay_seconds": (
                float(metrics["detection_delay"].total_seconds()) if metrics["detected"] else None
            ),
            "delay_windows": int(alerts[0]) + 1 if len(alerts) else None,
            "windows_before": int((pd.to_datetime(windows["window_end"], utc=True) < change).sum()),
            "windows_after": len(after),
        }
    return {
        "threshold": threshold,
        "validation_windows": len(val_windows),
        "validation_false_alarms": int(val_windows["alert"].sum()),
        "change_time": change.isoformat(),
        "window_size": window_size,
        "columns": list(columns),
        "controls": controls,
    }


def x_monitor_control__mutmut_13(train, val, test, columns, deltas=DELTAS, window_size=WINDOW_SIZE):
    """Known-change control: the threshold comes from validation, the change from the test."""
    scale = train[list(columns)].std(ddof=0).replace(0.0, 1.0)
    monitor = WindowDriftMonitor(TIME_UTC, None, window_size=window_size, threshold=1e12)
    monitor.fit(train)
    threshold = float(monitor.evaluate(val)["score"].max())
    monitor.threshold = threshold
    val_windows = monitor.evaluate(val)
    ordered = sorted(test[TIME_UTC].unique())
    change = pd.Timestamp(ordered[len(ordered) // 2])
    controls = {}
    for delta in deltas:
        windows = monitor.evaluate(inject_shift(test, columns, change, delta, scale))
        metrics = event_metrics(windows, change)
        after = windows[pd.to_datetime(windows["window_end"], utc=True) >= change]
        alerts = np.flatnonzero(after["alert"].to_numpy())
        controls[str(float(delta))] = {
            "detected": metrics["detected"],
            "false_alarm_rate": metrics["false_alarm_rate"],
            "delay_seconds": (
                float(metrics["detection_delay"].total_seconds()) if metrics["detected"] else None
            ),
            "delay_windows": int(alerts[0]) + 1 if len(alerts) else None,
            "windows_before": int((pd.to_datetime(windows["window_end"], utc=True) < change).sum()),
            "windows_after": len(after),
        }
    return {
        "threshold": threshold,
        "validation_windows": len(val_windows),
        "validation_false_alarms": int(val_windows["alert"].sum()),
        "change_time": change.isoformat(),
        "window_size": window_size,
        "columns": list(columns),
        "controls": controls,
    }


def x_monitor_control__mutmut_14(train, val, test, columns, deltas=DELTAS, window_size=WINDOW_SIZE):
    """Known-change control: the threshold comes from validation, the change from the test."""
    scale = train[list(columns)].std(ddof=0).replace(0.0, 1.0)
    monitor = WindowDriftMonitor(TIME_UTC, columns, window_size=None, threshold=1e12)
    monitor.fit(train)
    threshold = float(monitor.evaluate(val)["score"].max())
    monitor.threshold = threshold
    val_windows = monitor.evaluate(val)
    ordered = sorted(test[TIME_UTC].unique())
    change = pd.Timestamp(ordered[len(ordered) // 2])
    controls = {}
    for delta in deltas:
        windows = monitor.evaluate(inject_shift(test, columns, change, delta, scale))
        metrics = event_metrics(windows, change)
        after = windows[pd.to_datetime(windows["window_end"], utc=True) >= change]
        alerts = np.flatnonzero(after["alert"].to_numpy())
        controls[str(float(delta))] = {
            "detected": metrics["detected"],
            "false_alarm_rate": metrics["false_alarm_rate"],
            "delay_seconds": (
                float(metrics["detection_delay"].total_seconds()) if metrics["detected"] else None
            ),
            "delay_windows": int(alerts[0]) + 1 if len(alerts) else None,
            "windows_before": int((pd.to_datetime(windows["window_end"], utc=True) < change).sum()),
            "windows_after": len(after),
        }
    return {
        "threshold": threshold,
        "validation_windows": len(val_windows),
        "validation_false_alarms": int(val_windows["alert"].sum()),
        "change_time": change.isoformat(),
        "window_size": window_size,
        "columns": list(columns),
        "controls": controls,
    }


def x_monitor_control__mutmut_15(train, val, test, columns, deltas=DELTAS, window_size=WINDOW_SIZE):
    """Known-change control: the threshold comes from validation, the change from the test."""
    scale = train[list(columns)].std(ddof=0).replace(0.0, 1.0)
    monitor = WindowDriftMonitor(TIME_UTC, columns, window_size=window_size, threshold=None)
    monitor.fit(train)
    threshold = float(monitor.evaluate(val)["score"].max())
    monitor.threshold = threshold
    val_windows = monitor.evaluate(val)
    ordered = sorted(test[TIME_UTC].unique())
    change = pd.Timestamp(ordered[len(ordered) // 2])
    controls = {}
    for delta in deltas:
        windows = monitor.evaluate(inject_shift(test, columns, change, delta, scale))
        metrics = event_metrics(windows, change)
        after = windows[pd.to_datetime(windows["window_end"], utc=True) >= change]
        alerts = np.flatnonzero(after["alert"].to_numpy())
        controls[str(float(delta))] = {
            "detected": metrics["detected"],
            "false_alarm_rate": metrics["false_alarm_rate"],
            "delay_seconds": (
                float(metrics["detection_delay"].total_seconds()) if metrics["detected"] else None
            ),
            "delay_windows": int(alerts[0]) + 1 if len(alerts) else None,
            "windows_before": int((pd.to_datetime(windows["window_end"], utc=True) < change).sum()),
            "windows_after": len(after),
        }
    return {
        "threshold": threshold,
        "validation_windows": len(val_windows),
        "validation_false_alarms": int(val_windows["alert"].sum()),
        "change_time": change.isoformat(),
        "window_size": window_size,
        "columns": list(columns),
        "controls": controls,
    }


def x_monitor_control__mutmut_16(train, val, test, columns, deltas=DELTAS, window_size=WINDOW_SIZE):
    """Known-change control: the threshold comes from validation, the change from the test."""
    scale = train[list(columns)].std(ddof=0).replace(0.0, 1.0)
    monitor = WindowDriftMonitor(columns, window_size=window_size, threshold=1e12)
    monitor.fit(train)
    threshold = float(monitor.evaluate(val)["score"].max())
    monitor.threshold = threshold
    val_windows = monitor.evaluate(val)
    ordered = sorted(test[TIME_UTC].unique())
    change = pd.Timestamp(ordered[len(ordered) // 2])
    controls = {}
    for delta in deltas:
        windows = monitor.evaluate(inject_shift(test, columns, change, delta, scale))
        metrics = event_metrics(windows, change)
        after = windows[pd.to_datetime(windows["window_end"], utc=True) >= change]
        alerts = np.flatnonzero(after["alert"].to_numpy())
        controls[str(float(delta))] = {
            "detected": metrics["detected"],
            "false_alarm_rate": metrics["false_alarm_rate"],
            "delay_seconds": (
                float(metrics["detection_delay"].total_seconds()) if metrics["detected"] else None
            ),
            "delay_windows": int(alerts[0]) + 1 if len(alerts) else None,
            "windows_before": int((pd.to_datetime(windows["window_end"], utc=True) < change).sum()),
            "windows_after": len(after),
        }
    return {
        "threshold": threshold,
        "validation_windows": len(val_windows),
        "validation_false_alarms": int(val_windows["alert"].sum()),
        "change_time": change.isoformat(),
        "window_size": window_size,
        "columns": list(columns),
        "controls": controls,
    }


def x_monitor_control__mutmut_17(train, val, test, columns, deltas=DELTAS, window_size=WINDOW_SIZE):
    """Known-change control: the threshold comes from validation, the change from the test."""
    scale = train[list(columns)].std(ddof=0).replace(0.0, 1.0)
    monitor = WindowDriftMonitor(TIME_UTC, window_size=window_size, threshold=1e12)
    monitor.fit(train)
    threshold = float(monitor.evaluate(val)["score"].max())
    monitor.threshold = threshold
    val_windows = monitor.evaluate(val)
    ordered = sorted(test[TIME_UTC].unique())
    change = pd.Timestamp(ordered[len(ordered) // 2])
    controls = {}
    for delta in deltas:
        windows = monitor.evaluate(inject_shift(test, columns, change, delta, scale))
        metrics = event_metrics(windows, change)
        after = windows[pd.to_datetime(windows["window_end"], utc=True) >= change]
        alerts = np.flatnonzero(after["alert"].to_numpy())
        controls[str(float(delta))] = {
            "detected": metrics["detected"],
            "false_alarm_rate": metrics["false_alarm_rate"],
            "delay_seconds": (
                float(metrics["detection_delay"].total_seconds()) if metrics["detected"] else None
            ),
            "delay_windows": int(alerts[0]) + 1 if len(alerts) else None,
            "windows_before": int((pd.to_datetime(windows["window_end"], utc=True) < change).sum()),
            "windows_after": len(after),
        }
    return {
        "threshold": threshold,
        "validation_windows": len(val_windows),
        "validation_false_alarms": int(val_windows["alert"].sum()),
        "change_time": change.isoformat(),
        "window_size": window_size,
        "columns": list(columns),
        "controls": controls,
    }


def x_monitor_control__mutmut_18(train, val, test, columns, deltas=DELTAS, window_size=WINDOW_SIZE):
    """Known-change control: the threshold comes from validation, the change from the test."""
    scale = train[list(columns)].std(ddof=0).replace(0.0, 1.0)
    monitor = WindowDriftMonitor(TIME_UTC, columns, threshold=1e12)
    monitor.fit(train)
    threshold = float(monitor.evaluate(val)["score"].max())
    monitor.threshold = threshold
    val_windows = monitor.evaluate(val)
    ordered = sorted(test[TIME_UTC].unique())
    change = pd.Timestamp(ordered[len(ordered) // 2])
    controls = {}
    for delta in deltas:
        windows = monitor.evaluate(inject_shift(test, columns, change, delta, scale))
        metrics = event_metrics(windows, change)
        after = windows[pd.to_datetime(windows["window_end"], utc=True) >= change]
        alerts = np.flatnonzero(after["alert"].to_numpy())
        controls[str(float(delta))] = {
            "detected": metrics["detected"],
            "false_alarm_rate": metrics["false_alarm_rate"],
            "delay_seconds": (
                float(metrics["detection_delay"].total_seconds()) if metrics["detected"] else None
            ),
            "delay_windows": int(alerts[0]) + 1 if len(alerts) else None,
            "windows_before": int((pd.to_datetime(windows["window_end"], utc=True) < change).sum()),
            "windows_after": len(after),
        }
    return {
        "threshold": threshold,
        "validation_windows": len(val_windows),
        "validation_false_alarms": int(val_windows["alert"].sum()),
        "change_time": change.isoformat(),
        "window_size": window_size,
        "columns": list(columns),
        "controls": controls,
    }


def x_monitor_control__mutmut_19(train, val, test, columns, deltas=DELTAS, window_size=WINDOW_SIZE):
    """Known-change control: the threshold comes from validation, the change from the test."""
    scale = train[list(columns)].std(ddof=0).replace(0.0, 1.0)
    monitor = WindowDriftMonitor(TIME_UTC, columns, window_size=window_size, )
    monitor.fit(train)
    threshold = float(monitor.evaluate(val)["score"].max())
    monitor.threshold = threshold
    val_windows = monitor.evaluate(val)
    ordered = sorted(test[TIME_UTC].unique())
    change = pd.Timestamp(ordered[len(ordered) // 2])
    controls = {}
    for delta in deltas:
        windows = monitor.evaluate(inject_shift(test, columns, change, delta, scale))
        metrics = event_metrics(windows, change)
        after = windows[pd.to_datetime(windows["window_end"], utc=True) >= change]
        alerts = np.flatnonzero(after["alert"].to_numpy())
        controls[str(float(delta))] = {
            "detected": metrics["detected"],
            "false_alarm_rate": metrics["false_alarm_rate"],
            "delay_seconds": (
                float(metrics["detection_delay"].total_seconds()) if metrics["detected"] else None
            ),
            "delay_windows": int(alerts[0]) + 1 if len(alerts) else None,
            "windows_before": int((pd.to_datetime(windows["window_end"], utc=True) < change).sum()),
            "windows_after": len(after),
        }
    return {
        "threshold": threshold,
        "validation_windows": len(val_windows),
        "validation_false_alarms": int(val_windows["alert"].sum()),
        "change_time": change.isoformat(),
        "window_size": window_size,
        "columns": list(columns),
        "controls": controls,
    }


def x_monitor_control__mutmut_20(train, val, test, columns, deltas=DELTAS, window_size=WINDOW_SIZE):
    """Known-change control: the threshold comes from validation, the change from the test."""
    scale = train[list(columns)].std(ddof=0).replace(0.0, 1.0)
    monitor = WindowDriftMonitor(TIME_UTC, columns, window_size=window_size, threshold=1000000000001.0)
    monitor.fit(train)
    threshold = float(monitor.evaluate(val)["score"].max())
    monitor.threshold = threshold
    val_windows = monitor.evaluate(val)
    ordered = sorted(test[TIME_UTC].unique())
    change = pd.Timestamp(ordered[len(ordered) // 2])
    controls = {}
    for delta in deltas:
        windows = monitor.evaluate(inject_shift(test, columns, change, delta, scale))
        metrics = event_metrics(windows, change)
        after = windows[pd.to_datetime(windows["window_end"], utc=True) >= change]
        alerts = np.flatnonzero(after["alert"].to_numpy())
        controls[str(float(delta))] = {
            "detected": metrics["detected"],
            "false_alarm_rate": metrics["false_alarm_rate"],
            "delay_seconds": (
                float(metrics["detection_delay"].total_seconds()) if metrics["detected"] else None
            ),
            "delay_windows": int(alerts[0]) + 1 if len(alerts) else None,
            "windows_before": int((pd.to_datetime(windows["window_end"], utc=True) < change).sum()),
            "windows_after": len(after),
        }
    return {
        "threshold": threshold,
        "validation_windows": len(val_windows),
        "validation_false_alarms": int(val_windows["alert"].sum()),
        "change_time": change.isoformat(),
        "window_size": window_size,
        "columns": list(columns),
        "controls": controls,
    }


def x_monitor_control__mutmut_21(train, val, test, columns, deltas=DELTAS, window_size=WINDOW_SIZE):
    """Known-change control: the threshold comes from validation, the change from the test."""
    scale = train[list(columns)].std(ddof=0).replace(0.0, 1.0)
    monitor = WindowDriftMonitor(TIME_UTC, columns, window_size=window_size, threshold=1e12)
    monitor.fit(None)
    threshold = float(monitor.evaluate(val)["score"].max())
    monitor.threshold = threshold
    val_windows = monitor.evaluate(val)
    ordered = sorted(test[TIME_UTC].unique())
    change = pd.Timestamp(ordered[len(ordered) // 2])
    controls = {}
    for delta in deltas:
        windows = monitor.evaluate(inject_shift(test, columns, change, delta, scale))
        metrics = event_metrics(windows, change)
        after = windows[pd.to_datetime(windows["window_end"], utc=True) >= change]
        alerts = np.flatnonzero(after["alert"].to_numpy())
        controls[str(float(delta))] = {
            "detected": metrics["detected"],
            "false_alarm_rate": metrics["false_alarm_rate"],
            "delay_seconds": (
                float(metrics["detection_delay"].total_seconds()) if metrics["detected"] else None
            ),
            "delay_windows": int(alerts[0]) + 1 if len(alerts) else None,
            "windows_before": int((pd.to_datetime(windows["window_end"], utc=True) < change).sum()),
            "windows_after": len(after),
        }
    return {
        "threshold": threshold,
        "validation_windows": len(val_windows),
        "validation_false_alarms": int(val_windows["alert"].sum()),
        "change_time": change.isoformat(),
        "window_size": window_size,
        "columns": list(columns),
        "controls": controls,
    }


def x_monitor_control__mutmut_22(train, val, test, columns, deltas=DELTAS, window_size=WINDOW_SIZE):
    """Known-change control: the threshold comes from validation, the change from the test."""
    scale = train[list(columns)].std(ddof=0).replace(0.0, 1.0)
    monitor = WindowDriftMonitor(TIME_UTC, columns, window_size=window_size, threshold=1e12)
    monitor.fit(train)
    threshold = None
    monitor.threshold = threshold
    val_windows = monitor.evaluate(val)
    ordered = sorted(test[TIME_UTC].unique())
    change = pd.Timestamp(ordered[len(ordered) // 2])
    controls = {}
    for delta in deltas:
        windows = monitor.evaluate(inject_shift(test, columns, change, delta, scale))
        metrics = event_metrics(windows, change)
        after = windows[pd.to_datetime(windows["window_end"], utc=True) >= change]
        alerts = np.flatnonzero(after["alert"].to_numpy())
        controls[str(float(delta))] = {
            "detected": metrics["detected"],
            "false_alarm_rate": metrics["false_alarm_rate"],
            "delay_seconds": (
                float(metrics["detection_delay"].total_seconds()) if metrics["detected"] else None
            ),
            "delay_windows": int(alerts[0]) + 1 if len(alerts) else None,
            "windows_before": int((pd.to_datetime(windows["window_end"], utc=True) < change).sum()),
            "windows_after": len(after),
        }
    return {
        "threshold": threshold,
        "validation_windows": len(val_windows),
        "validation_false_alarms": int(val_windows["alert"].sum()),
        "change_time": change.isoformat(),
        "window_size": window_size,
        "columns": list(columns),
        "controls": controls,
    }


def x_monitor_control__mutmut_23(train, val, test, columns, deltas=DELTAS, window_size=WINDOW_SIZE):
    """Known-change control: the threshold comes from validation, the change from the test."""
    scale = train[list(columns)].std(ddof=0).replace(0.0, 1.0)
    monitor = WindowDriftMonitor(TIME_UTC, columns, window_size=window_size, threshold=1e12)
    monitor.fit(train)
    threshold = float(None)
    monitor.threshold = threshold
    val_windows = monitor.evaluate(val)
    ordered = sorted(test[TIME_UTC].unique())
    change = pd.Timestamp(ordered[len(ordered) // 2])
    controls = {}
    for delta in deltas:
        windows = monitor.evaluate(inject_shift(test, columns, change, delta, scale))
        metrics = event_metrics(windows, change)
        after = windows[pd.to_datetime(windows["window_end"], utc=True) >= change]
        alerts = np.flatnonzero(after["alert"].to_numpy())
        controls[str(float(delta))] = {
            "detected": metrics["detected"],
            "false_alarm_rate": metrics["false_alarm_rate"],
            "delay_seconds": (
                float(metrics["detection_delay"].total_seconds()) if metrics["detected"] else None
            ),
            "delay_windows": int(alerts[0]) + 1 if len(alerts) else None,
            "windows_before": int((pd.to_datetime(windows["window_end"], utc=True) < change).sum()),
            "windows_after": len(after),
        }
    return {
        "threshold": threshold,
        "validation_windows": len(val_windows),
        "validation_false_alarms": int(val_windows["alert"].sum()),
        "change_time": change.isoformat(),
        "window_size": window_size,
        "columns": list(columns),
        "controls": controls,
    }


def x_monitor_control__mutmut_24(train, val, test, columns, deltas=DELTAS, window_size=WINDOW_SIZE):
    """Known-change control: the threshold comes from validation, the change from the test."""
    scale = train[list(columns)].std(ddof=0).replace(0.0, 1.0)
    monitor = WindowDriftMonitor(TIME_UTC, columns, window_size=window_size, threshold=1e12)
    monitor.fit(train)
    threshold = float(monitor.evaluate(None)["score"].max())
    monitor.threshold = threshold
    val_windows = monitor.evaluate(val)
    ordered = sorted(test[TIME_UTC].unique())
    change = pd.Timestamp(ordered[len(ordered) // 2])
    controls = {}
    for delta in deltas:
        windows = monitor.evaluate(inject_shift(test, columns, change, delta, scale))
        metrics = event_metrics(windows, change)
        after = windows[pd.to_datetime(windows["window_end"], utc=True) >= change]
        alerts = np.flatnonzero(after["alert"].to_numpy())
        controls[str(float(delta))] = {
            "detected": metrics["detected"],
            "false_alarm_rate": metrics["false_alarm_rate"],
            "delay_seconds": (
                float(metrics["detection_delay"].total_seconds()) if metrics["detected"] else None
            ),
            "delay_windows": int(alerts[0]) + 1 if len(alerts) else None,
            "windows_before": int((pd.to_datetime(windows["window_end"], utc=True) < change).sum()),
            "windows_after": len(after),
        }
    return {
        "threshold": threshold,
        "validation_windows": len(val_windows),
        "validation_false_alarms": int(val_windows["alert"].sum()),
        "change_time": change.isoformat(),
        "window_size": window_size,
        "columns": list(columns),
        "controls": controls,
    }


def x_monitor_control__mutmut_25(train, val, test, columns, deltas=DELTAS, window_size=WINDOW_SIZE):
    """Known-change control: the threshold comes from validation, the change from the test."""
    scale = train[list(columns)].std(ddof=0).replace(0.0, 1.0)
    monitor = WindowDriftMonitor(TIME_UTC, columns, window_size=window_size, threshold=1e12)
    monitor.fit(train)
    threshold = float(monitor.evaluate(val)["XXscoreXX"].max())
    monitor.threshold = threshold
    val_windows = monitor.evaluate(val)
    ordered = sorted(test[TIME_UTC].unique())
    change = pd.Timestamp(ordered[len(ordered) // 2])
    controls = {}
    for delta in deltas:
        windows = monitor.evaluate(inject_shift(test, columns, change, delta, scale))
        metrics = event_metrics(windows, change)
        after = windows[pd.to_datetime(windows["window_end"], utc=True) >= change]
        alerts = np.flatnonzero(after["alert"].to_numpy())
        controls[str(float(delta))] = {
            "detected": metrics["detected"],
            "false_alarm_rate": metrics["false_alarm_rate"],
            "delay_seconds": (
                float(metrics["detection_delay"].total_seconds()) if metrics["detected"] else None
            ),
            "delay_windows": int(alerts[0]) + 1 if len(alerts) else None,
            "windows_before": int((pd.to_datetime(windows["window_end"], utc=True) < change).sum()),
            "windows_after": len(after),
        }
    return {
        "threshold": threshold,
        "validation_windows": len(val_windows),
        "validation_false_alarms": int(val_windows["alert"].sum()),
        "change_time": change.isoformat(),
        "window_size": window_size,
        "columns": list(columns),
        "controls": controls,
    }


def x_monitor_control__mutmut_26(train, val, test, columns, deltas=DELTAS, window_size=WINDOW_SIZE):
    """Known-change control: the threshold comes from validation, the change from the test."""
    scale = train[list(columns)].std(ddof=0).replace(0.0, 1.0)
    monitor = WindowDriftMonitor(TIME_UTC, columns, window_size=window_size, threshold=1e12)
    monitor.fit(train)
    threshold = float(monitor.evaluate(val)["SCORE"].max())
    monitor.threshold = threshold
    val_windows = monitor.evaluate(val)
    ordered = sorted(test[TIME_UTC].unique())
    change = pd.Timestamp(ordered[len(ordered) // 2])
    controls = {}
    for delta in deltas:
        windows = monitor.evaluate(inject_shift(test, columns, change, delta, scale))
        metrics = event_metrics(windows, change)
        after = windows[pd.to_datetime(windows["window_end"], utc=True) >= change]
        alerts = np.flatnonzero(after["alert"].to_numpy())
        controls[str(float(delta))] = {
            "detected": metrics["detected"],
            "false_alarm_rate": metrics["false_alarm_rate"],
            "delay_seconds": (
                float(metrics["detection_delay"].total_seconds()) if metrics["detected"] else None
            ),
            "delay_windows": int(alerts[0]) + 1 if len(alerts) else None,
            "windows_before": int((pd.to_datetime(windows["window_end"], utc=True) < change).sum()),
            "windows_after": len(after),
        }
    return {
        "threshold": threshold,
        "validation_windows": len(val_windows),
        "validation_false_alarms": int(val_windows["alert"].sum()),
        "change_time": change.isoformat(),
        "window_size": window_size,
        "columns": list(columns),
        "controls": controls,
    }


def x_monitor_control__mutmut_27(train, val, test, columns, deltas=DELTAS, window_size=WINDOW_SIZE):
    """Known-change control: the threshold comes from validation, the change from the test."""
    scale = train[list(columns)].std(ddof=0).replace(0.0, 1.0)
    monitor = WindowDriftMonitor(TIME_UTC, columns, window_size=window_size, threshold=1e12)
    monitor.fit(train)
    threshold = float(monitor.evaluate(val)["score"].max())
    monitor.threshold = None
    val_windows = monitor.evaluate(val)
    ordered = sorted(test[TIME_UTC].unique())
    change = pd.Timestamp(ordered[len(ordered) // 2])
    controls = {}
    for delta in deltas:
        windows = monitor.evaluate(inject_shift(test, columns, change, delta, scale))
        metrics = event_metrics(windows, change)
        after = windows[pd.to_datetime(windows["window_end"], utc=True) >= change]
        alerts = np.flatnonzero(after["alert"].to_numpy())
        controls[str(float(delta))] = {
            "detected": metrics["detected"],
            "false_alarm_rate": metrics["false_alarm_rate"],
            "delay_seconds": (
                float(metrics["detection_delay"].total_seconds()) if metrics["detected"] else None
            ),
            "delay_windows": int(alerts[0]) + 1 if len(alerts) else None,
            "windows_before": int((pd.to_datetime(windows["window_end"], utc=True) < change).sum()),
            "windows_after": len(after),
        }
    return {
        "threshold": threshold,
        "validation_windows": len(val_windows),
        "validation_false_alarms": int(val_windows["alert"].sum()),
        "change_time": change.isoformat(),
        "window_size": window_size,
        "columns": list(columns),
        "controls": controls,
    }


def x_monitor_control__mutmut_28(train, val, test, columns, deltas=DELTAS, window_size=WINDOW_SIZE):
    """Known-change control: the threshold comes from validation, the change from the test."""
    scale = train[list(columns)].std(ddof=0).replace(0.0, 1.0)
    monitor = WindowDriftMonitor(TIME_UTC, columns, window_size=window_size, threshold=1e12)
    monitor.fit(train)
    threshold = float(monitor.evaluate(val)["score"].max())
    monitor.threshold = threshold
    val_windows = None
    ordered = sorted(test[TIME_UTC].unique())
    change = pd.Timestamp(ordered[len(ordered) // 2])
    controls = {}
    for delta in deltas:
        windows = monitor.evaluate(inject_shift(test, columns, change, delta, scale))
        metrics = event_metrics(windows, change)
        after = windows[pd.to_datetime(windows["window_end"], utc=True) >= change]
        alerts = np.flatnonzero(after["alert"].to_numpy())
        controls[str(float(delta))] = {
            "detected": metrics["detected"],
            "false_alarm_rate": metrics["false_alarm_rate"],
            "delay_seconds": (
                float(metrics["detection_delay"].total_seconds()) if metrics["detected"] else None
            ),
            "delay_windows": int(alerts[0]) + 1 if len(alerts) else None,
            "windows_before": int((pd.to_datetime(windows["window_end"], utc=True) < change).sum()),
            "windows_after": len(after),
        }
    return {
        "threshold": threshold,
        "validation_windows": len(val_windows),
        "validation_false_alarms": int(val_windows["alert"].sum()),
        "change_time": change.isoformat(),
        "window_size": window_size,
        "columns": list(columns),
        "controls": controls,
    }


def x_monitor_control__mutmut_29(train, val, test, columns, deltas=DELTAS, window_size=WINDOW_SIZE):
    """Known-change control: the threshold comes from validation, the change from the test."""
    scale = train[list(columns)].std(ddof=0).replace(0.0, 1.0)
    monitor = WindowDriftMonitor(TIME_UTC, columns, window_size=window_size, threshold=1e12)
    monitor.fit(train)
    threshold = float(monitor.evaluate(val)["score"].max())
    monitor.threshold = threshold
    val_windows = monitor.evaluate(None)
    ordered = sorted(test[TIME_UTC].unique())
    change = pd.Timestamp(ordered[len(ordered) // 2])
    controls = {}
    for delta in deltas:
        windows = monitor.evaluate(inject_shift(test, columns, change, delta, scale))
        metrics = event_metrics(windows, change)
        after = windows[pd.to_datetime(windows["window_end"], utc=True) >= change]
        alerts = np.flatnonzero(after["alert"].to_numpy())
        controls[str(float(delta))] = {
            "detected": metrics["detected"],
            "false_alarm_rate": metrics["false_alarm_rate"],
            "delay_seconds": (
                float(metrics["detection_delay"].total_seconds()) if metrics["detected"] else None
            ),
            "delay_windows": int(alerts[0]) + 1 if len(alerts) else None,
            "windows_before": int((pd.to_datetime(windows["window_end"], utc=True) < change).sum()),
            "windows_after": len(after),
        }
    return {
        "threshold": threshold,
        "validation_windows": len(val_windows),
        "validation_false_alarms": int(val_windows["alert"].sum()),
        "change_time": change.isoformat(),
        "window_size": window_size,
        "columns": list(columns),
        "controls": controls,
    }


def x_monitor_control__mutmut_30(train, val, test, columns, deltas=DELTAS, window_size=WINDOW_SIZE):
    """Known-change control: the threshold comes from validation, the change from the test."""
    scale = train[list(columns)].std(ddof=0).replace(0.0, 1.0)
    monitor = WindowDriftMonitor(TIME_UTC, columns, window_size=window_size, threshold=1e12)
    monitor.fit(train)
    threshold = float(monitor.evaluate(val)["score"].max())
    monitor.threshold = threshold
    val_windows = monitor.evaluate(val)
    ordered = None
    change = pd.Timestamp(ordered[len(ordered) // 2])
    controls = {}
    for delta in deltas:
        windows = monitor.evaluate(inject_shift(test, columns, change, delta, scale))
        metrics = event_metrics(windows, change)
        after = windows[pd.to_datetime(windows["window_end"], utc=True) >= change]
        alerts = np.flatnonzero(after["alert"].to_numpy())
        controls[str(float(delta))] = {
            "detected": metrics["detected"],
            "false_alarm_rate": metrics["false_alarm_rate"],
            "delay_seconds": (
                float(metrics["detection_delay"].total_seconds()) if metrics["detected"] else None
            ),
            "delay_windows": int(alerts[0]) + 1 if len(alerts) else None,
            "windows_before": int((pd.to_datetime(windows["window_end"], utc=True) < change).sum()),
            "windows_after": len(after),
        }
    return {
        "threshold": threshold,
        "validation_windows": len(val_windows),
        "validation_false_alarms": int(val_windows["alert"].sum()),
        "change_time": change.isoformat(),
        "window_size": window_size,
        "columns": list(columns),
        "controls": controls,
    }


def x_monitor_control__mutmut_31(train, val, test, columns, deltas=DELTAS, window_size=WINDOW_SIZE):
    """Known-change control: the threshold comes from validation, the change from the test."""
    scale = train[list(columns)].std(ddof=0).replace(0.0, 1.0)
    monitor = WindowDriftMonitor(TIME_UTC, columns, window_size=window_size, threshold=1e12)
    monitor.fit(train)
    threshold = float(monitor.evaluate(val)["score"].max())
    monitor.threshold = threshold
    val_windows = monitor.evaluate(val)
    ordered = sorted(None)
    change = pd.Timestamp(ordered[len(ordered) // 2])
    controls = {}
    for delta in deltas:
        windows = monitor.evaluate(inject_shift(test, columns, change, delta, scale))
        metrics = event_metrics(windows, change)
        after = windows[pd.to_datetime(windows["window_end"], utc=True) >= change]
        alerts = np.flatnonzero(after["alert"].to_numpy())
        controls[str(float(delta))] = {
            "detected": metrics["detected"],
            "false_alarm_rate": metrics["false_alarm_rate"],
            "delay_seconds": (
                float(metrics["detection_delay"].total_seconds()) if metrics["detected"] else None
            ),
            "delay_windows": int(alerts[0]) + 1 if len(alerts) else None,
            "windows_before": int((pd.to_datetime(windows["window_end"], utc=True) < change).sum()),
            "windows_after": len(after),
        }
    return {
        "threshold": threshold,
        "validation_windows": len(val_windows),
        "validation_false_alarms": int(val_windows["alert"].sum()),
        "change_time": change.isoformat(),
        "window_size": window_size,
        "columns": list(columns),
        "controls": controls,
    }


def x_monitor_control__mutmut_32(train, val, test, columns, deltas=DELTAS, window_size=WINDOW_SIZE):
    """Known-change control: the threshold comes from validation, the change from the test."""
    scale = train[list(columns)].std(ddof=0).replace(0.0, 1.0)
    monitor = WindowDriftMonitor(TIME_UTC, columns, window_size=window_size, threshold=1e12)
    monitor.fit(train)
    threshold = float(monitor.evaluate(val)["score"].max())
    monitor.threshold = threshold
    val_windows = monitor.evaluate(val)
    ordered = sorted(test[TIME_UTC].unique())
    change = None
    controls = {}
    for delta in deltas:
        windows = monitor.evaluate(inject_shift(test, columns, change, delta, scale))
        metrics = event_metrics(windows, change)
        after = windows[pd.to_datetime(windows["window_end"], utc=True) >= change]
        alerts = np.flatnonzero(after["alert"].to_numpy())
        controls[str(float(delta))] = {
            "detected": metrics["detected"],
            "false_alarm_rate": metrics["false_alarm_rate"],
            "delay_seconds": (
                float(metrics["detection_delay"].total_seconds()) if metrics["detected"] else None
            ),
            "delay_windows": int(alerts[0]) + 1 if len(alerts) else None,
            "windows_before": int((pd.to_datetime(windows["window_end"], utc=True) < change).sum()),
            "windows_after": len(after),
        }
    return {
        "threshold": threshold,
        "validation_windows": len(val_windows),
        "validation_false_alarms": int(val_windows["alert"].sum()),
        "change_time": change.isoformat(),
        "window_size": window_size,
        "columns": list(columns),
        "controls": controls,
    }


def x_monitor_control__mutmut_33(train, val, test, columns, deltas=DELTAS, window_size=WINDOW_SIZE):
    """Known-change control: the threshold comes from validation, the change from the test."""
    scale = train[list(columns)].std(ddof=0).replace(0.0, 1.0)
    monitor = WindowDriftMonitor(TIME_UTC, columns, window_size=window_size, threshold=1e12)
    monitor.fit(train)
    threshold = float(monitor.evaluate(val)["score"].max())
    monitor.threshold = threshold
    val_windows = monitor.evaluate(val)
    ordered = sorted(test[TIME_UTC].unique())
    change = pd.Timestamp(None)
    controls = {}
    for delta in deltas:
        windows = monitor.evaluate(inject_shift(test, columns, change, delta, scale))
        metrics = event_metrics(windows, change)
        after = windows[pd.to_datetime(windows["window_end"], utc=True) >= change]
        alerts = np.flatnonzero(after["alert"].to_numpy())
        controls[str(float(delta))] = {
            "detected": metrics["detected"],
            "false_alarm_rate": metrics["false_alarm_rate"],
            "delay_seconds": (
                float(metrics["detection_delay"].total_seconds()) if metrics["detected"] else None
            ),
            "delay_windows": int(alerts[0]) + 1 if len(alerts) else None,
            "windows_before": int((pd.to_datetime(windows["window_end"], utc=True) < change).sum()),
            "windows_after": len(after),
        }
    return {
        "threshold": threshold,
        "validation_windows": len(val_windows),
        "validation_false_alarms": int(val_windows["alert"].sum()),
        "change_time": change.isoformat(),
        "window_size": window_size,
        "columns": list(columns),
        "controls": controls,
    }


def x_monitor_control__mutmut_34(train, val, test, columns, deltas=DELTAS, window_size=WINDOW_SIZE):
    """Known-change control: the threshold comes from validation, the change from the test."""
    scale = train[list(columns)].std(ddof=0).replace(0.0, 1.0)
    monitor = WindowDriftMonitor(TIME_UTC, columns, window_size=window_size, threshold=1e12)
    monitor.fit(train)
    threshold = float(monitor.evaluate(val)["score"].max())
    monitor.threshold = threshold
    val_windows = monitor.evaluate(val)
    ordered = sorted(test[TIME_UTC].unique())
    change = pd.Timestamp(ordered[len(ordered) / 2])
    controls = {}
    for delta in deltas:
        windows = monitor.evaluate(inject_shift(test, columns, change, delta, scale))
        metrics = event_metrics(windows, change)
        after = windows[pd.to_datetime(windows["window_end"], utc=True) >= change]
        alerts = np.flatnonzero(after["alert"].to_numpy())
        controls[str(float(delta))] = {
            "detected": metrics["detected"],
            "false_alarm_rate": metrics["false_alarm_rate"],
            "delay_seconds": (
                float(metrics["detection_delay"].total_seconds()) if metrics["detected"] else None
            ),
            "delay_windows": int(alerts[0]) + 1 if len(alerts) else None,
            "windows_before": int((pd.to_datetime(windows["window_end"], utc=True) < change).sum()),
            "windows_after": len(after),
        }
    return {
        "threshold": threshold,
        "validation_windows": len(val_windows),
        "validation_false_alarms": int(val_windows["alert"].sum()),
        "change_time": change.isoformat(),
        "window_size": window_size,
        "columns": list(columns),
        "controls": controls,
    }


def x_monitor_control__mutmut_35(train, val, test, columns, deltas=DELTAS, window_size=WINDOW_SIZE):
    """Known-change control: the threshold comes from validation, the change from the test."""
    scale = train[list(columns)].std(ddof=0).replace(0.0, 1.0)
    monitor = WindowDriftMonitor(TIME_UTC, columns, window_size=window_size, threshold=1e12)
    monitor.fit(train)
    threshold = float(monitor.evaluate(val)["score"].max())
    monitor.threshold = threshold
    val_windows = monitor.evaluate(val)
    ordered = sorted(test[TIME_UTC].unique())
    change = pd.Timestamp(ordered[len(ordered) // 3])
    controls = {}
    for delta in deltas:
        windows = monitor.evaluate(inject_shift(test, columns, change, delta, scale))
        metrics = event_metrics(windows, change)
        after = windows[pd.to_datetime(windows["window_end"], utc=True) >= change]
        alerts = np.flatnonzero(after["alert"].to_numpy())
        controls[str(float(delta))] = {
            "detected": metrics["detected"],
            "false_alarm_rate": metrics["false_alarm_rate"],
            "delay_seconds": (
                float(metrics["detection_delay"].total_seconds()) if metrics["detected"] else None
            ),
            "delay_windows": int(alerts[0]) + 1 if len(alerts) else None,
            "windows_before": int((pd.to_datetime(windows["window_end"], utc=True) < change).sum()),
            "windows_after": len(after),
        }
    return {
        "threshold": threshold,
        "validation_windows": len(val_windows),
        "validation_false_alarms": int(val_windows["alert"].sum()),
        "change_time": change.isoformat(),
        "window_size": window_size,
        "columns": list(columns),
        "controls": controls,
    }


def x_monitor_control__mutmut_36(train, val, test, columns, deltas=DELTAS, window_size=WINDOW_SIZE):
    """Known-change control: the threshold comes from validation, the change from the test."""
    scale = train[list(columns)].std(ddof=0).replace(0.0, 1.0)
    monitor = WindowDriftMonitor(TIME_UTC, columns, window_size=window_size, threshold=1e12)
    monitor.fit(train)
    threshold = float(monitor.evaluate(val)["score"].max())
    monitor.threshold = threshold
    val_windows = monitor.evaluate(val)
    ordered = sorted(test[TIME_UTC].unique())
    change = pd.Timestamp(ordered[len(ordered) // 2])
    controls = None
    for delta in deltas:
        windows = monitor.evaluate(inject_shift(test, columns, change, delta, scale))
        metrics = event_metrics(windows, change)
        after = windows[pd.to_datetime(windows["window_end"], utc=True) >= change]
        alerts = np.flatnonzero(after["alert"].to_numpy())
        controls[str(float(delta))] = {
            "detected": metrics["detected"],
            "false_alarm_rate": metrics["false_alarm_rate"],
            "delay_seconds": (
                float(metrics["detection_delay"].total_seconds()) if metrics["detected"] else None
            ),
            "delay_windows": int(alerts[0]) + 1 if len(alerts) else None,
            "windows_before": int((pd.to_datetime(windows["window_end"], utc=True) < change).sum()),
            "windows_after": len(after),
        }
    return {
        "threshold": threshold,
        "validation_windows": len(val_windows),
        "validation_false_alarms": int(val_windows["alert"].sum()),
        "change_time": change.isoformat(),
        "window_size": window_size,
        "columns": list(columns),
        "controls": controls,
    }


def x_monitor_control__mutmut_37(train, val, test, columns, deltas=DELTAS, window_size=WINDOW_SIZE):
    """Known-change control: the threshold comes from validation, the change from the test."""
    scale = train[list(columns)].std(ddof=0).replace(0.0, 1.0)
    monitor = WindowDriftMonitor(TIME_UTC, columns, window_size=window_size, threshold=1e12)
    monitor.fit(train)
    threshold = float(monitor.evaluate(val)["score"].max())
    monitor.threshold = threshold
    val_windows = monitor.evaluate(val)
    ordered = sorted(test[TIME_UTC].unique())
    change = pd.Timestamp(ordered[len(ordered) // 2])
    controls = {}
    for delta in deltas:
        windows = None
        metrics = event_metrics(windows, change)
        after = windows[pd.to_datetime(windows["window_end"], utc=True) >= change]
        alerts = np.flatnonzero(after["alert"].to_numpy())
        controls[str(float(delta))] = {
            "detected": metrics["detected"],
            "false_alarm_rate": metrics["false_alarm_rate"],
            "delay_seconds": (
                float(metrics["detection_delay"].total_seconds()) if metrics["detected"] else None
            ),
            "delay_windows": int(alerts[0]) + 1 if len(alerts) else None,
            "windows_before": int((pd.to_datetime(windows["window_end"], utc=True) < change).sum()),
            "windows_after": len(after),
        }
    return {
        "threshold": threshold,
        "validation_windows": len(val_windows),
        "validation_false_alarms": int(val_windows["alert"].sum()),
        "change_time": change.isoformat(),
        "window_size": window_size,
        "columns": list(columns),
        "controls": controls,
    }


def x_monitor_control__mutmut_38(train, val, test, columns, deltas=DELTAS, window_size=WINDOW_SIZE):
    """Known-change control: the threshold comes from validation, the change from the test."""
    scale = train[list(columns)].std(ddof=0).replace(0.0, 1.0)
    monitor = WindowDriftMonitor(TIME_UTC, columns, window_size=window_size, threshold=1e12)
    monitor.fit(train)
    threshold = float(monitor.evaluate(val)["score"].max())
    monitor.threshold = threshold
    val_windows = monitor.evaluate(val)
    ordered = sorted(test[TIME_UTC].unique())
    change = pd.Timestamp(ordered[len(ordered) // 2])
    controls = {}
    for delta in deltas:
        windows = monitor.evaluate(None)
        metrics = event_metrics(windows, change)
        after = windows[pd.to_datetime(windows["window_end"], utc=True) >= change]
        alerts = np.flatnonzero(after["alert"].to_numpy())
        controls[str(float(delta))] = {
            "detected": metrics["detected"],
            "false_alarm_rate": metrics["false_alarm_rate"],
            "delay_seconds": (
                float(metrics["detection_delay"].total_seconds()) if metrics["detected"] else None
            ),
            "delay_windows": int(alerts[0]) + 1 if len(alerts) else None,
            "windows_before": int((pd.to_datetime(windows["window_end"], utc=True) < change).sum()),
            "windows_after": len(after),
        }
    return {
        "threshold": threshold,
        "validation_windows": len(val_windows),
        "validation_false_alarms": int(val_windows["alert"].sum()),
        "change_time": change.isoformat(),
        "window_size": window_size,
        "columns": list(columns),
        "controls": controls,
    }


def x_monitor_control__mutmut_39(train, val, test, columns, deltas=DELTAS, window_size=WINDOW_SIZE):
    """Known-change control: the threshold comes from validation, the change from the test."""
    scale = train[list(columns)].std(ddof=0).replace(0.0, 1.0)
    monitor = WindowDriftMonitor(TIME_UTC, columns, window_size=window_size, threshold=1e12)
    monitor.fit(train)
    threshold = float(monitor.evaluate(val)["score"].max())
    monitor.threshold = threshold
    val_windows = monitor.evaluate(val)
    ordered = sorted(test[TIME_UTC].unique())
    change = pd.Timestamp(ordered[len(ordered) // 2])
    controls = {}
    for delta in deltas:
        windows = monitor.evaluate(inject_shift(None, columns, change, delta, scale))
        metrics = event_metrics(windows, change)
        after = windows[pd.to_datetime(windows["window_end"], utc=True) >= change]
        alerts = np.flatnonzero(after["alert"].to_numpy())
        controls[str(float(delta))] = {
            "detected": metrics["detected"],
            "false_alarm_rate": metrics["false_alarm_rate"],
            "delay_seconds": (
                float(metrics["detection_delay"].total_seconds()) if metrics["detected"] else None
            ),
            "delay_windows": int(alerts[0]) + 1 if len(alerts) else None,
            "windows_before": int((pd.to_datetime(windows["window_end"], utc=True) < change).sum()),
            "windows_after": len(after),
        }
    return {
        "threshold": threshold,
        "validation_windows": len(val_windows),
        "validation_false_alarms": int(val_windows["alert"].sum()),
        "change_time": change.isoformat(),
        "window_size": window_size,
        "columns": list(columns),
        "controls": controls,
    }


def x_monitor_control__mutmut_40(train, val, test, columns, deltas=DELTAS, window_size=WINDOW_SIZE):
    """Known-change control: the threshold comes from validation, the change from the test."""
    scale = train[list(columns)].std(ddof=0).replace(0.0, 1.0)
    monitor = WindowDriftMonitor(TIME_UTC, columns, window_size=window_size, threshold=1e12)
    monitor.fit(train)
    threshold = float(monitor.evaluate(val)["score"].max())
    monitor.threshold = threshold
    val_windows = monitor.evaluate(val)
    ordered = sorted(test[TIME_UTC].unique())
    change = pd.Timestamp(ordered[len(ordered) // 2])
    controls = {}
    for delta in deltas:
        windows = monitor.evaluate(inject_shift(test, None, change, delta, scale))
        metrics = event_metrics(windows, change)
        after = windows[pd.to_datetime(windows["window_end"], utc=True) >= change]
        alerts = np.flatnonzero(after["alert"].to_numpy())
        controls[str(float(delta))] = {
            "detected": metrics["detected"],
            "false_alarm_rate": metrics["false_alarm_rate"],
            "delay_seconds": (
                float(metrics["detection_delay"].total_seconds()) if metrics["detected"] else None
            ),
            "delay_windows": int(alerts[0]) + 1 if len(alerts) else None,
            "windows_before": int((pd.to_datetime(windows["window_end"], utc=True) < change).sum()),
            "windows_after": len(after),
        }
    return {
        "threshold": threshold,
        "validation_windows": len(val_windows),
        "validation_false_alarms": int(val_windows["alert"].sum()),
        "change_time": change.isoformat(),
        "window_size": window_size,
        "columns": list(columns),
        "controls": controls,
    }


def x_monitor_control__mutmut_41(train, val, test, columns, deltas=DELTAS, window_size=WINDOW_SIZE):
    """Known-change control: the threshold comes from validation, the change from the test."""
    scale = train[list(columns)].std(ddof=0).replace(0.0, 1.0)
    monitor = WindowDriftMonitor(TIME_UTC, columns, window_size=window_size, threshold=1e12)
    monitor.fit(train)
    threshold = float(monitor.evaluate(val)["score"].max())
    monitor.threshold = threshold
    val_windows = monitor.evaluate(val)
    ordered = sorted(test[TIME_UTC].unique())
    change = pd.Timestamp(ordered[len(ordered) // 2])
    controls = {}
    for delta in deltas:
        windows = monitor.evaluate(inject_shift(test, columns, None, delta, scale))
        metrics = event_metrics(windows, change)
        after = windows[pd.to_datetime(windows["window_end"], utc=True) >= change]
        alerts = np.flatnonzero(after["alert"].to_numpy())
        controls[str(float(delta))] = {
            "detected": metrics["detected"],
            "false_alarm_rate": metrics["false_alarm_rate"],
            "delay_seconds": (
                float(metrics["detection_delay"].total_seconds()) if metrics["detected"] else None
            ),
            "delay_windows": int(alerts[0]) + 1 if len(alerts) else None,
            "windows_before": int((pd.to_datetime(windows["window_end"], utc=True) < change).sum()),
            "windows_after": len(after),
        }
    return {
        "threshold": threshold,
        "validation_windows": len(val_windows),
        "validation_false_alarms": int(val_windows["alert"].sum()),
        "change_time": change.isoformat(),
        "window_size": window_size,
        "columns": list(columns),
        "controls": controls,
    }


def x_monitor_control__mutmut_42(train, val, test, columns, deltas=DELTAS, window_size=WINDOW_SIZE):
    """Known-change control: the threshold comes from validation, the change from the test."""
    scale = train[list(columns)].std(ddof=0).replace(0.0, 1.0)
    monitor = WindowDriftMonitor(TIME_UTC, columns, window_size=window_size, threshold=1e12)
    monitor.fit(train)
    threshold = float(monitor.evaluate(val)["score"].max())
    monitor.threshold = threshold
    val_windows = monitor.evaluate(val)
    ordered = sorted(test[TIME_UTC].unique())
    change = pd.Timestamp(ordered[len(ordered) // 2])
    controls = {}
    for delta in deltas:
        windows = monitor.evaluate(inject_shift(test, columns, change, None, scale))
        metrics = event_metrics(windows, change)
        after = windows[pd.to_datetime(windows["window_end"], utc=True) >= change]
        alerts = np.flatnonzero(after["alert"].to_numpy())
        controls[str(float(delta))] = {
            "detected": metrics["detected"],
            "false_alarm_rate": metrics["false_alarm_rate"],
            "delay_seconds": (
                float(metrics["detection_delay"].total_seconds()) if metrics["detected"] else None
            ),
            "delay_windows": int(alerts[0]) + 1 if len(alerts) else None,
            "windows_before": int((pd.to_datetime(windows["window_end"], utc=True) < change).sum()),
            "windows_after": len(after),
        }
    return {
        "threshold": threshold,
        "validation_windows": len(val_windows),
        "validation_false_alarms": int(val_windows["alert"].sum()),
        "change_time": change.isoformat(),
        "window_size": window_size,
        "columns": list(columns),
        "controls": controls,
    }


def x_monitor_control__mutmut_43(train, val, test, columns, deltas=DELTAS, window_size=WINDOW_SIZE):
    """Known-change control: the threshold comes from validation, the change from the test."""
    scale = train[list(columns)].std(ddof=0).replace(0.0, 1.0)
    monitor = WindowDriftMonitor(TIME_UTC, columns, window_size=window_size, threshold=1e12)
    monitor.fit(train)
    threshold = float(monitor.evaluate(val)["score"].max())
    monitor.threshold = threshold
    val_windows = monitor.evaluate(val)
    ordered = sorted(test[TIME_UTC].unique())
    change = pd.Timestamp(ordered[len(ordered) // 2])
    controls = {}
    for delta in deltas:
        windows = monitor.evaluate(inject_shift(test, columns, change, delta, None))
        metrics = event_metrics(windows, change)
        after = windows[pd.to_datetime(windows["window_end"], utc=True) >= change]
        alerts = np.flatnonzero(after["alert"].to_numpy())
        controls[str(float(delta))] = {
            "detected": metrics["detected"],
            "false_alarm_rate": metrics["false_alarm_rate"],
            "delay_seconds": (
                float(metrics["detection_delay"].total_seconds()) if metrics["detected"] else None
            ),
            "delay_windows": int(alerts[0]) + 1 if len(alerts) else None,
            "windows_before": int((pd.to_datetime(windows["window_end"], utc=True) < change).sum()),
            "windows_after": len(after),
        }
    return {
        "threshold": threshold,
        "validation_windows": len(val_windows),
        "validation_false_alarms": int(val_windows["alert"].sum()),
        "change_time": change.isoformat(),
        "window_size": window_size,
        "columns": list(columns),
        "controls": controls,
    }


def x_monitor_control__mutmut_44(train, val, test, columns, deltas=DELTAS, window_size=WINDOW_SIZE):
    """Known-change control: the threshold comes from validation, the change from the test."""
    scale = train[list(columns)].std(ddof=0).replace(0.0, 1.0)
    monitor = WindowDriftMonitor(TIME_UTC, columns, window_size=window_size, threshold=1e12)
    monitor.fit(train)
    threshold = float(monitor.evaluate(val)["score"].max())
    monitor.threshold = threshold
    val_windows = monitor.evaluate(val)
    ordered = sorted(test[TIME_UTC].unique())
    change = pd.Timestamp(ordered[len(ordered) // 2])
    controls = {}
    for delta in deltas:
        windows = monitor.evaluate(inject_shift(columns, change, delta, scale))
        metrics = event_metrics(windows, change)
        after = windows[pd.to_datetime(windows["window_end"], utc=True) >= change]
        alerts = np.flatnonzero(after["alert"].to_numpy())
        controls[str(float(delta))] = {
            "detected": metrics["detected"],
            "false_alarm_rate": metrics["false_alarm_rate"],
            "delay_seconds": (
                float(metrics["detection_delay"].total_seconds()) if metrics["detected"] else None
            ),
            "delay_windows": int(alerts[0]) + 1 if len(alerts) else None,
            "windows_before": int((pd.to_datetime(windows["window_end"], utc=True) < change).sum()),
            "windows_after": len(after),
        }
    return {
        "threshold": threshold,
        "validation_windows": len(val_windows),
        "validation_false_alarms": int(val_windows["alert"].sum()),
        "change_time": change.isoformat(),
        "window_size": window_size,
        "columns": list(columns),
        "controls": controls,
    }


def x_monitor_control__mutmut_45(train, val, test, columns, deltas=DELTAS, window_size=WINDOW_SIZE):
    """Known-change control: the threshold comes from validation, the change from the test."""
    scale = train[list(columns)].std(ddof=0).replace(0.0, 1.0)
    monitor = WindowDriftMonitor(TIME_UTC, columns, window_size=window_size, threshold=1e12)
    monitor.fit(train)
    threshold = float(monitor.evaluate(val)["score"].max())
    monitor.threshold = threshold
    val_windows = monitor.evaluate(val)
    ordered = sorted(test[TIME_UTC].unique())
    change = pd.Timestamp(ordered[len(ordered) // 2])
    controls = {}
    for delta in deltas:
        windows = monitor.evaluate(inject_shift(test, change, delta, scale))
        metrics = event_metrics(windows, change)
        after = windows[pd.to_datetime(windows["window_end"], utc=True) >= change]
        alerts = np.flatnonzero(after["alert"].to_numpy())
        controls[str(float(delta))] = {
            "detected": metrics["detected"],
            "false_alarm_rate": metrics["false_alarm_rate"],
            "delay_seconds": (
                float(metrics["detection_delay"].total_seconds()) if metrics["detected"] else None
            ),
            "delay_windows": int(alerts[0]) + 1 if len(alerts) else None,
            "windows_before": int((pd.to_datetime(windows["window_end"], utc=True) < change).sum()),
            "windows_after": len(after),
        }
    return {
        "threshold": threshold,
        "validation_windows": len(val_windows),
        "validation_false_alarms": int(val_windows["alert"].sum()),
        "change_time": change.isoformat(),
        "window_size": window_size,
        "columns": list(columns),
        "controls": controls,
    }


def x_monitor_control__mutmut_46(train, val, test, columns, deltas=DELTAS, window_size=WINDOW_SIZE):
    """Known-change control: the threshold comes from validation, the change from the test."""
    scale = train[list(columns)].std(ddof=0).replace(0.0, 1.0)
    monitor = WindowDriftMonitor(TIME_UTC, columns, window_size=window_size, threshold=1e12)
    monitor.fit(train)
    threshold = float(monitor.evaluate(val)["score"].max())
    monitor.threshold = threshold
    val_windows = monitor.evaluate(val)
    ordered = sorted(test[TIME_UTC].unique())
    change = pd.Timestamp(ordered[len(ordered) // 2])
    controls = {}
    for delta in deltas:
        windows = monitor.evaluate(inject_shift(test, columns, delta, scale))
        metrics = event_metrics(windows, change)
        after = windows[pd.to_datetime(windows["window_end"], utc=True) >= change]
        alerts = np.flatnonzero(after["alert"].to_numpy())
        controls[str(float(delta))] = {
            "detected": metrics["detected"],
            "false_alarm_rate": metrics["false_alarm_rate"],
            "delay_seconds": (
                float(metrics["detection_delay"].total_seconds()) if metrics["detected"] else None
            ),
            "delay_windows": int(alerts[0]) + 1 if len(alerts) else None,
            "windows_before": int((pd.to_datetime(windows["window_end"], utc=True) < change).sum()),
            "windows_after": len(after),
        }
    return {
        "threshold": threshold,
        "validation_windows": len(val_windows),
        "validation_false_alarms": int(val_windows["alert"].sum()),
        "change_time": change.isoformat(),
        "window_size": window_size,
        "columns": list(columns),
        "controls": controls,
    }


def x_monitor_control__mutmut_47(train, val, test, columns, deltas=DELTAS, window_size=WINDOW_SIZE):
    """Known-change control: the threshold comes from validation, the change from the test."""
    scale = train[list(columns)].std(ddof=0).replace(0.0, 1.0)
    monitor = WindowDriftMonitor(TIME_UTC, columns, window_size=window_size, threshold=1e12)
    monitor.fit(train)
    threshold = float(monitor.evaluate(val)["score"].max())
    monitor.threshold = threshold
    val_windows = monitor.evaluate(val)
    ordered = sorted(test[TIME_UTC].unique())
    change = pd.Timestamp(ordered[len(ordered) // 2])
    controls = {}
    for delta in deltas:
        windows = monitor.evaluate(inject_shift(test, columns, change, scale))
        metrics = event_metrics(windows, change)
        after = windows[pd.to_datetime(windows["window_end"], utc=True) >= change]
        alerts = np.flatnonzero(after["alert"].to_numpy())
        controls[str(float(delta))] = {
            "detected": metrics["detected"],
            "false_alarm_rate": metrics["false_alarm_rate"],
            "delay_seconds": (
                float(metrics["detection_delay"].total_seconds()) if metrics["detected"] else None
            ),
            "delay_windows": int(alerts[0]) + 1 if len(alerts) else None,
            "windows_before": int((pd.to_datetime(windows["window_end"], utc=True) < change).sum()),
            "windows_after": len(after),
        }
    return {
        "threshold": threshold,
        "validation_windows": len(val_windows),
        "validation_false_alarms": int(val_windows["alert"].sum()),
        "change_time": change.isoformat(),
        "window_size": window_size,
        "columns": list(columns),
        "controls": controls,
    }


def x_monitor_control__mutmut_48(train, val, test, columns, deltas=DELTAS, window_size=WINDOW_SIZE):
    """Known-change control: the threshold comes from validation, the change from the test."""
    scale = train[list(columns)].std(ddof=0).replace(0.0, 1.0)
    monitor = WindowDriftMonitor(TIME_UTC, columns, window_size=window_size, threshold=1e12)
    monitor.fit(train)
    threshold = float(monitor.evaluate(val)["score"].max())
    monitor.threshold = threshold
    val_windows = monitor.evaluate(val)
    ordered = sorted(test[TIME_UTC].unique())
    change = pd.Timestamp(ordered[len(ordered) // 2])
    controls = {}
    for delta in deltas:
        windows = monitor.evaluate(inject_shift(test, columns, change, delta, ))
        metrics = event_metrics(windows, change)
        after = windows[pd.to_datetime(windows["window_end"], utc=True) >= change]
        alerts = np.flatnonzero(after["alert"].to_numpy())
        controls[str(float(delta))] = {
            "detected": metrics["detected"],
            "false_alarm_rate": metrics["false_alarm_rate"],
            "delay_seconds": (
                float(metrics["detection_delay"].total_seconds()) if metrics["detected"] else None
            ),
            "delay_windows": int(alerts[0]) + 1 if len(alerts) else None,
            "windows_before": int((pd.to_datetime(windows["window_end"], utc=True) < change).sum()),
            "windows_after": len(after),
        }
    return {
        "threshold": threshold,
        "validation_windows": len(val_windows),
        "validation_false_alarms": int(val_windows["alert"].sum()),
        "change_time": change.isoformat(),
        "window_size": window_size,
        "columns": list(columns),
        "controls": controls,
    }


def x_monitor_control__mutmut_49(train, val, test, columns, deltas=DELTAS, window_size=WINDOW_SIZE):
    """Known-change control: the threshold comes from validation, the change from the test."""
    scale = train[list(columns)].std(ddof=0).replace(0.0, 1.0)
    monitor = WindowDriftMonitor(TIME_UTC, columns, window_size=window_size, threshold=1e12)
    monitor.fit(train)
    threshold = float(monitor.evaluate(val)["score"].max())
    monitor.threshold = threshold
    val_windows = monitor.evaluate(val)
    ordered = sorted(test[TIME_UTC].unique())
    change = pd.Timestamp(ordered[len(ordered) // 2])
    controls = {}
    for delta in deltas:
        windows = monitor.evaluate(inject_shift(test, columns, change, delta, scale))
        metrics = None
        after = windows[pd.to_datetime(windows["window_end"], utc=True) >= change]
        alerts = np.flatnonzero(after["alert"].to_numpy())
        controls[str(float(delta))] = {
            "detected": metrics["detected"],
            "false_alarm_rate": metrics["false_alarm_rate"],
            "delay_seconds": (
                float(metrics["detection_delay"].total_seconds()) if metrics["detected"] else None
            ),
            "delay_windows": int(alerts[0]) + 1 if len(alerts) else None,
            "windows_before": int((pd.to_datetime(windows["window_end"], utc=True) < change).sum()),
            "windows_after": len(after),
        }
    return {
        "threshold": threshold,
        "validation_windows": len(val_windows),
        "validation_false_alarms": int(val_windows["alert"].sum()),
        "change_time": change.isoformat(),
        "window_size": window_size,
        "columns": list(columns),
        "controls": controls,
    }


def x_monitor_control__mutmut_50(train, val, test, columns, deltas=DELTAS, window_size=WINDOW_SIZE):
    """Known-change control: the threshold comes from validation, the change from the test."""
    scale = train[list(columns)].std(ddof=0).replace(0.0, 1.0)
    monitor = WindowDriftMonitor(TIME_UTC, columns, window_size=window_size, threshold=1e12)
    monitor.fit(train)
    threshold = float(monitor.evaluate(val)["score"].max())
    monitor.threshold = threshold
    val_windows = monitor.evaluate(val)
    ordered = sorted(test[TIME_UTC].unique())
    change = pd.Timestamp(ordered[len(ordered) // 2])
    controls = {}
    for delta in deltas:
        windows = monitor.evaluate(inject_shift(test, columns, change, delta, scale))
        metrics = event_metrics(None, change)
        after = windows[pd.to_datetime(windows["window_end"], utc=True) >= change]
        alerts = np.flatnonzero(after["alert"].to_numpy())
        controls[str(float(delta))] = {
            "detected": metrics["detected"],
            "false_alarm_rate": metrics["false_alarm_rate"],
            "delay_seconds": (
                float(metrics["detection_delay"].total_seconds()) if metrics["detected"] else None
            ),
            "delay_windows": int(alerts[0]) + 1 if len(alerts) else None,
            "windows_before": int((pd.to_datetime(windows["window_end"], utc=True) < change).sum()),
            "windows_after": len(after),
        }
    return {
        "threshold": threshold,
        "validation_windows": len(val_windows),
        "validation_false_alarms": int(val_windows["alert"].sum()),
        "change_time": change.isoformat(),
        "window_size": window_size,
        "columns": list(columns),
        "controls": controls,
    }


def x_monitor_control__mutmut_51(train, val, test, columns, deltas=DELTAS, window_size=WINDOW_SIZE):
    """Known-change control: the threshold comes from validation, the change from the test."""
    scale = train[list(columns)].std(ddof=0).replace(0.0, 1.0)
    monitor = WindowDriftMonitor(TIME_UTC, columns, window_size=window_size, threshold=1e12)
    monitor.fit(train)
    threshold = float(monitor.evaluate(val)["score"].max())
    monitor.threshold = threshold
    val_windows = monitor.evaluate(val)
    ordered = sorted(test[TIME_UTC].unique())
    change = pd.Timestamp(ordered[len(ordered) // 2])
    controls = {}
    for delta in deltas:
        windows = monitor.evaluate(inject_shift(test, columns, change, delta, scale))
        metrics = event_metrics(windows, None)
        after = windows[pd.to_datetime(windows["window_end"], utc=True) >= change]
        alerts = np.flatnonzero(after["alert"].to_numpy())
        controls[str(float(delta))] = {
            "detected": metrics["detected"],
            "false_alarm_rate": metrics["false_alarm_rate"],
            "delay_seconds": (
                float(metrics["detection_delay"].total_seconds()) if metrics["detected"] else None
            ),
            "delay_windows": int(alerts[0]) + 1 if len(alerts) else None,
            "windows_before": int((pd.to_datetime(windows["window_end"], utc=True) < change).sum()),
            "windows_after": len(after),
        }
    return {
        "threshold": threshold,
        "validation_windows": len(val_windows),
        "validation_false_alarms": int(val_windows["alert"].sum()),
        "change_time": change.isoformat(),
        "window_size": window_size,
        "columns": list(columns),
        "controls": controls,
    }


def x_monitor_control__mutmut_52(train, val, test, columns, deltas=DELTAS, window_size=WINDOW_SIZE):
    """Known-change control: the threshold comes from validation, the change from the test."""
    scale = train[list(columns)].std(ddof=0).replace(0.0, 1.0)
    monitor = WindowDriftMonitor(TIME_UTC, columns, window_size=window_size, threshold=1e12)
    monitor.fit(train)
    threshold = float(monitor.evaluate(val)["score"].max())
    monitor.threshold = threshold
    val_windows = monitor.evaluate(val)
    ordered = sorted(test[TIME_UTC].unique())
    change = pd.Timestamp(ordered[len(ordered) // 2])
    controls = {}
    for delta in deltas:
        windows = monitor.evaluate(inject_shift(test, columns, change, delta, scale))
        metrics = event_metrics(change)
        after = windows[pd.to_datetime(windows["window_end"], utc=True) >= change]
        alerts = np.flatnonzero(after["alert"].to_numpy())
        controls[str(float(delta))] = {
            "detected": metrics["detected"],
            "false_alarm_rate": metrics["false_alarm_rate"],
            "delay_seconds": (
                float(metrics["detection_delay"].total_seconds()) if metrics["detected"] else None
            ),
            "delay_windows": int(alerts[0]) + 1 if len(alerts) else None,
            "windows_before": int((pd.to_datetime(windows["window_end"], utc=True) < change).sum()),
            "windows_after": len(after),
        }
    return {
        "threshold": threshold,
        "validation_windows": len(val_windows),
        "validation_false_alarms": int(val_windows["alert"].sum()),
        "change_time": change.isoformat(),
        "window_size": window_size,
        "columns": list(columns),
        "controls": controls,
    }


def x_monitor_control__mutmut_53(train, val, test, columns, deltas=DELTAS, window_size=WINDOW_SIZE):
    """Known-change control: the threshold comes from validation, the change from the test."""
    scale = train[list(columns)].std(ddof=0).replace(0.0, 1.0)
    monitor = WindowDriftMonitor(TIME_UTC, columns, window_size=window_size, threshold=1e12)
    monitor.fit(train)
    threshold = float(monitor.evaluate(val)["score"].max())
    monitor.threshold = threshold
    val_windows = monitor.evaluate(val)
    ordered = sorted(test[TIME_UTC].unique())
    change = pd.Timestamp(ordered[len(ordered) // 2])
    controls = {}
    for delta in deltas:
        windows = monitor.evaluate(inject_shift(test, columns, change, delta, scale))
        metrics = event_metrics(windows, )
        after = windows[pd.to_datetime(windows["window_end"], utc=True) >= change]
        alerts = np.flatnonzero(after["alert"].to_numpy())
        controls[str(float(delta))] = {
            "detected": metrics["detected"],
            "false_alarm_rate": metrics["false_alarm_rate"],
            "delay_seconds": (
                float(metrics["detection_delay"].total_seconds()) if metrics["detected"] else None
            ),
            "delay_windows": int(alerts[0]) + 1 if len(alerts) else None,
            "windows_before": int((pd.to_datetime(windows["window_end"], utc=True) < change).sum()),
            "windows_after": len(after),
        }
    return {
        "threshold": threshold,
        "validation_windows": len(val_windows),
        "validation_false_alarms": int(val_windows["alert"].sum()),
        "change_time": change.isoformat(),
        "window_size": window_size,
        "columns": list(columns),
        "controls": controls,
    }


def x_monitor_control__mutmut_54(train, val, test, columns, deltas=DELTAS, window_size=WINDOW_SIZE):
    """Known-change control: the threshold comes from validation, the change from the test."""
    scale = train[list(columns)].std(ddof=0).replace(0.0, 1.0)
    monitor = WindowDriftMonitor(TIME_UTC, columns, window_size=window_size, threshold=1e12)
    monitor.fit(train)
    threshold = float(monitor.evaluate(val)["score"].max())
    monitor.threshold = threshold
    val_windows = monitor.evaluate(val)
    ordered = sorted(test[TIME_UTC].unique())
    change = pd.Timestamp(ordered[len(ordered) // 2])
    controls = {}
    for delta in deltas:
        windows = monitor.evaluate(inject_shift(test, columns, change, delta, scale))
        metrics = event_metrics(windows, change)
        after = None
        alerts = np.flatnonzero(after["alert"].to_numpy())
        controls[str(float(delta))] = {
            "detected": metrics["detected"],
            "false_alarm_rate": metrics["false_alarm_rate"],
            "delay_seconds": (
                float(metrics["detection_delay"].total_seconds()) if metrics["detected"] else None
            ),
            "delay_windows": int(alerts[0]) + 1 if len(alerts) else None,
            "windows_before": int((pd.to_datetime(windows["window_end"], utc=True) < change).sum()),
            "windows_after": len(after),
        }
    return {
        "threshold": threshold,
        "validation_windows": len(val_windows),
        "validation_false_alarms": int(val_windows["alert"].sum()),
        "change_time": change.isoformat(),
        "window_size": window_size,
        "columns": list(columns),
        "controls": controls,
    }


def x_monitor_control__mutmut_55(train, val, test, columns, deltas=DELTAS, window_size=WINDOW_SIZE):
    """Known-change control: the threshold comes from validation, the change from the test."""
    scale = train[list(columns)].std(ddof=0).replace(0.0, 1.0)
    monitor = WindowDriftMonitor(TIME_UTC, columns, window_size=window_size, threshold=1e12)
    monitor.fit(train)
    threshold = float(monitor.evaluate(val)["score"].max())
    monitor.threshold = threshold
    val_windows = monitor.evaluate(val)
    ordered = sorted(test[TIME_UTC].unique())
    change = pd.Timestamp(ordered[len(ordered) // 2])
    controls = {}
    for delta in deltas:
        windows = monitor.evaluate(inject_shift(test, columns, change, delta, scale))
        metrics = event_metrics(windows, change)
        after = windows[pd.to_datetime(None, utc=True) >= change]
        alerts = np.flatnonzero(after["alert"].to_numpy())
        controls[str(float(delta))] = {
            "detected": metrics["detected"],
            "false_alarm_rate": metrics["false_alarm_rate"],
            "delay_seconds": (
                float(metrics["detection_delay"].total_seconds()) if metrics["detected"] else None
            ),
            "delay_windows": int(alerts[0]) + 1 if len(alerts) else None,
            "windows_before": int((pd.to_datetime(windows["window_end"], utc=True) < change).sum()),
            "windows_after": len(after),
        }
    return {
        "threshold": threshold,
        "validation_windows": len(val_windows),
        "validation_false_alarms": int(val_windows["alert"].sum()),
        "change_time": change.isoformat(),
        "window_size": window_size,
        "columns": list(columns),
        "controls": controls,
    }


def x_monitor_control__mutmut_56(train, val, test, columns, deltas=DELTAS, window_size=WINDOW_SIZE):
    """Known-change control: the threshold comes from validation, the change from the test."""
    scale = train[list(columns)].std(ddof=0).replace(0.0, 1.0)
    monitor = WindowDriftMonitor(TIME_UTC, columns, window_size=window_size, threshold=1e12)
    monitor.fit(train)
    threshold = float(monitor.evaluate(val)["score"].max())
    monitor.threshold = threshold
    val_windows = monitor.evaluate(val)
    ordered = sorted(test[TIME_UTC].unique())
    change = pd.Timestamp(ordered[len(ordered) // 2])
    controls = {}
    for delta in deltas:
        windows = monitor.evaluate(inject_shift(test, columns, change, delta, scale))
        metrics = event_metrics(windows, change)
        after = windows[pd.to_datetime(windows["window_end"], utc=None) >= change]
        alerts = np.flatnonzero(after["alert"].to_numpy())
        controls[str(float(delta))] = {
            "detected": metrics["detected"],
            "false_alarm_rate": metrics["false_alarm_rate"],
            "delay_seconds": (
                float(metrics["detection_delay"].total_seconds()) if metrics["detected"] else None
            ),
            "delay_windows": int(alerts[0]) + 1 if len(alerts) else None,
            "windows_before": int((pd.to_datetime(windows["window_end"], utc=True) < change).sum()),
            "windows_after": len(after),
        }
    return {
        "threshold": threshold,
        "validation_windows": len(val_windows),
        "validation_false_alarms": int(val_windows["alert"].sum()),
        "change_time": change.isoformat(),
        "window_size": window_size,
        "columns": list(columns),
        "controls": controls,
    }


def x_monitor_control__mutmut_57(train, val, test, columns, deltas=DELTAS, window_size=WINDOW_SIZE):
    """Known-change control: the threshold comes from validation, the change from the test."""
    scale = train[list(columns)].std(ddof=0).replace(0.0, 1.0)
    monitor = WindowDriftMonitor(TIME_UTC, columns, window_size=window_size, threshold=1e12)
    monitor.fit(train)
    threshold = float(monitor.evaluate(val)["score"].max())
    monitor.threshold = threshold
    val_windows = monitor.evaluate(val)
    ordered = sorted(test[TIME_UTC].unique())
    change = pd.Timestamp(ordered[len(ordered) // 2])
    controls = {}
    for delta in deltas:
        windows = monitor.evaluate(inject_shift(test, columns, change, delta, scale))
        metrics = event_metrics(windows, change)
        after = windows[pd.to_datetime(utc=True) >= change]
        alerts = np.flatnonzero(after["alert"].to_numpy())
        controls[str(float(delta))] = {
            "detected": metrics["detected"],
            "false_alarm_rate": metrics["false_alarm_rate"],
            "delay_seconds": (
                float(metrics["detection_delay"].total_seconds()) if metrics["detected"] else None
            ),
            "delay_windows": int(alerts[0]) + 1 if len(alerts) else None,
            "windows_before": int((pd.to_datetime(windows["window_end"], utc=True) < change).sum()),
            "windows_after": len(after),
        }
    return {
        "threshold": threshold,
        "validation_windows": len(val_windows),
        "validation_false_alarms": int(val_windows["alert"].sum()),
        "change_time": change.isoformat(),
        "window_size": window_size,
        "columns": list(columns),
        "controls": controls,
    }


def x_monitor_control__mutmut_58(train, val, test, columns, deltas=DELTAS, window_size=WINDOW_SIZE):
    """Known-change control: the threshold comes from validation, the change from the test."""
    scale = train[list(columns)].std(ddof=0).replace(0.0, 1.0)
    monitor = WindowDriftMonitor(TIME_UTC, columns, window_size=window_size, threshold=1e12)
    monitor.fit(train)
    threshold = float(monitor.evaluate(val)["score"].max())
    monitor.threshold = threshold
    val_windows = monitor.evaluate(val)
    ordered = sorted(test[TIME_UTC].unique())
    change = pd.Timestamp(ordered[len(ordered) // 2])
    controls = {}
    for delta in deltas:
        windows = monitor.evaluate(inject_shift(test, columns, change, delta, scale))
        metrics = event_metrics(windows, change)
        after = windows[pd.to_datetime(windows["window_end"], ) >= change]
        alerts = np.flatnonzero(after["alert"].to_numpy())
        controls[str(float(delta))] = {
            "detected": metrics["detected"],
            "false_alarm_rate": metrics["false_alarm_rate"],
            "delay_seconds": (
                float(metrics["detection_delay"].total_seconds()) if metrics["detected"] else None
            ),
            "delay_windows": int(alerts[0]) + 1 if len(alerts) else None,
            "windows_before": int((pd.to_datetime(windows["window_end"], utc=True) < change).sum()),
            "windows_after": len(after),
        }
    return {
        "threshold": threshold,
        "validation_windows": len(val_windows),
        "validation_false_alarms": int(val_windows["alert"].sum()),
        "change_time": change.isoformat(),
        "window_size": window_size,
        "columns": list(columns),
        "controls": controls,
    }


def x_monitor_control__mutmut_59(train, val, test, columns, deltas=DELTAS, window_size=WINDOW_SIZE):
    """Known-change control: the threshold comes from validation, the change from the test."""
    scale = train[list(columns)].std(ddof=0).replace(0.0, 1.0)
    monitor = WindowDriftMonitor(TIME_UTC, columns, window_size=window_size, threshold=1e12)
    monitor.fit(train)
    threshold = float(monitor.evaluate(val)["score"].max())
    monitor.threshold = threshold
    val_windows = monitor.evaluate(val)
    ordered = sorted(test[TIME_UTC].unique())
    change = pd.Timestamp(ordered[len(ordered) // 2])
    controls = {}
    for delta in deltas:
        windows = monitor.evaluate(inject_shift(test, columns, change, delta, scale))
        metrics = event_metrics(windows, change)
        after = windows[pd.to_datetime(windows["XXwindow_endXX"], utc=True) >= change]
        alerts = np.flatnonzero(after["alert"].to_numpy())
        controls[str(float(delta))] = {
            "detected": metrics["detected"],
            "false_alarm_rate": metrics["false_alarm_rate"],
            "delay_seconds": (
                float(metrics["detection_delay"].total_seconds()) if metrics["detected"] else None
            ),
            "delay_windows": int(alerts[0]) + 1 if len(alerts) else None,
            "windows_before": int((pd.to_datetime(windows["window_end"], utc=True) < change).sum()),
            "windows_after": len(after),
        }
    return {
        "threshold": threshold,
        "validation_windows": len(val_windows),
        "validation_false_alarms": int(val_windows["alert"].sum()),
        "change_time": change.isoformat(),
        "window_size": window_size,
        "columns": list(columns),
        "controls": controls,
    }


def x_monitor_control__mutmut_60(train, val, test, columns, deltas=DELTAS, window_size=WINDOW_SIZE):
    """Known-change control: the threshold comes from validation, the change from the test."""
    scale = train[list(columns)].std(ddof=0).replace(0.0, 1.0)
    monitor = WindowDriftMonitor(TIME_UTC, columns, window_size=window_size, threshold=1e12)
    monitor.fit(train)
    threshold = float(monitor.evaluate(val)["score"].max())
    monitor.threshold = threshold
    val_windows = monitor.evaluate(val)
    ordered = sorted(test[TIME_UTC].unique())
    change = pd.Timestamp(ordered[len(ordered) // 2])
    controls = {}
    for delta in deltas:
        windows = monitor.evaluate(inject_shift(test, columns, change, delta, scale))
        metrics = event_metrics(windows, change)
        after = windows[pd.to_datetime(windows["WINDOW_END"], utc=True) >= change]
        alerts = np.flatnonzero(after["alert"].to_numpy())
        controls[str(float(delta))] = {
            "detected": metrics["detected"],
            "false_alarm_rate": metrics["false_alarm_rate"],
            "delay_seconds": (
                float(metrics["detection_delay"].total_seconds()) if metrics["detected"] else None
            ),
            "delay_windows": int(alerts[0]) + 1 if len(alerts) else None,
            "windows_before": int((pd.to_datetime(windows["window_end"], utc=True) < change).sum()),
            "windows_after": len(after),
        }
    return {
        "threshold": threshold,
        "validation_windows": len(val_windows),
        "validation_false_alarms": int(val_windows["alert"].sum()),
        "change_time": change.isoformat(),
        "window_size": window_size,
        "columns": list(columns),
        "controls": controls,
    }


def x_monitor_control__mutmut_61(train, val, test, columns, deltas=DELTAS, window_size=WINDOW_SIZE):
    """Known-change control: the threshold comes from validation, the change from the test."""
    scale = train[list(columns)].std(ddof=0).replace(0.0, 1.0)
    monitor = WindowDriftMonitor(TIME_UTC, columns, window_size=window_size, threshold=1e12)
    monitor.fit(train)
    threshold = float(monitor.evaluate(val)["score"].max())
    monitor.threshold = threshold
    val_windows = monitor.evaluate(val)
    ordered = sorted(test[TIME_UTC].unique())
    change = pd.Timestamp(ordered[len(ordered) // 2])
    controls = {}
    for delta in deltas:
        windows = monitor.evaluate(inject_shift(test, columns, change, delta, scale))
        metrics = event_metrics(windows, change)
        after = windows[pd.to_datetime(windows["window_end"], utc=False) >= change]
        alerts = np.flatnonzero(after["alert"].to_numpy())
        controls[str(float(delta))] = {
            "detected": metrics["detected"],
            "false_alarm_rate": metrics["false_alarm_rate"],
            "delay_seconds": (
                float(metrics["detection_delay"].total_seconds()) if metrics["detected"] else None
            ),
            "delay_windows": int(alerts[0]) + 1 if len(alerts) else None,
            "windows_before": int((pd.to_datetime(windows["window_end"], utc=True) < change).sum()),
            "windows_after": len(after),
        }
    return {
        "threshold": threshold,
        "validation_windows": len(val_windows),
        "validation_false_alarms": int(val_windows["alert"].sum()),
        "change_time": change.isoformat(),
        "window_size": window_size,
        "columns": list(columns),
        "controls": controls,
    }


def x_monitor_control__mutmut_62(train, val, test, columns, deltas=DELTAS, window_size=WINDOW_SIZE):
    """Known-change control: the threshold comes from validation, the change from the test."""
    scale = train[list(columns)].std(ddof=0).replace(0.0, 1.0)
    monitor = WindowDriftMonitor(TIME_UTC, columns, window_size=window_size, threshold=1e12)
    monitor.fit(train)
    threshold = float(monitor.evaluate(val)["score"].max())
    monitor.threshold = threshold
    val_windows = monitor.evaluate(val)
    ordered = sorted(test[TIME_UTC].unique())
    change = pd.Timestamp(ordered[len(ordered) // 2])
    controls = {}
    for delta in deltas:
        windows = monitor.evaluate(inject_shift(test, columns, change, delta, scale))
        metrics = event_metrics(windows, change)
        after = windows[pd.to_datetime(windows["window_end"], utc=True) > change]
        alerts = np.flatnonzero(after["alert"].to_numpy())
        controls[str(float(delta))] = {
            "detected": metrics["detected"],
            "false_alarm_rate": metrics["false_alarm_rate"],
            "delay_seconds": (
                float(metrics["detection_delay"].total_seconds()) if metrics["detected"] else None
            ),
            "delay_windows": int(alerts[0]) + 1 if len(alerts) else None,
            "windows_before": int((pd.to_datetime(windows["window_end"], utc=True) < change).sum()),
            "windows_after": len(after),
        }
    return {
        "threshold": threshold,
        "validation_windows": len(val_windows),
        "validation_false_alarms": int(val_windows["alert"].sum()),
        "change_time": change.isoformat(),
        "window_size": window_size,
        "columns": list(columns),
        "controls": controls,
    }


def x_monitor_control__mutmut_63(train, val, test, columns, deltas=DELTAS, window_size=WINDOW_SIZE):
    """Known-change control: the threshold comes from validation, the change from the test."""
    scale = train[list(columns)].std(ddof=0).replace(0.0, 1.0)
    monitor = WindowDriftMonitor(TIME_UTC, columns, window_size=window_size, threshold=1e12)
    monitor.fit(train)
    threshold = float(monitor.evaluate(val)["score"].max())
    monitor.threshold = threshold
    val_windows = monitor.evaluate(val)
    ordered = sorted(test[TIME_UTC].unique())
    change = pd.Timestamp(ordered[len(ordered) // 2])
    controls = {}
    for delta in deltas:
        windows = monitor.evaluate(inject_shift(test, columns, change, delta, scale))
        metrics = event_metrics(windows, change)
        after = windows[pd.to_datetime(windows["window_end"], utc=True) >= change]
        alerts = None
        controls[str(float(delta))] = {
            "detected": metrics["detected"],
            "false_alarm_rate": metrics["false_alarm_rate"],
            "delay_seconds": (
                float(metrics["detection_delay"].total_seconds()) if metrics["detected"] else None
            ),
            "delay_windows": int(alerts[0]) + 1 if len(alerts) else None,
            "windows_before": int((pd.to_datetime(windows["window_end"], utc=True) < change).sum()),
            "windows_after": len(after),
        }
    return {
        "threshold": threshold,
        "validation_windows": len(val_windows),
        "validation_false_alarms": int(val_windows["alert"].sum()),
        "change_time": change.isoformat(),
        "window_size": window_size,
        "columns": list(columns),
        "controls": controls,
    }


def x_monitor_control__mutmut_64(train, val, test, columns, deltas=DELTAS, window_size=WINDOW_SIZE):
    """Known-change control: the threshold comes from validation, the change from the test."""
    scale = train[list(columns)].std(ddof=0).replace(0.0, 1.0)
    monitor = WindowDriftMonitor(TIME_UTC, columns, window_size=window_size, threshold=1e12)
    monitor.fit(train)
    threshold = float(monitor.evaluate(val)["score"].max())
    monitor.threshold = threshold
    val_windows = monitor.evaluate(val)
    ordered = sorted(test[TIME_UTC].unique())
    change = pd.Timestamp(ordered[len(ordered) // 2])
    controls = {}
    for delta in deltas:
        windows = monitor.evaluate(inject_shift(test, columns, change, delta, scale))
        metrics = event_metrics(windows, change)
        after = windows[pd.to_datetime(windows["window_end"], utc=True) >= change]
        alerts = np.flatnonzero(None)
        controls[str(float(delta))] = {
            "detected": metrics["detected"],
            "false_alarm_rate": metrics["false_alarm_rate"],
            "delay_seconds": (
                float(metrics["detection_delay"].total_seconds()) if metrics["detected"] else None
            ),
            "delay_windows": int(alerts[0]) + 1 if len(alerts) else None,
            "windows_before": int((pd.to_datetime(windows["window_end"], utc=True) < change).sum()),
            "windows_after": len(after),
        }
    return {
        "threshold": threshold,
        "validation_windows": len(val_windows),
        "validation_false_alarms": int(val_windows["alert"].sum()),
        "change_time": change.isoformat(),
        "window_size": window_size,
        "columns": list(columns),
        "controls": controls,
    }


def x_monitor_control__mutmut_65(train, val, test, columns, deltas=DELTAS, window_size=WINDOW_SIZE):
    """Known-change control: the threshold comes from validation, the change from the test."""
    scale = train[list(columns)].std(ddof=0).replace(0.0, 1.0)
    monitor = WindowDriftMonitor(TIME_UTC, columns, window_size=window_size, threshold=1e12)
    monitor.fit(train)
    threshold = float(monitor.evaluate(val)["score"].max())
    monitor.threshold = threshold
    val_windows = monitor.evaluate(val)
    ordered = sorted(test[TIME_UTC].unique())
    change = pd.Timestamp(ordered[len(ordered) // 2])
    controls = {}
    for delta in deltas:
        windows = monitor.evaluate(inject_shift(test, columns, change, delta, scale))
        metrics = event_metrics(windows, change)
        after = windows[pd.to_datetime(windows["window_end"], utc=True) >= change]
        alerts = np.flatnonzero(after["XXalertXX"].to_numpy())
        controls[str(float(delta))] = {
            "detected": metrics["detected"],
            "false_alarm_rate": metrics["false_alarm_rate"],
            "delay_seconds": (
                float(metrics["detection_delay"].total_seconds()) if metrics["detected"] else None
            ),
            "delay_windows": int(alerts[0]) + 1 if len(alerts) else None,
            "windows_before": int((pd.to_datetime(windows["window_end"], utc=True) < change).sum()),
            "windows_after": len(after),
        }
    return {
        "threshold": threshold,
        "validation_windows": len(val_windows),
        "validation_false_alarms": int(val_windows["alert"].sum()),
        "change_time": change.isoformat(),
        "window_size": window_size,
        "columns": list(columns),
        "controls": controls,
    }


def x_monitor_control__mutmut_66(train, val, test, columns, deltas=DELTAS, window_size=WINDOW_SIZE):
    """Known-change control: the threshold comes from validation, the change from the test."""
    scale = train[list(columns)].std(ddof=0).replace(0.0, 1.0)
    monitor = WindowDriftMonitor(TIME_UTC, columns, window_size=window_size, threshold=1e12)
    monitor.fit(train)
    threshold = float(monitor.evaluate(val)["score"].max())
    monitor.threshold = threshold
    val_windows = monitor.evaluate(val)
    ordered = sorted(test[TIME_UTC].unique())
    change = pd.Timestamp(ordered[len(ordered) // 2])
    controls = {}
    for delta in deltas:
        windows = monitor.evaluate(inject_shift(test, columns, change, delta, scale))
        metrics = event_metrics(windows, change)
        after = windows[pd.to_datetime(windows["window_end"], utc=True) >= change]
        alerts = np.flatnonzero(after["ALERT"].to_numpy())
        controls[str(float(delta))] = {
            "detected": metrics["detected"],
            "false_alarm_rate": metrics["false_alarm_rate"],
            "delay_seconds": (
                float(metrics["detection_delay"].total_seconds()) if metrics["detected"] else None
            ),
            "delay_windows": int(alerts[0]) + 1 if len(alerts) else None,
            "windows_before": int((pd.to_datetime(windows["window_end"], utc=True) < change).sum()),
            "windows_after": len(after),
        }
    return {
        "threshold": threshold,
        "validation_windows": len(val_windows),
        "validation_false_alarms": int(val_windows["alert"].sum()),
        "change_time": change.isoformat(),
        "window_size": window_size,
        "columns": list(columns),
        "controls": controls,
    }


def x_monitor_control__mutmut_67(train, val, test, columns, deltas=DELTAS, window_size=WINDOW_SIZE):
    """Known-change control: the threshold comes from validation, the change from the test."""
    scale = train[list(columns)].std(ddof=0).replace(0.0, 1.0)
    monitor = WindowDriftMonitor(TIME_UTC, columns, window_size=window_size, threshold=1e12)
    monitor.fit(train)
    threshold = float(monitor.evaluate(val)["score"].max())
    monitor.threshold = threshold
    val_windows = monitor.evaluate(val)
    ordered = sorted(test[TIME_UTC].unique())
    change = pd.Timestamp(ordered[len(ordered) // 2])
    controls = {}
    for delta in deltas:
        windows = monitor.evaluate(inject_shift(test, columns, change, delta, scale))
        metrics = event_metrics(windows, change)
        after = windows[pd.to_datetime(windows["window_end"], utc=True) >= change]
        alerts = np.flatnonzero(after["alert"].to_numpy())
        controls[str(float(delta))] = None
    return {
        "threshold": threshold,
        "validation_windows": len(val_windows),
        "validation_false_alarms": int(val_windows["alert"].sum()),
        "change_time": change.isoformat(),
        "window_size": window_size,
        "columns": list(columns),
        "controls": controls,
    }


def x_monitor_control__mutmut_68(train, val, test, columns, deltas=DELTAS, window_size=WINDOW_SIZE):
    """Known-change control: the threshold comes from validation, the change from the test."""
    scale = train[list(columns)].std(ddof=0).replace(0.0, 1.0)
    monitor = WindowDriftMonitor(TIME_UTC, columns, window_size=window_size, threshold=1e12)
    monitor.fit(train)
    threshold = float(monitor.evaluate(val)["score"].max())
    monitor.threshold = threshold
    val_windows = monitor.evaluate(val)
    ordered = sorted(test[TIME_UTC].unique())
    change = pd.Timestamp(ordered[len(ordered) // 2])
    controls = {}
    for delta in deltas:
        windows = monitor.evaluate(inject_shift(test, columns, change, delta, scale))
        metrics = event_metrics(windows, change)
        after = windows[pd.to_datetime(windows["window_end"], utc=True) >= change]
        alerts = np.flatnonzero(after["alert"].to_numpy())
        controls[str(None)] = {
            "detected": metrics["detected"],
            "false_alarm_rate": metrics["false_alarm_rate"],
            "delay_seconds": (
                float(metrics["detection_delay"].total_seconds()) if metrics["detected"] else None
            ),
            "delay_windows": int(alerts[0]) + 1 if len(alerts) else None,
            "windows_before": int((pd.to_datetime(windows["window_end"], utc=True) < change).sum()),
            "windows_after": len(after),
        }
    return {
        "threshold": threshold,
        "validation_windows": len(val_windows),
        "validation_false_alarms": int(val_windows["alert"].sum()),
        "change_time": change.isoformat(),
        "window_size": window_size,
        "columns": list(columns),
        "controls": controls,
    }


def x_monitor_control__mutmut_69(train, val, test, columns, deltas=DELTAS, window_size=WINDOW_SIZE):
    """Known-change control: the threshold comes from validation, the change from the test."""
    scale = train[list(columns)].std(ddof=0).replace(0.0, 1.0)
    monitor = WindowDriftMonitor(TIME_UTC, columns, window_size=window_size, threshold=1e12)
    monitor.fit(train)
    threshold = float(monitor.evaluate(val)["score"].max())
    monitor.threshold = threshold
    val_windows = monitor.evaluate(val)
    ordered = sorted(test[TIME_UTC].unique())
    change = pd.Timestamp(ordered[len(ordered) // 2])
    controls = {}
    for delta in deltas:
        windows = monitor.evaluate(inject_shift(test, columns, change, delta, scale))
        metrics = event_metrics(windows, change)
        after = windows[pd.to_datetime(windows["window_end"], utc=True) >= change]
        alerts = np.flatnonzero(after["alert"].to_numpy())
        controls[str(float(None))] = {
            "detected": metrics["detected"],
            "false_alarm_rate": metrics["false_alarm_rate"],
            "delay_seconds": (
                float(metrics["detection_delay"].total_seconds()) if metrics["detected"] else None
            ),
            "delay_windows": int(alerts[0]) + 1 if len(alerts) else None,
            "windows_before": int((pd.to_datetime(windows["window_end"], utc=True) < change).sum()),
            "windows_after": len(after),
        }
    return {
        "threshold": threshold,
        "validation_windows": len(val_windows),
        "validation_false_alarms": int(val_windows["alert"].sum()),
        "change_time": change.isoformat(),
        "window_size": window_size,
        "columns": list(columns),
        "controls": controls,
    }


def x_monitor_control__mutmut_70(train, val, test, columns, deltas=DELTAS, window_size=WINDOW_SIZE):
    """Known-change control: the threshold comes from validation, the change from the test."""
    scale = train[list(columns)].std(ddof=0).replace(0.0, 1.0)
    monitor = WindowDriftMonitor(TIME_UTC, columns, window_size=window_size, threshold=1e12)
    monitor.fit(train)
    threshold = float(monitor.evaluate(val)["score"].max())
    monitor.threshold = threshold
    val_windows = monitor.evaluate(val)
    ordered = sorted(test[TIME_UTC].unique())
    change = pd.Timestamp(ordered[len(ordered) // 2])
    controls = {}
    for delta in deltas:
        windows = monitor.evaluate(inject_shift(test, columns, change, delta, scale))
        metrics = event_metrics(windows, change)
        after = windows[pd.to_datetime(windows["window_end"], utc=True) >= change]
        alerts = np.flatnonzero(after["alert"].to_numpy())
        controls[str(float(delta))] = {
            "XXdetectedXX": metrics["detected"],
            "false_alarm_rate": metrics["false_alarm_rate"],
            "delay_seconds": (
                float(metrics["detection_delay"].total_seconds()) if metrics["detected"] else None
            ),
            "delay_windows": int(alerts[0]) + 1 if len(alerts) else None,
            "windows_before": int((pd.to_datetime(windows["window_end"], utc=True) < change).sum()),
            "windows_after": len(after),
        }
    return {
        "threshold": threshold,
        "validation_windows": len(val_windows),
        "validation_false_alarms": int(val_windows["alert"].sum()),
        "change_time": change.isoformat(),
        "window_size": window_size,
        "columns": list(columns),
        "controls": controls,
    }


def x_monitor_control__mutmut_71(train, val, test, columns, deltas=DELTAS, window_size=WINDOW_SIZE):
    """Known-change control: the threshold comes from validation, the change from the test."""
    scale = train[list(columns)].std(ddof=0).replace(0.0, 1.0)
    monitor = WindowDriftMonitor(TIME_UTC, columns, window_size=window_size, threshold=1e12)
    monitor.fit(train)
    threshold = float(monitor.evaluate(val)["score"].max())
    monitor.threshold = threshold
    val_windows = monitor.evaluate(val)
    ordered = sorted(test[TIME_UTC].unique())
    change = pd.Timestamp(ordered[len(ordered) // 2])
    controls = {}
    for delta in deltas:
        windows = monitor.evaluate(inject_shift(test, columns, change, delta, scale))
        metrics = event_metrics(windows, change)
        after = windows[pd.to_datetime(windows["window_end"], utc=True) >= change]
        alerts = np.flatnonzero(after["alert"].to_numpy())
        controls[str(float(delta))] = {
            "DETECTED": metrics["detected"],
            "false_alarm_rate": metrics["false_alarm_rate"],
            "delay_seconds": (
                float(metrics["detection_delay"].total_seconds()) if metrics["detected"] else None
            ),
            "delay_windows": int(alerts[0]) + 1 if len(alerts) else None,
            "windows_before": int((pd.to_datetime(windows["window_end"], utc=True) < change).sum()),
            "windows_after": len(after),
        }
    return {
        "threshold": threshold,
        "validation_windows": len(val_windows),
        "validation_false_alarms": int(val_windows["alert"].sum()),
        "change_time": change.isoformat(),
        "window_size": window_size,
        "columns": list(columns),
        "controls": controls,
    }


def x_monitor_control__mutmut_72(train, val, test, columns, deltas=DELTAS, window_size=WINDOW_SIZE):
    """Known-change control: the threshold comes from validation, the change from the test."""
    scale = train[list(columns)].std(ddof=0).replace(0.0, 1.0)
    monitor = WindowDriftMonitor(TIME_UTC, columns, window_size=window_size, threshold=1e12)
    monitor.fit(train)
    threshold = float(monitor.evaluate(val)["score"].max())
    monitor.threshold = threshold
    val_windows = monitor.evaluate(val)
    ordered = sorted(test[TIME_UTC].unique())
    change = pd.Timestamp(ordered[len(ordered) // 2])
    controls = {}
    for delta in deltas:
        windows = monitor.evaluate(inject_shift(test, columns, change, delta, scale))
        metrics = event_metrics(windows, change)
        after = windows[pd.to_datetime(windows["window_end"], utc=True) >= change]
        alerts = np.flatnonzero(after["alert"].to_numpy())
        controls[str(float(delta))] = {
            "detected": metrics["XXdetectedXX"],
            "false_alarm_rate": metrics["false_alarm_rate"],
            "delay_seconds": (
                float(metrics["detection_delay"].total_seconds()) if metrics["detected"] else None
            ),
            "delay_windows": int(alerts[0]) + 1 if len(alerts) else None,
            "windows_before": int((pd.to_datetime(windows["window_end"], utc=True) < change).sum()),
            "windows_after": len(after),
        }
    return {
        "threshold": threshold,
        "validation_windows": len(val_windows),
        "validation_false_alarms": int(val_windows["alert"].sum()),
        "change_time": change.isoformat(),
        "window_size": window_size,
        "columns": list(columns),
        "controls": controls,
    }


def x_monitor_control__mutmut_73(train, val, test, columns, deltas=DELTAS, window_size=WINDOW_SIZE):
    """Known-change control: the threshold comes from validation, the change from the test."""
    scale = train[list(columns)].std(ddof=0).replace(0.0, 1.0)
    monitor = WindowDriftMonitor(TIME_UTC, columns, window_size=window_size, threshold=1e12)
    monitor.fit(train)
    threshold = float(monitor.evaluate(val)["score"].max())
    monitor.threshold = threshold
    val_windows = monitor.evaluate(val)
    ordered = sorted(test[TIME_UTC].unique())
    change = pd.Timestamp(ordered[len(ordered) // 2])
    controls = {}
    for delta in deltas:
        windows = monitor.evaluate(inject_shift(test, columns, change, delta, scale))
        metrics = event_metrics(windows, change)
        after = windows[pd.to_datetime(windows["window_end"], utc=True) >= change]
        alerts = np.flatnonzero(after["alert"].to_numpy())
        controls[str(float(delta))] = {
            "detected": metrics["DETECTED"],
            "false_alarm_rate": metrics["false_alarm_rate"],
            "delay_seconds": (
                float(metrics["detection_delay"].total_seconds()) if metrics["detected"] else None
            ),
            "delay_windows": int(alerts[0]) + 1 if len(alerts) else None,
            "windows_before": int((pd.to_datetime(windows["window_end"], utc=True) < change).sum()),
            "windows_after": len(after),
        }
    return {
        "threshold": threshold,
        "validation_windows": len(val_windows),
        "validation_false_alarms": int(val_windows["alert"].sum()),
        "change_time": change.isoformat(),
        "window_size": window_size,
        "columns": list(columns),
        "controls": controls,
    }


def x_monitor_control__mutmut_74(train, val, test, columns, deltas=DELTAS, window_size=WINDOW_SIZE):
    """Known-change control: the threshold comes from validation, the change from the test."""
    scale = train[list(columns)].std(ddof=0).replace(0.0, 1.0)
    monitor = WindowDriftMonitor(TIME_UTC, columns, window_size=window_size, threshold=1e12)
    monitor.fit(train)
    threshold = float(monitor.evaluate(val)["score"].max())
    monitor.threshold = threshold
    val_windows = monitor.evaluate(val)
    ordered = sorted(test[TIME_UTC].unique())
    change = pd.Timestamp(ordered[len(ordered) // 2])
    controls = {}
    for delta in deltas:
        windows = monitor.evaluate(inject_shift(test, columns, change, delta, scale))
        metrics = event_metrics(windows, change)
        after = windows[pd.to_datetime(windows["window_end"], utc=True) >= change]
        alerts = np.flatnonzero(after["alert"].to_numpy())
        controls[str(float(delta))] = {
            "detected": metrics["detected"],
            "XXfalse_alarm_rateXX": metrics["false_alarm_rate"],
            "delay_seconds": (
                float(metrics["detection_delay"].total_seconds()) if metrics["detected"] else None
            ),
            "delay_windows": int(alerts[0]) + 1 if len(alerts) else None,
            "windows_before": int((pd.to_datetime(windows["window_end"], utc=True) < change).sum()),
            "windows_after": len(after),
        }
    return {
        "threshold": threshold,
        "validation_windows": len(val_windows),
        "validation_false_alarms": int(val_windows["alert"].sum()),
        "change_time": change.isoformat(),
        "window_size": window_size,
        "columns": list(columns),
        "controls": controls,
    }


def x_monitor_control__mutmut_75(train, val, test, columns, deltas=DELTAS, window_size=WINDOW_SIZE):
    """Known-change control: the threshold comes from validation, the change from the test."""
    scale = train[list(columns)].std(ddof=0).replace(0.0, 1.0)
    monitor = WindowDriftMonitor(TIME_UTC, columns, window_size=window_size, threshold=1e12)
    monitor.fit(train)
    threshold = float(monitor.evaluate(val)["score"].max())
    monitor.threshold = threshold
    val_windows = monitor.evaluate(val)
    ordered = sorted(test[TIME_UTC].unique())
    change = pd.Timestamp(ordered[len(ordered) // 2])
    controls = {}
    for delta in deltas:
        windows = monitor.evaluate(inject_shift(test, columns, change, delta, scale))
        metrics = event_metrics(windows, change)
        after = windows[pd.to_datetime(windows["window_end"], utc=True) >= change]
        alerts = np.flatnonzero(after["alert"].to_numpy())
        controls[str(float(delta))] = {
            "detected": metrics["detected"],
            "FALSE_ALARM_RATE": metrics["false_alarm_rate"],
            "delay_seconds": (
                float(metrics["detection_delay"].total_seconds()) if metrics["detected"] else None
            ),
            "delay_windows": int(alerts[0]) + 1 if len(alerts) else None,
            "windows_before": int((pd.to_datetime(windows["window_end"], utc=True) < change).sum()),
            "windows_after": len(after),
        }
    return {
        "threshold": threshold,
        "validation_windows": len(val_windows),
        "validation_false_alarms": int(val_windows["alert"].sum()),
        "change_time": change.isoformat(),
        "window_size": window_size,
        "columns": list(columns),
        "controls": controls,
    }


def x_monitor_control__mutmut_76(train, val, test, columns, deltas=DELTAS, window_size=WINDOW_SIZE):
    """Known-change control: the threshold comes from validation, the change from the test."""
    scale = train[list(columns)].std(ddof=0).replace(0.0, 1.0)
    monitor = WindowDriftMonitor(TIME_UTC, columns, window_size=window_size, threshold=1e12)
    monitor.fit(train)
    threshold = float(monitor.evaluate(val)["score"].max())
    monitor.threshold = threshold
    val_windows = monitor.evaluate(val)
    ordered = sorted(test[TIME_UTC].unique())
    change = pd.Timestamp(ordered[len(ordered) // 2])
    controls = {}
    for delta in deltas:
        windows = monitor.evaluate(inject_shift(test, columns, change, delta, scale))
        metrics = event_metrics(windows, change)
        after = windows[pd.to_datetime(windows["window_end"], utc=True) >= change]
        alerts = np.flatnonzero(after["alert"].to_numpy())
        controls[str(float(delta))] = {
            "detected": metrics["detected"],
            "false_alarm_rate": metrics["XXfalse_alarm_rateXX"],
            "delay_seconds": (
                float(metrics["detection_delay"].total_seconds()) if metrics["detected"] else None
            ),
            "delay_windows": int(alerts[0]) + 1 if len(alerts) else None,
            "windows_before": int((pd.to_datetime(windows["window_end"], utc=True) < change).sum()),
            "windows_after": len(after),
        }
    return {
        "threshold": threshold,
        "validation_windows": len(val_windows),
        "validation_false_alarms": int(val_windows["alert"].sum()),
        "change_time": change.isoformat(),
        "window_size": window_size,
        "columns": list(columns),
        "controls": controls,
    }


def x_monitor_control__mutmut_77(train, val, test, columns, deltas=DELTAS, window_size=WINDOW_SIZE):
    """Known-change control: the threshold comes from validation, the change from the test."""
    scale = train[list(columns)].std(ddof=0).replace(0.0, 1.0)
    monitor = WindowDriftMonitor(TIME_UTC, columns, window_size=window_size, threshold=1e12)
    monitor.fit(train)
    threshold = float(monitor.evaluate(val)["score"].max())
    monitor.threshold = threshold
    val_windows = monitor.evaluate(val)
    ordered = sorted(test[TIME_UTC].unique())
    change = pd.Timestamp(ordered[len(ordered) // 2])
    controls = {}
    for delta in deltas:
        windows = monitor.evaluate(inject_shift(test, columns, change, delta, scale))
        metrics = event_metrics(windows, change)
        after = windows[pd.to_datetime(windows["window_end"], utc=True) >= change]
        alerts = np.flatnonzero(after["alert"].to_numpy())
        controls[str(float(delta))] = {
            "detected": metrics["detected"],
            "false_alarm_rate": metrics["FALSE_ALARM_RATE"],
            "delay_seconds": (
                float(metrics["detection_delay"].total_seconds()) if metrics["detected"] else None
            ),
            "delay_windows": int(alerts[0]) + 1 if len(alerts) else None,
            "windows_before": int((pd.to_datetime(windows["window_end"], utc=True) < change).sum()),
            "windows_after": len(after),
        }
    return {
        "threshold": threshold,
        "validation_windows": len(val_windows),
        "validation_false_alarms": int(val_windows["alert"].sum()),
        "change_time": change.isoformat(),
        "window_size": window_size,
        "columns": list(columns),
        "controls": controls,
    }


def x_monitor_control__mutmut_78(train, val, test, columns, deltas=DELTAS, window_size=WINDOW_SIZE):
    """Known-change control: the threshold comes from validation, the change from the test."""
    scale = train[list(columns)].std(ddof=0).replace(0.0, 1.0)
    monitor = WindowDriftMonitor(TIME_UTC, columns, window_size=window_size, threshold=1e12)
    monitor.fit(train)
    threshold = float(monitor.evaluate(val)["score"].max())
    monitor.threshold = threshold
    val_windows = monitor.evaluate(val)
    ordered = sorted(test[TIME_UTC].unique())
    change = pd.Timestamp(ordered[len(ordered) // 2])
    controls = {}
    for delta in deltas:
        windows = monitor.evaluate(inject_shift(test, columns, change, delta, scale))
        metrics = event_metrics(windows, change)
        after = windows[pd.to_datetime(windows["window_end"], utc=True) >= change]
        alerts = np.flatnonzero(after["alert"].to_numpy())
        controls[str(float(delta))] = {
            "detected": metrics["detected"],
            "false_alarm_rate": metrics["false_alarm_rate"],
            "XXdelay_secondsXX": (
                float(metrics["detection_delay"].total_seconds()) if metrics["detected"] else None
            ),
            "delay_windows": int(alerts[0]) + 1 if len(alerts) else None,
            "windows_before": int((pd.to_datetime(windows["window_end"], utc=True) < change).sum()),
            "windows_after": len(after),
        }
    return {
        "threshold": threshold,
        "validation_windows": len(val_windows),
        "validation_false_alarms": int(val_windows["alert"].sum()),
        "change_time": change.isoformat(),
        "window_size": window_size,
        "columns": list(columns),
        "controls": controls,
    }


def x_monitor_control__mutmut_79(train, val, test, columns, deltas=DELTAS, window_size=WINDOW_SIZE):
    """Known-change control: the threshold comes from validation, the change from the test."""
    scale = train[list(columns)].std(ddof=0).replace(0.0, 1.0)
    monitor = WindowDriftMonitor(TIME_UTC, columns, window_size=window_size, threshold=1e12)
    monitor.fit(train)
    threshold = float(monitor.evaluate(val)["score"].max())
    monitor.threshold = threshold
    val_windows = monitor.evaluate(val)
    ordered = sorted(test[TIME_UTC].unique())
    change = pd.Timestamp(ordered[len(ordered) // 2])
    controls = {}
    for delta in deltas:
        windows = monitor.evaluate(inject_shift(test, columns, change, delta, scale))
        metrics = event_metrics(windows, change)
        after = windows[pd.to_datetime(windows["window_end"], utc=True) >= change]
        alerts = np.flatnonzero(after["alert"].to_numpy())
        controls[str(float(delta))] = {
            "detected": metrics["detected"],
            "false_alarm_rate": metrics["false_alarm_rate"],
            "DELAY_SECONDS": (
                float(metrics["detection_delay"].total_seconds()) if metrics["detected"] else None
            ),
            "delay_windows": int(alerts[0]) + 1 if len(alerts) else None,
            "windows_before": int((pd.to_datetime(windows["window_end"], utc=True) < change).sum()),
            "windows_after": len(after),
        }
    return {
        "threshold": threshold,
        "validation_windows": len(val_windows),
        "validation_false_alarms": int(val_windows["alert"].sum()),
        "change_time": change.isoformat(),
        "window_size": window_size,
        "columns": list(columns),
        "controls": controls,
    }


def x_monitor_control__mutmut_80(train, val, test, columns, deltas=DELTAS, window_size=WINDOW_SIZE):
    """Known-change control: the threshold comes from validation, the change from the test."""
    scale = train[list(columns)].std(ddof=0).replace(0.0, 1.0)
    monitor = WindowDriftMonitor(TIME_UTC, columns, window_size=window_size, threshold=1e12)
    monitor.fit(train)
    threshold = float(monitor.evaluate(val)["score"].max())
    monitor.threshold = threshold
    val_windows = monitor.evaluate(val)
    ordered = sorted(test[TIME_UTC].unique())
    change = pd.Timestamp(ordered[len(ordered) // 2])
    controls = {}
    for delta in deltas:
        windows = monitor.evaluate(inject_shift(test, columns, change, delta, scale))
        metrics = event_metrics(windows, change)
        after = windows[pd.to_datetime(windows["window_end"], utc=True) >= change]
        alerts = np.flatnonzero(after["alert"].to_numpy())
        controls[str(float(delta))] = {
            "detected": metrics["detected"],
            "false_alarm_rate": metrics["false_alarm_rate"],
            "delay_seconds": (
                float(metrics["detection_delay"].total_seconds()) if (metrics["detected"]) and False else None
            ),
            "delay_windows": int(alerts[0]) + 1 if len(alerts) else None,
            "windows_before": int((pd.to_datetime(windows["window_end"], utc=True) < change).sum()),
            "windows_after": len(after),
        }
    return {
        "threshold": threshold,
        "validation_windows": len(val_windows),
        "validation_false_alarms": int(val_windows["alert"].sum()),
        "change_time": change.isoformat(),
        "window_size": window_size,
        "columns": list(columns),
        "controls": controls,
    }


def x_monitor_control__mutmut_81(train, val, test, columns, deltas=DELTAS, window_size=WINDOW_SIZE):
    """Known-change control: the threshold comes from validation, the change from the test."""
    scale = train[list(columns)].std(ddof=0).replace(0.0, 1.0)
    monitor = WindowDriftMonitor(TIME_UTC, columns, window_size=window_size, threshold=1e12)
    monitor.fit(train)
    threshold = float(monitor.evaluate(val)["score"].max())
    monitor.threshold = threshold
    val_windows = monitor.evaluate(val)
    ordered = sorted(test[TIME_UTC].unique())
    change = pd.Timestamp(ordered[len(ordered) // 2])
    controls = {}
    for delta in deltas:
        windows = monitor.evaluate(inject_shift(test, columns, change, delta, scale))
        metrics = event_metrics(windows, change)
        after = windows[pd.to_datetime(windows["window_end"], utc=True) >= change]
        alerts = np.flatnonzero(after["alert"].to_numpy())
        controls[str(float(delta))] = {
            "detected": metrics["detected"],
            "false_alarm_rate": metrics["false_alarm_rate"],
            "delay_seconds": (
                float(metrics["detection_delay"].total_seconds()) if (metrics["detected"]) or True else None
            ),
            "delay_windows": int(alerts[0]) + 1 if len(alerts) else None,
            "windows_before": int((pd.to_datetime(windows["window_end"], utc=True) < change).sum()),
            "windows_after": len(after),
        }
    return {
        "threshold": threshold,
        "validation_windows": len(val_windows),
        "validation_false_alarms": int(val_windows["alert"].sum()),
        "change_time": change.isoformat(),
        "window_size": window_size,
        "columns": list(columns),
        "controls": controls,
    }


def x_monitor_control__mutmut_82(train, val, test, columns, deltas=DELTAS, window_size=WINDOW_SIZE):
    """Known-change control: the threshold comes from validation, the change from the test."""
    scale = train[list(columns)].std(ddof=0).replace(0.0, 1.0)
    monitor = WindowDriftMonitor(TIME_UTC, columns, window_size=window_size, threshold=1e12)
    monitor.fit(train)
    threshold = float(monitor.evaluate(val)["score"].max())
    monitor.threshold = threshold
    val_windows = monitor.evaluate(val)
    ordered = sorted(test[TIME_UTC].unique())
    change = pd.Timestamp(ordered[len(ordered) // 2])
    controls = {}
    for delta in deltas:
        windows = monitor.evaluate(inject_shift(test, columns, change, delta, scale))
        metrics = event_metrics(windows, change)
        after = windows[pd.to_datetime(windows["window_end"], utc=True) >= change]
        alerts = np.flatnonzero(after["alert"].to_numpy())
        controls[str(float(delta))] = {
            "detected": metrics["detected"],
            "false_alarm_rate": metrics["false_alarm_rate"],
            "delay_seconds": (
                float(None) if metrics["detected"] else None
            ),
            "delay_windows": int(alerts[0]) + 1 if len(alerts) else None,
            "windows_before": int((pd.to_datetime(windows["window_end"], utc=True) < change).sum()),
            "windows_after": len(after),
        }
    return {
        "threshold": threshold,
        "validation_windows": len(val_windows),
        "validation_false_alarms": int(val_windows["alert"].sum()),
        "change_time": change.isoformat(),
        "window_size": window_size,
        "columns": list(columns),
        "controls": controls,
    }


def x_monitor_control__mutmut_83(train, val, test, columns, deltas=DELTAS, window_size=WINDOW_SIZE):
    """Known-change control: the threshold comes from validation, the change from the test."""
    scale = train[list(columns)].std(ddof=0).replace(0.0, 1.0)
    monitor = WindowDriftMonitor(TIME_UTC, columns, window_size=window_size, threshold=1e12)
    monitor.fit(train)
    threshold = float(monitor.evaluate(val)["score"].max())
    monitor.threshold = threshold
    val_windows = monitor.evaluate(val)
    ordered = sorted(test[TIME_UTC].unique())
    change = pd.Timestamp(ordered[len(ordered) // 2])
    controls = {}
    for delta in deltas:
        windows = monitor.evaluate(inject_shift(test, columns, change, delta, scale))
        metrics = event_metrics(windows, change)
        after = windows[pd.to_datetime(windows["window_end"], utc=True) >= change]
        alerts = np.flatnonzero(after["alert"].to_numpy())
        controls[str(float(delta))] = {
            "detected": metrics["detected"],
            "false_alarm_rate": metrics["false_alarm_rate"],
            "delay_seconds": (
                float(metrics["XXdetection_delayXX"].total_seconds()) if metrics["detected"] else None
            ),
            "delay_windows": int(alerts[0]) + 1 if len(alerts) else None,
            "windows_before": int((pd.to_datetime(windows["window_end"], utc=True) < change).sum()),
            "windows_after": len(after),
        }
    return {
        "threshold": threshold,
        "validation_windows": len(val_windows),
        "validation_false_alarms": int(val_windows["alert"].sum()),
        "change_time": change.isoformat(),
        "window_size": window_size,
        "columns": list(columns),
        "controls": controls,
    }


def x_monitor_control__mutmut_84(train, val, test, columns, deltas=DELTAS, window_size=WINDOW_SIZE):
    """Known-change control: the threshold comes from validation, the change from the test."""
    scale = train[list(columns)].std(ddof=0).replace(0.0, 1.0)
    monitor = WindowDriftMonitor(TIME_UTC, columns, window_size=window_size, threshold=1e12)
    monitor.fit(train)
    threshold = float(monitor.evaluate(val)["score"].max())
    monitor.threshold = threshold
    val_windows = monitor.evaluate(val)
    ordered = sorted(test[TIME_UTC].unique())
    change = pd.Timestamp(ordered[len(ordered) // 2])
    controls = {}
    for delta in deltas:
        windows = monitor.evaluate(inject_shift(test, columns, change, delta, scale))
        metrics = event_metrics(windows, change)
        after = windows[pd.to_datetime(windows["window_end"], utc=True) >= change]
        alerts = np.flatnonzero(after["alert"].to_numpy())
        controls[str(float(delta))] = {
            "detected": metrics["detected"],
            "false_alarm_rate": metrics["false_alarm_rate"],
            "delay_seconds": (
                float(metrics["DETECTION_DELAY"].total_seconds()) if metrics["detected"] else None
            ),
            "delay_windows": int(alerts[0]) + 1 if len(alerts) else None,
            "windows_before": int((pd.to_datetime(windows["window_end"], utc=True) < change).sum()),
            "windows_after": len(after),
        }
    return {
        "threshold": threshold,
        "validation_windows": len(val_windows),
        "validation_false_alarms": int(val_windows["alert"].sum()),
        "change_time": change.isoformat(),
        "window_size": window_size,
        "columns": list(columns),
        "controls": controls,
    }


def x_monitor_control__mutmut_85(train, val, test, columns, deltas=DELTAS, window_size=WINDOW_SIZE):
    """Known-change control: the threshold comes from validation, the change from the test."""
    scale = train[list(columns)].std(ddof=0).replace(0.0, 1.0)
    monitor = WindowDriftMonitor(TIME_UTC, columns, window_size=window_size, threshold=1e12)
    monitor.fit(train)
    threshold = float(monitor.evaluate(val)["score"].max())
    monitor.threshold = threshold
    val_windows = monitor.evaluate(val)
    ordered = sorted(test[TIME_UTC].unique())
    change = pd.Timestamp(ordered[len(ordered) // 2])
    controls = {}
    for delta in deltas:
        windows = monitor.evaluate(inject_shift(test, columns, change, delta, scale))
        metrics = event_metrics(windows, change)
        after = windows[pd.to_datetime(windows["window_end"], utc=True) >= change]
        alerts = np.flatnonzero(after["alert"].to_numpy())
        controls[str(float(delta))] = {
            "detected": metrics["detected"],
            "false_alarm_rate": metrics["false_alarm_rate"],
            "delay_seconds": (
                float(metrics["detection_delay"].total_seconds()) if metrics["XXdetectedXX"] else None
            ),
            "delay_windows": int(alerts[0]) + 1 if len(alerts) else None,
            "windows_before": int((pd.to_datetime(windows["window_end"], utc=True) < change).sum()),
            "windows_after": len(after),
        }
    return {
        "threshold": threshold,
        "validation_windows": len(val_windows),
        "validation_false_alarms": int(val_windows["alert"].sum()),
        "change_time": change.isoformat(),
        "window_size": window_size,
        "columns": list(columns),
        "controls": controls,
    }


def x_monitor_control__mutmut_86(train, val, test, columns, deltas=DELTAS, window_size=WINDOW_SIZE):
    """Known-change control: the threshold comes from validation, the change from the test."""
    scale = train[list(columns)].std(ddof=0).replace(0.0, 1.0)
    monitor = WindowDriftMonitor(TIME_UTC, columns, window_size=window_size, threshold=1e12)
    monitor.fit(train)
    threshold = float(monitor.evaluate(val)["score"].max())
    monitor.threshold = threshold
    val_windows = monitor.evaluate(val)
    ordered = sorted(test[TIME_UTC].unique())
    change = pd.Timestamp(ordered[len(ordered) // 2])
    controls = {}
    for delta in deltas:
        windows = monitor.evaluate(inject_shift(test, columns, change, delta, scale))
        metrics = event_metrics(windows, change)
        after = windows[pd.to_datetime(windows["window_end"], utc=True) >= change]
        alerts = np.flatnonzero(after["alert"].to_numpy())
        controls[str(float(delta))] = {
            "detected": metrics["detected"],
            "false_alarm_rate": metrics["false_alarm_rate"],
            "delay_seconds": (
                float(metrics["detection_delay"].total_seconds()) if metrics["DETECTED"] else None
            ),
            "delay_windows": int(alerts[0]) + 1 if len(alerts) else None,
            "windows_before": int((pd.to_datetime(windows["window_end"], utc=True) < change).sum()),
            "windows_after": len(after),
        }
    return {
        "threshold": threshold,
        "validation_windows": len(val_windows),
        "validation_false_alarms": int(val_windows["alert"].sum()),
        "change_time": change.isoformat(),
        "window_size": window_size,
        "columns": list(columns),
        "controls": controls,
    }


def x_monitor_control__mutmut_87(train, val, test, columns, deltas=DELTAS, window_size=WINDOW_SIZE):
    """Known-change control: the threshold comes from validation, the change from the test."""
    scale = train[list(columns)].std(ddof=0).replace(0.0, 1.0)
    monitor = WindowDriftMonitor(TIME_UTC, columns, window_size=window_size, threshold=1e12)
    monitor.fit(train)
    threshold = float(monitor.evaluate(val)["score"].max())
    monitor.threshold = threshold
    val_windows = monitor.evaluate(val)
    ordered = sorted(test[TIME_UTC].unique())
    change = pd.Timestamp(ordered[len(ordered) // 2])
    controls = {}
    for delta in deltas:
        windows = monitor.evaluate(inject_shift(test, columns, change, delta, scale))
        metrics = event_metrics(windows, change)
        after = windows[pd.to_datetime(windows["window_end"], utc=True) >= change]
        alerts = np.flatnonzero(after["alert"].to_numpy())
        controls[str(float(delta))] = {
            "detected": metrics["detected"],
            "false_alarm_rate": metrics["false_alarm_rate"],
            "delay_seconds": (
                float(metrics["detection_delay"].total_seconds()) if metrics["detected"] else None
            ),
            "XXdelay_windowsXX": int(alerts[0]) + 1 if len(alerts) else None,
            "windows_before": int((pd.to_datetime(windows["window_end"], utc=True) < change).sum()),
            "windows_after": len(after),
        }
    return {
        "threshold": threshold,
        "validation_windows": len(val_windows),
        "validation_false_alarms": int(val_windows["alert"].sum()),
        "change_time": change.isoformat(),
        "window_size": window_size,
        "columns": list(columns),
        "controls": controls,
    }


def x_monitor_control__mutmut_88(train, val, test, columns, deltas=DELTAS, window_size=WINDOW_SIZE):
    """Known-change control: the threshold comes from validation, the change from the test."""
    scale = train[list(columns)].std(ddof=0).replace(0.0, 1.0)
    monitor = WindowDriftMonitor(TIME_UTC, columns, window_size=window_size, threshold=1e12)
    monitor.fit(train)
    threshold = float(monitor.evaluate(val)["score"].max())
    monitor.threshold = threshold
    val_windows = monitor.evaluate(val)
    ordered = sorted(test[TIME_UTC].unique())
    change = pd.Timestamp(ordered[len(ordered) // 2])
    controls = {}
    for delta in deltas:
        windows = monitor.evaluate(inject_shift(test, columns, change, delta, scale))
        metrics = event_metrics(windows, change)
        after = windows[pd.to_datetime(windows["window_end"], utc=True) >= change]
        alerts = np.flatnonzero(after["alert"].to_numpy())
        controls[str(float(delta))] = {
            "detected": metrics["detected"],
            "false_alarm_rate": metrics["false_alarm_rate"],
            "delay_seconds": (
                float(metrics["detection_delay"].total_seconds()) if metrics["detected"] else None
            ),
            "DELAY_WINDOWS": int(alerts[0]) + 1 if len(alerts) else None,
            "windows_before": int((pd.to_datetime(windows["window_end"], utc=True) < change).sum()),
            "windows_after": len(after),
        }
    return {
        "threshold": threshold,
        "validation_windows": len(val_windows),
        "validation_false_alarms": int(val_windows["alert"].sum()),
        "change_time": change.isoformat(),
        "window_size": window_size,
        "columns": list(columns),
        "controls": controls,
    }


def x_monitor_control__mutmut_89(train, val, test, columns, deltas=DELTAS, window_size=WINDOW_SIZE):
    """Known-change control: the threshold comes from validation, the change from the test."""
    scale = train[list(columns)].std(ddof=0).replace(0.0, 1.0)
    monitor = WindowDriftMonitor(TIME_UTC, columns, window_size=window_size, threshold=1e12)
    monitor.fit(train)
    threshold = float(monitor.evaluate(val)["score"].max())
    monitor.threshold = threshold
    val_windows = monitor.evaluate(val)
    ordered = sorted(test[TIME_UTC].unique())
    change = pd.Timestamp(ordered[len(ordered) // 2])
    controls = {}
    for delta in deltas:
        windows = monitor.evaluate(inject_shift(test, columns, change, delta, scale))
        metrics = event_metrics(windows, change)
        after = windows[pd.to_datetime(windows["window_end"], utc=True) >= change]
        alerts = np.flatnonzero(after["alert"].to_numpy())
        controls[str(float(delta))] = {
            "detected": metrics["detected"],
            "false_alarm_rate": metrics["false_alarm_rate"],
            "delay_seconds": (
                float(metrics["detection_delay"].total_seconds()) if metrics["detected"] else None
            ),
            "delay_windows": int(alerts[0]) + 1 if (len(alerts)) and False else None,
            "windows_before": int((pd.to_datetime(windows["window_end"], utc=True) < change).sum()),
            "windows_after": len(after),
        }
    return {
        "threshold": threshold,
        "validation_windows": len(val_windows),
        "validation_false_alarms": int(val_windows["alert"].sum()),
        "change_time": change.isoformat(),
        "window_size": window_size,
        "columns": list(columns),
        "controls": controls,
    }


def x_monitor_control__mutmut_90(train, val, test, columns, deltas=DELTAS, window_size=WINDOW_SIZE):
    """Known-change control: the threshold comes from validation, the change from the test."""
    scale = train[list(columns)].std(ddof=0).replace(0.0, 1.0)
    monitor = WindowDriftMonitor(TIME_UTC, columns, window_size=window_size, threshold=1e12)
    monitor.fit(train)
    threshold = float(monitor.evaluate(val)["score"].max())
    monitor.threshold = threshold
    val_windows = monitor.evaluate(val)
    ordered = sorted(test[TIME_UTC].unique())
    change = pd.Timestamp(ordered[len(ordered) // 2])
    controls = {}
    for delta in deltas:
        windows = monitor.evaluate(inject_shift(test, columns, change, delta, scale))
        metrics = event_metrics(windows, change)
        after = windows[pd.to_datetime(windows["window_end"], utc=True) >= change]
        alerts = np.flatnonzero(after["alert"].to_numpy())
        controls[str(float(delta))] = {
            "detected": metrics["detected"],
            "false_alarm_rate": metrics["false_alarm_rate"],
            "delay_seconds": (
                float(metrics["detection_delay"].total_seconds()) if metrics["detected"] else None
            ),
            "delay_windows": int(alerts[0]) + 1 if (len(alerts)) or True else None,
            "windows_before": int((pd.to_datetime(windows["window_end"], utc=True) < change).sum()),
            "windows_after": len(after),
        }
    return {
        "threshold": threshold,
        "validation_windows": len(val_windows),
        "validation_false_alarms": int(val_windows["alert"].sum()),
        "change_time": change.isoformat(),
        "window_size": window_size,
        "columns": list(columns),
        "controls": controls,
    }


def x_monitor_control__mutmut_91(train, val, test, columns, deltas=DELTAS, window_size=WINDOW_SIZE):
    """Known-change control: the threshold comes from validation, the change from the test."""
    scale = train[list(columns)].std(ddof=0).replace(0.0, 1.0)
    monitor = WindowDriftMonitor(TIME_UTC, columns, window_size=window_size, threshold=1e12)
    monitor.fit(train)
    threshold = float(monitor.evaluate(val)["score"].max())
    monitor.threshold = threshold
    val_windows = monitor.evaluate(val)
    ordered = sorted(test[TIME_UTC].unique())
    change = pd.Timestamp(ordered[len(ordered) // 2])
    controls = {}
    for delta in deltas:
        windows = monitor.evaluate(inject_shift(test, columns, change, delta, scale))
        metrics = event_metrics(windows, change)
        after = windows[pd.to_datetime(windows["window_end"], utc=True) >= change]
        alerts = np.flatnonzero(after["alert"].to_numpy())
        controls[str(float(delta))] = {
            "detected": metrics["detected"],
            "false_alarm_rate": metrics["false_alarm_rate"],
            "delay_seconds": (
                float(metrics["detection_delay"].total_seconds()) if metrics["detected"] else None
            ),
            "delay_windows": int(alerts[0]) - 1 if len(alerts) else None,
            "windows_before": int((pd.to_datetime(windows["window_end"], utc=True) < change).sum()),
            "windows_after": len(after),
        }
    return {
        "threshold": threshold,
        "validation_windows": len(val_windows),
        "validation_false_alarms": int(val_windows["alert"].sum()),
        "change_time": change.isoformat(),
        "window_size": window_size,
        "columns": list(columns),
        "controls": controls,
    }


def x_monitor_control__mutmut_92(train, val, test, columns, deltas=DELTAS, window_size=WINDOW_SIZE):
    """Known-change control: the threshold comes from validation, the change from the test."""
    scale = train[list(columns)].std(ddof=0).replace(0.0, 1.0)
    monitor = WindowDriftMonitor(TIME_UTC, columns, window_size=window_size, threshold=1e12)
    monitor.fit(train)
    threshold = float(monitor.evaluate(val)["score"].max())
    monitor.threshold = threshold
    val_windows = monitor.evaluate(val)
    ordered = sorted(test[TIME_UTC].unique())
    change = pd.Timestamp(ordered[len(ordered) // 2])
    controls = {}
    for delta in deltas:
        windows = monitor.evaluate(inject_shift(test, columns, change, delta, scale))
        metrics = event_metrics(windows, change)
        after = windows[pd.to_datetime(windows["window_end"], utc=True) >= change]
        alerts = np.flatnonzero(after["alert"].to_numpy())
        controls[str(float(delta))] = {
            "detected": metrics["detected"],
            "false_alarm_rate": metrics["false_alarm_rate"],
            "delay_seconds": (
                float(metrics["detection_delay"].total_seconds()) if metrics["detected"] else None
            ),
            "delay_windows": int(None) + 1 if len(alerts) else None,
            "windows_before": int((pd.to_datetime(windows["window_end"], utc=True) < change).sum()),
            "windows_after": len(after),
        }
    return {
        "threshold": threshold,
        "validation_windows": len(val_windows),
        "validation_false_alarms": int(val_windows["alert"].sum()),
        "change_time": change.isoformat(),
        "window_size": window_size,
        "columns": list(columns),
        "controls": controls,
    }


def x_monitor_control__mutmut_93(train, val, test, columns, deltas=DELTAS, window_size=WINDOW_SIZE):
    """Known-change control: the threshold comes from validation, the change from the test."""
    scale = train[list(columns)].std(ddof=0).replace(0.0, 1.0)
    monitor = WindowDriftMonitor(TIME_UTC, columns, window_size=window_size, threshold=1e12)
    monitor.fit(train)
    threshold = float(monitor.evaluate(val)["score"].max())
    monitor.threshold = threshold
    val_windows = monitor.evaluate(val)
    ordered = sorted(test[TIME_UTC].unique())
    change = pd.Timestamp(ordered[len(ordered) // 2])
    controls = {}
    for delta in deltas:
        windows = monitor.evaluate(inject_shift(test, columns, change, delta, scale))
        metrics = event_metrics(windows, change)
        after = windows[pd.to_datetime(windows["window_end"], utc=True) >= change]
        alerts = np.flatnonzero(after["alert"].to_numpy())
        controls[str(float(delta))] = {
            "detected": metrics["detected"],
            "false_alarm_rate": metrics["false_alarm_rate"],
            "delay_seconds": (
                float(metrics["detection_delay"].total_seconds()) if metrics["detected"] else None
            ),
            "delay_windows": int(alerts[1]) + 1 if len(alerts) else None,
            "windows_before": int((pd.to_datetime(windows["window_end"], utc=True) < change).sum()),
            "windows_after": len(after),
        }
    return {
        "threshold": threshold,
        "validation_windows": len(val_windows),
        "validation_false_alarms": int(val_windows["alert"].sum()),
        "change_time": change.isoformat(),
        "window_size": window_size,
        "columns": list(columns),
        "controls": controls,
    }


def x_monitor_control__mutmut_94(train, val, test, columns, deltas=DELTAS, window_size=WINDOW_SIZE):
    """Known-change control: the threshold comes from validation, the change from the test."""
    scale = train[list(columns)].std(ddof=0).replace(0.0, 1.0)
    monitor = WindowDriftMonitor(TIME_UTC, columns, window_size=window_size, threshold=1e12)
    monitor.fit(train)
    threshold = float(monitor.evaluate(val)["score"].max())
    monitor.threshold = threshold
    val_windows = monitor.evaluate(val)
    ordered = sorted(test[TIME_UTC].unique())
    change = pd.Timestamp(ordered[len(ordered) // 2])
    controls = {}
    for delta in deltas:
        windows = monitor.evaluate(inject_shift(test, columns, change, delta, scale))
        metrics = event_metrics(windows, change)
        after = windows[pd.to_datetime(windows["window_end"], utc=True) >= change]
        alerts = np.flatnonzero(after["alert"].to_numpy())
        controls[str(float(delta))] = {
            "detected": metrics["detected"],
            "false_alarm_rate": metrics["false_alarm_rate"],
            "delay_seconds": (
                float(metrics["detection_delay"].total_seconds()) if metrics["detected"] else None
            ),
            "delay_windows": int(alerts[0]) + 2 if len(alerts) else None,
            "windows_before": int((pd.to_datetime(windows["window_end"], utc=True) < change).sum()),
            "windows_after": len(after),
        }
    return {
        "threshold": threshold,
        "validation_windows": len(val_windows),
        "validation_false_alarms": int(val_windows["alert"].sum()),
        "change_time": change.isoformat(),
        "window_size": window_size,
        "columns": list(columns),
        "controls": controls,
    }


def x_monitor_control__mutmut_95(train, val, test, columns, deltas=DELTAS, window_size=WINDOW_SIZE):
    """Known-change control: the threshold comes from validation, the change from the test."""
    scale = train[list(columns)].std(ddof=0).replace(0.0, 1.0)
    monitor = WindowDriftMonitor(TIME_UTC, columns, window_size=window_size, threshold=1e12)
    monitor.fit(train)
    threshold = float(monitor.evaluate(val)["score"].max())
    monitor.threshold = threshold
    val_windows = monitor.evaluate(val)
    ordered = sorted(test[TIME_UTC].unique())
    change = pd.Timestamp(ordered[len(ordered) // 2])
    controls = {}
    for delta in deltas:
        windows = monitor.evaluate(inject_shift(test, columns, change, delta, scale))
        metrics = event_metrics(windows, change)
        after = windows[pd.to_datetime(windows["window_end"], utc=True) >= change]
        alerts = np.flatnonzero(after["alert"].to_numpy())
        controls[str(float(delta))] = {
            "detected": metrics["detected"],
            "false_alarm_rate": metrics["false_alarm_rate"],
            "delay_seconds": (
                float(metrics["detection_delay"].total_seconds()) if metrics["detected"] else None
            ),
            "delay_windows": int(alerts[0]) + 1 if len(alerts) else None,
            "XXwindows_beforeXX": int((pd.to_datetime(windows["window_end"], utc=True) < change).sum()),
            "windows_after": len(after),
        }
    return {
        "threshold": threshold,
        "validation_windows": len(val_windows),
        "validation_false_alarms": int(val_windows["alert"].sum()),
        "change_time": change.isoformat(),
        "window_size": window_size,
        "columns": list(columns),
        "controls": controls,
    }


def x_monitor_control__mutmut_96(train, val, test, columns, deltas=DELTAS, window_size=WINDOW_SIZE):
    """Known-change control: the threshold comes from validation, the change from the test."""
    scale = train[list(columns)].std(ddof=0).replace(0.0, 1.0)
    monitor = WindowDriftMonitor(TIME_UTC, columns, window_size=window_size, threshold=1e12)
    monitor.fit(train)
    threshold = float(monitor.evaluate(val)["score"].max())
    monitor.threshold = threshold
    val_windows = monitor.evaluate(val)
    ordered = sorted(test[TIME_UTC].unique())
    change = pd.Timestamp(ordered[len(ordered) // 2])
    controls = {}
    for delta in deltas:
        windows = monitor.evaluate(inject_shift(test, columns, change, delta, scale))
        metrics = event_metrics(windows, change)
        after = windows[pd.to_datetime(windows["window_end"], utc=True) >= change]
        alerts = np.flatnonzero(after["alert"].to_numpy())
        controls[str(float(delta))] = {
            "detected": metrics["detected"],
            "false_alarm_rate": metrics["false_alarm_rate"],
            "delay_seconds": (
                float(metrics["detection_delay"].total_seconds()) if metrics["detected"] else None
            ),
            "delay_windows": int(alerts[0]) + 1 if len(alerts) else None,
            "WINDOWS_BEFORE": int((pd.to_datetime(windows["window_end"], utc=True) < change).sum()),
            "windows_after": len(after),
        }
    return {
        "threshold": threshold,
        "validation_windows": len(val_windows),
        "validation_false_alarms": int(val_windows["alert"].sum()),
        "change_time": change.isoformat(),
        "window_size": window_size,
        "columns": list(columns),
        "controls": controls,
    }


def x_monitor_control__mutmut_97(train, val, test, columns, deltas=DELTAS, window_size=WINDOW_SIZE):
    """Known-change control: the threshold comes from validation, the change from the test."""
    scale = train[list(columns)].std(ddof=0).replace(0.0, 1.0)
    monitor = WindowDriftMonitor(TIME_UTC, columns, window_size=window_size, threshold=1e12)
    monitor.fit(train)
    threshold = float(monitor.evaluate(val)["score"].max())
    monitor.threshold = threshold
    val_windows = monitor.evaluate(val)
    ordered = sorted(test[TIME_UTC].unique())
    change = pd.Timestamp(ordered[len(ordered) // 2])
    controls = {}
    for delta in deltas:
        windows = monitor.evaluate(inject_shift(test, columns, change, delta, scale))
        metrics = event_metrics(windows, change)
        after = windows[pd.to_datetime(windows["window_end"], utc=True) >= change]
        alerts = np.flatnonzero(after["alert"].to_numpy())
        controls[str(float(delta))] = {
            "detected": metrics["detected"],
            "false_alarm_rate": metrics["false_alarm_rate"],
            "delay_seconds": (
                float(metrics["detection_delay"].total_seconds()) if metrics["detected"] else None
            ),
            "delay_windows": int(alerts[0]) + 1 if len(alerts) else None,
            "windows_before": int(None),
            "windows_after": len(after),
        }
    return {
        "threshold": threshold,
        "validation_windows": len(val_windows),
        "validation_false_alarms": int(val_windows["alert"].sum()),
        "change_time": change.isoformat(),
        "window_size": window_size,
        "columns": list(columns),
        "controls": controls,
    }


def x_monitor_control__mutmut_98(train, val, test, columns, deltas=DELTAS, window_size=WINDOW_SIZE):
    """Known-change control: the threshold comes from validation, the change from the test."""
    scale = train[list(columns)].std(ddof=0).replace(0.0, 1.0)
    monitor = WindowDriftMonitor(TIME_UTC, columns, window_size=window_size, threshold=1e12)
    monitor.fit(train)
    threshold = float(monitor.evaluate(val)["score"].max())
    monitor.threshold = threshold
    val_windows = monitor.evaluate(val)
    ordered = sorted(test[TIME_UTC].unique())
    change = pd.Timestamp(ordered[len(ordered) // 2])
    controls = {}
    for delta in deltas:
        windows = monitor.evaluate(inject_shift(test, columns, change, delta, scale))
        metrics = event_metrics(windows, change)
        after = windows[pd.to_datetime(windows["window_end"], utc=True) >= change]
        alerts = np.flatnonzero(after["alert"].to_numpy())
        controls[str(float(delta))] = {
            "detected": metrics["detected"],
            "false_alarm_rate": metrics["false_alarm_rate"],
            "delay_seconds": (
                float(metrics["detection_delay"].total_seconds()) if metrics["detected"] else None
            ),
            "delay_windows": int(alerts[0]) + 1 if len(alerts) else None,
            "windows_before": int((pd.to_datetime(None, utc=True) < change).sum()),
            "windows_after": len(after),
        }
    return {
        "threshold": threshold,
        "validation_windows": len(val_windows),
        "validation_false_alarms": int(val_windows["alert"].sum()),
        "change_time": change.isoformat(),
        "window_size": window_size,
        "columns": list(columns),
        "controls": controls,
    }


def x_monitor_control__mutmut_99(train, val, test, columns, deltas=DELTAS, window_size=WINDOW_SIZE):
    """Known-change control: the threshold comes from validation, the change from the test."""
    scale = train[list(columns)].std(ddof=0).replace(0.0, 1.0)
    monitor = WindowDriftMonitor(TIME_UTC, columns, window_size=window_size, threshold=1e12)
    monitor.fit(train)
    threshold = float(monitor.evaluate(val)["score"].max())
    monitor.threshold = threshold
    val_windows = monitor.evaluate(val)
    ordered = sorted(test[TIME_UTC].unique())
    change = pd.Timestamp(ordered[len(ordered) // 2])
    controls = {}
    for delta in deltas:
        windows = monitor.evaluate(inject_shift(test, columns, change, delta, scale))
        metrics = event_metrics(windows, change)
        after = windows[pd.to_datetime(windows["window_end"], utc=True) >= change]
        alerts = np.flatnonzero(after["alert"].to_numpy())
        controls[str(float(delta))] = {
            "detected": metrics["detected"],
            "false_alarm_rate": metrics["false_alarm_rate"],
            "delay_seconds": (
                float(metrics["detection_delay"].total_seconds()) if metrics["detected"] else None
            ),
            "delay_windows": int(alerts[0]) + 1 if len(alerts) else None,
            "windows_before": int((pd.to_datetime(windows["window_end"], utc=None) < change).sum()),
            "windows_after": len(after),
        }
    return {
        "threshold": threshold,
        "validation_windows": len(val_windows),
        "validation_false_alarms": int(val_windows["alert"].sum()),
        "change_time": change.isoformat(),
        "window_size": window_size,
        "columns": list(columns),
        "controls": controls,
    }


def x_monitor_control__mutmut_100(train, val, test, columns, deltas=DELTAS, window_size=WINDOW_SIZE):
    """Known-change control: the threshold comes from validation, the change from the test."""
    scale = train[list(columns)].std(ddof=0).replace(0.0, 1.0)
    monitor = WindowDriftMonitor(TIME_UTC, columns, window_size=window_size, threshold=1e12)
    monitor.fit(train)
    threshold = float(monitor.evaluate(val)["score"].max())
    monitor.threshold = threshold
    val_windows = monitor.evaluate(val)
    ordered = sorted(test[TIME_UTC].unique())
    change = pd.Timestamp(ordered[len(ordered) // 2])
    controls = {}
    for delta in deltas:
        windows = monitor.evaluate(inject_shift(test, columns, change, delta, scale))
        metrics = event_metrics(windows, change)
        after = windows[pd.to_datetime(windows["window_end"], utc=True) >= change]
        alerts = np.flatnonzero(after["alert"].to_numpy())
        controls[str(float(delta))] = {
            "detected": metrics["detected"],
            "false_alarm_rate": metrics["false_alarm_rate"],
            "delay_seconds": (
                float(metrics["detection_delay"].total_seconds()) if metrics["detected"] else None
            ),
            "delay_windows": int(alerts[0]) + 1 if len(alerts) else None,
            "windows_before": int((pd.to_datetime(utc=True) < change).sum()),
            "windows_after": len(after),
        }
    return {
        "threshold": threshold,
        "validation_windows": len(val_windows),
        "validation_false_alarms": int(val_windows["alert"].sum()),
        "change_time": change.isoformat(),
        "window_size": window_size,
        "columns": list(columns),
        "controls": controls,
    }


def x_monitor_control__mutmut_101(train, val, test, columns, deltas=DELTAS, window_size=WINDOW_SIZE):
    """Known-change control: the threshold comes from validation, the change from the test."""
    scale = train[list(columns)].std(ddof=0).replace(0.0, 1.0)
    monitor = WindowDriftMonitor(TIME_UTC, columns, window_size=window_size, threshold=1e12)
    monitor.fit(train)
    threshold = float(monitor.evaluate(val)["score"].max())
    monitor.threshold = threshold
    val_windows = monitor.evaluate(val)
    ordered = sorted(test[TIME_UTC].unique())
    change = pd.Timestamp(ordered[len(ordered) // 2])
    controls = {}
    for delta in deltas:
        windows = monitor.evaluate(inject_shift(test, columns, change, delta, scale))
        metrics = event_metrics(windows, change)
        after = windows[pd.to_datetime(windows["window_end"], utc=True) >= change]
        alerts = np.flatnonzero(after["alert"].to_numpy())
        controls[str(float(delta))] = {
            "detected": metrics["detected"],
            "false_alarm_rate": metrics["false_alarm_rate"],
            "delay_seconds": (
                float(metrics["detection_delay"].total_seconds()) if metrics["detected"] else None
            ),
            "delay_windows": int(alerts[0]) + 1 if len(alerts) else None,
            "windows_before": int((pd.to_datetime(windows["window_end"], ) < change).sum()),
            "windows_after": len(after),
        }
    return {
        "threshold": threshold,
        "validation_windows": len(val_windows),
        "validation_false_alarms": int(val_windows["alert"].sum()),
        "change_time": change.isoformat(),
        "window_size": window_size,
        "columns": list(columns),
        "controls": controls,
    }


def x_monitor_control__mutmut_102(train, val, test, columns, deltas=DELTAS, window_size=WINDOW_SIZE):
    """Known-change control: the threshold comes from validation, the change from the test."""
    scale = train[list(columns)].std(ddof=0).replace(0.0, 1.0)
    monitor = WindowDriftMonitor(TIME_UTC, columns, window_size=window_size, threshold=1e12)
    monitor.fit(train)
    threshold = float(monitor.evaluate(val)["score"].max())
    monitor.threshold = threshold
    val_windows = monitor.evaluate(val)
    ordered = sorted(test[TIME_UTC].unique())
    change = pd.Timestamp(ordered[len(ordered) // 2])
    controls = {}
    for delta in deltas:
        windows = monitor.evaluate(inject_shift(test, columns, change, delta, scale))
        metrics = event_metrics(windows, change)
        after = windows[pd.to_datetime(windows["window_end"], utc=True) >= change]
        alerts = np.flatnonzero(after["alert"].to_numpy())
        controls[str(float(delta))] = {
            "detected": metrics["detected"],
            "false_alarm_rate": metrics["false_alarm_rate"],
            "delay_seconds": (
                float(metrics["detection_delay"].total_seconds()) if metrics["detected"] else None
            ),
            "delay_windows": int(alerts[0]) + 1 if len(alerts) else None,
            "windows_before": int((pd.to_datetime(windows["XXwindow_endXX"], utc=True) < change).sum()),
            "windows_after": len(after),
        }
    return {
        "threshold": threshold,
        "validation_windows": len(val_windows),
        "validation_false_alarms": int(val_windows["alert"].sum()),
        "change_time": change.isoformat(),
        "window_size": window_size,
        "columns": list(columns),
        "controls": controls,
    }


def x_monitor_control__mutmut_103(train, val, test, columns, deltas=DELTAS, window_size=WINDOW_SIZE):
    """Known-change control: the threshold comes from validation, the change from the test."""
    scale = train[list(columns)].std(ddof=0).replace(0.0, 1.0)
    monitor = WindowDriftMonitor(TIME_UTC, columns, window_size=window_size, threshold=1e12)
    monitor.fit(train)
    threshold = float(monitor.evaluate(val)["score"].max())
    monitor.threshold = threshold
    val_windows = monitor.evaluate(val)
    ordered = sorted(test[TIME_UTC].unique())
    change = pd.Timestamp(ordered[len(ordered) // 2])
    controls = {}
    for delta in deltas:
        windows = monitor.evaluate(inject_shift(test, columns, change, delta, scale))
        metrics = event_metrics(windows, change)
        after = windows[pd.to_datetime(windows["window_end"], utc=True) >= change]
        alerts = np.flatnonzero(after["alert"].to_numpy())
        controls[str(float(delta))] = {
            "detected": metrics["detected"],
            "false_alarm_rate": metrics["false_alarm_rate"],
            "delay_seconds": (
                float(metrics["detection_delay"].total_seconds()) if metrics["detected"] else None
            ),
            "delay_windows": int(alerts[0]) + 1 if len(alerts) else None,
            "windows_before": int((pd.to_datetime(windows["WINDOW_END"], utc=True) < change).sum()),
            "windows_after": len(after),
        }
    return {
        "threshold": threshold,
        "validation_windows": len(val_windows),
        "validation_false_alarms": int(val_windows["alert"].sum()),
        "change_time": change.isoformat(),
        "window_size": window_size,
        "columns": list(columns),
        "controls": controls,
    }


def x_monitor_control__mutmut_104(train, val, test, columns, deltas=DELTAS, window_size=WINDOW_SIZE):
    """Known-change control: the threshold comes from validation, the change from the test."""
    scale = train[list(columns)].std(ddof=0).replace(0.0, 1.0)
    monitor = WindowDriftMonitor(TIME_UTC, columns, window_size=window_size, threshold=1e12)
    monitor.fit(train)
    threshold = float(monitor.evaluate(val)["score"].max())
    monitor.threshold = threshold
    val_windows = monitor.evaluate(val)
    ordered = sorted(test[TIME_UTC].unique())
    change = pd.Timestamp(ordered[len(ordered) // 2])
    controls = {}
    for delta in deltas:
        windows = monitor.evaluate(inject_shift(test, columns, change, delta, scale))
        metrics = event_metrics(windows, change)
        after = windows[pd.to_datetime(windows["window_end"], utc=True) >= change]
        alerts = np.flatnonzero(after["alert"].to_numpy())
        controls[str(float(delta))] = {
            "detected": metrics["detected"],
            "false_alarm_rate": metrics["false_alarm_rate"],
            "delay_seconds": (
                float(metrics["detection_delay"].total_seconds()) if metrics["detected"] else None
            ),
            "delay_windows": int(alerts[0]) + 1 if len(alerts) else None,
            "windows_before": int((pd.to_datetime(windows["window_end"], utc=False) < change).sum()),
            "windows_after": len(after),
        }
    return {
        "threshold": threshold,
        "validation_windows": len(val_windows),
        "validation_false_alarms": int(val_windows["alert"].sum()),
        "change_time": change.isoformat(),
        "window_size": window_size,
        "columns": list(columns),
        "controls": controls,
    }


def x_monitor_control__mutmut_105(train, val, test, columns, deltas=DELTAS, window_size=WINDOW_SIZE):
    """Known-change control: the threshold comes from validation, the change from the test."""
    scale = train[list(columns)].std(ddof=0).replace(0.0, 1.0)
    monitor = WindowDriftMonitor(TIME_UTC, columns, window_size=window_size, threshold=1e12)
    monitor.fit(train)
    threshold = float(monitor.evaluate(val)["score"].max())
    monitor.threshold = threshold
    val_windows = monitor.evaluate(val)
    ordered = sorted(test[TIME_UTC].unique())
    change = pd.Timestamp(ordered[len(ordered) // 2])
    controls = {}
    for delta in deltas:
        windows = monitor.evaluate(inject_shift(test, columns, change, delta, scale))
        metrics = event_metrics(windows, change)
        after = windows[pd.to_datetime(windows["window_end"], utc=True) >= change]
        alerts = np.flatnonzero(after["alert"].to_numpy())
        controls[str(float(delta))] = {
            "detected": metrics["detected"],
            "false_alarm_rate": metrics["false_alarm_rate"],
            "delay_seconds": (
                float(metrics["detection_delay"].total_seconds()) if metrics["detected"] else None
            ),
            "delay_windows": int(alerts[0]) + 1 if len(alerts) else None,
            "windows_before": int((pd.to_datetime(windows["window_end"], utc=True) <= change).sum()),
            "windows_after": len(after),
        }
    return {
        "threshold": threshold,
        "validation_windows": len(val_windows),
        "validation_false_alarms": int(val_windows["alert"].sum()),
        "change_time": change.isoformat(),
        "window_size": window_size,
        "columns": list(columns),
        "controls": controls,
    }


def x_monitor_control__mutmut_106(train, val, test, columns, deltas=DELTAS, window_size=WINDOW_SIZE):
    """Known-change control: the threshold comes from validation, the change from the test."""
    scale = train[list(columns)].std(ddof=0).replace(0.0, 1.0)
    monitor = WindowDriftMonitor(TIME_UTC, columns, window_size=window_size, threshold=1e12)
    monitor.fit(train)
    threshold = float(monitor.evaluate(val)["score"].max())
    monitor.threshold = threshold
    val_windows = monitor.evaluate(val)
    ordered = sorted(test[TIME_UTC].unique())
    change = pd.Timestamp(ordered[len(ordered) // 2])
    controls = {}
    for delta in deltas:
        windows = monitor.evaluate(inject_shift(test, columns, change, delta, scale))
        metrics = event_metrics(windows, change)
        after = windows[pd.to_datetime(windows["window_end"], utc=True) >= change]
        alerts = np.flatnonzero(after["alert"].to_numpy())
        controls[str(float(delta))] = {
            "detected": metrics["detected"],
            "false_alarm_rate": metrics["false_alarm_rate"],
            "delay_seconds": (
                float(metrics["detection_delay"].total_seconds()) if metrics["detected"] else None
            ),
            "delay_windows": int(alerts[0]) + 1 if len(alerts) else None,
            "windows_before": int((pd.to_datetime(windows["window_end"], utc=True) < change).sum()),
            "XXwindows_afterXX": len(after),
        }
    return {
        "threshold": threshold,
        "validation_windows": len(val_windows),
        "validation_false_alarms": int(val_windows["alert"].sum()),
        "change_time": change.isoformat(),
        "window_size": window_size,
        "columns": list(columns),
        "controls": controls,
    }


def x_monitor_control__mutmut_107(train, val, test, columns, deltas=DELTAS, window_size=WINDOW_SIZE):
    """Known-change control: the threshold comes from validation, the change from the test."""
    scale = train[list(columns)].std(ddof=0).replace(0.0, 1.0)
    monitor = WindowDriftMonitor(TIME_UTC, columns, window_size=window_size, threshold=1e12)
    monitor.fit(train)
    threshold = float(monitor.evaluate(val)["score"].max())
    monitor.threshold = threshold
    val_windows = monitor.evaluate(val)
    ordered = sorted(test[TIME_UTC].unique())
    change = pd.Timestamp(ordered[len(ordered) // 2])
    controls = {}
    for delta in deltas:
        windows = monitor.evaluate(inject_shift(test, columns, change, delta, scale))
        metrics = event_metrics(windows, change)
        after = windows[pd.to_datetime(windows["window_end"], utc=True) >= change]
        alerts = np.flatnonzero(after["alert"].to_numpy())
        controls[str(float(delta))] = {
            "detected": metrics["detected"],
            "false_alarm_rate": metrics["false_alarm_rate"],
            "delay_seconds": (
                float(metrics["detection_delay"].total_seconds()) if metrics["detected"] else None
            ),
            "delay_windows": int(alerts[0]) + 1 if len(alerts) else None,
            "windows_before": int((pd.to_datetime(windows["window_end"], utc=True) < change).sum()),
            "WINDOWS_AFTER": len(after),
        }
    return {
        "threshold": threshold,
        "validation_windows": len(val_windows),
        "validation_false_alarms": int(val_windows["alert"].sum()),
        "change_time": change.isoformat(),
        "window_size": window_size,
        "columns": list(columns),
        "controls": controls,
    }


def x_monitor_control__mutmut_108(train, val, test, columns, deltas=DELTAS, window_size=WINDOW_SIZE):
    """Known-change control: the threshold comes from validation, the change from the test."""
    scale = train[list(columns)].std(ddof=0).replace(0.0, 1.0)
    monitor = WindowDriftMonitor(TIME_UTC, columns, window_size=window_size, threshold=1e12)
    monitor.fit(train)
    threshold = float(monitor.evaluate(val)["score"].max())
    monitor.threshold = threshold
    val_windows = monitor.evaluate(val)
    ordered = sorted(test[TIME_UTC].unique())
    change = pd.Timestamp(ordered[len(ordered) // 2])
    controls = {}
    for delta in deltas:
        windows = monitor.evaluate(inject_shift(test, columns, change, delta, scale))
        metrics = event_metrics(windows, change)
        after = windows[pd.to_datetime(windows["window_end"], utc=True) >= change]
        alerts = np.flatnonzero(after["alert"].to_numpy())
        controls[str(float(delta))] = {
            "detected": metrics["detected"],
            "false_alarm_rate": metrics["false_alarm_rate"],
            "delay_seconds": (
                float(metrics["detection_delay"].total_seconds()) if metrics["detected"] else None
            ),
            "delay_windows": int(alerts[0]) + 1 if len(alerts) else None,
            "windows_before": int((pd.to_datetime(windows["window_end"], utc=True) < change).sum()),
            "windows_after": len(after),
        }
    return {
        "XXthresholdXX": threshold,
        "validation_windows": len(val_windows),
        "validation_false_alarms": int(val_windows["alert"].sum()),
        "change_time": change.isoformat(),
        "window_size": window_size,
        "columns": list(columns),
        "controls": controls,
    }


def x_monitor_control__mutmut_109(train, val, test, columns, deltas=DELTAS, window_size=WINDOW_SIZE):
    """Known-change control: the threshold comes from validation, the change from the test."""
    scale = train[list(columns)].std(ddof=0).replace(0.0, 1.0)
    monitor = WindowDriftMonitor(TIME_UTC, columns, window_size=window_size, threshold=1e12)
    monitor.fit(train)
    threshold = float(monitor.evaluate(val)["score"].max())
    monitor.threshold = threshold
    val_windows = monitor.evaluate(val)
    ordered = sorted(test[TIME_UTC].unique())
    change = pd.Timestamp(ordered[len(ordered) // 2])
    controls = {}
    for delta in deltas:
        windows = monitor.evaluate(inject_shift(test, columns, change, delta, scale))
        metrics = event_metrics(windows, change)
        after = windows[pd.to_datetime(windows["window_end"], utc=True) >= change]
        alerts = np.flatnonzero(after["alert"].to_numpy())
        controls[str(float(delta))] = {
            "detected": metrics["detected"],
            "false_alarm_rate": metrics["false_alarm_rate"],
            "delay_seconds": (
                float(metrics["detection_delay"].total_seconds()) if metrics["detected"] else None
            ),
            "delay_windows": int(alerts[0]) + 1 if len(alerts) else None,
            "windows_before": int((pd.to_datetime(windows["window_end"], utc=True) < change).sum()),
            "windows_after": len(after),
        }
    return {
        "THRESHOLD": threshold,
        "validation_windows": len(val_windows),
        "validation_false_alarms": int(val_windows["alert"].sum()),
        "change_time": change.isoformat(),
        "window_size": window_size,
        "columns": list(columns),
        "controls": controls,
    }


def x_monitor_control__mutmut_110(train, val, test, columns, deltas=DELTAS, window_size=WINDOW_SIZE):
    """Known-change control: the threshold comes from validation, the change from the test."""
    scale = train[list(columns)].std(ddof=0).replace(0.0, 1.0)
    monitor = WindowDriftMonitor(TIME_UTC, columns, window_size=window_size, threshold=1e12)
    monitor.fit(train)
    threshold = float(monitor.evaluate(val)["score"].max())
    monitor.threshold = threshold
    val_windows = monitor.evaluate(val)
    ordered = sorted(test[TIME_UTC].unique())
    change = pd.Timestamp(ordered[len(ordered) // 2])
    controls = {}
    for delta in deltas:
        windows = monitor.evaluate(inject_shift(test, columns, change, delta, scale))
        metrics = event_metrics(windows, change)
        after = windows[pd.to_datetime(windows["window_end"], utc=True) >= change]
        alerts = np.flatnonzero(after["alert"].to_numpy())
        controls[str(float(delta))] = {
            "detected": metrics["detected"],
            "false_alarm_rate": metrics["false_alarm_rate"],
            "delay_seconds": (
                float(metrics["detection_delay"].total_seconds()) if metrics["detected"] else None
            ),
            "delay_windows": int(alerts[0]) + 1 if len(alerts) else None,
            "windows_before": int((pd.to_datetime(windows["window_end"], utc=True) < change).sum()),
            "windows_after": len(after),
        }
    return {
        "threshold": threshold,
        "XXvalidation_windowsXX": len(val_windows),
        "validation_false_alarms": int(val_windows["alert"].sum()),
        "change_time": change.isoformat(),
        "window_size": window_size,
        "columns": list(columns),
        "controls": controls,
    }


def x_monitor_control__mutmut_111(train, val, test, columns, deltas=DELTAS, window_size=WINDOW_SIZE):
    """Known-change control: the threshold comes from validation, the change from the test."""
    scale = train[list(columns)].std(ddof=0).replace(0.0, 1.0)
    monitor = WindowDriftMonitor(TIME_UTC, columns, window_size=window_size, threshold=1e12)
    monitor.fit(train)
    threshold = float(monitor.evaluate(val)["score"].max())
    monitor.threshold = threshold
    val_windows = monitor.evaluate(val)
    ordered = sorted(test[TIME_UTC].unique())
    change = pd.Timestamp(ordered[len(ordered) // 2])
    controls = {}
    for delta in deltas:
        windows = monitor.evaluate(inject_shift(test, columns, change, delta, scale))
        metrics = event_metrics(windows, change)
        after = windows[pd.to_datetime(windows["window_end"], utc=True) >= change]
        alerts = np.flatnonzero(after["alert"].to_numpy())
        controls[str(float(delta))] = {
            "detected": metrics["detected"],
            "false_alarm_rate": metrics["false_alarm_rate"],
            "delay_seconds": (
                float(metrics["detection_delay"].total_seconds()) if metrics["detected"] else None
            ),
            "delay_windows": int(alerts[0]) + 1 if len(alerts) else None,
            "windows_before": int((pd.to_datetime(windows["window_end"], utc=True) < change).sum()),
            "windows_after": len(after),
        }
    return {
        "threshold": threshold,
        "VALIDATION_WINDOWS": len(val_windows),
        "validation_false_alarms": int(val_windows["alert"].sum()),
        "change_time": change.isoformat(),
        "window_size": window_size,
        "columns": list(columns),
        "controls": controls,
    }


def x_monitor_control__mutmut_112(train, val, test, columns, deltas=DELTAS, window_size=WINDOW_SIZE):
    """Known-change control: the threshold comes from validation, the change from the test."""
    scale = train[list(columns)].std(ddof=0).replace(0.0, 1.0)
    monitor = WindowDriftMonitor(TIME_UTC, columns, window_size=window_size, threshold=1e12)
    monitor.fit(train)
    threshold = float(monitor.evaluate(val)["score"].max())
    monitor.threshold = threshold
    val_windows = monitor.evaluate(val)
    ordered = sorted(test[TIME_UTC].unique())
    change = pd.Timestamp(ordered[len(ordered) // 2])
    controls = {}
    for delta in deltas:
        windows = monitor.evaluate(inject_shift(test, columns, change, delta, scale))
        metrics = event_metrics(windows, change)
        after = windows[pd.to_datetime(windows["window_end"], utc=True) >= change]
        alerts = np.flatnonzero(after["alert"].to_numpy())
        controls[str(float(delta))] = {
            "detected": metrics["detected"],
            "false_alarm_rate": metrics["false_alarm_rate"],
            "delay_seconds": (
                float(metrics["detection_delay"].total_seconds()) if metrics["detected"] else None
            ),
            "delay_windows": int(alerts[0]) + 1 if len(alerts) else None,
            "windows_before": int((pd.to_datetime(windows["window_end"], utc=True) < change).sum()),
            "windows_after": len(after),
        }
    return {
        "threshold": threshold,
        "validation_windows": len(val_windows),
        "XXvalidation_false_alarmsXX": int(val_windows["alert"].sum()),
        "change_time": change.isoformat(),
        "window_size": window_size,
        "columns": list(columns),
        "controls": controls,
    }


def x_monitor_control__mutmut_113(train, val, test, columns, deltas=DELTAS, window_size=WINDOW_SIZE):
    """Known-change control: the threshold comes from validation, the change from the test."""
    scale = train[list(columns)].std(ddof=0).replace(0.0, 1.0)
    monitor = WindowDriftMonitor(TIME_UTC, columns, window_size=window_size, threshold=1e12)
    monitor.fit(train)
    threshold = float(monitor.evaluate(val)["score"].max())
    monitor.threshold = threshold
    val_windows = monitor.evaluate(val)
    ordered = sorted(test[TIME_UTC].unique())
    change = pd.Timestamp(ordered[len(ordered) // 2])
    controls = {}
    for delta in deltas:
        windows = monitor.evaluate(inject_shift(test, columns, change, delta, scale))
        metrics = event_metrics(windows, change)
        after = windows[pd.to_datetime(windows["window_end"], utc=True) >= change]
        alerts = np.flatnonzero(after["alert"].to_numpy())
        controls[str(float(delta))] = {
            "detected": metrics["detected"],
            "false_alarm_rate": metrics["false_alarm_rate"],
            "delay_seconds": (
                float(metrics["detection_delay"].total_seconds()) if metrics["detected"] else None
            ),
            "delay_windows": int(alerts[0]) + 1 if len(alerts) else None,
            "windows_before": int((pd.to_datetime(windows["window_end"], utc=True) < change).sum()),
            "windows_after": len(after),
        }
    return {
        "threshold": threshold,
        "validation_windows": len(val_windows),
        "VALIDATION_FALSE_ALARMS": int(val_windows["alert"].sum()),
        "change_time": change.isoformat(),
        "window_size": window_size,
        "columns": list(columns),
        "controls": controls,
    }


def x_monitor_control__mutmut_114(train, val, test, columns, deltas=DELTAS, window_size=WINDOW_SIZE):
    """Known-change control: the threshold comes from validation, the change from the test."""
    scale = train[list(columns)].std(ddof=0).replace(0.0, 1.0)
    monitor = WindowDriftMonitor(TIME_UTC, columns, window_size=window_size, threshold=1e12)
    monitor.fit(train)
    threshold = float(monitor.evaluate(val)["score"].max())
    monitor.threshold = threshold
    val_windows = monitor.evaluate(val)
    ordered = sorted(test[TIME_UTC].unique())
    change = pd.Timestamp(ordered[len(ordered) // 2])
    controls = {}
    for delta in deltas:
        windows = monitor.evaluate(inject_shift(test, columns, change, delta, scale))
        metrics = event_metrics(windows, change)
        after = windows[pd.to_datetime(windows["window_end"], utc=True) >= change]
        alerts = np.flatnonzero(after["alert"].to_numpy())
        controls[str(float(delta))] = {
            "detected": metrics["detected"],
            "false_alarm_rate": metrics["false_alarm_rate"],
            "delay_seconds": (
                float(metrics["detection_delay"].total_seconds()) if metrics["detected"] else None
            ),
            "delay_windows": int(alerts[0]) + 1 if len(alerts) else None,
            "windows_before": int((pd.to_datetime(windows["window_end"], utc=True) < change).sum()),
            "windows_after": len(after),
        }
    return {
        "threshold": threshold,
        "validation_windows": len(val_windows),
        "validation_false_alarms": int(None),
        "change_time": change.isoformat(),
        "window_size": window_size,
        "columns": list(columns),
        "controls": controls,
    }


def x_monitor_control__mutmut_115(train, val, test, columns, deltas=DELTAS, window_size=WINDOW_SIZE):
    """Known-change control: the threshold comes from validation, the change from the test."""
    scale = train[list(columns)].std(ddof=0).replace(0.0, 1.0)
    monitor = WindowDriftMonitor(TIME_UTC, columns, window_size=window_size, threshold=1e12)
    monitor.fit(train)
    threshold = float(monitor.evaluate(val)["score"].max())
    monitor.threshold = threshold
    val_windows = monitor.evaluate(val)
    ordered = sorted(test[TIME_UTC].unique())
    change = pd.Timestamp(ordered[len(ordered) // 2])
    controls = {}
    for delta in deltas:
        windows = monitor.evaluate(inject_shift(test, columns, change, delta, scale))
        metrics = event_metrics(windows, change)
        after = windows[pd.to_datetime(windows["window_end"], utc=True) >= change]
        alerts = np.flatnonzero(after["alert"].to_numpy())
        controls[str(float(delta))] = {
            "detected": metrics["detected"],
            "false_alarm_rate": metrics["false_alarm_rate"],
            "delay_seconds": (
                float(metrics["detection_delay"].total_seconds()) if metrics["detected"] else None
            ),
            "delay_windows": int(alerts[0]) + 1 if len(alerts) else None,
            "windows_before": int((pd.to_datetime(windows["window_end"], utc=True) < change).sum()),
            "windows_after": len(after),
        }
    return {
        "threshold": threshold,
        "validation_windows": len(val_windows),
        "validation_false_alarms": int(val_windows["XXalertXX"].sum()),
        "change_time": change.isoformat(),
        "window_size": window_size,
        "columns": list(columns),
        "controls": controls,
    }


def x_monitor_control__mutmut_116(train, val, test, columns, deltas=DELTAS, window_size=WINDOW_SIZE):
    """Known-change control: the threshold comes from validation, the change from the test."""
    scale = train[list(columns)].std(ddof=0).replace(0.0, 1.0)
    monitor = WindowDriftMonitor(TIME_UTC, columns, window_size=window_size, threshold=1e12)
    monitor.fit(train)
    threshold = float(monitor.evaluate(val)["score"].max())
    monitor.threshold = threshold
    val_windows = monitor.evaluate(val)
    ordered = sorted(test[TIME_UTC].unique())
    change = pd.Timestamp(ordered[len(ordered) // 2])
    controls = {}
    for delta in deltas:
        windows = monitor.evaluate(inject_shift(test, columns, change, delta, scale))
        metrics = event_metrics(windows, change)
        after = windows[pd.to_datetime(windows["window_end"], utc=True) >= change]
        alerts = np.flatnonzero(after["alert"].to_numpy())
        controls[str(float(delta))] = {
            "detected": metrics["detected"],
            "false_alarm_rate": metrics["false_alarm_rate"],
            "delay_seconds": (
                float(metrics["detection_delay"].total_seconds()) if metrics["detected"] else None
            ),
            "delay_windows": int(alerts[0]) + 1 if len(alerts) else None,
            "windows_before": int((pd.to_datetime(windows["window_end"], utc=True) < change).sum()),
            "windows_after": len(after),
        }
    return {
        "threshold": threshold,
        "validation_windows": len(val_windows),
        "validation_false_alarms": int(val_windows["ALERT"].sum()),
        "change_time": change.isoformat(),
        "window_size": window_size,
        "columns": list(columns),
        "controls": controls,
    }


def x_monitor_control__mutmut_117(train, val, test, columns, deltas=DELTAS, window_size=WINDOW_SIZE):
    """Known-change control: the threshold comes from validation, the change from the test."""
    scale = train[list(columns)].std(ddof=0).replace(0.0, 1.0)
    monitor = WindowDriftMonitor(TIME_UTC, columns, window_size=window_size, threshold=1e12)
    monitor.fit(train)
    threshold = float(monitor.evaluate(val)["score"].max())
    monitor.threshold = threshold
    val_windows = monitor.evaluate(val)
    ordered = sorted(test[TIME_UTC].unique())
    change = pd.Timestamp(ordered[len(ordered) // 2])
    controls = {}
    for delta in deltas:
        windows = monitor.evaluate(inject_shift(test, columns, change, delta, scale))
        metrics = event_metrics(windows, change)
        after = windows[pd.to_datetime(windows["window_end"], utc=True) >= change]
        alerts = np.flatnonzero(after["alert"].to_numpy())
        controls[str(float(delta))] = {
            "detected": metrics["detected"],
            "false_alarm_rate": metrics["false_alarm_rate"],
            "delay_seconds": (
                float(metrics["detection_delay"].total_seconds()) if metrics["detected"] else None
            ),
            "delay_windows": int(alerts[0]) + 1 if len(alerts) else None,
            "windows_before": int((pd.to_datetime(windows["window_end"], utc=True) < change).sum()),
            "windows_after": len(after),
        }
    return {
        "threshold": threshold,
        "validation_windows": len(val_windows),
        "validation_false_alarms": int(val_windows["alert"].sum()),
        "XXchange_timeXX": change.isoformat(),
        "window_size": window_size,
        "columns": list(columns),
        "controls": controls,
    }


def x_monitor_control__mutmut_118(train, val, test, columns, deltas=DELTAS, window_size=WINDOW_SIZE):
    """Known-change control: the threshold comes from validation, the change from the test."""
    scale = train[list(columns)].std(ddof=0).replace(0.0, 1.0)
    monitor = WindowDriftMonitor(TIME_UTC, columns, window_size=window_size, threshold=1e12)
    monitor.fit(train)
    threshold = float(monitor.evaluate(val)["score"].max())
    monitor.threshold = threshold
    val_windows = monitor.evaluate(val)
    ordered = sorted(test[TIME_UTC].unique())
    change = pd.Timestamp(ordered[len(ordered) // 2])
    controls = {}
    for delta in deltas:
        windows = monitor.evaluate(inject_shift(test, columns, change, delta, scale))
        metrics = event_metrics(windows, change)
        after = windows[pd.to_datetime(windows["window_end"], utc=True) >= change]
        alerts = np.flatnonzero(after["alert"].to_numpy())
        controls[str(float(delta))] = {
            "detected": metrics["detected"],
            "false_alarm_rate": metrics["false_alarm_rate"],
            "delay_seconds": (
                float(metrics["detection_delay"].total_seconds()) if metrics["detected"] else None
            ),
            "delay_windows": int(alerts[0]) + 1 if len(alerts) else None,
            "windows_before": int((pd.to_datetime(windows["window_end"], utc=True) < change).sum()),
            "windows_after": len(after),
        }
    return {
        "threshold": threshold,
        "validation_windows": len(val_windows),
        "validation_false_alarms": int(val_windows["alert"].sum()),
        "CHANGE_TIME": change.isoformat(),
        "window_size": window_size,
        "columns": list(columns),
        "controls": controls,
    }


def x_monitor_control__mutmut_119(train, val, test, columns, deltas=DELTAS, window_size=WINDOW_SIZE):
    """Known-change control: the threshold comes from validation, the change from the test."""
    scale = train[list(columns)].std(ddof=0).replace(0.0, 1.0)
    monitor = WindowDriftMonitor(TIME_UTC, columns, window_size=window_size, threshold=1e12)
    monitor.fit(train)
    threshold = float(monitor.evaluate(val)["score"].max())
    monitor.threshold = threshold
    val_windows = monitor.evaluate(val)
    ordered = sorted(test[TIME_UTC].unique())
    change = pd.Timestamp(ordered[len(ordered) // 2])
    controls = {}
    for delta in deltas:
        windows = monitor.evaluate(inject_shift(test, columns, change, delta, scale))
        metrics = event_metrics(windows, change)
        after = windows[pd.to_datetime(windows["window_end"], utc=True) >= change]
        alerts = np.flatnonzero(after["alert"].to_numpy())
        controls[str(float(delta))] = {
            "detected": metrics["detected"],
            "false_alarm_rate": metrics["false_alarm_rate"],
            "delay_seconds": (
                float(metrics["detection_delay"].total_seconds()) if metrics["detected"] else None
            ),
            "delay_windows": int(alerts[0]) + 1 if len(alerts) else None,
            "windows_before": int((pd.to_datetime(windows["window_end"], utc=True) < change).sum()),
            "windows_after": len(after),
        }
    return {
        "threshold": threshold,
        "validation_windows": len(val_windows),
        "validation_false_alarms": int(val_windows["alert"].sum()),
        "change_time": change.isoformat(),
        "XXwindow_sizeXX": window_size,
        "columns": list(columns),
        "controls": controls,
    }


def x_monitor_control__mutmut_120(train, val, test, columns, deltas=DELTAS, window_size=WINDOW_SIZE):
    """Known-change control: the threshold comes from validation, the change from the test."""
    scale = train[list(columns)].std(ddof=0).replace(0.0, 1.0)
    monitor = WindowDriftMonitor(TIME_UTC, columns, window_size=window_size, threshold=1e12)
    monitor.fit(train)
    threshold = float(monitor.evaluate(val)["score"].max())
    monitor.threshold = threshold
    val_windows = monitor.evaluate(val)
    ordered = sorted(test[TIME_UTC].unique())
    change = pd.Timestamp(ordered[len(ordered) // 2])
    controls = {}
    for delta in deltas:
        windows = monitor.evaluate(inject_shift(test, columns, change, delta, scale))
        metrics = event_metrics(windows, change)
        after = windows[pd.to_datetime(windows["window_end"], utc=True) >= change]
        alerts = np.flatnonzero(after["alert"].to_numpy())
        controls[str(float(delta))] = {
            "detected": metrics["detected"],
            "false_alarm_rate": metrics["false_alarm_rate"],
            "delay_seconds": (
                float(metrics["detection_delay"].total_seconds()) if metrics["detected"] else None
            ),
            "delay_windows": int(alerts[0]) + 1 if len(alerts) else None,
            "windows_before": int((pd.to_datetime(windows["window_end"], utc=True) < change).sum()),
            "windows_after": len(after),
        }
    return {
        "threshold": threshold,
        "validation_windows": len(val_windows),
        "validation_false_alarms": int(val_windows["alert"].sum()),
        "change_time": change.isoformat(),
        "WINDOW_SIZE": window_size,
        "columns": list(columns),
        "controls": controls,
    }


def x_monitor_control__mutmut_121(train, val, test, columns, deltas=DELTAS, window_size=WINDOW_SIZE):
    """Known-change control: the threshold comes from validation, the change from the test."""
    scale = train[list(columns)].std(ddof=0).replace(0.0, 1.0)
    monitor = WindowDriftMonitor(TIME_UTC, columns, window_size=window_size, threshold=1e12)
    monitor.fit(train)
    threshold = float(monitor.evaluate(val)["score"].max())
    monitor.threshold = threshold
    val_windows = monitor.evaluate(val)
    ordered = sorted(test[TIME_UTC].unique())
    change = pd.Timestamp(ordered[len(ordered) // 2])
    controls = {}
    for delta in deltas:
        windows = monitor.evaluate(inject_shift(test, columns, change, delta, scale))
        metrics = event_metrics(windows, change)
        after = windows[pd.to_datetime(windows["window_end"], utc=True) >= change]
        alerts = np.flatnonzero(after["alert"].to_numpy())
        controls[str(float(delta))] = {
            "detected": metrics["detected"],
            "false_alarm_rate": metrics["false_alarm_rate"],
            "delay_seconds": (
                float(metrics["detection_delay"].total_seconds()) if metrics["detected"] else None
            ),
            "delay_windows": int(alerts[0]) + 1 if len(alerts) else None,
            "windows_before": int((pd.to_datetime(windows["window_end"], utc=True) < change).sum()),
            "windows_after": len(after),
        }
    return {
        "threshold": threshold,
        "validation_windows": len(val_windows),
        "validation_false_alarms": int(val_windows["alert"].sum()),
        "change_time": change.isoformat(),
        "window_size": window_size,
        "XXcolumnsXX": list(columns),
        "controls": controls,
    }


def x_monitor_control__mutmut_122(train, val, test, columns, deltas=DELTAS, window_size=WINDOW_SIZE):
    """Known-change control: the threshold comes from validation, the change from the test."""
    scale = train[list(columns)].std(ddof=0).replace(0.0, 1.0)
    monitor = WindowDriftMonitor(TIME_UTC, columns, window_size=window_size, threshold=1e12)
    monitor.fit(train)
    threshold = float(monitor.evaluate(val)["score"].max())
    monitor.threshold = threshold
    val_windows = monitor.evaluate(val)
    ordered = sorted(test[TIME_UTC].unique())
    change = pd.Timestamp(ordered[len(ordered) // 2])
    controls = {}
    for delta in deltas:
        windows = monitor.evaluate(inject_shift(test, columns, change, delta, scale))
        metrics = event_metrics(windows, change)
        after = windows[pd.to_datetime(windows["window_end"], utc=True) >= change]
        alerts = np.flatnonzero(after["alert"].to_numpy())
        controls[str(float(delta))] = {
            "detected": metrics["detected"],
            "false_alarm_rate": metrics["false_alarm_rate"],
            "delay_seconds": (
                float(metrics["detection_delay"].total_seconds()) if metrics["detected"] else None
            ),
            "delay_windows": int(alerts[0]) + 1 if len(alerts) else None,
            "windows_before": int((pd.to_datetime(windows["window_end"], utc=True) < change).sum()),
            "windows_after": len(after),
        }
    return {
        "threshold": threshold,
        "validation_windows": len(val_windows),
        "validation_false_alarms": int(val_windows["alert"].sum()),
        "change_time": change.isoformat(),
        "window_size": window_size,
        "COLUMNS": list(columns),
        "controls": controls,
    }


def x_monitor_control__mutmut_123(train, val, test, columns, deltas=DELTAS, window_size=WINDOW_SIZE):
    """Known-change control: the threshold comes from validation, the change from the test."""
    scale = train[list(columns)].std(ddof=0).replace(0.0, 1.0)
    monitor = WindowDriftMonitor(TIME_UTC, columns, window_size=window_size, threshold=1e12)
    monitor.fit(train)
    threshold = float(monitor.evaluate(val)["score"].max())
    monitor.threshold = threshold
    val_windows = monitor.evaluate(val)
    ordered = sorted(test[TIME_UTC].unique())
    change = pd.Timestamp(ordered[len(ordered) // 2])
    controls = {}
    for delta in deltas:
        windows = monitor.evaluate(inject_shift(test, columns, change, delta, scale))
        metrics = event_metrics(windows, change)
        after = windows[pd.to_datetime(windows["window_end"], utc=True) >= change]
        alerts = np.flatnonzero(after["alert"].to_numpy())
        controls[str(float(delta))] = {
            "detected": metrics["detected"],
            "false_alarm_rate": metrics["false_alarm_rate"],
            "delay_seconds": (
                float(metrics["detection_delay"].total_seconds()) if metrics["detected"] else None
            ),
            "delay_windows": int(alerts[0]) + 1 if len(alerts) else None,
            "windows_before": int((pd.to_datetime(windows["window_end"], utc=True) < change).sum()),
            "windows_after": len(after),
        }
    return {
        "threshold": threshold,
        "validation_windows": len(val_windows),
        "validation_false_alarms": int(val_windows["alert"].sum()),
        "change_time": change.isoformat(),
        "window_size": window_size,
        "columns": list(None),
        "controls": controls,
    }


def x_monitor_control__mutmut_124(train, val, test, columns, deltas=DELTAS, window_size=WINDOW_SIZE):
    """Known-change control: the threshold comes from validation, the change from the test."""
    scale = train[list(columns)].std(ddof=0).replace(0.0, 1.0)
    monitor = WindowDriftMonitor(TIME_UTC, columns, window_size=window_size, threshold=1e12)
    monitor.fit(train)
    threshold = float(monitor.evaluate(val)["score"].max())
    monitor.threshold = threshold
    val_windows = monitor.evaluate(val)
    ordered = sorted(test[TIME_UTC].unique())
    change = pd.Timestamp(ordered[len(ordered) // 2])
    controls = {}
    for delta in deltas:
        windows = monitor.evaluate(inject_shift(test, columns, change, delta, scale))
        metrics = event_metrics(windows, change)
        after = windows[pd.to_datetime(windows["window_end"], utc=True) >= change]
        alerts = np.flatnonzero(after["alert"].to_numpy())
        controls[str(float(delta))] = {
            "detected": metrics["detected"],
            "false_alarm_rate": metrics["false_alarm_rate"],
            "delay_seconds": (
                float(metrics["detection_delay"].total_seconds()) if metrics["detected"] else None
            ),
            "delay_windows": int(alerts[0]) + 1 if len(alerts) else None,
            "windows_before": int((pd.to_datetime(windows["window_end"], utc=True) < change).sum()),
            "windows_after": len(after),
        }
    return {
        "threshold": threshold,
        "validation_windows": len(val_windows),
        "validation_false_alarms": int(val_windows["alert"].sum()),
        "change_time": change.isoformat(),
        "window_size": window_size,
        "columns": list(columns),
        "XXcontrolsXX": controls,
    }


def x_monitor_control__mutmut_125(train, val, test, columns, deltas=DELTAS, window_size=WINDOW_SIZE):
    """Known-change control: the threshold comes from validation, the change from the test."""
    scale = train[list(columns)].std(ddof=0).replace(0.0, 1.0)
    monitor = WindowDriftMonitor(TIME_UTC, columns, window_size=window_size, threshold=1e12)
    monitor.fit(train)
    threshold = float(monitor.evaluate(val)["score"].max())
    monitor.threshold = threshold
    val_windows = monitor.evaluate(val)
    ordered = sorted(test[TIME_UTC].unique())
    change = pd.Timestamp(ordered[len(ordered) // 2])
    controls = {}
    for delta in deltas:
        windows = monitor.evaluate(inject_shift(test, columns, change, delta, scale))
        metrics = event_metrics(windows, change)
        after = windows[pd.to_datetime(windows["window_end"], utc=True) >= change]
        alerts = np.flatnonzero(after["alert"].to_numpy())
        controls[str(float(delta))] = {
            "detected": metrics["detected"],
            "false_alarm_rate": metrics["false_alarm_rate"],
            "delay_seconds": (
                float(metrics["detection_delay"].total_seconds()) if metrics["detected"] else None
            ),
            "delay_windows": int(alerts[0]) + 1 if len(alerts) else None,
            "windows_before": int((pd.to_datetime(windows["window_end"], utc=True) < change).sum()),
            "windows_after": len(after),
        }
    return {
        "threshold": threshold,
        "validation_windows": len(val_windows),
        "validation_false_alarms": int(val_windows["alert"].sum()),
        "change_time": change.isoformat(),
        "window_size": window_size,
        "columns": list(columns),
        "CONTROLS": controls,
    }

mutants_x_monitor_control__mutmut['_mutmut_orig'] = x_monitor_control__mutmut_orig # type: ignore # mutmut generated
mutants_x_monitor_control__mutmut['x_monitor_control__mutmut_1'] = x_monitor_control__mutmut_1 # type: ignore # mutmut generated
mutants_x_monitor_control__mutmut['x_monitor_control__mutmut_2'] = x_monitor_control__mutmut_2 # type: ignore # mutmut generated
mutants_x_monitor_control__mutmut['x_monitor_control__mutmut_3'] = x_monitor_control__mutmut_3 # type: ignore # mutmut generated
mutants_x_monitor_control__mutmut['x_monitor_control__mutmut_4'] = x_monitor_control__mutmut_4 # type: ignore # mutmut generated
mutants_x_monitor_control__mutmut['x_monitor_control__mutmut_5'] = x_monitor_control__mutmut_5 # type: ignore # mutmut generated
mutants_x_monitor_control__mutmut['x_monitor_control__mutmut_6'] = x_monitor_control__mutmut_6 # type: ignore # mutmut generated
mutants_x_monitor_control__mutmut['x_monitor_control__mutmut_7'] = x_monitor_control__mutmut_7 # type: ignore # mutmut generated
mutants_x_monitor_control__mutmut['x_monitor_control__mutmut_8'] = x_monitor_control__mutmut_8 # type: ignore # mutmut generated
mutants_x_monitor_control__mutmut['x_monitor_control__mutmut_9'] = x_monitor_control__mutmut_9 # type: ignore # mutmut generated
mutants_x_monitor_control__mutmut['x_monitor_control__mutmut_10'] = x_monitor_control__mutmut_10 # type: ignore # mutmut generated
mutants_x_monitor_control__mutmut['x_monitor_control__mutmut_11'] = x_monitor_control__mutmut_11 # type: ignore # mutmut generated
mutants_x_monitor_control__mutmut['x_monitor_control__mutmut_12'] = x_monitor_control__mutmut_12 # type: ignore # mutmut generated
mutants_x_monitor_control__mutmut['x_monitor_control__mutmut_13'] = x_monitor_control__mutmut_13 # type: ignore # mutmut generated
mutants_x_monitor_control__mutmut['x_monitor_control__mutmut_14'] = x_monitor_control__mutmut_14 # type: ignore # mutmut generated
mutants_x_monitor_control__mutmut['x_monitor_control__mutmut_15'] = x_monitor_control__mutmut_15 # type: ignore # mutmut generated
mutants_x_monitor_control__mutmut['x_monitor_control__mutmut_16'] = x_monitor_control__mutmut_16 # type: ignore # mutmut generated
mutants_x_monitor_control__mutmut['x_monitor_control__mutmut_17'] = x_monitor_control__mutmut_17 # type: ignore # mutmut generated
mutants_x_monitor_control__mutmut['x_monitor_control__mutmut_18'] = x_monitor_control__mutmut_18 # type: ignore # mutmut generated
mutants_x_monitor_control__mutmut['x_monitor_control__mutmut_19'] = x_monitor_control__mutmut_19 # type: ignore # mutmut generated
mutants_x_monitor_control__mutmut['x_monitor_control__mutmut_20'] = x_monitor_control__mutmut_20 # type: ignore # mutmut generated
mutants_x_monitor_control__mutmut['x_monitor_control__mutmut_21'] = x_monitor_control__mutmut_21 # type: ignore # mutmut generated
mutants_x_monitor_control__mutmut['x_monitor_control__mutmut_22'] = x_monitor_control__mutmut_22 # type: ignore # mutmut generated
mutants_x_monitor_control__mutmut['x_monitor_control__mutmut_23'] = x_monitor_control__mutmut_23 # type: ignore # mutmut generated
mutants_x_monitor_control__mutmut['x_monitor_control__mutmut_24'] = x_monitor_control__mutmut_24 # type: ignore # mutmut generated
mutants_x_monitor_control__mutmut['x_monitor_control__mutmut_25'] = x_monitor_control__mutmut_25 # type: ignore # mutmut generated
mutants_x_monitor_control__mutmut['x_monitor_control__mutmut_26'] = x_monitor_control__mutmut_26 # type: ignore # mutmut generated
mutants_x_monitor_control__mutmut['x_monitor_control__mutmut_27'] = x_monitor_control__mutmut_27 # type: ignore # mutmut generated
mutants_x_monitor_control__mutmut['x_monitor_control__mutmut_28'] = x_monitor_control__mutmut_28 # type: ignore # mutmut generated
mutants_x_monitor_control__mutmut['x_monitor_control__mutmut_29'] = x_monitor_control__mutmut_29 # type: ignore # mutmut generated
mutants_x_monitor_control__mutmut['x_monitor_control__mutmut_30'] = x_monitor_control__mutmut_30 # type: ignore # mutmut generated
mutants_x_monitor_control__mutmut['x_monitor_control__mutmut_31'] = x_monitor_control__mutmut_31 # type: ignore # mutmut generated
mutants_x_monitor_control__mutmut['x_monitor_control__mutmut_32'] = x_monitor_control__mutmut_32 # type: ignore # mutmut generated
mutants_x_monitor_control__mutmut['x_monitor_control__mutmut_33'] = x_monitor_control__mutmut_33 # type: ignore # mutmut generated
mutants_x_monitor_control__mutmut['x_monitor_control__mutmut_34'] = x_monitor_control__mutmut_34 # type: ignore # mutmut generated
mutants_x_monitor_control__mutmut['x_monitor_control__mutmut_35'] = x_monitor_control__mutmut_35 # type: ignore # mutmut generated
mutants_x_monitor_control__mutmut['x_monitor_control__mutmut_36'] = x_monitor_control__mutmut_36 # type: ignore # mutmut generated
mutants_x_monitor_control__mutmut['x_monitor_control__mutmut_37'] = x_monitor_control__mutmut_37 # type: ignore # mutmut generated
mutants_x_monitor_control__mutmut['x_monitor_control__mutmut_38'] = x_monitor_control__mutmut_38 # type: ignore # mutmut generated
mutants_x_monitor_control__mutmut['x_monitor_control__mutmut_39'] = x_monitor_control__mutmut_39 # type: ignore # mutmut generated
mutants_x_monitor_control__mutmut['x_monitor_control__mutmut_40'] = x_monitor_control__mutmut_40 # type: ignore # mutmut generated
mutants_x_monitor_control__mutmut['x_monitor_control__mutmut_41'] = x_monitor_control__mutmut_41 # type: ignore # mutmut generated
mutants_x_monitor_control__mutmut['x_monitor_control__mutmut_42'] = x_monitor_control__mutmut_42 # type: ignore # mutmut generated
mutants_x_monitor_control__mutmut['x_monitor_control__mutmut_43'] = x_monitor_control__mutmut_43 # type: ignore # mutmut generated
mutants_x_monitor_control__mutmut['x_monitor_control__mutmut_44'] = x_monitor_control__mutmut_44 # type: ignore # mutmut generated
mutants_x_monitor_control__mutmut['x_monitor_control__mutmut_45'] = x_monitor_control__mutmut_45 # type: ignore # mutmut generated
mutants_x_monitor_control__mutmut['x_monitor_control__mutmut_46'] = x_monitor_control__mutmut_46 # type: ignore # mutmut generated
mutants_x_monitor_control__mutmut['x_monitor_control__mutmut_47'] = x_monitor_control__mutmut_47 # type: ignore # mutmut generated
mutants_x_monitor_control__mutmut['x_monitor_control__mutmut_48'] = x_monitor_control__mutmut_48 # type: ignore # mutmut generated
mutants_x_monitor_control__mutmut['x_monitor_control__mutmut_49'] = x_monitor_control__mutmut_49 # type: ignore # mutmut generated
mutants_x_monitor_control__mutmut['x_monitor_control__mutmut_50'] = x_monitor_control__mutmut_50 # type: ignore # mutmut generated
mutants_x_monitor_control__mutmut['x_monitor_control__mutmut_51'] = x_monitor_control__mutmut_51 # type: ignore # mutmut generated
mutants_x_monitor_control__mutmut['x_monitor_control__mutmut_52'] = x_monitor_control__mutmut_52 # type: ignore # mutmut generated
mutants_x_monitor_control__mutmut['x_monitor_control__mutmut_53'] = x_monitor_control__mutmut_53 # type: ignore # mutmut generated
mutants_x_monitor_control__mutmut['x_monitor_control__mutmut_54'] = x_monitor_control__mutmut_54 # type: ignore # mutmut generated
mutants_x_monitor_control__mutmut['x_monitor_control__mutmut_55'] = x_monitor_control__mutmut_55 # type: ignore # mutmut generated
mutants_x_monitor_control__mutmut['x_monitor_control__mutmut_56'] = x_monitor_control__mutmut_56 # type: ignore # mutmut generated
mutants_x_monitor_control__mutmut['x_monitor_control__mutmut_57'] = x_monitor_control__mutmut_57 # type: ignore # mutmut generated
mutants_x_monitor_control__mutmut['x_monitor_control__mutmut_58'] = x_monitor_control__mutmut_58 # type: ignore # mutmut generated
mutants_x_monitor_control__mutmut['x_monitor_control__mutmut_59'] = x_monitor_control__mutmut_59 # type: ignore # mutmut generated
mutants_x_monitor_control__mutmut['x_monitor_control__mutmut_60'] = x_monitor_control__mutmut_60 # type: ignore # mutmut generated
mutants_x_monitor_control__mutmut['x_monitor_control__mutmut_61'] = x_monitor_control__mutmut_61 # type: ignore # mutmut generated
mutants_x_monitor_control__mutmut['x_monitor_control__mutmut_62'] = x_monitor_control__mutmut_62 # type: ignore # mutmut generated
mutants_x_monitor_control__mutmut['x_monitor_control__mutmut_63'] = x_monitor_control__mutmut_63 # type: ignore # mutmut generated
mutants_x_monitor_control__mutmut['x_monitor_control__mutmut_64'] = x_monitor_control__mutmut_64 # type: ignore # mutmut generated
mutants_x_monitor_control__mutmut['x_monitor_control__mutmut_65'] = x_monitor_control__mutmut_65 # type: ignore # mutmut generated
mutants_x_monitor_control__mutmut['x_monitor_control__mutmut_66'] = x_monitor_control__mutmut_66 # type: ignore # mutmut generated
mutants_x_monitor_control__mutmut['x_monitor_control__mutmut_67'] = x_monitor_control__mutmut_67 # type: ignore # mutmut generated
mutants_x_monitor_control__mutmut['x_monitor_control__mutmut_68'] = x_monitor_control__mutmut_68 # type: ignore # mutmut generated
mutants_x_monitor_control__mutmut['x_monitor_control__mutmut_69'] = x_monitor_control__mutmut_69 # type: ignore # mutmut generated
mutants_x_monitor_control__mutmut['x_monitor_control__mutmut_70'] = x_monitor_control__mutmut_70 # type: ignore # mutmut generated
mutants_x_monitor_control__mutmut['x_monitor_control__mutmut_71'] = x_monitor_control__mutmut_71 # type: ignore # mutmut generated
mutants_x_monitor_control__mutmut['x_monitor_control__mutmut_72'] = x_monitor_control__mutmut_72 # type: ignore # mutmut generated
mutants_x_monitor_control__mutmut['x_monitor_control__mutmut_73'] = x_monitor_control__mutmut_73 # type: ignore # mutmut generated
mutants_x_monitor_control__mutmut['x_monitor_control__mutmut_74'] = x_monitor_control__mutmut_74 # type: ignore # mutmut generated
mutants_x_monitor_control__mutmut['x_monitor_control__mutmut_75'] = x_monitor_control__mutmut_75 # type: ignore # mutmut generated
mutants_x_monitor_control__mutmut['x_monitor_control__mutmut_76'] = x_monitor_control__mutmut_76 # type: ignore # mutmut generated
mutants_x_monitor_control__mutmut['x_monitor_control__mutmut_77'] = x_monitor_control__mutmut_77 # type: ignore # mutmut generated
mutants_x_monitor_control__mutmut['x_monitor_control__mutmut_78'] = x_monitor_control__mutmut_78 # type: ignore # mutmut generated
mutants_x_monitor_control__mutmut['x_monitor_control__mutmut_79'] = x_monitor_control__mutmut_79 # type: ignore # mutmut generated
mutants_x_monitor_control__mutmut['x_monitor_control__mutmut_80'] = x_monitor_control__mutmut_80 # type: ignore # mutmut generated
mutants_x_monitor_control__mutmut['x_monitor_control__mutmut_81'] = x_monitor_control__mutmut_81 # type: ignore # mutmut generated
mutants_x_monitor_control__mutmut['x_monitor_control__mutmut_82'] = x_monitor_control__mutmut_82 # type: ignore # mutmut generated
mutants_x_monitor_control__mutmut['x_monitor_control__mutmut_83'] = x_monitor_control__mutmut_83 # type: ignore # mutmut generated
mutants_x_monitor_control__mutmut['x_monitor_control__mutmut_84'] = x_monitor_control__mutmut_84 # type: ignore # mutmut generated
mutants_x_monitor_control__mutmut['x_monitor_control__mutmut_85'] = x_monitor_control__mutmut_85 # type: ignore # mutmut generated
mutants_x_monitor_control__mutmut['x_monitor_control__mutmut_86'] = x_monitor_control__mutmut_86 # type: ignore # mutmut generated
mutants_x_monitor_control__mutmut['x_monitor_control__mutmut_87'] = x_monitor_control__mutmut_87 # type: ignore # mutmut generated
mutants_x_monitor_control__mutmut['x_monitor_control__mutmut_88'] = x_monitor_control__mutmut_88 # type: ignore # mutmut generated
mutants_x_monitor_control__mutmut['x_monitor_control__mutmut_89'] = x_monitor_control__mutmut_89 # type: ignore # mutmut generated
mutants_x_monitor_control__mutmut['x_monitor_control__mutmut_90'] = x_monitor_control__mutmut_90 # type: ignore # mutmut generated
mutants_x_monitor_control__mutmut['x_monitor_control__mutmut_91'] = x_monitor_control__mutmut_91 # type: ignore # mutmut generated
mutants_x_monitor_control__mutmut['x_monitor_control__mutmut_92'] = x_monitor_control__mutmut_92 # type: ignore # mutmut generated
mutants_x_monitor_control__mutmut['x_monitor_control__mutmut_93'] = x_monitor_control__mutmut_93 # type: ignore # mutmut generated
mutants_x_monitor_control__mutmut['x_monitor_control__mutmut_94'] = x_monitor_control__mutmut_94 # type: ignore # mutmut generated
mutants_x_monitor_control__mutmut['x_monitor_control__mutmut_95'] = x_monitor_control__mutmut_95 # type: ignore # mutmut generated
mutants_x_monitor_control__mutmut['x_monitor_control__mutmut_96'] = x_monitor_control__mutmut_96 # type: ignore # mutmut generated
mutants_x_monitor_control__mutmut['x_monitor_control__mutmut_97'] = x_monitor_control__mutmut_97 # type: ignore # mutmut generated
mutants_x_monitor_control__mutmut['x_monitor_control__mutmut_98'] = x_monitor_control__mutmut_98 # type: ignore # mutmut generated
mutants_x_monitor_control__mutmut['x_monitor_control__mutmut_99'] = x_monitor_control__mutmut_99 # type: ignore # mutmut generated
mutants_x_monitor_control__mutmut['x_monitor_control__mutmut_100'] = x_monitor_control__mutmut_100 # type: ignore # mutmut generated
mutants_x_monitor_control__mutmut['x_monitor_control__mutmut_101'] = x_monitor_control__mutmut_101 # type: ignore # mutmut generated
mutants_x_monitor_control__mutmut['x_monitor_control__mutmut_102'] = x_monitor_control__mutmut_102 # type: ignore # mutmut generated
mutants_x_monitor_control__mutmut['x_monitor_control__mutmut_103'] = x_monitor_control__mutmut_103 # type: ignore # mutmut generated
mutants_x_monitor_control__mutmut['x_monitor_control__mutmut_104'] = x_monitor_control__mutmut_104 # type: ignore # mutmut generated
mutants_x_monitor_control__mutmut['x_monitor_control__mutmut_105'] = x_monitor_control__mutmut_105 # type: ignore # mutmut generated
mutants_x_monitor_control__mutmut['x_monitor_control__mutmut_106'] = x_monitor_control__mutmut_106 # type: ignore # mutmut generated
mutants_x_monitor_control__mutmut['x_monitor_control__mutmut_107'] = x_monitor_control__mutmut_107 # type: ignore # mutmut generated
mutants_x_monitor_control__mutmut['x_monitor_control__mutmut_108'] = x_monitor_control__mutmut_108 # type: ignore # mutmut generated
mutants_x_monitor_control__mutmut['x_monitor_control__mutmut_109'] = x_monitor_control__mutmut_109 # type: ignore # mutmut generated
mutants_x_monitor_control__mutmut['x_monitor_control__mutmut_110'] = x_monitor_control__mutmut_110 # type: ignore # mutmut generated
mutants_x_monitor_control__mutmut['x_monitor_control__mutmut_111'] = x_monitor_control__mutmut_111 # type: ignore # mutmut generated
mutants_x_monitor_control__mutmut['x_monitor_control__mutmut_112'] = x_monitor_control__mutmut_112 # type: ignore # mutmut generated
mutants_x_monitor_control__mutmut['x_monitor_control__mutmut_113'] = x_monitor_control__mutmut_113 # type: ignore # mutmut generated
mutants_x_monitor_control__mutmut['x_monitor_control__mutmut_114'] = x_monitor_control__mutmut_114 # type: ignore # mutmut generated
mutants_x_monitor_control__mutmut['x_monitor_control__mutmut_115'] = x_monitor_control__mutmut_115 # type: ignore # mutmut generated
mutants_x_monitor_control__mutmut['x_monitor_control__mutmut_116'] = x_monitor_control__mutmut_116 # type: ignore # mutmut generated
mutants_x_monitor_control__mutmut['x_monitor_control__mutmut_117'] = x_monitor_control__mutmut_117 # type: ignore # mutmut generated
mutants_x_monitor_control__mutmut['x_monitor_control__mutmut_118'] = x_monitor_control__mutmut_118 # type: ignore # mutmut generated
mutants_x_monitor_control__mutmut['x_monitor_control__mutmut_119'] = x_monitor_control__mutmut_119 # type: ignore # mutmut generated
mutants_x_monitor_control__mutmut['x_monitor_control__mutmut_120'] = x_monitor_control__mutmut_120 # type: ignore # mutmut generated
mutants_x_monitor_control__mutmut['x_monitor_control__mutmut_121'] = x_monitor_control__mutmut_121 # type: ignore # mutmut generated
mutants_x_monitor_control__mutmut['x_monitor_control__mutmut_122'] = x_monitor_control__mutmut_122 # type: ignore # mutmut generated
mutants_x_monitor_control__mutmut['x_monitor_control__mutmut_123'] = x_monitor_control__mutmut_123 # type: ignore # mutmut generated
mutants_x_monitor_control__mutmut['x_monitor_control__mutmut_124'] = x_monitor_control__mutmut_124 # type: ignore # mutmut generated
mutants_x_monitor_control__mutmut['x_monitor_control__mutmut_125'] = x_monitor_control__mutmut_125 # type: ignore # mutmut generated
mutants_x_describe__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_describe__mutmut)
def describe(frame: pd.DataFrame) -> dict[str, Any]:
    return {
        "rows": len(frame),
        "frauds": int(frame[ANOMALY_COLUMN].sum()),
        "prevalence": float(frame[ANOMALY_COLUMN].mean()),
        "time_min_s": float(frame["Time"].min()),
        "time_max_s": float(frame["Time"].max()),
    }


def x_describe__mutmut_orig(frame: pd.DataFrame) -> dict[str, Any]:
    return {
        "rows": len(frame),
        "frauds": int(frame[ANOMALY_COLUMN].sum()),
        "prevalence": float(frame[ANOMALY_COLUMN].mean()),
        "time_min_s": float(frame["Time"].min()),
        "time_max_s": float(frame["Time"].max()),
    }


def x_describe__mutmut_1(frame: pd.DataFrame) -> dict[str, Any]:
    return {
        "XXrowsXX": len(frame),
        "frauds": int(frame[ANOMALY_COLUMN].sum()),
        "prevalence": float(frame[ANOMALY_COLUMN].mean()),
        "time_min_s": float(frame["Time"].min()),
        "time_max_s": float(frame["Time"].max()),
    }


def x_describe__mutmut_2(frame: pd.DataFrame) -> dict[str, Any]:
    return {
        "ROWS": len(frame),
        "frauds": int(frame[ANOMALY_COLUMN].sum()),
        "prevalence": float(frame[ANOMALY_COLUMN].mean()),
        "time_min_s": float(frame["Time"].min()),
        "time_max_s": float(frame["Time"].max()),
    }


def x_describe__mutmut_3(frame: pd.DataFrame) -> dict[str, Any]:
    return {
        "rows": len(frame),
        "XXfraudsXX": int(frame[ANOMALY_COLUMN].sum()),
        "prevalence": float(frame[ANOMALY_COLUMN].mean()),
        "time_min_s": float(frame["Time"].min()),
        "time_max_s": float(frame["Time"].max()),
    }


def x_describe__mutmut_4(frame: pd.DataFrame) -> dict[str, Any]:
    return {
        "rows": len(frame),
        "FRAUDS": int(frame[ANOMALY_COLUMN].sum()),
        "prevalence": float(frame[ANOMALY_COLUMN].mean()),
        "time_min_s": float(frame["Time"].min()),
        "time_max_s": float(frame["Time"].max()),
    }


def x_describe__mutmut_5(frame: pd.DataFrame) -> dict[str, Any]:
    return {
        "rows": len(frame),
        "frauds": int(None),
        "prevalence": float(frame[ANOMALY_COLUMN].mean()),
        "time_min_s": float(frame["Time"].min()),
        "time_max_s": float(frame["Time"].max()),
    }


def x_describe__mutmut_6(frame: pd.DataFrame) -> dict[str, Any]:
    return {
        "rows": len(frame),
        "frauds": int(frame[ANOMALY_COLUMN].sum()),
        "XXprevalenceXX": float(frame[ANOMALY_COLUMN].mean()),
        "time_min_s": float(frame["Time"].min()),
        "time_max_s": float(frame["Time"].max()),
    }


def x_describe__mutmut_7(frame: pd.DataFrame) -> dict[str, Any]:
    return {
        "rows": len(frame),
        "frauds": int(frame[ANOMALY_COLUMN].sum()),
        "PREVALENCE": float(frame[ANOMALY_COLUMN].mean()),
        "time_min_s": float(frame["Time"].min()),
        "time_max_s": float(frame["Time"].max()),
    }


def x_describe__mutmut_8(frame: pd.DataFrame) -> dict[str, Any]:
    return {
        "rows": len(frame),
        "frauds": int(frame[ANOMALY_COLUMN].sum()),
        "prevalence": float(None),
        "time_min_s": float(frame["Time"].min()),
        "time_max_s": float(frame["Time"].max()),
    }


def x_describe__mutmut_9(frame: pd.DataFrame) -> dict[str, Any]:
    return {
        "rows": len(frame),
        "frauds": int(frame[ANOMALY_COLUMN].sum()),
        "prevalence": float(frame[ANOMALY_COLUMN].mean()),
        "XXtime_min_sXX": float(frame["Time"].min()),
        "time_max_s": float(frame["Time"].max()),
    }


def x_describe__mutmut_10(frame: pd.DataFrame) -> dict[str, Any]:
    return {
        "rows": len(frame),
        "frauds": int(frame[ANOMALY_COLUMN].sum()),
        "prevalence": float(frame[ANOMALY_COLUMN].mean()),
        "TIME_MIN_S": float(frame["Time"].min()),
        "time_max_s": float(frame["Time"].max()),
    }


def x_describe__mutmut_11(frame: pd.DataFrame) -> dict[str, Any]:
    return {
        "rows": len(frame),
        "frauds": int(frame[ANOMALY_COLUMN].sum()),
        "prevalence": float(frame[ANOMALY_COLUMN].mean()),
        "time_min_s": float(None),
        "time_max_s": float(frame["Time"].max()),
    }


def x_describe__mutmut_12(frame: pd.DataFrame) -> dict[str, Any]:
    return {
        "rows": len(frame),
        "frauds": int(frame[ANOMALY_COLUMN].sum()),
        "prevalence": float(frame[ANOMALY_COLUMN].mean()),
        "time_min_s": float(frame["XXTimeXX"].min()),
        "time_max_s": float(frame["Time"].max()),
    }


def x_describe__mutmut_13(frame: pd.DataFrame) -> dict[str, Any]:
    return {
        "rows": len(frame),
        "frauds": int(frame[ANOMALY_COLUMN].sum()),
        "prevalence": float(frame[ANOMALY_COLUMN].mean()),
        "time_min_s": float(frame["time"].min()),
        "time_max_s": float(frame["Time"].max()),
    }


def x_describe__mutmut_14(frame: pd.DataFrame) -> dict[str, Any]:
    return {
        "rows": len(frame),
        "frauds": int(frame[ANOMALY_COLUMN].sum()),
        "prevalence": float(frame[ANOMALY_COLUMN].mean()),
        "time_min_s": float(frame["TIME"].min()),
        "time_max_s": float(frame["Time"].max()),
    }


def x_describe__mutmut_15(frame: pd.DataFrame) -> dict[str, Any]:
    return {
        "rows": len(frame),
        "frauds": int(frame[ANOMALY_COLUMN].sum()),
        "prevalence": float(frame[ANOMALY_COLUMN].mean()),
        "time_min_s": float(frame["Time"].min()),
        "XXtime_max_sXX": float(frame["Time"].max()),
    }


def x_describe__mutmut_16(frame: pd.DataFrame) -> dict[str, Any]:
    return {
        "rows": len(frame),
        "frauds": int(frame[ANOMALY_COLUMN].sum()),
        "prevalence": float(frame[ANOMALY_COLUMN].mean()),
        "time_min_s": float(frame["Time"].min()),
        "TIME_MAX_S": float(frame["Time"].max()),
    }


def x_describe__mutmut_17(frame: pd.DataFrame) -> dict[str, Any]:
    return {
        "rows": len(frame),
        "frauds": int(frame[ANOMALY_COLUMN].sum()),
        "prevalence": float(frame[ANOMALY_COLUMN].mean()),
        "time_min_s": float(frame["Time"].min()),
        "time_max_s": float(None),
    }


def x_describe__mutmut_18(frame: pd.DataFrame) -> dict[str, Any]:
    return {
        "rows": len(frame),
        "frauds": int(frame[ANOMALY_COLUMN].sum()),
        "prevalence": float(frame[ANOMALY_COLUMN].mean()),
        "time_min_s": float(frame["Time"].min()),
        "time_max_s": float(frame["XXTimeXX"].max()),
    }


def x_describe__mutmut_19(frame: pd.DataFrame) -> dict[str, Any]:
    return {
        "rows": len(frame),
        "frauds": int(frame[ANOMALY_COLUMN].sum()),
        "prevalence": float(frame[ANOMALY_COLUMN].mean()),
        "time_min_s": float(frame["Time"].min()),
        "time_max_s": float(frame["time"].max()),
    }


def x_describe__mutmut_20(frame: pd.DataFrame) -> dict[str, Any]:
    return {
        "rows": len(frame),
        "frauds": int(frame[ANOMALY_COLUMN].sum()),
        "prevalence": float(frame[ANOMALY_COLUMN].mean()),
        "time_min_s": float(frame["Time"].min()),
        "time_max_s": float(frame["TIME"].max()),
    }

mutants_x_describe__mutmut['_mutmut_orig'] = x_describe__mutmut_orig # type: ignore # mutmut generated
mutants_x_describe__mutmut['x_describe__mutmut_1'] = x_describe__mutmut_1 # type: ignore # mutmut generated
mutants_x_describe__mutmut['x_describe__mutmut_2'] = x_describe__mutmut_2 # type: ignore # mutmut generated
mutants_x_describe__mutmut['x_describe__mutmut_3'] = x_describe__mutmut_3 # type: ignore # mutmut generated
mutants_x_describe__mutmut['x_describe__mutmut_4'] = x_describe__mutmut_4 # type: ignore # mutmut generated
mutants_x_describe__mutmut['x_describe__mutmut_5'] = x_describe__mutmut_5 # type: ignore # mutmut generated
mutants_x_describe__mutmut['x_describe__mutmut_6'] = x_describe__mutmut_6 # type: ignore # mutmut generated
mutants_x_describe__mutmut['x_describe__mutmut_7'] = x_describe__mutmut_7 # type: ignore # mutmut generated
mutants_x_describe__mutmut['x_describe__mutmut_8'] = x_describe__mutmut_8 # type: ignore # mutmut generated
mutants_x_describe__mutmut['x_describe__mutmut_9'] = x_describe__mutmut_9 # type: ignore # mutmut generated
mutants_x_describe__mutmut['x_describe__mutmut_10'] = x_describe__mutmut_10 # type: ignore # mutmut generated
mutants_x_describe__mutmut['x_describe__mutmut_11'] = x_describe__mutmut_11 # type: ignore # mutmut generated
mutants_x_describe__mutmut['x_describe__mutmut_12'] = x_describe__mutmut_12 # type: ignore # mutmut generated
mutants_x_describe__mutmut['x_describe__mutmut_13'] = x_describe__mutmut_13 # type: ignore # mutmut generated
mutants_x_describe__mutmut['x_describe__mutmut_14'] = x_describe__mutmut_14 # type: ignore # mutmut generated
mutants_x_describe__mutmut['x_describe__mutmut_15'] = x_describe__mutmut_15 # type: ignore # mutmut generated
mutants_x_describe__mutmut['x_describe__mutmut_16'] = x_describe__mutmut_16 # type: ignore # mutmut generated
mutants_x_describe__mutmut['x_describe__mutmut_17'] = x_describe__mutmut_17 # type: ignore # mutmut generated
mutants_x_describe__mutmut['x_describe__mutmut_18'] = x_describe__mutmut_18 # type: ignore # mutmut generated
mutants_x_describe__mutmut['x_describe__mutmut_19'] = x_describe__mutmut_19 # type: ignore # mutmut generated
mutants_x_describe__mutmut['x_describe__mutmut_20'] = x_describe__mutmut_20 # type: ignore # mutmut generated
mutants_x_run__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_run__mutmut)
def run(spec: DatasetSpec, seeds=config.BENCHMARK_SEEDS) -> dict[str, Any]:
    frame = load(spec)
    train, val, test = chronological_partitions(frame)
    scored = score_partition(spec, train, test)
    chrono = {}
    for name, score in scored["scores"].items():
        metrics = compute_metrics(scored["y"], scored["flags"][name], score)
        ci = block_bootstrap_ci(
            scored["y"], score, test[TIME_UTC], BLOCK_SECONDS, RESAMPLES, BOOTSTRAP_SEED
        )
        chrono[name] = {**metrics, "pr_auc_ci": ci}
    control: dict[str, dict[str, list[float]]] = {}
    for seed in seeds:
        s_train, _s_val, s_test = stratified_partitions(frame, seed)
        s_scored = score_partition(spec, s_train, s_test)
        for name, score in s_scored["scores"].items():
            m = compute_metrics(s_scored["y"], s_scored["flags"][name], score)
            for key, value in m.items():
                control.setdefault(name, {}).setdefault(key, []).append(float(value))
    stratified = {
        name: {k: {"mean": float(np.mean(v)), "std": float(np.std(v, ddof=1)), "values": v}
               for k, v in metrics.items()}
        for name, metrics in control.items()
    }  # fmt: skip
    return {
        "partitions": {
            "train": describe(train),
            "validation": describe(val),
            "test": describe(test),
        },
        "chronological": chrono,
        "stratified": stratified,
        "drift_control": monitor_control(train, val, test, DRIFT_COLUMNS),
        "settings": {
            "seeds": list(seeds),
            "block_seconds": BLOCK_SECONDS,
            "resamples": RESAMPLES,
            "bootstrap_seed": BOOTSTRAP_SEED,
            "window_size": WINDOW_SIZE,
            "deltas": list(DELTAS),
            "ratios": list(config.SPLIT_RATIOS),
        },
    }


def x_run__mutmut_orig(spec: DatasetSpec, seeds=config.BENCHMARK_SEEDS) -> dict[str, Any]:
    frame = load(spec)
    train, val, test = chronological_partitions(frame)
    scored = score_partition(spec, train, test)
    chrono = {}
    for name, score in scored["scores"].items():
        metrics = compute_metrics(scored["y"], scored["flags"][name], score)
        ci = block_bootstrap_ci(
            scored["y"], score, test[TIME_UTC], BLOCK_SECONDS, RESAMPLES, BOOTSTRAP_SEED
        )
        chrono[name] = {**metrics, "pr_auc_ci": ci}
    control: dict[str, dict[str, list[float]]] = {}
    for seed in seeds:
        s_train, _s_val, s_test = stratified_partitions(frame, seed)
        s_scored = score_partition(spec, s_train, s_test)
        for name, score in s_scored["scores"].items():
            m = compute_metrics(s_scored["y"], s_scored["flags"][name], score)
            for key, value in m.items():
                control.setdefault(name, {}).setdefault(key, []).append(float(value))
    stratified = {
        name: {k: {"mean": float(np.mean(v)), "std": float(np.std(v, ddof=1)), "values": v}
               for k, v in metrics.items()}
        for name, metrics in control.items()
    }  # fmt: skip
    return {
        "partitions": {
            "train": describe(train),
            "validation": describe(val),
            "test": describe(test),
        },
        "chronological": chrono,
        "stratified": stratified,
        "drift_control": monitor_control(train, val, test, DRIFT_COLUMNS),
        "settings": {
            "seeds": list(seeds),
            "block_seconds": BLOCK_SECONDS,
            "resamples": RESAMPLES,
            "bootstrap_seed": BOOTSTRAP_SEED,
            "window_size": WINDOW_SIZE,
            "deltas": list(DELTAS),
            "ratios": list(config.SPLIT_RATIOS),
        },
    }


def x_run__mutmut_1(spec: DatasetSpec, seeds=config.BENCHMARK_SEEDS) -> dict[str, Any]:
    frame = None
    train, val, test = chronological_partitions(frame)
    scored = score_partition(spec, train, test)
    chrono = {}
    for name, score in scored["scores"].items():
        metrics = compute_metrics(scored["y"], scored["flags"][name], score)
        ci = block_bootstrap_ci(
            scored["y"], score, test[TIME_UTC], BLOCK_SECONDS, RESAMPLES, BOOTSTRAP_SEED
        )
        chrono[name] = {**metrics, "pr_auc_ci": ci}
    control: dict[str, dict[str, list[float]]] = {}
    for seed in seeds:
        s_train, _s_val, s_test = stratified_partitions(frame, seed)
        s_scored = score_partition(spec, s_train, s_test)
        for name, score in s_scored["scores"].items():
            m = compute_metrics(s_scored["y"], s_scored["flags"][name], score)
            for key, value in m.items():
                control.setdefault(name, {}).setdefault(key, []).append(float(value))
    stratified = {
        name: {k: {"mean": float(np.mean(v)), "std": float(np.std(v, ddof=1)), "values": v}
               for k, v in metrics.items()}
        for name, metrics in control.items()
    }  # fmt: skip
    return {
        "partitions": {
            "train": describe(train),
            "validation": describe(val),
            "test": describe(test),
        },
        "chronological": chrono,
        "stratified": stratified,
        "drift_control": monitor_control(train, val, test, DRIFT_COLUMNS),
        "settings": {
            "seeds": list(seeds),
            "block_seconds": BLOCK_SECONDS,
            "resamples": RESAMPLES,
            "bootstrap_seed": BOOTSTRAP_SEED,
            "window_size": WINDOW_SIZE,
            "deltas": list(DELTAS),
            "ratios": list(config.SPLIT_RATIOS),
        },
    }


def x_run__mutmut_2(spec: DatasetSpec, seeds=config.BENCHMARK_SEEDS) -> dict[str, Any]:
    frame = load(None)
    train, val, test = chronological_partitions(frame)
    scored = score_partition(spec, train, test)
    chrono = {}
    for name, score in scored["scores"].items():
        metrics = compute_metrics(scored["y"], scored["flags"][name], score)
        ci = block_bootstrap_ci(
            scored["y"], score, test[TIME_UTC], BLOCK_SECONDS, RESAMPLES, BOOTSTRAP_SEED
        )
        chrono[name] = {**metrics, "pr_auc_ci": ci}
    control: dict[str, dict[str, list[float]]] = {}
    for seed in seeds:
        s_train, _s_val, s_test = stratified_partitions(frame, seed)
        s_scored = score_partition(spec, s_train, s_test)
        for name, score in s_scored["scores"].items():
            m = compute_metrics(s_scored["y"], s_scored["flags"][name], score)
            for key, value in m.items():
                control.setdefault(name, {}).setdefault(key, []).append(float(value))
    stratified = {
        name: {k: {"mean": float(np.mean(v)), "std": float(np.std(v, ddof=1)), "values": v}
               for k, v in metrics.items()}
        for name, metrics in control.items()
    }  # fmt: skip
    return {
        "partitions": {
            "train": describe(train),
            "validation": describe(val),
            "test": describe(test),
        },
        "chronological": chrono,
        "stratified": stratified,
        "drift_control": monitor_control(train, val, test, DRIFT_COLUMNS),
        "settings": {
            "seeds": list(seeds),
            "block_seconds": BLOCK_SECONDS,
            "resamples": RESAMPLES,
            "bootstrap_seed": BOOTSTRAP_SEED,
            "window_size": WINDOW_SIZE,
            "deltas": list(DELTAS),
            "ratios": list(config.SPLIT_RATIOS),
        },
    }


def x_run__mutmut_3(spec: DatasetSpec, seeds=config.BENCHMARK_SEEDS) -> dict[str, Any]:
    frame = load(spec)
    train, val, test = None
    scored = score_partition(spec, train, test)
    chrono = {}
    for name, score in scored["scores"].items():
        metrics = compute_metrics(scored["y"], scored["flags"][name], score)
        ci = block_bootstrap_ci(
            scored["y"], score, test[TIME_UTC], BLOCK_SECONDS, RESAMPLES, BOOTSTRAP_SEED
        )
        chrono[name] = {**metrics, "pr_auc_ci": ci}
    control: dict[str, dict[str, list[float]]] = {}
    for seed in seeds:
        s_train, _s_val, s_test = stratified_partitions(frame, seed)
        s_scored = score_partition(spec, s_train, s_test)
        for name, score in s_scored["scores"].items():
            m = compute_metrics(s_scored["y"], s_scored["flags"][name], score)
            for key, value in m.items():
                control.setdefault(name, {}).setdefault(key, []).append(float(value))
    stratified = {
        name: {k: {"mean": float(np.mean(v)), "std": float(np.std(v, ddof=1)), "values": v}
               for k, v in metrics.items()}
        for name, metrics in control.items()
    }  # fmt: skip
    return {
        "partitions": {
            "train": describe(train),
            "validation": describe(val),
            "test": describe(test),
        },
        "chronological": chrono,
        "stratified": stratified,
        "drift_control": monitor_control(train, val, test, DRIFT_COLUMNS),
        "settings": {
            "seeds": list(seeds),
            "block_seconds": BLOCK_SECONDS,
            "resamples": RESAMPLES,
            "bootstrap_seed": BOOTSTRAP_SEED,
            "window_size": WINDOW_SIZE,
            "deltas": list(DELTAS),
            "ratios": list(config.SPLIT_RATIOS),
        },
    }


def x_run__mutmut_4(spec: DatasetSpec, seeds=config.BENCHMARK_SEEDS) -> dict[str, Any]:
    frame = load(spec)
    train, val, test = chronological_partitions(None)
    scored = score_partition(spec, train, test)
    chrono = {}
    for name, score in scored["scores"].items():
        metrics = compute_metrics(scored["y"], scored["flags"][name], score)
        ci = block_bootstrap_ci(
            scored["y"], score, test[TIME_UTC], BLOCK_SECONDS, RESAMPLES, BOOTSTRAP_SEED
        )
        chrono[name] = {**metrics, "pr_auc_ci": ci}
    control: dict[str, dict[str, list[float]]] = {}
    for seed in seeds:
        s_train, _s_val, s_test = stratified_partitions(frame, seed)
        s_scored = score_partition(spec, s_train, s_test)
        for name, score in s_scored["scores"].items():
            m = compute_metrics(s_scored["y"], s_scored["flags"][name], score)
            for key, value in m.items():
                control.setdefault(name, {}).setdefault(key, []).append(float(value))
    stratified = {
        name: {k: {"mean": float(np.mean(v)), "std": float(np.std(v, ddof=1)), "values": v}
               for k, v in metrics.items()}
        for name, metrics in control.items()
    }  # fmt: skip
    return {
        "partitions": {
            "train": describe(train),
            "validation": describe(val),
            "test": describe(test),
        },
        "chronological": chrono,
        "stratified": stratified,
        "drift_control": monitor_control(train, val, test, DRIFT_COLUMNS),
        "settings": {
            "seeds": list(seeds),
            "block_seconds": BLOCK_SECONDS,
            "resamples": RESAMPLES,
            "bootstrap_seed": BOOTSTRAP_SEED,
            "window_size": WINDOW_SIZE,
            "deltas": list(DELTAS),
            "ratios": list(config.SPLIT_RATIOS),
        },
    }


def x_run__mutmut_5(spec: DatasetSpec, seeds=config.BENCHMARK_SEEDS) -> dict[str, Any]:
    frame = load(spec)
    train, val, test = chronological_partitions(frame)
    scored = None
    chrono = {}
    for name, score in scored["scores"].items():
        metrics = compute_metrics(scored["y"], scored["flags"][name], score)
        ci = block_bootstrap_ci(
            scored["y"], score, test[TIME_UTC], BLOCK_SECONDS, RESAMPLES, BOOTSTRAP_SEED
        )
        chrono[name] = {**metrics, "pr_auc_ci": ci}
    control: dict[str, dict[str, list[float]]] = {}
    for seed in seeds:
        s_train, _s_val, s_test = stratified_partitions(frame, seed)
        s_scored = score_partition(spec, s_train, s_test)
        for name, score in s_scored["scores"].items():
            m = compute_metrics(s_scored["y"], s_scored["flags"][name], score)
            for key, value in m.items():
                control.setdefault(name, {}).setdefault(key, []).append(float(value))
    stratified = {
        name: {k: {"mean": float(np.mean(v)), "std": float(np.std(v, ddof=1)), "values": v}
               for k, v in metrics.items()}
        for name, metrics in control.items()
    }  # fmt: skip
    return {
        "partitions": {
            "train": describe(train),
            "validation": describe(val),
            "test": describe(test),
        },
        "chronological": chrono,
        "stratified": stratified,
        "drift_control": monitor_control(train, val, test, DRIFT_COLUMNS),
        "settings": {
            "seeds": list(seeds),
            "block_seconds": BLOCK_SECONDS,
            "resamples": RESAMPLES,
            "bootstrap_seed": BOOTSTRAP_SEED,
            "window_size": WINDOW_SIZE,
            "deltas": list(DELTAS),
            "ratios": list(config.SPLIT_RATIOS),
        },
    }


def x_run__mutmut_6(spec: DatasetSpec, seeds=config.BENCHMARK_SEEDS) -> dict[str, Any]:
    frame = load(spec)
    train, val, test = chronological_partitions(frame)
    scored = score_partition(None, train, test)
    chrono = {}
    for name, score in scored["scores"].items():
        metrics = compute_metrics(scored["y"], scored["flags"][name], score)
        ci = block_bootstrap_ci(
            scored["y"], score, test[TIME_UTC], BLOCK_SECONDS, RESAMPLES, BOOTSTRAP_SEED
        )
        chrono[name] = {**metrics, "pr_auc_ci": ci}
    control: dict[str, dict[str, list[float]]] = {}
    for seed in seeds:
        s_train, _s_val, s_test = stratified_partitions(frame, seed)
        s_scored = score_partition(spec, s_train, s_test)
        for name, score in s_scored["scores"].items():
            m = compute_metrics(s_scored["y"], s_scored["flags"][name], score)
            for key, value in m.items():
                control.setdefault(name, {}).setdefault(key, []).append(float(value))
    stratified = {
        name: {k: {"mean": float(np.mean(v)), "std": float(np.std(v, ddof=1)), "values": v}
               for k, v in metrics.items()}
        for name, metrics in control.items()
    }  # fmt: skip
    return {
        "partitions": {
            "train": describe(train),
            "validation": describe(val),
            "test": describe(test),
        },
        "chronological": chrono,
        "stratified": stratified,
        "drift_control": monitor_control(train, val, test, DRIFT_COLUMNS),
        "settings": {
            "seeds": list(seeds),
            "block_seconds": BLOCK_SECONDS,
            "resamples": RESAMPLES,
            "bootstrap_seed": BOOTSTRAP_SEED,
            "window_size": WINDOW_SIZE,
            "deltas": list(DELTAS),
            "ratios": list(config.SPLIT_RATIOS),
        },
    }


def x_run__mutmut_7(spec: DatasetSpec, seeds=config.BENCHMARK_SEEDS) -> dict[str, Any]:
    frame = load(spec)
    train, val, test = chronological_partitions(frame)
    scored = score_partition(spec, None, test)
    chrono = {}
    for name, score in scored["scores"].items():
        metrics = compute_metrics(scored["y"], scored["flags"][name], score)
        ci = block_bootstrap_ci(
            scored["y"], score, test[TIME_UTC], BLOCK_SECONDS, RESAMPLES, BOOTSTRAP_SEED
        )
        chrono[name] = {**metrics, "pr_auc_ci": ci}
    control: dict[str, dict[str, list[float]]] = {}
    for seed in seeds:
        s_train, _s_val, s_test = stratified_partitions(frame, seed)
        s_scored = score_partition(spec, s_train, s_test)
        for name, score in s_scored["scores"].items():
            m = compute_metrics(s_scored["y"], s_scored["flags"][name], score)
            for key, value in m.items():
                control.setdefault(name, {}).setdefault(key, []).append(float(value))
    stratified = {
        name: {k: {"mean": float(np.mean(v)), "std": float(np.std(v, ddof=1)), "values": v}
               for k, v in metrics.items()}
        for name, metrics in control.items()
    }  # fmt: skip
    return {
        "partitions": {
            "train": describe(train),
            "validation": describe(val),
            "test": describe(test),
        },
        "chronological": chrono,
        "stratified": stratified,
        "drift_control": monitor_control(train, val, test, DRIFT_COLUMNS),
        "settings": {
            "seeds": list(seeds),
            "block_seconds": BLOCK_SECONDS,
            "resamples": RESAMPLES,
            "bootstrap_seed": BOOTSTRAP_SEED,
            "window_size": WINDOW_SIZE,
            "deltas": list(DELTAS),
            "ratios": list(config.SPLIT_RATIOS),
        },
    }


def x_run__mutmut_8(spec: DatasetSpec, seeds=config.BENCHMARK_SEEDS) -> dict[str, Any]:
    frame = load(spec)
    train, val, test = chronological_partitions(frame)
    scored = score_partition(spec, train, None)
    chrono = {}
    for name, score in scored["scores"].items():
        metrics = compute_metrics(scored["y"], scored["flags"][name], score)
        ci = block_bootstrap_ci(
            scored["y"], score, test[TIME_UTC], BLOCK_SECONDS, RESAMPLES, BOOTSTRAP_SEED
        )
        chrono[name] = {**metrics, "pr_auc_ci": ci}
    control: dict[str, dict[str, list[float]]] = {}
    for seed in seeds:
        s_train, _s_val, s_test = stratified_partitions(frame, seed)
        s_scored = score_partition(spec, s_train, s_test)
        for name, score in s_scored["scores"].items():
            m = compute_metrics(s_scored["y"], s_scored["flags"][name], score)
            for key, value in m.items():
                control.setdefault(name, {}).setdefault(key, []).append(float(value))
    stratified = {
        name: {k: {"mean": float(np.mean(v)), "std": float(np.std(v, ddof=1)), "values": v}
               for k, v in metrics.items()}
        for name, metrics in control.items()
    }  # fmt: skip
    return {
        "partitions": {
            "train": describe(train),
            "validation": describe(val),
            "test": describe(test),
        },
        "chronological": chrono,
        "stratified": stratified,
        "drift_control": monitor_control(train, val, test, DRIFT_COLUMNS),
        "settings": {
            "seeds": list(seeds),
            "block_seconds": BLOCK_SECONDS,
            "resamples": RESAMPLES,
            "bootstrap_seed": BOOTSTRAP_SEED,
            "window_size": WINDOW_SIZE,
            "deltas": list(DELTAS),
            "ratios": list(config.SPLIT_RATIOS),
        },
    }


def x_run__mutmut_9(spec: DatasetSpec, seeds=config.BENCHMARK_SEEDS) -> dict[str, Any]:
    frame = load(spec)
    train, val, test = chronological_partitions(frame)
    scored = score_partition(train, test)
    chrono = {}
    for name, score in scored["scores"].items():
        metrics = compute_metrics(scored["y"], scored["flags"][name], score)
        ci = block_bootstrap_ci(
            scored["y"], score, test[TIME_UTC], BLOCK_SECONDS, RESAMPLES, BOOTSTRAP_SEED
        )
        chrono[name] = {**metrics, "pr_auc_ci": ci}
    control: dict[str, dict[str, list[float]]] = {}
    for seed in seeds:
        s_train, _s_val, s_test = stratified_partitions(frame, seed)
        s_scored = score_partition(spec, s_train, s_test)
        for name, score in s_scored["scores"].items():
            m = compute_metrics(s_scored["y"], s_scored["flags"][name], score)
            for key, value in m.items():
                control.setdefault(name, {}).setdefault(key, []).append(float(value))
    stratified = {
        name: {k: {"mean": float(np.mean(v)), "std": float(np.std(v, ddof=1)), "values": v}
               for k, v in metrics.items()}
        for name, metrics in control.items()
    }  # fmt: skip
    return {
        "partitions": {
            "train": describe(train),
            "validation": describe(val),
            "test": describe(test),
        },
        "chronological": chrono,
        "stratified": stratified,
        "drift_control": monitor_control(train, val, test, DRIFT_COLUMNS),
        "settings": {
            "seeds": list(seeds),
            "block_seconds": BLOCK_SECONDS,
            "resamples": RESAMPLES,
            "bootstrap_seed": BOOTSTRAP_SEED,
            "window_size": WINDOW_SIZE,
            "deltas": list(DELTAS),
            "ratios": list(config.SPLIT_RATIOS),
        },
    }


def x_run__mutmut_10(spec: DatasetSpec, seeds=config.BENCHMARK_SEEDS) -> dict[str, Any]:
    frame = load(spec)
    train, val, test = chronological_partitions(frame)
    scored = score_partition(spec, test)
    chrono = {}
    for name, score in scored["scores"].items():
        metrics = compute_metrics(scored["y"], scored["flags"][name], score)
        ci = block_bootstrap_ci(
            scored["y"], score, test[TIME_UTC], BLOCK_SECONDS, RESAMPLES, BOOTSTRAP_SEED
        )
        chrono[name] = {**metrics, "pr_auc_ci": ci}
    control: dict[str, dict[str, list[float]]] = {}
    for seed in seeds:
        s_train, _s_val, s_test = stratified_partitions(frame, seed)
        s_scored = score_partition(spec, s_train, s_test)
        for name, score in s_scored["scores"].items():
            m = compute_metrics(s_scored["y"], s_scored["flags"][name], score)
            for key, value in m.items():
                control.setdefault(name, {}).setdefault(key, []).append(float(value))
    stratified = {
        name: {k: {"mean": float(np.mean(v)), "std": float(np.std(v, ddof=1)), "values": v}
               for k, v in metrics.items()}
        for name, metrics in control.items()
    }  # fmt: skip
    return {
        "partitions": {
            "train": describe(train),
            "validation": describe(val),
            "test": describe(test),
        },
        "chronological": chrono,
        "stratified": stratified,
        "drift_control": monitor_control(train, val, test, DRIFT_COLUMNS),
        "settings": {
            "seeds": list(seeds),
            "block_seconds": BLOCK_SECONDS,
            "resamples": RESAMPLES,
            "bootstrap_seed": BOOTSTRAP_SEED,
            "window_size": WINDOW_SIZE,
            "deltas": list(DELTAS),
            "ratios": list(config.SPLIT_RATIOS),
        },
    }


def x_run__mutmut_11(spec: DatasetSpec, seeds=config.BENCHMARK_SEEDS) -> dict[str, Any]:
    frame = load(spec)
    train, val, test = chronological_partitions(frame)
    scored = score_partition(spec, train, )
    chrono = {}
    for name, score in scored["scores"].items():
        metrics = compute_metrics(scored["y"], scored["flags"][name], score)
        ci = block_bootstrap_ci(
            scored["y"], score, test[TIME_UTC], BLOCK_SECONDS, RESAMPLES, BOOTSTRAP_SEED
        )
        chrono[name] = {**metrics, "pr_auc_ci": ci}
    control: dict[str, dict[str, list[float]]] = {}
    for seed in seeds:
        s_train, _s_val, s_test = stratified_partitions(frame, seed)
        s_scored = score_partition(spec, s_train, s_test)
        for name, score in s_scored["scores"].items():
            m = compute_metrics(s_scored["y"], s_scored["flags"][name], score)
            for key, value in m.items():
                control.setdefault(name, {}).setdefault(key, []).append(float(value))
    stratified = {
        name: {k: {"mean": float(np.mean(v)), "std": float(np.std(v, ddof=1)), "values": v}
               for k, v in metrics.items()}
        for name, metrics in control.items()
    }  # fmt: skip
    return {
        "partitions": {
            "train": describe(train),
            "validation": describe(val),
            "test": describe(test),
        },
        "chronological": chrono,
        "stratified": stratified,
        "drift_control": monitor_control(train, val, test, DRIFT_COLUMNS),
        "settings": {
            "seeds": list(seeds),
            "block_seconds": BLOCK_SECONDS,
            "resamples": RESAMPLES,
            "bootstrap_seed": BOOTSTRAP_SEED,
            "window_size": WINDOW_SIZE,
            "deltas": list(DELTAS),
            "ratios": list(config.SPLIT_RATIOS),
        },
    }


def x_run__mutmut_12(spec: DatasetSpec, seeds=config.BENCHMARK_SEEDS) -> dict[str, Any]:
    frame = load(spec)
    train, val, test = chronological_partitions(frame)
    scored = score_partition(spec, train, test)
    chrono = None
    for name, score in scored["scores"].items():
        metrics = compute_metrics(scored["y"], scored["flags"][name], score)
        ci = block_bootstrap_ci(
            scored["y"], score, test[TIME_UTC], BLOCK_SECONDS, RESAMPLES, BOOTSTRAP_SEED
        )
        chrono[name] = {**metrics, "pr_auc_ci": ci}
    control: dict[str, dict[str, list[float]]] = {}
    for seed in seeds:
        s_train, _s_val, s_test = stratified_partitions(frame, seed)
        s_scored = score_partition(spec, s_train, s_test)
        for name, score in s_scored["scores"].items():
            m = compute_metrics(s_scored["y"], s_scored["flags"][name], score)
            for key, value in m.items():
                control.setdefault(name, {}).setdefault(key, []).append(float(value))
    stratified = {
        name: {k: {"mean": float(np.mean(v)), "std": float(np.std(v, ddof=1)), "values": v}
               for k, v in metrics.items()}
        for name, metrics in control.items()
    }  # fmt: skip
    return {
        "partitions": {
            "train": describe(train),
            "validation": describe(val),
            "test": describe(test),
        },
        "chronological": chrono,
        "stratified": stratified,
        "drift_control": monitor_control(train, val, test, DRIFT_COLUMNS),
        "settings": {
            "seeds": list(seeds),
            "block_seconds": BLOCK_SECONDS,
            "resamples": RESAMPLES,
            "bootstrap_seed": BOOTSTRAP_SEED,
            "window_size": WINDOW_SIZE,
            "deltas": list(DELTAS),
            "ratios": list(config.SPLIT_RATIOS),
        },
    }


def x_run__mutmut_13(spec: DatasetSpec, seeds=config.BENCHMARK_SEEDS) -> dict[str, Any]:
    frame = load(spec)
    train, val, test = chronological_partitions(frame)
    scored = score_partition(spec, train, test)
    chrono = {}
    for name, score in scored["XXscoresXX"].items():
        metrics = compute_metrics(scored["y"], scored["flags"][name], score)
        ci = block_bootstrap_ci(
            scored["y"], score, test[TIME_UTC], BLOCK_SECONDS, RESAMPLES, BOOTSTRAP_SEED
        )
        chrono[name] = {**metrics, "pr_auc_ci": ci}
    control: dict[str, dict[str, list[float]]] = {}
    for seed in seeds:
        s_train, _s_val, s_test = stratified_partitions(frame, seed)
        s_scored = score_partition(spec, s_train, s_test)
        for name, score in s_scored["scores"].items():
            m = compute_metrics(s_scored["y"], s_scored["flags"][name], score)
            for key, value in m.items():
                control.setdefault(name, {}).setdefault(key, []).append(float(value))
    stratified = {
        name: {k: {"mean": float(np.mean(v)), "std": float(np.std(v, ddof=1)), "values": v}
               for k, v in metrics.items()}
        for name, metrics in control.items()
    }  # fmt: skip
    return {
        "partitions": {
            "train": describe(train),
            "validation": describe(val),
            "test": describe(test),
        },
        "chronological": chrono,
        "stratified": stratified,
        "drift_control": monitor_control(train, val, test, DRIFT_COLUMNS),
        "settings": {
            "seeds": list(seeds),
            "block_seconds": BLOCK_SECONDS,
            "resamples": RESAMPLES,
            "bootstrap_seed": BOOTSTRAP_SEED,
            "window_size": WINDOW_SIZE,
            "deltas": list(DELTAS),
            "ratios": list(config.SPLIT_RATIOS),
        },
    }


def x_run__mutmut_14(spec: DatasetSpec, seeds=config.BENCHMARK_SEEDS) -> dict[str, Any]:
    frame = load(spec)
    train, val, test = chronological_partitions(frame)
    scored = score_partition(spec, train, test)
    chrono = {}
    for name, score in scored["SCORES"].items():
        metrics = compute_metrics(scored["y"], scored["flags"][name], score)
        ci = block_bootstrap_ci(
            scored["y"], score, test[TIME_UTC], BLOCK_SECONDS, RESAMPLES, BOOTSTRAP_SEED
        )
        chrono[name] = {**metrics, "pr_auc_ci": ci}
    control: dict[str, dict[str, list[float]]] = {}
    for seed in seeds:
        s_train, _s_val, s_test = stratified_partitions(frame, seed)
        s_scored = score_partition(spec, s_train, s_test)
        for name, score in s_scored["scores"].items():
            m = compute_metrics(s_scored["y"], s_scored["flags"][name], score)
            for key, value in m.items():
                control.setdefault(name, {}).setdefault(key, []).append(float(value))
    stratified = {
        name: {k: {"mean": float(np.mean(v)), "std": float(np.std(v, ddof=1)), "values": v}
               for k, v in metrics.items()}
        for name, metrics in control.items()
    }  # fmt: skip
    return {
        "partitions": {
            "train": describe(train),
            "validation": describe(val),
            "test": describe(test),
        },
        "chronological": chrono,
        "stratified": stratified,
        "drift_control": monitor_control(train, val, test, DRIFT_COLUMNS),
        "settings": {
            "seeds": list(seeds),
            "block_seconds": BLOCK_SECONDS,
            "resamples": RESAMPLES,
            "bootstrap_seed": BOOTSTRAP_SEED,
            "window_size": WINDOW_SIZE,
            "deltas": list(DELTAS),
            "ratios": list(config.SPLIT_RATIOS),
        },
    }


def x_run__mutmut_15(spec: DatasetSpec, seeds=config.BENCHMARK_SEEDS) -> dict[str, Any]:
    frame = load(spec)
    train, val, test = chronological_partitions(frame)
    scored = score_partition(spec, train, test)
    chrono = {}
    for name, score in scored["scores"].items():
        metrics = None
        ci = block_bootstrap_ci(
            scored["y"], score, test[TIME_UTC], BLOCK_SECONDS, RESAMPLES, BOOTSTRAP_SEED
        )
        chrono[name] = {**metrics, "pr_auc_ci": ci}
    control: dict[str, dict[str, list[float]]] = {}
    for seed in seeds:
        s_train, _s_val, s_test = stratified_partitions(frame, seed)
        s_scored = score_partition(spec, s_train, s_test)
        for name, score in s_scored["scores"].items():
            m = compute_metrics(s_scored["y"], s_scored["flags"][name], score)
            for key, value in m.items():
                control.setdefault(name, {}).setdefault(key, []).append(float(value))
    stratified = {
        name: {k: {"mean": float(np.mean(v)), "std": float(np.std(v, ddof=1)), "values": v}
               for k, v in metrics.items()}
        for name, metrics in control.items()
    }  # fmt: skip
    return {
        "partitions": {
            "train": describe(train),
            "validation": describe(val),
            "test": describe(test),
        },
        "chronological": chrono,
        "stratified": stratified,
        "drift_control": monitor_control(train, val, test, DRIFT_COLUMNS),
        "settings": {
            "seeds": list(seeds),
            "block_seconds": BLOCK_SECONDS,
            "resamples": RESAMPLES,
            "bootstrap_seed": BOOTSTRAP_SEED,
            "window_size": WINDOW_SIZE,
            "deltas": list(DELTAS),
            "ratios": list(config.SPLIT_RATIOS),
        },
    }


def x_run__mutmut_16(spec: DatasetSpec, seeds=config.BENCHMARK_SEEDS) -> dict[str, Any]:
    frame = load(spec)
    train, val, test = chronological_partitions(frame)
    scored = score_partition(spec, train, test)
    chrono = {}
    for name, score in scored["scores"].items():
        metrics = compute_metrics(None, scored["flags"][name], score)
        ci = block_bootstrap_ci(
            scored["y"], score, test[TIME_UTC], BLOCK_SECONDS, RESAMPLES, BOOTSTRAP_SEED
        )
        chrono[name] = {**metrics, "pr_auc_ci": ci}
    control: dict[str, dict[str, list[float]]] = {}
    for seed in seeds:
        s_train, _s_val, s_test = stratified_partitions(frame, seed)
        s_scored = score_partition(spec, s_train, s_test)
        for name, score in s_scored["scores"].items():
            m = compute_metrics(s_scored["y"], s_scored["flags"][name], score)
            for key, value in m.items():
                control.setdefault(name, {}).setdefault(key, []).append(float(value))
    stratified = {
        name: {k: {"mean": float(np.mean(v)), "std": float(np.std(v, ddof=1)), "values": v}
               for k, v in metrics.items()}
        for name, metrics in control.items()
    }  # fmt: skip
    return {
        "partitions": {
            "train": describe(train),
            "validation": describe(val),
            "test": describe(test),
        },
        "chronological": chrono,
        "stratified": stratified,
        "drift_control": monitor_control(train, val, test, DRIFT_COLUMNS),
        "settings": {
            "seeds": list(seeds),
            "block_seconds": BLOCK_SECONDS,
            "resamples": RESAMPLES,
            "bootstrap_seed": BOOTSTRAP_SEED,
            "window_size": WINDOW_SIZE,
            "deltas": list(DELTAS),
            "ratios": list(config.SPLIT_RATIOS),
        },
    }


def x_run__mutmut_17(spec: DatasetSpec, seeds=config.BENCHMARK_SEEDS) -> dict[str, Any]:
    frame = load(spec)
    train, val, test = chronological_partitions(frame)
    scored = score_partition(spec, train, test)
    chrono = {}
    for name, score in scored["scores"].items():
        metrics = compute_metrics(scored["y"], None, score)
        ci = block_bootstrap_ci(
            scored["y"], score, test[TIME_UTC], BLOCK_SECONDS, RESAMPLES, BOOTSTRAP_SEED
        )
        chrono[name] = {**metrics, "pr_auc_ci": ci}
    control: dict[str, dict[str, list[float]]] = {}
    for seed in seeds:
        s_train, _s_val, s_test = stratified_partitions(frame, seed)
        s_scored = score_partition(spec, s_train, s_test)
        for name, score in s_scored["scores"].items():
            m = compute_metrics(s_scored["y"], s_scored["flags"][name], score)
            for key, value in m.items():
                control.setdefault(name, {}).setdefault(key, []).append(float(value))
    stratified = {
        name: {k: {"mean": float(np.mean(v)), "std": float(np.std(v, ddof=1)), "values": v}
               for k, v in metrics.items()}
        for name, metrics in control.items()
    }  # fmt: skip
    return {
        "partitions": {
            "train": describe(train),
            "validation": describe(val),
            "test": describe(test),
        },
        "chronological": chrono,
        "stratified": stratified,
        "drift_control": monitor_control(train, val, test, DRIFT_COLUMNS),
        "settings": {
            "seeds": list(seeds),
            "block_seconds": BLOCK_SECONDS,
            "resamples": RESAMPLES,
            "bootstrap_seed": BOOTSTRAP_SEED,
            "window_size": WINDOW_SIZE,
            "deltas": list(DELTAS),
            "ratios": list(config.SPLIT_RATIOS),
        },
    }


def x_run__mutmut_18(spec: DatasetSpec, seeds=config.BENCHMARK_SEEDS) -> dict[str, Any]:
    frame = load(spec)
    train, val, test = chronological_partitions(frame)
    scored = score_partition(spec, train, test)
    chrono = {}
    for name, score in scored["scores"].items():
        metrics = compute_metrics(scored["y"], scored["flags"][name], None)
        ci = block_bootstrap_ci(
            scored["y"], score, test[TIME_UTC], BLOCK_SECONDS, RESAMPLES, BOOTSTRAP_SEED
        )
        chrono[name] = {**metrics, "pr_auc_ci": ci}
    control: dict[str, dict[str, list[float]]] = {}
    for seed in seeds:
        s_train, _s_val, s_test = stratified_partitions(frame, seed)
        s_scored = score_partition(spec, s_train, s_test)
        for name, score in s_scored["scores"].items():
            m = compute_metrics(s_scored["y"], s_scored["flags"][name], score)
            for key, value in m.items():
                control.setdefault(name, {}).setdefault(key, []).append(float(value))
    stratified = {
        name: {k: {"mean": float(np.mean(v)), "std": float(np.std(v, ddof=1)), "values": v}
               for k, v in metrics.items()}
        for name, metrics in control.items()
    }  # fmt: skip
    return {
        "partitions": {
            "train": describe(train),
            "validation": describe(val),
            "test": describe(test),
        },
        "chronological": chrono,
        "stratified": stratified,
        "drift_control": monitor_control(train, val, test, DRIFT_COLUMNS),
        "settings": {
            "seeds": list(seeds),
            "block_seconds": BLOCK_SECONDS,
            "resamples": RESAMPLES,
            "bootstrap_seed": BOOTSTRAP_SEED,
            "window_size": WINDOW_SIZE,
            "deltas": list(DELTAS),
            "ratios": list(config.SPLIT_RATIOS),
        },
    }


def x_run__mutmut_19(spec: DatasetSpec, seeds=config.BENCHMARK_SEEDS) -> dict[str, Any]:
    frame = load(spec)
    train, val, test = chronological_partitions(frame)
    scored = score_partition(spec, train, test)
    chrono = {}
    for name, score in scored["scores"].items():
        metrics = compute_metrics(scored["flags"][name], score)
        ci = block_bootstrap_ci(
            scored["y"], score, test[TIME_UTC], BLOCK_SECONDS, RESAMPLES, BOOTSTRAP_SEED
        )
        chrono[name] = {**metrics, "pr_auc_ci": ci}
    control: dict[str, dict[str, list[float]]] = {}
    for seed in seeds:
        s_train, _s_val, s_test = stratified_partitions(frame, seed)
        s_scored = score_partition(spec, s_train, s_test)
        for name, score in s_scored["scores"].items():
            m = compute_metrics(s_scored["y"], s_scored["flags"][name], score)
            for key, value in m.items():
                control.setdefault(name, {}).setdefault(key, []).append(float(value))
    stratified = {
        name: {k: {"mean": float(np.mean(v)), "std": float(np.std(v, ddof=1)), "values": v}
               for k, v in metrics.items()}
        for name, metrics in control.items()
    }  # fmt: skip
    return {
        "partitions": {
            "train": describe(train),
            "validation": describe(val),
            "test": describe(test),
        },
        "chronological": chrono,
        "stratified": stratified,
        "drift_control": monitor_control(train, val, test, DRIFT_COLUMNS),
        "settings": {
            "seeds": list(seeds),
            "block_seconds": BLOCK_SECONDS,
            "resamples": RESAMPLES,
            "bootstrap_seed": BOOTSTRAP_SEED,
            "window_size": WINDOW_SIZE,
            "deltas": list(DELTAS),
            "ratios": list(config.SPLIT_RATIOS),
        },
    }


def x_run__mutmut_20(spec: DatasetSpec, seeds=config.BENCHMARK_SEEDS) -> dict[str, Any]:
    frame = load(spec)
    train, val, test = chronological_partitions(frame)
    scored = score_partition(spec, train, test)
    chrono = {}
    for name, score in scored["scores"].items():
        metrics = compute_metrics(scored["y"], score)
        ci = block_bootstrap_ci(
            scored["y"], score, test[TIME_UTC], BLOCK_SECONDS, RESAMPLES, BOOTSTRAP_SEED
        )
        chrono[name] = {**metrics, "pr_auc_ci": ci}
    control: dict[str, dict[str, list[float]]] = {}
    for seed in seeds:
        s_train, _s_val, s_test = stratified_partitions(frame, seed)
        s_scored = score_partition(spec, s_train, s_test)
        for name, score in s_scored["scores"].items():
            m = compute_metrics(s_scored["y"], s_scored["flags"][name], score)
            for key, value in m.items():
                control.setdefault(name, {}).setdefault(key, []).append(float(value))
    stratified = {
        name: {k: {"mean": float(np.mean(v)), "std": float(np.std(v, ddof=1)), "values": v}
               for k, v in metrics.items()}
        for name, metrics in control.items()
    }  # fmt: skip
    return {
        "partitions": {
            "train": describe(train),
            "validation": describe(val),
            "test": describe(test),
        },
        "chronological": chrono,
        "stratified": stratified,
        "drift_control": monitor_control(train, val, test, DRIFT_COLUMNS),
        "settings": {
            "seeds": list(seeds),
            "block_seconds": BLOCK_SECONDS,
            "resamples": RESAMPLES,
            "bootstrap_seed": BOOTSTRAP_SEED,
            "window_size": WINDOW_SIZE,
            "deltas": list(DELTAS),
            "ratios": list(config.SPLIT_RATIOS),
        },
    }


def x_run__mutmut_21(spec: DatasetSpec, seeds=config.BENCHMARK_SEEDS) -> dict[str, Any]:
    frame = load(spec)
    train, val, test = chronological_partitions(frame)
    scored = score_partition(spec, train, test)
    chrono = {}
    for name, score in scored["scores"].items():
        metrics = compute_metrics(scored["y"], scored["flags"][name], )
        ci = block_bootstrap_ci(
            scored["y"], score, test[TIME_UTC], BLOCK_SECONDS, RESAMPLES, BOOTSTRAP_SEED
        )
        chrono[name] = {**metrics, "pr_auc_ci": ci}
    control: dict[str, dict[str, list[float]]] = {}
    for seed in seeds:
        s_train, _s_val, s_test = stratified_partitions(frame, seed)
        s_scored = score_partition(spec, s_train, s_test)
        for name, score in s_scored["scores"].items():
            m = compute_metrics(s_scored["y"], s_scored["flags"][name], score)
            for key, value in m.items():
                control.setdefault(name, {}).setdefault(key, []).append(float(value))
    stratified = {
        name: {k: {"mean": float(np.mean(v)), "std": float(np.std(v, ddof=1)), "values": v}
               for k, v in metrics.items()}
        for name, metrics in control.items()
    }  # fmt: skip
    return {
        "partitions": {
            "train": describe(train),
            "validation": describe(val),
            "test": describe(test),
        },
        "chronological": chrono,
        "stratified": stratified,
        "drift_control": monitor_control(train, val, test, DRIFT_COLUMNS),
        "settings": {
            "seeds": list(seeds),
            "block_seconds": BLOCK_SECONDS,
            "resamples": RESAMPLES,
            "bootstrap_seed": BOOTSTRAP_SEED,
            "window_size": WINDOW_SIZE,
            "deltas": list(DELTAS),
            "ratios": list(config.SPLIT_RATIOS),
        },
    }


def x_run__mutmut_22(spec: DatasetSpec, seeds=config.BENCHMARK_SEEDS) -> dict[str, Any]:
    frame = load(spec)
    train, val, test = chronological_partitions(frame)
    scored = score_partition(spec, train, test)
    chrono = {}
    for name, score in scored["scores"].items():
        metrics = compute_metrics(scored["XXyXX"], scored["flags"][name], score)
        ci = block_bootstrap_ci(
            scored["y"], score, test[TIME_UTC], BLOCK_SECONDS, RESAMPLES, BOOTSTRAP_SEED
        )
        chrono[name] = {**metrics, "pr_auc_ci": ci}
    control: dict[str, dict[str, list[float]]] = {}
    for seed in seeds:
        s_train, _s_val, s_test = stratified_partitions(frame, seed)
        s_scored = score_partition(spec, s_train, s_test)
        for name, score in s_scored["scores"].items():
            m = compute_metrics(s_scored["y"], s_scored["flags"][name], score)
            for key, value in m.items():
                control.setdefault(name, {}).setdefault(key, []).append(float(value))
    stratified = {
        name: {k: {"mean": float(np.mean(v)), "std": float(np.std(v, ddof=1)), "values": v}
               for k, v in metrics.items()}
        for name, metrics in control.items()
    }  # fmt: skip
    return {
        "partitions": {
            "train": describe(train),
            "validation": describe(val),
            "test": describe(test),
        },
        "chronological": chrono,
        "stratified": stratified,
        "drift_control": monitor_control(train, val, test, DRIFT_COLUMNS),
        "settings": {
            "seeds": list(seeds),
            "block_seconds": BLOCK_SECONDS,
            "resamples": RESAMPLES,
            "bootstrap_seed": BOOTSTRAP_SEED,
            "window_size": WINDOW_SIZE,
            "deltas": list(DELTAS),
            "ratios": list(config.SPLIT_RATIOS),
        },
    }


def x_run__mutmut_23(spec: DatasetSpec, seeds=config.BENCHMARK_SEEDS) -> dict[str, Any]:
    frame = load(spec)
    train, val, test = chronological_partitions(frame)
    scored = score_partition(spec, train, test)
    chrono = {}
    for name, score in scored["scores"].items():
        metrics = compute_metrics(scored["Y"], scored["flags"][name], score)
        ci = block_bootstrap_ci(
            scored["y"], score, test[TIME_UTC], BLOCK_SECONDS, RESAMPLES, BOOTSTRAP_SEED
        )
        chrono[name] = {**metrics, "pr_auc_ci": ci}
    control: dict[str, dict[str, list[float]]] = {}
    for seed in seeds:
        s_train, _s_val, s_test = stratified_partitions(frame, seed)
        s_scored = score_partition(spec, s_train, s_test)
        for name, score in s_scored["scores"].items():
            m = compute_metrics(s_scored["y"], s_scored["flags"][name], score)
            for key, value in m.items():
                control.setdefault(name, {}).setdefault(key, []).append(float(value))
    stratified = {
        name: {k: {"mean": float(np.mean(v)), "std": float(np.std(v, ddof=1)), "values": v}
               for k, v in metrics.items()}
        for name, metrics in control.items()
    }  # fmt: skip
    return {
        "partitions": {
            "train": describe(train),
            "validation": describe(val),
            "test": describe(test),
        },
        "chronological": chrono,
        "stratified": stratified,
        "drift_control": monitor_control(train, val, test, DRIFT_COLUMNS),
        "settings": {
            "seeds": list(seeds),
            "block_seconds": BLOCK_SECONDS,
            "resamples": RESAMPLES,
            "bootstrap_seed": BOOTSTRAP_SEED,
            "window_size": WINDOW_SIZE,
            "deltas": list(DELTAS),
            "ratios": list(config.SPLIT_RATIOS),
        },
    }


def x_run__mutmut_24(spec: DatasetSpec, seeds=config.BENCHMARK_SEEDS) -> dict[str, Any]:
    frame = load(spec)
    train, val, test = chronological_partitions(frame)
    scored = score_partition(spec, train, test)
    chrono = {}
    for name, score in scored["scores"].items():
        metrics = compute_metrics(scored["y"], scored["XXflagsXX"][name], score)
        ci = block_bootstrap_ci(
            scored["y"], score, test[TIME_UTC], BLOCK_SECONDS, RESAMPLES, BOOTSTRAP_SEED
        )
        chrono[name] = {**metrics, "pr_auc_ci": ci}
    control: dict[str, dict[str, list[float]]] = {}
    for seed in seeds:
        s_train, _s_val, s_test = stratified_partitions(frame, seed)
        s_scored = score_partition(spec, s_train, s_test)
        for name, score in s_scored["scores"].items():
            m = compute_metrics(s_scored["y"], s_scored["flags"][name], score)
            for key, value in m.items():
                control.setdefault(name, {}).setdefault(key, []).append(float(value))
    stratified = {
        name: {k: {"mean": float(np.mean(v)), "std": float(np.std(v, ddof=1)), "values": v}
               for k, v in metrics.items()}
        for name, metrics in control.items()
    }  # fmt: skip
    return {
        "partitions": {
            "train": describe(train),
            "validation": describe(val),
            "test": describe(test),
        },
        "chronological": chrono,
        "stratified": stratified,
        "drift_control": monitor_control(train, val, test, DRIFT_COLUMNS),
        "settings": {
            "seeds": list(seeds),
            "block_seconds": BLOCK_SECONDS,
            "resamples": RESAMPLES,
            "bootstrap_seed": BOOTSTRAP_SEED,
            "window_size": WINDOW_SIZE,
            "deltas": list(DELTAS),
            "ratios": list(config.SPLIT_RATIOS),
        },
    }


def x_run__mutmut_25(spec: DatasetSpec, seeds=config.BENCHMARK_SEEDS) -> dict[str, Any]:
    frame = load(spec)
    train, val, test = chronological_partitions(frame)
    scored = score_partition(spec, train, test)
    chrono = {}
    for name, score in scored["scores"].items():
        metrics = compute_metrics(scored["y"], scored["FLAGS"][name], score)
        ci = block_bootstrap_ci(
            scored["y"], score, test[TIME_UTC], BLOCK_SECONDS, RESAMPLES, BOOTSTRAP_SEED
        )
        chrono[name] = {**metrics, "pr_auc_ci": ci}
    control: dict[str, dict[str, list[float]]] = {}
    for seed in seeds:
        s_train, _s_val, s_test = stratified_partitions(frame, seed)
        s_scored = score_partition(spec, s_train, s_test)
        for name, score in s_scored["scores"].items():
            m = compute_metrics(s_scored["y"], s_scored["flags"][name], score)
            for key, value in m.items():
                control.setdefault(name, {}).setdefault(key, []).append(float(value))
    stratified = {
        name: {k: {"mean": float(np.mean(v)), "std": float(np.std(v, ddof=1)), "values": v}
               for k, v in metrics.items()}
        for name, metrics in control.items()
    }  # fmt: skip
    return {
        "partitions": {
            "train": describe(train),
            "validation": describe(val),
            "test": describe(test),
        },
        "chronological": chrono,
        "stratified": stratified,
        "drift_control": monitor_control(train, val, test, DRIFT_COLUMNS),
        "settings": {
            "seeds": list(seeds),
            "block_seconds": BLOCK_SECONDS,
            "resamples": RESAMPLES,
            "bootstrap_seed": BOOTSTRAP_SEED,
            "window_size": WINDOW_SIZE,
            "deltas": list(DELTAS),
            "ratios": list(config.SPLIT_RATIOS),
        },
    }


def x_run__mutmut_26(spec: DatasetSpec, seeds=config.BENCHMARK_SEEDS) -> dict[str, Any]:
    frame = load(spec)
    train, val, test = chronological_partitions(frame)
    scored = score_partition(spec, train, test)
    chrono = {}
    for name, score in scored["scores"].items():
        metrics = compute_metrics(scored["y"], scored["flags"][name], score)
        ci = None
        chrono[name] = {**metrics, "pr_auc_ci": ci}
    control: dict[str, dict[str, list[float]]] = {}
    for seed in seeds:
        s_train, _s_val, s_test = stratified_partitions(frame, seed)
        s_scored = score_partition(spec, s_train, s_test)
        for name, score in s_scored["scores"].items():
            m = compute_metrics(s_scored["y"], s_scored["flags"][name], score)
            for key, value in m.items():
                control.setdefault(name, {}).setdefault(key, []).append(float(value))
    stratified = {
        name: {k: {"mean": float(np.mean(v)), "std": float(np.std(v, ddof=1)), "values": v}
               for k, v in metrics.items()}
        for name, metrics in control.items()
    }  # fmt: skip
    return {
        "partitions": {
            "train": describe(train),
            "validation": describe(val),
            "test": describe(test),
        },
        "chronological": chrono,
        "stratified": stratified,
        "drift_control": monitor_control(train, val, test, DRIFT_COLUMNS),
        "settings": {
            "seeds": list(seeds),
            "block_seconds": BLOCK_SECONDS,
            "resamples": RESAMPLES,
            "bootstrap_seed": BOOTSTRAP_SEED,
            "window_size": WINDOW_SIZE,
            "deltas": list(DELTAS),
            "ratios": list(config.SPLIT_RATIOS),
        },
    }


def x_run__mutmut_27(spec: DatasetSpec, seeds=config.BENCHMARK_SEEDS) -> dict[str, Any]:
    frame = load(spec)
    train, val, test = chronological_partitions(frame)
    scored = score_partition(spec, train, test)
    chrono = {}
    for name, score in scored["scores"].items():
        metrics = compute_metrics(scored["y"], scored["flags"][name], score)
        ci = block_bootstrap_ci(
            None, score, test[TIME_UTC], BLOCK_SECONDS, RESAMPLES, BOOTSTRAP_SEED
        )
        chrono[name] = {**metrics, "pr_auc_ci": ci}
    control: dict[str, dict[str, list[float]]] = {}
    for seed in seeds:
        s_train, _s_val, s_test = stratified_partitions(frame, seed)
        s_scored = score_partition(spec, s_train, s_test)
        for name, score in s_scored["scores"].items():
            m = compute_metrics(s_scored["y"], s_scored["flags"][name], score)
            for key, value in m.items():
                control.setdefault(name, {}).setdefault(key, []).append(float(value))
    stratified = {
        name: {k: {"mean": float(np.mean(v)), "std": float(np.std(v, ddof=1)), "values": v}
               for k, v in metrics.items()}
        for name, metrics in control.items()
    }  # fmt: skip
    return {
        "partitions": {
            "train": describe(train),
            "validation": describe(val),
            "test": describe(test),
        },
        "chronological": chrono,
        "stratified": stratified,
        "drift_control": monitor_control(train, val, test, DRIFT_COLUMNS),
        "settings": {
            "seeds": list(seeds),
            "block_seconds": BLOCK_SECONDS,
            "resamples": RESAMPLES,
            "bootstrap_seed": BOOTSTRAP_SEED,
            "window_size": WINDOW_SIZE,
            "deltas": list(DELTAS),
            "ratios": list(config.SPLIT_RATIOS),
        },
    }


def x_run__mutmut_28(spec: DatasetSpec, seeds=config.BENCHMARK_SEEDS) -> dict[str, Any]:
    frame = load(spec)
    train, val, test = chronological_partitions(frame)
    scored = score_partition(spec, train, test)
    chrono = {}
    for name, score in scored["scores"].items():
        metrics = compute_metrics(scored["y"], scored["flags"][name], score)
        ci = block_bootstrap_ci(
            scored["y"], None, test[TIME_UTC], BLOCK_SECONDS, RESAMPLES, BOOTSTRAP_SEED
        )
        chrono[name] = {**metrics, "pr_auc_ci": ci}
    control: dict[str, dict[str, list[float]]] = {}
    for seed in seeds:
        s_train, _s_val, s_test = stratified_partitions(frame, seed)
        s_scored = score_partition(spec, s_train, s_test)
        for name, score in s_scored["scores"].items():
            m = compute_metrics(s_scored["y"], s_scored["flags"][name], score)
            for key, value in m.items():
                control.setdefault(name, {}).setdefault(key, []).append(float(value))
    stratified = {
        name: {k: {"mean": float(np.mean(v)), "std": float(np.std(v, ddof=1)), "values": v}
               for k, v in metrics.items()}
        for name, metrics in control.items()
    }  # fmt: skip
    return {
        "partitions": {
            "train": describe(train),
            "validation": describe(val),
            "test": describe(test),
        },
        "chronological": chrono,
        "stratified": stratified,
        "drift_control": monitor_control(train, val, test, DRIFT_COLUMNS),
        "settings": {
            "seeds": list(seeds),
            "block_seconds": BLOCK_SECONDS,
            "resamples": RESAMPLES,
            "bootstrap_seed": BOOTSTRAP_SEED,
            "window_size": WINDOW_SIZE,
            "deltas": list(DELTAS),
            "ratios": list(config.SPLIT_RATIOS),
        },
    }


def x_run__mutmut_29(spec: DatasetSpec, seeds=config.BENCHMARK_SEEDS) -> dict[str, Any]:
    frame = load(spec)
    train, val, test = chronological_partitions(frame)
    scored = score_partition(spec, train, test)
    chrono = {}
    for name, score in scored["scores"].items():
        metrics = compute_metrics(scored["y"], scored["flags"][name], score)
        ci = block_bootstrap_ci(
            scored["y"], score, None, BLOCK_SECONDS, RESAMPLES, BOOTSTRAP_SEED
        )
        chrono[name] = {**metrics, "pr_auc_ci": ci}
    control: dict[str, dict[str, list[float]]] = {}
    for seed in seeds:
        s_train, _s_val, s_test = stratified_partitions(frame, seed)
        s_scored = score_partition(spec, s_train, s_test)
        for name, score in s_scored["scores"].items():
            m = compute_metrics(s_scored["y"], s_scored["flags"][name], score)
            for key, value in m.items():
                control.setdefault(name, {}).setdefault(key, []).append(float(value))
    stratified = {
        name: {k: {"mean": float(np.mean(v)), "std": float(np.std(v, ddof=1)), "values": v}
               for k, v in metrics.items()}
        for name, metrics in control.items()
    }  # fmt: skip
    return {
        "partitions": {
            "train": describe(train),
            "validation": describe(val),
            "test": describe(test),
        },
        "chronological": chrono,
        "stratified": stratified,
        "drift_control": monitor_control(train, val, test, DRIFT_COLUMNS),
        "settings": {
            "seeds": list(seeds),
            "block_seconds": BLOCK_SECONDS,
            "resamples": RESAMPLES,
            "bootstrap_seed": BOOTSTRAP_SEED,
            "window_size": WINDOW_SIZE,
            "deltas": list(DELTAS),
            "ratios": list(config.SPLIT_RATIOS),
        },
    }


def x_run__mutmut_30(spec: DatasetSpec, seeds=config.BENCHMARK_SEEDS) -> dict[str, Any]:
    frame = load(spec)
    train, val, test = chronological_partitions(frame)
    scored = score_partition(spec, train, test)
    chrono = {}
    for name, score in scored["scores"].items():
        metrics = compute_metrics(scored["y"], scored["flags"][name], score)
        ci = block_bootstrap_ci(
            scored["y"], score, test[TIME_UTC], None, RESAMPLES, BOOTSTRAP_SEED
        )
        chrono[name] = {**metrics, "pr_auc_ci": ci}
    control: dict[str, dict[str, list[float]]] = {}
    for seed in seeds:
        s_train, _s_val, s_test = stratified_partitions(frame, seed)
        s_scored = score_partition(spec, s_train, s_test)
        for name, score in s_scored["scores"].items():
            m = compute_metrics(s_scored["y"], s_scored["flags"][name], score)
            for key, value in m.items():
                control.setdefault(name, {}).setdefault(key, []).append(float(value))
    stratified = {
        name: {k: {"mean": float(np.mean(v)), "std": float(np.std(v, ddof=1)), "values": v}
               for k, v in metrics.items()}
        for name, metrics in control.items()
    }  # fmt: skip
    return {
        "partitions": {
            "train": describe(train),
            "validation": describe(val),
            "test": describe(test),
        },
        "chronological": chrono,
        "stratified": stratified,
        "drift_control": monitor_control(train, val, test, DRIFT_COLUMNS),
        "settings": {
            "seeds": list(seeds),
            "block_seconds": BLOCK_SECONDS,
            "resamples": RESAMPLES,
            "bootstrap_seed": BOOTSTRAP_SEED,
            "window_size": WINDOW_SIZE,
            "deltas": list(DELTAS),
            "ratios": list(config.SPLIT_RATIOS),
        },
    }


def x_run__mutmut_31(spec: DatasetSpec, seeds=config.BENCHMARK_SEEDS) -> dict[str, Any]:
    frame = load(spec)
    train, val, test = chronological_partitions(frame)
    scored = score_partition(spec, train, test)
    chrono = {}
    for name, score in scored["scores"].items():
        metrics = compute_metrics(scored["y"], scored["flags"][name], score)
        ci = block_bootstrap_ci(
            scored["y"], score, test[TIME_UTC], BLOCK_SECONDS, None, BOOTSTRAP_SEED
        )
        chrono[name] = {**metrics, "pr_auc_ci": ci}
    control: dict[str, dict[str, list[float]]] = {}
    for seed in seeds:
        s_train, _s_val, s_test = stratified_partitions(frame, seed)
        s_scored = score_partition(spec, s_train, s_test)
        for name, score in s_scored["scores"].items():
            m = compute_metrics(s_scored["y"], s_scored["flags"][name], score)
            for key, value in m.items():
                control.setdefault(name, {}).setdefault(key, []).append(float(value))
    stratified = {
        name: {k: {"mean": float(np.mean(v)), "std": float(np.std(v, ddof=1)), "values": v}
               for k, v in metrics.items()}
        for name, metrics in control.items()
    }  # fmt: skip
    return {
        "partitions": {
            "train": describe(train),
            "validation": describe(val),
            "test": describe(test),
        },
        "chronological": chrono,
        "stratified": stratified,
        "drift_control": monitor_control(train, val, test, DRIFT_COLUMNS),
        "settings": {
            "seeds": list(seeds),
            "block_seconds": BLOCK_SECONDS,
            "resamples": RESAMPLES,
            "bootstrap_seed": BOOTSTRAP_SEED,
            "window_size": WINDOW_SIZE,
            "deltas": list(DELTAS),
            "ratios": list(config.SPLIT_RATIOS),
        },
    }


def x_run__mutmut_32(spec: DatasetSpec, seeds=config.BENCHMARK_SEEDS) -> dict[str, Any]:
    frame = load(spec)
    train, val, test = chronological_partitions(frame)
    scored = score_partition(spec, train, test)
    chrono = {}
    for name, score in scored["scores"].items():
        metrics = compute_metrics(scored["y"], scored["flags"][name], score)
        ci = block_bootstrap_ci(
            scored["y"], score, test[TIME_UTC], BLOCK_SECONDS, RESAMPLES, None
        )
        chrono[name] = {**metrics, "pr_auc_ci": ci}
    control: dict[str, dict[str, list[float]]] = {}
    for seed in seeds:
        s_train, _s_val, s_test = stratified_partitions(frame, seed)
        s_scored = score_partition(spec, s_train, s_test)
        for name, score in s_scored["scores"].items():
            m = compute_metrics(s_scored["y"], s_scored["flags"][name], score)
            for key, value in m.items():
                control.setdefault(name, {}).setdefault(key, []).append(float(value))
    stratified = {
        name: {k: {"mean": float(np.mean(v)), "std": float(np.std(v, ddof=1)), "values": v}
               for k, v in metrics.items()}
        for name, metrics in control.items()
    }  # fmt: skip
    return {
        "partitions": {
            "train": describe(train),
            "validation": describe(val),
            "test": describe(test),
        },
        "chronological": chrono,
        "stratified": stratified,
        "drift_control": monitor_control(train, val, test, DRIFT_COLUMNS),
        "settings": {
            "seeds": list(seeds),
            "block_seconds": BLOCK_SECONDS,
            "resamples": RESAMPLES,
            "bootstrap_seed": BOOTSTRAP_SEED,
            "window_size": WINDOW_SIZE,
            "deltas": list(DELTAS),
            "ratios": list(config.SPLIT_RATIOS),
        },
    }


def x_run__mutmut_33(spec: DatasetSpec, seeds=config.BENCHMARK_SEEDS) -> dict[str, Any]:
    frame = load(spec)
    train, val, test = chronological_partitions(frame)
    scored = score_partition(spec, train, test)
    chrono = {}
    for name, score in scored["scores"].items():
        metrics = compute_metrics(scored["y"], scored["flags"][name], score)
        ci = block_bootstrap_ci(
            score, test[TIME_UTC], BLOCK_SECONDS, RESAMPLES, BOOTSTRAP_SEED
        )
        chrono[name] = {**metrics, "pr_auc_ci": ci}
    control: dict[str, dict[str, list[float]]] = {}
    for seed in seeds:
        s_train, _s_val, s_test = stratified_partitions(frame, seed)
        s_scored = score_partition(spec, s_train, s_test)
        for name, score in s_scored["scores"].items():
            m = compute_metrics(s_scored["y"], s_scored["flags"][name], score)
            for key, value in m.items():
                control.setdefault(name, {}).setdefault(key, []).append(float(value))
    stratified = {
        name: {k: {"mean": float(np.mean(v)), "std": float(np.std(v, ddof=1)), "values": v}
               for k, v in metrics.items()}
        for name, metrics in control.items()
    }  # fmt: skip
    return {
        "partitions": {
            "train": describe(train),
            "validation": describe(val),
            "test": describe(test),
        },
        "chronological": chrono,
        "stratified": stratified,
        "drift_control": monitor_control(train, val, test, DRIFT_COLUMNS),
        "settings": {
            "seeds": list(seeds),
            "block_seconds": BLOCK_SECONDS,
            "resamples": RESAMPLES,
            "bootstrap_seed": BOOTSTRAP_SEED,
            "window_size": WINDOW_SIZE,
            "deltas": list(DELTAS),
            "ratios": list(config.SPLIT_RATIOS),
        },
    }


def x_run__mutmut_34(spec: DatasetSpec, seeds=config.BENCHMARK_SEEDS) -> dict[str, Any]:
    frame = load(spec)
    train, val, test = chronological_partitions(frame)
    scored = score_partition(spec, train, test)
    chrono = {}
    for name, score in scored["scores"].items():
        metrics = compute_metrics(scored["y"], scored["flags"][name], score)
        ci = block_bootstrap_ci(
            scored["y"], test[TIME_UTC], BLOCK_SECONDS, RESAMPLES, BOOTSTRAP_SEED
        )
        chrono[name] = {**metrics, "pr_auc_ci": ci}
    control: dict[str, dict[str, list[float]]] = {}
    for seed in seeds:
        s_train, _s_val, s_test = stratified_partitions(frame, seed)
        s_scored = score_partition(spec, s_train, s_test)
        for name, score in s_scored["scores"].items():
            m = compute_metrics(s_scored["y"], s_scored["flags"][name], score)
            for key, value in m.items():
                control.setdefault(name, {}).setdefault(key, []).append(float(value))
    stratified = {
        name: {k: {"mean": float(np.mean(v)), "std": float(np.std(v, ddof=1)), "values": v}
               for k, v in metrics.items()}
        for name, metrics in control.items()
    }  # fmt: skip
    return {
        "partitions": {
            "train": describe(train),
            "validation": describe(val),
            "test": describe(test),
        },
        "chronological": chrono,
        "stratified": stratified,
        "drift_control": monitor_control(train, val, test, DRIFT_COLUMNS),
        "settings": {
            "seeds": list(seeds),
            "block_seconds": BLOCK_SECONDS,
            "resamples": RESAMPLES,
            "bootstrap_seed": BOOTSTRAP_SEED,
            "window_size": WINDOW_SIZE,
            "deltas": list(DELTAS),
            "ratios": list(config.SPLIT_RATIOS),
        },
    }


def x_run__mutmut_35(spec: DatasetSpec, seeds=config.BENCHMARK_SEEDS) -> dict[str, Any]:
    frame = load(spec)
    train, val, test = chronological_partitions(frame)
    scored = score_partition(spec, train, test)
    chrono = {}
    for name, score in scored["scores"].items():
        metrics = compute_metrics(scored["y"], scored["flags"][name], score)
        ci = block_bootstrap_ci(
            scored["y"], score, BLOCK_SECONDS, RESAMPLES, BOOTSTRAP_SEED
        )
        chrono[name] = {**metrics, "pr_auc_ci": ci}
    control: dict[str, dict[str, list[float]]] = {}
    for seed in seeds:
        s_train, _s_val, s_test = stratified_partitions(frame, seed)
        s_scored = score_partition(spec, s_train, s_test)
        for name, score in s_scored["scores"].items():
            m = compute_metrics(s_scored["y"], s_scored["flags"][name], score)
            for key, value in m.items():
                control.setdefault(name, {}).setdefault(key, []).append(float(value))
    stratified = {
        name: {k: {"mean": float(np.mean(v)), "std": float(np.std(v, ddof=1)), "values": v}
               for k, v in metrics.items()}
        for name, metrics in control.items()
    }  # fmt: skip
    return {
        "partitions": {
            "train": describe(train),
            "validation": describe(val),
            "test": describe(test),
        },
        "chronological": chrono,
        "stratified": stratified,
        "drift_control": monitor_control(train, val, test, DRIFT_COLUMNS),
        "settings": {
            "seeds": list(seeds),
            "block_seconds": BLOCK_SECONDS,
            "resamples": RESAMPLES,
            "bootstrap_seed": BOOTSTRAP_SEED,
            "window_size": WINDOW_SIZE,
            "deltas": list(DELTAS),
            "ratios": list(config.SPLIT_RATIOS),
        },
    }


def x_run__mutmut_36(spec: DatasetSpec, seeds=config.BENCHMARK_SEEDS) -> dict[str, Any]:
    frame = load(spec)
    train, val, test = chronological_partitions(frame)
    scored = score_partition(spec, train, test)
    chrono = {}
    for name, score in scored["scores"].items():
        metrics = compute_metrics(scored["y"], scored["flags"][name], score)
        ci = block_bootstrap_ci(
            scored["y"], score, test[TIME_UTC], RESAMPLES, BOOTSTRAP_SEED
        )
        chrono[name] = {**metrics, "pr_auc_ci": ci}
    control: dict[str, dict[str, list[float]]] = {}
    for seed in seeds:
        s_train, _s_val, s_test = stratified_partitions(frame, seed)
        s_scored = score_partition(spec, s_train, s_test)
        for name, score in s_scored["scores"].items():
            m = compute_metrics(s_scored["y"], s_scored["flags"][name], score)
            for key, value in m.items():
                control.setdefault(name, {}).setdefault(key, []).append(float(value))
    stratified = {
        name: {k: {"mean": float(np.mean(v)), "std": float(np.std(v, ddof=1)), "values": v}
               for k, v in metrics.items()}
        for name, metrics in control.items()
    }  # fmt: skip
    return {
        "partitions": {
            "train": describe(train),
            "validation": describe(val),
            "test": describe(test),
        },
        "chronological": chrono,
        "stratified": stratified,
        "drift_control": monitor_control(train, val, test, DRIFT_COLUMNS),
        "settings": {
            "seeds": list(seeds),
            "block_seconds": BLOCK_SECONDS,
            "resamples": RESAMPLES,
            "bootstrap_seed": BOOTSTRAP_SEED,
            "window_size": WINDOW_SIZE,
            "deltas": list(DELTAS),
            "ratios": list(config.SPLIT_RATIOS),
        },
    }


def x_run__mutmut_37(spec: DatasetSpec, seeds=config.BENCHMARK_SEEDS) -> dict[str, Any]:
    frame = load(spec)
    train, val, test = chronological_partitions(frame)
    scored = score_partition(spec, train, test)
    chrono = {}
    for name, score in scored["scores"].items():
        metrics = compute_metrics(scored["y"], scored["flags"][name], score)
        ci = block_bootstrap_ci(
            scored["y"], score, test[TIME_UTC], BLOCK_SECONDS, BOOTSTRAP_SEED
        )
        chrono[name] = {**metrics, "pr_auc_ci": ci}
    control: dict[str, dict[str, list[float]]] = {}
    for seed in seeds:
        s_train, _s_val, s_test = stratified_partitions(frame, seed)
        s_scored = score_partition(spec, s_train, s_test)
        for name, score in s_scored["scores"].items():
            m = compute_metrics(s_scored["y"], s_scored["flags"][name], score)
            for key, value in m.items():
                control.setdefault(name, {}).setdefault(key, []).append(float(value))
    stratified = {
        name: {k: {"mean": float(np.mean(v)), "std": float(np.std(v, ddof=1)), "values": v}
               for k, v in metrics.items()}
        for name, metrics in control.items()
    }  # fmt: skip
    return {
        "partitions": {
            "train": describe(train),
            "validation": describe(val),
            "test": describe(test),
        },
        "chronological": chrono,
        "stratified": stratified,
        "drift_control": monitor_control(train, val, test, DRIFT_COLUMNS),
        "settings": {
            "seeds": list(seeds),
            "block_seconds": BLOCK_SECONDS,
            "resamples": RESAMPLES,
            "bootstrap_seed": BOOTSTRAP_SEED,
            "window_size": WINDOW_SIZE,
            "deltas": list(DELTAS),
            "ratios": list(config.SPLIT_RATIOS),
        },
    }


def x_run__mutmut_38(spec: DatasetSpec, seeds=config.BENCHMARK_SEEDS) -> dict[str, Any]:
    frame = load(spec)
    train, val, test = chronological_partitions(frame)
    scored = score_partition(spec, train, test)
    chrono = {}
    for name, score in scored["scores"].items():
        metrics = compute_metrics(scored["y"], scored["flags"][name], score)
        ci = block_bootstrap_ci(
            scored["y"], score, test[TIME_UTC], BLOCK_SECONDS, RESAMPLES, )
        chrono[name] = {**metrics, "pr_auc_ci": ci}
    control: dict[str, dict[str, list[float]]] = {}
    for seed in seeds:
        s_train, _s_val, s_test = stratified_partitions(frame, seed)
        s_scored = score_partition(spec, s_train, s_test)
        for name, score in s_scored["scores"].items():
            m = compute_metrics(s_scored["y"], s_scored["flags"][name], score)
            for key, value in m.items():
                control.setdefault(name, {}).setdefault(key, []).append(float(value))
    stratified = {
        name: {k: {"mean": float(np.mean(v)), "std": float(np.std(v, ddof=1)), "values": v}
               for k, v in metrics.items()}
        for name, metrics in control.items()
    }  # fmt: skip
    return {
        "partitions": {
            "train": describe(train),
            "validation": describe(val),
            "test": describe(test),
        },
        "chronological": chrono,
        "stratified": stratified,
        "drift_control": monitor_control(train, val, test, DRIFT_COLUMNS),
        "settings": {
            "seeds": list(seeds),
            "block_seconds": BLOCK_SECONDS,
            "resamples": RESAMPLES,
            "bootstrap_seed": BOOTSTRAP_SEED,
            "window_size": WINDOW_SIZE,
            "deltas": list(DELTAS),
            "ratios": list(config.SPLIT_RATIOS),
        },
    }


def x_run__mutmut_39(spec: DatasetSpec, seeds=config.BENCHMARK_SEEDS) -> dict[str, Any]:
    frame = load(spec)
    train, val, test = chronological_partitions(frame)
    scored = score_partition(spec, train, test)
    chrono = {}
    for name, score in scored["scores"].items():
        metrics = compute_metrics(scored["y"], scored["flags"][name], score)
        ci = block_bootstrap_ci(
            scored["XXyXX"], score, test[TIME_UTC], BLOCK_SECONDS, RESAMPLES, BOOTSTRAP_SEED
        )
        chrono[name] = {**metrics, "pr_auc_ci": ci}
    control: dict[str, dict[str, list[float]]] = {}
    for seed in seeds:
        s_train, _s_val, s_test = stratified_partitions(frame, seed)
        s_scored = score_partition(spec, s_train, s_test)
        for name, score in s_scored["scores"].items():
            m = compute_metrics(s_scored["y"], s_scored["flags"][name], score)
            for key, value in m.items():
                control.setdefault(name, {}).setdefault(key, []).append(float(value))
    stratified = {
        name: {k: {"mean": float(np.mean(v)), "std": float(np.std(v, ddof=1)), "values": v}
               for k, v in metrics.items()}
        for name, metrics in control.items()
    }  # fmt: skip
    return {
        "partitions": {
            "train": describe(train),
            "validation": describe(val),
            "test": describe(test),
        },
        "chronological": chrono,
        "stratified": stratified,
        "drift_control": monitor_control(train, val, test, DRIFT_COLUMNS),
        "settings": {
            "seeds": list(seeds),
            "block_seconds": BLOCK_SECONDS,
            "resamples": RESAMPLES,
            "bootstrap_seed": BOOTSTRAP_SEED,
            "window_size": WINDOW_SIZE,
            "deltas": list(DELTAS),
            "ratios": list(config.SPLIT_RATIOS),
        },
    }


def x_run__mutmut_40(spec: DatasetSpec, seeds=config.BENCHMARK_SEEDS) -> dict[str, Any]:
    frame = load(spec)
    train, val, test = chronological_partitions(frame)
    scored = score_partition(spec, train, test)
    chrono = {}
    for name, score in scored["scores"].items():
        metrics = compute_metrics(scored["y"], scored["flags"][name], score)
        ci = block_bootstrap_ci(
            scored["Y"], score, test[TIME_UTC], BLOCK_SECONDS, RESAMPLES, BOOTSTRAP_SEED
        )
        chrono[name] = {**metrics, "pr_auc_ci": ci}
    control: dict[str, dict[str, list[float]]] = {}
    for seed in seeds:
        s_train, _s_val, s_test = stratified_partitions(frame, seed)
        s_scored = score_partition(spec, s_train, s_test)
        for name, score in s_scored["scores"].items():
            m = compute_metrics(s_scored["y"], s_scored["flags"][name], score)
            for key, value in m.items():
                control.setdefault(name, {}).setdefault(key, []).append(float(value))
    stratified = {
        name: {k: {"mean": float(np.mean(v)), "std": float(np.std(v, ddof=1)), "values": v}
               for k, v in metrics.items()}
        for name, metrics in control.items()
    }  # fmt: skip
    return {
        "partitions": {
            "train": describe(train),
            "validation": describe(val),
            "test": describe(test),
        },
        "chronological": chrono,
        "stratified": stratified,
        "drift_control": monitor_control(train, val, test, DRIFT_COLUMNS),
        "settings": {
            "seeds": list(seeds),
            "block_seconds": BLOCK_SECONDS,
            "resamples": RESAMPLES,
            "bootstrap_seed": BOOTSTRAP_SEED,
            "window_size": WINDOW_SIZE,
            "deltas": list(DELTAS),
            "ratios": list(config.SPLIT_RATIOS),
        },
    }


def x_run__mutmut_41(spec: DatasetSpec, seeds=config.BENCHMARK_SEEDS) -> dict[str, Any]:
    frame = load(spec)
    train, val, test = chronological_partitions(frame)
    scored = score_partition(spec, train, test)
    chrono = {}
    for name, score in scored["scores"].items():
        metrics = compute_metrics(scored["y"], scored["flags"][name], score)
        ci = block_bootstrap_ci(
            scored["y"], score, test[TIME_UTC], BLOCK_SECONDS, RESAMPLES, BOOTSTRAP_SEED
        )
        chrono[name] = None
    control: dict[str, dict[str, list[float]]] = {}
    for seed in seeds:
        s_train, _s_val, s_test = stratified_partitions(frame, seed)
        s_scored = score_partition(spec, s_train, s_test)
        for name, score in s_scored["scores"].items():
            m = compute_metrics(s_scored["y"], s_scored["flags"][name], score)
            for key, value in m.items():
                control.setdefault(name, {}).setdefault(key, []).append(float(value))
    stratified = {
        name: {k: {"mean": float(np.mean(v)), "std": float(np.std(v, ddof=1)), "values": v}
               for k, v in metrics.items()}
        for name, metrics in control.items()
    }  # fmt: skip
    return {
        "partitions": {
            "train": describe(train),
            "validation": describe(val),
            "test": describe(test),
        },
        "chronological": chrono,
        "stratified": stratified,
        "drift_control": monitor_control(train, val, test, DRIFT_COLUMNS),
        "settings": {
            "seeds": list(seeds),
            "block_seconds": BLOCK_SECONDS,
            "resamples": RESAMPLES,
            "bootstrap_seed": BOOTSTRAP_SEED,
            "window_size": WINDOW_SIZE,
            "deltas": list(DELTAS),
            "ratios": list(config.SPLIT_RATIOS),
        },
    }


def x_run__mutmut_42(spec: DatasetSpec, seeds=config.BENCHMARK_SEEDS) -> dict[str, Any]:
    frame = load(spec)
    train, val, test = chronological_partitions(frame)
    scored = score_partition(spec, train, test)
    chrono = {}
    for name, score in scored["scores"].items():
        metrics = compute_metrics(scored["y"], scored["flags"][name], score)
        ci = block_bootstrap_ci(
            scored["y"], score, test[TIME_UTC], BLOCK_SECONDS, RESAMPLES, BOOTSTRAP_SEED
        )
        chrono[name] = {**metrics, "XXpr_auc_ciXX": ci}
    control: dict[str, dict[str, list[float]]] = {}
    for seed in seeds:
        s_train, _s_val, s_test = stratified_partitions(frame, seed)
        s_scored = score_partition(spec, s_train, s_test)
        for name, score in s_scored["scores"].items():
            m = compute_metrics(s_scored["y"], s_scored["flags"][name], score)
            for key, value in m.items():
                control.setdefault(name, {}).setdefault(key, []).append(float(value))
    stratified = {
        name: {k: {"mean": float(np.mean(v)), "std": float(np.std(v, ddof=1)), "values": v}
               for k, v in metrics.items()}
        for name, metrics in control.items()
    }  # fmt: skip
    return {
        "partitions": {
            "train": describe(train),
            "validation": describe(val),
            "test": describe(test),
        },
        "chronological": chrono,
        "stratified": stratified,
        "drift_control": monitor_control(train, val, test, DRIFT_COLUMNS),
        "settings": {
            "seeds": list(seeds),
            "block_seconds": BLOCK_SECONDS,
            "resamples": RESAMPLES,
            "bootstrap_seed": BOOTSTRAP_SEED,
            "window_size": WINDOW_SIZE,
            "deltas": list(DELTAS),
            "ratios": list(config.SPLIT_RATIOS),
        },
    }


def x_run__mutmut_43(spec: DatasetSpec, seeds=config.BENCHMARK_SEEDS) -> dict[str, Any]:
    frame = load(spec)
    train, val, test = chronological_partitions(frame)
    scored = score_partition(spec, train, test)
    chrono = {}
    for name, score in scored["scores"].items():
        metrics = compute_metrics(scored["y"], scored["flags"][name], score)
        ci = block_bootstrap_ci(
            scored["y"], score, test[TIME_UTC], BLOCK_SECONDS, RESAMPLES, BOOTSTRAP_SEED
        )
        chrono[name] = {**metrics, "PR_AUC_CI": ci}
    control: dict[str, dict[str, list[float]]] = {}
    for seed in seeds:
        s_train, _s_val, s_test = stratified_partitions(frame, seed)
        s_scored = score_partition(spec, s_train, s_test)
        for name, score in s_scored["scores"].items():
            m = compute_metrics(s_scored["y"], s_scored["flags"][name], score)
            for key, value in m.items():
                control.setdefault(name, {}).setdefault(key, []).append(float(value))
    stratified = {
        name: {k: {"mean": float(np.mean(v)), "std": float(np.std(v, ddof=1)), "values": v}
               for k, v in metrics.items()}
        for name, metrics in control.items()
    }  # fmt: skip
    return {
        "partitions": {
            "train": describe(train),
            "validation": describe(val),
            "test": describe(test),
        },
        "chronological": chrono,
        "stratified": stratified,
        "drift_control": monitor_control(train, val, test, DRIFT_COLUMNS),
        "settings": {
            "seeds": list(seeds),
            "block_seconds": BLOCK_SECONDS,
            "resamples": RESAMPLES,
            "bootstrap_seed": BOOTSTRAP_SEED,
            "window_size": WINDOW_SIZE,
            "deltas": list(DELTAS),
            "ratios": list(config.SPLIT_RATIOS),
        },
    }


def x_run__mutmut_44(spec: DatasetSpec, seeds=config.BENCHMARK_SEEDS) -> dict[str, Any]:
    frame = load(spec)
    train, val, test = chronological_partitions(frame)
    scored = score_partition(spec, train, test)
    chrono = {}
    for name, score in scored["scores"].items():
        metrics = compute_metrics(scored["y"], scored["flags"][name], score)
        ci = block_bootstrap_ci(
            scored["y"], score, test[TIME_UTC], BLOCK_SECONDS, RESAMPLES, BOOTSTRAP_SEED
        )
        chrono[name] = {**metrics, "pr_auc_ci": ci}
    control: dict[str, dict[str, list[float]]] = None
    for seed in seeds:
        s_train, _s_val, s_test = stratified_partitions(frame, seed)
        s_scored = score_partition(spec, s_train, s_test)
        for name, score in s_scored["scores"].items():
            m = compute_metrics(s_scored["y"], s_scored["flags"][name], score)
            for key, value in m.items():
                control.setdefault(name, {}).setdefault(key, []).append(float(value))
    stratified = {
        name: {k: {"mean": float(np.mean(v)), "std": float(np.std(v, ddof=1)), "values": v}
               for k, v in metrics.items()}
        for name, metrics in control.items()
    }  # fmt: skip
    return {
        "partitions": {
            "train": describe(train),
            "validation": describe(val),
            "test": describe(test),
        },
        "chronological": chrono,
        "stratified": stratified,
        "drift_control": monitor_control(train, val, test, DRIFT_COLUMNS),
        "settings": {
            "seeds": list(seeds),
            "block_seconds": BLOCK_SECONDS,
            "resamples": RESAMPLES,
            "bootstrap_seed": BOOTSTRAP_SEED,
            "window_size": WINDOW_SIZE,
            "deltas": list(DELTAS),
            "ratios": list(config.SPLIT_RATIOS),
        },
    }


def x_run__mutmut_45(spec: DatasetSpec, seeds=config.BENCHMARK_SEEDS) -> dict[str, Any]:
    frame = load(spec)
    train, val, test = chronological_partitions(frame)
    scored = score_partition(spec, train, test)
    chrono = {}
    for name, score in scored["scores"].items():
        metrics = compute_metrics(scored["y"], scored["flags"][name], score)
        ci = block_bootstrap_ci(
            scored["y"], score, test[TIME_UTC], BLOCK_SECONDS, RESAMPLES, BOOTSTRAP_SEED
        )
        chrono[name] = {**metrics, "pr_auc_ci": ci}
    control: dict[str, dict[str, list[float]]] = {}
    for seed in seeds:
        s_train, _s_val, s_test = None
        s_scored = score_partition(spec, s_train, s_test)
        for name, score in s_scored["scores"].items():
            m = compute_metrics(s_scored["y"], s_scored["flags"][name], score)
            for key, value in m.items():
                control.setdefault(name, {}).setdefault(key, []).append(float(value))
    stratified = {
        name: {k: {"mean": float(np.mean(v)), "std": float(np.std(v, ddof=1)), "values": v}
               for k, v in metrics.items()}
        for name, metrics in control.items()
    }  # fmt: skip
    return {
        "partitions": {
            "train": describe(train),
            "validation": describe(val),
            "test": describe(test),
        },
        "chronological": chrono,
        "stratified": stratified,
        "drift_control": monitor_control(train, val, test, DRIFT_COLUMNS),
        "settings": {
            "seeds": list(seeds),
            "block_seconds": BLOCK_SECONDS,
            "resamples": RESAMPLES,
            "bootstrap_seed": BOOTSTRAP_SEED,
            "window_size": WINDOW_SIZE,
            "deltas": list(DELTAS),
            "ratios": list(config.SPLIT_RATIOS),
        },
    }


def x_run__mutmut_46(spec: DatasetSpec, seeds=config.BENCHMARK_SEEDS) -> dict[str, Any]:
    frame = load(spec)
    train, val, test = chronological_partitions(frame)
    scored = score_partition(spec, train, test)
    chrono = {}
    for name, score in scored["scores"].items():
        metrics = compute_metrics(scored["y"], scored["flags"][name], score)
        ci = block_bootstrap_ci(
            scored["y"], score, test[TIME_UTC], BLOCK_SECONDS, RESAMPLES, BOOTSTRAP_SEED
        )
        chrono[name] = {**metrics, "pr_auc_ci": ci}
    control: dict[str, dict[str, list[float]]] = {}
    for seed in seeds:
        s_train, _s_val, s_test = stratified_partitions(None, seed)
        s_scored = score_partition(spec, s_train, s_test)
        for name, score in s_scored["scores"].items():
            m = compute_metrics(s_scored["y"], s_scored["flags"][name], score)
            for key, value in m.items():
                control.setdefault(name, {}).setdefault(key, []).append(float(value))
    stratified = {
        name: {k: {"mean": float(np.mean(v)), "std": float(np.std(v, ddof=1)), "values": v}
               for k, v in metrics.items()}
        for name, metrics in control.items()
    }  # fmt: skip
    return {
        "partitions": {
            "train": describe(train),
            "validation": describe(val),
            "test": describe(test),
        },
        "chronological": chrono,
        "stratified": stratified,
        "drift_control": monitor_control(train, val, test, DRIFT_COLUMNS),
        "settings": {
            "seeds": list(seeds),
            "block_seconds": BLOCK_SECONDS,
            "resamples": RESAMPLES,
            "bootstrap_seed": BOOTSTRAP_SEED,
            "window_size": WINDOW_SIZE,
            "deltas": list(DELTAS),
            "ratios": list(config.SPLIT_RATIOS),
        },
    }


def x_run__mutmut_47(spec: DatasetSpec, seeds=config.BENCHMARK_SEEDS) -> dict[str, Any]:
    frame = load(spec)
    train, val, test = chronological_partitions(frame)
    scored = score_partition(spec, train, test)
    chrono = {}
    for name, score in scored["scores"].items():
        metrics = compute_metrics(scored["y"], scored["flags"][name], score)
        ci = block_bootstrap_ci(
            scored["y"], score, test[TIME_UTC], BLOCK_SECONDS, RESAMPLES, BOOTSTRAP_SEED
        )
        chrono[name] = {**metrics, "pr_auc_ci": ci}
    control: dict[str, dict[str, list[float]]] = {}
    for seed in seeds:
        s_train, _s_val, s_test = stratified_partitions(frame, None)
        s_scored = score_partition(spec, s_train, s_test)
        for name, score in s_scored["scores"].items():
            m = compute_metrics(s_scored["y"], s_scored["flags"][name], score)
            for key, value in m.items():
                control.setdefault(name, {}).setdefault(key, []).append(float(value))
    stratified = {
        name: {k: {"mean": float(np.mean(v)), "std": float(np.std(v, ddof=1)), "values": v}
               for k, v in metrics.items()}
        for name, metrics in control.items()
    }  # fmt: skip
    return {
        "partitions": {
            "train": describe(train),
            "validation": describe(val),
            "test": describe(test),
        },
        "chronological": chrono,
        "stratified": stratified,
        "drift_control": monitor_control(train, val, test, DRIFT_COLUMNS),
        "settings": {
            "seeds": list(seeds),
            "block_seconds": BLOCK_SECONDS,
            "resamples": RESAMPLES,
            "bootstrap_seed": BOOTSTRAP_SEED,
            "window_size": WINDOW_SIZE,
            "deltas": list(DELTAS),
            "ratios": list(config.SPLIT_RATIOS),
        },
    }


def x_run__mutmut_48(spec: DatasetSpec, seeds=config.BENCHMARK_SEEDS) -> dict[str, Any]:
    frame = load(spec)
    train, val, test = chronological_partitions(frame)
    scored = score_partition(spec, train, test)
    chrono = {}
    for name, score in scored["scores"].items():
        metrics = compute_metrics(scored["y"], scored["flags"][name], score)
        ci = block_bootstrap_ci(
            scored["y"], score, test[TIME_UTC], BLOCK_SECONDS, RESAMPLES, BOOTSTRAP_SEED
        )
        chrono[name] = {**metrics, "pr_auc_ci": ci}
    control: dict[str, dict[str, list[float]]] = {}
    for seed in seeds:
        s_train, _s_val, s_test = stratified_partitions(seed)
        s_scored = score_partition(spec, s_train, s_test)
        for name, score in s_scored["scores"].items():
            m = compute_metrics(s_scored["y"], s_scored["flags"][name], score)
            for key, value in m.items():
                control.setdefault(name, {}).setdefault(key, []).append(float(value))
    stratified = {
        name: {k: {"mean": float(np.mean(v)), "std": float(np.std(v, ddof=1)), "values": v}
               for k, v in metrics.items()}
        for name, metrics in control.items()
    }  # fmt: skip
    return {
        "partitions": {
            "train": describe(train),
            "validation": describe(val),
            "test": describe(test),
        },
        "chronological": chrono,
        "stratified": stratified,
        "drift_control": monitor_control(train, val, test, DRIFT_COLUMNS),
        "settings": {
            "seeds": list(seeds),
            "block_seconds": BLOCK_SECONDS,
            "resamples": RESAMPLES,
            "bootstrap_seed": BOOTSTRAP_SEED,
            "window_size": WINDOW_SIZE,
            "deltas": list(DELTAS),
            "ratios": list(config.SPLIT_RATIOS),
        },
    }


def x_run__mutmut_49(spec: DatasetSpec, seeds=config.BENCHMARK_SEEDS) -> dict[str, Any]:
    frame = load(spec)
    train, val, test = chronological_partitions(frame)
    scored = score_partition(spec, train, test)
    chrono = {}
    for name, score in scored["scores"].items():
        metrics = compute_metrics(scored["y"], scored["flags"][name], score)
        ci = block_bootstrap_ci(
            scored["y"], score, test[TIME_UTC], BLOCK_SECONDS, RESAMPLES, BOOTSTRAP_SEED
        )
        chrono[name] = {**metrics, "pr_auc_ci": ci}
    control: dict[str, dict[str, list[float]]] = {}
    for seed in seeds:
        s_train, _s_val, s_test = stratified_partitions(frame, )
        s_scored = score_partition(spec, s_train, s_test)
        for name, score in s_scored["scores"].items():
            m = compute_metrics(s_scored["y"], s_scored["flags"][name], score)
            for key, value in m.items():
                control.setdefault(name, {}).setdefault(key, []).append(float(value))
    stratified = {
        name: {k: {"mean": float(np.mean(v)), "std": float(np.std(v, ddof=1)), "values": v}
               for k, v in metrics.items()}
        for name, metrics in control.items()
    }  # fmt: skip
    return {
        "partitions": {
            "train": describe(train),
            "validation": describe(val),
            "test": describe(test),
        },
        "chronological": chrono,
        "stratified": stratified,
        "drift_control": monitor_control(train, val, test, DRIFT_COLUMNS),
        "settings": {
            "seeds": list(seeds),
            "block_seconds": BLOCK_SECONDS,
            "resamples": RESAMPLES,
            "bootstrap_seed": BOOTSTRAP_SEED,
            "window_size": WINDOW_SIZE,
            "deltas": list(DELTAS),
            "ratios": list(config.SPLIT_RATIOS),
        },
    }


def x_run__mutmut_50(spec: DatasetSpec, seeds=config.BENCHMARK_SEEDS) -> dict[str, Any]:
    frame = load(spec)
    train, val, test = chronological_partitions(frame)
    scored = score_partition(spec, train, test)
    chrono = {}
    for name, score in scored["scores"].items():
        metrics = compute_metrics(scored["y"], scored["flags"][name], score)
        ci = block_bootstrap_ci(
            scored["y"], score, test[TIME_UTC], BLOCK_SECONDS, RESAMPLES, BOOTSTRAP_SEED
        )
        chrono[name] = {**metrics, "pr_auc_ci": ci}
    control: dict[str, dict[str, list[float]]] = {}
    for seed in seeds:
        s_train, _s_val, s_test = stratified_partitions(frame, seed)
        s_scored = None
        for name, score in s_scored["scores"].items():
            m = compute_metrics(s_scored["y"], s_scored["flags"][name], score)
            for key, value in m.items():
                control.setdefault(name, {}).setdefault(key, []).append(float(value))
    stratified = {
        name: {k: {"mean": float(np.mean(v)), "std": float(np.std(v, ddof=1)), "values": v}
               for k, v in metrics.items()}
        for name, metrics in control.items()
    }  # fmt: skip
    return {
        "partitions": {
            "train": describe(train),
            "validation": describe(val),
            "test": describe(test),
        },
        "chronological": chrono,
        "stratified": stratified,
        "drift_control": monitor_control(train, val, test, DRIFT_COLUMNS),
        "settings": {
            "seeds": list(seeds),
            "block_seconds": BLOCK_SECONDS,
            "resamples": RESAMPLES,
            "bootstrap_seed": BOOTSTRAP_SEED,
            "window_size": WINDOW_SIZE,
            "deltas": list(DELTAS),
            "ratios": list(config.SPLIT_RATIOS),
        },
    }


def x_run__mutmut_51(spec: DatasetSpec, seeds=config.BENCHMARK_SEEDS) -> dict[str, Any]:
    frame = load(spec)
    train, val, test = chronological_partitions(frame)
    scored = score_partition(spec, train, test)
    chrono = {}
    for name, score in scored["scores"].items():
        metrics = compute_metrics(scored["y"], scored["flags"][name], score)
        ci = block_bootstrap_ci(
            scored["y"], score, test[TIME_UTC], BLOCK_SECONDS, RESAMPLES, BOOTSTRAP_SEED
        )
        chrono[name] = {**metrics, "pr_auc_ci": ci}
    control: dict[str, dict[str, list[float]]] = {}
    for seed in seeds:
        s_train, _s_val, s_test = stratified_partitions(frame, seed)
        s_scored = score_partition(None, s_train, s_test)
        for name, score in s_scored["scores"].items():
            m = compute_metrics(s_scored["y"], s_scored["flags"][name], score)
            for key, value in m.items():
                control.setdefault(name, {}).setdefault(key, []).append(float(value))
    stratified = {
        name: {k: {"mean": float(np.mean(v)), "std": float(np.std(v, ddof=1)), "values": v}
               for k, v in metrics.items()}
        for name, metrics in control.items()
    }  # fmt: skip
    return {
        "partitions": {
            "train": describe(train),
            "validation": describe(val),
            "test": describe(test),
        },
        "chronological": chrono,
        "stratified": stratified,
        "drift_control": monitor_control(train, val, test, DRIFT_COLUMNS),
        "settings": {
            "seeds": list(seeds),
            "block_seconds": BLOCK_SECONDS,
            "resamples": RESAMPLES,
            "bootstrap_seed": BOOTSTRAP_SEED,
            "window_size": WINDOW_SIZE,
            "deltas": list(DELTAS),
            "ratios": list(config.SPLIT_RATIOS),
        },
    }


def x_run__mutmut_52(spec: DatasetSpec, seeds=config.BENCHMARK_SEEDS) -> dict[str, Any]:
    frame = load(spec)
    train, val, test = chronological_partitions(frame)
    scored = score_partition(spec, train, test)
    chrono = {}
    for name, score in scored["scores"].items():
        metrics = compute_metrics(scored["y"], scored["flags"][name], score)
        ci = block_bootstrap_ci(
            scored["y"], score, test[TIME_UTC], BLOCK_SECONDS, RESAMPLES, BOOTSTRAP_SEED
        )
        chrono[name] = {**metrics, "pr_auc_ci": ci}
    control: dict[str, dict[str, list[float]]] = {}
    for seed in seeds:
        s_train, _s_val, s_test = stratified_partitions(frame, seed)
        s_scored = score_partition(spec, None, s_test)
        for name, score in s_scored["scores"].items():
            m = compute_metrics(s_scored["y"], s_scored["flags"][name], score)
            for key, value in m.items():
                control.setdefault(name, {}).setdefault(key, []).append(float(value))
    stratified = {
        name: {k: {"mean": float(np.mean(v)), "std": float(np.std(v, ddof=1)), "values": v}
               for k, v in metrics.items()}
        for name, metrics in control.items()
    }  # fmt: skip
    return {
        "partitions": {
            "train": describe(train),
            "validation": describe(val),
            "test": describe(test),
        },
        "chronological": chrono,
        "stratified": stratified,
        "drift_control": monitor_control(train, val, test, DRIFT_COLUMNS),
        "settings": {
            "seeds": list(seeds),
            "block_seconds": BLOCK_SECONDS,
            "resamples": RESAMPLES,
            "bootstrap_seed": BOOTSTRAP_SEED,
            "window_size": WINDOW_SIZE,
            "deltas": list(DELTAS),
            "ratios": list(config.SPLIT_RATIOS),
        },
    }


def x_run__mutmut_53(spec: DatasetSpec, seeds=config.BENCHMARK_SEEDS) -> dict[str, Any]:
    frame = load(spec)
    train, val, test = chronological_partitions(frame)
    scored = score_partition(spec, train, test)
    chrono = {}
    for name, score in scored["scores"].items():
        metrics = compute_metrics(scored["y"], scored["flags"][name], score)
        ci = block_bootstrap_ci(
            scored["y"], score, test[TIME_UTC], BLOCK_SECONDS, RESAMPLES, BOOTSTRAP_SEED
        )
        chrono[name] = {**metrics, "pr_auc_ci": ci}
    control: dict[str, dict[str, list[float]]] = {}
    for seed in seeds:
        s_train, _s_val, s_test = stratified_partitions(frame, seed)
        s_scored = score_partition(spec, s_train, None)
        for name, score in s_scored["scores"].items():
            m = compute_metrics(s_scored["y"], s_scored["flags"][name], score)
            for key, value in m.items():
                control.setdefault(name, {}).setdefault(key, []).append(float(value))
    stratified = {
        name: {k: {"mean": float(np.mean(v)), "std": float(np.std(v, ddof=1)), "values": v}
               for k, v in metrics.items()}
        for name, metrics in control.items()
    }  # fmt: skip
    return {
        "partitions": {
            "train": describe(train),
            "validation": describe(val),
            "test": describe(test),
        },
        "chronological": chrono,
        "stratified": stratified,
        "drift_control": monitor_control(train, val, test, DRIFT_COLUMNS),
        "settings": {
            "seeds": list(seeds),
            "block_seconds": BLOCK_SECONDS,
            "resamples": RESAMPLES,
            "bootstrap_seed": BOOTSTRAP_SEED,
            "window_size": WINDOW_SIZE,
            "deltas": list(DELTAS),
            "ratios": list(config.SPLIT_RATIOS),
        },
    }


def x_run__mutmut_54(spec: DatasetSpec, seeds=config.BENCHMARK_SEEDS) -> dict[str, Any]:
    frame = load(spec)
    train, val, test = chronological_partitions(frame)
    scored = score_partition(spec, train, test)
    chrono = {}
    for name, score in scored["scores"].items():
        metrics = compute_metrics(scored["y"], scored["flags"][name], score)
        ci = block_bootstrap_ci(
            scored["y"], score, test[TIME_UTC], BLOCK_SECONDS, RESAMPLES, BOOTSTRAP_SEED
        )
        chrono[name] = {**metrics, "pr_auc_ci": ci}
    control: dict[str, dict[str, list[float]]] = {}
    for seed in seeds:
        s_train, _s_val, s_test = stratified_partitions(frame, seed)
        s_scored = score_partition(s_train, s_test)
        for name, score in s_scored["scores"].items():
            m = compute_metrics(s_scored["y"], s_scored["flags"][name], score)
            for key, value in m.items():
                control.setdefault(name, {}).setdefault(key, []).append(float(value))
    stratified = {
        name: {k: {"mean": float(np.mean(v)), "std": float(np.std(v, ddof=1)), "values": v}
               for k, v in metrics.items()}
        for name, metrics in control.items()
    }  # fmt: skip
    return {
        "partitions": {
            "train": describe(train),
            "validation": describe(val),
            "test": describe(test),
        },
        "chronological": chrono,
        "stratified": stratified,
        "drift_control": monitor_control(train, val, test, DRIFT_COLUMNS),
        "settings": {
            "seeds": list(seeds),
            "block_seconds": BLOCK_SECONDS,
            "resamples": RESAMPLES,
            "bootstrap_seed": BOOTSTRAP_SEED,
            "window_size": WINDOW_SIZE,
            "deltas": list(DELTAS),
            "ratios": list(config.SPLIT_RATIOS),
        },
    }


def x_run__mutmut_55(spec: DatasetSpec, seeds=config.BENCHMARK_SEEDS) -> dict[str, Any]:
    frame = load(spec)
    train, val, test = chronological_partitions(frame)
    scored = score_partition(spec, train, test)
    chrono = {}
    for name, score in scored["scores"].items():
        metrics = compute_metrics(scored["y"], scored["flags"][name], score)
        ci = block_bootstrap_ci(
            scored["y"], score, test[TIME_UTC], BLOCK_SECONDS, RESAMPLES, BOOTSTRAP_SEED
        )
        chrono[name] = {**metrics, "pr_auc_ci": ci}
    control: dict[str, dict[str, list[float]]] = {}
    for seed in seeds:
        s_train, _s_val, s_test = stratified_partitions(frame, seed)
        s_scored = score_partition(spec, s_test)
        for name, score in s_scored["scores"].items():
            m = compute_metrics(s_scored["y"], s_scored["flags"][name], score)
            for key, value in m.items():
                control.setdefault(name, {}).setdefault(key, []).append(float(value))
    stratified = {
        name: {k: {"mean": float(np.mean(v)), "std": float(np.std(v, ddof=1)), "values": v}
               for k, v in metrics.items()}
        for name, metrics in control.items()
    }  # fmt: skip
    return {
        "partitions": {
            "train": describe(train),
            "validation": describe(val),
            "test": describe(test),
        },
        "chronological": chrono,
        "stratified": stratified,
        "drift_control": monitor_control(train, val, test, DRIFT_COLUMNS),
        "settings": {
            "seeds": list(seeds),
            "block_seconds": BLOCK_SECONDS,
            "resamples": RESAMPLES,
            "bootstrap_seed": BOOTSTRAP_SEED,
            "window_size": WINDOW_SIZE,
            "deltas": list(DELTAS),
            "ratios": list(config.SPLIT_RATIOS),
        },
    }


def x_run__mutmut_56(spec: DatasetSpec, seeds=config.BENCHMARK_SEEDS) -> dict[str, Any]:
    frame = load(spec)
    train, val, test = chronological_partitions(frame)
    scored = score_partition(spec, train, test)
    chrono = {}
    for name, score in scored["scores"].items():
        metrics = compute_metrics(scored["y"], scored["flags"][name], score)
        ci = block_bootstrap_ci(
            scored["y"], score, test[TIME_UTC], BLOCK_SECONDS, RESAMPLES, BOOTSTRAP_SEED
        )
        chrono[name] = {**metrics, "pr_auc_ci": ci}
    control: dict[str, dict[str, list[float]]] = {}
    for seed in seeds:
        s_train, _s_val, s_test = stratified_partitions(frame, seed)
        s_scored = score_partition(spec, s_train, )
        for name, score in s_scored["scores"].items():
            m = compute_metrics(s_scored["y"], s_scored["flags"][name], score)
            for key, value in m.items():
                control.setdefault(name, {}).setdefault(key, []).append(float(value))
    stratified = {
        name: {k: {"mean": float(np.mean(v)), "std": float(np.std(v, ddof=1)), "values": v}
               for k, v in metrics.items()}
        for name, metrics in control.items()
    }  # fmt: skip
    return {
        "partitions": {
            "train": describe(train),
            "validation": describe(val),
            "test": describe(test),
        },
        "chronological": chrono,
        "stratified": stratified,
        "drift_control": monitor_control(train, val, test, DRIFT_COLUMNS),
        "settings": {
            "seeds": list(seeds),
            "block_seconds": BLOCK_SECONDS,
            "resamples": RESAMPLES,
            "bootstrap_seed": BOOTSTRAP_SEED,
            "window_size": WINDOW_SIZE,
            "deltas": list(DELTAS),
            "ratios": list(config.SPLIT_RATIOS),
        },
    }


def x_run__mutmut_57(spec: DatasetSpec, seeds=config.BENCHMARK_SEEDS) -> dict[str, Any]:
    frame = load(spec)
    train, val, test = chronological_partitions(frame)
    scored = score_partition(spec, train, test)
    chrono = {}
    for name, score in scored["scores"].items():
        metrics = compute_metrics(scored["y"], scored["flags"][name], score)
        ci = block_bootstrap_ci(
            scored["y"], score, test[TIME_UTC], BLOCK_SECONDS, RESAMPLES, BOOTSTRAP_SEED
        )
        chrono[name] = {**metrics, "pr_auc_ci": ci}
    control: dict[str, dict[str, list[float]]] = {}
    for seed in seeds:
        s_train, _s_val, s_test = stratified_partitions(frame, seed)
        s_scored = score_partition(spec, s_train, s_test)
        for name, score in s_scored["XXscoresXX"].items():
            m = compute_metrics(s_scored["y"], s_scored["flags"][name], score)
            for key, value in m.items():
                control.setdefault(name, {}).setdefault(key, []).append(float(value))
    stratified = {
        name: {k: {"mean": float(np.mean(v)), "std": float(np.std(v, ddof=1)), "values": v}
               for k, v in metrics.items()}
        for name, metrics in control.items()
    }  # fmt: skip
    return {
        "partitions": {
            "train": describe(train),
            "validation": describe(val),
            "test": describe(test),
        },
        "chronological": chrono,
        "stratified": stratified,
        "drift_control": monitor_control(train, val, test, DRIFT_COLUMNS),
        "settings": {
            "seeds": list(seeds),
            "block_seconds": BLOCK_SECONDS,
            "resamples": RESAMPLES,
            "bootstrap_seed": BOOTSTRAP_SEED,
            "window_size": WINDOW_SIZE,
            "deltas": list(DELTAS),
            "ratios": list(config.SPLIT_RATIOS),
        },
    }


def x_run__mutmut_58(spec: DatasetSpec, seeds=config.BENCHMARK_SEEDS) -> dict[str, Any]:
    frame = load(spec)
    train, val, test = chronological_partitions(frame)
    scored = score_partition(spec, train, test)
    chrono = {}
    for name, score in scored["scores"].items():
        metrics = compute_metrics(scored["y"], scored["flags"][name], score)
        ci = block_bootstrap_ci(
            scored["y"], score, test[TIME_UTC], BLOCK_SECONDS, RESAMPLES, BOOTSTRAP_SEED
        )
        chrono[name] = {**metrics, "pr_auc_ci": ci}
    control: dict[str, dict[str, list[float]]] = {}
    for seed in seeds:
        s_train, _s_val, s_test = stratified_partitions(frame, seed)
        s_scored = score_partition(spec, s_train, s_test)
        for name, score in s_scored["SCORES"].items():
            m = compute_metrics(s_scored["y"], s_scored["flags"][name], score)
            for key, value in m.items():
                control.setdefault(name, {}).setdefault(key, []).append(float(value))
    stratified = {
        name: {k: {"mean": float(np.mean(v)), "std": float(np.std(v, ddof=1)), "values": v}
               for k, v in metrics.items()}
        for name, metrics in control.items()
    }  # fmt: skip
    return {
        "partitions": {
            "train": describe(train),
            "validation": describe(val),
            "test": describe(test),
        },
        "chronological": chrono,
        "stratified": stratified,
        "drift_control": monitor_control(train, val, test, DRIFT_COLUMNS),
        "settings": {
            "seeds": list(seeds),
            "block_seconds": BLOCK_SECONDS,
            "resamples": RESAMPLES,
            "bootstrap_seed": BOOTSTRAP_SEED,
            "window_size": WINDOW_SIZE,
            "deltas": list(DELTAS),
            "ratios": list(config.SPLIT_RATIOS),
        },
    }


def x_run__mutmut_59(spec: DatasetSpec, seeds=config.BENCHMARK_SEEDS) -> dict[str, Any]:
    frame = load(spec)
    train, val, test = chronological_partitions(frame)
    scored = score_partition(spec, train, test)
    chrono = {}
    for name, score in scored["scores"].items():
        metrics = compute_metrics(scored["y"], scored["flags"][name], score)
        ci = block_bootstrap_ci(
            scored["y"], score, test[TIME_UTC], BLOCK_SECONDS, RESAMPLES, BOOTSTRAP_SEED
        )
        chrono[name] = {**metrics, "pr_auc_ci": ci}
    control: dict[str, dict[str, list[float]]] = {}
    for seed in seeds:
        s_train, _s_val, s_test = stratified_partitions(frame, seed)
        s_scored = score_partition(spec, s_train, s_test)
        for name, score in s_scored["scores"].items():
            m = None
            for key, value in m.items():
                control.setdefault(name, {}).setdefault(key, []).append(float(value))
    stratified = {
        name: {k: {"mean": float(np.mean(v)), "std": float(np.std(v, ddof=1)), "values": v}
               for k, v in metrics.items()}
        for name, metrics in control.items()
    }  # fmt: skip
    return {
        "partitions": {
            "train": describe(train),
            "validation": describe(val),
            "test": describe(test),
        },
        "chronological": chrono,
        "stratified": stratified,
        "drift_control": monitor_control(train, val, test, DRIFT_COLUMNS),
        "settings": {
            "seeds": list(seeds),
            "block_seconds": BLOCK_SECONDS,
            "resamples": RESAMPLES,
            "bootstrap_seed": BOOTSTRAP_SEED,
            "window_size": WINDOW_SIZE,
            "deltas": list(DELTAS),
            "ratios": list(config.SPLIT_RATIOS),
        },
    }


def x_run__mutmut_60(spec: DatasetSpec, seeds=config.BENCHMARK_SEEDS) -> dict[str, Any]:
    frame = load(spec)
    train, val, test = chronological_partitions(frame)
    scored = score_partition(spec, train, test)
    chrono = {}
    for name, score in scored["scores"].items():
        metrics = compute_metrics(scored["y"], scored["flags"][name], score)
        ci = block_bootstrap_ci(
            scored["y"], score, test[TIME_UTC], BLOCK_SECONDS, RESAMPLES, BOOTSTRAP_SEED
        )
        chrono[name] = {**metrics, "pr_auc_ci": ci}
    control: dict[str, dict[str, list[float]]] = {}
    for seed in seeds:
        s_train, _s_val, s_test = stratified_partitions(frame, seed)
        s_scored = score_partition(spec, s_train, s_test)
        for name, score in s_scored["scores"].items():
            m = compute_metrics(None, s_scored["flags"][name], score)
            for key, value in m.items():
                control.setdefault(name, {}).setdefault(key, []).append(float(value))
    stratified = {
        name: {k: {"mean": float(np.mean(v)), "std": float(np.std(v, ddof=1)), "values": v}
               for k, v in metrics.items()}
        for name, metrics in control.items()
    }  # fmt: skip
    return {
        "partitions": {
            "train": describe(train),
            "validation": describe(val),
            "test": describe(test),
        },
        "chronological": chrono,
        "stratified": stratified,
        "drift_control": monitor_control(train, val, test, DRIFT_COLUMNS),
        "settings": {
            "seeds": list(seeds),
            "block_seconds": BLOCK_SECONDS,
            "resamples": RESAMPLES,
            "bootstrap_seed": BOOTSTRAP_SEED,
            "window_size": WINDOW_SIZE,
            "deltas": list(DELTAS),
            "ratios": list(config.SPLIT_RATIOS),
        },
    }


def x_run__mutmut_61(spec: DatasetSpec, seeds=config.BENCHMARK_SEEDS) -> dict[str, Any]:
    frame = load(spec)
    train, val, test = chronological_partitions(frame)
    scored = score_partition(spec, train, test)
    chrono = {}
    for name, score in scored["scores"].items():
        metrics = compute_metrics(scored["y"], scored["flags"][name], score)
        ci = block_bootstrap_ci(
            scored["y"], score, test[TIME_UTC], BLOCK_SECONDS, RESAMPLES, BOOTSTRAP_SEED
        )
        chrono[name] = {**metrics, "pr_auc_ci": ci}
    control: dict[str, dict[str, list[float]]] = {}
    for seed in seeds:
        s_train, _s_val, s_test = stratified_partitions(frame, seed)
        s_scored = score_partition(spec, s_train, s_test)
        for name, score in s_scored["scores"].items():
            m = compute_metrics(s_scored["y"], None, score)
            for key, value in m.items():
                control.setdefault(name, {}).setdefault(key, []).append(float(value))
    stratified = {
        name: {k: {"mean": float(np.mean(v)), "std": float(np.std(v, ddof=1)), "values": v}
               for k, v in metrics.items()}
        for name, metrics in control.items()
    }  # fmt: skip
    return {
        "partitions": {
            "train": describe(train),
            "validation": describe(val),
            "test": describe(test),
        },
        "chronological": chrono,
        "stratified": stratified,
        "drift_control": monitor_control(train, val, test, DRIFT_COLUMNS),
        "settings": {
            "seeds": list(seeds),
            "block_seconds": BLOCK_SECONDS,
            "resamples": RESAMPLES,
            "bootstrap_seed": BOOTSTRAP_SEED,
            "window_size": WINDOW_SIZE,
            "deltas": list(DELTAS),
            "ratios": list(config.SPLIT_RATIOS),
        },
    }


def x_run__mutmut_62(spec: DatasetSpec, seeds=config.BENCHMARK_SEEDS) -> dict[str, Any]:
    frame = load(spec)
    train, val, test = chronological_partitions(frame)
    scored = score_partition(spec, train, test)
    chrono = {}
    for name, score in scored["scores"].items():
        metrics = compute_metrics(scored["y"], scored["flags"][name], score)
        ci = block_bootstrap_ci(
            scored["y"], score, test[TIME_UTC], BLOCK_SECONDS, RESAMPLES, BOOTSTRAP_SEED
        )
        chrono[name] = {**metrics, "pr_auc_ci": ci}
    control: dict[str, dict[str, list[float]]] = {}
    for seed in seeds:
        s_train, _s_val, s_test = stratified_partitions(frame, seed)
        s_scored = score_partition(spec, s_train, s_test)
        for name, score in s_scored["scores"].items():
            m = compute_metrics(s_scored["y"], s_scored["flags"][name], None)
            for key, value in m.items():
                control.setdefault(name, {}).setdefault(key, []).append(float(value))
    stratified = {
        name: {k: {"mean": float(np.mean(v)), "std": float(np.std(v, ddof=1)), "values": v}
               for k, v in metrics.items()}
        for name, metrics in control.items()
    }  # fmt: skip
    return {
        "partitions": {
            "train": describe(train),
            "validation": describe(val),
            "test": describe(test),
        },
        "chronological": chrono,
        "stratified": stratified,
        "drift_control": monitor_control(train, val, test, DRIFT_COLUMNS),
        "settings": {
            "seeds": list(seeds),
            "block_seconds": BLOCK_SECONDS,
            "resamples": RESAMPLES,
            "bootstrap_seed": BOOTSTRAP_SEED,
            "window_size": WINDOW_SIZE,
            "deltas": list(DELTAS),
            "ratios": list(config.SPLIT_RATIOS),
        },
    }


def x_run__mutmut_63(spec: DatasetSpec, seeds=config.BENCHMARK_SEEDS) -> dict[str, Any]:
    frame = load(spec)
    train, val, test = chronological_partitions(frame)
    scored = score_partition(spec, train, test)
    chrono = {}
    for name, score in scored["scores"].items():
        metrics = compute_metrics(scored["y"], scored["flags"][name], score)
        ci = block_bootstrap_ci(
            scored["y"], score, test[TIME_UTC], BLOCK_SECONDS, RESAMPLES, BOOTSTRAP_SEED
        )
        chrono[name] = {**metrics, "pr_auc_ci": ci}
    control: dict[str, dict[str, list[float]]] = {}
    for seed in seeds:
        s_train, _s_val, s_test = stratified_partitions(frame, seed)
        s_scored = score_partition(spec, s_train, s_test)
        for name, score in s_scored["scores"].items():
            m = compute_metrics(s_scored["flags"][name], score)
            for key, value in m.items():
                control.setdefault(name, {}).setdefault(key, []).append(float(value))
    stratified = {
        name: {k: {"mean": float(np.mean(v)), "std": float(np.std(v, ddof=1)), "values": v}
               for k, v in metrics.items()}
        for name, metrics in control.items()
    }  # fmt: skip
    return {
        "partitions": {
            "train": describe(train),
            "validation": describe(val),
            "test": describe(test),
        },
        "chronological": chrono,
        "stratified": stratified,
        "drift_control": monitor_control(train, val, test, DRIFT_COLUMNS),
        "settings": {
            "seeds": list(seeds),
            "block_seconds": BLOCK_SECONDS,
            "resamples": RESAMPLES,
            "bootstrap_seed": BOOTSTRAP_SEED,
            "window_size": WINDOW_SIZE,
            "deltas": list(DELTAS),
            "ratios": list(config.SPLIT_RATIOS),
        },
    }


def x_run__mutmut_64(spec: DatasetSpec, seeds=config.BENCHMARK_SEEDS) -> dict[str, Any]:
    frame = load(spec)
    train, val, test = chronological_partitions(frame)
    scored = score_partition(spec, train, test)
    chrono = {}
    for name, score in scored["scores"].items():
        metrics = compute_metrics(scored["y"], scored["flags"][name], score)
        ci = block_bootstrap_ci(
            scored["y"], score, test[TIME_UTC], BLOCK_SECONDS, RESAMPLES, BOOTSTRAP_SEED
        )
        chrono[name] = {**metrics, "pr_auc_ci": ci}
    control: dict[str, dict[str, list[float]]] = {}
    for seed in seeds:
        s_train, _s_val, s_test = stratified_partitions(frame, seed)
        s_scored = score_partition(spec, s_train, s_test)
        for name, score in s_scored["scores"].items():
            m = compute_metrics(s_scored["y"], score)
            for key, value in m.items():
                control.setdefault(name, {}).setdefault(key, []).append(float(value))
    stratified = {
        name: {k: {"mean": float(np.mean(v)), "std": float(np.std(v, ddof=1)), "values": v}
               for k, v in metrics.items()}
        for name, metrics in control.items()
    }  # fmt: skip
    return {
        "partitions": {
            "train": describe(train),
            "validation": describe(val),
            "test": describe(test),
        },
        "chronological": chrono,
        "stratified": stratified,
        "drift_control": monitor_control(train, val, test, DRIFT_COLUMNS),
        "settings": {
            "seeds": list(seeds),
            "block_seconds": BLOCK_SECONDS,
            "resamples": RESAMPLES,
            "bootstrap_seed": BOOTSTRAP_SEED,
            "window_size": WINDOW_SIZE,
            "deltas": list(DELTAS),
            "ratios": list(config.SPLIT_RATIOS),
        },
    }


def x_run__mutmut_65(spec: DatasetSpec, seeds=config.BENCHMARK_SEEDS) -> dict[str, Any]:
    frame = load(spec)
    train, val, test = chronological_partitions(frame)
    scored = score_partition(spec, train, test)
    chrono = {}
    for name, score in scored["scores"].items():
        metrics = compute_metrics(scored["y"], scored["flags"][name], score)
        ci = block_bootstrap_ci(
            scored["y"], score, test[TIME_UTC], BLOCK_SECONDS, RESAMPLES, BOOTSTRAP_SEED
        )
        chrono[name] = {**metrics, "pr_auc_ci": ci}
    control: dict[str, dict[str, list[float]]] = {}
    for seed in seeds:
        s_train, _s_val, s_test = stratified_partitions(frame, seed)
        s_scored = score_partition(spec, s_train, s_test)
        for name, score in s_scored["scores"].items():
            m = compute_metrics(s_scored["y"], s_scored["flags"][name], )
            for key, value in m.items():
                control.setdefault(name, {}).setdefault(key, []).append(float(value))
    stratified = {
        name: {k: {"mean": float(np.mean(v)), "std": float(np.std(v, ddof=1)), "values": v}
               for k, v in metrics.items()}
        for name, metrics in control.items()
    }  # fmt: skip
    return {
        "partitions": {
            "train": describe(train),
            "validation": describe(val),
            "test": describe(test),
        },
        "chronological": chrono,
        "stratified": stratified,
        "drift_control": monitor_control(train, val, test, DRIFT_COLUMNS),
        "settings": {
            "seeds": list(seeds),
            "block_seconds": BLOCK_SECONDS,
            "resamples": RESAMPLES,
            "bootstrap_seed": BOOTSTRAP_SEED,
            "window_size": WINDOW_SIZE,
            "deltas": list(DELTAS),
            "ratios": list(config.SPLIT_RATIOS),
        },
    }


def x_run__mutmut_66(spec: DatasetSpec, seeds=config.BENCHMARK_SEEDS) -> dict[str, Any]:
    frame = load(spec)
    train, val, test = chronological_partitions(frame)
    scored = score_partition(spec, train, test)
    chrono = {}
    for name, score in scored["scores"].items():
        metrics = compute_metrics(scored["y"], scored["flags"][name], score)
        ci = block_bootstrap_ci(
            scored["y"], score, test[TIME_UTC], BLOCK_SECONDS, RESAMPLES, BOOTSTRAP_SEED
        )
        chrono[name] = {**metrics, "pr_auc_ci": ci}
    control: dict[str, dict[str, list[float]]] = {}
    for seed in seeds:
        s_train, _s_val, s_test = stratified_partitions(frame, seed)
        s_scored = score_partition(spec, s_train, s_test)
        for name, score in s_scored["scores"].items():
            m = compute_metrics(s_scored["XXyXX"], s_scored["flags"][name], score)
            for key, value in m.items():
                control.setdefault(name, {}).setdefault(key, []).append(float(value))
    stratified = {
        name: {k: {"mean": float(np.mean(v)), "std": float(np.std(v, ddof=1)), "values": v}
               for k, v in metrics.items()}
        for name, metrics in control.items()
    }  # fmt: skip
    return {
        "partitions": {
            "train": describe(train),
            "validation": describe(val),
            "test": describe(test),
        },
        "chronological": chrono,
        "stratified": stratified,
        "drift_control": monitor_control(train, val, test, DRIFT_COLUMNS),
        "settings": {
            "seeds": list(seeds),
            "block_seconds": BLOCK_SECONDS,
            "resamples": RESAMPLES,
            "bootstrap_seed": BOOTSTRAP_SEED,
            "window_size": WINDOW_SIZE,
            "deltas": list(DELTAS),
            "ratios": list(config.SPLIT_RATIOS),
        },
    }


def x_run__mutmut_67(spec: DatasetSpec, seeds=config.BENCHMARK_SEEDS) -> dict[str, Any]:
    frame = load(spec)
    train, val, test = chronological_partitions(frame)
    scored = score_partition(spec, train, test)
    chrono = {}
    for name, score in scored["scores"].items():
        metrics = compute_metrics(scored["y"], scored["flags"][name], score)
        ci = block_bootstrap_ci(
            scored["y"], score, test[TIME_UTC], BLOCK_SECONDS, RESAMPLES, BOOTSTRAP_SEED
        )
        chrono[name] = {**metrics, "pr_auc_ci": ci}
    control: dict[str, dict[str, list[float]]] = {}
    for seed in seeds:
        s_train, _s_val, s_test = stratified_partitions(frame, seed)
        s_scored = score_partition(spec, s_train, s_test)
        for name, score in s_scored["scores"].items():
            m = compute_metrics(s_scored["Y"], s_scored["flags"][name], score)
            for key, value in m.items():
                control.setdefault(name, {}).setdefault(key, []).append(float(value))
    stratified = {
        name: {k: {"mean": float(np.mean(v)), "std": float(np.std(v, ddof=1)), "values": v}
               for k, v in metrics.items()}
        for name, metrics in control.items()
    }  # fmt: skip
    return {
        "partitions": {
            "train": describe(train),
            "validation": describe(val),
            "test": describe(test),
        },
        "chronological": chrono,
        "stratified": stratified,
        "drift_control": monitor_control(train, val, test, DRIFT_COLUMNS),
        "settings": {
            "seeds": list(seeds),
            "block_seconds": BLOCK_SECONDS,
            "resamples": RESAMPLES,
            "bootstrap_seed": BOOTSTRAP_SEED,
            "window_size": WINDOW_SIZE,
            "deltas": list(DELTAS),
            "ratios": list(config.SPLIT_RATIOS),
        },
    }


def x_run__mutmut_68(spec: DatasetSpec, seeds=config.BENCHMARK_SEEDS) -> dict[str, Any]:
    frame = load(spec)
    train, val, test = chronological_partitions(frame)
    scored = score_partition(spec, train, test)
    chrono = {}
    for name, score in scored["scores"].items():
        metrics = compute_metrics(scored["y"], scored["flags"][name], score)
        ci = block_bootstrap_ci(
            scored["y"], score, test[TIME_UTC], BLOCK_SECONDS, RESAMPLES, BOOTSTRAP_SEED
        )
        chrono[name] = {**metrics, "pr_auc_ci": ci}
    control: dict[str, dict[str, list[float]]] = {}
    for seed in seeds:
        s_train, _s_val, s_test = stratified_partitions(frame, seed)
        s_scored = score_partition(spec, s_train, s_test)
        for name, score in s_scored["scores"].items():
            m = compute_metrics(s_scored["y"], s_scored["XXflagsXX"][name], score)
            for key, value in m.items():
                control.setdefault(name, {}).setdefault(key, []).append(float(value))
    stratified = {
        name: {k: {"mean": float(np.mean(v)), "std": float(np.std(v, ddof=1)), "values": v}
               for k, v in metrics.items()}
        for name, metrics in control.items()
    }  # fmt: skip
    return {
        "partitions": {
            "train": describe(train),
            "validation": describe(val),
            "test": describe(test),
        },
        "chronological": chrono,
        "stratified": stratified,
        "drift_control": monitor_control(train, val, test, DRIFT_COLUMNS),
        "settings": {
            "seeds": list(seeds),
            "block_seconds": BLOCK_SECONDS,
            "resamples": RESAMPLES,
            "bootstrap_seed": BOOTSTRAP_SEED,
            "window_size": WINDOW_SIZE,
            "deltas": list(DELTAS),
            "ratios": list(config.SPLIT_RATIOS),
        },
    }


def x_run__mutmut_69(spec: DatasetSpec, seeds=config.BENCHMARK_SEEDS) -> dict[str, Any]:
    frame = load(spec)
    train, val, test = chronological_partitions(frame)
    scored = score_partition(spec, train, test)
    chrono = {}
    for name, score in scored["scores"].items():
        metrics = compute_metrics(scored["y"], scored["flags"][name], score)
        ci = block_bootstrap_ci(
            scored["y"], score, test[TIME_UTC], BLOCK_SECONDS, RESAMPLES, BOOTSTRAP_SEED
        )
        chrono[name] = {**metrics, "pr_auc_ci": ci}
    control: dict[str, dict[str, list[float]]] = {}
    for seed in seeds:
        s_train, _s_val, s_test = stratified_partitions(frame, seed)
        s_scored = score_partition(spec, s_train, s_test)
        for name, score in s_scored["scores"].items():
            m = compute_metrics(s_scored["y"], s_scored["FLAGS"][name], score)
            for key, value in m.items():
                control.setdefault(name, {}).setdefault(key, []).append(float(value))
    stratified = {
        name: {k: {"mean": float(np.mean(v)), "std": float(np.std(v, ddof=1)), "values": v}
               for k, v in metrics.items()}
        for name, metrics in control.items()
    }  # fmt: skip
    return {
        "partitions": {
            "train": describe(train),
            "validation": describe(val),
            "test": describe(test),
        },
        "chronological": chrono,
        "stratified": stratified,
        "drift_control": monitor_control(train, val, test, DRIFT_COLUMNS),
        "settings": {
            "seeds": list(seeds),
            "block_seconds": BLOCK_SECONDS,
            "resamples": RESAMPLES,
            "bootstrap_seed": BOOTSTRAP_SEED,
            "window_size": WINDOW_SIZE,
            "deltas": list(DELTAS),
            "ratios": list(config.SPLIT_RATIOS),
        },
    }


def x_run__mutmut_70(spec: DatasetSpec, seeds=config.BENCHMARK_SEEDS) -> dict[str, Any]:
    frame = load(spec)
    train, val, test = chronological_partitions(frame)
    scored = score_partition(spec, train, test)
    chrono = {}
    for name, score in scored["scores"].items():
        metrics = compute_metrics(scored["y"], scored["flags"][name], score)
        ci = block_bootstrap_ci(
            scored["y"], score, test[TIME_UTC], BLOCK_SECONDS, RESAMPLES, BOOTSTRAP_SEED
        )
        chrono[name] = {**metrics, "pr_auc_ci": ci}
    control: dict[str, dict[str, list[float]]] = {}
    for seed in seeds:
        s_train, _s_val, s_test = stratified_partitions(frame, seed)
        s_scored = score_partition(spec, s_train, s_test)
        for name, score in s_scored["scores"].items():
            m = compute_metrics(s_scored["y"], s_scored["flags"][name], score)
            for key, value in m.items():
                control.setdefault(name, {}).setdefault(key, []).append(None)
    stratified = {
        name: {k: {"mean": float(np.mean(v)), "std": float(np.std(v, ddof=1)), "values": v}
               for k, v in metrics.items()}
        for name, metrics in control.items()
    }  # fmt: skip
    return {
        "partitions": {
            "train": describe(train),
            "validation": describe(val),
            "test": describe(test),
        },
        "chronological": chrono,
        "stratified": stratified,
        "drift_control": monitor_control(train, val, test, DRIFT_COLUMNS),
        "settings": {
            "seeds": list(seeds),
            "block_seconds": BLOCK_SECONDS,
            "resamples": RESAMPLES,
            "bootstrap_seed": BOOTSTRAP_SEED,
            "window_size": WINDOW_SIZE,
            "deltas": list(DELTAS),
            "ratios": list(config.SPLIT_RATIOS),
        },
    }


def x_run__mutmut_71(spec: DatasetSpec, seeds=config.BENCHMARK_SEEDS) -> dict[str, Any]:
    frame = load(spec)
    train, val, test = chronological_partitions(frame)
    scored = score_partition(spec, train, test)
    chrono = {}
    for name, score in scored["scores"].items():
        metrics = compute_metrics(scored["y"], scored["flags"][name], score)
        ci = block_bootstrap_ci(
            scored["y"], score, test[TIME_UTC], BLOCK_SECONDS, RESAMPLES, BOOTSTRAP_SEED
        )
        chrono[name] = {**metrics, "pr_auc_ci": ci}
    control: dict[str, dict[str, list[float]]] = {}
    for seed in seeds:
        s_train, _s_val, s_test = stratified_partitions(frame, seed)
        s_scored = score_partition(spec, s_train, s_test)
        for name, score in s_scored["scores"].items():
            m = compute_metrics(s_scored["y"], s_scored["flags"][name], score)
            for key, value in m.items():
                control.setdefault(name, {}).setdefault(None, []).append(float(value))
    stratified = {
        name: {k: {"mean": float(np.mean(v)), "std": float(np.std(v, ddof=1)), "values": v}
               for k, v in metrics.items()}
        for name, metrics in control.items()
    }  # fmt: skip
    return {
        "partitions": {
            "train": describe(train),
            "validation": describe(val),
            "test": describe(test),
        },
        "chronological": chrono,
        "stratified": stratified,
        "drift_control": monitor_control(train, val, test, DRIFT_COLUMNS),
        "settings": {
            "seeds": list(seeds),
            "block_seconds": BLOCK_SECONDS,
            "resamples": RESAMPLES,
            "bootstrap_seed": BOOTSTRAP_SEED,
            "window_size": WINDOW_SIZE,
            "deltas": list(DELTAS),
            "ratios": list(config.SPLIT_RATIOS),
        },
    }


def x_run__mutmut_72(spec: DatasetSpec, seeds=config.BENCHMARK_SEEDS) -> dict[str, Any]:
    frame = load(spec)
    train, val, test = chronological_partitions(frame)
    scored = score_partition(spec, train, test)
    chrono = {}
    for name, score in scored["scores"].items():
        metrics = compute_metrics(scored["y"], scored["flags"][name], score)
        ci = block_bootstrap_ci(
            scored["y"], score, test[TIME_UTC], BLOCK_SECONDS, RESAMPLES, BOOTSTRAP_SEED
        )
        chrono[name] = {**metrics, "pr_auc_ci": ci}
    control: dict[str, dict[str, list[float]]] = {}
    for seed in seeds:
        s_train, _s_val, s_test = stratified_partitions(frame, seed)
        s_scored = score_partition(spec, s_train, s_test)
        for name, score in s_scored["scores"].items():
            m = compute_metrics(s_scored["y"], s_scored["flags"][name], score)
            for key, value in m.items():
                control.setdefault(name, {}).setdefault(key, None).append(float(value))
    stratified = {
        name: {k: {"mean": float(np.mean(v)), "std": float(np.std(v, ddof=1)), "values": v}
               for k, v in metrics.items()}
        for name, metrics in control.items()
    }  # fmt: skip
    return {
        "partitions": {
            "train": describe(train),
            "validation": describe(val),
            "test": describe(test),
        },
        "chronological": chrono,
        "stratified": stratified,
        "drift_control": monitor_control(train, val, test, DRIFT_COLUMNS),
        "settings": {
            "seeds": list(seeds),
            "block_seconds": BLOCK_SECONDS,
            "resamples": RESAMPLES,
            "bootstrap_seed": BOOTSTRAP_SEED,
            "window_size": WINDOW_SIZE,
            "deltas": list(DELTAS),
            "ratios": list(config.SPLIT_RATIOS),
        },
    }


def x_run__mutmut_73(spec: DatasetSpec, seeds=config.BENCHMARK_SEEDS) -> dict[str, Any]:
    frame = load(spec)
    train, val, test = chronological_partitions(frame)
    scored = score_partition(spec, train, test)
    chrono = {}
    for name, score in scored["scores"].items():
        metrics = compute_metrics(scored["y"], scored["flags"][name], score)
        ci = block_bootstrap_ci(
            scored["y"], score, test[TIME_UTC], BLOCK_SECONDS, RESAMPLES, BOOTSTRAP_SEED
        )
        chrono[name] = {**metrics, "pr_auc_ci": ci}
    control: dict[str, dict[str, list[float]]] = {}
    for seed in seeds:
        s_train, _s_val, s_test = stratified_partitions(frame, seed)
        s_scored = score_partition(spec, s_train, s_test)
        for name, score in s_scored["scores"].items():
            m = compute_metrics(s_scored["y"], s_scored["flags"][name], score)
            for key, value in m.items():
                control.setdefault(name, {}).setdefault([]).append(float(value))
    stratified = {
        name: {k: {"mean": float(np.mean(v)), "std": float(np.std(v, ddof=1)), "values": v}
               for k, v in metrics.items()}
        for name, metrics in control.items()
    }  # fmt: skip
    return {
        "partitions": {
            "train": describe(train),
            "validation": describe(val),
            "test": describe(test),
        },
        "chronological": chrono,
        "stratified": stratified,
        "drift_control": monitor_control(train, val, test, DRIFT_COLUMNS),
        "settings": {
            "seeds": list(seeds),
            "block_seconds": BLOCK_SECONDS,
            "resamples": RESAMPLES,
            "bootstrap_seed": BOOTSTRAP_SEED,
            "window_size": WINDOW_SIZE,
            "deltas": list(DELTAS),
            "ratios": list(config.SPLIT_RATIOS),
        },
    }


def x_run__mutmut_74(spec: DatasetSpec, seeds=config.BENCHMARK_SEEDS) -> dict[str, Any]:
    frame = load(spec)
    train, val, test = chronological_partitions(frame)
    scored = score_partition(spec, train, test)
    chrono = {}
    for name, score in scored["scores"].items():
        metrics = compute_metrics(scored["y"], scored["flags"][name], score)
        ci = block_bootstrap_ci(
            scored["y"], score, test[TIME_UTC], BLOCK_SECONDS, RESAMPLES, BOOTSTRAP_SEED
        )
        chrono[name] = {**metrics, "pr_auc_ci": ci}
    control: dict[str, dict[str, list[float]]] = {}
    for seed in seeds:
        s_train, _s_val, s_test = stratified_partitions(frame, seed)
        s_scored = score_partition(spec, s_train, s_test)
        for name, score in s_scored["scores"].items():
            m = compute_metrics(s_scored["y"], s_scored["flags"][name], score)
            for key, value in m.items():
                control.setdefault(name, {}).setdefault(key, ).append(float(value))
    stratified = {
        name: {k: {"mean": float(np.mean(v)), "std": float(np.std(v, ddof=1)), "values": v}
               for k, v in metrics.items()}
        for name, metrics in control.items()
    }  # fmt: skip
    return {
        "partitions": {
            "train": describe(train),
            "validation": describe(val),
            "test": describe(test),
        },
        "chronological": chrono,
        "stratified": stratified,
        "drift_control": monitor_control(train, val, test, DRIFT_COLUMNS),
        "settings": {
            "seeds": list(seeds),
            "block_seconds": BLOCK_SECONDS,
            "resamples": RESAMPLES,
            "bootstrap_seed": BOOTSTRAP_SEED,
            "window_size": WINDOW_SIZE,
            "deltas": list(DELTAS),
            "ratios": list(config.SPLIT_RATIOS),
        },
    }


def x_run__mutmut_75(spec: DatasetSpec, seeds=config.BENCHMARK_SEEDS) -> dict[str, Any]:
    frame = load(spec)
    train, val, test = chronological_partitions(frame)
    scored = score_partition(spec, train, test)
    chrono = {}
    for name, score in scored["scores"].items():
        metrics = compute_metrics(scored["y"], scored["flags"][name], score)
        ci = block_bootstrap_ci(
            scored["y"], score, test[TIME_UTC], BLOCK_SECONDS, RESAMPLES, BOOTSTRAP_SEED
        )
        chrono[name] = {**metrics, "pr_auc_ci": ci}
    control: dict[str, dict[str, list[float]]] = {}
    for seed in seeds:
        s_train, _s_val, s_test = stratified_partitions(frame, seed)
        s_scored = score_partition(spec, s_train, s_test)
        for name, score in s_scored["scores"].items():
            m = compute_metrics(s_scored["y"], s_scored["flags"][name], score)
            for key, value in m.items():
                control.setdefault(None, {}).setdefault(key, []).append(float(value))
    stratified = {
        name: {k: {"mean": float(np.mean(v)), "std": float(np.std(v, ddof=1)), "values": v}
               for k, v in metrics.items()}
        for name, metrics in control.items()
    }  # fmt: skip
    return {
        "partitions": {
            "train": describe(train),
            "validation": describe(val),
            "test": describe(test),
        },
        "chronological": chrono,
        "stratified": stratified,
        "drift_control": monitor_control(train, val, test, DRIFT_COLUMNS),
        "settings": {
            "seeds": list(seeds),
            "block_seconds": BLOCK_SECONDS,
            "resamples": RESAMPLES,
            "bootstrap_seed": BOOTSTRAP_SEED,
            "window_size": WINDOW_SIZE,
            "deltas": list(DELTAS),
            "ratios": list(config.SPLIT_RATIOS),
        },
    }


def x_run__mutmut_76(spec: DatasetSpec, seeds=config.BENCHMARK_SEEDS) -> dict[str, Any]:
    frame = load(spec)
    train, val, test = chronological_partitions(frame)
    scored = score_partition(spec, train, test)
    chrono = {}
    for name, score in scored["scores"].items():
        metrics = compute_metrics(scored["y"], scored["flags"][name], score)
        ci = block_bootstrap_ci(
            scored["y"], score, test[TIME_UTC], BLOCK_SECONDS, RESAMPLES, BOOTSTRAP_SEED
        )
        chrono[name] = {**metrics, "pr_auc_ci": ci}
    control: dict[str, dict[str, list[float]]] = {}
    for seed in seeds:
        s_train, _s_val, s_test = stratified_partitions(frame, seed)
        s_scored = score_partition(spec, s_train, s_test)
        for name, score in s_scored["scores"].items():
            m = compute_metrics(s_scored["y"], s_scored["flags"][name], score)
            for key, value in m.items():
                control.setdefault(name, None).setdefault(key, []).append(float(value))
    stratified = {
        name: {k: {"mean": float(np.mean(v)), "std": float(np.std(v, ddof=1)), "values": v}
               for k, v in metrics.items()}
        for name, metrics in control.items()
    }  # fmt: skip
    return {
        "partitions": {
            "train": describe(train),
            "validation": describe(val),
            "test": describe(test),
        },
        "chronological": chrono,
        "stratified": stratified,
        "drift_control": monitor_control(train, val, test, DRIFT_COLUMNS),
        "settings": {
            "seeds": list(seeds),
            "block_seconds": BLOCK_SECONDS,
            "resamples": RESAMPLES,
            "bootstrap_seed": BOOTSTRAP_SEED,
            "window_size": WINDOW_SIZE,
            "deltas": list(DELTAS),
            "ratios": list(config.SPLIT_RATIOS),
        },
    }


def x_run__mutmut_77(spec: DatasetSpec, seeds=config.BENCHMARK_SEEDS) -> dict[str, Any]:
    frame = load(spec)
    train, val, test = chronological_partitions(frame)
    scored = score_partition(spec, train, test)
    chrono = {}
    for name, score in scored["scores"].items():
        metrics = compute_metrics(scored["y"], scored["flags"][name], score)
        ci = block_bootstrap_ci(
            scored["y"], score, test[TIME_UTC], BLOCK_SECONDS, RESAMPLES, BOOTSTRAP_SEED
        )
        chrono[name] = {**metrics, "pr_auc_ci": ci}
    control: dict[str, dict[str, list[float]]] = {}
    for seed in seeds:
        s_train, _s_val, s_test = stratified_partitions(frame, seed)
        s_scored = score_partition(spec, s_train, s_test)
        for name, score in s_scored["scores"].items():
            m = compute_metrics(s_scored["y"], s_scored["flags"][name], score)
            for key, value in m.items():
                control.setdefault({}).setdefault(key, []).append(float(value))
    stratified = {
        name: {k: {"mean": float(np.mean(v)), "std": float(np.std(v, ddof=1)), "values": v}
               for k, v in metrics.items()}
        for name, metrics in control.items()
    }  # fmt: skip
    return {
        "partitions": {
            "train": describe(train),
            "validation": describe(val),
            "test": describe(test),
        },
        "chronological": chrono,
        "stratified": stratified,
        "drift_control": monitor_control(train, val, test, DRIFT_COLUMNS),
        "settings": {
            "seeds": list(seeds),
            "block_seconds": BLOCK_SECONDS,
            "resamples": RESAMPLES,
            "bootstrap_seed": BOOTSTRAP_SEED,
            "window_size": WINDOW_SIZE,
            "deltas": list(DELTAS),
            "ratios": list(config.SPLIT_RATIOS),
        },
    }


def x_run__mutmut_78(spec: DatasetSpec, seeds=config.BENCHMARK_SEEDS) -> dict[str, Any]:
    frame = load(spec)
    train, val, test = chronological_partitions(frame)
    scored = score_partition(spec, train, test)
    chrono = {}
    for name, score in scored["scores"].items():
        metrics = compute_metrics(scored["y"], scored["flags"][name], score)
        ci = block_bootstrap_ci(
            scored["y"], score, test[TIME_UTC], BLOCK_SECONDS, RESAMPLES, BOOTSTRAP_SEED
        )
        chrono[name] = {**metrics, "pr_auc_ci": ci}
    control: dict[str, dict[str, list[float]]] = {}
    for seed in seeds:
        s_train, _s_val, s_test = stratified_partitions(frame, seed)
        s_scored = score_partition(spec, s_train, s_test)
        for name, score in s_scored["scores"].items():
            m = compute_metrics(s_scored["y"], s_scored["flags"][name], score)
            for key, value in m.items():
                control.setdefault(name, ).setdefault(key, []).append(float(value))
    stratified = {
        name: {k: {"mean": float(np.mean(v)), "std": float(np.std(v, ddof=1)), "values": v}
               for k, v in metrics.items()}
        for name, metrics in control.items()
    }  # fmt: skip
    return {
        "partitions": {
            "train": describe(train),
            "validation": describe(val),
            "test": describe(test),
        },
        "chronological": chrono,
        "stratified": stratified,
        "drift_control": monitor_control(train, val, test, DRIFT_COLUMNS),
        "settings": {
            "seeds": list(seeds),
            "block_seconds": BLOCK_SECONDS,
            "resamples": RESAMPLES,
            "bootstrap_seed": BOOTSTRAP_SEED,
            "window_size": WINDOW_SIZE,
            "deltas": list(DELTAS),
            "ratios": list(config.SPLIT_RATIOS),
        },
    }


def x_run__mutmut_79(spec: DatasetSpec, seeds=config.BENCHMARK_SEEDS) -> dict[str, Any]:
    frame = load(spec)
    train, val, test = chronological_partitions(frame)
    scored = score_partition(spec, train, test)
    chrono = {}
    for name, score in scored["scores"].items():
        metrics = compute_metrics(scored["y"], scored["flags"][name], score)
        ci = block_bootstrap_ci(
            scored["y"], score, test[TIME_UTC], BLOCK_SECONDS, RESAMPLES, BOOTSTRAP_SEED
        )
        chrono[name] = {**metrics, "pr_auc_ci": ci}
    control: dict[str, dict[str, list[float]]] = {}
    for seed in seeds:
        s_train, _s_val, s_test = stratified_partitions(frame, seed)
        s_scored = score_partition(spec, s_train, s_test)
        for name, score in s_scored["scores"].items():
            m = compute_metrics(s_scored["y"], s_scored["flags"][name], score)
            for key, value in m.items():
                control.setdefault(name, {}).setdefault(key, []).append(float(None))
    stratified = {
        name: {k: {"mean": float(np.mean(v)), "std": float(np.std(v, ddof=1)), "values": v}
               for k, v in metrics.items()}
        for name, metrics in control.items()
    }  # fmt: skip
    return {
        "partitions": {
            "train": describe(train),
            "validation": describe(val),
            "test": describe(test),
        },
        "chronological": chrono,
        "stratified": stratified,
        "drift_control": monitor_control(train, val, test, DRIFT_COLUMNS),
        "settings": {
            "seeds": list(seeds),
            "block_seconds": BLOCK_SECONDS,
            "resamples": RESAMPLES,
            "bootstrap_seed": BOOTSTRAP_SEED,
            "window_size": WINDOW_SIZE,
            "deltas": list(DELTAS),
            "ratios": list(config.SPLIT_RATIOS),
        },
    }


def x_run__mutmut_80(spec: DatasetSpec, seeds=config.BENCHMARK_SEEDS) -> dict[str, Any]:
    frame = load(spec)
    train, val, test = chronological_partitions(frame)
    scored = score_partition(spec, train, test)
    chrono = {}
    for name, score in scored["scores"].items():
        metrics = compute_metrics(scored["y"], scored["flags"][name], score)
        ci = block_bootstrap_ci(
            scored["y"], score, test[TIME_UTC], BLOCK_SECONDS, RESAMPLES, BOOTSTRAP_SEED
        )
        chrono[name] = {**metrics, "pr_auc_ci": ci}
    control: dict[str, dict[str, list[float]]] = {}
    for seed in seeds:
        s_train, _s_val, s_test = stratified_partitions(frame, seed)
        s_scored = score_partition(spec, s_train, s_test)
        for name, score in s_scored["scores"].items():
            m = compute_metrics(s_scored["y"], s_scored["flags"][name], score)
            for key, value in m.items():
                control.setdefault(name, {}).setdefault(key, []).append(float(value))
    stratified = None  # fmt: skip
    return {
        "partitions": {
            "train": describe(train),
            "validation": describe(val),
            "test": describe(test),
        },
        "chronological": chrono,
        "stratified": stratified,
        "drift_control": monitor_control(train, val, test, DRIFT_COLUMNS),
        "settings": {
            "seeds": list(seeds),
            "block_seconds": BLOCK_SECONDS,
            "resamples": RESAMPLES,
            "bootstrap_seed": BOOTSTRAP_SEED,
            "window_size": WINDOW_SIZE,
            "deltas": list(DELTAS),
            "ratios": list(config.SPLIT_RATIOS),
        },
    }


def x_run__mutmut_81(spec: DatasetSpec, seeds=config.BENCHMARK_SEEDS) -> dict[str, Any]:
    frame = load(spec)
    train, val, test = chronological_partitions(frame)
    scored = score_partition(spec, train, test)
    chrono = {}
    for name, score in scored["scores"].items():
        metrics = compute_metrics(scored["y"], scored["flags"][name], score)
        ci = block_bootstrap_ci(
            scored["y"], score, test[TIME_UTC], BLOCK_SECONDS, RESAMPLES, BOOTSTRAP_SEED
        )
        chrono[name] = {**metrics, "pr_auc_ci": ci}
    control: dict[str, dict[str, list[float]]] = {}
    for seed in seeds:
        s_train, _s_val, s_test = stratified_partitions(frame, seed)
        s_scored = score_partition(spec, s_train, s_test)
        for name, score in s_scored["scores"].items():
            m = compute_metrics(s_scored["y"], s_scored["flags"][name], score)
            for key, value in m.items():
                control.setdefault(name, {}).setdefault(key, []).append(float(value))
    stratified = {
        name: {k: {"XXmeanXX": float(np.mean(v)), "std": float(np.std(v, ddof=1)), "values": v}
               for k, v in metrics.items()}
        for name, metrics in control.items()
    }  # fmt: skip
    return {
        "partitions": {
            "train": describe(train),
            "validation": describe(val),
            "test": describe(test),
        },
        "chronological": chrono,
        "stratified": stratified,
        "drift_control": monitor_control(train, val, test, DRIFT_COLUMNS),
        "settings": {
            "seeds": list(seeds),
            "block_seconds": BLOCK_SECONDS,
            "resamples": RESAMPLES,
            "bootstrap_seed": BOOTSTRAP_SEED,
            "window_size": WINDOW_SIZE,
            "deltas": list(DELTAS),
            "ratios": list(config.SPLIT_RATIOS),
        },
    }


def x_run__mutmut_82(spec: DatasetSpec, seeds=config.BENCHMARK_SEEDS) -> dict[str, Any]:
    frame = load(spec)
    train, val, test = chronological_partitions(frame)
    scored = score_partition(spec, train, test)
    chrono = {}
    for name, score in scored["scores"].items():
        metrics = compute_metrics(scored["y"], scored["flags"][name], score)
        ci = block_bootstrap_ci(
            scored["y"], score, test[TIME_UTC], BLOCK_SECONDS, RESAMPLES, BOOTSTRAP_SEED
        )
        chrono[name] = {**metrics, "pr_auc_ci": ci}
    control: dict[str, dict[str, list[float]]] = {}
    for seed in seeds:
        s_train, _s_val, s_test = stratified_partitions(frame, seed)
        s_scored = score_partition(spec, s_train, s_test)
        for name, score in s_scored["scores"].items():
            m = compute_metrics(s_scored["y"], s_scored["flags"][name], score)
            for key, value in m.items():
                control.setdefault(name, {}).setdefault(key, []).append(float(value))
    stratified = {
        name: {k: {"MEAN": float(np.mean(v)), "std": float(np.std(v, ddof=1)), "values": v}
               for k, v in metrics.items()}
        for name, metrics in control.items()
    }  # fmt: skip
    return {
        "partitions": {
            "train": describe(train),
            "validation": describe(val),
            "test": describe(test),
        },
        "chronological": chrono,
        "stratified": stratified,
        "drift_control": monitor_control(train, val, test, DRIFT_COLUMNS),
        "settings": {
            "seeds": list(seeds),
            "block_seconds": BLOCK_SECONDS,
            "resamples": RESAMPLES,
            "bootstrap_seed": BOOTSTRAP_SEED,
            "window_size": WINDOW_SIZE,
            "deltas": list(DELTAS),
            "ratios": list(config.SPLIT_RATIOS),
        },
    }


def x_run__mutmut_83(spec: DatasetSpec, seeds=config.BENCHMARK_SEEDS) -> dict[str, Any]:
    frame = load(spec)
    train, val, test = chronological_partitions(frame)
    scored = score_partition(spec, train, test)
    chrono = {}
    for name, score in scored["scores"].items():
        metrics = compute_metrics(scored["y"], scored["flags"][name], score)
        ci = block_bootstrap_ci(
            scored["y"], score, test[TIME_UTC], BLOCK_SECONDS, RESAMPLES, BOOTSTRAP_SEED
        )
        chrono[name] = {**metrics, "pr_auc_ci": ci}
    control: dict[str, dict[str, list[float]]] = {}
    for seed in seeds:
        s_train, _s_val, s_test = stratified_partitions(frame, seed)
        s_scored = score_partition(spec, s_train, s_test)
        for name, score in s_scored["scores"].items():
            m = compute_metrics(s_scored["y"], s_scored["flags"][name], score)
            for key, value in m.items():
                control.setdefault(name, {}).setdefault(key, []).append(float(value))
    stratified = {
        name: {k: {"mean": float(None), "std": float(np.std(v, ddof=1)), "values": v}
               for k, v in metrics.items()}
        for name, metrics in control.items()
    }  # fmt: skip
    return {
        "partitions": {
            "train": describe(train),
            "validation": describe(val),
            "test": describe(test),
        },
        "chronological": chrono,
        "stratified": stratified,
        "drift_control": monitor_control(train, val, test, DRIFT_COLUMNS),
        "settings": {
            "seeds": list(seeds),
            "block_seconds": BLOCK_SECONDS,
            "resamples": RESAMPLES,
            "bootstrap_seed": BOOTSTRAP_SEED,
            "window_size": WINDOW_SIZE,
            "deltas": list(DELTAS),
            "ratios": list(config.SPLIT_RATIOS),
        },
    }


def x_run__mutmut_84(spec: DatasetSpec, seeds=config.BENCHMARK_SEEDS) -> dict[str, Any]:
    frame = load(spec)
    train, val, test = chronological_partitions(frame)
    scored = score_partition(spec, train, test)
    chrono = {}
    for name, score in scored["scores"].items():
        metrics = compute_metrics(scored["y"], scored["flags"][name], score)
        ci = block_bootstrap_ci(
            scored["y"], score, test[TIME_UTC], BLOCK_SECONDS, RESAMPLES, BOOTSTRAP_SEED
        )
        chrono[name] = {**metrics, "pr_auc_ci": ci}
    control: dict[str, dict[str, list[float]]] = {}
    for seed in seeds:
        s_train, _s_val, s_test = stratified_partitions(frame, seed)
        s_scored = score_partition(spec, s_train, s_test)
        for name, score in s_scored["scores"].items():
            m = compute_metrics(s_scored["y"], s_scored["flags"][name], score)
            for key, value in m.items():
                control.setdefault(name, {}).setdefault(key, []).append(float(value))
    stratified = {
        name: {k: {"mean": float(np.mean(None)), "std": float(np.std(v, ddof=1)), "values": v}
               for k, v in metrics.items()}
        for name, metrics in control.items()
    }  # fmt: skip
    return {
        "partitions": {
            "train": describe(train),
            "validation": describe(val),
            "test": describe(test),
        },
        "chronological": chrono,
        "stratified": stratified,
        "drift_control": monitor_control(train, val, test, DRIFT_COLUMNS),
        "settings": {
            "seeds": list(seeds),
            "block_seconds": BLOCK_SECONDS,
            "resamples": RESAMPLES,
            "bootstrap_seed": BOOTSTRAP_SEED,
            "window_size": WINDOW_SIZE,
            "deltas": list(DELTAS),
            "ratios": list(config.SPLIT_RATIOS),
        },
    }


def x_run__mutmut_85(spec: DatasetSpec, seeds=config.BENCHMARK_SEEDS) -> dict[str, Any]:
    frame = load(spec)
    train, val, test = chronological_partitions(frame)
    scored = score_partition(spec, train, test)
    chrono = {}
    for name, score in scored["scores"].items():
        metrics = compute_metrics(scored["y"], scored["flags"][name], score)
        ci = block_bootstrap_ci(
            scored["y"], score, test[TIME_UTC], BLOCK_SECONDS, RESAMPLES, BOOTSTRAP_SEED
        )
        chrono[name] = {**metrics, "pr_auc_ci": ci}
    control: dict[str, dict[str, list[float]]] = {}
    for seed in seeds:
        s_train, _s_val, s_test = stratified_partitions(frame, seed)
        s_scored = score_partition(spec, s_train, s_test)
        for name, score in s_scored["scores"].items():
            m = compute_metrics(s_scored["y"], s_scored["flags"][name], score)
            for key, value in m.items():
                control.setdefault(name, {}).setdefault(key, []).append(float(value))
    stratified = {
        name: {k: {"mean": float(np.mean(v)), "XXstdXX": float(np.std(v, ddof=1)), "values": v}
               for k, v in metrics.items()}
        for name, metrics in control.items()
    }  # fmt: skip
    return {
        "partitions": {
            "train": describe(train),
            "validation": describe(val),
            "test": describe(test),
        },
        "chronological": chrono,
        "stratified": stratified,
        "drift_control": monitor_control(train, val, test, DRIFT_COLUMNS),
        "settings": {
            "seeds": list(seeds),
            "block_seconds": BLOCK_SECONDS,
            "resamples": RESAMPLES,
            "bootstrap_seed": BOOTSTRAP_SEED,
            "window_size": WINDOW_SIZE,
            "deltas": list(DELTAS),
            "ratios": list(config.SPLIT_RATIOS),
        },
    }


def x_run__mutmut_86(spec: DatasetSpec, seeds=config.BENCHMARK_SEEDS) -> dict[str, Any]:
    frame = load(spec)
    train, val, test = chronological_partitions(frame)
    scored = score_partition(spec, train, test)
    chrono = {}
    for name, score in scored["scores"].items():
        metrics = compute_metrics(scored["y"], scored["flags"][name], score)
        ci = block_bootstrap_ci(
            scored["y"], score, test[TIME_UTC], BLOCK_SECONDS, RESAMPLES, BOOTSTRAP_SEED
        )
        chrono[name] = {**metrics, "pr_auc_ci": ci}
    control: dict[str, dict[str, list[float]]] = {}
    for seed in seeds:
        s_train, _s_val, s_test = stratified_partitions(frame, seed)
        s_scored = score_partition(spec, s_train, s_test)
        for name, score in s_scored["scores"].items():
            m = compute_metrics(s_scored["y"], s_scored["flags"][name], score)
            for key, value in m.items():
                control.setdefault(name, {}).setdefault(key, []).append(float(value))
    stratified = {
        name: {k: {"mean": float(np.mean(v)), "STD": float(np.std(v, ddof=1)), "values": v}
               for k, v in metrics.items()}
        for name, metrics in control.items()
    }  # fmt: skip
    return {
        "partitions": {
            "train": describe(train),
            "validation": describe(val),
            "test": describe(test),
        },
        "chronological": chrono,
        "stratified": stratified,
        "drift_control": monitor_control(train, val, test, DRIFT_COLUMNS),
        "settings": {
            "seeds": list(seeds),
            "block_seconds": BLOCK_SECONDS,
            "resamples": RESAMPLES,
            "bootstrap_seed": BOOTSTRAP_SEED,
            "window_size": WINDOW_SIZE,
            "deltas": list(DELTAS),
            "ratios": list(config.SPLIT_RATIOS),
        },
    }


def x_run__mutmut_87(spec: DatasetSpec, seeds=config.BENCHMARK_SEEDS) -> dict[str, Any]:
    frame = load(spec)
    train, val, test = chronological_partitions(frame)
    scored = score_partition(spec, train, test)
    chrono = {}
    for name, score in scored["scores"].items():
        metrics = compute_metrics(scored["y"], scored["flags"][name], score)
        ci = block_bootstrap_ci(
            scored["y"], score, test[TIME_UTC], BLOCK_SECONDS, RESAMPLES, BOOTSTRAP_SEED
        )
        chrono[name] = {**metrics, "pr_auc_ci": ci}
    control: dict[str, dict[str, list[float]]] = {}
    for seed in seeds:
        s_train, _s_val, s_test = stratified_partitions(frame, seed)
        s_scored = score_partition(spec, s_train, s_test)
        for name, score in s_scored["scores"].items():
            m = compute_metrics(s_scored["y"], s_scored["flags"][name], score)
            for key, value in m.items():
                control.setdefault(name, {}).setdefault(key, []).append(float(value))
    stratified = {
        name: {k: {"mean": float(np.mean(v)), "std": float(None), "values": v}
               for k, v in metrics.items()}
        for name, metrics in control.items()
    }  # fmt: skip
    return {
        "partitions": {
            "train": describe(train),
            "validation": describe(val),
            "test": describe(test),
        },
        "chronological": chrono,
        "stratified": stratified,
        "drift_control": monitor_control(train, val, test, DRIFT_COLUMNS),
        "settings": {
            "seeds": list(seeds),
            "block_seconds": BLOCK_SECONDS,
            "resamples": RESAMPLES,
            "bootstrap_seed": BOOTSTRAP_SEED,
            "window_size": WINDOW_SIZE,
            "deltas": list(DELTAS),
            "ratios": list(config.SPLIT_RATIOS),
        },
    }


def x_run__mutmut_88(spec: DatasetSpec, seeds=config.BENCHMARK_SEEDS) -> dict[str, Any]:
    frame = load(spec)
    train, val, test = chronological_partitions(frame)
    scored = score_partition(spec, train, test)
    chrono = {}
    for name, score in scored["scores"].items():
        metrics = compute_metrics(scored["y"], scored["flags"][name], score)
        ci = block_bootstrap_ci(
            scored["y"], score, test[TIME_UTC], BLOCK_SECONDS, RESAMPLES, BOOTSTRAP_SEED
        )
        chrono[name] = {**metrics, "pr_auc_ci": ci}
    control: dict[str, dict[str, list[float]]] = {}
    for seed in seeds:
        s_train, _s_val, s_test = stratified_partitions(frame, seed)
        s_scored = score_partition(spec, s_train, s_test)
        for name, score in s_scored["scores"].items():
            m = compute_metrics(s_scored["y"], s_scored["flags"][name], score)
            for key, value in m.items():
                control.setdefault(name, {}).setdefault(key, []).append(float(value))
    stratified = {
        name: {k: {"mean": float(np.mean(v)), "std": float(np.std(None, ddof=1)), "values": v}
               for k, v in metrics.items()}
        for name, metrics in control.items()
    }  # fmt: skip
    return {
        "partitions": {
            "train": describe(train),
            "validation": describe(val),
            "test": describe(test),
        },
        "chronological": chrono,
        "stratified": stratified,
        "drift_control": monitor_control(train, val, test, DRIFT_COLUMNS),
        "settings": {
            "seeds": list(seeds),
            "block_seconds": BLOCK_SECONDS,
            "resamples": RESAMPLES,
            "bootstrap_seed": BOOTSTRAP_SEED,
            "window_size": WINDOW_SIZE,
            "deltas": list(DELTAS),
            "ratios": list(config.SPLIT_RATIOS),
        },
    }


def x_run__mutmut_89(spec: DatasetSpec, seeds=config.BENCHMARK_SEEDS) -> dict[str, Any]:
    frame = load(spec)
    train, val, test = chronological_partitions(frame)
    scored = score_partition(spec, train, test)
    chrono = {}
    for name, score in scored["scores"].items():
        metrics = compute_metrics(scored["y"], scored["flags"][name], score)
        ci = block_bootstrap_ci(
            scored["y"], score, test[TIME_UTC], BLOCK_SECONDS, RESAMPLES, BOOTSTRAP_SEED
        )
        chrono[name] = {**metrics, "pr_auc_ci": ci}
    control: dict[str, dict[str, list[float]]] = {}
    for seed in seeds:
        s_train, _s_val, s_test = stratified_partitions(frame, seed)
        s_scored = score_partition(spec, s_train, s_test)
        for name, score in s_scored["scores"].items():
            m = compute_metrics(s_scored["y"], s_scored["flags"][name], score)
            for key, value in m.items():
                control.setdefault(name, {}).setdefault(key, []).append(float(value))
    stratified = {
        name: {k: {"mean": float(np.mean(v)), "std": float(np.std(v, ddof=None)), "values": v}
               for k, v in metrics.items()}
        for name, metrics in control.items()
    }  # fmt: skip
    return {
        "partitions": {
            "train": describe(train),
            "validation": describe(val),
            "test": describe(test),
        },
        "chronological": chrono,
        "stratified": stratified,
        "drift_control": monitor_control(train, val, test, DRIFT_COLUMNS),
        "settings": {
            "seeds": list(seeds),
            "block_seconds": BLOCK_SECONDS,
            "resamples": RESAMPLES,
            "bootstrap_seed": BOOTSTRAP_SEED,
            "window_size": WINDOW_SIZE,
            "deltas": list(DELTAS),
            "ratios": list(config.SPLIT_RATIOS),
        },
    }


def x_run__mutmut_90(spec: DatasetSpec, seeds=config.BENCHMARK_SEEDS) -> dict[str, Any]:
    frame = load(spec)
    train, val, test = chronological_partitions(frame)
    scored = score_partition(spec, train, test)
    chrono = {}
    for name, score in scored["scores"].items():
        metrics = compute_metrics(scored["y"], scored["flags"][name], score)
        ci = block_bootstrap_ci(
            scored["y"], score, test[TIME_UTC], BLOCK_SECONDS, RESAMPLES, BOOTSTRAP_SEED
        )
        chrono[name] = {**metrics, "pr_auc_ci": ci}
    control: dict[str, dict[str, list[float]]] = {}
    for seed in seeds:
        s_train, _s_val, s_test = stratified_partitions(frame, seed)
        s_scored = score_partition(spec, s_train, s_test)
        for name, score in s_scored["scores"].items():
            m = compute_metrics(s_scored["y"], s_scored["flags"][name], score)
            for key, value in m.items():
                control.setdefault(name, {}).setdefault(key, []).append(float(value))
    stratified = {
        name: {k: {"mean": float(np.mean(v)), "std": float(np.std(ddof=1)), "values": v}
               for k, v in metrics.items()}
        for name, metrics in control.items()
    }  # fmt: skip
    return {
        "partitions": {
            "train": describe(train),
            "validation": describe(val),
            "test": describe(test),
        },
        "chronological": chrono,
        "stratified": stratified,
        "drift_control": monitor_control(train, val, test, DRIFT_COLUMNS),
        "settings": {
            "seeds": list(seeds),
            "block_seconds": BLOCK_SECONDS,
            "resamples": RESAMPLES,
            "bootstrap_seed": BOOTSTRAP_SEED,
            "window_size": WINDOW_SIZE,
            "deltas": list(DELTAS),
            "ratios": list(config.SPLIT_RATIOS),
        },
    }


def x_run__mutmut_91(spec: DatasetSpec, seeds=config.BENCHMARK_SEEDS) -> dict[str, Any]:
    frame = load(spec)
    train, val, test = chronological_partitions(frame)
    scored = score_partition(spec, train, test)
    chrono = {}
    for name, score in scored["scores"].items():
        metrics = compute_metrics(scored["y"], scored["flags"][name], score)
        ci = block_bootstrap_ci(
            scored["y"], score, test[TIME_UTC], BLOCK_SECONDS, RESAMPLES, BOOTSTRAP_SEED
        )
        chrono[name] = {**metrics, "pr_auc_ci": ci}
    control: dict[str, dict[str, list[float]]] = {}
    for seed in seeds:
        s_train, _s_val, s_test = stratified_partitions(frame, seed)
        s_scored = score_partition(spec, s_train, s_test)
        for name, score in s_scored["scores"].items():
            m = compute_metrics(s_scored["y"], s_scored["flags"][name], score)
            for key, value in m.items():
                control.setdefault(name, {}).setdefault(key, []).append(float(value))
    stratified = {
        name: {k: {"mean": float(np.mean(v)), "std": float(np.std(v, )), "values": v}
               for k, v in metrics.items()}
        for name, metrics in control.items()
    }  # fmt: skip
    return {
        "partitions": {
            "train": describe(train),
            "validation": describe(val),
            "test": describe(test),
        },
        "chronological": chrono,
        "stratified": stratified,
        "drift_control": monitor_control(train, val, test, DRIFT_COLUMNS),
        "settings": {
            "seeds": list(seeds),
            "block_seconds": BLOCK_SECONDS,
            "resamples": RESAMPLES,
            "bootstrap_seed": BOOTSTRAP_SEED,
            "window_size": WINDOW_SIZE,
            "deltas": list(DELTAS),
            "ratios": list(config.SPLIT_RATIOS),
        },
    }


def x_run__mutmut_92(spec: DatasetSpec, seeds=config.BENCHMARK_SEEDS) -> dict[str, Any]:
    frame = load(spec)
    train, val, test = chronological_partitions(frame)
    scored = score_partition(spec, train, test)
    chrono = {}
    for name, score in scored["scores"].items():
        metrics = compute_metrics(scored["y"], scored["flags"][name], score)
        ci = block_bootstrap_ci(
            scored["y"], score, test[TIME_UTC], BLOCK_SECONDS, RESAMPLES, BOOTSTRAP_SEED
        )
        chrono[name] = {**metrics, "pr_auc_ci": ci}
    control: dict[str, dict[str, list[float]]] = {}
    for seed in seeds:
        s_train, _s_val, s_test = stratified_partitions(frame, seed)
        s_scored = score_partition(spec, s_train, s_test)
        for name, score in s_scored["scores"].items():
            m = compute_metrics(s_scored["y"], s_scored["flags"][name], score)
            for key, value in m.items():
                control.setdefault(name, {}).setdefault(key, []).append(float(value))
    stratified = {
        name: {k: {"mean": float(np.mean(v)), "std": float(np.std(v, ddof=2)), "values": v}
               for k, v in metrics.items()}
        for name, metrics in control.items()
    }  # fmt: skip
    return {
        "partitions": {
            "train": describe(train),
            "validation": describe(val),
            "test": describe(test),
        },
        "chronological": chrono,
        "stratified": stratified,
        "drift_control": monitor_control(train, val, test, DRIFT_COLUMNS),
        "settings": {
            "seeds": list(seeds),
            "block_seconds": BLOCK_SECONDS,
            "resamples": RESAMPLES,
            "bootstrap_seed": BOOTSTRAP_SEED,
            "window_size": WINDOW_SIZE,
            "deltas": list(DELTAS),
            "ratios": list(config.SPLIT_RATIOS),
        },
    }


def x_run__mutmut_93(spec: DatasetSpec, seeds=config.BENCHMARK_SEEDS) -> dict[str, Any]:
    frame = load(spec)
    train, val, test = chronological_partitions(frame)
    scored = score_partition(spec, train, test)
    chrono = {}
    for name, score in scored["scores"].items():
        metrics = compute_metrics(scored["y"], scored["flags"][name], score)
        ci = block_bootstrap_ci(
            scored["y"], score, test[TIME_UTC], BLOCK_SECONDS, RESAMPLES, BOOTSTRAP_SEED
        )
        chrono[name] = {**metrics, "pr_auc_ci": ci}
    control: dict[str, dict[str, list[float]]] = {}
    for seed in seeds:
        s_train, _s_val, s_test = stratified_partitions(frame, seed)
        s_scored = score_partition(spec, s_train, s_test)
        for name, score in s_scored["scores"].items():
            m = compute_metrics(s_scored["y"], s_scored["flags"][name], score)
            for key, value in m.items():
                control.setdefault(name, {}).setdefault(key, []).append(float(value))
    stratified = {
        name: {k: {"mean": float(np.mean(v)), "std": float(np.std(v, ddof=1)), "XXvaluesXX": v}
               for k, v in metrics.items()}
        for name, metrics in control.items()
    }  # fmt: skip
    return {
        "partitions": {
            "train": describe(train),
            "validation": describe(val),
            "test": describe(test),
        },
        "chronological": chrono,
        "stratified": stratified,
        "drift_control": monitor_control(train, val, test, DRIFT_COLUMNS),
        "settings": {
            "seeds": list(seeds),
            "block_seconds": BLOCK_SECONDS,
            "resamples": RESAMPLES,
            "bootstrap_seed": BOOTSTRAP_SEED,
            "window_size": WINDOW_SIZE,
            "deltas": list(DELTAS),
            "ratios": list(config.SPLIT_RATIOS),
        },
    }


def x_run__mutmut_94(spec: DatasetSpec, seeds=config.BENCHMARK_SEEDS) -> dict[str, Any]:
    frame = load(spec)
    train, val, test = chronological_partitions(frame)
    scored = score_partition(spec, train, test)
    chrono = {}
    for name, score in scored["scores"].items():
        metrics = compute_metrics(scored["y"], scored["flags"][name], score)
        ci = block_bootstrap_ci(
            scored["y"], score, test[TIME_UTC], BLOCK_SECONDS, RESAMPLES, BOOTSTRAP_SEED
        )
        chrono[name] = {**metrics, "pr_auc_ci": ci}
    control: dict[str, dict[str, list[float]]] = {}
    for seed in seeds:
        s_train, _s_val, s_test = stratified_partitions(frame, seed)
        s_scored = score_partition(spec, s_train, s_test)
        for name, score in s_scored["scores"].items():
            m = compute_metrics(s_scored["y"], s_scored["flags"][name], score)
            for key, value in m.items():
                control.setdefault(name, {}).setdefault(key, []).append(float(value))
    stratified = {
        name: {k: {"mean": float(np.mean(v)), "std": float(np.std(v, ddof=1)), "VALUES": v}
               for k, v in metrics.items()}
        for name, metrics in control.items()
    }  # fmt: skip
    return {
        "partitions": {
            "train": describe(train),
            "validation": describe(val),
            "test": describe(test),
        },
        "chronological": chrono,
        "stratified": stratified,
        "drift_control": monitor_control(train, val, test, DRIFT_COLUMNS),
        "settings": {
            "seeds": list(seeds),
            "block_seconds": BLOCK_SECONDS,
            "resamples": RESAMPLES,
            "bootstrap_seed": BOOTSTRAP_SEED,
            "window_size": WINDOW_SIZE,
            "deltas": list(DELTAS),
            "ratios": list(config.SPLIT_RATIOS),
        },
    }


def x_run__mutmut_95(spec: DatasetSpec, seeds=config.BENCHMARK_SEEDS) -> dict[str, Any]:
    frame = load(spec)
    train, val, test = chronological_partitions(frame)
    scored = score_partition(spec, train, test)
    chrono = {}
    for name, score in scored["scores"].items():
        metrics = compute_metrics(scored["y"], scored["flags"][name], score)
        ci = block_bootstrap_ci(
            scored["y"], score, test[TIME_UTC], BLOCK_SECONDS, RESAMPLES, BOOTSTRAP_SEED
        )
        chrono[name] = {**metrics, "pr_auc_ci": ci}
    control: dict[str, dict[str, list[float]]] = {}
    for seed in seeds:
        s_train, _s_val, s_test = stratified_partitions(frame, seed)
        s_scored = score_partition(spec, s_train, s_test)
        for name, score in s_scored["scores"].items():
            m = compute_metrics(s_scored["y"], s_scored["flags"][name], score)
            for key, value in m.items():
                control.setdefault(name, {}).setdefault(key, []).append(float(value))
    stratified = {
        name: {k: {"mean": float(np.mean(v)), "std": float(np.std(v, ddof=1)), "values": v}
               for k, v in metrics.items()}
        for name, metrics in control.items()
    }  # fmt: skip
    return {
        "XXpartitionsXX": {
            "train": describe(train),
            "validation": describe(val),
            "test": describe(test),
        },
        "chronological": chrono,
        "stratified": stratified,
        "drift_control": monitor_control(train, val, test, DRIFT_COLUMNS),
        "settings": {
            "seeds": list(seeds),
            "block_seconds": BLOCK_SECONDS,
            "resamples": RESAMPLES,
            "bootstrap_seed": BOOTSTRAP_SEED,
            "window_size": WINDOW_SIZE,
            "deltas": list(DELTAS),
            "ratios": list(config.SPLIT_RATIOS),
        },
    }


def x_run__mutmut_96(spec: DatasetSpec, seeds=config.BENCHMARK_SEEDS) -> dict[str, Any]:
    frame = load(spec)
    train, val, test = chronological_partitions(frame)
    scored = score_partition(spec, train, test)
    chrono = {}
    for name, score in scored["scores"].items():
        metrics = compute_metrics(scored["y"], scored["flags"][name], score)
        ci = block_bootstrap_ci(
            scored["y"], score, test[TIME_UTC], BLOCK_SECONDS, RESAMPLES, BOOTSTRAP_SEED
        )
        chrono[name] = {**metrics, "pr_auc_ci": ci}
    control: dict[str, dict[str, list[float]]] = {}
    for seed in seeds:
        s_train, _s_val, s_test = stratified_partitions(frame, seed)
        s_scored = score_partition(spec, s_train, s_test)
        for name, score in s_scored["scores"].items():
            m = compute_metrics(s_scored["y"], s_scored["flags"][name], score)
            for key, value in m.items():
                control.setdefault(name, {}).setdefault(key, []).append(float(value))
    stratified = {
        name: {k: {"mean": float(np.mean(v)), "std": float(np.std(v, ddof=1)), "values": v}
               for k, v in metrics.items()}
        for name, metrics in control.items()
    }  # fmt: skip
    return {
        "PARTITIONS": {
            "train": describe(train),
            "validation": describe(val),
            "test": describe(test),
        },
        "chronological": chrono,
        "stratified": stratified,
        "drift_control": monitor_control(train, val, test, DRIFT_COLUMNS),
        "settings": {
            "seeds": list(seeds),
            "block_seconds": BLOCK_SECONDS,
            "resamples": RESAMPLES,
            "bootstrap_seed": BOOTSTRAP_SEED,
            "window_size": WINDOW_SIZE,
            "deltas": list(DELTAS),
            "ratios": list(config.SPLIT_RATIOS),
        },
    }


def x_run__mutmut_97(spec: DatasetSpec, seeds=config.BENCHMARK_SEEDS) -> dict[str, Any]:
    frame = load(spec)
    train, val, test = chronological_partitions(frame)
    scored = score_partition(spec, train, test)
    chrono = {}
    for name, score in scored["scores"].items():
        metrics = compute_metrics(scored["y"], scored["flags"][name], score)
        ci = block_bootstrap_ci(
            scored["y"], score, test[TIME_UTC], BLOCK_SECONDS, RESAMPLES, BOOTSTRAP_SEED
        )
        chrono[name] = {**metrics, "pr_auc_ci": ci}
    control: dict[str, dict[str, list[float]]] = {}
    for seed in seeds:
        s_train, _s_val, s_test = stratified_partitions(frame, seed)
        s_scored = score_partition(spec, s_train, s_test)
        for name, score in s_scored["scores"].items():
            m = compute_metrics(s_scored["y"], s_scored["flags"][name], score)
            for key, value in m.items():
                control.setdefault(name, {}).setdefault(key, []).append(float(value))
    stratified = {
        name: {k: {"mean": float(np.mean(v)), "std": float(np.std(v, ddof=1)), "values": v}
               for k, v in metrics.items()}
        for name, metrics in control.items()
    }  # fmt: skip
    return {
        "partitions": {
            "XXtrainXX": describe(train),
            "validation": describe(val),
            "test": describe(test),
        },
        "chronological": chrono,
        "stratified": stratified,
        "drift_control": monitor_control(train, val, test, DRIFT_COLUMNS),
        "settings": {
            "seeds": list(seeds),
            "block_seconds": BLOCK_SECONDS,
            "resamples": RESAMPLES,
            "bootstrap_seed": BOOTSTRAP_SEED,
            "window_size": WINDOW_SIZE,
            "deltas": list(DELTAS),
            "ratios": list(config.SPLIT_RATIOS),
        },
    }


def x_run__mutmut_98(spec: DatasetSpec, seeds=config.BENCHMARK_SEEDS) -> dict[str, Any]:
    frame = load(spec)
    train, val, test = chronological_partitions(frame)
    scored = score_partition(spec, train, test)
    chrono = {}
    for name, score in scored["scores"].items():
        metrics = compute_metrics(scored["y"], scored["flags"][name], score)
        ci = block_bootstrap_ci(
            scored["y"], score, test[TIME_UTC], BLOCK_SECONDS, RESAMPLES, BOOTSTRAP_SEED
        )
        chrono[name] = {**metrics, "pr_auc_ci": ci}
    control: dict[str, dict[str, list[float]]] = {}
    for seed in seeds:
        s_train, _s_val, s_test = stratified_partitions(frame, seed)
        s_scored = score_partition(spec, s_train, s_test)
        for name, score in s_scored["scores"].items():
            m = compute_metrics(s_scored["y"], s_scored["flags"][name], score)
            for key, value in m.items():
                control.setdefault(name, {}).setdefault(key, []).append(float(value))
    stratified = {
        name: {k: {"mean": float(np.mean(v)), "std": float(np.std(v, ddof=1)), "values": v}
               for k, v in metrics.items()}
        for name, metrics in control.items()
    }  # fmt: skip
    return {
        "partitions": {
            "TRAIN": describe(train),
            "validation": describe(val),
            "test": describe(test),
        },
        "chronological": chrono,
        "stratified": stratified,
        "drift_control": monitor_control(train, val, test, DRIFT_COLUMNS),
        "settings": {
            "seeds": list(seeds),
            "block_seconds": BLOCK_SECONDS,
            "resamples": RESAMPLES,
            "bootstrap_seed": BOOTSTRAP_SEED,
            "window_size": WINDOW_SIZE,
            "deltas": list(DELTAS),
            "ratios": list(config.SPLIT_RATIOS),
        },
    }


def x_run__mutmut_99(spec: DatasetSpec, seeds=config.BENCHMARK_SEEDS) -> dict[str, Any]:
    frame = load(spec)
    train, val, test = chronological_partitions(frame)
    scored = score_partition(spec, train, test)
    chrono = {}
    for name, score in scored["scores"].items():
        metrics = compute_metrics(scored["y"], scored["flags"][name], score)
        ci = block_bootstrap_ci(
            scored["y"], score, test[TIME_UTC], BLOCK_SECONDS, RESAMPLES, BOOTSTRAP_SEED
        )
        chrono[name] = {**metrics, "pr_auc_ci": ci}
    control: dict[str, dict[str, list[float]]] = {}
    for seed in seeds:
        s_train, _s_val, s_test = stratified_partitions(frame, seed)
        s_scored = score_partition(spec, s_train, s_test)
        for name, score in s_scored["scores"].items():
            m = compute_metrics(s_scored["y"], s_scored["flags"][name], score)
            for key, value in m.items():
                control.setdefault(name, {}).setdefault(key, []).append(float(value))
    stratified = {
        name: {k: {"mean": float(np.mean(v)), "std": float(np.std(v, ddof=1)), "values": v}
               for k, v in metrics.items()}
        for name, metrics in control.items()
    }  # fmt: skip
    return {
        "partitions": {
            "train": describe(None),
            "validation": describe(val),
            "test": describe(test),
        },
        "chronological": chrono,
        "stratified": stratified,
        "drift_control": monitor_control(train, val, test, DRIFT_COLUMNS),
        "settings": {
            "seeds": list(seeds),
            "block_seconds": BLOCK_SECONDS,
            "resamples": RESAMPLES,
            "bootstrap_seed": BOOTSTRAP_SEED,
            "window_size": WINDOW_SIZE,
            "deltas": list(DELTAS),
            "ratios": list(config.SPLIT_RATIOS),
        },
    }


def x_run__mutmut_100(spec: DatasetSpec, seeds=config.BENCHMARK_SEEDS) -> dict[str, Any]:
    frame = load(spec)
    train, val, test = chronological_partitions(frame)
    scored = score_partition(spec, train, test)
    chrono = {}
    for name, score in scored["scores"].items():
        metrics = compute_metrics(scored["y"], scored["flags"][name], score)
        ci = block_bootstrap_ci(
            scored["y"], score, test[TIME_UTC], BLOCK_SECONDS, RESAMPLES, BOOTSTRAP_SEED
        )
        chrono[name] = {**metrics, "pr_auc_ci": ci}
    control: dict[str, dict[str, list[float]]] = {}
    for seed in seeds:
        s_train, _s_val, s_test = stratified_partitions(frame, seed)
        s_scored = score_partition(spec, s_train, s_test)
        for name, score in s_scored["scores"].items():
            m = compute_metrics(s_scored["y"], s_scored["flags"][name], score)
            for key, value in m.items():
                control.setdefault(name, {}).setdefault(key, []).append(float(value))
    stratified = {
        name: {k: {"mean": float(np.mean(v)), "std": float(np.std(v, ddof=1)), "values": v}
               for k, v in metrics.items()}
        for name, metrics in control.items()
    }  # fmt: skip
    return {
        "partitions": {
            "train": describe(train),
            "XXvalidationXX": describe(val),
            "test": describe(test),
        },
        "chronological": chrono,
        "stratified": stratified,
        "drift_control": monitor_control(train, val, test, DRIFT_COLUMNS),
        "settings": {
            "seeds": list(seeds),
            "block_seconds": BLOCK_SECONDS,
            "resamples": RESAMPLES,
            "bootstrap_seed": BOOTSTRAP_SEED,
            "window_size": WINDOW_SIZE,
            "deltas": list(DELTAS),
            "ratios": list(config.SPLIT_RATIOS),
        },
    }


def x_run__mutmut_101(spec: DatasetSpec, seeds=config.BENCHMARK_SEEDS) -> dict[str, Any]:
    frame = load(spec)
    train, val, test = chronological_partitions(frame)
    scored = score_partition(spec, train, test)
    chrono = {}
    for name, score in scored["scores"].items():
        metrics = compute_metrics(scored["y"], scored["flags"][name], score)
        ci = block_bootstrap_ci(
            scored["y"], score, test[TIME_UTC], BLOCK_SECONDS, RESAMPLES, BOOTSTRAP_SEED
        )
        chrono[name] = {**metrics, "pr_auc_ci": ci}
    control: dict[str, dict[str, list[float]]] = {}
    for seed in seeds:
        s_train, _s_val, s_test = stratified_partitions(frame, seed)
        s_scored = score_partition(spec, s_train, s_test)
        for name, score in s_scored["scores"].items():
            m = compute_metrics(s_scored["y"], s_scored["flags"][name], score)
            for key, value in m.items():
                control.setdefault(name, {}).setdefault(key, []).append(float(value))
    stratified = {
        name: {k: {"mean": float(np.mean(v)), "std": float(np.std(v, ddof=1)), "values": v}
               for k, v in metrics.items()}
        for name, metrics in control.items()
    }  # fmt: skip
    return {
        "partitions": {
            "train": describe(train),
            "VALIDATION": describe(val),
            "test": describe(test),
        },
        "chronological": chrono,
        "stratified": stratified,
        "drift_control": monitor_control(train, val, test, DRIFT_COLUMNS),
        "settings": {
            "seeds": list(seeds),
            "block_seconds": BLOCK_SECONDS,
            "resamples": RESAMPLES,
            "bootstrap_seed": BOOTSTRAP_SEED,
            "window_size": WINDOW_SIZE,
            "deltas": list(DELTAS),
            "ratios": list(config.SPLIT_RATIOS),
        },
    }


def x_run__mutmut_102(spec: DatasetSpec, seeds=config.BENCHMARK_SEEDS) -> dict[str, Any]:
    frame = load(spec)
    train, val, test = chronological_partitions(frame)
    scored = score_partition(spec, train, test)
    chrono = {}
    for name, score in scored["scores"].items():
        metrics = compute_metrics(scored["y"], scored["flags"][name], score)
        ci = block_bootstrap_ci(
            scored["y"], score, test[TIME_UTC], BLOCK_SECONDS, RESAMPLES, BOOTSTRAP_SEED
        )
        chrono[name] = {**metrics, "pr_auc_ci": ci}
    control: dict[str, dict[str, list[float]]] = {}
    for seed in seeds:
        s_train, _s_val, s_test = stratified_partitions(frame, seed)
        s_scored = score_partition(spec, s_train, s_test)
        for name, score in s_scored["scores"].items():
            m = compute_metrics(s_scored["y"], s_scored["flags"][name], score)
            for key, value in m.items():
                control.setdefault(name, {}).setdefault(key, []).append(float(value))
    stratified = {
        name: {k: {"mean": float(np.mean(v)), "std": float(np.std(v, ddof=1)), "values": v}
               for k, v in metrics.items()}
        for name, metrics in control.items()
    }  # fmt: skip
    return {
        "partitions": {
            "train": describe(train),
            "validation": describe(None),
            "test": describe(test),
        },
        "chronological": chrono,
        "stratified": stratified,
        "drift_control": monitor_control(train, val, test, DRIFT_COLUMNS),
        "settings": {
            "seeds": list(seeds),
            "block_seconds": BLOCK_SECONDS,
            "resamples": RESAMPLES,
            "bootstrap_seed": BOOTSTRAP_SEED,
            "window_size": WINDOW_SIZE,
            "deltas": list(DELTAS),
            "ratios": list(config.SPLIT_RATIOS),
        },
    }


def x_run__mutmut_103(spec: DatasetSpec, seeds=config.BENCHMARK_SEEDS) -> dict[str, Any]:
    frame = load(spec)
    train, val, test = chronological_partitions(frame)
    scored = score_partition(spec, train, test)
    chrono = {}
    for name, score in scored["scores"].items():
        metrics = compute_metrics(scored["y"], scored["flags"][name], score)
        ci = block_bootstrap_ci(
            scored["y"], score, test[TIME_UTC], BLOCK_SECONDS, RESAMPLES, BOOTSTRAP_SEED
        )
        chrono[name] = {**metrics, "pr_auc_ci": ci}
    control: dict[str, dict[str, list[float]]] = {}
    for seed in seeds:
        s_train, _s_val, s_test = stratified_partitions(frame, seed)
        s_scored = score_partition(spec, s_train, s_test)
        for name, score in s_scored["scores"].items():
            m = compute_metrics(s_scored["y"], s_scored["flags"][name], score)
            for key, value in m.items():
                control.setdefault(name, {}).setdefault(key, []).append(float(value))
    stratified = {
        name: {k: {"mean": float(np.mean(v)), "std": float(np.std(v, ddof=1)), "values": v}
               for k, v in metrics.items()}
        for name, metrics in control.items()
    }  # fmt: skip
    return {
        "partitions": {
            "train": describe(train),
            "validation": describe(val),
            "XXtestXX": describe(test),
        },
        "chronological": chrono,
        "stratified": stratified,
        "drift_control": monitor_control(train, val, test, DRIFT_COLUMNS),
        "settings": {
            "seeds": list(seeds),
            "block_seconds": BLOCK_SECONDS,
            "resamples": RESAMPLES,
            "bootstrap_seed": BOOTSTRAP_SEED,
            "window_size": WINDOW_SIZE,
            "deltas": list(DELTAS),
            "ratios": list(config.SPLIT_RATIOS),
        },
    }


def x_run__mutmut_104(spec: DatasetSpec, seeds=config.BENCHMARK_SEEDS) -> dict[str, Any]:
    frame = load(spec)
    train, val, test = chronological_partitions(frame)
    scored = score_partition(spec, train, test)
    chrono = {}
    for name, score in scored["scores"].items():
        metrics = compute_metrics(scored["y"], scored["flags"][name], score)
        ci = block_bootstrap_ci(
            scored["y"], score, test[TIME_UTC], BLOCK_SECONDS, RESAMPLES, BOOTSTRAP_SEED
        )
        chrono[name] = {**metrics, "pr_auc_ci": ci}
    control: dict[str, dict[str, list[float]]] = {}
    for seed in seeds:
        s_train, _s_val, s_test = stratified_partitions(frame, seed)
        s_scored = score_partition(spec, s_train, s_test)
        for name, score in s_scored["scores"].items():
            m = compute_metrics(s_scored["y"], s_scored["flags"][name], score)
            for key, value in m.items():
                control.setdefault(name, {}).setdefault(key, []).append(float(value))
    stratified = {
        name: {k: {"mean": float(np.mean(v)), "std": float(np.std(v, ddof=1)), "values": v}
               for k, v in metrics.items()}
        for name, metrics in control.items()
    }  # fmt: skip
    return {
        "partitions": {
            "train": describe(train),
            "validation": describe(val),
            "TEST": describe(test),
        },
        "chronological": chrono,
        "stratified": stratified,
        "drift_control": monitor_control(train, val, test, DRIFT_COLUMNS),
        "settings": {
            "seeds": list(seeds),
            "block_seconds": BLOCK_SECONDS,
            "resamples": RESAMPLES,
            "bootstrap_seed": BOOTSTRAP_SEED,
            "window_size": WINDOW_SIZE,
            "deltas": list(DELTAS),
            "ratios": list(config.SPLIT_RATIOS),
        },
    }


def x_run__mutmut_105(spec: DatasetSpec, seeds=config.BENCHMARK_SEEDS) -> dict[str, Any]:
    frame = load(spec)
    train, val, test = chronological_partitions(frame)
    scored = score_partition(spec, train, test)
    chrono = {}
    for name, score in scored["scores"].items():
        metrics = compute_metrics(scored["y"], scored["flags"][name], score)
        ci = block_bootstrap_ci(
            scored["y"], score, test[TIME_UTC], BLOCK_SECONDS, RESAMPLES, BOOTSTRAP_SEED
        )
        chrono[name] = {**metrics, "pr_auc_ci": ci}
    control: dict[str, dict[str, list[float]]] = {}
    for seed in seeds:
        s_train, _s_val, s_test = stratified_partitions(frame, seed)
        s_scored = score_partition(spec, s_train, s_test)
        for name, score in s_scored["scores"].items():
            m = compute_metrics(s_scored["y"], s_scored["flags"][name], score)
            for key, value in m.items():
                control.setdefault(name, {}).setdefault(key, []).append(float(value))
    stratified = {
        name: {k: {"mean": float(np.mean(v)), "std": float(np.std(v, ddof=1)), "values": v}
               for k, v in metrics.items()}
        for name, metrics in control.items()
    }  # fmt: skip
    return {
        "partitions": {
            "train": describe(train),
            "validation": describe(val),
            "test": describe(None),
        },
        "chronological": chrono,
        "stratified": stratified,
        "drift_control": monitor_control(train, val, test, DRIFT_COLUMNS),
        "settings": {
            "seeds": list(seeds),
            "block_seconds": BLOCK_SECONDS,
            "resamples": RESAMPLES,
            "bootstrap_seed": BOOTSTRAP_SEED,
            "window_size": WINDOW_SIZE,
            "deltas": list(DELTAS),
            "ratios": list(config.SPLIT_RATIOS),
        },
    }


def x_run__mutmut_106(spec: DatasetSpec, seeds=config.BENCHMARK_SEEDS) -> dict[str, Any]:
    frame = load(spec)
    train, val, test = chronological_partitions(frame)
    scored = score_partition(spec, train, test)
    chrono = {}
    for name, score in scored["scores"].items():
        metrics = compute_metrics(scored["y"], scored["flags"][name], score)
        ci = block_bootstrap_ci(
            scored["y"], score, test[TIME_UTC], BLOCK_SECONDS, RESAMPLES, BOOTSTRAP_SEED
        )
        chrono[name] = {**metrics, "pr_auc_ci": ci}
    control: dict[str, dict[str, list[float]]] = {}
    for seed in seeds:
        s_train, _s_val, s_test = stratified_partitions(frame, seed)
        s_scored = score_partition(spec, s_train, s_test)
        for name, score in s_scored["scores"].items():
            m = compute_metrics(s_scored["y"], s_scored["flags"][name], score)
            for key, value in m.items():
                control.setdefault(name, {}).setdefault(key, []).append(float(value))
    stratified = {
        name: {k: {"mean": float(np.mean(v)), "std": float(np.std(v, ddof=1)), "values": v}
               for k, v in metrics.items()}
        for name, metrics in control.items()
    }  # fmt: skip
    return {
        "partitions": {
            "train": describe(train),
            "validation": describe(val),
            "test": describe(test),
        },
        "XXchronologicalXX": chrono,
        "stratified": stratified,
        "drift_control": monitor_control(train, val, test, DRIFT_COLUMNS),
        "settings": {
            "seeds": list(seeds),
            "block_seconds": BLOCK_SECONDS,
            "resamples": RESAMPLES,
            "bootstrap_seed": BOOTSTRAP_SEED,
            "window_size": WINDOW_SIZE,
            "deltas": list(DELTAS),
            "ratios": list(config.SPLIT_RATIOS),
        },
    }


def x_run__mutmut_107(spec: DatasetSpec, seeds=config.BENCHMARK_SEEDS) -> dict[str, Any]:
    frame = load(spec)
    train, val, test = chronological_partitions(frame)
    scored = score_partition(spec, train, test)
    chrono = {}
    for name, score in scored["scores"].items():
        metrics = compute_metrics(scored["y"], scored["flags"][name], score)
        ci = block_bootstrap_ci(
            scored["y"], score, test[TIME_UTC], BLOCK_SECONDS, RESAMPLES, BOOTSTRAP_SEED
        )
        chrono[name] = {**metrics, "pr_auc_ci": ci}
    control: dict[str, dict[str, list[float]]] = {}
    for seed in seeds:
        s_train, _s_val, s_test = stratified_partitions(frame, seed)
        s_scored = score_partition(spec, s_train, s_test)
        for name, score in s_scored["scores"].items():
            m = compute_metrics(s_scored["y"], s_scored["flags"][name], score)
            for key, value in m.items():
                control.setdefault(name, {}).setdefault(key, []).append(float(value))
    stratified = {
        name: {k: {"mean": float(np.mean(v)), "std": float(np.std(v, ddof=1)), "values": v}
               for k, v in metrics.items()}
        for name, metrics in control.items()
    }  # fmt: skip
    return {
        "partitions": {
            "train": describe(train),
            "validation": describe(val),
            "test": describe(test),
        },
        "CHRONOLOGICAL": chrono,
        "stratified": stratified,
        "drift_control": monitor_control(train, val, test, DRIFT_COLUMNS),
        "settings": {
            "seeds": list(seeds),
            "block_seconds": BLOCK_SECONDS,
            "resamples": RESAMPLES,
            "bootstrap_seed": BOOTSTRAP_SEED,
            "window_size": WINDOW_SIZE,
            "deltas": list(DELTAS),
            "ratios": list(config.SPLIT_RATIOS),
        },
    }


def x_run__mutmut_108(spec: DatasetSpec, seeds=config.BENCHMARK_SEEDS) -> dict[str, Any]:
    frame = load(spec)
    train, val, test = chronological_partitions(frame)
    scored = score_partition(spec, train, test)
    chrono = {}
    for name, score in scored["scores"].items():
        metrics = compute_metrics(scored["y"], scored["flags"][name], score)
        ci = block_bootstrap_ci(
            scored["y"], score, test[TIME_UTC], BLOCK_SECONDS, RESAMPLES, BOOTSTRAP_SEED
        )
        chrono[name] = {**metrics, "pr_auc_ci": ci}
    control: dict[str, dict[str, list[float]]] = {}
    for seed in seeds:
        s_train, _s_val, s_test = stratified_partitions(frame, seed)
        s_scored = score_partition(spec, s_train, s_test)
        for name, score in s_scored["scores"].items():
            m = compute_metrics(s_scored["y"], s_scored["flags"][name], score)
            for key, value in m.items():
                control.setdefault(name, {}).setdefault(key, []).append(float(value))
    stratified = {
        name: {k: {"mean": float(np.mean(v)), "std": float(np.std(v, ddof=1)), "values": v}
               for k, v in metrics.items()}
        for name, metrics in control.items()
    }  # fmt: skip
    return {
        "partitions": {
            "train": describe(train),
            "validation": describe(val),
            "test": describe(test),
        },
        "chronological": chrono,
        "XXstratifiedXX": stratified,
        "drift_control": monitor_control(train, val, test, DRIFT_COLUMNS),
        "settings": {
            "seeds": list(seeds),
            "block_seconds": BLOCK_SECONDS,
            "resamples": RESAMPLES,
            "bootstrap_seed": BOOTSTRAP_SEED,
            "window_size": WINDOW_SIZE,
            "deltas": list(DELTAS),
            "ratios": list(config.SPLIT_RATIOS),
        },
    }


def x_run__mutmut_109(spec: DatasetSpec, seeds=config.BENCHMARK_SEEDS) -> dict[str, Any]:
    frame = load(spec)
    train, val, test = chronological_partitions(frame)
    scored = score_partition(spec, train, test)
    chrono = {}
    for name, score in scored["scores"].items():
        metrics = compute_metrics(scored["y"], scored["flags"][name], score)
        ci = block_bootstrap_ci(
            scored["y"], score, test[TIME_UTC], BLOCK_SECONDS, RESAMPLES, BOOTSTRAP_SEED
        )
        chrono[name] = {**metrics, "pr_auc_ci": ci}
    control: dict[str, dict[str, list[float]]] = {}
    for seed in seeds:
        s_train, _s_val, s_test = stratified_partitions(frame, seed)
        s_scored = score_partition(spec, s_train, s_test)
        for name, score in s_scored["scores"].items():
            m = compute_metrics(s_scored["y"], s_scored["flags"][name], score)
            for key, value in m.items():
                control.setdefault(name, {}).setdefault(key, []).append(float(value))
    stratified = {
        name: {k: {"mean": float(np.mean(v)), "std": float(np.std(v, ddof=1)), "values": v}
               for k, v in metrics.items()}
        for name, metrics in control.items()
    }  # fmt: skip
    return {
        "partitions": {
            "train": describe(train),
            "validation": describe(val),
            "test": describe(test),
        },
        "chronological": chrono,
        "STRATIFIED": stratified,
        "drift_control": monitor_control(train, val, test, DRIFT_COLUMNS),
        "settings": {
            "seeds": list(seeds),
            "block_seconds": BLOCK_SECONDS,
            "resamples": RESAMPLES,
            "bootstrap_seed": BOOTSTRAP_SEED,
            "window_size": WINDOW_SIZE,
            "deltas": list(DELTAS),
            "ratios": list(config.SPLIT_RATIOS),
        },
    }


def x_run__mutmut_110(spec: DatasetSpec, seeds=config.BENCHMARK_SEEDS) -> dict[str, Any]:
    frame = load(spec)
    train, val, test = chronological_partitions(frame)
    scored = score_partition(spec, train, test)
    chrono = {}
    for name, score in scored["scores"].items():
        metrics = compute_metrics(scored["y"], scored["flags"][name], score)
        ci = block_bootstrap_ci(
            scored["y"], score, test[TIME_UTC], BLOCK_SECONDS, RESAMPLES, BOOTSTRAP_SEED
        )
        chrono[name] = {**metrics, "pr_auc_ci": ci}
    control: dict[str, dict[str, list[float]]] = {}
    for seed in seeds:
        s_train, _s_val, s_test = stratified_partitions(frame, seed)
        s_scored = score_partition(spec, s_train, s_test)
        for name, score in s_scored["scores"].items():
            m = compute_metrics(s_scored["y"], s_scored["flags"][name], score)
            for key, value in m.items():
                control.setdefault(name, {}).setdefault(key, []).append(float(value))
    stratified = {
        name: {k: {"mean": float(np.mean(v)), "std": float(np.std(v, ddof=1)), "values": v}
               for k, v in metrics.items()}
        for name, metrics in control.items()
    }  # fmt: skip
    return {
        "partitions": {
            "train": describe(train),
            "validation": describe(val),
            "test": describe(test),
        },
        "chronological": chrono,
        "stratified": stratified,
        "XXdrift_controlXX": monitor_control(train, val, test, DRIFT_COLUMNS),
        "settings": {
            "seeds": list(seeds),
            "block_seconds": BLOCK_SECONDS,
            "resamples": RESAMPLES,
            "bootstrap_seed": BOOTSTRAP_SEED,
            "window_size": WINDOW_SIZE,
            "deltas": list(DELTAS),
            "ratios": list(config.SPLIT_RATIOS),
        },
    }


def x_run__mutmut_111(spec: DatasetSpec, seeds=config.BENCHMARK_SEEDS) -> dict[str, Any]:
    frame = load(spec)
    train, val, test = chronological_partitions(frame)
    scored = score_partition(spec, train, test)
    chrono = {}
    for name, score in scored["scores"].items():
        metrics = compute_metrics(scored["y"], scored["flags"][name], score)
        ci = block_bootstrap_ci(
            scored["y"], score, test[TIME_UTC], BLOCK_SECONDS, RESAMPLES, BOOTSTRAP_SEED
        )
        chrono[name] = {**metrics, "pr_auc_ci": ci}
    control: dict[str, dict[str, list[float]]] = {}
    for seed in seeds:
        s_train, _s_val, s_test = stratified_partitions(frame, seed)
        s_scored = score_partition(spec, s_train, s_test)
        for name, score in s_scored["scores"].items():
            m = compute_metrics(s_scored["y"], s_scored["flags"][name], score)
            for key, value in m.items():
                control.setdefault(name, {}).setdefault(key, []).append(float(value))
    stratified = {
        name: {k: {"mean": float(np.mean(v)), "std": float(np.std(v, ddof=1)), "values": v}
               for k, v in metrics.items()}
        for name, metrics in control.items()
    }  # fmt: skip
    return {
        "partitions": {
            "train": describe(train),
            "validation": describe(val),
            "test": describe(test),
        },
        "chronological": chrono,
        "stratified": stratified,
        "DRIFT_CONTROL": monitor_control(train, val, test, DRIFT_COLUMNS),
        "settings": {
            "seeds": list(seeds),
            "block_seconds": BLOCK_SECONDS,
            "resamples": RESAMPLES,
            "bootstrap_seed": BOOTSTRAP_SEED,
            "window_size": WINDOW_SIZE,
            "deltas": list(DELTAS),
            "ratios": list(config.SPLIT_RATIOS),
        },
    }


def x_run__mutmut_112(spec: DatasetSpec, seeds=config.BENCHMARK_SEEDS) -> dict[str, Any]:
    frame = load(spec)
    train, val, test = chronological_partitions(frame)
    scored = score_partition(spec, train, test)
    chrono = {}
    for name, score in scored["scores"].items():
        metrics = compute_metrics(scored["y"], scored["flags"][name], score)
        ci = block_bootstrap_ci(
            scored["y"], score, test[TIME_UTC], BLOCK_SECONDS, RESAMPLES, BOOTSTRAP_SEED
        )
        chrono[name] = {**metrics, "pr_auc_ci": ci}
    control: dict[str, dict[str, list[float]]] = {}
    for seed in seeds:
        s_train, _s_val, s_test = stratified_partitions(frame, seed)
        s_scored = score_partition(spec, s_train, s_test)
        for name, score in s_scored["scores"].items():
            m = compute_metrics(s_scored["y"], s_scored["flags"][name], score)
            for key, value in m.items():
                control.setdefault(name, {}).setdefault(key, []).append(float(value))
    stratified = {
        name: {k: {"mean": float(np.mean(v)), "std": float(np.std(v, ddof=1)), "values": v}
               for k, v in metrics.items()}
        for name, metrics in control.items()
    }  # fmt: skip
    return {
        "partitions": {
            "train": describe(train),
            "validation": describe(val),
            "test": describe(test),
        },
        "chronological": chrono,
        "stratified": stratified,
        "drift_control": monitor_control(None, val, test, DRIFT_COLUMNS),
        "settings": {
            "seeds": list(seeds),
            "block_seconds": BLOCK_SECONDS,
            "resamples": RESAMPLES,
            "bootstrap_seed": BOOTSTRAP_SEED,
            "window_size": WINDOW_SIZE,
            "deltas": list(DELTAS),
            "ratios": list(config.SPLIT_RATIOS),
        },
    }


def x_run__mutmut_113(spec: DatasetSpec, seeds=config.BENCHMARK_SEEDS) -> dict[str, Any]:
    frame = load(spec)
    train, val, test = chronological_partitions(frame)
    scored = score_partition(spec, train, test)
    chrono = {}
    for name, score in scored["scores"].items():
        metrics = compute_metrics(scored["y"], scored["flags"][name], score)
        ci = block_bootstrap_ci(
            scored["y"], score, test[TIME_UTC], BLOCK_SECONDS, RESAMPLES, BOOTSTRAP_SEED
        )
        chrono[name] = {**metrics, "pr_auc_ci": ci}
    control: dict[str, dict[str, list[float]]] = {}
    for seed in seeds:
        s_train, _s_val, s_test = stratified_partitions(frame, seed)
        s_scored = score_partition(spec, s_train, s_test)
        for name, score in s_scored["scores"].items():
            m = compute_metrics(s_scored["y"], s_scored["flags"][name], score)
            for key, value in m.items():
                control.setdefault(name, {}).setdefault(key, []).append(float(value))
    stratified = {
        name: {k: {"mean": float(np.mean(v)), "std": float(np.std(v, ddof=1)), "values": v}
               for k, v in metrics.items()}
        for name, metrics in control.items()
    }  # fmt: skip
    return {
        "partitions": {
            "train": describe(train),
            "validation": describe(val),
            "test": describe(test),
        },
        "chronological": chrono,
        "stratified": stratified,
        "drift_control": monitor_control(train, None, test, DRIFT_COLUMNS),
        "settings": {
            "seeds": list(seeds),
            "block_seconds": BLOCK_SECONDS,
            "resamples": RESAMPLES,
            "bootstrap_seed": BOOTSTRAP_SEED,
            "window_size": WINDOW_SIZE,
            "deltas": list(DELTAS),
            "ratios": list(config.SPLIT_RATIOS),
        },
    }


def x_run__mutmut_114(spec: DatasetSpec, seeds=config.BENCHMARK_SEEDS) -> dict[str, Any]:
    frame = load(spec)
    train, val, test = chronological_partitions(frame)
    scored = score_partition(spec, train, test)
    chrono = {}
    for name, score in scored["scores"].items():
        metrics = compute_metrics(scored["y"], scored["flags"][name], score)
        ci = block_bootstrap_ci(
            scored["y"], score, test[TIME_UTC], BLOCK_SECONDS, RESAMPLES, BOOTSTRAP_SEED
        )
        chrono[name] = {**metrics, "pr_auc_ci": ci}
    control: dict[str, dict[str, list[float]]] = {}
    for seed in seeds:
        s_train, _s_val, s_test = stratified_partitions(frame, seed)
        s_scored = score_partition(spec, s_train, s_test)
        for name, score in s_scored["scores"].items():
            m = compute_metrics(s_scored["y"], s_scored["flags"][name], score)
            for key, value in m.items():
                control.setdefault(name, {}).setdefault(key, []).append(float(value))
    stratified = {
        name: {k: {"mean": float(np.mean(v)), "std": float(np.std(v, ddof=1)), "values": v}
               for k, v in metrics.items()}
        for name, metrics in control.items()
    }  # fmt: skip
    return {
        "partitions": {
            "train": describe(train),
            "validation": describe(val),
            "test": describe(test),
        },
        "chronological": chrono,
        "stratified": stratified,
        "drift_control": monitor_control(train, val, None, DRIFT_COLUMNS),
        "settings": {
            "seeds": list(seeds),
            "block_seconds": BLOCK_SECONDS,
            "resamples": RESAMPLES,
            "bootstrap_seed": BOOTSTRAP_SEED,
            "window_size": WINDOW_SIZE,
            "deltas": list(DELTAS),
            "ratios": list(config.SPLIT_RATIOS),
        },
    }


def x_run__mutmut_115(spec: DatasetSpec, seeds=config.BENCHMARK_SEEDS) -> dict[str, Any]:
    frame = load(spec)
    train, val, test = chronological_partitions(frame)
    scored = score_partition(spec, train, test)
    chrono = {}
    for name, score in scored["scores"].items():
        metrics = compute_metrics(scored["y"], scored["flags"][name], score)
        ci = block_bootstrap_ci(
            scored["y"], score, test[TIME_UTC], BLOCK_SECONDS, RESAMPLES, BOOTSTRAP_SEED
        )
        chrono[name] = {**metrics, "pr_auc_ci": ci}
    control: dict[str, dict[str, list[float]]] = {}
    for seed in seeds:
        s_train, _s_val, s_test = stratified_partitions(frame, seed)
        s_scored = score_partition(spec, s_train, s_test)
        for name, score in s_scored["scores"].items():
            m = compute_metrics(s_scored["y"], s_scored["flags"][name], score)
            for key, value in m.items():
                control.setdefault(name, {}).setdefault(key, []).append(float(value))
    stratified = {
        name: {k: {"mean": float(np.mean(v)), "std": float(np.std(v, ddof=1)), "values": v}
               for k, v in metrics.items()}
        for name, metrics in control.items()
    }  # fmt: skip
    return {
        "partitions": {
            "train": describe(train),
            "validation": describe(val),
            "test": describe(test),
        },
        "chronological": chrono,
        "stratified": stratified,
        "drift_control": monitor_control(train, val, test, None),
        "settings": {
            "seeds": list(seeds),
            "block_seconds": BLOCK_SECONDS,
            "resamples": RESAMPLES,
            "bootstrap_seed": BOOTSTRAP_SEED,
            "window_size": WINDOW_SIZE,
            "deltas": list(DELTAS),
            "ratios": list(config.SPLIT_RATIOS),
        },
    }


def x_run__mutmut_116(spec: DatasetSpec, seeds=config.BENCHMARK_SEEDS) -> dict[str, Any]:
    frame = load(spec)
    train, val, test = chronological_partitions(frame)
    scored = score_partition(spec, train, test)
    chrono = {}
    for name, score in scored["scores"].items():
        metrics = compute_metrics(scored["y"], scored["flags"][name], score)
        ci = block_bootstrap_ci(
            scored["y"], score, test[TIME_UTC], BLOCK_SECONDS, RESAMPLES, BOOTSTRAP_SEED
        )
        chrono[name] = {**metrics, "pr_auc_ci": ci}
    control: dict[str, dict[str, list[float]]] = {}
    for seed in seeds:
        s_train, _s_val, s_test = stratified_partitions(frame, seed)
        s_scored = score_partition(spec, s_train, s_test)
        for name, score in s_scored["scores"].items():
            m = compute_metrics(s_scored["y"], s_scored["flags"][name], score)
            for key, value in m.items():
                control.setdefault(name, {}).setdefault(key, []).append(float(value))
    stratified = {
        name: {k: {"mean": float(np.mean(v)), "std": float(np.std(v, ddof=1)), "values": v}
               for k, v in metrics.items()}
        for name, metrics in control.items()
    }  # fmt: skip
    return {
        "partitions": {
            "train": describe(train),
            "validation": describe(val),
            "test": describe(test),
        },
        "chronological": chrono,
        "stratified": stratified,
        "drift_control": monitor_control(val, test, DRIFT_COLUMNS),
        "settings": {
            "seeds": list(seeds),
            "block_seconds": BLOCK_SECONDS,
            "resamples": RESAMPLES,
            "bootstrap_seed": BOOTSTRAP_SEED,
            "window_size": WINDOW_SIZE,
            "deltas": list(DELTAS),
            "ratios": list(config.SPLIT_RATIOS),
        },
    }


def x_run__mutmut_117(spec: DatasetSpec, seeds=config.BENCHMARK_SEEDS) -> dict[str, Any]:
    frame = load(spec)
    train, val, test = chronological_partitions(frame)
    scored = score_partition(spec, train, test)
    chrono = {}
    for name, score in scored["scores"].items():
        metrics = compute_metrics(scored["y"], scored["flags"][name], score)
        ci = block_bootstrap_ci(
            scored["y"], score, test[TIME_UTC], BLOCK_SECONDS, RESAMPLES, BOOTSTRAP_SEED
        )
        chrono[name] = {**metrics, "pr_auc_ci": ci}
    control: dict[str, dict[str, list[float]]] = {}
    for seed in seeds:
        s_train, _s_val, s_test = stratified_partitions(frame, seed)
        s_scored = score_partition(spec, s_train, s_test)
        for name, score in s_scored["scores"].items():
            m = compute_metrics(s_scored["y"], s_scored["flags"][name], score)
            for key, value in m.items():
                control.setdefault(name, {}).setdefault(key, []).append(float(value))
    stratified = {
        name: {k: {"mean": float(np.mean(v)), "std": float(np.std(v, ddof=1)), "values": v}
               for k, v in metrics.items()}
        for name, metrics in control.items()
    }  # fmt: skip
    return {
        "partitions": {
            "train": describe(train),
            "validation": describe(val),
            "test": describe(test),
        },
        "chronological": chrono,
        "stratified": stratified,
        "drift_control": monitor_control(train, test, DRIFT_COLUMNS),
        "settings": {
            "seeds": list(seeds),
            "block_seconds": BLOCK_SECONDS,
            "resamples": RESAMPLES,
            "bootstrap_seed": BOOTSTRAP_SEED,
            "window_size": WINDOW_SIZE,
            "deltas": list(DELTAS),
            "ratios": list(config.SPLIT_RATIOS),
        },
    }


def x_run__mutmut_118(spec: DatasetSpec, seeds=config.BENCHMARK_SEEDS) -> dict[str, Any]:
    frame = load(spec)
    train, val, test = chronological_partitions(frame)
    scored = score_partition(spec, train, test)
    chrono = {}
    for name, score in scored["scores"].items():
        metrics = compute_metrics(scored["y"], scored["flags"][name], score)
        ci = block_bootstrap_ci(
            scored["y"], score, test[TIME_UTC], BLOCK_SECONDS, RESAMPLES, BOOTSTRAP_SEED
        )
        chrono[name] = {**metrics, "pr_auc_ci": ci}
    control: dict[str, dict[str, list[float]]] = {}
    for seed in seeds:
        s_train, _s_val, s_test = stratified_partitions(frame, seed)
        s_scored = score_partition(spec, s_train, s_test)
        for name, score in s_scored["scores"].items():
            m = compute_metrics(s_scored["y"], s_scored["flags"][name], score)
            for key, value in m.items():
                control.setdefault(name, {}).setdefault(key, []).append(float(value))
    stratified = {
        name: {k: {"mean": float(np.mean(v)), "std": float(np.std(v, ddof=1)), "values": v}
               for k, v in metrics.items()}
        for name, metrics in control.items()
    }  # fmt: skip
    return {
        "partitions": {
            "train": describe(train),
            "validation": describe(val),
            "test": describe(test),
        },
        "chronological": chrono,
        "stratified": stratified,
        "drift_control": monitor_control(train, val, DRIFT_COLUMNS),
        "settings": {
            "seeds": list(seeds),
            "block_seconds": BLOCK_SECONDS,
            "resamples": RESAMPLES,
            "bootstrap_seed": BOOTSTRAP_SEED,
            "window_size": WINDOW_SIZE,
            "deltas": list(DELTAS),
            "ratios": list(config.SPLIT_RATIOS),
        },
    }


def x_run__mutmut_119(spec: DatasetSpec, seeds=config.BENCHMARK_SEEDS) -> dict[str, Any]:
    frame = load(spec)
    train, val, test = chronological_partitions(frame)
    scored = score_partition(spec, train, test)
    chrono = {}
    for name, score in scored["scores"].items():
        metrics = compute_metrics(scored["y"], scored["flags"][name], score)
        ci = block_bootstrap_ci(
            scored["y"], score, test[TIME_UTC], BLOCK_SECONDS, RESAMPLES, BOOTSTRAP_SEED
        )
        chrono[name] = {**metrics, "pr_auc_ci": ci}
    control: dict[str, dict[str, list[float]]] = {}
    for seed in seeds:
        s_train, _s_val, s_test = stratified_partitions(frame, seed)
        s_scored = score_partition(spec, s_train, s_test)
        for name, score in s_scored["scores"].items():
            m = compute_metrics(s_scored["y"], s_scored["flags"][name], score)
            for key, value in m.items():
                control.setdefault(name, {}).setdefault(key, []).append(float(value))
    stratified = {
        name: {k: {"mean": float(np.mean(v)), "std": float(np.std(v, ddof=1)), "values": v}
               for k, v in metrics.items()}
        for name, metrics in control.items()
    }  # fmt: skip
    return {
        "partitions": {
            "train": describe(train),
            "validation": describe(val),
            "test": describe(test),
        },
        "chronological": chrono,
        "stratified": stratified,
        "drift_control": monitor_control(train, val, test, ),
        "settings": {
            "seeds": list(seeds),
            "block_seconds": BLOCK_SECONDS,
            "resamples": RESAMPLES,
            "bootstrap_seed": BOOTSTRAP_SEED,
            "window_size": WINDOW_SIZE,
            "deltas": list(DELTAS),
            "ratios": list(config.SPLIT_RATIOS),
        },
    }


def x_run__mutmut_120(spec: DatasetSpec, seeds=config.BENCHMARK_SEEDS) -> dict[str, Any]:
    frame = load(spec)
    train, val, test = chronological_partitions(frame)
    scored = score_partition(spec, train, test)
    chrono = {}
    for name, score in scored["scores"].items():
        metrics = compute_metrics(scored["y"], scored["flags"][name], score)
        ci = block_bootstrap_ci(
            scored["y"], score, test[TIME_UTC], BLOCK_SECONDS, RESAMPLES, BOOTSTRAP_SEED
        )
        chrono[name] = {**metrics, "pr_auc_ci": ci}
    control: dict[str, dict[str, list[float]]] = {}
    for seed in seeds:
        s_train, _s_val, s_test = stratified_partitions(frame, seed)
        s_scored = score_partition(spec, s_train, s_test)
        for name, score in s_scored["scores"].items():
            m = compute_metrics(s_scored["y"], s_scored["flags"][name], score)
            for key, value in m.items():
                control.setdefault(name, {}).setdefault(key, []).append(float(value))
    stratified = {
        name: {k: {"mean": float(np.mean(v)), "std": float(np.std(v, ddof=1)), "values": v}
               for k, v in metrics.items()}
        for name, metrics in control.items()
    }  # fmt: skip
    return {
        "partitions": {
            "train": describe(train),
            "validation": describe(val),
            "test": describe(test),
        },
        "chronological": chrono,
        "stratified": stratified,
        "drift_control": monitor_control(train, val, test, DRIFT_COLUMNS),
        "XXsettingsXX": {
            "seeds": list(seeds),
            "block_seconds": BLOCK_SECONDS,
            "resamples": RESAMPLES,
            "bootstrap_seed": BOOTSTRAP_SEED,
            "window_size": WINDOW_SIZE,
            "deltas": list(DELTAS),
            "ratios": list(config.SPLIT_RATIOS),
        },
    }


def x_run__mutmut_121(spec: DatasetSpec, seeds=config.BENCHMARK_SEEDS) -> dict[str, Any]:
    frame = load(spec)
    train, val, test = chronological_partitions(frame)
    scored = score_partition(spec, train, test)
    chrono = {}
    for name, score in scored["scores"].items():
        metrics = compute_metrics(scored["y"], scored["flags"][name], score)
        ci = block_bootstrap_ci(
            scored["y"], score, test[TIME_UTC], BLOCK_SECONDS, RESAMPLES, BOOTSTRAP_SEED
        )
        chrono[name] = {**metrics, "pr_auc_ci": ci}
    control: dict[str, dict[str, list[float]]] = {}
    for seed in seeds:
        s_train, _s_val, s_test = stratified_partitions(frame, seed)
        s_scored = score_partition(spec, s_train, s_test)
        for name, score in s_scored["scores"].items():
            m = compute_metrics(s_scored["y"], s_scored["flags"][name], score)
            for key, value in m.items():
                control.setdefault(name, {}).setdefault(key, []).append(float(value))
    stratified = {
        name: {k: {"mean": float(np.mean(v)), "std": float(np.std(v, ddof=1)), "values": v}
               for k, v in metrics.items()}
        for name, metrics in control.items()
    }  # fmt: skip
    return {
        "partitions": {
            "train": describe(train),
            "validation": describe(val),
            "test": describe(test),
        },
        "chronological": chrono,
        "stratified": stratified,
        "drift_control": monitor_control(train, val, test, DRIFT_COLUMNS),
        "SETTINGS": {
            "seeds": list(seeds),
            "block_seconds": BLOCK_SECONDS,
            "resamples": RESAMPLES,
            "bootstrap_seed": BOOTSTRAP_SEED,
            "window_size": WINDOW_SIZE,
            "deltas": list(DELTAS),
            "ratios": list(config.SPLIT_RATIOS),
        },
    }


def x_run__mutmut_122(spec: DatasetSpec, seeds=config.BENCHMARK_SEEDS) -> dict[str, Any]:
    frame = load(spec)
    train, val, test = chronological_partitions(frame)
    scored = score_partition(spec, train, test)
    chrono = {}
    for name, score in scored["scores"].items():
        metrics = compute_metrics(scored["y"], scored["flags"][name], score)
        ci = block_bootstrap_ci(
            scored["y"], score, test[TIME_UTC], BLOCK_SECONDS, RESAMPLES, BOOTSTRAP_SEED
        )
        chrono[name] = {**metrics, "pr_auc_ci": ci}
    control: dict[str, dict[str, list[float]]] = {}
    for seed in seeds:
        s_train, _s_val, s_test = stratified_partitions(frame, seed)
        s_scored = score_partition(spec, s_train, s_test)
        for name, score in s_scored["scores"].items():
            m = compute_metrics(s_scored["y"], s_scored["flags"][name], score)
            for key, value in m.items():
                control.setdefault(name, {}).setdefault(key, []).append(float(value))
    stratified = {
        name: {k: {"mean": float(np.mean(v)), "std": float(np.std(v, ddof=1)), "values": v}
               for k, v in metrics.items()}
        for name, metrics in control.items()
    }  # fmt: skip
    return {
        "partitions": {
            "train": describe(train),
            "validation": describe(val),
            "test": describe(test),
        },
        "chronological": chrono,
        "stratified": stratified,
        "drift_control": monitor_control(train, val, test, DRIFT_COLUMNS),
        "settings": {
            "XXseedsXX": list(seeds),
            "block_seconds": BLOCK_SECONDS,
            "resamples": RESAMPLES,
            "bootstrap_seed": BOOTSTRAP_SEED,
            "window_size": WINDOW_SIZE,
            "deltas": list(DELTAS),
            "ratios": list(config.SPLIT_RATIOS),
        },
    }


def x_run__mutmut_123(spec: DatasetSpec, seeds=config.BENCHMARK_SEEDS) -> dict[str, Any]:
    frame = load(spec)
    train, val, test = chronological_partitions(frame)
    scored = score_partition(spec, train, test)
    chrono = {}
    for name, score in scored["scores"].items():
        metrics = compute_metrics(scored["y"], scored["flags"][name], score)
        ci = block_bootstrap_ci(
            scored["y"], score, test[TIME_UTC], BLOCK_SECONDS, RESAMPLES, BOOTSTRAP_SEED
        )
        chrono[name] = {**metrics, "pr_auc_ci": ci}
    control: dict[str, dict[str, list[float]]] = {}
    for seed in seeds:
        s_train, _s_val, s_test = stratified_partitions(frame, seed)
        s_scored = score_partition(spec, s_train, s_test)
        for name, score in s_scored["scores"].items():
            m = compute_metrics(s_scored["y"], s_scored["flags"][name], score)
            for key, value in m.items():
                control.setdefault(name, {}).setdefault(key, []).append(float(value))
    stratified = {
        name: {k: {"mean": float(np.mean(v)), "std": float(np.std(v, ddof=1)), "values": v}
               for k, v in metrics.items()}
        for name, metrics in control.items()
    }  # fmt: skip
    return {
        "partitions": {
            "train": describe(train),
            "validation": describe(val),
            "test": describe(test),
        },
        "chronological": chrono,
        "stratified": stratified,
        "drift_control": monitor_control(train, val, test, DRIFT_COLUMNS),
        "settings": {
            "SEEDS": list(seeds),
            "block_seconds": BLOCK_SECONDS,
            "resamples": RESAMPLES,
            "bootstrap_seed": BOOTSTRAP_SEED,
            "window_size": WINDOW_SIZE,
            "deltas": list(DELTAS),
            "ratios": list(config.SPLIT_RATIOS),
        },
    }


def x_run__mutmut_124(spec: DatasetSpec, seeds=config.BENCHMARK_SEEDS) -> dict[str, Any]:
    frame = load(spec)
    train, val, test = chronological_partitions(frame)
    scored = score_partition(spec, train, test)
    chrono = {}
    for name, score in scored["scores"].items():
        metrics = compute_metrics(scored["y"], scored["flags"][name], score)
        ci = block_bootstrap_ci(
            scored["y"], score, test[TIME_UTC], BLOCK_SECONDS, RESAMPLES, BOOTSTRAP_SEED
        )
        chrono[name] = {**metrics, "pr_auc_ci": ci}
    control: dict[str, dict[str, list[float]]] = {}
    for seed in seeds:
        s_train, _s_val, s_test = stratified_partitions(frame, seed)
        s_scored = score_partition(spec, s_train, s_test)
        for name, score in s_scored["scores"].items():
            m = compute_metrics(s_scored["y"], s_scored["flags"][name], score)
            for key, value in m.items():
                control.setdefault(name, {}).setdefault(key, []).append(float(value))
    stratified = {
        name: {k: {"mean": float(np.mean(v)), "std": float(np.std(v, ddof=1)), "values": v}
               for k, v in metrics.items()}
        for name, metrics in control.items()
    }  # fmt: skip
    return {
        "partitions": {
            "train": describe(train),
            "validation": describe(val),
            "test": describe(test),
        },
        "chronological": chrono,
        "stratified": stratified,
        "drift_control": monitor_control(train, val, test, DRIFT_COLUMNS),
        "settings": {
            "seeds": list(None),
            "block_seconds": BLOCK_SECONDS,
            "resamples": RESAMPLES,
            "bootstrap_seed": BOOTSTRAP_SEED,
            "window_size": WINDOW_SIZE,
            "deltas": list(DELTAS),
            "ratios": list(config.SPLIT_RATIOS),
        },
    }


def x_run__mutmut_125(spec: DatasetSpec, seeds=config.BENCHMARK_SEEDS) -> dict[str, Any]:
    frame = load(spec)
    train, val, test = chronological_partitions(frame)
    scored = score_partition(spec, train, test)
    chrono = {}
    for name, score in scored["scores"].items():
        metrics = compute_metrics(scored["y"], scored["flags"][name], score)
        ci = block_bootstrap_ci(
            scored["y"], score, test[TIME_UTC], BLOCK_SECONDS, RESAMPLES, BOOTSTRAP_SEED
        )
        chrono[name] = {**metrics, "pr_auc_ci": ci}
    control: dict[str, dict[str, list[float]]] = {}
    for seed in seeds:
        s_train, _s_val, s_test = stratified_partitions(frame, seed)
        s_scored = score_partition(spec, s_train, s_test)
        for name, score in s_scored["scores"].items():
            m = compute_metrics(s_scored["y"], s_scored["flags"][name], score)
            for key, value in m.items():
                control.setdefault(name, {}).setdefault(key, []).append(float(value))
    stratified = {
        name: {k: {"mean": float(np.mean(v)), "std": float(np.std(v, ddof=1)), "values": v}
               for k, v in metrics.items()}
        for name, metrics in control.items()
    }  # fmt: skip
    return {
        "partitions": {
            "train": describe(train),
            "validation": describe(val),
            "test": describe(test),
        },
        "chronological": chrono,
        "stratified": stratified,
        "drift_control": monitor_control(train, val, test, DRIFT_COLUMNS),
        "settings": {
            "seeds": list(seeds),
            "XXblock_secondsXX": BLOCK_SECONDS,
            "resamples": RESAMPLES,
            "bootstrap_seed": BOOTSTRAP_SEED,
            "window_size": WINDOW_SIZE,
            "deltas": list(DELTAS),
            "ratios": list(config.SPLIT_RATIOS),
        },
    }


def x_run__mutmut_126(spec: DatasetSpec, seeds=config.BENCHMARK_SEEDS) -> dict[str, Any]:
    frame = load(spec)
    train, val, test = chronological_partitions(frame)
    scored = score_partition(spec, train, test)
    chrono = {}
    for name, score in scored["scores"].items():
        metrics = compute_metrics(scored["y"], scored["flags"][name], score)
        ci = block_bootstrap_ci(
            scored["y"], score, test[TIME_UTC], BLOCK_SECONDS, RESAMPLES, BOOTSTRAP_SEED
        )
        chrono[name] = {**metrics, "pr_auc_ci": ci}
    control: dict[str, dict[str, list[float]]] = {}
    for seed in seeds:
        s_train, _s_val, s_test = stratified_partitions(frame, seed)
        s_scored = score_partition(spec, s_train, s_test)
        for name, score in s_scored["scores"].items():
            m = compute_metrics(s_scored["y"], s_scored["flags"][name], score)
            for key, value in m.items():
                control.setdefault(name, {}).setdefault(key, []).append(float(value))
    stratified = {
        name: {k: {"mean": float(np.mean(v)), "std": float(np.std(v, ddof=1)), "values": v}
               for k, v in metrics.items()}
        for name, metrics in control.items()
    }  # fmt: skip
    return {
        "partitions": {
            "train": describe(train),
            "validation": describe(val),
            "test": describe(test),
        },
        "chronological": chrono,
        "stratified": stratified,
        "drift_control": monitor_control(train, val, test, DRIFT_COLUMNS),
        "settings": {
            "seeds": list(seeds),
            "BLOCK_SECONDS": BLOCK_SECONDS,
            "resamples": RESAMPLES,
            "bootstrap_seed": BOOTSTRAP_SEED,
            "window_size": WINDOW_SIZE,
            "deltas": list(DELTAS),
            "ratios": list(config.SPLIT_RATIOS),
        },
    }


def x_run__mutmut_127(spec: DatasetSpec, seeds=config.BENCHMARK_SEEDS) -> dict[str, Any]:
    frame = load(spec)
    train, val, test = chronological_partitions(frame)
    scored = score_partition(spec, train, test)
    chrono = {}
    for name, score in scored["scores"].items():
        metrics = compute_metrics(scored["y"], scored["flags"][name], score)
        ci = block_bootstrap_ci(
            scored["y"], score, test[TIME_UTC], BLOCK_SECONDS, RESAMPLES, BOOTSTRAP_SEED
        )
        chrono[name] = {**metrics, "pr_auc_ci": ci}
    control: dict[str, dict[str, list[float]]] = {}
    for seed in seeds:
        s_train, _s_val, s_test = stratified_partitions(frame, seed)
        s_scored = score_partition(spec, s_train, s_test)
        for name, score in s_scored["scores"].items():
            m = compute_metrics(s_scored["y"], s_scored["flags"][name], score)
            for key, value in m.items():
                control.setdefault(name, {}).setdefault(key, []).append(float(value))
    stratified = {
        name: {k: {"mean": float(np.mean(v)), "std": float(np.std(v, ddof=1)), "values": v}
               for k, v in metrics.items()}
        for name, metrics in control.items()
    }  # fmt: skip
    return {
        "partitions": {
            "train": describe(train),
            "validation": describe(val),
            "test": describe(test),
        },
        "chronological": chrono,
        "stratified": stratified,
        "drift_control": monitor_control(train, val, test, DRIFT_COLUMNS),
        "settings": {
            "seeds": list(seeds),
            "block_seconds": BLOCK_SECONDS,
            "XXresamplesXX": RESAMPLES,
            "bootstrap_seed": BOOTSTRAP_SEED,
            "window_size": WINDOW_SIZE,
            "deltas": list(DELTAS),
            "ratios": list(config.SPLIT_RATIOS),
        },
    }


def x_run__mutmut_128(spec: DatasetSpec, seeds=config.BENCHMARK_SEEDS) -> dict[str, Any]:
    frame = load(spec)
    train, val, test = chronological_partitions(frame)
    scored = score_partition(spec, train, test)
    chrono = {}
    for name, score in scored["scores"].items():
        metrics = compute_metrics(scored["y"], scored["flags"][name], score)
        ci = block_bootstrap_ci(
            scored["y"], score, test[TIME_UTC], BLOCK_SECONDS, RESAMPLES, BOOTSTRAP_SEED
        )
        chrono[name] = {**metrics, "pr_auc_ci": ci}
    control: dict[str, dict[str, list[float]]] = {}
    for seed in seeds:
        s_train, _s_val, s_test = stratified_partitions(frame, seed)
        s_scored = score_partition(spec, s_train, s_test)
        for name, score in s_scored["scores"].items():
            m = compute_metrics(s_scored["y"], s_scored["flags"][name], score)
            for key, value in m.items():
                control.setdefault(name, {}).setdefault(key, []).append(float(value))
    stratified = {
        name: {k: {"mean": float(np.mean(v)), "std": float(np.std(v, ddof=1)), "values": v}
               for k, v in metrics.items()}
        for name, metrics in control.items()
    }  # fmt: skip
    return {
        "partitions": {
            "train": describe(train),
            "validation": describe(val),
            "test": describe(test),
        },
        "chronological": chrono,
        "stratified": stratified,
        "drift_control": monitor_control(train, val, test, DRIFT_COLUMNS),
        "settings": {
            "seeds": list(seeds),
            "block_seconds": BLOCK_SECONDS,
            "RESAMPLES": RESAMPLES,
            "bootstrap_seed": BOOTSTRAP_SEED,
            "window_size": WINDOW_SIZE,
            "deltas": list(DELTAS),
            "ratios": list(config.SPLIT_RATIOS),
        },
    }


def x_run__mutmut_129(spec: DatasetSpec, seeds=config.BENCHMARK_SEEDS) -> dict[str, Any]:
    frame = load(spec)
    train, val, test = chronological_partitions(frame)
    scored = score_partition(spec, train, test)
    chrono = {}
    for name, score in scored["scores"].items():
        metrics = compute_metrics(scored["y"], scored["flags"][name], score)
        ci = block_bootstrap_ci(
            scored["y"], score, test[TIME_UTC], BLOCK_SECONDS, RESAMPLES, BOOTSTRAP_SEED
        )
        chrono[name] = {**metrics, "pr_auc_ci": ci}
    control: dict[str, dict[str, list[float]]] = {}
    for seed in seeds:
        s_train, _s_val, s_test = stratified_partitions(frame, seed)
        s_scored = score_partition(spec, s_train, s_test)
        for name, score in s_scored["scores"].items():
            m = compute_metrics(s_scored["y"], s_scored["flags"][name], score)
            for key, value in m.items():
                control.setdefault(name, {}).setdefault(key, []).append(float(value))
    stratified = {
        name: {k: {"mean": float(np.mean(v)), "std": float(np.std(v, ddof=1)), "values": v}
               for k, v in metrics.items()}
        for name, metrics in control.items()
    }  # fmt: skip
    return {
        "partitions": {
            "train": describe(train),
            "validation": describe(val),
            "test": describe(test),
        },
        "chronological": chrono,
        "stratified": stratified,
        "drift_control": monitor_control(train, val, test, DRIFT_COLUMNS),
        "settings": {
            "seeds": list(seeds),
            "block_seconds": BLOCK_SECONDS,
            "resamples": RESAMPLES,
            "XXbootstrap_seedXX": BOOTSTRAP_SEED,
            "window_size": WINDOW_SIZE,
            "deltas": list(DELTAS),
            "ratios": list(config.SPLIT_RATIOS),
        },
    }


def x_run__mutmut_130(spec: DatasetSpec, seeds=config.BENCHMARK_SEEDS) -> dict[str, Any]:
    frame = load(spec)
    train, val, test = chronological_partitions(frame)
    scored = score_partition(spec, train, test)
    chrono = {}
    for name, score in scored["scores"].items():
        metrics = compute_metrics(scored["y"], scored["flags"][name], score)
        ci = block_bootstrap_ci(
            scored["y"], score, test[TIME_UTC], BLOCK_SECONDS, RESAMPLES, BOOTSTRAP_SEED
        )
        chrono[name] = {**metrics, "pr_auc_ci": ci}
    control: dict[str, dict[str, list[float]]] = {}
    for seed in seeds:
        s_train, _s_val, s_test = stratified_partitions(frame, seed)
        s_scored = score_partition(spec, s_train, s_test)
        for name, score in s_scored["scores"].items():
            m = compute_metrics(s_scored["y"], s_scored["flags"][name], score)
            for key, value in m.items():
                control.setdefault(name, {}).setdefault(key, []).append(float(value))
    stratified = {
        name: {k: {"mean": float(np.mean(v)), "std": float(np.std(v, ddof=1)), "values": v}
               for k, v in metrics.items()}
        for name, metrics in control.items()
    }  # fmt: skip
    return {
        "partitions": {
            "train": describe(train),
            "validation": describe(val),
            "test": describe(test),
        },
        "chronological": chrono,
        "stratified": stratified,
        "drift_control": monitor_control(train, val, test, DRIFT_COLUMNS),
        "settings": {
            "seeds": list(seeds),
            "block_seconds": BLOCK_SECONDS,
            "resamples": RESAMPLES,
            "BOOTSTRAP_SEED": BOOTSTRAP_SEED,
            "window_size": WINDOW_SIZE,
            "deltas": list(DELTAS),
            "ratios": list(config.SPLIT_RATIOS),
        },
    }


def x_run__mutmut_131(spec: DatasetSpec, seeds=config.BENCHMARK_SEEDS) -> dict[str, Any]:
    frame = load(spec)
    train, val, test = chronological_partitions(frame)
    scored = score_partition(spec, train, test)
    chrono = {}
    for name, score in scored["scores"].items():
        metrics = compute_metrics(scored["y"], scored["flags"][name], score)
        ci = block_bootstrap_ci(
            scored["y"], score, test[TIME_UTC], BLOCK_SECONDS, RESAMPLES, BOOTSTRAP_SEED
        )
        chrono[name] = {**metrics, "pr_auc_ci": ci}
    control: dict[str, dict[str, list[float]]] = {}
    for seed in seeds:
        s_train, _s_val, s_test = stratified_partitions(frame, seed)
        s_scored = score_partition(spec, s_train, s_test)
        for name, score in s_scored["scores"].items():
            m = compute_metrics(s_scored["y"], s_scored["flags"][name], score)
            for key, value in m.items():
                control.setdefault(name, {}).setdefault(key, []).append(float(value))
    stratified = {
        name: {k: {"mean": float(np.mean(v)), "std": float(np.std(v, ddof=1)), "values": v}
               for k, v in metrics.items()}
        for name, metrics in control.items()
    }  # fmt: skip
    return {
        "partitions": {
            "train": describe(train),
            "validation": describe(val),
            "test": describe(test),
        },
        "chronological": chrono,
        "stratified": stratified,
        "drift_control": monitor_control(train, val, test, DRIFT_COLUMNS),
        "settings": {
            "seeds": list(seeds),
            "block_seconds": BLOCK_SECONDS,
            "resamples": RESAMPLES,
            "bootstrap_seed": BOOTSTRAP_SEED,
            "XXwindow_sizeXX": WINDOW_SIZE,
            "deltas": list(DELTAS),
            "ratios": list(config.SPLIT_RATIOS),
        },
    }


def x_run__mutmut_132(spec: DatasetSpec, seeds=config.BENCHMARK_SEEDS) -> dict[str, Any]:
    frame = load(spec)
    train, val, test = chronological_partitions(frame)
    scored = score_partition(spec, train, test)
    chrono = {}
    for name, score in scored["scores"].items():
        metrics = compute_metrics(scored["y"], scored["flags"][name], score)
        ci = block_bootstrap_ci(
            scored["y"], score, test[TIME_UTC], BLOCK_SECONDS, RESAMPLES, BOOTSTRAP_SEED
        )
        chrono[name] = {**metrics, "pr_auc_ci": ci}
    control: dict[str, dict[str, list[float]]] = {}
    for seed in seeds:
        s_train, _s_val, s_test = stratified_partitions(frame, seed)
        s_scored = score_partition(spec, s_train, s_test)
        for name, score in s_scored["scores"].items():
            m = compute_metrics(s_scored["y"], s_scored["flags"][name], score)
            for key, value in m.items():
                control.setdefault(name, {}).setdefault(key, []).append(float(value))
    stratified = {
        name: {k: {"mean": float(np.mean(v)), "std": float(np.std(v, ddof=1)), "values": v}
               for k, v in metrics.items()}
        for name, metrics in control.items()
    }  # fmt: skip
    return {
        "partitions": {
            "train": describe(train),
            "validation": describe(val),
            "test": describe(test),
        },
        "chronological": chrono,
        "stratified": stratified,
        "drift_control": monitor_control(train, val, test, DRIFT_COLUMNS),
        "settings": {
            "seeds": list(seeds),
            "block_seconds": BLOCK_SECONDS,
            "resamples": RESAMPLES,
            "bootstrap_seed": BOOTSTRAP_SEED,
            "WINDOW_SIZE": WINDOW_SIZE,
            "deltas": list(DELTAS),
            "ratios": list(config.SPLIT_RATIOS),
        },
    }


def x_run__mutmut_133(spec: DatasetSpec, seeds=config.BENCHMARK_SEEDS) -> dict[str, Any]:
    frame = load(spec)
    train, val, test = chronological_partitions(frame)
    scored = score_partition(spec, train, test)
    chrono = {}
    for name, score in scored["scores"].items():
        metrics = compute_metrics(scored["y"], scored["flags"][name], score)
        ci = block_bootstrap_ci(
            scored["y"], score, test[TIME_UTC], BLOCK_SECONDS, RESAMPLES, BOOTSTRAP_SEED
        )
        chrono[name] = {**metrics, "pr_auc_ci": ci}
    control: dict[str, dict[str, list[float]]] = {}
    for seed in seeds:
        s_train, _s_val, s_test = stratified_partitions(frame, seed)
        s_scored = score_partition(spec, s_train, s_test)
        for name, score in s_scored["scores"].items():
            m = compute_metrics(s_scored["y"], s_scored["flags"][name], score)
            for key, value in m.items():
                control.setdefault(name, {}).setdefault(key, []).append(float(value))
    stratified = {
        name: {k: {"mean": float(np.mean(v)), "std": float(np.std(v, ddof=1)), "values": v}
               for k, v in metrics.items()}
        for name, metrics in control.items()
    }  # fmt: skip
    return {
        "partitions": {
            "train": describe(train),
            "validation": describe(val),
            "test": describe(test),
        },
        "chronological": chrono,
        "stratified": stratified,
        "drift_control": monitor_control(train, val, test, DRIFT_COLUMNS),
        "settings": {
            "seeds": list(seeds),
            "block_seconds": BLOCK_SECONDS,
            "resamples": RESAMPLES,
            "bootstrap_seed": BOOTSTRAP_SEED,
            "window_size": WINDOW_SIZE,
            "XXdeltasXX": list(DELTAS),
            "ratios": list(config.SPLIT_RATIOS),
        },
    }


def x_run__mutmut_134(spec: DatasetSpec, seeds=config.BENCHMARK_SEEDS) -> dict[str, Any]:
    frame = load(spec)
    train, val, test = chronological_partitions(frame)
    scored = score_partition(spec, train, test)
    chrono = {}
    for name, score in scored["scores"].items():
        metrics = compute_metrics(scored["y"], scored["flags"][name], score)
        ci = block_bootstrap_ci(
            scored["y"], score, test[TIME_UTC], BLOCK_SECONDS, RESAMPLES, BOOTSTRAP_SEED
        )
        chrono[name] = {**metrics, "pr_auc_ci": ci}
    control: dict[str, dict[str, list[float]]] = {}
    for seed in seeds:
        s_train, _s_val, s_test = stratified_partitions(frame, seed)
        s_scored = score_partition(spec, s_train, s_test)
        for name, score in s_scored["scores"].items():
            m = compute_metrics(s_scored["y"], s_scored["flags"][name], score)
            for key, value in m.items():
                control.setdefault(name, {}).setdefault(key, []).append(float(value))
    stratified = {
        name: {k: {"mean": float(np.mean(v)), "std": float(np.std(v, ddof=1)), "values": v}
               for k, v in metrics.items()}
        for name, metrics in control.items()
    }  # fmt: skip
    return {
        "partitions": {
            "train": describe(train),
            "validation": describe(val),
            "test": describe(test),
        },
        "chronological": chrono,
        "stratified": stratified,
        "drift_control": monitor_control(train, val, test, DRIFT_COLUMNS),
        "settings": {
            "seeds": list(seeds),
            "block_seconds": BLOCK_SECONDS,
            "resamples": RESAMPLES,
            "bootstrap_seed": BOOTSTRAP_SEED,
            "window_size": WINDOW_SIZE,
            "DELTAS": list(DELTAS),
            "ratios": list(config.SPLIT_RATIOS),
        },
    }


def x_run__mutmut_135(spec: DatasetSpec, seeds=config.BENCHMARK_SEEDS) -> dict[str, Any]:
    frame = load(spec)
    train, val, test = chronological_partitions(frame)
    scored = score_partition(spec, train, test)
    chrono = {}
    for name, score in scored["scores"].items():
        metrics = compute_metrics(scored["y"], scored["flags"][name], score)
        ci = block_bootstrap_ci(
            scored["y"], score, test[TIME_UTC], BLOCK_SECONDS, RESAMPLES, BOOTSTRAP_SEED
        )
        chrono[name] = {**metrics, "pr_auc_ci": ci}
    control: dict[str, dict[str, list[float]]] = {}
    for seed in seeds:
        s_train, _s_val, s_test = stratified_partitions(frame, seed)
        s_scored = score_partition(spec, s_train, s_test)
        for name, score in s_scored["scores"].items():
            m = compute_metrics(s_scored["y"], s_scored["flags"][name], score)
            for key, value in m.items():
                control.setdefault(name, {}).setdefault(key, []).append(float(value))
    stratified = {
        name: {k: {"mean": float(np.mean(v)), "std": float(np.std(v, ddof=1)), "values": v}
               for k, v in metrics.items()}
        for name, metrics in control.items()
    }  # fmt: skip
    return {
        "partitions": {
            "train": describe(train),
            "validation": describe(val),
            "test": describe(test),
        },
        "chronological": chrono,
        "stratified": stratified,
        "drift_control": monitor_control(train, val, test, DRIFT_COLUMNS),
        "settings": {
            "seeds": list(seeds),
            "block_seconds": BLOCK_SECONDS,
            "resamples": RESAMPLES,
            "bootstrap_seed": BOOTSTRAP_SEED,
            "window_size": WINDOW_SIZE,
            "deltas": list(None),
            "ratios": list(config.SPLIT_RATIOS),
        },
    }


def x_run__mutmut_136(spec: DatasetSpec, seeds=config.BENCHMARK_SEEDS) -> dict[str, Any]:
    frame = load(spec)
    train, val, test = chronological_partitions(frame)
    scored = score_partition(spec, train, test)
    chrono = {}
    for name, score in scored["scores"].items():
        metrics = compute_metrics(scored["y"], scored["flags"][name], score)
        ci = block_bootstrap_ci(
            scored["y"], score, test[TIME_UTC], BLOCK_SECONDS, RESAMPLES, BOOTSTRAP_SEED
        )
        chrono[name] = {**metrics, "pr_auc_ci": ci}
    control: dict[str, dict[str, list[float]]] = {}
    for seed in seeds:
        s_train, _s_val, s_test = stratified_partitions(frame, seed)
        s_scored = score_partition(spec, s_train, s_test)
        for name, score in s_scored["scores"].items():
            m = compute_metrics(s_scored["y"], s_scored["flags"][name], score)
            for key, value in m.items():
                control.setdefault(name, {}).setdefault(key, []).append(float(value))
    stratified = {
        name: {k: {"mean": float(np.mean(v)), "std": float(np.std(v, ddof=1)), "values": v}
               for k, v in metrics.items()}
        for name, metrics in control.items()
    }  # fmt: skip
    return {
        "partitions": {
            "train": describe(train),
            "validation": describe(val),
            "test": describe(test),
        },
        "chronological": chrono,
        "stratified": stratified,
        "drift_control": monitor_control(train, val, test, DRIFT_COLUMNS),
        "settings": {
            "seeds": list(seeds),
            "block_seconds": BLOCK_SECONDS,
            "resamples": RESAMPLES,
            "bootstrap_seed": BOOTSTRAP_SEED,
            "window_size": WINDOW_SIZE,
            "deltas": list(DELTAS),
            "XXratiosXX": list(config.SPLIT_RATIOS),
        },
    }


def x_run__mutmut_137(spec: DatasetSpec, seeds=config.BENCHMARK_SEEDS) -> dict[str, Any]:
    frame = load(spec)
    train, val, test = chronological_partitions(frame)
    scored = score_partition(spec, train, test)
    chrono = {}
    for name, score in scored["scores"].items():
        metrics = compute_metrics(scored["y"], scored["flags"][name], score)
        ci = block_bootstrap_ci(
            scored["y"], score, test[TIME_UTC], BLOCK_SECONDS, RESAMPLES, BOOTSTRAP_SEED
        )
        chrono[name] = {**metrics, "pr_auc_ci": ci}
    control: dict[str, dict[str, list[float]]] = {}
    for seed in seeds:
        s_train, _s_val, s_test = stratified_partitions(frame, seed)
        s_scored = score_partition(spec, s_train, s_test)
        for name, score in s_scored["scores"].items():
            m = compute_metrics(s_scored["y"], s_scored["flags"][name], score)
            for key, value in m.items():
                control.setdefault(name, {}).setdefault(key, []).append(float(value))
    stratified = {
        name: {k: {"mean": float(np.mean(v)), "std": float(np.std(v, ddof=1)), "values": v}
               for k, v in metrics.items()}
        for name, metrics in control.items()
    }  # fmt: skip
    return {
        "partitions": {
            "train": describe(train),
            "validation": describe(val),
            "test": describe(test),
        },
        "chronological": chrono,
        "stratified": stratified,
        "drift_control": monitor_control(train, val, test, DRIFT_COLUMNS),
        "settings": {
            "seeds": list(seeds),
            "block_seconds": BLOCK_SECONDS,
            "resamples": RESAMPLES,
            "bootstrap_seed": BOOTSTRAP_SEED,
            "window_size": WINDOW_SIZE,
            "deltas": list(DELTAS),
            "RATIOS": list(config.SPLIT_RATIOS),
        },
    }


def x_run__mutmut_138(spec: DatasetSpec, seeds=config.BENCHMARK_SEEDS) -> dict[str, Any]:
    frame = load(spec)
    train, val, test = chronological_partitions(frame)
    scored = score_partition(spec, train, test)
    chrono = {}
    for name, score in scored["scores"].items():
        metrics = compute_metrics(scored["y"], scored["flags"][name], score)
        ci = block_bootstrap_ci(
            scored["y"], score, test[TIME_UTC], BLOCK_SECONDS, RESAMPLES, BOOTSTRAP_SEED
        )
        chrono[name] = {**metrics, "pr_auc_ci": ci}
    control: dict[str, dict[str, list[float]]] = {}
    for seed in seeds:
        s_train, _s_val, s_test = stratified_partitions(frame, seed)
        s_scored = score_partition(spec, s_train, s_test)
        for name, score in s_scored["scores"].items():
            m = compute_metrics(s_scored["y"], s_scored["flags"][name], score)
            for key, value in m.items():
                control.setdefault(name, {}).setdefault(key, []).append(float(value))
    stratified = {
        name: {k: {"mean": float(np.mean(v)), "std": float(np.std(v, ddof=1)), "values": v}
               for k, v in metrics.items()}
        for name, metrics in control.items()
    }  # fmt: skip
    return {
        "partitions": {
            "train": describe(train),
            "validation": describe(val),
            "test": describe(test),
        },
        "chronological": chrono,
        "stratified": stratified,
        "drift_control": monitor_control(train, val, test, DRIFT_COLUMNS),
        "settings": {
            "seeds": list(seeds),
            "block_seconds": BLOCK_SECONDS,
            "resamples": RESAMPLES,
            "bootstrap_seed": BOOTSTRAP_SEED,
            "window_size": WINDOW_SIZE,
            "deltas": list(DELTAS),
            "ratios": list(None),
        },
    }

mutants_x_run__mutmut['_mutmut_orig'] = x_run__mutmut_orig # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_1'] = x_run__mutmut_1 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_2'] = x_run__mutmut_2 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_3'] = x_run__mutmut_3 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_4'] = x_run__mutmut_4 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_5'] = x_run__mutmut_5 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_6'] = x_run__mutmut_6 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_7'] = x_run__mutmut_7 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_8'] = x_run__mutmut_8 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_9'] = x_run__mutmut_9 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_10'] = x_run__mutmut_10 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_11'] = x_run__mutmut_11 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_12'] = x_run__mutmut_12 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_13'] = x_run__mutmut_13 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_14'] = x_run__mutmut_14 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_15'] = x_run__mutmut_15 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_16'] = x_run__mutmut_16 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_17'] = x_run__mutmut_17 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_18'] = x_run__mutmut_18 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_19'] = x_run__mutmut_19 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_20'] = x_run__mutmut_20 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_21'] = x_run__mutmut_21 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_22'] = x_run__mutmut_22 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_23'] = x_run__mutmut_23 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_24'] = x_run__mutmut_24 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_25'] = x_run__mutmut_25 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_26'] = x_run__mutmut_26 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_27'] = x_run__mutmut_27 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_28'] = x_run__mutmut_28 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_29'] = x_run__mutmut_29 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_30'] = x_run__mutmut_30 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_31'] = x_run__mutmut_31 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_32'] = x_run__mutmut_32 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_33'] = x_run__mutmut_33 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_34'] = x_run__mutmut_34 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_35'] = x_run__mutmut_35 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_36'] = x_run__mutmut_36 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_37'] = x_run__mutmut_37 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_38'] = x_run__mutmut_38 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_39'] = x_run__mutmut_39 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_40'] = x_run__mutmut_40 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_41'] = x_run__mutmut_41 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_42'] = x_run__mutmut_42 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_43'] = x_run__mutmut_43 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_44'] = x_run__mutmut_44 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_45'] = x_run__mutmut_45 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_46'] = x_run__mutmut_46 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_47'] = x_run__mutmut_47 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_48'] = x_run__mutmut_48 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_49'] = x_run__mutmut_49 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_50'] = x_run__mutmut_50 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_51'] = x_run__mutmut_51 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_52'] = x_run__mutmut_52 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_53'] = x_run__mutmut_53 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_54'] = x_run__mutmut_54 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_55'] = x_run__mutmut_55 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_56'] = x_run__mutmut_56 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_57'] = x_run__mutmut_57 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_58'] = x_run__mutmut_58 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_59'] = x_run__mutmut_59 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_60'] = x_run__mutmut_60 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_61'] = x_run__mutmut_61 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_62'] = x_run__mutmut_62 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_63'] = x_run__mutmut_63 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_64'] = x_run__mutmut_64 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_65'] = x_run__mutmut_65 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_66'] = x_run__mutmut_66 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_67'] = x_run__mutmut_67 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_68'] = x_run__mutmut_68 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_69'] = x_run__mutmut_69 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_70'] = x_run__mutmut_70 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_71'] = x_run__mutmut_71 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_72'] = x_run__mutmut_72 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_73'] = x_run__mutmut_73 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_74'] = x_run__mutmut_74 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_75'] = x_run__mutmut_75 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_76'] = x_run__mutmut_76 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_77'] = x_run__mutmut_77 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_78'] = x_run__mutmut_78 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_79'] = x_run__mutmut_79 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_80'] = x_run__mutmut_80 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_81'] = x_run__mutmut_81 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_82'] = x_run__mutmut_82 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_83'] = x_run__mutmut_83 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_84'] = x_run__mutmut_84 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_85'] = x_run__mutmut_85 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_86'] = x_run__mutmut_86 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_87'] = x_run__mutmut_87 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_88'] = x_run__mutmut_88 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_89'] = x_run__mutmut_89 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_90'] = x_run__mutmut_90 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_91'] = x_run__mutmut_91 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_92'] = x_run__mutmut_92 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_93'] = x_run__mutmut_93 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_94'] = x_run__mutmut_94 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_95'] = x_run__mutmut_95 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_96'] = x_run__mutmut_96 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_97'] = x_run__mutmut_97 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_98'] = x_run__mutmut_98 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_99'] = x_run__mutmut_99 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_100'] = x_run__mutmut_100 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_101'] = x_run__mutmut_101 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_102'] = x_run__mutmut_102 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_103'] = x_run__mutmut_103 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_104'] = x_run__mutmut_104 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_105'] = x_run__mutmut_105 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_106'] = x_run__mutmut_106 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_107'] = x_run__mutmut_107 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_108'] = x_run__mutmut_108 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_109'] = x_run__mutmut_109 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_110'] = x_run__mutmut_110 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_111'] = x_run__mutmut_111 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_112'] = x_run__mutmut_112 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_113'] = x_run__mutmut_113 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_114'] = x_run__mutmut_114 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_115'] = x_run__mutmut_115 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_116'] = x_run__mutmut_116 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_117'] = x_run__mutmut_117 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_118'] = x_run__mutmut_118 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_119'] = x_run__mutmut_119 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_120'] = x_run__mutmut_120 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_121'] = x_run__mutmut_121 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_122'] = x_run__mutmut_122 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_123'] = x_run__mutmut_123 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_124'] = x_run__mutmut_124 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_125'] = x_run__mutmut_125 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_126'] = x_run__mutmut_126 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_127'] = x_run__mutmut_127 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_128'] = x_run__mutmut_128 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_129'] = x_run__mutmut_129 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_130'] = x_run__mutmut_130 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_131'] = x_run__mutmut_131 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_132'] = x_run__mutmut_132 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_133'] = x_run__mutmut_133 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_134'] = x_run__mutmut_134 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_135'] = x_run__mutmut_135 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_136'] = x_run__mutmut_136 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_137'] = x_run__mutmut_137 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_138'] = x_run__mutmut_138 # type: ignore # mutmut generated
mutants_x_main__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_main__mutmut)
def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=config.RESULTS_DIR / "temporal_pilot.json")
    parser.add_argument("--csv", type=Path, default=None)
    args = parser.parse_args(argv)
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(name)s %(message)s")
    spec = DATASETS["credit_card"]
    if args.csv is not None:
        spec = DatasetSpec(**{**spec.__dict__, "csv": args.csv})
    result = run(spec)
    with spec.csv.open("rb") as stream:
        data_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    with Path(__file__).open("rb") as stream:
        script_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    result["provenance"] = {
        "dataset_sha256": data_sha,
        "script_sha256": script_sha,
        "protocol": "verification/temporal_pilot.md",
        "python": platform.python_version(),
        "platform": platform.platform(),
        "machine": platform.machine(),
        "cpu_count": os.cpu_count(),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    from provenance import write_record

    write_record(
        args.output.with_name("run_temporal_pilot.json"),
        experiment="temporal_pilot",
        seeds=list(config.BENCHMARK_SEEDS),
        dataset="credit_card",
        data_path=None,
        settings={**result["settings"], **result["provenance"]},
        outputs=[args.output.name],
    )
    print(f"wrote {args.output}")
    return 0


def x_main__mutmut_orig(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=config.RESULTS_DIR / "temporal_pilot.json")
    parser.add_argument("--csv", type=Path, default=None)
    args = parser.parse_args(argv)
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(name)s %(message)s")
    spec = DATASETS["credit_card"]
    if args.csv is not None:
        spec = DatasetSpec(**{**spec.__dict__, "csv": args.csv})
    result = run(spec)
    with spec.csv.open("rb") as stream:
        data_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    with Path(__file__).open("rb") as stream:
        script_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    result["provenance"] = {
        "dataset_sha256": data_sha,
        "script_sha256": script_sha,
        "protocol": "verification/temporal_pilot.md",
        "python": platform.python_version(),
        "platform": platform.platform(),
        "machine": platform.machine(),
        "cpu_count": os.cpu_count(),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    from provenance import write_record

    write_record(
        args.output.with_name("run_temporal_pilot.json"),
        experiment="temporal_pilot",
        seeds=list(config.BENCHMARK_SEEDS),
        dataset="credit_card",
        data_path=None,
        settings={**result["settings"], **result["provenance"]},
        outputs=[args.output.name],
    )
    print(f"wrote {args.output}")
    return 0


def x_main__mutmut_1(argv: list[str] | None = None) -> int:
    parser = None
    parser.add_argument("--output", type=Path, default=config.RESULTS_DIR / "temporal_pilot.json")
    parser.add_argument("--csv", type=Path, default=None)
    args = parser.parse_args(argv)
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(name)s %(message)s")
    spec = DATASETS["credit_card"]
    if args.csv is not None:
        spec = DatasetSpec(**{**spec.__dict__, "csv": args.csv})
    result = run(spec)
    with spec.csv.open("rb") as stream:
        data_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    with Path(__file__).open("rb") as stream:
        script_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    result["provenance"] = {
        "dataset_sha256": data_sha,
        "script_sha256": script_sha,
        "protocol": "verification/temporal_pilot.md",
        "python": platform.python_version(),
        "platform": platform.platform(),
        "machine": platform.machine(),
        "cpu_count": os.cpu_count(),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    from provenance import write_record

    write_record(
        args.output.with_name("run_temporal_pilot.json"),
        experiment="temporal_pilot",
        seeds=list(config.BENCHMARK_SEEDS),
        dataset="credit_card",
        data_path=None,
        settings={**result["settings"], **result["provenance"]},
        outputs=[args.output.name],
    )
    print(f"wrote {args.output}")
    return 0


def x_main__mutmut_2(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=None)
    parser.add_argument("--output", type=Path, default=config.RESULTS_DIR / "temporal_pilot.json")
    parser.add_argument("--csv", type=Path, default=None)
    args = parser.parse_args(argv)
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(name)s %(message)s")
    spec = DATASETS["credit_card"]
    if args.csv is not None:
        spec = DatasetSpec(**{**spec.__dict__, "csv": args.csv})
    result = run(spec)
    with spec.csv.open("rb") as stream:
        data_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    with Path(__file__).open("rb") as stream:
        script_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    result["provenance"] = {
        "dataset_sha256": data_sha,
        "script_sha256": script_sha,
        "protocol": "verification/temporal_pilot.md",
        "python": platform.python_version(),
        "platform": platform.platform(),
        "machine": platform.machine(),
        "cpu_count": os.cpu_count(),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    from provenance import write_record

    write_record(
        args.output.with_name("run_temporal_pilot.json"),
        experiment="temporal_pilot",
        seeds=list(config.BENCHMARK_SEEDS),
        dataset="credit_card",
        data_path=None,
        settings={**result["settings"], **result["provenance"]},
        outputs=[args.output.name],
    )
    print(f"wrote {args.output}")
    return 0


def x_main__mutmut_3(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(None, type=Path, default=config.RESULTS_DIR / "temporal_pilot.json")
    parser.add_argument("--csv", type=Path, default=None)
    args = parser.parse_args(argv)
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(name)s %(message)s")
    spec = DATASETS["credit_card"]
    if args.csv is not None:
        spec = DatasetSpec(**{**spec.__dict__, "csv": args.csv})
    result = run(spec)
    with spec.csv.open("rb") as stream:
        data_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    with Path(__file__).open("rb") as stream:
        script_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    result["provenance"] = {
        "dataset_sha256": data_sha,
        "script_sha256": script_sha,
        "protocol": "verification/temporal_pilot.md",
        "python": platform.python_version(),
        "platform": platform.platform(),
        "machine": platform.machine(),
        "cpu_count": os.cpu_count(),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    from provenance import write_record

    write_record(
        args.output.with_name("run_temporal_pilot.json"),
        experiment="temporal_pilot",
        seeds=list(config.BENCHMARK_SEEDS),
        dataset="credit_card",
        data_path=None,
        settings={**result["settings"], **result["provenance"]},
        outputs=[args.output.name],
    )
    print(f"wrote {args.output}")
    return 0


def x_main__mutmut_4(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=None, default=config.RESULTS_DIR / "temporal_pilot.json")
    parser.add_argument("--csv", type=Path, default=None)
    args = parser.parse_args(argv)
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(name)s %(message)s")
    spec = DATASETS["credit_card"]
    if args.csv is not None:
        spec = DatasetSpec(**{**spec.__dict__, "csv": args.csv})
    result = run(spec)
    with spec.csv.open("rb") as stream:
        data_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    with Path(__file__).open("rb") as stream:
        script_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    result["provenance"] = {
        "dataset_sha256": data_sha,
        "script_sha256": script_sha,
        "protocol": "verification/temporal_pilot.md",
        "python": platform.python_version(),
        "platform": platform.platform(),
        "machine": platform.machine(),
        "cpu_count": os.cpu_count(),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    from provenance import write_record

    write_record(
        args.output.with_name("run_temporal_pilot.json"),
        experiment="temporal_pilot",
        seeds=list(config.BENCHMARK_SEEDS),
        dataset="credit_card",
        data_path=None,
        settings={**result["settings"], **result["provenance"]},
        outputs=[args.output.name],
    )
    print(f"wrote {args.output}")
    return 0


def x_main__mutmut_5(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=None)
    parser.add_argument("--csv", type=Path, default=None)
    args = parser.parse_args(argv)
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(name)s %(message)s")
    spec = DATASETS["credit_card"]
    if args.csv is not None:
        spec = DatasetSpec(**{**spec.__dict__, "csv": args.csv})
    result = run(spec)
    with spec.csv.open("rb") as stream:
        data_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    with Path(__file__).open("rb") as stream:
        script_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    result["provenance"] = {
        "dataset_sha256": data_sha,
        "script_sha256": script_sha,
        "protocol": "verification/temporal_pilot.md",
        "python": platform.python_version(),
        "platform": platform.platform(),
        "machine": platform.machine(),
        "cpu_count": os.cpu_count(),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    from provenance import write_record

    write_record(
        args.output.with_name("run_temporal_pilot.json"),
        experiment="temporal_pilot",
        seeds=list(config.BENCHMARK_SEEDS),
        dataset="credit_card",
        data_path=None,
        settings={**result["settings"], **result["provenance"]},
        outputs=[args.output.name],
    )
    print(f"wrote {args.output}")
    return 0


def x_main__mutmut_6(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(type=Path, default=config.RESULTS_DIR / "temporal_pilot.json")
    parser.add_argument("--csv", type=Path, default=None)
    args = parser.parse_args(argv)
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(name)s %(message)s")
    spec = DATASETS["credit_card"]
    if args.csv is not None:
        spec = DatasetSpec(**{**spec.__dict__, "csv": args.csv})
    result = run(spec)
    with spec.csv.open("rb") as stream:
        data_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    with Path(__file__).open("rb") as stream:
        script_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    result["provenance"] = {
        "dataset_sha256": data_sha,
        "script_sha256": script_sha,
        "protocol": "verification/temporal_pilot.md",
        "python": platform.python_version(),
        "platform": platform.platform(),
        "machine": platform.machine(),
        "cpu_count": os.cpu_count(),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    from provenance import write_record

    write_record(
        args.output.with_name("run_temporal_pilot.json"),
        experiment="temporal_pilot",
        seeds=list(config.BENCHMARK_SEEDS),
        dataset="credit_card",
        data_path=None,
        settings={**result["settings"], **result["provenance"]},
        outputs=[args.output.name],
    )
    print(f"wrote {args.output}")
    return 0


def x_main__mutmut_7(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", default=config.RESULTS_DIR / "temporal_pilot.json")
    parser.add_argument("--csv", type=Path, default=None)
    args = parser.parse_args(argv)
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(name)s %(message)s")
    spec = DATASETS["credit_card"]
    if args.csv is not None:
        spec = DatasetSpec(**{**spec.__dict__, "csv": args.csv})
    result = run(spec)
    with spec.csv.open("rb") as stream:
        data_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    with Path(__file__).open("rb") as stream:
        script_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    result["provenance"] = {
        "dataset_sha256": data_sha,
        "script_sha256": script_sha,
        "protocol": "verification/temporal_pilot.md",
        "python": platform.python_version(),
        "platform": platform.platform(),
        "machine": platform.machine(),
        "cpu_count": os.cpu_count(),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    from provenance import write_record

    write_record(
        args.output.with_name("run_temporal_pilot.json"),
        experiment="temporal_pilot",
        seeds=list(config.BENCHMARK_SEEDS),
        dataset="credit_card",
        data_path=None,
        settings={**result["settings"], **result["provenance"]},
        outputs=[args.output.name],
    )
    print(f"wrote {args.output}")
    return 0


def x_main__mutmut_8(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, )
    parser.add_argument("--csv", type=Path, default=None)
    args = parser.parse_args(argv)
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(name)s %(message)s")
    spec = DATASETS["credit_card"]
    if args.csv is not None:
        spec = DatasetSpec(**{**spec.__dict__, "csv": args.csv})
    result = run(spec)
    with spec.csv.open("rb") as stream:
        data_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    with Path(__file__).open("rb") as stream:
        script_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    result["provenance"] = {
        "dataset_sha256": data_sha,
        "script_sha256": script_sha,
        "protocol": "verification/temporal_pilot.md",
        "python": platform.python_version(),
        "platform": platform.platform(),
        "machine": platform.machine(),
        "cpu_count": os.cpu_count(),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    from provenance import write_record

    write_record(
        args.output.with_name("run_temporal_pilot.json"),
        experiment="temporal_pilot",
        seeds=list(config.BENCHMARK_SEEDS),
        dataset="credit_card",
        data_path=None,
        settings={**result["settings"], **result["provenance"]},
        outputs=[args.output.name],
    )
    print(f"wrote {args.output}")
    return 0


def x_main__mutmut_9(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("XX--outputXX", type=Path, default=config.RESULTS_DIR / "temporal_pilot.json")
    parser.add_argument("--csv", type=Path, default=None)
    args = parser.parse_args(argv)
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(name)s %(message)s")
    spec = DATASETS["credit_card"]
    if args.csv is not None:
        spec = DatasetSpec(**{**spec.__dict__, "csv": args.csv})
    result = run(spec)
    with spec.csv.open("rb") as stream:
        data_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    with Path(__file__).open("rb") as stream:
        script_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    result["provenance"] = {
        "dataset_sha256": data_sha,
        "script_sha256": script_sha,
        "protocol": "verification/temporal_pilot.md",
        "python": platform.python_version(),
        "platform": platform.platform(),
        "machine": platform.machine(),
        "cpu_count": os.cpu_count(),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    from provenance import write_record

    write_record(
        args.output.with_name("run_temporal_pilot.json"),
        experiment="temporal_pilot",
        seeds=list(config.BENCHMARK_SEEDS),
        dataset="credit_card",
        data_path=None,
        settings={**result["settings"], **result["provenance"]},
        outputs=[args.output.name],
    )
    print(f"wrote {args.output}")
    return 0


def x_main__mutmut_10(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--OUTPUT", type=Path, default=config.RESULTS_DIR / "temporal_pilot.json")
    parser.add_argument("--csv", type=Path, default=None)
    args = parser.parse_args(argv)
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(name)s %(message)s")
    spec = DATASETS["credit_card"]
    if args.csv is not None:
        spec = DatasetSpec(**{**spec.__dict__, "csv": args.csv})
    result = run(spec)
    with spec.csv.open("rb") as stream:
        data_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    with Path(__file__).open("rb") as stream:
        script_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    result["provenance"] = {
        "dataset_sha256": data_sha,
        "script_sha256": script_sha,
        "protocol": "verification/temporal_pilot.md",
        "python": platform.python_version(),
        "platform": platform.platform(),
        "machine": platform.machine(),
        "cpu_count": os.cpu_count(),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    from provenance import write_record

    write_record(
        args.output.with_name("run_temporal_pilot.json"),
        experiment="temporal_pilot",
        seeds=list(config.BENCHMARK_SEEDS),
        dataset="credit_card",
        data_path=None,
        settings={**result["settings"], **result["provenance"]},
        outputs=[args.output.name],
    )
    print(f"wrote {args.output}")
    return 0


def x_main__mutmut_11(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=config.RESULTS_DIR * "temporal_pilot.json")
    parser.add_argument("--csv", type=Path, default=None)
    args = parser.parse_args(argv)
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(name)s %(message)s")
    spec = DATASETS["credit_card"]
    if args.csv is not None:
        spec = DatasetSpec(**{**spec.__dict__, "csv": args.csv})
    result = run(spec)
    with spec.csv.open("rb") as stream:
        data_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    with Path(__file__).open("rb") as stream:
        script_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    result["provenance"] = {
        "dataset_sha256": data_sha,
        "script_sha256": script_sha,
        "protocol": "verification/temporal_pilot.md",
        "python": platform.python_version(),
        "platform": platform.platform(),
        "machine": platform.machine(),
        "cpu_count": os.cpu_count(),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    from provenance import write_record

    write_record(
        args.output.with_name("run_temporal_pilot.json"),
        experiment="temporal_pilot",
        seeds=list(config.BENCHMARK_SEEDS),
        dataset="credit_card",
        data_path=None,
        settings={**result["settings"], **result["provenance"]},
        outputs=[args.output.name],
    )
    print(f"wrote {args.output}")
    return 0


def x_main__mutmut_12(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=config.RESULTS_DIR / "XXtemporal_pilot.jsonXX")
    parser.add_argument("--csv", type=Path, default=None)
    args = parser.parse_args(argv)
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(name)s %(message)s")
    spec = DATASETS["credit_card"]
    if args.csv is not None:
        spec = DatasetSpec(**{**spec.__dict__, "csv": args.csv})
    result = run(spec)
    with spec.csv.open("rb") as stream:
        data_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    with Path(__file__).open("rb") as stream:
        script_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    result["provenance"] = {
        "dataset_sha256": data_sha,
        "script_sha256": script_sha,
        "protocol": "verification/temporal_pilot.md",
        "python": platform.python_version(),
        "platform": platform.platform(),
        "machine": platform.machine(),
        "cpu_count": os.cpu_count(),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    from provenance import write_record

    write_record(
        args.output.with_name("run_temporal_pilot.json"),
        experiment="temporal_pilot",
        seeds=list(config.BENCHMARK_SEEDS),
        dataset="credit_card",
        data_path=None,
        settings={**result["settings"], **result["provenance"]},
        outputs=[args.output.name],
    )
    print(f"wrote {args.output}")
    return 0


def x_main__mutmut_13(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=config.RESULTS_DIR / "TEMPORAL_PILOT.JSON")
    parser.add_argument("--csv", type=Path, default=None)
    args = parser.parse_args(argv)
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(name)s %(message)s")
    spec = DATASETS["credit_card"]
    if args.csv is not None:
        spec = DatasetSpec(**{**spec.__dict__, "csv": args.csv})
    result = run(spec)
    with spec.csv.open("rb") as stream:
        data_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    with Path(__file__).open("rb") as stream:
        script_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    result["provenance"] = {
        "dataset_sha256": data_sha,
        "script_sha256": script_sha,
        "protocol": "verification/temporal_pilot.md",
        "python": platform.python_version(),
        "platform": platform.platform(),
        "machine": platform.machine(),
        "cpu_count": os.cpu_count(),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    from provenance import write_record

    write_record(
        args.output.with_name("run_temporal_pilot.json"),
        experiment="temporal_pilot",
        seeds=list(config.BENCHMARK_SEEDS),
        dataset="credit_card",
        data_path=None,
        settings={**result["settings"], **result["provenance"]},
        outputs=[args.output.name],
    )
    print(f"wrote {args.output}")
    return 0


def x_main__mutmut_14(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=config.RESULTS_DIR / "temporal_pilot.json")
    parser.add_argument(None, type=Path, default=None)
    args = parser.parse_args(argv)
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(name)s %(message)s")
    spec = DATASETS["credit_card"]
    if args.csv is not None:
        spec = DatasetSpec(**{**spec.__dict__, "csv": args.csv})
    result = run(spec)
    with spec.csv.open("rb") as stream:
        data_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    with Path(__file__).open("rb") as stream:
        script_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    result["provenance"] = {
        "dataset_sha256": data_sha,
        "script_sha256": script_sha,
        "protocol": "verification/temporal_pilot.md",
        "python": platform.python_version(),
        "platform": platform.platform(),
        "machine": platform.machine(),
        "cpu_count": os.cpu_count(),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    from provenance import write_record

    write_record(
        args.output.with_name("run_temporal_pilot.json"),
        experiment="temporal_pilot",
        seeds=list(config.BENCHMARK_SEEDS),
        dataset="credit_card",
        data_path=None,
        settings={**result["settings"], **result["provenance"]},
        outputs=[args.output.name],
    )
    print(f"wrote {args.output}")
    return 0


def x_main__mutmut_15(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=config.RESULTS_DIR / "temporal_pilot.json")
    parser.add_argument("--csv", type=None, default=None)
    args = parser.parse_args(argv)
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(name)s %(message)s")
    spec = DATASETS["credit_card"]
    if args.csv is not None:
        spec = DatasetSpec(**{**spec.__dict__, "csv": args.csv})
    result = run(spec)
    with spec.csv.open("rb") as stream:
        data_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    with Path(__file__).open("rb") as stream:
        script_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    result["provenance"] = {
        "dataset_sha256": data_sha,
        "script_sha256": script_sha,
        "protocol": "verification/temporal_pilot.md",
        "python": platform.python_version(),
        "platform": platform.platform(),
        "machine": platform.machine(),
        "cpu_count": os.cpu_count(),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    from provenance import write_record

    write_record(
        args.output.with_name("run_temporal_pilot.json"),
        experiment="temporal_pilot",
        seeds=list(config.BENCHMARK_SEEDS),
        dataset="credit_card",
        data_path=None,
        settings={**result["settings"], **result["provenance"]},
        outputs=[args.output.name],
    )
    print(f"wrote {args.output}")
    return 0


def x_main__mutmut_16(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=config.RESULTS_DIR / "temporal_pilot.json")
    parser.add_argument(type=Path, default=None)
    args = parser.parse_args(argv)
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(name)s %(message)s")
    spec = DATASETS["credit_card"]
    if args.csv is not None:
        spec = DatasetSpec(**{**spec.__dict__, "csv": args.csv})
    result = run(spec)
    with spec.csv.open("rb") as stream:
        data_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    with Path(__file__).open("rb") as stream:
        script_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    result["provenance"] = {
        "dataset_sha256": data_sha,
        "script_sha256": script_sha,
        "protocol": "verification/temporal_pilot.md",
        "python": platform.python_version(),
        "platform": platform.platform(),
        "machine": platform.machine(),
        "cpu_count": os.cpu_count(),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    from provenance import write_record

    write_record(
        args.output.with_name("run_temporal_pilot.json"),
        experiment="temporal_pilot",
        seeds=list(config.BENCHMARK_SEEDS),
        dataset="credit_card",
        data_path=None,
        settings={**result["settings"], **result["provenance"]},
        outputs=[args.output.name],
    )
    print(f"wrote {args.output}")
    return 0


def x_main__mutmut_17(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=config.RESULTS_DIR / "temporal_pilot.json")
    parser.add_argument("--csv", default=None)
    args = parser.parse_args(argv)
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(name)s %(message)s")
    spec = DATASETS["credit_card"]
    if args.csv is not None:
        spec = DatasetSpec(**{**spec.__dict__, "csv": args.csv})
    result = run(spec)
    with spec.csv.open("rb") as stream:
        data_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    with Path(__file__).open("rb") as stream:
        script_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    result["provenance"] = {
        "dataset_sha256": data_sha,
        "script_sha256": script_sha,
        "protocol": "verification/temporal_pilot.md",
        "python": platform.python_version(),
        "platform": platform.platform(),
        "machine": platform.machine(),
        "cpu_count": os.cpu_count(),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    from provenance import write_record

    write_record(
        args.output.with_name("run_temporal_pilot.json"),
        experiment="temporal_pilot",
        seeds=list(config.BENCHMARK_SEEDS),
        dataset="credit_card",
        data_path=None,
        settings={**result["settings"], **result["provenance"]},
        outputs=[args.output.name],
    )
    print(f"wrote {args.output}")
    return 0


def x_main__mutmut_18(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=config.RESULTS_DIR / "temporal_pilot.json")
    parser.add_argument("--csv", type=Path, )
    args = parser.parse_args(argv)
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(name)s %(message)s")
    spec = DATASETS["credit_card"]
    if args.csv is not None:
        spec = DatasetSpec(**{**spec.__dict__, "csv": args.csv})
    result = run(spec)
    with spec.csv.open("rb") as stream:
        data_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    with Path(__file__).open("rb") as stream:
        script_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    result["provenance"] = {
        "dataset_sha256": data_sha,
        "script_sha256": script_sha,
        "protocol": "verification/temporal_pilot.md",
        "python": platform.python_version(),
        "platform": platform.platform(),
        "machine": platform.machine(),
        "cpu_count": os.cpu_count(),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    from provenance import write_record

    write_record(
        args.output.with_name("run_temporal_pilot.json"),
        experiment="temporal_pilot",
        seeds=list(config.BENCHMARK_SEEDS),
        dataset="credit_card",
        data_path=None,
        settings={**result["settings"], **result["provenance"]},
        outputs=[args.output.name],
    )
    print(f"wrote {args.output}")
    return 0


def x_main__mutmut_19(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=config.RESULTS_DIR / "temporal_pilot.json")
    parser.add_argument("XX--csvXX", type=Path, default=None)
    args = parser.parse_args(argv)
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(name)s %(message)s")
    spec = DATASETS["credit_card"]
    if args.csv is not None:
        spec = DatasetSpec(**{**spec.__dict__, "csv": args.csv})
    result = run(spec)
    with spec.csv.open("rb") as stream:
        data_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    with Path(__file__).open("rb") as stream:
        script_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    result["provenance"] = {
        "dataset_sha256": data_sha,
        "script_sha256": script_sha,
        "protocol": "verification/temporal_pilot.md",
        "python": platform.python_version(),
        "platform": platform.platform(),
        "machine": platform.machine(),
        "cpu_count": os.cpu_count(),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    from provenance import write_record

    write_record(
        args.output.with_name("run_temporal_pilot.json"),
        experiment="temporal_pilot",
        seeds=list(config.BENCHMARK_SEEDS),
        dataset="credit_card",
        data_path=None,
        settings={**result["settings"], **result["provenance"]},
        outputs=[args.output.name],
    )
    print(f"wrote {args.output}")
    return 0


def x_main__mutmut_20(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=config.RESULTS_DIR / "temporal_pilot.json")
    parser.add_argument("--CSV", type=Path, default=None)
    args = parser.parse_args(argv)
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(name)s %(message)s")
    spec = DATASETS["credit_card"]
    if args.csv is not None:
        spec = DatasetSpec(**{**spec.__dict__, "csv": args.csv})
    result = run(spec)
    with spec.csv.open("rb") as stream:
        data_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    with Path(__file__).open("rb") as stream:
        script_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    result["provenance"] = {
        "dataset_sha256": data_sha,
        "script_sha256": script_sha,
        "protocol": "verification/temporal_pilot.md",
        "python": platform.python_version(),
        "platform": platform.platform(),
        "machine": platform.machine(),
        "cpu_count": os.cpu_count(),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    from provenance import write_record

    write_record(
        args.output.with_name("run_temporal_pilot.json"),
        experiment="temporal_pilot",
        seeds=list(config.BENCHMARK_SEEDS),
        dataset="credit_card",
        data_path=None,
        settings={**result["settings"], **result["provenance"]},
        outputs=[args.output.name],
    )
    print(f"wrote {args.output}")
    return 0


def x_main__mutmut_21(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=config.RESULTS_DIR / "temporal_pilot.json")
    parser.add_argument("--csv", type=Path, default=None)
    args = None
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(name)s %(message)s")
    spec = DATASETS["credit_card"]
    if args.csv is not None:
        spec = DatasetSpec(**{**spec.__dict__, "csv": args.csv})
    result = run(spec)
    with spec.csv.open("rb") as stream:
        data_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    with Path(__file__).open("rb") as stream:
        script_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    result["provenance"] = {
        "dataset_sha256": data_sha,
        "script_sha256": script_sha,
        "protocol": "verification/temporal_pilot.md",
        "python": platform.python_version(),
        "platform": platform.platform(),
        "machine": platform.machine(),
        "cpu_count": os.cpu_count(),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    from provenance import write_record

    write_record(
        args.output.with_name("run_temporal_pilot.json"),
        experiment="temporal_pilot",
        seeds=list(config.BENCHMARK_SEEDS),
        dataset="credit_card",
        data_path=None,
        settings={**result["settings"], **result["provenance"]},
        outputs=[args.output.name],
    )
    print(f"wrote {args.output}")
    return 0


def x_main__mutmut_22(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=config.RESULTS_DIR / "temporal_pilot.json")
    parser.add_argument("--csv", type=Path, default=None)
    args = parser.parse_args(None)
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(name)s %(message)s")
    spec = DATASETS["credit_card"]
    if args.csv is not None:
        spec = DatasetSpec(**{**spec.__dict__, "csv": args.csv})
    result = run(spec)
    with spec.csv.open("rb") as stream:
        data_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    with Path(__file__).open("rb") as stream:
        script_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    result["provenance"] = {
        "dataset_sha256": data_sha,
        "script_sha256": script_sha,
        "protocol": "verification/temporal_pilot.md",
        "python": platform.python_version(),
        "platform": platform.platform(),
        "machine": platform.machine(),
        "cpu_count": os.cpu_count(),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    from provenance import write_record

    write_record(
        args.output.with_name("run_temporal_pilot.json"),
        experiment="temporal_pilot",
        seeds=list(config.BENCHMARK_SEEDS),
        dataset="credit_card",
        data_path=None,
        settings={**result["settings"], **result["provenance"]},
        outputs=[args.output.name],
    )
    print(f"wrote {args.output}")
    return 0


def x_main__mutmut_23(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=config.RESULTS_DIR / "temporal_pilot.json")
    parser.add_argument("--csv", type=Path, default=None)
    args = parser.parse_args(argv)
    logging.basicConfig(level=None, format="%(asctime)s %(name)s %(message)s")
    spec = DATASETS["credit_card"]
    if args.csv is not None:
        spec = DatasetSpec(**{**spec.__dict__, "csv": args.csv})
    result = run(spec)
    with spec.csv.open("rb") as stream:
        data_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    with Path(__file__).open("rb") as stream:
        script_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    result["provenance"] = {
        "dataset_sha256": data_sha,
        "script_sha256": script_sha,
        "protocol": "verification/temporal_pilot.md",
        "python": platform.python_version(),
        "platform": platform.platform(),
        "machine": platform.machine(),
        "cpu_count": os.cpu_count(),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    from provenance import write_record

    write_record(
        args.output.with_name("run_temporal_pilot.json"),
        experiment="temporal_pilot",
        seeds=list(config.BENCHMARK_SEEDS),
        dataset="credit_card",
        data_path=None,
        settings={**result["settings"], **result["provenance"]},
        outputs=[args.output.name],
    )
    print(f"wrote {args.output}")
    return 0


def x_main__mutmut_24(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=config.RESULTS_DIR / "temporal_pilot.json")
    parser.add_argument("--csv", type=Path, default=None)
    args = parser.parse_args(argv)
    logging.basicConfig(level=logging.INFO, format=None)
    spec = DATASETS["credit_card"]
    if args.csv is not None:
        spec = DatasetSpec(**{**spec.__dict__, "csv": args.csv})
    result = run(spec)
    with spec.csv.open("rb") as stream:
        data_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    with Path(__file__).open("rb") as stream:
        script_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    result["provenance"] = {
        "dataset_sha256": data_sha,
        "script_sha256": script_sha,
        "protocol": "verification/temporal_pilot.md",
        "python": platform.python_version(),
        "platform": platform.platform(),
        "machine": platform.machine(),
        "cpu_count": os.cpu_count(),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    from provenance import write_record

    write_record(
        args.output.with_name("run_temporal_pilot.json"),
        experiment="temporal_pilot",
        seeds=list(config.BENCHMARK_SEEDS),
        dataset="credit_card",
        data_path=None,
        settings={**result["settings"], **result["provenance"]},
        outputs=[args.output.name],
    )
    print(f"wrote {args.output}")
    return 0


def x_main__mutmut_25(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=config.RESULTS_DIR / "temporal_pilot.json")
    parser.add_argument("--csv", type=Path, default=None)
    args = parser.parse_args(argv)
    logging.basicConfig(format="%(asctime)s %(name)s %(message)s")
    spec = DATASETS["credit_card"]
    if args.csv is not None:
        spec = DatasetSpec(**{**spec.__dict__, "csv": args.csv})
    result = run(spec)
    with spec.csv.open("rb") as stream:
        data_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    with Path(__file__).open("rb") as stream:
        script_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    result["provenance"] = {
        "dataset_sha256": data_sha,
        "script_sha256": script_sha,
        "protocol": "verification/temporal_pilot.md",
        "python": platform.python_version(),
        "platform": platform.platform(),
        "machine": platform.machine(),
        "cpu_count": os.cpu_count(),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    from provenance import write_record

    write_record(
        args.output.with_name("run_temporal_pilot.json"),
        experiment="temporal_pilot",
        seeds=list(config.BENCHMARK_SEEDS),
        dataset="credit_card",
        data_path=None,
        settings={**result["settings"], **result["provenance"]},
        outputs=[args.output.name],
    )
    print(f"wrote {args.output}")
    return 0


def x_main__mutmut_26(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=config.RESULTS_DIR / "temporal_pilot.json")
    parser.add_argument("--csv", type=Path, default=None)
    args = parser.parse_args(argv)
    logging.basicConfig(level=logging.INFO, )
    spec = DATASETS["credit_card"]
    if args.csv is not None:
        spec = DatasetSpec(**{**spec.__dict__, "csv": args.csv})
    result = run(spec)
    with spec.csv.open("rb") as stream:
        data_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    with Path(__file__).open("rb") as stream:
        script_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    result["provenance"] = {
        "dataset_sha256": data_sha,
        "script_sha256": script_sha,
        "protocol": "verification/temporal_pilot.md",
        "python": platform.python_version(),
        "platform": platform.platform(),
        "machine": platform.machine(),
        "cpu_count": os.cpu_count(),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    from provenance import write_record

    write_record(
        args.output.with_name("run_temporal_pilot.json"),
        experiment="temporal_pilot",
        seeds=list(config.BENCHMARK_SEEDS),
        dataset="credit_card",
        data_path=None,
        settings={**result["settings"], **result["provenance"]},
        outputs=[args.output.name],
    )
    print(f"wrote {args.output}")
    return 0


def x_main__mutmut_27(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=config.RESULTS_DIR / "temporal_pilot.json")
    parser.add_argument("--csv", type=Path, default=None)
    args = parser.parse_args(argv)
    logging.basicConfig(level=logging.INFO, format="XX%(asctime)s %(name)s %(message)sXX")
    spec = DATASETS["credit_card"]
    if args.csv is not None:
        spec = DatasetSpec(**{**spec.__dict__, "csv": args.csv})
    result = run(spec)
    with spec.csv.open("rb") as stream:
        data_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    with Path(__file__).open("rb") as stream:
        script_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    result["provenance"] = {
        "dataset_sha256": data_sha,
        "script_sha256": script_sha,
        "protocol": "verification/temporal_pilot.md",
        "python": platform.python_version(),
        "platform": platform.platform(),
        "machine": platform.machine(),
        "cpu_count": os.cpu_count(),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    from provenance import write_record

    write_record(
        args.output.with_name("run_temporal_pilot.json"),
        experiment="temporal_pilot",
        seeds=list(config.BENCHMARK_SEEDS),
        dataset="credit_card",
        data_path=None,
        settings={**result["settings"], **result["provenance"]},
        outputs=[args.output.name],
    )
    print(f"wrote {args.output}")
    return 0


def x_main__mutmut_28(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=config.RESULTS_DIR / "temporal_pilot.json")
    parser.add_argument("--csv", type=Path, default=None)
    args = parser.parse_args(argv)
    logging.basicConfig(level=logging.INFO, format="%(ASCTIME)S %(NAME)S %(MESSAGE)S")
    spec = DATASETS["credit_card"]
    if args.csv is not None:
        spec = DatasetSpec(**{**spec.__dict__, "csv": args.csv})
    result = run(spec)
    with spec.csv.open("rb") as stream:
        data_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    with Path(__file__).open("rb") as stream:
        script_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    result["provenance"] = {
        "dataset_sha256": data_sha,
        "script_sha256": script_sha,
        "protocol": "verification/temporal_pilot.md",
        "python": platform.python_version(),
        "platform": platform.platform(),
        "machine": platform.machine(),
        "cpu_count": os.cpu_count(),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    from provenance import write_record

    write_record(
        args.output.with_name("run_temporal_pilot.json"),
        experiment="temporal_pilot",
        seeds=list(config.BENCHMARK_SEEDS),
        dataset="credit_card",
        data_path=None,
        settings={**result["settings"], **result["provenance"]},
        outputs=[args.output.name],
    )
    print(f"wrote {args.output}")
    return 0


def x_main__mutmut_29(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=config.RESULTS_DIR / "temporal_pilot.json")
    parser.add_argument("--csv", type=Path, default=None)
    args = parser.parse_args(argv)
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(name)s %(message)s")
    spec = None
    if args.csv is not None:
        spec = DatasetSpec(**{**spec.__dict__, "csv": args.csv})
    result = run(spec)
    with spec.csv.open("rb") as stream:
        data_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    with Path(__file__).open("rb") as stream:
        script_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    result["provenance"] = {
        "dataset_sha256": data_sha,
        "script_sha256": script_sha,
        "protocol": "verification/temporal_pilot.md",
        "python": platform.python_version(),
        "platform": platform.platform(),
        "machine": platform.machine(),
        "cpu_count": os.cpu_count(),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    from provenance import write_record

    write_record(
        args.output.with_name("run_temporal_pilot.json"),
        experiment="temporal_pilot",
        seeds=list(config.BENCHMARK_SEEDS),
        dataset="credit_card",
        data_path=None,
        settings={**result["settings"], **result["provenance"]},
        outputs=[args.output.name],
    )
    print(f"wrote {args.output}")
    return 0


def x_main__mutmut_30(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=config.RESULTS_DIR / "temporal_pilot.json")
    parser.add_argument("--csv", type=Path, default=None)
    args = parser.parse_args(argv)
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(name)s %(message)s")
    spec = DATASETS["XXcredit_cardXX"]
    if args.csv is not None:
        spec = DatasetSpec(**{**spec.__dict__, "csv": args.csv})
    result = run(spec)
    with spec.csv.open("rb") as stream:
        data_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    with Path(__file__).open("rb") as stream:
        script_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    result["provenance"] = {
        "dataset_sha256": data_sha,
        "script_sha256": script_sha,
        "protocol": "verification/temporal_pilot.md",
        "python": platform.python_version(),
        "platform": platform.platform(),
        "machine": platform.machine(),
        "cpu_count": os.cpu_count(),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    from provenance import write_record

    write_record(
        args.output.with_name("run_temporal_pilot.json"),
        experiment="temporal_pilot",
        seeds=list(config.BENCHMARK_SEEDS),
        dataset="credit_card",
        data_path=None,
        settings={**result["settings"], **result["provenance"]},
        outputs=[args.output.name],
    )
    print(f"wrote {args.output}")
    return 0


def x_main__mutmut_31(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=config.RESULTS_DIR / "temporal_pilot.json")
    parser.add_argument("--csv", type=Path, default=None)
    args = parser.parse_args(argv)
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(name)s %(message)s")
    spec = DATASETS["CREDIT_CARD"]
    if args.csv is not None:
        spec = DatasetSpec(**{**spec.__dict__, "csv": args.csv})
    result = run(spec)
    with spec.csv.open("rb") as stream:
        data_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    with Path(__file__).open("rb") as stream:
        script_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    result["provenance"] = {
        "dataset_sha256": data_sha,
        "script_sha256": script_sha,
        "protocol": "verification/temporal_pilot.md",
        "python": platform.python_version(),
        "platform": platform.platform(),
        "machine": platform.machine(),
        "cpu_count": os.cpu_count(),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    from provenance import write_record

    write_record(
        args.output.with_name("run_temporal_pilot.json"),
        experiment="temporal_pilot",
        seeds=list(config.BENCHMARK_SEEDS),
        dataset="credit_card",
        data_path=None,
        settings={**result["settings"], **result["provenance"]},
        outputs=[args.output.name],
    )
    print(f"wrote {args.output}")
    return 0


def x_main__mutmut_32(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=config.RESULTS_DIR / "temporal_pilot.json")
    parser.add_argument("--csv", type=Path, default=None)
    args = parser.parse_args(argv)
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(name)s %(message)s")
    spec = DATASETS["credit_card"]
    if args.csv is None:
        spec = DatasetSpec(**{**spec.__dict__, "csv": args.csv})
    result = run(spec)
    with spec.csv.open("rb") as stream:
        data_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    with Path(__file__).open("rb") as stream:
        script_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    result["provenance"] = {
        "dataset_sha256": data_sha,
        "script_sha256": script_sha,
        "protocol": "verification/temporal_pilot.md",
        "python": platform.python_version(),
        "platform": platform.platform(),
        "machine": platform.machine(),
        "cpu_count": os.cpu_count(),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    from provenance import write_record

    write_record(
        args.output.with_name("run_temporal_pilot.json"),
        experiment="temporal_pilot",
        seeds=list(config.BENCHMARK_SEEDS),
        dataset="credit_card",
        data_path=None,
        settings={**result["settings"], **result["provenance"]},
        outputs=[args.output.name],
    )
    print(f"wrote {args.output}")
    return 0


def x_main__mutmut_33(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=config.RESULTS_DIR / "temporal_pilot.json")
    parser.add_argument("--csv", type=Path, default=None)
    args = parser.parse_args(argv)
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(name)s %(message)s")
    spec = DATASETS["credit_card"]
    if args.csv is not None:
        spec = None
    result = run(spec)
    with spec.csv.open("rb") as stream:
        data_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    with Path(__file__).open("rb") as stream:
        script_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    result["provenance"] = {
        "dataset_sha256": data_sha,
        "script_sha256": script_sha,
        "protocol": "verification/temporal_pilot.md",
        "python": platform.python_version(),
        "platform": platform.platform(),
        "machine": platform.machine(),
        "cpu_count": os.cpu_count(),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    from provenance import write_record

    write_record(
        args.output.with_name("run_temporal_pilot.json"),
        experiment="temporal_pilot",
        seeds=list(config.BENCHMARK_SEEDS),
        dataset="credit_card",
        data_path=None,
        settings={**result["settings"], **result["provenance"]},
        outputs=[args.output.name],
    )
    print(f"wrote {args.output}")
    return 0


def x_main__mutmut_34(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=config.RESULTS_DIR / "temporal_pilot.json")
    parser.add_argument("--csv", type=Path, default=None)
    args = parser.parse_args(argv)
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(name)s %(message)s")
    spec = DATASETS["credit_card"]
    if args.csv is not None:
        spec = DatasetSpec(**{**spec.__dict__, "XXcsvXX": args.csv})
    result = run(spec)
    with spec.csv.open("rb") as stream:
        data_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    with Path(__file__).open("rb") as stream:
        script_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    result["provenance"] = {
        "dataset_sha256": data_sha,
        "script_sha256": script_sha,
        "protocol": "verification/temporal_pilot.md",
        "python": platform.python_version(),
        "platform": platform.platform(),
        "machine": platform.machine(),
        "cpu_count": os.cpu_count(),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    from provenance import write_record

    write_record(
        args.output.with_name("run_temporal_pilot.json"),
        experiment="temporal_pilot",
        seeds=list(config.BENCHMARK_SEEDS),
        dataset="credit_card",
        data_path=None,
        settings={**result["settings"], **result["provenance"]},
        outputs=[args.output.name],
    )
    print(f"wrote {args.output}")
    return 0


def x_main__mutmut_35(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=config.RESULTS_DIR / "temporal_pilot.json")
    parser.add_argument("--csv", type=Path, default=None)
    args = parser.parse_args(argv)
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(name)s %(message)s")
    spec = DATASETS["credit_card"]
    if args.csv is not None:
        spec = DatasetSpec(**{**spec.__dict__, "CSV": args.csv})
    result = run(spec)
    with spec.csv.open("rb") as stream:
        data_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    with Path(__file__).open("rb") as stream:
        script_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    result["provenance"] = {
        "dataset_sha256": data_sha,
        "script_sha256": script_sha,
        "protocol": "verification/temporal_pilot.md",
        "python": platform.python_version(),
        "platform": platform.platform(),
        "machine": platform.machine(),
        "cpu_count": os.cpu_count(),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    from provenance import write_record

    write_record(
        args.output.with_name("run_temporal_pilot.json"),
        experiment="temporal_pilot",
        seeds=list(config.BENCHMARK_SEEDS),
        dataset="credit_card",
        data_path=None,
        settings={**result["settings"], **result["provenance"]},
        outputs=[args.output.name],
    )
    print(f"wrote {args.output}")
    return 0


def x_main__mutmut_36(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=config.RESULTS_DIR / "temporal_pilot.json")
    parser.add_argument("--csv", type=Path, default=None)
    args = parser.parse_args(argv)
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(name)s %(message)s")
    spec = DATASETS["credit_card"]
    if args.csv is not None:
        spec = DatasetSpec(**{**spec.__dict__, "csv": args.csv})
    result = None
    with spec.csv.open("rb") as stream:
        data_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    with Path(__file__).open("rb") as stream:
        script_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    result["provenance"] = {
        "dataset_sha256": data_sha,
        "script_sha256": script_sha,
        "protocol": "verification/temporal_pilot.md",
        "python": platform.python_version(),
        "platform": platform.platform(),
        "machine": platform.machine(),
        "cpu_count": os.cpu_count(),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    from provenance import write_record

    write_record(
        args.output.with_name("run_temporal_pilot.json"),
        experiment="temporal_pilot",
        seeds=list(config.BENCHMARK_SEEDS),
        dataset="credit_card",
        data_path=None,
        settings={**result["settings"], **result["provenance"]},
        outputs=[args.output.name],
    )
    print(f"wrote {args.output}")
    return 0


def x_main__mutmut_37(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=config.RESULTS_DIR / "temporal_pilot.json")
    parser.add_argument("--csv", type=Path, default=None)
    args = parser.parse_args(argv)
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(name)s %(message)s")
    spec = DATASETS["credit_card"]
    if args.csv is not None:
        spec = DatasetSpec(**{**spec.__dict__, "csv": args.csv})
    result = run(None)
    with spec.csv.open("rb") as stream:
        data_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    with Path(__file__).open("rb") as stream:
        script_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    result["provenance"] = {
        "dataset_sha256": data_sha,
        "script_sha256": script_sha,
        "protocol": "verification/temporal_pilot.md",
        "python": platform.python_version(),
        "platform": platform.platform(),
        "machine": platform.machine(),
        "cpu_count": os.cpu_count(),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    from provenance import write_record

    write_record(
        args.output.with_name("run_temporal_pilot.json"),
        experiment="temporal_pilot",
        seeds=list(config.BENCHMARK_SEEDS),
        dataset="credit_card",
        data_path=None,
        settings={**result["settings"], **result["provenance"]},
        outputs=[args.output.name],
    )
    print(f"wrote {args.output}")
    return 0


def x_main__mutmut_38(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=config.RESULTS_DIR / "temporal_pilot.json")
    parser.add_argument("--csv", type=Path, default=None)
    args = parser.parse_args(argv)
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(name)s %(message)s")
    spec = DATASETS["credit_card"]
    if args.csv is not None:
        spec = DatasetSpec(**{**spec.__dict__, "csv": args.csv})
    result = run(spec)
    with spec.csv.open(None) as stream:
        data_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    with Path(__file__).open("rb") as stream:
        script_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    result["provenance"] = {
        "dataset_sha256": data_sha,
        "script_sha256": script_sha,
        "protocol": "verification/temporal_pilot.md",
        "python": platform.python_version(),
        "platform": platform.platform(),
        "machine": platform.machine(),
        "cpu_count": os.cpu_count(),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    from provenance import write_record

    write_record(
        args.output.with_name("run_temporal_pilot.json"),
        experiment="temporal_pilot",
        seeds=list(config.BENCHMARK_SEEDS),
        dataset="credit_card",
        data_path=None,
        settings={**result["settings"], **result["provenance"]},
        outputs=[args.output.name],
    )
    print(f"wrote {args.output}")
    return 0


def x_main__mutmut_39(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=config.RESULTS_DIR / "temporal_pilot.json")
    parser.add_argument("--csv", type=Path, default=None)
    args = parser.parse_args(argv)
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(name)s %(message)s")
    spec = DATASETS["credit_card"]
    if args.csv is not None:
        spec = DatasetSpec(**{**spec.__dict__, "csv": args.csv})
    result = run(spec)
    with spec.csv.open("XXrbXX") as stream:
        data_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    with Path(__file__).open("rb") as stream:
        script_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    result["provenance"] = {
        "dataset_sha256": data_sha,
        "script_sha256": script_sha,
        "protocol": "verification/temporal_pilot.md",
        "python": platform.python_version(),
        "platform": platform.platform(),
        "machine": platform.machine(),
        "cpu_count": os.cpu_count(),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    from provenance import write_record

    write_record(
        args.output.with_name("run_temporal_pilot.json"),
        experiment="temporal_pilot",
        seeds=list(config.BENCHMARK_SEEDS),
        dataset="credit_card",
        data_path=None,
        settings={**result["settings"], **result["provenance"]},
        outputs=[args.output.name],
    )
    print(f"wrote {args.output}")
    return 0


def x_main__mutmut_40(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=config.RESULTS_DIR / "temporal_pilot.json")
    parser.add_argument("--csv", type=Path, default=None)
    args = parser.parse_args(argv)
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(name)s %(message)s")
    spec = DATASETS["credit_card"]
    if args.csv is not None:
        spec = DatasetSpec(**{**spec.__dict__, "csv": args.csv})
    result = run(spec)
    with spec.csv.open("RB") as stream:
        data_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    with Path(__file__).open("rb") as stream:
        script_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    result["provenance"] = {
        "dataset_sha256": data_sha,
        "script_sha256": script_sha,
        "protocol": "verification/temporal_pilot.md",
        "python": platform.python_version(),
        "platform": platform.platform(),
        "machine": platform.machine(),
        "cpu_count": os.cpu_count(),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    from provenance import write_record

    write_record(
        args.output.with_name("run_temporal_pilot.json"),
        experiment="temporal_pilot",
        seeds=list(config.BENCHMARK_SEEDS),
        dataset="credit_card",
        data_path=None,
        settings={**result["settings"], **result["provenance"]},
        outputs=[args.output.name],
    )
    print(f"wrote {args.output}")
    return 0


def x_main__mutmut_41(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=config.RESULTS_DIR / "temporal_pilot.json")
    parser.add_argument("--csv", type=Path, default=None)
    args = parser.parse_args(argv)
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(name)s %(message)s")
    spec = DATASETS["credit_card"]
    if args.csv is not None:
        spec = DatasetSpec(**{**spec.__dict__, "csv": args.csv})
    result = run(spec)
    with spec.csv.open("rb") as stream:
        data_sha = None
    with Path(__file__).open("rb") as stream:
        script_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    result["provenance"] = {
        "dataset_sha256": data_sha,
        "script_sha256": script_sha,
        "protocol": "verification/temporal_pilot.md",
        "python": platform.python_version(),
        "platform": platform.platform(),
        "machine": platform.machine(),
        "cpu_count": os.cpu_count(),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    from provenance import write_record

    write_record(
        args.output.with_name("run_temporal_pilot.json"),
        experiment="temporal_pilot",
        seeds=list(config.BENCHMARK_SEEDS),
        dataset="credit_card",
        data_path=None,
        settings={**result["settings"], **result["provenance"]},
        outputs=[args.output.name],
    )
    print(f"wrote {args.output}")
    return 0


def x_main__mutmut_42(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=config.RESULTS_DIR / "temporal_pilot.json")
    parser.add_argument("--csv", type=Path, default=None)
    args = parser.parse_args(argv)
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(name)s %(message)s")
    spec = DATASETS["credit_card"]
    if args.csv is not None:
        spec = DatasetSpec(**{**spec.__dict__, "csv": args.csv})
    result = run(spec)
    with spec.csv.open("rb") as stream:
        data_sha = hashlib.file_digest(None, hashlib.sha256).hexdigest()
    with Path(__file__).open("rb") as stream:
        script_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    result["provenance"] = {
        "dataset_sha256": data_sha,
        "script_sha256": script_sha,
        "protocol": "verification/temporal_pilot.md",
        "python": platform.python_version(),
        "platform": platform.platform(),
        "machine": platform.machine(),
        "cpu_count": os.cpu_count(),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    from provenance import write_record

    write_record(
        args.output.with_name("run_temporal_pilot.json"),
        experiment="temporal_pilot",
        seeds=list(config.BENCHMARK_SEEDS),
        dataset="credit_card",
        data_path=None,
        settings={**result["settings"], **result["provenance"]},
        outputs=[args.output.name],
    )
    print(f"wrote {args.output}")
    return 0


def x_main__mutmut_43(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=config.RESULTS_DIR / "temporal_pilot.json")
    parser.add_argument("--csv", type=Path, default=None)
    args = parser.parse_args(argv)
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(name)s %(message)s")
    spec = DATASETS["credit_card"]
    if args.csv is not None:
        spec = DatasetSpec(**{**spec.__dict__, "csv": args.csv})
    result = run(spec)
    with spec.csv.open("rb") as stream:
        data_sha = hashlib.file_digest(stream, None).hexdigest()
    with Path(__file__).open("rb") as stream:
        script_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    result["provenance"] = {
        "dataset_sha256": data_sha,
        "script_sha256": script_sha,
        "protocol": "verification/temporal_pilot.md",
        "python": platform.python_version(),
        "platform": platform.platform(),
        "machine": platform.machine(),
        "cpu_count": os.cpu_count(),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    from provenance import write_record

    write_record(
        args.output.with_name("run_temporal_pilot.json"),
        experiment="temporal_pilot",
        seeds=list(config.BENCHMARK_SEEDS),
        dataset="credit_card",
        data_path=None,
        settings={**result["settings"], **result["provenance"]},
        outputs=[args.output.name],
    )
    print(f"wrote {args.output}")
    return 0


def x_main__mutmut_44(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=config.RESULTS_DIR / "temporal_pilot.json")
    parser.add_argument("--csv", type=Path, default=None)
    args = parser.parse_args(argv)
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(name)s %(message)s")
    spec = DATASETS["credit_card"]
    if args.csv is not None:
        spec = DatasetSpec(**{**spec.__dict__, "csv": args.csv})
    result = run(spec)
    with spec.csv.open("rb") as stream:
        data_sha = hashlib.file_digest(hashlib.sha256).hexdigest()
    with Path(__file__).open("rb") as stream:
        script_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    result["provenance"] = {
        "dataset_sha256": data_sha,
        "script_sha256": script_sha,
        "protocol": "verification/temporal_pilot.md",
        "python": platform.python_version(),
        "platform": platform.platform(),
        "machine": platform.machine(),
        "cpu_count": os.cpu_count(),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    from provenance import write_record

    write_record(
        args.output.with_name("run_temporal_pilot.json"),
        experiment="temporal_pilot",
        seeds=list(config.BENCHMARK_SEEDS),
        dataset="credit_card",
        data_path=None,
        settings={**result["settings"], **result["provenance"]},
        outputs=[args.output.name],
    )
    print(f"wrote {args.output}")
    return 0


def x_main__mutmut_45(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=config.RESULTS_DIR / "temporal_pilot.json")
    parser.add_argument("--csv", type=Path, default=None)
    args = parser.parse_args(argv)
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(name)s %(message)s")
    spec = DATASETS["credit_card"]
    if args.csv is not None:
        spec = DatasetSpec(**{**spec.__dict__, "csv": args.csv})
    result = run(spec)
    with spec.csv.open("rb") as stream:
        data_sha = hashlib.file_digest(stream, ).hexdigest()
    with Path(__file__).open("rb") as stream:
        script_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    result["provenance"] = {
        "dataset_sha256": data_sha,
        "script_sha256": script_sha,
        "protocol": "verification/temporal_pilot.md",
        "python": platform.python_version(),
        "platform": platform.platform(),
        "machine": platform.machine(),
        "cpu_count": os.cpu_count(),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    from provenance import write_record

    write_record(
        args.output.with_name("run_temporal_pilot.json"),
        experiment="temporal_pilot",
        seeds=list(config.BENCHMARK_SEEDS),
        dataset="credit_card",
        data_path=None,
        settings={**result["settings"], **result["provenance"]},
        outputs=[args.output.name],
    )
    print(f"wrote {args.output}")
    return 0


def x_main__mutmut_46(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=config.RESULTS_DIR / "temporal_pilot.json")
    parser.add_argument("--csv", type=Path, default=None)
    args = parser.parse_args(argv)
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(name)s %(message)s")
    spec = DATASETS["credit_card"]
    if args.csv is not None:
        spec = DatasetSpec(**{**spec.__dict__, "csv": args.csv})
    result = run(spec)
    with spec.csv.open("rb") as stream:
        data_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    with Path(__file__).open(None) as stream:
        script_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    result["provenance"] = {
        "dataset_sha256": data_sha,
        "script_sha256": script_sha,
        "protocol": "verification/temporal_pilot.md",
        "python": platform.python_version(),
        "platform": platform.platform(),
        "machine": platform.machine(),
        "cpu_count": os.cpu_count(),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    from provenance import write_record

    write_record(
        args.output.with_name("run_temporal_pilot.json"),
        experiment="temporal_pilot",
        seeds=list(config.BENCHMARK_SEEDS),
        dataset="credit_card",
        data_path=None,
        settings={**result["settings"], **result["provenance"]},
        outputs=[args.output.name],
    )
    print(f"wrote {args.output}")
    return 0


def x_main__mutmut_47(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=config.RESULTS_DIR / "temporal_pilot.json")
    parser.add_argument("--csv", type=Path, default=None)
    args = parser.parse_args(argv)
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(name)s %(message)s")
    spec = DATASETS["credit_card"]
    if args.csv is not None:
        spec = DatasetSpec(**{**spec.__dict__, "csv": args.csv})
    result = run(spec)
    with spec.csv.open("rb") as stream:
        data_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    with Path(None).open("rb") as stream:
        script_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    result["provenance"] = {
        "dataset_sha256": data_sha,
        "script_sha256": script_sha,
        "protocol": "verification/temporal_pilot.md",
        "python": platform.python_version(),
        "platform": platform.platform(),
        "machine": platform.machine(),
        "cpu_count": os.cpu_count(),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    from provenance import write_record

    write_record(
        args.output.with_name("run_temporal_pilot.json"),
        experiment="temporal_pilot",
        seeds=list(config.BENCHMARK_SEEDS),
        dataset="credit_card",
        data_path=None,
        settings={**result["settings"], **result["provenance"]},
        outputs=[args.output.name],
    )
    print(f"wrote {args.output}")
    return 0


def x_main__mutmut_48(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=config.RESULTS_DIR / "temporal_pilot.json")
    parser.add_argument("--csv", type=Path, default=None)
    args = parser.parse_args(argv)
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(name)s %(message)s")
    spec = DATASETS["credit_card"]
    if args.csv is not None:
        spec = DatasetSpec(**{**spec.__dict__, "csv": args.csv})
    result = run(spec)
    with spec.csv.open("rb") as stream:
        data_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    with Path(__file__).open("XXrbXX") as stream:
        script_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    result["provenance"] = {
        "dataset_sha256": data_sha,
        "script_sha256": script_sha,
        "protocol": "verification/temporal_pilot.md",
        "python": platform.python_version(),
        "platform": platform.platform(),
        "machine": platform.machine(),
        "cpu_count": os.cpu_count(),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    from provenance import write_record

    write_record(
        args.output.with_name("run_temporal_pilot.json"),
        experiment="temporal_pilot",
        seeds=list(config.BENCHMARK_SEEDS),
        dataset="credit_card",
        data_path=None,
        settings={**result["settings"], **result["provenance"]},
        outputs=[args.output.name],
    )
    print(f"wrote {args.output}")
    return 0


def x_main__mutmut_49(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=config.RESULTS_DIR / "temporal_pilot.json")
    parser.add_argument("--csv", type=Path, default=None)
    args = parser.parse_args(argv)
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(name)s %(message)s")
    spec = DATASETS["credit_card"]
    if args.csv is not None:
        spec = DatasetSpec(**{**spec.__dict__, "csv": args.csv})
    result = run(spec)
    with spec.csv.open("rb") as stream:
        data_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    with Path(__file__).open("RB") as stream:
        script_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    result["provenance"] = {
        "dataset_sha256": data_sha,
        "script_sha256": script_sha,
        "protocol": "verification/temporal_pilot.md",
        "python": platform.python_version(),
        "platform": platform.platform(),
        "machine": platform.machine(),
        "cpu_count": os.cpu_count(),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    from provenance import write_record

    write_record(
        args.output.with_name("run_temporal_pilot.json"),
        experiment="temporal_pilot",
        seeds=list(config.BENCHMARK_SEEDS),
        dataset="credit_card",
        data_path=None,
        settings={**result["settings"], **result["provenance"]},
        outputs=[args.output.name],
    )
    print(f"wrote {args.output}")
    return 0


def x_main__mutmut_50(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=config.RESULTS_DIR / "temporal_pilot.json")
    parser.add_argument("--csv", type=Path, default=None)
    args = parser.parse_args(argv)
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(name)s %(message)s")
    spec = DATASETS["credit_card"]
    if args.csv is not None:
        spec = DatasetSpec(**{**spec.__dict__, "csv": args.csv})
    result = run(spec)
    with spec.csv.open("rb") as stream:
        data_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    with Path(__file__).open("rb") as stream:
        script_sha = None
    result["provenance"] = {
        "dataset_sha256": data_sha,
        "script_sha256": script_sha,
        "protocol": "verification/temporal_pilot.md",
        "python": platform.python_version(),
        "platform": platform.platform(),
        "machine": platform.machine(),
        "cpu_count": os.cpu_count(),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    from provenance import write_record

    write_record(
        args.output.with_name("run_temporal_pilot.json"),
        experiment="temporal_pilot",
        seeds=list(config.BENCHMARK_SEEDS),
        dataset="credit_card",
        data_path=None,
        settings={**result["settings"], **result["provenance"]},
        outputs=[args.output.name],
    )
    print(f"wrote {args.output}")
    return 0


def x_main__mutmut_51(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=config.RESULTS_DIR / "temporal_pilot.json")
    parser.add_argument("--csv", type=Path, default=None)
    args = parser.parse_args(argv)
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(name)s %(message)s")
    spec = DATASETS["credit_card"]
    if args.csv is not None:
        spec = DatasetSpec(**{**spec.__dict__, "csv": args.csv})
    result = run(spec)
    with spec.csv.open("rb") as stream:
        data_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    with Path(__file__).open("rb") as stream:
        script_sha = hashlib.file_digest(None, hashlib.sha256).hexdigest()
    result["provenance"] = {
        "dataset_sha256": data_sha,
        "script_sha256": script_sha,
        "protocol": "verification/temporal_pilot.md",
        "python": platform.python_version(),
        "platform": platform.platform(),
        "machine": platform.machine(),
        "cpu_count": os.cpu_count(),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    from provenance import write_record

    write_record(
        args.output.with_name("run_temporal_pilot.json"),
        experiment="temporal_pilot",
        seeds=list(config.BENCHMARK_SEEDS),
        dataset="credit_card",
        data_path=None,
        settings={**result["settings"], **result["provenance"]},
        outputs=[args.output.name],
    )
    print(f"wrote {args.output}")
    return 0


def x_main__mutmut_52(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=config.RESULTS_DIR / "temporal_pilot.json")
    parser.add_argument("--csv", type=Path, default=None)
    args = parser.parse_args(argv)
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(name)s %(message)s")
    spec = DATASETS["credit_card"]
    if args.csv is not None:
        spec = DatasetSpec(**{**spec.__dict__, "csv": args.csv})
    result = run(spec)
    with spec.csv.open("rb") as stream:
        data_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    with Path(__file__).open("rb") as stream:
        script_sha = hashlib.file_digest(stream, None).hexdigest()
    result["provenance"] = {
        "dataset_sha256": data_sha,
        "script_sha256": script_sha,
        "protocol": "verification/temporal_pilot.md",
        "python": platform.python_version(),
        "platform": platform.platform(),
        "machine": platform.machine(),
        "cpu_count": os.cpu_count(),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    from provenance import write_record

    write_record(
        args.output.with_name("run_temporal_pilot.json"),
        experiment="temporal_pilot",
        seeds=list(config.BENCHMARK_SEEDS),
        dataset="credit_card",
        data_path=None,
        settings={**result["settings"], **result["provenance"]},
        outputs=[args.output.name],
    )
    print(f"wrote {args.output}")
    return 0


def x_main__mutmut_53(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=config.RESULTS_DIR / "temporal_pilot.json")
    parser.add_argument("--csv", type=Path, default=None)
    args = parser.parse_args(argv)
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(name)s %(message)s")
    spec = DATASETS["credit_card"]
    if args.csv is not None:
        spec = DatasetSpec(**{**spec.__dict__, "csv": args.csv})
    result = run(spec)
    with spec.csv.open("rb") as stream:
        data_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    with Path(__file__).open("rb") as stream:
        script_sha = hashlib.file_digest(hashlib.sha256).hexdigest()
    result["provenance"] = {
        "dataset_sha256": data_sha,
        "script_sha256": script_sha,
        "protocol": "verification/temporal_pilot.md",
        "python": platform.python_version(),
        "platform": platform.platform(),
        "machine": platform.machine(),
        "cpu_count": os.cpu_count(),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    from provenance import write_record

    write_record(
        args.output.with_name("run_temporal_pilot.json"),
        experiment="temporal_pilot",
        seeds=list(config.BENCHMARK_SEEDS),
        dataset="credit_card",
        data_path=None,
        settings={**result["settings"], **result["provenance"]},
        outputs=[args.output.name],
    )
    print(f"wrote {args.output}")
    return 0


def x_main__mutmut_54(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=config.RESULTS_DIR / "temporal_pilot.json")
    parser.add_argument("--csv", type=Path, default=None)
    args = parser.parse_args(argv)
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(name)s %(message)s")
    spec = DATASETS["credit_card"]
    if args.csv is not None:
        spec = DatasetSpec(**{**spec.__dict__, "csv": args.csv})
    result = run(spec)
    with spec.csv.open("rb") as stream:
        data_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    with Path(__file__).open("rb") as stream:
        script_sha = hashlib.file_digest(stream, ).hexdigest()
    result["provenance"] = {
        "dataset_sha256": data_sha,
        "script_sha256": script_sha,
        "protocol": "verification/temporal_pilot.md",
        "python": platform.python_version(),
        "platform": platform.platform(),
        "machine": platform.machine(),
        "cpu_count": os.cpu_count(),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    from provenance import write_record

    write_record(
        args.output.with_name("run_temporal_pilot.json"),
        experiment="temporal_pilot",
        seeds=list(config.BENCHMARK_SEEDS),
        dataset="credit_card",
        data_path=None,
        settings={**result["settings"], **result["provenance"]},
        outputs=[args.output.name],
    )
    print(f"wrote {args.output}")
    return 0


def x_main__mutmut_55(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=config.RESULTS_DIR / "temporal_pilot.json")
    parser.add_argument("--csv", type=Path, default=None)
    args = parser.parse_args(argv)
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(name)s %(message)s")
    spec = DATASETS["credit_card"]
    if args.csv is not None:
        spec = DatasetSpec(**{**spec.__dict__, "csv": args.csv})
    result = run(spec)
    with spec.csv.open("rb") as stream:
        data_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    with Path(__file__).open("rb") as stream:
        script_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    result["provenance"] = None
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    from provenance import write_record

    write_record(
        args.output.with_name("run_temporal_pilot.json"),
        experiment="temporal_pilot",
        seeds=list(config.BENCHMARK_SEEDS),
        dataset="credit_card",
        data_path=None,
        settings={**result["settings"], **result["provenance"]},
        outputs=[args.output.name],
    )
    print(f"wrote {args.output}")
    return 0


def x_main__mutmut_56(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=config.RESULTS_DIR / "temporal_pilot.json")
    parser.add_argument("--csv", type=Path, default=None)
    args = parser.parse_args(argv)
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(name)s %(message)s")
    spec = DATASETS["credit_card"]
    if args.csv is not None:
        spec = DatasetSpec(**{**spec.__dict__, "csv": args.csv})
    result = run(spec)
    with spec.csv.open("rb") as stream:
        data_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    with Path(__file__).open("rb") as stream:
        script_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    result["XXprovenanceXX"] = {
        "dataset_sha256": data_sha,
        "script_sha256": script_sha,
        "protocol": "verification/temporal_pilot.md",
        "python": platform.python_version(),
        "platform": platform.platform(),
        "machine": platform.machine(),
        "cpu_count": os.cpu_count(),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    from provenance import write_record

    write_record(
        args.output.with_name("run_temporal_pilot.json"),
        experiment="temporal_pilot",
        seeds=list(config.BENCHMARK_SEEDS),
        dataset="credit_card",
        data_path=None,
        settings={**result["settings"], **result["provenance"]},
        outputs=[args.output.name],
    )
    print(f"wrote {args.output}")
    return 0


def x_main__mutmut_57(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=config.RESULTS_DIR / "temporal_pilot.json")
    parser.add_argument("--csv", type=Path, default=None)
    args = parser.parse_args(argv)
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(name)s %(message)s")
    spec = DATASETS["credit_card"]
    if args.csv is not None:
        spec = DatasetSpec(**{**spec.__dict__, "csv": args.csv})
    result = run(spec)
    with spec.csv.open("rb") as stream:
        data_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    with Path(__file__).open("rb") as stream:
        script_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    result["PROVENANCE"] = {
        "dataset_sha256": data_sha,
        "script_sha256": script_sha,
        "protocol": "verification/temporal_pilot.md",
        "python": platform.python_version(),
        "platform": platform.platform(),
        "machine": platform.machine(),
        "cpu_count": os.cpu_count(),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    from provenance import write_record

    write_record(
        args.output.with_name("run_temporal_pilot.json"),
        experiment="temporal_pilot",
        seeds=list(config.BENCHMARK_SEEDS),
        dataset="credit_card",
        data_path=None,
        settings={**result["settings"], **result["provenance"]},
        outputs=[args.output.name],
    )
    print(f"wrote {args.output}")
    return 0


def x_main__mutmut_58(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=config.RESULTS_DIR / "temporal_pilot.json")
    parser.add_argument("--csv", type=Path, default=None)
    args = parser.parse_args(argv)
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(name)s %(message)s")
    spec = DATASETS["credit_card"]
    if args.csv is not None:
        spec = DatasetSpec(**{**spec.__dict__, "csv": args.csv})
    result = run(spec)
    with spec.csv.open("rb") as stream:
        data_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    with Path(__file__).open("rb") as stream:
        script_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    result["provenance"] = {
        "XXdataset_sha256XX": data_sha,
        "script_sha256": script_sha,
        "protocol": "verification/temporal_pilot.md",
        "python": platform.python_version(),
        "platform": platform.platform(),
        "machine": platform.machine(),
        "cpu_count": os.cpu_count(),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    from provenance import write_record

    write_record(
        args.output.with_name("run_temporal_pilot.json"),
        experiment="temporal_pilot",
        seeds=list(config.BENCHMARK_SEEDS),
        dataset="credit_card",
        data_path=None,
        settings={**result["settings"], **result["provenance"]},
        outputs=[args.output.name],
    )
    print(f"wrote {args.output}")
    return 0


def x_main__mutmut_59(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=config.RESULTS_DIR / "temporal_pilot.json")
    parser.add_argument("--csv", type=Path, default=None)
    args = parser.parse_args(argv)
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(name)s %(message)s")
    spec = DATASETS["credit_card"]
    if args.csv is not None:
        spec = DatasetSpec(**{**spec.__dict__, "csv": args.csv})
    result = run(spec)
    with spec.csv.open("rb") as stream:
        data_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    with Path(__file__).open("rb") as stream:
        script_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    result["provenance"] = {
        "DATASET_SHA256": data_sha,
        "script_sha256": script_sha,
        "protocol": "verification/temporal_pilot.md",
        "python": platform.python_version(),
        "platform": platform.platform(),
        "machine": platform.machine(),
        "cpu_count": os.cpu_count(),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    from provenance import write_record

    write_record(
        args.output.with_name("run_temporal_pilot.json"),
        experiment="temporal_pilot",
        seeds=list(config.BENCHMARK_SEEDS),
        dataset="credit_card",
        data_path=None,
        settings={**result["settings"], **result["provenance"]},
        outputs=[args.output.name],
    )
    print(f"wrote {args.output}")
    return 0


def x_main__mutmut_60(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=config.RESULTS_DIR / "temporal_pilot.json")
    parser.add_argument("--csv", type=Path, default=None)
    args = parser.parse_args(argv)
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(name)s %(message)s")
    spec = DATASETS["credit_card"]
    if args.csv is not None:
        spec = DatasetSpec(**{**spec.__dict__, "csv": args.csv})
    result = run(spec)
    with spec.csv.open("rb") as stream:
        data_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    with Path(__file__).open("rb") as stream:
        script_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    result["provenance"] = {
        "dataset_sha256": data_sha,
        "XXscript_sha256XX": script_sha,
        "protocol": "verification/temporal_pilot.md",
        "python": platform.python_version(),
        "platform": platform.platform(),
        "machine": platform.machine(),
        "cpu_count": os.cpu_count(),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    from provenance import write_record

    write_record(
        args.output.with_name("run_temporal_pilot.json"),
        experiment="temporal_pilot",
        seeds=list(config.BENCHMARK_SEEDS),
        dataset="credit_card",
        data_path=None,
        settings={**result["settings"], **result["provenance"]},
        outputs=[args.output.name],
    )
    print(f"wrote {args.output}")
    return 0


def x_main__mutmut_61(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=config.RESULTS_DIR / "temporal_pilot.json")
    parser.add_argument("--csv", type=Path, default=None)
    args = parser.parse_args(argv)
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(name)s %(message)s")
    spec = DATASETS["credit_card"]
    if args.csv is not None:
        spec = DatasetSpec(**{**spec.__dict__, "csv": args.csv})
    result = run(spec)
    with spec.csv.open("rb") as stream:
        data_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    with Path(__file__).open("rb") as stream:
        script_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    result["provenance"] = {
        "dataset_sha256": data_sha,
        "SCRIPT_SHA256": script_sha,
        "protocol": "verification/temporal_pilot.md",
        "python": platform.python_version(),
        "platform": platform.platform(),
        "machine": platform.machine(),
        "cpu_count": os.cpu_count(),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    from provenance import write_record

    write_record(
        args.output.with_name("run_temporal_pilot.json"),
        experiment="temporal_pilot",
        seeds=list(config.BENCHMARK_SEEDS),
        dataset="credit_card",
        data_path=None,
        settings={**result["settings"], **result["provenance"]},
        outputs=[args.output.name],
    )
    print(f"wrote {args.output}")
    return 0


def x_main__mutmut_62(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=config.RESULTS_DIR / "temporal_pilot.json")
    parser.add_argument("--csv", type=Path, default=None)
    args = parser.parse_args(argv)
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(name)s %(message)s")
    spec = DATASETS["credit_card"]
    if args.csv is not None:
        spec = DatasetSpec(**{**spec.__dict__, "csv": args.csv})
    result = run(spec)
    with spec.csv.open("rb") as stream:
        data_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    with Path(__file__).open("rb") as stream:
        script_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    result["provenance"] = {
        "dataset_sha256": data_sha,
        "script_sha256": script_sha,
        "XXprotocolXX": "verification/temporal_pilot.md",
        "python": platform.python_version(),
        "platform": platform.platform(),
        "machine": platform.machine(),
        "cpu_count": os.cpu_count(),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    from provenance import write_record

    write_record(
        args.output.with_name("run_temporal_pilot.json"),
        experiment="temporal_pilot",
        seeds=list(config.BENCHMARK_SEEDS),
        dataset="credit_card",
        data_path=None,
        settings={**result["settings"], **result["provenance"]},
        outputs=[args.output.name],
    )
    print(f"wrote {args.output}")
    return 0


def x_main__mutmut_63(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=config.RESULTS_DIR / "temporal_pilot.json")
    parser.add_argument("--csv", type=Path, default=None)
    args = parser.parse_args(argv)
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(name)s %(message)s")
    spec = DATASETS["credit_card"]
    if args.csv is not None:
        spec = DatasetSpec(**{**spec.__dict__, "csv": args.csv})
    result = run(spec)
    with spec.csv.open("rb") as stream:
        data_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    with Path(__file__).open("rb") as stream:
        script_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    result["provenance"] = {
        "dataset_sha256": data_sha,
        "script_sha256": script_sha,
        "PROTOCOL": "verification/temporal_pilot.md",
        "python": platform.python_version(),
        "platform": platform.platform(),
        "machine": platform.machine(),
        "cpu_count": os.cpu_count(),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    from provenance import write_record

    write_record(
        args.output.with_name("run_temporal_pilot.json"),
        experiment="temporal_pilot",
        seeds=list(config.BENCHMARK_SEEDS),
        dataset="credit_card",
        data_path=None,
        settings={**result["settings"], **result["provenance"]},
        outputs=[args.output.name],
    )
    print(f"wrote {args.output}")
    return 0


def x_main__mutmut_64(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=config.RESULTS_DIR / "temporal_pilot.json")
    parser.add_argument("--csv", type=Path, default=None)
    args = parser.parse_args(argv)
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(name)s %(message)s")
    spec = DATASETS["credit_card"]
    if args.csv is not None:
        spec = DatasetSpec(**{**spec.__dict__, "csv": args.csv})
    result = run(spec)
    with spec.csv.open("rb") as stream:
        data_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    with Path(__file__).open("rb") as stream:
        script_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    result["provenance"] = {
        "dataset_sha256": data_sha,
        "script_sha256": script_sha,
        "protocol": "XXverification/temporal_pilot.mdXX",
        "python": platform.python_version(),
        "platform": platform.platform(),
        "machine": platform.machine(),
        "cpu_count": os.cpu_count(),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    from provenance import write_record

    write_record(
        args.output.with_name("run_temporal_pilot.json"),
        experiment="temporal_pilot",
        seeds=list(config.BENCHMARK_SEEDS),
        dataset="credit_card",
        data_path=None,
        settings={**result["settings"], **result["provenance"]},
        outputs=[args.output.name],
    )
    print(f"wrote {args.output}")
    return 0


def x_main__mutmut_65(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=config.RESULTS_DIR / "temporal_pilot.json")
    parser.add_argument("--csv", type=Path, default=None)
    args = parser.parse_args(argv)
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(name)s %(message)s")
    spec = DATASETS["credit_card"]
    if args.csv is not None:
        spec = DatasetSpec(**{**spec.__dict__, "csv": args.csv})
    result = run(spec)
    with spec.csv.open("rb") as stream:
        data_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    with Path(__file__).open("rb") as stream:
        script_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    result["provenance"] = {
        "dataset_sha256": data_sha,
        "script_sha256": script_sha,
        "protocol": "VERIFICATION/TEMPORAL_PILOT.MD",
        "python": platform.python_version(),
        "platform": platform.platform(),
        "machine": platform.machine(),
        "cpu_count": os.cpu_count(),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    from provenance import write_record

    write_record(
        args.output.with_name("run_temporal_pilot.json"),
        experiment="temporal_pilot",
        seeds=list(config.BENCHMARK_SEEDS),
        dataset="credit_card",
        data_path=None,
        settings={**result["settings"], **result["provenance"]},
        outputs=[args.output.name],
    )
    print(f"wrote {args.output}")
    return 0


def x_main__mutmut_66(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=config.RESULTS_DIR / "temporal_pilot.json")
    parser.add_argument("--csv", type=Path, default=None)
    args = parser.parse_args(argv)
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(name)s %(message)s")
    spec = DATASETS["credit_card"]
    if args.csv is not None:
        spec = DatasetSpec(**{**spec.__dict__, "csv": args.csv})
    result = run(spec)
    with spec.csv.open("rb") as stream:
        data_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    with Path(__file__).open("rb") as stream:
        script_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    result["provenance"] = {
        "dataset_sha256": data_sha,
        "script_sha256": script_sha,
        "protocol": "verification/temporal_pilot.md",
        "XXpythonXX": platform.python_version(),
        "platform": platform.platform(),
        "machine": platform.machine(),
        "cpu_count": os.cpu_count(),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    from provenance import write_record

    write_record(
        args.output.with_name("run_temporal_pilot.json"),
        experiment="temporal_pilot",
        seeds=list(config.BENCHMARK_SEEDS),
        dataset="credit_card",
        data_path=None,
        settings={**result["settings"], **result["provenance"]},
        outputs=[args.output.name],
    )
    print(f"wrote {args.output}")
    return 0


def x_main__mutmut_67(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=config.RESULTS_DIR / "temporal_pilot.json")
    parser.add_argument("--csv", type=Path, default=None)
    args = parser.parse_args(argv)
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(name)s %(message)s")
    spec = DATASETS["credit_card"]
    if args.csv is not None:
        spec = DatasetSpec(**{**spec.__dict__, "csv": args.csv})
    result = run(spec)
    with spec.csv.open("rb") as stream:
        data_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    with Path(__file__).open("rb") as stream:
        script_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    result["provenance"] = {
        "dataset_sha256": data_sha,
        "script_sha256": script_sha,
        "protocol": "verification/temporal_pilot.md",
        "PYTHON": platform.python_version(),
        "platform": platform.platform(),
        "machine": platform.machine(),
        "cpu_count": os.cpu_count(),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    from provenance import write_record

    write_record(
        args.output.with_name("run_temporal_pilot.json"),
        experiment="temporal_pilot",
        seeds=list(config.BENCHMARK_SEEDS),
        dataset="credit_card",
        data_path=None,
        settings={**result["settings"], **result["provenance"]},
        outputs=[args.output.name],
    )
    print(f"wrote {args.output}")
    return 0


def x_main__mutmut_68(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=config.RESULTS_DIR / "temporal_pilot.json")
    parser.add_argument("--csv", type=Path, default=None)
    args = parser.parse_args(argv)
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(name)s %(message)s")
    spec = DATASETS["credit_card"]
    if args.csv is not None:
        spec = DatasetSpec(**{**spec.__dict__, "csv": args.csv})
    result = run(spec)
    with spec.csv.open("rb") as stream:
        data_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    with Path(__file__).open("rb") as stream:
        script_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    result["provenance"] = {
        "dataset_sha256": data_sha,
        "script_sha256": script_sha,
        "protocol": "verification/temporal_pilot.md",
        "python": platform.python_version(),
        "XXplatformXX": platform.platform(),
        "machine": platform.machine(),
        "cpu_count": os.cpu_count(),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    from provenance import write_record

    write_record(
        args.output.with_name("run_temporal_pilot.json"),
        experiment="temporal_pilot",
        seeds=list(config.BENCHMARK_SEEDS),
        dataset="credit_card",
        data_path=None,
        settings={**result["settings"], **result["provenance"]},
        outputs=[args.output.name],
    )
    print(f"wrote {args.output}")
    return 0


def x_main__mutmut_69(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=config.RESULTS_DIR / "temporal_pilot.json")
    parser.add_argument("--csv", type=Path, default=None)
    args = parser.parse_args(argv)
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(name)s %(message)s")
    spec = DATASETS["credit_card"]
    if args.csv is not None:
        spec = DatasetSpec(**{**spec.__dict__, "csv": args.csv})
    result = run(spec)
    with spec.csv.open("rb") as stream:
        data_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    with Path(__file__).open("rb") as stream:
        script_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    result["provenance"] = {
        "dataset_sha256": data_sha,
        "script_sha256": script_sha,
        "protocol": "verification/temporal_pilot.md",
        "python": platform.python_version(),
        "PLATFORM": platform.platform(),
        "machine": platform.machine(),
        "cpu_count": os.cpu_count(),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    from provenance import write_record

    write_record(
        args.output.with_name("run_temporal_pilot.json"),
        experiment="temporal_pilot",
        seeds=list(config.BENCHMARK_SEEDS),
        dataset="credit_card",
        data_path=None,
        settings={**result["settings"], **result["provenance"]},
        outputs=[args.output.name],
    )
    print(f"wrote {args.output}")
    return 0


def x_main__mutmut_70(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=config.RESULTS_DIR / "temporal_pilot.json")
    parser.add_argument("--csv", type=Path, default=None)
    args = parser.parse_args(argv)
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(name)s %(message)s")
    spec = DATASETS["credit_card"]
    if args.csv is not None:
        spec = DatasetSpec(**{**spec.__dict__, "csv": args.csv})
    result = run(spec)
    with spec.csv.open("rb") as stream:
        data_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    with Path(__file__).open("rb") as stream:
        script_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    result["provenance"] = {
        "dataset_sha256": data_sha,
        "script_sha256": script_sha,
        "protocol": "verification/temporal_pilot.md",
        "python": platform.python_version(),
        "platform": platform.platform(),
        "XXmachineXX": platform.machine(),
        "cpu_count": os.cpu_count(),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    from provenance import write_record

    write_record(
        args.output.with_name("run_temporal_pilot.json"),
        experiment="temporal_pilot",
        seeds=list(config.BENCHMARK_SEEDS),
        dataset="credit_card",
        data_path=None,
        settings={**result["settings"], **result["provenance"]},
        outputs=[args.output.name],
    )
    print(f"wrote {args.output}")
    return 0


def x_main__mutmut_71(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=config.RESULTS_DIR / "temporal_pilot.json")
    parser.add_argument("--csv", type=Path, default=None)
    args = parser.parse_args(argv)
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(name)s %(message)s")
    spec = DATASETS["credit_card"]
    if args.csv is not None:
        spec = DatasetSpec(**{**spec.__dict__, "csv": args.csv})
    result = run(spec)
    with spec.csv.open("rb") as stream:
        data_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    with Path(__file__).open("rb") as stream:
        script_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    result["provenance"] = {
        "dataset_sha256": data_sha,
        "script_sha256": script_sha,
        "protocol": "verification/temporal_pilot.md",
        "python": platform.python_version(),
        "platform": platform.platform(),
        "MACHINE": platform.machine(),
        "cpu_count": os.cpu_count(),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    from provenance import write_record

    write_record(
        args.output.with_name("run_temporal_pilot.json"),
        experiment="temporal_pilot",
        seeds=list(config.BENCHMARK_SEEDS),
        dataset="credit_card",
        data_path=None,
        settings={**result["settings"], **result["provenance"]},
        outputs=[args.output.name],
    )
    print(f"wrote {args.output}")
    return 0


def x_main__mutmut_72(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=config.RESULTS_DIR / "temporal_pilot.json")
    parser.add_argument("--csv", type=Path, default=None)
    args = parser.parse_args(argv)
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(name)s %(message)s")
    spec = DATASETS["credit_card"]
    if args.csv is not None:
        spec = DatasetSpec(**{**spec.__dict__, "csv": args.csv})
    result = run(spec)
    with spec.csv.open("rb") as stream:
        data_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    with Path(__file__).open("rb") as stream:
        script_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    result["provenance"] = {
        "dataset_sha256": data_sha,
        "script_sha256": script_sha,
        "protocol": "verification/temporal_pilot.md",
        "python": platform.python_version(),
        "platform": platform.platform(),
        "machine": platform.machine(),
        "XXcpu_countXX": os.cpu_count(),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    from provenance import write_record

    write_record(
        args.output.with_name("run_temporal_pilot.json"),
        experiment="temporal_pilot",
        seeds=list(config.BENCHMARK_SEEDS),
        dataset="credit_card",
        data_path=None,
        settings={**result["settings"], **result["provenance"]},
        outputs=[args.output.name],
    )
    print(f"wrote {args.output}")
    return 0


def x_main__mutmut_73(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=config.RESULTS_DIR / "temporal_pilot.json")
    parser.add_argument("--csv", type=Path, default=None)
    args = parser.parse_args(argv)
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(name)s %(message)s")
    spec = DATASETS["credit_card"]
    if args.csv is not None:
        spec = DatasetSpec(**{**spec.__dict__, "csv": args.csv})
    result = run(spec)
    with spec.csv.open("rb") as stream:
        data_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    with Path(__file__).open("rb") as stream:
        script_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    result["provenance"] = {
        "dataset_sha256": data_sha,
        "script_sha256": script_sha,
        "protocol": "verification/temporal_pilot.md",
        "python": platform.python_version(),
        "platform": platform.platform(),
        "machine": platform.machine(),
        "CPU_COUNT": os.cpu_count(),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    from provenance import write_record

    write_record(
        args.output.with_name("run_temporal_pilot.json"),
        experiment="temporal_pilot",
        seeds=list(config.BENCHMARK_SEEDS),
        dataset="credit_card",
        data_path=None,
        settings={**result["settings"], **result["provenance"]},
        outputs=[args.output.name],
    )
    print(f"wrote {args.output}")
    return 0


def x_main__mutmut_74(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=config.RESULTS_DIR / "temporal_pilot.json")
    parser.add_argument("--csv", type=Path, default=None)
    args = parser.parse_args(argv)
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(name)s %(message)s")
    spec = DATASETS["credit_card"]
    if args.csv is not None:
        spec = DatasetSpec(**{**spec.__dict__, "csv": args.csv})
    result = run(spec)
    with spec.csv.open("rb") as stream:
        data_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    with Path(__file__).open("rb") as stream:
        script_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    result["provenance"] = {
        "dataset_sha256": data_sha,
        "script_sha256": script_sha,
        "protocol": "verification/temporal_pilot.md",
        "python": platform.python_version(),
        "platform": platform.platform(),
        "machine": platform.machine(),
        "cpu_count": os.cpu_count(),
    }
    with atomic_path(None) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    from provenance import write_record

    write_record(
        args.output.with_name("run_temporal_pilot.json"),
        experiment="temporal_pilot",
        seeds=list(config.BENCHMARK_SEEDS),
        dataset="credit_card",
        data_path=None,
        settings={**result["settings"], **result["provenance"]},
        outputs=[args.output.name],
    )
    print(f"wrote {args.output}")
    return 0


def x_main__mutmut_75(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=config.RESULTS_DIR / "temporal_pilot.json")
    parser.add_argument("--csv", type=Path, default=None)
    args = parser.parse_args(argv)
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(name)s %(message)s")
    spec = DATASETS["credit_card"]
    if args.csv is not None:
        spec = DatasetSpec(**{**spec.__dict__, "csv": args.csv})
    result = run(spec)
    with spec.csv.open("rb") as stream:
        data_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    with Path(__file__).open("rb") as stream:
        script_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    result["provenance"] = {
        "dataset_sha256": data_sha,
        "script_sha256": script_sha,
        "protocol": "verification/temporal_pilot.md",
        "python": platform.python_version(),
        "platform": platform.platform(),
        "machine": platform.machine(),
        "cpu_count": os.cpu_count(),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(None)
    from provenance import write_record

    write_record(
        args.output.with_name("run_temporal_pilot.json"),
        experiment="temporal_pilot",
        seeds=list(config.BENCHMARK_SEEDS),
        dataset="credit_card",
        data_path=None,
        settings={**result["settings"], **result["provenance"]},
        outputs=[args.output.name],
    )
    print(f"wrote {args.output}")
    return 0


def x_main__mutmut_76(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=config.RESULTS_DIR / "temporal_pilot.json")
    parser.add_argument("--csv", type=Path, default=None)
    args = parser.parse_args(argv)
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(name)s %(message)s")
    spec = DATASETS["credit_card"]
    if args.csv is not None:
        spec = DatasetSpec(**{**spec.__dict__, "csv": args.csv})
    result = run(spec)
    with spec.csv.open("rb") as stream:
        data_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    with Path(__file__).open("rb") as stream:
        script_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    result["provenance"] = {
        "dataset_sha256": data_sha,
        "script_sha256": script_sha,
        "protocol": "verification/temporal_pilot.md",
        "python": platform.python_version(),
        "platform": platform.platform(),
        "machine": platform.machine(),
        "cpu_count": os.cpu_count(),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True) - "\n")
    from provenance import write_record

    write_record(
        args.output.with_name("run_temporal_pilot.json"),
        experiment="temporal_pilot",
        seeds=list(config.BENCHMARK_SEEDS),
        dataset="credit_card",
        data_path=None,
        settings={**result["settings"], **result["provenance"]},
        outputs=[args.output.name],
    )
    print(f"wrote {args.output}")
    return 0


def x_main__mutmut_77(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=config.RESULTS_DIR / "temporal_pilot.json")
    parser.add_argument("--csv", type=Path, default=None)
    args = parser.parse_args(argv)
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(name)s %(message)s")
    spec = DATASETS["credit_card"]
    if args.csv is not None:
        spec = DatasetSpec(**{**spec.__dict__, "csv": args.csv})
    result = run(spec)
    with spec.csv.open("rb") as stream:
        data_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    with Path(__file__).open("rb") as stream:
        script_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    result["provenance"] = {
        "dataset_sha256": data_sha,
        "script_sha256": script_sha,
        "protocol": "verification/temporal_pilot.md",
        "python": platform.python_version(),
        "platform": platform.platform(),
        "machine": platform.machine(),
        "cpu_count": os.cpu_count(),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(None, indent=2, sort_keys=True) + "\n")
    from provenance import write_record

    write_record(
        args.output.with_name("run_temporal_pilot.json"),
        experiment="temporal_pilot",
        seeds=list(config.BENCHMARK_SEEDS),
        dataset="credit_card",
        data_path=None,
        settings={**result["settings"], **result["provenance"]},
        outputs=[args.output.name],
    )
    print(f"wrote {args.output}")
    return 0


def x_main__mutmut_78(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=config.RESULTS_DIR / "temporal_pilot.json")
    parser.add_argument("--csv", type=Path, default=None)
    args = parser.parse_args(argv)
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(name)s %(message)s")
    spec = DATASETS["credit_card"]
    if args.csv is not None:
        spec = DatasetSpec(**{**spec.__dict__, "csv": args.csv})
    result = run(spec)
    with spec.csv.open("rb") as stream:
        data_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    with Path(__file__).open("rb") as stream:
        script_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    result["provenance"] = {
        "dataset_sha256": data_sha,
        "script_sha256": script_sha,
        "protocol": "verification/temporal_pilot.md",
        "python": platform.python_version(),
        "platform": platform.platform(),
        "machine": platform.machine(),
        "cpu_count": os.cpu_count(),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=None, sort_keys=True) + "\n")
    from provenance import write_record

    write_record(
        args.output.with_name("run_temporal_pilot.json"),
        experiment="temporal_pilot",
        seeds=list(config.BENCHMARK_SEEDS),
        dataset="credit_card",
        data_path=None,
        settings={**result["settings"], **result["provenance"]},
        outputs=[args.output.name],
    )
    print(f"wrote {args.output}")
    return 0


def x_main__mutmut_79(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=config.RESULTS_DIR / "temporal_pilot.json")
    parser.add_argument("--csv", type=Path, default=None)
    args = parser.parse_args(argv)
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(name)s %(message)s")
    spec = DATASETS["credit_card"]
    if args.csv is not None:
        spec = DatasetSpec(**{**spec.__dict__, "csv": args.csv})
    result = run(spec)
    with spec.csv.open("rb") as stream:
        data_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    with Path(__file__).open("rb") as stream:
        script_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    result["provenance"] = {
        "dataset_sha256": data_sha,
        "script_sha256": script_sha,
        "protocol": "verification/temporal_pilot.md",
        "python": platform.python_version(),
        "platform": platform.platform(),
        "machine": platform.machine(),
        "cpu_count": os.cpu_count(),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=None) + "\n")
    from provenance import write_record

    write_record(
        args.output.with_name("run_temporal_pilot.json"),
        experiment="temporal_pilot",
        seeds=list(config.BENCHMARK_SEEDS),
        dataset="credit_card",
        data_path=None,
        settings={**result["settings"], **result["provenance"]},
        outputs=[args.output.name],
    )
    print(f"wrote {args.output}")
    return 0


def x_main__mutmut_80(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=config.RESULTS_DIR / "temporal_pilot.json")
    parser.add_argument("--csv", type=Path, default=None)
    args = parser.parse_args(argv)
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(name)s %(message)s")
    spec = DATASETS["credit_card"]
    if args.csv is not None:
        spec = DatasetSpec(**{**spec.__dict__, "csv": args.csv})
    result = run(spec)
    with spec.csv.open("rb") as stream:
        data_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    with Path(__file__).open("rb") as stream:
        script_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    result["provenance"] = {
        "dataset_sha256": data_sha,
        "script_sha256": script_sha,
        "protocol": "verification/temporal_pilot.md",
        "python": platform.python_version(),
        "platform": platform.platform(),
        "machine": platform.machine(),
        "cpu_count": os.cpu_count(),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(indent=2, sort_keys=True) + "\n")
    from provenance import write_record

    write_record(
        args.output.with_name("run_temporal_pilot.json"),
        experiment="temporal_pilot",
        seeds=list(config.BENCHMARK_SEEDS),
        dataset="credit_card",
        data_path=None,
        settings={**result["settings"], **result["provenance"]},
        outputs=[args.output.name],
    )
    print(f"wrote {args.output}")
    return 0


def x_main__mutmut_81(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=config.RESULTS_DIR / "temporal_pilot.json")
    parser.add_argument("--csv", type=Path, default=None)
    args = parser.parse_args(argv)
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(name)s %(message)s")
    spec = DATASETS["credit_card"]
    if args.csv is not None:
        spec = DatasetSpec(**{**spec.__dict__, "csv": args.csv})
    result = run(spec)
    with spec.csv.open("rb") as stream:
        data_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    with Path(__file__).open("rb") as stream:
        script_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    result["provenance"] = {
        "dataset_sha256": data_sha,
        "script_sha256": script_sha,
        "protocol": "verification/temporal_pilot.md",
        "python": platform.python_version(),
        "platform": platform.platform(),
        "machine": platform.machine(),
        "cpu_count": os.cpu_count(),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, sort_keys=True) + "\n")
    from provenance import write_record

    write_record(
        args.output.with_name("run_temporal_pilot.json"),
        experiment="temporal_pilot",
        seeds=list(config.BENCHMARK_SEEDS),
        dataset="credit_card",
        data_path=None,
        settings={**result["settings"], **result["provenance"]},
        outputs=[args.output.name],
    )
    print(f"wrote {args.output}")
    return 0


def x_main__mutmut_82(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=config.RESULTS_DIR / "temporal_pilot.json")
    parser.add_argument("--csv", type=Path, default=None)
    args = parser.parse_args(argv)
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(name)s %(message)s")
    spec = DATASETS["credit_card"]
    if args.csv is not None:
        spec = DatasetSpec(**{**spec.__dict__, "csv": args.csv})
    result = run(spec)
    with spec.csv.open("rb") as stream:
        data_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    with Path(__file__).open("rb") as stream:
        script_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    result["provenance"] = {
        "dataset_sha256": data_sha,
        "script_sha256": script_sha,
        "protocol": "verification/temporal_pilot.md",
        "python": platform.python_version(),
        "platform": platform.platform(),
        "machine": platform.machine(),
        "cpu_count": os.cpu_count(),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, ) + "\n")
    from provenance import write_record

    write_record(
        args.output.with_name("run_temporal_pilot.json"),
        experiment="temporal_pilot",
        seeds=list(config.BENCHMARK_SEEDS),
        dataset="credit_card",
        data_path=None,
        settings={**result["settings"], **result["provenance"]},
        outputs=[args.output.name],
    )
    print(f"wrote {args.output}")
    return 0


def x_main__mutmut_83(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=config.RESULTS_DIR / "temporal_pilot.json")
    parser.add_argument("--csv", type=Path, default=None)
    args = parser.parse_args(argv)
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(name)s %(message)s")
    spec = DATASETS["credit_card"]
    if args.csv is not None:
        spec = DatasetSpec(**{**spec.__dict__, "csv": args.csv})
    result = run(spec)
    with spec.csv.open("rb") as stream:
        data_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    with Path(__file__).open("rb") as stream:
        script_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    result["provenance"] = {
        "dataset_sha256": data_sha,
        "script_sha256": script_sha,
        "protocol": "verification/temporal_pilot.md",
        "python": platform.python_version(),
        "platform": platform.platform(),
        "machine": platform.machine(),
        "cpu_count": os.cpu_count(),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=3, sort_keys=True) + "\n")
    from provenance import write_record

    write_record(
        args.output.with_name("run_temporal_pilot.json"),
        experiment="temporal_pilot",
        seeds=list(config.BENCHMARK_SEEDS),
        dataset="credit_card",
        data_path=None,
        settings={**result["settings"], **result["provenance"]},
        outputs=[args.output.name],
    )
    print(f"wrote {args.output}")
    return 0


def x_main__mutmut_84(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=config.RESULTS_DIR / "temporal_pilot.json")
    parser.add_argument("--csv", type=Path, default=None)
    args = parser.parse_args(argv)
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(name)s %(message)s")
    spec = DATASETS["credit_card"]
    if args.csv is not None:
        spec = DatasetSpec(**{**spec.__dict__, "csv": args.csv})
    result = run(spec)
    with spec.csv.open("rb") as stream:
        data_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    with Path(__file__).open("rb") as stream:
        script_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    result["provenance"] = {
        "dataset_sha256": data_sha,
        "script_sha256": script_sha,
        "protocol": "verification/temporal_pilot.md",
        "python": platform.python_version(),
        "platform": platform.platform(),
        "machine": platform.machine(),
        "cpu_count": os.cpu_count(),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=False) + "\n")
    from provenance import write_record

    write_record(
        args.output.with_name("run_temporal_pilot.json"),
        experiment="temporal_pilot",
        seeds=list(config.BENCHMARK_SEEDS),
        dataset="credit_card",
        data_path=None,
        settings={**result["settings"], **result["provenance"]},
        outputs=[args.output.name],
    )
    print(f"wrote {args.output}")
    return 0


def x_main__mutmut_85(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=config.RESULTS_DIR / "temporal_pilot.json")
    parser.add_argument("--csv", type=Path, default=None)
    args = parser.parse_args(argv)
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(name)s %(message)s")
    spec = DATASETS["credit_card"]
    if args.csv is not None:
        spec = DatasetSpec(**{**spec.__dict__, "csv": args.csv})
    result = run(spec)
    with spec.csv.open("rb") as stream:
        data_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    with Path(__file__).open("rb") as stream:
        script_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    result["provenance"] = {
        "dataset_sha256": data_sha,
        "script_sha256": script_sha,
        "protocol": "verification/temporal_pilot.md",
        "python": platform.python_version(),
        "platform": platform.platform(),
        "machine": platform.machine(),
        "cpu_count": os.cpu_count(),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True) + "XX\nXX")
    from provenance import write_record

    write_record(
        args.output.with_name("run_temporal_pilot.json"),
        experiment="temporal_pilot",
        seeds=list(config.BENCHMARK_SEEDS),
        dataset="credit_card",
        data_path=None,
        settings={**result["settings"], **result["provenance"]},
        outputs=[args.output.name],
    )
    print(f"wrote {args.output}")
    return 0


def x_main__mutmut_86(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=config.RESULTS_DIR / "temporal_pilot.json")
    parser.add_argument("--csv", type=Path, default=None)
    args = parser.parse_args(argv)
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(name)s %(message)s")
    spec = DATASETS["credit_card"]
    if args.csv is not None:
        spec = DatasetSpec(**{**spec.__dict__, "csv": args.csv})
    result = run(spec)
    with spec.csv.open("rb") as stream:
        data_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    with Path(__file__).open("rb") as stream:
        script_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    result["provenance"] = {
        "dataset_sha256": data_sha,
        "script_sha256": script_sha,
        "protocol": "verification/temporal_pilot.md",
        "python": platform.python_version(),
        "platform": platform.platform(),
        "machine": platform.machine(),
        "cpu_count": os.cpu_count(),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    from provenance import write_record

    write_record(
        None,
        experiment="temporal_pilot",
        seeds=list(config.BENCHMARK_SEEDS),
        dataset="credit_card",
        data_path=None,
        settings={**result["settings"], **result["provenance"]},
        outputs=[args.output.name],
    )
    print(f"wrote {args.output}")
    return 0


def x_main__mutmut_87(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=config.RESULTS_DIR / "temporal_pilot.json")
    parser.add_argument("--csv", type=Path, default=None)
    args = parser.parse_args(argv)
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(name)s %(message)s")
    spec = DATASETS["credit_card"]
    if args.csv is not None:
        spec = DatasetSpec(**{**spec.__dict__, "csv": args.csv})
    result = run(spec)
    with spec.csv.open("rb") as stream:
        data_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    with Path(__file__).open("rb") as stream:
        script_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    result["provenance"] = {
        "dataset_sha256": data_sha,
        "script_sha256": script_sha,
        "protocol": "verification/temporal_pilot.md",
        "python": platform.python_version(),
        "platform": platform.platform(),
        "machine": platform.machine(),
        "cpu_count": os.cpu_count(),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    from provenance import write_record

    write_record(
        args.output.with_name("run_temporal_pilot.json"),
        experiment=None,
        seeds=list(config.BENCHMARK_SEEDS),
        dataset="credit_card",
        data_path=None,
        settings={**result["settings"], **result["provenance"]},
        outputs=[args.output.name],
    )
    print(f"wrote {args.output}")
    return 0


def x_main__mutmut_88(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=config.RESULTS_DIR / "temporal_pilot.json")
    parser.add_argument("--csv", type=Path, default=None)
    args = parser.parse_args(argv)
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(name)s %(message)s")
    spec = DATASETS["credit_card"]
    if args.csv is not None:
        spec = DatasetSpec(**{**spec.__dict__, "csv": args.csv})
    result = run(spec)
    with spec.csv.open("rb") as stream:
        data_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    with Path(__file__).open("rb") as stream:
        script_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    result["provenance"] = {
        "dataset_sha256": data_sha,
        "script_sha256": script_sha,
        "protocol": "verification/temporal_pilot.md",
        "python": platform.python_version(),
        "platform": platform.platform(),
        "machine": platform.machine(),
        "cpu_count": os.cpu_count(),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    from provenance import write_record

    write_record(
        args.output.with_name("run_temporal_pilot.json"),
        experiment="temporal_pilot",
        seeds=None,
        dataset="credit_card",
        data_path=None,
        settings={**result["settings"], **result["provenance"]},
        outputs=[args.output.name],
    )
    print(f"wrote {args.output}")
    return 0


def x_main__mutmut_89(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=config.RESULTS_DIR / "temporal_pilot.json")
    parser.add_argument("--csv", type=Path, default=None)
    args = parser.parse_args(argv)
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(name)s %(message)s")
    spec = DATASETS["credit_card"]
    if args.csv is not None:
        spec = DatasetSpec(**{**spec.__dict__, "csv": args.csv})
    result = run(spec)
    with spec.csv.open("rb") as stream:
        data_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    with Path(__file__).open("rb") as stream:
        script_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    result["provenance"] = {
        "dataset_sha256": data_sha,
        "script_sha256": script_sha,
        "protocol": "verification/temporal_pilot.md",
        "python": platform.python_version(),
        "platform": platform.platform(),
        "machine": platform.machine(),
        "cpu_count": os.cpu_count(),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    from provenance import write_record

    write_record(
        args.output.with_name("run_temporal_pilot.json"),
        experiment="temporal_pilot",
        seeds=list(config.BENCHMARK_SEEDS),
        dataset=None,
        data_path=None,
        settings={**result["settings"], **result["provenance"]},
        outputs=[args.output.name],
    )
    print(f"wrote {args.output}")
    return 0


def x_main__mutmut_90(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=config.RESULTS_DIR / "temporal_pilot.json")
    parser.add_argument("--csv", type=Path, default=None)
    args = parser.parse_args(argv)
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(name)s %(message)s")
    spec = DATASETS["credit_card"]
    if args.csv is not None:
        spec = DatasetSpec(**{**spec.__dict__, "csv": args.csv})
    result = run(spec)
    with spec.csv.open("rb") as stream:
        data_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    with Path(__file__).open("rb") as stream:
        script_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    result["provenance"] = {
        "dataset_sha256": data_sha,
        "script_sha256": script_sha,
        "protocol": "verification/temporal_pilot.md",
        "python": platform.python_version(),
        "platform": platform.platform(),
        "machine": platform.machine(),
        "cpu_count": os.cpu_count(),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    from provenance import write_record

    write_record(
        args.output.with_name("run_temporal_pilot.json"),
        experiment="temporal_pilot",
        seeds=list(config.BENCHMARK_SEEDS),
        dataset="credit_card",
        data_path=None,
        settings=None,
        outputs=[args.output.name],
    )
    print(f"wrote {args.output}")
    return 0


def x_main__mutmut_91(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=config.RESULTS_DIR / "temporal_pilot.json")
    parser.add_argument("--csv", type=Path, default=None)
    args = parser.parse_args(argv)
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(name)s %(message)s")
    spec = DATASETS["credit_card"]
    if args.csv is not None:
        spec = DatasetSpec(**{**spec.__dict__, "csv": args.csv})
    result = run(spec)
    with spec.csv.open("rb") as stream:
        data_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    with Path(__file__).open("rb") as stream:
        script_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    result["provenance"] = {
        "dataset_sha256": data_sha,
        "script_sha256": script_sha,
        "protocol": "verification/temporal_pilot.md",
        "python": platform.python_version(),
        "platform": platform.platform(),
        "machine": platform.machine(),
        "cpu_count": os.cpu_count(),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    from provenance import write_record

    write_record(
        args.output.with_name("run_temporal_pilot.json"),
        experiment="temporal_pilot",
        seeds=list(config.BENCHMARK_SEEDS),
        dataset="credit_card",
        data_path=None,
        settings={**result["settings"], **result["provenance"]},
        outputs=None,
    )
    print(f"wrote {args.output}")
    return 0


def x_main__mutmut_92(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=config.RESULTS_DIR / "temporal_pilot.json")
    parser.add_argument("--csv", type=Path, default=None)
    args = parser.parse_args(argv)
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(name)s %(message)s")
    spec = DATASETS["credit_card"]
    if args.csv is not None:
        spec = DatasetSpec(**{**spec.__dict__, "csv": args.csv})
    result = run(spec)
    with spec.csv.open("rb") as stream:
        data_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    with Path(__file__).open("rb") as stream:
        script_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    result["provenance"] = {
        "dataset_sha256": data_sha,
        "script_sha256": script_sha,
        "protocol": "verification/temporal_pilot.md",
        "python": platform.python_version(),
        "platform": platform.platform(),
        "machine": platform.machine(),
        "cpu_count": os.cpu_count(),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    from provenance import write_record

    write_record(
        experiment="temporal_pilot",
        seeds=list(config.BENCHMARK_SEEDS),
        dataset="credit_card",
        data_path=None,
        settings={**result["settings"], **result["provenance"]},
        outputs=[args.output.name],
    )
    print(f"wrote {args.output}")
    return 0


def x_main__mutmut_93(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=config.RESULTS_DIR / "temporal_pilot.json")
    parser.add_argument("--csv", type=Path, default=None)
    args = parser.parse_args(argv)
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(name)s %(message)s")
    spec = DATASETS["credit_card"]
    if args.csv is not None:
        spec = DatasetSpec(**{**spec.__dict__, "csv": args.csv})
    result = run(spec)
    with spec.csv.open("rb") as stream:
        data_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    with Path(__file__).open("rb") as stream:
        script_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    result["provenance"] = {
        "dataset_sha256": data_sha,
        "script_sha256": script_sha,
        "protocol": "verification/temporal_pilot.md",
        "python": platform.python_version(),
        "platform": platform.platform(),
        "machine": platform.machine(),
        "cpu_count": os.cpu_count(),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    from provenance import write_record

    write_record(
        args.output.with_name("run_temporal_pilot.json"),
        seeds=list(config.BENCHMARK_SEEDS),
        dataset="credit_card",
        data_path=None,
        settings={**result["settings"], **result["provenance"]},
        outputs=[args.output.name],
    )
    print(f"wrote {args.output}")
    return 0


def x_main__mutmut_94(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=config.RESULTS_DIR / "temporal_pilot.json")
    parser.add_argument("--csv", type=Path, default=None)
    args = parser.parse_args(argv)
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(name)s %(message)s")
    spec = DATASETS["credit_card"]
    if args.csv is not None:
        spec = DatasetSpec(**{**spec.__dict__, "csv": args.csv})
    result = run(spec)
    with spec.csv.open("rb") as stream:
        data_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    with Path(__file__).open("rb") as stream:
        script_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    result["provenance"] = {
        "dataset_sha256": data_sha,
        "script_sha256": script_sha,
        "protocol": "verification/temporal_pilot.md",
        "python": platform.python_version(),
        "platform": platform.platform(),
        "machine": platform.machine(),
        "cpu_count": os.cpu_count(),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    from provenance import write_record

    write_record(
        args.output.with_name("run_temporal_pilot.json"),
        experiment="temporal_pilot",
        dataset="credit_card",
        data_path=None,
        settings={**result["settings"], **result["provenance"]},
        outputs=[args.output.name],
    )
    print(f"wrote {args.output}")
    return 0


def x_main__mutmut_95(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=config.RESULTS_DIR / "temporal_pilot.json")
    parser.add_argument("--csv", type=Path, default=None)
    args = parser.parse_args(argv)
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(name)s %(message)s")
    spec = DATASETS["credit_card"]
    if args.csv is not None:
        spec = DatasetSpec(**{**spec.__dict__, "csv": args.csv})
    result = run(spec)
    with spec.csv.open("rb") as stream:
        data_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    with Path(__file__).open("rb") as stream:
        script_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    result["provenance"] = {
        "dataset_sha256": data_sha,
        "script_sha256": script_sha,
        "protocol": "verification/temporal_pilot.md",
        "python": platform.python_version(),
        "platform": platform.platform(),
        "machine": platform.machine(),
        "cpu_count": os.cpu_count(),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    from provenance import write_record

    write_record(
        args.output.with_name("run_temporal_pilot.json"),
        experiment="temporal_pilot",
        seeds=list(config.BENCHMARK_SEEDS),
        data_path=None,
        settings={**result["settings"], **result["provenance"]},
        outputs=[args.output.name],
    )
    print(f"wrote {args.output}")
    return 0


def x_main__mutmut_96(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=config.RESULTS_DIR / "temporal_pilot.json")
    parser.add_argument("--csv", type=Path, default=None)
    args = parser.parse_args(argv)
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(name)s %(message)s")
    spec = DATASETS["credit_card"]
    if args.csv is not None:
        spec = DatasetSpec(**{**spec.__dict__, "csv": args.csv})
    result = run(spec)
    with spec.csv.open("rb") as stream:
        data_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    with Path(__file__).open("rb") as stream:
        script_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    result["provenance"] = {
        "dataset_sha256": data_sha,
        "script_sha256": script_sha,
        "protocol": "verification/temporal_pilot.md",
        "python": platform.python_version(),
        "platform": platform.platform(),
        "machine": platform.machine(),
        "cpu_count": os.cpu_count(),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    from provenance import write_record

    write_record(
        args.output.with_name("run_temporal_pilot.json"),
        experiment="temporal_pilot",
        seeds=list(config.BENCHMARK_SEEDS),
        dataset="credit_card",
        settings={**result["settings"], **result["provenance"]},
        outputs=[args.output.name],
    )
    print(f"wrote {args.output}")
    return 0


def x_main__mutmut_97(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=config.RESULTS_DIR / "temporal_pilot.json")
    parser.add_argument("--csv", type=Path, default=None)
    args = parser.parse_args(argv)
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(name)s %(message)s")
    spec = DATASETS["credit_card"]
    if args.csv is not None:
        spec = DatasetSpec(**{**spec.__dict__, "csv": args.csv})
    result = run(spec)
    with spec.csv.open("rb") as stream:
        data_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    with Path(__file__).open("rb") as stream:
        script_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    result["provenance"] = {
        "dataset_sha256": data_sha,
        "script_sha256": script_sha,
        "protocol": "verification/temporal_pilot.md",
        "python": platform.python_version(),
        "platform": platform.platform(),
        "machine": platform.machine(),
        "cpu_count": os.cpu_count(),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    from provenance import write_record

    write_record(
        args.output.with_name("run_temporal_pilot.json"),
        experiment="temporal_pilot",
        seeds=list(config.BENCHMARK_SEEDS),
        dataset="credit_card",
        data_path=None,
        outputs=[args.output.name],
    )
    print(f"wrote {args.output}")
    return 0


def x_main__mutmut_98(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=config.RESULTS_DIR / "temporal_pilot.json")
    parser.add_argument("--csv", type=Path, default=None)
    args = parser.parse_args(argv)
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(name)s %(message)s")
    spec = DATASETS["credit_card"]
    if args.csv is not None:
        spec = DatasetSpec(**{**spec.__dict__, "csv": args.csv})
    result = run(spec)
    with spec.csv.open("rb") as stream:
        data_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    with Path(__file__).open("rb") as stream:
        script_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    result["provenance"] = {
        "dataset_sha256": data_sha,
        "script_sha256": script_sha,
        "protocol": "verification/temporal_pilot.md",
        "python": platform.python_version(),
        "platform": platform.platform(),
        "machine": platform.machine(),
        "cpu_count": os.cpu_count(),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    from provenance import write_record

    write_record(
        args.output.with_name("run_temporal_pilot.json"),
        experiment="temporal_pilot",
        seeds=list(config.BENCHMARK_SEEDS),
        dataset="credit_card",
        data_path=None,
        settings={**result["settings"], **result["provenance"]},
        )
    print(f"wrote {args.output}")
    return 0


def x_main__mutmut_99(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=config.RESULTS_DIR / "temporal_pilot.json")
    parser.add_argument("--csv", type=Path, default=None)
    args = parser.parse_args(argv)
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(name)s %(message)s")
    spec = DATASETS["credit_card"]
    if args.csv is not None:
        spec = DatasetSpec(**{**spec.__dict__, "csv": args.csv})
    result = run(spec)
    with spec.csv.open("rb") as stream:
        data_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    with Path(__file__).open("rb") as stream:
        script_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    result["provenance"] = {
        "dataset_sha256": data_sha,
        "script_sha256": script_sha,
        "protocol": "verification/temporal_pilot.md",
        "python": platform.python_version(),
        "platform": platform.platform(),
        "machine": platform.machine(),
        "cpu_count": os.cpu_count(),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    from provenance import write_record

    write_record(
        args.output.with_name(None),
        experiment="temporal_pilot",
        seeds=list(config.BENCHMARK_SEEDS),
        dataset="credit_card",
        data_path=None,
        settings={**result["settings"], **result["provenance"]},
        outputs=[args.output.name],
    )
    print(f"wrote {args.output}")
    return 0


def x_main__mutmut_100(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=config.RESULTS_DIR / "temporal_pilot.json")
    parser.add_argument("--csv", type=Path, default=None)
    args = parser.parse_args(argv)
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(name)s %(message)s")
    spec = DATASETS["credit_card"]
    if args.csv is not None:
        spec = DatasetSpec(**{**spec.__dict__, "csv": args.csv})
    result = run(spec)
    with spec.csv.open("rb") as stream:
        data_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    with Path(__file__).open("rb") as stream:
        script_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    result["provenance"] = {
        "dataset_sha256": data_sha,
        "script_sha256": script_sha,
        "protocol": "verification/temporal_pilot.md",
        "python": platform.python_version(),
        "platform": platform.platform(),
        "machine": platform.machine(),
        "cpu_count": os.cpu_count(),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    from provenance import write_record

    write_record(
        args.output.with_name("XXrun_temporal_pilot.jsonXX"),
        experiment="temporal_pilot",
        seeds=list(config.BENCHMARK_SEEDS),
        dataset="credit_card",
        data_path=None,
        settings={**result["settings"], **result["provenance"]},
        outputs=[args.output.name],
    )
    print(f"wrote {args.output}")
    return 0


def x_main__mutmut_101(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=config.RESULTS_DIR / "temporal_pilot.json")
    parser.add_argument("--csv", type=Path, default=None)
    args = parser.parse_args(argv)
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(name)s %(message)s")
    spec = DATASETS["credit_card"]
    if args.csv is not None:
        spec = DatasetSpec(**{**spec.__dict__, "csv": args.csv})
    result = run(spec)
    with spec.csv.open("rb") as stream:
        data_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    with Path(__file__).open("rb") as stream:
        script_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    result["provenance"] = {
        "dataset_sha256": data_sha,
        "script_sha256": script_sha,
        "protocol": "verification/temporal_pilot.md",
        "python": platform.python_version(),
        "platform": platform.platform(),
        "machine": platform.machine(),
        "cpu_count": os.cpu_count(),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    from provenance import write_record

    write_record(
        args.output.with_name("RUN_TEMPORAL_PILOT.JSON"),
        experiment="temporal_pilot",
        seeds=list(config.BENCHMARK_SEEDS),
        dataset="credit_card",
        data_path=None,
        settings={**result["settings"], **result["provenance"]},
        outputs=[args.output.name],
    )
    print(f"wrote {args.output}")
    return 0


def x_main__mutmut_102(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=config.RESULTS_DIR / "temporal_pilot.json")
    parser.add_argument("--csv", type=Path, default=None)
    args = parser.parse_args(argv)
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(name)s %(message)s")
    spec = DATASETS["credit_card"]
    if args.csv is not None:
        spec = DatasetSpec(**{**spec.__dict__, "csv": args.csv})
    result = run(spec)
    with spec.csv.open("rb") as stream:
        data_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    with Path(__file__).open("rb") as stream:
        script_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    result["provenance"] = {
        "dataset_sha256": data_sha,
        "script_sha256": script_sha,
        "protocol": "verification/temporal_pilot.md",
        "python": platform.python_version(),
        "platform": platform.platform(),
        "machine": platform.machine(),
        "cpu_count": os.cpu_count(),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    from provenance import write_record

    write_record(
        args.output.with_name("run_temporal_pilot.json"),
        experiment="XXtemporal_pilotXX",
        seeds=list(config.BENCHMARK_SEEDS),
        dataset="credit_card",
        data_path=None,
        settings={**result["settings"], **result["provenance"]},
        outputs=[args.output.name],
    )
    print(f"wrote {args.output}")
    return 0


def x_main__mutmut_103(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=config.RESULTS_DIR / "temporal_pilot.json")
    parser.add_argument("--csv", type=Path, default=None)
    args = parser.parse_args(argv)
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(name)s %(message)s")
    spec = DATASETS["credit_card"]
    if args.csv is not None:
        spec = DatasetSpec(**{**spec.__dict__, "csv": args.csv})
    result = run(spec)
    with spec.csv.open("rb") as stream:
        data_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    with Path(__file__).open("rb") as stream:
        script_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    result["provenance"] = {
        "dataset_sha256": data_sha,
        "script_sha256": script_sha,
        "protocol": "verification/temporal_pilot.md",
        "python": platform.python_version(),
        "platform": platform.platform(),
        "machine": platform.machine(),
        "cpu_count": os.cpu_count(),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    from provenance import write_record

    write_record(
        args.output.with_name("run_temporal_pilot.json"),
        experiment="TEMPORAL_PILOT",
        seeds=list(config.BENCHMARK_SEEDS),
        dataset="credit_card",
        data_path=None,
        settings={**result["settings"], **result["provenance"]},
        outputs=[args.output.name],
    )
    print(f"wrote {args.output}")
    return 0


def x_main__mutmut_104(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=config.RESULTS_DIR / "temporal_pilot.json")
    parser.add_argument("--csv", type=Path, default=None)
    args = parser.parse_args(argv)
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(name)s %(message)s")
    spec = DATASETS["credit_card"]
    if args.csv is not None:
        spec = DatasetSpec(**{**spec.__dict__, "csv": args.csv})
    result = run(spec)
    with spec.csv.open("rb") as stream:
        data_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    with Path(__file__).open("rb") as stream:
        script_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    result["provenance"] = {
        "dataset_sha256": data_sha,
        "script_sha256": script_sha,
        "protocol": "verification/temporal_pilot.md",
        "python": platform.python_version(),
        "platform": platform.platform(),
        "machine": platform.machine(),
        "cpu_count": os.cpu_count(),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    from provenance import write_record

    write_record(
        args.output.with_name("run_temporal_pilot.json"),
        experiment="temporal_pilot",
        seeds=list(None),
        dataset="credit_card",
        data_path=None,
        settings={**result["settings"], **result["provenance"]},
        outputs=[args.output.name],
    )
    print(f"wrote {args.output}")
    return 0


def x_main__mutmut_105(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=config.RESULTS_DIR / "temporal_pilot.json")
    parser.add_argument("--csv", type=Path, default=None)
    args = parser.parse_args(argv)
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(name)s %(message)s")
    spec = DATASETS["credit_card"]
    if args.csv is not None:
        spec = DatasetSpec(**{**spec.__dict__, "csv": args.csv})
    result = run(spec)
    with spec.csv.open("rb") as stream:
        data_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    with Path(__file__).open("rb") as stream:
        script_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    result["provenance"] = {
        "dataset_sha256": data_sha,
        "script_sha256": script_sha,
        "protocol": "verification/temporal_pilot.md",
        "python": platform.python_version(),
        "platform": platform.platform(),
        "machine": platform.machine(),
        "cpu_count": os.cpu_count(),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    from provenance import write_record

    write_record(
        args.output.with_name("run_temporal_pilot.json"),
        experiment="temporal_pilot",
        seeds=list(config.BENCHMARK_SEEDS),
        dataset="XXcredit_cardXX",
        data_path=None,
        settings={**result["settings"], **result["provenance"]},
        outputs=[args.output.name],
    )
    print(f"wrote {args.output}")
    return 0


def x_main__mutmut_106(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=config.RESULTS_DIR / "temporal_pilot.json")
    parser.add_argument("--csv", type=Path, default=None)
    args = parser.parse_args(argv)
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(name)s %(message)s")
    spec = DATASETS["credit_card"]
    if args.csv is not None:
        spec = DatasetSpec(**{**spec.__dict__, "csv": args.csv})
    result = run(spec)
    with spec.csv.open("rb") as stream:
        data_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    with Path(__file__).open("rb") as stream:
        script_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    result["provenance"] = {
        "dataset_sha256": data_sha,
        "script_sha256": script_sha,
        "protocol": "verification/temporal_pilot.md",
        "python": platform.python_version(),
        "platform": platform.platform(),
        "machine": platform.machine(),
        "cpu_count": os.cpu_count(),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    from provenance import write_record

    write_record(
        args.output.with_name("run_temporal_pilot.json"),
        experiment="temporal_pilot",
        seeds=list(config.BENCHMARK_SEEDS),
        dataset="CREDIT_CARD",
        data_path=None,
        settings={**result["settings"], **result["provenance"]},
        outputs=[args.output.name],
    )
    print(f"wrote {args.output}")
    return 0


def x_main__mutmut_107(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=config.RESULTS_DIR / "temporal_pilot.json")
    parser.add_argument("--csv", type=Path, default=None)
    args = parser.parse_args(argv)
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(name)s %(message)s")
    spec = DATASETS["credit_card"]
    if args.csv is not None:
        spec = DatasetSpec(**{**spec.__dict__, "csv": args.csv})
    result = run(spec)
    with spec.csv.open("rb") as stream:
        data_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    with Path(__file__).open("rb") as stream:
        script_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    result["provenance"] = {
        "dataset_sha256": data_sha,
        "script_sha256": script_sha,
        "protocol": "verification/temporal_pilot.md",
        "python": platform.python_version(),
        "platform": platform.platform(),
        "machine": platform.machine(),
        "cpu_count": os.cpu_count(),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    from provenance import write_record

    write_record(
        args.output.with_name("run_temporal_pilot.json"),
        experiment="temporal_pilot",
        seeds=list(config.BENCHMARK_SEEDS),
        dataset="credit_card",
        data_path=None,
        settings={**result["XXsettingsXX"], **result["provenance"]},
        outputs=[args.output.name],
    )
    print(f"wrote {args.output}")
    return 0


def x_main__mutmut_108(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=config.RESULTS_DIR / "temporal_pilot.json")
    parser.add_argument("--csv", type=Path, default=None)
    args = parser.parse_args(argv)
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(name)s %(message)s")
    spec = DATASETS["credit_card"]
    if args.csv is not None:
        spec = DatasetSpec(**{**spec.__dict__, "csv": args.csv})
    result = run(spec)
    with spec.csv.open("rb") as stream:
        data_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    with Path(__file__).open("rb") as stream:
        script_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    result["provenance"] = {
        "dataset_sha256": data_sha,
        "script_sha256": script_sha,
        "protocol": "verification/temporal_pilot.md",
        "python": platform.python_version(),
        "platform": platform.platform(),
        "machine": platform.machine(),
        "cpu_count": os.cpu_count(),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    from provenance import write_record

    write_record(
        args.output.with_name("run_temporal_pilot.json"),
        experiment="temporal_pilot",
        seeds=list(config.BENCHMARK_SEEDS),
        dataset="credit_card",
        data_path=None,
        settings={**result["SETTINGS"], **result["provenance"]},
        outputs=[args.output.name],
    )
    print(f"wrote {args.output}")
    return 0


def x_main__mutmut_109(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=config.RESULTS_DIR / "temporal_pilot.json")
    parser.add_argument("--csv", type=Path, default=None)
    args = parser.parse_args(argv)
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(name)s %(message)s")
    spec = DATASETS["credit_card"]
    if args.csv is not None:
        spec = DatasetSpec(**{**spec.__dict__, "csv": args.csv})
    result = run(spec)
    with spec.csv.open("rb") as stream:
        data_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    with Path(__file__).open("rb") as stream:
        script_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    result["provenance"] = {
        "dataset_sha256": data_sha,
        "script_sha256": script_sha,
        "protocol": "verification/temporal_pilot.md",
        "python": platform.python_version(),
        "platform": platform.platform(),
        "machine": platform.machine(),
        "cpu_count": os.cpu_count(),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    from provenance import write_record

    write_record(
        args.output.with_name("run_temporal_pilot.json"),
        experiment="temporal_pilot",
        seeds=list(config.BENCHMARK_SEEDS),
        dataset="credit_card",
        data_path=None,
        settings={**result["settings"], **result["XXprovenanceXX"]},
        outputs=[args.output.name],
    )
    print(f"wrote {args.output}")
    return 0


def x_main__mutmut_110(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=config.RESULTS_DIR / "temporal_pilot.json")
    parser.add_argument("--csv", type=Path, default=None)
    args = parser.parse_args(argv)
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(name)s %(message)s")
    spec = DATASETS["credit_card"]
    if args.csv is not None:
        spec = DatasetSpec(**{**spec.__dict__, "csv": args.csv})
    result = run(spec)
    with spec.csv.open("rb") as stream:
        data_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    with Path(__file__).open("rb") as stream:
        script_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    result["provenance"] = {
        "dataset_sha256": data_sha,
        "script_sha256": script_sha,
        "protocol": "verification/temporal_pilot.md",
        "python": platform.python_version(),
        "platform": platform.platform(),
        "machine": platform.machine(),
        "cpu_count": os.cpu_count(),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    from provenance import write_record

    write_record(
        args.output.with_name("run_temporal_pilot.json"),
        experiment="temporal_pilot",
        seeds=list(config.BENCHMARK_SEEDS),
        dataset="credit_card",
        data_path=None,
        settings={**result["settings"], **result["PROVENANCE"]},
        outputs=[args.output.name],
    )
    print(f"wrote {args.output}")
    return 0


def x_main__mutmut_111(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=config.RESULTS_DIR / "temporal_pilot.json")
    parser.add_argument("--csv", type=Path, default=None)
    args = parser.parse_args(argv)
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(name)s %(message)s")
    spec = DATASETS["credit_card"]
    if args.csv is not None:
        spec = DatasetSpec(**{**spec.__dict__, "csv": args.csv})
    result = run(spec)
    with spec.csv.open("rb") as stream:
        data_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    with Path(__file__).open("rb") as stream:
        script_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    result["provenance"] = {
        "dataset_sha256": data_sha,
        "script_sha256": script_sha,
        "protocol": "verification/temporal_pilot.md",
        "python": platform.python_version(),
        "platform": platform.platform(),
        "machine": platform.machine(),
        "cpu_count": os.cpu_count(),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    from provenance import write_record

    write_record(
        args.output.with_name("run_temporal_pilot.json"),
        experiment="temporal_pilot",
        seeds=list(config.BENCHMARK_SEEDS),
        dataset="credit_card",
        data_path=None,
        settings={**result["settings"], **result["provenance"]},
        outputs=[args.output.name],
    )
    print(None)
    return 0


def x_main__mutmut_112(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=config.RESULTS_DIR / "temporal_pilot.json")
    parser.add_argument("--csv", type=Path, default=None)
    args = parser.parse_args(argv)
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(name)s %(message)s")
    spec = DATASETS["credit_card"]
    if args.csv is not None:
        spec = DatasetSpec(**{**spec.__dict__, "csv": args.csv})
    result = run(spec)
    with spec.csv.open("rb") as stream:
        data_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    with Path(__file__).open("rb") as stream:
        script_sha = hashlib.file_digest(stream, hashlib.sha256).hexdigest()
    result["provenance"] = {
        "dataset_sha256": data_sha,
        "script_sha256": script_sha,
        "protocol": "verification/temporal_pilot.md",
        "python": platform.python_version(),
        "platform": platform.platform(),
        "machine": platform.machine(),
        "cpu_count": os.cpu_count(),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    from provenance import write_record

    write_record(
        args.output.with_name("run_temporal_pilot.json"),
        experiment="temporal_pilot",
        seeds=list(config.BENCHMARK_SEEDS),
        dataset="credit_card",
        data_path=None,
        settings={**result["settings"], **result["provenance"]},
        outputs=[args.output.name],
    )
    print(f"wrote {args.output}")
    return 1

mutants_x_main__mutmut['_mutmut_orig'] = x_main__mutmut_orig # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_1'] = x_main__mutmut_1 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_2'] = x_main__mutmut_2 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_3'] = x_main__mutmut_3 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_4'] = x_main__mutmut_4 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_5'] = x_main__mutmut_5 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_6'] = x_main__mutmut_6 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_7'] = x_main__mutmut_7 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_8'] = x_main__mutmut_8 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_9'] = x_main__mutmut_9 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_10'] = x_main__mutmut_10 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_11'] = x_main__mutmut_11 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_12'] = x_main__mutmut_12 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_13'] = x_main__mutmut_13 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_14'] = x_main__mutmut_14 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_15'] = x_main__mutmut_15 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_16'] = x_main__mutmut_16 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_17'] = x_main__mutmut_17 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_18'] = x_main__mutmut_18 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_19'] = x_main__mutmut_19 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_20'] = x_main__mutmut_20 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_21'] = x_main__mutmut_21 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_22'] = x_main__mutmut_22 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_23'] = x_main__mutmut_23 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_24'] = x_main__mutmut_24 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_25'] = x_main__mutmut_25 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_26'] = x_main__mutmut_26 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_27'] = x_main__mutmut_27 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_28'] = x_main__mutmut_28 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_29'] = x_main__mutmut_29 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_30'] = x_main__mutmut_30 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_31'] = x_main__mutmut_31 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_32'] = x_main__mutmut_32 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_33'] = x_main__mutmut_33 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_34'] = x_main__mutmut_34 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_35'] = x_main__mutmut_35 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_36'] = x_main__mutmut_36 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_37'] = x_main__mutmut_37 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_38'] = x_main__mutmut_38 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_39'] = x_main__mutmut_39 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_40'] = x_main__mutmut_40 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_41'] = x_main__mutmut_41 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_42'] = x_main__mutmut_42 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_43'] = x_main__mutmut_43 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_44'] = x_main__mutmut_44 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_45'] = x_main__mutmut_45 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_46'] = x_main__mutmut_46 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_47'] = x_main__mutmut_47 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_48'] = x_main__mutmut_48 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_49'] = x_main__mutmut_49 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_50'] = x_main__mutmut_50 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_51'] = x_main__mutmut_51 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_52'] = x_main__mutmut_52 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_53'] = x_main__mutmut_53 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_54'] = x_main__mutmut_54 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_55'] = x_main__mutmut_55 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_56'] = x_main__mutmut_56 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_57'] = x_main__mutmut_57 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_58'] = x_main__mutmut_58 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_59'] = x_main__mutmut_59 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_60'] = x_main__mutmut_60 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_61'] = x_main__mutmut_61 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_62'] = x_main__mutmut_62 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_63'] = x_main__mutmut_63 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_64'] = x_main__mutmut_64 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_65'] = x_main__mutmut_65 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_66'] = x_main__mutmut_66 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_67'] = x_main__mutmut_67 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_68'] = x_main__mutmut_68 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_69'] = x_main__mutmut_69 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_70'] = x_main__mutmut_70 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_71'] = x_main__mutmut_71 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_72'] = x_main__mutmut_72 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_73'] = x_main__mutmut_73 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_74'] = x_main__mutmut_74 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_75'] = x_main__mutmut_75 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_76'] = x_main__mutmut_76 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_77'] = x_main__mutmut_77 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_78'] = x_main__mutmut_78 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_79'] = x_main__mutmut_79 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_80'] = x_main__mutmut_80 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_81'] = x_main__mutmut_81 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_82'] = x_main__mutmut_82 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_83'] = x_main__mutmut_83 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_84'] = x_main__mutmut_84 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_85'] = x_main__mutmut_85 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_86'] = x_main__mutmut_86 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_87'] = x_main__mutmut_87 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_88'] = x_main__mutmut_88 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_89'] = x_main__mutmut_89 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_90'] = x_main__mutmut_90 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_91'] = x_main__mutmut_91 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_92'] = x_main__mutmut_92 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_93'] = x_main__mutmut_93 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_94'] = x_main__mutmut_94 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_95'] = x_main__mutmut_95 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_96'] = x_main__mutmut_96 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_97'] = x_main__mutmut_97 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_98'] = x_main__mutmut_98 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_99'] = x_main__mutmut_99 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_100'] = x_main__mutmut_100 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_101'] = x_main__mutmut_101 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_102'] = x_main__mutmut_102 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_103'] = x_main__mutmut_103 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_104'] = x_main__mutmut_104 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_105'] = x_main__mutmut_105 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_106'] = x_main__mutmut_106 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_107'] = x_main__mutmut_107 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_108'] = x_main__mutmut_108 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_109'] = x_main__mutmut_109 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_110'] = x_main__mutmut_110 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_111'] = x_main__mutmut_111 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_112'] = x_main__mutmut_112 # type: ignore # mutmut generated


if __name__ == "__main__":
    raise SystemExit(main())
