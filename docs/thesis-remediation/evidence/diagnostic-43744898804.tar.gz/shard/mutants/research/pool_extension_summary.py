"""Tables and hypotheses P1 to P6 of the pool extension (verification/pool_extension.md)."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
from scipy.stats import spearmanr

METRICS = ("precision", "recall", "f1", "flagged_pct")
GRID = ("0.001", "0.01", "0.05", "0.1", "0.2")


from mutmut.mutation.trampoline import wrap_in_trampoline as _mutmut_mutated, MutantDict
mutants_x_load_runs__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_load_runs__mutmut)
def load_runs(*folders: Path) -> list[dict[str, Any]]:
    """The problem files of the one-pass runs, the classical and the neural folders together."""
    merged: dict[str, dict[str, Any]] = {}
    for folder in folders:
        for path in sorted(folder.glob("*.json")):
            run = json.loads(path.read_text())
            if "failed" in run:
                continue
            base = merged.setdefault(
                run["problem"], {**run, "runs": {}, "errors": {}, "skipped": []}
            )
            base["runs"].update(run["runs"])
            base["errors"].update(run["errors"])
            base["skipped"] = sorted(set(base["skipped"]) | set(run["skipped"]))
    return list(merged.values())


def x_load_runs__mutmut_orig(*folders: Path) -> list[dict[str, Any]]:
    """The problem files of the one-pass runs, the classical and the neural folders together."""
    merged: dict[str, dict[str, Any]] = {}
    for folder in folders:
        for path in sorted(folder.glob("*.json")):
            run = json.loads(path.read_text())
            if "failed" in run:
                continue
            base = merged.setdefault(
                run["problem"], {**run, "runs": {}, "errors": {}, "skipped": []}
            )
            base["runs"].update(run["runs"])
            base["errors"].update(run["errors"])
            base["skipped"] = sorted(set(base["skipped"]) | set(run["skipped"]))
    return list(merged.values())


def x_load_runs__mutmut_1(*folders: Path) -> list[dict[str, Any]]:
    """The problem files of the one-pass runs, the classical and the neural folders together."""
    merged: dict[str, dict[str, Any]] = None
    for folder in folders:
        for path in sorted(folder.glob("*.json")):
            run = json.loads(path.read_text())
            if "failed" in run:
                continue
            base = merged.setdefault(
                run["problem"], {**run, "runs": {}, "errors": {}, "skipped": []}
            )
            base["runs"].update(run["runs"])
            base["errors"].update(run["errors"])
            base["skipped"] = sorted(set(base["skipped"]) | set(run["skipped"]))
    return list(merged.values())


def x_load_runs__mutmut_2(*folders: Path) -> list[dict[str, Any]]:
    """The problem files of the one-pass runs, the classical and the neural folders together."""
    merged: dict[str, dict[str, Any]] = {}
    for folder in folders:
        for path in sorted(None):
            run = json.loads(path.read_text())
            if "failed" in run:
                continue
            base = merged.setdefault(
                run["problem"], {**run, "runs": {}, "errors": {}, "skipped": []}
            )
            base["runs"].update(run["runs"])
            base["errors"].update(run["errors"])
            base["skipped"] = sorted(set(base["skipped"]) | set(run["skipped"]))
    return list(merged.values())


def x_load_runs__mutmut_3(*folders: Path) -> list[dict[str, Any]]:
    """The problem files of the one-pass runs, the classical and the neural folders together."""
    merged: dict[str, dict[str, Any]] = {}
    for folder in folders:
        for path in sorted(folder.glob(None)):
            run = json.loads(path.read_text())
            if "failed" in run:
                continue
            base = merged.setdefault(
                run["problem"], {**run, "runs": {}, "errors": {}, "skipped": []}
            )
            base["runs"].update(run["runs"])
            base["errors"].update(run["errors"])
            base["skipped"] = sorted(set(base["skipped"]) | set(run["skipped"]))
    return list(merged.values())


def x_load_runs__mutmut_4(*folders: Path) -> list[dict[str, Any]]:
    """The problem files of the one-pass runs, the classical and the neural folders together."""
    merged: dict[str, dict[str, Any]] = {}
    for folder in folders:
        for path in sorted(folder.glob("XX*.jsonXX")):
            run = json.loads(path.read_text())
            if "failed" in run:
                continue
            base = merged.setdefault(
                run["problem"], {**run, "runs": {}, "errors": {}, "skipped": []}
            )
            base["runs"].update(run["runs"])
            base["errors"].update(run["errors"])
            base["skipped"] = sorted(set(base["skipped"]) | set(run["skipped"]))
    return list(merged.values())


def x_load_runs__mutmut_5(*folders: Path) -> list[dict[str, Any]]:
    """The problem files of the one-pass runs, the classical and the neural folders together."""
    merged: dict[str, dict[str, Any]] = {}
    for folder in folders:
        for path in sorted(folder.glob("*.JSON")):
            run = json.loads(path.read_text())
            if "failed" in run:
                continue
            base = merged.setdefault(
                run["problem"], {**run, "runs": {}, "errors": {}, "skipped": []}
            )
            base["runs"].update(run["runs"])
            base["errors"].update(run["errors"])
            base["skipped"] = sorted(set(base["skipped"]) | set(run["skipped"]))
    return list(merged.values())


def x_load_runs__mutmut_6(*folders: Path) -> list[dict[str, Any]]:
    """The problem files of the one-pass runs, the classical and the neural folders together."""
    merged: dict[str, dict[str, Any]] = {}
    for folder in folders:
        for path in sorted(folder.glob("*.json")):
            run = None
            if "failed" in run:
                continue
            base = merged.setdefault(
                run["problem"], {**run, "runs": {}, "errors": {}, "skipped": []}
            )
            base["runs"].update(run["runs"])
            base["errors"].update(run["errors"])
            base["skipped"] = sorted(set(base["skipped"]) | set(run["skipped"]))
    return list(merged.values())


def x_load_runs__mutmut_7(*folders: Path) -> list[dict[str, Any]]:
    """The problem files of the one-pass runs, the classical and the neural folders together."""
    merged: dict[str, dict[str, Any]] = {}
    for folder in folders:
        for path in sorted(folder.glob("*.json")):
            run = json.loads(None)
            if "failed" in run:
                continue
            base = merged.setdefault(
                run["problem"], {**run, "runs": {}, "errors": {}, "skipped": []}
            )
            base["runs"].update(run["runs"])
            base["errors"].update(run["errors"])
            base["skipped"] = sorted(set(base["skipped"]) | set(run["skipped"]))
    return list(merged.values())


def x_load_runs__mutmut_8(*folders: Path) -> list[dict[str, Any]]:
    """The problem files of the one-pass runs, the classical and the neural folders together."""
    merged: dict[str, dict[str, Any]] = {}
    for folder in folders:
        for path in sorted(folder.glob("*.json")):
            run = json.loads(path.read_text())
            if "XXfailedXX" in run:
                continue
            base = merged.setdefault(
                run["problem"], {**run, "runs": {}, "errors": {}, "skipped": []}
            )
            base["runs"].update(run["runs"])
            base["errors"].update(run["errors"])
            base["skipped"] = sorted(set(base["skipped"]) | set(run["skipped"]))
    return list(merged.values())


def x_load_runs__mutmut_9(*folders: Path) -> list[dict[str, Any]]:
    """The problem files of the one-pass runs, the classical and the neural folders together."""
    merged: dict[str, dict[str, Any]] = {}
    for folder in folders:
        for path in sorted(folder.glob("*.json")):
            run = json.loads(path.read_text())
            if "FAILED" in run:
                continue
            base = merged.setdefault(
                run["problem"], {**run, "runs": {}, "errors": {}, "skipped": []}
            )
            base["runs"].update(run["runs"])
            base["errors"].update(run["errors"])
            base["skipped"] = sorted(set(base["skipped"]) | set(run["skipped"]))
    return list(merged.values())


def x_load_runs__mutmut_10(*folders: Path) -> list[dict[str, Any]]:
    """The problem files of the one-pass runs, the classical and the neural folders together."""
    merged: dict[str, dict[str, Any]] = {}
    for folder in folders:
        for path in sorted(folder.glob("*.json")):
            run = json.loads(path.read_text())
            if "failed" not in run:
                continue
            base = merged.setdefault(
                run["problem"], {**run, "runs": {}, "errors": {}, "skipped": []}
            )
            base["runs"].update(run["runs"])
            base["errors"].update(run["errors"])
            base["skipped"] = sorted(set(base["skipped"]) | set(run["skipped"]))
    return list(merged.values())


def x_load_runs__mutmut_11(*folders: Path) -> list[dict[str, Any]]:
    """The problem files of the one-pass runs, the classical and the neural folders together."""
    merged: dict[str, dict[str, Any]] = {}
    for folder in folders:
        for path in sorted(folder.glob("*.json")):
            run = json.loads(path.read_text())
            if "failed" in run:
                break
            base = merged.setdefault(
                run["problem"], {**run, "runs": {}, "errors": {}, "skipped": []}
            )
            base["runs"].update(run["runs"])
            base["errors"].update(run["errors"])
            base["skipped"] = sorted(set(base["skipped"]) | set(run["skipped"]))
    return list(merged.values())


def x_load_runs__mutmut_12(*folders: Path) -> list[dict[str, Any]]:
    """The problem files of the one-pass runs, the classical and the neural folders together."""
    merged: dict[str, dict[str, Any]] = {}
    for folder in folders:
        for path in sorted(folder.glob("*.json")):
            run = json.loads(path.read_text())
            if "failed" in run:
                continue
            base = None
            base["runs"].update(run["runs"])
            base["errors"].update(run["errors"])
            base["skipped"] = sorted(set(base["skipped"]) | set(run["skipped"]))
    return list(merged.values())


def x_load_runs__mutmut_13(*folders: Path) -> list[dict[str, Any]]:
    """The problem files of the one-pass runs, the classical and the neural folders together."""
    merged: dict[str, dict[str, Any]] = {}
    for folder in folders:
        for path in sorted(folder.glob("*.json")):
            run = json.loads(path.read_text())
            if "failed" in run:
                continue
            base = merged.setdefault(
                None, {**run, "runs": {}, "errors": {}, "skipped": []}
            )
            base["runs"].update(run["runs"])
            base["errors"].update(run["errors"])
            base["skipped"] = sorted(set(base["skipped"]) | set(run["skipped"]))
    return list(merged.values())


def x_load_runs__mutmut_14(*folders: Path) -> list[dict[str, Any]]:
    """The problem files of the one-pass runs, the classical and the neural folders together."""
    merged: dict[str, dict[str, Any]] = {}
    for folder in folders:
        for path in sorted(folder.glob("*.json")):
            run = json.loads(path.read_text())
            if "failed" in run:
                continue
            base = merged.setdefault(
                run["problem"], None
            )
            base["runs"].update(run["runs"])
            base["errors"].update(run["errors"])
            base["skipped"] = sorted(set(base["skipped"]) | set(run["skipped"]))
    return list(merged.values())


def x_load_runs__mutmut_15(*folders: Path) -> list[dict[str, Any]]:
    """The problem files of the one-pass runs, the classical and the neural folders together."""
    merged: dict[str, dict[str, Any]] = {}
    for folder in folders:
        for path in sorted(folder.glob("*.json")):
            run = json.loads(path.read_text())
            if "failed" in run:
                continue
            base = merged.setdefault(
                {**run, "runs": {}, "errors": {}, "skipped": []}
            )
            base["runs"].update(run["runs"])
            base["errors"].update(run["errors"])
            base["skipped"] = sorted(set(base["skipped"]) | set(run["skipped"]))
    return list(merged.values())


def x_load_runs__mutmut_16(*folders: Path) -> list[dict[str, Any]]:
    """The problem files of the one-pass runs, the classical and the neural folders together."""
    merged: dict[str, dict[str, Any]] = {}
    for folder in folders:
        for path in sorted(folder.glob("*.json")):
            run = json.loads(path.read_text())
            if "failed" in run:
                continue
            base = merged.setdefault(
                run["problem"], )
            base["runs"].update(run["runs"])
            base["errors"].update(run["errors"])
            base["skipped"] = sorted(set(base["skipped"]) | set(run["skipped"]))
    return list(merged.values())


def x_load_runs__mutmut_17(*folders: Path) -> list[dict[str, Any]]:
    """The problem files of the one-pass runs, the classical and the neural folders together."""
    merged: dict[str, dict[str, Any]] = {}
    for folder in folders:
        for path in sorted(folder.glob("*.json")):
            run = json.loads(path.read_text())
            if "failed" in run:
                continue
            base = merged.setdefault(
                run["XXproblemXX"], {**run, "runs": {}, "errors": {}, "skipped": []}
            )
            base["runs"].update(run["runs"])
            base["errors"].update(run["errors"])
            base["skipped"] = sorted(set(base["skipped"]) | set(run["skipped"]))
    return list(merged.values())


def x_load_runs__mutmut_18(*folders: Path) -> list[dict[str, Any]]:
    """The problem files of the one-pass runs, the classical and the neural folders together."""
    merged: dict[str, dict[str, Any]] = {}
    for folder in folders:
        for path in sorted(folder.glob("*.json")):
            run = json.loads(path.read_text())
            if "failed" in run:
                continue
            base = merged.setdefault(
                run["PROBLEM"], {**run, "runs": {}, "errors": {}, "skipped": []}
            )
            base["runs"].update(run["runs"])
            base["errors"].update(run["errors"])
            base["skipped"] = sorted(set(base["skipped"]) | set(run["skipped"]))
    return list(merged.values())


def x_load_runs__mutmut_19(*folders: Path) -> list[dict[str, Any]]:
    """The problem files of the one-pass runs, the classical and the neural folders together."""
    merged: dict[str, dict[str, Any]] = {}
    for folder in folders:
        for path in sorted(folder.glob("*.json")):
            run = json.loads(path.read_text())
            if "failed" in run:
                continue
            base = merged.setdefault(
                run["problem"], {**run, "XXrunsXX": {}, "errors": {}, "skipped": []}
            )
            base["runs"].update(run["runs"])
            base["errors"].update(run["errors"])
            base["skipped"] = sorted(set(base["skipped"]) | set(run["skipped"]))
    return list(merged.values())


def x_load_runs__mutmut_20(*folders: Path) -> list[dict[str, Any]]:
    """The problem files of the one-pass runs, the classical and the neural folders together."""
    merged: dict[str, dict[str, Any]] = {}
    for folder in folders:
        for path in sorted(folder.glob("*.json")):
            run = json.loads(path.read_text())
            if "failed" in run:
                continue
            base = merged.setdefault(
                run["problem"], {**run, "RUNS": {}, "errors": {}, "skipped": []}
            )
            base["runs"].update(run["runs"])
            base["errors"].update(run["errors"])
            base["skipped"] = sorted(set(base["skipped"]) | set(run["skipped"]))
    return list(merged.values())


def x_load_runs__mutmut_21(*folders: Path) -> list[dict[str, Any]]:
    """The problem files of the one-pass runs, the classical and the neural folders together."""
    merged: dict[str, dict[str, Any]] = {}
    for folder in folders:
        for path in sorted(folder.glob("*.json")):
            run = json.loads(path.read_text())
            if "failed" in run:
                continue
            base = merged.setdefault(
                run["problem"], {**run, "runs": {}, "XXerrorsXX": {}, "skipped": []}
            )
            base["runs"].update(run["runs"])
            base["errors"].update(run["errors"])
            base["skipped"] = sorted(set(base["skipped"]) | set(run["skipped"]))
    return list(merged.values())


def x_load_runs__mutmut_22(*folders: Path) -> list[dict[str, Any]]:
    """The problem files of the one-pass runs, the classical and the neural folders together."""
    merged: dict[str, dict[str, Any]] = {}
    for folder in folders:
        for path in sorted(folder.glob("*.json")):
            run = json.loads(path.read_text())
            if "failed" in run:
                continue
            base = merged.setdefault(
                run["problem"], {**run, "runs": {}, "ERRORS": {}, "skipped": []}
            )
            base["runs"].update(run["runs"])
            base["errors"].update(run["errors"])
            base["skipped"] = sorted(set(base["skipped"]) | set(run["skipped"]))
    return list(merged.values())


def x_load_runs__mutmut_23(*folders: Path) -> list[dict[str, Any]]:
    """The problem files of the one-pass runs, the classical and the neural folders together."""
    merged: dict[str, dict[str, Any]] = {}
    for folder in folders:
        for path in sorted(folder.glob("*.json")):
            run = json.loads(path.read_text())
            if "failed" in run:
                continue
            base = merged.setdefault(
                run["problem"], {**run, "runs": {}, "errors": {}, "XXskippedXX": []}
            )
            base["runs"].update(run["runs"])
            base["errors"].update(run["errors"])
            base["skipped"] = sorted(set(base["skipped"]) | set(run["skipped"]))
    return list(merged.values())


def x_load_runs__mutmut_24(*folders: Path) -> list[dict[str, Any]]:
    """The problem files of the one-pass runs, the classical and the neural folders together."""
    merged: dict[str, dict[str, Any]] = {}
    for folder in folders:
        for path in sorted(folder.glob("*.json")):
            run = json.loads(path.read_text())
            if "failed" in run:
                continue
            base = merged.setdefault(
                run["problem"], {**run, "runs": {}, "errors": {}, "SKIPPED": []}
            )
            base["runs"].update(run["runs"])
            base["errors"].update(run["errors"])
            base["skipped"] = sorted(set(base["skipped"]) | set(run["skipped"]))
    return list(merged.values())


def x_load_runs__mutmut_25(*folders: Path) -> list[dict[str, Any]]:
    """The problem files of the one-pass runs, the classical and the neural folders together."""
    merged: dict[str, dict[str, Any]] = {}
    for folder in folders:
        for path in sorted(folder.glob("*.json")):
            run = json.loads(path.read_text())
            if "failed" in run:
                continue
            base = merged.setdefault(
                run["problem"], {**run, "runs": {}, "errors": {}, "skipped": []}
            )
            base["runs"].update(None)
            base["errors"].update(run["errors"])
            base["skipped"] = sorted(set(base["skipped"]) | set(run["skipped"]))
    return list(merged.values())


def x_load_runs__mutmut_26(*folders: Path) -> list[dict[str, Any]]:
    """The problem files of the one-pass runs, the classical and the neural folders together."""
    merged: dict[str, dict[str, Any]] = {}
    for folder in folders:
        for path in sorted(folder.glob("*.json")):
            run = json.loads(path.read_text())
            if "failed" in run:
                continue
            base = merged.setdefault(
                run["problem"], {**run, "runs": {}, "errors": {}, "skipped": []}
            )
            base["XXrunsXX"].update(run["runs"])
            base["errors"].update(run["errors"])
            base["skipped"] = sorted(set(base["skipped"]) | set(run["skipped"]))
    return list(merged.values())


def x_load_runs__mutmut_27(*folders: Path) -> list[dict[str, Any]]:
    """The problem files of the one-pass runs, the classical and the neural folders together."""
    merged: dict[str, dict[str, Any]] = {}
    for folder in folders:
        for path in sorted(folder.glob("*.json")):
            run = json.loads(path.read_text())
            if "failed" in run:
                continue
            base = merged.setdefault(
                run["problem"], {**run, "runs": {}, "errors": {}, "skipped": []}
            )
            base["RUNS"].update(run["runs"])
            base["errors"].update(run["errors"])
            base["skipped"] = sorted(set(base["skipped"]) | set(run["skipped"]))
    return list(merged.values())


def x_load_runs__mutmut_28(*folders: Path) -> list[dict[str, Any]]:
    """The problem files of the one-pass runs, the classical and the neural folders together."""
    merged: dict[str, dict[str, Any]] = {}
    for folder in folders:
        for path in sorted(folder.glob("*.json")):
            run = json.loads(path.read_text())
            if "failed" in run:
                continue
            base = merged.setdefault(
                run["problem"], {**run, "runs": {}, "errors": {}, "skipped": []}
            )
            base["runs"].update(run["XXrunsXX"])
            base["errors"].update(run["errors"])
            base["skipped"] = sorted(set(base["skipped"]) | set(run["skipped"]))
    return list(merged.values())


def x_load_runs__mutmut_29(*folders: Path) -> list[dict[str, Any]]:
    """The problem files of the one-pass runs, the classical and the neural folders together."""
    merged: dict[str, dict[str, Any]] = {}
    for folder in folders:
        for path in sorted(folder.glob("*.json")):
            run = json.loads(path.read_text())
            if "failed" in run:
                continue
            base = merged.setdefault(
                run["problem"], {**run, "runs": {}, "errors": {}, "skipped": []}
            )
            base["runs"].update(run["RUNS"])
            base["errors"].update(run["errors"])
            base["skipped"] = sorted(set(base["skipped"]) | set(run["skipped"]))
    return list(merged.values())


def x_load_runs__mutmut_30(*folders: Path) -> list[dict[str, Any]]:
    """The problem files of the one-pass runs, the classical and the neural folders together."""
    merged: dict[str, dict[str, Any]] = {}
    for folder in folders:
        for path in sorted(folder.glob("*.json")):
            run = json.loads(path.read_text())
            if "failed" in run:
                continue
            base = merged.setdefault(
                run["problem"], {**run, "runs": {}, "errors": {}, "skipped": []}
            )
            base["runs"].update(run["runs"])
            base["errors"].update(None)
            base["skipped"] = sorted(set(base["skipped"]) | set(run["skipped"]))
    return list(merged.values())


def x_load_runs__mutmut_31(*folders: Path) -> list[dict[str, Any]]:
    """The problem files of the one-pass runs, the classical and the neural folders together."""
    merged: dict[str, dict[str, Any]] = {}
    for folder in folders:
        for path in sorted(folder.glob("*.json")):
            run = json.loads(path.read_text())
            if "failed" in run:
                continue
            base = merged.setdefault(
                run["problem"], {**run, "runs": {}, "errors": {}, "skipped": []}
            )
            base["runs"].update(run["runs"])
            base["XXerrorsXX"].update(run["errors"])
            base["skipped"] = sorted(set(base["skipped"]) | set(run["skipped"]))
    return list(merged.values())


def x_load_runs__mutmut_32(*folders: Path) -> list[dict[str, Any]]:
    """The problem files of the one-pass runs, the classical and the neural folders together."""
    merged: dict[str, dict[str, Any]] = {}
    for folder in folders:
        for path in sorted(folder.glob("*.json")):
            run = json.loads(path.read_text())
            if "failed" in run:
                continue
            base = merged.setdefault(
                run["problem"], {**run, "runs": {}, "errors": {}, "skipped": []}
            )
            base["runs"].update(run["runs"])
            base["ERRORS"].update(run["errors"])
            base["skipped"] = sorted(set(base["skipped"]) | set(run["skipped"]))
    return list(merged.values())


def x_load_runs__mutmut_33(*folders: Path) -> list[dict[str, Any]]:
    """The problem files of the one-pass runs, the classical and the neural folders together."""
    merged: dict[str, dict[str, Any]] = {}
    for folder in folders:
        for path in sorted(folder.glob("*.json")):
            run = json.loads(path.read_text())
            if "failed" in run:
                continue
            base = merged.setdefault(
                run["problem"], {**run, "runs": {}, "errors": {}, "skipped": []}
            )
            base["runs"].update(run["runs"])
            base["errors"].update(run["XXerrorsXX"])
            base["skipped"] = sorted(set(base["skipped"]) | set(run["skipped"]))
    return list(merged.values())


def x_load_runs__mutmut_34(*folders: Path) -> list[dict[str, Any]]:
    """The problem files of the one-pass runs, the classical and the neural folders together."""
    merged: dict[str, dict[str, Any]] = {}
    for folder in folders:
        for path in sorted(folder.glob("*.json")):
            run = json.loads(path.read_text())
            if "failed" in run:
                continue
            base = merged.setdefault(
                run["problem"], {**run, "runs": {}, "errors": {}, "skipped": []}
            )
            base["runs"].update(run["runs"])
            base["errors"].update(run["ERRORS"])
            base["skipped"] = sorted(set(base["skipped"]) | set(run["skipped"]))
    return list(merged.values())


def x_load_runs__mutmut_35(*folders: Path) -> list[dict[str, Any]]:
    """The problem files of the one-pass runs, the classical and the neural folders together."""
    merged: dict[str, dict[str, Any]] = {}
    for folder in folders:
        for path in sorted(folder.glob("*.json")):
            run = json.loads(path.read_text())
            if "failed" in run:
                continue
            base = merged.setdefault(
                run["problem"], {**run, "runs": {}, "errors": {}, "skipped": []}
            )
            base["runs"].update(run["runs"])
            base["errors"].update(run["errors"])
            base["skipped"] = None
    return list(merged.values())


def x_load_runs__mutmut_36(*folders: Path) -> list[dict[str, Any]]:
    """The problem files of the one-pass runs, the classical and the neural folders together."""
    merged: dict[str, dict[str, Any]] = {}
    for folder in folders:
        for path in sorted(folder.glob("*.json")):
            run = json.loads(path.read_text())
            if "failed" in run:
                continue
            base = merged.setdefault(
                run["problem"], {**run, "runs": {}, "errors": {}, "skipped": []}
            )
            base["runs"].update(run["runs"])
            base["errors"].update(run["errors"])
            base["XXskippedXX"] = sorted(set(base["skipped"]) | set(run["skipped"]))
    return list(merged.values())


def x_load_runs__mutmut_37(*folders: Path) -> list[dict[str, Any]]:
    """The problem files of the one-pass runs, the classical and the neural folders together."""
    merged: dict[str, dict[str, Any]] = {}
    for folder in folders:
        for path in sorted(folder.glob("*.json")):
            run = json.loads(path.read_text())
            if "failed" in run:
                continue
            base = merged.setdefault(
                run["problem"], {**run, "runs": {}, "errors": {}, "skipped": []}
            )
            base["runs"].update(run["runs"])
            base["errors"].update(run["errors"])
            base["SKIPPED"] = sorted(set(base["skipped"]) | set(run["skipped"]))
    return list(merged.values())


def x_load_runs__mutmut_38(*folders: Path) -> list[dict[str, Any]]:
    """The problem files of the one-pass runs, the classical and the neural folders together."""
    merged: dict[str, dict[str, Any]] = {}
    for folder in folders:
        for path in sorted(folder.glob("*.json")):
            run = json.loads(path.read_text())
            if "failed" in run:
                continue
            base = merged.setdefault(
                run["problem"], {**run, "runs": {}, "errors": {}, "skipped": []}
            )
            base["runs"].update(run["runs"])
            base["errors"].update(run["errors"])
            base["skipped"] = sorted(None)
    return list(merged.values())


def x_load_runs__mutmut_39(*folders: Path) -> list[dict[str, Any]]:
    """The problem files of the one-pass runs, the classical and the neural folders together."""
    merged: dict[str, dict[str, Any]] = {}
    for folder in folders:
        for path in sorted(folder.glob("*.json")):
            run = json.loads(path.read_text())
            if "failed" in run:
                continue
            base = merged.setdefault(
                run["problem"], {**run, "runs": {}, "errors": {}, "skipped": []}
            )
            base["runs"].update(run["runs"])
            base["errors"].update(run["errors"])
            base["skipped"] = sorted(set(base["skipped"]) & set(run["skipped"]))
    return list(merged.values())


def x_load_runs__mutmut_40(*folders: Path) -> list[dict[str, Any]]:
    """The problem files of the one-pass runs, the classical and the neural folders together."""
    merged: dict[str, dict[str, Any]] = {}
    for folder in folders:
        for path in sorted(folder.glob("*.json")):
            run = json.loads(path.read_text())
            if "failed" in run:
                continue
            base = merged.setdefault(
                run["problem"], {**run, "runs": {}, "errors": {}, "skipped": []}
            )
            base["runs"].update(run["runs"])
            base["errors"].update(run["errors"])
            base["skipped"] = sorted(set(None) | set(run["skipped"]))
    return list(merged.values())


def x_load_runs__mutmut_41(*folders: Path) -> list[dict[str, Any]]:
    """The problem files of the one-pass runs, the classical and the neural folders together."""
    merged: dict[str, dict[str, Any]] = {}
    for folder in folders:
        for path in sorted(folder.glob("*.json")):
            run = json.loads(path.read_text())
            if "failed" in run:
                continue
            base = merged.setdefault(
                run["problem"], {**run, "runs": {}, "errors": {}, "skipped": []}
            )
            base["runs"].update(run["runs"])
            base["errors"].update(run["errors"])
            base["skipped"] = sorted(set(base["XXskippedXX"]) | set(run["skipped"]))
    return list(merged.values())


def x_load_runs__mutmut_42(*folders: Path) -> list[dict[str, Any]]:
    """The problem files of the one-pass runs, the classical and the neural folders together."""
    merged: dict[str, dict[str, Any]] = {}
    for folder in folders:
        for path in sorted(folder.glob("*.json")):
            run = json.loads(path.read_text())
            if "failed" in run:
                continue
            base = merged.setdefault(
                run["problem"], {**run, "runs": {}, "errors": {}, "skipped": []}
            )
            base["runs"].update(run["runs"])
            base["errors"].update(run["errors"])
            base["skipped"] = sorted(set(base["SKIPPED"]) | set(run["skipped"]))
    return list(merged.values())


def x_load_runs__mutmut_43(*folders: Path) -> list[dict[str, Any]]:
    """The problem files of the one-pass runs, the classical and the neural folders together."""
    merged: dict[str, dict[str, Any]] = {}
    for folder in folders:
        for path in sorted(folder.glob("*.json")):
            run = json.loads(path.read_text())
            if "failed" in run:
                continue
            base = merged.setdefault(
                run["problem"], {**run, "runs": {}, "errors": {}, "skipped": []}
            )
            base["runs"].update(run["runs"])
            base["errors"].update(run["errors"])
            base["skipped"] = sorted(set(base["skipped"]) | set(None))
    return list(merged.values())


def x_load_runs__mutmut_44(*folders: Path) -> list[dict[str, Any]]:
    """The problem files of the one-pass runs, the classical and the neural folders together."""
    merged: dict[str, dict[str, Any]] = {}
    for folder in folders:
        for path in sorted(folder.glob("*.json")):
            run = json.loads(path.read_text())
            if "failed" in run:
                continue
            base = merged.setdefault(
                run["problem"], {**run, "runs": {}, "errors": {}, "skipped": []}
            )
            base["runs"].update(run["runs"])
            base["errors"].update(run["errors"])
            base["skipped"] = sorted(set(base["skipped"]) | set(run["XXskippedXX"]))
    return list(merged.values())


def x_load_runs__mutmut_45(*folders: Path) -> list[dict[str, Any]]:
    """The problem files of the one-pass runs, the classical and the neural folders together."""
    merged: dict[str, dict[str, Any]] = {}
    for folder in folders:
        for path in sorted(folder.glob("*.json")):
            run = json.loads(path.read_text())
            if "failed" in run:
                continue
            base = merged.setdefault(
                run["problem"], {**run, "runs": {}, "errors": {}, "skipped": []}
            )
            base["runs"].update(run["runs"])
            base["errors"].update(run["errors"])
            base["skipped"] = sorted(set(base["skipped"]) | set(run["SKIPPED"]))
    return list(merged.values())


def x_load_runs__mutmut_46(*folders: Path) -> list[dict[str, Any]]:
    """The problem files of the one-pass runs, the classical and the neural folders together."""
    merged: dict[str, dict[str, Any]] = {}
    for folder in folders:
        for path in sorted(folder.glob("*.json")):
            run = json.loads(path.read_text())
            if "failed" in run:
                continue
            base = merged.setdefault(
                run["problem"], {**run, "runs": {}, "errors": {}, "skipped": []}
            )
            base["runs"].update(run["runs"])
            base["errors"].update(run["errors"])
            base["skipped"] = sorted(set(base["skipped"]) | set(run["skipped"]))
    return list(None)

mutants_x_load_runs__mutmut['_mutmut_orig'] = x_load_runs__mutmut_orig # type: ignore # mutmut generated
mutants_x_load_runs__mutmut['x_load_runs__mutmut_1'] = x_load_runs__mutmut_1 # type: ignore # mutmut generated
mutants_x_load_runs__mutmut['x_load_runs__mutmut_2'] = x_load_runs__mutmut_2 # type: ignore # mutmut generated
mutants_x_load_runs__mutmut['x_load_runs__mutmut_3'] = x_load_runs__mutmut_3 # type: ignore # mutmut generated
mutants_x_load_runs__mutmut['x_load_runs__mutmut_4'] = x_load_runs__mutmut_4 # type: ignore # mutmut generated
mutants_x_load_runs__mutmut['x_load_runs__mutmut_5'] = x_load_runs__mutmut_5 # type: ignore # mutmut generated
mutants_x_load_runs__mutmut['x_load_runs__mutmut_6'] = x_load_runs__mutmut_6 # type: ignore # mutmut generated
mutants_x_load_runs__mutmut['x_load_runs__mutmut_7'] = x_load_runs__mutmut_7 # type: ignore # mutmut generated
mutants_x_load_runs__mutmut['x_load_runs__mutmut_8'] = x_load_runs__mutmut_8 # type: ignore # mutmut generated
mutants_x_load_runs__mutmut['x_load_runs__mutmut_9'] = x_load_runs__mutmut_9 # type: ignore # mutmut generated
mutants_x_load_runs__mutmut['x_load_runs__mutmut_10'] = x_load_runs__mutmut_10 # type: ignore # mutmut generated
mutants_x_load_runs__mutmut['x_load_runs__mutmut_11'] = x_load_runs__mutmut_11 # type: ignore # mutmut generated
mutants_x_load_runs__mutmut['x_load_runs__mutmut_12'] = x_load_runs__mutmut_12 # type: ignore # mutmut generated
mutants_x_load_runs__mutmut['x_load_runs__mutmut_13'] = x_load_runs__mutmut_13 # type: ignore # mutmut generated
mutants_x_load_runs__mutmut['x_load_runs__mutmut_14'] = x_load_runs__mutmut_14 # type: ignore # mutmut generated
mutants_x_load_runs__mutmut['x_load_runs__mutmut_15'] = x_load_runs__mutmut_15 # type: ignore # mutmut generated
mutants_x_load_runs__mutmut['x_load_runs__mutmut_16'] = x_load_runs__mutmut_16 # type: ignore # mutmut generated
mutants_x_load_runs__mutmut['x_load_runs__mutmut_17'] = x_load_runs__mutmut_17 # type: ignore # mutmut generated
mutants_x_load_runs__mutmut['x_load_runs__mutmut_18'] = x_load_runs__mutmut_18 # type: ignore # mutmut generated
mutants_x_load_runs__mutmut['x_load_runs__mutmut_19'] = x_load_runs__mutmut_19 # type: ignore # mutmut generated
mutants_x_load_runs__mutmut['x_load_runs__mutmut_20'] = x_load_runs__mutmut_20 # type: ignore # mutmut generated
mutants_x_load_runs__mutmut['x_load_runs__mutmut_21'] = x_load_runs__mutmut_21 # type: ignore # mutmut generated
mutants_x_load_runs__mutmut['x_load_runs__mutmut_22'] = x_load_runs__mutmut_22 # type: ignore # mutmut generated
mutants_x_load_runs__mutmut['x_load_runs__mutmut_23'] = x_load_runs__mutmut_23 # type: ignore # mutmut generated
mutants_x_load_runs__mutmut['x_load_runs__mutmut_24'] = x_load_runs__mutmut_24 # type: ignore # mutmut generated
mutants_x_load_runs__mutmut['x_load_runs__mutmut_25'] = x_load_runs__mutmut_25 # type: ignore # mutmut generated
mutants_x_load_runs__mutmut['x_load_runs__mutmut_26'] = x_load_runs__mutmut_26 # type: ignore # mutmut generated
mutants_x_load_runs__mutmut['x_load_runs__mutmut_27'] = x_load_runs__mutmut_27 # type: ignore # mutmut generated
mutants_x_load_runs__mutmut['x_load_runs__mutmut_28'] = x_load_runs__mutmut_28 # type: ignore # mutmut generated
mutants_x_load_runs__mutmut['x_load_runs__mutmut_29'] = x_load_runs__mutmut_29 # type: ignore # mutmut generated
mutants_x_load_runs__mutmut['x_load_runs__mutmut_30'] = x_load_runs__mutmut_30 # type: ignore # mutmut generated
mutants_x_load_runs__mutmut['x_load_runs__mutmut_31'] = x_load_runs__mutmut_31 # type: ignore # mutmut generated
mutants_x_load_runs__mutmut['x_load_runs__mutmut_32'] = x_load_runs__mutmut_32 # type: ignore # mutmut generated
mutants_x_load_runs__mutmut['x_load_runs__mutmut_33'] = x_load_runs__mutmut_33 # type: ignore # mutmut generated
mutants_x_load_runs__mutmut['x_load_runs__mutmut_34'] = x_load_runs__mutmut_34 # type: ignore # mutmut generated
mutants_x_load_runs__mutmut['x_load_runs__mutmut_35'] = x_load_runs__mutmut_35 # type: ignore # mutmut generated
mutants_x_load_runs__mutmut['x_load_runs__mutmut_36'] = x_load_runs__mutmut_36 # type: ignore # mutmut generated
mutants_x_load_runs__mutmut['x_load_runs__mutmut_37'] = x_load_runs__mutmut_37 # type: ignore # mutmut generated
mutants_x_load_runs__mutmut['x_load_runs__mutmut_38'] = x_load_runs__mutmut_38 # type: ignore # mutmut generated
mutants_x_load_runs__mutmut['x_load_runs__mutmut_39'] = x_load_runs__mutmut_39 # type: ignore # mutmut generated
mutants_x_load_runs__mutmut['x_load_runs__mutmut_40'] = x_load_runs__mutmut_40 # type: ignore # mutmut generated
mutants_x_load_runs__mutmut['x_load_runs__mutmut_41'] = x_load_runs__mutmut_41 # type: ignore # mutmut generated
mutants_x_load_runs__mutmut['x_load_runs__mutmut_42'] = x_load_runs__mutmut_42 # type: ignore # mutmut generated
mutants_x_load_runs__mutmut['x_load_runs__mutmut_43'] = x_load_runs__mutmut_43 # type: ignore # mutmut generated
mutants_x_load_runs__mutmut['x_load_runs__mutmut_44'] = x_load_runs__mutmut_44 # type: ignore # mutmut generated
mutants_x_load_runs__mutmut['x_load_runs__mutmut_45'] = x_load_runs__mutmut_45 # type: ignore # mutmut generated
mutants_x_load_runs__mutmut['x_load_runs__mutmut_46'] = x_load_runs__mutmut_46 # type: ignore # mutmut generated
mutants_x_per_problem__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_per_problem__mutmut)
def per_problem(runs: list[dict[str, Any]], key: str, metric: str) -> pd.DataFrame:
    """Seed-mean of ``metric`` of the table ``key`` ("metrics" or "fixed"): problems by methods."""
    rows = {}
    for run in runs:
        rows[run["problem"]] = {
            method: float(np.mean([r[key][metric] for r in seeds]))
            for method, seeds in run["runs"].items()
        }
    return pd.DataFrame(rows).T


def x_per_problem__mutmut_orig(runs: list[dict[str, Any]], key: str, metric: str) -> pd.DataFrame:
    """Seed-mean of ``metric`` of the table ``key`` ("metrics" or "fixed"): problems by methods."""
    rows = {}
    for run in runs:
        rows[run["problem"]] = {
            method: float(np.mean([r[key][metric] for r in seeds]))
            for method, seeds in run["runs"].items()
        }
    return pd.DataFrame(rows).T


def x_per_problem__mutmut_1(runs: list[dict[str, Any]], key: str, metric: str) -> pd.DataFrame:
    """Seed-mean of ``metric`` of the table ``key`` ("metrics" or "fixed"): problems by methods."""
    rows = None
    for run in runs:
        rows[run["problem"]] = {
            method: float(np.mean([r[key][metric] for r in seeds]))
            for method, seeds in run["runs"].items()
        }
    return pd.DataFrame(rows).T


def x_per_problem__mutmut_2(runs: list[dict[str, Any]], key: str, metric: str) -> pd.DataFrame:
    """Seed-mean of ``metric`` of the table ``key`` ("metrics" or "fixed"): problems by methods."""
    rows = {}
    for run in runs:
        rows[run["problem"]] = None
    return pd.DataFrame(rows).T


def x_per_problem__mutmut_3(runs: list[dict[str, Any]], key: str, metric: str) -> pd.DataFrame:
    """Seed-mean of ``metric`` of the table ``key`` ("metrics" or "fixed"): problems by methods."""
    rows = {}
    for run in runs:
        rows[run["XXproblemXX"]] = {
            method: float(np.mean([r[key][metric] for r in seeds]))
            for method, seeds in run["runs"].items()
        }
    return pd.DataFrame(rows).T


def x_per_problem__mutmut_4(runs: list[dict[str, Any]], key: str, metric: str) -> pd.DataFrame:
    """Seed-mean of ``metric`` of the table ``key`` ("metrics" or "fixed"): problems by methods."""
    rows = {}
    for run in runs:
        rows[run["PROBLEM"]] = {
            method: float(np.mean([r[key][metric] for r in seeds]))
            for method, seeds in run["runs"].items()
        }
    return pd.DataFrame(rows).T


def x_per_problem__mutmut_5(runs: list[dict[str, Any]], key: str, metric: str) -> pd.DataFrame:
    """Seed-mean of ``metric`` of the table ``key`` ("metrics" or "fixed"): problems by methods."""
    rows = {}
    for run in runs:
        rows[run["problem"]] = {
            method: float(None)
            for method, seeds in run["runs"].items()
        }
    return pd.DataFrame(rows).T


def x_per_problem__mutmut_6(runs: list[dict[str, Any]], key: str, metric: str) -> pd.DataFrame:
    """Seed-mean of ``metric`` of the table ``key`` ("metrics" or "fixed"): problems by methods."""
    rows = {}
    for run in runs:
        rows[run["problem"]] = {
            method: float(np.mean(None))
            for method, seeds in run["runs"].items()
        }
    return pd.DataFrame(rows).T


def x_per_problem__mutmut_7(runs: list[dict[str, Any]], key: str, metric: str) -> pd.DataFrame:
    """Seed-mean of ``metric`` of the table ``key`` ("metrics" or "fixed"): problems by methods."""
    rows = {}
    for run in runs:
        rows[run["problem"]] = {
            method: float(np.mean([r[key][metric] for r in seeds]))
            for method, seeds in run["XXrunsXX"].items()
        }
    return pd.DataFrame(rows).T


def x_per_problem__mutmut_8(runs: list[dict[str, Any]], key: str, metric: str) -> pd.DataFrame:
    """Seed-mean of ``metric`` of the table ``key`` ("metrics" or "fixed"): problems by methods."""
    rows = {}
    for run in runs:
        rows[run["problem"]] = {
            method: float(np.mean([r[key][metric] for r in seeds]))
            for method, seeds in run["RUNS"].items()
        }
    return pd.DataFrame(rows).T


def x_per_problem__mutmut_9(runs: list[dict[str, Any]], key: str, metric: str) -> pd.DataFrame:
    """Seed-mean of ``metric`` of the table ``key`` ("metrics" or "fixed"): problems by methods."""
    rows = {}
    for run in runs:
        rows[run["problem"]] = {
            method: float(np.mean([r[key][metric] for r in seeds]))
            for method, seeds in run["runs"].items()
        }
    return pd.DataFrame(None).T

mutants_x_per_problem__mutmut['_mutmut_orig'] = x_per_problem__mutmut_orig # type: ignore # mutmut generated
mutants_x_per_problem__mutmut['x_per_problem__mutmut_1'] = x_per_problem__mutmut_1 # type: ignore # mutmut generated
mutants_x_per_problem__mutmut['x_per_problem__mutmut_2'] = x_per_problem__mutmut_2 # type: ignore # mutmut generated
mutants_x_per_problem__mutmut['x_per_problem__mutmut_3'] = x_per_problem__mutmut_3 # type: ignore # mutmut generated
mutants_x_per_problem__mutmut['x_per_problem__mutmut_4'] = x_per_problem__mutmut_4 # type: ignore # mutmut generated
mutants_x_per_problem__mutmut['x_per_problem__mutmut_5'] = x_per_problem__mutmut_5 # type: ignore # mutmut generated
mutants_x_per_problem__mutmut['x_per_problem__mutmut_6'] = x_per_problem__mutmut_6 # type: ignore # mutmut generated
mutants_x_per_problem__mutmut['x_per_problem__mutmut_7'] = x_per_problem__mutmut_7 # type: ignore # mutmut generated
mutants_x_per_problem__mutmut['x_per_problem__mutmut_8'] = x_per_problem__mutmut_8 # type: ignore # mutmut generated
mutants_x_per_problem__mutmut['x_per_problem__mutmut_9'] = x_per_problem__mutmut_9 # type: ignore # mutmut generated
mutants_x_fixed_threshold__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_fixed_threshold__mutmut)
def fixed_threshold(runs: list[dict[str, Any]]) -> dict[str, Any]:
    """P1: the median F1 of each detector at the label-free threshold against the prevalence one."""
    table = {}
    for method in sorted({m for r in runs for m in r["runs"]}):
        entry = {}
        for metric in METRICS:
            prev = per_problem(runs, "metrics", metric)[method].dropna()
            fixed = per_problem(runs, "fixed", metric)[method].dropna()
            entry[metric] = {"prevalence": float(prev.median()), "fixed": float(fixed.median())}
        table[method] = entry
    lower = [m for m, e in table.items() if e["f1"]["fixed"] < e["f1"]["prevalence"]]
    return {
        "supported": bool(len(lower) >= 12),
        "lower_at_fixed": len(lower),
        "detectors": len(table),
        "by_detector": table,
    }


def x_fixed_threshold__mutmut_orig(runs: list[dict[str, Any]]) -> dict[str, Any]:
    """P1: the median F1 of each detector at the label-free threshold against the prevalence one."""
    table = {}
    for method in sorted({m for r in runs for m in r["runs"]}):
        entry = {}
        for metric in METRICS:
            prev = per_problem(runs, "metrics", metric)[method].dropna()
            fixed = per_problem(runs, "fixed", metric)[method].dropna()
            entry[metric] = {"prevalence": float(prev.median()), "fixed": float(fixed.median())}
        table[method] = entry
    lower = [m for m, e in table.items() if e["f1"]["fixed"] < e["f1"]["prevalence"]]
    return {
        "supported": bool(len(lower) >= 12),
        "lower_at_fixed": len(lower),
        "detectors": len(table),
        "by_detector": table,
    }


def x_fixed_threshold__mutmut_1(runs: list[dict[str, Any]]) -> dict[str, Any]:
    """P1: the median F1 of each detector at the label-free threshold against the prevalence one."""
    table = None
    for method in sorted({m for r in runs for m in r["runs"]}):
        entry = {}
        for metric in METRICS:
            prev = per_problem(runs, "metrics", metric)[method].dropna()
            fixed = per_problem(runs, "fixed", metric)[method].dropna()
            entry[metric] = {"prevalence": float(prev.median()), "fixed": float(fixed.median())}
        table[method] = entry
    lower = [m for m, e in table.items() if e["f1"]["fixed"] < e["f1"]["prevalence"]]
    return {
        "supported": bool(len(lower) >= 12),
        "lower_at_fixed": len(lower),
        "detectors": len(table),
        "by_detector": table,
    }


def x_fixed_threshold__mutmut_2(runs: list[dict[str, Any]]) -> dict[str, Any]:
    """P1: the median F1 of each detector at the label-free threshold against the prevalence one."""
    table = {}
    for method in sorted(None):
        entry = {}
        for metric in METRICS:
            prev = per_problem(runs, "metrics", metric)[method].dropna()
            fixed = per_problem(runs, "fixed", metric)[method].dropna()
            entry[metric] = {"prevalence": float(prev.median()), "fixed": float(fixed.median())}
        table[method] = entry
    lower = [m for m, e in table.items() if e["f1"]["fixed"] < e["f1"]["prevalence"]]
    return {
        "supported": bool(len(lower) >= 12),
        "lower_at_fixed": len(lower),
        "detectors": len(table),
        "by_detector": table,
    }


def x_fixed_threshold__mutmut_3(runs: list[dict[str, Any]]) -> dict[str, Any]:
    """P1: the median F1 of each detector at the label-free threshold against the prevalence one."""
    table = {}
    for method in sorted({m for r in runs for m in r["XXrunsXX"]}):
        entry = {}
        for metric in METRICS:
            prev = per_problem(runs, "metrics", metric)[method].dropna()
            fixed = per_problem(runs, "fixed", metric)[method].dropna()
            entry[metric] = {"prevalence": float(prev.median()), "fixed": float(fixed.median())}
        table[method] = entry
    lower = [m for m, e in table.items() if e["f1"]["fixed"] < e["f1"]["prevalence"]]
    return {
        "supported": bool(len(lower) >= 12),
        "lower_at_fixed": len(lower),
        "detectors": len(table),
        "by_detector": table,
    }


def x_fixed_threshold__mutmut_4(runs: list[dict[str, Any]]) -> dict[str, Any]:
    """P1: the median F1 of each detector at the label-free threshold against the prevalence one."""
    table = {}
    for method in sorted({m for r in runs for m in r["RUNS"]}):
        entry = {}
        for metric in METRICS:
            prev = per_problem(runs, "metrics", metric)[method].dropna()
            fixed = per_problem(runs, "fixed", metric)[method].dropna()
            entry[metric] = {"prevalence": float(prev.median()), "fixed": float(fixed.median())}
        table[method] = entry
    lower = [m for m, e in table.items() if e["f1"]["fixed"] < e["f1"]["prevalence"]]
    return {
        "supported": bool(len(lower) >= 12),
        "lower_at_fixed": len(lower),
        "detectors": len(table),
        "by_detector": table,
    }


def x_fixed_threshold__mutmut_5(runs: list[dict[str, Any]]) -> dict[str, Any]:
    """P1: the median F1 of each detector at the label-free threshold against the prevalence one."""
    table = {}
    for method in sorted({m for r in runs for m in r["runs"]}):
        entry = None
        for metric in METRICS:
            prev = per_problem(runs, "metrics", metric)[method].dropna()
            fixed = per_problem(runs, "fixed", metric)[method].dropna()
            entry[metric] = {"prevalence": float(prev.median()), "fixed": float(fixed.median())}
        table[method] = entry
    lower = [m for m, e in table.items() if e["f1"]["fixed"] < e["f1"]["prevalence"]]
    return {
        "supported": bool(len(lower) >= 12),
        "lower_at_fixed": len(lower),
        "detectors": len(table),
        "by_detector": table,
    }


def x_fixed_threshold__mutmut_6(runs: list[dict[str, Any]]) -> dict[str, Any]:
    """P1: the median F1 of each detector at the label-free threshold against the prevalence one."""
    table = {}
    for method in sorted({m for r in runs for m in r["runs"]}):
        entry = {}
        for metric in METRICS:
            prev = None
            fixed = per_problem(runs, "fixed", metric)[method].dropna()
            entry[metric] = {"prevalence": float(prev.median()), "fixed": float(fixed.median())}
        table[method] = entry
    lower = [m for m, e in table.items() if e["f1"]["fixed"] < e["f1"]["prevalence"]]
    return {
        "supported": bool(len(lower) >= 12),
        "lower_at_fixed": len(lower),
        "detectors": len(table),
        "by_detector": table,
    }


def x_fixed_threshold__mutmut_7(runs: list[dict[str, Any]]) -> dict[str, Any]:
    """P1: the median F1 of each detector at the label-free threshold against the prevalence one."""
    table = {}
    for method in sorted({m for r in runs for m in r["runs"]}):
        entry = {}
        for metric in METRICS:
            prev = per_problem(None, "metrics", metric)[method].dropna()
            fixed = per_problem(runs, "fixed", metric)[method].dropna()
            entry[metric] = {"prevalence": float(prev.median()), "fixed": float(fixed.median())}
        table[method] = entry
    lower = [m for m, e in table.items() if e["f1"]["fixed"] < e["f1"]["prevalence"]]
    return {
        "supported": bool(len(lower) >= 12),
        "lower_at_fixed": len(lower),
        "detectors": len(table),
        "by_detector": table,
    }


def x_fixed_threshold__mutmut_8(runs: list[dict[str, Any]]) -> dict[str, Any]:
    """P1: the median F1 of each detector at the label-free threshold against the prevalence one."""
    table = {}
    for method in sorted({m for r in runs for m in r["runs"]}):
        entry = {}
        for metric in METRICS:
            prev = per_problem(runs, None, metric)[method].dropna()
            fixed = per_problem(runs, "fixed", metric)[method].dropna()
            entry[metric] = {"prevalence": float(prev.median()), "fixed": float(fixed.median())}
        table[method] = entry
    lower = [m for m, e in table.items() if e["f1"]["fixed"] < e["f1"]["prevalence"]]
    return {
        "supported": bool(len(lower) >= 12),
        "lower_at_fixed": len(lower),
        "detectors": len(table),
        "by_detector": table,
    }


def x_fixed_threshold__mutmut_9(runs: list[dict[str, Any]]) -> dict[str, Any]:
    """P1: the median F1 of each detector at the label-free threshold against the prevalence one."""
    table = {}
    for method in sorted({m for r in runs for m in r["runs"]}):
        entry = {}
        for metric in METRICS:
            prev = per_problem(runs, "metrics", None)[method].dropna()
            fixed = per_problem(runs, "fixed", metric)[method].dropna()
            entry[metric] = {"prevalence": float(prev.median()), "fixed": float(fixed.median())}
        table[method] = entry
    lower = [m for m, e in table.items() if e["f1"]["fixed"] < e["f1"]["prevalence"]]
    return {
        "supported": bool(len(lower) >= 12),
        "lower_at_fixed": len(lower),
        "detectors": len(table),
        "by_detector": table,
    }


def x_fixed_threshold__mutmut_10(runs: list[dict[str, Any]]) -> dict[str, Any]:
    """P1: the median F1 of each detector at the label-free threshold against the prevalence one."""
    table = {}
    for method in sorted({m for r in runs for m in r["runs"]}):
        entry = {}
        for metric in METRICS:
            prev = per_problem("metrics", metric)[method].dropna()
            fixed = per_problem(runs, "fixed", metric)[method].dropna()
            entry[metric] = {"prevalence": float(prev.median()), "fixed": float(fixed.median())}
        table[method] = entry
    lower = [m for m, e in table.items() if e["f1"]["fixed"] < e["f1"]["prevalence"]]
    return {
        "supported": bool(len(lower) >= 12),
        "lower_at_fixed": len(lower),
        "detectors": len(table),
        "by_detector": table,
    }


def x_fixed_threshold__mutmut_11(runs: list[dict[str, Any]]) -> dict[str, Any]:
    """P1: the median F1 of each detector at the label-free threshold against the prevalence one."""
    table = {}
    for method in sorted({m for r in runs for m in r["runs"]}):
        entry = {}
        for metric in METRICS:
            prev = per_problem(runs, metric)[method].dropna()
            fixed = per_problem(runs, "fixed", metric)[method].dropna()
            entry[metric] = {"prevalence": float(prev.median()), "fixed": float(fixed.median())}
        table[method] = entry
    lower = [m for m, e in table.items() if e["f1"]["fixed"] < e["f1"]["prevalence"]]
    return {
        "supported": bool(len(lower) >= 12),
        "lower_at_fixed": len(lower),
        "detectors": len(table),
        "by_detector": table,
    }


def x_fixed_threshold__mutmut_12(runs: list[dict[str, Any]]) -> dict[str, Any]:
    """P1: the median F1 of each detector at the label-free threshold against the prevalence one."""
    table = {}
    for method in sorted({m for r in runs for m in r["runs"]}):
        entry = {}
        for metric in METRICS:
            prev = per_problem(runs, "metrics", )[method].dropna()
            fixed = per_problem(runs, "fixed", metric)[method].dropna()
            entry[metric] = {"prevalence": float(prev.median()), "fixed": float(fixed.median())}
        table[method] = entry
    lower = [m for m, e in table.items() if e["f1"]["fixed"] < e["f1"]["prevalence"]]
    return {
        "supported": bool(len(lower) >= 12),
        "lower_at_fixed": len(lower),
        "detectors": len(table),
        "by_detector": table,
    }


def x_fixed_threshold__mutmut_13(runs: list[dict[str, Any]]) -> dict[str, Any]:
    """P1: the median F1 of each detector at the label-free threshold against the prevalence one."""
    table = {}
    for method in sorted({m for r in runs for m in r["runs"]}):
        entry = {}
        for metric in METRICS:
            prev = per_problem(runs, "XXmetricsXX", metric)[method].dropna()
            fixed = per_problem(runs, "fixed", metric)[method].dropna()
            entry[metric] = {"prevalence": float(prev.median()), "fixed": float(fixed.median())}
        table[method] = entry
    lower = [m for m, e in table.items() if e["f1"]["fixed"] < e["f1"]["prevalence"]]
    return {
        "supported": bool(len(lower) >= 12),
        "lower_at_fixed": len(lower),
        "detectors": len(table),
        "by_detector": table,
    }


def x_fixed_threshold__mutmut_14(runs: list[dict[str, Any]]) -> dict[str, Any]:
    """P1: the median F1 of each detector at the label-free threshold against the prevalence one."""
    table = {}
    for method in sorted({m for r in runs for m in r["runs"]}):
        entry = {}
        for metric in METRICS:
            prev = per_problem(runs, "METRICS", metric)[method].dropna()
            fixed = per_problem(runs, "fixed", metric)[method].dropna()
            entry[metric] = {"prevalence": float(prev.median()), "fixed": float(fixed.median())}
        table[method] = entry
    lower = [m for m, e in table.items() if e["f1"]["fixed"] < e["f1"]["prevalence"]]
    return {
        "supported": bool(len(lower) >= 12),
        "lower_at_fixed": len(lower),
        "detectors": len(table),
        "by_detector": table,
    }


def x_fixed_threshold__mutmut_15(runs: list[dict[str, Any]]) -> dict[str, Any]:
    """P1: the median F1 of each detector at the label-free threshold against the prevalence one."""
    table = {}
    for method in sorted({m for r in runs for m in r["runs"]}):
        entry = {}
        for metric in METRICS:
            prev = per_problem(runs, "metrics", metric)[method].dropna()
            fixed = None
            entry[metric] = {"prevalence": float(prev.median()), "fixed": float(fixed.median())}
        table[method] = entry
    lower = [m for m, e in table.items() if e["f1"]["fixed"] < e["f1"]["prevalence"]]
    return {
        "supported": bool(len(lower) >= 12),
        "lower_at_fixed": len(lower),
        "detectors": len(table),
        "by_detector": table,
    }


def x_fixed_threshold__mutmut_16(runs: list[dict[str, Any]]) -> dict[str, Any]:
    """P1: the median F1 of each detector at the label-free threshold against the prevalence one."""
    table = {}
    for method in sorted({m for r in runs for m in r["runs"]}):
        entry = {}
        for metric in METRICS:
            prev = per_problem(runs, "metrics", metric)[method].dropna()
            fixed = per_problem(None, "fixed", metric)[method].dropna()
            entry[metric] = {"prevalence": float(prev.median()), "fixed": float(fixed.median())}
        table[method] = entry
    lower = [m for m, e in table.items() if e["f1"]["fixed"] < e["f1"]["prevalence"]]
    return {
        "supported": bool(len(lower) >= 12),
        "lower_at_fixed": len(lower),
        "detectors": len(table),
        "by_detector": table,
    }


def x_fixed_threshold__mutmut_17(runs: list[dict[str, Any]]) -> dict[str, Any]:
    """P1: the median F1 of each detector at the label-free threshold against the prevalence one."""
    table = {}
    for method in sorted({m for r in runs for m in r["runs"]}):
        entry = {}
        for metric in METRICS:
            prev = per_problem(runs, "metrics", metric)[method].dropna()
            fixed = per_problem(runs, None, metric)[method].dropna()
            entry[metric] = {"prevalence": float(prev.median()), "fixed": float(fixed.median())}
        table[method] = entry
    lower = [m for m, e in table.items() if e["f1"]["fixed"] < e["f1"]["prevalence"]]
    return {
        "supported": bool(len(lower) >= 12),
        "lower_at_fixed": len(lower),
        "detectors": len(table),
        "by_detector": table,
    }


def x_fixed_threshold__mutmut_18(runs: list[dict[str, Any]]) -> dict[str, Any]:
    """P1: the median F1 of each detector at the label-free threshold against the prevalence one."""
    table = {}
    for method in sorted({m for r in runs for m in r["runs"]}):
        entry = {}
        for metric in METRICS:
            prev = per_problem(runs, "metrics", metric)[method].dropna()
            fixed = per_problem(runs, "fixed", None)[method].dropna()
            entry[metric] = {"prevalence": float(prev.median()), "fixed": float(fixed.median())}
        table[method] = entry
    lower = [m for m, e in table.items() if e["f1"]["fixed"] < e["f1"]["prevalence"]]
    return {
        "supported": bool(len(lower) >= 12),
        "lower_at_fixed": len(lower),
        "detectors": len(table),
        "by_detector": table,
    }


def x_fixed_threshold__mutmut_19(runs: list[dict[str, Any]]) -> dict[str, Any]:
    """P1: the median F1 of each detector at the label-free threshold against the prevalence one."""
    table = {}
    for method in sorted({m for r in runs for m in r["runs"]}):
        entry = {}
        for metric in METRICS:
            prev = per_problem(runs, "metrics", metric)[method].dropna()
            fixed = per_problem("fixed", metric)[method].dropna()
            entry[metric] = {"prevalence": float(prev.median()), "fixed": float(fixed.median())}
        table[method] = entry
    lower = [m for m, e in table.items() if e["f1"]["fixed"] < e["f1"]["prevalence"]]
    return {
        "supported": bool(len(lower) >= 12),
        "lower_at_fixed": len(lower),
        "detectors": len(table),
        "by_detector": table,
    }


def x_fixed_threshold__mutmut_20(runs: list[dict[str, Any]]) -> dict[str, Any]:
    """P1: the median F1 of each detector at the label-free threshold against the prevalence one."""
    table = {}
    for method in sorted({m for r in runs for m in r["runs"]}):
        entry = {}
        for metric in METRICS:
            prev = per_problem(runs, "metrics", metric)[method].dropna()
            fixed = per_problem(runs, metric)[method].dropna()
            entry[metric] = {"prevalence": float(prev.median()), "fixed": float(fixed.median())}
        table[method] = entry
    lower = [m for m, e in table.items() if e["f1"]["fixed"] < e["f1"]["prevalence"]]
    return {
        "supported": bool(len(lower) >= 12),
        "lower_at_fixed": len(lower),
        "detectors": len(table),
        "by_detector": table,
    }


def x_fixed_threshold__mutmut_21(runs: list[dict[str, Any]]) -> dict[str, Any]:
    """P1: the median F1 of each detector at the label-free threshold against the prevalence one."""
    table = {}
    for method in sorted({m for r in runs for m in r["runs"]}):
        entry = {}
        for metric in METRICS:
            prev = per_problem(runs, "metrics", metric)[method].dropna()
            fixed = per_problem(runs, "fixed", )[method].dropna()
            entry[metric] = {"prevalence": float(prev.median()), "fixed": float(fixed.median())}
        table[method] = entry
    lower = [m for m, e in table.items() if e["f1"]["fixed"] < e["f1"]["prevalence"]]
    return {
        "supported": bool(len(lower) >= 12),
        "lower_at_fixed": len(lower),
        "detectors": len(table),
        "by_detector": table,
    }


def x_fixed_threshold__mutmut_22(runs: list[dict[str, Any]]) -> dict[str, Any]:
    """P1: the median F1 of each detector at the label-free threshold against the prevalence one."""
    table = {}
    for method in sorted({m for r in runs for m in r["runs"]}):
        entry = {}
        for metric in METRICS:
            prev = per_problem(runs, "metrics", metric)[method].dropna()
            fixed = per_problem(runs, "XXfixedXX", metric)[method].dropna()
            entry[metric] = {"prevalence": float(prev.median()), "fixed": float(fixed.median())}
        table[method] = entry
    lower = [m for m, e in table.items() if e["f1"]["fixed"] < e["f1"]["prevalence"]]
    return {
        "supported": bool(len(lower) >= 12),
        "lower_at_fixed": len(lower),
        "detectors": len(table),
        "by_detector": table,
    }


def x_fixed_threshold__mutmut_23(runs: list[dict[str, Any]]) -> dict[str, Any]:
    """P1: the median F1 of each detector at the label-free threshold against the prevalence one."""
    table = {}
    for method in sorted({m for r in runs for m in r["runs"]}):
        entry = {}
        for metric in METRICS:
            prev = per_problem(runs, "metrics", metric)[method].dropna()
            fixed = per_problem(runs, "FIXED", metric)[method].dropna()
            entry[metric] = {"prevalence": float(prev.median()), "fixed": float(fixed.median())}
        table[method] = entry
    lower = [m for m, e in table.items() if e["f1"]["fixed"] < e["f1"]["prevalence"]]
    return {
        "supported": bool(len(lower) >= 12),
        "lower_at_fixed": len(lower),
        "detectors": len(table),
        "by_detector": table,
    }


def x_fixed_threshold__mutmut_24(runs: list[dict[str, Any]]) -> dict[str, Any]:
    """P1: the median F1 of each detector at the label-free threshold against the prevalence one."""
    table = {}
    for method in sorted({m for r in runs for m in r["runs"]}):
        entry = {}
        for metric in METRICS:
            prev = per_problem(runs, "metrics", metric)[method].dropna()
            fixed = per_problem(runs, "fixed", metric)[method].dropna()
            entry[metric] = None
        table[method] = entry
    lower = [m for m, e in table.items() if e["f1"]["fixed"] < e["f1"]["prevalence"]]
    return {
        "supported": bool(len(lower) >= 12),
        "lower_at_fixed": len(lower),
        "detectors": len(table),
        "by_detector": table,
    }


def x_fixed_threshold__mutmut_25(runs: list[dict[str, Any]]) -> dict[str, Any]:
    """P1: the median F1 of each detector at the label-free threshold against the prevalence one."""
    table = {}
    for method in sorted({m for r in runs for m in r["runs"]}):
        entry = {}
        for metric in METRICS:
            prev = per_problem(runs, "metrics", metric)[method].dropna()
            fixed = per_problem(runs, "fixed", metric)[method].dropna()
            entry[metric] = {"XXprevalenceXX": float(prev.median()), "fixed": float(fixed.median())}
        table[method] = entry
    lower = [m for m, e in table.items() if e["f1"]["fixed"] < e["f1"]["prevalence"]]
    return {
        "supported": bool(len(lower) >= 12),
        "lower_at_fixed": len(lower),
        "detectors": len(table),
        "by_detector": table,
    }


def x_fixed_threshold__mutmut_26(runs: list[dict[str, Any]]) -> dict[str, Any]:
    """P1: the median F1 of each detector at the label-free threshold against the prevalence one."""
    table = {}
    for method in sorted({m for r in runs for m in r["runs"]}):
        entry = {}
        for metric in METRICS:
            prev = per_problem(runs, "metrics", metric)[method].dropna()
            fixed = per_problem(runs, "fixed", metric)[method].dropna()
            entry[metric] = {"PREVALENCE": float(prev.median()), "fixed": float(fixed.median())}
        table[method] = entry
    lower = [m for m, e in table.items() if e["f1"]["fixed"] < e["f1"]["prevalence"]]
    return {
        "supported": bool(len(lower) >= 12),
        "lower_at_fixed": len(lower),
        "detectors": len(table),
        "by_detector": table,
    }


def x_fixed_threshold__mutmut_27(runs: list[dict[str, Any]]) -> dict[str, Any]:
    """P1: the median F1 of each detector at the label-free threshold against the prevalence one."""
    table = {}
    for method in sorted({m for r in runs for m in r["runs"]}):
        entry = {}
        for metric in METRICS:
            prev = per_problem(runs, "metrics", metric)[method].dropna()
            fixed = per_problem(runs, "fixed", metric)[method].dropna()
            entry[metric] = {"prevalence": float(None), "fixed": float(fixed.median())}
        table[method] = entry
    lower = [m for m, e in table.items() if e["f1"]["fixed"] < e["f1"]["prevalence"]]
    return {
        "supported": bool(len(lower) >= 12),
        "lower_at_fixed": len(lower),
        "detectors": len(table),
        "by_detector": table,
    }


def x_fixed_threshold__mutmut_28(runs: list[dict[str, Any]]) -> dict[str, Any]:
    """P1: the median F1 of each detector at the label-free threshold against the prevalence one."""
    table = {}
    for method in sorted({m for r in runs for m in r["runs"]}):
        entry = {}
        for metric in METRICS:
            prev = per_problem(runs, "metrics", metric)[method].dropna()
            fixed = per_problem(runs, "fixed", metric)[method].dropna()
            entry[metric] = {"prevalence": float(prev.median()), "XXfixedXX": float(fixed.median())}
        table[method] = entry
    lower = [m for m, e in table.items() if e["f1"]["fixed"] < e["f1"]["prevalence"]]
    return {
        "supported": bool(len(lower) >= 12),
        "lower_at_fixed": len(lower),
        "detectors": len(table),
        "by_detector": table,
    }


def x_fixed_threshold__mutmut_29(runs: list[dict[str, Any]]) -> dict[str, Any]:
    """P1: the median F1 of each detector at the label-free threshold against the prevalence one."""
    table = {}
    for method in sorted({m for r in runs for m in r["runs"]}):
        entry = {}
        for metric in METRICS:
            prev = per_problem(runs, "metrics", metric)[method].dropna()
            fixed = per_problem(runs, "fixed", metric)[method].dropna()
            entry[metric] = {"prevalence": float(prev.median()), "FIXED": float(fixed.median())}
        table[method] = entry
    lower = [m for m, e in table.items() if e["f1"]["fixed"] < e["f1"]["prevalence"]]
    return {
        "supported": bool(len(lower) >= 12),
        "lower_at_fixed": len(lower),
        "detectors": len(table),
        "by_detector": table,
    }


def x_fixed_threshold__mutmut_30(runs: list[dict[str, Any]]) -> dict[str, Any]:
    """P1: the median F1 of each detector at the label-free threshold against the prevalence one."""
    table = {}
    for method in sorted({m for r in runs for m in r["runs"]}):
        entry = {}
        for metric in METRICS:
            prev = per_problem(runs, "metrics", metric)[method].dropna()
            fixed = per_problem(runs, "fixed", metric)[method].dropna()
            entry[metric] = {"prevalence": float(prev.median()), "fixed": float(None)}
        table[method] = entry
    lower = [m for m, e in table.items() if e["f1"]["fixed"] < e["f1"]["prevalence"]]
    return {
        "supported": bool(len(lower) >= 12),
        "lower_at_fixed": len(lower),
        "detectors": len(table),
        "by_detector": table,
    }


def x_fixed_threshold__mutmut_31(runs: list[dict[str, Any]]) -> dict[str, Any]:
    """P1: the median F1 of each detector at the label-free threshold against the prevalence one."""
    table = {}
    for method in sorted({m for r in runs for m in r["runs"]}):
        entry = {}
        for metric in METRICS:
            prev = per_problem(runs, "metrics", metric)[method].dropna()
            fixed = per_problem(runs, "fixed", metric)[method].dropna()
            entry[metric] = {"prevalence": float(prev.median()), "fixed": float(fixed.median())}
        table[method] = None
    lower = [m for m, e in table.items() if e["f1"]["fixed"] < e["f1"]["prevalence"]]
    return {
        "supported": bool(len(lower) >= 12),
        "lower_at_fixed": len(lower),
        "detectors": len(table),
        "by_detector": table,
    }


def x_fixed_threshold__mutmut_32(runs: list[dict[str, Any]]) -> dict[str, Any]:
    """P1: the median F1 of each detector at the label-free threshold against the prevalence one."""
    table = {}
    for method in sorted({m for r in runs for m in r["runs"]}):
        entry = {}
        for metric in METRICS:
            prev = per_problem(runs, "metrics", metric)[method].dropna()
            fixed = per_problem(runs, "fixed", metric)[method].dropna()
            entry[metric] = {"prevalence": float(prev.median()), "fixed": float(fixed.median())}
        table[method] = entry
    lower = None
    return {
        "supported": bool(len(lower) >= 12),
        "lower_at_fixed": len(lower),
        "detectors": len(table),
        "by_detector": table,
    }


def x_fixed_threshold__mutmut_33(runs: list[dict[str, Any]]) -> dict[str, Any]:
    """P1: the median F1 of each detector at the label-free threshold against the prevalence one."""
    table = {}
    for method in sorted({m for r in runs for m in r["runs"]}):
        entry = {}
        for metric in METRICS:
            prev = per_problem(runs, "metrics", metric)[method].dropna()
            fixed = per_problem(runs, "fixed", metric)[method].dropna()
            entry[metric] = {"prevalence": float(prev.median()), "fixed": float(fixed.median())}
        table[method] = entry
    lower = [m for m, e in table.items() if e["XXf1XX"]["fixed"] < e["f1"]["prevalence"]]
    return {
        "supported": bool(len(lower) >= 12),
        "lower_at_fixed": len(lower),
        "detectors": len(table),
        "by_detector": table,
    }


def x_fixed_threshold__mutmut_34(runs: list[dict[str, Any]]) -> dict[str, Any]:
    """P1: the median F1 of each detector at the label-free threshold against the prevalence one."""
    table = {}
    for method in sorted({m for r in runs for m in r["runs"]}):
        entry = {}
        for metric in METRICS:
            prev = per_problem(runs, "metrics", metric)[method].dropna()
            fixed = per_problem(runs, "fixed", metric)[method].dropna()
            entry[metric] = {"prevalence": float(prev.median()), "fixed": float(fixed.median())}
        table[method] = entry
    lower = [m for m, e in table.items() if e["F1"]["fixed"] < e["f1"]["prevalence"]]
    return {
        "supported": bool(len(lower) >= 12),
        "lower_at_fixed": len(lower),
        "detectors": len(table),
        "by_detector": table,
    }


def x_fixed_threshold__mutmut_35(runs: list[dict[str, Any]]) -> dict[str, Any]:
    """P1: the median F1 of each detector at the label-free threshold against the prevalence one."""
    table = {}
    for method in sorted({m for r in runs for m in r["runs"]}):
        entry = {}
        for metric in METRICS:
            prev = per_problem(runs, "metrics", metric)[method].dropna()
            fixed = per_problem(runs, "fixed", metric)[method].dropna()
            entry[metric] = {"prevalence": float(prev.median()), "fixed": float(fixed.median())}
        table[method] = entry
    lower = [m for m, e in table.items() if e["f1"]["XXfixedXX"] < e["f1"]["prevalence"]]
    return {
        "supported": bool(len(lower) >= 12),
        "lower_at_fixed": len(lower),
        "detectors": len(table),
        "by_detector": table,
    }


def x_fixed_threshold__mutmut_36(runs: list[dict[str, Any]]) -> dict[str, Any]:
    """P1: the median F1 of each detector at the label-free threshold against the prevalence one."""
    table = {}
    for method in sorted({m for r in runs for m in r["runs"]}):
        entry = {}
        for metric in METRICS:
            prev = per_problem(runs, "metrics", metric)[method].dropna()
            fixed = per_problem(runs, "fixed", metric)[method].dropna()
            entry[metric] = {"prevalence": float(prev.median()), "fixed": float(fixed.median())}
        table[method] = entry
    lower = [m for m, e in table.items() if e["f1"]["FIXED"] < e["f1"]["prevalence"]]
    return {
        "supported": bool(len(lower) >= 12),
        "lower_at_fixed": len(lower),
        "detectors": len(table),
        "by_detector": table,
    }


def x_fixed_threshold__mutmut_37(runs: list[dict[str, Any]]) -> dict[str, Any]:
    """P1: the median F1 of each detector at the label-free threshold against the prevalence one."""
    table = {}
    for method in sorted({m for r in runs for m in r["runs"]}):
        entry = {}
        for metric in METRICS:
            prev = per_problem(runs, "metrics", metric)[method].dropna()
            fixed = per_problem(runs, "fixed", metric)[method].dropna()
            entry[metric] = {"prevalence": float(prev.median()), "fixed": float(fixed.median())}
        table[method] = entry
    lower = [m for m, e in table.items() if e["f1"]["fixed"] <= e["f1"]["prevalence"]]
    return {
        "supported": bool(len(lower) >= 12),
        "lower_at_fixed": len(lower),
        "detectors": len(table),
        "by_detector": table,
    }


def x_fixed_threshold__mutmut_38(runs: list[dict[str, Any]]) -> dict[str, Any]:
    """P1: the median F1 of each detector at the label-free threshold against the prevalence one."""
    table = {}
    for method in sorted({m for r in runs for m in r["runs"]}):
        entry = {}
        for metric in METRICS:
            prev = per_problem(runs, "metrics", metric)[method].dropna()
            fixed = per_problem(runs, "fixed", metric)[method].dropna()
            entry[metric] = {"prevalence": float(prev.median()), "fixed": float(fixed.median())}
        table[method] = entry
    lower = [m for m, e in table.items() if e["f1"]["fixed"] < e["XXf1XX"]["prevalence"]]
    return {
        "supported": bool(len(lower) >= 12),
        "lower_at_fixed": len(lower),
        "detectors": len(table),
        "by_detector": table,
    }


def x_fixed_threshold__mutmut_39(runs: list[dict[str, Any]]) -> dict[str, Any]:
    """P1: the median F1 of each detector at the label-free threshold against the prevalence one."""
    table = {}
    for method in sorted({m for r in runs for m in r["runs"]}):
        entry = {}
        for metric in METRICS:
            prev = per_problem(runs, "metrics", metric)[method].dropna()
            fixed = per_problem(runs, "fixed", metric)[method].dropna()
            entry[metric] = {"prevalence": float(prev.median()), "fixed": float(fixed.median())}
        table[method] = entry
    lower = [m for m, e in table.items() if e["f1"]["fixed"] < e["F1"]["prevalence"]]
    return {
        "supported": bool(len(lower) >= 12),
        "lower_at_fixed": len(lower),
        "detectors": len(table),
        "by_detector": table,
    }


def x_fixed_threshold__mutmut_40(runs: list[dict[str, Any]]) -> dict[str, Any]:
    """P1: the median F1 of each detector at the label-free threshold against the prevalence one."""
    table = {}
    for method in sorted({m for r in runs for m in r["runs"]}):
        entry = {}
        for metric in METRICS:
            prev = per_problem(runs, "metrics", metric)[method].dropna()
            fixed = per_problem(runs, "fixed", metric)[method].dropna()
            entry[metric] = {"prevalence": float(prev.median()), "fixed": float(fixed.median())}
        table[method] = entry
    lower = [m for m, e in table.items() if e["f1"]["fixed"] < e["f1"]["XXprevalenceXX"]]
    return {
        "supported": bool(len(lower) >= 12),
        "lower_at_fixed": len(lower),
        "detectors": len(table),
        "by_detector": table,
    }


def x_fixed_threshold__mutmut_41(runs: list[dict[str, Any]]) -> dict[str, Any]:
    """P1: the median F1 of each detector at the label-free threshold against the prevalence one."""
    table = {}
    for method in sorted({m for r in runs for m in r["runs"]}):
        entry = {}
        for metric in METRICS:
            prev = per_problem(runs, "metrics", metric)[method].dropna()
            fixed = per_problem(runs, "fixed", metric)[method].dropna()
            entry[metric] = {"prevalence": float(prev.median()), "fixed": float(fixed.median())}
        table[method] = entry
    lower = [m for m, e in table.items() if e["f1"]["fixed"] < e["f1"]["PREVALENCE"]]
    return {
        "supported": bool(len(lower) >= 12),
        "lower_at_fixed": len(lower),
        "detectors": len(table),
        "by_detector": table,
    }


def x_fixed_threshold__mutmut_42(runs: list[dict[str, Any]]) -> dict[str, Any]:
    """P1: the median F1 of each detector at the label-free threshold against the prevalence one."""
    table = {}
    for method in sorted({m for r in runs for m in r["runs"]}):
        entry = {}
        for metric in METRICS:
            prev = per_problem(runs, "metrics", metric)[method].dropna()
            fixed = per_problem(runs, "fixed", metric)[method].dropna()
            entry[metric] = {"prevalence": float(prev.median()), "fixed": float(fixed.median())}
        table[method] = entry
    lower = [m for m, e in table.items() if e["f1"]["fixed"] < e["f1"]["prevalence"]]
    return {
        "XXsupportedXX": bool(len(lower) >= 12),
        "lower_at_fixed": len(lower),
        "detectors": len(table),
        "by_detector": table,
    }


def x_fixed_threshold__mutmut_43(runs: list[dict[str, Any]]) -> dict[str, Any]:
    """P1: the median F1 of each detector at the label-free threshold against the prevalence one."""
    table = {}
    for method in sorted({m for r in runs for m in r["runs"]}):
        entry = {}
        for metric in METRICS:
            prev = per_problem(runs, "metrics", metric)[method].dropna()
            fixed = per_problem(runs, "fixed", metric)[method].dropna()
            entry[metric] = {"prevalence": float(prev.median()), "fixed": float(fixed.median())}
        table[method] = entry
    lower = [m for m, e in table.items() if e["f1"]["fixed"] < e["f1"]["prevalence"]]
    return {
        "SUPPORTED": bool(len(lower) >= 12),
        "lower_at_fixed": len(lower),
        "detectors": len(table),
        "by_detector": table,
    }


def x_fixed_threshold__mutmut_44(runs: list[dict[str, Any]]) -> dict[str, Any]:
    """P1: the median F1 of each detector at the label-free threshold against the prevalence one."""
    table = {}
    for method in sorted({m for r in runs for m in r["runs"]}):
        entry = {}
        for metric in METRICS:
            prev = per_problem(runs, "metrics", metric)[method].dropna()
            fixed = per_problem(runs, "fixed", metric)[method].dropna()
            entry[metric] = {"prevalence": float(prev.median()), "fixed": float(fixed.median())}
        table[method] = entry
    lower = [m for m, e in table.items() if e["f1"]["fixed"] < e["f1"]["prevalence"]]
    return {
        "supported": bool(None),
        "lower_at_fixed": len(lower),
        "detectors": len(table),
        "by_detector": table,
    }


def x_fixed_threshold__mutmut_45(runs: list[dict[str, Any]]) -> dict[str, Any]:
    """P1: the median F1 of each detector at the label-free threshold against the prevalence one."""
    table = {}
    for method in sorted({m for r in runs for m in r["runs"]}):
        entry = {}
        for metric in METRICS:
            prev = per_problem(runs, "metrics", metric)[method].dropna()
            fixed = per_problem(runs, "fixed", metric)[method].dropna()
            entry[metric] = {"prevalence": float(prev.median()), "fixed": float(fixed.median())}
        table[method] = entry
    lower = [m for m, e in table.items() if e["f1"]["fixed"] < e["f1"]["prevalence"]]
    return {
        "supported": bool(len(lower) > 12),
        "lower_at_fixed": len(lower),
        "detectors": len(table),
        "by_detector": table,
    }


def x_fixed_threshold__mutmut_46(runs: list[dict[str, Any]]) -> dict[str, Any]:
    """P1: the median F1 of each detector at the label-free threshold against the prevalence one."""
    table = {}
    for method in sorted({m for r in runs for m in r["runs"]}):
        entry = {}
        for metric in METRICS:
            prev = per_problem(runs, "metrics", metric)[method].dropna()
            fixed = per_problem(runs, "fixed", metric)[method].dropna()
            entry[metric] = {"prevalence": float(prev.median()), "fixed": float(fixed.median())}
        table[method] = entry
    lower = [m for m, e in table.items() if e["f1"]["fixed"] < e["f1"]["prevalence"]]
    return {
        "supported": bool(len(lower) >= 13),
        "lower_at_fixed": len(lower),
        "detectors": len(table),
        "by_detector": table,
    }


def x_fixed_threshold__mutmut_47(runs: list[dict[str, Any]]) -> dict[str, Any]:
    """P1: the median F1 of each detector at the label-free threshold against the prevalence one."""
    table = {}
    for method in sorted({m for r in runs for m in r["runs"]}):
        entry = {}
        for metric in METRICS:
            prev = per_problem(runs, "metrics", metric)[method].dropna()
            fixed = per_problem(runs, "fixed", metric)[method].dropna()
            entry[metric] = {"prevalence": float(prev.median()), "fixed": float(fixed.median())}
        table[method] = entry
    lower = [m for m, e in table.items() if e["f1"]["fixed"] < e["f1"]["prevalence"]]
    return {
        "supported": bool(len(lower) >= 12),
        "XXlower_at_fixedXX": len(lower),
        "detectors": len(table),
        "by_detector": table,
    }


def x_fixed_threshold__mutmut_48(runs: list[dict[str, Any]]) -> dict[str, Any]:
    """P1: the median F1 of each detector at the label-free threshold against the prevalence one."""
    table = {}
    for method in sorted({m for r in runs for m in r["runs"]}):
        entry = {}
        for metric in METRICS:
            prev = per_problem(runs, "metrics", metric)[method].dropna()
            fixed = per_problem(runs, "fixed", metric)[method].dropna()
            entry[metric] = {"prevalence": float(prev.median()), "fixed": float(fixed.median())}
        table[method] = entry
    lower = [m for m, e in table.items() if e["f1"]["fixed"] < e["f1"]["prevalence"]]
    return {
        "supported": bool(len(lower) >= 12),
        "LOWER_AT_FIXED": len(lower),
        "detectors": len(table),
        "by_detector": table,
    }


def x_fixed_threshold__mutmut_49(runs: list[dict[str, Any]]) -> dict[str, Any]:
    """P1: the median F1 of each detector at the label-free threshold against the prevalence one."""
    table = {}
    for method in sorted({m for r in runs for m in r["runs"]}):
        entry = {}
        for metric in METRICS:
            prev = per_problem(runs, "metrics", metric)[method].dropna()
            fixed = per_problem(runs, "fixed", metric)[method].dropna()
            entry[metric] = {"prevalence": float(prev.median()), "fixed": float(fixed.median())}
        table[method] = entry
    lower = [m for m, e in table.items() if e["f1"]["fixed"] < e["f1"]["prevalence"]]
    return {
        "supported": bool(len(lower) >= 12),
        "lower_at_fixed": len(lower),
        "XXdetectorsXX": len(table),
        "by_detector": table,
    }


def x_fixed_threshold__mutmut_50(runs: list[dict[str, Any]]) -> dict[str, Any]:
    """P1: the median F1 of each detector at the label-free threshold against the prevalence one."""
    table = {}
    for method in sorted({m for r in runs for m in r["runs"]}):
        entry = {}
        for metric in METRICS:
            prev = per_problem(runs, "metrics", metric)[method].dropna()
            fixed = per_problem(runs, "fixed", metric)[method].dropna()
            entry[metric] = {"prevalence": float(prev.median()), "fixed": float(fixed.median())}
        table[method] = entry
    lower = [m for m, e in table.items() if e["f1"]["fixed"] < e["f1"]["prevalence"]]
    return {
        "supported": bool(len(lower) >= 12),
        "lower_at_fixed": len(lower),
        "DETECTORS": len(table),
        "by_detector": table,
    }


def x_fixed_threshold__mutmut_51(runs: list[dict[str, Any]]) -> dict[str, Any]:
    """P1: the median F1 of each detector at the label-free threshold against the prevalence one."""
    table = {}
    for method in sorted({m for r in runs for m in r["runs"]}):
        entry = {}
        for metric in METRICS:
            prev = per_problem(runs, "metrics", metric)[method].dropna()
            fixed = per_problem(runs, "fixed", metric)[method].dropna()
            entry[metric] = {"prevalence": float(prev.median()), "fixed": float(fixed.median())}
        table[method] = entry
    lower = [m for m, e in table.items() if e["f1"]["fixed"] < e["f1"]["prevalence"]]
    return {
        "supported": bool(len(lower) >= 12),
        "lower_at_fixed": len(lower),
        "detectors": len(table),
        "XXby_detectorXX": table,
    }


def x_fixed_threshold__mutmut_52(runs: list[dict[str, Any]]) -> dict[str, Any]:
    """P1: the median F1 of each detector at the label-free threshold against the prevalence one."""
    table = {}
    for method in sorted({m for r in runs for m in r["runs"]}):
        entry = {}
        for metric in METRICS:
            prev = per_problem(runs, "metrics", metric)[method].dropna()
            fixed = per_problem(runs, "fixed", metric)[method].dropna()
            entry[metric] = {"prevalence": float(prev.median()), "fixed": float(fixed.median())}
        table[method] = entry
    lower = [m for m, e in table.items() if e["f1"]["fixed"] < e["f1"]["prevalence"]]
    return {
        "supported": bool(len(lower) >= 12),
        "lower_at_fixed": len(lower),
        "detectors": len(table),
        "BY_DETECTOR": table,
    }

mutants_x_fixed_threshold__mutmut['_mutmut_orig'] = x_fixed_threshold__mutmut_orig # type: ignore # mutmut generated
mutants_x_fixed_threshold__mutmut['x_fixed_threshold__mutmut_1'] = x_fixed_threshold__mutmut_1 # type: ignore # mutmut generated
mutants_x_fixed_threshold__mutmut['x_fixed_threshold__mutmut_2'] = x_fixed_threshold__mutmut_2 # type: ignore # mutmut generated
mutants_x_fixed_threshold__mutmut['x_fixed_threshold__mutmut_3'] = x_fixed_threshold__mutmut_3 # type: ignore # mutmut generated
mutants_x_fixed_threshold__mutmut['x_fixed_threshold__mutmut_4'] = x_fixed_threshold__mutmut_4 # type: ignore # mutmut generated
mutants_x_fixed_threshold__mutmut['x_fixed_threshold__mutmut_5'] = x_fixed_threshold__mutmut_5 # type: ignore # mutmut generated
mutants_x_fixed_threshold__mutmut['x_fixed_threshold__mutmut_6'] = x_fixed_threshold__mutmut_6 # type: ignore # mutmut generated
mutants_x_fixed_threshold__mutmut['x_fixed_threshold__mutmut_7'] = x_fixed_threshold__mutmut_7 # type: ignore # mutmut generated
mutants_x_fixed_threshold__mutmut['x_fixed_threshold__mutmut_8'] = x_fixed_threshold__mutmut_8 # type: ignore # mutmut generated
mutants_x_fixed_threshold__mutmut['x_fixed_threshold__mutmut_9'] = x_fixed_threshold__mutmut_9 # type: ignore # mutmut generated
mutants_x_fixed_threshold__mutmut['x_fixed_threshold__mutmut_10'] = x_fixed_threshold__mutmut_10 # type: ignore # mutmut generated
mutants_x_fixed_threshold__mutmut['x_fixed_threshold__mutmut_11'] = x_fixed_threshold__mutmut_11 # type: ignore # mutmut generated
mutants_x_fixed_threshold__mutmut['x_fixed_threshold__mutmut_12'] = x_fixed_threshold__mutmut_12 # type: ignore # mutmut generated
mutants_x_fixed_threshold__mutmut['x_fixed_threshold__mutmut_13'] = x_fixed_threshold__mutmut_13 # type: ignore # mutmut generated
mutants_x_fixed_threshold__mutmut['x_fixed_threshold__mutmut_14'] = x_fixed_threshold__mutmut_14 # type: ignore # mutmut generated
mutants_x_fixed_threshold__mutmut['x_fixed_threshold__mutmut_15'] = x_fixed_threshold__mutmut_15 # type: ignore # mutmut generated
mutants_x_fixed_threshold__mutmut['x_fixed_threshold__mutmut_16'] = x_fixed_threshold__mutmut_16 # type: ignore # mutmut generated
mutants_x_fixed_threshold__mutmut['x_fixed_threshold__mutmut_17'] = x_fixed_threshold__mutmut_17 # type: ignore # mutmut generated
mutants_x_fixed_threshold__mutmut['x_fixed_threshold__mutmut_18'] = x_fixed_threshold__mutmut_18 # type: ignore # mutmut generated
mutants_x_fixed_threshold__mutmut['x_fixed_threshold__mutmut_19'] = x_fixed_threshold__mutmut_19 # type: ignore # mutmut generated
mutants_x_fixed_threshold__mutmut['x_fixed_threshold__mutmut_20'] = x_fixed_threshold__mutmut_20 # type: ignore # mutmut generated
mutants_x_fixed_threshold__mutmut['x_fixed_threshold__mutmut_21'] = x_fixed_threshold__mutmut_21 # type: ignore # mutmut generated
mutants_x_fixed_threshold__mutmut['x_fixed_threshold__mutmut_22'] = x_fixed_threshold__mutmut_22 # type: ignore # mutmut generated
mutants_x_fixed_threshold__mutmut['x_fixed_threshold__mutmut_23'] = x_fixed_threshold__mutmut_23 # type: ignore # mutmut generated
mutants_x_fixed_threshold__mutmut['x_fixed_threshold__mutmut_24'] = x_fixed_threshold__mutmut_24 # type: ignore # mutmut generated
mutants_x_fixed_threshold__mutmut['x_fixed_threshold__mutmut_25'] = x_fixed_threshold__mutmut_25 # type: ignore # mutmut generated
mutants_x_fixed_threshold__mutmut['x_fixed_threshold__mutmut_26'] = x_fixed_threshold__mutmut_26 # type: ignore # mutmut generated
mutants_x_fixed_threshold__mutmut['x_fixed_threshold__mutmut_27'] = x_fixed_threshold__mutmut_27 # type: ignore # mutmut generated
mutants_x_fixed_threshold__mutmut['x_fixed_threshold__mutmut_28'] = x_fixed_threshold__mutmut_28 # type: ignore # mutmut generated
mutants_x_fixed_threshold__mutmut['x_fixed_threshold__mutmut_29'] = x_fixed_threshold__mutmut_29 # type: ignore # mutmut generated
mutants_x_fixed_threshold__mutmut['x_fixed_threshold__mutmut_30'] = x_fixed_threshold__mutmut_30 # type: ignore # mutmut generated
mutants_x_fixed_threshold__mutmut['x_fixed_threshold__mutmut_31'] = x_fixed_threshold__mutmut_31 # type: ignore # mutmut generated
mutants_x_fixed_threshold__mutmut['x_fixed_threshold__mutmut_32'] = x_fixed_threshold__mutmut_32 # type: ignore # mutmut generated
mutants_x_fixed_threshold__mutmut['x_fixed_threshold__mutmut_33'] = x_fixed_threshold__mutmut_33 # type: ignore # mutmut generated
mutants_x_fixed_threshold__mutmut['x_fixed_threshold__mutmut_34'] = x_fixed_threshold__mutmut_34 # type: ignore # mutmut generated
mutants_x_fixed_threshold__mutmut['x_fixed_threshold__mutmut_35'] = x_fixed_threshold__mutmut_35 # type: ignore # mutmut generated
mutants_x_fixed_threshold__mutmut['x_fixed_threshold__mutmut_36'] = x_fixed_threshold__mutmut_36 # type: ignore # mutmut generated
mutants_x_fixed_threshold__mutmut['x_fixed_threshold__mutmut_37'] = x_fixed_threshold__mutmut_37 # type: ignore # mutmut generated
mutants_x_fixed_threshold__mutmut['x_fixed_threshold__mutmut_38'] = x_fixed_threshold__mutmut_38 # type: ignore # mutmut generated
mutants_x_fixed_threshold__mutmut['x_fixed_threshold__mutmut_39'] = x_fixed_threshold__mutmut_39 # type: ignore # mutmut generated
mutants_x_fixed_threshold__mutmut['x_fixed_threshold__mutmut_40'] = x_fixed_threshold__mutmut_40 # type: ignore # mutmut generated
mutants_x_fixed_threshold__mutmut['x_fixed_threshold__mutmut_41'] = x_fixed_threshold__mutmut_41 # type: ignore # mutmut generated
mutants_x_fixed_threshold__mutmut['x_fixed_threshold__mutmut_42'] = x_fixed_threshold__mutmut_42 # type: ignore # mutmut generated
mutants_x_fixed_threshold__mutmut['x_fixed_threshold__mutmut_43'] = x_fixed_threshold__mutmut_43 # type: ignore # mutmut generated
mutants_x_fixed_threshold__mutmut['x_fixed_threshold__mutmut_44'] = x_fixed_threshold__mutmut_44 # type: ignore # mutmut generated
mutants_x_fixed_threshold__mutmut['x_fixed_threshold__mutmut_45'] = x_fixed_threshold__mutmut_45 # type: ignore # mutmut generated
mutants_x_fixed_threshold__mutmut['x_fixed_threshold__mutmut_46'] = x_fixed_threshold__mutmut_46 # type: ignore # mutmut generated
mutants_x_fixed_threshold__mutmut['x_fixed_threshold__mutmut_47'] = x_fixed_threshold__mutmut_47 # type: ignore # mutmut generated
mutants_x_fixed_threshold__mutmut['x_fixed_threshold__mutmut_48'] = x_fixed_threshold__mutmut_48 # type: ignore # mutmut generated
mutants_x_fixed_threshold__mutmut['x_fixed_threshold__mutmut_49'] = x_fixed_threshold__mutmut_49 # type: ignore # mutmut generated
mutants_x_fixed_threshold__mutmut['x_fixed_threshold__mutmut_50'] = x_fixed_threshold__mutmut_50 # type: ignore # mutmut generated
mutants_x_fixed_threshold__mutmut['x_fixed_threshold__mutmut_51'] = x_fixed_threshold__mutmut_51 # type: ignore # mutmut generated
mutants_x_fixed_threshold__mutmut['x_fixed_threshold__mutmut_52'] = x_fixed_threshold__mutmut_52 # type: ignore # mutmut generated
mutants_x_curve_ranking__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_curve_ranking__mutmut)
def curve_ranking(runs: list[dict[str, Any]]) -> dict[str, Any]:
    """P2: the rank of the detectors by the average precision of the curves of seed 42."""
    ap: dict[str, dict[str, float]] = {}
    for run in runs:
        for method, seeds in run["runs"].items():
            for row in seeds:
                if "curve" in row:
                    ap.setdefault(method, {})[run["problem"]] = row["curve"]["average_precision"]
    curves = pd.DataFrame(ap).median()
    pooled = per_problem(runs, "metrics", "pr_auc").median()
    common = curves.index.intersection(pooled.index)
    rho = float(spearmanr(curves[common], pooled[common]).statistic)
    return {
        "supported": bool(round(rho, 9) >= 0.99),
        "spearman": rho,
        "median_ap": curves.to_dict(),
    }


def x_curve_ranking__mutmut_orig(runs: list[dict[str, Any]]) -> dict[str, Any]:
    """P2: the rank of the detectors by the average precision of the curves of seed 42."""
    ap: dict[str, dict[str, float]] = {}
    for run in runs:
        for method, seeds in run["runs"].items():
            for row in seeds:
                if "curve" in row:
                    ap.setdefault(method, {})[run["problem"]] = row["curve"]["average_precision"]
    curves = pd.DataFrame(ap).median()
    pooled = per_problem(runs, "metrics", "pr_auc").median()
    common = curves.index.intersection(pooled.index)
    rho = float(spearmanr(curves[common], pooled[common]).statistic)
    return {
        "supported": bool(round(rho, 9) >= 0.99),
        "spearman": rho,
        "median_ap": curves.to_dict(),
    }


def x_curve_ranking__mutmut_1(runs: list[dict[str, Any]]) -> dict[str, Any]:
    """P2: the rank of the detectors by the average precision of the curves of seed 42."""
    ap: dict[str, dict[str, float]] = None
    for run in runs:
        for method, seeds in run["runs"].items():
            for row in seeds:
                if "curve" in row:
                    ap.setdefault(method, {})[run["problem"]] = row["curve"]["average_precision"]
    curves = pd.DataFrame(ap).median()
    pooled = per_problem(runs, "metrics", "pr_auc").median()
    common = curves.index.intersection(pooled.index)
    rho = float(spearmanr(curves[common], pooled[common]).statistic)
    return {
        "supported": bool(round(rho, 9) >= 0.99),
        "spearman": rho,
        "median_ap": curves.to_dict(),
    }


def x_curve_ranking__mutmut_2(runs: list[dict[str, Any]]) -> dict[str, Any]:
    """P2: the rank of the detectors by the average precision of the curves of seed 42."""
    ap: dict[str, dict[str, float]] = {}
    for run in runs:
        for method, seeds in run["XXrunsXX"].items():
            for row in seeds:
                if "curve" in row:
                    ap.setdefault(method, {})[run["problem"]] = row["curve"]["average_precision"]
    curves = pd.DataFrame(ap).median()
    pooled = per_problem(runs, "metrics", "pr_auc").median()
    common = curves.index.intersection(pooled.index)
    rho = float(spearmanr(curves[common], pooled[common]).statistic)
    return {
        "supported": bool(round(rho, 9) >= 0.99),
        "spearman": rho,
        "median_ap": curves.to_dict(),
    }


def x_curve_ranking__mutmut_3(runs: list[dict[str, Any]]) -> dict[str, Any]:
    """P2: the rank of the detectors by the average precision of the curves of seed 42."""
    ap: dict[str, dict[str, float]] = {}
    for run in runs:
        for method, seeds in run["RUNS"].items():
            for row in seeds:
                if "curve" in row:
                    ap.setdefault(method, {})[run["problem"]] = row["curve"]["average_precision"]
    curves = pd.DataFrame(ap).median()
    pooled = per_problem(runs, "metrics", "pr_auc").median()
    common = curves.index.intersection(pooled.index)
    rho = float(spearmanr(curves[common], pooled[common]).statistic)
    return {
        "supported": bool(round(rho, 9) >= 0.99),
        "spearman": rho,
        "median_ap": curves.to_dict(),
    }


def x_curve_ranking__mutmut_4(runs: list[dict[str, Any]]) -> dict[str, Any]:
    """P2: the rank of the detectors by the average precision of the curves of seed 42."""
    ap: dict[str, dict[str, float]] = {}
    for run in runs:
        for method, seeds in run["runs"].items():
            for row in seeds:
                if "XXcurveXX" in row:
                    ap.setdefault(method, {})[run["problem"]] = row["curve"]["average_precision"]
    curves = pd.DataFrame(ap).median()
    pooled = per_problem(runs, "metrics", "pr_auc").median()
    common = curves.index.intersection(pooled.index)
    rho = float(spearmanr(curves[common], pooled[common]).statistic)
    return {
        "supported": bool(round(rho, 9) >= 0.99),
        "spearman": rho,
        "median_ap": curves.to_dict(),
    }


def x_curve_ranking__mutmut_5(runs: list[dict[str, Any]]) -> dict[str, Any]:
    """P2: the rank of the detectors by the average precision of the curves of seed 42."""
    ap: dict[str, dict[str, float]] = {}
    for run in runs:
        for method, seeds in run["runs"].items():
            for row in seeds:
                if "CURVE" in row:
                    ap.setdefault(method, {})[run["problem"]] = row["curve"]["average_precision"]
    curves = pd.DataFrame(ap).median()
    pooled = per_problem(runs, "metrics", "pr_auc").median()
    common = curves.index.intersection(pooled.index)
    rho = float(spearmanr(curves[common], pooled[common]).statistic)
    return {
        "supported": bool(round(rho, 9) >= 0.99),
        "spearman": rho,
        "median_ap": curves.to_dict(),
    }


def x_curve_ranking__mutmut_6(runs: list[dict[str, Any]]) -> dict[str, Any]:
    """P2: the rank of the detectors by the average precision of the curves of seed 42."""
    ap: dict[str, dict[str, float]] = {}
    for run in runs:
        for method, seeds in run["runs"].items():
            for row in seeds:
                if "curve" not in row:
                    ap.setdefault(method, {})[run["problem"]] = row["curve"]["average_precision"]
    curves = pd.DataFrame(ap).median()
    pooled = per_problem(runs, "metrics", "pr_auc").median()
    common = curves.index.intersection(pooled.index)
    rho = float(spearmanr(curves[common], pooled[common]).statistic)
    return {
        "supported": bool(round(rho, 9) >= 0.99),
        "spearman": rho,
        "median_ap": curves.to_dict(),
    }


def x_curve_ranking__mutmut_7(runs: list[dict[str, Any]]) -> dict[str, Any]:
    """P2: the rank of the detectors by the average precision of the curves of seed 42."""
    ap: dict[str, dict[str, float]] = {}
    for run in runs:
        for method, seeds in run["runs"].items():
            for row in seeds:
                if "curve" in row:
                    ap.setdefault(method, {})[run["problem"]] = None
    curves = pd.DataFrame(ap).median()
    pooled = per_problem(runs, "metrics", "pr_auc").median()
    common = curves.index.intersection(pooled.index)
    rho = float(spearmanr(curves[common], pooled[common]).statistic)
    return {
        "supported": bool(round(rho, 9) >= 0.99),
        "spearman": rho,
        "median_ap": curves.to_dict(),
    }


def x_curve_ranking__mutmut_8(runs: list[dict[str, Any]]) -> dict[str, Any]:
    """P2: the rank of the detectors by the average precision of the curves of seed 42."""
    ap: dict[str, dict[str, float]] = {}
    for run in runs:
        for method, seeds in run["runs"].items():
            for row in seeds:
                if "curve" in row:
                    ap.setdefault(None, {})[run["problem"]] = row["curve"]["average_precision"]
    curves = pd.DataFrame(ap).median()
    pooled = per_problem(runs, "metrics", "pr_auc").median()
    common = curves.index.intersection(pooled.index)
    rho = float(spearmanr(curves[common], pooled[common]).statistic)
    return {
        "supported": bool(round(rho, 9) >= 0.99),
        "spearman": rho,
        "median_ap": curves.to_dict(),
    }


def x_curve_ranking__mutmut_9(runs: list[dict[str, Any]]) -> dict[str, Any]:
    """P2: the rank of the detectors by the average precision of the curves of seed 42."""
    ap: dict[str, dict[str, float]] = {}
    for run in runs:
        for method, seeds in run["runs"].items():
            for row in seeds:
                if "curve" in row:
                    ap.setdefault(method, None)[run["problem"]] = row["curve"]["average_precision"]
    curves = pd.DataFrame(ap).median()
    pooled = per_problem(runs, "metrics", "pr_auc").median()
    common = curves.index.intersection(pooled.index)
    rho = float(spearmanr(curves[common], pooled[common]).statistic)
    return {
        "supported": bool(round(rho, 9) >= 0.99),
        "spearman": rho,
        "median_ap": curves.to_dict(),
    }


def x_curve_ranking__mutmut_10(runs: list[dict[str, Any]]) -> dict[str, Any]:
    """P2: the rank of the detectors by the average precision of the curves of seed 42."""
    ap: dict[str, dict[str, float]] = {}
    for run in runs:
        for method, seeds in run["runs"].items():
            for row in seeds:
                if "curve" in row:
                    ap.setdefault({})[run["problem"]] = row["curve"]["average_precision"]
    curves = pd.DataFrame(ap).median()
    pooled = per_problem(runs, "metrics", "pr_auc").median()
    common = curves.index.intersection(pooled.index)
    rho = float(spearmanr(curves[common], pooled[common]).statistic)
    return {
        "supported": bool(round(rho, 9) >= 0.99),
        "spearman": rho,
        "median_ap": curves.to_dict(),
    }


def x_curve_ranking__mutmut_11(runs: list[dict[str, Any]]) -> dict[str, Any]:
    """P2: the rank of the detectors by the average precision of the curves of seed 42."""
    ap: dict[str, dict[str, float]] = {}
    for run in runs:
        for method, seeds in run["runs"].items():
            for row in seeds:
                if "curve" in row:
                    ap.setdefault(method, )[run["problem"]] = row["curve"]["average_precision"]
    curves = pd.DataFrame(ap).median()
    pooled = per_problem(runs, "metrics", "pr_auc").median()
    common = curves.index.intersection(pooled.index)
    rho = float(spearmanr(curves[common], pooled[common]).statistic)
    return {
        "supported": bool(round(rho, 9) >= 0.99),
        "spearman": rho,
        "median_ap": curves.to_dict(),
    }


def x_curve_ranking__mutmut_12(runs: list[dict[str, Any]]) -> dict[str, Any]:
    """P2: the rank of the detectors by the average precision of the curves of seed 42."""
    ap: dict[str, dict[str, float]] = {}
    for run in runs:
        for method, seeds in run["runs"].items():
            for row in seeds:
                if "curve" in row:
                    ap.setdefault(method, {})[run["XXproblemXX"]] = row["curve"]["average_precision"]
    curves = pd.DataFrame(ap).median()
    pooled = per_problem(runs, "metrics", "pr_auc").median()
    common = curves.index.intersection(pooled.index)
    rho = float(spearmanr(curves[common], pooled[common]).statistic)
    return {
        "supported": bool(round(rho, 9) >= 0.99),
        "spearman": rho,
        "median_ap": curves.to_dict(),
    }


def x_curve_ranking__mutmut_13(runs: list[dict[str, Any]]) -> dict[str, Any]:
    """P2: the rank of the detectors by the average precision of the curves of seed 42."""
    ap: dict[str, dict[str, float]] = {}
    for run in runs:
        for method, seeds in run["runs"].items():
            for row in seeds:
                if "curve" in row:
                    ap.setdefault(method, {})[run["PROBLEM"]] = row["curve"]["average_precision"]
    curves = pd.DataFrame(ap).median()
    pooled = per_problem(runs, "metrics", "pr_auc").median()
    common = curves.index.intersection(pooled.index)
    rho = float(spearmanr(curves[common], pooled[common]).statistic)
    return {
        "supported": bool(round(rho, 9) >= 0.99),
        "spearman": rho,
        "median_ap": curves.to_dict(),
    }


def x_curve_ranking__mutmut_14(runs: list[dict[str, Any]]) -> dict[str, Any]:
    """P2: the rank of the detectors by the average precision of the curves of seed 42."""
    ap: dict[str, dict[str, float]] = {}
    for run in runs:
        for method, seeds in run["runs"].items():
            for row in seeds:
                if "curve" in row:
                    ap.setdefault(method, {})[run["problem"]] = row["XXcurveXX"]["average_precision"]
    curves = pd.DataFrame(ap).median()
    pooled = per_problem(runs, "metrics", "pr_auc").median()
    common = curves.index.intersection(pooled.index)
    rho = float(spearmanr(curves[common], pooled[common]).statistic)
    return {
        "supported": bool(round(rho, 9) >= 0.99),
        "spearman": rho,
        "median_ap": curves.to_dict(),
    }


def x_curve_ranking__mutmut_15(runs: list[dict[str, Any]]) -> dict[str, Any]:
    """P2: the rank of the detectors by the average precision of the curves of seed 42."""
    ap: dict[str, dict[str, float]] = {}
    for run in runs:
        for method, seeds in run["runs"].items():
            for row in seeds:
                if "curve" in row:
                    ap.setdefault(method, {})[run["problem"]] = row["CURVE"]["average_precision"]
    curves = pd.DataFrame(ap).median()
    pooled = per_problem(runs, "metrics", "pr_auc").median()
    common = curves.index.intersection(pooled.index)
    rho = float(spearmanr(curves[common], pooled[common]).statistic)
    return {
        "supported": bool(round(rho, 9) >= 0.99),
        "spearman": rho,
        "median_ap": curves.to_dict(),
    }


def x_curve_ranking__mutmut_16(runs: list[dict[str, Any]]) -> dict[str, Any]:
    """P2: the rank of the detectors by the average precision of the curves of seed 42."""
    ap: dict[str, dict[str, float]] = {}
    for run in runs:
        for method, seeds in run["runs"].items():
            for row in seeds:
                if "curve" in row:
                    ap.setdefault(method, {})[run["problem"]] = row["curve"]["XXaverage_precisionXX"]
    curves = pd.DataFrame(ap).median()
    pooled = per_problem(runs, "metrics", "pr_auc").median()
    common = curves.index.intersection(pooled.index)
    rho = float(spearmanr(curves[common], pooled[common]).statistic)
    return {
        "supported": bool(round(rho, 9) >= 0.99),
        "spearman": rho,
        "median_ap": curves.to_dict(),
    }


def x_curve_ranking__mutmut_17(runs: list[dict[str, Any]]) -> dict[str, Any]:
    """P2: the rank of the detectors by the average precision of the curves of seed 42."""
    ap: dict[str, dict[str, float]] = {}
    for run in runs:
        for method, seeds in run["runs"].items():
            for row in seeds:
                if "curve" in row:
                    ap.setdefault(method, {})[run["problem"]] = row["curve"]["AVERAGE_PRECISION"]
    curves = pd.DataFrame(ap).median()
    pooled = per_problem(runs, "metrics", "pr_auc").median()
    common = curves.index.intersection(pooled.index)
    rho = float(spearmanr(curves[common], pooled[common]).statistic)
    return {
        "supported": bool(round(rho, 9) >= 0.99),
        "spearman": rho,
        "median_ap": curves.to_dict(),
    }


def x_curve_ranking__mutmut_18(runs: list[dict[str, Any]]) -> dict[str, Any]:
    """P2: the rank of the detectors by the average precision of the curves of seed 42."""
    ap: dict[str, dict[str, float]] = {}
    for run in runs:
        for method, seeds in run["runs"].items():
            for row in seeds:
                if "curve" in row:
                    ap.setdefault(method, {})[run["problem"]] = row["curve"]["average_precision"]
    curves = None
    pooled = per_problem(runs, "metrics", "pr_auc").median()
    common = curves.index.intersection(pooled.index)
    rho = float(spearmanr(curves[common], pooled[common]).statistic)
    return {
        "supported": bool(round(rho, 9) >= 0.99),
        "spearman": rho,
        "median_ap": curves.to_dict(),
    }


def x_curve_ranking__mutmut_19(runs: list[dict[str, Any]]) -> dict[str, Any]:
    """P2: the rank of the detectors by the average precision of the curves of seed 42."""
    ap: dict[str, dict[str, float]] = {}
    for run in runs:
        for method, seeds in run["runs"].items():
            for row in seeds:
                if "curve" in row:
                    ap.setdefault(method, {})[run["problem"]] = row["curve"]["average_precision"]
    curves = pd.DataFrame(None).median()
    pooled = per_problem(runs, "metrics", "pr_auc").median()
    common = curves.index.intersection(pooled.index)
    rho = float(spearmanr(curves[common], pooled[common]).statistic)
    return {
        "supported": bool(round(rho, 9) >= 0.99),
        "spearman": rho,
        "median_ap": curves.to_dict(),
    }


def x_curve_ranking__mutmut_20(runs: list[dict[str, Any]]) -> dict[str, Any]:
    """P2: the rank of the detectors by the average precision of the curves of seed 42."""
    ap: dict[str, dict[str, float]] = {}
    for run in runs:
        for method, seeds in run["runs"].items():
            for row in seeds:
                if "curve" in row:
                    ap.setdefault(method, {})[run["problem"]] = row["curve"]["average_precision"]
    curves = pd.DataFrame(ap).median()
    pooled = None
    common = curves.index.intersection(pooled.index)
    rho = float(spearmanr(curves[common], pooled[common]).statistic)
    return {
        "supported": bool(round(rho, 9) >= 0.99),
        "spearman": rho,
        "median_ap": curves.to_dict(),
    }


def x_curve_ranking__mutmut_21(runs: list[dict[str, Any]]) -> dict[str, Any]:
    """P2: the rank of the detectors by the average precision of the curves of seed 42."""
    ap: dict[str, dict[str, float]] = {}
    for run in runs:
        for method, seeds in run["runs"].items():
            for row in seeds:
                if "curve" in row:
                    ap.setdefault(method, {})[run["problem"]] = row["curve"]["average_precision"]
    curves = pd.DataFrame(ap).median()
    pooled = per_problem(None, "metrics", "pr_auc").median()
    common = curves.index.intersection(pooled.index)
    rho = float(spearmanr(curves[common], pooled[common]).statistic)
    return {
        "supported": bool(round(rho, 9) >= 0.99),
        "spearman": rho,
        "median_ap": curves.to_dict(),
    }


def x_curve_ranking__mutmut_22(runs: list[dict[str, Any]]) -> dict[str, Any]:
    """P2: the rank of the detectors by the average precision of the curves of seed 42."""
    ap: dict[str, dict[str, float]] = {}
    for run in runs:
        for method, seeds in run["runs"].items():
            for row in seeds:
                if "curve" in row:
                    ap.setdefault(method, {})[run["problem"]] = row["curve"]["average_precision"]
    curves = pd.DataFrame(ap).median()
    pooled = per_problem(runs, None, "pr_auc").median()
    common = curves.index.intersection(pooled.index)
    rho = float(spearmanr(curves[common], pooled[common]).statistic)
    return {
        "supported": bool(round(rho, 9) >= 0.99),
        "spearman": rho,
        "median_ap": curves.to_dict(),
    }


def x_curve_ranking__mutmut_23(runs: list[dict[str, Any]]) -> dict[str, Any]:
    """P2: the rank of the detectors by the average precision of the curves of seed 42."""
    ap: dict[str, dict[str, float]] = {}
    for run in runs:
        for method, seeds in run["runs"].items():
            for row in seeds:
                if "curve" in row:
                    ap.setdefault(method, {})[run["problem"]] = row["curve"]["average_precision"]
    curves = pd.DataFrame(ap).median()
    pooled = per_problem(runs, "metrics", None).median()
    common = curves.index.intersection(pooled.index)
    rho = float(spearmanr(curves[common], pooled[common]).statistic)
    return {
        "supported": bool(round(rho, 9) >= 0.99),
        "spearman": rho,
        "median_ap": curves.to_dict(),
    }


def x_curve_ranking__mutmut_24(runs: list[dict[str, Any]]) -> dict[str, Any]:
    """P2: the rank of the detectors by the average precision of the curves of seed 42."""
    ap: dict[str, dict[str, float]] = {}
    for run in runs:
        for method, seeds in run["runs"].items():
            for row in seeds:
                if "curve" in row:
                    ap.setdefault(method, {})[run["problem"]] = row["curve"]["average_precision"]
    curves = pd.DataFrame(ap).median()
    pooled = per_problem("metrics", "pr_auc").median()
    common = curves.index.intersection(pooled.index)
    rho = float(spearmanr(curves[common], pooled[common]).statistic)
    return {
        "supported": bool(round(rho, 9) >= 0.99),
        "spearman": rho,
        "median_ap": curves.to_dict(),
    }


def x_curve_ranking__mutmut_25(runs: list[dict[str, Any]]) -> dict[str, Any]:
    """P2: the rank of the detectors by the average precision of the curves of seed 42."""
    ap: dict[str, dict[str, float]] = {}
    for run in runs:
        for method, seeds in run["runs"].items():
            for row in seeds:
                if "curve" in row:
                    ap.setdefault(method, {})[run["problem"]] = row["curve"]["average_precision"]
    curves = pd.DataFrame(ap).median()
    pooled = per_problem(runs, "pr_auc").median()
    common = curves.index.intersection(pooled.index)
    rho = float(spearmanr(curves[common], pooled[common]).statistic)
    return {
        "supported": bool(round(rho, 9) >= 0.99),
        "spearman": rho,
        "median_ap": curves.to_dict(),
    }


def x_curve_ranking__mutmut_26(runs: list[dict[str, Any]]) -> dict[str, Any]:
    """P2: the rank of the detectors by the average precision of the curves of seed 42."""
    ap: dict[str, dict[str, float]] = {}
    for run in runs:
        for method, seeds in run["runs"].items():
            for row in seeds:
                if "curve" in row:
                    ap.setdefault(method, {})[run["problem"]] = row["curve"]["average_precision"]
    curves = pd.DataFrame(ap).median()
    pooled = per_problem(runs, "metrics", ).median()
    common = curves.index.intersection(pooled.index)
    rho = float(spearmanr(curves[common], pooled[common]).statistic)
    return {
        "supported": bool(round(rho, 9) >= 0.99),
        "spearman": rho,
        "median_ap": curves.to_dict(),
    }


def x_curve_ranking__mutmut_27(runs: list[dict[str, Any]]) -> dict[str, Any]:
    """P2: the rank of the detectors by the average precision of the curves of seed 42."""
    ap: dict[str, dict[str, float]] = {}
    for run in runs:
        for method, seeds in run["runs"].items():
            for row in seeds:
                if "curve" in row:
                    ap.setdefault(method, {})[run["problem"]] = row["curve"]["average_precision"]
    curves = pd.DataFrame(ap).median()
    pooled = per_problem(runs, "XXmetricsXX", "pr_auc").median()
    common = curves.index.intersection(pooled.index)
    rho = float(spearmanr(curves[common], pooled[common]).statistic)
    return {
        "supported": bool(round(rho, 9) >= 0.99),
        "spearman": rho,
        "median_ap": curves.to_dict(),
    }


def x_curve_ranking__mutmut_28(runs: list[dict[str, Any]]) -> dict[str, Any]:
    """P2: the rank of the detectors by the average precision of the curves of seed 42."""
    ap: dict[str, dict[str, float]] = {}
    for run in runs:
        for method, seeds in run["runs"].items():
            for row in seeds:
                if "curve" in row:
                    ap.setdefault(method, {})[run["problem"]] = row["curve"]["average_precision"]
    curves = pd.DataFrame(ap).median()
    pooled = per_problem(runs, "METRICS", "pr_auc").median()
    common = curves.index.intersection(pooled.index)
    rho = float(spearmanr(curves[common], pooled[common]).statistic)
    return {
        "supported": bool(round(rho, 9) >= 0.99),
        "spearman": rho,
        "median_ap": curves.to_dict(),
    }


def x_curve_ranking__mutmut_29(runs: list[dict[str, Any]]) -> dict[str, Any]:
    """P2: the rank of the detectors by the average precision of the curves of seed 42."""
    ap: dict[str, dict[str, float]] = {}
    for run in runs:
        for method, seeds in run["runs"].items():
            for row in seeds:
                if "curve" in row:
                    ap.setdefault(method, {})[run["problem"]] = row["curve"]["average_precision"]
    curves = pd.DataFrame(ap).median()
    pooled = per_problem(runs, "metrics", "XXpr_aucXX").median()
    common = curves.index.intersection(pooled.index)
    rho = float(spearmanr(curves[common], pooled[common]).statistic)
    return {
        "supported": bool(round(rho, 9) >= 0.99),
        "spearman": rho,
        "median_ap": curves.to_dict(),
    }


def x_curve_ranking__mutmut_30(runs: list[dict[str, Any]]) -> dict[str, Any]:
    """P2: the rank of the detectors by the average precision of the curves of seed 42."""
    ap: dict[str, dict[str, float]] = {}
    for run in runs:
        for method, seeds in run["runs"].items():
            for row in seeds:
                if "curve" in row:
                    ap.setdefault(method, {})[run["problem"]] = row["curve"]["average_precision"]
    curves = pd.DataFrame(ap).median()
    pooled = per_problem(runs, "metrics", "PR_AUC").median()
    common = curves.index.intersection(pooled.index)
    rho = float(spearmanr(curves[common], pooled[common]).statistic)
    return {
        "supported": bool(round(rho, 9) >= 0.99),
        "spearman": rho,
        "median_ap": curves.to_dict(),
    }


def x_curve_ranking__mutmut_31(runs: list[dict[str, Any]]) -> dict[str, Any]:
    """P2: the rank of the detectors by the average precision of the curves of seed 42."""
    ap: dict[str, dict[str, float]] = {}
    for run in runs:
        for method, seeds in run["runs"].items():
            for row in seeds:
                if "curve" in row:
                    ap.setdefault(method, {})[run["problem"]] = row["curve"]["average_precision"]
    curves = pd.DataFrame(ap).median()
    pooled = per_problem(runs, "metrics", "pr_auc").median()
    common = None
    rho = float(spearmanr(curves[common], pooled[common]).statistic)
    return {
        "supported": bool(round(rho, 9) >= 0.99),
        "spearman": rho,
        "median_ap": curves.to_dict(),
    }


def x_curve_ranking__mutmut_32(runs: list[dict[str, Any]]) -> dict[str, Any]:
    """P2: the rank of the detectors by the average precision of the curves of seed 42."""
    ap: dict[str, dict[str, float]] = {}
    for run in runs:
        for method, seeds in run["runs"].items():
            for row in seeds:
                if "curve" in row:
                    ap.setdefault(method, {})[run["problem"]] = row["curve"]["average_precision"]
    curves = pd.DataFrame(ap).median()
    pooled = per_problem(runs, "metrics", "pr_auc").median()
    common = curves.index.intersection(None)
    rho = float(spearmanr(curves[common], pooled[common]).statistic)
    return {
        "supported": bool(round(rho, 9) >= 0.99),
        "spearman": rho,
        "median_ap": curves.to_dict(),
    }


def x_curve_ranking__mutmut_33(runs: list[dict[str, Any]]) -> dict[str, Any]:
    """P2: the rank of the detectors by the average precision of the curves of seed 42."""
    ap: dict[str, dict[str, float]] = {}
    for run in runs:
        for method, seeds in run["runs"].items():
            for row in seeds:
                if "curve" in row:
                    ap.setdefault(method, {})[run["problem"]] = row["curve"]["average_precision"]
    curves = pd.DataFrame(ap).median()
    pooled = per_problem(runs, "metrics", "pr_auc").median()
    common = curves.index.intersection(pooled.index)
    rho = None
    return {
        "supported": bool(round(rho, 9) >= 0.99),
        "spearman": rho,
        "median_ap": curves.to_dict(),
    }


def x_curve_ranking__mutmut_34(runs: list[dict[str, Any]]) -> dict[str, Any]:
    """P2: the rank of the detectors by the average precision of the curves of seed 42."""
    ap: dict[str, dict[str, float]] = {}
    for run in runs:
        for method, seeds in run["runs"].items():
            for row in seeds:
                if "curve" in row:
                    ap.setdefault(method, {})[run["problem"]] = row["curve"]["average_precision"]
    curves = pd.DataFrame(ap).median()
    pooled = per_problem(runs, "metrics", "pr_auc").median()
    common = curves.index.intersection(pooled.index)
    rho = float(None)
    return {
        "supported": bool(round(rho, 9) >= 0.99),
        "spearman": rho,
        "median_ap": curves.to_dict(),
    }


def x_curve_ranking__mutmut_35(runs: list[dict[str, Any]]) -> dict[str, Any]:
    """P2: the rank of the detectors by the average precision of the curves of seed 42."""
    ap: dict[str, dict[str, float]] = {}
    for run in runs:
        for method, seeds in run["runs"].items():
            for row in seeds:
                if "curve" in row:
                    ap.setdefault(method, {})[run["problem"]] = row["curve"]["average_precision"]
    curves = pd.DataFrame(ap).median()
    pooled = per_problem(runs, "metrics", "pr_auc").median()
    common = curves.index.intersection(pooled.index)
    rho = float(spearmanr(None, pooled[common]).statistic)
    return {
        "supported": bool(round(rho, 9) >= 0.99),
        "spearman": rho,
        "median_ap": curves.to_dict(),
    }


def x_curve_ranking__mutmut_36(runs: list[dict[str, Any]]) -> dict[str, Any]:
    """P2: the rank of the detectors by the average precision of the curves of seed 42."""
    ap: dict[str, dict[str, float]] = {}
    for run in runs:
        for method, seeds in run["runs"].items():
            for row in seeds:
                if "curve" in row:
                    ap.setdefault(method, {})[run["problem"]] = row["curve"]["average_precision"]
    curves = pd.DataFrame(ap).median()
    pooled = per_problem(runs, "metrics", "pr_auc").median()
    common = curves.index.intersection(pooled.index)
    rho = float(spearmanr(curves[common], None).statistic)
    return {
        "supported": bool(round(rho, 9) >= 0.99),
        "spearman": rho,
        "median_ap": curves.to_dict(),
    }


def x_curve_ranking__mutmut_37(runs: list[dict[str, Any]]) -> dict[str, Any]:
    """P2: the rank of the detectors by the average precision of the curves of seed 42."""
    ap: dict[str, dict[str, float]] = {}
    for run in runs:
        for method, seeds in run["runs"].items():
            for row in seeds:
                if "curve" in row:
                    ap.setdefault(method, {})[run["problem"]] = row["curve"]["average_precision"]
    curves = pd.DataFrame(ap).median()
    pooled = per_problem(runs, "metrics", "pr_auc").median()
    common = curves.index.intersection(pooled.index)
    rho = float(spearmanr(pooled[common]).statistic)
    return {
        "supported": bool(round(rho, 9) >= 0.99),
        "spearman": rho,
        "median_ap": curves.to_dict(),
    }


def x_curve_ranking__mutmut_38(runs: list[dict[str, Any]]) -> dict[str, Any]:
    """P2: the rank of the detectors by the average precision of the curves of seed 42."""
    ap: dict[str, dict[str, float]] = {}
    for run in runs:
        for method, seeds in run["runs"].items():
            for row in seeds:
                if "curve" in row:
                    ap.setdefault(method, {})[run["problem"]] = row["curve"]["average_precision"]
    curves = pd.DataFrame(ap).median()
    pooled = per_problem(runs, "metrics", "pr_auc").median()
    common = curves.index.intersection(pooled.index)
    rho = float(spearmanr(curves[common], ).statistic)
    return {
        "supported": bool(round(rho, 9) >= 0.99),
        "spearman": rho,
        "median_ap": curves.to_dict(),
    }


def x_curve_ranking__mutmut_39(runs: list[dict[str, Any]]) -> dict[str, Any]:
    """P2: the rank of the detectors by the average precision of the curves of seed 42."""
    ap: dict[str, dict[str, float]] = {}
    for run in runs:
        for method, seeds in run["runs"].items():
            for row in seeds:
                if "curve" in row:
                    ap.setdefault(method, {})[run["problem"]] = row["curve"]["average_precision"]
    curves = pd.DataFrame(ap).median()
    pooled = per_problem(runs, "metrics", "pr_auc").median()
    common = curves.index.intersection(pooled.index)
    rho = float(spearmanr(curves[common], pooled[common]).statistic)
    return {
        "XXsupportedXX": bool(round(rho, 9) >= 0.99),
        "spearman": rho,
        "median_ap": curves.to_dict(),
    }


def x_curve_ranking__mutmut_40(runs: list[dict[str, Any]]) -> dict[str, Any]:
    """P2: the rank of the detectors by the average precision of the curves of seed 42."""
    ap: dict[str, dict[str, float]] = {}
    for run in runs:
        for method, seeds in run["runs"].items():
            for row in seeds:
                if "curve" in row:
                    ap.setdefault(method, {})[run["problem"]] = row["curve"]["average_precision"]
    curves = pd.DataFrame(ap).median()
    pooled = per_problem(runs, "metrics", "pr_auc").median()
    common = curves.index.intersection(pooled.index)
    rho = float(spearmanr(curves[common], pooled[common]).statistic)
    return {
        "SUPPORTED": bool(round(rho, 9) >= 0.99),
        "spearman": rho,
        "median_ap": curves.to_dict(),
    }


def x_curve_ranking__mutmut_41(runs: list[dict[str, Any]]) -> dict[str, Any]:
    """P2: the rank of the detectors by the average precision of the curves of seed 42."""
    ap: dict[str, dict[str, float]] = {}
    for run in runs:
        for method, seeds in run["runs"].items():
            for row in seeds:
                if "curve" in row:
                    ap.setdefault(method, {})[run["problem"]] = row["curve"]["average_precision"]
    curves = pd.DataFrame(ap).median()
    pooled = per_problem(runs, "metrics", "pr_auc").median()
    common = curves.index.intersection(pooled.index)
    rho = float(spearmanr(curves[common], pooled[common]).statistic)
    return {
        "supported": bool(None),
        "spearman": rho,
        "median_ap": curves.to_dict(),
    }


def x_curve_ranking__mutmut_42(runs: list[dict[str, Any]]) -> dict[str, Any]:
    """P2: the rank of the detectors by the average precision of the curves of seed 42."""
    ap: dict[str, dict[str, float]] = {}
    for run in runs:
        for method, seeds in run["runs"].items():
            for row in seeds:
                if "curve" in row:
                    ap.setdefault(method, {})[run["problem"]] = row["curve"]["average_precision"]
    curves = pd.DataFrame(ap).median()
    pooled = per_problem(runs, "metrics", "pr_auc").median()
    common = curves.index.intersection(pooled.index)
    rho = float(spearmanr(curves[common], pooled[common]).statistic)
    return {
        "supported": bool(round(None, 9) >= 0.99),
        "spearman": rho,
        "median_ap": curves.to_dict(),
    }


def x_curve_ranking__mutmut_43(runs: list[dict[str, Any]]) -> dict[str, Any]:
    """P2: the rank of the detectors by the average precision of the curves of seed 42."""
    ap: dict[str, dict[str, float]] = {}
    for run in runs:
        for method, seeds in run["runs"].items():
            for row in seeds:
                if "curve" in row:
                    ap.setdefault(method, {})[run["problem"]] = row["curve"]["average_precision"]
    curves = pd.DataFrame(ap).median()
    pooled = per_problem(runs, "metrics", "pr_auc").median()
    common = curves.index.intersection(pooled.index)
    rho = float(spearmanr(curves[common], pooled[common]).statistic)
    return {
        "supported": bool(round(rho, None) >= 0.99),
        "spearman": rho,
        "median_ap": curves.to_dict(),
    }


def x_curve_ranking__mutmut_44(runs: list[dict[str, Any]]) -> dict[str, Any]:
    """P2: the rank of the detectors by the average precision of the curves of seed 42."""
    ap: dict[str, dict[str, float]] = {}
    for run in runs:
        for method, seeds in run["runs"].items():
            for row in seeds:
                if "curve" in row:
                    ap.setdefault(method, {})[run["problem"]] = row["curve"]["average_precision"]
    curves = pd.DataFrame(ap).median()
    pooled = per_problem(runs, "metrics", "pr_auc").median()
    common = curves.index.intersection(pooled.index)
    rho = float(spearmanr(curves[common], pooled[common]).statistic)
    return {
        "supported": bool(round(9) >= 0.99),
        "spearman": rho,
        "median_ap": curves.to_dict(),
    }


def x_curve_ranking__mutmut_45(runs: list[dict[str, Any]]) -> dict[str, Any]:
    """P2: the rank of the detectors by the average precision of the curves of seed 42."""
    ap: dict[str, dict[str, float]] = {}
    for run in runs:
        for method, seeds in run["runs"].items():
            for row in seeds:
                if "curve" in row:
                    ap.setdefault(method, {})[run["problem"]] = row["curve"]["average_precision"]
    curves = pd.DataFrame(ap).median()
    pooled = per_problem(runs, "metrics", "pr_auc").median()
    common = curves.index.intersection(pooled.index)
    rho = float(spearmanr(curves[common], pooled[common]).statistic)
    return {
        "supported": bool(round(rho, ) >= 0.99),
        "spearman": rho,
        "median_ap": curves.to_dict(),
    }


def x_curve_ranking__mutmut_46(runs: list[dict[str, Any]]) -> dict[str, Any]:
    """P2: the rank of the detectors by the average precision of the curves of seed 42."""
    ap: dict[str, dict[str, float]] = {}
    for run in runs:
        for method, seeds in run["runs"].items():
            for row in seeds:
                if "curve" in row:
                    ap.setdefault(method, {})[run["problem"]] = row["curve"]["average_precision"]
    curves = pd.DataFrame(ap).median()
    pooled = per_problem(runs, "metrics", "pr_auc").median()
    common = curves.index.intersection(pooled.index)
    rho = float(spearmanr(curves[common], pooled[common]).statistic)
    return {
        "supported": bool(round(rho, 10) >= 0.99),
        "spearman": rho,
        "median_ap": curves.to_dict(),
    }


def x_curve_ranking__mutmut_47(runs: list[dict[str, Any]]) -> dict[str, Any]:
    """P2: the rank of the detectors by the average precision of the curves of seed 42."""
    ap: dict[str, dict[str, float]] = {}
    for run in runs:
        for method, seeds in run["runs"].items():
            for row in seeds:
                if "curve" in row:
                    ap.setdefault(method, {})[run["problem"]] = row["curve"]["average_precision"]
    curves = pd.DataFrame(ap).median()
    pooled = per_problem(runs, "metrics", "pr_auc").median()
    common = curves.index.intersection(pooled.index)
    rho = float(spearmanr(curves[common], pooled[common]).statistic)
    return {
        "supported": bool(round(rho, 9) > 0.99),
        "spearman": rho,
        "median_ap": curves.to_dict(),
    }


def x_curve_ranking__mutmut_48(runs: list[dict[str, Any]]) -> dict[str, Any]:
    """P2: the rank of the detectors by the average precision of the curves of seed 42."""
    ap: dict[str, dict[str, float]] = {}
    for run in runs:
        for method, seeds in run["runs"].items():
            for row in seeds:
                if "curve" in row:
                    ap.setdefault(method, {})[run["problem"]] = row["curve"]["average_precision"]
    curves = pd.DataFrame(ap).median()
    pooled = per_problem(runs, "metrics", "pr_auc").median()
    common = curves.index.intersection(pooled.index)
    rho = float(spearmanr(curves[common], pooled[common]).statistic)
    return {
        "supported": bool(round(rho, 9) >= 1.99),
        "spearman": rho,
        "median_ap": curves.to_dict(),
    }


def x_curve_ranking__mutmut_49(runs: list[dict[str, Any]]) -> dict[str, Any]:
    """P2: the rank of the detectors by the average precision of the curves of seed 42."""
    ap: dict[str, dict[str, float]] = {}
    for run in runs:
        for method, seeds in run["runs"].items():
            for row in seeds:
                if "curve" in row:
                    ap.setdefault(method, {})[run["problem"]] = row["curve"]["average_precision"]
    curves = pd.DataFrame(ap).median()
    pooled = per_problem(runs, "metrics", "pr_auc").median()
    common = curves.index.intersection(pooled.index)
    rho = float(spearmanr(curves[common], pooled[common]).statistic)
    return {
        "supported": bool(round(rho, 9) >= 0.99),
        "XXspearmanXX": rho,
        "median_ap": curves.to_dict(),
    }


def x_curve_ranking__mutmut_50(runs: list[dict[str, Any]]) -> dict[str, Any]:
    """P2: the rank of the detectors by the average precision of the curves of seed 42."""
    ap: dict[str, dict[str, float]] = {}
    for run in runs:
        for method, seeds in run["runs"].items():
            for row in seeds:
                if "curve" in row:
                    ap.setdefault(method, {})[run["problem"]] = row["curve"]["average_precision"]
    curves = pd.DataFrame(ap).median()
    pooled = per_problem(runs, "metrics", "pr_auc").median()
    common = curves.index.intersection(pooled.index)
    rho = float(spearmanr(curves[common], pooled[common]).statistic)
    return {
        "supported": bool(round(rho, 9) >= 0.99),
        "SPEARMAN": rho,
        "median_ap": curves.to_dict(),
    }


def x_curve_ranking__mutmut_51(runs: list[dict[str, Any]]) -> dict[str, Any]:
    """P2: the rank of the detectors by the average precision of the curves of seed 42."""
    ap: dict[str, dict[str, float]] = {}
    for run in runs:
        for method, seeds in run["runs"].items():
            for row in seeds:
                if "curve" in row:
                    ap.setdefault(method, {})[run["problem"]] = row["curve"]["average_precision"]
    curves = pd.DataFrame(ap).median()
    pooled = per_problem(runs, "metrics", "pr_auc").median()
    common = curves.index.intersection(pooled.index)
    rho = float(spearmanr(curves[common], pooled[common]).statistic)
    return {
        "supported": bool(round(rho, 9) >= 0.99),
        "spearman": rho,
        "XXmedian_apXX": curves.to_dict(),
    }


def x_curve_ranking__mutmut_52(runs: list[dict[str, Any]]) -> dict[str, Any]:
    """P2: the rank of the detectors by the average precision of the curves of seed 42."""
    ap: dict[str, dict[str, float]] = {}
    for run in runs:
        for method, seeds in run["runs"].items():
            for row in seeds:
                if "curve" in row:
                    ap.setdefault(method, {})[run["problem"]] = row["curve"]["average_precision"]
    curves = pd.DataFrame(ap).median()
    pooled = per_problem(runs, "metrics", "pr_auc").median()
    common = curves.index.intersection(pooled.index)
    rho = float(spearmanr(curves[common], pooled[common]).statistic)
    return {
        "supported": bool(round(rho, 9) >= 0.99),
        "spearman": rho,
        "MEDIAN_AP": curves.to_dict(),
    }

mutants_x_curve_ranking__mutmut['_mutmut_orig'] = x_curve_ranking__mutmut_orig # type: ignore # mutmut generated
mutants_x_curve_ranking__mutmut['x_curve_ranking__mutmut_1'] = x_curve_ranking__mutmut_1 # type: ignore # mutmut generated
mutants_x_curve_ranking__mutmut['x_curve_ranking__mutmut_2'] = x_curve_ranking__mutmut_2 # type: ignore # mutmut generated
mutants_x_curve_ranking__mutmut['x_curve_ranking__mutmut_3'] = x_curve_ranking__mutmut_3 # type: ignore # mutmut generated
mutants_x_curve_ranking__mutmut['x_curve_ranking__mutmut_4'] = x_curve_ranking__mutmut_4 # type: ignore # mutmut generated
mutants_x_curve_ranking__mutmut['x_curve_ranking__mutmut_5'] = x_curve_ranking__mutmut_5 # type: ignore # mutmut generated
mutants_x_curve_ranking__mutmut['x_curve_ranking__mutmut_6'] = x_curve_ranking__mutmut_6 # type: ignore # mutmut generated
mutants_x_curve_ranking__mutmut['x_curve_ranking__mutmut_7'] = x_curve_ranking__mutmut_7 # type: ignore # mutmut generated
mutants_x_curve_ranking__mutmut['x_curve_ranking__mutmut_8'] = x_curve_ranking__mutmut_8 # type: ignore # mutmut generated
mutants_x_curve_ranking__mutmut['x_curve_ranking__mutmut_9'] = x_curve_ranking__mutmut_9 # type: ignore # mutmut generated
mutants_x_curve_ranking__mutmut['x_curve_ranking__mutmut_10'] = x_curve_ranking__mutmut_10 # type: ignore # mutmut generated
mutants_x_curve_ranking__mutmut['x_curve_ranking__mutmut_11'] = x_curve_ranking__mutmut_11 # type: ignore # mutmut generated
mutants_x_curve_ranking__mutmut['x_curve_ranking__mutmut_12'] = x_curve_ranking__mutmut_12 # type: ignore # mutmut generated
mutants_x_curve_ranking__mutmut['x_curve_ranking__mutmut_13'] = x_curve_ranking__mutmut_13 # type: ignore # mutmut generated
mutants_x_curve_ranking__mutmut['x_curve_ranking__mutmut_14'] = x_curve_ranking__mutmut_14 # type: ignore # mutmut generated
mutants_x_curve_ranking__mutmut['x_curve_ranking__mutmut_15'] = x_curve_ranking__mutmut_15 # type: ignore # mutmut generated
mutants_x_curve_ranking__mutmut['x_curve_ranking__mutmut_16'] = x_curve_ranking__mutmut_16 # type: ignore # mutmut generated
mutants_x_curve_ranking__mutmut['x_curve_ranking__mutmut_17'] = x_curve_ranking__mutmut_17 # type: ignore # mutmut generated
mutants_x_curve_ranking__mutmut['x_curve_ranking__mutmut_18'] = x_curve_ranking__mutmut_18 # type: ignore # mutmut generated
mutants_x_curve_ranking__mutmut['x_curve_ranking__mutmut_19'] = x_curve_ranking__mutmut_19 # type: ignore # mutmut generated
mutants_x_curve_ranking__mutmut['x_curve_ranking__mutmut_20'] = x_curve_ranking__mutmut_20 # type: ignore # mutmut generated
mutants_x_curve_ranking__mutmut['x_curve_ranking__mutmut_21'] = x_curve_ranking__mutmut_21 # type: ignore # mutmut generated
mutants_x_curve_ranking__mutmut['x_curve_ranking__mutmut_22'] = x_curve_ranking__mutmut_22 # type: ignore # mutmut generated
mutants_x_curve_ranking__mutmut['x_curve_ranking__mutmut_23'] = x_curve_ranking__mutmut_23 # type: ignore # mutmut generated
mutants_x_curve_ranking__mutmut['x_curve_ranking__mutmut_24'] = x_curve_ranking__mutmut_24 # type: ignore # mutmut generated
mutants_x_curve_ranking__mutmut['x_curve_ranking__mutmut_25'] = x_curve_ranking__mutmut_25 # type: ignore # mutmut generated
mutants_x_curve_ranking__mutmut['x_curve_ranking__mutmut_26'] = x_curve_ranking__mutmut_26 # type: ignore # mutmut generated
mutants_x_curve_ranking__mutmut['x_curve_ranking__mutmut_27'] = x_curve_ranking__mutmut_27 # type: ignore # mutmut generated
mutants_x_curve_ranking__mutmut['x_curve_ranking__mutmut_28'] = x_curve_ranking__mutmut_28 # type: ignore # mutmut generated
mutants_x_curve_ranking__mutmut['x_curve_ranking__mutmut_29'] = x_curve_ranking__mutmut_29 # type: ignore # mutmut generated
mutants_x_curve_ranking__mutmut['x_curve_ranking__mutmut_30'] = x_curve_ranking__mutmut_30 # type: ignore # mutmut generated
mutants_x_curve_ranking__mutmut['x_curve_ranking__mutmut_31'] = x_curve_ranking__mutmut_31 # type: ignore # mutmut generated
mutants_x_curve_ranking__mutmut['x_curve_ranking__mutmut_32'] = x_curve_ranking__mutmut_32 # type: ignore # mutmut generated
mutants_x_curve_ranking__mutmut['x_curve_ranking__mutmut_33'] = x_curve_ranking__mutmut_33 # type: ignore # mutmut generated
mutants_x_curve_ranking__mutmut['x_curve_ranking__mutmut_34'] = x_curve_ranking__mutmut_34 # type: ignore # mutmut generated
mutants_x_curve_ranking__mutmut['x_curve_ranking__mutmut_35'] = x_curve_ranking__mutmut_35 # type: ignore # mutmut generated
mutants_x_curve_ranking__mutmut['x_curve_ranking__mutmut_36'] = x_curve_ranking__mutmut_36 # type: ignore # mutmut generated
mutants_x_curve_ranking__mutmut['x_curve_ranking__mutmut_37'] = x_curve_ranking__mutmut_37 # type: ignore # mutmut generated
mutants_x_curve_ranking__mutmut['x_curve_ranking__mutmut_38'] = x_curve_ranking__mutmut_38 # type: ignore # mutmut generated
mutants_x_curve_ranking__mutmut['x_curve_ranking__mutmut_39'] = x_curve_ranking__mutmut_39 # type: ignore # mutmut generated
mutants_x_curve_ranking__mutmut['x_curve_ranking__mutmut_40'] = x_curve_ranking__mutmut_40 # type: ignore # mutmut generated
mutants_x_curve_ranking__mutmut['x_curve_ranking__mutmut_41'] = x_curve_ranking__mutmut_41 # type: ignore # mutmut generated
mutants_x_curve_ranking__mutmut['x_curve_ranking__mutmut_42'] = x_curve_ranking__mutmut_42 # type: ignore # mutmut generated
mutants_x_curve_ranking__mutmut['x_curve_ranking__mutmut_43'] = x_curve_ranking__mutmut_43 # type: ignore # mutmut generated
mutants_x_curve_ranking__mutmut['x_curve_ranking__mutmut_44'] = x_curve_ranking__mutmut_44 # type: ignore # mutmut generated
mutants_x_curve_ranking__mutmut['x_curve_ranking__mutmut_45'] = x_curve_ranking__mutmut_45 # type: ignore # mutmut generated
mutants_x_curve_ranking__mutmut['x_curve_ranking__mutmut_46'] = x_curve_ranking__mutmut_46 # type: ignore # mutmut generated
mutants_x_curve_ranking__mutmut['x_curve_ranking__mutmut_47'] = x_curve_ranking__mutmut_47 # type: ignore # mutmut generated
mutants_x_curve_ranking__mutmut['x_curve_ranking__mutmut_48'] = x_curve_ranking__mutmut_48 # type: ignore # mutmut generated
mutants_x_curve_ranking__mutmut['x_curve_ranking__mutmut_49'] = x_curve_ranking__mutmut_49 # type: ignore # mutmut generated
mutants_x_curve_ranking__mutmut['x_curve_ranking__mutmut_50'] = x_curve_ranking__mutmut_50 # type: ignore # mutmut generated
mutants_x_curve_ranking__mutmut['x_curve_ranking__mutmut_51'] = x_curve_ranking__mutmut_51 # type: ignore # mutmut generated
mutants_x_curve_ranking__mutmut['x_curve_ranking__mutmut_52'] = x_curve_ranking__mutmut_52 # type: ignore # mutmut generated
mutants_x_contamination_sweep__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_contamination_sweep__mutmut)
def contamination_sweep(runs: list[dict[str, Any]]) -> dict[str, Any]:
    """Isolation Forest over the contamination grid: median precision, recall, F1, flagged share."""
    out: dict[str, dict[str, float]] = {}
    for value in GRID:
        cells = {m: [] for m in METRICS}
        for run in runs:
            seeds = run["runs"].get("isolation_forest", [])
            rows = [r["sweep"][value] for r in seeds if "sweep" in r]
            if rows:
                for m in METRICS:
                    cells[m].append(float(np.mean([r[m] for r in rows])))
        out[value] = {m: float(np.median(v)) for m, v in cells.items()}
    return out


def x_contamination_sweep__mutmut_orig(runs: list[dict[str, Any]]) -> dict[str, Any]:
    """Isolation Forest over the contamination grid: median precision, recall, F1, flagged share."""
    out: dict[str, dict[str, float]] = {}
    for value in GRID:
        cells = {m: [] for m in METRICS}
        for run in runs:
            seeds = run["runs"].get("isolation_forest", [])
            rows = [r["sweep"][value] for r in seeds if "sweep" in r]
            if rows:
                for m in METRICS:
                    cells[m].append(float(np.mean([r[m] for r in rows])))
        out[value] = {m: float(np.median(v)) for m, v in cells.items()}
    return out


def x_contamination_sweep__mutmut_1(runs: list[dict[str, Any]]) -> dict[str, Any]:
    """Isolation Forest over the contamination grid: median precision, recall, F1, flagged share."""
    out: dict[str, dict[str, float]] = None
    for value in GRID:
        cells = {m: [] for m in METRICS}
        for run in runs:
            seeds = run["runs"].get("isolation_forest", [])
            rows = [r["sweep"][value] for r in seeds if "sweep" in r]
            if rows:
                for m in METRICS:
                    cells[m].append(float(np.mean([r[m] for r in rows])))
        out[value] = {m: float(np.median(v)) for m, v in cells.items()}
    return out


def x_contamination_sweep__mutmut_2(runs: list[dict[str, Any]]) -> dict[str, Any]:
    """Isolation Forest over the contamination grid: median precision, recall, F1, flagged share."""
    out: dict[str, dict[str, float]] = {}
    for value in GRID:
        cells = None
        for run in runs:
            seeds = run["runs"].get("isolation_forest", [])
            rows = [r["sweep"][value] for r in seeds if "sweep" in r]
            if rows:
                for m in METRICS:
                    cells[m].append(float(np.mean([r[m] for r in rows])))
        out[value] = {m: float(np.median(v)) for m, v in cells.items()}
    return out


def x_contamination_sweep__mutmut_3(runs: list[dict[str, Any]]) -> dict[str, Any]:
    """Isolation Forest over the contamination grid: median precision, recall, F1, flagged share."""
    out: dict[str, dict[str, float]] = {}
    for value in GRID:
        cells = {m: [] for m in METRICS}
        for run in runs:
            seeds = None
            rows = [r["sweep"][value] for r in seeds if "sweep" in r]
            if rows:
                for m in METRICS:
                    cells[m].append(float(np.mean([r[m] for r in rows])))
        out[value] = {m: float(np.median(v)) for m, v in cells.items()}
    return out


def x_contamination_sweep__mutmut_4(runs: list[dict[str, Any]]) -> dict[str, Any]:
    """Isolation Forest over the contamination grid: median precision, recall, F1, flagged share."""
    out: dict[str, dict[str, float]] = {}
    for value in GRID:
        cells = {m: [] for m in METRICS}
        for run in runs:
            seeds = run["runs"].get(None, [])
            rows = [r["sweep"][value] for r in seeds if "sweep" in r]
            if rows:
                for m in METRICS:
                    cells[m].append(float(np.mean([r[m] for r in rows])))
        out[value] = {m: float(np.median(v)) for m, v in cells.items()}
    return out


def x_contamination_sweep__mutmut_5(runs: list[dict[str, Any]]) -> dict[str, Any]:
    """Isolation Forest over the contamination grid: median precision, recall, F1, flagged share."""
    out: dict[str, dict[str, float]] = {}
    for value in GRID:
        cells = {m: [] for m in METRICS}
        for run in runs:
            seeds = run["runs"].get("isolation_forest", None)
            rows = [r["sweep"][value] for r in seeds if "sweep" in r]
            if rows:
                for m in METRICS:
                    cells[m].append(float(np.mean([r[m] for r in rows])))
        out[value] = {m: float(np.median(v)) for m, v in cells.items()}
    return out


def x_contamination_sweep__mutmut_6(runs: list[dict[str, Any]]) -> dict[str, Any]:
    """Isolation Forest over the contamination grid: median precision, recall, F1, flagged share."""
    out: dict[str, dict[str, float]] = {}
    for value in GRID:
        cells = {m: [] for m in METRICS}
        for run in runs:
            seeds = run["runs"].get([])
            rows = [r["sweep"][value] for r in seeds if "sweep" in r]
            if rows:
                for m in METRICS:
                    cells[m].append(float(np.mean([r[m] for r in rows])))
        out[value] = {m: float(np.median(v)) for m, v in cells.items()}
    return out


def x_contamination_sweep__mutmut_7(runs: list[dict[str, Any]]) -> dict[str, Any]:
    """Isolation Forest over the contamination grid: median precision, recall, F1, flagged share."""
    out: dict[str, dict[str, float]] = {}
    for value in GRID:
        cells = {m: [] for m in METRICS}
        for run in runs:
            seeds = run["runs"].get("isolation_forest", )
            rows = [r["sweep"][value] for r in seeds if "sweep" in r]
            if rows:
                for m in METRICS:
                    cells[m].append(float(np.mean([r[m] for r in rows])))
        out[value] = {m: float(np.median(v)) for m, v in cells.items()}
    return out


def x_contamination_sweep__mutmut_8(runs: list[dict[str, Any]]) -> dict[str, Any]:
    """Isolation Forest over the contamination grid: median precision, recall, F1, flagged share."""
    out: dict[str, dict[str, float]] = {}
    for value in GRID:
        cells = {m: [] for m in METRICS}
        for run in runs:
            seeds = run["XXrunsXX"].get("isolation_forest", [])
            rows = [r["sweep"][value] for r in seeds if "sweep" in r]
            if rows:
                for m in METRICS:
                    cells[m].append(float(np.mean([r[m] for r in rows])))
        out[value] = {m: float(np.median(v)) for m, v in cells.items()}
    return out


def x_contamination_sweep__mutmut_9(runs: list[dict[str, Any]]) -> dict[str, Any]:
    """Isolation Forest over the contamination grid: median precision, recall, F1, flagged share."""
    out: dict[str, dict[str, float]] = {}
    for value in GRID:
        cells = {m: [] for m in METRICS}
        for run in runs:
            seeds = run["RUNS"].get("isolation_forest", [])
            rows = [r["sweep"][value] for r in seeds if "sweep" in r]
            if rows:
                for m in METRICS:
                    cells[m].append(float(np.mean([r[m] for r in rows])))
        out[value] = {m: float(np.median(v)) for m, v in cells.items()}
    return out


def x_contamination_sweep__mutmut_10(runs: list[dict[str, Any]]) -> dict[str, Any]:
    """Isolation Forest over the contamination grid: median precision, recall, F1, flagged share."""
    out: dict[str, dict[str, float]] = {}
    for value in GRID:
        cells = {m: [] for m in METRICS}
        for run in runs:
            seeds = run["runs"].get("XXisolation_forestXX", [])
            rows = [r["sweep"][value] for r in seeds if "sweep" in r]
            if rows:
                for m in METRICS:
                    cells[m].append(float(np.mean([r[m] for r in rows])))
        out[value] = {m: float(np.median(v)) for m, v in cells.items()}
    return out


def x_contamination_sweep__mutmut_11(runs: list[dict[str, Any]]) -> dict[str, Any]:
    """Isolation Forest over the contamination grid: median precision, recall, F1, flagged share."""
    out: dict[str, dict[str, float]] = {}
    for value in GRID:
        cells = {m: [] for m in METRICS}
        for run in runs:
            seeds = run["runs"].get("ISOLATION_FOREST", [])
            rows = [r["sweep"][value] for r in seeds if "sweep" in r]
            if rows:
                for m in METRICS:
                    cells[m].append(float(np.mean([r[m] for r in rows])))
        out[value] = {m: float(np.median(v)) for m, v in cells.items()}
    return out


def x_contamination_sweep__mutmut_12(runs: list[dict[str, Any]]) -> dict[str, Any]:
    """Isolation Forest over the contamination grid: median precision, recall, F1, flagged share."""
    out: dict[str, dict[str, float]] = {}
    for value in GRID:
        cells = {m: [] for m in METRICS}
        for run in runs:
            seeds = run["runs"].get("isolation_forest", [])
            rows = None
            if rows:
                for m in METRICS:
                    cells[m].append(float(np.mean([r[m] for r in rows])))
        out[value] = {m: float(np.median(v)) for m, v in cells.items()}
    return out


def x_contamination_sweep__mutmut_13(runs: list[dict[str, Any]]) -> dict[str, Any]:
    """Isolation Forest over the contamination grid: median precision, recall, F1, flagged share."""
    out: dict[str, dict[str, float]] = {}
    for value in GRID:
        cells = {m: [] for m in METRICS}
        for run in runs:
            seeds = run["runs"].get("isolation_forest", [])
            rows = [r["XXsweepXX"][value] for r in seeds if "sweep" in r]
            if rows:
                for m in METRICS:
                    cells[m].append(float(np.mean([r[m] for r in rows])))
        out[value] = {m: float(np.median(v)) for m, v in cells.items()}
    return out


def x_contamination_sweep__mutmut_14(runs: list[dict[str, Any]]) -> dict[str, Any]:
    """Isolation Forest over the contamination grid: median precision, recall, F1, flagged share."""
    out: dict[str, dict[str, float]] = {}
    for value in GRID:
        cells = {m: [] for m in METRICS}
        for run in runs:
            seeds = run["runs"].get("isolation_forest", [])
            rows = [r["SWEEP"][value] for r in seeds if "sweep" in r]
            if rows:
                for m in METRICS:
                    cells[m].append(float(np.mean([r[m] for r in rows])))
        out[value] = {m: float(np.median(v)) for m, v in cells.items()}
    return out


def x_contamination_sweep__mutmut_15(runs: list[dict[str, Any]]) -> dict[str, Any]:
    """Isolation Forest over the contamination grid: median precision, recall, F1, flagged share."""
    out: dict[str, dict[str, float]] = {}
    for value in GRID:
        cells = {m: [] for m in METRICS}
        for run in runs:
            seeds = run["runs"].get("isolation_forest", [])
            rows = [r["sweep"][value] for r in seeds if "XXsweepXX" in r]
            if rows:
                for m in METRICS:
                    cells[m].append(float(np.mean([r[m] for r in rows])))
        out[value] = {m: float(np.median(v)) for m, v in cells.items()}
    return out


def x_contamination_sweep__mutmut_16(runs: list[dict[str, Any]]) -> dict[str, Any]:
    """Isolation Forest over the contamination grid: median precision, recall, F1, flagged share."""
    out: dict[str, dict[str, float]] = {}
    for value in GRID:
        cells = {m: [] for m in METRICS}
        for run in runs:
            seeds = run["runs"].get("isolation_forest", [])
            rows = [r["sweep"][value] for r in seeds if "SWEEP" in r]
            if rows:
                for m in METRICS:
                    cells[m].append(float(np.mean([r[m] for r in rows])))
        out[value] = {m: float(np.median(v)) for m, v in cells.items()}
    return out


def x_contamination_sweep__mutmut_17(runs: list[dict[str, Any]]) -> dict[str, Any]:
    """Isolation Forest over the contamination grid: median precision, recall, F1, flagged share."""
    out: dict[str, dict[str, float]] = {}
    for value in GRID:
        cells = {m: [] for m in METRICS}
        for run in runs:
            seeds = run["runs"].get("isolation_forest", [])
            rows = [r["sweep"][value] for r in seeds if "sweep" not in r]
            if rows:
                for m in METRICS:
                    cells[m].append(float(np.mean([r[m] for r in rows])))
        out[value] = {m: float(np.median(v)) for m, v in cells.items()}
    return out


def x_contamination_sweep__mutmut_18(runs: list[dict[str, Any]]) -> dict[str, Any]:
    """Isolation Forest over the contamination grid: median precision, recall, F1, flagged share."""
    out: dict[str, dict[str, float]] = {}
    for value in GRID:
        cells = {m: [] for m in METRICS}
        for run in runs:
            seeds = run["runs"].get("isolation_forest", [])
            rows = [r["sweep"][value] for r in seeds if "sweep" in r]
            if rows:
                for m in METRICS:
                    cells[m].append(None)
        out[value] = {m: float(np.median(v)) for m, v in cells.items()}
    return out


def x_contamination_sweep__mutmut_19(runs: list[dict[str, Any]]) -> dict[str, Any]:
    """Isolation Forest over the contamination grid: median precision, recall, F1, flagged share."""
    out: dict[str, dict[str, float]] = {}
    for value in GRID:
        cells = {m: [] for m in METRICS}
        for run in runs:
            seeds = run["runs"].get("isolation_forest", [])
            rows = [r["sweep"][value] for r in seeds if "sweep" in r]
            if rows:
                for m in METRICS:
                    cells[m].append(float(None))
        out[value] = {m: float(np.median(v)) for m, v in cells.items()}
    return out


def x_contamination_sweep__mutmut_20(runs: list[dict[str, Any]]) -> dict[str, Any]:
    """Isolation Forest over the contamination grid: median precision, recall, F1, flagged share."""
    out: dict[str, dict[str, float]] = {}
    for value in GRID:
        cells = {m: [] for m in METRICS}
        for run in runs:
            seeds = run["runs"].get("isolation_forest", [])
            rows = [r["sweep"][value] for r in seeds if "sweep" in r]
            if rows:
                for m in METRICS:
                    cells[m].append(float(np.mean(None)))
        out[value] = {m: float(np.median(v)) for m, v in cells.items()}
    return out


def x_contamination_sweep__mutmut_21(runs: list[dict[str, Any]]) -> dict[str, Any]:
    """Isolation Forest over the contamination grid: median precision, recall, F1, flagged share."""
    out: dict[str, dict[str, float]] = {}
    for value in GRID:
        cells = {m: [] for m in METRICS}
        for run in runs:
            seeds = run["runs"].get("isolation_forest", [])
            rows = [r["sweep"][value] for r in seeds if "sweep" in r]
            if rows:
                for m in METRICS:
                    cells[m].append(float(np.mean([r[m] for r in rows])))
        out[value] = None
    return out


def x_contamination_sweep__mutmut_22(runs: list[dict[str, Any]]) -> dict[str, Any]:
    """Isolation Forest over the contamination grid: median precision, recall, F1, flagged share."""
    out: dict[str, dict[str, float]] = {}
    for value in GRID:
        cells = {m: [] for m in METRICS}
        for run in runs:
            seeds = run["runs"].get("isolation_forest", [])
            rows = [r["sweep"][value] for r in seeds if "sweep" in r]
            if rows:
                for m in METRICS:
                    cells[m].append(float(np.mean([r[m] for r in rows])))
        out[value] = {m: float(None) for m, v in cells.items()}
    return out


def x_contamination_sweep__mutmut_23(runs: list[dict[str, Any]]) -> dict[str, Any]:
    """Isolation Forest over the contamination grid: median precision, recall, F1, flagged share."""
    out: dict[str, dict[str, float]] = {}
    for value in GRID:
        cells = {m: [] for m in METRICS}
        for run in runs:
            seeds = run["runs"].get("isolation_forest", [])
            rows = [r["sweep"][value] for r in seeds if "sweep" in r]
            if rows:
                for m in METRICS:
                    cells[m].append(float(np.mean([r[m] for r in rows])))
        out[value] = {m: float(np.median(None)) for m, v in cells.items()}
    return out

mutants_x_contamination_sweep__mutmut['_mutmut_orig'] = x_contamination_sweep__mutmut_orig # type: ignore # mutmut generated
mutants_x_contamination_sweep__mutmut['x_contamination_sweep__mutmut_1'] = x_contamination_sweep__mutmut_1 # type: ignore # mutmut generated
mutants_x_contamination_sweep__mutmut['x_contamination_sweep__mutmut_2'] = x_contamination_sweep__mutmut_2 # type: ignore # mutmut generated
mutants_x_contamination_sweep__mutmut['x_contamination_sweep__mutmut_3'] = x_contamination_sweep__mutmut_3 # type: ignore # mutmut generated
mutants_x_contamination_sweep__mutmut['x_contamination_sweep__mutmut_4'] = x_contamination_sweep__mutmut_4 # type: ignore # mutmut generated
mutants_x_contamination_sweep__mutmut['x_contamination_sweep__mutmut_5'] = x_contamination_sweep__mutmut_5 # type: ignore # mutmut generated
mutants_x_contamination_sweep__mutmut['x_contamination_sweep__mutmut_6'] = x_contamination_sweep__mutmut_6 # type: ignore # mutmut generated
mutants_x_contamination_sweep__mutmut['x_contamination_sweep__mutmut_7'] = x_contamination_sweep__mutmut_7 # type: ignore # mutmut generated
mutants_x_contamination_sweep__mutmut['x_contamination_sweep__mutmut_8'] = x_contamination_sweep__mutmut_8 # type: ignore # mutmut generated
mutants_x_contamination_sweep__mutmut['x_contamination_sweep__mutmut_9'] = x_contamination_sweep__mutmut_9 # type: ignore # mutmut generated
mutants_x_contamination_sweep__mutmut['x_contamination_sweep__mutmut_10'] = x_contamination_sweep__mutmut_10 # type: ignore # mutmut generated
mutants_x_contamination_sweep__mutmut['x_contamination_sweep__mutmut_11'] = x_contamination_sweep__mutmut_11 # type: ignore # mutmut generated
mutants_x_contamination_sweep__mutmut['x_contamination_sweep__mutmut_12'] = x_contamination_sweep__mutmut_12 # type: ignore # mutmut generated
mutants_x_contamination_sweep__mutmut['x_contamination_sweep__mutmut_13'] = x_contamination_sweep__mutmut_13 # type: ignore # mutmut generated
mutants_x_contamination_sweep__mutmut['x_contamination_sweep__mutmut_14'] = x_contamination_sweep__mutmut_14 # type: ignore # mutmut generated
mutants_x_contamination_sweep__mutmut['x_contamination_sweep__mutmut_15'] = x_contamination_sweep__mutmut_15 # type: ignore # mutmut generated
mutants_x_contamination_sweep__mutmut['x_contamination_sweep__mutmut_16'] = x_contamination_sweep__mutmut_16 # type: ignore # mutmut generated
mutants_x_contamination_sweep__mutmut['x_contamination_sweep__mutmut_17'] = x_contamination_sweep__mutmut_17 # type: ignore # mutmut generated
mutants_x_contamination_sweep__mutmut['x_contamination_sweep__mutmut_18'] = x_contamination_sweep__mutmut_18 # type: ignore # mutmut generated
mutants_x_contamination_sweep__mutmut['x_contamination_sweep__mutmut_19'] = x_contamination_sweep__mutmut_19 # type: ignore # mutmut generated
mutants_x_contamination_sweep__mutmut['x_contamination_sweep__mutmut_20'] = x_contamination_sweep__mutmut_20 # type: ignore # mutmut generated
mutants_x_contamination_sweep__mutmut['x_contamination_sweep__mutmut_21'] = x_contamination_sweep__mutmut_21 # type: ignore # mutmut generated
mutants_x_contamination_sweep__mutmut['x_contamination_sweep__mutmut_22'] = x_contamination_sweep__mutmut_22 # type: ignore # mutmut generated
mutants_x_contamination_sweep__mutmut['x_contamination_sweep__mutmut_23'] = x_contamination_sweep__mutmut_23 # type: ignore # mutmut generated
mutants_x_timings__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_timings__mutmut)
def timings(runs: list[dict[str, Any]]) -> dict[str, dict[str, float]]:
    """Median detection time (fit, predict and score) over the problems, per detector."""
    rows: dict[str, list[float]] = {}
    for run in runs:
        for method, seeds in run["runs"].items():
            rows.setdefault(method, []).append(
                float(np.mean([r["fit_s"] + r["predict_s"] + r["score_s"] for r in seeds]))
            )
    return {
        m: {"median_s": float(np.median(v)), "max_s": float(np.max(v))} for m, v in rows.items()
    }


def x_timings__mutmut_orig(runs: list[dict[str, Any]]) -> dict[str, dict[str, float]]:
    """Median detection time (fit, predict and score) over the problems, per detector."""
    rows: dict[str, list[float]] = {}
    for run in runs:
        for method, seeds in run["runs"].items():
            rows.setdefault(method, []).append(
                float(np.mean([r["fit_s"] + r["predict_s"] + r["score_s"] for r in seeds]))
            )
    return {
        m: {"median_s": float(np.median(v)), "max_s": float(np.max(v))} for m, v in rows.items()
    }


def x_timings__mutmut_1(runs: list[dict[str, Any]]) -> dict[str, dict[str, float]]:
    """Median detection time (fit, predict and score) over the problems, per detector."""
    rows: dict[str, list[float]] = None
    for run in runs:
        for method, seeds in run["runs"].items():
            rows.setdefault(method, []).append(
                float(np.mean([r["fit_s"] + r["predict_s"] + r["score_s"] for r in seeds]))
            )
    return {
        m: {"median_s": float(np.median(v)), "max_s": float(np.max(v))} for m, v in rows.items()
    }


def x_timings__mutmut_2(runs: list[dict[str, Any]]) -> dict[str, dict[str, float]]:
    """Median detection time (fit, predict and score) over the problems, per detector."""
    rows: dict[str, list[float]] = {}
    for run in runs:
        for method, seeds in run["XXrunsXX"].items():
            rows.setdefault(method, []).append(
                float(np.mean([r["fit_s"] + r["predict_s"] + r["score_s"] for r in seeds]))
            )
    return {
        m: {"median_s": float(np.median(v)), "max_s": float(np.max(v))} for m, v in rows.items()
    }


def x_timings__mutmut_3(runs: list[dict[str, Any]]) -> dict[str, dict[str, float]]:
    """Median detection time (fit, predict and score) over the problems, per detector."""
    rows: dict[str, list[float]] = {}
    for run in runs:
        for method, seeds in run["RUNS"].items():
            rows.setdefault(method, []).append(
                float(np.mean([r["fit_s"] + r["predict_s"] + r["score_s"] for r in seeds]))
            )
    return {
        m: {"median_s": float(np.median(v)), "max_s": float(np.max(v))} for m, v in rows.items()
    }


def x_timings__mutmut_4(runs: list[dict[str, Any]]) -> dict[str, dict[str, float]]:
    """Median detection time (fit, predict and score) over the problems, per detector."""
    rows: dict[str, list[float]] = {}
    for run in runs:
        for method, seeds in run["runs"].items():
            rows.setdefault(method, []).append(
                None
            )
    return {
        m: {"median_s": float(np.median(v)), "max_s": float(np.max(v))} for m, v in rows.items()
    }


def x_timings__mutmut_5(runs: list[dict[str, Any]]) -> dict[str, dict[str, float]]:
    """Median detection time (fit, predict and score) over the problems, per detector."""
    rows: dict[str, list[float]] = {}
    for run in runs:
        for method, seeds in run["runs"].items():
            rows.setdefault(None, []).append(
                float(np.mean([r["fit_s"] + r["predict_s"] + r["score_s"] for r in seeds]))
            )
    return {
        m: {"median_s": float(np.median(v)), "max_s": float(np.max(v))} for m, v in rows.items()
    }


def x_timings__mutmut_6(runs: list[dict[str, Any]]) -> dict[str, dict[str, float]]:
    """Median detection time (fit, predict and score) over the problems, per detector."""
    rows: dict[str, list[float]] = {}
    for run in runs:
        for method, seeds in run["runs"].items():
            rows.setdefault(method, None).append(
                float(np.mean([r["fit_s"] + r["predict_s"] + r["score_s"] for r in seeds]))
            )
    return {
        m: {"median_s": float(np.median(v)), "max_s": float(np.max(v))} for m, v in rows.items()
    }


def x_timings__mutmut_7(runs: list[dict[str, Any]]) -> dict[str, dict[str, float]]:
    """Median detection time (fit, predict and score) over the problems, per detector."""
    rows: dict[str, list[float]] = {}
    for run in runs:
        for method, seeds in run["runs"].items():
            rows.setdefault([]).append(
                float(np.mean([r["fit_s"] + r["predict_s"] + r["score_s"] for r in seeds]))
            )
    return {
        m: {"median_s": float(np.median(v)), "max_s": float(np.max(v))} for m, v in rows.items()
    }


def x_timings__mutmut_8(runs: list[dict[str, Any]]) -> dict[str, dict[str, float]]:
    """Median detection time (fit, predict and score) over the problems, per detector."""
    rows: dict[str, list[float]] = {}
    for run in runs:
        for method, seeds in run["runs"].items():
            rows.setdefault(method, ).append(
                float(np.mean([r["fit_s"] + r["predict_s"] + r["score_s"] for r in seeds]))
            )
    return {
        m: {"median_s": float(np.median(v)), "max_s": float(np.max(v))} for m, v in rows.items()
    }


def x_timings__mutmut_9(runs: list[dict[str, Any]]) -> dict[str, dict[str, float]]:
    """Median detection time (fit, predict and score) over the problems, per detector."""
    rows: dict[str, list[float]] = {}
    for run in runs:
        for method, seeds in run["runs"].items():
            rows.setdefault(method, []).append(
                float(None)
            )
    return {
        m: {"median_s": float(np.median(v)), "max_s": float(np.max(v))} for m, v in rows.items()
    }


def x_timings__mutmut_10(runs: list[dict[str, Any]]) -> dict[str, dict[str, float]]:
    """Median detection time (fit, predict and score) over the problems, per detector."""
    rows: dict[str, list[float]] = {}
    for run in runs:
        for method, seeds in run["runs"].items():
            rows.setdefault(method, []).append(
                float(np.mean(None))
            )
    return {
        m: {"median_s": float(np.median(v)), "max_s": float(np.max(v))} for m, v in rows.items()
    }


def x_timings__mutmut_11(runs: list[dict[str, Any]]) -> dict[str, dict[str, float]]:
    """Median detection time (fit, predict and score) over the problems, per detector."""
    rows: dict[str, list[float]] = {}
    for run in runs:
        for method, seeds in run["runs"].items():
            rows.setdefault(method, []).append(
                float(np.mean([r["fit_s"] + r["predict_s"] - r["score_s"] for r in seeds]))
            )
    return {
        m: {"median_s": float(np.median(v)), "max_s": float(np.max(v))} for m, v in rows.items()
    }


def x_timings__mutmut_12(runs: list[dict[str, Any]]) -> dict[str, dict[str, float]]:
    """Median detection time (fit, predict and score) over the problems, per detector."""
    rows: dict[str, list[float]] = {}
    for run in runs:
        for method, seeds in run["runs"].items():
            rows.setdefault(method, []).append(
                float(np.mean([r["fit_s"] - r["predict_s"] + r["score_s"] for r in seeds]))
            )
    return {
        m: {"median_s": float(np.median(v)), "max_s": float(np.max(v))} for m, v in rows.items()
    }


def x_timings__mutmut_13(runs: list[dict[str, Any]]) -> dict[str, dict[str, float]]:
    """Median detection time (fit, predict and score) over the problems, per detector."""
    rows: dict[str, list[float]] = {}
    for run in runs:
        for method, seeds in run["runs"].items():
            rows.setdefault(method, []).append(
                float(np.mean([r["XXfit_sXX"] + r["predict_s"] + r["score_s"] for r in seeds]))
            )
    return {
        m: {"median_s": float(np.median(v)), "max_s": float(np.max(v))} for m, v in rows.items()
    }


def x_timings__mutmut_14(runs: list[dict[str, Any]]) -> dict[str, dict[str, float]]:
    """Median detection time (fit, predict and score) over the problems, per detector."""
    rows: dict[str, list[float]] = {}
    for run in runs:
        for method, seeds in run["runs"].items():
            rows.setdefault(method, []).append(
                float(np.mean([r["FIT_S"] + r["predict_s"] + r["score_s"] for r in seeds]))
            )
    return {
        m: {"median_s": float(np.median(v)), "max_s": float(np.max(v))} for m, v in rows.items()
    }


def x_timings__mutmut_15(runs: list[dict[str, Any]]) -> dict[str, dict[str, float]]:
    """Median detection time (fit, predict and score) over the problems, per detector."""
    rows: dict[str, list[float]] = {}
    for run in runs:
        for method, seeds in run["runs"].items():
            rows.setdefault(method, []).append(
                float(np.mean([r["fit_s"] + r["XXpredict_sXX"] + r["score_s"] for r in seeds]))
            )
    return {
        m: {"median_s": float(np.median(v)), "max_s": float(np.max(v))} for m, v in rows.items()
    }


def x_timings__mutmut_16(runs: list[dict[str, Any]]) -> dict[str, dict[str, float]]:
    """Median detection time (fit, predict and score) over the problems, per detector."""
    rows: dict[str, list[float]] = {}
    for run in runs:
        for method, seeds in run["runs"].items():
            rows.setdefault(method, []).append(
                float(np.mean([r["fit_s"] + r["PREDICT_S"] + r["score_s"] for r in seeds]))
            )
    return {
        m: {"median_s": float(np.median(v)), "max_s": float(np.max(v))} for m, v in rows.items()
    }


def x_timings__mutmut_17(runs: list[dict[str, Any]]) -> dict[str, dict[str, float]]:
    """Median detection time (fit, predict and score) over the problems, per detector."""
    rows: dict[str, list[float]] = {}
    for run in runs:
        for method, seeds in run["runs"].items():
            rows.setdefault(method, []).append(
                float(np.mean([r["fit_s"] + r["predict_s"] + r["XXscore_sXX"] for r in seeds]))
            )
    return {
        m: {"median_s": float(np.median(v)), "max_s": float(np.max(v))} for m, v in rows.items()
    }


def x_timings__mutmut_18(runs: list[dict[str, Any]]) -> dict[str, dict[str, float]]:
    """Median detection time (fit, predict and score) over the problems, per detector."""
    rows: dict[str, list[float]] = {}
    for run in runs:
        for method, seeds in run["runs"].items():
            rows.setdefault(method, []).append(
                float(np.mean([r["fit_s"] + r["predict_s"] + r["SCORE_S"] for r in seeds]))
            )
    return {
        m: {"median_s": float(np.median(v)), "max_s": float(np.max(v))} for m, v in rows.items()
    }


def x_timings__mutmut_19(runs: list[dict[str, Any]]) -> dict[str, dict[str, float]]:
    """Median detection time (fit, predict and score) over the problems, per detector."""
    rows: dict[str, list[float]] = {}
    for run in runs:
        for method, seeds in run["runs"].items():
            rows.setdefault(method, []).append(
                float(np.mean([r["fit_s"] + r["predict_s"] + r["score_s"] for r in seeds]))
            )
    return {
        m: {"XXmedian_sXX": float(np.median(v)), "max_s": float(np.max(v))} for m, v in rows.items()
    }


def x_timings__mutmut_20(runs: list[dict[str, Any]]) -> dict[str, dict[str, float]]:
    """Median detection time (fit, predict and score) over the problems, per detector."""
    rows: dict[str, list[float]] = {}
    for run in runs:
        for method, seeds in run["runs"].items():
            rows.setdefault(method, []).append(
                float(np.mean([r["fit_s"] + r["predict_s"] + r["score_s"] for r in seeds]))
            )
    return {
        m: {"MEDIAN_S": float(np.median(v)), "max_s": float(np.max(v))} for m, v in rows.items()
    }


def x_timings__mutmut_21(runs: list[dict[str, Any]]) -> dict[str, dict[str, float]]:
    """Median detection time (fit, predict and score) over the problems, per detector."""
    rows: dict[str, list[float]] = {}
    for run in runs:
        for method, seeds in run["runs"].items():
            rows.setdefault(method, []).append(
                float(np.mean([r["fit_s"] + r["predict_s"] + r["score_s"] for r in seeds]))
            )
    return {
        m: {"median_s": float(None), "max_s": float(np.max(v))} for m, v in rows.items()
    }


def x_timings__mutmut_22(runs: list[dict[str, Any]]) -> dict[str, dict[str, float]]:
    """Median detection time (fit, predict and score) over the problems, per detector."""
    rows: dict[str, list[float]] = {}
    for run in runs:
        for method, seeds in run["runs"].items():
            rows.setdefault(method, []).append(
                float(np.mean([r["fit_s"] + r["predict_s"] + r["score_s"] for r in seeds]))
            )
    return {
        m: {"median_s": float(np.median(None)), "max_s": float(np.max(v))} for m, v in rows.items()
    }


def x_timings__mutmut_23(runs: list[dict[str, Any]]) -> dict[str, dict[str, float]]:
    """Median detection time (fit, predict and score) over the problems, per detector."""
    rows: dict[str, list[float]] = {}
    for run in runs:
        for method, seeds in run["runs"].items():
            rows.setdefault(method, []).append(
                float(np.mean([r["fit_s"] + r["predict_s"] + r["score_s"] for r in seeds]))
            )
    return {
        m: {"median_s": float(np.median(v)), "XXmax_sXX": float(np.max(v))} for m, v in rows.items()
    }


def x_timings__mutmut_24(runs: list[dict[str, Any]]) -> dict[str, dict[str, float]]:
    """Median detection time (fit, predict and score) over the problems, per detector."""
    rows: dict[str, list[float]] = {}
    for run in runs:
        for method, seeds in run["runs"].items():
            rows.setdefault(method, []).append(
                float(np.mean([r["fit_s"] + r["predict_s"] + r["score_s"] for r in seeds]))
            )
    return {
        m: {"median_s": float(np.median(v)), "MAX_S": float(np.max(v))} for m, v in rows.items()
    }


def x_timings__mutmut_25(runs: list[dict[str, Any]]) -> dict[str, dict[str, float]]:
    """Median detection time (fit, predict and score) over the problems, per detector."""
    rows: dict[str, list[float]] = {}
    for run in runs:
        for method, seeds in run["runs"].items():
            rows.setdefault(method, []).append(
                float(np.mean([r["fit_s"] + r["predict_s"] + r["score_s"] for r in seeds]))
            )
    return {
        m: {"median_s": float(np.median(v)), "max_s": float(None)} for m, v in rows.items()
    }


def x_timings__mutmut_26(runs: list[dict[str, Any]]) -> dict[str, dict[str, float]]:
    """Median detection time (fit, predict and score) over the problems, per detector."""
    rows: dict[str, list[float]] = {}
    for run in runs:
        for method, seeds in run["runs"].items():
            rows.setdefault(method, []).append(
                float(np.mean([r["fit_s"] + r["predict_s"] + r["score_s"] for r in seeds]))
            )
    return {
        m: {"median_s": float(np.median(v)), "max_s": float(np.max(None))} for m, v in rows.items()
    }

mutants_x_timings__mutmut['_mutmut_orig'] = x_timings__mutmut_orig # type: ignore # mutmut generated
mutants_x_timings__mutmut['x_timings__mutmut_1'] = x_timings__mutmut_1 # type: ignore # mutmut generated
mutants_x_timings__mutmut['x_timings__mutmut_2'] = x_timings__mutmut_2 # type: ignore # mutmut generated
mutants_x_timings__mutmut['x_timings__mutmut_3'] = x_timings__mutmut_3 # type: ignore # mutmut generated
mutants_x_timings__mutmut['x_timings__mutmut_4'] = x_timings__mutmut_4 # type: ignore # mutmut generated
mutants_x_timings__mutmut['x_timings__mutmut_5'] = x_timings__mutmut_5 # type: ignore # mutmut generated
mutants_x_timings__mutmut['x_timings__mutmut_6'] = x_timings__mutmut_6 # type: ignore # mutmut generated
mutants_x_timings__mutmut['x_timings__mutmut_7'] = x_timings__mutmut_7 # type: ignore # mutmut generated
mutants_x_timings__mutmut['x_timings__mutmut_8'] = x_timings__mutmut_8 # type: ignore # mutmut generated
mutants_x_timings__mutmut['x_timings__mutmut_9'] = x_timings__mutmut_9 # type: ignore # mutmut generated
mutants_x_timings__mutmut['x_timings__mutmut_10'] = x_timings__mutmut_10 # type: ignore # mutmut generated
mutants_x_timings__mutmut['x_timings__mutmut_11'] = x_timings__mutmut_11 # type: ignore # mutmut generated
mutants_x_timings__mutmut['x_timings__mutmut_12'] = x_timings__mutmut_12 # type: ignore # mutmut generated
mutants_x_timings__mutmut['x_timings__mutmut_13'] = x_timings__mutmut_13 # type: ignore # mutmut generated
mutants_x_timings__mutmut['x_timings__mutmut_14'] = x_timings__mutmut_14 # type: ignore # mutmut generated
mutants_x_timings__mutmut['x_timings__mutmut_15'] = x_timings__mutmut_15 # type: ignore # mutmut generated
mutants_x_timings__mutmut['x_timings__mutmut_16'] = x_timings__mutmut_16 # type: ignore # mutmut generated
mutants_x_timings__mutmut['x_timings__mutmut_17'] = x_timings__mutmut_17 # type: ignore # mutmut generated
mutants_x_timings__mutmut['x_timings__mutmut_18'] = x_timings__mutmut_18 # type: ignore # mutmut generated
mutants_x_timings__mutmut['x_timings__mutmut_19'] = x_timings__mutmut_19 # type: ignore # mutmut generated
mutants_x_timings__mutmut['x_timings__mutmut_20'] = x_timings__mutmut_20 # type: ignore # mutmut generated
mutants_x_timings__mutmut['x_timings__mutmut_21'] = x_timings__mutmut_21 # type: ignore # mutmut generated
mutants_x_timings__mutmut['x_timings__mutmut_22'] = x_timings__mutmut_22 # type: ignore # mutmut generated
mutants_x_timings__mutmut['x_timings__mutmut_23'] = x_timings__mutmut_23 # type: ignore # mutmut generated
mutants_x_timings__mutmut['x_timings__mutmut_24'] = x_timings__mutmut_24 # type: ignore # mutmut generated
mutants_x_timings__mutmut['x_timings__mutmut_25'] = x_timings__mutmut_25 # type: ignore # mutmut generated
mutants_x_timings__mutmut['x_timings__mutmut_26'] = x_timings__mutmut_26 # type: ignore # mutmut generated
mutants_x_severity__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_severity__mutmut)
def severity(runs_dirs: Path | list[Path]) -> dict[str, Any]:
    """P3: median over tables of the multivariate recall at severity 4 against 0.5."""
    cells: dict[str, dict[str, list[float]]] = {}
    folders = [runs_dirs] if isinstance(runs_dirs, Path) else runs_dirs
    for path in sorted(p for folder in folders for p in folder.glob("*.json")):
        run = json.loads(path.read_text())
        for sev, payload in run["recall_by_severity"].items():
            frame = pd.DataFrame(payload["data"], payload["index"], payload["columns"])
            for method in frame.index:
                cells.setdefault(method, {}).setdefault(sev, []).append(
                    float(frame.loc[method, "multivariate_outlier"])
                )
    median = {m: {s: float(np.nanmedian(v)) for s, v in by.items()} for m, by in cells.items()}
    learned = [m for m in median if m not in {"transform_dedup", "drift"}]
    higher = [m for m in learned if median[m]["4.0"] > median[m]["0.5"]]
    return {
        "supported": bool(learned and len(higher) == len(learned)),
        "detectors": len(learned),
        "higher_at_4": len(higher),
        "median_multivariate_recall": median,
    }


def x_severity__mutmut_orig(runs_dirs: Path | list[Path]) -> dict[str, Any]:
    """P3: median over tables of the multivariate recall at severity 4 against 0.5."""
    cells: dict[str, dict[str, list[float]]] = {}
    folders = [runs_dirs] if isinstance(runs_dirs, Path) else runs_dirs
    for path in sorted(p for folder in folders for p in folder.glob("*.json")):
        run = json.loads(path.read_text())
        for sev, payload in run["recall_by_severity"].items():
            frame = pd.DataFrame(payload["data"], payload["index"], payload["columns"])
            for method in frame.index:
                cells.setdefault(method, {}).setdefault(sev, []).append(
                    float(frame.loc[method, "multivariate_outlier"])
                )
    median = {m: {s: float(np.nanmedian(v)) for s, v in by.items()} for m, by in cells.items()}
    learned = [m for m in median if m not in {"transform_dedup", "drift"}]
    higher = [m for m in learned if median[m]["4.0"] > median[m]["0.5"]]
    return {
        "supported": bool(learned and len(higher) == len(learned)),
        "detectors": len(learned),
        "higher_at_4": len(higher),
        "median_multivariate_recall": median,
    }


def x_severity__mutmut_1(runs_dirs: Path | list[Path]) -> dict[str, Any]:
    """P3: median over tables of the multivariate recall at severity 4 against 0.5."""
    cells: dict[str, dict[str, list[float]]] = None
    folders = [runs_dirs] if isinstance(runs_dirs, Path) else runs_dirs
    for path in sorted(p for folder in folders for p in folder.glob("*.json")):
        run = json.loads(path.read_text())
        for sev, payload in run["recall_by_severity"].items():
            frame = pd.DataFrame(payload["data"], payload["index"], payload["columns"])
            for method in frame.index:
                cells.setdefault(method, {}).setdefault(sev, []).append(
                    float(frame.loc[method, "multivariate_outlier"])
                )
    median = {m: {s: float(np.nanmedian(v)) for s, v in by.items()} for m, by in cells.items()}
    learned = [m for m in median if m not in {"transform_dedup", "drift"}]
    higher = [m for m in learned if median[m]["4.0"] > median[m]["0.5"]]
    return {
        "supported": bool(learned and len(higher) == len(learned)),
        "detectors": len(learned),
        "higher_at_4": len(higher),
        "median_multivariate_recall": median,
    }


def x_severity__mutmut_2(runs_dirs: Path | list[Path]) -> dict[str, Any]:
    """P3: median over tables of the multivariate recall at severity 4 against 0.5."""
    cells: dict[str, dict[str, list[float]]] = {}
    folders = None
    for path in sorted(p for folder in folders for p in folder.glob("*.json")):
        run = json.loads(path.read_text())
        for sev, payload in run["recall_by_severity"].items():
            frame = pd.DataFrame(payload["data"], payload["index"], payload["columns"])
            for method in frame.index:
                cells.setdefault(method, {}).setdefault(sev, []).append(
                    float(frame.loc[method, "multivariate_outlier"])
                )
    median = {m: {s: float(np.nanmedian(v)) for s, v in by.items()} for m, by in cells.items()}
    learned = [m for m in median if m not in {"transform_dedup", "drift"}]
    higher = [m for m in learned if median[m]["4.0"] > median[m]["0.5"]]
    return {
        "supported": bool(learned and len(higher) == len(learned)),
        "detectors": len(learned),
        "higher_at_4": len(higher),
        "median_multivariate_recall": median,
    }


def x_severity__mutmut_3(runs_dirs: Path | list[Path]) -> dict[str, Any]:
    """P3: median over tables of the multivariate recall at severity 4 against 0.5."""
    cells: dict[str, dict[str, list[float]]] = {}
    folders = [runs_dirs] if (isinstance(runs_dirs, Path)) and False else runs_dirs
    for path in sorted(p for folder in folders for p in folder.glob("*.json")):
        run = json.loads(path.read_text())
        for sev, payload in run["recall_by_severity"].items():
            frame = pd.DataFrame(payload["data"], payload["index"], payload["columns"])
            for method in frame.index:
                cells.setdefault(method, {}).setdefault(sev, []).append(
                    float(frame.loc[method, "multivariate_outlier"])
                )
    median = {m: {s: float(np.nanmedian(v)) for s, v in by.items()} for m, by in cells.items()}
    learned = [m for m in median if m not in {"transform_dedup", "drift"}]
    higher = [m for m in learned if median[m]["4.0"] > median[m]["0.5"]]
    return {
        "supported": bool(learned and len(higher) == len(learned)),
        "detectors": len(learned),
        "higher_at_4": len(higher),
        "median_multivariate_recall": median,
    }


def x_severity__mutmut_4(runs_dirs: Path | list[Path]) -> dict[str, Any]:
    """P3: median over tables of the multivariate recall at severity 4 against 0.5."""
    cells: dict[str, dict[str, list[float]]] = {}
    folders = [runs_dirs] if (isinstance(runs_dirs, Path)) or True else runs_dirs
    for path in sorted(p for folder in folders for p in folder.glob("*.json")):
        run = json.loads(path.read_text())
        for sev, payload in run["recall_by_severity"].items():
            frame = pd.DataFrame(payload["data"], payload["index"], payload["columns"])
            for method in frame.index:
                cells.setdefault(method, {}).setdefault(sev, []).append(
                    float(frame.loc[method, "multivariate_outlier"])
                )
    median = {m: {s: float(np.nanmedian(v)) for s, v in by.items()} for m, by in cells.items()}
    learned = [m for m in median if m not in {"transform_dedup", "drift"}]
    higher = [m for m in learned if median[m]["4.0"] > median[m]["0.5"]]
    return {
        "supported": bool(learned and len(higher) == len(learned)),
        "detectors": len(learned),
        "higher_at_4": len(higher),
        "median_multivariate_recall": median,
    }


def x_severity__mutmut_5(runs_dirs: Path | list[Path]) -> dict[str, Any]:
    """P3: median over tables of the multivariate recall at severity 4 against 0.5."""
    cells: dict[str, dict[str, list[float]]] = {}
    folders = [runs_dirs] if isinstance(runs_dirs, Path) else runs_dirs
    for path in sorted(None):
        run = json.loads(path.read_text())
        for sev, payload in run["recall_by_severity"].items():
            frame = pd.DataFrame(payload["data"], payload["index"], payload["columns"])
            for method in frame.index:
                cells.setdefault(method, {}).setdefault(sev, []).append(
                    float(frame.loc[method, "multivariate_outlier"])
                )
    median = {m: {s: float(np.nanmedian(v)) for s, v in by.items()} for m, by in cells.items()}
    learned = [m for m in median if m not in {"transform_dedup", "drift"}]
    higher = [m for m in learned if median[m]["4.0"] > median[m]["0.5"]]
    return {
        "supported": bool(learned and len(higher) == len(learned)),
        "detectors": len(learned),
        "higher_at_4": len(higher),
        "median_multivariate_recall": median,
    }


def x_severity__mutmut_6(runs_dirs: Path | list[Path]) -> dict[str, Any]:
    """P3: median over tables of the multivariate recall at severity 4 against 0.5."""
    cells: dict[str, dict[str, list[float]]] = {}
    folders = [runs_dirs] if isinstance(runs_dirs, Path) else runs_dirs
    for path in sorted(p for folder in folders for p in folder.glob(None)):
        run = json.loads(path.read_text())
        for sev, payload in run["recall_by_severity"].items():
            frame = pd.DataFrame(payload["data"], payload["index"], payload["columns"])
            for method in frame.index:
                cells.setdefault(method, {}).setdefault(sev, []).append(
                    float(frame.loc[method, "multivariate_outlier"])
                )
    median = {m: {s: float(np.nanmedian(v)) for s, v in by.items()} for m, by in cells.items()}
    learned = [m for m in median if m not in {"transform_dedup", "drift"}]
    higher = [m for m in learned if median[m]["4.0"] > median[m]["0.5"]]
    return {
        "supported": bool(learned and len(higher) == len(learned)),
        "detectors": len(learned),
        "higher_at_4": len(higher),
        "median_multivariate_recall": median,
    }


def x_severity__mutmut_7(runs_dirs: Path | list[Path]) -> dict[str, Any]:
    """P3: median over tables of the multivariate recall at severity 4 against 0.5."""
    cells: dict[str, dict[str, list[float]]] = {}
    folders = [runs_dirs] if isinstance(runs_dirs, Path) else runs_dirs
    for path in sorted(p for folder in folders for p in folder.glob("XX*.jsonXX")):
        run = json.loads(path.read_text())
        for sev, payload in run["recall_by_severity"].items():
            frame = pd.DataFrame(payload["data"], payload["index"], payload["columns"])
            for method in frame.index:
                cells.setdefault(method, {}).setdefault(sev, []).append(
                    float(frame.loc[method, "multivariate_outlier"])
                )
    median = {m: {s: float(np.nanmedian(v)) for s, v in by.items()} for m, by in cells.items()}
    learned = [m for m in median if m not in {"transform_dedup", "drift"}]
    higher = [m for m in learned if median[m]["4.0"] > median[m]["0.5"]]
    return {
        "supported": bool(learned and len(higher) == len(learned)),
        "detectors": len(learned),
        "higher_at_4": len(higher),
        "median_multivariate_recall": median,
    }


def x_severity__mutmut_8(runs_dirs: Path | list[Path]) -> dict[str, Any]:
    """P3: median over tables of the multivariate recall at severity 4 against 0.5."""
    cells: dict[str, dict[str, list[float]]] = {}
    folders = [runs_dirs] if isinstance(runs_dirs, Path) else runs_dirs
    for path in sorted(p for folder in folders for p in folder.glob("*.JSON")):
        run = json.loads(path.read_text())
        for sev, payload in run["recall_by_severity"].items():
            frame = pd.DataFrame(payload["data"], payload["index"], payload["columns"])
            for method in frame.index:
                cells.setdefault(method, {}).setdefault(sev, []).append(
                    float(frame.loc[method, "multivariate_outlier"])
                )
    median = {m: {s: float(np.nanmedian(v)) for s, v in by.items()} for m, by in cells.items()}
    learned = [m for m in median if m not in {"transform_dedup", "drift"}]
    higher = [m for m in learned if median[m]["4.0"] > median[m]["0.5"]]
    return {
        "supported": bool(learned and len(higher) == len(learned)),
        "detectors": len(learned),
        "higher_at_4": len(higher),
        "median_multivariate_recall": median,
    }


def x_severity__mutmut_9(runs_dirs: Path | list[Path]) -> dict[str, Any]:
    """P3: median over tables of the multivariate recall at severity 4 against 0.5."""
    cells: dict[str, dict[str, list[float]]] = {}
    folders = [runs_dirs] if isinstance(runs_dirs, Path) else runs_dirs
    for path in sorted(p for folder in folders for p in folder.glob("*.json")):
        run = None
        for sev, payload in run["recall_by_severity"].items():
            frame = pd.DataFrame(payload["data"], payload["index"], payload["columns"])
            for method in frame.index:
                cells.setdefault(method, {}).setdefault(sev, []).append(
                    float(frame.loc[method, "multivariate_outlier"])
                )
    median = {m: {s: float(np.nanmedian(v)) for s, v in by.items()} for m, by in cells.items()}
    learned = [m for m in median if m not in {"transform_dedup", "drift"}]
    higher = [m for m in learned if median[m]["4.0"] > median[m]["0.5"]]
    return {
        "supported": bool(learned and len(higher) == len(learned)),
        "detectors": len(learned),
        "higher_at_4": len(higher),
        "median_multivariate_recall": median,
    }


def x_severity__mutmut_10(runs_dirs: Path | list[Path]) -> dict[str, Any]:
    """P3: median over tables of the multivariate recall at severity 4 against 0.5."""
    cells: dict[str, dict[str, list[float]]] = {}
    folders = [runs_dirs] if isinstance(runs_dirs, Path) else runs_dirs
    for path in sorted(p for folder in folders for p in folder.glob("*.json")):
        run = json.loads(None)
        for sev, payload in run["recall_by_severity"].items():
            frame = pd.DataFrame(payload["data"], payload["index"], payload["columns"])
            for method in frame.index:
                cells.setdefault(method, {}).setdefault(sev, []).append(
                    float(frame.loc[method, "multivariate_outlier"])
                )
    median = {m: {s: float(np.nanmedian(v)) for s, v in by.items()} for m, by in cells.items()}
    learned = [m for m in median if m not in {"transform_dedup", "drift"}]
    higher = [m for m in learned if median[m]["4.0"] > median[m]["0.5"]]
    return {
        "supported": bool(learned and len(higher) == len(learned)),
        "detectors": len(learned),
        "higher_at_4": len(higher),
        "median_multivariate_recall": median,
    }


def x_severity__mutmut_11(runs_dirs: Path | list[Path]) -> dict[str, Any]:
    """P3: median over tables of the multivariate recall at severity 4 against 0.5."""
    cells: dict[str, dict[str, list[float]]] = {}
    folders = [runs_dirs] if isinstance(runs_dirs, Path) else runs_dirs
    for path in sorted(p for folder in folders for p in folder.glob("*.json")):
        run = json.loads(path.read_text())
        for sev, payload in run["XXrecall_by_severityXX"].items():
            frame = pd.DataFrame(payload["data"], payload["index"], payload["columns"])
            for method in frame.index:
                cells.setdefault(method, {}).setdefault(sev, []).append(
                    float(frame.loc[method, "multivariate_outlier"])
                )
    median = {m: {s: float(np.nanmedian(v)) for s, v in by.items()} for m, by in cells.items()}
    learned = [m for m in median if m not in {"transform_dedup", "drift"}]
    higher = [m for m in learned if median[m]["4.0"] > median[m]["0.5"]]
    return {
        "supported": bool(learned and len(higher) == len(learned)),
        "detectors": len(learned),
        "higher_at_4": len(higher),
        "median_multivariate_recall": median,
    }


def x_severity__mutmut_12(runs_dirs: Path | list[Path]) -> dict[str, Any]:
    """P3: median over tables of the multivariate recall at severity 4 against 0.5."""
    cells: dict[str, dict[str, list[float]]] = {}
    folders = [runs_dirs] if isinstance(runs_dirs, Path) else runs_dirs
    for path in sorted(p for folder in folders for p in folder.glob("*.json")):
        run = json.loads(path.read_text())
        for sev, payload in run["RECALL_BY_SEVERITY"].items():
            frame = pd.DataFrame(payload["data"], payload["index"], payload["columns"])
            for method in frame.index:
                cells.setdefault(method, {}).setdefault(sev, []).append(
                    float(frame.loc[method, "multivariate_outlier"])
                )
    median = {m: {s: float(np.nanmedian(v)) for s, v in by.items()} for m, by in cells.items()}
    learned = [m for m in median if m not in {"transform_dedup", "drift"}]
    higher = [m for m in learned if median[m]["4.0"] > median[m]["0.5"]]
    return {
        "supported": bool(learned and len(higher) == len(learned)),
        "detectors": len(learned),
        "higher_at_4": len(higher),
        "median_multivariate_recall": median,
    }


def x_severity__mutmut_13(runs_dirs: Path | list[Path]) -> dict[str, Any]:
    """P3: median over tables of the multivariate recall at severity 4 against 0.5."""
    cells: dict[str, dict[str, list[float]]] = {}
    folders = [runs_dirs] if isinstance(runs_dirs, Path) else runs_dirs
    for path in sorted(p for folder in folders for p in folder.glob("*.json")):
        run = json.loads(path.read_text())
        for sev, payload in run["recall_by_severity"].items():
            frame = None
            for method in frame.index:
                cells.setdefault(method, {}).setdefault(sev, []).append(
                    float(frame.loc[method, "multivariate_outlier"])
                )
    median = {m: {s: float(np.nanmedian(v)) for s, v in by.items()} for m, by in cells.items()}
    learned = [m for m in median if m not in {"transform_dedup", "drift"}]
    higher = [m for m in learned if median[m]["4.0"] > median[m]["0.5"]]
    return {
        "supported": bool(learned and len(higher) == len(learned)),
        "detectors": len(learned),
        "higher_at_4": len(higher),
        "median_multivariate_recall": median,
    }


def x_severity__mutmut_14(runs_dirs: Path | list[Path]) -> dict[str, Any]:
    """P3: median over tables of the multivariate recall at severity 4 against 0.5."""
    cells: dict[str, dict[str, list[float]]] = {}
    folders = [runs_dirs] if isinstance(runs_dirs, Path) else runs_dirs
    for path in sorted(p for folder in folders for p in folder.glob("*.json")):
        run = json.loads(path.read_text())
        for sev, payload in run["recall_by_severity"].items():
            frame = pd.DataFrame(None, payload["index"], payload["columns"])
            for method in frame.index:
                cells.setdefault(method, {}).setdefault(sev, []).append(
                    float(frame.loc[method, "multivariate_outlier"])
                )
    median = {m: {s: float(np.nanmedian(v)) for s, v in by.items()} for m, by in cells.items()}
    learned = [m for m in median if m not in {"transform_dedup", "drift"}]
    higher = [m for m in learned if median[m]["4.0"] > median[m]["0.5"]]
    return {
        "supported": bool(learned and len(higher) == len(learned)),
        "detectors": len(learned),
        "higher_at_4": len(higher),
        "median_multivariate_recall": median,
    }


def x_severity__mutmut_15(runs_dirs: Path | list[Path]) -> dict[str, Any]:
    """P3: median over tables of the multivariate recall at severity 4 against 0.5."""
    cells: dict[str, dict[str, list[float]]] = {}
    folders = [runs_dirs] if isinstance(runs_dirs, Path) else runs_dirs
    for path in sorted(p for folder in folders for p in folder.glob("*.json")):
        run = json.loads(path.read_text())
        for sev, payload in run["recall_by_severity"].items():
            frame = pd.DataFrame(payload["data"], None, payload["columns"])
            for method in frame.index:
                cells.setdefault(method, {}).setdefault(sev, []).append(
                    float(frame.loc[method, "multivariate_outlier"])
                )
    median = {m: {s: float(np.nanmedian(v)) for s, v in by.items()} for m, by in cells.items()}
    learned = [m for m in median if m not in {"transform_dedup", "drift"}]
    higher = [m for m in learned if median[m]["4.0"] > median[m]["0.5"]]
    return {
        "supported": bool(learned and len(higher) == len(learned)),
        "detectors": len(learned),
        "higher_at_4": len(higher),
        "median_multivariate_recall": median,
    }


def x_severity__mutmut_16(runs_dirs: Path | list[Path]) -> dict[str, Any]:
    """P3: median over tables of the multivariate recall at severity 4 against 0.5."""
    cells: dict[str, dict[str, list[float]]] = {}
    folders = [runs_dirs] if isinstance(runs_dirs, Path) else runs_dirs
    for path in sorted(p for folder in folders for p in folder.glob("*.json")):
        run = json.loads(path.read_text())
        for sev, payload in run["recall_by_severity"].items():
            frame = pd.DataFrame(payload["data"], payload["index"], None)
            for method in frame.index:
                cells.setdefault(method, {}).setdefault(sev, []).append(
                    float(frame.loc[method, "multivariate_outlier"])
                )
    median = {m: {s: float(np.nanmedian(v)) for s, v in by.items()} for m, by in cells.items()}
    learned = [m for m in median if m not in {"transform_dedup", "drift"}]
    higher = [m for m in learned if median[m]["4.0"] > median[m]["0.5"]]
    return {
        "supported": bool(learned and len(higher) == len(learned)),
        "detectors": len(learned),
        "higher_at_4": len(higher),
        "median_multivariate_recall": median,
    }


def x_severity__mutmut_17(runs_dirs: Path | list[Path]) -> dict[str, Any]:
    """P3: median over tables of the multivariate recall at severity 4 against 0.5."""
    cells: dict[str, dict[str, list[float]]] = {}
    folders = [runs_dirs] if isinstance(runs_dirs, Path) else runs_dirs
    for path in sorted(p for folder in folders for p in folder.glob("*.json")):
        run = json.loads(path.read_text())
        for sev, payload in run["recall_by_severity"].items():
            frame = pd.DataFrame(payload["index"], payload["columns"])
            for method in frame.index:
                cells.setdefault(method, {}).setdefault(sev, []).append(
                    float(frame.loc[method, "multivariate_outlier"])
                )
    median = {m: {s: float(np.nanmedian(v)) for s, v in by.items()} for m, by in cells.items()}
    learned = [m for m in median if m not in {"transform_dedup", "drift"}]
    higher = [m for m in learned if median[m]["4.0"] > median[m]["0.5"]]
    return {
        "supported": bool(learned and len(higher) == len(learned)),
        "detectors": len(learned),
        "higher_at_4": len(higher),
        "median_multivariate_recall": median,
    }


def x_severity__mutmut_18(runs_dirs: Path | list[Path]) -> dict[str, Any]:
    """P3: median over tables of the multivariate recall at severity 4 against 0.5."""
    cells: dict[str, dict[str, list[float]]] = {}
    folders = [runs_dirs] if isinstance(runs_dirs, Path) else runs_dirs
    for path in sorted(p for folder in folders for p in folder.glob("*.json")):
        run = json.loads(path.read_text())
        for sev, payload in run["recall_by_severity"].items():
            frame = pd.DataFrame(payload["data"], payload["columns"])
            for method in frame.index:
                cells.setdefault(method, {}).setdefault(sev, []).append(
                    float(frame.loc[method, "multivariate_outlier"])
                )
    median = {m: {s: float(np.nanmedian(v)) for s, v in by.items()} for m, by in cells.items()}
    learned = [m for m in median if m not in {"transform_dedup", "drift"}]
    higher = [m for m in learned if median[m]["4.0"] > median[m]["0.5"]]
    return {
        "supported": bool(learned and len(higher) == len(learned)),
        "detectors": len(learned),
        "higher_at_4": len(higher),
        "median_multivariate_recall": median,
    }


def x_severity__mutmut_19(runs_dirs: Path | list[Path]) -> dict[str, Any]:
    """P3: median over tables of the multivariate recall at severity 4 against 0.5."""
    cells: dict[str, dict[str, list[float]]] = {}
    folders = [runs_dirs] if isinstance(runs_dirs, Path) else runs_dirs
    for path in sorted(p for folder in folders for p in folder.glob("*.json")):
        run = json.loads(path.read_text())
        for sev, payload in run["recall_by_severity"].items():
            frame = pd.DataFrame(payload["data"], payload["index"], )
            for method in frame.index:
                cells.setdefault(method, {}).setdefault(sev, []).append(
                    float(frame.loc[method, "multivariate_outlier"])
                )
    median = {m: {s: float(np.nanmedian(v)) for s, v in by.items()} for m, by in cells.items()}
    learned = [m for m in median if m not in {"transform_dedup", "drift"}]
    higher = [m for m in learned if median[m]["4.0"] > median[m]["0.5"]]
    return {
        "supported": bool(learned and len(higher) == len(learned)),
        "detectors": len(learned),
        "higher_at_4": len(higher),
        "median_multivariate_recall": median,
    }


def x_severity__mutmut_20(runs_dirs: Path | list[Path]) -> dict[str, Any]:
    """P3: median over tables of the multivariate recall at severity 4 against 0.5."""
    cells: dict[str, dict[str, list[float]]] = {}
    folders = [runs_dirs] if isinstance(runs_dirs, Path) else runs_dirs
    for path in sorted(p for folder in folders for p in folder.glob("*.json")):
        run = json.loads(path.read_text())
        for sev, payload in run["recall_by_severity"].items():
            frame = pd.DataFrame(payload["XXdataXX"], payload["index"], payload["columns"])
            for method in frame.index:
                cells.setdefault(method, {}).setdefault(sev, []).append(
                    float(frame.loc[method, "multivariate_outlier"])
                )
    median = {m: {s: float(np.nanmedian(v)) for s, v in by.items()} for m, by in cells.items()}
    learned = [m for m in median if m not in {"transform_dedup", "drift"}]
    higher = [m for m in learned if median[m]["4.0"] > median[m]["0.5"]]
    return {
        "supported": bool(learned and len(higher) == len(learned)),
        "detectors": len(learned),
        "higher_at_4": len(higher),
        "median_multivariate_recall": median,
    }


def x_severity__mutmut_21(runs_dirs: Path | list[Path]) -> dict[str, Any]:
    """P3: median over tables of the multivariate recall at severity 4 against 0.5."""
    cells: dict[str, dict[str, list[float]]] = {}
    folders = [runs_dirs] if isinstance(runs_dirs, Path) else runs_dirs
    for path in sorted(p for folder in folders for p in folder.glob("*.json")):
        run = json.loads(path.read_text())
        for sev, payload in run["recall_by_severity"].items():
            frame = pd.DataFrame(payload["DATA"], payload["index"], payload["columns"])
            for method in frame.index:
                cells.setdefault(method, {}).setdefault(sev, []).append(
                    float(frame.loc[method, "multivariate_outlier"])
                )
    median = {m: {s: float(np.nanmedian(v)) for s, v in by.items()} for m, by in cells.items()}
    learned = [m for m in median if m not in {"transform_dedup", "drift"}]
    higher = [m for m in learned if median[m]["4.0"] > median[m]["0.5"]]
    return {
        "supported": bool(learned and len(higher) == len(learned)),
        "detectors": len(learned),
        "higher_at_4": len(higher),
        "median_multivariate_recall": median,
    }


def x_severity__mutmut_22(runs_dirs: Path | list[Path]) -> dict[str, Any]:
    """P3: median over tables of the multivariate recall at severity 4 against 0.5."""
    cells: dict[str, dict[str, list[float]]] = {}
    folders = [runs_dirs] if isinstance(runs_dirs, Path) else runs_dirs
    for path in sorted(p for folder in folders for p in folder.glob("*.json")):
        run = json.loads(path.read_text())
        for sev, payload in run["recall_by_severity"].items():
            frame = pd.DataFrame(payload["data"], payload["XXindexXX"], payload["columns"])
            for method in frame.index:
                cells.setdefault(method, {}).setdefault(sev, []).append(
                    float(frame.loc[method, "multivariate_outlier"])
                )
    median = {m: {s: float(np.nanmedian(v)) for s, v in by.items()} for m, by in cells.items()}
    learned = [m for m in median if m not in {"transform_dedup", "drift"}]
    higher = [m for m in learned if median[m]["4.0"] > median[m]["0.5"]]
    return {
        "supported": bool(learned and len(higher) == len(learned)),
        "detectors": len(learned),
        "higher_at_4": len(higher),
        "median_multivariate_recall": median,
    }


def x_severity__mutmut_23(runs_dirs: Path | list[Path]) -> dict[str, Any]:
    """P3: median over tables of the multivariate recall at severity 4 against 0.5."""
    cells: dict[str, dict[str, list[float]]] = {}
    folders = [runs_dirs] if isinstance(runs_dirs, Path) else runs_dirs
    for path in sorted(p for folder in folders for p in folder.glob("*.json")):
        run = json.loads(path.read_text())
        for sev, payload in run["recall_by_severity"].items():
            frame = pd.DataFrame(payload["data"], payload["INDEX"], payload["columns"])
            for method in frame.index:
                cells.setdefault(method, {}).setdefault(sev, []).append(
                    float(frame.loc[method, "multivariate_outlier"])
                )
    median = {m: {s: float(np.nanmedian(v)) for s, v in by.items()} for m, by in cells.items()}
    learned = [m for m in median if m not in {"transform_dedup", "drift"}]
    higher = [m for m in learned if median[m]["4.0"] > median[m]["0.5"]]
    return {
        "supported": bool(learned and len(higher) == len(learned)),
        "detectors": len(learned),
        "higher_at_4": len(higher),
        "median_multivariate_recall": median,
    }


def x_severity__mutmut_24(runs_dirs: Path | list[Path]) -> dict[str, Any]:
    """P3: median over tables of the multivariate recall at severity 4 against 0.5."""
    cells: dict[str, dict[str, list[float]]] = {}
    folders = [runs_dirs] if isinstance(runs_dirs, Path) else runs_dirs
    for path in sorted(p for folder in folders for p in folder.glob("*.json")):
        run = json.loads(path.read_text())
        for sev, payload in run["recall_by_severity"].items():
            frame = pd.DataFrame(payload["data"], payload["index"], payload["XXcolumnsXX"])
            for method in frame.index:
                cells.setdefault(method, {}).setdefault(sev, []).append(
                    float(frame.loc[method, "multivariate_outlier"])
                )
    median = {m: {s: float(np.nanmedian(v)) for s, v in by.items()} for m, by in cells.items()}
    learned = [m for m in median if m not in {"transform_dedup", "drift"}]
    higher = [m for m in learned if median[m]["4.0"] > median[m]["0.5"]]
    return {
        "supported": bool(learned and len(higher) == len(learned)),
        "detectors": len(learned),
        "higher_at_4": len(higher),
        "median_multivariate_recall": median,
    }


def x_severity__mutmut_25(runs_dirs: Path | list[Path]) -> dict[str, Any]:
    """P3: median over tables of the multivariate recall at severity 4 against 0.5."""
    cells: dict[str, dict[str, list[float]]] = {}
    folders = [runs_dirs] if isinstance(runs_dirs, Path) else runs_dirs
    for path in sorted(p for folder in folders for p in folder.glob("*.json")):
        run = json.loads(path.read_text())
        for sev, payload in run["recall_by_severity"].items():
            frame = pd.DataFrame(payload["data"], payload["index"], payload["COLUMNS"])
            for method in frame.index:
                cells.setdefault(method, {}).setdefault(sev, []).append(
                    float(frame.loc[method, "multivariate_outlier"])
                )
    median = {m: {s: float(np.nanmedian(v)) for s, v in by.items()} for m, by in cells.items()}
    learned = [m for m in median if m not in {"transform_dedup", "drift"}]
    higher = [m for m in learned if median[m]["4.0"] > median[m]["0.5"]]
    return {
        "supported": bool(learned and len(higher) == len(learned)),
        "detectors": len(learned),
        "higher_at_4": len(higher),
        "median_multivariate_recall": median,
    }


def x_severity__mutmut_26(runs_dirs: Path | list[Path]) -> dict[str, Any]:
    """P3: median over tables of the multivariate recall at severity 4 against 0.5."""
    cells: dict[str, dict[str, list[float]]] = {}
    folders = [runs_dirs] if isinstance(runs_dirs, Path) else runs_dirs
    for path in sorted(p for folder in folders for p in folder.glob("*.json")):
        run = json.loads(path.read_text())
        for sev, payload in run["recall_by_severity"].items():
            frame = pd.DataFrame(payload["data"], payload["index"], payload["columns"])
            for method in frame.index:
                cells.setdefault(method, {}).setdefault(sev, []).append(
                    None
                )
    median = {m: {s: float(np.nanmedian(v)) for s, v in by.items()} for m, by in cells.items()}
    learned = [m for m in median if m not in {"transform_dedup", "drift"}]
    higher = [m for m in learned if median[m]["4.0"] > median[m]["0.5"]]
    return {
        "supported": bool(learned and len(higher) == len(learned)),
        "detectors": len(learned),
        "higher_at_4": len(higher),
        "median_multivariate_recall": median,
    }


def x_severity__mutmut_27(runs_dirs: Path | list[Path]) -> dict[str, Any]:
    """P3: median over tables of the multivariate recall at severity 4 against 0.5."""
    cells: dict[str, dict[str, list[float]]] = {}
    folders = [runs_dirs] if isinstance(runs_dirs, Path) else runs_dirs
    for path in sorted(p for folder in folders for p in folder.glob("*.json")):
        run = json.loads(path.read_text())
        for sev, payload in run["recall_by_severity"].items():
            frame = pd.DataFrame(payload["data"], payload["index"], payload["columns"])
            for method in frame.index:
                cells.setdefault(method, {}).setdefault(None, []).append(
                    float(frame.loc[method, "multivariate_outlier"])
                )
    median = {m: {s: float(np.nanmedian(v)) for s, v in by.items()} for m, by in cells.items()}
    learned = [m for m in median if m not in {"transform_dedup", "drift"}]
    higher = [m for m in learned if median[m]["4.0"] > median[m]["0.5"]]
    return {
        "supported": bool(learned and len(higher) == len(learned)),
        "detectors": len(learned),
        "higher_at_4": len(higher),
        "median_multivariate_recall": median,
    }


def x_severity__mutmut_28(runs_dirs: Path | list[Path]) -> dict[str, Any]:
    """P3: median over tables of the multivariate recall at severity 4 against 0.5."""
    cells: dict[str, dict[str, list[float]]] = {}
    folders = [runs_dirs] if isinstance(runs_dirs, Path) else runs_dirs
    for path in sorted(p for folder in folders for p in folder.glob("*.json")):
        run = json.loads(path.read_text())
        for sev, payload in run["recall_by_severity"].items():
            frame = pd.DataFrame(payload["data"], payload["index"], payload["columns"])
            for method in frame.index:
                cells.setdefault(method, {}).setdefault(sev, None).append(
                    float(frame.loc[method, "multivariate_outlier"])
                )
    median = {m: {s: float(np.nanmedian(v)) for s, v in by.items()} for m, by in cells.items()}
    learned = [m for m in median if m not in {"transform_dedup", "drift"}]
    higher = [m for m in learned if median[m]["4.0"] > median[m]["0.5"]]
    return {
        "supported": bool(learned and len(higher) == len(learned)),
        "detectors": len(learned),
        "higher_at_4": len(higher),
        "median_multivariate_recall": median,
    }


def x_severity__mutmut_29(runs_dirs: Path | list[Path]) -> dict[str, Any]:
    """P3: median over tables of the multivariate recall at severity 4 against 0.5."""
    cells: dict[str, dict[str, list[float]]] = {}
    folders = [runs_dirs] if isinstance(runs_dirs, Path) else runs_dirs
    for path in sorted(p for folder in folders for p in folder.glob("*.json")):
        run = json.loads(path.read_text())
        for sev, payload in run["recall_by_severity"].items():
            frame = pd.DataFrame(payload["data"], payload["index"], payload["columns"])
            for method in frame.index:
                cells.setdefault(method, {}).setdefault([]).append(
                    float(frame.loc[method, "multivariate_outlier"])
                )
    median = {m: {s: float(np.nanmedian(v)) for s, v in by.items()} for m, by in cells.items()}
    learned = [m for m in median if m not in {"transform_dedup", "drift"}]
    higher = [m for m in learned if median[m]["4.0"] > median[m]["0.5"]]
    return {
        "supported": bool(learned and len(higher) == len(learned)),
        "detectors": len(learned),
        "higher_at_4": len(higher),
        "median_multivariate_recall": median,
    }


def x_severity__mutmut_30(runs_dirs: Path | list[Path]) -> dict[str, Any]:
    """P3: median over tables of the multivariate recall at severity 4 against 0.5."""
    cells: dict[str, dict[str, list[float]]] = {}
    folders = [runs_dirs] if isinstance(runs_dirs, Path) else runs_dirs
    for path in sorted(p for folder in folders for p in folder.glob("*.json")):
        run = json.loads(path.read_text())
        for sev, payload in run["recall_by_severity"].items():
            frame = pd.DataFrame(payload["data"], payload["index"], payload["columns"])
            for method in frame.index:
                cells.setdefault(method, {}).setdefault(sev, ).append(
                    float(frame.loc[method, "multivariate_outlier"])
                )
    median = {m: {s: float(np.nanmedian(v)) for s, v in by.items()} for m, by in cells.items()}
    learned = [m for m in median if m not in {"transform_dedup", "drift"}]
    higher = [m for m in learned if median[m]["4.0"] > median[m]["0.5"]]
    return {
        "supported": bool(learned and len(higher) == len(learned)),
        "detectors": len(learned),
        "higher_at_4": len(higher),
        "median_multivariate_recall": median,
    }


def x_severity__mutmut_31(runs_dirs: Path | list[Path]) -> dict[str, Any]:
    """P3: median over tables of the multivariate recall at severity 4 against 0.5."""
    cells: dict[str, dict[str, list[float]]] = {}
    folders = [runs_dirs] if isinstance(runs_dirs, Path) else runs_dirs
    for path in sorted(p for folder in folders for p in folder.glob("*.json")):
        run = json.loads(path.read_text())
        for sev, payload in run["recall_by_severity"].items():
            frame = pd.DataFrame(payload["data"], payload["index"], payload["columns"])
            for method in frame.index:
                cells.setdefault(None, {}).setdefault(sev, []).append(
                    float(frame.loc[method, "multivariate_outlier"])
                )
    median = {m: {s: float(np.nanmedian(v)) for s, v in by.items()} for m, by in cells.items()}
    learned = [m for m in median if m not in {"transform_dedup", "drift"}]
    higher = [m for m in learned if median[m]["4.0"] > median[m]["0.5"]]
    return {
        "supported": bool(learned and len(higher) == len(learned)),
        "detectors": len(learned),
        "higher_at_4": len(higher),
        "median_multivariate_recall": median,
    }


def x_severity__mutmut_32(runs_dirs: Path | list[Path]) -> dict[str, Any]:
    """P3: median over tables of the multivariate recall at severity 4 against 0.5."""
    cells: dict[str, dict[str, list[float]]] = {}
    folders = [runs_dirs] if isinstance(runs_dirs, Path) else runs_dirs
    for path in sorted(p for folder in folders for p in folder.glob("*.json")):
        run = json.loads(path.read_text())
        for sev, payload in run["recall_by_severity"].items():
            frame = pd.DataFrame(payload["data"], payload["index"], payload["columns"])
            for method in frame.index:
                cells.setdefault(method, None).setdefault(sev, []).append(
                    float(frame.loc[method, "multivariate_outlier"])
                )
    median = {m: {s: float(np.nanmedian(v)) for s, v in by.items()} for m, by in cells.items()}
    learned = [m for m in median if m not in {"transform_dedup", "drift"}]
    higher = [m for m in learned if median[m]["4.0"] > median[m]["0.5"]]
    return {
        "supported": bool(learned and len(higher) == len(learned)),
        "detectors": len(learned),
        "higher_at_4": len(higher),
        "median_multivariate_recall": median,
    }


def x_severity__mutmut_33(runs_dirs: Path | list[Path]) -> dict[str, Any]:
    """P3: median over tables of the multivariate recall at severity 4 against 0.5."""
    cells: dict[str, dict[str, list[float]]] = {}
    folders = [runs_dirs] if isinstance(runs_dirs, Path) else runs_dirs
    for path in sorted(p for folder in folders for p in folder.glob("*.json")):
        run = json.loads(path.read_text())
        for sev, payload in run["recall_by_severity"].items():
            frame = pd.DataFrame(payload["data"], payload["index"], payload["columns"])
            for method in frame.index:
                cells.setdefault({}).setdefault(sev, []).append(
                    float(frame.loc[method, "multivariate_outlier"])
                )
    median = {m: {s: float(np.nanmedian(v)) for s, v in by.items()} for m, by in cells.items()}
    learned = [m for m in median if m not in {"transform_dedup", "drift"}]
    higher = [m for m in learned if median[m]["4.0"] > median[m]["0.5"]]
    return {
        "supported": bool(learned and len(higher) == len(learned)),
        "detectors": len(learned),
        "higher_at_4": len(higher),
        "median_multivariate_recall": median,
    }


def x_severity__mutmut_34(runs_dirs: Path | list[Path]) -> dict[str, Any]:
    """P3: median over tables of the multivariate recall at severity 4 against 0.5."""
    cells: dict[str, dict[str, list[float]]] = {}
    folders = [runs_dirs] if isinstance(runs_dirs, Path) else runs_dirs
    for path in sorted(p for folder in folders for p in folder.glob("*.json")):
        run = json.loads(path.read_text())
        for sev, payload in run["recall_by_severity"].items():
            frame = pd.DataFrame(payload["data"], payload["index"], payload["columns"])
            for method in frame.index:
                cells.setdefault(method, ).setdefault(sev, []).append(
                    float(frame.loc[method, "multivariate_outlier"])
                )
    median = {m: {s: float(np.nanmedian(v)) for s, v in by.items()} for m, by in cells.items()}
    learned = [m for m in median if m not in {"transform_dedup", "drift"}]
    higher = [m for m in learned if median[m]["4.0"] > median[m]["0.5"]]
    return {
        "supported": bool(learned and len(higher) == len(learned)),
        "detectors": len(learned),
        "higher_at_4": len(higher),
        "median_multivariate_recall": median,
    }


def x_severity__mutmut_35(runs_dirs: Path | list[Path]) -> dict[str, Any]:
    """P3: median over tables of the multivariate recall at severity 4 against 0.5."""
    cells: dict[str, dict[str, list[float]]] = {}
    folders = [runs_dirs] if isinstance(runs_dirs, Path) else runs_dirs
    for path in sorted(p for folder in folders for p in folder.glob("*.json")):
        run = json.loads(path.read_text())
        for sev, payload in run["recall_by_severity"].items():
            frame = pd.DataFrame(payload["data"], payload["index"], payload["columns"])
            for method in frame.index:
                cells.setdefault(method, {}).setdefault(sev, []).append(
                    float(None)
                )
    median = {m: {s: float(np.nanmedian(v)) for s, v in by.items()} for m, by in cells.items()}
    learned = [m for m in median if m not in {"transform_dedup", "drift"}]
    higher = [m for m in learned if median[m]["4.0"] > median[m]["0.5"]]
    return {
        "supported": bool(learned and len(higher) == len(learned)),
        "detectors": len(learned),
        "higher_at_4": len(higher),
        "median_multivariate_recall": median,
    }


def x_severity__mutmut_36(runs_dirs: Path | list[Path]) -> dict[str, Any]:
    """P3: median over tables of the multivariate recall at severity 4 against 0.5."""
    cells: dict[str, dict[str, list[float]]] = {}
    folders = [runs_dirs] if isinstance(runs_dirs, Path) else runs_dirs
    for path in sorted(p for folder in folders for p in folder.glob("*.json")):
        run = json.loads(path.read_text())
        for sev, payload in run["recall_by_severity"].items():
            frame = pd.DataFrame(payload["data"], payload["index"], payload["columns"])
            for method in frame.index:
                cells.setdefault(method, {}).setdefault(sev, []).append(
                    float(frame.loc[method, "XXmultivariate_outlierXX"])
                )
    median = {m: {s: float(np.nanmedian(v)) for s, v in by.items()} for m, by in cells.items()}
    learned = [m for m in median if m not in {"transform_dedup", "drift"}]
    higher = [m for m in learned if median[m]["4.0"] > median[m]["0.5"]]
    return {
        "supported": bool(learned and len(higher) == len(learned)),
        "detectors": len(learned),
        "higher_at_4": len(higher),
        "median_multivariate_recall": median,
    }


def x_severity__mutmut_37(runs_dirs: Path | list[Path]) -> dict[str, Any]:
    """P3: median over tables of the multivariate recall at severity 4 against 0.5."""
    cells: dict[str, dict[str, list[float]]] = {}
    folders = [runs_dirs] if isinstance(runs_dirs, Path) else runs_dirs
    for path in sorted(p for folder in folders for p in folder.glob("*.json")):
        run = json.loads(path.read_text())
        for sev, payload in run["recall_by_severity"].items():
            frame = pd.DataFrame(payload["data"], payload["index"], payload["columns"])
            for method in frame.index:
                cells.setdefault(method, {}).setdefault(sev, []).append(
                    float(frame.loc[method, "MULTIVARIATE_OUTLIER"])
                )
    median = {m: {s: float(np.nanmedian(v)) for s, v in by.items()} for m, by in cells.items()}
    learned = [m for m in median if m not in {"transform_dedup", "drift"}]
    higher = [m for m in learned if median[m]["4.0"] > median[m]["0.5"]]
    return {
        "supported": bool(learned and len(higher) == len(learned)),
        "detectors": len(learned),
        "higher_at_4": len(higher),
        "median_multivariate_recall": median,
    }


def x_severity__mutmut_38(runs_dirs: Path | list[Path]) -> dict[str, Any]:
    """P3: median over tables of the multivariate recall at severity 4 against 0.5."""
    cells: dict[str, dict[str, list[float]]] = {}
    folders = [runs_dirs] if isinstance(runs_dirs, Path) else runs_dirs
    for path in sorted(p for folder in folders for p in folder.glob("*.json")):
        run = json.loads(path.read_text())
        for sev, payload in run["recall_by_severity"].items():
            frame = pd.DataFrame(payload["data"], payload["index"], payload["columns"])
            for method in frame.index:
                cells.setdefault(method, {}).setdefault(sev, []).append(
                    float(frame.loc[method, "multivariate_outlier"])
                )
    median = None
    learned = [m for m in median if m not in {"transform_dedup", "drift"}]
    higher = [m for m in learned if median[m]["4.0"] > median[m]["0.5"]]
    return {
        "supported": bool(learned and len(higher) == len(learned)),
        "detectors": len(learned),
        "higher_at_4": len(higher),
        "median_multivariate_recall": median,
    }


def x_severity__mutmut_39(runs_dirs: Path | list[Path]) -> dict[str, Any]:
    """P3: median over tables of the multivariate recall at severity 4 against 0.5."""
    cells: dict[str, dict[str, list[float]]] = {}
    folders = [runs_dirs] if isinstance(runs_dirs, Path) else runs_dirs
    for path in sorted(p for folder in folders for p in folder.glob("*.json")):
        run = json.loads(path.read_text())
        for sev, payload in run["recall_by_severity"].items():
            frame = pd.DataFrame(payload["data"], payload["index"], payload["columns"])
            for method in frame.index:
                cells.setdefault(method, {}).setdefault(sev, []).append(
                    float(frame.loc[method, "multivariate_outlier"])
                )
    median = {m: {s: float(None) for s, v in by.items()} for m, by in cells.items()}
    learned = [m for m in median if m not in {"transform_dedup", "drift"}]
    higher = [m for m in learned if median[m]["4.0"] > median[m]["0.5"]]
    return {
        "supported": bool(learned and len(higher) == len(learned)),
        "detectors": len(learned),
        "higher_at_4": len(higher),
        "median_multivariate_recall": median,
    }


def x_severity__mutmut_40(runs_dirs: Path | list[Path]) -> dict[str, Any]:
    """P3: median over tables of the multivariate recall at severity 4 against 0.5."""
    cells: dict[str, dict[str, list[float]]] = {}
    folders = [runs_dirs] if isinstance(runs_dirs, Path) else runs_dirs
    for path in sorted(p for folder in folders for p in folder.glob("*.json")):
        run = json.loads(path.read_text())
        for sev, payload in run["recall_by_severity"].items():
            frame = pd.DataFrame(payload["data"], payload["index"], payload["columns"])
            for method in frame.index:
                cells.setdefault(method, {}).setdefault(sev, []).append(
                    float(frame.loc[method, "multivariate_outlier"])
                )
    median = {m: {s: float(np.nanmedian(None)) for s, v in by.items()} for m, by in cells.items()}
    learned = [m for m in median if m not in {"transform_dedup", "drift"}]
    higher = [m for m in learned if median[m]["4.0"] > median[m]["0.5"]]
    return {
        "supported": bool(learned and len(higher) == len(learned)),
        "detectors": len(learned),
        "higher_at_4": len(higher),
        "median_multivariate_recall": median,
    }


def x_severity__mutmut_41(runs_dirs: Path | list[Path]) -> dict[str, Any]:
    """P3: median over tables of the multivariate recall at severity 4 against 0.5."""
    cells: dict[str, dict[str, list[float]]] = {}
    folders = [runs_dirs] if isinstance(runs_dirs, Path) else runs_dirs
    for path in sorted(p for folder in folders for p in folder.glob("*.json")):
        run = json.loads(path.read_text())
        for sev, payload in run["recall_by_severity"].items():
            frame = pd.DataFrame(payload["data"], payload["index"], payload["columns"])
            for method in frame.index:
                cells.setdefault(method, {}).setdefault(sev, []).append(
                    float(frame.loc[method, "multivariate_outlier"])
                )
    median = {m: {s: float(np.nanmedian(v)) for s, v in by.items()} for m, by in cells.items()}
    learned = None
    higher = [m for m in learned if median[m]["4.0"] > median[m]["0.5"]]
    return {
        "supported": bool(learned and len(higher) == len(learned)),
        "detectors": len(learned),
        "higher_at_4": len(higher),
        "median_multivariate_recall": median,
    }


def x_severity__mutmut_42(runs_dirs: Path | list[Path]) -> dict[str, Any]:
    """P3: median over tables of the multivariate recall at severity 4 against 0.5."""
    cells: dict[str, dict[str, list[float]]] = {}
    folders = [runs_dirs] if isinstance(runs_dirs, Path) else runs_dirs
    for path in sorted(p for folder in folders for p in folder.glob("*.json")):
        run = json.loads(path.read_text())
        for sev, payload in run["recall_by_severity"].items():
            frame = pd.DataFrame(payload["data"], payload["index"], payload["columns"])
            for method in frame.index:
                cells.setdefault(method, {}).setdefault(sev, []).append(
                    float(frame.loc[method, "multivariate_outlier"])
                )
    median = {m: {s: float(np.nanmedian(v)) for s, v in by.items()} for m, by in cells.items()}
    learned = [m for m in median if m in {"transform_dedup", "drift"}]
    higher = [m for m in learned if median[m]["4.0"] > median[m]["0.5"]]
    return {
        "supported": bool(learned and len(higher) == len(learned)),
        "detectors": len(learned),
        "higher_at_4": len(higher),
        "median_multivariate_recall": median,
    }


def x_severity__mutmut_43(runs_dirs: Path | list[Path]) -> dict[str, Any]:
    """P3: median over tables of the multivariate recall at severity 4 against 0.5."""
    cells: dict[str, dict[str, list[float]]] = {}
    folders = [runs_dirs] if isinstance(runs_dirs, Path) else runs_dirs
    for path in sorted(p for folder in folders for p in folder.glob("*.json")):
        run = json.loads(path.read_text())
        for sev, payload in run["recall_by_severity"].items():
            frame = pd.DataFrame(payload["data"], payload["index"], payload["columns"])
            for method in frame.index:
                cells.setdefault(method, {}).setdefault(sev, []).append(
                    float(frame.loc[method, "multivariate_outlier"])
                )
    median = {m: {s: float(np.nanmedian(v)) for s, v in by.items()} for m, by in cells.items()}
    learned = [m for m in median if m not in {"XXtransform_dedupXX", "drift"}]
    higher = [m for m in learned if median[m]["4.0"] > median[m]["0.5"]]
    return {
        "supported": bool(learned and len(higher) == len(learned)),
        "detectors": len(learned),
        "higher_at_4": len(higher),
        "median_multivariate_recall": median,
    }


def x_severity__mutmut_44(runs_dirs: Path | list[Path]) -> dict[str, Any]:
    """P3: median over tables of the multivariate recall at severity 4 against 0.5."""
    cells: dict[str, dict[str, list[float]]] = {}
    folders = [runs_dirs] if isinstance(runs_dirs, Path) else runs_dirs
    for path in sorted(p for folder in folders for p in folder.glob("*.json")):
        run = json.loads(path.read_text())
        for sev, payload in run["recall_by_severity"].items():
            frame = pd.DataFrame(payload["data"], payload["index"], payload["columns"])
            for method in frame.index:
                cells.setdefault(method, {}).setdefault(sev, []).append(
                    float(frame.loc[method, "multivariate_outlier"])
                )
    median = {m: {s: float(np.nanmedian(v)) for s, v in by.items()} for m, by in cells.items()}
    learned = [m for m in median if m not in {"TRANSFORM_DEDUP", "drift"}]
    higher = [m for m in learned if median[m]["4.0"] > median[m]["0.5"]]
    return {
        "supported": bool(learned and len(higher) == len(learned)),
        "detectors": len(learned),
        "higher_at_4": len(higher),
        "median_multivariate_recall": median,
    }


def x_severity__mutmut_45(runs_dirs: Path | list[Path]) -> dict[str, Any]:
    """P3: median over tables of the multivariate recall at severity 4 against 0.5."""
    cells: dict[str, dict[str, list[float]]] = {}
    folders = [runs_dirs] if isinstance(runs_dirs, Path) else runs_dirs
    for path in sorted(p for folder in folders for p in folder.glob("*.json")):
        run = json.loads(path.read_text())
        for sev, payload in run["recall_by_severity"].items():
            frame = pd.DataFrame(payload["data"], payload["index"], payload["columns"])
            for method in frame.index:
                cells.setdefault(method, {}).setdefault(sev, []).append(
                    float(frame.loc[method, "multivariate_outlier"])
                )
    median = {m: {s: float(np.nanmedian(v)) for s, v in by.items()} for m, by in cells.items()}
    learned = [m for m in median if m not in {"transform_dedup", "XXdriftXX"}]
    higher = [m for m in learned if median[m]["4.0"] > median[m]["0.5"]]
    return {
        "supported": bool(learned and len(higher) == len(learned)),
        "detectors": len(learned),
        "higher_at_4": len(higher),
        "median_multivariate_recall": median,
    }


def x_severity__mutmut_46(runs_dirs: Path | list[Path]) -> dict[str, Any]:
    """P3: median over tables of the multivariate recall at severity 4 against 0.5."""
    cells: dict[str, dict[str, list[float]]] = {}
    folders = [runs_dirs] if isinstance(runs_dirs, Path) else runs_dirs
    for path in sorted(p for folder in folders for p in folder.glob("*.json")):
        run = json.loads(path.read_text())
        for sev, payload in run["recall_by_severity"].items():
            frame = pd.DataFrame(payload["data"], payload["index"], payload["columns"])
            for method in frame.index:
                cells.setdefault(method, {}).setdefault(sev, []).append(
                    float(frame.loc[method, "multivariate_outlier"])
                )
    median = {m: {s: float(np.nanmedian(v)) for s, v in by.items()} for m, by in cells.items()}
    learned = [m for m in median if m not in {"transform_dedup", "DRIFT"}]
    higher = [m for m in learned if median[m]["4.0"] > median[m]["0.5"]]
    return {
        "supported": bool(learned and len(higher) == len(learned)),
        "detectors": len(learned),
        "higher_at_4": len(higher),
        "median_multivariate_recall": median,
    }


def x_severity__mutmut_47(runs_dirs: Path | list[Path]) -> dict[str, Any]:
    """P3: median over tables of the multivariate recall at severity 4 against 0.5."""
    cells: dict[str, dict[str, list[float]]] = {}
    folders = [runs_dirs] if isinstance(runs_dirs, Path) else runs_dirs
    for path in sorted(p for folder in folders for p in folder.glob("*.json")):
        run = json.loads(path.read_text())
        for sev, payload in run["recall_by_severity"].items():
            frame = pd.DataFrame(payload["data"], payload["index"], payload["columns"])
            for method in frame.index:
                cells.setdefault(method, {}).setdefault(sev, []).append(
                    float(frame.loc[method, "multivariate_outlier"])
                )
    median = {m: {s: float(np.nanmedian(v)) for s, v in by.items()} for m, by in cells.items()}
    learned = [m for m in median if m not in {"transform_dedup", "drift"}]
    higher = None
    return {
        "supported": bool(learned and len(higher) == len(learned)),
        "detectors": len(learned),
        "higher_at_4": len(higher),
        "median_multivariate_recall": median,
    }


def x_severity__mutmut_48(runs_dirs: Path | list[Path]) -> dict[str, Any]:
    """P3: median over tables of the multivariate recall at severity 4 against 0.5."""
    cells: dict[str, dict[str, list[float]]] = {}
    folders = [runs_dirs] if isinstance(runs_dirs, Path) else runs_dirs
    for path in sorted(p for folder in folders for p in folder.glob("*.json")):
        run = json.loads(path.read_text())
        for sev, payload in run["recall_by_severity"].items():
            frame = pd.DataFrame(payload["data"], payload["index"], payload["columns"])
            for method in frame.index:
                cells.setdefault(method, {}).setdefault(sev, []).append(
                    float(frame.loc[method, "multivariate_outlier"])
                )
    median = {m: {s: float(np.nanmedian(v)) for s, v in by.items()} for m, by in cells.items()}
    learned = [m for m in median if m not in {"transform_dedup", "drift"}]
    higher = [m for m in learned if median[m]["XX4.0XX"] > median[m]["0.5"]]
    return {
        "supported": bool(learned and len(higher) == len(learned)),
        "detectors": len(learned),
        "higher_at_4": len(higher),
        "median_multivariate_recall": median,
    }


def x_severity__mutmut_49(runs_dirs: Path | list[Path]) -> dict[str, Any]:
    """P3: median over tables of the multivariate recall at severity 4 against 0.5."""
    cells: dict[str, dict[str, list[float]]] = {}
    folders = [runs_dirs] if isinstance(runs_dirs, Path) else runs_dirs
    for path in sorted(p for folder in folders for p in folder.glob("*.json")):
        run = json.loads(path.read_text())
        for sev, payload in run["recall_by_severity"].items():
            frame = pd.DataFrame(payload["data"], payload["index"], payload["columns"])
            for method in frame.index:
                cells.setdefault(method, {}).setdefault(sev, []).append(
                    float(frame.loc[method, "multivariate_outlier"])
                )
    median = {m: {s: float(np.nanmedian(v)) for s, v in by.items()} for m, by in cells.items()}
    learned = [m for m in median if m not in {"transform_dedup", "drift"}]
    higher = [m for m in learned if median[m]["4.0"] >= median[m]["0.5"]]
    return {
        "supported": bool(learned and len(higher) == len(learned)),
        "detectors": len(learned),
        "higher_at_4": len(higher),
        "median_multivariate_recall": median,
    }


def x_severity__mutmut_50(runs_dirs: Path | list[Path]) -> dict[str, Any]:
    """P3: median over tables of the multivariate recall at severity 4 against 0.5."""
    cells: dict[str, dict[str, list[float]]] = {}
    folders = [runs_dirs] if isinstance(runs_dirs, Path) else runs_dirs
    for path in sorted(p for folder in folders for p in folder.glob("*.json")):
        run = json.loads(path.read_text())
        for sev, payload in run["recall_by_severity"].items():
            frame = pd.DataFrame(payload["data"], payload["index"], payload["columns"])
            for method in frame.index:
                cells.setdefault(method, {}).setdefault(sev, []).append(
                    float(frame.loc[method, "multivariate_outlier"])
                )
    median = {m: {s: float(np.nanmedian(v)) for s, v in by.items()} for m, by in cells.items()}
    learned = [m for m in median if m not in {"transform_dedup", "drift"}]
    higher = [m for m in learned if median[m]["4.0"] > median[m]["XX0.5XX"]]
    return {
        "supported": bool(learned and len(higher) == len(learned)),
        "detectors": len(learned),
        "higher_at_4": len(higher),
        "median_multivariate_recall": median,
    }


def x_severity__mutmut_51(runs_dirs: Path | list[Path]) -> dict[str, Any]:
    """P3: median over tables of the multivariate recall at severity 4 against 0.5."""
    cells: dict[str, dict[str, list[float]]] = {}
    folders = [runs_dirs] if isinstance(runs_dirs, Path) else runs_dirs
    for path in sorted(p for folder in folders for p in folder.glob("*.json")):
        run = json.loads(path.read_text())
        for sev, payload in run["recall_by_severity"].items():
            frame = pd.DataFrame(payload["data"], payload["index"], payload["columns"])
            for method in frame.index:
                cells.setdefault(method, {}).setdefault(sev, []).append(
                    float(frame.loc[method, "multivariate_outlier"])
                )
    median = {m: {s: float(np.nanmedian(v)) for s, v in by.items()} for m, by in cells.items()}
    learned = [m for m in median if m not in {"transform_dedup", "drift"}]
    higher = [m for m in learned if median[m]["4.0"] > median[m]["0.5"]]
    return {
        "XXsupportedXX": bool(learned and len(higher) == len(learned)),
        "detectors": len(learned),
        "higher_at_4": len(higher),
        "median_multivariate_recall": median,
    }


def x_severity__mutmut_52(runs_dirs: Path | list[Path]) -> dict[str, Any]:
    """P3: median over tables of the multivariate recall at severity 4 against 0.5."""
    cells: dict[str, dict[str, list[float]]] = {}
    folders = [runs_dirs] if isinstance(runs_dirs, Path) else runs_dirs
    for path in sorted(p for folder in folders for p in folder.glob("*.json")):
        run = json.loads(path.read_text())
        for sev, payload in run["recall_by_severity"].items():
            frame = pd.DataFrame(payload["data"], payload["index"], payload["columns"])
            for method in frame.index:
                cells.setdefault(method, {}).setdefault(sev, []).append(
                    float(frame.loc[method, "multivariate_outlier"])
                )
    median = {m: {s: float(np.nanmedian(v)) for s, v in by.items()} for m, by in cells.items()}
    learned = [m for m in median if m not in {"transform_dedup", "drift"}]
    higher = [m for m in learned if median[m]["4.0"] > median[m]["0.5"]]
    return {
        "SUPPORTED": bool(learned and len(higher) == len(learned)),
        "detectors": len(learned),
        "higher_at_4": len(higher),
        "median_multivariate_recall": median,
    }


def x_severity__mutmut_53(runs_dirs: Path | list[Path]) -> dict[str, Any]:
    """P3: median over tables of the multivariate recall at severity 4 against 0.5."""
    cells: dict[str, dict[str, list[float]]] = {}
    folders = [runs_dirs] if isinstance(runs_dirs, Path) else runs_dirs
    for path in sorted(p for folder in folders for p in folder.glob("*.json")):
        run = json.loads(path.read_text())
        for sev, payload in run["recall_by_severity"].items():
            frame = pd.DataFrame(payload["data"], payload["index"], payload["columns"])
            for method in frame.index:
                cells.setdefault(method, {}).setdefault(sev, []).append(
                    float(frame.loc[method, "multivariate_outlier"])
                )
    median = {m: {s: float(np.nanmedian(v)) for s, v in by.items()} for m, by in cells.items()}
    learned = [m for m in median if m not in {"transform_dedup", "drift"}]
    higher = [m for m in learned if median[m]["4.0"] > median[m]["0.5"]]
    return {
        "supported": bool(None),
        "detectors": len(learned),
        "higher_at_4": len(higher),
        "median_multivariate_recall": median,
    }


def x_severity__mutmut_54(runs_dirs: Path | list[Path]) -> dict[str, Any]:
    """P3: median over tables of the multivariate recall at severity 4 against 0.5."""
    cells: dict[str, dict[str, list[float]]] = {}
    folders = [runs_dirs] if isinstance(runs_dirs, Path) else runs_dirs
    for path in sorted(p for folder in folders for p in folder.glob("*.json")):
        run = json.loads(path.read_text())
        for sev, payload in run["recall_by_severity"].items():
            frame = pd.DataFrame(payload["data"], payload["index"], payload["columns"])
            for method in frame.index:
                cells.setdefault(method, {}).setdefault(sev, []).append(
                    float(frame.loc[method, "multivariate_outlier"])
                )
    median = {m: {s: float(np.nanmedian(v)) for s, v in by.items()} for m, by in cells.items()}
    learned = [m for m in median if m not in {"transform_dedup", "drift"}]
    higher = [m for m in learned if median[m]["4.0"] > median[m]["0.5"]]
    return {
        "supported": bool(learned or len(higher) == len(learned)),
        "detectors": len(learned),
        "higher_at_4": len(higher),
        "median_multivariate_recall": median,
    }


def x_severity__mutmut_55(runs_dirs: Path | list[Path]) -> dict[str, Any]:
    """P3: median over tables of the multivariate recall at severity 4 against 0.5."""
    cells: dict[str, dict[str, list[float]]] = {}
    folders = [runs_dirs] if isinstance(runs_dirs, Path) else runs_dirs
    for path in sorted(p for folder in folders for p in folder.glob("*.json")):
        run = json.loads(path.read_text())
        for sev, payload in run["recall_by_severity"].items():
            frame = pd.DataFrame(payload["data"], payload["index"], payload["columns"])
            for method in frame.index:
                cells.setdefault(method, {}).setdefault(sev, []).append(
                    float(frame.loc[method, "multivariate_outlier"])
                )
    median = {m: {s: float(np.nanmedian(v)) for s, v in by.items()} for m, by in cells.items()}
    learned = [m for m in median if m not in {"transform_dedup", "drift"}]
    higher = [m for m in learned if median[m]["4.0"] > median[m]["0.5"]]
    return {
        "supported": bool(learned and len(higher) != len(learned)),
        "detectors": len(learned),
        "higher_at_4": len(higher),
        "median_multivariate_recall": median,
    }


def x_severity__mutmut_56(runs_dirs: Path | list[Path]) -> dict[str, Any]:
    """P3: median over tables of the multivariate recall at severity 4 against 0.5."""
    cells: dict[str, dict[str, list[float]]] = {}
    folders = [runs_dirs] if isinstance(runs_dirs, Path) else runs_dirs
    for path in sorted(p for folder in folders for p in folder.glob("*.json")):
        run = json.loads(path.read_text())
        for sev, payload in run["recall_by_severity"].items():
            frame = pd.DataFrame(payload["data"], payload["index"], payload["columns"])
            for method in frame.index:
                cells.setdefault(method, {}).setdefault(sev, []).append(
                    float(frame.loc[method, "multivariate_outlier"])
                )
    median = {m: {s: float(np.nanmedian(v)) for s, v in by.items()} for m, by in cells.items()}
    learned = [m for m in median if m not in {"transform_dedup", "drift"}]
    higher = [m for m in learned if median[m]["4.0"] > median[m]["0.5"]]
    return {
        "supported": bool(learned and len(higher) == len(learned)),
        "XXdetectorsXX": len(learned),
        "higher_at_4": len(higher),
        "median_multivariate_recall": median,
    }


def x_severity__mutmut_57(runs_dirs: Path | list[Path]) -> dict[str, Any]:
    """P3: median over tables of the multivariate recall at severity 4 against 0.5."""
    cells: dict[str, dict[str, list[float]]] = {}
    folders = [runs_dirs] if isinstance(runs_dirs, Path) else runs_dirs
    for path in sorted(p for folder in folders for p in folder.glob("*.json")):
        run = json.loads(path.read_text())
        for sev, payload in run["recall_by_severity"].items():
            frame = pd.DataFrame(payload["data"], payload["index"], payload["columns"])
            for method in frame.index:
                cells.setdefault(method, {}).setdefault(sev, []).append(
                    float(frame.loc[method, "multivariate_outlier"])
                )
    median = {m: {s: float(np.nanmedian(v)) for s, v in by.items()} for m, by in cells.items()}
    learned = [m for m in median if m not in {"transform_dedup", "drift"}]
    higher = [m for m in learned if median[m]["4.0"] > median[m]["0.5"]]
    return {
        "supported": bool(learned and len(higher) == len(learned)),
        "DETECTORS": len(learned),
        "higher_at_4": len(higher),
        "median_multivariate_recall": median,
    }


def x_severity__mutmut_58(runs_dirs: Path | list[Path]) -> dict[str, Any]:
    """P3: median over tables of the multivariate recall at severity 4 against 0.5."""
    cells: dict[str, dict[str, list[float]]] = {}
    folders = [runs_dirs] if isinstance(runs_dirs, Path) else runs_dirs
    for path in sorted(p for folder in folders for p in folder.glob("*.json")):
        run = json.loads(path.read_text())
        for sev, payload in run["recall_by_severity"].items():
            frame = pd.DataFrame(payload["data"], payload["index"], payload["columns"])
            for method in frame.index:
                cells.setdefault(method, {}).setdefault(sev, []).append(
                    float(frame.loc[method, "multivariate_outlier"])
                )
    median = {m: {s: float(np.nanmedian(v)) for s, v in by.items()} for m, by in cells.items()}
    learned = [m for m in median if m not in {"transform_dedup", "drift"}]
    higher = [m for m in learned if median[m]["4.0"] > median[m]["0.5"]]
    return {
        "supported": bool(learned and len(higher) == len(learned)),
        "detectors": len(learned),
        "XXhigher_at_4XX": len(higher),
        "median_multivariate_recall": median,
    }


def x_severity__mutmut_59(runs_dirs: Path | list[Path]) -> dict[str, Any]:
    """P3: median over tables of the multivariate recall at severity 4 against 0.5."""
    cells: dict[str, dict[str, list[float]]] = {}
    folders = [runs_dirs] if isinstance(runs_dirs, Path) else runs_dirs
    for path in sorted(p for folder in folders for p in folder.glob("*.json")):
        run = json.loads(path.read_text())
        for sev, payload in run["recall_by_severity"].items():
            frame = pd.DataFrame(payload["data"], payload["index"], payload["columns"])
            for method in frame.index:
                cells.setdefault(method, {}).setdefault(sev, []).append(
                    float(frame.loc[method, "multivariate_outlier"])
                )
    median = {m: {s: float(np.nanmedian(v)) for s, v in by.items()} for m, by in cells.items()}
    learned = [m for m in median if m not in {"transform_dedup", "drift"}]
    higher = [m for m in learned if median[m]["4.0"] > median[m]["0.5"]]
    return {
        "supported": bool(learned and len(higher) == len(learned)),
        "detectors": len(learned),
        "HIGHER_AT_4": len(higher),
        "median_multivariate_recall": median,
    }


def x_severity__mutmut_60(runs_dirs: Path | list[Path]) -> dict[str, Any]:
    """P3: median over tables of the multivariate recall at severity 4 against 0.5."""
    cells: dict[str, dict[str, list[float]]] = {}
    folders = [runs_dirs] if isinstance(runs_dirs, Path) else runs_dirs
    for path in sorted(p for folder in folders for p in folder.glob("*.json")):
        run = json.loads(path.read_text())
        for sev, payload in run["recall_by_severity"].items():
            frame = pd.DataFrame(payload["data"], payload["index"], payload["columns"])
            for method in frame.index:
                cells.setdefault(method, {}).setdefault(sev, []).append(
                    float(frame.loc[method, "multivariate_outlier"])
                )
    median = {m: {s: float(np.nanmedian(v)) for s, v in by.items()} for m, by in cells.items()}
    learned = [m for m in median if m not in {"transform_dedup", "drift"}]
    higher = [m for m in learned if median[m]["4.0"] > median[m]["0.5"]]
    return {
        "supported": bool(learned and len(higher) == len(learned)),
        "detectors": len(learned),
        "higher_at_4": len(higher),
        "XXmedian_multivariate_recallXX": median,
    }


def x_severity__mutmut_61(runs_dirs: Path | list[Path]) -> dict[str, Any]:
    """P3: median over tables of the multivariate recall at severity 4 against 0.5."""
    cells: dict[str, dict[str, list[float]]] = {}
    folders = [runs_dirs] if isinstance(runs_dirs, Path) else runs_dirs
    for path in sorted(p for folder in folders for p in folder.glob("*.json")):
        run = json.loads(path.read_text())
        for sev, payload in run["recall_by_severity"].items():
            frame = pd.DataFrame(payload["data"], payload["index"], payload["columns"])
            for method in frame.index:
                cells.setdefault(method, {}).setdefault(sev, []).append(
                    float(frame.loc[method, "multivariate_outlier"])
                )
    median = {m: {s: float(np.nanmedian(v)) for s, v in by.items()} for m, by in cells.items()}
    learned = [m for m in median if m not in {"transform_dedup", "drift"}]
    higher = [m for m in learned if median[m]["4.0"] > median[m]["0.5"]]
    return {
        "supported": bool(learned and len(higher) == len(learned)),
        "detectors": len(learned),
        "higher_at_4": len(higher),
        "MEDIAN_MULTIVARIATE_RECALL": median,
    }

mutants_x_severity__mutmut['_mutmut_orig'] = x_severity__mutmut_orig # type: ignore # mutmut generated
mutants_x_severity__mutmut['x_severity__mutmut_1'] = x_severity__mutmut_1 # type: ignore # mutmut generated
mutants_x_severity__mutmut['x_severity__mutmut_2'] = x_severity__mutmut_2 # type: ignore # mutmut generated
mutants_x_severity__mutmut['x_severity__mutmut_3'] = x_severity__mutmut_3 # type: ignore # mutmut generated
mutants_x_severity__mutmut['x_severity__mutmut_4'] = x_severity__mutmut_4 # type: ignore # mutmut generated
mutants_x_severity__mutmut['x_severity__mutmut_5'] = x_severity__mutmut_5 # type: ignore # mutmut generated
mutants_x_severity__mutmut['x_severity__mutmut_6'] = x_severity__mutmut_6 # type: ignore # mutmut generated
mutants_x_severity__mutmut['x_severity__mutmut_7'] = x_severity__mutmut_7 # type: ignore # mutmut generated
mutants_x_severity__mutmut['x_severity__mutmut_8'] = x_severity__mutmut_8 # type: ignore # mutmut generated
mutants_x_severity__mutmut['x_severity__mutmut_9'] = x_severity__mutmut_9 # type: ignore # mutmut generated
mutants_x_severity__mutmut['x_severity__mutmut_10'] = x_severity__mutmut_10 # type: ignore # mutmut generated
mutants_x_severity__mutmut['x_severity__mutmut_11'] = x_severity__mutmut_11 # type: ignore # mutmut generated
mutants_x_severity__mutmut['x_severity__mutmut_12'] = x_severity__mutmut_12 # type: ignore # mutmut generated
mutants_x_severity__mutmut['x_severity__mutmut_13'] = x_severity__mutmut_13 # type: ignore # mutmut generated
mutants_x_severity__mutmut['x_severity__mutmut_14'] = x_severity__mutmut_14 # type: ignore # mutmut generated
mutants_x_severity__mutmut['x_severity__mutmut_15'] = x_severity__mutmut_15 # type: ignore # mutmut generated
mutants_x_severity__mutmut['x_severity__mutmut_16'] = x_severity__mutmut_16 # type: ignore # mutmut generated
mutants_x_severity__mutmut['x_severity__mutmut_17'] = x_severity__mutmut_17 # type: ignore # mutmut generated
mutants_x_severity__mutmut['x_severity__mutmut_18'] = x_severity__mutmut_18 # type: ignore # mutmut generated
mutants_x_severity__mutmut['x_severity__mutmut_19'] = x_severity__mutmut_19 # type: ignore # mutmut generated
mutants_x_severity__mutmut['x_severity__mutmut_20'] = x_severity__mutmut_20 # type: ignore # mutmut generated
mutants_x_severity__mutmut['x_severity__mutmut_21'] = x_severity__mutmut_21 # type: ignore # mutmut generated
mutants_x_severity__mutmut['x_severity__mutmut_22'] = x_severity__mutmut_22 # type: ignore # mutmut generated
mutants_x_severity__mutmut['x_severity__mutmut_23'] = x_severity__mutmut_23 # type: ignore # mutmut generated
mutants_x_severity__mutmut['x_severity__mutmut_24'] = x_severity__mutmut_24 # type: ignore # mutmut generated
mutants_x_severity__mutmut['x_severity__mutmut_25'] = x_severity__mutmut_25 # type: ignore # mutmut generated
mutants_x_severity__mutmut['x_severity__mutmut_26'] = x_severity__mutmut_26 # type: ignore # mutmut generated
mutants_x_severity__mutmut['x_severity__mutmut_27'] = x_severity__mutmut_27 # type: ignore # mutmut generated
mutants_x_severity__mutmut['x_severity__mutmut_28'] = x_severity__mutmut_28 # type: ignore # mutmut generated
mutants_x_severity__mutmut['x_severity__mutmut_29'] = x_severity__mutmut_29 # type: ignore # mutmut generated
mutants_x_severity__mutmut['x_severity__mutmut_30'] = x_severity__mutmut_30 # type: ignore # mutmut generated
mutants_x_severity__mutmut['x_severity__mutmut_31'] = x_severity__mutmut_31 # type: ignore # mutmut generated
mutants_x_severity__mutmut['x_severity__mutmut_32'] = x_severity__mutmut_32 # type: ignore # mutmut generated
mutants_x_severity__mutmut['x_severity__mutmut_33'] = x_severity__mutmut_33 # type: ignore # mutmut generated
mutants_x_severity__mutmut['x_severity__mutmut_34'] = x_severity__mutmut_34 # type: ignore # mutmut generated
mutants_x_severity__mutmut['x_severity__mutmut_35'] = x_severity__mutmut_35 # type: ignore # mutmut generated
mutants_x_severity__mutmut['x_severity__mutmut_36'] = x_severity__mutmut_36 # type: ignore # mutmut generated
mutants_x_severity__mutmut['x_severity__mutmut_37'] = x_severity__mutmut_37 # type: ignore # mutmut generated
mutants_x_severity__mutmut['x_severity__mutmut_38'] = x_severity__mutmut_38 # type: ignore # mutmut generated
mutants_x_severity__mutmut['x_severity__mutmut_39'] = x_severity__mutmut_39 # type: ignore # mutmut generated
mutants_x_severity__mutmut['x_severity__mutmut_40'] = x_severity__mutmut_40 # type: ignore # mutmut generated
mutants_x_severity__mutmut['x_severity__mutmut_41'] = x_severity__mutmut_41 # type: ignore # mutmut generated
mutants_x_severity__mutmut['x_severity__mutmut_42'] = x_severity__mutmut_42 # type: ignore # mutmut generated
mutants_x_severity__mutmut['x_severity__mutmut_43'] = x_severity__mutmut_43 # type: ignore # mutmut generated
mutants_x_severity__mutmut['x_severity__mutmut_44'] = x_severity__mutmut_44 # type: ignore # mutmut generated
mutants_x_severity__mutmut['x_severity__mutmut_45'] = x_severity__mutmut_45 # type: ignore # mutmut generated
mutants_x_severity__mutmut['x_severity__mutmut_46'] = x_severity__mutmut_46 # type: ignore # mutmut generated
mutants_x_severity__mutmut['x_severity__mutmut_47'] = x_severity__mutmut_47 # type: ignore # mutmut generated
mutants_x_severity__mutmut['x_severity__mutmut_48'] = x_severity__mutmut_48 # type: ignore # mutmut generated
mutants_x_severity__mutmut['x_severity__mutmut_49'] = x_severity__mutmut_49 # type: ignore # mutmut generated
mutants_x_severity__mutmut['x_severity__mutmut_50'] = x_severity__mutmut_50 # type: ignore # mutmut generated
mutants_x_severity__mutmut['x_severity__mutmut_51'] = x_severity__mutmut_51 # type: ignore # mutmut generated
mutants_x_severity__mutmut['x_severity__mutmut_52'] = x_severity__mutmut_52 # type: ignore # mutmut generated
mutants_x_severity__mutmut['x_severity__mutmut_53'] = x_severity__mutmut_53 # type: ignore # mutmut generated
mutants_x_severity__mutmut['x_severity__mutmut_54'] = x_severity__mutmut_54 # type: ignore # mutmut generated
mutants_x_severity__mutmut['x_severity__mutmut_55'] = x_severity__mutmut_55 # type: ignore # mutmut generated
mutants_x_severity__mutmut['x_severity__mutmut_56'] = x_severity__mutmut_56 # type: ignore # mutmut generated
mutants_x_severity__mutmut['x_severity__mutmut_57'] = x_severity__mutmut_57 # type: ignore # mutmut generated
mutants_x_severity__mutmut['x_severity__mutmut_58'] = x_severity__mutmut_58 # type: ignore # mutmut generated
mutants_x_severity__mutmut['x_severity__mutmut_59'] = x_severity__mutmut_59 # type: ignore # mutmut generated
mutants_x_severity__mutmut['x_severity__mutmut_60'] = x_severity__mutmut_60 # type: ignore # mutmut generated
mutants_x_severity__mutmut['x_severity__mutmut_61'] = x_severity__mutmut_61 # type: ignore # mutmut generated
mutants_x_severity_rows__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_severity_rows__mutmut)
def severity_rows(median: dict[str, dict[str, float]], names: dict[str, str]) -> str:
    """LaTeX rows: median multivariate recall at the four severity multipliers."""
    return "\n".join(
        f"{label:<18} & "
        + " & ".join(f"{median[m][s]:.2f}" for s in ("0.5", "1.0", "2.0", "4.0"))
        + " \\\\"
        for m, label in names.items()
    )


def x_severity_rows__mutmut_orig(median: dict[str, dict[str, float]], names: dict[str, str]) -> str:
    """LaTeX rows: median multivariate recall at the four severity multipliers."""
    return "\n".join(
        f"{label:<18} & "
        + " & ".join(f"{median[m][s]:.2f}" for s in ("0.5", "1.0", "2.0", "4.0"))
        + " \\\\"
        for m, label in names.items()
    )


def x_severity_rows__mutmut_1(median: dict[str, dict[str, float]], names: dict[str, str]) -> str:
    """LaTeX rows: median multivariate recall at the four severity multipliers."""
    return "\n".join(
        None
    )


def x_severity_rows__mutmut_2(median: dict[str, dict[str, float]], names: dict[str, str]) -> str:
    """LaTeX rows: median multivariate recall at the four severity multipliers."""
    return "XX\nXX".join(
        f"{label:<18} & "
        + " & ".join(f"{median[m][s]:.2f}" for s in ("0.5", "1.0", "2.0", "4.0"))
        + " \\\\"
        for m, label in names.items()
    )


def x_severity_rows__mutmut_3(median: dict[str, dict[str, float]], names: dict[str, str]) -> str:
    """LaTeX rows: median multivariate recall at the four severity multipliers."""
    return "\n".join(
        f"{label:<18} & "
        + " & ".join(f"{median[m][s]:.2f}" for s in ("0.5", "1.0", "2.0", "4.0")) - " \\\\"
        for m, label in names.items()
    )


def x_severity_rows__mutmut_4(median: dict[str, dict[str, float]], names: dict[str, str]) -> str:
    """LaTeX rows: median multivariate recall at the four severity multipliers."""
    return "\n".join(
        f"{label:<18} & " - " & ".join(f"{median[m][s]:.2f}" for s in ("0.5", "1.0", "2.0", "4.0"))
        + " \\\\"
        for m, label in names.items()
    )


def x_severity_rows__mutmut_5(median: dict[str, dict[str, float]], names: dict[str, str]) -> str:
    """LaTeX rows: median multivariate recall at the four severity multipliers."""
    return "\n".join(
        f"{label:<18} & "
        + " & ".join(None)
        + " \\\\"
        for m, label in names.items()
    )


def x_severity_rows__mutmut_6(median: dict[str, dict[str, float]], names: dict[str, str]) -> str:
    """LaTeX rows: median multivariate recall at the four severity multipliers."""
    return "\n".join(
        f"{label:<18} & "
        + "XX & XX".join(f"{median[m][s]:.2f}" for s in ("0.5", "1.0", "2.0", "4.0"))
        + " \\\\"
        for m, label in names.items()
    )


def x_severity_rows__mutmut_7(median: dict[str, dict[str, float]], names: dict[str, str]) -> str:
    """LaTeX rows: median multivariate recall at the four severity multipliers."""
    return "\n".join(
        f"{label:<18} & "
        + " & ".join(f"{median[m][s]:.2f}" for s in ("XX0.5XX", "1.0", "2.0", "4.0"))
        + " \\\\"
        for m, label in names.items()
    )


def x_severity_rows__mutmut_8(median: dict[str, dict[str, float]], names: dict[str, str]) -> str:
    """LaTeX rows: median multivariate recall at the four severity multipliers."""
    return "\n".join(
        f"{label:<18} & "
        + " & ".join(f"{median[m][s]:.2f}" for s in ("0.5", "XX1.0XX", "2.0", "4.0"))
        + " \\\\"
        for m, label in names.items()
    )


def x_severity_rows__mutmut_9(median: dict[str, dict[str, float]], names: dict[str, str]) -> str:
    """LaTeX rows: median multivariate recall at the four severity multipliers."""
    return "\n".join(
        f"{label:<18} & "
        + " & ".join(f"{median[m][s]:.2f}" for s in ("0.5", "1.0", "XX2.0XX", "4.0"))
        + " \\\\"
        for m, label in names.items()
    )


def x_severity_rows__mutmut_10(median: dict[str, dict[str, float]], names: dict[str, str]) -> str:
    """LaTeX rows: median multivariate recall at the four severity multipliers."""
    return "\n".join(
        f"{label:<18} & "
        + " & ".join(f"{median[m][s]:.2f}" for s in ("0.5", "1.0", "2.0", "XX4.0XX"))
        + " \\\\"
        for m, label in names.items()
    )


def x_severity_rows__mutmut_11(median: dict[str, dict[str, float]], names: dict[str, str]) -> str:
    """LaTeX rows: median multivariate recall at the four severity multipliers."""
    return "\n".join(
        f"{label:<18} & "
        + " & ".join(f"{median[m][s]:.2f}" for s in ("0.5", "1.0", "2.0", "4.0"))
        + "XX \\\\XX"
        for m, label in names.items()
    )

mutants_x_severity_rows__mutmut['_mutmut_orig'] = x_severity_rows__mutmut_orig # type: ignore # mutmut generated
mutants_x_severity_rows__mutmut['x_severity_rows__mutmut_1'] = x_severity_rows__mutmut_1 # type: ignore # mutmut generated
mutants_x_severity_rows__mutmut['x_severity_rows__mutmut_2'] = x_severity_rows__mutmut_2 # type: ignore # mutmut generated
mutants_x_severity_rows__mutmut['x_severity_rows__mutmut_3'] = x_severity_rows__mutmut_3 # type: ignore # mutmut generated
mutants_x_severity_rows__mutmut['x_severity_rows__mutmut_4'] = x_severity_rows__mutmut_4 # type: ignore # mutmut generated
mutants_x_severity_rows__mutmut['x_severity_rows__mutmut_5'] = x_severity_rows__mutmut_5 # type: ignore # mutmut generated
mutants_x_severity_rows__mutmut['x_severity_rows__mutmut_6'] = x_severity_rows__mutmut_6 # type: ignore # mutmut generated
mutants_x_severity_rows__mutmut['x_severity_rows__mutmut_7'] = x_severity_rows__mutmut_7 # type: ignore # mutmut generated
mutants_x_severity_rows__mutmut['x_severity_rows__mutmut_8'] = x_severity_rows__mutmut_8 # type: ignore # mutmut generated
mutants_x_severity_rows__mutmut['x_severity_rows__mutmut_9'] = x_severity_rows__mutmut_9 # type: ignore # mutmut generated
mutants_x_severity_rows__mutmut['x_severity_rows__mutmut_10'] = x_severity_rows__mutmut_10 # type: ignore # mutmut generated
mutants_x_severity_rows__mutmut['x_severity_rows__mutmut_11'] = x_severity_rows__mutmut_11 # type: ignore # mutmut generated
mutants_x_pipeline__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_pipeline__mutmut)
def pipeline(records: list[dict[str, Any]], large: int = 50_000) -> dict[str, Any]:
    """P4: detection share of the pipeline time on the datasets above ``large`` rows."""
    ok = [r for r in records if r["status"] == "OK"]
    big = [r for r in ok if r["rows_after_transform"] > large]
    share = {
        method: [r["detect_stage_share"] for r in big if r["method"] == method]
        for method in ("zscore", "isolation_forest")
    }
    median = {m: float(np.median(v)) if v else float("nan") for m, v in share.items()}
    return {
        "supported": bool(
            share["isolation_forest"]
            and share["zscore"]
            and median["isolation_forest"] > 0.30
            and median["zscore"] < 0.10
        ),
        "datasets_above": len({r["id"] for r in big}),
        "median_detect_share": median,
        "failed": [r["id"] for r in records if r["status"] != "OK"],
    }


def x_pipeline__mutmut_orig(records: list[dict[str, Any]], large: int = 50_000) -> dict[str, Any]:
    """P4: detection share of the pipeline time on the datasets above ``large`` rows."""
    ok = [r for r in records if r["status"] == "OK"]
    big = [r for r in ok if r["rows_after_transform"] > large]
    share = {
        method: [r["detect_stage_share"] for r in big if r["method"] == method]
        for method in ("zscore", "isolation_forest")
    }
    median = {m: float(np.median(v)) if v else float("nan") for m, v in share.items()}
    return {
        "supported": bool(
            share["isolation_forest"]
            and share["zscore"]
            and median["isolation_forest"] > 0.30
            and median["zscore"] < 0.10
        ),
        "datasets_above": len({r["id"] for r in big}),
        "median_detect_share": median,
        "failed": [r["id"] for r in records if r["status"] != "OK"],
    }


def x_pipeline__mutmut_1(records: list[dict[str, Any]], large: int = 50001) -> dict[str, Any]:
    """P4: detection share of the pipeline time on the datasets above ``large`` rows."""
    ok = [r for r in records if r["status"] == "OK"]
    big = [r for r in ok if r["rows_after_transform"] > large]
    share = {
        method: [r["detect_stage_share"] for r in big if r["method"] == method]
        for method in ("zscore", "isolation_forest")
    }
    median = {m: float(np.median(v)) if v else float("nan") for m, v in share.items()}
    return {
        "supported": bool(
            share["isolation_forest"]
            and share["zscore"]
            and median["isolation_forest"] > 0.30
            and median["zscore"] < 0.10
        ),
        "datasets_above": len({r["id"] for r in big}),
        "median_detect_share": median,
        "failed": [r["id"] for r in records if r["status"] != "OK"],
    }


def x_pipeline__mutmut_2(records: list[dict[str, Any]], large: int = 50_000) -> dict[str, Any]:
    """P4: detection share of the pipeline time on the datasets above ``large`` rows."""
    ok = None
    big = [r for r in ok if r["rows_after_transform"] > large]
    share = {
        method: [r["detect_stage_share"] for r in big if r["method"] == method]
        for method in ("zscore", "isolation_forest")
    }
    median = {m: float(np.median(v)) if v else float("nan") for m, v in share.items()}
    return {
        "supported": bool(
            share["isolation_forest"]
            and share["zscore"]
            and median["isolation_forest"] > 0.30
            and median["zscore"] < 0.10
        ),
        "datasets_above": len({r["id"] for r in big}),
        "median_detect_share": median,
        "failed": [r["id"] for r in records if r["status"] != "OK"],
    }


def x_pipeline__mutmut_3(records: list[dict[str, Any]], large: int = 50_000) -> dict[str, Any]:
    """P4: detection share of the pipeline time on the datasets above ``large`` rows."""
    ok = [r for r in records if r["XXstatusXX"] == "OK"]
    big = [r for r in ok if r["rows_after_transform"] > large]
    share = {
        method: [r["detect_stage_share"] for r in big if r["method"] == method]
        for method in ("zscore", "isolation_forest")
    }
    median = {m: float(np.median(v)) if v else float("nan") for m, v in share.items()}
    return {
        "supported": bool(
            share["isolation_forest"]
            and share["zscore"]
            and median["isolation_forest"] > 0.30
            and median["zscore"] < 0.10
        ),
        "datasets_above": len({r["id"] for r in big}),
        "median_detect_share": median,
        "failed": [r["id"] for r in records if r["status"] != "OK"],
    }


def x_pipeline__mutmut_4(records: list[dict[str, Any]], large: int = 50_000) -> dict[str, Any]:
    """P4: detection share of the pipeline time on the datasets above ``large`` rows."""
    ok = [r for r in records if r["STATUS"] == "OK"]
    big = [r for r in ok if r["rows_after_transform"] > large]
    share = {
        method: [r["detect_stage_share"] for r in big if r["method"] == method]
        for method in ("zscore", "isolation_forest")
    }
    median = {m: float(np.median(v)) if v else float("nan") for m, v in share.items()}
    return {
        "supported": bool(
            share["isolation_forest"]
            and share["zscore"]
            and median["isolation_forest"] > 0.30
            and median["zscore"] < 0.10
        ),
        "datasets_above": len({r["id"] for r in big}),
        "median_detect_share": median,
        "failed": [r["id"] for r in records if r["status"] != "OK"],
    }


def x_pipeline__mutmut_5(records: list[dict[str, Any]], large: int = 50_000) -> dict[str, Any]:
    """P4: detection share of the pipeline time on the datasets above ``large`` rows."""
    ok = [r for r in records if r["status"] != "OK"]
    big = [r for r in ok if r["rows_after_transform"] > large]
    share = {
        method: [r["detect_stage_share"] for r in big if r["method"] == method]
        for method in ("zscore", "isolation_forest")
    }
    median = {m: float(np.median(v)) if v else float("nan") for m, v in share.items()}
    return {
        "supported": bool(
            share["isolation_forest"]
            and share["zscore"]
            and median["isolation_forest"] > 0.30
            and median["zscore"] < 0.10
        ),
        "datasets_above": len({r["id"] for r in big}),
        "median_detect_share": median,
        "failed": [r["id"] for r in records if r["status"] != "OK"],
    }


def x_pipeline__mutmut_6(records: list[dict[str, Any]], large: int = 50_000) -> dict[str, Any]:
    """P4: detection share of the pipeline time on the datasets above ``large`` rows."""
    ok = [r for r in records if r["status"] == "XXOKXX"]
    big = [r for r in ok if r["rows_after_transform"] > large]
    share = {
        method: [r["detect_stage_share"] for r in big if r["method"] == method]
        for method in ("zscore", "isolation_forest")
    }
    median = {m: float(np.median(v)) if v else float("nan") for m, v in share.items()}
    return {
        "supported": bool(
            share["isolation_forest"]
            and share["zscore"]
            and median["isolation_forest"] > 0.30
            and median["zscore"] < 0.10
        ),
        "datasets_above": len({r["id"] for r in big}),
        "median_detect_share": median,
        "failed": [r["id"] for r in records if r["status"] != "OK"],
    }


def x_pipeline__mutmut_7(records: list[dict[str, Any]], large: int = 50_000) -> dict[str, Any]:
    """P4: detection share of the pipeline time on the datasets above ``large`` rows."""
    ok = [r for r in records if r["status"] == "ok"]
    big = [r for r in ok if r["rows_after_transform"] > large]
    share = {
        method: [r["detect_stage_share"] for r in big if r["method"] == method]
        for method in ("zscore", "isolation_forest")
    }
    median = {m: float(np.median(v)) if v else float("nan") for m, v in share.items()}
    return {
        "supported": bool(
            share["isolation_forest"]
            and share["zscore"]
            and median["isolation_forest"] > 0.30
            and median["zscore"] < 0.10
        ),
        "datasets_above": len({r["id"] for r in big}),
        "median_detect_share": median,
        "failed": [r["id"] for r in records if r["status"] != "OK"],
    }


def x_pipeline__mutmut_8(records: list[dict[str, Any]], large: int = 50_000) -> dict[str, Any]:
    """P4: detection share of the pipeline time on the datasets above ``large`` rows."""
    ok = [r for r in records if r["status"] == "OK"]
    big = None
    share = {
        method: [r["detect_stage_share"] for r in big if r["method"] == method]
        for method in ("zscore", "isolation_forest")
    }
    median = {m: float(np.median(v)) if v else float("nan") for m, v in share.items()}
    return {
        "supported": bool(
            share["isolation_forest"]
            and share["zscore"]
            and median["isolation_forest"] > 0.30
            and median["zscore"] < 0.10
        ),
        "datasets_above": len({r["id"] for r in big}),
        "median_detect_share": median,
        "failed": [r["id"] for r in records if r["status"] != "OK"],
    }


def x_pipeline__mutmut_9(records: list[dict[str, Any]], large: int = 50_000) -> dict[str, Any]:
    """P4: detection share of the pipeline time on the datasets above ``large`` rows."""
    ok = [r for r in records if r["status"] == "OK"]
    big = [r for r in ok if r["XXrows_after_transformXX"] > large]
    share = {
        method: [r["detect_stage_share"] for r in big if r["method"] == method]
        for method in ("zscore", "isolation_forest")
    }
    median = {m: float(np.median(v)) if v else float("nan") for m, v in share.items()}
    return {
        "supported": bool(
            share["isolation_forest"]
            and share["zscore"]
            and median["isolation_forest"] > 0.30
            and median["zscore"] < 0.10
        ),
        "datasets_above": len({r["id"] for r in big}),
        "median_detect_share": median,
        "failed": [r["id"] for r in records if r["status"] != "OK"],
    }


def x_pipeline__mutmut_10(records: list[dict[str, Any]], large: int = 50_000) -> dict[str, Any]:
    """P4: detection share of the pipeline time on the datasets above ``large`` rows."""
    ok = [r for r in records if r["status"] == "OK"]
    big = [r for r in ok if r["ROWS_AFTER_TRANSFORM"] > large]
    share = {
        method: [r["detect_stage_share"] for r in big if r["method"] == method]
        for method in ("zscore", "isolation_forest")
    }
    median = {m: float(np.median(v)) if v else float("nan") for m, v in share.items()}
    return {
        "supported": bool(
            share["isolation_forest"]
            and share["zscore"]
            and median["isolation_forest"] > 0.30
            and median["zscore"] < 0.10
        ),
        "datasets_above": len({r["id"] for r in big}),
        "median_detect_share": median,
        "failed": [r["id"] for r in records if r["status"] != "OK"],
    }


def x_pipeline__mutmut_11(records: list[dict[str, Any]], large: int = 50_000) -> dict[str, Any]:
    """P4: detection share of the pipeline time on the datasets above ``large`` rows."""
    ok = [r for r in records if r["status"] == "OK"]
    big = [r for r in ok if r["rows_after_transform"] >= large]
    share = {
        method: [r["detect_stage_share"] for r in big if r["method"] == method]
        for method in ("zscore", "isolation_forest")
    }
    median = {m: float(np.median(v)) if v else float("nan") for m, v in share.items()}
    return {
        "supported": bool(
            share["isolation_forest"]
            and share["zscore"]
            and median["isolation_forest"] > 0.30
            and median["zscore"] < 0.10
        ),
        "datasets_above": len({r["id"] for r in big}),
        "median_detect_share": median,
        "failed": [r["id"] for r in records if r["status"] != "OK"],
    }


def x_pipeline__mutmut_12(records: list[dict[str, Any]], large: int = 50_000) -> dict[str, Any]:
    """P4: detection share of the pipeline time on the datasets above ``large`` rows."""
    ok = [r for r in records if r["status"] == "OK"]
    big = [r for r in ok if r["rows_after_transform"] > large]
    share = None
    median = {m: float(np.median(v)) if v else float("nan") for m, v in share.items()}
    return {
        "supported": bool(
            share["isolation_forest"]
            and share["zscore"]
            and median["isolation_forest"] > 0.30
            and median["zscore"] < 0.10
        ),
        "datasets_above": len({r["id"] for r in big}),
        "median_detect_share": median,
        "failed": [r["id"] for r in records if r["status"] != "OK"],
    }


def x_pipeline__mutmut_13(records: list[dict[str, Any]], large: int = 50_000) -> dict[str, Any]:
    """P4: detection share of the pipeline time on the datasets above ``large`` rows."""
    ok = [r for r in records if r["status"] == "OK"]
    big = [r for r in ok if r["rows_after_transform"] > large]
    share = {
        method: [r["XXdetect_stage_shareXX"] for r in big if r["method"] == method]
        for method in ("zscore", "isolation_forest")
    }
    median = {m: float(np.median(v)) if v else float("nan") for m, v in share.items()}
    return {
        "supported": bool(
            share["isolation_forest"]
            and share["zscore"]
            and median["isolation_forest"] > 0.30
            and median["zscore"] < 0.10
        ),
        "datasets_above": len({r["id"] for r in big}),
        "median_detect_share": median,
        "failed": [r["id"] for r in records if r["status"] != "OK"],
    }


def x_pipeline__mutmut_14(records: list[dict[str, Any]], large: int = 50_000) -> dict[str, Any]:
    """P4: detection share of the pipeline time on the datasets above ``large`` rows."""
    ok = [r for r in records if r["status"] == "OK"]
    big = [r for r in ok if r["rows_after_transform"] > large]
    share = {
        method: [r["DETECT_STAGE_SHARE"] for r in big if r["method"] == method]
        for method in ("zscore", "isolation_forest")
    }
    median = {m: float(np.median(v)) if v else float("nan") for m, v in share.items()}
    return {
        "supported": bool(
            share["isolation_forest"]
            and share["zscore"]
            and median["isolation_forest"] > 0.30
            and median["zscore"] < 0.10
        ),
        "datasets_above": len({r["id"] for r in big}),
        "median_detect_share": median,
        "failed": [r["id"] for r in records if r["status"] != "OK"],
    }


def x_pipeline__mutmut_15(records: list[dict[str, Any]], large: int = 50_000) -> dict[str, Any]:
    """P4: detection share of the pipeline time on the datasets above ``large`` rows."""
    ok = [r for r in records if r["status"] == "OK"]
    big = [r for r in ok if r["rows_after_transform"] > large]
    share = {
        method: [r["detect_stage_share"] for r in big if r["XXmethodXX"] == method]
        for method in ("zscore", "isolation_forest")
    }
    median = {m: float(np.median(v)) if v else float("nan") for m, v in share.items()}
    return {
        "supported": bool(
            share["isolation_forest"]
            and share["zscore"]
            and median["isolation_forest"] > 0.30
            and median["zscore"] < 0.10
        ),
        "datasets_above": len({r["id"] for r in big}),
        "median_detect_share": median,
        "failed": [r["id"] for r in records if r["status"] != "OK"],
    }


def x_pipeline__mutmut_16(records: list[dict[str, Any]], large: int = 50_000) -> dict[str, Any]:
    """P4: detection share of the pipeline time on the datasets above ``large`` rows."""
    ok = [r for r in records if r["status"] == "OK"]
    big = [r for r in ok if r["rows_after_transform"] > large]
    share = {
        method: [r["detect_stage_share"] for r in big if r["METHOD"] == method]
        for method in ("zscore", "isolation_forest")
    }
    median = {m: float(np.median(v)) if v else float("nan") for m, v in share.items()}
    return {
        "supported": bool(
            share["isolation_forest"]
            and share["zscore"]
            and median["isolation_forest"] > 0.30
            and median["zscore"] < 0.10
        ),
        "datasets_above": len({r["id"] for r in big}),
        "median_detect_share": median,
        "failed": [r["id"] for r in records if r["status"] != "OK"],
    }


def x_pipeline__mutmut_17(records: list[dict[str, Any]], large: int = 50_000) -> dict[str, Any]:
    """P4: detection share of the pipeline time on the datasets above ``large`` rows."""
    ok = [r for r in records if r["status"] == "OK"]
    big = [r for r in ok if r["rows_after_transform"] > large]
    share = {
        method: [r["detect_stage_share"] for r in big if r["method"] != method]
        for method in ("zscore", "isolation_forest")
    }
    median = {m: float(np.median(v)) if v else float("nan") for m, v in share.items()}
    return {
        "supported": bool(
            share["isolation_forest"]
            and share["zscore"]
            and median["isolation_forest"] > 0.30
            and median["zscore"] < 0.10
        ),
        "datasets_above": len({r["id"] for r in big}),
        "median_detect_share": median,
        "failed": [r["id"] for r in records if r["status"] != "OK"],
    }


def x_pipeline__mutmut_18(records: list[dict[str, Any]], large: int = 50_000) -> dict[str, Any]:
    """P4: detection share of the pipeline time on the datasets above ``large`` rows."""
    ok = [r for r in records if r["status"] == "OK"]
    big = [r for r in ok if r["rows_after_transform"] > large]
    share = {
        method: [r["detect_stage_share"] for r in big if r["method"] == method]
        for method in ("XXzscoreXX", "isolation_forest")
    }
    median = {m: float(np.median(v)) if v else float("nan") for m, v in share.items()}
    return {
        "supported": bool(
            share["isolation_forest"]
            and share["zscore"]
            and median["isolation_forest"] > 0.30
            and median["zscore"] < 0.10
        ),
        "datasets_above": len({r["id"] for r in big}),
        "median_detect_share": median,
        "failed": [r["id"] for r in records if r["status"] != "OK"],
    }


def x_pipeline__mutmut_19(records: list[dict[str, Any]], large: int = 50_000) -> dict[str, Any]:
    """P4: detection share of the pipeline time on the datasets above ``large`` rows."""
    ok = [r for r in records if r["status"] == "OK"]
    big = [r for r in ok if r["rows_after_transform"] > large]
    share = {
        method: [r["detect_stage_share"] for r in big if r["method"] == method]
        for method in ("ZSCORE", "isolation_forest")
    }
    median = {m: float(np.median(v)) if v else float("nan") for m, v in share.items()}
    return {
        "supported": bool(
            share["isolation_forest"]
            and share["zscore"]
            and median["isolation_forest"] > 0.30
            and median["zscore"] < 0.10
        ),
        "datasets_above": len({r["id"] for r in big}),
        "median_detect_share": median,
        "failed": [r["id"] for r in records if r["status"] != "OK"],
    }


def x_pipeline__mutmut_20(records: list[dict[str, Any]], large: int = 50_000) -> dict[str, Any]:
    """P4: detection share of the pipeline time on the datasets above ``large`` rows."""
    ok = [r for r in records if r["status"] == "OK"]
    big = [r for r in ok if r["rows_after_transform"] > large]
    share = {
        method: [r["detect_stage_share"] for r in big if r["method"] == method]
        for method in ("zscore", "XXisolation_forestXX")
    }
    median = {m: float(np.median(v)) if v else float("nan") for m, v in share.items()}
    return {
        "supported": bool(
            share["isolation_forest"]
            and share["zscore"]
            and median["isolation_forest"] > 0.30
            and median["zscore"] < 0.10
        ),
        "datasets_above": len({r["id"] for r in big}),
        "median_detect_share": median,
        "failed": [r["id"] for r in records if r["status"] != "OK"],
    }


def x_pipeline__mutmut_21(records: list[dict[str, Any]], large: int = 50_000) -> dict[str, Any]:
    """P4: detection share of the pipeline time on the datasets above ``large`` rows."""
    ok = [r for r in records if r["status"] == "OK"]
    big = [r for r in ok if r["rows_after_transform"] > large]
    share = {
        method: [r["detect_stage_share"] for r in big if r["method"] == method]
        for method in ("zscore", "ISOLATION_FOREST")
    }
    median = {m: float(np.median(v)) if v else float("nan") for m, v in share.items()}
    return {
        "supported": bool(
            share["isolation_forest"]
            and share["zscore"]
            and median["isolation_forest"] > 0.30
            and median["zscore"] < 0.10
        ),
        "datasets_above": len({r["id"] for r in big}),
        "median_detect_share": median,
        "failed": [r["id"] for r in records if r["status"] != "OK"],
    }


def x_pipeline__mutmut_22(records: list[dict[str, Any]], large: int = 50_000) -> dict[str, Any]:
    """P4: detection share of the pipeline time on the datasets above ``large`` rows."""
    ok = [r for r in records if r["status"] == "OK"]
    big = [r for r in ok if r["rows_after_transform"] > large]
    share = {
        method: [r["detect_stage_share"] for r in big if r["method"] == method]
        for method in ("zscore", "isolation_forest")
    }
    median = None
    return {
        "supported": bool(
            share["isolation_forest"]
            and share["zscore"]
            and median["isolation_forest"] > 0.30
            and median["zscore"] < 0.10
        ),
        "datasets_above": len({r["id"] for r in big}),
        "median_detect_share": median,
        "failed": [r["id"] for r in records if r["status"] != "OK"],
    }


def x_pipeline__mutmut_23(records: list[dict[str, Any]], large: int = 50_000) -> dict[str, Any]:
    """P4: detection share of the pipeline time on the datasets above ``large`` rows."""
    ok = [r for r in records if r["status"] == "OK"]
    big = [r for r in ok if r["rows_after_transform"] > large]
    share = {
        method: [r["detect_stage_share"] for r in big if r["method"] == method]
        for method in ("zscore", "isolation_forest")
    }
    median = {m: float(np.median(v)) if (v) and False else float("nan") for m, v in share.items()}
    return {
        "supported": bool(
            share["isolation_forest"]
            and share["zscore"]
            and median["isolation_forest"] > 0.30
            and median["zscore"] < 0.10
        ),
        "datasets_above": len({r["id"] for r in big}),
        "median_detect_share": median,
        "failed": [r["id"] for r in records if r["status"] != "OK"],
    }


def x_pipeline__mutmut_24(records: list[dict[str, Any]], large: int = 50_000) -> dict[str, Any]:
    """P4: detection share of the pipeline time on the datasets above ``large`` rows."""
    ok = [r for r in records if r["status"] == "OK"]
    big = [r for r in ok if r["rows_after_transform"] > large]
    share = {
        method: [r["detect_stage_share"] for r in big if r["method"] == method]
        for method in ("zscore", "isolation_forest")
    }
    median = {m: float(np.median(v)) if (v) or True else float("nan") for m, v in share.items()}
    return {
        "supported": bool(
            share["isolation_forest"]
            and share["zscore"]
            and median["isolation_forest"] > 0.30
            and median["zscore"] < 0.10
        ),
        "datasets_above": len({r["id"] for r in big}),
        "median_detect_share": median,
        "failed": [r["id"] for r in records if r["status"] != "OK"],
    }


def x_pipeline__mutmut_25(records: list[dict[str, Any]], large: int = 50_000) -> dict[str, Any]:
    """P4: detection share of the pipeline time on the datasets above ``large`` rows."""
    ok = [r for r in records if r["status"] == "OK"]
    big = [r for r in ok if r["rows_after_transform"] > large]
    share = {
        method: [r["detect_stage_share"] for r in big if r["method"] == method]
        for method in ("zscore", "isolation_forest")
    }
    median = {m: float(None) if v else float("nan") for m, v in share.items()}
    return {
        "supported": bool(
            share["isolation_forest"]
            and share["zscore"]
            and median["isolation_forest"] > 0.30
            and median["zscore"] < 0.10
        ),
        "datasets_above": len({r["id"] for r in big}),
        "median_detect_share": median,
        "failed": [r["id"] for r in records if r["status"] != "OK"],
    }


def x_pipeline__mutmut_26(records: list[dict[str, Any]], large: int = 50_000) -> dict[str, Any]:
    """P4: detection share of the pipeline time on the datasets above ``large`` rows."""
    ok = [r for r in records if r["status"] == "OK"]
    big = [r for r in ok if r["rows_after_transform"] > large]
    share = {
        method: [r["detect_stage_share"] for r in big if r["method"] == method]
        for method in ("zscore", "isolation_forest")
    }
    median = {m: float(np.median(None)) if v else float("nan") for m, v in share.items()}
    return {
        "supported": bool(
            share["isolation_forest"]
            and share["zscore"]
            and median["isolation_forest"] > 0.30
            and median["zscore"] < 0.10
        ),
        "datasets_above": len({r["id"] for r in big}),
        "median_detect_share": median,
        "failed": [r["id"] for r in records if r["status"] != "OK"],
    }


def x_pipeline__mutmut_27(records: list[dict[str, Any]], large: int = 50_000) -> dict[str, Any]:
    """P4: detection share of the pipeline time on the datasets above ``large`` rows."""
    ok = [r for r in records if r["status"] == "OK"]
    big = [r for r in ok if r["rows_after_transform"] > large]
    share = {
        method: [r["detect_stage_share"] for r in big if r["method"] == method]
        for method in ("zscore", "isolation_forest")
    }
    median = {m: float(np.median(v)) if v else float(None) for m, v in share.items()}
    return {
        "supported": bool(
            share["isolation_forest"]
            and share["zscore"]
            and median["isolation_forest"] > 0.30
            and median["zscore"] < 0.10
        ),
        "datasets_above": len({r["id"] for r in big}),
        "median_detect_share": median,
        "failed": [r["id"] for r in records if r["status"] != "OK"],
    }


def x_pipeline__mutmut_28(records: list[dict[str, Any]], large: int = 50_000) -> dict[str, Any]:
    """P4: detection share of the pipeline time on the datasets above ``large`` rows."""
    ok = [r for r in records if r["status"] == "OK"]
    big = [r for r in ok if r["rows_after_transform"] > large]
    share = {
        method: [r["detect_stage_share"] for r in big if r["method"] == method]
        for method in ("zscore", "isolation_forest")
    }
    median = {m: float(np.median(v)) if v else float("XXnanXX") for m, v in share.items()}
    return {
        "supported": bool(
            share["isolation_forest"]
            and share["zscore"]
            and median["isolation_forest"] > 0.30
            and median["zscore"] < 0.10
        ),
        "datasets_above": len({r["id"] for r in big}),
        "median_detect_share": median,
        "failed": [r["id"] for r in records if r["status"] != "OK"],
    }


def x_pipeline__mutmut_29(records: list[dict[str, Any]], large: int = 50_000) -> dict[str, Any]:
    """P4: detection share of the pipeline time on the datasets above ``large`` rows."""
    ok = [r for r in records if r["status"] == "OK"]
    big = [r for r in ok if r["rows_after_transform"] > large]
    share = {
        method: [r["detect_stage_share"] for r in big if r["method"] == method]
        for method in ("zscore", "isolation_forest")
    }
    median = {m: float(np.median(v)) if v else float("NAN") for m, v in share.items()}
    return {
        "supported": bool(
            share["isolation_forest"]
            and share["zscore"]
            and median["isolation_forest"] > 0.30
            and median["zscore"] < 0.10
        ),
        "datasets_above": len({r["id"] for r in big}),
        "median_detect_share": median,
        "failed": [r["id"] for r in records if r["status"] != "OK"],
    }


def x_pipeline__mutmut_30(records: list[dict[str, Any]], large: int = 50_000) -> dict[str, Any]:
    """P4: detection share of the pipeline time on the datasets above ``large`` rows."""
    ok = [r for r in records if r["status"] == "OK"]
    big = [r for r in ok if r["rows_after_transform"] > large]
    share = {
        method: [r["detect_stage_share"] for r in big if r["method"] == method]
        for method in ("zscore", "isolation_forest")
    }
    median = {m: float(np.median(v)) if v else float("nan") for m, v in share.items()}
    return {
        "XXsupportedXX": bool(
            share["isolation_forest"]
            and share["zscore"]
            and median["isolation_forest"] > 0.30
            and median["zscore"] < 0.10
        ),
        "datasets_above": len({r["id"] for r in big}),
        "median_detect_share": median,
        "failed": [r["id"] for r in records if r["status"] != "OK"],
    }


def x_pipeline__mutmut_31(records: list[dict[str, Any]], large: int = 50_000) -> dict[str, Any]:
    """P4: detection share of the pipeline time on the datasets above ``large`` rows."""
    ok = [r for r in records if r["status"] == "OK"]
    big = [r for r in ok if r["rows_after_transform"] > large]
    share = {
        method: [r["detect_stage_share"] for r in big if r["method"] == method]
        for method in ("zscore", "isolation_forest")
    }
    median = {m: float(np.median(v)) if v else float("nan") for m, v in share.items()}
    return {
        "SUPPORTED": bool(
            share["isolation_forest"]
            and share["zscore"]
            and median["isolation_forest"] > 0.30
            and median["zscore"] < 0.10
        ),
        "datasets_above": len({r["id"] for r in big}),
        "median_detect_share": median,
        "failed": [r["id"] for r in records if r["status"] != "OK"],
    }


def x_pipeline__mutmut_32(records: list[dict[str, Any]], large: int = 50_000) -> dict[str, Any]:
    """P4: detection share of the pipeline time on the datasets above ``large`` rows."""
    ok = [r for r in records if r["status"] == "OK"]
    big = [r for r in ok if r["rows_after_transform"] > large]
    share = {
        method: [r["detect_stage_share"] for r in big if r["method"] == method]
        for method in ("zscore", "isolation_forest")
    }
    median = {m: float(np.median(v)) if v else float("nan") for m, v in share.items()}
    return {
        "supported": bool(
            None
        ),
        "datasets_above": len({r["id"] for r in big}),
        "median_detect_share": median,
        "failed": [r["id"] for r in records if r["status"] != "OK"],
    }


def x_pipeline__mutmut_33(records: list[dict[str, Any]], large: int = 50_000) -> dict[str, Any]:
    """P4: detection share of the pipeline time on the datasets above ``large`` rows."""
    ok = [r for r in records if r["status"] == "OK"]
    big = [r for r in ok if r["rows_after_transform"] > large]
    share = {
        method: [r["detect_stage_share"] for r in big if r["method"] == method]
        for method in ("zscore", "isolation_forest")
    }
    median = {m: float(np.median(v)) if v else float("nan") for m, v in share.items()}
    return {
        "supported": bool(
            share["isolation_forest"]
            and share["zscore"]
            and median["isolation_forest"] > 0.30 or median["zscore"] < 0.10
        ),
        "datasets_above": len({r["id"] for r in big}),
        "median_detect_share": median,
        "failed": [r["id"] for r in records if r["status"] != "OK"],
    }


def x_pipeline__mutmut_34(records: list[dict[str, Any]], large: int = 50_000) -> dict[str, Any]:
    """P4: detection share of the pipeline time on the datasets above ``large`` rows."""
    ok = [r for r in records if r["status"] == "OK"]
    big = [r for r in ok if r["rows_after_transform"] > large]
    share = {
        method: [r["detect_stage_share"] for r in big if r["method"] == method]
        for method in ("zscore", "isolation_forest")
    }
    median = {m: float(np.median(v)) if v else float("nan") for m, v in share.items()}
    return {
        "supported": bool(
            share["isolation_forest"]
            and share["zscore"] or median["isolation_forest"] > 0.30
            and median["zscore"] < 0.10
        ),
        "datasets_above": len({r["id"] for r in big}),
        "median_detect_share": median,
        "failed": [r["id"] for r in records if r["status"] != "OK"],
    }


def x_pipeline__mutmut_35(records: list[dict[str, Any]], large: int = 50_000) -> dict[str, Any]:
    """P4: detection share of the pipeline time on the datasets above ``large`` rows."""
    ok = [r for r in records if r["status"] == "OK"]
    big = [r for r in ok if r["rows_after_transform"] > large]
    share = {
        method: [r["detect_stage_share"] for r in big if r["method"] == method]
        for method in ("zscore", "isolation_forest")
    }
    median = {m: float(np.median(v)) if v else float("nan") for m, v in share.items()}
    return {
        "supported": bool(
            share["isolation_forest"] or share["zscore"]
            and median["isolation_forest"] > 0.30
            and median["zscore"] < 0.10
        ),
        "datasets_above": len({r["id"] for r in big}),
        "median_detect_share": median,
        "failed": [r["id"] for r in records if r["status"] != "OK"],
    }


def x_pipeline__mutmut_36(records: list[dict[str, Any]], large: int = 50_000) -> dict[str, Any]:
    """P4: detection share of the pipeline time on the datasets above ``large`` rows."""
    ok = [r for r in records if r["status"] == "OK"]
    big = [r for r in ok if r["rows_after_transform"] > large]
    share = {
        method: [r["detect_stage_share"] for r in big if r["method"] == method]
        for method in ("zscore", "isolation_forest")
    }
    median = {m: float(np.median(v)) if v else float("nan") for m, v in share.items()}
    return {
        "supported": bool(
            share["XXisolation_forestXX"]
            and share["zscore"]
            and median["isolation_forest"] > 0.30
            and median["zscore"] < 0.10
        ),
        "datasets_above": len({r["id"] for r in big}),
        "median_detect_share": median,
        "failed": [r["id"] for r in records if r["status"] != "OK"],
    }


def x_pipeline__mutmut_37(records: list[dict[str, Any]], large: int = 50_000) -> dict[str, Any]:
    """P4: detection share of the pipeline time on the datasets above ``large`` rows."""
    ok = [r for r in records if r["status"] == "OK"]
    big = [r for r in ok if r["rows_after_transform"] > large]
    share = {
        method: [r["detect_stage_share"] for r in big if r["method"] == method]
        for method in ("zscore", "isolation_forest")
    }
    median = {m: float(np.median(v)) if v else float("nan") for m, v in share.items()}
    return {
        "supported": bool(
            share["ISOLATION_FOREST"]
            and share["zscore"]
            and median["isolation_forest"] > 0.30
            and median["zscore"] < 0.10
        ),
        "datasets_above": len({r["id"] for r in big}),
        "median_detect_share": median,
        "failed": [r["id"] for r in records if r["status"] != "OK"],
    }


def x_pipeline__mutmut_38(records: list[dict[str, Any]], large: int = 50_000) -> dict[str, Any]:
    """P4: detection share of the pipeline time on the datasets above ``large`` rows."""
    ok = [r for r in records if r["status"] == "OK"]
    big = [r for r in ok if r["rows_after_transform"] > large]
    share = {
        method: [r["detect_stage_share"] for r in big if r["method"] == method]
        for method in ("zscore", "isolation_forest")
    }
    median = {m: float(np.median(v)) if v else float("nan") for m, v in share.items()}
    return {
        "supported": bool(
            share["isolation_forest"]
            and share["XXzscoreXX"]
            and median["isolation_forest"] > 0.30
            and median["zscore"] < 0.10
        ),
        "datasets_above": len({r["id"] for r in big}),
        "median_detect_share": median,
        "failed": [r["id"] for r in records if r["status"] != "OK"],
    }


def x_pipeline__mutmut_39(records: list[dict[str, Any]], large: int = 50_000) -> dict[str, Any]:
    """P4: detection share of the pipeline time on the datasets above ``large`` rows."""
    ok = [r for r in records if r["status"] == "OK"]
    big = [r for r in ok if r["rows_after_transform"] > large]
    share = {
        method: [r["detect_stage_share"] for r in big if r["method"] == method]
        for method in ("zscore", "isolation_forest")
    }
    median = {m: float(np.median(v)) if v else float("nan") for m, v in share.items()}
    return {
        "supported": bool(
            share["isolation_forest"]
            and share["ZSCORE"]
            and median["isolation_forest"] > 0.30
            and median["zscore"] < 0.10
        ),
        "datasets_above": len({r["id"] for r in big}),
        "median_detect_share": median,
        "failed": [r["id"] for r in records if r["status"] != "OK"],
    }


def x_pipeline__mutmut_40(records: list[dict[str, Any]], large: int = 50_000) -> dict[str, Any]:
    """P4: detection share of the pipeline time on the datasets above ``large`` rows."""
    ok = [r for r in records if r["status"] == "OK"]
    big = [r for r in ok if r["rows_after_transform"] > large]
    share = {
        method: [r["detect_stage_share"] for r in big if r["method"] == method]
        for method in ("zscore", "isolation_forest")
    }
    median = {m: float(np.median(v)) if v else float("nan") for m, v in share.items()}
    return {
        "supported": bool(
            share["isolation_forest"]
            and share["zscore"]
            and median["XXisolation_forestXX"] > 0.30
            and median["zscore"] < 0.10
        ),
        "datasets_above": len({r["id"] for r in big}),
        "median_detect_share": median,
        "failed": [r["id"] for r in records if r["status"] != "OK"],
    }


def x_pipeline__mutmut_41(records: list[dict[str, Any]], large: int = 50_000) -> dict[str, Any]:
    """P4: detection share of the pipeline time on the datasets above ``large`` rows."""
    ok = [r for r in records if r["status"] == "OK"]
    big = [r for r in ok if r["rows_after_transform"] > large]
    share = {
        method: [r["detect_stage_share"] for r in big if r["method"] == method]
        for method in ("zscore", "isolation_forest")
    }
    median = {m: float(np.median(v)) if v else float("nan") for m, v in share.items()}
    return {
        "supported": bool(
            share["isolation_forest"]
            and share["zscore"]
            and median["ISOLATION_FOREST"] > 0.30
            and median["zscore"] < 0.10
        ),
        "datasets_above": len({r["id"] for r in big}),
        "median_detect_share": median,
        "failed": [r["id"] for r in records if r["status"] != "OK"],
    }


def x_pipeline__mutmut_42(records: list[dict[str, Any]], large: int = 50_000) -> dict[str, Any]:
    """P4: detection share of the pipeline time on the datasets above ``large`` rows."""
    ok = [r for r in records if r["status"] == "OK"]
    big = [r for r in ok if r["rows_after_transform"] > large]
    share = {
        method: [r["detect_stage_share"] for r in big if r["method"] == method]
        for method in ("zscore", "isolation_forest")
    }
    median = {m: float(np.median(v)) if v else float("nan") for m, v in share.items()}
    return {
        "supported": bool(
            share["isolation_forest"]
            and share["zscore"]
            and median["isolation_forest"] >= 0.30
            and median["zscore"] < 0.10
        ),
        "datasets_above": len({r["id"] for r in big}),
        "median_detect_share": median,
        "failed": [r["id"] for r in records if r["status"] != "OK"],
    }


def x_pipeline__mutmut_43(records: list[dict[str, Any]], large: int = 50_000) -> dict[str, Any]:
    """P4: detection share of the pipeline time on the datasets above ``large`` rows."""
    ok = [r for r in records if r["status"] == "OK"]
    big = [r for r in ok if r["rows_after_transform"] > large]
    share = {
        method: [r["detect_stage_share"] for r in big if r["method"] == method]
        for method in ("zscore", "isolation_forest")
    }
    median = {m: float(np.median(v)) if v else float("nan") for m, v in share.items()}
    return {
        "supported": bool(
            share["isolation_forest"]
            and share["zscore"]
            and median["isolation_forest"] > 1.3
            and median["zscore"] < 0.10
        ),
        "datasets_above": len({r["id"] for r in big}),
        "median_detect_share": median,
        "failed": [r["id"] for r in records if r["status"] != "OK"],
    }


def x_pipeline__mutmut_44(records: list[dict[str, Any]], large: int = 50_000) -> dict[str, Any]:
    """P4: detection share of the pipeline time on the datasets above ``large`` rows."""
    ok = [r for r in records if r["status"] == "OK"]
    big = [r for r in ok if r["rows_after_transform"] > large]
    share = {
        method: [r["detect_stage_share"] for r in big if r["method"] == method]
        for method in ("zscore", "isolation_forest")
    }
    median = {m: float(np.median(v)) if v else float("nan") for m, v in share.items()}
    return {
        "supported": bool(
            share["isolation_forest"]
            and share["zscore"]
            and median["isolation_forest"] > 0.30
            and median["XXzscoreXX"] < 0.10
        ),
        "datasets_above": len({r["id"] for r in big}),
        "median_detect_share": median,
        "failed": [r["id"] for r in records if r["status"] != "OK"],
    }


def x_pipeline__mutmut_45(records: list[dict[str, Any]], large: int = 50_000) -> dict[str, Any]:
    """P4: detection share of the pipeline time on the datasets above ``large`` rows."""
    ok = [r for r in records if r["status"] == "OK"]
    big = [r for r in ok if r["rows_after_transform"] > large]
    share = {
        method: [r["detect_stage_share"] for r in big if r["method"] == method]
        for method in ("zscore", "isolation_forest")
    }
    median = {m: float(np.median(v)) if v else float("nan") for m, v in share.items()}
    return {
        "supported": bool(
            share["isolation_forest"]
            and share["zscore"]
            and median["isolation_forest"] > 0.30
            and median["ZSCORE"] < 0.10
        ),
        "datasets_above": len({r["id"] for r in big}),
        "median_detect_share": median,
        "failed": [r["id"] for r in records if r["status"] != "OK"],
    }


def x_pipeline__mutmut_46(records: list[dict[str, Any]], large: int = 50_000) -> dict[str, Any]:
    """P4: detection share of the pipeline time on the datasets above ``large`` rows."""
    ok = [r for r in records if r["status"] == "OK"]
    big = [r for r in ok if r["rows_after_transform"] > large]
    share = {
        method: [r["detect_stage_share"] for r in big if r["method"] == method]
        for method in ("zscore", "isolation_forest")
    }
    median = {m: float(np.median(v)) if v else float("nan") for m, v in share.items()}
    return {
        "supported": bool(
            share["isolation_forest"]
            and share["zscore"]
            and median["isolation_forest"] > 0.30
            and median["zscore"] <= 0.10
        ),
        "datasets_above": len({r["id"] for r in big}),
        "median_detect_share": median,
        "failed": [r["id"] for r in records if r["status"] != "OK"],
    }


def x_pipeline__mutmut_47(records: list[dict[str, Any]], large: int = 50_000) -> dict[str, Any]:
    """P4: detection share of the pipeline time on the datasets above ``large`` rows."""
    ok = [r for r in records if r["status"] == "OK"]
    big = [r for r in ok if r["rows_after_transform"] > large]
    share = {
        method: [r["detect_stage_share"] for r in big if r["method"] == method]
        for method in ("zscore", "isolation_forest")
    }
    median = {m: float(np.median(v)) if v else float("nan") for m, v in share.items()}
    return {
        "supported": bool(
            share["isolation_forest"]
            and share["zscore"]
            and median["isolation_forest"] > 0.30
            and median["zscore"] < 1.1
        ),
        "datasets_above": len({r["id"] for r in big}),
        "median_detect_share": median,
        "failed": [r["id"] for r in records if r["status"] != "OK"],
    }


def x_pipeline__mutmut_48(records: list[dict[str, Any]], large: int = 50_000) -> dict[str, Any]:
    """P4: detection share of the pipeline time on the datasets above ``large`` rows."""
    ok = [r for r in records if r["status"] == "OK"]
    big = [r for r in ok if r["rows_after_transform"] > large]
    share = {
        method: [r["detect_stage_share"] for r in big if r["method"] == method]
        for method in ("zscore", "isolation_forest")
    }
    median = {m: float(np.median(v)) if v else float("nan") for m, v in share.items()}
    return {
        "supported": bool(
            share["isolation_forest"]
            and share["zscore"]
            and median["isolation_forest"] > 0.30
            and median["zscore"] < 0.10
        ),
        "XXdatasets_aboveXX": len({r["id"] for r in big}),
        "median_detect_share": median,
        "failed": [r["id"] for r in records if r["status"] != "OK"],
    }


def x_pipeline__mutmut_49(records: list[dict[str, Any]], large: int = 50_000) -> dict[str, Any]:
    """P4: detection share of the pipeline time on the datasets above ``large`` rows."""
    ok = [r for r in records if r["status"] == "OK"]
    big = [r for r in ok if r["rows_after_transform"] > large]
    share = {
        method: [r["detect_stage_share"] for r in big if r["method"] == method]
        for method in ("zscore", "isolation_forest")
    }
    median = {m: float(np.median(v)) if v else float("nan") for m, v in share.items()}
    return {
        "supported": bool(
            share["isolation_forest"]
            and share["zscore"]
            and median["isolation_forest"] > 0.30
            and median["zscore"] < 0.10
        ),
        "DATASETS_ABOVE": len({r["id"] for r in big}),
        "median_detect_share": median,
        "failed": [r["id"] for r in records if r["status"] != "OK"],
    }


def x_pipeline__mutmut_50(records: list[dict[str, Any]], large: int = 50_000) -> dict[str, Any]:
    """P4: detection share of the pipeline time on the datasets above ``large`` rows."""
    ok = [r for r in records if r["status"] == "OK"]
    big = [r for r in ok if r["rows_after_transform"] > large]
    share = {
        method: [r["detect_stage_share"] for r in big if r["method"] == method]
        for method in ("zscore", "isolation_forest")
    }
    median = {m: float(np.median(v)) if v else float("nan") for m, v in share.items()}
    return {
        "supported": bool(
            share["isolation_forest"]
            and share["zscore"]
            and median["isolation_forest"] > 0.30
            and median["zscore"] < 0.10
        ),
        "datasets_above": len({r["id"] for r in big}),
        "XXmedian_detect_shareXX": median,
        "failed": [r["id"] for r in records if r["status"] != "OK"],
    }


def x_pipeline__mutmut_51(records: list[dict[str, Any]], large: int = 50_000) -> dict[str, Any]:
    """P4: detection share of the pipeline time on the datasets above ``large`` rows."""
    ok = [r for r in records if r["status"] == "OK"]
    big = [r for r in ok if r["rows_after_transform"] > large]
    share = {
        method: [r["detect_stage_share"] for r in big if r["method"] == method]
        for method in ("zscore", "isolation_forest")
    }
    median = {m: float(np.median(v)) if v else float("nan") for m, v in share.items()}
    return {
        "supported": bool(
            share["isolation_forest"]
            and share["zscore"]
            and median["isolation_forest"] > 0.30
            and median["zscore"] < 0.10
        ),
        "datasets_above": len({r["id"] for r in big}),
        "MEDIAN_DETECT_SHARE": median,
        "failed": [r["id"] for r in records if r["status"] != "OK"],
    }


def x_pipeline__mutmut_52(records: list[dict[str, Any]], large: int = 50_000) -> dict[str, Any]:
    """P4: detection share of the pipeline time on the datasets above ``large`` rows."""
    ok = [r for r in records if r["status"] == "OK"]
    big = [r for r in ok if r["rows_after_transform"] > large]
    share = {
        method: [r["detect_stage_share"] for r in big if r["method"] == method]
        for method in ("zscore", "isolation_forest")
    }
    median = {m: float(np.median(v)) if v else float("nan") for m, v in share.items()}
    return {
        "supported": bool(
            share["isolation_forest"]
            and share["zscore"]
            and median["isolation_forest"] > 0.30
            and median["zscore"] < 0.10
        ),
        "datasets_above": len({r["id"] for r in big}),
        "median_detect_share": median,
        "XXfailedXX": [r["id"] for r in records if r["status"] != "OK"],
    }


def x_pipeline__mutmut_53(records: list[dict[str, Any]], large: int = 50_000) -> dict[str, Any]:
    """P4: detection share of the pipeline time on the datasets above ``large`` rows."""
    ok = [r for r in records if r["status"] == "OK"]
    big = [r for r in ok if r["rows_after_transform"] > large]
    share = {
        method: [r["detect_stage_share"] for r in big if r["method"] == method]
        for method in ("zscore", "isolation_forest")
    }
    median = {m: float(np.median(v)) if v else float("nan") for m, v in share.items()}
    return {
        "supported": bool(
            share["isolation_forest"]
            and share["zscore"]
            and median["isolation_forest"] > 0.30
            and median["zscore"] < 0.10
        ),
        "datasets_above": len({r["id"] for r in big}),
        "median_detect_share": median,
        "FAILED": [r["id"] for r in records if r["status"] != "OK"],
    }


def x_pipeline__mutmut_54(records: list[dict[str, Any]], large: int = 50_000) -> dict[str, Any]:
    """P4: detection share of the pipeline time on the datasets above ``large`` rows."""
    ok = [r for r in records if r["status"] == "OK"]
    big = [r for r in ok if r["rows_after_transform"] > large]
    share = {
        method: [r["detect_stage_share"] for r in big if r["method"] == method]
        for method in ("zscore", "isolation_forest")
    }
    median = {m: float(np.median(v)) if v else float("nan") for m, v in share.items()}
    return {
        "supported": bool(
            share["isolation_forest"]
            and share["zscore"]
            and median["isolation_forest"] > 0.30
            and median["zscore"] < 0.10
        ),
        "datasets_above": len({r["id"] for r in big}),
        "median_detect_share": median,
        "failed": [r["XXidXX"] for r in records if r["status"] != "OK"],
    }


def x_pipeline__mutmut_55(records: list[dict[str, Any]], large: int = 50_000) -> dict[str, Any]:
    """P4: detection share of the pipeline time on the datasets above ``large`` rows."""
    ok = [r for r in records if r["status"] == "OK"]
    big = [r for r in ok if r["rows_after_transform"] > large]
    share = {
        method: [r["detect_stage_share"] for r in big if r["method"] == method]
        for method in ("zscore", "isolation_forest")
    }
    median = {m: float(np.median(v)) if v else float("nan") for m, v in share.items()}
    return {
        "supported": bool(
            share["isolation_forest"]
            and share["zscore"]
            and median["isolation_forest"] > 0.30
            and median["zscore"] < 0.10
        ),
        "datasets_above": len({r["id"] for r in big}),
        "median_detect_share": median,
        "failed": [r["ID"] for r in records if r["status"] != "OK"],
    }


def x_pipeline__mutmut_56(records: list[dict[str, Any]], large: int = 50_000) -> dict[str, Any]:
    """P4: detection share of the pipeline time on the datasets above ``large`` rows."""
    ok = [r for r in records if r["status"] == "OK"]
    big = [r for r in ok if r["rows_after_transform"] > large]
    share = {
        method: [r["detect_stage_share"] for r in big if r["method"] == method]
        for method in ("zscore", "isolation_forest")
    }
    median = {m: float(np.median(v)) if v else float("nan") for m, v in share.items()}
    return {
        "supported": bool(
            share["isolation_forest"]
            and share["zscore"]
            and median["isolation_forest"] > 0.30
            and median["zscore"] < 0.10
        ),
        "datasets_above": len({r["id"] for r in big}),
        "median_detect_share": median,
        "failed": [r["id"] for r in records if r["XXstatusXX"] != "OK"],
    }


def x_pipeline__mutmut_57(records: list[dict[str, Any]], large: int = 50_000) -> dict[str, Any]:
    """P4: detection share of the pipeline time on the datasets above ``large`` rows."""
    ok = [r for r in records if r["status"] == "OK"]
    big = [r for r in ok if r["rows_after_transform"] > large]
    share = {
        method: [r["detect_stage_share"] for r in big if r["method"] == method]
        for method in ("zscore", "isolation_forest")
    }
    median = {m: float(np.median(v)) if v else float("nan") for m, v in share.items()}
    return {
        "supported": bool(
            share["isolation_forest"]
            and share["zscore"]
            and median["isolation_forest"] > 0.30
            and median["zscore"] < 0.10
        ),
        "datasets_above": len({r["id"] for r in big}),
        "median_detect_share": median,
        "failed": [r["id"] for r in records if r["STATUS"] != "OK"],
    }


def x_pipeline__mutmut_58(records: list[dict[str, Any]], large: int = 50_000) -> dict[str, Any]:
    """P4: detection share of the pipeline time on the datasets above ``large`` rows."""
    ok = [r for r in records if r["status"] == "OK"]
    big = [r for r in ok if r["rows_after_transform"] > large]
    share = {
        method: [r["detect_stage_share"] for r in big if r["method"] == method]
        for method in ("zscore", "isolation_forest")
    }
    median = {m: float(np.median(v)) if v else float("nan") for m, v in share.items()}
    return {
        "supported": bool(
            share["isolation_forest"]
            and share["zscore"]
            and median["isolation_forest"] > 0.30
            and median["zscore"] < 0.10
        ),
        "datasets_above": len({r["id"] for r in big}),
        "median_detect_share": median,
        "failed": [r["id"] for r in records if r["status"] == "OK"],
    }


def x_pipeline__mutmut_59(records: list[dict[str, Any]], large: int = 50_000) -> dict[str, Any]:
    """P4: detection share of the pipeline time on the datasets above ``large`` rows."""
    ok = [r for r in records if r["status"] == "OK"]
    big = [r for r in ok if r["rows_after_transform"] > large]
    share = {
        method: [r["detect_stage_share"] for r in big if r["method"] == method]
        for method in ("zscore", "isolation_forest")
    }
    median = {m: float(np.median(v)) if v else float("nan") for m, v in share.items()}
    return {
        "supported": bool(
            share["isolation_forest"]
            and share["zscore"]
            and median["isolation_forest"] > 0.30
            and median["zscore"] < 0.10
        ),
        "datasets_above": len({r["id"] for r in big}),
        "median_detect_share": median,
        "failed": [r["id"] for r in records if r["status"] != "XXOKXX"],
    }


def x_pipeline__mutmut_60(records: list[dict[str, Any]], large: int = 50_000) -> dict[str, Any]:
    """P4: detection share of the pipeline time on the datasets above ``large`` rows."""
    ok = [r for r in records if r["status"] == "OK"]
    big = [r for r in ok if r["rows_after_transform"] > large]
    share = {
        method: [r["detect_stage_share"] for r in big if r["method"] == method]
        for method in ("zscore", "isolation_forest")
    }
    median = {m: float(np.median(v)) if v else float("nan") for m, v in share.items()}
    return {
        "supported": bool(
            share["isolation_forest"]
            and share["zscore"]
            and median["isolation_forest"] > 0.30
            and median["zscore"] < 0.10
        ),
        "datasets_above": len({r["id"] for r in big}),
        "median_detect_share": median,
        "failed": [r["id"] for r in records if r["status"] != "ok"],
    }

mutants_x_pipeline__mutmut['_mutmut_orig'] = x_pipeline__mutmut_orig # type: ignore # mutmut generated
mutants_x_pipeline__mutmut['x_pipeline__mutmut_1'] = x_pipeline__mutmut_1 # type: ignore # mutmut generated
mutants_x_pipeline__mutmut['x_pipeline__mutmut_2'] = x_pipeline__mutmut_2 # type: ignore # mutmut generated
mutants_x_pipeline__mutmut['x_pipeline__mutmut_3'] = x_pipeline__mutmut_3 # type: ignore # mutmut generated
mutants_x_pipeline__mutmut['x_pipeline__mutmut_4'] = x_pipeline__mutmut_4 # type: ignore # mutmut generated
mutants_x_pipeline__mutmut['x_pipeline__mutmut_5'] = x_pipeline__mutmut_5 # type: ignore # mutmut generated
mutants_x_pipeline__mutmut['x_pipeline__mutmut_6'] = x_pipeline__mutmut_6 # type: ignore # mutmut generated
mutants_x_pipeline__mutmut['x_pipeline__mutmut_7'] = x_pipeline__mutmut_7 # type: ignore # mutmut generated
mutants_x_pipeline__mutmut['x_pipeline__mutmut_8'] = x_pipeline__mutmut_8 # type: ignore # mutmut generated
mutants_x_pipeline__mutmut['x_pipeline__mutmut_9'] = x_pipeline__mutmut_9 # type: ignore # mutmut generated
mutants_x_pipeline__mutmut['x_pipeline__mutmut_10'] = x_pipeline__mutmut_10 # type: ignore # mutmut generated
mutants_x_pipeline__mutmut['x_pipeline__mutmut_11'] = x_pipeline__mutmut_11 # type: ignore # mutmut generated
mutants_x_pipeline__mutmut['x_pipeline__mutmut_12'] = x_pipeline__mutmut_12 # type: ignore # mutmut generated
mutants_x_pipeline__mutmut['x_pipeline__mutmut_13'] = x_pipeline__mutmut_13 # type: ignore # mutmut generated
mutants_x_pipeline__mutmut['x_pipeline__mutmut_14'] = x_pipeline__mutmut_14 # type: ignore # mutmut generated
mutants_x_pipeline__mutmut['x_pipeline__mutmut_15'] = x_pipeline__mutmut_15 # type: ignore # mutmut generated
mutants_x_pipeline__mutmut['x_pipeline__mutmut_16'] = x_pipeline__mutmut_16 # type: ignore # mutmut generated
mutants_x_pipeline__mutmut['x_pipeline__mutmut_17'] = x_pipeline__mutmut_17 # type: ignore # mutmut generated
mutants_x_pipeline__mutmut['x_pipeline__mutmut_18'] = x_pipeline__mutmut_18 # type: ignore # mutmut generated
mutants_x_pipeline__mutmut['x_pipeline__mutmut_19'] = x_pipeline__mutmut_19 # type: ignore # mutmut generated
mutants_x_pipeline__mutmut['x_pipeline__mutmut_20'] = x_pipeline__mutmut_20 # type: ignore # mutmut generated
mutants_x_pipeline__mutmut['x_pipeline__mutmut_21'] = x_pipeline__mutmut_21 # type: ignore # mutmut generated
mutants_x_pipeline__mutmut['x_pipeline__mutmut_22'] = x_pipeline__mutmut_22 # type: ignore # mutmut generated
mutants_x_pipeline__mutmut['x_pipeline__mutmut_23'] = x_pipeline__mutmut_23 # type: ignore # mutmut generated
mutants_x_pipeline__mutmut['x_pipeline__mutmut_24'] = x_pipeline__mutmut_24 # type: ignore # mutmut generated
mutants_x_pipeline__mutmut['x_pipeline__mutmut_25'] = x_pipeline__mutmut_25 # type: ignore # mutmut generated
mutants_x_pipeline__mutmut['x_pipeline__mutmut_26'] = x_pipeline__mutmut_26 # type: ignore # mutmut generated
mutants_x_pipeline__mutmut['x_pipeline__mutmut_27'] = x_pipeline__mutmut_27 # type: ignore # mutmut generated
mutants_x_pipeline__mutmut['x_pipeline__mutmut_28'] = x_pipeline__mutmut_28 # type: ignore # mutmut generated
mutants_x_pipeline__mutmut['x_pipeline__mutmut_29'] = x_pipeline__mutmut_29 # type: ignore # mutmut generated
mutants_x_pipeline__mutmut['x_pipeline__mutmut_30'] = x_pipeline__mutmut_30 # type: ignore # mutmut generated
mutants_x_pipeline__mutmut['x_pipeline__mutmut_31'] = x_pipeline__mutmut_31 # type: ignore # mutmut generated
mutants_x_pipeline__mutmut['x_pipeline__mutmut_32'] = x_pipeline__mutmut_32 # type: ignore # mutmut generated
mutants_x_pipeline__mutmut['x_pipeline__mutmut_33'] = x_pipeline__mutmut_33 # type: ignore # mutmut generated
mutants_x_pipeline__mutmut['x_pipeline__mutmut_34'] = x_pipeline__mutmut_34 # type: ignore # mutmut generated
mutants_x_pipeline__mutmut['x_pipeline__mutmut_35'] = x_pipeline__mutmut_35 # type: ignore # mutmut generated
mutants_x_pipeline__mutmut['x_pipeline__mutmut_36'] = x_pipeline__mutmut_36 # type: ignore # mutmut generated
mutants_x_pipeline__mutmut['x_pipeline__mutmut_37'] = x_pipeline__mutmut_37 # type: ignore # mutmut generated
mutants_x_pipeline__mutmut['x_pipeline__mutmut_38'] = x_pipeline__mutmut_38 # type: ignore # mutmut generated
mutants_x_pipeline__mutmut['x_pipeline__mutmut_39'] = x_pipeline__mutmut_39 # type: ignore # mutmut generated
mutants_x_pipeline__mutmut['x_pipeline__mutmut_40'] = x_pipeline__mutmut_40 # type: ignore # mutmut generated
mutants_x_pipeline__mutmut['x_pipeline__mutmut_41'] = x_pipeline__mutmut_41 # type: ignore # mutmut generated
mutants_x_pipeline__mutmut['x_pipeline__mutmut_42'] = x_pipeline__mutmut_42 # type: ignore # mutmut generated
mutants_x_pipeline__mutmut['x_pipeline__mutmut_43'] = x_pipeline__mutmut_43 # type: ignore # mutmut generated
mutants_x_pipeline__mutmut['x_pipeline__mutmut_44'] = x_pipeline__mutmut_44 # type: ignore # mutmut generated
mutants_x_pipeline__mutmut['x_pipeline__mutmut_45'] = x_pipeline__mutmut_45 # type: ignore # mutmut generated
mutants_x_pipeline__mutmut['x_pipeline__mutmut_46'] = x_pipeline__mutmut_46 # type: ignore # mutmut generated
mutants_x_pipeline__mutmut['x_pipeline__mutmut_47'] = x_pipeline__mutmut_47 # type: ignore # mutmut generated
mutants_x_pipeline__mutmut['x_pipeline__mutmut_48'] = x_pipeline__mutmut_48 # type: ignore # mutmut generated
mutants_x_pipeline__mutmut['x_pipeline__mutmut_49'] = x_pipeline__mutmut_49 # type: ignore # mutmut generated
mutants_x_pipeline__mutmut['x_pipeline__mutmut_50'] = x_pipeline__mutmut_50 # type: ignore # mutmut generated
mutants_x_pipeline__mutmut['x_pipeline__mutmut_51'] = x_pipeline__mutmut_51 # type: ignore # mutmut generated
mutants_x_pipeline__mutmut['x_pipeline__mutmut_52'] = x_pipeline__mutmut_52 # type: ignore # mutmut generated
mutants_x_pipeline__mutmut['x_pipeline__mutmut_53'] = x_pipeline__mutmut_53 # type: ignore # mutmut generated
mutants_x_pipeline__mutmut['x_pipeline__mutmut_54'] = x_pipeline__mutmut_54 # type: ignore # mutmut generated
mutants_x_pipeline__mutmut['x_pipeline__mutmut_55'] = x_pipeline__mutmut_55 # type: ignore # mutmut generated
mutants_x_pipeline__mutmut['x_pipeline__mutmut_56'] = x_pipeline__mutmut_56 # type: ignore # mutmut generated
mutants_x_pipeline__mutmut['x_pipeline__mutmut_57'] = x_pipeline__mutmut_57 # type: ignore # mutmut generated
mutants_x_pipeline__mutmut['x_pipeline__mutmut_58'] = x_pipeline__mutmut_58 # type: ignore # mutmut generated
mutants_x_pipeline__mutmut['x_pipeline__mutmut_59'] = x_pipeline__mutmut_59 # type: ignore # mutmut generated
mutants_x_pipeline__mutmut['x_pipeline__mutmut_60'] = x_pipeline__mutmut_60 # type: ignore # mutmut generated
mutants_x_chronology__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_chronology__mutmut)
def chronology(results: dict[str, dict[str, Any]]) -> dict[str, Any]:
    """P5: the chronological PR-AUC below the stratified one for two thirds of the pairs."""
    pairs = lower = 0
    by_dataset = {}
    for name, result in results.items():
        if "excluded" in result:
            by_dataset[name] = {"excluded": result["excluded"]}
            continue
        count = sum(
            result["chronological"][m]["pr_auc"] < result["stratified"][m]["pr_auc"]
            for m in result["chronological"]
        )
        by_dataset[name] = {"lower": int(count), "detectors": len(result["chronological"])}
        pairs += len(result["chronological"])
        lower += count
    return {
        "supported": bool(pairs and lower >= 2 * pairs / 3),
        "lower": int(lower),
        "pairs": int(pairs),
        "by_dataset": by_dataset,
    }


def x_chronology__mutmut_orig(results: dict[str, dict[str, Any]]) -> dict[str, Any]:
    """P5: the chronological PR-AUC below the stratified one for two thirds of the pairs."""
    pairs = lower = 0
    by_dataset = {}
    for name, result in results.items():
        if "excluded" in result:
            by_dataset[name] = {"excluded": result["excluded"]}
            continue
        count = sum(
            result["chronological"][m]["pr_auc"] < result["stratified"][m]["pr_auc"]
            for m in result["chronological"]
        )
        by_dataset[name] = {"lower": int(count), "detectors": len(result["chronological"])}
        pairs += len(result["chronological"])
        lower += count
    return {
        "supported": bool(pairs and lower >= 2 * pairs / 3),
        "lower": int(lower),
        "pairs": int(pairs),
        "by_dataset": by_dataset,
    }


def x_chronology__mutmut_1(results: dict[str, dict[str, Any]]) -> dict[str, Any]:
    """P5: the chronological PR-AUC below the stratified one for two thirds of the pairs."""
    pairs = lower = None
    by_dataset = {}
    for name, result in results.items():
        if "excluded" in result:
            by_dataset[name] = {"excluded": result["excluded"]}
            continue
        count = sum(
            result["chronological"][m]["pr_auc"] < result["stratified"][m]["pr_auc"]
            for m in result["chronological"]
        )
        by_dataset[name] = {"lower": int(count), "detectors": len(result["chronological"])}
        pairs += len(result["chronological"])
        lower += count
    return {
        "supported": bool(pairs and lower >= 2 * pairs / 3),
        "lower": int(lower),
        "pairs": int(pairs),
        "by_dataset": by_dataset,
    }


def x_chronology__mutmut_2(results: dict[str, dict[str, Any]]) -> dict[str, Any]:
    """P5: the chronological PR-AUC below the stratified one for two thirds of the pairs."""
    pairs = lower = 1
    by_dataset = {}
    for name, result in results.items():
        if "excluded" in result:
            by_dataset[name] = {"excluded": result["excluded"]}
            continue
        count = sum(
            result["chronological"][m]["pr_auc"] < result["stratified"][m]["pr_auc"]
            for m in result["chronological"]
        )
        by_dataset[name] = {"lower": int(count), "detectors": len(result["chronological"])}
        pairs += len(result["chronological"])
        lower += count
    return {
        "supported": bool(pairs and lower >= 2 * pairs / 3),
        "lower": int(lower),
        "pairs": int(pairs),
        "by_dataset": by_dataset,
    }


def x_chronology__mutmut_3(results: dict[str, dict[str, Any]]) -> dict[str, Any]:
    """P5: the chronological PR-AUC below the stratified one for two thirds of the pairs."""
    pairs = lower = 0
    by_dataset = None
    for name, result in results.items():
        if "excluded" in result:
            by_dataset[name] = {"excluded": result["excluded"]}
            continue
        count = sum(
            result["chronological"][m]["pr_auc"] < result["stratified"][m]["pr_auc"]
            for m in result["chronological"]
        )
        by_dataset[name] = {"lower": int(count), "detectors": len(result["chronological"])}
        pairs += len(result["chronological"])
        lower += count
    return {
        "supported": bool(pairs and lower >= 2 * pairs / 3),
        "lower": int(lower),
        "pairs": int(pairs),
        "by_dataset": by_dataset,
    }


def x_chronology__mutmut_4(results: dict[str, dict[str, Any]]) -> dict[str, Any]:
    """P5: the chronological PR-AUC below the stratified one for two thirds of the pairs."""
    pairs = lower = 0
    by_dataset = {}
    for name, result in results.items():
        if "XXexcludedXX" in result:
            by_dataset[name] = {"excluded": result["excluded"]}
            continue
        count = sum(
            result["chronological"][m]["pr_auc"] < result["stratified"][m]["pr_auc"]
            for m in result["chronological"]
        )
        by_dataset[name] = {"lower": int(count), "detectors": len(result["chronological"])}
        pairs += len(result["chronological"])
        lower += count
    return {
        "supported": bool(pairs and lower >= 2 * pairs / 3),
        "lower": int(lower),
        "pairs": int(pairs),
        "by_dataset": by_dataset,
    }


def x_chronology__mutmut_5(results: dict[str, dict[str, Any]]) -> dict[str, Any]:
    """P5: the chronological PR-AUC below the stratified one for two thirds of the pairs."""
    pairs = lower = 0
    by_dataset = {}
    for name, result in results.items():
        if "EXCLUDED" in result:
            by_dataset[name] = {"excluded": result["excluded"]}
            continue
        count = sum(
            result["chronological"][m]["pr_auc"] < result["stratified"][m]["pr_auc"]
            for m in result["chronological"]
        )
        by_dataset[name] = {"lower": int(count), "detectors": len(result["chronological"])}
        pairs += len(result["chronological"])
        lower += count
    return {
        "supported": bool(pairs and lower >= 2 * pairs / 3),
        "lower": int(lower),
        "pairs": int(pairs),
        "by_dataset": by_dataset,
    }


def x_chronology__mutmut_6(results: dict[str, dict[str, Any]]) -> dict[str, Any]:
    """P5: the chronological PR-AUC below the stratified one for two thirds of the pairs."""
    pairs = lower = 0
    by_dataset = {}
    for name, result in results.items():
        if "excluded" not in result:
            by_dataset[name] = {"excluded": result["excluded"]}
            continue
        count = sum(
            result["chronological"][m]["pr_auc"] < result["stratified"][m]["pr_auc"]
            for m in result["chronological"]
        )
        by_dataset[name] = {"lower": int(count), "detectors": len(result["chronological"])}
        pairs += len(result["chronological"])
        lower += count
    return {
        "supported": bool(pairs and lower >= 2 * pairs / 3),
        "lower": int(lower),
        "pairs": int(pairs),
        "by_dataset": by_dataset,
    }


def x_chronology__mutmut_7(results: dict[str, dict[str, Any]]) -> dict[str, Any]:
    """P5: the chronological PR-AUC below the stratified one for two thirds of the pairs."""
    pairs = lower = 0
    by_dataset = {}
    for name, result in results.items():
        if "excluded" in result:
            by_dataset[name] = None
            continue
        count = sum(
            result["chronological"][m]["pr_auc"] < result["stratified"][m]["pr_auc"]
            for m in result["chronological"]
        )
        by_dataset[name] = {"lower": int(count), "detectors": len(result["chronological"])}
        pairs += len(result["chronological"])
        lower += count
    return {
        "supported": bool(pairs and lower >= 2 * pairs / 3),
        "lower": int(lower),
        "pairs": int(pairs),
        "by_dataset": by_dataset,
    }


def x_chronology__mutmut_8(results: dict[str, dict[str, Any]]) -> dict[str, Any]:
    """P5: the chronological PR-AUC below the stratified one for two thirds of the pairs."""
    pairs = lower = 0
    by_dataset = {}
    for name, result in results.items():
        if "excluded" in result:
            by_dataset[name] = {"XXexcludedXX": result["excluded"]}
            continue
        count = sum(
            result["chronological"][m]["pr_auc"] < result["stratified"][m]["pr_auc"]
            for m in result["chronological"]
        )
        by_dataset[name] = {"lower": int(count), "detectors": len(result["chronological"])}
        pairs += len(result["chronological"])
        lower += count
    return {
        "supported": bool(pairs and lower >= 2 * pairs / 3),
        "lower": int(lower),
        "pairs": int(pairs),
        "by_dataset": by_dataset,
    }


def x_chronology__mutmut_9(results: dict[str, dict[str, Any]]) -> dict[str, Any]:
    """P5: the chronological PR-AUC below the stratified one for two thirds of the pairs."""
    pairs = lower = 0
    by_dataset = {}
    for name, result in results.items():
        if "excluded" in result:
            by_dataset[name] = {"EXCLUDED": result["excluded"]}
            continue
        count = sum(
            result["chronological"][m]["pr_auc"] < result["stratified"][m]["pr_auc"]
            for m in result["chronological"]
        )
        by_dataset[name] = {"lower": int(count), "detectors": len(result["chronological"])}
        pairs += len(result["chronological"])
        lower += count
    return {
        "supported": bool(pairs and lower >= 2 * pairs / 3),
        "lower": int(lower),
        "pairs": int(pairs),
        "by_dataset": by_dataset,
    }


def x_chronology__mutmut_10(results: dict[str, dict[str, Any]]) -> dict[str, Any]:
    """P5: the chronological PR-AUC below the stratified one for two thirds of the pairs."""
    pairs = lower = 0
    by_dataset = {}
    for name, result in results.items():
        if "excluded" in result:
            by_dataset[name] = {"excluded": result["XXexcludedXX"]}
            continue
        count = sum(
            result["chronological"][m]["pr_auc"] < result["stratified"][m]["pr_auc"]
            for m in result["chronological"]
        )
        by_dataset[name] = {"lower": int(count), "detectors": len(result["chronological"])}
        pairs += len(result["chronological"])
        lower += count
    return {
        "supported": bool(pairs and lower >= 2 * pairs / 3),
        "lower": int(lower),
        "pairs": int(pairs),
        "by_dataset": by_dataset,
    }


def x_chronology__mutmut_11(results: dict[str, dict[str, Any]]) -> dict[str, Any]:
    """P5: the chronological PR-AUC below the stratified one for two thirds of the pairs."""
    pairs = lower = 0
    by_dataset = {}
    for name, result in results.items():
        if "excluded" in result:
            by_dataset[name] = {"excluded": result["EXCLUDED"]}
            continue
        count = sum(
            result["chronological"][m]["pr_auc"] < result["stratified"][m]["pr_auc"]
            for m in result["chronological"]
        )
        by_dataset[name] = {"lower": int(count), "detectors": len(result["chronological"])}
        pairs += len(result["chronological"])
        lower += count
    return {
        "supported": bool(pairs and lower >= 2 * pairs / 3),
        "lower": int(lower),
        "pairs": int(pairs),
        "by_dataset": by_dataset,
    }


def x_chronology__mutmut_12(results: dict[str, dict[str, Any]]) -> dict[str, Any]:
    """P5: the chronological PR-AUC below the stratified one for two thirds of the pairs."""
    pairs = lower = 0
    by_dataset = {}
    for name, result in results.items():
        if "excluded" in result:
            by_dataset[name] = {"excluded": result["excluded"]}
            break
        count = sum(
            result["chronological"][m]["pr_auc"] < result["stratified"][m]["pr_auc"]
            for m in result["chronological"]
        )
        by_dataset[name] = {"lower": int(count), "detectors": len(result["chronological"])}
        pairs += len(result["chronological"])
        lower += count
    return {
        "supported": bool(pairs and lower >= 2 * pairs / 3),
        "lower": int(lower),
        "pairs": int(pairs),
        "by_dataset": by_dataset,
    }


def x_chronology__mutmut_13(results: dict[str, dict[str, Any]]) -> dict[str, Any]:
    """P5: the chronological PR-AUC below the stratified one for two thirds of the pairs."""
    pairs = lower = 0
    by_dataset = {}
    for name, result in results.items():
        if "excluded" in result:
            by_dataset[name] = {"excluded": result["excluded"]}
            continue
        count = None
        by_dataset[name] = {"lower": int(count), "detectors": len(result["chronological"])}
        pairs += len(result["chronological"])
        lower += count
    return {
        "supported": bool(pairs and lower >= 2 * pairs / 3),
        "lower": int(lower),
        "pairs": int(pairs),
        "by_dataset": by_dataset,
    }


def x_chronology__mutmut_14(results: dict[str, dict[str, Any]]) -> dict[str, Any]:
    """P5: the chronological PR-AUC below the stratified one for two thirds of the pairs."""
    pairs = lower = 0
    by_dataset = {}
    for name, result in results.items():
        if "excluded" in result:
            by_dataset[name] = {"excluded": result["excluded"]}
            continue
        count = sum(
            None
        )
        by_dataset[name] = {"lower": int(count), "detectors": len(result["chronological"])}
        pairs += len(result["chronological"])
        lower += count
    return {
        "supported": bool(pairs and lower >= 2 * pairs / 3),
        "lower": int(lower),
        "pairs": int(pairs),
        "by_dataset": by_dataset,
    }


def x_chronology__mutmut_15(results: dict[str, dict[str, Any]]) -> dict[str, Any]:
    """P5: the chronological PR-AUC below the stratified one for two thirds of the pairs."""
    pairs = lower = 0
    by_dataset = {}
    for name, result in results.items():
        if "excluded" in result:
            by_dataset[name] = {"excluded": result["excluded"]}
            continue
        count = sum(
            result["XXchronologicalXX"][m]["pr_auc"] < result["stratified"][m]["pr_auc"]
            for m in result["chronological"]
        )
        by_dataset[name] = {"lower": int(count), "detectors": len(result["chronological"])}
        pairs += len(result["chronological"])
        lower += count
    return {
        "supported": bool(pairs and lower >= 2 * pairs / 3),
        "lower": int(lower),
        "pairs": int(pairs),
        "by_dataset": by_dataset,
    }


def x_chronology__mutmut_16(results: dict[str, dict[str, Any]]) -> dict[str, Any]:
    """P5: the chronological PR-AUC below the stratified one for two thirds of the pairs."""
    pairs = lower = 0
    by_dataset = {}
    for name, result in results.items():
        if "excluded" in result:
            by_dataset[name] = {"excluded": result["excluded"]}
            continue
        count = sum(
            result["CHRONOLOGICAL"][m]["pr_auc"] < result["stratified"][m]["pr_auc"]
            for m in result["chronological"]
        )
        by_dataset[name] = {"lower": int(count), "detectors": len(result["chronological"])}
        pairs += len(result["chronological"])
        lower += count
    return {
        "supported": bool(pairs and lower >= 2 * pairs / 3),
        "lower": int(lower),
        "pairs": int(pairs),
        "by_dataset": by_dataset,
    }


def x_chronology__mutmut_17(results: dict[str, dict[str, Any]]) -> dict[str, Any]:
    """P5: the chronological PR-AUC below the stratified one for two thirds of the pairs."""
    pairs = lower = 0
    by_dataset = {}
    for name, result in results.items():
        if "excluded" in result:
            by_dataset[name] = {"excluded": result["excluded"]}
            continue
        count = sum(
            result["chronological"][m]["XXpr_aucXX"] < result["stratified"][m]["pr_auc"]
            for m in result["chronological"]
        )
        by_dataset[name] = {"lower": int(count), "detectors": len(result["chronological"])}
        pairs += len(result["chronological"])
        lower += count
    return {
        "supported": bool(pairs and lower >= 2 * pairs / 3),
        "lower": int(lower),
        "pairs": int(pairs),
        "by_dataset": by_dataset,
    }


def x_chronology__mutmut_18(results: dict[str, dict[str, Any]]) -> dict[str, Any]:
    """P5: the chronological PR-AUC below the stratified one for two thirds of the pairs."""
    pairs = lower = 0
    by_dataset = {}
    for name, result in results.items():
        if "excluded" in result:
            by_dataset[name] = {"excluded": result["excluded"]}
            continue
        count = sum(
            result["chronological"][m]["PR_AUC"] < result["stratified"][m]["pr_auc"]
            for m in result["chronological"]
        )
        by_dataset[name] = {"lower": int(count), "detectors": len(result["chronological"])}
        pairs += len(result["chronological"])
        lower += count
    return {
        "supported": bool(pairs and lower >= 2 * pairs / 3),
        "lower": int(lower),
        "pairs": int(pairs),
        "by_dataset": by_dataset,
    }


def x_chronology__mutmut_19(results: dict[str, dict[str, Any]]) -> dict[str, Any]:
    """P5: the chronological PR-AUC below the stratified one for two thirds of the pairs."""
    pairs = lower = 0
    by_dataset = {}
    for name, result in results.items():
        if "excluded" in result:
            by_dataset[name] = {"excluded": result["excluded"]}
            continue
        count = sum(
            result["chronological"][m]["pr_auc"] <= result["stratified"][m]["pr_auc"]
            for m in result["chronological"]
        )
        by_dataset[name] = {"lower": int(count), "detectors": len(result["chronological"])}
        pairs += len(result["chronological"])
        lower += count
    return {
        "supported": bool(pairs and lower >= 2 * pairs / 3),
        "lower": int(lower),
        "pairs": int(pairs),
        "by_dataset": by_dataset,
    }


def x_chronology__mutmut_20(results: dict[str, dict[str, Any]]) -> dict[str, Any]:
    """P5: the chronological PR-AUC below the stratified one for two thirds of the pairs."""
    pairs = lower = 0
    by_dataset = {}
    for name, result in results.items():
        if "excluded" in result:
            by_dataset[name] = {"excluded": result["excluded"]}
            continue
        count = sum(
            result["chronological"][m]["pr_auc"] < result["XXstratifiedXX"][m]["pr_auc"]
            for m in result["chronological"]
        )
        by_dataset[name] = {"lower": int(count), "detectors": len(result["chronological"])}
        pairs += len(result["chronological"])
        lower += count
    return {
        "supported": bool(pairs and lower >= 2 * pairs / 3),
        "lower": int(lower),
        "pairs": int(pairs),
        "by_dataset": by_dataset,
    }


def x_chronology__mutmut_21(results: dict[str, dict[str, Any]]) -> dict[str, Any]:
    """P5: the chronological PR-AUC below the stratified one for two thirds of the pairs."""
    pairs = lower = 0
    by_dataset = {}
    for name, result in results.items():
        if "excluded" in result:
            by_dataset[name] = {"excluded": result["excluded"]}
            continue
        count = sum(
            result["chronological"][m]["pr_auc"] < result["STRATIFIED"][m]["pr_auc"]
            for m in result["chronological"]
        )
        by_dataset[name] = {"lower": int(count), "detectors": len(result["chronological"])}
        pairs += len(result["chronological"])
        lower += count
    return {
        "supported": bool(pairs and lower >= 2 * pairs / 3),
        "lower": int(lower),
        "pairs": int(pairs),
        "by_dataset": by_dataset,
    }


def x_chronology__mutmut_22(results: dict[str, dict[str, Any]]) -> dict[str, Any]:
    """P5: the chronological PR-AUC below the stratified one for two thirds of the pairs."""
    pairs = lower = 0
    by_dataset = {}
    for name, result in results.items():
        if "excluded" in result:
            by_dataset[name] = {"excluded": result["excluded"]}
            continue
        count = sum(
            result["chronological"][m]["pr_auc"] < result["stratified"][m]["XXpr_aucXX"]
            for m in result["chronological"]
        )
        by_dataset[name] = {"lower": int(count), "detectors": len(result["chronological"])}
        pairs += len(result["chronological"])
        lower += count
    return {
        "supported": bool(pairs and lower >= 2 * pairs / 3),
        "lower": int(lower),
        "pairs": int(pairs),
        "by_dataset": by_dataset,
    }


def x_chronology__mutmut_23(results: dict[str, dict[str, Any]]) -> dict[str, Any]:
    """P5: the chronological PR-AUC below the stratified one for two thirds of the pairs."""
    pairs = lower = 0
    by_dataset = {}
    for name, result in results.items():
        if "excluded" in result:
            by_dataset[name] = {"excluded": result["excluded"]}
            continue
        count = sum(
            result["chronological"][m]["pr_auc"] < result["stratified"][m]["PR_AUC"]
            for m in result["chronological"]
        )
        by_dataset[name] = {"lower": int(count), "detectors": len(result["chronological"])}
        pairs += len(result["chronological"])
        lower += count
    return {
        "supported": bool(pairs and lower >= 2 * pairs / 3),
        "lower": int(lower),
        "pairs": int(pairs),
        "by_dataset": by_dataset,
    }


def x_chronology__mutmut_24(results: dict[str, dict[str, Any]]) -> dict[str, Any]:
    """P5: the chronological PR-AUC below the stratified one for two thirds of the pairs."""
    pairs = lower = 0
    by_dataset = {}
    for name, result in results.items():
        if "excluded" in result:
            by_dataset[name] = {"excluded": result["excluded"]}
            continue
        count = sum(
            result["chronological"][m]["pr_auc"] < result["stratified"][m]["pr_auc"]
            for m in result["XXchronologicalXX"]
        )
        by_dataset[name] = {"lower": int(count), "detectors": len(result["chronological"])}
        pairs += len(result["chronological"])
        lower += count
    return {
        "supported": bool(pairs and lower >= 2 * pairs / 3),
        "lower": int(lower),
        "pairs": int(pairs),
        "by_dataset": by_dataset,
    }


def x_chronology__mutmut_25(results: dict[str, dict[str, Any]]) -> dict[str, Any]:
    """P5: the chronological PR-AUC below the stratified one for two thirds of the pairs."""
    pairs = lower = 0
    by_dataset = {}
    for name, result in results.items():
        if "excluded" in result:
            by_dataset[name] = {"excluded": result["excluded"]}
            continue
        count = sum(
            result["chronological"][m]["pr_auc"] < result["stratified"][m]["pr_auc"]
            for m in result["CHRONOLOGICAL"]
        )
        by_dataset[name] = {"lower": int(count), "detectors": len(result["chronological"])}
        pairs += len(result["chronological"])
        lower += count
    return {
        "supported": bool(pairs and lower >= 2 * pairs / 3),
        "lower": int(lower),
        "pairs": int(pairs),
        "by_dataset": by_dataset,
    }


def x_chronology__mutmut_26(results: dict[str, dict[str, Any]]) -> dict[str, Any]:
    """P5: the chronological PR-AUC below the stratified one for two thirds of the pairs."""
    pairs = lower = 0
    by_dataset = {}
    for name, result in results.items():
        if "excluded" in result:
            by_dataset[name] = {"excluded": result["excluded"]}
            continue
        count = sum(
            result["chronological"][m]["pr_auc"] < result["stratified"][m]["pr_auc"]
            for m in result["chronological"]
        )
        by_dataset[name] = None
        pairs += len(result["chronological"])
        lower += count
    return {
        "supported": bool(pairs and lower >= 2 * pairs / 3),
        "lower": int(lower),
        "pairs": int(pairs),
        "by_dataset": by_dataset,
    }


def x_chronology__mutmut_27(results: dict[str, dict[str, Any]]) -> dict[str, Any]:
    """P5: the chronological PR-AUC below the stratified one for two thirds of the pairs."""
    pairs = lower = 0
    by_dataset = {}
    for name, result in results.items():
        if "excluded" in result:
            by_dataset[name] = {"excluded": result["excluded"]}
            continue
        count = sum(
            result["chronological"][m]["pr_auc"] < result["stratified"][m]["pr_auc"]
            for m in result["chronological"]
        )
        by_dataset[name] = {"XXlowerXX": int(count), "detectors": len(result["chronological"])}
        pairs += len(result["chronological"])
        lower += count
    return {
        "supported": bool(pairs and lower >= 2 * pairs / 3),
        "lower": int(lower),
        "pairs": int(pairs),
        "by_dataset": by_dataset,
    }


def x_chronology__mutmut_28(results: dict[str, dict[str, Any]]) -> dict[str, Any]:
    """P5: the chronological PR-AUC below the stratified one for two thirds of the pairs."""
    pairs = lower = 0
    by_dataset = {}
    for name, result in results.items():
        if "excluded" in result:
            by_dataset[name] = {"excluded": result["excluded"]}
            continue
        count = sum(
            result["chronological"][m]["pr_auc"] < result["stratified"][m]["pr_auc"]
            for m in result["chronological"]
        )
        by_dataset[name] = {"LOWER": int(count), "detectors": len(result["chronological"])}
        pairs += len(result["chronological"])
        lower += count
    return {
        "supported": bool(pairs and lower >= 2 * pairs / 3),
        "lower": int(lower),
        "pairs": int(pairs),
        "by_dataset": by_dataset,
    }


def x_chronology__mutmut_29(results: dict[str, dict[str, Any]]) -> dict[str, Any]:
    """P5: the chronological PR-AUC below the stratified one for two thirds of the pairs."""
    pairs = lower = 0
    by_dataset = {}
    for name, result in results.items():
        if "excluded" in result:
            by_dataset[name] = {"excluded": result["excluded"]}
            continue
        count = sum(
            result["chronological"][m]["pr_auc"] < result["stratified"][m]["pr_auc"]
            for m in result["chronological"]
        )
        by_dataset[name] = {"lower": int(None), "detectors": len(result["chronological"])}
        pairs += len(result["chronological"])
        lower += count
    return {
        "supported": bool(pairs and lower >= 2 * pairs / 3),
        "lower": int(lower),
        "pairs": int(pairs),
        "by_dataset": by_dataset,
    }


def x_chronology__mutmut_30(results: dict[str, dict[str, Any]]) -> dict[str, Any]:
    """P5: the chronological PR-AUC below the stratified one for two thirds of the pairs."""
    pairs = lower = 0
    by_dataset = {}
    for name, result in results.items():
        if "excluded" in result:
            by_dataset[name] = {"excluded": result["excluded"]}
            continue
        count = sum(
            result["chronological"][m]["pr_auc"] < result["stratified"][m]["pr_auc"]
            for m in result["chronological"]
        )
        by_dataset[name] = {"lower": int(count), "XXdetectorsXX": len(result["chronological"])}
        pairs += len(result["chronological"])
        lower += count
    return {
        "supported": bool(pairs and lower >= 2 * pairs / 3),
        "lower": int(lower),
        "pairs": int(pairs),
        "by_dataset": by_dataset,
    }


def x_chronology__mutmut_31(results: dict[str, dict[str, Any]]) -> dict[str, Any]:
    """P5: the chronological PR-AUC below the stratified one for two thirds of the pairs."""
    pairs = lower = 0
    by_dataset = {}
    for name, result in results.items():
        if "excluded" in result:
            by_dataset[name] = {"excluded": result["excluded"]}
            continue
        count = sum(
            result["chronological"][m]["pr_auc"] < result["stratified"][m]["pr_auc"]
            for m in result["chronological"]
        )
        by_dataset[name] = {"lower": int(count), "DETECTORS": len(result["chronological"])}
        pairs += len(result["chronological"])
        lower += count
    return {
        "supported": bool(pairs and lower >= 2 * pairs / 3),
        "lower": int(lower),
        "pairs": int(pairs),
        "by_dataset": by_dataset,
    }


def x_chronology__mutmut_32(results: dict[str, dict[str, Any]]) -> dict[str, Any]:
    """P5: the chronological PR-AUC below the stratified one for two thirds of the pairs."""
    pairs = lower = 0
    by_dataset = {}
    for name, result in results.items():
        if "excluded" in result:
            by_dataset[name] = {"excluded": result["excluded"]}
            continue
        count = sum(
            result["chronological"][m]["pr_auc"] < result["stratified"][m]["pr_auc"]
            for m in result["chronological"]
        )
        by_dataset[name] = {"lower": int(count), "detectors": len(result["chronological"])}
        pairs = len(result["chronological"])
        lower += count
    return {
        "supported": bool(pairs and lower >= 2 * pairs / 3),
        "lower": int(lower),
        "pairs": int(pairs),
        "by_dataset": by_dataset,
    }


def x_chronology__mutmut_33(results: dict[str, dict[str, Any]]) -> dict[str, Any]:
    """P5: the chronological PR-AUC below the stratified one for two thirds of the pairs."""
    pairs = lower = 0
    by_dataset = {}
    for name, result in results.items():
        if "excluded" in result:
            by_dataset[name] = {"excluded": result["excluded"]}
            continue
        count = sum(
            result["chronological"][m]["pr_auc"] < result["stratified"][m]["pr_auc"]
            for m in result["chronological"]
        )
        by_dataset[name] = {"lower": int(count), "detectors": len(result["chronological"])}
        pairs -= len(result["chronological"])
        lower += count
    return {
        "supported": bool(pairs and lower >= 2 * pairs / 3),
        "lower": int(lower),
        "pairs": int(pairs),
        "by_dataset": by_dataset,
    }


def x_chronology__mutmut_34(results: dict[str, dict[str, Any]]) -> dict[str, Any]:
    """P5: the chronological PR-AUC below the stratified one for two thirds of the pairs."""
    pairs = lower = 0
    by_dataset = {}
    for name, result in results.items():
        if "excluded" in result:
            by_dataset[name] = {"excluded": result["excluded"]}
            continue
        count = sum(
            result["chronological"][m]["pr_auc"] < result["stratified"][m]["pr_auc"]
            for m in result["chronological"]
        )
        by_dataset[name] = {"lower": int(count), "detectors": len(result["chronological"])}
        pairs += len(result["chronological"])
        lower = count
    return {
        "supported": bool(pairs and lower >= 2 * pairs / 3),
        "lower": int(lower),
        "pairs": int(pairs),
        "by_dataset": by_dataset,
    }


def x_chronology__mutmut_35(results: dict[str, dict[str, Any]]) -> dict[str, Any]:
    """P5: the chronological PR-AUC below the stratified one for two thirds of the pairs."""
    pairs = lower = 0
    by_dataset = {}
    for name, result in results.items():
        if "excluded" in result:
            by_dataset[name] = {"excluded": result["excluded"]}
            continue
        count = sum(
            result["chronological"][m]["pr_auc"] < result["stratified"][m]["pr_auc"]
            for m in result["chronological"]
        )
        by_dataset[name] = {"lower": int(count), "detectors": len(result["chronological"])}
        pairs += len(result["chronological"])
        lower -= count
    return {
        "supported": bool(pairs and lower >= 2 * pairs / 3),
        "lower": int(lower),
        "pairs": int(pairs),
        "by_dataset": by_dataset,
    }


def x_chronology__mutmut_36(results: dict[str, dict[str, Any]]) -> dict[str, Any]:
    """P5: the chronological PR-AUC below the stratified one for two thirds of the pairs."""
    pairs = lower = 0
    by_dataset = {}
    for name, result in results.items():
        if "excluded" in result:
            by_dataset[name] = {"excluded": result["excluded"]}
            continue
        count = sum(
            result["chronological"][m]["pr_auc"] < result["stratified"][m]["pr_auc"]
            for m in result["chronological"]
        )
        by_dataset[name] = {"lower": int(count), "detectors": len(result["chronological"])}
        pairs += len(result["chronological"])
        lower += count
    return {
        "XXsupportedXX": bool(pairs and lower >= 2 * pairs / 3),
        "lower": int(lower),
        "pairs": int(pairs),
        "by_dataset": by_dataset,
    }


def x_chronology__mutmut_37(results: dict[str, dict[str, Any]]) -> dict[str, Any]:
    """P5: the chronological PR-AUC below the stratified one for two thirds of the pairs."""
    pairs = lower = 0
    by_dataset = {}
    for name, result in results.items():
        if "excluded" in result:
            by_dataset[name] = {"excluded": result["excluded"]}
            continue
        count = sum(
            result["chronological"][m]["pr_auc"] < result["stratified"][m]["pr_auc"]
            for m in result["chronological"]
        )
        by_dataset[name] = {"lower": int(count), "detectors": len(result["chronological"])}
        pairs += len(result["chronological"])
        lower += count
    return {
        "SUPPORTED": bool(pairs and lower >= 2 * pairs / 3),
        "lower": int(lower),
        "pairs": int(pairs),
        "by_dataset": by_dataset,
    }


def x_chronology__mutmut_38(results: dict[str, dict[str, Any]]) -> dict[str, Any]:
    """P5: the chronological PR-AUC below the stratified one for two thirds of the pairs."""
    pairs = lower = 0
    by_dataset = {}
    for name, result in results.items():
        if "excluded" in result:
            by_dataset[name] = {"excluded": result["excluded"]}
            continue
        count = sum(
            result["chronological"][m]["pr_auc"] < result["stratified"][m]["pr_auc"]
            for m in result["chronological"]
        )
        by_dataset[name] = {"lower": int(count), "detectors": len(result["chronological"])}
        pairs += len(result["chronological"])
        lower += count
    return {
        "supported": bool(None),
        "lower": int(lower),
        "pairs": int(pairs),
        "by_dataset": by_dataset,
    }


def x_chronology__mutmut_39(results: dict[str, dict[str, Any]]) -> dict[str, Any]:
    """P5: the chronological PR-AUC below the stratified one for two thirds of the pairs."""
    pairs = lower = 0
    by_dataset = {}
    for name, result in results.items():
        if "excluded" in result:
            by_dataset[name] = {"excluded": result["excluded"]}
            continue
        count = sum(
            result["chronological"][m]["pr_auc"] < result["stratified"][m]["pr_auc"]
            for m in result["chronological"]
        )
        by_dataset[name] = {"lower": int(count), "detectors": len(result["chronological"])}
        pairs += len(result["chronological"])
        lower += count
    return {
        "supported": bool(pairs or lower >= 2 * pairs / 3),
        "lower": int(lower),
        "pairs": int(pairs),
        "by_dataset": by_dataset,
    }


def x_chronology__mutmut_40(results: dict[str, dict[str, Any]]) -> dict[str, Any]:
    """P5: the chronological PR-AUC below the stratified one for two thirds of the pairs."""
    pairs = lower = 0
    by_dataset = {}
    for name, result in results.items():
        if "excluded" in result:
            by_dataset[name] = {"excluded": result["excluded"]}
            continue
        count = sum(
            result["chronological"][m]["pr_auc"] < result["stratified"][m]["pr_auc"]
            for m in result["chronological"]
        )
        by_dataset[name] = {"lower": int(count), "detectors": len(result["chronological"])}
        pairs += len(result["chronological"])
        lower += count
    return {
        "supported": bool(pairs and lower > 2 * pairs / 3),
        "lower": int(lower),
        "pairs": int(pairs),
        "by_dataset": by_dataset,
    }


def x_chronology__mutmut_41(results: dict[str, dict[str, Any]]) -> dict[str, Any]:
    """P5: the chronological PR-AUC below the stratified one for two thirds of the pairs."""
    pairs = lower = 0
    by_dataset = {}
    for name, result in results.items():
        if "excluded" in result:
            by_dataset[name] = {"excluded": result["excluded"]}
            continue
        count = sum(
            result["chronological"][m]["pr_auc"] < result["stratified"][m]["pr_auc"]
            for m in result["chronological"]
        )
        by_dataset[name] = {"lower": int(count), "detectors": len(result["chronological"])}
        pairs += len(result["chronological"])
        lower += count
    return {
        "supported": bool(pairs and lower >= 2 * pairs * 3),
        "lower": int(lower),
        "pairs": int(pairs),
        "by_dataset": by_dataset,
    }


def x_chronology__mutmut_42(results: dict[str, dict[str, Any]]) -> dict[str, Any]:
    """P5: the chronological PR-AUC below the stratified one for two thirds of the pairs."""
    pairs = lower = 0
    by_dataset = {}
    for name, result in results.items():
        if "excluded" in result:
            by_dataset[name] = {"excluded": result["excluded"]}
            continue
        count = sum(
            result["chronological"][m]["pr_auc"] < result["stratified"][m]["pr_auc"]
            for m in result["chronological"]
        )
        by_dataset[name] = {"lower": int(count), "detectors": len(result["chronological"])}
        pairs += len(result["chronological"])
        lower += count
    return {
        "supported": bool(pairs and lower >= 2 / pairs / 3),
        "lower": int(lower),
        "pairs": int(pairs),
        "by_dataset": by_dataset,
    }


def x_chronology__mutmut_43(results: dict[str, dict[str, Any]]) -> dict[str, Any]:
    """P5: the chronological PR-AUC below the stratified one for two thirds of the pairs."""
    pairs = lower = 0
    by_dataset = {}
    for name, result in results.items():
        if "excluded" in result:
            by_dataset[name] = {"excluded": result["excluded"]}
            continue
        count = sum(
            result["chronological"][m]["pr_auc"] < result["stratified"][m]["pr_auc"]
            for m in result["chronological"]
        )
        by_dataset[name] = {"lower": int(count), "detectors": len(result["chronological"])}
        pairs += len(result["chronological"])
        lower += count
    return {
        "supported": bool(pairs and lower >= 3 * pairs / 3),
        "lower": int(lower),
        "pairs": int(pairs),
        "by_dataset": by_dataset,
    }


def x_chronology__mutmut_44(results: dict[str, dict[str, Any]]) -> dict[str, Any]:
    """P5: the chronological PR-AUC below the stratified one for two thirds of the pairs."""
    pairs = lower = 0
    by_dataset = {}
    for name, result in results.items():
        if "excluded" in result:
            by_dataset[name] = {"excluded": result["excluded"]}
            continue
        count = sum(
            result["chronological"][m]["pr_auc"] < result["stratified"][m]["pr_auc"]
            for m in result["chronological"]
        )
        by_dataset[name] = {"lower": int(count), "detectors": len(result["chronological"])}
        pairs += len(result["chronological"])
        lower += count
    return {
        "supported": bool(pairs and lower >= 2 * pairs / 4),
        "lower": int(lower),
        "pairs": int(pairs),
        "by_dataset": by_dataset,
    }


def x_chronology__mutmut_45(results: dict[str, dict[str, Any]]) -> dict[str, Any]:
    """P5: the chronological PR-AUC below the stratified one for two thirds of the pairs."""
    pairs = lower = 0
    by_dataset = {}
    for name, result in results.items():
        if "excluded" in result:
            by_dataset[name] = {"excluded": result["excluded"]}
            continue
        count = sum(
            result["chronological"][m]["pr_auc"] < result["stratified"][m]["pr_auc"]
            for m in result["chronological"]
        )
        by_dataset[name] = {"lower": int(count), "detectors": len(result["chronological"])}
        pairs += len(result["chronological"])
        lower += count
    return {
        "supported": bool(pairs and lower >= 2 * pairs / 3),
        "XXlowerXX": int(lower),
        "pairs": int(pairs),
        "by_dataset": by_dataset,
    }


def x_chronology__mutmut_46(results: dict[str, dict[str, Any]]) -> dict[str, Any]:
    """P5: the chronological PR-AUC below the stratified one for two thirds of the pairs."""
    pairs = lower = 0
    by_dataset = {}
    for name, result in results.items():
        if "excluded" in result:
            by_dataset[name] = {"excluded": result["excluded"]}
            continue
        count = sum(
            result["chronological"][m]["pr_auc"] < result["stratified"][m]["pr_auc"]
            for m in result["chronological"]
        )
        by_dataset[name] = {"lower": int(count), "detectors": len(result["chronological"])}
        pairs += len(result["chronological"])
        lower += count
    return {
        "supported": bool(pairs and lower >= 2 * pairs / 3),
        "LOWER": int(lower),
        "pairs": int(pairs),
        "by_dataset": by_dataset,
    }


def x_chronology__mutmut_47(results: dict[str, dict[str, Any]]) -> dict[str, Any]:
    """P5: the chronological PR-AUC below the stratified one for two thirds of the pairs."""
    pairs = lower = 0
    by_dataset = {}
    for name, result in results.items():
        if "excluded" in result:
            by_dataset[name] = {"excluded": result["excluded"]}
            continue
        count = sum(
            result["chronological"][m]["pr_auc"] < result["stratified"][m]["pr_auc"]
            for m in result["chronological"]
        )
        by_dataset[name] = {"lower": int(count), "detectors": len(result["chronological"])}
        pairs += len(result["chronological"])
        lower += count
    return {
        "supported": bool(pairs and lower >= 2 * pairs / 3),
        "lower": int(None),
        "pairs": int(pairs),
        "by_dataset": by_dataset,
    }


def x_chronology__mutmut_48(results: dict[str, dict[str, Any]]) -> dict[str, Any]:
    """P5: the chronological PR-AUC below the stratified one for two thirds of the pairs."""
    pairs = lower = 0
    by_dataset = {}
    for name, result in results.items():
        if "excluded" in result:
            by_dataset[name] = {"excluded": result["excluded"]}
            continue
        count = sum(
            result["chronological"][m]["pr_auc"] < result["stratified"][m]["pr_auc"]
            for m in result["chronological"]
        )
        by_dataset[name] = {"lower": int(count), "detectors": len(result["chronological"])}
        pairs += len(result["chronological"])
        lower += count
    return {
        "supported": bool(pairs and lower >= 2 * pairs / 3),
        "lower": int(lower),
        "XXpairsXX": int(pairs),
        "by_dataset": by_dataset,
    }


def x_chronology__mutmut_49(results: dict[str, dict[str, Any]]) -> dict[str, Any]:
    """P5: the chronological PR-AUC below the stratified one for two thirds of the pairs."""
    pairs = lower = 0
    by_dataset = {}
    for name, result in results.items():
        if "excluded" in result:
            by_dataset[name] = {"excluded": result["excluded"]}
            continue
        count = sum(
            result["chronological"][m]["pr_auc"] < result["stratified"][m]["pr_auc"]
            for m in result["chronological"]
        )
        by_dataset[name] = {"lower": int(count), "detectors": len(result["chronological"])}
        pairs += len(result["chronological"])
        lower += count
    return {
        "supported": bool(pairs and lower >= 2 * pairs / 3),
        "lower": int(lower),
        "PAIRS": int(pairs),
        "by_dataset": by_dataset,
    }


def x_chronology__mutmut_50(results: dict[str, dict[str, Any]]) -> dict[str, Any]:
    """P5: the chronological PR-AUC below the stratified one for two thirds of the pairs."""
    pairs = lower = 0
    by_dataset = {}
    for name, result in results.items():
        if "excluded" in result:
            by_dataset[name] = {"excluded": result["excluded"]}
            continue
        count = sum(
            result["chronological"][m]["pr_auc"] < result["stratified"][m]["pr_auc"]
            for m in result["chronological"]
        )
        by_dataset[name] = {"lower": int(count), "detectors": len(result["chronological"])}
        pairs += len(result["chronological"])
        lower += count
    return {
        "supported": bool(pairs and lower >= 2 * pairs / 3),
        "lower": int(lower),
        "pairs": int(None),
        "by_dataset": by_dataset,
    }


def x_chronology__mutmut_51(results: dict[str, dict[str, Any]]) -> dict[str, Any]:
    """P5: the chronological PR-AUC below the stratified one for two thirds of the pairs."""
    pairs = lower = 0
    by_dataset = {}
    for name, result in results.items():
        if "excluded" in result:
            by_dataset[name] = {"excluded": result["excluded"]}
            continue
        count = sum(
            result["chronological"][m]["pr_auc"] < result["stratified"][m]["pr_auc"]
            for m in result["chronological"]
        )
        by_dataset[name] = {"lower": int(count), "detectors": len(result["chronological"])}
        pairs += len(result["chronological"])
        lower += count
    return {
        "supported": bool(pairs and lower >= 2 * pairs / 3),
        "lower": int(lower),
        "pairs": int(pairs),
        "XXby_datasetXX": by_dataset,
    }


def x_chronology__mutmut_52(results: dict[str, dict[str, Any]]) -> dict[str, Any]:
    """P5: the chronological PR-AUC below the stratified one for two thirds of the pairs."""
    pairs = lower = 0
    by_dataset = {}
    for name, result in results.items():
        if "excluded" in result:
            by_dataset[name] = {"excluded": result["excluded"]}
            continue
        count = sum(
            result["chronological"][m]["pr_auc"] < result["stratified"][m]["pr_auc"]
            for m in result["chronological"]
        )
        by_dataset[name] = {"lower": int(count), "detectors": len(result["chronological"])}
        pairs += len(result["chronological"])
        lower += count
    return {
        "supported": bool(pairs and lower >= 2 * pairs / 3),
        "lower": int(lower),
        "pairs": int(pairs),
        "BY_DATASET": by_dataset,
    }

mutants_x_chronology__mutmut['_mutmut_orig'] = x_chronology__mutmut_orig # type: ignore # mutmut generated
mutants_x_chronology__mutmut['x_chronology__mutmut_1'] = x_chronology__mutmut_1 # type: ignore # mutmut generated
mutants_x_chronology__mutmut['x_chronology__mutmut_2'] = x_chronology__mutmut_2 # type: ignore # mutmut generated
mutants_x_chronology__mutmut['x_chronology__mutmut_3'] = x_chronology__mutmut_3 # type: ignore # mutmut generated
mutants_x_chronology__mutmut['x_chronology__mutmut_4'] = x_chronology__mutmut_4 # type: ignore # mutmut generated
mutants_x_chronology__mutmut['x_chronology__mutmut_5'] = x_chronology__mutmut_5 # type: ignore # mutmut generated
mutants_x_chronology__mutmut['x_chronology__mutmut_6'] = x_chronology__mutmut_6 # type: ignore # mutmut generated
mutants_x_chronology__mutmut['x_chronology__mutmut_7'] = x_chronology__mutmut_7 # type: ignore # mutmut generated
mutants_x_chronology__mutmut['x_chronology__mutmut_8'] = x_chronology__mutmut_8 # type: ignore # mutmut generated
mutants_x_chronology__mutmut['x_chronology__mutmut_9'] = x_chronology__mutmut_9 # type: ignore # mutmut generated
mutants_x_chronology__mutmut['x_chronology__mutmut_10'] = x_chronology__mutmut_10 # type: ignore # mutmut generated
mutants_x_chronology__mutmut['x_chronology__mutmut_11'] = x_chronology__mutmut_11 # type: ignore # mutmut generated
mutants_x_chronology__mutmut['x_chronology__mutmut_12'] = x_chronology__mutmut_12 # type: ignore # mutmut generated
mutants_x_chronology__mutmut['x_chronology__mutmut_13'] = x_chronology__mutmut_13 # type: ignore # mutmut generated
mutants_x_chronology__mutmut['x_chronology__mutmut_14'] = x_chronology__mutmut_14 # type: ignore # mutmut generated
mutants_x_chronology__mutmut['x_chronology__mutmut_15'] = x_chronology__mutmut_15 # type: ignore # mutmut generated
mutants_x_chronology__mutmut['x_chronology__mutmut_16'] = x_chronology__mutmut_16 # type: ignore # mutmut generated
mutants_x_chronology__mutmut['x_chronology__mutmut_17'] = x_chronology__mutmut_17 # type: ignore # mutmut generated
mutants_x_chronology__mutmut['x_chronology__mutmut_18'] = x_chronology__mutmut_18 # type: ignore # mutmut generated
mutants_x_chronology__mutmut['x_chronology__mutmut_19'] = x_chronology__mutmut_19 # type: ignore # mutmut generated
mutants_x_chronology__mutmut['x_chronology__mutmut_20'] = x_chronology__mutmut_20 # type: ignore # mutmut generated
mutants_x_chronology__mutmut['x_chronology__mutmut_21'] = x_chronology__mutmut_21 # type: ignore # mutmut generated
mutants_x_chronology__mutmut['x_chronology__mutmut_22'] = x_chronology__mutmut_22 # type: ignore # mutmut generated
mutants_x_chronology__mutmut['x_chronology__mutmut_23'] = x_chronology__mutmut_23 # type: ignore # mutmut generated
mutants_x_chronology__mutmut['x_chronology__mutmut_24'] = x_chronology__mutmut_24 # type: ignore # mutmut generated
mutants_x_chronology__mutmut['x_chronology__mutmut_25'] = x_chronology__mutmut_25 # type: ignore # mutmut generated
mutants_x_chronology__mutmut['x_chronology__mutmut_26'] = x_chronology__mutmut_26 # type: ignore # mutmut generated
mutants_x_chronology__mutmut['x_chronology__mutmut_27'] = x_chronology__mutmut_27 # type: ignore # mutmut generated
mutants_x_chronology__mutmut['x_chronology__mutmut_28'] = x_chronology__mutmut_28 # type: ignore # mutmut generated
mutants_x_chronology__mutmut['x_chronology__mutmut_29'] = x_chronology__mutmut_29 # type: ignore # mutmut generated
mutants_x_chronology__mutmut['x_chronology__mutmut_30'] = x_chronology__mutmut_30 # type: ignore # mutmut generated
mutants_x_chronology__mutmut['x_chronology__mutmut_31'] = x_chronology__mutmut_31 # type: ignore # mutmut generated
mutants_x_chronology__mutmut['x_chronology__mutmut_32'] = x_chronology__mutmut_32 # type: ignore # mutmut generated
mutants_x_chronology__mutmut['x_chronology__mutmut_33'] = x_chronology__mutmut_33 # type: ignore # mutmut generated
mutants_x_chronology__mutmut['x_chronology__mutmut_34'] = x_chronology__mutmut_34 # type: ignore # mutmut generated
mutants_x_chronology__mutmut['x_chronology__mutmut_35'] = x_chronology__mutmut_35 # type: ignore # mutmut generated
mutants_x_chronology__mutmut['x_chronology__mutmut_36'] = x_chronology__mutmut_36 # type: ignore # mutmut generated
mutants_x_chronology__mutmut['x_chronology__mutmut_37'] = x_chronology__mutmut_37 # type: ignore # mutmut generated
mutants_x_chronology__mutmut['x_chronology__mutmut_38'] = x_chronology__mutmut_38 # type: ignore # mutmut generated
mutants_x_chronology__mutmut['x_chronology__mutmut_39'] = x_chronology__mutmut_39 # type: ignore # mutmut generated
mutants_x_chronology__mutmut['x_chronology__mutmut_40'] = x_chronology__mutmut_40 # type: ignore # mutmut generated
mutants_x_chronology__mutmut['x_chronology__mutmut_41'] = x_chronology__mutmut_41 # type: ignore # mutmut generated
mutants_x_chronology__mutmut['x_chronology__mutmut_42'] = x_chronology__mutmut_42 # type: ignore # mutmut generated
mutants_x_chronology__mutmut['x_chronology__mutmut_43'] = x_chronology__mutmut_43 # type: ignore # mutmut generated
mutants_x_chronology__mutmut['x_chronology__mutmut_44'] = x_chronology__mutmut_44 # type: ignore # mutmut generated
mutants_x_chronology__mutmut['x_chronology__mutmut_45'] = x_chronology__mutmut_45 # type: ignore # mutmut generated
mutants_x_chronology__mutmut['x_chronology__mutmut_46'] = x_chronology__mutmut_46 # type: ignore # mutmut generated
mutants_x_chronology__mutmut['x_chronology__mutmut_47'] = x_chronology__mutmut_47 # type: ignore # mutmut generated
mutants_x_chronology__mutmut['x_chronology__mutmut_48'] = x_chronology__mutmut_48 # type: ignore # mutmut generated
mutants_x_chronology__mutmut['x_chronology__mutmut_49'] = x_chronology__mutmut_49 # type: ignore # mutmut generated
mutants_x_chronology__mutmut['x_chronology__mutmut_50'] = x_chronology__mutmut_50 # type: ignore # mutmut generated
mutants_x_chronology__mutmut['x_chronology__mutmut_51'] = x_chronology__mutmut_51 # type: ignore # mutmut generated
mutants_x_chronology__mutmut['x_chronology__mutmut_52'] = x_chronology__mutmut_52 # type: ignore # mutmut generated
mutants_x_contract__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_contract__mutmut)
def contract(report: dict[str, Any]) -> dict[str, Any]:
    """P6: no pool file differs from the manifest."""
    return {"supported": bool(report["summary"]["all_ok"]), **report["summary"]}


def x_contract__mutmut_orig(report: dict[str, Any]) -> dict[str, Any]:
    """P6: no pool file differs from the manifest."""
    return {"supported": bool(report["summary"]["all_ok"]), **report["summary"]}


def x_contract__mutmut_1(report: dict[str, Any]) -> dict[str, Any]:
    """P6: no pool file differs from the manifest."""
    return {"XXsupportedXX": bool(report["summary"]["all_ok"]), **report["summary"]}


def x_contract__mutmut_2(report: dict[str, Any]) -> dict[str, Any]:
    """P6: no pool file differs from the manifest."""
    return {"SUPPORTED": bool(report["summary"]["all_ok"]), **report["summary"]}


def x_contract__mutmut_3(report: dict[str, Any]) -> dict[str, Any]:
    """P6: no pool file differs from the manifest."""
    return {"supported": bool(None), **report["summary"]}


def x_contract__mutmut_4(report: dict[str, Any]) -> dict[str, Any]:
    """P6: no pool file differs from the manifest."""
    return {"supported": bool(report["XXsummaryXX"]["all_ok"]), **report["summary"]}


def x_contract__mutmut_5(report: dict[str, Any]) -> dict[str, Any]:
    """P6: no pool file differs from the manifest."""
    return {"supported": bool(report["SUMMARY"]["all_ok"]), **report["summary"]}


def x_contract__mutmut_6(report: dict[str, Any]) -> dict[str, Any]:
    """P6: no pool file differs from the manifest."""
    return {"supported": bool(report["summary"]["XXall_okXX"]), **report["summary"]}


def x_contract__mutmut_7(report: dict[str, Any]) -> dict[str, Any]:
    """P6: no pool file differs from the manifest."""
    return {"supported": bool(report["summary"]["ALL_OK"]), **report["summary"]}


def x_contract__mutmut_8(report: dict[str, Any]) -> dict[str, Any]:
    """P6: no pool file differs from the manifest."""
    return {"supported": bool(report["summary"]["all_ok"]), **report["XXsummaryXX"]}


def x_contract__mutmut_9(report: dict[str, Any]) -> dict[str, Any]:
    """P6: no pool file differs from the manifest."""
    return {"supported": bool(report["summary"]["all_ok"]), **report["SUMMARY"]}

mutants_x_contract__mutmut['_mutmut_orig'] = x_contract__mutmut_orig # type: ignore # mutmut generated
mutants_x_contract__mutmut['x_contract__mutmut_1'] = x_contract__mutmut_1 # type: ignore # mutmut generated
mutants_x_contract__mutmut['x_contract__mutmut_2'] = x_contract__mutmut_2 # type: ignore # mutmut generated
mutants_x_contract__mutmut['x_contract__mutmut_3'] = x_contract__mutmut_3 # type: ignore # mutmut generated
mutants_x_contract__mutmut['x_contract__mutmut_4'] = x_contract__mutmut_4 # type: ignore # mutmut generated
mutants_x_contract__mutmut['x_contract__mutmut_5'] = x_contract__mutmut_5 # type: ignore # mutmut generated
mutants_x_contract__mutmut['x_contract__mutmut_6'] = x_contract__mutmut_6 # type: ignore # mutmut generated
mutants_x_contract__mutmut['x_contract__mutmut_7'] = x_contract__mutmut_7 # type: ignore # mutmut generated
mutants_x_contract__mutmut['x_contract__mutmut_8'] = x_contract__mutmut_8 # type: ignore # mutmut generated
mutants_x_contract__mutmut['x_contract__mutmut_9'] = x_contract__mutmut_9 # type: ignore # mutmut generated
mutants_x_fixed_rows__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_fixed_rows__mutmut)
def fixed_rows(table: dict[str, Any], names: dict[str, str]) -> str:
    """LaTeX rows: median F1 and flagged share at the prevalence and at the fixed threshold."""
    lines = []
    for method, label in names.items():
        e = table["by_detector"][method]
        lines.append(
            f"{label:<18} & {e['f1']['prevalence']:.3f} & {e['f1']['fixed']:.3f} "
            f"& {e['flagged_pct']['prevalence']:.1f} & {e['flagged_pct']['fixed']:.1f} \\\\"
        )
        if method in ("great_expectations", "pca"):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_fixed_rows__mutmut_orig(table: dict[str, Any], names: dict[str, str]) -> str:
    """LaTeX rows: median F1 and flagged share at the prevalence and at the fixed threshold."""
    lines = []
    for method, label in names.items():
        e = table["by_detector"][method]
        lines.append(
            f"{label:<18} & {e['f1']['prevalence']:.3f} & {e['f1']['fixed']:.3f} "
            f"& {e['flagged_pct']['prevalence']:.1f} & {e['flagged_pct']['fixed']:.1f} \\\\"
        )
        if method in ("great_expectations", "pca"):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_fixed_rows__mutmut_1(table: dict[str, Any], names: dict[str, str]) -> str:
    """LaTeX rows: median F1 and flagged share at the prevalence and at the fixed threshold."""
    lines = None
    for method, label in names.items():
        e = table["by_detector"][method]
        lines.append(
            f"{label:<18} & {e['f1']['prevalence']:.3f} & {e['f1']['fixed']:.3f} "
            f"& {e['flagged_pct']['prevalence']:.1f} & {e['flagged_pct']['fixed']:.1f} \\\\"
        )
        if method in ("great_expectations", "pca"):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_fixed_rows__mutmut_2(table: dict[str, Any], names: dict[str, str]) -> str:
    """LaTeX rows: median F1 and flagged share at the prevalence and at the fixed threshold."""
    lines = []
    for method, label in names.items():
        e = None
        lines.append(
            f"{label:<18} & {e['f1']['prevalence']:.3f} & {e['f1']['fixed']:.3f} "
            f"& {e['flagged_pct']['prevalence']:.1f} & {e['flagged_pct']['fixed']:.1f} \\\\"
        )
        if method in ("great_expectations", "pca"):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_fixed_rows__mutmut_3(table: dict[str, Any], names: dict[str, str]) -> str:
    """LaTeX rows: median F1 and flagged share at the prevalence and at the fixed threshold."""
    lines = []
    for method, label in names.items():
        e = table["XXby_detectorXX"][method]
        lines.append(
            f"{label:<18} & {e['f1']['prevalence']:.3f} & {e['f1']['fixed']:.3f} "
            f"& {e['flagged_pct']['prevalence']:.1f} & {e['flagged_pct']['fixed']:.1f} \\\\"
        )
        if method in ("great_expectations", "pca"):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_fixed_rows__mutmut_4(table: dict[str, Any], names: dict[str, str]) -> str:
    """LaTeX rows: median F1 and flagged share at the prevalence and at the fixed threshold."""
    lines = []
    for method, label in names.items():
        e = table["BY_DETECTOR"][method]
        lines.append(
            f"{label:<18} & {e['f1']['prevalence']:.3f} & {e['f1']['fixed']:.3f} "
            f"& {e['flagged_pct']['prevalence']:.1f} & {e['flagged_pct']['fixed']:.1f} \\\\"
        )
        if method in ("great_expectations", "pca"):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_fixed_rows__mutmut_5(table: dict[str, Any], names: dict[str, str]) -> str:
    """LaTeX rows: median F1 and flagged share at the prevalence and at the fixed threshold."""
    lines = []
    for method, label in names.items():
        e = table["by_detector"][method]
        lines.append(
            None
        )
        if method in ("great_expectations", "pca"):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_fixed_rows__mutmut_6(table: dict[str, Any], names: dict[str, str]) -> str:
    """LaTeX rows: median F1 and flagged share at the prevalence and at the fixed threshold."""
    lines = []
    for method, label in names.items():
        e = table["by_detector"][method]
        lines.append(
            f"{label:<18} & {e['XXf1XX']['prevalence']:.3f} & {e['f1']['fixed']:.3f} "
            f"& {e['flagged_pct']['prevalence']:.1f} & {e['flagged_pct']['fixed']:.1f} \\\\"
        )
        if method in ("great_expectations", "pca"):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_fixed_rows__mutmut_7(table: dict[str, Any], names: dict[str, str]) -> str:
    """LaTeX rows: median F1 and flagged share at the prevalence and at the fixed threshold."""
    lines = []
    for method, label in names.items():
        e = table["by_detector"][method]
        lines.append(
            f"{label:<18} & {e['F1']['prevalence']:.3f} & {e['f1']['fixed']:.3f} "
            f"& {e['flagged_pct']['prevalence']:.1f} & {e['flagged_pct']['fixed']:.1f} \\\\"
        )
        if method in ("great_expectations", "pca"):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_fixed_rows__mutmut_8(table: dict[str, Any], names: dict[str, str]) -> str:
    """LaTeX rows: median F1 and flagged share at the prevalence and at the fixed threshold."""
    lines = []
    for method, label in names.items():
        e = table["by_detector"][method]
        lines.append(
            f"{label:<18} & {e['f1']['XXprevalenceXX']:.3f} & {e['f1']['fixed']:.3f} "
            f"& {e['flagged_pct']['prevalence']:.1f} & {e['flagged_pct']['fixed']:.1f} \\\\"
        )
        if method in ("great_expectations", "pca"):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_fixed_rows__mutmut_9(table: dict[str, Any], names: dict[str, str]) -> str:
    """LaTeX rows: median F1 and flagged share at the prevalence and at the fixed threshold."""
    lines = []
    for method, label in names.items():
        e = table["by_detector"][method]
        lines.append(
            f"{label:<18} & {e['f1']['PREVALENCE']:.3f} & {e['f1']['fixed']:.3f} "
            f"& {e['flagged_pct']['prevalence']:.1f} & {e['flagged_pct']['fixed']:.1f} \\\\"
        )
        if method in ("great_expectations", "pca"):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_fixed_rows__mutmut_10(table: dict[str, Any], names: dict[str, str]) -> str:
    """LaTeX rows: median F1 and flagged share at the prevalence and at the fixed threshold."""
    lines = []
    for method, label in names.items():
        e = table["by_detector"][method]
        lines.append(
            f"{label:<18} & {e['f1']['prevalence']:.3f} & {e['XXf1XX']['fixed']:.3f} "
            f"& {e['flagged_pct']['prevalence']:.1f} & {e['flagged_pct']['fixed']:.1f} \\\\"
        )
        if method in ("great_expectations", "pca"):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_fixed_rows__mutmut_11(table: dict[str, Any], names: dict[str, str]) -> str:
    """LaTeX rows: median F1 and flagged share at the prevalence and at the fixed threshold."""
    lines = []
    for method, label in names.items():
        e = table["by_detector"][method]
        lines.append(
            f"{label:<18} & {e['f1']['prevalence']:.3f} & {e['F1']['fixed']:.3f} "
            f"& {e['flagged_pct']['prevalence']:.1f} & {e['flagged_pct']['fixed']:.1f} \\\\"
        )
        if method in ("great_expectations", "pca"):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_fixed_rows__mutmut_12(table: dict[str, Any], names: dict[str, str]) -> str:
    """LaTeX rows: median F1 and flagged share at the prevalence and at the fixed threshold."""
    lines = []
    for method, label in names.items():
        e = table["by_detector"][method]
        lines.append(
            f"{label:<18} & {e['f1']['prevalence']:.3f} & {e['f1']['XXfixedXX']:.3f} "
            f"& {e['flagged_pct']['prevalence']:.1f} & {e['flagged_pct']['fixed']:.1f} \\\\"
        )
        if method in ("great_expectations", "pca"):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_fixed_rows__mutmut_13(table: dict[str, Any], names: dict[str, str]) -> str:
    """LaTeX rows: median F1 and flagged share at the prevalence and at the fixed threshold."""
    lines = []
    for method, label in names.items():
        e = table["by_detector"][method]
        lines.append(
            f"{label:<18} & {e['f1']['prevalence']:.3f} & {e['f1']['FIXED']:.3f} "
            f"& {e['flagged_pct']['prevalence']:.1f} & {e['flagged_pct']['fixed']:.1f} \\\\"
        )
        if method in ("great_expectations", "pca"):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_fixed_rows__mutmut_14(table: dict[str, Any], names: dict[str, str]) -> str:
    """LaTeX rows: median F1 and flagged share at the prevalence and at the fixed threshold."""
    lines = []
    for method, label in names.items():
        e = table["by_detector"][method]
        lines.append(
            f"{label:<18} & {e['f1']['prevalence']:.3f} & {e['f1']['fixed']:.3f} "
            f"& {e['XXflagged_pctXX']['prevalence']:.1f} & {e['flagged_pct']['fixed']:.1f} \\\\"
        )
        if method in ("great_expectations", "pca"):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_fixed_rows__mutmut_15(table: dict[str, Any], names: dict[str, str]) -> str:
    """LaTeX rows: median F1 and flagged share at the prevalence and at the fixed threshold."""
    lines = []
    for method, label in names.items():
        e = table["by_detector"][method]
        lines.append(
            f"{label:<18} & {e['f1']['prevalence']:.3f} & {e['f1']['fixed']:.3f} "
            f"& {e['FLAGGED_PCT']['prevalence']:.1f} & {e['flagged_pct']['fixed']:.1f} \\\\"
        )
        if method in ("great_expectations", "pca"):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_fixed_rows__mutmut_16(table: dict[str, Any], names: dict[str, str]) -> str:
    """LaTeX rows: median F1 and flagged share at the prevalence and at the fixed threshold."""
    lines = []
    for method, label in names.items():
        e = table["by_detector"][method]
        lines.append(
            f"{label:<18} & {e['f1']['prevalence']:.3f} & {e['f1']['fixed']:.3f} "
            f"& {e['flagged_pct']['XXprevalenceXX']:.1f} & {e['flagged_pct']['fixed']:.1f} \\\\"
        )
        if method in ("great_expectations", "pca"):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_fixed_rows__mutmut_17(table: dict[str, Any], names: dict[str, str]) -> str:
    """LaTeX rows: median F1 and flagged share at the prevalence and at the fixed threshold."""
    lines = []
    for method, label in names.items():
        e = table["by_detector"][method]
        lines.append(
            f"{label:<18} & {e['f1']['prevalence']:.3f} & {e['f1']['fixed']:.3f} "
            f"& {e['flagged_pct']['PREVALENCE']:.1f} & {e['flagged_pct']['fixed']:.1f} \\\\"
        )
        if method in ("great_expectations", "pca"):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_fixed_rows__mutmut_18(table: dict[str, Any], names: dict[str, str]) -> str:
    """LaTeX rows: median F1 and flagged share at the prevalence and at the fixed threshold."""
    lines = []
    for method, label in names.items():
        e = table["by_detector"][method]
        lines.append(
            f"{label:<18} & {e['f1']['prevalence']:.3f} & {e['f1']['fixed']:.3f} "
            f"& {e['flagged_pct']['prevalence']:.1f} & {e['XXflagged_pctXX']['fixed']:.1f} \\\\"
        )
        if method in ("great_expectations", "pca"):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_fixed_rows__mutmut_19(table: dict[str, Any], names: dict[str, str]) -> str:
    """LaTeX rows: median F1 and flagged share at the prevalence and at the fixed threshold."""
    lines = []
    for method, label in names.items():
        e = table["by_detector"][method]
        lines.append(
            f"{label:<18} & {e['f1']['prevalence']:.3f} & {e['f1']['fixed']:.3f} "
            f"& {e['flagged_pct']['prevalence']:.1f} & {e['FLAGGED_PCT']['fixed']:.1f} \\\\"
        )
        if method in ("great_expectations", "pca"):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_fixed_rows__mutmut_20(table: dict[str, Any], names: dict[str, str]) -> str:
    """LaTeX rows: median F1 and flagged share at the prevalence and at the fixed threshold."""
    lines = []
    for method, label in names.items():
        e = table["by_detector"][method]
        lines.append(
            f"{label:<18} & {e['f1']['prevalence']:.3f} & {e['f1']['fixed']:.3f} "
            f"& {e['flagged_pct']['prevalence']:.1f} & {e['flagged_pct']['XXfixedXX']:.1f} \\\\"
        )
        if method in ("great_expectations", "pca"):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_fixed_rows__mutmut_21(table: dict[str, Any], names: dict[str, str]) -> str:
    """LaTeX rows: median F1 and flagged share at the prevalence and at the fixed threshold."""
    lines = []
    for method, label in names.items():
        e = table["by_detector"][method]
        lines.append(
            f"{label:<18} & {e['f1']['prevalence']:.3f} & {e['f1']['fixed']:.3f} "
            f"& {e['flagged_pct']['prevalence']:.1f} & {e['flagged_pct']['FIXED']:.1f} \\\\"
        )
        if method in ("great_expectations", "pca"):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_fixed_rows__mutmut_22(table: dict[str, Any], names: dict[str, str]) -> str:
    """LaTeX rows: median F1 and flagged share at the prevalence and at the fixed threshold."""
    lines = []
    for method, label in names.items():
        e = table["by_detector"][method]
        lines.append(
            f"{label:<18} & {e['f1']['prevalence']:.3f} & {e['f1']['fixed']:.3f} "
            f"& {e['flagged_pct']['prevalence']:.1f} & {e['flagged_pct']['fixed']:.1f} \\\\"
        )
        if method not in ("great_expectations", "pca"):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_fixed_rows__mutmut_23(table: dict[str, Any], names: dict[str, str]) -> str:
    """LaTeX rows: median F1 and flagged share at the prevalence and at the fixed threshold."""
    lines = []
    for method, label in names.items():
        e = table["by_detector"][method]
        lines.append(
            f"{label:<18} & {e['f1']['prevalence']:.3f} & {e['f1']['fixed']:.3f} "
            f"& {e['flagged_pct']['prevalence']:.1f} & {e['flagged_pct']['fixed']:.1f} \\\\"
        )
        if method in ("XXgreat_expectationsXX", "pca"):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_fixed_rows__mutmut_24(table: dict[str, Any], names: dict[str, str]) -> str:
    """LaTeX rows: median F1 and flagged share at the prevalence and at the fixed threshold."""
    lines = []
    for method, label in names.items():
        e = table["by_detector"][method]
        lines.append(
            f"{label:<18} & {e['f1']['prevalence']:.3f} & {e['f1']['fixed']:.3f} "
            f"& {e['flagged_pct']['prevalence']:.1f} & {e['flagged_pct']['fixed']:.1f} \\\\"
        )
        if method in ("GREAT_EXPECTATIONS", "pca"):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_fixed_rows__mutmut_25(table: dict[str, Any], names: dict[str, str]) -> str:
    """LaTeX rows: median F1 and flagged share at the prevalence and at the fixed threshold."""
    lines = []
    for method, label in names.items():
        e = table["by_detector"][method]
        lines.append(
            f"{label:<18} & {e['f1']['prevalence']:.3f} & {e['f1']['fixed']:.3f} "
            f"& {e['flagged_pct']['prevalence']:.1f} & {e['flagged_pct']['fixed']:.1f} \\\\"
        )
        if method in ("great_expectations", "XXpcaXX"):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_fixed_rows__mutmut_26(table: dict[str, Any], names: dict[str, str]) -> str:
    """LaTeX rows: median F1 and flagged share at the prevalence and at the fixed threshold."""
    lines = []
    for method, label in names.items():
        e = table["by_detector"][method]
        lines.append(
            f"{label:<18} & {e['f1']['prevalence']:.3f} & {e['f1']['fixed']:.3f} "
            f"& {e['flagged_pct']['prevalence']:.1f} & {e['flagged_pct']['fixed']:.1f} \\\\"
        )
        if method in ("great_expectations", "PCA"):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_fixed_rows__mutmut_27(table: dict[str, Any], names: dict[str, str]) -> str:
    """LaTeX rows: median F1 and flagged share at the prevalence and at the fixed threshold."""
    lines = []
    for method, label in names.items():
        e = table["by_detector"][method]
        lines.append(
            f"{label:<18} & {e['f1']['prevalence']:.3f} & {e['f1']['fixed']:.3f} "
            f"& {e['flagged_pct']['prevalence']:.1f} & {e['flagged_pct']['fixed']:.1f} \\\\"
        )
        if method in ("great_expectations", "pca"):
            lines.append(None)
    return "\n".join(lines)


def x_fixed_rows__mutmut_28(table: dict[str, Any], names: dict[str, str]) -> str:
    """LaTeX rows: median F1 and flagged share at the prevalence and at the fixed threshold."""
    lines = []
    for method, label in names.items():
        e = table["by_detector"][method]
        lines.append(
            f"{label:<18} & {e['f1']['prevalence']:.3f} & {e['f1']['fixed']:.3f} "
            f"& {e['flagged_pct']['prevalence']:.1f} & {e['flagged_pct']['fixed']:.1f} \\\\"
        )
        if method in ("great_expectations", "pca"):
            lines.append(r"XX\midruleXX")
    return "\n".join(lines)


def x_fixed_rows__mutmut_29(table: dict[str, Any], names: dict[str, str]) -> str:
    """LaTeX rows: median F1 and flagged share at the prevalence and at the fixed threshold."""
    lines = []
    for method, label in names.items():
        e = table["by_detector"][method]
        lines.append(
            f"{label:<18} & {e['f1']['prevalence']:.3f} & {e['f1']['fixed']:.3f} "
            f"& {e['flagged_pct']['prevalence']:.1f} & {e['flagged_pct']['fixed']:.1f} \\\\"
        )
        if method in ("great_expectations", "pca"):
            lines.append(r"\mIDRULE")
    return "\n".join(lines)


def x_fixed_rows__mutmut_30(table: dict[str, Any], names: dict[str, str]) -> str:
    """LaTeX rows: median F1 and flagged share at the prevalence and at the fixed threshold."""
    lines = []
    for method, label in names.items():
        e = table["by_detector"][method]
        lines.append(
            f"{label:<18} & {e['f1']['prevalence']:.3f} & {e['f1']['fixed']:.3f} "
            f"& {e['flagged_pct']['prevalence']:.1f} & {e['flagged_pct']['fixed']:.1f} \\\\"
        )
        if method in ("great_expectations", "pca"):
            lines.append(r"\midrule")
    return "\n".join(None)


def x_fixed_rows__mutmut_31(table: dict[str, Any], names: dict[str, str]) -> str:
    """LaTeX rows: median F1 and flagged share at the prevalence and at the fixed threshold."""
    lines = []
    for method, label in names.items():
        e = table["by_detector"][method]
        lines.append(
            f"{label:<18} & {e['f1']['prevalence']:.3f} & {e['f1']['fixed']:.3f} "
            f"& {e['flagged_pct']['prevalence']:.1f} & {e['flagged_pct']['fixed']:.1f} \\\\"
        )
        if method in ("great_expectations", "pca"):
            lines.append(r"\midrule")
    return "XX\nXX".join(lines)

mutants_x_fixed_rows__mutmut['_mutmut_orig'] = x_fixed_rows__mutmut_orig # type: ignore # mutmut generated
mutants_x_fixed_rows__mutmut['x_fixed_rows__mutmut_1'] = x_fixed_rows__mutmut_1 # type: ignore # mutmut generated
mutants_x_fixed_rows__mutmut['x_fixed_rows__mutmut_2'] = x_fixed_rows__mutmut_2 # type: ignore # mutmut generated
mutants_x_fixed_rows__mutmut['x_fixed_rows__mutmut_3'] = x_fixed_rows__mutmut_3 # type: ignore # mutmut generated
mutants_x_fixed_rows__mutmut['x_fixed_rows__mutmut_4'] = x_fixed_rows__mutmut_4 # type: ignore # mutmut generated
mutants_x_fixed_rows__mutmut['x_fixed_rows__mutmut_5'] = x_fixed_rows__mutmut_5 # type: ignore # mutmut generated
mutants_x_fixed_rows__mutmut['x_fixed_rows__mutmut_6'] = x_fixed_rows__mutmut_6 # type: ignore # mutmut generated
mutants_x_fixed_rows__mutmut['x_fixed_rows__mutmut_7'] = x_fixed_rows__mutmut_7 # type: ignore # mutmut generated
mutants_x_fixed_rows__mutmut['x_fixed_rows__mutmut_8'] = x_fixed_rows__mutmut_8 # type: ignore # mutmut generated
mutants_x_fixed_rows__mutmut['x_fixed_rows__mutmut_9'] = x_fixed_rows__mutmut_9 # type: ignore # mutmut generated
mutants_x_fixed_rows__mutmut['x_fixed_rows__mutmut_10'] = x_fixed_rows__mutmut_10 # type: ignore # mutmut generated
mutants_x_fixed_rows__mutmut['x_fixed_rows__mutmut_11'] = x_fixed_rows__mutmut_11 # type: ignore # mutmut generated
mutants_x_fixed_rows__mutmut['x_fixed_rows__mutmut_12'] = x_fixed_rows__mutmut_12 # type: ignore # mutmut generated
mutants_x_fixed_rows__mutmut['x_fixed_rows__mutmut_13'] = x_fixed_rows__mutmut_13 # type: ignore # mutmut generated
mutants_x_fixed_rows__mutmut['x_fixed_rows__mutmut_14'] = x_fixed_rows__mutmut_14 # type: ignore # mutmut generated
mutants_x_fixed_rows__mutmut['x_fixed_rows__mutmut_15'] = x_fixed_rows__mutmut_15 # type: ignore # mutmut generated
mutants_x_fixed_rows__mutmut['x_fixed_rows__mutmut_16'] = x_fixed_rows__mutmut_16 # type: ignore # mutmut generated
mutants_x_fixed_rows__mutmut['x_fixed_rows__mutmut_17'] = x_fixed_rows__mutmut_17 # type: ignore # mutmut generated
mutants_x_fixed_rows__mutmut['x_fixed_rows__mutmut_18'] = x_fixed_rows__mutmut_18 # type: ignore # mutmut generated
mutants_x_fixed_rows__mutmut['x_fixed_rows__mutmut_19'] = x_fixed_rows__mutmut_19 # type: ignore # mutmut generated
mutants_x_fixed_rows__mutmut['x_fixed_rows__mutmut_20'] = x_fixed_rows__mutmut_20 # type: ignore # mutmut generated
mutants_x_fixed_rows__mutmut['x_fixed_rows__mutmut_21'] = x_fixed_rows__mutmut_21 # type: ignore # mutmut generated
mutants_x_fixed_rows__mutmut['x_fixed_rows__mutmut_22'] = x_fixed_rows__mutmut_22 # type: ignore # mutmut generated
mutants_x_fixed_rows__mutmut['x_fixed_rows__mutmut_23'] = x_fixed_rows__mutmut_23 # type: ignore # mutmut generated
mutants_x_fixed_rows__mutmut['x_fixed_rows__mutmut_24'] = x_fixed_rows__mutmut_24 # type: ignore # mutmut generated
mutants_x_fixed_rows__mutmut['x_fixed_rows__mutmut_25'] = x_fixed_rows__mutmut_25 # type: ignore # mutmut generated
mutants_x_fixed_rows__mutmut['x_fixed_rows__mutmut_26'] = x_fixed_rows__mutmut_26 # type: ignore # mutmut generated
mutants_x_fixed_rows__mutmut['x_fixed_rows__mutmut_27'] = x_fixed_rows__mutmut_27 # type: ignore # mutmut generated
mutants_x_fixed_rows__mutmut['x_fixed_rows__mutmut_28'] = x_fixed_rows__mutmut_28 # type: ignore # mutmut generated
mutants_x_fixed_rows__mutmut['x_fixed_rows__mutmut_29'] = x_fixed_rows__mutmut_29 # type: ignore # mutmut generated
mutants_x_fixed_rows__mutmut['x_fixed_rows__mutmut_30'] = x_fixed_rows__mutmut_30 # type: ignore # mutmut generated
mutants_x_fixed_rows__mutmut['x_fixed_rows__mutmut_31'] = x_fixed_rows__mutmut_31 # type: ignore # mutmut generated
mutants_x_sweep_rows__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_sweep_rows__mutmut)
def sweep_rows(sweep: dict[str, Any]) -> str:
    """LaTeX rows of the Isolation Forest contamination grid."""
    return "\n".join(
        f"{float(c):.3f} & {v['precision']:.3f} & {v['recall']:.3f} & {v['f1']:.3f} "
        f"& {v['flagged_pct']:.1f} \\\\"
        for c, v in sweep.items()
    )


def x_sweep_rows__mutmut_orig(sweep: dict[str, Any]) -> str:
    """LaTeX rows of the Isolation Forest contamination grid."""
    return "\n".join(
        f"{float(c):.3f} & {v['precision']:.3f} & {v['recall']:.3f} & {v['f1']:.3f} "
        f"& {v['flagged_pct']:.1f} \\\\"
        for c, v in sweep.items()
    )


def x_sweep_rows__mutmut_1(sweep: dict[str, Any]) -> str:
    """LaTeX rows of the Isolation Forest contamination grid."""
    return "\n".join(
        None
    )


def x_sweep_rows__mutmut_2(sweep: dict[str, Any]) -> str:
    """LaTeX rows of the Isolation Forest contamination grid."""
    return "XX\nXX".join(
        f"{float(c):.3f} & {v['precision']:.3f} & {v['recall']:.3f} & {v['f1']:.3f} "
        f"& {v['flagged_pct']:.1f} \\\\"
        for c, v in sweep.items()
    )


def x_sweep_rows__mutmut_3(sweep: dict[str, Any]) -> str:
    """LaTeX rows of the Isolation Forest contamination grid."""
    return "\n".join(
        f"{float(None):.3f} & {v['precision']:.3f} & {v['recall']:.3f} & {v['f1']:.3f} "
        f"& {v['flagged_pct']:.1f} \\\\"
        for c, v in sweep.items()
    )


def x_sweep_rows__mutmut_4(sweep: dict[str, Any]) -> str:
    """LaTeX rows of the Isolation Forest contamination grid."""
    return "\n".join(
        f"{float(c):.3f} & {v['XXprecisionXX']:.3f} & {v['recall']:.3f} & {v['f1']:.3f} "
        f"& {v['flagged_pct']:.1f} \\\\"
        for c, v in sweep.items()
    )


def x_sweep_rows__mutmut_5(sweep: dict[str, Any]) -> str:
    """LaTeX rows of the Isolation Forest contamination grid."""
    return "\n".join(
        f"{float(c):.3f} & {v['PRECISION']:.3f} & {v['recall']:.3f} & {v['f1']:.3f} "
        f"& {v['flagged_pct']:.1f} \\\\"
        for c, v in sweep.items()
    )


def x_sweep_rows__mutmut_6(sweep: dict[str, Any]) -> str:
    """LaTeX rows of the Isolation Forest contamination grid."""
    return "\n".join(
        f"{float(c):.3f} & {v['precision']:.3f} & {v['XXrecallXX']:.3f} & {v['f1']:.3f} "
        f"& {v['flagged_pct']:.1f} \\\\"
        for c, v in sweep.items()
    )


def x_sweep_rows__mutmut_7(sweep: dict[str, Any]) -> str:
    """LaTeX rows of the Isolation Forest contamination grid."""
    return "\n".join(
        f"{float(c):.3f} & {v['precision']:.3f} & {v['RECALL']:.3f} & {v['f1']:.3f} "
        f"& {v['flagged_pct']:.1f} \\\\"
        for c, v in sweep.items()
    )


def x_sweep_rows__mutmut_8(sweep: dict[str, Any]) -> str:
    """LaTeX rows of the Isolation Forest contamination grid."""
    return "\n".join(
        f"{float(c):.3f} & {v['precision']:.3f} & {v['recall']:.3f} & {v['XXf1XX']:.3f} "
        f"& {v['flagged_pct']:.1f} \\\\"
        for c, v in sweep.items()
    )


def x_sweep_rows__mutmut_9(sweep: dict[str, Any]) -> str:
    """LaTeX rows of the Isolation Forest contamination grid."""
    return "\n".join(
        f"{float(c):.3f} & {v['precision']:.3f} & {v['recall']:.3f} & {v['F1']:.3f} "
        f"& {v['flagged_pct']:.1f} \\\\"
        for c, v in sweep.items()
    )


def x_sweep_rows__mutmut_10(sweep: dict[str, Any]) -> str:
    """LaTeX rows of the Isolation Forest contamination grid."""
    return "\n".join(
        f"{float(c):.3f} & {v['precision']:.3f} & {v['recall']:.3f} & {v['f1']:.3f} "
        f"& {v['XXflagged_pctXX']:.1f} \\\\"
        for c, v in sweep.items()
    )


def x_sweep_rows__mutmut_11(sweep: dict[str, Any]) -> str:
    """LaTeX rows of the Isolation Forest contamination grid."""
    return "\n".join(
        f"{float(c):.3f} & {v['precision']:.3f} & {v['recall']:.3f} & {v['f1']:.3f} "
        f"& {v['FLAGGED_PCT']:.1f} \\\\"
        for c, v in sweep.items()
    )

mutants_x_sweep_rows__mutmut['_mutmut_orig'] = x_sweep_rows__mutmut_orig # type: ignore # mutmut generated
mutants_x_sweep_rows__mutmut['x_sweep_rows__mutmut_1'] = x_sweep_rows__mutmut_1 # type: ignore # mutmut generated
mutants_x_sweep_rows__mutmut['x_sweep_rows__mutmut_2'] = x_sweep_rows__mutmut_2 # type: ignore # mutmut generated
mutants_x_sweep_rows__mutmut['x_sweep_rows__mutmut_3'] = x_sweep_rows__mutmut_3 # type: ignore # mutmut generated
mutants_x_sweep_rows__mutmut['x_sweep_rows__mutmut_4'] = x_sweep_rows__mutmut_4 # type: ignore # mutmut generated
mutants_x_sweep_rows__mutmut['x_sweep_rows__mutmut_5'] = x_sweep_rows__mutmut_5 # type: ignore # mutmut generated
mutants_x_sweep_rows__mutmut['x_sweep_rows__mutmut_6'] = x_sweep_rows__mutmut_6 # type: ignore # mutmut generated
mutants_x_sweep_rows__mutmut['x_sweep_rows__mutmut_7'] = x_sweep_rows__mutmut_7 # type: ignore # mutmut generated
mutants_x_sweep_rows__mutmut['x_sweep_rows__mutmut_8'] = x_sweep_rows__mutmut_8 # type: ignore # mutmut generated
mutants_x_sweep_rows__mutmut['x_sweep_rows__mutmut_9'] = x_sweep_rows__mutmut_9 # type: ignore # mutmut generated
mutants_x_sweep_rows__mutmut['x_sweep_rows__mutmut_10'] = x_sweep_rows__mutmut_10 # type: ignore # mutmut generated
mutants_x_sweep_rows__mutmut['x_sweep_rows__mutmut_11'] = x_sweep_rows__mutmut_11 # type: ignore # mutmut generated
mutants_x__short__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x__short__mutmut)
def _short(reason: str) -> str:
    return reason.replace(" anomalies in the test partition (at least 20)", " test anomalies")


def x__short__mutmut_orig(reason: str) -> str:
    return reason.replace(" anomalies in the test partition (at least 20)", " test anomalies")


def x__short__mutmut_1(reason: str) -> str:
    return reason.replace(None, " test anomalies")


def x__short__mutmut_2(reason: str) -> str:
    return reason.replace(" anomalies in the test partition (at least 20)", None)


def x__short__mutmut_3(reason: str) -> str:
    return reason.replace(" test anomalies")


def x__short__mutmut_4(reason: str) -> str:
    return reason.replace(" anomalies in the test partition (at least 20)", )


def x__short__mutmut_5(reason: str) -> str:
    return reason.replace("XX anomalies in the test partition (at least 20)XX", " test anomalies")


def x__short__mutmut_6(reason: str) -> str:
    return reason.replace(" ANOMALIES IN THE TEST PARTITION (AT LEAST 20)", " test anomalies")


def x__short__mutmut_7(reason: str) -> str:
    return reason.replace(" anomalies in the test partition (at least 20)", "XX test anomaliesXX")


def x__short__mutmut_8(reason: str) -> str:
    return reason.replace(" anomalies in the test partition (at least 20)", " TEST ANOMALIES")

mutants_x__short__mutmut['_mutmut_orig'] = x__short__mutmut_orig # type: ignore # mutmut generated
mutants_x__short__mutmut['x__short__mutmut_1'] = x__short__mutmut_1 # type: ignore # mutmut generated
mutants_x__short__mutmut['x__short__mutmut_2'] = x__short__mutmut_2 # type: ignore # mutmut generated
mutants_x__short__mutmut['x__short__mutmut_3'] = x__short__mutmut_3 # type: ignore # mutmut generated
mutants_x__short__mutmut['x__short__mutmut_4'] = x__short__mutmut_4 # type: ignore # mutmut generated
mutants_x__short__mutmut['x__short__mutmut_5'] = x__short__mutmut_5 # type: ignore # mutmut generated
mutants_x__short__mutmut['x__short__mutmut_6'] = x__short__mutmut_6 # type: ignore # mutmut generated
mutants_x__short__mutmut['x__short__mutmut_7'] = x__short__mutmut_7 # type: ignore # mutmut generated
mutants_x__short__mutmut['x__short__mutmut_8'] = x__short__mutmut_8 # type: ignore # mutmut generated
mutants_x_chrono_rows__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_chrono_rows__mutmut)
def chrono_rows(results: dict[str, dict[str, Any]], labels: dict[str, str]) -> str:
    """LaTeX rows of the chronological study: partitions, prevalence shift, lower pairs."""
    lines = []
    for name, label in labels.items():
        result = results[name]
        if "excluded" in result:
            lines.append(
                f"{label} & \\multicolumn{{4}}{{l}}{{excluded: {_short(result['excluded'])}}} \\\\"
            )
            continue
        part = result["partitions"]
        lower = sum(
            result["chronological"][m]["pr_auc"] < result["stratified"][m]["pr_auc"]
            for m in result["chronological"]
        )
        lines.append(
            f"{label} & {part['test']['positives']} "
            f"& {100 * part['train']['prevalence']:.1f} & {100 * part['test']['prevalence']:.1f} "
            f"& {lower} of {len(result['chronological'])} \\\\"
        )
    return "\n".join(lines)


def x_chrono_rows__mutmut_orig(results: dict[str, dict[str, Any]], labels: dict[str, str]) -> str:
    """LaTeX rows of the chronological study: partitions, prevalence shift, lower pairs."""
    lines = []
    for name, label in labels.items():
        result = results[name]
        if "excluded" in result:
            lines.append(
                f"{label} & \\multicolumn{{4}}{{l}}{{excluded: {_short(result['excluded'])}}} \\\\"
            )
            continue
        part = result["partitions"]
        lower = sum(
            result["chronological"][m]["pr_auc"] < result["stratified"][m]["pr_auc"]
            for m in result["chronological"]
        )
        lines.append(
            f"{label} & {part['test']['positives']} "
            f"& {100 * part['train']['prevalence']:.1f} & {100 * part['test']['prevalence']:.1f} "
            f"& {lower} of {len(result['chronological'])} \\\\"
        )
    return "\n".join(lines)


def x_chrono_rows__mutmut_1(results: dict[str, dict[str, Any]], labels: dict[str, str]) -> str:
    """LaTeX rows of the chronological study: partitions, prevalence shift, lower pairs."""
    lines = None
    for name, label in labels.items():
        result = results[name]
        if "excluded" in result:
            lines.append(
                f"{label} & \\multicolumn{{4}}{{l}}{{excluded: {_short(result['excluded'])}}} \\\\"
            )
            continue
        part = result["partitions"]
        lower = sum(
            result["chronological"][m]["pr_auc"] < result["stratified"][m]["pr_auc"]
            for m in result["chronological"]
        )
        lines.append(
            f"{label} & {part['test']['positives']} "
            f"& {100 * part['train']['prevalence']:.1f} & {100 * part['test']['prevalence']:.1f} "
            f"& {lower} of {len(result['chronological'])} \\\\"
        )
    return "\n".join(lines)


def x_chrono_rows__mutmut_2(results: dict[str, dict[str, Any]], labels: dict[str, str]) -> str:
    """LaTeX rows of the chronological study: partitions, prevalence shift, lower pairs."""
    lines = []
    for name, label in labels.items():
        result = None
        if "excluded" in result:
            lines.append(
                f"{label} & \\multicolumn{{4}}{{l}}{{excluded: {_short(result['excluded'])}}} \\\\"
            )
            continue
        part = result["partitions"]
        lower = sum(
            result["chronological"][m]["pr_auc"] < result["stratified"][m]["pr_auc"]
            for m in result["chronological"]
        )
        lines.append(
            f"{label} & {part['test']['positives']} "
            f"& {100 * part['train']['prevalence']:.1f} & {100 * part['test']['prevalence']:.1f} "
            f"& {lower} of {len(result['chronological'])} \\\\"
        )
    return "\n".join(lines)


def x_chrono_rows__mutmut_3(results: dict[str, dict[str, Any]], labels: dict[str, str]) -> str:
    """LaTeX rows of the chronological study: partitions, prevalence shift, lower pairs."""
    lines = []
    for name, label in labels.items():
        result = results[name]
        if "XXexcludedXX" in result:
            lines.append(
                f"{label} & \\multicolumn{{4}}{{l}}{{excluded: {_short(result['excluded'])}}} \\\\"
            )
            continue
        part = result["partitions"]
        lower = sum(
            result["chronological"][m]["pr_auc"] < result["stratified"][m]["pr_auc"]
            for m in result["chronological"]
        )
        lines.append(
            f"{label} & {part['test']['positives']} "
            f"& {100 * part['train']['prevalence']:.1f} & {100 * part['test']['prevalence']:.1f} "
            f"& {lower} of {len(result['chronological'])} \\\\"
        )
    return "\n".join(lines)


def x_chrono_rows__mutmut_4(results: dict[str, dict[str, Any]], labels: dict[str, str]) -> str:
    """LaTeX rows of the chronological study: partitions, prevalence shift, lower pairs."""
    lines = []
    for name, label in labels.items():
        result = results[name]
        if "EXCLUDED" in result:
            lines.append(
                f"{label} & \\multicolumn{{4}}{{l}}{{excluded: {_short(result['excluded'])}}} \\\\"
            )
            continue
        part = result["partitions"]
        lower = sum(
            result["chronological"][m]["pr_auc"] < result["stratified"][m]["pr_auc"]
            for m in result["chronological"]
        )
        lines.append(
            f"{label} & {part['test']['positives']} "
            f"& {100 * part['train']['prevalence']:.1f} & {100 * part['test']['prevalence']:.1f} "
            f"& {lower} of {len(result['chronological'])} \\\\"
        )
    return "\n".join(lines)


def x_chrono_rows__mutmut_5(results: dict[str, dict[str, Any]], labels: dict[str, str]) -> str:
    """LaTeX rows of the chronological study: partitions, prevalence shift, lower pairs."""
    lines = []
    for name, label in labels.items():
        result = results[name]
        if "excluded" not in result:
            lines.append(
                f"{label} & \\multicolumn{{4}}{{l}}{{excluded: {_short(result['excluded'])}}} \\\\"
            )
            continue
        part = result["partitions"]
        lower = sum(
            result["chronological"][m]["pr_auc"] < result["stratified"][m]["pr_auc"]
            for m in result["chronological"]
        )
        lines.append(
            f"{label} & {part['test']['positives']} "
            f"& {100 * part['train']['prevalence']:.1f} & {100 * part['test']['prevalence']:.1f} "
            f"& {lower} of {len(result['chronological'])} \\\\"
        )
    return "\n".join(lines)


def x_chrono_rows__mutmut_6(results: dict[str, dict[str, Any]], labels: dict[str, str]) -> str:
    """LaTeX rows of the chronological study: partitions, prevalence shift, lower pairs."""
    lines = []
    for name, label in labels.items():
        result = results[name]
        if "excluded" in result:
            lines.append(
                None
            )
            continue
        part = result["partitions"]
        lower = sum(
            result["chronological"][m]["pr_auc"] < result["stratified"][m]["pr_auc"]
            for m in result["chronological"]
        )
        lines.append(
            f"{label} & {part['test']['positives']} "
            f"& {100 * part['train']['prevalence']:.1f} & {100 * part['test']['prevalence']:.1f} "
            f"& {lower} of {len(result['chronological'])} \\\\"
        )
    return "\n".join(lines)


def x_chrono_rows__mutmut_7(results: dict[str, dict[str, Any]], labels: dict[str, str]) -> str:
    """LaTeX rows of the chronological study: partitions, prevalence shift, lower pairs."""
    lines = []
    for name, label in labels.items():
        result = results[name]
        if "excluded" in result:
            lines.append(
                f"{label} & \\multicolumn{{4}}{{l}}{{excluded: {_short(None)}}} \\\\"
            )
            continue
        part = result["partitions"]
        lower = sum(
            result["chronological"][m]["pr_auc"] < result["stratified"][m]["pr_auc"]
            for m in result["chronological"]
        )
        lines.append(
            f"{label} & {part['test']['positives']} "
            f"& {100 * part['train']['prevalence']:.1f} & {100 * part['test']['prevalence']:.1f} "
            f"& {lower} of {len(result['chronological'])} \\\\"
        )
    return "\n".join(lines)


def x_chrono_rows__mutmut_8(results: dict[str, dict[str, Any]], labels: dict[str, str]) -> str:
    """LaTeX rows of the chronological study: partitions, prevalence shift, lower pairs."""
    lines = []
    for name, label in labels.items():
        result = results[name]
        if "excluded" in result:
            lines.append(
                f"{label} & \\multicolumn{{4}}{{l}}{{excluded: {_short(result['XXexcludedXX'])}}} \\\\"
            )
            continue
        part = result["partitions"]
        lower = sum(
            result["chronological"][m]["pr_auc"] < result["stratified"][m]["pr_auc"]
            for m in result["chronological"]
        )
        lines.append(
            f"{label} & {part['test']['positives']} "
            f"& {100 * part['train']['prevalence']:.1f} & {100 * part['test']['prevalence']:.1f} "
            f"& {lower} of {len(result['chronological'])} \\\\"
        )
    return "\n".join(lines)


def x_chrono_rows__mutmut_9(results: dict[str, dict[str, Any]], labels: dict[str, str]) -> str:
    """LaTeX rows of the chronological study: partitions, prevalence shift, lower pairs."""
    lines = []
    for name, label in labels.items():
        result = results[name]
        if "excluded" in result:
            lines.append(
                f"{label} & \\multicolumn{{4}}{{l}}{{excluded: {_short(result['EXCLUDED'])}}} \\\\"
            )
            continue
        part = result["partitions"]
        lower = sum(
            result["chronological"][m]["pr_auc"] < result["stratified"][m]["pr_auc"]
            for m in result["chronological"]
        )
        lines.append(
            f"{label} & {part['test']['positives']} "
            f"& {100 * part['train']['prevalence']:.1f} & {100 * part['test']['prevalence']:.1f} "
            f"& {lower} of {len(result['chronological'])} \\\\"
        )
    return "\n".join(lines)


def x_chrono_rows__mutmut_10(results: dict[str, dict[str, Any]], labels: dict[str, str]) -> str:
    """LaTeX rows of the chronological study: partitions, prevalence shift, lower pairs."""
    lines = []
    for name, label in labels.items():
        result = results[name]
        if "excluded" in result:
            lines.append(
                f"{label} & \\multicolumn{{4}}{{l}}{{excluded: {_short(result['excluded'])}}} \\\\"
            )
            break
        part = result["partitions"]
        lower = sum(
            result["chronological"][m]["pr_auc"] < result["stratified"][m]["pr_auc"]
            for m in result["chronological"]
        )
        lines.append(
            f"{label} & {part['test']['positives']} "
            f"& {100 * part['train']['prevalence']:.1f} & {100 * part['test']['prevalence']:.1f} "
            f"& {lower} of {len(result['chronological'])} \\\\"
        )
    return "\n".join(lines)


def x_chrono_rows__mutmut_11(results: dict[str, dict[str, Any]], labels: dict[str, str]) -> str:
    """LaTeX rows of the chronological study: partitions, prevalence shift, lower pairs."""
    lines = []
    for name, label in labels.items():
        result = results[name]
        if "excluded" in result:
            lines.append(
                f"{label} & \\multicolumn{{4}}{{l}}{{excluded: {_short(result['excluded'])}}} \\\\"
            )
            continue
        part = None
        lower = sum(
            result["chronological"][m]["pr_auc"] < result["stratified"][m]["pr_auc"]
            for m in result["chronological"]
        )
        lines.append(
            f"{label} & {part['test']['positives']} "
            f"& {100 * part['train']['prevalence']:.1f} & {100 * part['test']['prevalence']:.1f} "
            f"& {lower} of {len(result['chronological'])} \\\\"
        )
    return "\n".join(lines)


def x_chrono_rows__mutmut_12(results: dict[str, dict[str, Any]], labels: dict[str, str]) -> str:
    """LaTeX rows of the chronological study: partitions, prevalence shift, lower pairs."""
    lines = []
    for name, label in labels.items():
        result = results[name]
        if "excluded" in result:
            lines.append(
                f"{label} & \\multicolumn{{4}}{{l}}{{excluded: {_short(result['excluded'])}}} \\\\"
            )
            continue
        part = result["XXpartitionsXX"]
        lower = sum(
            result["chronological"][m]["pr_auc"] < result["stratified"][m]["pr_auc"]
            for m in result["chronological"]
        )
        lines.append(
            f"{label} & {part['test']['positives']} "
            f"& {100 * part['train']['prevalence']:.1f} & {100 * part['test']['prevalence']:.1f} "
            f"& {lower} of {len(result['chronological'])} \\\\"
        )
    return "\n".join(lines)


def x_chrono_rows__mutmut_13(results: dict[str, dict[str, Any]], labels: dict[str, str]) -> str:
    """LaTeX rows of the chronological study: partitions, prevalence shift, lower pairs."""
    lines = []
    for name, label in labels.items():
        result = results[name]
        if "excluded" in result:
            lines.append(
                f"{label} & \\multicolumn{{4}}{{l}}{{excluded: {_short(result['excluded'])}}} \\\\"
            )
            continue
        part = result["PARTITIONS"]
        lower = sum(
            result["chronological"][m]["pr_auc"] < result["stratified"][m]["pr_auc"]
            for m in result["chronological"]
        )
        lines.append(
            f"{label} & {part['test']['positives']} "
            f"& {100 * part['train']['prevalence']:.1f} & {100 * part['test']['prevalence']:.1f} "
            f"& {lower} of {len(result['chronological'])} \\\\"
        )
    return "\n".join(lines)


def x_chrono_rows__mutmut_14(results: dict[str, dict[str, Any]], labels: dict[str, str]) -> str:
    """LaTeX rows of the chronological study: partitions, prevalence shift, lower pairs."""
    lines = []
    for name, label in labels.items():
        result = results[name]
        if "excluded" in result:
            lines.append(
                f"{label} & \\multicolumn{{4}}{{l}}{{excluded: {_short(result['excluded'])}}} \\\\"
            )
            continue
        part = result["partitions"]
        lower = None
        lines.append(
            f"{label} & {part['test']['positives']} "
            f"& {100 * part['train']['prevalence']:.1f} & {100 * part['test']['prevalence']:.1f} "
            f"& {lower} of {len(result['chronological'])} \\\\"
        )
    return "\n".join(lines)


def x_chrono_rows__mutmut_15(results: dict[str, dict[str, Any]], labels: dict[str, str]) -> str:
    """LaTeX rows of the chronological study: partitions, prevalence shift, lower pairs."""
    lines = []
    for name, label in labels.items():
        result = results[name]
        if "excluded" in result:
            lines.append(
                f"{label} & \\multicolumn{{4}}{{l}}{{excluded: {_short(result['excluded'])}}} \\\\"
            )
            continue
        part = result["partitions"]
        lower = sum(
            None
        )
        lines.append(
            f"{label} & {part['test']['positives']} "
            f"& {100 * part['train']['prevalence']:.1f} & {100 * part['test']['prevalence']:.1f} "
            f"& {lower} of {len(result['chronological'])} \\\\"
        )
    return "\n".join(lines)


def x_chrono_rows__mutmut_16(results: dict[str, dict[str, Any]], labels: dict[str, str]) -> str:
    """LaTeX rows of the chronological study: partitions, prevalence shift, lower pairs."""
    lines = []
    for name, label in labels.items():
        result = results[name]
        if "excluded" in result:
            lines.append(
                f"{label} & \\multicolumn{{4}}{{l}}{{excluded: {_short(result['excluded'])}}} \\\\"
            )
            continue
        part = result["partitions"]
        lower = sum(
            result["XXchronologicalXX"][m]["pr_auc"] < result["stratified"][m]["pr_auc"]
            for m in result["chronological"]
        )
        lines.append(
            f"{label} & {part['test']['positives']} "
            f"& {100 * part['train']['prevalence']:.1f} & {100 * part['test']['prevalence']:.1f} "
            f"& {lower} of {len(result['chronological'])} \\\\"
        )
    return "\n".join(lines)


def x_chrono_rows__mutmut_17(results: dict[str, dict[str, Any]], labels: dict[str, str]) -> str:
    """LaTeX rows of the chronological study: partitions, prevalence shift, lower pairs."""
    lines = []
    for name, label in labels.items():
        result = results[name]
        if "excluded" in result:
            lines.append(
                f"{label} & \\multicolumn{{4}}{{l}}{{excluded: {_short(result['excluded'])}}} \\\\"
            )
            continue
        part = result["partitions"]
        lower = sum(
            result["CHRONOLOGICAL"][m]["pr_auc"] < result["stratified"][m]["pr_auc"]
            for m in result["chronological"]
        )
        lines.append(
            f"{label} & {part['test']['positives']} "
            f"& {100 * part['train']['prevalence']:.1f} & {100 * part['test']['prevalence']:.1f} "
            f"& {lower} of {len(result['chronological'])} \\\\"
        )
    return "\n".join(lines)


def x_chrono_rows__mutmut_18(results: dict[str, dict[str, Any]], labels: dict[str, str]) -> str:
    """LaTeX rows of the chronological study: partitions, prevalence shift, lower pairs."""
    lines = []
    for name, label in labels.items():
        result = results[name]
        if "excluded" in result:
            lines.append(
                f"{label} & \\multicolumn{{4}}{{l}}{{excluded: {_short(result['excluded'])}}} \\\\"
            )
            continue
        part = result["partitions"]
        lower = sum(
            result["chronological"][m]["XXpr_aucXX"] < result["stratified"][m]["pr_auc"]
            for m in result["chronological"]
        )
        lines.append(
            f"{label} & {part['test']['positives']} "
            f"& {100 * part['train']['prevalence']:.1f} & {100 * part['test']['prevalence']:.1f} "
            f"& {lower} of {len(result['chronological'])} \\\\"
        )
    return "\n".join(lines)


def x_chrono_rows__mutmut_19(results: dict[str, dict[str, Any]], labels: dict[str, str]) -> str:
    """LaTeX rows of the chronological study: partitions, prevalence shift, lower pairs."""
    lines = []
    for name, label in labels.items():
        result = results[name]
        if "excluded" in result:
            lines.append(
                f"{label} & \\multicolumn{{4}}{{l}}{{excluded: {_short(result['excluded'])}}} \\\\"
            )
            continue
        part = result["partitions"]
        lower = sum(
            result["chronological"][m]["PR_AUC"] < result["stratified"][m]["pr_auc"]
            for m in result["chronological"]
        )
        lines.append(
            f"{label} & {part['test']['positives']} "
            f"& {100 * part['train']['prevalence']:.1f} & {100 * part['test']['prevalence']:.1f} "
            f"& {lower} of {len(result['chronological'])} \\\\"
        )
    return "\n".join(lines)


def x_chrono_rows__mutmut_20(results: dict[str, dict[str, Any]], labels: dict[str, str]) -> str:
    """LaTeX rows of the chronological study: partitions, prevalence shift, lower pairs."""
    lines = []
    for name, label in labels.items():
        result = results[name]
        if "excluded" in result:
            lines.append(
                f"{label} & \\multicolumn{{4}}{{l}}{{excluded: {_short(result['excluded'])}}} \\\\"
            )
            continue
        part = result["partitions"]
        lower = sum(
            result["chronological"][m]["pr_auc"] <= result["stratified"][m]["pr_auc"]
            for m in result["chronological"]
        )
        lines.append(
            f"{label} & {part['test']['positives']} "
            f"& {100 * part['train']['prevalence']:.1f} & {100 * part['test']['prevalence']:.1f} "
            f"& {lower} of {len(result['chronological'])} \\\\"
        )
    return "\n".join(lines)


def x_chrono_rows__mutmut_21(results: dict[str, dict[str, Any]], labels: dict[str, str]) -> str:
    """LaTeX rows of the chronological study: partitions, prevalence shift, lower pairs."""
    lines = []
    for name, label in labels.items():
        result = results[name]
        if "excluded" in result:
            lines.append(
                f"{label} & \\multicolumn{{4}}{{l}}{{excluded: {_short(result['excluded'])}}} \\\\"
            )
            continue
        part = result["partitions"]
        lower = sum(
            result["chronological"][m]["pr_auc"] < result["XXstratifiedXX"][m]["pr_auc"]
            for m in result["chronological"]
        )
        lines.append(
            f"{label} & {part['test']['positives']} "
            f"& {100 * part['train']['prevalence']:.1f} & {100 * part['test']['prevalence']:.1f} "
            f"& {lower} of {len(result['chronological'])} \\\\"
        )
    return "\n".join(lines)


def x_chrono_rows__mutmut_22(results: dict[str, dict[str, Any]], labels: dict[str, str]) -> str:
    """LaTeX rows of the chronological study: partitions, prevalence shift, lower pairs."""
    lines = []
    for name, label in labels.items():
        result = results[name]
        if "excluded" in result:
            lines.append(
                f"{label} & \\multicolumn{{4}}{{l}}{{excluded: {_short(result['excluded'])}}} \\\\"
            )
            continue
        part = result["partitions"]
        lower = sum(
            result["chronological"][m]["pr_auc"] < result["STRATIFIED"][m]["pr_auc"]
            for m in result["chronological"]
        )
        lines.append(
            f"{label} & {part['test']['positives']} "
            f"& {100 * part['train']['prevalence']:.1f} & {100 * part['test']['prevalence']:.1f} "
            f"& {lower} of {len(result['chronological'])} \\\\"
        )
    return "\n".join(lines)


def x_chrono_rows__mutmut_23(results: dict[str, dict[str, Any]], labels: dict[str, str]) -> str:
    """LaTeX rows of the chronological study: partitions, prevalence shift, lower pairs."""
    lines = []
    for name, label in labels.items():
        result = results[name]
        if "excluded" in result:
            lines.append(
                f"{label} & \\multicolumn{{4}}{{l}}{{excluded: {_short(result['excluded'])}}} \\\\"
            )
            continue
        part = result["partitions"]
        lower = sum(
            result["chronological"][m]["pr_auc"] < result["stratified"][m]["XXpr_aucXX"]
            for m in result["chronological"]
        )
        lines.append(
            f"{label} & {part['test']['positives']} "
            f"& {100 * part['train']['prevalence']:.1f} & {100 * part['test']['prevalence']:.1f} "
            f"& {lower} of {len(result['chronological'])} \\\\"
        )
    return "\n".join(lines)


def x_chrono_rows__mutmut_24(results: dict[str, dict[str, Any]], labels: dict[str, str]) -> str:
    """LaTeX rows of the chronological study: partitions, prevalence shift, lower pairs."""
    lines = []
    for name, label in labels.items():
        result = results[name]
        if "excluded" in result:
            lines.append(
                f"{label} & \\multicolumn{{4}}{{l}}{{excluded: {_short(result['excluded'])}}} \\\\"
            )
            continue
        part = result["partitions"]
        lower = sum(
            result["chronological"][m]["pr_auc"] < result["stratified"][m]["PR_AUC"]
            for m in result["chronological"]
        )
        lines.append(
            f"{label} & {part['test']['positives']} "
            f"& {100 * part['train']['prevalence']:.1f} & {100 * part['test']['prevalence']:.1f} "
            f"& {lower} of {len(result['chronological'])} \\\\"
        )
    return "\n".join(lines)


def x_chrono_rows__mutmut_25(results: dict[str, dict[str, Any]], labels: dict[str, str]) -> str:
    """LaTeX rows of the chronological study: partitions, prevalence shift, lower pairs."""
    lines = []
    for name, label in labels.items():
        result = results[name]
        if "excluded" in result:
            lines.append(
                f"{label} & \\multicolumn{{4}}{{l}}{{excluded: {_short(result['excluded'])}}} \\\\"
            )
            continue
        part = result["partitions"]
        lower = sum(
            result["chronological"][m]["pr_auc"] < result["stratified"][m]["pr_auc"]
            for m in result["XXchronologicalXX"]
        )
        lines.append(
            f"{label} & {part['test']['positives']} "
            f"& {100 * part['train']['prevalence']:.1f} & {100 * part['test']['prevalence']:.1f} "
            f"& {lower} of {len(result['chronological'])} \\\\"
        )
    return "\n".join(lines)


def x_chrono_rows__mutmut_26(results: dict[str, dict[str, Any]], labels: dict[str, str]) -> str:
    """LaTeX rows of the chronological study: partitions, prevalence shift, lower pairs."""
    lines = []
    for name, label in labels.items():
        result = results[name]
        if "excluded" in result:
            lines.append(
                f"{label} & \\multicolumn{{4}}{{l}}{{excluded: {_short(result['excluded'])}}} \\\\"
            )
            continue
        part = result["partitions"]
        lower = sum(
            result["chronological"][m]["pr_auc"] < result["stratified"][m]["pr_auc"]
            for m in result["CHRONOLOGICAL"]
        )
        lines.append(
            f"{label} & {part['test']['positives']} "
            f"& {100 * part['train']['prevalence']:.1f} & {100 * part['test']['prevalence']:.1f} "
            f"& {lower} of {len(result['chronological'])} \\\\"
        )
    return "\n".join(lines)


def x_chrono_rows__mutmut_27(results: dict[str, dict[str, Any]], labels: dict[str, str]) -> str:
    """LaTeX rows of the chronological study: partitions, prevalence shift, lower pairs."""
    lines = []
    for name, label in labels.items():
        result = results[name]
        if "excluded" in result:
            lines.append(
                f"{label} & \\multicolumn{{4}}{{l}}{{excluded: {_short(result['excluded'])}}} \\\\"
            )
            continue
        part = result["partitions"]
        lower = sum(
            result["chronological"][m]["pr_auc"] < result["stratified"][m]["pr_auc"]
            for m in result["chronological"]
        )
        lines.append(
            None
        )
    return "\n".join(lines)


def x_chrono_rows__mutmut_28(results: dict[str, dict[str, Any]], labels: dict[str, str]) -> str:
    """LaTeX rows of the chronological study: partitions, prevalence shift, lower pairs."""
    lines = []
    for name, label in labels.items():
        result = results[name]
        if "excluded" in result:
            lines.append(
                f"{label} & \\multicolumn{{4}}{{l}}{{excluded: {_short(result['excluded'])}}} \\\\"
            )
            continue
        part = result["partitions"]
        lower = sum(
            result["chronological"][m]["pr_auc"] < result["stratified"][m]["pr_auc"]
            for m in result["chronological"]
        )
        lines.append(
            f"{label} & {part['XXtestXX']['positives']} "
            f"& {100 * part['train']['prevalence']:.1f} & {100 * part['test']['prevalence']:.1f} "
            f"& {lower} of {len(result['chronological'])} \\\\"
        )
    return "\n".join(lines)


def x_chrono_rows__mutmut_29(results: dict[str, dict[str, Any]], labels: dict[str, str]) -> str:
    """LaTeX rows of the chronological study: partitions, prevalence shift, lower pairs."""
    lines = []
    for name, label in labels.items():
        result = results[name]
        if "excluded" in result:
            lines.append(
                f"{label} & \\multicolumn{{4}}{{l}}{{excluded: {_short(result['excluded'])}}} \\\\"
            )
            continue
        part = result["partitions"]
        lower = sum(
            result["chronological"][m]["pr_auc"] < result["stratified"][m]["pr_auc"]
            for m in result["chronological"]
        )
        lines.append(
            f"{label} & {part['TEST']['positives']} "
            f"& {100 * part['train']['prevalence']:.1f} & {100 * part['test']['prevalence']:.1f} "
            f"& {lower} of {len(result['chronological'])} \\\\"
        )
    return "\n".join(lines)


def x_chrono_rows__mutmut_30(results: dict[str, dict[str, Any]], labels: dict[str, str]) -> str:
    """LaTeX rows of the chronological study: partitions, prevalence shift, lower pairs."""
    lines = []
    for name, label in labels.items():
        result = results[name]
        if "excluded" in result:
            lines.append(
                f"{label} & \\multicolumn{{4}}{{l}}{{excluded: {_short(result['excluded'])}}} \\\\"
            )
            continue
        part = result["partitions"]
        lower = sum(
            result["chronological"][m]["pr_auc"] < result["stratified"][m]["pr_auc"]
            for m in result["chronological"]
        )
        lines.append(
            f"{label} & {part['test']['XXpositivesXX']} "
            f"& {100 * part['train']['prevalence']:.1f} & {100 * part['test']['prevalence']:.1f} "
            f"& {lower} of {len(result['chronological'])} \\\\"
        )
    return "\n".join(lines)


def x_chrono_rows__mutmut_31(results: dict[str, dict[str, Any]], labels: dict[str, str]) -> str:
    """LaTeX rows of the chronological study: partitions, prevalence shift, lower pairs."""
    lines = []
    for name, label in labels.items():
        result = results[name]
        if "excluded" in result:
            lines.append(
                f"{label} & \\multicolumn{{4}}{{l}}{{excluded: {_short(result['excluded'])}}} \\\\"
            )
            continue
        part = result["partitions"]
        lower = sum(
            result["chronological"][m]["pr_auc"] < result["stratified"][m]["pr_auc"]
            for m in result["chronological"]
        )
        lines.append(
            f"{label} & {part['test']['POSITIVES']} "
            f"& {100 * part['train']['prevalence']:.1f} & {100 * part['test']['prevalence']:.1f} "
            f"& {lower} of {len(result['chronological'])} \\\\"
        )
    return "\n".join(lines)


def x_chrono_rows__mutmut_32(results: dict[str, dict[str, Any]], labels: dict[str, str]) -> str:
    """LaTeX rows of the chronological study: partitions, prevalence shift, lower pairs."""
    lines = []
    for name, label in labels.items():
        result = results[name]
        if "excluded" in result:
            lines.append(
                f"{label} & \\multicolumn{{4}}{{l}}{{excluded: {_short(result['excluded'])}}} \\\\"
            )
            continue
        part = result["partitions"]
        lower = sum(
            result["chronological"][m]["pr_auc"] < result["stratified"][m]["pr_auc"]
            for m in result["chronological"]
        )
        lines.append(
            f"{label} & {part['test']['positives']} "
            f"& {100 / part['train']['prevalence']:.1f} & {100 * part['test']['prevalence']:.1f} "
            f"& {lower} of {len(result['chronological'])} \\\\"
        )
    return "\n".join(lines)


def x_chrono_rows__mutmut_33(results: dict[str, dict[str, Any]], labels: dict[str, str]) -> str:
    """LaTeX rows of the chronological study: partitions, prevalence shift, lower pairs."""
    lines = []
    for name, label in labels.items():
        result = results[name]
        if "excluded" in result:
            lines.append(
                f"{label} & \\multicolumn{{4}}{{l}}{{excluded: {_short(result['excluded'])}}} \\\\"
            )
            continue
        part = result["partitions"]
        lower = sum(
            result["chronological"][m]["pr_auc"] < result["stratified"][m]["pr_auc"]
            for m in result["chronological"]
        )
        lines.append(
            f"{label} & {part['test']['positives']} "
            f"& {101 * part['train']['prevalence']:.1f} & {100 * part['test']['prevalence']:.1f} "
            f"& {lower} of {len(result['chronological'])} \\\\"
        )
    return "\n".join(lines)


def x_chrono_rows__mutmut_34(results: dict[str, dict[str, Any]], labels: dict[str, str]) -> str:
    """LaTeX rows of the chronological study: partitions, prevalence shift, lower pairs."""
    lines = []
    for name, label in labels.items():
        result = results[name]
        if "excluded" in result:
            lines.append(
                f"{label} & \\multicolumn{{4}}{{l}}{{excluded: {_short(result['excluded'])}}} \\\\"
            )
            continue
        part = result["partitions"]
        lower = sum(
            result["chronological"][m]["pr_auc"] < result["stratified"][m]["pr_auc"]
            for m in result["chronological"]
        )
        lines.append(
            f"{label} & {part['test']['positives']} "
            f"& {100 * part['XXtrainXX']['prevalence']:.1f} & {100 * part['test']['prevalence']:.1f} "
            f"& {lower} of {len(result['chronological'])} \\\\"
        )
    return "\n".join(lines)


def x_chrono_rows__mutmut_35(results: dict[str, dict[str, Any]], labels: dict[str, str]) -> str:
    """LaTeX rows of the chronological study: partitions, prevalence shift, lower pairs."""
    lines = []
    for name, label in labels.items():
        result = results[name]
        if "excluded" in result:
            lines.append(
                f"{label} & \\multicolumn{{4}}{{l}}{{excluded: {_short(result['excluded'])}}} \\\\"
            )
            continue
        part = result["partitions"]
        lower = sum(
            result["chronological"][m]["pr_auc"] < result["stratified"][m]["pr_auc"]
            for m in result["chronological"]
        )
        lines.append(
            f"{label} & {part['test']['positives']} "
            f"& {100 * part['TRAIN']['prevalence']:.1f} & {100 * part['test']['prevalence']:.1f} "
            f"& {lower} of {len(result['chronological'])} \\\\"
        )
    return "\n".join(lines)


def x_chrono_rows__mutmut_36(results: dict[str, dict[str, Any]], labels: dict[str, str]) -> str:
    """LaTeX rows of the chronological study: partitions, prevalence shift, lower pairs."""
    lines = []
    for name, label in labels.items():
        result = results[name]
        if "excluded" in result:
            lines.append(
                f"{label} & \\multicolumn{{4}}{{l}}{{excluded: {_short(result['excluded'])}}} \\\\"
            )
            continue
        part = result["partitions"]
        lower = sum(
            result["chronological"][m]["pr_auc"] < result["stratified"][m]["pr_auc"]
            for m in result["chronological"]
        )
        lines.append(
            f"{label} & {part['test']['positives']} "
            f"& {100 * part['train']['XXprevalenceXX']:.1f} & {100 * part['test']['prevalence']:.1f} "
            f"& {lower} of {len(result['chronological'])} \\\\"
        )
    return "\n".join(lines)


def x_chrono_rows__mutmut_37(results: dict[str, dict[str, Any]], labels: dict[str, str]) -> str:
    """LaTeX rows of the chronological study: partitions, prevalence shift, lower pairs."""
    lines = []
    for name, label in labels.items():
        result = results[name]
        if "excluded" in result:
            lines.append(
                f"{label} & \\multicolumn{{4}}{{l}}{{excluded: {_short(result['excluded'])}}} \\\\"
            )
            continue
        part = result["partitions"]
        lower = sum(
            result["chronological"][m]["pr_auc"] < result["stratified"][m]["pr_auc"]
            for m in result["chronological"]
        )
        lines.append(
            f"{label} & {part['test']['positives']} "
            f"& {100 * part['train']['PREVALENCE']:.1f} & {100 * part['test']['prevalence']:.1f} "
            f"& {lower} of {len(result['chronological'])} \\\\"
        )
    return "\n".join(lines)


def x_chrono_rows__mutmut_38(results: dict[str, dict[str, Any]], labels: dict[str, str]) -> str:
    """LaTeX rows of the chronological study: partitions, prevalence shift, lower pairs."""
    lines = []
    for name, label in labels.items():
        result = results[name]
        if "excluded" in result:
            lines.append(
                f"{label} & \\multicolumn{{4}}{{l}}{{excluded: {_short(result['excluded'])}}} \\\\"
            )
            continue
        part = result["partitions"]
        lower = sum(
            result["chronological"][m]["pr_auc"] < result["stratified"][m]["pr_auc"]
            for m in result["chronological"]
        )
        lines.append(
            f"{label} & {part['test']['positives']} "
            f"& {100 * part['train']['prevalence']:.1f} & {100 / part['test']['prevalence']:.1f} "
            f"& {lower} of {len(result['chronological'])} \\\\"
        )
    return "\n".join(lines)


def x_chrono_rows__mutmut_39(results: dict[str, dict[str, Any]], labels: dict[str, str]) -> str:
    """LaTeX rows of the chronological study: partitions, prevalence shift, lower pairs."""
    lines = []
    for name, label in labels.items():
        result = results[name]
        if "excluded" in result:
            lines.append(
                f"{label} & \\multicolumn{{4}}{{l}}{{excluded: {_short(result['excluded'])}}} \\\\"
            )
            continue
        part = result["partitions"]
        lower = sum(
            result["chronological"][m]["pr_auc"] < result["stratified"][m]["pr_auc"]
            for m in result["chronological"]
        )
        lines.append(
            f"{label} & {part['test']['positives']} "
            f"& {100 * part['train']['prevalence']:.1f} & {101 * part['test']['prevalence']:.1f} "
            f"& {lower} of {len(result['chronological'])} \\\\"
        )
    return "\n".join(lines)


def x_chrono_rows__mutmut_40(results: dict[str, dict[str, Any]], labels: dict[str, str]) -> str:
    """LaTeX rows of the chronological study: partitions, prevalence shift, lower pairs."""
    lines = []
    for name, label in labels.items():
        result = results[name]
        if "excluded" in result:
            lines.append(
                f"{label} & \\multicolumn{{4}}{{l}}{{excluded: {_short(result['excluded'])}}} \\\\"
            )
            continue
        part = result["partitions"]
        lower = sum(
            result["chronological"][m]["pr_auc"] < result["stratified"][m]["pr_auc"]
            for m in result["chronological"]
        )
        lines.append(
            f"{label} & {part['test']['positives']} "
            f"& {100 * part['train']['prevalence']:.1f} & {100 * part['XXtestXX']['prevalence']:.1f} "
            f"& {lower} of {len(result['chronological'])} \\\\"
        )
    return "\n".join(lines)


def x_chrono_rows__mutmut_41(results: dict[str, dict[str, Any]], labels: dict[str, str]) -> str:
    """LaTeX rows of the chronological study: partitions, prevalence shift, lower pairs."""
    lines = []
    for name, label in labels.items():
        result = results[name]
        if "excluded" in result:
            lines.append(
                f"{label} & \\multicolumn{{4}}{{l}}{{excluded: {_short(result['excluded'])}}} \\\\"
            )
            continue
        part = result["partitions"]
        lower = sum(
            result["chronological"][m]["pr_auc"] < result["stratified"][m]["pr_auc"]
            for m in result["chronological"]
        )
        lines.append(
            f"{label} & {part['test']['positives']} "
            f"& {100 * part['train']['prevalence']:.1f} & {100 * part['TEST']['prevalence']:.1f} "
            f"& {lower} of {len(result['chronological'])} \\\\"
        )
    return "\n".join(lines)


def x_chrono_rows__mutmut_42(results: dict[str, dict[str, Any]], labels: dict[str, str]) -> str:
    """LaTeX rows of the chronological study: partitions, prevalence shift, lower pairs."""
    lines = []
    for name, label in labels.items():
        result = results[name]
        if "excluded" in result:
            lines.append(
                f"{label} & \\multicolumn{{4}}{{l}}{{excluded: {_short(result['excluded'])}}} \\\\"
            )
            continue
        part = result["partitions"]
        lower = sum(
            result["chronological"][m]["pr_auc"] < result["stratified"][m]["pr_auc"]
            for m in result["chronological"]
        )
        lines.append(
            f"{label} & {part['test']['positives']} "
            f"& {100 * part['train']['prevalence']:.1f} & {100 * part['test']['XXprevalenceXX']:.1f} "
            f"& {lower} of {len(result['chronological'])} \\\\"
        )
    return "\n".join(lines)


def x_chrono_rows__mutmut_43(results: dict[str, dict[str, Any]], labels: dict[str, str]) -> str:
    """LaTeX rows of the chronological study: partitions, prevalence shift, lower pairs."""
    lines = []
    for name, label in labels.items():
        result = results[name]
        if "excluded" in result:
            lines.append(
                f"{label} & \\multicolumn{{4}}{{l}}{{excluded: {_short(result['excluded'])}}} \\\\"
            )
            continue
        part = result["partitions"]
        lower = sum(
            result["chronological"][m]["pr_auc"] < result["stratified"][m]["pr_auc"]
            for m in result["chronological"]
        )
        lines.append(
            f"{label} & {part['test']['positives']} "
            f"& {100 * part['train']['prevalence']:.1f} & {100 * part['test']['PREVALENCE']:.1f} "
            f"& {lower} of {len(result['chronological'])} \\\\"
        )
    return "\n".join(lines)


def x_chrono_rows__mutmut_44(results: dict[str, dict[str, Any]], labels: dict[str, str]) -> str:
    """LaTeX rows of the chronological study: partitions, prevalence shift, lower pairs."""
    lines = []
    for name, label in labels.items():
        result = results[name]
        if "excluded" in result:
            lines.append(
                f"{label} & \\multicolumn{{4}}{{l}}{{excluded: {_short(result['excluded'])}}} \\\\"
            )
            continue
        part = result["partitions"]
        lower = sum(
            result["chronological"][m]["pr_auc"] < result["stratified"][m]["pr_auc"]
            for m in result["chronological"]
        )
        lines.append(
            f"{label} & {part['test']['positives']} "
            f"& {100 * part['train']['prevalence']:.1f} & {100 * part['test']['prevalence']:.1f} "
            f"& {lower} of {len(result['chronological'])} \\\\"
        )
    return "\n".join(None)


def x_chrono_rows__mutmut_45(results: dict[str, dict[str, Any]], labels: dict[str, str]) -> str:
    """LaTeX rows of the chronological study: partitions, prevalence shift, lower pairs."""
    lines = []
    for name, label in labels.items():
        result = results[name]
        if "excluded" in result:
            lines.append(
                f"{label} & \\multicolumn{{4}}{{l}}{{excluded: {_short(result['excluded'])}}} \\\\"
            )
            continue
        part = result["partitions"]
        lower = sum(
            result["chronological"][m]["pr_auc"] < result["stratified"][m]["pr_auc"]
            for m in result["chronological"]
        )
        lines.append(
            f"{label} & {part['test']['positives']} "
            f"& {100 * part['train']['prevalence']:.1f} & {100 * part['test']['prevalence']:.1f} "
            f"& {lower} of {len(result['chronological'])} \\\\"
        )
    return "XX\nXX".join(lines)

mutants_x_chrono_rows__mutmut['_mutmut_orig'] = x_chrono_rows__mutmut_orig # type: ignore # mutmut generated
mutants_x_chrono_rows__mutmut['x_chrono_rows__mutmut_1'] = x_chrono_rows__mutmut_1 # type: ignore # mutmut generated
mutants_x_chrono_rows__mutmut['x_chrono_rows__mutmut_2'] = x_chrono_rows__mutmut_2 # type: ignore # mutmut generated
mutants_x_chrono_rows__mutmut['x_chrono_rows__mutmut_3'] = x_chrono_rows__mutmut_3 # type: ignore # mutmut generated
mutants_x_chrono_rows__mutmut['x_chrono_rows__mutmut_4'] = x_chrono_rows__mutmut_4 # type: ignore # mutmut generated
mutants_x_chrono_rows__mutmut['x_chrono_rows__mutmut_5'] = x_chrono_rows__mutmut_5 # type: ignore # mutmut generated
mutants_x_chrono_rows__mutmut['x_chrono_rows__mutmut_6'] = x_chrono_rows__mutmut_6 # type: ignore # mutmut generated
mutants_x_chrono_rows__mutmut['x_chrono_rows__mutmut_7'] = x_chrono_rows__mutmut_7 # type: ignore # mutmut generated
mutants_x_chrono_rows__mutmut['x_chrono_rows__mutmut_8'] = x_chrono_rows__mutmut_8 # type: ignore # mutmut generated
mutants_x_chrono_rows__mutmut['x_chrono_rows__mutmut_9'] = x_chrono_rows__mutmut_9 # type: ignore # mutmut generated
mutants_x_chrono_rows__mutmut['x_chrono_rows__mutmut_10'] = x_chrono_rows__mutmut_10 # type: ignore # mutmut generated
mutants_x_chrono_rows__mutmut['x_chrono_rows__mutmut_11'] = x_chrono_rows__mutmut_11 # type: ignore # mutmut generated
mutants_x_chrono_rows__mutmut['x_chrono_rows__mutmut_12'] = x_chrono_rows__mutmut_12 # type: ignore # mutmut generated
mutants_x_chrono_rows__mutmut['x_chrono_rows__mutmut_13'] = x_chrono_rows__mutmut_13 # type: ignore # mutmut generated
mutants_x_chrono_rows__mutmut['x_chrono_rows__mutmut_14'] = x_chrono_rows__mutmut_14 # type: ignore # mutmut generated
mutants_x_chrono_rows__mutmut['x_chrono_rows__mutmut_15'] = x_chrono_rows__mutmut_15 # type: ignore # mutmut generated
mutants_x_chrono_rows__mutmut['x_chrono_rows__mutmut_16'] = x_chrono_rows__mutmut_16 # type: ignore # mutmut generated
mutants_x_chrono_rows__mutmut['x_chrono_rows__mutmut_17'] = x_chrono_rows__mutmut_17 # type: ignore # mutmut generated
mutants_x_chrono_rows__mutmut['x_chrono_rows__mutmut_18'] = x_chrono_rows__mutmut_18 # type: ignore # mutmut generated
mutants_x_chrono_rows__mutmut['x_chrono_rows__mutmut_19'] = x_chrono_rows__mutmut_19 # type: ignore # mutmut generated
mutants_x_chrono_rows__mutmut['x_chrono_rows__mutmut_20'] = x_chrono_rows__mutmut_20 # type: ignore # mutmut generated
mutants_x_chrono_rows__mutmut['x_chrono_rows__mutmut_21'] = x_chrono_rows__mutmut_21 # type: ignore # mutmut generated
mutants_x_chrono_rows__mutmut['x_chrono_rows__mutmut_22'] = x_chrono_rows__mutmut_22 # type: ignore # mutmut generated
mutants_x_chrono_rows__mutmut['x_chrono_rows__mutmut_23'] = x_chrono_rows__mutmut_23 # type: ignore # mutmut generated
mutants_x_chrono_rows__mutmut['x_chrono_rows__mutmut_24'] = x_chrono_rows__mutmut_24 # type: ignore # mutmut generated
mutants_x_chrono_rows__mutmut['x_chrono_rows__mutmut_25'] = x_chrono_rows__mutmut_25 # type: ignore # mutmut generated
mutants_x_chrono_rows__mutmut['x_chrono_rows__mutmut_26'] = x_chrono_rows__mutmut_26 # type: ignore # mutmut generated
mutants_x_chrono_rows__mutmut['x_chrono_rows__mutmut_27'] = x_chrono_rows__mutmut_27 # type: ignore # mutmut generated
mutants_x_chrono_rows__mutmut['x_chrono_rows__mutmut_28'] = x_chrono_rows__mutmut_28 # type: ignore # mutmut generated
mutants_x_chrono_rows__mutmut['x_chrono_rows__mutmut_29'] = x_chrono_rows__mutmut_29 # type: ignore # mutmut generated
mutants_x_chrono_rows__mutmut['x_chrono_rows__mutmut_30'] = x_chrono_rows__mutmut_30 # type: ignore # mutmut generated
mutants_x_chrono_rows__mutmut['x_chrono_rows__mutmut_31'] = x_chrono_rows__mutmut_31 # type: ignore # mutmut generated
mutants_x_chrono_rows__mutmut['x_chrono_rows__mutmut_32'] = x_chrono_rows__mutmut_32 # type: ignore # mutmut generated
mutants_x_chrono_rows__mutmut['x_chrono_rows__mutmut_33'] = x_chrono_rows__mutmut_33 # type: ignore # mutmut generated
mutants_x_chrono_rows__mutmut['x_chrono_rows__mutmut_34'] = x_chrono_rows__mutmut_34 # type: ignore # mutmut generated
mutants_x_chrono_rows__mutmut['x_chrono_rows__mutmut_35'] = x_chrono_rows__mutmut_35 # type: ignore # mutmut generated
mutants_x_chrono_rows__mutmut['x_chrono_rows__mutmut_36'] = x_chrono_rows__mutmut_36 # type: ignore # mutmut generated
mutants_x_chrono_rows__mutmut['x_chrono_rows__mutmut_37'] = x_chrono_rows__mutmut_37 # type: ignore # mutmut generated
mutants_x_chrono_rows__mutmut['x_chrono_rows__mutmut_38'] = x_chrono_rows__mutmut_38 # type: ignore # mutmut generated
mutants_x_chrono_rows__mutmut['x_chrono_rows__mutmut_39'] = x_chrono_rows__mutmut_39 # type: ignore # mutmut generated
mutants_x_chrono_rows__mutmut['x_chrono_rows__mutmut_40'] = x_chrono_rows__mutmut_40 # type: ignore # mutmut generated
mutants_x_chrono_rows__mutmut['x_chrono_rows__mutmut_41'] = x_chrono_rows__mutmut_41 # type: ignore # mutmut generated
mutants_x_chrono_rows__mutmut['x_chrono_rows__mutmut_42'] = x_chrono_rows__mutmut_42 # type: ignore # mutmut generated
mutants_x_chrono_rows__mutmut['x_chrono_rows__mutmut_43'] = x_chrono_rows__mutmut_43 # type: ignore # mutmut generated
mutants_x_chrono_rows__mutmut['x_chrono_rows__mutmut_44'] = x_chrono_rows__mutmut_44 # type: ignore # mutmut generated
mutants_x_chrono_rows__mutmut['x_chrono_rows__mutmut_45'] = x_chrono_rows__mutmut_45 # type: ignore # mutmut generated
