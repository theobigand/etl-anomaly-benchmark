"""Recover the train/validation/test memberships of the labelled-pool experiments (T088, T089).

The historical runs did not archive row identifiers. The split is a deterministic function of the
cleaned table and the seed (``normalise.split``, unchanged since the archives were written), so
the memberships are recomputed, never invented: each record keeps the digests of the source file,
of the cleaned table and of every index set, the partition sizes and prevalences, and the result
of replaying the deterministic Z-score detector on the recomputed partitions against the archived
per-seed metrics. A problem whose replay differs from the archive is flagged, not repaired.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import sys
from pathlib import Path
from typing import Any

import numpy as np

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import labelled_benchmark as lb  # noqa: E402
import normalise as nm  # noqa: E402

FORMAT = 1
TOLERANCE = 1e-9


from mutmut.mutation.trampoline import wrap_in_trampoline as _mutmut_mutated, MutantDict
mutants_x__digest__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x__digest__mutmut)
def _digest(array: np.ndarray) -> str:
    return hashlib.sha256(np.ascontiguousarray(array).tobytes()).hexdigest()


def x__digest__mutmut_orig(array: np.ndarray) -> str:
    return hashlib.sha256(np.ascontiguousarray(array).tobytes()).hexdigest()


def x__digest__mutmut_1(array: np.ndarray) -> str:
    return hashlib.sha256(None).hexdigest()


def x__digest__mutmut_2(array: np.ndarray) -> str:
    return hashlib.sha256(np.ascontiguousarray(None).tobytes()).hexdigest()

mutants_x__digest__mutmut['_mutmut_orig'] = x__digest__mutmut_orig # type: ignore # mutmut generated
mutants_x__digest__mutmut['x__digest__mutmut_1'] = x__digest__mutmut_1 # type: ignore # mutmut generated
mutants_x__digest__mutmut['x__digest__mutmut_2'] = x__digest__mutmut_2 # type: ignore # mutmut generated
mutants_x__file_digest__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x__file_digest__mutmut)
def _file_digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def x__file_digest__mutmut_orig(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def x__file_digest__mutmut_1(path: Path) -> str:
    return hashlib.sha256(None).hexdigest()

mutants_x__file_digest__mutmut['_mutmut_orig'] = x__file_digest__mutmut_orig # type: ignore # mutmut generated
mutants_x__file_digest__mutmut['x__file_digest__mutmut_1'] = x__file_digest__mutmut_1 # type: ignore # mutmut generated
mutants_x_partitions__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_partitions__mutmut)
def partitions(x: np.ndarray, y: np.ndarray, seeds: tuple[int, ...]) -> dict[str, Any]:
    """Digests, sizes and prevalences of the split of every seed."""
    out: dict[str, Any] = {}
    for seed in seeds:
        part = nm.split(x, y, seed)
        record: dict[str, Any] = {}
        for name in ("train", "val", "test"):
            rows = np.asarray(part[f"idx_{name}"], dtype=np.int64)
            record[name] = {
                "rows": int(len(rows)),
                "anomalies": int(y[rows].sum()),
                "prevalence": float(y[rows].mean()),
                "sha256": _digest(rows),
            }
        out[str(seed)] = record
    return out


def x_partitions__mutmut_orig(x: np.ndarray, y: np.ndarray, seeds: tuple[int, ...]) -> dict[str, Any]:
    """Digests, sizes and prevalences of the split of every seed."""
    out: dict[str, Any] = {}
    for seed in seeds:
        part = nm.split(x, y, seed)
        record: dict[str, Any] = {}
        for name in ("train", "val", "test"):
            rows = np.asarray(part[f"idx_{name}"], dtype=np.int64)
            record[name] = {
                "rows": int(len(rows)),
                "anomalies": int(y[rows].sum()),
                "prevalence": float(y[rows].mean()),
                "sha256": _digest(rows),
            }
        out[str(seed)] = record
    return out


def x_partitions__mutmut_1(x: np.ndarray, y: np.ndarray, seeds: tuple[int, ...]) -> dict[str, Any]:
    """Digests, sizes and prevalences of the split of every seed."""
    out: dict[str, Any] = None
    for seed in seeds:
        part = nm.split(x, y, seed)
        record: dict[str, Any] = {}
        for name in ("train", "val", "test"):
            rows = np.asarray(part[f"idx_{name}"], dtype=np.int64)
            record[name] = {
                "rows": int(len(rows)),
                "anomalies": int(y[rows].sum()),
                "prevalence": float(y[rows].mean()),
                "sha256": _digest(rows),
            }
        out[str(seed)] = record
    return out


def x_partitions__mutmut_2(x: np.ndarray, y: np.ndarray, seeds: tuple[int, ...]) -> dict[str, Any]:
    """Digests, sizes and prevalences of the split of every seed."""
    out: dict[str, Any] = {}
    for seed in seeds:
        part = None
        record: dict[str, Any] = {}
        for name in ("train", "val", "test"):
            rows = np.asarray(part[f"idx_{name}"], dtype=np.int64)
            record[name] = {
                "rows": int(len(rows)),
                "anomalies": int(y[rows].sum()),
                "prevalence": float(y[rows].mean()),
                "sha256": _digest(rows),
            }
        out[str(seed)] = record
    return out


def x_partitions__mutmut_3(x: np.ndarray, y: np.ndarray, seeds: tuple[int, ...]) -> dict[str, Any]:
    """Digests, sizes and prevalences of the split of every seed."""
    out: dict[str, Any] = {}
    for seed in seeds:
        part = nm.split(None, y, seed)
        record: dict[str, Any] = {}
        for name in ("train", "val", "test"):
            rows = np.asarray(part[f"idx_{name}"], dtype=np.int64)
            record[name] = {
                "rows": int(len(rows)),
                "anomalies": int(y[rows].sum()),
                "prevalence": float(y[rows].mean()),
                "sha256": _digest(rows),
            }
        out[str(seed)] = record
    return out


def x_partitions__mutmut_4(x: np.ndarray, y: np.ndarray, seeds: tuple[int, ...]) -> dict[str, Any]:
    """Digests, sizes and prevalences of the split of every seed."""
    out: dict[str, Any] = {}
    for seed in seeds:
        part = nm.split(x, None, seed)
        record: dict[str, Any] = {}
        for name in ("train", "val", "test"):
            rows = np.asarray(part[f"idx_{name}"], dtype=np.int64)
            record[name] = {
                "rows": int(len(rows)),
                "anomalies": int(y[rows].sum()),
                "prevalence": float(y[rows].mean()),
                "sha256": _digest(rows),
            }
        out[str(seed)] = record
    return out


def x_partitions__mutmut_5(x: np.ndarray, y: np.ndarray, seeds: tuple[int, ...]) -> dict[str, Any]:
    """Digests, sizes and prevalences of the split of every seed."""
    out: dict[str, Any] = {}
    for seed in seeds:
        part = nm.split(x, y, None)
        record: dict[str, Any] = {}
        for name in ("train", "val", "test"):
            rows = np.asarray(part[f"idx_{name}"], dtype=np.int64)
            record[name] = {
                "rows": int(len(rows)),
                "anomalies": int(y[rows].sum()),
                "prevalence": float(y[rows].mean()),
                "sha256": _digest(rows),
            }
        out[str(seed)] = record
    return out


def x_partitions__mutmut_6(x: np.ndarray, y: np.ndarray, seeds: tuple[int, ...]) -> dict[str, Any]:
    """Digests, sizes and prevalences of the split of every seed."""
    out: dict[str, Any] = {}
    for seed in seeds:
        part = nm.split(y, seed)
        record: dict[str, Any] = {}
        for name in ("train", "val", "test"):
            rows = np.asarray(part[f"idx_{name}"], dtype=np.int64)
            record[name] = {
                "rows": int(len(rows)),
                "anomalies": int(y[rows].sum()),
                "prevalence": float(y[rows].mean()),
                "sha256": _digest(rows),
            }
        out[str(seed)] = record
    return out


def x_partitions__mutmut_7(x: np.ndarray, y: np.ndarray, seeds: tuple[int, ...]) -> dict[str, Any]:
    """Digests, sizes and prevalences of the split of every seed."""
    out: dict[str, Any] = {}
    for seed in seeds:
        part = nm.split(x, seed)
        record: dict[str, Any] = {}
        for name in ("train", "val", "test"):
            rows = np.asarray(part[f"idx_{name}"], dtype=np.int64)
            record[name] = {
                "rows": int(len(rows)),
                "anomalies": int(y[rows].sum()),
                "prevalence": float(y[rows].mean()),
                "sha256": _digest(rows),
            }
        out[str(seed)] = record
    return out


def x_partitions__mutmut_8(x: np.ndarray, y: np.ndarray, seeds: tuple[int, ...]) -> dict[str, Any]:
    """Digests, sizes and prevalences of the split of every seed."""
    out: dict[str, Any] = {}
    for seed in seeds:
        part = nm.split(x, y, )
        record: dict[str, Any] = {}
        for name in ("train", "val", "test"):
            rows = np.asarray(part[f"idx_{name}"], dtype=np.int64)
            record[name] = {
                "rows": int(len(rows)),
                "anomalies": int(y[rows].sum()),
                "prevalence": float(y[rows].mean()),
                "sha256": _digest(rows),
            }
        out[str(seed)] = record
    return out


def x_partitions__mutmut_9(x: np.ndarray, y: np.ndarray, seeds: tuple[int, ...]) -> dict[str, Any]:
    """Digests, sizes and prevalences of the split of every seed."""
    out: dict[str, Any] = {}
    for seed in seeds:
        part = nm.split(x, y, seed)
        record: dict[str, Any] = None
        for name in ("train", "val", "test"):
            rows = np.asarray(part[f"idx_{name}"], dtype=np.int64)
            record[name] = {
                "rows": int(len(rows)),
                "anomalies": int(y[rows].sum()),
                "prevalence": float(y[rows].mean()),
                "sha256": _digest(rows),
            }
        out[str(seed)] = record
    return out


def x_partitions__mutmut_10(x: np.ndarray, y: np.ndarray, seeds: tuple[int, ...]) -> dict[str, Any]:
    """Digests, sizes and prevalences of the split of every seed."""
    out: dict[str, Any] = {}
    for seed in seeds:
        part = nm.split(x, y, seed)
        record: dict[str, Any] = {}
        for name in ("XXtrainXX", "val", "test"):
            rows = np.asarray(part[f"idx_{name}"], dtype=np.int64)
            record[name] = {
                "rows": int(len(rows)),
                "anomalies": int(y[rows].sum()),
                "prevalence": float(y[rows].mean()),
                "sha256": _digest(rows),
            }
        out[str(seed)] = record
    return out


def x_partitions__mutmut_11(x: np.ndarray, y: np.ndarray, seeds: tuple[int, ...]) -> dict[str, Any]:
    """Digests, sizes and prevalences of the split of every seed."""
    out: dict[str, Any] = {}
    for seed in seeds:
        part = nm.split(x, y, seed)
        record: dict[str, Any] = {}
        for name in ("TRAIN", "val", "test"):
            rows = np.asarray(part[f"idx_{name}"], dtype=np.int64)
            record[name] = {
                "rows": int(len(rows)),
                "anomalies": int(y[rows].sum()),
                "prevalence": float(y[rows].mean()),
                "sha256": _digest(rows),
            }
        out[str(seed)] = record
    return out


def x_partitions__mutmut_12(x: np.ndarray, y: np.ndarray, seeds: tuple[int, ...]) -> dict[str, Any]:
    """Digests, sizes and prevalences of the split of every seed."""
    out: dict[str, Any] = {}
    for seed in seeds:
        part = nm.split(x, y, seed)
        record: dict[str, Any] = {}
        for name in ("train", "XXvalXX", "test"):
            rows = np.asarray(part[f"idx_{name}"], dtype=np.int64)
            record[name] = {
                "rows": int(len(rows)),
                "anomalies": int(y[rows].sum()),
                "prevalence": float(y[rows].mean()),
                "sha256": _digest(rows),
            }
        out[str(seed)] = record
    return out


def x_partitions__mutmut_13(x: np.ndarray, y: np.ndarray, seeds: tuple[int, ...]) -> dict[str, Any]:
    """Digests, sizes and prevalences of the split of every seed."""
    out: dict[str, Any] = {}
    for seed in seeds:
        part = nm.split(x, y, seed)
        record: dict[str, Any] = {}
        for name in ("train", "VAL", "test"):
            rows = np.asarray(part[f"idx_{name}"], dtype=np.int64)
            record[name] = {
                "rows": int(len(rows)),
                "anomalies": int(y[rows].sum()),
                "prevalence": float(y[rows].mean()),
                "sha256": _digest(rows),
            }
        out[str(seed)] = record
    return out


def x_partitions__mutmut_14(x: np.ndarray, y: np.ndarray, seeds: tuple[int, ...]) -> dict[str, Any]:
    """Digests, sizes and prevalences of the split of every seed."""
    out: dict[str, Any] = {}
    for seed in seeds:
        part = nm.split(x, y, seed)
        record: dict[str, Any] = {}
        for name in ("train", "val", "XXtestXX"):
            rows = np.asarray(part[f"idx_{name}"], dtype=np.int64)
            record[name] = {
                "rows": int(len(rows)),
                "anomalies": int(y[rows].sum()),
                "prevalence": float(y[rows].mean()),
                "sha256": _digest(rows),
            }
        out[str(seed)] = record
    return out


def x_partitions__mutmut_15(x: np.ndarray, y: np.ndarray, seeds: tuple[int, ...]) -> dict[str, Any]:
    """Digests, sizes and prevalences of the split of every seed."""
    out: dict[str, Any] = {}
    for seed in seeds:
        part = nm.split(x, y, seed)
        record: dict[str, Any] = {}
        for name in ("train", "val", "TEST"):
            rows = np.asarray(part[f"idx_{name}"], dtype=np.int64)
            record[name] = {
                "rows": int(len(rows)),
                "anomalies": int(y[rows].sum()),
                "prevalence": float(y[rows].mean()),
                "sha256": _digest(rows),
            }
        out[str(seed)] = record
    return out


def x_partitions__mutmut_16(x: np.ndarray, y: np.ndarray, seeds: tuple[int, ...]) -> dict[str, Any]:
    """Digests, sizes and prevalences of the split of every seed."""
    out: dict[str, Any] = {}
    for seed in seeds:
        part = nm.split(x, y, seed)
        record: dict[str, Any] = {}
        for name in ("train", "val", "test"):
            rows = None
            record[name] = {
                "rows": int(len(rows)),
                "anomalies": int(y[rows].sum()),
                "prevalence": float(y[rows].mean()),
                "sha256": _digest(rows),
            }
        out[str(seed)] = record
    return out


def x_partitions__mutmut_17(x: np.ndarray, y: np.ndarray, seeds: tuple[int, ...]) -> dict[str, Any]:
    """Digests, sizes and prevalences of the split of every seed."""
    out: dict[str, Any] = {}
    for seed in seeds:
        part = nm.split(x, y, seed)
        record: dict[str, Any] = {}
        for name in ("train", "val", "test"):
            rows = np.asarray(None, dtype=np.int64)
            record[name] = {
                "rows": int(len(rows)),
                "anomalies": int(y[rows].sum()),
                "prevalence": float(y[rows].mean()),
                "sha256": _digest(rows),
            }
        out[str(seed)] = record
    return out


def x_partitions__mutmut_18(x: np.ndarray, y: np.ndarray, seeds: tuple[int, ...]) -> dict[str, Any]:
    """Digests, sizes and prevalences of the split of every seed."""
    out: dict[str, Any] = {}
    for seed in seeds:
        part = nm.split(x, y, seed)
        record: dict[str, Any] = {}
        for name in ("train", "val", "test"):
            rows = np.asarray(part[f"idx_{name}"], dtype=None)
            record[name] = {
                "rows": int(len(rows)),
                "anomalies": int(y[rows].sum()),
                "prevalence": float(y[rows].mean()),
                "sha256": _digest(rows),
            }
        out[str(seed)] = record
    return out


def x_partitions__mutmut_19(x: np.ndarray, y: np.ndarray, seeds: tuple[int, ...]) -> dict[str, Any]:
    """Digests, sizes and prevalences of the split of every seed."""
    out: dict[str, Any] = {}
    for seed in seeds:
        part = nm.split(x, y, seed)
        record: dict[str, Any] = {}
        for name in ("train", "val", "test"):
            rows = np.asarray(dtype=np.int64)
            record[name] = {
                "rows": int(len(rows)),
                "anomalies": int(y[rows].sum()),
                "prevalence": float(y[rows].mean()),
                "sha256": _digest(rows),
            }
        out[str(seed)] = record
    return out


def x_partitions__mutmut_20(x: np.ndarray, y: np.ndarray, seeds: tuple[int, ...]) -> dict[str, Any]:
    """Digests, sizes and prevalences of the split of every seed."""
    out: dict[str, Any] = {}
    for seed in seeds:
        part = nm.split(x, y, seed)
        record: dict[str, Any] = {}
        for name in ("train", "val", "test"):
            rows = np.asarray(part[f"idx_{name}"], )
            record[name] = {
                "rows": int(len(rows)),
                "anomalies": int(y[rows].sum()),
                "prevalence": float(y[rows].mean()),
                "sha256": _digest(rows),
            }
        out[str(seed)] = record
    return out


def x_partitions__mutmut_21(x: np.ndarray, y: np.ndarray, seeds: tuple[int, ...]) -> dict[str, Any]:
    """Digests, sizes and prevalences of the split of every seed."""
    out: dict[str, Any] = {}
    for seed in seeds:
        part = nm.split(x, y, seed)
        record: dict[str, Any] = {}
        for name in ("train", "val", "test"):
            rows = np.asarray(part[f"idx_{name}"], dtype=np.int64)
            record[name] = None
        out[str(seed)] = record
    return out


def x_partitions__mutmut_22(x: np.ndarray, y: np.ndarray, seeds: tuple[int, ...]) -> dict[str, Any]:
    """Digests, sizes and prevalences of the split of every seed."""
    out: dict[str, Any] = {}
    for seed in seeds:
        part = nm.split(x, y, seed)
        record: dict[str, Any] = {}
        for name in ("train", "val", "test"):
            rows = np.asarray(part[f"idx_{name}"], dtype=np.int64)
            record[name] = {
                "XXrowsXX": int(len(rows)),
                "anomalies": int(y[rows].sum()),
                "prevalence": float(y[rows].mean()),
                "sha256": _digest(rows),
            }
        out[str(seed)] = record
    return out


def x_partitions__mutmut_23(x: np.ndarray, y: np.ndarray, seeds: tuple[int, ...]) -> dict[str, Any]:
    """Digests, sizes and prevalences of the split of every seed."""
    out: dict[str, Any] = {}
    for seed in seeds:
        part = nm.split(x, y, seed)
        record: dict[str, Any] = {}
        for name in ("train", "val", "test"):
            rows = np.asarray(part[f"idx_{name}"], dtype=np.int64)
            record[name] = {
                "ROWS": int(len(rows)),
                "anomalies": int(y[rows].sum()),
                "prevalence": float(y[rows].mean()),
                "sha256": _digest(rows),
            }
        out[str(seed)] = record
    return out


def x_partitions__mutmut_24(x: np.ndarray, y: np.ndarray, seeds: tuple[int, ...]) -> dict[str, Any]:
    """Digests, sizes and prevalences of the split of every seed."""
    out: dict[str, Any] = {}
    for seed in seeds:
        part = nm.split(x, y, seed)
        record: dict[str, Any] = {}
        for name in ("train", "val", "test"):
            rows = np.asarray(part[f"idx_{name}"], dtype=np.int64)
            record[name] = {
                "rows": int(None),
                "anomalies": int(y[rows].sum()),
                "prevalence": float(y[rows].mean()),
                "sha256": _digest(rows),
            }
        out[str(seed)] = record
    return out


def x_partitions__mutmut_25(x: np.ndarray, y: np.ndarray, seeds: tuple[int, ...]) -> dict[str, Any]:
    """Digests, sizes and prevalences of the split of every seed."""
    out: dict[str, Any] = {}
    for seed in seeds:
        part = nm.split(x, y, seed)
        record: dict[str, Any] = {}
        for name in ("train", "val", "test"):
            rows = np.asarray(part[f"idx_{name}"], dtype=np.int64)
            record[name] = {
                "rows": int(len(rows)),
                "XXanomaliesXX": int(y[rows].sum()),
                "prevalence": float(y[rows].mean()),
                "sha256": _digest(rows),
            }
        out[str(seed)] = record
    return out


def x_partitions__mutmut_26(x: np.ndarray, y: np.ndarray, seeds: tuple[int, ...]) -> dict[str, Any]:
    """Digests, sizes and prevalences of the split of every seed."""
    out: dict[str, Any] = {}
    for seed in seeds:
        part = nm.split(x, y, seed)
        record: dict[str, Any] = {}
        for name in ("train", "val", "test"):
            rows = np.asarray(part[f"idx_{name}"], dtype=np.int64)
            record[name] = {
                "rows": int(len(rows)),
                "ANOMALIES": int(y[rows].sum()),
                "prevalence": float(y[rows].mean()),
                "sha256": _digest(rows),
            }
        out[str(seed)] = record
    return out


def x_partitions__mutmut_27(x: np.ndarray, y: np.ndarray, seeds: tuple[int, ...]) -> dict[str, Any]:
    """Digests, sizes and prevalences of the split of every seed."""
    out: dict[str, Any] = {}
    for seed in seeds:
        part = nm.split(x, y, seed)
        record: dict[str, Any] = {}
        for name in ("train", "val", "test"):
            rows = np.asarray(part[f"idx_{name}"], dtype=np.int64)
            record[name] = {
                "rows": int(len(rows)),
                "anomalies": int(None),
                "prevalence": float(y[rows].mean()),
                "sha256": _digest(rows),
            }
        out[str(seed)] = record
    return out


def x_partitions__mutmut_28(x: np.ndarray, y: np.ndarray, seeds: tuple[int, ...]) -> dict[str, Any]:
    """Digests, sizes and prevalences of the split of every seed."""
    out: dict[str, Any] = {}
    for seed in seeds:
        part = nm.split(x, y, seed)
        record: dict[str, Any] = {}
        for name in ("train", "val", "test"):
            rows = np.asarray(part[f"idx_{name}"], dtype=np.int64)
            record[name] = {
                "rows": int(len(rows)),
                "anomalies": int(y[rows].sum()),
                "XXprevalenceXX": float(y[rows].mean()),
                "sha256": _digest(rows),
            }
        out[str(seed)] = record
    return out


def x_partitions__mutmut_29(x: np.ndarray, y: np.ndarray, seeds: tuple[int, ...]) -> dict[str, Any]:
    """Digests, sizes and prevalences of the split of every seed."""
    out: dict[str, Any] = {}
    for seed in seeds:
        part = nm.split(x, y, seed)
        record: dict[str, Any] = {}
        for name in ("train", "val", "test"):
            rows = np.asarray(part[f"idx_{name}"], dtype=np.int64)
            record[name] = {
                "rows": int(len(rows)),
                "anomalies": int(y[rows].sum()),
                "PREVALENCE": float(y[rows].mean()),
                "sha256": _digest(rows),
            }
        out[str(seed)] = record
    return out


def x_partitions__mutmut_30(x: np.ndarray, y: np.ndarray, seeds: tuple[int, ...]) -> dict[str, Any]:
    """Digests, sizes and prevalences of the split of every seed."""
    out: dict[str, Any] = {}
    for seed in seeds:
        part = nm.split(x, y, seed)
        record: dict[str, Any] = {}
        for name in ("train", "val", "test"):
            rows = np.asarray(part[f"idx_{name}"], dtype=np.int64)
            record[name] = {
                "rows": int(len(rows)),
                "anomalies": int(y[rows].sum()),
                "prevalence": float(None),
                "sha256": _digest(rows),
            }
        out[str(seed)] = record
    return out


def x_partitions__mutmut_31(x: np.ndarray, y: np.ndarray, seeds: tuple[int, ...]) -> dict[str, Any]:
    """Digests, sizes and prevalences of the split of every seed."""
    out: dict[str, Any] = {}
    for seed in seeds:
        part = nm.split(x, y, seed)
        record: dict[str, Any] = {}
        for name in ("train", "val", "test"):
            rows = np.asarray(part[f"idx_{name}"], dtype=np.int64)
            record[name] = {
                "rows": int(len(rows)),
                "anomalies": int(y[rows].sum()),
                "prevalence": float(y[rows].mean()),
                "XXsha256XX": _digest(rows),
            }
        out[str(seed)] = record
    return out


def x_partitions__mutmut_32(x: np.ndarray, y: np.ndarray, seeds: tuple[int, ...]) -> dict[str, Any]:
    """Digests, sizes and prevalences of the split of every seed."""
    out: dict[str, Any] = {}
    for seed in seeds:
        part = nm.split(x, y, seed)
        record: dict[str, Any] = {}
        for name in ("train", "val", "test"):
            rows = np.asarray(part[f"idx_{name}"], dtype=np.int64)
            record[name] = {
                "rows": int(len(rows)),
                "anomalies": int(y[rows].sum()),
                "prevalence": float(y[rows].mean()),
                "SHA256": _digest(rows),
            }
        out[str(seed)] = record
    return out


def x_partitions__mutmut_33(x: np.ndarray, y: np.ndarray, seeds: tuple[int, ...]) -> dict[str, Any]:
    """Digests, sizes and prevalences of the split of every seed."""
    out: dict[str, Any] = {}
    for seed in seeds:
        part = nm.split(x, y, seed)
        record: dict[str, Any] = {}
        for name in ("train", "val", "test"):
            rows = np.asarray(part[f"idx_{name}"], dtype=np.int64)
            record[name] = {
                "rows": int(len(rows)),
                "anomalies": int(y[rows].sum()),
                "prevalence": float(y[rows].mean()),
                "sha256": _digest(None),
            }
        out[str(seed)] = record
    return out


def x_partitions__mutmut_34(x: np.ndarray, y: np.ndarray, seeds: tuple[int, ...]) -> dict[str, Any]:
    """Digests, sizes and prevalences of the split of every seed."""
    out: dict[str, Any] = {}
    for seed in seeds:
        part = nm.split(x, y, seed)
        record: dict[str, Any] = {}
        for name in ("train", "val", "test"):
            rows = np.asarray(part[f"idx_{name}"], dtype=np.int64)
            record[name] = {
                "rows": int(len(rows)),
                "anomalies": int(y[rows].sum()),
                "prevalence": float(y[rows].mean()),
                "sha256": _digest(rows),
            }
        out[str(seed)] = None
    return out


def x_partitions__mutmut_35(x: np.ndarray, y: np.ndarray, seeds: tuple[int, ...]) -> dict[str, Any]:
    """Digests, sizes and prevalences of the split of every seed."""
    out: dict[str, Any] = {}
    for seed in seeds:
        part = nm.split(x, y, seed)
        record: dict[str, Any] = {}
        for name in ("train", "val", "test"):
            rows = np.asarray(part[f"idx_{name}"], dtype=np.int64)
            record[name] = {
                "rows": int(len(rows)),
                "anomalies": int(y[rows].sum()),
                "prevalence": float(y[rows].mean()),
                "sha256": _digest(rows),
            }
        out[str(None)] = record
    return out

mutants_x_partitions__mutmut['_mutmut_orig'] = x_partitions__mutmut_orig # type: ignore # mutmut generated
mutants_x_partitions__mutmut['x_partitions__mutmut_1'] = x_partitions__mutmut_1 # type: ignore # mutmut generated
mutants_x_partitions__mutmut['x_partitions__mutmut_2'] = x_partitions__mutmut_2 # type: ignore # mutmut generated
mutants_x_partitions__mutmut['x_partitions__mutmut_3'] = x_partitions__mutmut_3 # type: ignore # mutmut generated
mutants_x_partitions__mutmut['x_partitions__mutmut_4'] = x_partitions__mutmut_4 # type: ignore # mutmut generated
mutants_x_partitions__mutmut['x_partitions__mutmut_5'] = x_partitions__mutmut_5 # type: ignore # mutmut generated
mutants_x_partitions__mutmut['x_partitions__mutmut_6'] = x_partitions__mutmut_6 # type: ignore # mutmut generated
mutants_x_partitions__mutmut['x_partitions__mutmut_7'] = x_partitions__mutmut_7 # type: ignore # mutmut generated
mutants_x_partitions__mutmut['x_partitions__mutmut_8'] = x_partitions__mutmut_8 # type: ignore # mutmut generated
mutants_x_partitions__mutmut['x_partitions__mutmut_9'] = x_partitions__mutmut_9 # type: ignore # mutmut generated
mutants_x_partitions__mutmut['x_partitions__mutmut_10'] = x_partitions__mutmut_10 # type: ignore # mutmut generated
mutants_x_partitions__mutmut['x_partitions__mutmut_11'] = x_partitions__mutmut_11 # type: ignore # mutmut generated
mutants_x_partitions__mutmut['x_partitions__mutmut_12'] = x_partitions__mutmut_12 # type: ignore # mutmut generated
mutants_x_partitions__mutmut['x_partitions__mutmut_13'] = x_partitions__mutmut_13 # type: ignore # mutmut generated
mutants_x_partitions__mutmut['x_partitions__mutmut_14'] = x_partitions__mutmut_14 # type: ignore # mutmut generated
mutants_x_partitions__mutmut['x_partitions__mutmut_15'] = x_partitions__mutmut_15 # type: ignore # mutmut generated
mutants_x_partitions__mutmut['x_partitions__mutmut_16'] = x_partitions__mutmut_16 # type: ignore # mutmut generated
mutants_x_partitions__mutmut['x_partitions__mutmut_17'] = x_partitions__mutmut_17 # type: ignore # mutmut generated
mutants_x_partitions__mutmut['x_partitions__mutmut_18'] = x_partitions__mutmut_18 # type: ignore # mutmut generated
mutants_x_partitions__mutmut['x_partitions__mutmut_19'] = x_partitions__mutmut_19 # type: ignore # mutmut generated
mutants_x_partitions__mutmut['x_partitions__mutmut_20'] = x_partitions__mutmut_20 # type: ignore # mutmut generated
mutants_x_partitions__mutmut['x_partitions__mutmut_21'] = x_partitions__mutmut_21 # type: ignore # mutmut generated
mutants_x_partitions__mutmut['x_partitions__mutmut_22'] = x_partitions__mutmut_22 # type: ignore # mutmut generated
mutants_x_partitions__mutmut['x_partitions__mutmut_23'] = x_partitions__mutmut_23 # type: ignore # mutmut generated
mutants_x_partitions__mutmut['x_partitions__mutmut_24'] = x_partitions__mutmut_24 # type: ignore # mutmut generated
mutants_x_partitions__mutmut['x_partitions__mutmut_25'] = x_partitions__mutmut_25 # type: ignore # mutmut generated
mutants_x_partitions__mutmut['x_partitions__mutmut_26'] = x_partitions__mutmut_26 # type: ignore # mutmut generated
mutants_x_partitions__mutmut['x_partitions__mutmut_27'] = x_partitions__mutmut_27 # type: ignore # mutmut generated
mutants_x_partitions__mutmut['x_partitions__mutmut_28'] = x_partitions__mutmut_28 # type: ignore # mutmut generated
mutants_x_partitions__mutmut['x_partitions__mutmut_29'] = x_partitions__mutmut_29 # type: ignore # mutmut generated
mutants_x_partitions__mutmut['x_partitions__mutmut_30'] = x_partitions__mutmut_30 # type: ignore # mutmut generated
mutants_x_partitions__mutmut['x_partitions__mutmut_31'] = x_partitions__mutmut_31 # type: ignore # mutmut generated
mutants_x_partitions__mutmut['x_partitions__mutmut_32'] = x_partitions__mutmut_32 # type: ignore # mutmut generated
mutants_x_partitions__mutmut['x_partitions__mutmut_33'] = x_partitions__mutmut_33 # type: ignore # mutmut generated
mutants_x_partitions__mutmut['x_partitions__mutmut_34'] = x_partitions__mutmut_34 # type: ignore # mutmut generated
mutants_x_partitions__mutmut['x_partitions__mutmut_35'] = x_partitions__mutmut_35 # type: ignore # mutmut generated
mutants_x__same__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x__same__mutmut)
def _same(archived: dict[str, float], replayed: dict[str, float]) -> bool:
    return set(archived) == set(replayed) and all(
        abs(archived[key] - replayed[key]) <= TOLERANCE for key in archived
    )


def x__same__mutmut_orig(archived: dict[str, float], replayed: dict[str, float]) -> bool:
    return set(archived) == set(replayed) and all(
        abs(archived[key] - replayed[key]) <= TOLERANCE for key in archived
    )


def x__same__mutmut_1(archived: dict[str, float], replayed: dict[str, float]) -> bool:
    return set(archived) == set(replayed) or all(
        abs(archived[key] - replayed[key]) <= TOLERANCE for key in archived
    )


def x__same__mutmut_2(archived: dict[str, float], replayed: dict[str, float]) -> bool:
    return set(None) == set(replayed) and all(
        abs(archived[key] - replayed[key]) <= TOLERANCE for key in archived
    )


def x__same__mutmut_3(archived: dict[str, float], replayed: dict[str, float]) -> bool:
    return set(archived) != set(replayed) and all(
        abs(archived[key] - replayed[key]) <= TOLERANCE for key in archived
    )


def x__same__mutmut_4(archived: dict[str, float], replayed: dict[str, float]) -> bool:
    return set(archived) == set(None) and all(
        abs(archived[key] - replayed[key]) <= TOLERANCE for key in archived
    )


def x__same__mutmut_5(archived: dict[str, float], replayed: dict[str, float]) -> bool:
    return set(archived) == set(replayed) and all(
        None
    )


def x__same__mutmut_6(archived: dict[str, float], replayed: dict[str, float]) -> bool:
    return set(archived) == set(replayed) and all(
        abs(None) <= TOLERANCE for key in archived
    )


def x__same__mutmut_7(archived: dict[str, float], replayed: dict[str, float]) -> bool:
    return set(archived) == set(replayed) and all(
        abs(archived[key] + replayed[key]) <= TOLERANCE for key in archived
    )


def x__same__mutmut_8(archived: dict[str, float], replayed: dict[str, float]) -> bool:
    return set(archived) == set(replayed) and all(
        abs(archived[key] - replayed[key]) < TOLERANCE for key in archived
    )

mutants_x__same__mutmut['_mutmut_orig'] = x__same__mutmut_orig # type: ignore # mutmut generated
mutants_x__same__mutmut['x__same__mutmut_1'] = x__same__mutmut_1 # type: ignore # mutmut generated
mutants_x__same__mutmut['x__same__mutmut_2'] = x__same__mutmut_2 # type: ignore # mutmut generated
mutants_x__same__mutmut['x__same__mutmut_3'] = x__same__mutmut_3 # type: ignore # mutmut generated
mutants_x__same__mutmut['x__same__mutmut_4'] = x__same__mutmut_4 # type: ignore # mutmut generated
mutants_x__same__mutmut['x__same__mutmut_5'] = x__same__mutmut_5 # type: ignore # mutmut generated
mutants_x__same__mutmut['x__same__mutmut_6'] = x__same__mutmut_6 # type: ignore # mutmut generated
mutants_x__same__mutmut['x__same__mutmut_7'] = x__same__mutmut_7 # type: ignore # mutmut generated
mutants_x__same__mutmut['x__same__mutmut_8'] = x__same__mutmut_8 # type: ignore # mutmut generated
mutants_x_replay_matches__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_replay_matches__mutmut)
def replay_matches(x: np.ndarray, y: np.ndarray, archive: dict[str, Any]) -> list[bool]:
    """Whether the deterministic Z-score detector reproduces the archived metrics seed by seed."""
    seeds = tuple(archive["seeds"])
    rows = archive["metrics"].get("zscore", [])
    if len(rows) != len(seeds):
        return [False] * len(seeds)
    replay = lb.run_problem(x, y, seeds=seeds, methods=["zscore"])["metrics"]["zscore"]
    return [_same(old, new) for old, new in zip(rows, replay, strict=True)]


def x_replay_matches__mutmut_orig(x: np.ndarray, y: np.ndarray, archive: dict[str, Any]) -> list[bool]:
    """Whether the deterministic Z-score detector reproduces the archived metrics seed by seed."""
    seeds = tuple(archive["seeds"])
    rows = archive["metrics"].get("zscore", [])
    if len(rows) != len(seeds):
        return [False] * len(seeds)
    replay = lb.run_problem(x, y, seeds=seeds, methods=["zscore"])["metrics"]["zscore"]
    return [_same(old, new) for old, new in zip(rows, replay, strict=True)]


def x_replay_matches__mutmut_1(x: np.ndarray, y: np.ndarray, archive: dict[str, Any]) -> list[bool]:
    """Whether the deterministic Z-score detector reproduces the archived metrics seed by seed."""
    seeds = None
    rows = archive["metrics"].get("zscore", [])
    if len(rows) != len(seeds):
        return [False] * len(seeds)
    replay = lb.run_problem(x, y, seeds=seeds, methods=["zscore"])["metrics"]["zscore"]
    return [_same(old, new) for old, new in zip(rows, replay, strict=True)]


def x_replay_matches__mutmut_2(x: np.ndarray, y: np.ndarray, archive: dict[str, Any]) -> list[bool]:
    """Whether the deterministic Z-score detector reproduces the archived metrics seed by seed."""
    seeds = tuple(None)
    rows = archive["metrics"].get("zscore", [])
    if len(rows) != len(seeds):
        return [False] * len(seeds)
    replay = lb.run_problem(x, y, seeds=seeds, methods=["zscore"])["metrics"]["zscore"]
    return [_same(old, new) for old, new in zip(rows, replay, strict=True)]


def x_replay_matches__mutmut_3(x: np.ndarray, y: np.ndarray, archive: dict[str, Any]) -> list[bool]:
    """Whether the deterministic Z-score detector reproduces the archived metrics seed by seed."""
    seeds = tuple(archive["XXseedsXX"])
    rows = archive["metrics"].get("zscore", [])
    if len(rows) != len(seeds):
        return [False] * len(seeds)
    replay = lb.run_problem(x, y, seeds=seeds, methods=["zscore"])["metrics"]["zscore"]
    return [_same(old, new) for old, new in zip(rows, replay, strict=True)]


def x_replay_matches__mutmut_4(x: np.ndarray, y: np.ndarray, archive: dict[str, Any]) -> list[bool]:
    """Whether the deterministic Z-score detector reproduces the archived metrics seed by seed."""
    seeds = tuple(archive["SEEDS"])
    rows = archive["metrics"].get("zscore", [])
    if len(rows) != len(seeds):
        return [False] * len(seeds)
    replay = lb.run_problem(x, y, seeds=seeds, methods=["zscore"])["metrics"]["zscore"]
    return [_same(old, new) for old, new in zip(rows, replay, strict=True)]


def x_replay_matches__mutmut_5(x: np.ndarray, y: np.ndarray, archive: dict[str, Any]) -> list[bool]:
    """Whether the deterministic Z-score detector reproduces the archived metrics seed by seed."""
    seeds = tuple(archive["seeds"])
    rows = None
    if len(rows) != len(seeds):
        return [False] * len(seeds)
    replay = lb.run_problem(x, y, seeds=seeds, methods=["zscore"])["metrics"]["zscore"]
    return [_same(old, new) for old, new in zip(rows, replay, strict=True)]


def x_replay_matches__mutmut_6(x: np.ndarray, y: np.ndarray, archive: dict[str, Any]) -> list[bool]:
    """Whether the deterministic Z-score detector reproduces the archived metrics seed by seed."""
    seeds = tuple(archive["seeds"])
    rows = archive["metrics"].get(None, [])
    if len(rows) != len(seeds):
        return [False] * len(seeds)
    replay = lb.run_problem(x, y, seeds=seeds, methods=["zscore"])["metrics"]["zscore"]
    return [_same(old, new) for old, new in zip(rows, replay, strict=True)]


def x_replay_matches__mutmut_7(x: np.ndarray, y: np.ndarray, archive: dict[str, Any]) -> list[bool]:
    """Whether the deterministic Z-score detector reproduces the archived metrics seed by seed."""
    seeds = tuple(archive["seeds"])
    rows = archive["metrics"].get("zscore", None)
    if len(rows) != len(seeds):
        return [False] * len(seeds)
    replay = lb.run_problem(x, y, seeds=seeds, methods=["zscore"])["metrics"]["zscore"]
    return [_same(old, new) for old, new in zip(rows, replay, strict=True)]


def x_replay_matches__mutmut_8(x: np.ndarray, y: np.ndarray, archive: dict[str, Any]) -> list[bool]:
    """Whether the deterministic Z-score detector reproduces the archived metrics seed by seed."""
    seeds = tuple(archive["seeds"])
    rows = archive["metrics"].get([])
    if len(rows) != len(seeds):
        return [False] * len(seeds)
    replay = lb.run_problem(x, y, seeds=seeds, methods=["zscore"])["metrics"]["zscore"]
    return [_same(old, new) for old, new in zip(rows, replay, strict=True)]


def x_replay_matches__mutmut_9(x: np.ndarray, y: np.ndarray, archive: dict[str, Any]) -> list[bool]:
    """Whether the deterministic Z-score detector reproduces the archived metrics seed by seed."""
    seeds = tuple(archive["seeds"])
    rows = archive["metrics"].get("zscore", )
    if len(rows) != len(seeds):
        return [False] * len(seeds)
    replay = lb.run_problem(x, y, seeds=seeds, methods=["zscore"])["metrics"]["zscore"]
    return [_same(old, new) for old, new in zip(rows, replay, strict=True)]


def x_replay_matches__mutmut_10(x: np.ndarray, y: np.ndarray, archive: dict[str, Any]) -> list[bool]:
    """Whether the deterministic Z-score detector reproduces the archived metrics seed by seed."""
    seeds = tuple(archive["seeds"])
    rows = archive["XXmetricsXX"].get("zscore", [])
    if len(rows) != len(seeds):
        return [False] * len(seeds)
    replay = lb.run_problem(x, y, seeds=seeds, methods=["zscore"])["metrics"]["zscore"]
    return [_same(old, new) for old, new in zip(rows, replay, strict=True)]


def x_replay_matches__mutmut_11(x: np.ndarray, y: np.ndarray, archive: dict[str, Any]) -> list[bool]:
    """Whether the deterministic Z-score detector reproduces the archived metrics seed by seed."""
    seeds = tuple(archive["seeds"])
    rows = archive["METRICS"].get("zscore", [])
    if len(rows) != len(seeds):
        return [False] * len(seeds)
    replay = lb.run_problem(x, y, seeds=seeds, methods=["zscore"])["metrics"]["zscore"]
    return [_same(old, new) for old, new in zip(rows, replay, strict=True)]


def x_replay_matches__mutmut_12(x: np.ndarray, y: np.ndarray, archive: dict[str, Any]) -> list[bool]:
    """Whether the deterministic Z-score detector reproduces the archived metrics seed by seed."""
    seeds = tuple(archive["seeds"])
    rows = archive["metrics"].get("XXzscoreXX", [])
    if len(rows) != len(seeds):
        return [False] * len(seeds)
    replay = lb.run_problem(x, y, seeds=seeds, methods=["zscore"])["metrics"]["zscore"]
    return [_same(old, new) for old, new in zip(rows, replay, strict=True)]


def x_replay_matches__mutmut_13(x: np.ndarray, y: np.ndarray, archive: dict[str, Any]) -> list[bool]:
    """Whether the deterministic Z-score detector reproduces the archived metrics seed by seed."""
    seeds = tuple(archive["seeds"])
    rows = archive["metrics"].get("ZSCORE", [])
    if len(rows) != len(seeds):
        return [False] * len(seeds)
    replay = lb.run_problem(x, y, seeds=seeds, methods=["zscore"])["metrics"]["zscore"]
    return [_same(old, new) for old, new in zip(rows, replay, strict=True)]


def x_replay_matches__mutmut_14(x: np.ndarray, y: np.ndarray, archive: dict[str, Any]) -> list[bool]:
    """Whether the deterministic Z-score detector reproduces the archived metrics seed by seed."""
    seeds = tuple(archive["seeds"])
    rows = archive["metrics"].get("zscore", [])
    if len(rows) == len(seeds):
        return [False] * len(seeds)
    replay = lb.run_problem(x, y, seeds=seeds, methods=["zscore"])["metrics"]["zscore"]
    return [_same(old, new) for old, new in zip(rows, replay, strict=True)]


def x_replay_matches__mutmut_15(x: np.ndarray, y: np.ndarray, archive: dict[str, Any]) -> list[bool]:
    """Whether the deterministic Z-score detector reproduces the archived metrics seed by seed."""
    seeds = tuple(archive["seeds"])
    rows = archive["metrics"].get("zscore", [])
    if len(rows) != len(seeds):
        return [False] / len(seeds)
    replay = lb.run_problem(x, y, seeds=seeds, methods=["zscore"])["metrics"]["zscore"]
    return [_same(old, new) for old, new in zip(rows, replay, strict=True)]


def x_replay_matches__mutmut_16(x: np.ndarray, y: np.ndarray, archive: dict[str, Any]) -> list[bool]:
    """Whether the deterministic Z-score detector reproduces the archived metrics seed by seed."""
    seeds = tuple(archive["seeds"])
    rows = archive["metrics"].get("zscore", [])
    if len(rows) != len(seeds):
        return [True] * len(seeds)
    replay = lb.run_problem(x, y, seeds=seeds, methods=["zscore"])["metrics"]["zscore"]
    return [_same(old, new) for old, new in zip(rows, replay, strict=True)]


def x_replay_matches__mutmut_17(x: np.ndarray, y: np.ndarray, archive: dict[str, Any]) -> list[bool]:
    """Whether the deterministic Z-score detector reproduces the archived metrics seed by seed."""
    seeds = tuple(archive["seeds"])
    rows = archive["metrics"].get("zscore", [])
    if len(rows) != len(seeds):
        return [False] * len(seeds)
    replay = None
    return [_same(old, new) for old, new in zip(rows, replay, strict=True)]


def x_replay_matches__mutmut_18(x: np.ndarray, y: np.ndarray, archive: dict[str, Any]) -> list[bool]:
    """Whether the deterministic Z-score detector reproduces the archived metrics seed by seed."""
    seeds = tuple(archive["seeds"])
    rows = archive["metrics"].get("zscore", [])
    if len(rows) != len(seeds):
        return [False] * len(seeds)
    replay = lb.run_problem(None, y, seeds=seeds, methods=["zscore"])["metrics"]["zscore"]
    return [_same(old, new) for old, new in zip(rows, replay, strict=True)]


def x_replay_matches__mutmut_19(x: np.ndarray, y: np.ndarray, archive: dict[str, Any]) -> list[bool]:
    """Whether the deterministic Z-score detector reproduces the archived metrics seed by seed."""
    seeds = tuple(archive["seeds"])
    rows = archive["metrics"].get("zscore", [])
    if len(rows) != len(seeds):
        return [False] * len(seeds)
    replay = lb.run_problem(x, None, seeds=seeds, methods=["zscore"])["metrics"]["zscore"]
    return [_same(old, new) for old, new in zip(rows, replay, strict=True)]


def x_replay_matches__mutmut_20(x: np.ndarray, y: np.ndarray, archive: dict[str, Any]) -> list[bool]:
    """Whether the deterministic Z-score detector reproduces the archived metrics seed by seed."""
    seeds = tuple(archive["seeds"])
    rows = archive["metrics"].get("zscore", [])
    if len(rows) != len(seeds):
        return [False] * len(seeds)
    replay = lb.run_problem(x, y, seeds=None, methods=["zscore"])["metrics"]["zscore"]
    return [_same(old, new) for old, new in zip(rows, replay, strict=True)]


def x_replay_matches__mutmut_21(x: np.ndarray, y: np.ndarray, archive: dict[str, Any]) -> list[bool]:
    """Whether the deterministic Z-score detector reproduces the archived metrics seed by seed."""
    seeds = tuple(archive["seeds"])
    rows = archive["metrics"].get("zscore", [])
    if len(rows) != len(seeds):
        return [False] * len(seeds)
    replay = lb.run_problem(x, y, seeds=seeds, methods=None)["metrics"]["zscore"]
    return [_same(old, new) for old, new in zip(rows, replay, strict=True)]


def x_replay_matches__mutmut_22(x: np.ndarray, y: np.ndarray, archive: dict[str, Any]) -> list[bool]:
    """Whether the deterministic Z-score detector reproduces the archived metrics seed by seed."""
    seeds = tuple(archive["seeds"])
    rows = archive["metrics"].get("zscore", [])
    if len(rows) != len(seeds):
        return [False] * len(seeds)
    replay = lb.run_problem(y, seeds=seeds, methods=["zscore"])["metrics"]["zscore"]
    return [_same(old, new) for old, new in zip(rows, replay, strict=True)]


def x_replay_matches__mutmut_23(x: np.ndarray, y: np.ndarray, archive: dict[str, Any]) -> list[bool]:
    """Whether the deterministic Z-score detector reproduces the archived metrics seed by seed."""
    seeds = tuple(archive["seeds"])
    rows = archive["metrics"].get("zscore", [])
    if len(rows) != len(seeds):
        return [False] * len(seeds)
    replay = lb.run_problem(x, seeds=seeds, methods=["zscore"])["metrics"]["zscore"]
    return [_same(old, new) for old, new in zip(rows, replay, strict=True)]


def x_replay_matches__mutmut_24(x: np.ndarray, y: np.ndarray, archive: dict[str, Any]) -> list[bool]:
    """Whether the deterministic Z-score detector reproduces the archived metrics seed by seed."""
    seeds = tuple(archive["seeds"])
    rows = archive["metrics"].get("zscore", [])
    if len(rows) != len(seeds):
        return [False] * len(seeds)
    replay = lb.run_problem(x, y, methods=["zscore"])["metrics"]["zscore"]
    return [_same(old, new) for old, new in zip(rows, replay, strict=True)]


def x_replay_matches__mutmut_25(x: np.ndarray, y: np.ndarray, archive: dict[str, Any]) -> list[bool]:
    """Whether the deterministic Z-score detector reproduces the archived metrics seed by seed."""
    seeds = tuple(archive["seeds"])
    rows = archive["metrics"].get("zscore", [])
    if len(rows) != len(seeds):
        return [False] * len(seeds)
    replay = lb.run_problem(x, y, seeds=seeds, )["metrics"]["zscore"]
    return [_same(old, new) for old, new in zip(rows, replay, strict=True)]


def x_replay_matches__mutmut_26(x: np.ndarray, y: np.ndarray, archive: dict[str, Any]) -> list[bool]:
    """Whether the deterministic Z-score detector reproduces the archived metrics seed by seed."""
    seeds = tuple(archive["seeds"])
    rows = archive["metrics"].get("zscore", [])
    if len(rows) != len(seeds):
        return [False] * len(seeds)
    replay = lb.run_problem(x, y, seeds=seeds, methods=["XXzscoreXX"])["metrics"]["zscore"]
    return [_same(old, new) for old, new in zip(rows, replay, strict=True)]


def x_replay_matches__mutmut_27(x: np.ndarray, y: np.ndarray, archive: dict[str, Any]) -> list[bool]:
    """Whether the deterministic Z-score detector reproduces the archived metrics seed by seed."""
    seeds = tuple(archive["seeds"])
    rows = archive["metrics"].get("zscore", [])
    if len(rows) != len(seeds):
        return [False] * len(seeds)
    replay = lb.run_problem(x, y, seeds=seeds, methods=["ZSCORE"])["metrics"]["zscore"]
    return [_same(old, new) for old, new in zip(rows, replay, strict=True)]


def x_replay_matches__mutmut_28(x: np.ndarray, y: np.ndarray, archive: dict[str, Any]) -> list[bool]:
    """Whether the deterministic Z-score detector reproduces the archived metrics seed by seed."""
    seeds = tuple(archive["seeds"])
    rows = archive["metrics"].get("zscore", [])
    if len(rows) != len(seeds):
        return [False] * len(seeds)
    replay = lb.run_problem(x, y, seeds=seeds, methods=["zscore"])["XXmetricsXX"]["zscore"]
    return [_same(old, new) for old, new in zip(rows, replay, strict=True)]


def x_replay_matches__mutmut_29(x: np.ndarray, y: np.ndarray, archive: dict[str, Any]) -> list[bool]:
    """Whether the deterministic Z-score detector reproduces the archived metrics seed by seed."""
    seeds = tuple(archive["seeds"])
    rows = archive["metrics"].get("zscore", [])
    if len(rows) != len(seeds):
        return [False] * len(seeds)
    replay = lb.run_problem(x, y, seeds=seeds, methods=["zscore"])["METRICS"]["zscore"]
    return [_same(old, new) for old, new in zip(rows, replay, strict=True)]


def x_replay_matches__mutmut_30(x: np.ndarray, y: np.ndarray, archive: dict[str, Any]) -> list[bool]:
    """Whether the deterministic Z-score detector reproduces the archived metrics seed by seed."""
    seeds = tuple(archive["seeds"])
    rows = archive["metrics"].get("zscore", [])
    if len(rows) != len(seeds):
        return [False] * len(seeds)
    replay = lb.run_problem(x, y, seeds=seeds, methods=["zscore"])["metrics"]["XXzscoreXX"]
    return [_same(old, new) for old, new in zip(rows, replay, strict=True)]


def x_replay_matches__mutmut_31(x: np.ndarray, y: np.ndarray, archive: dict[str, Any]) -> list[bool]:
    """Whether the deterministic Z-score detector reproduces the archived metrics seed by seed."""
    seeds = tuple(archive["seeds"])
    rows = archive["metrics"].get("zscore", [])
    if len(rows) != len(seeds):
        return [False] * len(seeds)
    replay = lb.run_problem(x, y, seeds=seeds, methods=["zscore"])["metrics"]["ZSCORE"]
    return [_same(old, new) for old, new in zip(rows, replay, strict=True)]


def x_replay_matches__mutmut_32(x: np.ndarray, y: np.ndarray, archive: dict[str, Any]) -> list[bool]:
    """Whether the deterministic Z-score detector reproduces the archived metrics seed by seed."""
    seeds = tuple(archive["seeds"])
    rows = archive["metrics"].get("zscore", [])
    if len(rows) != len(seeds):
        return [False] * len(seeds)
    replay = lb.run_problem(x, y, seeds=seeds, methods=["zscore"])["metrics"]["zscore"]
    return [_same(None, new) for old, new in zip(rows, replay, strict=True)]


def x_replay_matches__mutmut_33(x: np.ndarray, y: np.ndarray, archive: dict[str, Any]) -> list[bool]:
    """Whether the deterministic Z-score detector reproduces the archived metrics seed by seed."""
    seeds = tuple(archive["seeds"])
    rows = archive["metrics"].get("zscore", [])
    if len(rows) != len(seeds):
        return [False] * len(seeds)
    replay = lb.run_problem(x, y, seeds=seeds, methods=["zscore"])["metrics"]["zscore"]
    return [_same(old, None) for old, new in zip(rows, replay, strict=True)]


def x_replay_matches__mutmut_34(x: np.ndarray, y: np.ndarray, archive: dict[str, Any]) -> list[bool]:
    """Whether the deterministic Z-score detector reproduces the archived metrics seed by seed."""
    seeds = tuple(archive["seeds"])
    rows = archive["metrics"].get("zscore", [])
    if len(rows) != len(seeds):
        return [False] * len(seeds)
    replay = lb.run_problem(x, y, seeds=seeds, methods=["zscore"])["metrics"]["zscore"]
    return [_same(new) for old, new in zip(rows, replay, strict=True)]


def x_replay_matches__mutmut_35(x: np.ndarray, y: np.ndarray, archive: dict[str, Any]) -> list[bool]:
    """Whether the deterministic Z-score detector reproduces the archived metrics seed by seed."""
    seeds = tuple(archive["seeds"])
    rows = archive["metrics"].get("zscore", [])
    if len(rows) != len(seeds):
        return [False] * len(seeds)
    replay = lb.run_problem(x, y, seeds=seeds, methods=["zscore"])["metrics"]["zscore"]
    return [_same(old, ) for old, new in zip(rows, replay, strict=True)]


def x_replay_matches__mutmut_36(x: np.ndarray, y: np.ndarray, archive: dict[str, Any]) -> list[bool]:
    """Whether the deterministic Z-score detector reproduces the archived metrics seed by seed."""
    seeds = tuple(archive["seeds"])
    rows = archive["metrics"].get("zscore", [])
    if len(rows) != len(seeds):
        return [False] * len(seeds)
    replay = lb.run_problem(x, y, seeds=seeds, methods=["zscore"])["metrics"]["zscore"]
    return [_same(old, new) for old, new in zip(None, replay, strict=True)]


def x_replay_matches__mutmut_37(x: np.ndarray, y: np.ndarray, archive: dict[str, Any]) -> list[bool]:
    """Whether the deterministic Z-score detector reproduces the archived metrics seed by seed."""
    seeds = tuple(archive["seeds"])
    rows = archive["metrics"].get("zscore", [])
    if len(rows) != len(seeds):
        return [False] * len(seeds)
    replay = lb.run_problem(x, y, seeds=seeds, methods=["zscore"])["metrics"]["zscore"]
    return [_same(old, new) for old, new in zip(rows, None, strict=True)]


def x_replay_matches__mutmut_38(x: np.ndarray, y: np.ndarray, archive: dict[str, Any]) -> list[bool]:
    """Whether the deterministic Z-score detector reproduces the archived metrics seed by seed."""
    seeds = tuple(archive["seeds"])
    rows = archive["metrics"].get("zscore", [])
    if len(rows) != len(seeds):
        return [False] * len(seeds)
    replay = lb.run_problem(x, y, seeds=seeds, methods=["zscore"])["metrics"]["zscore"]
    return [_same(old, new) for old, new in zip(rows, replay, strict=None)]


def x_replay_matches__mutmut_39(x: np.ndarray, y: np.ndarray, archive: dict[str, Any]) -> list[bool]:
    """Whether the deterministic Z-score detector reproduces the archived metrics seed by seed."""
    seeds = tuple(archive["seeds"])
    rows = archive["metrics"].get("zscore", [])
    if len(rows) != len(seeds):
        return [False] * len(seeds)
    replay = lb.run_problem(x, y, seeds=seeds, methods=["zscore"])["metrics"]["zscore"]
    return [_same(old, new) for old, new in zip(replay, strict=True)]


def x_replay_matches__mutmut_40(x: np.ndarray, y: np.ndarray, archive: dict[str, Any]) -> list[bool]:
    """Whether the deterministic Z-score detector reproduces the archived metrics seed by seed."""
    seeds = tuple(archive["seeds"])
    rows = archive["metrics"].get("zscore", [])
    if len(rows) != len(seeds):
        return [False] * len(seeds)
    replay = lb.run_problem(x, y, seeds=seeds, methods=["zscore"])["metrics"]["zscore"]
    return [_same(old, new) for old, new in zip(rows, strict=True)]


def x_replay_matches__mutmut_41(x: np.ndarray, y: np.ndarray, archive: dict[str, Any]) -> list[bool]:
    """Whether the deterministic Z-score detector reproduces the archived metrics seed by seed."""
    seeds = tuple(archive["seeds"])
    rows = archive["metrics"].get("zscore", [])
    if len(rows) != len(seeds):
        return [False] * len(seeds)
    replay = lb.run_problem(x, y, seeds=seeds, methods=["zscore"])["metrics"]["zscore"]
    return [_same(old, new) for old, new in zip(rows, replay, )]


def x_replay_matches__mutmut_42(x: np.ndarray, y: np.ndarray, archive: dict[str, Any]) -> list[bool]:
    """Whether the deterministic Z-score detector reproduces the archived metrics seed by seed."""
    seeds = tuple(archive["seeds"])
    rows = archive["metrics"].get("zscore", [])
    if len(rows) != len(seeds):
        return [False] * len(seeds)
    replay = lb.run_problem(x, y, seeds=seeds, methods=["zscore"])["metrics"]["zscore"]
    return [_same(old, new) for old, new in zip(rows, replay, strict=False)]

mutants_x_replay_matches__mutmut['_mutmut_orig'] = x_replay_matches__mutmut_orig # type: ignore # mutmut generated
mutants_x_replay_matches__mutmut['x_replay_matches__mutmut_1'] = x_replay_matches__mutmut_1 # type: ignore # mutmut generated
mutants_x_replay_matches__mutmut['x_replay_matches__mutmut_2'] = x_replay_matches__mutmut_2 # type: ignore # mutmut generated
mutants_x_replay_matches__mutmut['x_replay_matches__mutmut_3'] = x_replay_matches__mutmut_3 # type: ignore # mutmut generated
mutants_x_replay_matches__mutmut['x_replay_matches__mutmut_4'] = x_replay_matches__mutmut_4 # type: ignore # mutmut generated
mutants_x_replay_matches__mutmut['x_replay_matches__mutmut_5'] = x_replay_matches__mutmut_5 # type: ignore # mutmut generated
mutants_x_replay_matches__mutmut['x_replay_matches__mutmut_6'] = x_replay_matches__mutmut_6 # type: ignore # mutmut generated
mutants_x_replay_matches__mutmut['x_replay_matches__mutmut_7'] = x_replay_matches__mutmut_7 # type: ignore # mutmut generated
mutants_x_replay_matches__mutmut['x_replay_matches__mutmut_8'] = x_replay_matches__mutmut_8 # type: ignore # mutmut generated
mutants_x_replay_matches__mutmut['x_replay_matches__mutmut_9'] = x_replay_matches__mutmut_9 # type: ignore # mutmut generated
mutants_x_replay_matches__mutmut['x_replay_matches__mutmut_10'] = x_replay_matches__mutmut_10 # type: ignore # mutmut generated
mutants_x_replay_matches__mutmut['x_replay_matches__mutmut_11'] = x_replay_matches__mutmut_11 # type: ignore # mutmut generated
mutants_x_replay_matches__mutmut['x_replay_matches__mutmut_12'] = x_replay_matches__mutmut_12 # type: ignore # mutmut generated
mutants_x_replay_matches__mutmut['x_replay_matches__mutmut_13'] = x_replay_matches__mutmut_13 # type: ignore # mutmut generated
mutants_x_replay_matches__mutmut['x_replay_matches__mutmut_14'] = x_replay_matches__mutmut_14 # type: ignore # mutmut generated
mutants_x_replay_matches__mutmut['x_replay_matches__mutmut_15'] = x_replay_matches__mutmut_15 # type: ignore # mutmut generated
mutants_x_replay_matches__mutmut['x_replay_matches__mutmut_16'] = x_replay_matches__mutmut_16 # type: ignore # mutmut generated
mutants_x_replay_matches__mutmut['x_replay_matches__mutmut_17'] = x_replay_matches__mutmut_17 # type: ignore # mutmut generated
mutants_x_replay_matches__mutmut['x_replay_matches__mutmut_18'] = x_replay_matches__mutmut_18 # type: ignore # mutmut generated
mutants_x_replay_matches__mutmut['x_replay_matches__mutmut_19'] = x_replay_matches__mutmut_19 # type: ignore # mutmut generated
mutants_x_replay_matches__mutmut['x_replay_matches__mutmut_20'] = x_replay_matches__mutmut_20 # type: ignore # mutmut generated
mutants_x_replay_matches__mutmut['x_replay_matches__mutmut_21'] = x_replay_matches__mutmut_21 # type: ignore # mutmut generated
mutants_x_replay_matches__mutmut['x_replay_matches__mutmut_22'] = x_replay_matches__mutmut_22 # type: ignore # mutmut generated
mutants_x_replay_matches__mutmut['x_replay_matches__mutmut_23'] = x_replay_matches__mutmut_23 # type: ignore # mutmut generated
mutants_x_replay_matches__mutmut['x_replay_matches__mutmut_24'] = x_replay_matches__mutmut_24 # type: ignore # mutmut generated
mutants_x_replay_matches__mutmut['x_replay_matches__mutmut_25'] = x_replay_matches__mutmut_25 # type: ignore # mutmut generated
mutants_x_replay_matches__mutmut['x_replay_matches__mutmut_26'] = x_replay_matches__mutmut_26 # type: ignore # mutmut generated
mutants_x_replay_matches__mutmut['x_replay_matches__mutmut_27'] = x_replay_matches__mutmut_27 # type: ignore # mutmut generated
mutants_x_replay_matches__mutmut['x_replay_matches__mutmut_28'] = x_replay_matches__mutmut_28 # type: ignore # mutmut generated
mutants_x_replay_matches__mutmut['x_replay_matches__mutmut_29'] = x_replay_matches__mutmut_29 # type: ignore # mutmut generated
mutants_x_replay_matches__mutmut['x_replay_matches__mutmut_30'] = x_replay_matches__mutmut_30 # type: ignore # mutmut generated
mutants_x_replay_matches__mutmut['x_replay_matches__mutmut_31'] = x_replay_matches__mutmut_31 # type: ignore # mutmut generated
mutants_x_replay_matches__mutmut['x_replay_matches__mutmut_32'] = x_replay_matches__mutmut_32 # type: ignore # mutmut generated
mutants_x_replay_matches__mutmut['x_replay_matches__mutmut_33'] = x_replay_matches__mutmut_33 # type: ignore # mutmut generated
mutants_x_replay_matches__mutmut['x_replay_matches__mutmut_34'] = x_replay_matches__mutmut_34 # type: ignore # mutmut generated
mutants_x_replay_matches__mutmut['x_replay_matches__mutmut_35'] = x_replay_matches__mutmut_35 # type: ignore # mutmut generated
mutants_x_replay_matches__mutmut['x_replay_matches__mutmut_36'] = x_replay_matches__mutmut_36 # type: ignore # mutmut generated
mutants_x_replay_matches__mutmut['x_replay_matches__mutmut_37'] = x_replay_matches__mutmut_37 # type: ignore # mutmut generated
mutants_x_replay_matches__mutmut['x_replay_matches__mutmut_38'] = x_replay_matches__mutmut_38 # type: ignore # mutmut generated
mutants_x_replay_matches__mutmut['x_replay_matches__mutmut_39'] = x_replay_matches__mutmut_39 # type: ignore # mutmut generated
mutants_x_replay_matches__mutmut['x_replay_matches__mutmut_40'] = x_replay_matches__mutmut_40 # type: ignore # mutmut generated
mutants_x_replay_matches__mutmut['x_replay_matches__mutmut_41'] = x_replay_matches__mutmut_41 # type: ignore # mutmut generated
mutants_x_replay_matches__mutmut['x_replay_matches__mutmut_42'] = x_replay_matches__mutmut_42 # type: ignore # mutmut generated
mutants_x_recover__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_recover__mutmut)
def recover(job: dict[str, Any], archive: dict[str, Any]) -> dict[str, Any]:
    if job["source"] == "adbench":
        x, y, report = lb.load_adbench(job["name"], Path(job["path"]))
    else:
        x, y, report = lb.load_uci(job["meta"], Path(job["path"]))
    seeds = tuple(archive["seeds"])
    matches = replay_matches(x, y, archive)
    return {
        "format": FORMAT,
        "problem": job["problem"],
        "source": job["source"],
        "recovery": "recomputed from the deterministic split; not archived at run time",
        "input_sha256": _file_digest(Path(job["path"])),
        "cleaned_rows": int(len(y)),
        "cleaned_sha256": _digest(np.ascontiguousarray(x)),
        "labels_sha256": _digest(np.asarray(y, dtype=np.int64)),
        "seeds": list(seeds),
        "partitions": partitions(x, y, seeds),
        "archived_rows": archive.get("rows"),
        "archive_replay": {"detector": "zscore", "seeds_matching": matches, "all": all(matches)},
        "report_rows_out": report.get("rows_out"),
    }


def x_recover__mutmut_orig(job: dict[str, Any], archive: dict[str, Any]) -> dict[str, Any]:
    if job["source"] == "adbench":
        x, y, report = lb.load_adbench(job["name"], Path(job["path"]))
    else:
        x, y, report = lb.load_uci(job["meta"], Path(job["path"]))
    seeds = tuple(archive["seeds"])
    matches = replay_matches(x, y, archive)
    return {
        "format": FORMAT,
        "problem": job["problem"],
        "source": job["source"],
        "recovery": "recomputed from the deterministic split; not archived at run time",
        "input_sha256": _file_digest(Path(job["path"])),
        "cleaned_rows": int(len(y)),
        "cleaned_sha256": _digest(np.ascontiguousarray(x)),
        "labels_sha256": _digest(np.asarray(y, dtype=np.int64)),
        "seeds": list(seeds),
        "partitions": partitions(x, y, seeds),
        "archived_rows": archive.get("rows"),
        "archive_replay": {"detector": "zscore", "seeds_matching": matches, "all": all(matches)},
        "report_rows_out": report.get("rows_out"),
    }


def x_recover__mutmut_1(job: dict[str, Any], archive: dict[str, Any]) -> dict[str, Any]:
    if job["XXsourceXX"] == "adbench":
        x, y, report = lb.load_adbench(job["name"], Path(job["path"]))
    else:
        x, y, report = lb.load_uci(job["meta"], Path(job["path"]))
    seeds = tuple(archive["seeds"])
    matches = replay_matches(x, y, archive)
    return {
        "format": FORMAT,
        "problem": job["problem"],
        "source": job["source"],
        "recovery": "recomputed from the deterministic split; not archived at run time",
        "input_sha256": _file_digest(Path(job["path"])),
        "cleaned_rows": int(len(y)),
        "cleaned_sha256": _digest(np.ascontiguousarray(x)),
        "labels_sha256": _digest(np.asarray(y, dtype=np.int64)),
        "seeds": list(seeds),
        "partitions": partitions(x, y, seeds),
        "archived_rows": archive.get("rows"),
        "archive_replay": {"detector": "zscore", "seeds_matching": matches, "all": all(matches)},
        "report_rows_out": report.get("rows_out"),
    }


def x_recover__mutmut_2(job: dict[str, Any], archive: dict[str, Any]) -> dict[str, Any]:
    if job["SOURCE"] == "adbench":
        x, y, report = lb.load_adbench(job["name"], Path(job["path"]))
    else:
        x, y, report = lb.load_uci(job["meta"], Path(job["path"]))
    seeds = tuple(archive["seeds"])
    matches = replay_matches(x, y, archive)
    return {
        "format": FORMAT,
        "problem": job["problem"],
        "source": job["source"],
        "recovery": "recomputed from the deterministic split; not archived at run time",
        "input_sha256": _file_digest(Path(job["path"])),
        "cleaned_rows": int(len(y)),
        "cleaned_sha256": _digest(np.ascontiguousarray(x)),
        "labels_sha256": _digest(np.asarray(y, dtype=np.int64)),
        "seeds": list(seeds),
        "partitions": partitions(x, y, seeds),
        "archived_rows": archive.get("rows"),
        "archive_replay": {"detector": "zscore", "seeds_matching": matches, "all": all(matches)},
        "report_rows_out": report.get("rows_out"),
    }


def x_recover__mutmut_3(job: dict[str, Any], archive: dict[str, Any]) -> dict[str, Any]:
    if job["source"] != "adbench":
        x, y, report = lb.load_adbench(job["name"], Path(job["path"]))
    else:
        x, y, report = lb.load_uci(job["meta"], Path(job["path"]))
    seeds = tuple(archive["seeds"])
    matches = replay_matches(x, y, archive)
    return {
        "format": FORMAT,
        "problem": job["problem"],
        "source": job["source"],
        "recovery": "recomputed from the deterministic split; not archived at run time",
        "input_sha256": _file_digest(Path(job["path"])),
        "cleaned_rows": int(len(y)),
        "cleaned_sha256": _digest(np.ascontiguousarray(x)),
        "labels_sha256": _digest(np.asarray(y, dtype=np.int64)),
        "seeds": list(seeds),
        "partitions": partitions(x, y, seeds),
        "archived_rows": archive.get("rows"),
        "archive_replay": {"detector": "zscore", "seeds_matching": matches, "all": all(matches)},
        "report_rows_out": report.get("rows_out"),
    }


def x_recover__mutmut_4(job: dict[str, Any], archive: dict[str, Any]) -> dict[str, Any]:
    if job["source"] == "XXadbenchXX":
        x, y, report = lb.load_adbench(job["name"], Path(job["path"]))
    else:
        x, y, report = lb.load_uci(job["meta"], Path(job["path"]))
    seeds = tuple(archive["seeds"])
    matches = replay_matches(x, y, archive)
    return {
        "format": FORMAT,
        "problem": job["problem"],
        "source": job["source"],
        "recovery": "recomputed from the deterministic split; not archived at run time",
        "input_sha256": _file_digest(Path(job["path"])),
        "cleaned_rows": int(len(y)),
        "cleaned_sha256": _digest(np.ascontiguousarray(x)),
        "labels_sha256": _digest(np.asarray(y, dtype=np.int64)),
        "seeds": list(seeds),
        "partitions": partitions(x, y, seeds),
        "archived_rows": archive.get("rows"),
        "archive_replay": {"detector": "zscore", "seeds_matching": matches, "all": all(matches)},
        "report_rows_out": report.get("rows_out"),
    }


def x_recover__mutmut_5(job: dict[str, Any], archive: dict[str, Any]) -> dict[str, Any]:
    if job["source"] == "ADBENCH":
        x, y, report = lb.load_adbench(job["name"], Path(job["path"]))
    else:
        x, y, report = lb.load_uci(job["meta"], Path(job["path"]))
    seeds = tuple(archive["seeds"])
    matches = replay_matches(x, y, archive)
    return {
        "format": FORMAT,
        "problem": job["problem"],
        "source": job["source"],
        "recovery": "recomputed from the deterministic split; not archived at run time",
        "input_sha256": _file_digest(Path(job["path"])),
        "cleaned_rows": int(len(y)),
        "cleaned_sha256": _digest(np.ascontiguousarray(x)),
        "labels_sha256": _digest(np.asarray(y, dtype=np.int64)),
        "seeds": list(seeds),
        "partitions": partitions(x, y, seeds),
        "archived_rows": archive.get("rows"),
        "archive_replay": {"detector": "zscore", "seeds_matching": matches, "all": all(matches)},
        "report_rows_out": report.get("rows_out"),
    }


def x_recover__mutmut_6(job: dict[str, Any], archive: dict[str, Any]) -> dict[str, Any]:
    if job["source"] == "adbench":
        x, y, report = None
    else:
        x, y, report = lb.load_uci(job["meta"], Path(job["path"]))
    seeds = tuple(archive["seeds"])
    matches = replay_matches(x, y, archive)
    return {
        "format": FORMAT,
        "problem": job["problem"],
        "source": job["source"],
        "recovery": "recomputed from the deterministic split; not archived at run time",
        "input_sha256": _file_digest(Path(job["path"])),
        "cleaned_rows": int(len(y)),
        "cleaned_sha256": _digest(np.ascontiguousarray(x)),
        "labels_sha256": _digest(np.asarray(y, dtype=np.int64)),
        "seeds": list(seeds),
        "partitions": partitions(x, y, seeds),
        "archived_rows": archive.get("rows"),
        "archive_replay": {"detector": "zscore", "seeds_matching": matches, "all": all(matches)},
        "report_rows_out": report.get("rows_out"),
    }


def x_recover__mutmut_7(job: dict[str, Any], archive: dict[str, Any]) -> dict[str, Any]:
    if job["source"] == "adbench":
        x, y, report = lb.load_adbench(None, Path(job["path"]))
    else:
        x, y, report = lb.load_uci(job["meta"], Path(job["path"]))
    seeds = tuple(archive["seeds"])
    matches = replay_matches(x, y, archive)
    return {
        "format": FORMAT,
        "problem": job["problem"],
        "source": job["source"],
        "recovery": "recomputed from the deterministic split; not archived at run time",
        "input_sha256": _file_digest(Path(job["path"])),
        "cleaned_rows": int(len(y)),
        "cleaned_sha256": _digest(np.ascontiguousarray(x)),
        "labels_sha256": _digest(np.asarray(y, dtype=np.int64)),
        "seeds": list(seeds),
        "partitions": partitions(x, y, seeds),
        "archived_rows": archive.get("rows"),
        "archive_replay": {"detector": "zscore", "seeds_matching": matches, "all": all(matches)},
        "report_rows_out": report.get("rows_out"),
    }


def x_recover__mutmut_8(job: dict[str, Any], archive: dict[str, Any]) -> dict[str, Any]:
    if job["source"] == "adbench":
        x, y, report = lb.load_adbench(job["name"], None)
    else:
        x, y, report = lb.load_uci(job["meta"], Path(job["path"]))
    seeds = tuple(archive["seeds"])
    matches = replay_matches(x, y, archive)
    return {
        "format": FORMAT,
        "problem": job["problem"],
        "source": job["source"],
        "recovery": "recomputed from the deterministic split; not archived at run time",
        "input_sha256": _file_digest(Path(job["path"])),
        "cleaned_rows": int(len(y)),
        "cleaned_sha256": _digest(np.ascontiguousarray(x)),
        "labels_sha256": _digest(np.asarray(y, dtype=np.int64)),
        "seeds": list(seeds),
        "partitions": partitions(x, y, seeds),
        "archived_rows": archive.get("rows"),
        "archive_replay": {"detector": "zscore", "seeds_matching": matches, "all": all(matches)},
        "report_rows_out": report.get("rows_out"),
    }


def x_recover__mutmut_9(job: dict[str, Any], archive: dict[str, Any]) -> dict[str, Any]:
    if job["source"] == "adbench":
        x, y, report = lb.load_adbench(Path(job["path"]))
    else:
        x, y, report = lb.load_uci(job["meta"], Path(job["path"]))
    seeds = tuple(archive["seeds"])
    matches = replay_matches(x, y, archive)
    return {
        "format": FORMAT,
        "problem": job["problem"],
        "source": job["source"],
        "recovery": "recomputed from the deterministic split; not archived at run time",
        "input_sha256": _file_digest(Path(job["path"])),
        "cleaned_rows": int(len(y)),
        "cleaned_sha256": _digest(np.ascontiguousarray(x)),
        "labels_sha256": _digest(np.asarray(y, dtype=np.int64)),
        "seeds": list(seeds),
        "partitions": partitions(x, y, seeds),
        "archived_rows": archive.get("rows"),
        "archive_replay": {"detector": "zscore", "seeds_matching": matches, "all": all(matches)},
        "report_rows_out": report.get("rows_out"),
    }


def x_recover__mutmut_10(job: dict[str, Any], archive: dict[str, Any]) -> dict[str, Any]:
    if job["source"] == "adbench":
        x, y, report = lb.load_adbench(job["name"], )
    else:
        x, y, report = lb.load_uci(job["meta"], Path(job["path"]))
    seeds = tuple(archive["seeds"])
    matches = replay_matches(x, y, archive)
    return {
        "format": FORMAT,
        "problem": job["problem"],
        "source": job["source"],
        "recovery": "recomputed from the deterministic split; not archived at run time",
        "input_sha256": _file_digest(Path(job["path"])),
        "cleaned_rows": int(len(y)),
        "cleaned_sha256": _digest(np.ascontiguousarray(x)),
        "labels_sha256": _digest(np.asarray(y, dtype=np.int64)),
        "seeds": list(seeds),
        "partitions": partitions(x, y, seeds),
        "archived_rows": archive.get("rows"),
        "archive_replay": {"detector": "zscore", "seeds_matching": matches, "all": all(matches)},
        "report_rows_out": report.get("rows_out"),
    }


def x_recover__mutmut_11(job: dict[str, Any], archive: dict[str, Any]) -> dict[str, Any]:
    if job["source"] == "adbench":
        x, y, report = lb.load_adbench(job["XXnameXX"], Path(job["path"]))
    else:
        x, y, report = lb.load_uci(job["meta"], Path(job["path"]))
    seeds = tuple(archive["seeds"])
    matches = replay_matches(x, y, archive)
    return {
        "format": FORMAT,
        "problem": job["problem"],
        "source": job["source"],
        "recovery": "recomputed from the deterministic split; not archived at run time",
        "input_sha256": _file_digest(Path(job["path"])),
        "cleaned_rows": int(len(y)),
        "cleaned_sha256": _digest(np.ascontiguousarray(x)),
        "labels_sha256": _digest(np.asarray(y, dtype=np.int64)),
        "seeds": list(seeds),
        "partitions": partitions(x, y, seeds),
        "archived_rows": archive.get("rows"),
        "archive_replay": {"detector": "zscore", "seeds_matching": matches, "all": all(matches)},
        "report_rows_out": report.get("rows_out"),
    }


def x_recover__mutmut_12(job: dict[str, Any], archive: dict[str, Any]) -> dict[str, Any]:
    if job["source"] == "adbench":
        x, y, report = lb.load_adbench(job["NAME"], Path(job["path"]))
    else:
        x, y, report = lb.load_uci(job["meta"], Path(job["path"]))
    seeds = tuple(archive["seeds"])
    matches = replay_matches(x, y, archive)
    return {
        "format": FORMAT,
        "problem": job["problem"],
        "source": job["source"],
        "recovery": "recomputed from the deterministic split; not archived at run time",
        "input_sha256": _file_digest(Path(job["path"])),
        "cleaned_rows": int(len(y)),
        "cleaned_sha256": _digest(np.ascontiguousarray(x)),
        "labels_sha256": _digest(np.asarray(y, dtype=np.int64)),
        "seeds": list(seeds),
        "partitions": partitions(x, y, seeds),
        "archived_rows": archive.get("rows"),
        "archive_replay": {"detector": "zscore", "seeds_matching": matches, "all": all(matches)},
        "report_rows_out": report.get("rows_out"),
    }


def x_recover__mutmut_13(job: dict[str, Any], archive: dict[str, Any]) -> dict[str, Any]:
    if job["source"] == "adbench":
        x, y, report = lb.load_adbench(job["name"], Path(None))
    else:
        x, y, report = lb.load_uci(job["meta"], Path(job["path"]))
    seeds = tuple(archive["seeds"])
    matches = replay_matches(x, y, archive)
    return {
        "format": FORMAT,
        "problem": job["problem"],
        "source": job["source"],
        "recovery": "recomputed from the deterministic split; not archived at run time",
        "input_sha256": _file_digest(Path(job["path"])),
        "cleaned_rows": int(len(y)),
        "cleaned_sha256": _digest(np.ascontiguousarray(x)),
        "labels_sha256": _digest(np.asarray(y, dtype=np.int64)),
        "seeds": list(seeds),
        "partitions": partitions(x, y, seeds),
        "archived_rows": archive.get("rows"),
        "archive_replay": {"detector": "zscore", "seeds_matching": matches, "all": all(matches)},
        "report_rows_out": report.get("rows_out"),
    }


def x_recover__mutmut_14(job: dict[str, Any], archive: dict[str, Any]) -> dict[str, Any]:
    if job["source"] == "adbench":
        x, y, report = lb.load_adbench(job["name"], Path(job["XXpathXX"]))
    else:
        x, y, report = lb.load_uci(job["meta"], Path(job["path"]))
    seeds = tuple(archive["seeds"])
    matches = replay_matches(x, y, archive)
    return {
        "format": FORMAT,
        "problem": job["problem"],
        "source": job["source"],
        "recovery": "recomputed from the deterministic split; not archived at run time",
        "input_sha256": _file_digest(Path(job["path"])),
        "cleaned_rows": int(len(y)),
        "cleaned_sha256": _digest(np.ascontiguousarray(x)),
        "labels_sha256": _digest(np.asarray(y, dtype=np.int64)),
        "seeds": list(seeds),
        "partitions": partitions(x, y, seeds),
        "archived_rows": archive.get("rows"),
        "archive_replay": {"detector": "zscore", "seeds_matching": matches, "all": all(matches)},
        "report_rows_out": report.get("rows_out"),
    }


def x_recover__mutmut_15(job: dict[str, Any], archive: dict[str, Any]) -> dict[str, Any]:
    if job["source"] == "adbench":
        x, y, report = lb.load_adbench(job["name"], Path(job["PATH"]))
    else:
        x, y, report = lb.load_uci(job["meta"], Path(job["path"]))
    seeds = tuple(archive["seeds"])
    matches = replay_matches(x, y, archive)
    return {
        "format": FORMAT,
        "problem": job["problem"],
        "source": job["source"],
        "recovery": "recomputed from the deterministic split; not archived at run time",
        "input_sha256": _file_digest(Path(job["path"])),
        "cleaned_rows": int(len(y)),
        "cleaned_sha256": _digest(np.ascontiguousarray(x)),
        "labels_sha256": _digest(np.asarray(y, dtype=np.int64)),
        "seeds": list(seeds),
        "partitions": partitions(x, y, seeds),
        "archived_rows": archive.get("rows"),
        "archive_replay": {"detector": "zscore", "seeds_matching": matches, "all": all(matches)},
        "report_rows_out": report.get("rows_out"),
    }


def x_recover__mutmut_16(job: dict[str, Any], archive: dict[str, Any]) -> dict[str, Any]:
    if job["source"] == "adbench":
        x, y, report = lb.load_adbench(job["name"], Path(job["path"]))
    else:
        x, y, report = None
    seeds = tuple(archive["seeds"])
    matches = replay_matches(x, y, archive)
    return {
        "format": FORMAT,
        "problem": job["problem"],
        "source": job["source"],
        "recovery": "recomputed from the deterministic split; not archived at run time",
        "input_sha256": _file_digest(Path(job["path"])),
        "cleaned_rows": int(len(y)),
        "cleaned_sha256": _digest(np.ascontiguousarray(x)),
        "labels_sha256": _digest(np.asarray(y, dtype=np.int64)),
        "seeds": list(seeds),
        "partitions": partitions(x, y, seeds),
        "archived_rows": archive.get("rows"),
        "archive_replay": {"detector": "zscore", "seeds_matching": matches, "all": all(matches)},
        "report_rows_out": report.get("rows_out"),
    }


def x_recover__mutmut_17(job: dict[str, Any], archive: dict[str, Any]) -> dict[str, Any]:
    if job["source"] == "adbench":
        x, y, report = lb.load_adbench(job["name"], Path(job["path"]))
    else:
        x, y, report = lb.load_uci(None, Path(job["path"]))
    seeds = tuple(archive["seeds"])
    matches = replay_matches(x, y, archive)
    return {
        "format": FORMAT,
        "problem": job["problem"],
        "source": job["source"],
        "recovery": "recomputed from the deterministic split; not archived at run time",
        "input_sha256": _file_digest(Path(job["path"])),
        "cleaned_rows": int(len(y)),
        "cleaned_sha256": _digest(np.ascontiguousarray(x)),
        "labels_sha256": _digest(np.asarray(y, dtype=np.int64)),
        "seeds": list(seeds),
        "partitions": partitions(x, y, seeds),
        "archived_rows": archive.get("rows"),
        "archive_replay": {"detector": "zscore", "seeds_matching": matches, "all": all(matches)},
        "report_rows_out": report.get("rows_out"),
    }


def x_recover__mutmut_18(job: dict[str, Any], archive: dict[str, Any]) -> dict[str, Any]:
    if job["source"] == "adbench":
        x, y, report = lb.load_adbench(job["name"], Path(job["path"]))
    else:
        x, y, report = lb.load_uci(job["meta"], None)
    seeds = tuple(archive["seeds"])
    matches = replay_matches(x, y, archive)
    return {
        "format": FORMAT,
        "problem": job["problem"],
        "source": job["source"],
        "recovery": "recomputed from the deterministic split; not archived at run time",
        "input_sha256": _file_digest(Path(job["path"])),
        "cleaned_rows": int(len(y)),
        "cleaned_sha256": _digest(np.ascontiguousarray(x)),
        "labels_sha256": _digest(np.asarray(y, dtype=np.int64)),
        "seeds": list(seeds),
        "partitions": partitions(x, y, seeds),
        "archived_rows": archive.get("rows"),
        "archive_replay": {"detector": "zscore", "seeds_matching": matches, "all": all(matches)},
        "report_rows_out": report.get("rows_out"),
    }


def x_recover__mutmut_19(job: dict[str, Any], archive: dict[str, Any]) -> dict[str, Any]:
    if job["source"] == "adbench":
        x, y, report = lb.load_adbench(job["name"], Path(job["path"]))
    else:
        x, y, report = lb.load_uci(Path(job["path"]))
    seeds = tuple(archive["seeds"])
    matches = replay_matches(x, y, archive)
    return {
        "format": FORMAT,
        "problem": job["problem"],
        "source": job["source"],
        "recovery": "recomputed from the deterministic split; not archived at run time",
        "input_sha256": _file_digest(Path(job["path"])),
        "cleaned_rows": int(len(y)),
        "cleaned_sha256": _digest(np.ascontiguousarray(x)),
        "labels_sha256": _digest(np.asarray(y, dtype=np.int64)),
        "seeds": list(seeds),
        "partitions": partitions(x, y, seeds),
        "archived_rows": archive.get("rows"),
        "archive_replay": {"detector": "zscore", "seeds_matching": matches, "all": all(matches)},
        "report_rows_out": report.get("rows_out"),
    }


def x_recover__mutmut_20(job: dict[str, Any], archive: dict[str, Any]) -> dict[str, Any]:
    if job["source"] == "adbench":
        x, y, report = lb.load_adbench(job["name"], Path(job["path"]))
    else:
        x, y, report = lb.load_uci(job["meta"], )
    seeds = tuple(archive["seeds"])
    matches = replay_matches(x, y, archive)
    return {
        "format": FORMAT,
        "problem": job["problem"],
        "source": job["source"],
        "recovery": "recomputed from the deterministic split; not archived at run time",
        "input_sha256": _file_digest(Path(job["path"])),
        "cleaned_rows": int(len(y)),
        "cleaned_sha256": _digest(np.ascontiguousarray(x)),
        "labels_sha256": _digest(np.asarray(y, dtype=np.int64)),
        "seeds": list(seeds),
        "partitions": partitions(x, y, seeds),
        "archived_rows": archive.get("rows"),
        "archive_replay": {"detector": "zscore", "seeds_matching": matches, "all": all(matches)},
        "report_rows_out": report.get("rows_out"),
    }


def x_recover__mutmut_21(job: dict[str, Any], archive: dict[str, Any]) -> dict[str, Any]:
    if job["source"] == "adbench":
        x, y, report = lb.load_adbench(job["name"], Path(job["path"]))
    else:
        x, y, report = lb.load_uci(job["XXmetaXX"], Path(job["path"]))
    seeds = tuple(archive["seeds"])
    matches = replay_matches(x, y, archive)
    return {
        "format": FORMAT,
        "problem": job["problem"],
        "source": job["source"],
        "recovery": "recomputed from the deterministic split; not archived at run time",
        "input_sha256": _file_digest(Path(job["path"])),
        "cleaned_rows": int(len(y)),
        "cleaned_sha256": _digest(np.ascontiguousarray(x)),
        "labels_sha256": _digest(np.asarray(y, dtype=np.int64)),
        "seeds": list(seeds),
        "partitions": partitions(x, y, seeds),
        "archived_rows": archive.get("rows"),
        "archive_replay": {"detector": "zscore", "seeds_matching": matches, "all": all(matches)},
        "report_rows_out": report.get("rows_out"),
    }


def x_recover__mutmut_22(job: dict[str, Any], archive: dict[str, Any]) -> dict[str, Any]:
    if job["source"] == "adbench":
        x, y, report = lb.load_adbench(job["name"], Path(job["path"]))
    else:
        x, y, report = lb.load_uci(job["META"], Path(job["path"]))
    seeds = tuple(archive["seeds"])
    matches = replay_matches(x, y, archive)
    return {
        "format": FORMAT,
        "problem": job["problem"],
        "source": job["source"],
        "recovery": "recomputed from the deterministic split; not archived at run time",
        "input_sha256": _file_digest(Path(job["path"])),
        "cleaned_rows": int(len(y)),
        "cleaned_sha256": _digest(np.ascontiguousarray(x)),
        "labels_sha256": _digest(np.asarray(y, dtype=np.int64)),
        "seeds": list(seeds),
        "partitions": partitions(x, y, seeds),
        "archived_rows": archive.get("rows"),
        "archive_replay": {"detector": "zscore", "seeds_matching": matches, "all": all(matches)},
        "report_rows_out": report.get("rows_out"),
    }


def x_recover__mutmut_23(job: dict[str, Any], archive: dict[str, Any]) -> dict[str, Any]:
    if job["source"] == "adbench":
        x, y, report = lb.load_adbench(job["name"], Path(job["path"]))
    else:
        x, y, report = lb.load_uci(job["meta"], Path(None))
    seeds = tuple(archive["seeds"])
    matches = replay_matches(x, y, archive)
    return {
        "format": FORMAT,
        "problem": job["problem"],
        "source": job["source"],
        "recovery": "recomputed from the deterministic split; not archived at run time",
        "input_sha256": _file_digest(Path(job["path"])),
        "cleaned_rows": int(len(y)),
        "cleaned_sha256": _digest(np.ascontiguousarray(x)),
        "labels_sha256": _digest(np.asarray(y, dtype=np.int64)),
        "seeds": list(seeds),
        "partitions": partitions(x, y, seeds),
        "archived_rows": archive.get("rows"),
        "archive_replay": {"detector": "zscore", "seeds_matching": matches, "all": all(matches)},
        "report_rows_out": report.get("rows_out"),
    }


def x_recover__mutmut_24(job: dict[str, Any], archive: dict[str, Any]) -> dict[str, Any]:
    if job["source"] == "adbench":
        x, y, report = lb.load_adbench(job["name"], Path(job["path"]))
    else:
        x, y, report = lb.load_uci(job["meta"], Path(job["XXpathXX"]))
    seeds = tuple(archive["seeds"])
    matches = replay_matches(x, y, archive)
    return {
        "format": FORMAT,
        "problem": job["problem"],
        "source": job["source"],
        "recovery": "recomputed from the deterministic split; not archived at run time",
        "input_sha256": _file_digest(Path(job["path"])),
        "cleaned_rows": int(len(y)),
        "cleaned_sha256": _digest(np.ascontiguousarray(x)),
        "labels_sha256": _digest(np.asarray(y, dtype=np.int64)),
        "seeds": list(seeds),
        "partitions": partitions(x, y, seeds),
        "archived_rows": archive.get("rows"),
        "archive_replay": {"detector": "zscore", "seeds_matching": matches, "all": all(matches)},
        "report_rows_out": report.get("rows_out"),
    }


def x_recover__mutmut_25(job: dict[str, Any], archive: dict[str, Any]) -> dict[str, Any]:
    if job["source"] == "adbench":
        x, y, report = lb.load_adbench(job["name"], Path(job["path"]))
    else:
        x, y, report = lb.load_uci(job["meta"], Path(job["PATH"]))
    seeds = tuple(archive["seeds"])
    matches = replay_matches(x, y, archive)
    return {
        "format": FORMAT,
        "problem": job["problem"],
        "source": job["source"],
        "recovery": "recomputed from the deterministic split; not archived at run time",
        "input_sha256": _file_digest(Path(job["path"])),
        "cleaned_rows": int(len(y)),
        "cleaned_sha256": _digest(np.ascontiguousarray(x)),
        "labels_sha256": _digest(np.asarray(y, dtype=np.int64)),
        "seeds": list(seeds),
        "partitions": partitions(x, y, seeds),
        "archived_rows": archive.get("rows"),
        "archive_replay": {"detector": "zscore", "seeds_matching": matches, "all": all(matches)},
        "report_rows_out": report.get("rows_out"),
    }


def x_recover__mutmut_26(job: dict[str, Any], archive: dict[str, Any]) -> dict[str, Any]:
    if job["source"] == "adbench":
        x, y, report = lb.load_adbench(job["name"], Path(job["path"]))
    else:
        x, y, report = lb.load_uci(job["meta"], Path(job["path"]))
    seeds = None
    matches = replay_matches(x, y, archive)
    return {
        "format": FORMAT,
        "problem": job["problem"],
        "source": job["source"],
        "recovery": "recomputed from the deterministic split; not archived at run time",
        "input_sha256": _file_digest(Path(job["path"])),
        "cleaned_rows": int(len(y)),
        "cleaned_sha256": _digest(np.ascontiguousarray(x)),
        "labels_sha256": _digest(np.asarray(y, dtype=np.int64)),
        "seeds": list(seeds),
        "partitions": partitions(x, y, seeds),
        "archived_rows": archive.get("rows"),
        "archive_replay": {"detector": "zscore", "seeds_matching": matches, "all": all(matches)},
        "report_rows_out": report.get("rows_out"),
    }


def x_recover__mutmut_27(job: dict[str, Any], archive: dict[str, Any]) -> dict[str, Any]:
    if job["source"] == "adbench":
        x, y, report = lb.load_adbench(job["name"], Path(job["path"]))
    else:
        x, y, report = lb.load_uci(job["meta"], Path(job["path"]))
    seeds = tuple(None)
    matches = replay_matches(x, y, archive)
    return {
        "format": FORMAT,
        "problem": job["problem"],
        "source": job["source"],
        "recovery": "recomputed from the deterministic split; not archived at run time",
        "input_sha256": _file_digest(Path(job["path"])),
        "cleaned_rows": int(len(y)),
        "cleaned_sha256": _digest(np.ascontiguousarray(x)),
        "labels_sha256": _digest(np.asarray(y, dtype=np.int64)),
        "seeds": list(seeds),
        "partitions": partitions(x, y, seeds),
        "archived_rows": archive.get("rows"),
        "archive_replay": {"detector": "zscore", "seeds_matching": matches, "all": all(matches)},
        "report_rows_out": report.get("rows_out"),
    }


def x_recover__mutmut_28(job: dict[str, Any], archive: dict[str, Any]) -> dict[str, Any]:
    if job["source"] == "adbench":
        x, y, report = lb.load_adbench(job["name"], Path(job["path"]))
    else:
        x, y, report = lb.load_uci(job["meta"], Path(job["path"]))
    seeds = tuple(archive["XXseedsXX"])
    matches = replay_matches(x, y, archive)
    return {
        "format": FORMAT,
        "problem": job["problem"],
        "source": job["source"],
        "recovery": "recomputed from the deterministic split; not archived at run time",
        "input_sha256": _file_digest(Path(job["path"])),
        "cleaned_rows": int(len(y)),
        "cleaned_sha256": _digest(np.ascontiguousarray(x)),
        "labels_sha256": _digest(np.asarray(y, dtype=np.int64)),
        "seeds": list(seeds),
        "partitions": partitions(x, y, seeds),
        "archived_rows": archive.get("rows"),
        "archive_replay": {"detector": "zscore", "seeds_matching": matches, "all": all(matches)},
        "report_rows_out": report.get("rows_out"),
    }


def x_recover__mutmut_29(job: dict[str, Any], archive: dict[str, Any]) -> dict[str, Any]:
    if job["source"] == "adbench":
        x, y, report = lb.load_adbench(job["name"], Path(job["path"]))
    else:
        x, y, report = lb.load_uci(job["meta"], Path(job["path"]))
    seeds = tuple(archive["SEEDS"])
    matches = replay_matches(x, y, archive)
    return {
        "format": FORMAT,
        "problem": job["problem"],
        "source": job["source"],
        "recovery": "recomputed from the deterministic split; not archived at run time",
        "input_sha256": _file_digest(Path(job["path"])),
        "cleaned_rows": int(len(y)),
        "cleaned_sha256": _digest(np.ascontiguousarray(x)),
        "labels_sha256": _digest(np.asarray(y, dtype=np.int64)),
        "seeds": list(seeds),
        "partitions": partitions(x, y, seeds),
        "archived_rows": archive.get("rows"),
        "archive_replay": {"detector": "zscore", "seeds_matching": matches, "all": all(matches)},
        "report_rows_out": report.get("rows_out"),
    }


def x_recover__mutmut_30(job: dict[str, Any], archive: dict[str, Any]) -> dict[str, Any]:
    if job["source"] == "adbench":
        x, y, report = lb.load_adbench(job["name"], Path(job["path"]))
    else:
        x, y, report = lb.load_uci(job["meta"], Path(job["path"]))
    seeds = tuple(archive["seeds"])
    matches = None
    return {
        "format": FORMAT,
        "problem": job["problem"],
        "source": job["source"],
        "recovery": "recomputed from the deterministic split; not archived at run time",
        "input_sha256": _file_digest(Path(job["path"])),
        "cleaned_rows": int(len(y)),
        "cleaned_sha256": _digest(np.ascontiguousarray(x)),
        "labels_sha256": _digest(np.asarray(y, dtype=np.int64)),
        "seeds": list(seeds),
        "partitions": partitions(x, y, seeds),
        "archived_rows": archive.get("rows"),
        "archive_replay": {"detector": "zscore", "seeds_matching": matches, "all": all(matches)},
        "report_rows_out": report.get("rows_out"),
    }


def x_recover__mutmut_31(job: dict[str, Any], archive: dict[str, Any]) -> dict[str, Any]:
    if job["source"] == "adbench":
        x, y, report = lb.load_adbench(job["name"], Path(job["path"]))
    else:
        x, y, report = lb.load_uci(job["meta"], Path(job["path"]))
    seeds = tuple(archive["seeds"])
    matches = replay_matches(None, y, archive)
    return {
        "format": FORMAT,
        "problem": job["problem"],
        "source": job["source"],
        "recovery": "recomputed from the deterministic split; not archived at run time",
        "input_sha256": _file_digest(Path(job["path"])),
        "cleaned_rows": int(len(y)),
        "cleaned_sha256": _digest(np.ascontiguousarray(x)),
        "labels_sha256": _digest(np.asarray(y, dtype=np.int64)),
        "seeds": list(seeds),
        "partitions": partitions(x, y, seeds),
        "archived_rows": archive.get("rows"),
        "archive_replay": {"detector": "zscore", "seeds_matching": matches, "all": all(matches)},
        "report_rows_out": report.get("rows_out"),
    }


def x_recover__mutmut_32(job: dict[str, Any], archive: dict[str, Any]) -> dict[str, Any]:
    if job["source"] == "adbench":
        x, y, report = lb.load_adbench(job["name"], Path(job["path"]))
    else:
        x, y, report = lb.load_uci(job["meta"], Path(job["path"]))
    seeds = tuple(archive["seeds"])
    matches = replay_matches(x, None, archive)
    return {
        "format": FORMAT,
        "problem": job["problem"],
        "source": job["source"],
        "recovery": "recomputed from the deterministic split; not archived at run time",
        "input_sha256": _file_digest(Path(job["path"])),
        "cleaned_rows": int(len(y)),
        "cleaned_sha256": _digest(np.ascontiguousarray(x)),
        "labels_sha256": _digest(np.asarray(y, dtype=np.int64)),
        "seeds": list(seeds),
        "partitions": partitions(x, y, seeds),
        "archived_rows": archive.get("rows"),
        "archive_replay": {"detector": "zscore", "seeds_matching": matches, "all": all(matches)},
        "report_rows_out": report.get("rows_out"),
    }


def x_recover__mutmut_33(job: dict[str, Any], archive: dict[str, Any]) -> dict[str, Any]:
    if job["source"] == "adbench":
        x, y, report = lb.load_adbench(job["name"], Path(job["path"]))
    else:
        x, y, report = lb.load_uci(job["meta"], Path(job["path"]))
    seeds = tuple(archive["seeds"])
    matches = replay_matches(x, y, None)
    return {
        "format": FORMAT,
        "problem": job["problem"],
        "source": job["source"],
        "recovery": "recomputed from the deterministic split; not archived at run time",
        "input_sha256": _file_digest(Path(job["path"])),
        "cleaned_rows": int(len(y)),
        "cleaned_sha256": _digest(np.ascontiguousarray(x)),
        "labels_sha256": _digest(np.asarray(y, dtype=np.int64)),
        "seeds": list(seeds),
        "partitions": partitions(x, y, seeds),
        "archived_rows": archive.get("rows"),
        "archive_replay": {"detector": "zscore", "seeds_matching": matches, "all": all(matches)},
        "report_rows_out": report.get("rows_out"),
    }


def x_recover__mutmut_34(job: dict[str, Any], archive: dict[str, Any]) -> dict[str, Any]:
    if job["source"] == "adbench":
        x, y, report = lb.load_adbench(job["name"], Path(job["path"]))
    else:
        x, y, report = lb.load_uci(job["meta"], Path(job["path"]))
    seeds = tuple(archive["seeds"])
    matches = replay_matches(y, archive)
    return {
        "format": FORMAT,
        "problem": job["problem"],
        "source": job["source"],
        "recovery": "recomputed from the deterministic split; not archived at run time",
        "input_sha256": _file_digest(Path(job["path"])),
        "cleaned_rows": int(len(y)),
        "cleaned_sha256": _digest(np.ascontiguousarray(x)),
        "labels_sha256": _digest(np.asarray(y, dtype=np.int64)),
        "seeds": list(seeds),
        "partitions": partitions(x, y, seeds),
        "archived_rows": archive.get("rows"),
        "archive_replay": {"detector": "zscore", "seeds_matching": matches, "all": all(matches)},
        "report_rows_out": report.get("rows_out"),
    }


def x_recover__mutmut_35(job: dict[str, Any], archive: dict[str, Any]) -> dict[str, Any]:
    if job["source"] == "adbench":
        x, y, report = lb.load_adbench(job["name"], Path(job["path"]))
    else:
        x, y, report = lb.load_uci(job["meta"], Path(job["path"]))
    seeds = tuple(archive["seeds"])
    matches = replay_matches(x, archive)
    return {
        "format": FORMAT,
        "problem": job["problem"],
        "source": job["source"],
        "recovery": "recomputed from the deterministic split; not archived at run time",
        "input_sha256": _file_digest(Path(job["path"])),
        "cleaned_rows": int(len(y)),
        "cleaned_sha256": _digest(np.ascontiguousarray(x)),
        "labels_sha256": _digest(np.asarray(y, dtype=np.int64)),
        "seeds": list(seeds),
        "partitions": partitions(x, y, seeds),
        "archived_rows": archive.get("rows"),
        "archive_replay": {"detector": "zscore", "seeds_matching": matches, "all": all(matches)},
        "report_rows_out": report.get("rows_out"),
    }


def x_recover__mutmut_36(job: dict[str, Any], archive: dict[str, Any]) -> dict[str, Any]:
    if job["source"] == "adbench":
        x, y, report = lb.load_adbench(job["name"], Path(job["path"]))
    else:
        x, y, report = lb.load_uci(job["meta"], Path(job["path"]))
    seeds = tuple(archive["seeds"])
    matches = replay_matches(x, y, )
    return {
        "format": FORMAT,
        "problem": job["problem"],
        "source": job["source"],
        "recovery": "recomputed from the deterministic split; not archived at run time",
        "input_sha256": _file_digest(Path(job["path"])),
        "cleaned_rows": int(len(y)),
        "cleaned_sha256": _digest(np.ascontiguousarray(x)),
        "labels_sha256": _digest(np.asarray(y, dtype=np.int64)),
        "seeds": list(seeds),
        "partitions": partitions(x, y, seeds),
        "archived_rows": archive.get("rows"),
        "archive_replay": {"detector": "zscore", "seeds_matching": matches, "all": all(matches)},
        "report_rows_out": report.get("rows_out"),
    }


def x_recover__mutmut_37(job: dict[str, Any], archive: dict[str, Any]) -> dict[str, Any]:
    if job["source"] == "adbench":
        x, y, report = lb.load_adbench(job["name"], Path(job["path"]))
    else:
        x, y, report = lb.load_uci(job["meta"], Path(job["path"]))
    seeds = tuple(archive["seeds"])
    matches = replay_matches(x, y, archive)
    return {
        "XXformatXX": FORMAT,
        "problem": job["problem"],
        "source": job["source"],
        "recovery": "recomputed from the deterministic split; not archived at run time",
        "input_sha256": _file_digest(Path(job["path"])),
        "cleaned_rows": int(len(y)),
        "cleaned_sha256": _digest(np.ascontiguousarray(x)),
        "labels_sha256": _digest(np.asarray(y, dtype=np.int64)),
        "seeds": list(seeds),
        "partitions": partitions(x, y, seeds),
        "archived_rows": archive.get("rows"),
        "archive_replay": {"detector": "zscore", "seeds_matching": matches, "all": all(matches)},
        "report_rows_out": report.get("rows_out"),
    }


def x_recover__mutmut_38(job: dict[str, Any], archive: dict[str, Any]) -> dict[str, Any]:
    if job["source"] == "adbench":
        x, y, report = lb.load_adbench(job["name"], Path(job["path"]))
    else:
        x, y, report = lb.load_uci(job["meta"], Path(job["path"]))
    seeds = tuple(archive["seeds"])
    matches = replay_matches(x, y, archive)
    return {
        "FORMAT": FORMAT,
        "problem": job["problem"],
        "source": job["source"],
        "recovery": "recomputed from the deterministic split; not archived at run time",
        "input_sha256": _file_digest(Path(job["path"])),
        "cleaned_rows": int(len(y)),
        "cleaned_sha256": _digest(np.ascontiguousarray(x)),
        "labels_sha256": _digest(np.asarray(y, dtype=np.int64)),
        "seeds": list(seeds),
        "partitions": partitions(x, y, seeds),
        "archived_rows": archive.get("rows"),
        "archive_replay": {"detector": "zscore", "seeds_matching": matches, "all": all(matches)},
        "report_rows_out": report.get("rows_out"),
    }


def x_recover__mutmut_39(job: dict[str, Any], archive: dict[str, Any]) -> dict[str, Any]:
    if job["source"] == "adbench":
        x, y, report = lb.load_adbench(job["name"], Path(job["path"]))
    else:
        x, y, report = lb.load_uci(job["meta"], Path(job["path"]))
    seeds = tuple(archive["seeds"])
    matches = replay_matches(x, y, archive)
    return {
        "format": FORMAT,
        "XXproblemXX": job["problem"],
        "source": job["source"],
        "recovery": "recomputed from the deterministic split; not archived at run time",
        "input_sha256": _file_digest(Path(job["path"])),
        "cleaned_rows": int(len(y)),
        "cleaned_sha256": _digest(np.ascontiguousarray(x)),
        "labels_sha256": _digest(np.asarray(y, dtype=np.int64)),
        "seeds": list(seeds),
        "partitions": partitions(x, y, seeds),
        "archived_rows": archive.get("rows"),
        "archive_replay": {"detector": "zscore", "seeds_matching": matches, "all": all(matches)},
        "report_rows_out": report.get("rows_out"),
    }


def x_recover__mutmut_40(job: dict[str, Any], archive: dict[str, Any]) -> dict[str, Any]:
    if job["source"] == "adbench":
        x, y, report = lb.load_adbench(job["name"], Path(job["path"]))
    else:
        x, y, report = lb.load_uci(job["meta"], Path(job["path"]))
    seeds = tuple(archive["seeds"])
    matches = replay_matches(x, y, archive)
    return {
        "format": FORMAT,
        "PROBLEM": job["problem"],
        "source": job["source"],
        "recovery": "recomputed from the deterministic split; not archived at run time",
        "input_sha256": _file_digest(Path(job["path"])),
        "cleaned_rows": int(len(y)),
        "cleaned_sha256": _digest(np.ascontiguousarray(x)),
        "labels_sha256": _digest(np.asarray(y, dtype=np.int64)),
        "seeds": list(seeds),
        "partitions": partitions(x, y, seeds),
        "archived_rows": archive.get("rows"),
        "archive_replay": {"detector": "zscore", "seeds_matching": matches, "all": all(matches)},
        "report_rows_out": report.get("rows_out"),
    }


def x_recover__mutmut_41(job: dict[str, Any], archive: dict[str, Any]) -> dict[str, Any]:
    if job["source"] == "adbench":
        x, y, report = lb.load_adbench(job["name"], Path(job["path"]))
    else:
        x, y, report = lb.load_uci(job["meta"], Path(job["path"]))
    seeds = tuple(archive["seeds"])
    matches = replay_matches(x, y, archive)
    return {
        "format": FORMAT,
        "problem": job["XXproblemXX"],
        "source": job["source"],
        "recovery": "recomputed from the deterministic split; not archived at run time",
        "input_sha256": _file_digest(Path(job["path"])),
        "cleaned_rows": int(len(y)),
        "cleaned_sha256": _digest(np.ascontiguousarray(x)),
        "labels_sha256": _digest(np.asarray(y, dtype=np.int64)),
        "seeds": list(seeds),
        "partitions": partitions(x, y, seeds),
        "archived_rows": archive.get("rows"),
        "archive_replay": {"detector": "zscore", "seeds_matching": matches, "all": all(matches)},
        "report_rows_out": report.get("rows_out"),
    }


def x_recover__mutmut_42(job: dict[str, Any], archive: dict[str, Any]) -> dict[str, Any]:
    if job["source"] == "adbench":
        x, y, report = lb.load_adbench(job["name"], Path(job["path"]))
    else:
        x, y, report = lb.load_uci(job["meta"], Path(job["path"]))
    seeds = tuple(archive["seeds"])
    matches = replay_matches(x, y, archive)
    return {
        "format": FORMAT,
        "problem": job["PROBLEM"],
        "source": job["source"],
        "recovery": "recomputed from the deterministic split; not archived at run time",
        "input_sha256": _file_digest(Path(job["path"])),
        "cleaned_rows": int(len(y)),
        "cleaned_sha256": _digest(np.ascontiguousarray(x)),
        "labels_sha256": _digest(np.asarray(y, dtype=np.int64)),
        "seeds": list(seeds),
        "partitions": partitions(x, y, seeds),
        "archived_rows": archive.get("rows"),
        "archive_replay": {"detector": "zscore", "seeds_matching": matches, "all": all(matches)},
        "report_rows_out": report.get("rows_out"),
    }


def x_recover__mutmut_43(job: dict[str, Any], archive: dict[str, Any]) -> dict[str, Any]:
    if job["source"] == "adbench":
        x, y, report = lb.load_adbench(job["name"], Path(job["path"]))
    else:
        x, y, report = lb.load_uci(job["meta"], Path(job["path"]))
    seeds = tuple(archive["seeds"])
    matches = replay_matches(x, y, archive)
    return {
        "format": FORMAT,
        "problem": job["problem"],
        "XXsourceXX": job["source"],
        "recovery": "recomputed from the deterministic split; not archived at run time",
        "input_sha256": _file_digest(Path(job["path"])),
        "cleaned_rows": int(len(y)),
        "cleaned_sha256": _digest(np.ascontiguousarray(x)),
        "labels_sha256": _digest(np.asarray(y, dtype=np.int64)),
        "seeds": list(seeds),
        "partitions": partitions(x, y, seeds),
        "archived_rows": archive.get("rows"),
        "archive_replay": {"detector": "zscore", "seeds_matching": matches, "all": all(matches)},
        "report_rows_out": report.get("rows_out"),
    }


def x_recover__mutmut_44(job: dict[str, Any], archive: dict[str, Any]) -> dict[str, Any]:
    if job["source"] == "adbench":
        x, y, report = lb.load_adbench(job["name"], Path(job["path"]))
    else:
        x, y, report = lb.load_uci(job["meta"], Path(job["path"]))
    seeds = tuple(archive["seeds"])
    matches = replay_matches(x, y, archive)
    return {
        "format": FORMAT,
        "problem": job["problem"],
        "SOURCE": job["source"],
        "recovery": "recomputed from the deterministic split; not archived at run time",
        "input_sha256": _file_digest(Path(job["path"])),
        "cleaned_rows": int(len(y)),
        "cleaned_sha256": _digest(np.ascontiguousarray(x)),
        "labels_sha256": _digest(np.asarray(y, dtype=np.int64)),
        "seeds": list(seeds),
        "partitions": partitions(x, y, seeds),
        "archived_rows": archive.get("rows"),
        "archive_replay": {"detector": "zscore", "seeds_matching": matches, "all": all(matches)},
        "report_rows_out": report.get("rows_out"),
    }


def x_recover__mutmut_45(job: dict[str, Any], archive: dict[str, Any]) -> dict[str, Any]:
    if job["source"] == "adbench":
        x, y, report = lb.load_adbench(job["name"], Path(job["path"]))
    else:
        x, y, report = lb.load_uci(job["meta"], Path(job["path"]))
    seeds = tuple(archive["seeds"])
    matches = replay_matches(x, y, archive)
    return {
        "format": FORMAT,
        "problem": job["problem"],
        "source": job["XXsourceXX"],
        "recovery": "recomputed from the deterministic split; not archived at run time",
        "input_sha256": _file_digest(Path(job["path"])),
        "cleaned_rows": int(len(y)),
        "cleaned_sha256": _digest(np.ascontiguousarray(x)),
        "labels_sha256": _digest(np.asarray(y, dtype=np.int64)),
        "seeds": list(seeds),
        "partitions": partitions(x, y, seeds),
        "archived_rows": archive.get("rows"),
        "archive_replay": {"detector": "zscore", "seeds_matching": matches, "all": all(matches)},
        "report_rows_out": report.get("rows_out"),
    }


def x_recover__mutmut_46(job: dict[str, Any], archive: dict[str, Any]) -> dict[str, Any]:
    if job["source"] == "adbench":
        x, y, report = lb.load_adbench(job["name"], Path(job["path"]))
    else:
        x, y, report = lb.load_uci(job["meta"], Path(job["path"]))
    seeds = tuple(archive["seeds"])
    matches = replay_matches(x, y, archive)
    return {
        "format": FORMAT,
        "problem": job["problem"],
        "source": job["SOURCE"],
        "recovery": "recomputed from the deterministic split; not archived at run time",
        "input_sha256": _file_digest(Path(job["path"])),
        "cleaned_rows": int(len(y)),
        "cleaned_sha256": _digest(np.ascontiguousarray(x)),
        "labels_sha256": _digest(np.asarray(y, dtype=np.int64)),
        "seeds": list(seeds),
        "partitions": partitions(x, y, seeds),
        "archived_rows": archive.get("rows"),
        "archive_replay": {"detector": "zscore", "seeds_matching": matches, "all": all(matches)},
        "report_rows_out": report.get("rows_out"),
    }


def x_recover__mutmut_47(job: dict[str, Any], archive: dict[str, Any]) -> dict[str, Any]:
    if job["source"] == "adbench":
        x, y, report = lb.load_adbench(job["name"], Path(job["path"]))
    else:
        x, y, report = lb.load_uci(job["meta"], Path(job["path"]))
    seeds = tuple(archive["seeds"])
    matches = replay_matches(x, y, archive)
    return {
        "format": FORMAT,
        "problem": job["problem"],
        "source": job["source"],
        "XXrecoveryXX": "recomputed from the deterministic split; not archived at run time",
        "input_sha256": _file_digest(Path(job["path"])),
        "cleaned_rows": int(len(y)),
        "cleaned_sha256": _digest(np.ascontiguousarray(x)),
        "labels_sha256": _digest(np.asarray(y, dtype=np.int64)),
        "seeds": list(seeds),
        "partitions": partitions(x, y, seeds),
        "archived_rows": archive.get("rows"),
        "archive_replay": {"detector": "zscore", "seeds_matching": matches, "all": all(matches)},
        "report_rows_out": report.get("rows_out"),
    }


def x_recover__mutmut_48(job: dict[str, Any], archive: dict[str, Any]) -> dict[str, Any]:
    if job["source"] == "adbench":
        x, y, report = lb.load_adbench(job["name"], Path(job["path"]))
    else:
        x, y, report = lb.load_uci(job["meta"], Path(job["path"]))
    seeds = tuple(archive["seeds"])
    matches = replay_matches(x, y, archive)
    return {
        "format": FORMAT,
        "problem": job["problem"],
        "source": job["source"],
        "RECOVERY": "recomputed from the deterministic split; not archived at run time",
        "input_sha256": _file_digest(Path(job["path"])),
        "cleaned_rows": int(len(y)),
        "cleaned_sha256": _digest(np.ascontiguousarray(x)),
        "labels_sha256": _digest(np.asarray(y, dtype=np.int64)),
        "seeds": list(seeds),
        "partitions": partitions(x, y, seeds),
        "archived_rows": archive.get("rows"),
        "archive_replay": {"detector": "zscore", "seeds_matching": matches, "all": all(matches)},
        "report_rows_out": report.get("rows_out"),
    }


def x_recover__mutmut_49(job: dict[str, Any], archive: dict[str, Any]) -> dict[str, Any]:
    if job["source"] == "adbench":
        x, y, report = lb.load_adbench(job["name"], Path(job["path"]))
    else:
        x, y, report = lb.load_uci(job["meta"], Path(job["path"]))
    seeds = tuple(archive["seeds"])
    matches = replay_matches(x, y, archive)
    return {
        "format": FORMAT,
        "problem": job["problem"],
        "source": job["source"],
        "recovery": "XXrecomputed from the deterministic split; not archived at run timeXX",
        "input_sha256": _file_digest(Path(job["path"])),
        "cleaned_rows": int(len(y)),
        "cleaned_sha256": _digest(np.ascontiguousarray(x)),
        "labels_sha256": _digest(np.asarray(y, dtype=np.int64)),
        "seeds": list(seeds),
        "partitions": partitions(x, y, seeds),
        "archived_rows": archive.get("rows"),
        "archive_replay": {"detector": "zscore", "seeds_matching": matches, "all": all(matches)},
        "report_rows_out": report.get("rows_out"),
    }


def x_recover__mutmut_50(job: dict[str, Any], archive: dict[str, Any]) -> dict[str, Any]:
    if job["source"] == "adbench":
        x, y, report = lb.load_adbench(job["name"], Path(job["path"]))
    else:
        x, y, report = lb.load_uci(job["meta"], Path(job["path"]))
    seeds = tuple(archive["seeds"])
    matches = replay_matches(x, y, archive)
    return {
        "format": FORMAT,
        "problem": job["problem"],
        "source": job["source"],
        "recovery": "RECOMPUTED FROM THE DETERMINISTIC SPLIT; NOT ARCHIVED AT RUN TIME",
        "input_sha256": _file_digest(Path(job["path"])),
        "cleaned_rows": int(len(y)),
        "cleaned_sha256": _digest(np.ascontiguousarray(x)),
        "labels_sha256": _digest(np.asarray(y, dtype=np.int64)),
        "seeds": list(seeds),
        "partitions": partitions(x, y, seeds),
        "archived_rows": archive.get("rows"),
        "archive_replay": {"detector": "zscore", "seeds_matching": matches, "all": all(matches)},
        "report_rows_out": report.get("rows_out"),
    }


def x_recover__mutmut_51(job: dict[str, Any], archive: dict[str, Any]) -> dict[str, Any]:
    if job["source"] == "adbench":
        x, y, report = lb.load_adbench(job["name"], Path(job["path"]))
    else:
        x, y, report = lb.load_uci(job["meta"], Path(job["path"]))
    seeds = tuple(archive["seeds"])
    matches = replay_matches(x, y, archive)
    return {
        "format": FORMAT,
        "problem": job["problem"],
        "source": job["source"],
        "recovery": "recomputed from the deterministic split; not archived at run time",
        "XXinput_sha256XX": _file_digest(Path(job["path"])),
        "cleaned_rows": int(len(y)),
        "cleaned_sha256": _digest(np.ascontiguousarray(x)),
        "labels_sha256": _digest(np.asarray(y, dtype=np.int64)),
        "seeds": list(seeds),
        "partitions": partitions(x, y, seeds),
        "archived_rows": archive.get("rows"),
        "archive_replay": {"detector": "zscore", "seeds_matching": matches, "all": all(matches)},
        "report_rows_out": report.get("rows_out"),
    }


def x_recover__mutmut_52(job: dict[str, Any], archive: dict[str, Any]) -> dict[str, Any]:
    if job["source"] == "adbench":
        x, y, report = lb.load_adbench(job["name"], Path(job["path"]))
    else:
        x, y, report = lb.load_uci(job["meta"], Path(job["path"]))
    seeds = tuple(archive["seeds"])
    matches = replay_matches(x, y, archive)
    return {
        "format": FORMAT,
        "problem": job["problem"],
        "source": job["source"],
        "recovery": "recomputed from the deterministic split; not archived at run time",
        "INPUT_SHA256": _file_digest(Path(job["path"])),
        "cleaned_rows": int(len(y)),
        "cleaned_sha256": _digest(np.ascontiguousarray(x)),
        "labels_sha256": _digest(np.asarray(y, dtype=np.int64)),
        "seeds": list(seeds),
        "partitions": partitions(x, y, seeds),
        "archived_rows": archive.get("rows"),
        "archive_replay": {"detector": "zscore", "seeds_matching": matches, "all": all(matches)},
        "report_rows_out": report.get("rows_out"),
    }


def x_recover__mutmut_53(job: dict[str, Any], archive: dict[str, Any]) -> dict[str, Any]:
    if job["source"] == "adbench":
        x, y, report = lb.load_adbench(job["name"], Path(job["path"]))
    else:
        x, y, report = lb.load_uci(job["meta"], Path(job["path"]))
    seeds = tuple(archive["seeds"])
    matches = replay_matches(x, y, archive)
    return {
        "format": FORMAT,
        "problem": job["problem"],
        "source": job["source"],
        "recovery": "recomputed from the deterministic split; not archived at run time",
        "input_sha256": _file_digest(None),
        "cleaned_rows": int(len(y)),
        "cleaned_sha256": _digest(np.ascontiguousarray(x)),
        "labels_sha256": _digest(np.asarray(y, dtype=np.int64)),
        "seeds": list(seeds),
        "partitions": partitions(x, y, seeds),
        "archived_rows": archive.get("rows"),
        "archive_replay": {"detector": "zscore", "seeds_matching": matches, "all": all(matches)},
        "report_rows_out": report.get("rows_out"),
    }


def x_recover__mutmut_54(job: dict[str, Any], archive: dict[str, Any]) -> dict[str, Any]:
    if job["source"] == "adbench":
        x, y, report = lb.load_adbench(job["name"], Path(job["path"]))
    else:
        x, y, report = lb.load_uci(job["meta"], Path(job["path"]))
    seeds = tuple(archive["seeds"])
    matches = replay_matches(x, y, archive)
    return {
        "format": FORMAT,
        "problem": job["problem"],
        "source": job["source"],
        "recovery": "recomputed from the deterministic split; not archived at run time",
        "input_sha256": _file_digest(Path(None)),
        "cleaned_rows": int(len(y)),
        "cleaned_sha256": _digest(np.ascontiguousarray(x)),
        "labels_sha256": _digest(np.asarray(y, dtype=np.int64)),
        "seeds": list(seeds),
        "partitions": partitions(x, y, seeds),
        "archived_rows": archive.get("rows"),
        "archive_replay": {"detector": "zscore", "seeds_matching": matches, "all": all(matches)},
        "report_rows_out": report.get("rows_out"),
    }


def x_recover__mutmut_55(job: dict[str, Any], archive: dict[str, Any]) -> dict[str, Any]:
    if job["source"] == "adbench":
        x, y, report = lb.load_adbench(job["name"], Path(job["path"]))
    else:
        x, y, report = lb.load_uci(job["meta"], Path(job["path"]))
    seeds = tuple(archive["seeds"])
    matches = replay_matches(x, y, archive)
    return {
        "format": FORMAT,
        "problem": job["problem"],
        "source": job["source"],
        "recovery": "recomputed from the deterministic split; not archived at run time",
        "input_sha256": _file_digest(Path(job["XXpathXX"])),
        "cleaned_rows": int(len(y)),
        "cleaned_sha256": _digest(np.ascontiguousarray(x)),
        "labels_sha256": _digest(np.asarray(y, dtype=np.int64)),
        "seeds": list(seeds),
        "partitions": partitions(x, y, seeds),
        "archived_rows": archive.get("rows"),
        "archive_replay": {"detector": "zscore", "seeds_matching": matches, "all": all(matches)},
        "report_rows_out": report.get("rows_out"),
    }


def x_recover__mutmut_56(job: dict[str, Any], archive: dict[str, Any]) -> dict[str, Any]:
    if job["source"] == "adbench":
        x, y, report = lb.load_adbench(job["name"], Path(job["path"]))
    else:
        x, y, report = lb.load_uci(job["meta"], Path(job["path"]))
    seeds = tuple(archive["seeds"])
    matches = replay_matches(x, y, archive)
    return {
        "format": FORMAT,
        "problem": job["problem"],
        "source": job["source"],
        "recovery": "recomputed from the deterministic split; not archived at run time",
        "input_sha256": _file_digest(Path(job["PATH"])),
        "cleaned_rows": int(len(y)),
        "cleaned_sha256": _digest(np.ascontiguousarray(x)),
        "labels_sha256": _digest(np.asarray(y, dtype=np.int64)),
        "seeds": list(seeds),
        "partitions": partitions(x, y, seeds),
        "archived_rows": archive.get("rows"),
        "archive_replay": {"detector": "zscore", "seeds_matching": matches, "all": all(matches)},
        "report_rows_out": report.get("rows_out"),
    }


def x_recover__mutmut_57(job: dict[str, Any], archive: dict[str, Any]) -> dict[str, Any]:
    if job["source"] == "adbench":
        x, y, report = lb.load_adbench(job["name"], Path(job["path"]))
    else:
        x, y, report = lb.load_uci(job["meta"], Path(job["path"]))
    seeds = tuple(archive["seeds"])
    matches = replay_matches(x, y, archive)
    return {
        "format": FORMAT,
        "problem": job["problem"],
        "source": job["source"],
        "recovery": "recomputed from the deterministic split; not archived at run time",
        "input_sha256": _file_digest(Path(job["path"])),
        "XXcleaned_rowsXX": int(len(y)),
        "cleaned_sha256": _digest(np.ascontiguousarray(x)),
        "labels_sha256": _digest(np.asarray(y, dtype=np.int64)),
        "seeds": list(seeds),
        "partitions": partitions(x, y, seeds),
        "archived_rows": archive.get("rows"),
        "archive_replay": {"detector": "zscore", "seeds_matching": matches, "all": all(matches)},
        "report_rows_out": report.get("rows_out"),
    }


def x_recover__mutmut_58(job: dict[str, Any], archive: dict[str, Any]) -> dict[str, Any]:
    if job["source"] == "adbench":
        x, y, report = lb.load_adbench(job["name"], Path(job["path"]))
    else:
        x, y, report = lb.load_uci(job["meta"], Path(job["path"]))
    seeds = tuple(archive["seeds"])
    matches = replay_matches(x, y, archive)
    return {
        "format": FORMAT,
        "problem": job["problem"],
        "source": job["source"],
        "recovery": "recomputed from the deterministic split; not archived at run time",
        "input_sha256": _file_digest(Path(job["path"])),
        "CLEANED_ROWS": int(len(y)),
        "cleaned_sha256": _digest(np.ascontiguousarray(x)),
        "labels_sha256": _digest(np.asarray(y, dtype=np.int64)),
        "seeds": list(seeds),
        "partitions": partitions(x, y, seeds),
        "archived_rows": archive.get("rows"),
        "archive_replay": {"detector": "zscore", "seeds_matching": matches, "all": all(matches)},
        "report_rows_out": report.get("rows_out"),
    }


def x_recover__mutmut_59(job: dict[str, Any], archive: dict[str, Any]) -> dict[str, Any]:
    if job["source"] == "adbench":
        x, y, report = lb.load_adbench(job["name"], Path(job["path"]))
    else:
        x, y, report = lb.load_uci(job["meta"], Path(job["path"]))
    seeds = tuple(archive["seeds"])
    matches = replay_matches(x, y, archive)
    return {
        "format": FORMAT,
        "problem": job["problem"],
        "source": job["source"],
        "recovery": "recomputed from the deterministic split; not archived at run time",
        "input_sha256": _file_digest(Path(job["path"])),
        "cleaned_rows": int(None),
        "cleaned_sha256": _digest(np.ascontiguousarray(x)),
        "labels_sha256": _digest(np.asarray(y, dtype=np.int64)),
        "seeds": list(seeds),
        "partitions": partitions(x, y, seeds),
        "archived_rows": archive.get("rows"),
        "archive_replay": {"detector": "zscore", "seeds_matching": matches, "all": all(matches)},
        "report_rows_out": report.get("rows_out"),
    }


def x_recover__mutmut_60(job: dict[str, Any], archive: dict[str, Any]) -> dict[str, Any]:
    if job["source"] == "adbench":
        x, y, report = lb.load_adbench(job["name"], Path(job["path"]))
    else:
        x, y, report = lb.load_uci(job["meta"], Path(job["path"]))
    seeds = tuple(archive["seeds"])
    matches = replay_matches(x, y, archive)
    return {
        "format": FORMAT,
        "problem": job["problem"],
        "source": job["source"],
        "recovery": "recomputed from the deterministic split; not archived at run time",
        "input_sha256": _file_digest(Path(job["path"])),
        "cleaned_rows": int(len(y)),
        "XXcleaned_sha256XX": _digest(np.ascontiguousarray(x)),
        "labels_sha256": _digest(np.asarray(y, dtype=np.int64)),
        "seeds": list(seeds),
        "partitions": partitions(x, y, seeds),
        "archived_rows": archive.get("rows"),
        "archive_replay": {"detector": "zscore", "seeds_matching": matches, "all": all(matches)},
        "report_rows_out": report.get("rows_out"),
    }


def x_recover__mutmut_61(job: dict[str, Any], archive: dict[str, Any]) -> dict[str, Any]:
    if job["source"] == "adbench":
        x, y, report = lb.load_adbench(job["name"], Path(job["path"]))
    else:
        x, y, report = lb.load_uci(job["meta"], Path(job["path"]))
    seeds = tuple(archive["seeds"])
    matches = replay_matches(x, y, archive)
    return {
        "format": FORMAT,
        "problem": job["problem"],
        "source": job["source"],
        "recovery": "recomputed from the deterministic split; not archived at run time",
        "input_sha256": _file_digest(Path(job["path"])),
        "cleaned_rows": int(len(y)),
        "CLEANED_SHA256": _digest(np.ascontiguousarray(x)),
        "labels_sha256": _digest(np.asarray(y, dtype=np.int64)),
        "seeds": list(seeds),
        "partitions": partitions(x, y, seeds),
        "archived_rows": archive.get("rows"),
        "archive_replay": {"detector": "zscore", "seeds_matching": matches, "all": all(matches)},
        "report_rows_out": report.get("rows_out"),
    }


def x_recover__mutmut_62(job: dict[str, Any], archive: dict[str, Any]) -> dict[str, Any]:
    if job["source"] == "adbench":
        x, y, report = lb.load_adbench(job["name"], Path(job["path"]))
    else:
        x, y, report = lb.load_uci(job["meta"], Path(job["path"]))
    seeds = tuple(archive["seeds"])
    matches = replay_matches(x, y, archive)
    return {
        "format": FORMAT,
        "problem": job["problem"],
        "source": job["source"],
        "recovery": "recomputed from the deterministic split; not archived at run time",
        "input_sha256": _file_digest(Path(job["path"])),
        "cleaned_rows": int(len(y)),
        "cleaned_sha256": _digest(None),
        "labels_sha256": _digest(np.asarray(y, dtype=np.int64)),
        "seeds": list(seeds),
        "partitions": partitions(x, y, seeds),
        "archived_rows": archive.get("rows"),
        "archive_replay": {"detector": "zscore", "seeds_matching": matches, "all": all(matches)},
        "report_rows_out": report.get("rows_out"),
    }


def x_recover__mutmut_63(job: dict[str, Any], archive: dict[str, Any]) -> dict[str, Any]:
    if job["source"] == "adbench":
        x, y, report = lb.load_adbench(job["name"], Path(job["path"]))
    else:
        x, y, report = lb.load_uci(job["meta"], Path(job["path"]))
    seeds = tuple(archive["seeds"])
    matches = replay_matches(x, y, archive)
    return {
        "format": FORMAT,
        "problem": job["problem"],
        "source": job["source"],
        "recovery": "recomputed from the deterministic split; not archived at run time",
        "input_sha256": _file_digest(Path(job["path"])),
        "cleaned_rows": int(len(y)),
        "cleaned_sha256": _digest(np.ascontiguousarray(None)),
        "labels_sha256": _digest(np.asarray(y, dtype=np.int64)),
        "seeds": list(seeds),
        "partitions": partitions(x, y, seeds),
        "archived_rows": archive.get("rows"),
        "archive_replay": {"detector": "zscore", "seeds_matching": matches, "all": all(matches)},
        "report_rows_out": report.get("rows_out"),
    }


def x_recover__mutmut_64(job: dict[str, Any], archive: dict[str, Any]) -> dict[str, Any]:
    if job["source"] == "adbench":
        x, y, report = lb.load_adbench(job["name"], Path(job["path"]))
    else:
        x, y, report = lb.load_uci(job["meta"], Path(job["path"]))
    seeds = tuple(archive["seeds"])
    matches = replay_matches(x, y, archive)
    return {
        "format": FORMAT,
        "problem": job["problem"],
        "source": job["source"],
        "recovery": "recomputed from the deterministic split; not archived at run time",
        "input_sha256": _file_digest(Path(job["path"])),
        "cleaned_rows": int(len(y)),
        "cleaned_sha256": _digest(np.ascontiguousarray(x)),
        "XXlabels_sha256XX": _digest(np.asarray(y, dtype=np.int64)),
        "seeds": list(seeds),
        "partitions": partitions(x, y, seeds),
        "archived_rows": archive.get("rows"),
        "archive_replay": {"detector": "zscore", "seeds_matching": matches, "all": all(matches)},
        "report_rows_out": report.get("rows_out"),
    }


def x_recover__mutmut_65(job: dict[str, Any], archive: dict[str, Any]) -> dict[str, Any]:
    if job["source"] == "adbench":
        x, y, report = lb.load_adbench(job["name"], Path(job["path"]))
    else:
        x, y, report = lb.load_uci(job["meta"], Path(job["path"]))
    seeds = tuple(archive["seeds"])
    matches = replay_matches(x, y, archive)
    return {
        "format": FORMAT,
        "problem": job["problem"],
        "source": job["source"],
        "recovery": "recomputed from the deterministic split; not archived at run time",
        "input_sha256": _file_digest(Path(job["path"])),
        "cleaned_rows": int(len(y)),
        "cleaned_sha256": _digest(np.ascontiguousarray(x)),
        "LABELS_SHA256": _digest(np.asarray(y, dtype=np.int64)),
        "seeds": list(seeds),
        "partitions": partitions(x, y, seeds),
        "archived_rows": archive.get("rows"),
        "archive_replay": {"detector": "zscore", "seeds_matching": matches, "all": all(matches)},
        "report_rows_out": report.get("rows_out"),
    }


def x_recover__mutmut_66(job: dict[str, Any], archive: dict[str, Any]) -> dict[str, Any]:
    if job["source"] == "adbench":
        x, y, report = lb.load_adbench(job["name"], Path(job["path"]))
    else:
        x, y, report = lb.load_uci(job["meta"], Path(job["path"]))
    seeds = tuple(archive["seeds"])
    matches = replay_matches(x, y, archive)
    return {
        "format": FORMAT,
        "problem": job["problem"],
        "source": job["source"],
        "recovery": "recomputed from the deterministic split; not archived at run time",
        "input_sha256": _file_digest(Path(job["path"])),
        "cleaned_rows": int(len(y)),
        "cleaned_sha256": _digest(np.ascontiguousarray(x)),
        "labels_sha256": _digest(None),
        "seeds": list(seeds),
        "partitions": partitions(x, y, seeds),
        "archived_rows": archive.get("rows"),
        "archive_replay": {"detector": "zscore", "seeds_matching": matches, "all": all(matches)},
        "report_rows_out": report.get("rows_out"),
    }


def x_recover__mutmut_67(job: dict[str, Any], archive: dict[str, Any]) -> dict[str, Any]:
    if job["source"] == "adbench":
        x, y, report = lb.load_adbench(job["name"], Path(job["path"]))
    else:
        x, y, report = lb.load_uci(job["meta"], Path(job["path"]))
    seeds = tuple(archive["seeds"])
    matches = replay_matches(x, y, archive)
    return {
        "format": FORMAT,
        "problem": job["problem"],
        "source": job["source"],
        "recovery": "recomputed from the deterministic split; not archived at run time",
        "input_sha256": _file_digest(Path(job["path"])),
        "cleaned_rows": int(len(y)),
        "cleaned_sha256": _digest(np.ascontiguousarray(x)),
        "labels_sha256": _digest(np.asarray(None, dtype=np.int64)),
        "seeds": list(seeds),
        "partitions": partitions(x, y, seeds),
        "archived_rows": archive.get("rows"),
        "archive_replay": {"detector": "zscore", "seeds_matching": matches, "all": all(matches)},
        "report_rows_out": report.get("rows_out"),
    }


def x_recover__mutmut_68(job: dict[str, Any], archive: dict[str, Any]) -> dict[str, Any]:
    if job["source"] == "adbench":
        x, y, report = lb.load_adbench(job["name"], Path(job["path"]))
    else:
        x, y, report = lb.load_uci(job["meta"], Path(job["path"]))
    seeds = tuple(archive["seeds"])
    matches = replay_matches(x, y, archive)
    return {
        "format": FORMAT,
        "problem": job["problem"],
        "source": job["source"],
        "recovery": "recomputed from the deterministic split; not archived at run time",
        "input_sha256": _file_digest(Path(job["path"])),
        "cleaned_rows": int(len(y)),
        "cleaned_sha256": _digest(np.ascontiguousarray(x)),
        "labels_sha256": _digest(np.asarray(y, dtype=None)),
        "seeds": list(seeds),
        "partitions": partitions(x, y, seeds),
        "archived_rows": archive.get("rows"),
        "archive_replay": {"detector": "zscore", "seeds_matching": matches, "all": all(matches)},
        "report_rows_out": report.get("rows_out"),
    }


def x_recover__mutmut_69(job: dict[str, Any], archive: dict[str, Any]) -> dict[str, Any]:
    if job["source"] == "adbench":
        x, y, report = lb.load_adbench(job["name"], Path(job["path"]))
    else:
        x, y, report = lb.load_uci(job["meta"], Path(job["path"]))
    seeds = tuple(archive["seeds"])
    matches = replay_matches(x, y, archive)
    return {
        "format": FORMAT,
        "problem": job["problem"],
        "source": job["source"],
        "recovery": "recomputed from the deterministic split; not archived at run time",
        "input_sha256": _file_digest(Path(job["path"])),
        "cleaned_rows": int(len(y)),
        "cleaned_sha256": _digest(np.ascontiguousarray(x)),
        "labels_sha256": _digest(np.asarray(dtype=np.int64)),
        "seeds": list(seeds),
        "partitions": partitions(x, y, seeds),
        "archived_rows": archive.get("rows"),
        "archive_replay": {"detector": "zscore", "seeds_matching": matches, "all": all(matches)},
        "report_rows_out": report.get("rows_out"),
    }


def x_recover__mutmut_70(job: dict[str, Any], archive: dict[str, Any]) -> dict[str, Any]:
    if job["source"] == "adbench":
        x, y, report = lb.load_adbench(job["name"], Path(job["path"]))
    else:
        x, y, report = lb.load_uci(job["meta"], Path(job["path"]))
    seeds = tuple(archive["seeds"])
    matches = replay_matches(x, y, archive)
    return {
        "format": FORMAT,
        "problem": job["problem"],
        "source": job["source"],
        "recovery": "recomputed from the deterministic split; not archived at run time",
        "input_sha256": _file_digest(Path(job["path"])),
        "cleaned_rows": int(len(y)),
        "cleaned_sha256": _digest(np.ascontiguousarray(x)),
        "labels_sha256": _digest(np.asarray(y, )),
        "seeds": list(seeds),
        "partitions": partitions(x, y, seeds),
        "archived_rows": archive.get("rows"),
        "archive_replay": {"detector": "zscore", "seeds_matching": matches, "all": all(matches)},
        "report_rows_out": report.get("rows_out"),
    }


def x_recover__mutmut_71(job: dict[str, Any], archive: dict[str, Any]) -> dict[str, Any]:
    if job["source"] == "adbench":
        x, y, report = lb.load_adbench(job["name"], Path(job["path"]))
    else:
        x, y, report = lb.load_uci(job["meta"], Path(job["path"]))
    seeds = tuple(archive["seeds"])
    matches = replay_matches(x, y, archive)
    return {
        "format": FORMAT,
        "problem": job["problem"],
        "source": job["source"],
        "recovery": "recomputed from the deterministic split; not archived at run time",
        "input_sha256": _file_digest(Path(job["path"])),
        "cleaned_rows": int(len(y)),
        "cleaned_sha256": _digest(np.ascontiguousarray(x)),
        "labels_sha256": _digest(np.asarray(y, dtype=np.int64)),
        "XXseedsXX": list(seeds),
        "partitions": partitions(x, y, seeds),
        "archived_rows": archive.get("rows"),
        "archive_replay": {"detector": "zscore", "seeds_matching": matches, "all": all(matches)},
        "report_rows_out": report.get("rows_out"),
    }


def x_recover__mutmut_72(job: dict[str, Any], archive: dict[str, Any]) -> dict[str, Any]:
    if job["source"] == "adbench":
        x, y, report = lb.load_adbench(job["name"], Path(job["path"]))
    else:
        x, y, report = lb.load_uci(job["meta"], Path(job["path"]))
    seeds = tuple(archive["seeds"])
    matches = replay_matches(x, y, archive)
    return {
        "format": FORMAT,
        "problem": job["problem"],
        "source": job["source"],
        "recovery": "recomputed from the deterministic split; not archived at run time",
        "input_sha256": _file_digest(Path(job["path"])),
        "cleaned_rows": int(len(y)),
        "cleaned_sha256": _digest(np.ascontiguousarray(x)),
        "labels_sha256": _digest(np.asarray(y, dtype=np.int64)),
        "SEEDS": list(seeds),
        "partitions": partitions(x, y, seeds),
        "archived_rows": archive.get("rows"),
        "archive_replay": {"detector": "zscore", "seeds_matching": matches, "all": all(matches)},
        "report_rows_out": report.get("rows_out"),
    }


def x_recover__mutmut_73(job: dict[str, Any], archive: dict[str, Any]) -> dict[str, Any]:
    if job["source"] == "adbench":
        x, y, report = lb.load_adbench(job["name"], Path(job["path"]))
    else:
        x, y, report = lb.load_uci(job["meta"], Path(job["path"]))
    seeds = tuple(archive["seeds"])
    matches = replay_matches(x, y, archive)
    return {
        "format": FORMAT,
        "problem": job["problem"],
        "source": job["source"],
        "recovery": "recomputed from the deterministic split; not archived at run time",
        "input_sha256": _file_digest(Path(job["path"])),
        "cleaned_rows": int(len(y)),
        "cleaned_sha256": _digest(np.ascontiguousarray(x)),
        "labels_sha256": _digest(np.asarray(y, dtype=np.int64)),
        "seeds": list(None),
        "partitions": partitions(x, y, seeds),
        "archived_rows": archive.get("rows"),
        "archive_replay": {"detector": "zscore", "seeds_matching": matches, "all": all(matches)},
        "report_rows_out": report.get("rows_out"),
    }


def x_recover__mutmut_74(job: dict[str, Any], archive: dict[str, Any]) -> dict[str, Any]:
    if job["source"] == "adbench":
        x, y, report = lb.load_adbench(job["name"], Path(job["path"]))
    else:
        x, y, report = lb.load_uci(job["meta"], Path(job["path"]))
    seeds = tuple(archive["seeds"])
    matches = replay_matches(x, y, archive)
    return {
        "format": FORMAT,
        "problem": job["problem"],
        "source": job["source"],
        "recovery": "recomputed from the deterministic split; not archived at run time",
        "input_sha256": _file_digest(Path(job["path"])),
        "cleaned_rows": int(len(y)),
        "cleaned_sha256": _digest(np.ascontiguousarray(x)),
        "labels_sha256": _digest(np.asarray(y, dtype=np.int64)),
        "seeds": list(seeds),
        "XXpartitionsXX": partitions(x, y, seeds),
        "archived_rows": archive.get("rows"),
        "archive_replay": {"detector": "zscore", "seeds_matching": matches, "all": all(matches)},
        "report_rows_out": report.get("rows_out"),
    }


def x_recover__mutmut_75(job: dict[str, Any], archive: dict[str, Any]) -> dict[str, Any]:
    if job["source"] == "adbench":
        x, y, report = lb.load_adbench(job["name"], Path(job["path"]))
    else:
        x, y, report = lb.load_uci(job["meta"], Path(job["path"]))
    seeds = tuple(archive["seeds"])
    matches = replay_matches(x, y, archive)
    return {
        "format": FORMAT,
        "problem": job["problem"],
        "source": job["source"],
        "recovery": "recomputed from the deterministic split; not archived at run time",
        "input_sha256": _file_digest(Path(job["path"])),
        "cleaned_rows": int(len(y)),
        "cleaned_sha256": _digest(np.ascontiguousarray(x)),
        "labels_sha256": _digest(np.asarray(y, dtype=np.int64)),
        "seeds": list(seeds),
        "PARTITIONS": partitions(x, y, seeds),
        "archived_rows": archive.get("rows"),
        "archive_replay": {"detector": "zscore", "seeds_matching": matches, "all": all(matches)},
        "report_rows_out": report.get("rows_out"),
    }


def x_recover__mutmut_76(job: dict[str, Any], archive: dict[str, Any]) -> dict[str, Any]:
    if job["source"] == "adbench":
        x, y, report = lb.load_adbench(job["name"], Path(job["path"]))
    else:
        x, y, report = lb.load_uci(job["meta"], Path(job["path"]))
    seeds = tuple(archive["seeds"])
    matches = replay_matches(x, y, archive)
    return {
        "format": FORMAT,
        "problem": job["problem"],
        "source": job["source"],
        "recovery": "recomputed from the deterministic split; not archived at run time",
        "input_sha256": _file_digest(Path(job["path"])),
        "cleaned_rows": int(len(y)),
        "cleaned_sha256": _digest(np.ascontiguousarray(x)),
        "labels_sha256": _digest(np.asarray(y, dtype=np.int64)),
        "seeds": list(seeds),
        "partitions": partitions(None, y, seeds),
        "archived_rows": archive.get("rows"),
        "archive_replay": {"detector": "zscore", "seeds_matching": matches, "all": all(matches)},
        "report_rows_out": report.get("rows_out"),
    }


def x_recover__mutmut_77(job: dict[str, Any], archive: dict[str, Any]) -> dict[str, Any]:
    if job["source"] == "adbench":
        x, y, report = lb.load_adbench(job["name"], Path(job["path"]))
    else:
        x, y, report = lb.load_uci(job["meta"], Path(job["path"]))
    seeds = tuple(archive["seeds"])
    matches = replay_matches(x, y, archive)
    return {
        "format": FORMAT,
        "problem": job["problem"],
        "source": job["source"],
        "recovery": "recomputed from the deterministic split; not archived at run time",
        "input_sha256": _file_digest(Path(job["path"])),
        "cleaned_rows": int(len(y)),
        "cleaned_sha256": _digest(np.ascontiguousarray(x)),
        "labels_sha256": _digest(np.asarray(y, dtype=np.int64)),
        "seeds": list(seeds),
        "partitions": partitions(x, None, seeds),
        "archived_rows": archive.get("rows"),
        "archive_replay": {"detector": "zscore", "seeds_matching": matches, "all": all(matches)},
        "report_rows_out": report.get("rows_out"),
    }


def x_recover__mutmut_78(job: dict[str, Any], archive: dict[str, Any]) -> dict[str, Any]:
    if job["source"] == "adbench":
        x, y, report = lb.load_adbench(job["name"], Path(job["path"]))
    else:
        x, y, report = lb.load_uci(job["meta"], Path(job["path"]))
    seeds = tuple(archive["seeds"])
    matches = replay_matches(x, y, archive)
    return {
        "format": FORMAT,
        "problem": job["problem"],
        "source": job["source"],
        "recovery": "recomputed from the deterministic split; not archived at run time",
        "input_sha256": _file_digest(Path(job["path"])),
        "cleaned_rows": int(len(y)),
        "cleaned_sha256": _digest(np.ascontiguousarray(x)),
        "labels_sha256": _digest(np.asarray(y, dtype=np.int64)),
        "seeds": list(seeds),
        "partitions": partitions(x, y, None),
        "archived_rows": archive.get("rows"),
        "archive_replay": {"detector": "zscore", "seeds_matching": matches, "all": all(matches)},
        "report_rows_out": report.get("rows_out"),
    }


def x_recover__mutmut_79(job: dict[str, Any], archive: dict[str, Any]) -> dict[str, Any]:
    if job["source"] == "adbench":
        x, y, report = lb.load_adbench(job["name"], Path(job["path"]))
    else:
        x, y, report = lb.load_uci(job["meta"], Path(job["path"]))
    seeds = tuple(archive["seeds"])
    matches = replay_matches(x, y, archive)
    return {
        "format": FORMAT,
        "problem": job["problem"],
        "source": job["source"],
        "recovery": "recomputed from the deterministic split; not archived at run time",
        "input_sha256": _file_digest(Path(job["path"])),
        "cleaned_rows": int(len(y)),
        "cleaned_sha256": _digest(np.ascontiguousarray(x)),
        "labels_sha256": _digest(np.asarray(y, dtype=np.int64)),
        "seeds": list(seeds),
        "partitions": partitions(y, seeds),
        "archived_rows": archive.get("rows"),
        "archive_replay": {"detector": "zscore", "seeds_matching": matches, "all": all(matches)},
        "report_rows_out": report.get("rows_out"),
    }


def x_recover__mutmut_80(job: dict[str, Any], archive: dict[str, Any]) -> dict[str, Any]:
    if job["source"] == "adbench":
        x, y, report = lb.load_adbench(job["name"], Path(job["path"]))
    else:
        x, y, report = lb.load_uci(job["meta"], Path(job["path"]))
    seeds = tuple(archive["seeds"])
    matches = replay_matches(x, y, archive)
    return {
        "format": FORMAT,
        "problem": job["problem"],
        "source": job["source"],
        "recovery": "recomputed from the deterministic split; not archived at run time",
        "input_sha256": _file_digest(Path(job["path"])),
        "cleaned_rows": int(len(y)),
        "cleaned_sha256": _digest(np.ascontiguousarray(x)),
        "labels_sha256": _digest(np.asarray(y, dtype=np.int64)),
        "seeds": list(seeds),
        "partitions": partitions(x, seeds),
        "archived_rows": archive.get("rows"),
        "archive_replay": {"detector": "zscore", "seeds_matching": matches, "all": all(matches)},
        "report_rows_out": report.get("rows_out"),
    }


def x_recover__mutmut_81(job: dict[str, Any], archive: dict[str, Any]) -> dict[str, Any]:
    if job["source"] == "adbench":
        x, y, report = lb.load_adbench(job["name"], Path(job["path"]))
    else:
        x, y, report = lb.load_uci(job["meta"], Path(job["path"]))
    seeds = tuple(archive["seeds"])
    matches = replay_matches(x, y, archive)
    return {
        "format": FORMAT,
        "problem": job["problem"],
        "source": job["source"],
        "recovery": "recomputed from the deterministic split; not archived at run time",
        "input_sha256": _file_digest(Path(job["path"])),
        "cleaned_rows": int(len(y)),
        "cleaned_sha256": _digest(np.ascontiguousarray(x)),
        "labels_sha256": _digest(np.asarray(y, dtype=np.int64)),
        "seeds": list(seeds),
        "partitions": partitions(x, y, ),
        "archived_rows": archive.get("rows"),
        "archive_replay": {"detector": "zscore", "seeds_matching": matches, "all": all(matches)},
        "report_rows_out": report.get("rows_out"),
    }


def x_recover__mutmut_82(job: dict[str, Any], archive: dict[str, Any]) -> dict[str, Any]:
    if job["source"] == "adbench":
        x, y, report = lb.load_adbench(job["name"], Path(job["path"]))
    else:
        x, y, report = lb.load_uci(job["meta"], Path(job["path"]))
    seeds = tuple(archive["seeds"])
    matches = replay_matches(x, y, archive)
    return {
        "format": FORMAT,
        "problem": job["problem"],
        "source": job["source"],
        "recovery": "recomputed from the deterministic split; not archived at run time",
        "input_sha256": _file_digest(Path(job["path"])),
        "cleaned_rows": int(len(y)),
        "cleaned_sha256": _digest(np.ascontiguousarray(x)),
        "labels_sha256": _digest(np.asarray(y, dtype=np.int64)),
        "seeds": list(seeds),
        "partitions": partitions(x, y, seeds),
        "XXarchived_rowsXX": archive.get("rows"),
        "archive_replay": {"detector": "zscore", "seeds_matching": matches, "all": all(matches)},
        "report_rows_out": report.get("rows_out"),
    }


def x_recover__mutmut_83(job: dict[str, Any], archive: dict[str, Any]) -> dict[str, Any]:
    if job["source"] == "adbench":
        x, y, report = lb.load_adbench(job["name"], Path(job["path"]))
    else:
        x, y, report = lb.load_uci(job["meta"], Path(job["path"]))
    seeds = tuple(archive["seeds"])
    matches = replay_matches(x, y, archive)
    return {
        "format": FORMAT,
        "problem": job["problem"],
        "source": job["source"],
        "recovery": "recomputed from the deterministic split; not archived at run time",
        "input_sha256": _file_digest(Path(job["path"])),
        "cleaned_rows": int(len(y)),
        "cleaned_sha256": _digest(np.ascontiguousarray(x)),
        "labels_sha256": _digest(np.asarray(y, dtype=np.int64)),
        "seeds": list(seeds),
        "partitions": partitions(x, y, seeds),
        "ARCHIVED_ROWS": archive.get("rows"),
        "archive_replay": {"detector": "zscore", "seeds_matching": matches, "all": all(matches)},
        "report_rows_out": report.get("rows_out"),
    }


def x_recover__mutmut_84(job: dict[str, Any], archive: dict[str, Any]) -> dict[str, Any]:
    if job["source"] == "adbench":
        x, y, report = lb.load_adbench(job["name"], Path(job["path"]))
    else:
        x, y, report = lb.load_uci(job["meta"], Path(job["path"]))
    seeds = tuple(archive["seeds"])
    matches = replay_matches(x, y, archive)
    return {
        "format": FORMAT,
        "problem": job["problem"],
        "source": job["source"],
        "recovery": "recomputed from the deterministic split; not archived at run time",
        "input_sha256": _file_digest(Path(job["path"])),
        "cleaned_rows": int(len(y)),
        "cleaned_sha256": _digest(np.ascontiguousarray(x)),
        "labels_sha256": _digest(np.asarray(y, dtype=np.int64)),
        "seeds": list(seeds),
        "partitions": partitions(x, y, seeds),
        "archived_rows": archive.get(None),
        "archive_replay": {"detector": "zscore", "seeds_matching": matches, "all": all(matches)},
        "report_rows_out": report.get("rows_out"),
    }


def x_recover__mutmut_85(job: dict[str, Any], archive: dict[str, Any]) -> dict[str, Any]:
    if job["source"] == "adbench":
        x, y, report = lb.load_adbench(job["name"], Path(job["path"]))
    else:
        x, y, report = lb.load_uci(job["meta"], Path(job["path"]))
    seeds = tuple(archive["seeds"])
    matches = replay_matches(x, y, archive)
    return {
        "format": FORMAT,
        "problem": job["problem"],
        "source": job["source"],
        "recovery": "recomputed from the deterministic split; not archived at run time",
        "input_sha256": _file_digest(Path(job["path"])),
        "cleaned_rows": int(len(y)),
        "cleaned_sha256": _digest(np.ascontiguousarray(x)),
        "labels_sha256": _digest(np.asarray(y, dtype=np.int64)),
        "seeds": list(seeds),
        "partitions": partitions(x, y, seeds),
        "archived_rows": archive.get("XXrowsXX"),
        "archive_replay": {"detector": "zscore", "seeds_matching": matches, "all": all(matches)},
        "report_rows_out": report.get("rows_out"),
    }


def x_recover__mutmut_86(job: dict[str, Any], archive: dict[str, Any]) -> dict[str, Any]:
    if job["source"] == "adbench":
        x, y, report = lb.load_adbench(job["name"], Path(job["path"]))
    else:
        x, y, report = lb.load_uci(job["meta"], Path(job["path"]))
    seeds = tuple(archive["seeds"])
    matches = replay_matches(x, y, archive)
    return {
        "format": FORMAT,
        "problem": job["problem"],
        "source": job["source"],
        "recovery": "recomputed from the deterministic split; not archived at run time",
        "input_sha256": _file_digest(Path(job["path"])),
        "cleaned_rows": int(len(y)),
        "cleaned_sha256": _digest(np.ascontiguousarray(x)),
        "labels_sha256": _digest(np.asarray(y, dtype=np.int64)),
        "seeds": list(seeds),
        "partitions": partitions(x, y, seeds),
        "archived_rows": archive.get("ROWS"),
        "archive_replay": {"detector": "zscore", "seeds_matching": matches, "all": all(matches)},
        "report_rows_out": report.get("rows_out"),
    }


def x_recover__mutmut_87(job: dict[str, Any], archive: dict[str, Any]) -> dict[str, Any]:
    if job["source"] == "adbench":
        x, y, report = lb.load_adbench(job["name"], Path(job["path"]))
    else:
        x, y, report = lb.load_uci(job["meta"], Path(job["path"]))
    seeds = tuple(archive["seeds"])
    matches = replay_matches(x, y, archive)
    return {
        "format": FORMAT,
        "problem": job["problem"],
        "source": job["source"],
        "recovery": "recomputed from the deterministic split; not archived at run time",
        "input_sha256": _file_digest(Path(job["path"])),
        "cleaned_rows": int(len(y)),
        "cleaned_sha256": _digest(np.ascontiguousarray(x)),
        "labels_sha256": _digest(np.asarray(y, dtype=np.int64)),
        "seeds": list(seeds),
        "partitions": partitions(x, y, seeds),
        "archived_rows": archive.get("rows"),
        "XXarchive_replayXX": {"detector": "zscore", "seeds_matching": matches, "all": all(matches)},
        "report_rows_out": report.get("rows_out"),
    }


def x_recover__mutmut_88(job: dict[str, Any], archive: dict[str, Any]) -> dict[str, Any]:
    if job["source"] == "adbench":
        x, y, report = lb.load_adbench(job["name"], Path(job["path"]))
    else:
        x, y, report = lb.load_uci(job["meta"], Path(job["path"]))
    seeds = tuple(archive["seeds"])
    matches = replay_matches(x, y, archive)
    return {
        "format": FORMAT,
        "problem": job["problem"],
        "source": job["source"],
        "recovery": "recomputed from the deterministic split; not archived at run time",
        "input_sha256": _file_digest(Path(job["path"])),
        "cleaned_rows": int(len(y)),
        "cleaned_sha256": _digest(np.ascontiguousarray(x)),
        "labels_sha256": _digest(np.asarray(y, dtype=np.int64)),
        "seeds": list(seeds),
        "partitions": partitions(x, y, seeds),
        "archived_rows": archive.get("rows"),
        "ARCHIVE_REPLAY": {"detector": "zscore", "seeds_matching": matches, "all": all(matches)},
        "report_rows_out": report.get("rows_out"),
    }


def x_recover__mutmut_89(job: dict[str, Any], archive: dict[str, Any]) -> dict[str, Any]:
    if job["source"] == "adbench":
        x, y, report = lb.load_adbench(job["name"], Path(job["path"]))
    else:
        x, y, report = lb.load_uci(job["meta"], Path(job["path"]))
    seeds = tuple(archive["seeds"])
    matches = replay_matches(x, y, archive)
    return {
        "format": FORMAT,
        "problem": job["problem"],
        "source": job["source"],
        "recovery": "recomputed from the deterministic split; not archived at run time",
        "input_sha256": _file_digest(Path(job["path"])),
        "cleaned_rows": int(len(y)),
        "cleaned_sha256": _digest(np.ascontiguousarray(x)),
        "labels_sha256": _digest(np.asarray(y, dtype=np.int64)),
        "seeds": list(seeds),
        "partitions": partitions(x, y, seeds),
        "archived_rows": archive.get("rows"),
        "archive_replay": {"XXdetectorXX": "zscore", "seeds_matching": matches, "all": all(matches)},
        "report_rows_out": report.get("rows_out"),
    }


def x_recover__mutmut_90(job: dict[str, Any], archive: dict[str, Any]) -> dict[str, Any]:
    if job["source"] == "adbench":
        x, y, report = lb.load_adbench(job["name"], Path(job["path"]))
    else:
        x, y, report = lb.load_uci(job["meta"], Path(job["path"]))
    seeds = tuple(archive["seeds"])
    matches = replay_matches(x, y, archive)
    return {
        "format": FORMAT,
        "problem": job["problem"],
        "source": job["source"],
        "recovery": "recomputed from the deterministic split; not archived at run time",
        "input_sha256": _file_digest(Path(job["path"])),
        "cleaned_rows": int(len(y)),
        "cleaned_sha256": _digest(np.ascontiguousarray(x)),
        "labels_sha256": _digest(np.asarray(y, dtype=np.int64)),
        "seeds": list(seeds),
        "partitions": partitions(x, y, seeds),
        "archived_rows": archive.get("rows"),
        "archive_replay": {"DETECTOR": "zscore", "seeds_matching": matches, "all": all(matches)},
        "report_rows_out": report.get("rows_out"),
    }


def x_recover__mutmut_91(job: dict[str, Any], archive: dict[str, Any]) -> dict[str, Any]:
    if job["source"] == "adbench":
        x, y, report = lb.load_adbench(job["name"], Path(job["path"]))
    else:
        x, y, report = lb.load_uci(job["meta"], Path(job["path"]))
    seeds = tuple(archive["seeds"])
    matches = replay_matches(x, y, archive)
    return {
        "format": FORMAT,
        "problem": job["problem"],
        "source": job["source"],
        "recovery": "recomputed from the deterministic split; not archived at run time",
        "input_sha256": _file_digest(Path(job["path"])),
        "cleaned_rows": int(len(y)),
        "cleaned_sha256": _digest(np.ascontiguousarray(x)),
        "labels_sha256": _digest(np.asarray(y, dtype=np.int64)),
        "seeds": list(seeds),
        "partitions": partitions(x, y, seeds),
        "archived_rows": archive.get("rows"),
        "archive_replay": {"detector": "XXzscoreXX", "seeds_matching": matches, "all": all(matches)},
        "report_rows_out": report.get("rows_out"),
    }


def x_recover__mutmut_92(job: dict[str, Any], archive: dict[str, Any]) -> dict[str, Any]:
    if job["source"] == "adbench":
        x, y, report = lb.load_adbench(job["name"], Path(job["path"]))
    else:
        x, y, report = lb.load_uci(job["meta"], Path(job["path"]))
    seeds = tuple(archive["seeds"])
    matches = replay_matches(x, y, archive)
    return {
        "format": FORMAT,
        "problem": job["problem"],
        "source": job["source"],
        "recovery": "recomputed from the deterministic split; not archived at run time",
        "input_sha256": _file_digest(Path(job["path"])),
        "cleaned_rows": int(len(y)),
        "cleaned_sha256": _digest(np.ascontiguousarray(x)),
        "labels_sha256": _digest(np.asarray(y, dtype=np.int64)),
        "seeds": list(seeds),
        "partitions": partitions(x, y, seeds),
        "archived_rows": archive.get("rows"),
        "archive_replay": {"detector": "ZSCORE", "seeds_matching": matches, "all": all(matches)},
        "report_rows_out": report.get("rows_out"),
    }


def x_recover__mutmut_93(job: dict[str, Any], archive: dict[str, Any]) -> dict[str, Any]:
    if job["source"] == "adbench":
        x, y, report = lb.load_adbench(job["name"], Path(job["path"]))
    else:
        x, y, report = lb.load_uci(job["meta"], Path(job["path"]))
    seeds = tuple(archive["seeds"])
    matches = replay_matches(x, y, archive)
    return {
        "format": FORMAT,
        "problem": job["problem"],
        "source": job["source"],
        "recovery": "recomputed from the deterministic split; not archived at run time",
        "input_sha256": _file_digest(Path(job["path"])),
        "cleaned_rows": int(len(y)),
        "cleaned_sha256": _digest(np.ascontiguousarray(x)),
        "labels_sha256": _digest(np.asarray(y, dtype=np.int64)),
        "seeds": list(seeds),
        "partitions": partitions(x, y, seeds),
        "archived_rows": archive.get("rows"),
        "archive_replay": {"detector": "zscore", "XXseeds_matchingXX": matches, "all": all(matches)},
        "report_rows_out": report.get("rows_out"),
    }


def x_recover__mutmut_94(job: dict[str, Any], archive: dict[str, Any]) -> dict[str, Any]:
    if job["source"] == "adbench":
        x, y, report = lb.load_adbench(job["name"], Path(job["path"]))
    else:
        x, y, report = lb.load_uci(job["meta"], Path(job["path"]))
    seeds = tuple(archive["seeds"])
    matches = replay_matches(x, y, archive)
    return {
        "format": FORMAT,
        "problem": job["problem"],
        "source": job["source"],
        "recovery": "recomputed from the deterministic split; not archived at run time",
        "input_sha256": _file_digest(Path(job["path"])),
        "cleaned_rows": int(len(y)),
        "cleaned_sha256": _digest(np.ascontiguousarray(x)),
        "labels_sha256": _digest(np.asarray(y, dtype=np.int64)),
        "seeds": list(seeds),
        "partitions": partitions(x, y, seeds),
        "archived_rows": archive.get("rows"),
        "archive_replay": {"detector": "zscore", "SEEDS_MATCHING": matches, "all": all(matches)},
        "report_rows_out": report.get("rows_out"),
    }


def x_recover__mutmut_95(job: dict[str, Any], archive: dict[str, Any]) -> dict[str, Any]:
    if job["source"] == "adbench":
        x, y, report = lb.load_adbench(job["name"], Path(job["path"]))
    else:
        x, y, report = lb.load_uci(job["meta"], Path(job["path"]))
    seeds = tuple(archive["seeds"])
    matches = replay_matches(x, y, archive)
    return {
        "format": FORMAT,
        "problem": job["problem"],
        "source": job["source"],
        "recovery": "recomputed from the deterministic split; not archived at run time",
        "input_sha256": _file_digest(Path(job["path"])),
        "cleaned_rows": int(len(y)),
        "cleaned_sha256": _digest(np.ascontiguousarray(x)),
        "labels_sha256": _digest(np.asarray(y, dtype=np.int64)),
        "seeds": list(seeds),
        "partitions": partitions(x, y, seeds),
        "archived_rows": archive.get("rows"),
        "archive_replay": {"detector": "zscore", "seeds_matching": matches, "XXallXX": all(matches)},
        "report_rows_out": report.get("rows_out"),
    }


def x_recover__mutmut_96(job: dict[str, Any], archive: dict[str, Any]) -> dict[str, Any]:
    if job["source"] == "adbench":
        x, y, report = lb.load_adbench(job["name"], Path(job["path"]))
    else:
        x, y, report = lb.load_uci(job["meta"], Path(job["path"]))
    seeds = tuple(archive["seeds"])
    matches = replay_matches(x, y, archive)
    return {
        "format": FORMAT,
        "problem": job["problem"],
        "source": job["source"],
        "recovery": "recomputed from the deterministic split; not archived at run time",
        "input_sha256": _file_digest(Path(job["path"])),
        "cleaned_rows": int(len(y)),
        "cleaned_sha256": _digest(np.ascontiguousarray(x)),
        "labels_sha256": _digest(np.asarray(y, dtype=np.int64)),
        "seeds": list(seeds),
        "partitions": partitions(x, y, seeds),
        "archived_rows": archive.get("rows"),
        "archive_replay": {"detector": "zscore", "seeds_matching": matches, "ALL": all(matches)},
        "report_rows_out": report.get("rows_out"),
    }


def x_recover__mutmut_97(job: dict[str, Any], archive: dict[str, Any]) -> dict[str, Any]:
    if job["source"] == "adbench":
        x, y, report = lb.load_adbench(job["name"], Path(job["path"]))
    else:
        x, y, report = lb.load_uci(job["meta"], Path(job["path"]))
    seeds = tuple(archive["seeds"])
    matches = replay_matches(x, y, archive)
    return {
        "format": FORMAT,
        "problem": job["problem"],
        "source": job["source"],
        "recovery": "recomputed from the deterministic split; not archived at run time",
        "input_sha256": _file_digest(Path(job["path"])),
        "cleaned_rows": int(len(y)),
        "cleaned_sha256": _digest(np.ascontiguousarray(x)),
        "labels_sha256": _digest(np.asarray(y, dtype=np.int64)),
        "seeds": list(seeds),
        "partitions": partitions(x, y, seeds),
        "archived_rows": archive.get("rows"),
        "archive_replay": {"detector": "zscore", "seeds_matching": matches, "all": all(None)},
        "report_rows_out": report.get("rows_out"),
    }


def x_recover__mutmut_98(job: dict[str, Any], archive: dict[str, Any]) -> dict[str, Any]:
    if job["source"] == "adbench":
        x, y, report = lb.load_adbench(job["name"], Path(job["path"]))
    else:
        x, y, report = lb.load_uci(job["meta"], Path(job["path"]))
    seeds = tuple(archive["seeds"])
    matches = replay_matches(x, y, archive)
    return {
        "format": FORMAT,
        "problem": job["problem"],
        "source": job["source"],
        "recovery": "recomputed from the deterministic split; not archived at run time",
        "input_sha256": _file_digest(Path(job["path"])),
        "cleaned_rows": int(len(y)),
        "cleaned_sha256": _digest(np.ascontiguousarray(x)),
        "labels_sha256": _digest(np.asarray(y, dtype=np.int64)),
        "seeds": list(seeds),
        "partitions": partitions(x, y, seeds),
        "archived_rows": archive.get("rows"),
        "archive_replay": {"detector": "zscore", "seeds_matching": matches, "all": all(matches)},
        "XXreport_rows_outXX": report.get("rows_out"),
    }


def x_recover__mutmut_99(job: dict[str, Any], archive: dict[str, Any]) -> dict[str, Any]:
    if job["source"] == "adbench":
        x, y, report = lb.load_adbench(job["name"], Path(job["path"]))
    else:
        x, y, report = lb.load_uci(job["meta"], Path(job["path"]))
    seeds = tuple(archive["seeds"])
    matches = replay_matches(x, y, archive)
    return {
        "format": FORMAT,
        "problem": job["problem"],
        "source": job["source"],
        "recovery": "recomputed from the deterministic split; not archived at run time",
        "input_sha256": _file_digest(Path(job["path"])),
        "cleaned_rows": int(len(y)),
        "cleaned_sha256": _digest(np.ascontiguousarray(x)),
        "labels_sha256": _digest(np.asarray(y, dtype=np.int64)),
        "seeds": list(seeds),
        "partitions": partitions(x, y, seeds),
        "archived_rows": archive.get("rows"),
        "archive_replay": {"detector": "zscore", "seeds_matching": matches, "all": all(matches)},
        "REPORT_ROWS_OUT": report.get("rows_out"),
    }


def x_recover__mutmut_100(job: dict[str, Any], archive: dict[str, Any]) -> dict[str, Any]:
    if job["source"] == "adbench":
        x, y, report = lb.load_adbench(job["name"], Path(job["path"]))
    else:
        x, y, report = lb.load_uci(job["meta"], Path(job["path"]))
    seeds = tuple(archive["seeds"])
    matches = replay_matches(x, y, archive)
    return {
        "format": FORMAT,
        "problem": job["problem"],
        "source": job["source"],
        "recovery": "recomputed from the deterministic split; not archived at run time",
        "input_sha256": _file_digest(Path(job["path"])),
        "cleaned_rows": int(len(y)),
        "cleaned_sha256": _digest(np.ascontiguousarray(x)),
        "labels_sha256": _digest(np.asarray(y, dtype=np.int64)),
        "seeds": list(seeds),
        "partitions": partitions(x, y, seeds),
        "archived_rows": archive.get("rows"),
        "archive_replay": {"detector": "zscore", "seeds_matching": matches, "all": all(matches)},
        "report_rows_out": report.get(None),
    }


def x_recover__mutmut_101(job: dict[str, Any], archive: dict[str, Any]) -> dict[str, Any]:
    if job["source"] == "adbench":
        x, y, report = lb.load_adbench(job["name"], Path(job["path"]))
    else:
        x, y, report = lb.load_uci(job["meta"], Path(job["path"]))
    seeds = tuple(archive["seeds"])
    matches = replay_matches(x, y, archive)
    return {
        "format": FORMAT,
        "problem": job["problem"],
        "source": job["source"],
        "recovery": "recomputed from the deterministic split; not archived at run time",
        "input_sha256": _file_digest(Path(job["path"])),
        "cleaned_rows": int(len(y)),
        "cleaned_sha256": _digest(np.ascontiguousarray(x)),
        "labels_sha256": _digest(np.asarray(y, dtype=np.int64)),
        "seeds": list(seeds),
        "partitions": partitions(x, y, seeds),
        "archived_rows": archive.get("rows"),
        "archive_replay": {"detector": "zscore", "seeds_matching": matches, "all": all(matches)},
        "report_rows_out": report.get("XXrows_outXX"),
    }


def x_recover__mutmut_102(job: dict[str, Any], archive: dict[str, Any]) -> dict[str, Any]:
    if job["source"] == "adbench":
        x, y, report = lb.load_adbench(job["name"], Path(job["path"]))
    else:
        x, y, report = lb.load_uci(job["meta"], Path(job["path"]))
    seeds = tuple(archive["seeds"])
    matches = replay_matches(x, y, archive)
    return {
        "format": FORMAT,
        "problem": job["problem"],
        "source": job["source"],
        "recovery": "recomputed from the deterministic split; not archived at run time",
        "input_sha256": _file_digest(Path(job["path"])),
        "cleaned_rows": int(len(y)),
        "cleaned_sha256": _digest(np.ascontiguousarray(x)),
        "labels_sha256": _digest(np.asarray(y, dtype=np.int64)),
        "seeds": list(seeds),
        "partitions": partitions(x, y, seeds),
        "archived_rows": archive.get("rows"),
        "archive_replay": {"detector": "zscore", "seeds_matching": matches, "all": all(matches)},
        "report_rows_out": report.get("ROWS_OUT"),
    }

mutants_x_recover__mutmut['_mutmut_orig'] = x_recover__mutmut_orig # type: ignore # mutmut generated
mutants_x_recover__mutmut['x_recover__mutmut_1'] = x_recover__mutmut_1 # type: ignore # mutmut generated
mutants_x_recover__mutmut['x_recover__mutmut_2'] = x_recover__mutmut_2 # type: ignore # mutmut generated
mutants_x_recover__mutmut['x_recover__mutmut_3'] = x_recover__mutmut_3 # type: ignore # mutmut generated
mutants_x_recover__mutmut['x_recover__mutmut_4'] = x_recover__mutmut_4 # type: ignore # mutmut generated
mutants_x_recover__mutmut['x_recover__mutmut_5'] = x_recover__mutmut_5 # type: ignore # mutmut generated
mutants_x_recover__mutmut['x_recover__mutmut_6'] = x_recover__mutmut_6 # type: ignore # mutmut generated
mutants_x_recover__mutmut['x_recover__mutmut_7'] = x_recover__mutmut_7 # type: ignore # mutmut generated
mutants_x_recover__mutmut['x_recover__mutmut_8'] = x_recover__mutmut_8 # type: ignore # mutmut generated
mutants_x_recover__mutmut['x_recover__mutmut_9'] = x_recover__mutmut_9 # type: ignore # mutmut generated
mutants_x_recover__mutmut['x_recover__mutmut_10'] = x_recover__mutmut_10 # type: ignore # mutmut generated
mutants_x_recover__mutmut['x_recover__mutmut_11'] = x_recover__mutmut_11 # type: ignore # mutmut generated
mutants_x_recover__mutmut['x_recover__mutmut_12'] = x_recover__mutmut_12 # type: ignore # mutmut generated
mutants_x_recover__mutmut['x_recover__mutmut_13'] = x_recover__mutmut_13 # type: ignore # mutmut generated
mutants_x_recover__mutmut['x_recover__mutmut_14'] = x_recover__mutmut_14 # type: ignore # mutmut generated
mutants_x_recover__mutmut['x_recover__mutmut_15'] = x_recover__mutmut_15 # type: ignore # mutmut generated
mutants_x_recover__mutmut['x_recover__mutmut_16'] = x_recover__mutmut_16 # type: ignore # mutmut generated
mutants_x_recover__mutmut['x_recover__mutmut_17'] = x_recover__mutmut_17 # type: ignore # mutmut generated
mutants_x_recover__mutmut['x_recover__mutmut_18'] = x_recover__mutmut_18 # type: ignore # mutmut generated
mutants_x_recover__mutmut['x_recover__mutmut_19'] = x_recover__mutmut_19 # type: ignore # mutmut generated
mutants_x_recover__mutmut['x_recover__mutmut_20'] = x_recover__mutmut_20 # type: ignore # mutmut generated
mutants_x_recover__mutmut['x_recover__mutmut_21'] = x_recover__mutmut_21 # type: ignore # mutmut generated
mutants_x_recover__mutmut['x_recover__mutmut_22'] = x_recover__mutmut_22 # type: ignore # mutmut generated
mutants_x_recover__mutmut['x_recover__mutmut_23'] = x_recover__mutmut_23 # type: ignore # mutmut generated
mutants_x_recover__mutmut['x_recover__mutmut_24'] = x_recover__mutmut_24 # type: ignore # mutmut generated
mutants_x_recover__mutmut['x_recover__mutmut_25'] = x_recover__mutmut_25 # type: ignore # mutmut generated
mutants_x_recover__mutmut['x_recover__mutmut_26'] = x_recover__mutmut_26 # type: ignore # mutmut generated
mutants_x_recover__mutmut['x_recover__mutmut_27'] = x_recover__mutmut_27 # type: ignore # mutmut generated
mutants_x_recover__mutmut['x_recover__mutmut_28'] = x_recover__mutmut_28 # type: ignore # mutmut generated
mutants_x_recover__mutmut['x_recover__mutmut_29'] = x_recover__mutmut_29 # type: ignore # mutmut generated
mutants_x_recover__mutmut['x_recover__mutmut_30'] = x_recover__mutmut_30 # type: ignore # mutmut generated
mutants_x_recover__mutmut['x_recover__mutmut_31'] = x_recover__mutmut_31 # type: ignore # mutmut generated
mutants_x_recover__mutmut['x_recover__mutmut_32'] = x_recover__mutmut_32 # type: ignore # mutmut generated
mutants_x_recover__mutmut['x_recover__mutmut_33'] = x_recover__mutmut_33 # type: ignore # mutmut generated
mutants_x_recover__mutmut['x_recover__mutmut_34'] = x_recover__mutmut_34 # type: ignore # mutmut generated
mutants_x_recover__mutmut['x_recover__mutmut_35'] = x_recover__mutmut_35 # type: ignore # mutmut generated
mutants_x_recover__mutmut['x_recover__mutmut_36'] = x_recover__mutmut_36 # type: ignore # mutmut generated
mutants_x_recover__mutmut['x_recover__mutmut_37'] = x_recover__mutmut_37 # type: ignore # mutmut generated
mutants_x_recover__mutmut['x_recover__mutmut_38'] = x_recover__mutmut_38 # type: ignore # mutmut generated
mutants_x_recover__mutmut['x_recover__mutmut_39'] = x_recover__mutmut_39 # type: ignore # mutmut generated
mutants_x_recover__mutmut['x_recover__mutmut_40'] = x_recover__mutmut_40 # type: ignore # mutmut generated
mutants_x_recover__mutmut['x_recover__mutmut_41'] = x_recover__mutmut_41 # type: ignore # mutmut generated
mutants_x_recover__mutmut['x_recover__mutmut_42'] = x_recover__mutmut_42 # type: ignore # mutmut generated
mutants_x_recover__mutmut['x_recover__mutmut_43'] = x_recover__mutmut_43 # type: ignore # mutmut generated
mutants_x_recover__mutmut['x_recover__mutmut_44'] = x_recover__mutmut_44 # type: ignore # mutmut generated
mutants_x_recover__mutmut['x_recover__mutmut_45'] = x_recover__mutmut_45 # type: ignore # mutmut generated
mutants_x_recover__mutmut['x_recover__mutmut_46'] = x_recover__mutmut_46 # type: ignore # mutmut generated
mutants_x_recover__mutmut['x_recover__mutmut_47'] = x_recover__mutmut_47 # type: ignore # mutmut generated
mutants_x_recover__mutmut['x_recover__mutmut_48'] = x_recover__mutmut_48 # type: ignore # mutmut generated
mutants_x_recover__mutmut['x_recover__mutmut_49'] = x_recover__mutmut_49 # type: ignore # mutmut generated
mutants_x_recover__mutmut['x_recover__mutmut_50'] = x_recover__mutmut_50 # type: ignore # mutmut generated
mutants_x_recover__mutmut['x_recover__mutmut_51'] = x_recover__mutmut_51 # type: ignore # mutmut generated
mutants_x_recover__mutmut['x_recover__mutmut_52'] = x_recover__mutmut_52 # type: ignore # mutmut generated
mutants_x_recover__mutmut['x_recover__mutmut_53'] = x_recover__mutmut_53 # type: ignore # mutmut generated
mutants_x_recover__mutmut['x_recover__mutmut_54'] = x_recover__mutmut_54 # type: ignore # mutmut generated
mutants_x_recover__mutmut['x_recover__mutmut_55'] = x_recover__mutmut_55 # type: ignore # mutmut generated
mutants_x_recover__mutmut['x_recover__mutmut_56'] = x_recover__mutmut_56 # type: ignore # mutmut generated
mutants_x_recover__mutmut['x_recover__mutmut_57'] = x_recover__mutmut_57 # type: ignore # mutmut generated
mutants_x_recover__mutmut['x_recover__mutmut_58'] = x_recover__mutmut_58 # type: ignore # mutmut generated
mutants_x_recover__mutmut['x_recover__mutmut_59'] = x_recover__mutmut_59 # type: ignore # mutmut generated
mutants_x_recover__mutmut['x_recover__mutmut_60'] = x_recover__mutmut_60 # type: ignore # mutmut generated
mutants_x_recover__mutmut['x_recover__mutmut_61'] = x_recover__mutmut_61 # type: ignore # mutmut generated
mutants_x_recover__mutmut['x_recover__mutmut_62'] = x_recover__mutmut_62 # type: ignore # mutmut generated
mutants_x_recover__mutmut['x_recover__mutmut_63'] = x_recover__mutmut_63 # type: ignore # mutmut generated
mutants_x_recover__mutmut['x_recover__mutmut_64'] = x_recover__mutmut_64 # type: ignore # mutmut generated
mutants_x_recover__mutmut['x_recover__mutmut_65'] = x_recover__mutmut_65 # type: ignore # mutmut generated
mutants_x_recover__mutmut['x_recover__mutmut_66'] = x_recover__mutmut_66 # type: ignore # mutmut generated
mutants_x_recover__mutmut['x_recover__mutmut_67'] = x_recover__mutmut_67 # type: ignore # mutmut generated
mutants_x_recover__mutmut['x_recover__mutmut_68'] = x_recover__mutmut_68 # type: ignore # mutmut generated
mutants_x_recover__mutmut['x_recover__mutmut_69'] = x_recover__mutmut_69 # type: ignore # mutmut generated
mutants_x_recover__mutmut['x_recover__mutmut_70'] = x_recover__mutmut_70 # type: ignore # mutmut generated
mutants_x_recover__mutmut['x_recover__mutmut_71'] = x_recover__mutmut_71 # type: ignore # mutmut generated
mutants_x_recover__mutmut['x_recover__mutmut_72'] = x_recover__mutmut_72 # type: ignore # mutmut generated
mutants_x_recover__mutmut['x_recover__mutmut_73'] = x_recover__mutmut_73 # type: ignore # mutmut generated
mutants_x_recover__mutmut['x_recover__mutmut_74'] = x_recover__mutmut_74 # type: ignore # mutmut generated
mutants_x_recover__mutmut['x_recover__mutmut_75'] = x_recover__mutmut_75 # type: ignore # mutmut generated
mutants_x_recover__mutmut['x_recover__mutmut_76'] = x_recover__mutmut_76 # type: ignore # mutmut generated
mutants_x_recover__mutmut['x_recover__mutmut_77'] = x_recover__mutmut_77 # type: ignore # mutmut generated
mutants_x_recover__mutmut['x_recover__mutmut_78'] = x_recover__mutmut_78 # type: ignore # mutmut generated
mutants_x_recover__mutmut['x_recover__mutmut_79'] = x_recover__mutmut_79 # type: ignore # mutmut generated
mutants_x_recover__mutmut['x_recover__mutmut_80'] = x_recover__mutmut_80 # type: ignore # mutmut generated
mutants_x_recover__mutmut['x_recover__mutmut_81'] = x_recover__mutmut_81 # type: ignore # mutmut generated
mutants_x_recover__mutmut['x_recover__mutmut_82'] = x_recover__mutmut_82 # type: ignore # mutmut generated
mutants_x_recover__mutmut['x_recover__mutmut_83'] = x_recover__mutmut_83 # type: ignore # mutmut generated
mutants_x_recover__mutmut['x_recover__mutmut_84'] = x_recover__mutmut_84 # type: ignore # mutmut generated
mutants_x_recover__mutmut['x_recover__mutmut_85'] = x_recover__mutmut_85 # type: ignore # mutmut generated
mutants_x_recover__mutmut['x_recover__mutmut_86'] = x_recover__mutmut_86 # type: ignore # mutmut generated
mutants_x_recover__mutmut['x_recover__mutmut_87'] = x_recover__mutmut_87 # type: ignore # mutmut generated
mutants_x_recover__mutmut['x_recover__mutmut_88'] = x_recover__mutmut_88 # type: ignore # mutmut generated
mutants_x_recover__mutmut['x_recover__mutmut_89'] = x_recover__mutmut_89 # type: ignore # mutmut generated
mutants_x_recover__mutmut['x_recover__mutmut_90'] = x_recover__mutmut_90 # type: ignore # mutmut generated
mutants_x_recover__mutmut['x_recover__mutmut_91'] = x_recover__mutmut_91 # type: ignore # mutmut generated
mutants_x_recover__mutmut['x_recover__mutmut_92'] = x_recover__mutmut_92 # type: ignore # mutmut generated
mutants_x_recover__mutmut['x_recover__mutmut_93'] = x_recover__mutmut_93 # type: ignore # mutmut generated
mutants_x_recover__mutmut['x_recover__mutmut_94'] = x_recover__mutmut_94 # type: ignore # mutmut generated
mutants_x_recover__mutmut['x_recover__mutmut_95'] = x_recover__mutmut_95 # type: ignore # mutmut generated
mutants_x_recover__mutmut['x_recover__mutmut_96'] = x_recover__mutmut_96 # type: ignore # mutmut generated
mutants_x_recover__mutmut['x_recover__mutmut_97'] = x_recover__mutmut_97 # type: ignore # mutmut generated
mutants_x_recover__mutmut['x_recover__mutmut_98'] = x_recover__mutmut_98 # type: ignore # mutmut generated
mutants_x_recover__mutmut['x_recover__mutmut_99'] = x_recover__mutmut_99 # type: ignore # mutmut generated
mutants_x_recover__mutmut['x_recover__mutmut_100'] = x_recover__mutmut_100 # type: ignore # mutmut generated
mutants_x_recover__mutmut['x_recover__mutmut_101'] = x_recover__mutmut_101 # type: ignore # mutmut generated
mutants_x_recover__mutmut['x_recover__mutmut_102'] = x_recover__mutmut_102 # type: ignore # mutmut generated
mutants_x_main__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_main__mutmut)
def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    parser.add_argument(
        "--registry", type=Path, default=root / "verification/evidence/dataset_registry"
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument(
        "--archive", type=Path, default=root / "verification/evidence/labelled_pool/runs"
    )
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    mismatched = 0
    for job in lb.jobs(args.registry, args.adbench, args.pool):
        stem = job["problem"].replace(":", "_")
        archive_path = args.archive / f"{stem}.json"
        if not archive_path.is_file():
            print(job["problem"], "no archived run")
            mismatched += 1
            continue
        archive = json.loads(archive_path.read_text())
        if "failed" in archive:
            print(job["problem"], "archived run failed; not recoverable")
            mismatched += 1
            continue
        record = recover(job, archive)
        (args.output / f"{stem}.json").write_text(
            json.dumps(record, indent=1, sort_keys=True) + "\n"
        )
        flag = "ok" if record["archive_replay"]["all"] else "REPLAY DIFFERS"
        mismatched += not record["archive_replay"]["all"]
        print(job["problem"], flag, flush=True)
    print(f"{mismatched} problems not confirmed")
    return 0 if mismatched == 0 else 1


def x_main__mutmut_orig(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    parser.add_argument(
        "--registry", type=Path, default=root / "verification/evidence/dataset_registry"
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument(
        "--archive", type=Path, default=root / "verification/evidence/labelled_pool/runs"
    )
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    mismatched = 0
    for job in lb.jobs(args.registry, args.adbench, args.pool):
        stem = job["problem"].replace(":", "_")
        archive_path = args.archive / f"{stem}.json"
        if not archive_path.is_file():
            print(job["problem"], "no archived run")
            mismatched += 1
            continue
        archive = json.loads(archive_path.read_text())
        if "failed" in archive:
            print(job["problem"], "archived run failed; not recoverable")
            mismatched += 1
            continue
        record = recover(job, archive)
        (args.output / f"{stem}.json").write_text(
            json.dumps(record, indent=1, sort_keys=True) + "\n"
        )
        flag = "ok" if record["archive_replay"]["all"] else "REPLAY DIFFERS"
        mismatched += not record["archive_replay"]["all"]
        print(job["problem"], flag, flush=True)
    print(f"{mismatched} problems not confirmed")
    return 0 if mismatched == 0 else 1


def x_main__mutmut_1(argv: list[str] | None = None) -> int:
    parser = None
    root = HERE.parent
    parser.add_argument(
        "--registry", type=Path, default=root / "verification/evidence/dataset_registry"
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument(
        "--archive", type=Path, default=root / "verification/evidence/labelled_pool/runs"
    )
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    mismatched = 0
    for job in lb.jobs(args.registry, args.adbench, args.pool):
        stem = job["problem"].replace(":", "_")
        archive_path = args.archive / f"{stem}.json"
        if not archive_path.is_file():
            print(job["problem"], "no archived run")
            mismatched += 1
            continue
        archive = json.loads(archive_path.read_text())
        if "failed" in archive:
            print(job["problem"], "archived run failed; not recoverable")
            mismatched += 1
            continue
        record = recover(job, archive)
        (args.output / f"{stem}.json").write_text(
            json.dumps(record, indent=1, sort_keys=True) + "\n"
        )
        flag = "ok" if record["archive_replay"]["all"] else "REPLAY DIFFERS"
        mismatched += not record["archive_replay"]["all"]
        print(job["problem"], flag, flush=True)
    print(f"{mismatched} problems not confirmed")
    return 0 if mismatched == 0 else 1


def x_main__mutmut_2(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=None)
    root = HERE.parent
    parser.add_argument(
        "--registry", type=Path, default=root / "verification/evidence/dataset_registry"
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument(
        "--archive", type=Path, default=root / "verification/evidence/labelled_pool/runs"
    )
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    mismatched = 0
    for job in lb.jobs(args.registry, args.adbench, args.pool):
        stem = job["problem"].replace(":", "_")
        archive_path = args.archive / f"{stem}.json"
        if not archive_path.is_file():
            print(job["problem"], "no archived run")
            mismatched += 1
            continue
        archive = json.loads(archive_path.read_text())
        if "failed" in archive:
            print(job["problem"], "archived run failed; not recoverable")
            mismatched += 1
            continue
        record = recover(job, archive)
        (args.output / f"{stem}.json").write_text(
            json.dumps(record, indent=1, sort_keys=True) + "\n"
        )
        flag = "ok" if record["archive_replay"]["all"] else "REPLAY DIFFERS"
        mismatched += not record["archive_replay"]["all"]
        print(job["problem"], flag, flush=True)
    print(f"{mismatched} problems not confirmed")
    return 0 if mismatched == 0 else 1


def x_main__mutmut_3(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = None
    parser.add_argument(
        "--registry", type=Path, default=root / "verification/evidence/dataset_registry"
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument(
        "--archive", type=Path, default=root / "verification/evidence/labelled_pool/runs"
    )
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    mismatched = 0
    for job in lb.jobs(args.registry, args.adbench, args.pool):
        stem = job["problem"].replace(":", "_")
        archive_path = args.archive / f"{stem}.json"
        if not archive_path.is_file():
            print(job["problem"], "no archived run")
            mismatched += 1
            continue
        archive = json.loads(archive_path.read_text())
        if "failed" in archive:
            print(job["problem"], "archived run failed; not recoverable")
            mismatched += 1
            continue
        record = recover(job, archive)
        (args.output / f"{stem}.json").write_text(
            json.dumps(record, indent=1, sort_keys=True) + "\n"
        )
        flag = "ok" if record["archive_replay"]["all"] else "REPLAY DIFFERS"
        mismatched += not record["archive_replay"]["all"]
        print(job["problem"], flag, flush=True)
    print(f"{mismatched} problems not confirmed")
    return 0 if mismatched == 0 else 1


def x_main__mutmut_4(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    parser.add_argument(
        None, type=Path, default=root / "verification/evidence/dataset_registry"
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument(
        "--archive", type=Path, default=root / "verification/evidence/labelled_pool/runs"
    )
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    mismatched = 0
    for job in lb.jobs(args.registry, args.adbench, args.pool):
        stem = job["problem"].replace(":", "_")
        archive_path = args.archive / f"{stem}.json"
        if not archive_path.is_file():
            print(job["problem"], "no archived run")
            mismatched += 1
            continue
        archive = json.loads(archive_path.read_text())
        if "failed" in archive:
            print(job["problem"], "archived run failed; not recoverable")
            mismatched += 1
            continue
        record = recover(job, archive)
        (args.output / f"{stem}.json").write_text(
            json.dumps(record, indent=1, sort_keys=True) + "\n"
        )
        flag = "ok" if record["archive_replay"]["all"] else "REPLAY DIFFERS"
        mismatched += not record["archive_replay"]["all"]
        print(job["problem"], flag, flush=True)
    print(f"{mismatched} problems not confirmed")
    return 0 if mismatched == 0 else 1


def x_main__mutmut_5(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    parser.add_argument(
        "--registry", type=None, default=root / "verification/evidence/dataset_registry"
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument(
        "--archive", type=Path, default=root / "verification/evidence/labelled_pool/runs"
    )
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    mismatched = 0
    for job in lb.jobs(args.registry, args.adbench, args.pool):
        stem = job["problem"].replace(":", "_")
        archive_path = args.archive / f"{stem}.json"
        if not archive_path.is_file():
            print(job["problem"], "no archived run")
            mismatched += 1
            continue
        archive = json.loads(archive_path.read_text())
        if "failed" in archive:
            print(job["problem"], "archived run failed; not recoverable")
            mismatched += 1
            continue
        record = recover(job, archive)
        (args.output / f"{stem}.json").write_text(
            json.dumps(record, indent=1, sort_keys=True) + "\n"
        )
        flag = "ok" if record["archive_replay"]["all"] else "REPLAY DIFFERS"
        mismatched += not record["archive_replay"]["all"]
        print(job["problem"], flag, flush=True)
    print(f"{mismatched} problems not confirmed")
    return 0 if mismatched == 0 else 1


def x_main__mutmut_6(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    parser.add_argument(
        "--registry", type=Path, default=None
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument(
        "--archive", type=Path, default=root / "verification/evidence/labelled_pool/runs"
    )
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    mismatched = 0
    for job in lb.jobs(args.registry, args.adbench, args.pool):
        stem = job["problem"].replace(":", "_")
        archive_path = args.archive / f"{stem}.json"
        if not archive_path.is_file():
            print(job["problem"], "no archived run")
            mismatched += 1
            continue
        archive = json.loads(archive_path.read_text())
        if "failed" in archive:
            print(job["problem"], "archived run failed; not recoverable")
            mismatched += 1
            continue
        record = recover(job, archive)
        (args.output / f"{stem}.json").write_text(
            json.dumps(record, indent=1, sort_keys=True) + "\n"
        )
        flag = "ok" if record["archive_replay"]["all"] else "REPLAY DIFFERS"
        mismatched += not record["archive_replay"]["all"]
        print(job["problem"], flag, flush=True)
    print(f"{mismatched} problems not confirmed")
    return 0 if mismatched == 0 else 1


def x_main__mutmut_7(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    parser.add_argument(
        type=Path, default=root / "verification/evidence/dataset_registry"
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument(
        "--archive", type=Path, default=root / "verification/evidence/labelled_pool/runs"
    )
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    mismatched = 0
    for job in lb.jobs(args.registry, args.adbench, args.pool):
        stem = job["problem"].replace(":", "_")
        archive_path = args.archive / f"{stem}.json"
        if not archive_path.is_file():
            print(job["problem"], "no archived run")
            mismatched += 1
            continue
        archive = json.loads(archive_path.read_text())
        if "failed" in archive:
            print(job["problem"], "archived run failed; not recoverable")
            mismatched += 1
            continue
        record = recover(job, archive)
        (args.output / f"{stem}.json").write_text(
            json.dumps(record, indent=1, sort_keys=True) + "\n"
        )
        flag = "ok" if record["archive_replay"]["all"] else "REPLAY DIFFERS"
        mismatched += not record["archive_replay"]["all"]
        print(job["problem"], flag, flush=True)
    print(f"{mismatched} problems not confirmed")
    return 0 if mismatched == 0 else 1


def x_main__mutmut_8(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    parser.add_argument(
        "--registry", default=root / "verification/evidence/dataset_registry"
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument(
        "--archive", type=Path, default=root / "verification/evidence/labelled_pool/runs"
    )
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    mismatched = 0
    for job in lb.jobs(args.registry, args.adbench, args.pool):
        stem = job["problem"].replace(":", "_")
        archive_path = args.archive / f"{stem}.json"
        if not archive_path.is_file():
            print(job["problem"], "no archived run")
            mismatched += 1
            continue
        archive = json.loads(archive_path.read_text())
        if "failed" in archive:
            print(job["problem"], "archived run failed; not recoverable")
            mismatched += 1
            continue
        record = recover(job, archive)
        (args.output / f"{stem}.json").write_text(
            json.dumps(record, indent=1, sort_keys=True) + "\n"
        )
        flag = "ok" if record["archive_replay"]["all"] else "REPLAY DIFFERS"
        mismatched += not record["archive_replay"]["all"]
        print(job["problem"], flag, flush=True)
    print(f"{mismatched} problems not confirmed")
    return 0 if mismatched == 0 else 1


def x_main__mutmut_9(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    parser.add_argument(
        "--registry", type=Path, )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument(
        "--archive", type=Path, default=root / "verification/evidence/labelled_pool/runs"
    )
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    mismatched = 0
    for job in lb.jobs(args.registry, args.adbench, args.pool):
        stem = job["problem"].replace(":", "_")
        archive_path = args.archive / f"{stem}.json"
        if not archive_path.is_file():
            print(job["problem"], "no archived run")
            mismatched += 1
            continue
        archive = json.loads(archive_path.read_text())
        if "failed" in archive:
            print(job["problem"], "archived run failed; not recoverable")
            mismatched += 1
            continue
        record = recover(job, archive)
        (args.output / f"{stem}.json").write_text(
            json.dumps(record, indent=1, sort_keys=True) + "\n"
        )
        flag = "ok" if record["archive_replay"]["all"] else "REPLAY DIFFERS"
        mismatched += not record["archive_replay"]["all"]
        print(job["problem"], flag, flush=True)
    print(f"{mismatched} problems not confirmed")
    return 0 if mismatched == 0 else 1


def x_main__mutmut_10(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    parser.add_argument(
        "XX--registryXX", type=Path, default=root / "verification/evidence/dataset_registry"
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument(
        "--archive", type=Path, default=root / "verification/evidence/labelled_pool/runs"
    )
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    mismatched = 0
    for job in lb.jobs(args.registry, args.adbench, args.pool):
        stem = job["problem"].replace(":", "_")
        archive_path = args.archive / f"{stem}.json"
        if not archive_path.is_file():
            print(job["problem"], "no archived run")
            mismatched += 1
            continue
        archive = json.loads(archive_path.read_text())
        if "failed" in archive:
            print(job["problem"], "archived run failed; not recoverable")
            mismatched += 1
            continue
        record = recover(job, archive)
        (args.output / f"{stem}.json").write_text(
            json.dumps(record, indent=1, sort_keys=True) + "\n"
        )
        flag = "ok" if record["archive_replay"]["all"] else "REPLAY DIFFERS"
        mismatched += not record["archive_replay"]["all"]
        print(job["problem"], flag, flush=True)
    print(f"{mismatched} problems not confirmed")
    return 0 if mismatched == 0 else 1


def x_main__mutmut_11(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    parser.add_argument(
        "--REGISTRY", type=Path, default=root / "verification/evidence/dataset_registry"
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument(
        "--archive", type=Path, default=root / "verification/evidence/labelled_pool/runs"
    )
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    mismatched = 0
    for job in lb.jobs(args.registry, args.adbench, args.pool):
        stem = job["problem"].replace(":", "_")
        archive_path = args.archive / f"{stem}.json"
        if not archive_path.is_file():
            print(job["problem"], "no archived run")
            mismatched += 1
            continue
        archive = json.loads(archive_path.read_text())
        if "failed" in archive:
            print(job["problem"], "archived run failed; not recoverable")
            mismatched += 1
            continue
        record = recover(job, archive)
        (args.output / f"{stem}.json").write_text(
            json.dumps(record, indent=1, sort_keys=True) + "\n"
        )
        flag = "ok" if record["archive_replay"]["all"] else "REPLAY DIFFERS"
        mismatched += not record["archive_replay"]["all"]
        print(job["problem"], flag, flush=True)
    print(f"{mismatched} problems not confirmed")
    return 0 if mismatched == 0 else 1


def x_main__mutmut_12(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    parser.add_argument(
        "--registry", type=Path, default=root * "verification/evidence/dataset_registry"
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument(
        "--archive", type=Path, default=root / "verification/evidence/labelled_pool/runs"
    )
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    mismatched = 0
    for job in lb.jobs(args.registry, args.adbench, args.pool):
        stem = job["problem"].replace(":", "_")
        archive_path = args.archive / f"{stem}.json"
        if not archive_path.is_file():
            print(job["problem"], "no archived run")
            mismatched += 1
            continue
        archive = json.loads(archive_path.read_text())
        if "failed" in archive:
            print(job["problem"], "archived run failed; not recoverable")
            mismatched += 1
            continue
        record = recover(job, archive)
        (args.output / f"{stem}.json").write_text(
            json.dumps(record, indent=1, sort_keys=True) + "\n"
        )
        flag = "ok" if record["archive_replay"]["all"] else "REPLAY DIFFERS"
        mismatched += not record["archive_replay"]["all"]
        print(job["problem"], flag, flush=True)
    print(f"{mismatched} problems not confirmed")
    return 0 if mismatched == 0 else 1


def x_main__mutmut_13(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    parser.add_argument(
        "--registry", type=Path, default=root / "XXverification/evidence/dataset_registryXX"
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument(
        "--archive", type=Path, default=root / "verification/evidence/labelled_pool/runs"
    )
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    mismatched = 0
    for job in lb.jobs(args.registry, args.adbench, args.pool):
        stem = job["problem"].replace(":", "_")
        archive_path = args.archive / f"{stem}.json"
        if not archive_path.is_file():
            print(job["problem"], "no archived run")
            mismatched += 1
            continue
        archive = json.loads(archive_path.read_text())
        if "failed" in archive:
            print(job["problem"], "archived run failed; not recoverable")
            mismatched += 1
            continue
        record = recover(job, archive)
        (args.output / f"{stem}.json").write_text(
            json.dumps(record, indent=1, sort_keys=True) + "\n"
        )
        flag = "ok" if record["archive_replay"]["all"] else "REPLAY DIFFERS"
        mismatched += not record["archive_replay"]["all"]
        print(job["problem"], flag, flush=True)
    print(f"{mismatched} problems not confirmed")
    return 0 if mismatched == 0 else 1


def x_main__mutmut_14(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    parser.add_argument(
        "--registry", type=Path, default=root / "VERIFICATION/EVIDENCE/DATASET_REGISTRY"
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument(
        "--archive", type=Path, default=root / "verification/evidence/labelled_pool/runs"
    )
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    mismatched = 0
    for job in lb.jobs(args.registry, args.adbench, args.pool):
        stem = job["problem"].replace(":", "_")
        archive_path = args.archive / f"{stem}.json"
        if not archive_path.is_file():
            print(job["problem"], "no archived run")
            mismatched += 1
            continue
        archive = json.loads(archive_path.read_text())
        if "failed" in archive:
            print(job["problem"], "archived run failed; not recoverable")
            mismatched += 1
            continue
        record = recover(job, archive)
        (args.output / f"{stem}.json").write_text(
            json.dumps(record, indent=1, sort_keys=True) + "\n"
        )
        flag = "ok" if record["archive_replay"]["all"] else "REPLAY DIFFERS"
        mismatched += not record["archive_replay"]["all"]
        print(job["problem"], flag, flush=True)
    print(f"{mismatched} problems not confirmed")
    return 0 if mismatched == 0 else 1


def x_main__mutmut_15(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    parser.add_argument(
        "--registry", type=Path, default=root / "verification/evidence/dataset_registry"
    )
    parser.add_argument(None, type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument(
        "--archive", type=Path, default=root / "verification/evidence/labelled_pool/runs"
    )
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    mismatched = 0
    for job in lb.jobs(args.registry, args.adbench, args.pool):
        stem = job["problem"].replace(":", "_")
        archive_path = args.archive / f"{stem}.json"
        if not archive_path.is_file():
            print(job["problem"], "no archived run")
            mismatched += 1
            continue
        archive = json.loads(archive_path.read_text())
        if "failed" in archive:
            print(job["problem"], "archived run failed; not recoverable")
            mismatched += 1
            continue
        record = recover(job, archive)
        (args.output / f"{stem}.json").write_text(
            json.dumps(record, indent=1, sort_keys=True) + "\n"
        )
        flag = "ok" if record["archive_replay"]["all"] else "REPLAY DIFFERS"
        mismatched += not record["archive_replay"]["all"]
        print(job["problem"], flag, flush=True)
    print(f"{mismatched} problems not confirmed")
    return 0 if mismatched == 0 else 1


def x_main__mutmut_16(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    parser.add_argument(
        "--registry", type=Path, default=root / "verification/evidence/dataset_registry"
    )
    parser.add_argument("--adbench", type=None, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument(
        "--archive", type=Path, default=root / "verification/evidence/labelled_pool/runs"
    )
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    mismatched = 0
    for job in lb.jobs(args.registry, args.adbench, args.pool):
        stem = job["problem"].replace(":", "_")
        archive_path = args.archive / f"{stem}.json"
        if not archive_path.is_file():
            print(job["problem"], "no archived run")
            mismatched += 1
            continue
        archive = json.loads(archive_path.read_text())
        if "failed" in archive:
            print(job["problem"], "archived run failed; not recoverable")
            mismatched += 1
            continue
        record = recover(job, archive)
        (args.output / f"{stem}.json").write_text(
            json.dumps(record, indent=1, sort_keys=True) + "\n"
        )
        flag = "ok" if record["archive_replay"]["all"] else "REPLAY DIFFERS"
        mismatched += not record["archive_replay"]["all"]
        print(job["problem"], flag, flush=True)
    print(f"{mismatched} problems not confirmed")
    return 0 if mismatched == 0 else 1


def x_main__mutmut_17(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    parser.add_argument(
        "--registry", type=Path, default=root / "verification/evidence/dataset_registry"
    )
    parser.add_argument("--adbench", type=Path, default=None)
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument(
        "--archive", type=Path, default=root / "verification/evidence/labelled_pool/runs"
    )
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    mismatched = 0
    for job in lb.jobs(args.registry, args.adbench, args.pool):
        stem = job["problem"].replace(":", "_")
        archive_path = args.archive / f"{stem}.json"
        if not archive_path.is_file():
            print(job["problem"], "no archived run")
            mismatched += 1
            continue
        archive = json.loads(archive_path.read_text())
        if "failed" in archive:
            print(job["problem"], "archived run failed; not recoverable")
            mismatched += 1
            continue
        record = recover(job, archive)
        (args.output / f"{stem}.json").write_text(
            json.dumps(record, indent=1, sort_keys=True) + "\n"
        )
        flag = "ok" if record["archive_replay"]["all"] else "REPLAY DIFFERS"
        mismatched += not record["archive_replay"]["all"]
        print(job["problem"], flag, flush=True)
    print(f"{mismatched} problems not confirmed")
    return 0 if mismatched == 0 else 1


def x_main__mutmut_18(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    parser.add_argument(
        "--registry", type=Path, default=root / "verification/evidence/dataset_registry"
    )
    parser.add_argument(type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument(
        "--archive", type=Path, default=root / "verification/evidence/labelled_pool/runs"
    )
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    mismatched = 0
    for job in lb.jobs(args.registry, args.adbench, args.pool):
        stem = job["problem"].replace(":", "_")
        archive_path = args.archive / f"{stem}.json"
        if not archive_path.is_file():
            print(job["problem"], "no archived run")
            mismatched += 1
            continue
        archive = json.loads(archive_path.read_text())
        if "failed" in archive:
            print(job["problem"], "archived run failed; not recoverable")
            mismatched += 1
            continue
        record = recover(job, archive)
        (args.output / f"{stem}.json").write_text(
            json.dumps(record, indent=1, sort_keys=True) + "\n"
        )
        flag = "ok" if record["archive_replay"]["all"] else "REPLAY DIFFERS"
        mismatched += not record["archive_replay"]["all"]
        print(job["problem"], flag, flush=True)
    print(f"{mismatched} problems not confirmed")
    return 0 if mismatched == 0 else 1


def x_main__mutmut_19(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    parser.add_argument(
        "--registry", type=Path, default=root / "verification/evidence/dataset_registry"
    )
    parser.add_argument("--adbench", default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument(
        "--archive", type=Path, default=root / "verification/evidence/labelled_pool/runs"
    )
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    mismatched = 0
    for job in lb.jobs(args.registry, args.adbench, args.pool):
        stem = job["problem"].replace(":", "_")
        archive_path = args.archive / f"{stem}.json"
        if not archive_path.is_file():
            print(job["problem"], "no archived run")
            mismatched += 1
            continue
        archive = json.loads(archive_path.read_text())
        if "failed" in archive:
            print(job["problem"], "archived run failed; not recoverable")
            mismatched += 1
            continue
        record = recover(job, archive)
        (args.output / f"{stem}.json").write_text(
            json.dumps(record, indent=1, sort_keys=True) + "\n"
        )
        flag = "ok" if record["archive_replay"]["all"] else "REPLAY DIFFERS"
        mismatched += not record["archive_replay"]["all"]
        print(job["problem"], flag, flush=True)
    print(f"{mismatched} problems not confirmed")
    return 0 if mismatched == 0 else 1


def x_main__mutmut_20(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    parser.add_argument(
        "--registry", type=Path, default=root / "verification/evidence/dataset_registry"
    )
    parser.add_argument("--adbench", type=Path, )
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument(
        "--archive", type=Path, default=root / "verification/evidence/labelled_pool/runs"
    )
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    mismatched = 0
    for job in lb.jobs(args.registry, args.adbench, args.pool):
        stem = job["problem"].replace(":", "_")
        archive_path = args.archive / f"{stem}.json"
        if not archive_path.is_file():
            print(job["problem"], "no archived run")
            mismatched += 1
            continue
        archive = json.loads(archive_path.read_text())
        if "failed" in archive:
            print(job["problem"], "archived run failed; not recoverable")
            mismatched += 1
            continue
        record = recover(job, archive)
        (args.output / f"{stem}.json").write_text(
            json.dumps(record, indent=1, sort_keys=True) + "\n"
        )
        flag = "ok" if record["archive_replay"]["all"] else "REPLAY DIFFERS"
        mismatched += not record["archive_replay"]["all"]
        print(job["problem"], flag, flush=True)
    print(f"{mismatched} problems not confirmed")
    return 0 if mismatched == 0 else 1


def x_main__mutmut_21(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    parser.add_argument(
        "--registry", type=Path, default=root / "verification/evidence/dataset_registry"
    )
    parser.add_argument("XX--adbenchXX", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument(
        "--archive", type=Path, default=root / "verification/evidence/labelled_pool/runs"
    )
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    mismatched = 0
    for job in lb.jobs(args.registry, args.adbench, args.pool):
        stem = job["problem"].replace(":", "_")
        archive_path = args.archive / f"{stem}.json"
        if not archive_path.is_file():
            print(job["problem"], "no archived run")
            mismatched += 1
            continue
        archive = json.loads(archive_path.read_text())
        if "failed" in archive:
            print(job["problem"], "archived run failed; not recoverable")
            mismatched += 1
            continue
        record = recover(job, archive)
        (args.output / f"{stem}.json").write_text(
            json.dumps(record, indent=1, sort_keys=True) + "\n"
        )
        flag = "ok" if record["archive_replay"]["all"] else "REPLAY DIFFERS"
        mismatched += not record["archive_replay"]["all"]
        print(job["problem"], flag, flush=True)
    print(f"{mismatched} problems not confirmed")
    return 0 if mismatched == 0 else 1


def x_main__mutmut_22(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    parser.add_argument(
        "--registry", type=Path, default=root / "verification/evidence/dataset_registry"
    )
    parser.add_argument("--ADBENCH", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument(
        "--archive", type=Path, default=root / "verification/evidence/labelled_pool/runs"
    )
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    mismatched = 0
    for job in lb.jobs(args.registry, args.adbench, args.pool):
        stem = job["problem"].replace(":", "_")
        archive_path = args.archive / f"{stem}.json"
        if not archive_path.is_file():
            print(job["problem"], "no archived run")
            mismatched += 1
            continue
        archive = json.loads(archive_path.read_text())
        if "failed" in archive:
            print(job["problem"], "archived run failed; not recoverable")
            mismatched += 1
            continue
        record = recover(job, archive)
        (args.output / f"{stem}.json").write_text(
            json.dumps(record, indent=1, sort_keys=True) + "\n"
        )
        flag = "ok" if record["archive_replay"]["all"] else "REPLAY DIFFERS"
        mismatched += not record["archive_replay"]["all"]
        print(job["problem"], flag, flush=True)
    print(f"{mismatched} problems not confirmed")
    return 0 if mismatched == 0 else 1


def x_main__mutmut_23(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    parser.add_argument(
        "--registry", type=Path, default=root / "verification/evidence/dataset_registry"
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" * "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument(
        "--archive", type=Path, default=root / "verification/evidence/labelled_pool/runs"
    )
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    mismatched = 0
    for job in lb.jobs(args.registry, args.adbench, args.pool):
        stem = job["problem"].replace(":", "_")
        archive_path = args.archive / f"{stem}.json"
        if not archive_path.is_file():
            print(job["problem"], "no archived run")
            mismatched += 1
            continue
        archive = json.loads(archive_path.read_text())
        if "failed" in archive:
            print(job["problem"], "archived run failed; not recoverable")
            mismatched += 1
            continue
        record = recover(job, archive)
        (args.output / f"{stem}.json").write_text(
            json.dumps(record, indent=1, sort_keys=True) + "\n"
        )
        flag = "ok" if record["archive_replay"]["all"] else "REPLAY DIFFERS"
        mismatched += not record["archive_replay"]["all"]
        print(job["problem"], flag, flush=True)
    print(f"{mismatched} problems not confirmed")
    return 0 if mismatched == 0 else 1


def x_main__mutmut_24(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    parser.add_argument(
        "--registry", type=Path, default=root / "verification/evidence/dataset_registry"
    )
    parser.add_argument("--adbench", type=Path, default=root * "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument(
        "--archive", type=Path, default=root / "verification/evidence/labelled_pool/runs"
    )
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    mismatched = 0
    for job in lb.jobs(args.registry, args.adbench, args.pool):
        stem = job["problem"].replace(":", "_")
        archive_path = args.archive / f"{stem}.json"
        if not archive_path.is_file():
            print(job["problem"], "no archived run")
            mismatched += 1
            continue
        archive = json.loads(archive_path.read_text())
        if "failed" in archive:
            print(job["problem"], "archived run failed; not recoverable")
            mismatched += 1
            continue
        record = recover(job, archive)
        (args.output / f"{stem}.json").write_text(
            json.dumps(record, indent=1, sort_keys=True) + "\n"
        )
        flag = "ok" if record["archive_replay"]["all"] else "REPLAY DIFFERS"
        mismatched += not record["archive_replay"]["all"]
        print(job["problem"], flag, flush=True)
    print(f"{mismatched} problems not confirmed")
    return 0 if mismatched == 0 else 1


def x_main__mutmut_25(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    parser.add_argument(
        "--registry", type=Path, default=root / "verification/evidence/dataset_registry"
    )
    parser.add_argument("--adbench", type=Path, default=root / "XXdataXX" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument(
        "--archive", type=Path, default=root / "verification/evidence/labelled_pool/runs"
    )
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    mismatched = 0
    for job in lb.jobs(args.registry, args.adbench, args.pool):
        stem = job["problem"].replace(":", "_")
        archive_path = args.archive / f"{stem}.json"
        if not archive_path.is_file():
            print(job["problem"], "no archived run")
            mismatched += 1
            continue
        archive = json.loads(archive_path.read_text())
        if "failed" in archive:
            print(job["problem"], "archived run failed; not recoverable")
            mismatched += 1
            continue
        record = recover(job, archive)
        (args.output / f"{stem}.json").write_text(
            json.dumps(record, indent=1, sort_keys=True) + "\n"
        )
        flag = "ok" if record["archive_replay"]["all"] else "REPLAY DIFFERS"
        mismatched += not record["archive_replay"]["all"]
        print(job["problem"], flag, flush=True)
    print(f"{mismatched} problems not confirmed")
    return 0 if mismatched == 0 else 1


def x_main__mutmut_26(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    parser.add_argument(
        "--registry", type=Path, default=root / "verification/evidence/dataset_registry"
    )
    parser.add_argument("--adbench", type=Path, default=root / "DATA" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument(
        "--archive", type=Path, default=root / "verification/evidence/labelled_pool/runs"
    )
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    mismatched = 0
    for job in lb.jobs(args.registry, args.adbench, args.pool):
        stem = job["problem"].replace(":", "_")
        archive_path = args.archive / f"{stem}.json"
        if not archive_path.is_file():
            print(job["problem"], "no archived run")
            mismatched += 1
            continue
        archive = json.loads(archive_path.read_text())
        if "failed" in archive:
            print(job["problem"], "archived run failed; not recoverable")
            mismatched += 1
            continue
        record = recover(job, archive)
        (args.output / f"{stem}.json").write_text(
            json.dumps(record, indent=1, sort_keys=True) + "\n"
        )
        flag = "ok" if record["archive_replay"]["all"] else "REPLAY DIFFERS"
        mismatched += not record["archive_replay"]["all"]
        print(job["problem"], flag, flush=True)
    print(f"{mismatched} problems not confirmed")
    return 0 if mismatched == 0 else 1


def x_main__mutmut_27(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    parser.add_argument(
        "--registry", type=Path, default=root / "verification/evidence/dataset_registry"
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "XXadbenchXX")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument(
        "--archive", type=Path, default=root / "verification/evidence/labelled_pool/runs"
    )
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    mismatched = 0
    for job in lb.jobs(args.registry, args.adbench, args.pool):
        stem = job["problem"].replace(":", "_")
        archive_path = args.archive / f"{stem}.json"
        if not archive_path.is_file():
            print(job["problem"], "no archived run")
            mismatched += 1
            continue
        archive = json.loads(archive_path.read_text())
        if "failed" in archive:
            print(job["problem"], "archived run failed; not recoverable")
            mismatched += 1
            continue
        record = recover(job, archive)
        (args.output / f"{stem}.json").write_text(
            json.dumps(record, indent=1, sort_keys=True) + "\n"
        )
        flag = "ok" if record["archive_replay"]["all"] else "REPLAY DIFFERS"
        mismatched += not record["archive_replay"]["all"]
        print(job["problem"], flag, flush=True)
    print(f"{mismatched} problems not confirmed")
    return 0 if mismatched == 0 else 1


def x_main__mutmut_28(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    parser.add_argument(
        "--registry", type=Path, default=root / "verification/evidence/dataset_registry"
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "ADBENCH")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument(
        "--archive", type=Path, default=root / "verification/evidence/labelled_pool/runs"
    )
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    mismatched = 0
    for job in lb.jobs(args.registry, args.adbench, args.pool):
        stem = job["problem"].replace(":", "_")
        archive_path = args.archive / f"{stem}.json"
        if not archive_path.is_file():
            print(job["problem"], "no archived run")
            mismatched += 1
            continue
        archive = json.loads(archive_path.read_text())
        if "failed" in archive:
            print(job["problem"], "archived run failed; not recoverable")
            mismatched += 1
            continue
        record = recover(job, archive)
        (args.output / f"{stem}.json").write_text(
            json.dumps(record, indent=1, sort_keys=True) + "\n"
        )
        flag = "ok" if record["archive_replay"]["all"] else "REPLAY DIFFERS"
        mismatched += not record["archive_replay"]["all"]
        print(job["problem"], flag, flush=True)
    print(f"{mismatched} problems not confirmed")
    return 0 if mismatched == 0 else 1


def x_main__mutmut_29(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    parser.add_argument(
        "--registry", type=Path, default=root / "verification/evidence/dataset_registry"
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument(None, type=Path, default=root / "data" / "pool")
    parser.add_argument(
        "--archive", type=Path, default=root / "verification/evidence/labelled_pool/runs"
    )
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    mismatched = 0
    for job in lb.jobs(args.registry, args.adbench, args.pool):
        stem = job["problem"].replace(":", "_")
        archive_path = args.archive / f"{stem}.json"
        if not archive_path.is_file():
            print(job["problem"], "no archived run")
            mismatched += 1
            continue
        archive = json.loads(archive_path.read_text())
        if "failed" in archive:
            print(job["problem"], "archived run failed; not recoverable")
            mismatched += 1
            continue
        record = recover(job, archive)
        (args.output / f"{stem}.json").write_text(
            json.dumps(record, indent=1, sort_keys=True) + "\n"
        )
        flag = "ok" if record["archive_replay"]["all"] else "REPLAY DIFFERS"
        mismatched += not record["archive_replay"]["all"]
        print(job["problem"], flag, flush=True)
    print(f"{mismatched} problems not confirmed")
    return 0 if mismatched == 0 else 1


def x_main__mutmut_30(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    parser.add_argument(
        "--registry", type=Path, default=root / "verification/evidence/dataset_registry"
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=None, default=root / "data" / "pool")
    parser.add_argument(
        "--archive", type=Path, default=root / "verification/evidence/labelled_pool/runs"
    )
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    mismatched = 0
    for job in lb.jobs(args.registry, args.adbench, args.pool):
        stem = job["problem"].replace(":", "_")
        archive_path = args.archive / f"{stem}.json"
        if not archive_path.is_file():
            print(job["problem"], "no archived run")
            mismatched += 1
            continue
        archive = json.loads(archive_path.read_text())
        if "failed" in archive:
            print(job["problem"], "archived run failed; not recoverable")
            mismatched += 1
            continue
        record = recover(job, archive)
        (args.output / f"{stem}.json").write_text(
            json.dumps(record, indent=1, sort_keys=True) + "\n"
        )
        flag = "ok" if record["archive_replay"]["all"] else "REPLAY DIFFERS"
        mismatched += not record["archive_replay"]["all"]
        print(job["problem"], flag, flush=True)
    print(f"{mismatched} problems not confirmed")
    return 0 if mismatched == 0 else 1


def x_main__mutmut_31(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    parser.add_argument(
        "--registry", type=Path, default=root / "verification/evidence/dataset_registry"
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=None)
    parser.add_argument(
        "--archive", type=Path, default=root / "verification/evidence/labelled_pool/runs"
    )
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    mismatched = 0
    for job in lb.jobs(args.registry, args.adbench, args.pool):
        stem = job["problem"].replace(":", "_")
        archive_path = args.archive / f"{stem}.json"
        if not archive_path.is_file():
            print(job["problem"], "no archived run")
            mismatched += 1
            continue
        archive = json.loads(archive_path.read_text())
        if "failed" in archive:
            print(job["problem"], "archived run failed; not recoverable")
            mismatched += 1
            continue
        record = recover(job, archive)
        (args.output / f"{stem}.json").write_text(
            json.dumps(record, indent=1, sort_keys=True) + "\n"
        )
        flag = "ok" if record["archive_replay"]["all"] else "REPLAY DIFFERS"
        mismatched += not record["archive_replay"]["all"]
        print(job["problem"], flag, flush=True)
    print(f"{mismatched} problems not confirmed")
    return 0 if mismatched == 0 else 1


def x_main__mutmut_32(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    parser.add_argument(
        "--registry", type=Path, default=root / "verification/evidence/dataset_registry"
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument(type=Path, default=root / "data" / "pool")
    parser.add_argument(
        "--archive", type=Path, default=root / "verification/evidence/labelled_pool/runs"
    )
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    mismatched = 0
    for job in lb.jobs(args.registry, args.adbench, args.pool):
        stem = job["problem"].replace(":", "_")
        archive_path = args.archive / f"{stem}.json"
        if not archive_path.is_file():
            print(job["problem"], "no archived run")
            mismatched += 1
            continue
        archive = json.loads(archive_path.read_text())
        if "failed" in archive:
            print(job["problem"], "archived run failed; not recoverable")
            mismatched += 1
            continue
        record = recover(job, archive)
        (args.output / f"{stem}.json").write_text(
            json.dumps(record, indent=1, sort_keys=True) + "\n"
        )
        flag = "ok" if record["archive_replay"]["all"] else "REPLAY DIFFERS"
        mismatched += not record["archive_replay"]["all"]
        print(job["problem"], flag, flush=True)
    print(f"{mismatched} problems not confirmed")
    return 0 if mismatched == 0 else 1


def x_main__mutmut_33(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    parser.add_argument(
        "--registry", type=Path, default=root / "verification/evidence/dataset_registry"
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", default=root / "data" / "pool")
    parser.add_argument(
        "--archive", type=Path, default=root / "verification/evidence/labelled_pool/runs"
    )
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    mismatched = 0
    for job in lb.jobs(args.registry, args.adbench, args.pool):
        stem = job["problem"].replace(":", "_")
        archive_path = args.archive / f"{stem}.json"
        if not archive_path.is_file():
            print(job["problem"], "no archived run")
            mismatched += 1
            continue
        archive = json.loads(archive_path.read_text())
        if "failed" in archive:
            print(job["problem"], "archived run failed; not recoverable")
            mismatched += 1
            continue
        record = recover(job, archive)
        (args.output / f"{stem}.json").write_text(
            json.dumps(record, indent=1, sort_keys=True) + "\n"
        )
        flag = "ok" if record["archive_replay"]["all"] else "REPLAY DIFFERS"
        mismatched += not record["archive_replay"]["all"]
        print(job["problem"], flag, flush=True)
    print(f"{mismatched} problems not confirmed")
    return 0 if mismatched == 0 else 1


def x_main__mutmut_34(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    parser.add_argument(
        "--registry", type=Path, default=root / "verification/evidence/dataset_registry"
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, )
    parser.add_argument(
        "--archive", type=Path, default=root / "verification/evidence/labelled_pool/runs"
    )
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    mismatched = 0
    for job in lb.jobs(args.registry, args.adbench, args.pool):
        stem = job["problem"].replace(":", "_")
        archive_path = args.archive / f"{stem}.json"
        if not archive_path.is_file():
            print(job["problem"], "no archived run")
            mismatched += 1
            continue
        archive = json.loads(archive_path.read_text())
        if "failed" in archive:
            print(job["problem"], "archived run failed; not recoverable")
            mismatched += 1
            continue
        record = recover(job, archive)
        (args.output / f"{stem}.json").write_text(
            json.dumps(record, indent=1, sort_keys=True) + "\n"
        )
        flag = "ok" if record["archive_replay"]["all"] else "REPLAY DIFFERS"
        mismatched += not record["archive_replay"]["all"]
        print(job["problem"], flag, flush=True)
    print(f"{mismatched} problems not confirmed")
    return 0 if mismatched == 0 else 1


def x_main__mutmut_35(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    parser.add_argument(
        "--registry", type=Path, default=root / "verification/evidence/dataset_registry"
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("XX--poolXX", type=Path, default=root / "data" / "pool")
    parser.add_argument(
        "--archive", type=Path, default=root / "verification/evidence/labelled_pool/runs"
    )
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    mismatched = 0
    for job in lb.jobs(args.registry, args.adbench, args.pool):
        stem = job["problem"].replace(":", "_")
        archive_path = args.archive / f"{stem}.json"
        if not archive_path.is_file():
            print(job["problem"], "no archived run")
            mismatched += 1
            continue
        archive = json.loads(archive_path.read_text())
        if "failed" in archive:
            print(job["problem"], "archived run failed; not recoverable")
            mismatched += 1
            continue
        record = recover(job, archive)
        (args.output / f"{stem}.json").write_text(
            json.dumps(record, indent=1, sort_keys=True) + "\n"
        )
        flag = "ok" if record["archive_replay"]["all"] else "REPLAY DIFFERS"
        mismatched += not record["archive_replay"]["all"]
        print(job["problem"], flag, flush=True)
    print(f"{mismatched} problems not confirmed")
    return 0 if mismatched == 0 else 1


def x_main__mutmut_36(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    parser.add_argument(
        "--registry", type=Path, default=root / "verification/evidence/dataset_registry"
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--POOL", type=Path, default=root / "data" / "pool")
    parser.add_argument(
        "--archive", type=Path, default=root / "verification/evidence/labelled_pool/runs"
    )
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    mismatched = 0
    for job in lb.jobs(args.registry, args.adbench, args.pool):
        stem = job["problem"].replace(":", "_")
        archive_path = args.archive / f"{stem}.json"
        if not archive_path.is_file():
            print(job["problem"], "no archived run")
            mismatched += 1
            continue
        archive = json.loads(archive_path.read_text())
        if "failed" in archive:
            print(job["problem"], "archived run failed; not recoverable")
            mismatched += 1
            continue
        record = recover(job, archive)
        (args.output / f"{stem}.json").write_text(
            json.dumps(record, indent=1, sort_keys=True) + "\n"
        )
        flag = "ok" if record["archive_replay"]["all"] else "REPLAY DIFFERS"
        mismatched += not record["archive_replay"]["all"]
        print(job["problem"], flag, flush=True)
    print(f"{mismatched} problems not confirmed")
    return 0 if mismatched == 0 else 1


def x_main__mutmut_37(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    parser.add_argument(
        "--registry", type=Path, default=root / "verification/evidence/dataset_registry"
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" * "pool")
    parser.add_argument(
        "--archive", type=Path, default=root / "verification/evidence/labelled_pool/runs"
    )
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    mismatched = 0
    for job in lb.jobs(args.registry, args.adbench, args.pool):
        stem = job["problem"].replace(":", "_")
        archive_path = args.archive / f"{stem}.json"
        if not archive_path.is_file():
            print(job["problem"], "no archived run")
            mismatched += 1
            continue
        archive = json.loads(archive_path.read_text())
        if "failed" in archive:
            print(job["problem"], "archived run failed; not recoverable")
            mismatched += 1
            continue
        record = recover(job, archive)
        (args.output / f"{stem}.json").write_text(
            json.dumps(record, indent=1, sort_keys=True) + "\n"
        )
        flag = "ok" if record["archive_replay"]["all"] else "REPLAY DIFFERS"
        mismatched += not record["archive_replay"]["all"]
        print(job["problem"], flag, flush=True)
    print(f"{mismatched} problems not confirmed")
    return 0 if mismatched == 0 else 1


def x_main__mutmut_38(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    parser.add_argument(
        "--registry", type=Path, default=root / "verification/evidence/dataset_registry"
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root * "data" / "pool")
    parser.add_argument(
        "--archive", type=Path, default=root / "verification/evidence/labelled_pool/runs"
    )
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    mismatched = 0
    for job in lb.jobs(args.registry, args.adbench, args.pool):
        stem = job["problem"].replace(":", "_")
        archive_path = args.archive / f"{stem}.json"
        if not archive_path.is_file():
            print(job["problem"], "no archived run")
            mismatched += 1
            continue
        archive = json.loads(archive_path.read_text())
        if "failed" in archive:
            print(job["problem"], "archived run failed; not recoverable")
            mismatched += 1
            continue
        record = recover(job, archive)
        (args.output / f"{stem}.json").write_text(
            json.dumps(record, indent=1, sort_keys=True) + "\n"
        )
        flag = "ok" if record["archive_replay"]["all"] else "REPLAY DIFFERS"
        mismatched += not record["archive_replay"]["all"]
        print(job["problem"], flag, flush=True)
    print(f"{mismatched} problems not confirmed")
    return 0 if mismatched == 0 else 1


def x_main__mutmut_39(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    parser.add_argument(
        "--registry", type=Path, default=root / "verification/evidence/dataset_registry"
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "XXdataXX" / "pool")
    parser.add_argument(
        "--archive", type=Path, default=root / "verification/evidence/labelled_pool/runs"
    )
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    mismatched = 0
    for job in lb.jobs(args.registry, args.adbench, args.pool):
        stem = job["problem"].replace(":", "_")
        archive_path = args.archive / f"{stem}.json"
        if not archive_path.is_file():
            print(job["problem"], "no archived run")
            mismatched += 1
            continue
        archive = json.loads(archive_path.read_text())
        if "failed" in archive:
            print(job["problem"], "archived run failed; not recoverable")
            mismatched += 1
            continue
        record = recover(job, archive)
        (args.output / f"{stem}.json").write_text(
            json.dumps(record, indent=1, sort_keys=True) + "\n"
        )
        flag = "ok" if record["archive_replay"]["all"] else "REPLAY DIFFERS"
        mismatched += not record["archive_replay"]["all"]
        print(job["problem"], flag, flush=True)
    print(f"{mismatched} problems not confirmed")
    return 0 if mismatched == 0 else 1


def x_main__mutmut_40(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    parser.add_argument(
        "--registry", type=Path, default=root / "verification/evidence/dataset_registry"
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "DATA" / "pool")
    parser.add_argument(
        "--archive", type=Path, default=root / "verification/evidence/labelled_pool/runs"
    )
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    mismatched = 0
    for job in lb.jobs(args.registry, args.adbench, args.pool):
        stem = job["problem"].replace(":", "_")
        archive_path = args.archive / f"{stem}.json"
        if not archive_path.is_file():
            print(job["problem"], "no archived run")
            mismatched += 1
            continue
        archive = json.loads(archive_path.read_text())
        if "failed" in archive:
            print(job["problem"], "archived run failed; not recoverable")
            mismatched += 1
            continue
        record = recover(job, archive)
        (args.output / f"{stem}.json").write_text(
            json.dumps(record, indent=1, sort_keys=True) + "\n"
        )
        flag = "ok" if record["archive_replay"]["all"] else "REPLAY DIFFERS"
        mismatched += not record["archive_replay"]["all"]
        print(job["problem"], flag, flush=True)
    print(f"{mismatched} problems not confirmed")
    return 0 if mismatched == 0 else 1


def x_main__mutmut_41(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    parser.add_argument(
        "--registry", type=Path, default=root / "verification/evidence/dataset_registry"
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "XXpoolXX")
    parser.add_argument(
        "--archive", type=Path, default=root / "verification/evidence/labelled_pool/runs"
    )
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    mismatched = 0
    for job in lb.jobs(args.registry, args.adbench, args.pool):
        stem = job["problem"].replace(":", "_")
        archive_path = args.archive / f"{stem}.json"
        if not archive_path.is_file():
            print(job["problem"], "no archived run")
            mismatched += 1
            continue
        archive = json.loads(archive_path.read_text())
        if "failed" in archive:
            print(job["problem"], "archived run failed; not recoverable")
            mismatched += 1
            continue
        record = recover(job, archive)
        (args.output / f"{stem}.json").write_text(
            json.dumps(record, indent=1, sort_keys=True) + "\n"
        )
        flag = "ok" if record["archive_replay"]["all"] else "REPLAY DIFFERS"
        mismatched += not record["archive_replay"]["all"]
        print(job["problem"], flag, flush=True)
    print(f"{mismatched} problems not confirmed")
    return 0 if mismatched == 0 else 1


def x_main__mutmut_42(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    parser.add_argument(
        "--registry", type=Path, default=root / "verification/evidence/dataset_registry"
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "POOL")
    parser.add_argument(
        "--archive", type=Path, default=root / "verification/evidence/labelled_pool/runs"
    )
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    mismatched = 0
    for job in lb.jobs(args.registry, args.adbench, args.pool):
        stem = job["problem"].replace(":", "_")
        archive_path = args.archive / f"{stem}.json"
        if not archive_path.is_file():
            print(job["problem"], "no archived run")
            mismatched += 1
            continue
        archive = json.loads(archive_path.read_text())
        if "failed" in archive:
            print(job["problem"], "archived run failed; not recoverable")
            mismatched += 1
            continue
        record = recover(job, archive)
        (args.output / f"{stem}.json").write_text(
            json.dumps(record, indent=1, sort_keys=True) + "\n"
        )
        flag = "ok" if record["archive_replay"]["all"] else "REPLAY DIFFERS"
        mismatched += not record["archive_replay"]["all"]
        print(job["problem"], flag, flush=True)
    print(f"{mismatched} problems not confirmed")
    return 0 if mismatched == 0 else 1


def x_main__mutmut_43(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    parser.add_argument(
        "--registry", type=Path, default=root / "verification/evidence/dataset_registry"
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument(
        None, type=Path, default=root / "verification/evidence/labelled_pool/runs"
    )
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    mismatched = 0
    for job in lb.jobs(args.registry, args.adbench, args.pool):
        stem = job["problem"].replace(":", "_")
        archive_path = args.archive / f"{stem}.json"
        if not archive_path.is_file():
            print(job["problem"], "no archived run")
            mismatched += 1
            continue
        archive = json.loads(archive_path.read_text())
        if "failed" in archive:
            print(job["problem"], "archived run failed; not recoverable")
            mismatched += 1
            continue
        record = recover(job, archive)
        (args.output / f"{stem}.json").write_text(
            json.dumps(record, indent=1, sort_keys=True) + "\n"
        )
        flag = "ok" if record["archive_replay"]["all"] else "REPLAY DIFFERS"
        mismatched += not record["archive_replay"]["all"]
        print(job["problem"], flag, flush=True)
    print(f"{mismatched} problems not confirmed")
    return 0 if mismatched == 0 else 1


def x_main__mutmut_44(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    parser.add_argument(
        "--registry", type=Path, default=root / "verification/evidence/dataset_registry"
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument(
        "--archive", type=None, default=root / "verification/evidence/labelled_pool/runs"
    )
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    mismatched = 0
    for job in lb.jobs(args.registry, args.adbench, args.pool):
        stem = job["problem"].replace(":", "_")
        archive_path = args.archive / f"{stem}.json"
        if not archive_path.is_file():
            print(job["problem"], "no archived run")
            mismatched += 1
            continue
        archive = json.loads(archive_path.read_text())
        if "failed" in archive:
            print(job["problem"], "archived run failed; not recoverable")
            mismatched += 1
            continue
        record = recover(job, archive)
        (args.output / f"{stem}.json").write_text(
            json.dumps(record, indent=1, sort_keys=True) + "\n"
        )
        flag = "ok" if record["archive_replay"]["all"] else "REPLAY DIFFERS"
        mismatched += not record["archive_replay"]["all"]
        print(job["problem"], flag, flush=True)
    print(f"{mismatched} problems not confirmed")
    return 0 if mismatched == 0 else 1


def x_main__mutmut_45(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    parser.add_argument(
        "--registry", type=Path, default=root / "verification/evidence/dataset_registry"
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument(
        "--archive", type=Path, default=None
    )
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    mismatched = 0
    for job in lb.jobs(args.registry, args.adbench, args.pool):
        stem = job["problem"].replace(":", "_")
        archive_path = args.archive / f"{stem}.json"
        if not archive_path.is_file():
            print(job["problem"], "no archived run")
            mismatched += 1
            continue
        archive = json.loads(archive_path.read_text())
        if "failed" in archive:
            print(job["problem"], "archived run failed; not recoverable")
            mismatched += 1
            continue
        record = recover(job, archive)
        (args.output / f"{stem}.json").write_text(
            json.dumps(record, indent=1, sort_keys=True) + "\n"
        )
        flag = "ok" if record["archive_replay"]["all"] else "REPLAY DIFFERS"
        mismatched += not record["archive_replay"]["all"]
        print(job["problem"], flag, flush=True)
    print(f"{mismatched} problems not confirmed")
    return 0 if mismatched == 0 else 1


def x_main__mutmut_46(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    parser.add_argument(
        "--registry", type=Path, default=root / "verification/evidence/dataset_registry"
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument(
        type=Path, default=root / "verification/evidence/labelled_pool/runs"
    )
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    mismatched = 0
    for job in lb.jobs(args.registry, args.adbench, args.pool):
        stem = job["problem"].replace(":", "_")
        archive_path = args.archive / f"{stem}.json"
        if not archive_path.is_file():
            print(job["problem"], "no archived run")
            mismatched += 1
            continue
        archive = json.loads(archive_path.read_text())
        if "failed" in archive:
            print(job["problem"], "archived run failed; not recoverable")
            mismatched += 1
            continue
        record = recover(job, archive)
        (args.output / f"{stem}.json").write_text(
            json.dumps(record, indent=1, sort_keys=True) + "\n"
        )
        flag = "ok" if record["archive_replay"]["all"] else "REPLAY DIFFERS"
        mismatched += not record["archive_replay"]["all"]
        print(job["problem"], flag, flush=True)
    print(f"{mismatched} problems not confirmed")
    return 0 if mismatched == 0 else 1


def x_main__mutmut_47(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    parser.add_argument(
        "--registry", type=Path, default=root / "verification/evidence/dataset_registry"
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument(
        "--archive", default=root / "verification/evidence/labelled_pool/runs"
    )
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    mismatched = 0
    for job in lb.jobs(args.registry, args.adbench, args.pool):
        stem = job["problem"].replace(":", "_")
        archive_path = args.archive / f"{stem}.json"
        if not archive_path.is_file():
            print(job["problem"], "no archived run")
            mismatched += 1
            continue
        archive = json.loads(archive_path.read_text())
        if "failed" in archive:
            print(job["problem"], "archived run failed; not recoverable")
            mismatched += 1
            continue
        record = recover(job, archive)
        (args.output / f"{stem}.json").write_text(
            json.dumps(record, indent=1, sort_keys=True) + "\n"
        )
        flag = "ok" if record["archive_replay"]["all"] else "REPLAY DIFFERS"
        mismatched += not record["archive_replay"]["all"]
        print(job["problem"], flag, flush=True)
    print(f"{mismatched} problems not confirmed")
    return 0 if mismatched == 0 else 1


def x_main__mutmut_48(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    parser.add_argument(
        "--registry", type=Path, default=root / "verification/evidence/dataset_registry"
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument(
        "--archive", type=Path, )
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    mismatched = 0
    for job in lb.jobs(args.registry, args.adbench, args.pool):
        stem = job["problem"].replace(":", "_")
        archive_path = args.archive / f"{stem}.json"
        if not archive_path.is_file():
            print(job["problem"], "no archived run")
            mismatched += 1
            continue
        archive = json.loads(archive_path.read_text())
        if "failed" in archive:
            print(job["problem"], "archived run failed; not recoverable")
            mismatched += 1
            continue
        record = recover(job, archive)
        (args.output / f"{stem}.json").write_text(
            json.dumps(record, indent=1, sort_keys=True) + "\n"
        )
        flag = "ok" if record["archive_replay"]["all"] else "REPLAY DIFFERS"
        mismatched += not record["archive_replay"]["all"]
        print(job["problem"], flag, flush=True)
    print(f"{mismatched} problems not confirmed")
    return 0 if mismatched == 0 else 1


def x_main__mutmut_49(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    parser.add_argument(
        "--registry", type=Path, default=root / "verification/evidence/dataset_registry"
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument(
        "XX--archiveXX", type=Path, default=root / "verification/evidence/labelled_pool/runs"
    )
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    mismatched = 0
    for job in lb.jobs(args.registry, args.adbench, args.pool):
        stem = job["problem"].replace(":", "_")
        archive_path = args.archive / f"{stem}.json"
        if not archive_path.is_file():
            print(job["problem"], "no archived run")
            mismatched += 1
            continue
        archive = json.loads(archive_path.read_text())
        if "failed" in archive:
            print(job["problem"], "archived run failed; not recoverable")
            mismatched += 1
            continue
        record = recover(job, archive)
        (args.output / f"{stem}.json").write_text(
            json.dumps(record, indent=1, sort_keys=True) + "\n"
        )
        flag = "ok" if record["archive_replay"]["all"] else "REPLAY DIFFERS"
        mismatched += not record["archive_replay"]["all"]
        print(job["problem"], flag, flush=True)
    print(f"{mismatched} problems not confirmed")
    return 0 if mismatched == 0 else 1


def x_main__mutmut_50(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    parser.add_argument(
        "--registry", type=Path, default=root / "verification/evidence/dataset_registry"
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument(
        "--ARCHIVE", type=Path, default=root / "verification/evidence/labelled_pool/runs"
    )
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    mismatched = 0
    for job in lb.jobs(args.registry, args.adbench, args.pool):
        stem = job["problem"].replace(":", "_")
        archive_path = args.archive / f"{stem}.json"
        if not archive_path.is_file():
            print(job["problem"], "no archived run")
            mismatched += 1
            continue
        archive = json.loads(archive_path.read_text())
        if "failed" in archive:
            print(job["problem"], "archived run failed; not recoverable")
            mismatched += 1
            continue
        record = recover(job, archive)
        (args.output / f"{stem}.json").write_text(
            json.dumps(record, indent=1, sort_keys=True) + "\n"
        )
        flag = "ok" if record["archive_replay"]["all"] else "REPLAY DIFFERS"
        mismatched += not record["archive_replay"]["all"]
        print(job["problem"], flag, flush=True)
    print(f"{mismatched} problems not confirmed")
    return 0 if mismatched == 0 else 1


def x_main__mutmut_51(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    parser.add_argument(
        "--registry", type=Path, default=root / "verification/evidence/dataset_registry"
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument(
        "--archive", type=Path, default=root * "verification/evidence/labelled_pool/runs"
    )
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    mismatched = 0
    for job in lb.jobs(args.registry, args.adbench, args.pool):
        stem = job["problem"].replace(":", "_")
        archive_path = args.archive / f"{stem}.json"
        if not archive_path.is_file():
            print(job["problem"], "no archived run")
            mismatched += 1
            continue
        archive = json.loads(archive_path.read_text())
        if "failed" in archive:
            print(job["problem"], "archived run failed; not recoverable")
            mismatched += 1
            continue
        record = recover(job, archive)
        (args.output / f"{stem}.json").write_text(
            json.dumps(record, indent=1, sort_keys=True) + "\n"
        )
        flag = "ok" if record["archive_replay"]["all"] else "REPLAY DIFFERS"
        mismatched += not record["archive_replay"]["all"]
        print(job["problem"], flag, flush=True)
    print(f"{mismatched} problems not confirmed")
    return 0 if mismatched == 0 else 1


def x_main__mutmut_52(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    parser.add_argument(
        "--registry", type=Path, default=root / "verification/evidence/dataset_registry"
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument(
        "--archive", type=Path, default=root / "XXverification/evidence/labelled_pool/runsXX"
    )
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    mismatched = 0
    for job in lb.jobs(args.registry, args.adbench, args.pool):
        stem = job["problem"].replace(":", "_")
        archive_path = args.archive / f"{stem}.json"
        if not archive_path.is_file():
            print(job["problem"], "no archived run")
            mismatched += 1
            continue
        archive = json.loads(archive_path.read_text())
        if "failed" in archive:
            print(job["problem"], "archived run failed; not recoverable")
            mismatched += 1
            continue
        record = recover(job, archive)
        (args.output / f"{stem}.json").write_text(
            json.dumps(record, indent=1, sort_keys=True) + "\n"
        )
        flag = "ok" if record["archive_replay"]["all"] else "REPLAY DIFFERS"
        mismatched += not record["archive_replay"]["all"]
        print(job["problem"], flag, flush=True)
    print(f"{mismatched} problems not confirmed")
    return 0 if mismatched == 0 else 1


def x_main__mutmut_53(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    parser.add_argument(
        "--registry", type=Path, default=root / "verification/evidence/dataset_registry"
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument(
        "--archive", type=Path, default=root / "VERIFICATION/EVIDENCE/LABELLED_POOL/RUNS"
    )
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    mismatched = 0
    for job in lb.jobs(args.registry, args.adbench, args.pool):
        stem = job["problem"].replace(":", "_")
        archive_path = args.archive / f"{stem}.json"
        if not archive_path.is_file():
            print(job["problem"], "no archived run")
            mismatched += 1
            continue
        archive = json.loads(archive_path.read_text())
        if "failed" in archive:
            print(job["problem"], "archived run failed; not recoverable")
            mismatched += 1
            continue
        record = recover(job, archive)
        (args.output / f"{stem}.json").write_text(
            json.dumps(record, indent=1, sort_keys=True) + "\n"
        )
        flag = "ok" if record["archive_replay"]["all"] else "REPLAY DIFFERS"
        mismatched += not record["archive_replay"]["all"]
        print(job["problem"], flag, flush=True)
    print(f"{mismatched} problems not confirmed")
    return 0 if mismatched == 0 else 1


def x_main__mutmut_54(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    parser.add_argument(
        "--registry", type=Path, default=root / "verification/evidence/dataset_registry"
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument(
        "--archive", type=Path, default=root / "verification/evidence/labelled_pool/runs"
    )
    parser.add_argument(None, type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    mismatched = 0
    for job in lb.jobs(args.registry, args.adbench, args.pool):
        stem = job["problem"].replace(":", "_")
        archive_path = args.archive / f"{stem}.json"
        if not archive_path.is_file():
            print(job["problem"], "no archived run")
            mismatched += 1
            continue
        archive = json.loads(archive_path.read_text())
        if "failed" in archive:
            print(job["problem"], "archived run failed; not recoverable")
            mismatched += 1
            continue
        record = recover(job, archive)
        (args.output / f"{stem}.json").write_text(
            json.dumps(record, indent=1, sort_keys=True) + "\n"
        )
        flag = "ok" if record["archive_replay"]["all"] else "REPLAY DIFFERS"
        mismatched += not record["archive_replay"]["all"]
        print(job["problem"], flag, flush=True)
    print(f"{mismatched} problems not confirmed")
    return 0 if mismatched == 0 else 1


def x_main__mutmut_55(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    parser.add_argument(
        "--registry", type=Path, default=root / "verification/evidence/dataset_registry"
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument(
        "--archive", type=Path, default=root / "verification/evidence/labelled_pool/runs"
    )
    parser.add_argument("--output", type=None, required=True)
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    mismatched = 0
    for job in lb.jobs(args.registry, args.adbench, args.pool):
        stem = job["problem"].replace(":", "_")
        archive_path = args.archive / f"{stem}.json"
        if not archive_path.is_file():
            print(job["problem"], "no archived run")
            mismatched += 1
            continue
        archive = json.loads(archive_path.read_text())
        if "failed" in archive:
            print(job["problem"], "archived run failed; not recoverable")
            mismatched += 1
            continue
        record = recover(job, archive)
        (args.output / f"{stem}.json").write_text(
            json.dumps(record, indent=1, sort_keys=True) + "\n"
        )
        flag = "ok" if record["archive_replay"]["all"] else "REPLAY DIFFERS"
        mismatched += not record["archive_replay"]["all"]
        print(job["problem"], flag, flush=True)
    print(f"{mismatched} problems not confirmed")
    return 0 if mismatched == 0 else 1


def x_main__mutmut_56(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    parser.add_argument(
        "--registry", type=Path, default=root / "verification/evidence/dataset_registry"
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument(
        "--archive", type=Path, default=root / "verification/evidence/labelled_pool/runs"
    )
    parser.add_argument("--output", type=Path, required=None)
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    mismatched = 0
    for job in lb.jobs(args.registry, args.adbench, args.pool):
        stem = job["problem"].replace(":", "_")
        archive_path = args.archive / f"{stem}.json"
        if not archive_path.is_file():
            print(job["problem"], "no archived run")
            mismatched += 1
            continue
        archive = json.loads(archive_path.read_text())
        if "failed" in archive:
            print(job["problem"], "archived run failed; not recoverable")
            mismatched += 1
            continue
        record = recover(job, archive)
        (args.output / f"{stem}.json").write_text(
            json.dumps(record, indent=1, sort_keys=True) + "\n"
        )
        flag = "ok" if record["archive_replay"]["all"] else "REPLAY DIFFERS"
        mismatched += not record["archive_replay"]["all"]
        print(job["problem"], flag, flush=True)
    print(f"{mismatched} problems not confirmed")
    return 0 if mismatched == 0 else 1


def x_main__mutmut_57(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    parser.add_argument(
        "--registry", type=Path, default=root / "verification/evidence/dataset_registry"
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument(
        "--archive", type=Path, default=root / "verification/evidence/labelled_pool/runs"
    )
    parser.add_argument(type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    mismatched = 0
    for job in lb.jobs(args.registry, args.adbench, args.pool):
        stem = job["problem"].replace(":", "_")
        archive_path = args.archive / f"{stem}.json"
        if not archive_path.is_file():
            print(job["problem"], "no archived run")
            mismatched += 1
            continue
        archive = json.loads(archive_path.read_text())
        if "failed" in archive:
            print(job["problem"], "archived run failed; not recoverable")
            mismatched += 1
            continue
        record = recover(job, archive)
        (args.output / f"{stem}.json").write_text(
            json.dumps(record, indent=1, sort_keys=True) + "\n"
        )
        flag = "ok" if record["archive_replay"]["all"] else "REPLAY DIFFERS"
        mismatched += not record["archive_replay"]["all"]
        print(job["problem"], flag, flush=True)
    print(f"{mismatched} problems not confirmed")
    return 0 if mismatched == 0 else 1


def x_main__mutmut_58(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    parser.add_argument(
        "--registry", type=Path, default=root / "verification/evidence/dataset_registry"
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument(
        "--archive", type=Path, default=root / "verification/evidence/labelled_pool/runs"
    )
    parser.add_argument("--output", required=True)
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    mismatched = 0
    for job in lb.jobs(args.registry, args.adbench, args.pool):
        stem = job["problem"].replace(":", "_")
        archive_path = args.archive / f"{stem}.json"
        if not archive_path.is_file():
            print(job["problem"], "no archived run")
            mismatched += 1
            continue
        archive = json.loads(archive_path.read_text())
        if "failed" in archive:
            print(job["problem"], "archived run failed; not recoverable")
            mismatched += 1
            continue
        record = recover(job, archive)
        (args.output / f"{stem}.json").write_text(
            json.dumps(record, indent=1, sort_keys=True) + "\n"
        )
        flag = "ok" if record["archive_replay"]["all"] else "REPLAY DIFFERS"
        mismatched += not record["archive_replay"]["all"]
        print(job["problem"], flag, flush=True)
    print(f"{mismatched} problems not confirmed")
    return 0 if mismatched == 0 else 1


def x_main__mutmut_59(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    parser.add_argument(
        "--registry", type=Path, default=root / "verification/evidence/dataset_registry"
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument(
        "--archive", type=Path, default=root / "verification/evidence/labelled_pool/runs"
    )
    parser.add_argument("--output", type=Path, )
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    mismatched = 0
    for job in lb.jobs(args.registry, args.adbench, args.pool):
        stem = job["problem"].replace(":", "_")
        archive_path = args.archive / f"{stem}.json"
        if not archive_path.is_file():
            print(job["problem"], "no archived run")
            mismatched += 1
            continue
        archive = json.loads(archive_path.read_text())
        if "failed" in archive:
            print(job["problem"], "archived run failed; not recoverable")
            mismatched += 1
            continue
        record = recover(job, archive)
        (args.output / f"{stem}.json").write_text(
            json.dumps(record, indent=1, sort_keys=True) + "\n"
        )
        flag = "ok" if record["archive_replay"]["all"] else "REPLAY DIFFERS"
        mismatched += not record["archive_replay"]["all"]
        print(job["problem"], flag, flush=True)
    print(f"{mismatched} problems not confirmed")
    return 0 if mismatched == 0 else 1


def x_main__mutmut_60(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    parser.add_argument(
        "--registry", type=Path, default=root / "verification/evidence/dataset_registry"
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument(
        "--archive", type=Path, default=root / "verification/evidence/labelled_pool/runs"
    )
    parser.add_argument("XX--outputXX", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    mismatched = 0
    for job in lb.jobs(args.registry, args.adbench, args.pool):
        stem = job["problem"].replace(":", "_")
        archive_path = args.archive / f"{stem}.json"
        if not archive_path.is_file():
            print(job["problem"], "no archived run")
            mismatched += 1
            continue
        archive = json.loads(archive_path.read_text())
        if "failed" in archive:
            print(job["problem"], "archived run failed; not recoverable")
            mismatched += 1
            continue
        record = recover(job, archive)
        (args.output / f"{stem}.json").write_text(
            json.dumps(record, indent=1, sort_keys=True) + "\n"
        )
        flag = "ok" if record["archive_replay"]["all"] else "REPLAY DIFFERS"
        mismatched += not record["archive_replay"]["all"]
        print(job["problem"], flag, flush=True)
    print(f"{mismatched} problems not confirmed")
    return 0 if mismatched == 0 else 1


def x_main__mutmut_61(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    parser.add_argument(
        "--registry", type=Path, default=root / "verification/evidence/dataset_registry"
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument(
        "--archive", type=Path, default=root / "verification/evidence/labelled_pool/runs"
    )
    parser.add_argument("--OUTPUT", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    mismatched = 0
    for job in lb.jobs(args.registry, args.adbench, args.pool):
        stem = job["problem"].replace(":", "_")
        archive_path = args.archive / f"{stem}.json"
        if not archive_path.is_file():
            print(job["problem"], "no archived run")
            mismatched += 1
            continue
        archive = json.loads(archive_path.read_text())
        if "failed" in archive:
            print(job["problem"], "archived run failed; not recoverable")
            mismatched += 1
            continue
        record = recover(job, archive)
        (args.output / f"{stem}.json").write_text(
            json.dumps(record, indent=1, sort_keys=True) + "\n"
        )
        flag = "ok" if record["archive_replay"]["all"] else "REPLAY DIFFERS"
        mismatched += not record["archive_replay"]["all"]
        print(job["problem"], flag, flush=True)
    print(f"{mismatched} problems not confirmed")
    return 0 if mismatched == 0 else 1


def x_main__mutmut_62(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    parser.add_argument(
        "--registry", type=Path, default=root / "verification/evidence/dataset_registry"
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument(
        "--archive", type=Path, default=root / "verification/evidence/labelled_pool/runs"
    )
    parser.add_argument("--output", type=Path, required=False)
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    mismatched = 0
    for job in lb.jobs(args.registry, args.adbench, args.pool):
        stem = job["problem"].replace(":", "_")
        archive_path = args.archive / f"{stem}.json"
        if not archive_path.is_file():
            print(job["problem"], "no archived run")
            mismatched += 1
            continue
        archive = json.loads(archive_path.read_text())
        if "failed" in archive:
            print(job["problem"], "archived run failed; not recoverable")
            mismatched += 1
            continue
        record = recover(job, archive)
        (args.output / f"{stem}.json").write_text(
            json.dumps(record, indent=1, sort_keys=True) + "\n"
        )
        flag = "ok" if record["archive_replay"]["all"] else "REPLAY DIFFERS"
        mismatched += not record["archive_replay"]["all"]
        print(job["problem"], flag, flush=True)
    print(f"{mismatched} problems not confirmed")
    return 0 if mismatched == 0 else 1


def x_main__mutmut_63(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    parser.add_argument(
        "--registry", type=Path, default=root / "verification/evidence/dataset_registry"
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument(
        "--archive", type=Path, default=root / "verification/evidence/labelled_pool/runs"
    )
    parser.add_argument("--output", type=Path, required=True)
    args = None
    args.output.mkdir(parents=True, exist_ok=True)
    mismatched = 0
    for job in lb.jobs(args.registry, args.adbench, args.pool):
        stem = job["problem"].replace(":", "_")
        archive_path = args.archive / f"{stem}.json"
        if not archive_path.is_file():
            print(job["problem"], "no archived run")
            mismatched += 1
            continue
        archive = json.loads(archive_path.read_text())
        if "failed" in archive:
            print(job["problem"], "archived run failed; not recoverable")
            mismatched += 1
            continue
        record = recover(job, archive)
        (args.output / f"{stem}.json").write_text(
            json.dumps(record, indent=1, sort_keys=True) + "\n"
        )
        flag = "ok" if record["archive_replay"]["all"] else "REPLAY DIFFERS"
        mismatched += not record["archive_replay"]["all"]
        print(job["problem"], flag, flush=True)
    print(f"{mismatched} problems not confirmed")
    return 0 if mismatched == 0 else 1


def x_main__mutmut_64(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    parser.add_argument(
        "--registry", type=Path, default=root / "verification/evidence/dataset_registry"
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument(
        "--archive", type=Path, default=root / "verification/evidence/labelled_pool/runs"
    )
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(None)
    args.output.mkdir(parents=True, exist_ok=True)
    mismatched = 0
    for job in lb.jobs(args.registry, args.adbench, args.pool):
        stem = job["problem"].replace(":", "_")
        archive_path = args.archive / f"{stem}.json"
        if not archive_path.is_file():
            print(job["problem"], "no archived run")
            mismatched += 1
            continue
        archive = json.loads(archive_path.read_text())
        if "failed" in archive:
            print(job["problem"], "archived run failed; not recoverable")
            mismatched += 1
            continue
        record = recover(job, archive)
        (args.output / f"{stem}.json").write_text(
            json.dumps(record, indent=1, sort_keys=True) + "\n"
        )
        flag = "ok" if record["archive_replay"]["all"] else "REPLAY DIFFERS"
        mismatched += not record["archive_replay"]["all"]
        print(job["problem"], flag, flush=True)
    print(f"{mismatched} problems not confirmed")
    return 0 if mismatched == 0 else 1


def x_main__mutmut_65(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    parser.add_argument(
        "--registry", type=Path, default=root / "verification/evidence/dataset_registry"
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument(
        "--archive", type=Path, default=root / "verification/evidence/labelled_pool/runs"
    )
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.mkdir(parents=None, exist_ok=True)
    mismatched = 0
    for job in lb.jobs(args.registry, args.adbench, args.pool):
        stem = job["problem"].replace(":", "_")
        archive_path = args.archive / f"{stem}.json"
        if not archive_path.is_file():
            print(job["problem"], "no archived run")
            mismatched += 1
            continue
        archive = json.loads(archive_path.read_text())
        if "failed" in archive:
            print(job["problem"], "archived run failed; not recoverable")
            mismatched += 1
            continue
        record = recover(job, archive)
        (args.output / f"{stem}.json").write_text(
            json.dumps(record, indent=1, sort_keys=True) + "\n"
        )
        flag = "ok" if record["archive_replay"]["all"] else "REPLAY DIFFERS"
        mismatched += not record["archive_replay"]["all"]
        print(job["problem"], flag, flush=True)
    print(f"{mismatched} problems not confirmed")
    return 0 if mismatched == 0 else 1


def x_main__mutmut_66(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    parser.add_argument(
        "--registry", type=Path, default=root / "verification/evidence/dataset_registry"
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument(
        "--archive", type=Path, default=root / "verification/evidence/labelled_pool/runs"
    )
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=None)
    mismatched = 0
    for job in lb.jobs(args.registry, args.adbench, args.pool):
        stem = job["problem"].replace(":", "_")
        archive_path = args.archive / f"{stem}.json"
        if not archive_path.is_file():
            print(job["problem"], "no archived run")
            mismatched += 1
            continue
        archive = json.loads(archive_path.read_text())
        if "failed" in archive:
            print(job["problem"], "archived run failed; not recoverable")
            mismatched += 1
            continue
        record = recover(job, archive)
        (args.output / f"{stem}.json").write_text(
            json.dumps(record, indent=1, sort_keys=True) + "\n"
        )
        flag = "ok" if record["archive_replay"]["all"] else "REPLAY DIFFERS"
        mismatched += not record["archive_replay"]["all"]
        print(job["problem"], flag, flush=True)
    print(f"{mismatched} problems not confirmed")
    return 0 if mismatched == 0 else 1


def x_main__mutmut_67(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    parser.add_argument(
        "--registry", type=Path, default=root / "verification/evidence/dataset_registry"
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument(
        "--archive", type=Path, default=root / "verification/evidence/labelled_pool/runs"
    )
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.mkdir(exist_ok=True)
    mismatched = 0
    for job in lb.jobs(args.registry, args.adbench, args.pool):
        stem = job["problem"].replace(":", "_")
        archive_path = args.archive / f"{stem}.json"
        if not archive_path.is_file():
            print(job["problem"], "no archived run")
            mismatched += 1
            continue
        archive = json.loads(archive_path.read_text())
        if "failed" in archive:
            print(job["problem"], "archived run failed; not recoverable")
            mismatched += 1
            continue
        record = recover(job, archive)
        (args.output / f"{stem}.json").write_text(
            json.dumps(record, indent=1, sort_keys=True) + "\n"
        )
        flag = "ok" if record["archive_replay"]["all"] else "REPLAY DIFFERS"
        mismatched += not record["archive_replay"]["all"]
        print(job["problem"], flag, flush=True)
    print(f"{mismatched} problems not confirmed")
    return 0 if mismatched == 0 else 1


def x_main__mutmut_68(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    parser.add_argument(
        "--registry", type=Path, default=root / "verification/evidence/dataset_registry"
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument(
        "--archive", type=Path, default=root / "verification/evidence/labelled_pool/runs"
    )
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, )
    mismatched = 0
    for job in lb.jobs(args.registry, args.adbench, args.pool):
        stem = job["problem"].replace(":", "_")
        archive_path = args.archive / f"{stem}.json"
        if not archive_path.is_file():
            print(job["problem"], "no archived run")
            mismatched += 1
            continue
        archive = json.loads(archive_path.read_text())
        if "failed" in archive:
            print(job["problem"], "archived run failed; not recoverable")
            mismatched += 1
            continue
        record = recover(job, archive)
        (args.output / f"{stem}.json").write_text(
            json.dumps(record, indent=1, sort_keys=True) + "\n"
        )
        flag = "ok" if record["archive_replay"]["all"] else "REPLAY DIFFERS"
        mismatched += not record["archive_replay"]["all"]
        print(job["problem"], flag, flush=True)
    print(f"{mismatched} problems not confirmed")
    return 0 if mismatched == 0 else 1


def x_main__mutmut_69(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    parser.add_argument(
        "--registry", type=Path, default=root / "verification/evidence/dataset_registry"
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument(
        "--archive", type=Path, default=root / "verification/evidence/labelled_pool/runs"
    )
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.mkdir(parents=False, exist_ok=True)
    mismatched = 0
    for job in lb.jobs(args.registry, args.adbench, args.pool):
        stem = job["problem"].replace(":", "_")
        archive_path = args.archive / f"{stem}.json"
        if not archive_path.is_file():
            print(job["problem"], "no archived run")
            mismatched += 1
            continue
        archive = json.loads(archive_path.read_text())
        if "failed" in archive:
            print(job["problem"], "archived run failed; not recoverable")
            mismatched += 1
            continue
        record = recover(job, archive)
        (args.output / f"{stem}.json").write_text(
            json.dumps(record, indent=1, sort_keys=True) + "\n"
        )
        flag = "ok" if record["archive_replay"]["all"] else "REPLAY DIFFERS"
        mismatched += not record["archive_replay"]["all"]
        print(job["problem"], flag, flush=True)
    print(f"{mismatched} problems not confirmed")
    return 0 if mismatched == 0 else 1


def x_main__mutmut_70(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    parser.add_argument(
        "--registry", type=Path, default=root / "verification/evidence/dataset_registry"
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument(
        "--archive", type=Path, default=root / "verification/evidence/labelled_pool/runs"
    )
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=False)
    mismatched = 0
    for job in lb.jobs(args.registry, args.adbench, args.pool):
        stem = job["problem"].replace(":", "_")
        archive_path = args.archive / f"{stem}.json"
        if not archive_path.is_file():
            print(job["problem"], "no archived run")
            mismatched += 1
            continue
        archive = json.loads(archive_path.read_text())
        if "failed" in archive:
            print(job["problem"], "archived run failed; not recoverable")
            mismatched += 1
            continue
        record = recover(job, archive)
        (args.output / f"{stem}.json").write_text(
            json.dumps(record, indent=1, sort_keys=True) + "\n"
        )
        flag = "ok" if record["archive_replay"]["all"] else "REPLAY DIFFERS"
        mismatched += not record["archive_replay"]["all"]
        print(job["problem"], flag, flush=True)
    print(f"{mismatched} problems not confirmed")
    return 0 if mismatched == 0 else 1


def x_main__mutmut_71(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    parser.add_argument(
        "--registry", type=Path, default=root / "verification/evidence/dataset_registry"
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument(
        "--archive", type=Path, default=root / "verification/evidence/labelled_pool/runs"
    )
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    mismatched = None
    for job in lb.jobs(args.registry, args.adbench, args.pool):
        stem = job["problem"].replace(":", "_")
        archive_path = args.archive / f"{stem}.json"
        if not archive_path.is_file():
            print(job["problem"], "no archived run")
            mismatched += 1
            continue
        archive = json.loads(archive_path.read_text())
        if "failed" in archive:
            print(job["problem"], "archived run failed; not recoverable")
            mismatched += 1
            continue
        record = recover(job, archive)
        (args.output / f"{stem}.json").write_text(
            json.dumps(record, indent=1, sort_keys=True) + "\n"
        )
        flag = "ok" if record["archive_replay"]["all"] else "REPLAY DIFFERS"
        mismatched += not record["archive_replay"]["all"]
        print(job["problem"], flag, flush=True)
    print(f"{mismatched} problems not confirmed")
    return 0 if mismatched == 0 else 1


def x_main__mutmut_72(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    parser.add_argument(
        "--registry", type=Path, default=root / "verification/evidence/dataset_registry"
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument(
        "--archive", type=Path, default=root / "verification/evidence/labelled_pool/runs"
    )
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    mismatched = 1
    for job in lb.jobs(args.registry, args.adbench, args.pool):
        stem = job["problem"].replace(":", "_")
        archive_path = args.archive / f"{stem}.json"
        if not archive_path.is_file():
            print(job["problem"], "no archived run")
            mismatched += 1
            continue
        archive = json.loads(archive_path.read_text())
        if "failed" in archive:
            print(job["problem"], "archived run failed; not recoverable")
            mismatched += 1
            continue
        record = recover(job, archive)
        (args.output / f"{stem}.json").write_text(
            json.dumps(record, indent=1, sort_keys=True) + "\n"
        )
        flag = "ok" if record["archive_replay"]["all"] else "REPLAY DIFFERS"
        mismatched += not record["archive_replay"]["all"]
        print(job["problem"], flag, flush=True)
    print(f"{mismatched} problems not confirmed")
    return 0 if mismatched == 0 else 1


def x_main__mutmut_73(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    parser.add_argument(
        "--registry", type=Path, default=root / "verification/evidence/dataset_registry"
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument(
        "--archive", type=Path, default=root / "verification/evidence/labelled_pool/runs"
    )
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    mismatched = 0
    for job in lb.jobs(None, args.adbench, args.pool):
        stem = job["problem"].replace(":", "_")
        archive_path = args.archive / f"{stem}.json"
        if not archive_path.is_file():
            print(job["problem"], "no archived run")
            mismatched += 1
            continue
        archive = json.loads(archive_path.read_text())
        if "failed" in archive:
            print(job["problem"], "archived run failed; not recoverable")
            mismatched += 1
            continue
        record = recover(job, archive)
        (args.output / f"{stem}.json").write_text(
            json.dumps(record, indent=1, sort_keys=True) + "\n"
        )
        flag = "ok" if record["archive_replay"]["all"] else "REPLAY DIFFERS"
        mismatched += not record["archive_replay"]["all"]
        print(job["problem"], flag, flush=True)
    print(f"{mismatched} problems not confirmed")
    return 0 if mismatched == 0 else 1


def x_main__mutmut_74(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    parser.add_argument(
        "--registry", type=Path, default=root / "verification/evidence/dataset_registry"
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument(
        "--archive", type=Path, default=root / "verification/evidence/labelled_pool/runs"
    )
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    mismatched = 0
    for job in lb.jobs(args.registry, None, args.pool):
        stem = job["problem"].replace(":", "_")
        archive_path = args.archive / f"{stem}.json"
        if not archive_path.is_file():
            print(job["problem"], "no archived run")
            mismatched += 1
            continue
        archive = json.loads(archive_path.read_text())
        if "failed" in archive:
            print(job["problem"], "archived run failed; not recoverable")
            mismatched += 1
            continue
        record = recover(job, archive)
        (args.output / f"{stem}.json").write_text(
            json.dumps(record, indent=1, sort_keys=True) + "\n"
        )
        flag = "ok" if record["archive_replay"]["all"] else "REPLAY DIFFERS"
        mismatched += not record["archive_replay"]["all"]
        print(job["problem"], flag, flush=True)
    print(f"{mismatched} problems not confirmed")
    return 0 if mismatched == 0 else 1


def x_main__mutmut_75(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    parser.add_argument(
        "--registry", type=Path, default=root / "verification/evidence/dataset_registry"
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument(
        "--archive", type=Path, default=root / "verification/evidence/labelled_pool/runs"
    )
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    mismatched = 0
    for job in lb.jobs(args.registry, args.adbench, None):
        stem = job["problem"].replace(":", "_")
        archive_path = args.archive / f"{stem}.json"
        if not archive_path.is_file():
            print(job["problem"], "no archived run")
            mismatched += 1
            continue
        archive = json.loads(archive_path.read_text())
        if "failed" in archive:
            print(job["problem"], "archived run failed; not recoverable")
            mismatched += 1
            continue
        record = recover(job, archive)
        (args.output / f"{stem}.json").write_text(
            json.dumps(record, indent=1, sort_keys=True) + "\n"
        )
        flag = "ok" if record["archive_replay"]["all"] else "REPLAY DIFFERS"
        mismatched += not record["archive_replay"]["all"]
        print(job["problem"], flag, flush=True)
    print(f"{mismatched} problems not confirmed")
    return 0 if mismatched == 0 else 1


def x_main__mutmut_76(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    parser.add_argument(
        "--registry", type=Path, default=root / "verification/evidence/dataset_registry"
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument(
        "--archive", type=Path, default=root / "verification/evidence/labelled_pool/runs"
    )
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    mismatched = 0
    for job in lb.jobs(args.adbench, args.pool):
        stem = job["problem"].replace(":", "_")
        archive_path = args.archive / f"{stem}.json"
        if not archive_path.is_file():
            print(job["problem"], "no archived run")
            mismatched += 1
            continue
        archive = json.loads(archive_path.read_text())
        if "failed" in archive:
            print(job["problem"], "archived run failed; not recoverable")
            mismatched += 1
            continue
        record = recover(job, archive)
        (args.output / f"{stem}.json").write_text(
            json.dumps(record, indent=1, sort_keys=True) + "\n"
        )
        flag = "ok" if record["archive_replay"]["all"] else "REPLAY DIFFERS"
        mismatched += not record["archive_replay"]["all"]
        print(job["problem"], flag, flush=True)
    print(f"{mismatched} problems not confirmed")
    return 0 if mismatched == 0 else 1


def x_main__mutmut_77(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    parser.add_argument(
        "--registry", type=Path, default=root / "verification/evidence/dataset_registry"
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument(
        "--archive", type=Path, default=root / "verification/evidence/labelled_pool/runs"
    )
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    mismatched = 0
    for job in lb.jobs(args.registry, args.pool):
        stem = job["problem"].replace(":", "_")
        archive_path = args.archive / f"{stem}.json"
        if not archive_path.is_file():
            print(job["problem"], "no archived run")
            mismatched += 1
            continue
        archive = json.loads(archive_path.read_text())
        if "failed" in archive:
            print(job["problem"], "archived run failed; not recoverable")
            mismatched += 1
            continue
        record = recover(job, archive)
        (args.output / f"{stem}.json").write_text(
            json.dumps(record, indent=1, sort_keys=True) + "\n"
        )
        flag = "ok" if record["archive_replay"]["all"] else "REPLAY DIFFERS"
        mismatched += not record["archive_replay"]["all"]
        print(job["problem"], flag, flush=True)
    print(f"{mismatched} problems not confirmed")
    return 0 if mismatched == 0 else 1


def x_main__mutmut_78(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    parser.add_argument(
        "--registry", type=Path, default=root / "verification/evidence/dataset_registry"
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument(
        "--archive", type=Path, default=root / "verification/evidence/labelled_pool/runs"
    )
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    mismatched = 0
    for job in lb.jobs(args.registry, args.adbench, ):
        stem = job["problem"].replace(":", "_")
        archive_path = args.archive / f"{stem}.json"
        if not archive_path.is_file():
            print(job["problem"], "no archived run")
            mismatched += 1
            continue
        archive = json.loads(archive_path.read_text())
        if "failed" in archive:
            print(job["problem"], "archived run failed; not recoverable")
            mismatched += 1
            continue
        record = recover(job, archive)
        (args.output / f"{stem}.json").write_text(
            json.dumps(record, indent=1, sort_keys=True) + "\n"
        )
        flag = "ok" if record["archive_replay"]["all"] else "REPLAY DIFFERS"
        mismatched += not record["archive_replay"]["all"]
        print(job["problem"], flag, flush=True)
    print(f"{mismatched} problems not confirmed")
    return 0 if mismatched == 0 else 1


def x_main__mutmut_79(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    parser.add_argument(
        "--registry", type=Path, default=root / "verification/evidence/dataset_registry"
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument(
        "--archive", type=Path, default=root / "verification/evidence/labelled_pool/runs"
    )
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    mismatched = 0
    for job in lb.jobs(args.registry, args.adbench, args.pool):
        stem = None
        archive_path = args.archive / f"{stem}.json"
        if not archive_path.is_file():
            print(job["problem"], "no archived run")
            mismatched += 1
            continue
        archive = json.loads(archive_path.read_text())
        if "failed" in archive:
            print(job["problem"], "archived run failed; not recoverable")
            mismatched += 1
            continue
        record = recover(job, archive)
        (args.output / f"{stem}.json").write_text(
            json.dumps(record, indent=1, sort_keys=True) + "\n"
        )
        flag = "ok" if record["archive_replay"]["all"] else "REPLAY DIFFERS"
        mismatched += not record["archive_replay"]["all"]
        print(job["problem"], flag, flush=True)
    print(f"{mismatched} problems not confirmed")
    return 0 if mismatched == 0 else 1


def x_main__mutmut_80(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    parser.add_argument(
        "--registry", type=Path, default=root / "verification/evidence/dataset_registry"
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument(
        "--archive", type=Path, default=root / "verification/evidence/labelled_pool/runs"
    )
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    mismatched = 0
    for job in lb.jobs(args.registry, args.adbench, args.pool):
        stem = job["problem"].replace(None, "_")
        archive_path = args.archive / f"{stem}.json"
        if not archive_path.is_file():
            print(job["problem"], "no archived run")
            mismatched += 1
            continue
        archive = json.loads(archive_path.read_text())
        if "failed" in archive:
            print(job["problem"], "archived run failed; not recoverable")
            mismatched += 1
            continue
        record = recover(job, archive)
        (args.output / f"{stem}.json").write_text(
            json.dumps(record, indent=1, sort_keys=True) + "\n"
        )
        flag = "ok" if record["archive_replay"]["all"] else "REPLAY DIFFERS"
        mismatched += not record["archive_replay"]["all"]
        print(job["problem"], flag, flush=True)
    print(f"{mismatched} problems not confirmed")
    return 0 if mismatched == 0 else 1


def x_main__mutmut_81(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    parser.add_argument(
        "--registry", type=Path, default=root / "verification/evidence/dataset_registry"
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument(
        "--archive", type=Path, default=root / "verification/evidence/labelled_pool/runs"
    )
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    mismatched = 0
    for job in lb.jobs(args.registry, args.adbench, args.pool):
        stem = job["problem"].replace(":", None)
        archive_path = args.archive / f"{stem}.json"
        if not archive_path.is_file():
            print(job["problem"], "no archived run")
            mismatched += 1
            continue
        archive = json.loads(archive_path.read_text())
        if "failed" in archive:
            print(job["problem"], "archived run failed; not recoverable")
            mismatched += 1
            continue
        record = recover(job, archive)
        (args.output / f"{stem}.json").write_text(
            json.dumps(record, indent=1, sort_keys=True) + "\n"
        )
        flag = "ok" if record["archive_replay"]["all"] else "REPLAY DIFFERS"
        mismatched += not record["archive_replay"]["all"]
        print(job["problem"], flag, flush=True)
    print(f"{mismatched} problems not confirmed")
    return 0 if mismatched == 0 else 1


def x_main__mutmut_82(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    parser.add_argument(
        "--registry", type=Path, default=root / "verification/evidence/dataset_registry"
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument(
        "--archive", type=Path, default=root / "verification/evidence/labelled_pool/runs"
    )
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    mismatched = 0
    for job in lb.jobs(args.registry, args.adbench, args.pool):
        stem = job["problem"].replace("_")
        archive_path = args.archive / f"{stem}.json"
        if not archive_path.is_file():
            print(job["problem"], "no archived run")
            mismatched += 1
            continue
        archive = json.loads(archive_path.read_text())
        if "failed" in archive:
            print(job["problem"], "archived run failed; not recoverable")
            mismatched += 1
            continue
        record = recover(job, archive)
        (args.output / f"{stem}.json").write_text(
            json.dumps(record, indent=1, sort_keys=True) + "\n"
        )
        flag = "ok" if record["archive_replay"]["all"] else "REPLAY DIFFERS"
        mismatched += not record["archive_replay"]["all"]
        print(job["problem"], flag, flush=True)
    print(f"{mismatched} problems not confirmed")
    return 0 if mismatched == 0 else 1


def x_main__mutmut_83(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    parser.add_argument(
        "--registry", type=Path, default=root / "verification/evidence/dataset_registry"
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument(
        "--archive", type=Path, default=root / "verification/evidence/labelled_pool/runs"
    )
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    mismatched = 0
    for job in lb.jobs(args.registry, args.adbench, args.pool):
        stem = job["problem"].replace(":", )
        archive_path = args.archive / f"{stem}.json"
        if not archive_path.is_file():
            print(job["problem"], "no archived run")
            mismatched += 1
            continue
        archive = json.loads(archive_path.read_text())
        if "failed" in archive:
            print(job["problem"], "archived run failed; not recoverable")
            mismatched += 1
            continue
        record = recover(job, archive)
        (args.output / f"{stem}.json").write_text(
            json.dumps(record, indent=1, sort_keys=True) + "\n"
        )
        flag = "ok" if record["archive_replay"]["all"] else "REPLAY DIFFERS"
        mismatched += not record["archive_replay"]["all"]
        print(job["problem"], flag, flush=True)
    print(f"{mismatched} problems not confirmed")
    return 0 if mismatched == 0 else 1


def x_main__mutmut_84(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    parser.add_argument(
        "--registry", type=Path, default=root / "verification/evidence/dataset_registry"
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument(
        "--archive", type=Path, default=root / "verification/evidence/labelled_pool/runs"
    )
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    mismatched = 0
    for job in lb.jobs(args.registry, args.adbench, args.pool):
        stem = job["XXproblemXX"].replace(":", "_")
        archive_path = args.archive / f"{stem}.json"
        if not archive_path.is_file():
            print(job["problem"], "no archived run")
            mismatched += 1
            continue
        archive = json.loads(archive_path.read_text())
        if "failed" in archive:
            print(job["problem"], "archived run failed; not recoverable")
            mismatched += 1
            continue
        record = recover(job, archive)
        (args.output / f"{stem}.json").write_text(
            json.dumps(record, indent=1, sort_keys=True) + "\n"
        )
        flag = "ok" if record["archive_replay"]["all"] else "REPLAY DIFFERS"
        mismatched += not record["archive_replay"]["all"]
        print(job["problem"], flag, flush=True)
    print(f"{mismatched} problems not confirmed")
    return 0 if mismatched == 0 else 1


def x_main__mutmut_85(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    parser.add_argument(
        "--registry", type=Path, default=root / "verification/evidence/dataset_registry"
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument(
        "--archive", type=Path, default=root / "verification/evidence/labelled_pool/runs"
    )
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    mismatched = 0
    for job in lb.jobs(args.registry, args.adbench, args.pool):
        stem = job["PROBLEM"].replace(":", "_")
        archive_path = args.archive / f"{stem}.json"
        if not archive_path.is_file():
            print(job["problem"], "no archived run")
            mismatched += 1
            continue
        archive = json.loads(archive_path.read_text())
        if "failed" in archive:
            print(job["problem"], "archived run failed; not recoverable")
            mismatched += 1
            continue
        record = recover(job, archive)
        (args.output / f"{stem}.json").write_text(
            json.dumps(record, indent=1, sort_keys=True) + "\n"
        )
        flag = "ok" if record["archive_replay"]["all"] else "REPLAY DIFFERS"
        mismatched += not record["archive_replay"]["all"]
        print(job["problem"], flag, flush=True)
    print(f"{mismatched} problems not confirmed")
    return 0 if mismatched == 0 else 1


def x_main__mutmut_86(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    parser.add_argument(
        "--registry", type=Path, default=root / "verification/evidence/dataset_registry"
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument(
        "--archive", type=Path, default=root / "verification/evidence/labelled_pool/runs"
    )
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    mismatched = 0
    for job in lb.jobs(args.registry, args.adbench, args.pool):
        stem = job["problem"].replace("XX:XX", "_")
        archive_path = args.archive / f"{stem}.json"
        if not archive_path.is_file():
            print(job["problem"], "no archived run")
            mismatched += 1
            continue
        archive = json.loads(archive_path.read_text())
        if "failed" in archive:
            print(job["problem"], "archived run failed; not recoverable")
            mismatched += 1
            continue
        record = recover(job, archive)
        (args.output / f"{stem}.json").write_text(
            json.dumps(record, indent=1, sort_keys=True) + "\n"
        )
        flag = "ok" if record["archive_replay"]["all"] else "REPLAY DIFFERS"
        mismatched += not record["archive_replay"]["all"]
        print(job["problem"], flag, flush=True)
    print(f"{mismatched} problems not confirmed")
    return 0 if mismatched == 0 else 1


def x_main__mutmut_87(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    parser.add_argument(
        "--registry", type=Path, default=root / "verification/evidence/dataset_registry"
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument(
        "--archive", type=Path, default=root / "verification/evidence/labelled_pool/runs"
    )
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    mismatched = 0
    for job in lb.jobs(args.registry, args.adbench, args.pool):
        stem = job["problem"].replace(":", "XX_XX")
        archive_path = args.archive / f"{stem}.json"
        if not archive_path.is_file():
            print(job["problem"], "no archived run")
            mismatched += 1
            continue
        archive = json.loads(archive_path.read_text())
        if "failed" in archive:
            print(job["problem"], "archived run failed; not recoverable")
            mismatched += 1
            continue
        record = recover(job, archive)
        (args.output / f"{stem}.json").write_text(
            json.dumps(record, indent=1, sort_keys=True) + "\n"
        )
        flag = "ok" if record["archive_replay"]["all"] else "REPLAY DIFFERS"
        mismatched += not record["archive_replay"]["all"]
        print(job["problem"], flag, flush=True)
    print(f"{mismatched} problems not confirmed")
    return 0 if mismatched == 0 else 1


def x_main__mutmut_88(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    parser.add_argument(
        "--registry", type=Path, default=root / "verification/evidence/dataset_registry"
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument(
        "--archive", type=Path, default=root / "verification/evidence/labelled_pool/runs"
    )
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    mismatched = 0
    for job in lb.jobs(args.registry, args.adbench, args.pool):
        stem = job["problem"].replace(":", "_")
        archive_path = None
        if not archive_path.is_file():
            print(job["problem"], "no archived run")
            mismatched += 1
            continue
        archive = json.loads(archive_path.read_text())
        if "failed" in archive:
            print(job["problem"], "archived run failed; not recoverable")
            mismatched += 1
            continue
        record = recover(job, archive)
        (args.output / f"{stem}.json").write_text(
            json.dumps(record, indent=1, sort_keys=True) + "\n"
        )
        flag = "ok" if record["archive_replay"]["all"] else "REPLAY DIFFERS"
        mismatched += not record["archive_replay"]["all"]
        print(job["problem"], flag, flush=True)
    print(f"{mismatched} problems not confirmed")
    return 0 if mismatched == 0 else 1


def x_main__mutmut_89(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    parser.add_argument(
        "--registry", type=Path, default=root / "verification/evidence/dataset_registry"
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument(
        "--archive", type=Path, default=root / "verification/evidence/labelled_pool/runs"
    )
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    mismatched = 0
    for job in lb.jobs(args.registry, args.adbench, args.pool):
        stem = job["problem"].replace(":", "_")
        archive_path = args.archive * f"{stem}.json"
        if not archive_path.is_file():
            print(job["problem"], "no archived run")
            mismatched += 1
            continue
        archive = json.loads(archive_path.read_text())
        if "failed" in archive:
            print(job["problem"], "archived run failed; not recoverable")
            mismatched += 1
            continue
        record = recover(job, archive)
        (args.output / f"{stem}.json").write_text(
            json.dumps(record, indent=1, sort_keys=True) + "\n"
        )
        flag = "ok" if record["archive_replay"]["all"] else "REPLAY DIFFERS"
        mismatched += not record["archive_replay"]["all"]
        print(job["problem"], flag, flush=True)
    print(f"{mismatched} problems not confirmed")
    return 0 if mismatched == 0 else 1


def x_main__mutmut_90(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    parser.add_argument(
        "--registry", type=Path, default=root / "verification/evidence/dataset_registry"
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument(
        "--archive", type=Path, default=root / "verification/evidence/labelled_pool/runs"
    )
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    mismatched = 0
    for job in lb.jobs(args.registry, args.adbench, args.pool):
        stem = job["problem"].replace(":", "_")
        archive_path = args.archive / f"{stem}.json"
        if archive_path.is_file():
            print(job["problem"], "no archived run")
            mismatched += 1
            continue
        archive = json.loads(archive_path.read_text())
        if "failed" in archive:
            print(job["problem"], "archived run failed; not recoverable")
            mismatched += 1
            continue
        record = recover(job, archive)
        (args.output / f"{stem}.json").write_text(
            json.dumps(record, indent=1, sort_keys=True) + "\n"
        )
        flag = "ok" if record["archive_replay"]["all"] else "REPLAY DIFFERS"
        mismatched += not record["archive_replay"]["all"]
        print(job["problem"], flag, flush=True)
    print(f"{mismatched} problems not confirmed")
    return 0 if mismatched == 0 else 1


def x_main__mutmut_91(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    parser.add_argument(
        "--registry", type=Path, default=root / "verification/evidence/dataset_registry"
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument(
        "--archive", type=Path, default=root / "verification/evidence/labelled_pool/runs"
    )
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    mismatched = 0
    for job in lb.jobs(args.registry, args.adbench, args.pool):
        stem = job["problem"].replace(":", "_")
        archive_path = args.archive / f"{stem}.json"
        if not archive_path.is_file():
            print(None, "no archived run")
            mismatched += 1
            continue
        archive = json.loads(archive_path.read_text())
        if "failed" in archive:
            print(job["problem"], "archived run failed; not recoverable")
            mismatched += 1
            continue
        record = recover(job, archive)
        (args.output / f"{stem}.json").write_text(
            json.dumps(record, indent=1, sort_keys=True) + "\n"
        )
        flag = "ok" if record["archive_replay"]["all"] else "REPLAY DIFFERS"
        mismatched += not record["archive_replay"]["all"]
        print(job["problem"], flag, flush=True)
    print(f"{mismatched} problems not confirmed")
    return 0 if mismatched == 0 else 1


def x_main__mutmut_92(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    parser.add_argument(
        "--registry", type=Path, default=root / "verification/evidence/dataset_registry"
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument(
        "--archive", type=Path, default=root / "verification/evidence/labelled_pool/runs"
    )
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    mismatched = 0
    for job in lb.jobs(args.registry, args.adbench, args.pool):
        stem = job["problem"].replace(":", "_")
        archive_path = args.archive / f"{stem}.json"
        if not archive_path.is_file():
            print(job["problem"], None)
            mismatched += 1
            continue
        archive = json.loads(archive_path.read_text())
        if "failed" in archive:
            print(job["problem"], "archived run failed; not recoverable")
            mismatched += 1
            continue
        record = recover(job, archive)
        (args.output / f"{stem}.json").write_text(
            json.dumps(record, indent=1, sort_keys=True) + "\n"
        )
        flag = "ok" if record["archive_replay"]["all"] else "REPLAY DIFFERS"
        mismatched += not record["archive_replay"]["all"]
        print(job["problem"], flag, flush=True)
    print(f"{mismatched} problems not confirmed")
    return 0 if mismatched == 0 else 1


def x_main__mutmut_93(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    parser.add_argument(
        "--registry", type=Path, default=root / "verification/evidence/dataset_registry"
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument(
        "--archive", type=Path, default=root / "verification/evidence/labelled_pool/runs"
    )
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    mismatched = 0
    for job in lb.jobs(args.registry, args.adbench, args.pool):
        stem = job["problem"].replace(":", "_")
        archive_path = args.archive / f"{stem}.json"
        if not archive_path.is_file():
            print("no archived run")
            mismatched += 1
            continue
        archive = json.loads(archive_path.read_text())
        if "failed" in archive:
            print(job["problem"], "archived run failed; not recoverable")
            mismatched += 1
            continue
        record = recover(job, archive)
        (args.output / f"{stem}.json").write_text(
            json.dumps(record, indent=1, sort_keys=True) + "\n"
        )
        flag = "ok" if record["archive_replay"]["all"] else "REPLAY DIFFERS"
        mismatched += not record["archive_replay"]["all"]
        print(job["problem"], flag, flush=True)
    print(f"{mismatched} problems not confirmed")
    return 0 if mismatched == 0 else 1


def x_main__mutmut_94(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    parser.add_argument(
        "--registry", type=Path, default=root / "verification/evidence/dataset_registry"
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument(
        "--archive", type=Path, default=root / "verification/evidence/labelled_pool/runs"
    )
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    mismatched = 0
    for job in lb.jobs(args.registry, args.adbench, args.pool):
        stem = job["problem"].replace(":", "_")
        archive_path = args.archive / f"{stem}.json"
        if not archive_path.is_file():
            print(job["problem"], )
            mismatched += 1
            continue
        archive = json.loads(archive_path.read_text())
        if "failed" in archive:
            print(job["problem"], "archived run failed; not recoverable")
            mismatched += 1
            continue
        record = recover(job, archive)
        (args.output / f"{stem}.json").write_text(
            json.dumps(record, indent=1, sort_keys=True) + "\n"
        )
        flag = "ok" if record["archive_replay"]["all"] else "REPLAY DIFFERS"
        mismatched += not record["archive_replay"]["all"]
        print(job["problem"], flag, flush=True)
    print(f"{mismatched} problems not confirmed")
    return 0 if mismatched == 0 else 1


def x_main__mutmut_95(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    parser.add_argument(
        "--registry", type=Path, default=root / "verification/evidence/dataset_registry"
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument(
        "--archive", type=Path, default=root / "verification/evidence/labelled_pool/runs"
    )
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    mismatched = 0
    for job in lb.jobs(args.registry, args.adbench, args.pool):
        stem = job["problem"].replace(":", "_")
        archive_path = args.archive / f"{stem}.json"
        if not archive_path.is_file():
            print(job["XXproblemXX"], "no archived run")
            mismatched += 1
            continue
        archive = json.loads(archive_path.read_text())
        if "failed" in archive:
            print(job["problem"], "archived run failed; not recoverable")
            mismatched += 1
            continue
        record = recover(job, archive)
        (args.output / f"{stem}.json").write_text(
            json.dumps(record, indent=1, sort_keys=True) + "\n"
        )
        flag = "ok" if record["archive_replay"]["all"] else "REPLAY DIFFERS"
        mismatched += not record["archive_replay"]["all"]
        print(job["problem"], flag, flush=True)
    print(f"{mismatched} problems not confirmed")
    return 0 if mismatched == 0 else 1


def x_main__mutmut_96(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    parser.add_argument(
        "--registry", type=Path, default=root / "verification/evidence/dataset_registry"
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument(
        "--archive", type=Path, default=root / "verification/evidence/labelled_pool/runs"
    )
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    mismatched = 0
    for job in lb.jobs(args.registry, args.adbench, args.pool):
        stem = job["problem"].replace(":", "_")
        archive_path = args.archive / f"{stem}.json"
        if not archive_path.is_file():
            print(job["PROBLEM"], "no archived run")
            mismatched += 1
            continue
        archive = json.loads(archive_path.read_text())
        if "failed" in archive:
            print(job["problem"], "archived run failed; not recoverable")
            mismatched += 1
            continue
        record = recover(job, archive)
        (args.output / f"{stem}.json").write_text(
            json.dumps(record, indent=1, sort_keys=True) + "\n"
        )
        flag = "ok" if record["archive_replay"]["all"] else "REPLAY DIFFERS"
        mismatched += not record["archive_replay"]["all"]
        print(job["problem"], flag, flush=True)
    print(f"{mismatched} problems not confirmed")
    return 0 if mismatched == 0 else 1


def x_main__mutmut_97(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    parser.add_argument(
        "--registry", type=Path, default=root / "verification/evidence/dataset_registry"
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument(
        "--archive", type=Path, default=root / "verification/evidence/labelled_pool/runs"
    )
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    mismatched = 0
    for job in lb.jobs(args.registry, args.adbench, args.pool):
        stem = job["problem"].replace(":", "_")
        archive_path = args.archive / f"{stem}.json"
        if not archive_path.is_file():
            print(job["problem"], "XXno archived runXX")
            mismatched += 1
            continue
        archive = json.loads(archive_path.read_text())
        if "failed" in archive:
            print(job["problem"], "archived run failed; not recoverable")
            mismatched += 1
            continue
        record = recover(job, archive)
        (args.output / f"{stem}.json").write_text(
            json.dumps(record, indent=1, sort_keys=True) + "\n"
        )
        flag = "ok" if record["archive_replay"]["all"] else "REPLAY DIFFERS"
        mismatched += not record["archive_replay"]["all"]
        print(job["problem"], flag, flush=True)
    print(f"{mismatched} problems not confirmed")
    return 0 if mismatched == 0 else 1


def x_main__mutmut_98(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    parser.add_argument(
        "--registry", type=Path, default=root / "verification/evidence/dataset_registry"
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument(
        "--archive", type=Path, default=root / "verification/evidence/labelled_pool/runs"
    )
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    mismatched = 0
    for job in lb.jobs(args.registry, args.adbench, args.pool):
        stem = job["problem"].replace(":", "_")
        archive_path = args.archive / f"{stem}.json"
        if not archive_path.is_file():
            print(job["problem"], "NO ARCHIVED RUN")
            mismatched += 1
            continue
        archive = json.loads(archive_path.read_text())
        if "failed" in archive:
            print(job["problem"], "archived run failed; not recoverable")
            mismatched += 1
            continue
        record = recover(job, archive)
        (args.output / f"{stem}.json").write_text(
            json.dumps(record, indent=1, sort_keys=True) + "\n"
        )
        flag = "ok" if record["archive_replay"]["all"] else "REPLAY DIFFERS"
        mismatched += not record["archive_replay"]["all"]
        print(job["problem"], flag, flush=True)
    print(f"{mismatched} problems not confirmed")
    return 0 if mismatched == 0 else 1


def x_main__mutmut_99(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    parser.add_argument(
        "--registry", type=Path, default=root / "verification/evidence/dataset_registry"
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument(
        "--archive", type=Path, default=root / "verification/evidence/labelled_pool/runs"
    )
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    mismatched = 0
    for job in lb.jobs(args.registry, args.adbench, args.pool):
        stem = job["problem"].replace(":", "_")
        archive_path = args.archive / f"{stem}.json"
        if not archive_path.is_file():
            print(job["problem"], "no archived run")
            mismatched = 1
            continue
        archive = json.loads(archive_path.read_text())
        if "failed" in archive:
            print(job["problem"], "archived run failed; not recoverable")
            mismatched += 1
            continue
        record = recover(job, archive)
        (args.output / f"{stem}.json").write_text(
            json.dumps(record, indent=1, sort_keys=True) + "\n"
        )
        flag = "ok" if record["archive_replay"]["all"] else "REPLAY DIFFERS"
        mismatched += not record["archive_replay"]["all"]
        print(job["problem"], flag, flush=True)
    print(f"{mismatched} problems not confirmed")
    return 0 if mismatched == 0 else 1


def x_main__mutmut_100(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    parser.add_argument(
        "--registry", type=Path, default=root / "verification/evidence/dataset_registry"
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument(
        "--archive", type=Path, default=root / "verification/evidence/labelled_pool/runs"
    )
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    mismatched = 0
    for job in lb.jobs(args.registry, args.adbench, args.pool):
        stem = job["problem"].replace(":", "_")
        archive_path = args.archive / f"{stem}.json"
        if not archive_path.is_file():
            print(job["problem"], "no archived run")
            mismatched -= 1
            continue
        archive = json.loads(archive_path.read_text())
        if "failed" in archive:
            print(job["problem"], "archived run failed; not recoverable")
            mismatched += 1
            continue
        record = recover(job, archive)
        (args.output / f"{stem}.json").write_text(
            json.dumps(record, indent=1, sort_keys=True) + "\n"
        )
        flag = "ok" if record["archive_replay"]["all"] else "REPLAY DIFFERS"
        mismatched += not record["archive_replay"]["all"]
        print(job["problem"], flag, flush=True)
    print(f"{mismatched} problems not confirmed")
    return 0 if mismatched == 0 else 1


def x_main__mutmut_101(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    parser.add_argument(
        "--registry", type=Path, default=root / "verification/evidence/dataset_registry"
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument(
        "--archive", type=Path, default=root / "verification/evidence/labelled_pool/runs"
    )
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    mismatched = 0
    for job in lb.jobs(args.registry, args.adbench, args.pool):
        stem = job["problem"].replace(":", "_")
        archive_path = args.archive / f"{stem}.json"
        if not archive_path.is_file():
            print(job["problem"], "no archived run")
            mismatched += 2
            continue
        archive = json.loads(archive_path.read_text())
        if "failed" in archive:
            print(job["problem"], "archived run failed; not recoverable")
            mismatched += 1
            continue
        record = recover(job, archive)
        (args.output / f"{stem}.json").write_text(
            json.dumps(record, indent=1, sort_keys=True) + "\n"
        )
        flag = "ok" if record["archive_replay"]["all"] else "REPLAY DIFFERS"
        mismatched += not record["archive_replay"]["all"]
        print(job["problem"], flag, flush=True)
    print(f"{mismatched} problems not confirmed")
    return 0 if mismatched == 0 else 1


def x_main__mutmut_102(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    parser.add_argument(
        "--registry", type=Path, default=root / "verification/evidence/dataset_registry"
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument(
        "--archive", type=Path, default=root / "verification/evidence/labelled_pool/runs"
    )
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    mismatched = 0
    for job in lb.jobs(args.registry, args.adbench, args.pool):
        stem = job["problem"].replace(":", "_")
        archive_path = args.archive / f"{stem}.json"
        if not archive_path.is_file():
            print(job["problem"], "no archived run")
            mismatched += 1
            break
        archive = json.loads(archive_path.read_text())
        if "failed" in archive:
            print(job["problem"], "archived run failed; not recoverable")
            mismatched += 1
            continue
        record = recover(job, archive)
        (args.output / f"{stem}.json").write_text(
            json.dumps(record, indent=1, sort_keys=True) + "\n"
        )
        flag = "ok" if record["archive_replay"]["all"] else "REPLAY DIFFERS"
        mismatched += not record["archive_replay"]["all"]
        print(job["problem"], flag, flush=True)
    print(f"{mismatched} problems not confirmed")
    return 0 if mismatched == 0 else 1


def x_main__mutmut_103(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    parser.add_argument(
        "--registry", type=Path, default=root / "verification/evidence/dataset_registry"
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument(
        "--archive", type=Path, default=root / "verification/evidence/labelled_pool/runs"
    )
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    mismatched = 0
    for job in lb.jobs(args.registry, args.adbench, args.pool):
        stem = job["problem"].replace(":", "_")
        archive_path = args.archive / f"{stem}.json"
        if not archive_path.is_file():
            print(job["problem"], "no archived run")
            mismatched += 1
            continue
        archive = None
        if "failed" in archive:
            print(job["problem"], "archived run failed; not recoverable")
            mismatched += 1
            continue
        record = recover(job, archive)
        (args.output / f"{stem}.json").write_text(
            json.dumps(record, indent=1, sort_keys=True) + "\n"
        )
        flag = "ok" if record["archive_replay"]["all"] else "REPLAY DIFFERS"
        mismatched += not record["archive_replay"]["all"]
        print(job["problem"], flag, flush=True)
    print(f"{mismatched} problems not confirmed")
    return 0 if mismatched == 0 else 1


def x_main__mutmut_104(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    parser.add_argument(
        "--registry", type=Path, default=root / "verification/evidence/dataset_registry"
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument(
        "--archive", type=Path, default=root / "verification/evidence/labelled_pool/runs"
    )
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    mismatched = 0
    for job in lb.jobs(args.registry, args.adbench, args.pool):
        stem = job["problem"].replace(":", "_")
        archive_path = args.archive / f"{stem}.json"
        if not archive_path.is_file():
            print(job["problem"], "no archived run")
            mismatched += 1
            continue
        archive = json.loads(None)
        if "failed" in archive:
            print(job["problem"], "archived run failed; not recoverable")
            mismatched += 1
            continue
        record = recover(job, archive)
        (args.output / f"{stem}.json").write_text(
            json.dumps(record, indent=1, sort_keys=True) + "\n"
        )
        flag = "ok" if record["archive_replay"]["all"] else "REPLAY DIFFERS"
        mismatched += not record["archive_replay"]["all"]
        print(job["problem"], flag, flush=True)
    print(f"{mismatched} problems not confirmed")
    return 0 if mismatched == 0 else 1


def x_main__mutmut_105(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    parser.add_argument(
        "--registry", type=Path, default=root / "verification/evidence/dataset_registry"
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument(
        "--archive", type=Path, default=root / "verification/evidence/labelled_pool/runs"
    )
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    mismatched = 0
    for job in lb.jobs(args.registry, args.adbench, args.pool):
        stem = job["problem"].replace(":", "_")
        archive_path = args.archive / f"{stem}.json"
        if not archive_path.is_file():
            print(job["problem"], "no archived run")
            mismatched += 1
            continue
        archive = json.loads(archive_path.read_text())
        if "XXfailedXX" in archive:
            print(job["problem"], "archived run failed; not recoverable")
            mismatched += 1
            continue
        record = recover(job, archive)
        (args.output / f"{stem}.json").write_text(
            json.dumps(record, indent=1, sort_keys=True) + "\n"
        )
        flag = "ok" if record["archive_replay"]["all"] else "REPLAY DIFFERS"
        mismatched += not record["archive_replay"]["all"]
        print(job["problem"], flag, flush=True)
    print(f"{mismatched} problems not confirmed")
    return 0 if mismatched == 0 else 1


def x_main__mutmut_106(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    parser.add_argument(
        "--registry", type=Path, default=root / "verification/evidence/dataset_registry"
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument(
        "--archive", type=Path, default=root / "verification/evidence/labelled_pool/runs"
    )
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    mismatched = 0
    for job in lb.jobs(args.registry, args.adbench, args.pool):
        stem = job["problem"].replace(":", "_")
        archive_path = args.archive / f"{stem}.json"
        if not archive_path.is_file():
            print(job["problem"], "no archived run")
            mismatched += 1
            continue
        archive = json.loads(archive_path.read_text())
        if "FAILED" in archive:
            print(job["problem"], "archived run failed; not recoverable")
            mismatched += 1
            continue
        record = recover(job, archive)
        (args.output / f"{stem}.json").write_text(
            json.dumps(record, indent=1, sort_keys=True) + "\n"
        )
        flag = "ok" if record["archive_replay"]["all"] else "REPLAY DIFFERS"
        mismatched += not record["archive_replay"]["all"]
        print(job["problem"], flag, flush=True)
    print(f"{mismatched} problems not confirmed")
    return 0 if mismatched == 0 else 1


def x_main__mutmut_107(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    parser.add_argument(
        "--registry", type=Path, default=root / "verification/evidence/dataset_registry"
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument(
        "--archive", type=Path, default=root / "verification/evidence/labelled_pool/runs"
    )
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    mismatched = 0
    for job in lb.jobs(args.registry, args.adbench, args.pool):
        stem = job["problem"].replace(":", "_")
        archive_path = args.archive / f"{stem}.json"
        if not archive_path.is_file():
            print(job["problem"], "no archived run")
            mismatched += 1
            continue
        archive = json.loads(archive_path.read_text())
        if "failed" not in archive:
            print(job["problem"], "archived run failed; not recoverable")
            mismatched += 1
            continue
        record = recover(job, archive)
        (args.output / f"{stem}.json").write_text(
            json.dumps(record, indent=1, sort_keys=True) + "\n"
        )
        flag = "ok" if record["archive_replay"]["all"] else "REPLAY DIFFERS"
        mismatched += not record["archive_replay"]["all"]
        print(job["problem"], flag, flush=True)
    print(f"{mismatched} problems not confirmed")
    return 0 if mismatched == 0 else 1


def x_main__mutmut_108(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    parser.add_argument(
        "--registry", type=Path, default=root / "verification/evidence/dataset_registry"
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument(
        "--archive", type=Path, default=root / "verification/evidence/labelled_pool/runs"
    )
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    mismatched = 0
    for job in lb.jobs(args.registry, args.adbench, args.pool):
        stem = job["problem"].replace(":", "_")
        archive_path = args.archive / f"{stem}.json"
        if not archive_path.is_file():
            print(job["problem"], "no archived run")
            mismatched += 1
            continue
        archive = json.loads(archive_path.read_text())
        if "failed" in archive:
            print(None, "archived run failed; not recoverable")
            mismatched += 1
            continue
        record = recover(job, archive)
        (args.output / f"{stem}.json").write_text(
            json.dumps(record, indent=1, sort_keys=True) + "\n"
        )
        flag = "ok" if record["archive_replay"]["all"] else "REPLAY DIFFERS"
        mismatched += not record["archive_replay"]["all"]
        print(job["problem"], flag, flush=True)
    print(f"{mismatched} problems not confirmed")
    return 0 if mismatched == 0 else 1


def x_main__mutmut_109(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    parser.add_argument(
        "--registry", type=Path, default=root / "verification/evidence/dataset_registry"
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument(
        "--archive", type=Path, default=root / "verification/evidence/labelled_pool/runs"
    )
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    mismatched = 0
    for job in lb.jobs(args.registry, args.adbench, args.pool):
        stem = job["problem"].replace(":", "_")
        archive_path = args.archive / f"{stem}.json"
        if not archive_path.is_file():
            print(job["problem"], "no archived run")
            mismatched += 1
            continue
        archive = json.loads(archive_path.read_text())
        if "failed" in archive:
            print(job["problem"], None)
            mismatched += 1
            continue
        record = recover(job, archive)
        (args.output / f"{stem}.json").write_text(
            json.dumps(record, indent=1, sort_keys=True) + "\n"
        )
        flag = "ok" if record["archive_replay"]["all"] else "REPLAY DIFFERS"
        mismatched += not record["archive_replay"]["all"]
        print(job["problem"], flag, flush=True)
    print(f"{mismatched} problems not confirmed")
    return 0 if mismatched == 0 else 1


def x_main__mutmut_110(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    parser.add_argument(
        "--registry", type=Path, default=root / "verification/evidence/dataset_registry"
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument(
        "--archive", type=Path, default=root / "verification/evidence/labelled_pool/runs"
    )
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    mismatched = 0
    for job in lb.jobs(args.registry, args.adbench, args.pool):
        stem = job["problem"].replace(":", "_")
        archive_path = args.archive / f"{stem}.json"
        if not archive_path.is_file():
            print(job["problem"], "no archived run")
            mismatched += 1
            continue
        archive = json.loads(archive_path.read_text())
        if "failed" in archive:
            print("archived run failed; not recoverable")
            mismatched += 1
            continue
        record = recover(job, archive)
        (args.output / f"{stem}.json").write_text(
            json.dumps(record, indent=1, sort_keys=True) + "\n"
        )
        flag = "ok" if record["archive_replay"]["all"] else "REPLAY DIFFERS"
        mismatched += not record["archive_replay"]["all"]
        print(job["problem"], flag, flush=True)
    print(f"{mismatched} problems not confirmed")
    return 0 if mismatched == 0 else 1


def x_main__mutmut_111(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    parser.add_argument(
        "--registry", type=Path, default=root / "verification/evidence/dataset_registry"
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument(
        "--archive", type=Path, default=root / "verification/evidence/labelled_pool/runs"
    )
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    mismatched = 0
    for job in lb.jobs(args.registry, args.adbench, args.pool):
        stem = job["problem"].replace(":", "_")
        archive_path = args.archive / f"{stem}.json"
        if not archive_path.is_file():
            print(job["problem"], "no archived run")
            mismatched += 1
            continue
        archive = json.loads(archive_path.read_text())
        if "failed" in archive:
            print(job["problem"], )
            mismatched += 1
            continue
        record = recover(job, archive)
        (args.output / f"{stem}.json").write_text(
            json.dumps(record, indent=1, sort_keys=True) + "\n"
        )
        flag = "ok" if record["archive_replay"]["all"] else "REPLAY DIFFERS"
        mismatched += not record["archive_replay"]["all"]
        print(job["problem"], flag, flush=True)
    print(f"{mismatched} problems not confirmed")
    return 0 if mismatched == 0 else 1


def x_main__mutmut_112(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    parser.add_argument(
        "--registry", type=Path, default=root / "verification/evidence/dataset_registry"
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument(
        "--archive", type=Path, default=root / "verification/evidence/labelled_pool/runs"
    )
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    mismatched = 0
    for job in lb.jobs(args.registry, args.adbench, args.pool):
        stem = job["problem"].replace(":", "_")
        archive_path = args.archive / f"{stem}.json"
        if not archive_path.is_file():
            print(job["problem"], "no archived run")
            mismatched += 1
            continue
        archive = json.loads(archive_path.read_text())
        if "failed" in archive:
            print(job["XXproblemXX"], "archived run failed; not recoverable")
            mismatched += 1
            continue
        record = recover(job, archive)
        (args.output / f"{stem}.json").write_text(
            json.dumps(record, indent=1, sort_keys=True) + "\n"
        )
        flag = "ok" if record["archive_replay"]["all"] else "REPLAY DIFFERS"
        mismatched += not record["archive_replay"]["all"]
        print(job["problem"], flag, flush=True)
    print(f"{mismatched} problems not confirmed")
    return 0 if mismatched == 0 else 1


def x_main__mutmut_113(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    parser.add_argument(
        "--registry", type=Path, default=root / "verification/evidence/dataset_registry"
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument(
        "--archive", type=Path, default=root / "verification/evidence/labelled_pool/runs"
    )
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    mismatched = 0
    for job in lb.jobs(args.registry, args.adbench, args.pool):
        stem = job["problem"].replace(":", "_")
        archive_path = args.archive / f"{stem}.json"
        if not archive_path.is_file():
            print(job["problem"], "no archived run")
            mismatched += 1
            continue
        archive = json.loads(archive_path.read_text())
        if "failed" in archive:
            print(job["PROBLEM"], "archived run failed; not recoverable")
            mismatched += 1
            continue
        record = recover(job, archive)
        (args.output / f"{stem}.json").write_text(
            json.dumps(record, indent=1, sort_keys=True) + "\n"
        )
        flag = "ok" if record["archive_replay"]["all"] else "REPLAY DIFFERS"
        mismatched += not record["archive_replay"]["all"]
        print(job["problem"], flag, flush=True)
    print(f"{mismatched} problems not confirmed")
    return 0 if mismatched == 0 else 1


def x_main__mutmut_114(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    parser.add_argument(
        "--registry", type=Path, default=root / "verification/evidence/dataset_registry"
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument(
        "--archive", type=Path, default=root / "verification/evidence/labelled_pool/runs"
    )
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    mismatched = 0
    for job in lb.jobs(args.registry, args.adbench, args.pool):
        stem = job["problem"].replace(":", "_")
        archive_path = args.archive / f"{stem}.json"
        if not archive_path.is_file():
            print(job["problem"], "no archived run")
            mismatched += 1
            continue
        archive = json.loads(archive_path.read_text())
        if "failed" in archive:
            print(job["problem"], "XXarchived run failed; not recoverableXX")
            mismatched += 1
            continue
        record = recover(job, archive)
        (args.output / f"{stem}.json").write_text(
            json.dumps(record, indent=1, sort_keys=True) + "\n"
        )
        flag = "ok" if record["archive_replay"]["all"] else "REPLAY DIFFERS"
        mismatched += not record["archive_replay"]["all"]
        print(job["problem"], flag, flush=True)
    print(f"{mismatched} problems not confirmed")
    return 0 if mismatched == 0 else 1


def x_main__mutmut_115(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    parser.add_argument(
        "--registry", type=Path, default=root / "verification/evidence/dataset_registry"
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument(
        "--archive", type=Path, default=root / "verification/evidence/labelled_pool/runs"
    )
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    mismatched = 0
    for job in lb.jobs(args.registry, args.adbench, args.pool):
        stem = job["problem"].replace(":", "_")
        archive_path = args.archive / f"{stem}.json"
        if not archive_path.is_file():
            print(job["problem"], "no archived run")
            mismatched += 1
            continue
        archive = json.loads(archive_path.read_text())
        if "failed" in archive:
            print(job["problem"], "ARCHIVED RUN FAILED; NOT RECOVERABLE")
            mismatched += 1
            continue
        record = recover(job, archive)
        (args.output / f"{stem}.json").write_text(
            json.dumps(record, indent=1, sort_keys=True) + "\n"
        )
        flag = "ok" if record["archive_replay"]["all"] else "REPLAY DIFFERS"
        mismatched += not record["archive_replay"]["all"]
        print(job["problem"], flag, flush=True)
    print(f"{mismatched} problems not confirmed")
    return 0 if mismatched == 0 else 1


def x_main__mutmut_116(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    parser.add_argument(
        "--registry", type=Path, default=root / "verification/evidence/dataset_registry"
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument(
        "--archive", type=Path, default=root / "verification/evidence/labelled_pool/runs"
    )
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    mismatched = 0
    for job in lb.jobs(args.registry, args.adbench, args.pool):
        stem = job["problem"].replace(":", "_")
        archive_path = args.archive / f"{stem}.json"
        if not archive_path.is_file():
            print(job["problem"], "no archived run")
            mismatched += 1
            continue
        archive = json.loads(archive_path.read_text())
        if "failed" in archive:
            print(job["problem"], "archived run failed; not recoverable")
            mismatched = 1
            continue
        record = recover(job, archive)
        (args.output / f"{stem}.json").write_text(
            json.dumps(record, indent=1, sort_keys=True) + "\n"
        )
        flag = "ok" if record["archive_replay"]["all"] else "REPLAY DIFFERS"
        mismatched += not record["archive_replay"]["all"]
        print(job["problem"], flag, flush=True)
    print(f"{mismatched} problems not confirmed")
    return 0 if mismatched == 0 else 1


def x_main__mutmut_117(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    parser.add_argument(
        "--registry", type=Path, default=root / "verification/evidence/dataset_registry"
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument(
        "--archive", type=Path, default=root / "verification/evidence/labelled_pool/runs"
    )
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    mismatched = 0
    for job in lb.jobs(args.registry, args.adbench, args.pool):
        stem = job["problem"].replace(":", "_")
        archive_path = args.archive / f"{stem}.json"
        if not archive_path.is_file():
            print(job["problem"], "no archived run")
            mismatched += 1
            continue
        archive = json.loads(archive_path.read_text())
        if "failed" in archive:
            print(job["problem"], "archived run failed; not recoverable")
            mismatched -= 1
            continue
        record = recover(job, archive)
        (args.output / f"{stem}.json").write_text(
            json.dumps(record, indent=1, sort_keys=True) + "\n"
        )
        flag = "ok" if record["archive_replay"]["all"] else "REPLAY DIFFERS"
        mismatched += not record["archive_replay"]["all"]
        print(job["problem"], flag, flush=True)
    print(f"{mismatched} problems not confirmed")
    return 0 if mismatched == 0 else 1


def x_main__mutmut_118(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    parser.add_argument(
        "--registry", type=Path, default=root / "verification/evidence/dataset_registry"
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument(
        "--archive", type=Path, default=root / "verification/evidence/labelled_pool/runs"
    )
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    mismatched = 0
    for job in lb.jobs(args.registry, args.adbench, args.pool):
        stem = job["problem"].replace(":", "_")
        archive_path = args.archive / f"{stem}.json"
        if not archive_path.is_file():
            print(job["problem"], "no archived run")
            mismatched += 1
            continue
        archive = json.loads(archive_path.read_text())
        if "failed" in archive:
            print(job["problem"], "archived run failed; not recoverable")
            mismatched += 2
            continue
        record = recover(job, archive)
        (args.output / f"{stem}.json").write_text(
            json.dumps(record, indent=1, sort_keys=True) + "\n"
        )
        flag = "ok" if record["archive_replay"]["all"] else "REPLAY DIFFERS"
        mismatched += not record["archive_replay"]["all"]
        print(job["problem"], flag, flush=True)
    print(f"{mismatched} problems not confirmed")
    return 0 if mismatched == 0 else 1


def x_main__mutmut_119(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    parser.add_argument(
        "--registry", type=Path, default=root / "verification/evidence/dataset_registry"
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument(
        "--archive", type=Path, default=root / "verification/evidence/labelled_pool/runs"
    )
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    mismatched = 0
    for job in lb.jobs(args.registry, args.adbench, args.pool):
        stem = job["problem"].replace(":", "_")
        archive_path = args.archive / f"{stem}.json"
        if not archive_path.is_file():
            print(job["problem"], "no archived run")
            mismatched += 1
            continue
        archive = json.loads(archive_path.read_text())
        if "failed" in archive:
            print(job["problem"], "archived run failed; not recoverable")
            mismatched += 1
            break
        record = recover(job, archive)
        (args.output / f"{stem}.json").write_text(
            json.dumps(record, indent=1, sort_keys=True) + "\n"
        )
        flag = "ok" if record["archive_replay"]["all"] else "REPLAY DIFFERS"
        mismatched += not record["archive_replay"]["all"]
        print(job["problem"], flag, flush=True)
    print(f"{mismatched} problems not confirmed")
    return 0 if mismatched == 0 else 1


def x_main__mutmut_120(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    parser.add_argument(
        "--registry", type=Path, default=root / "verification/evidence/dataset_registry"
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument(
        "--archive", type=Path, default=root / "verification/evidence/labelled_pool/runs"
    )
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    mismatched = 0
    for job in lb.jobs(args.registry, args.adbench, args.pool):
        stem = job["problem"].replace(":", "_")
        archive_path = args.archive / f"{stem}.json"
        if not archive_path.is_file():
            print(job["problem"], "no archived run")
            mismatched += 1
            continue
        archive = json.loads(archive_path.read_text())
        if "failed" in archive:
            print(job["problem"], "archived run failed; not recoverable")
            mismatched += 1
            continue
        record = None
        (args.output / f"{stem}.json").write_text(
            json.dumps(record, indent=1, sort_keys=True) + "\n"
        )
        flag = "ok" if record["archive_replay"]["all"] else "REPLAY DIFFERS"
        mismatched += not record["archive_replay"]["all"]
        print(job["problem"], flag, flush=True)
    print(f"{mismatched} problems not confirmed")
    return 0 if mismatched == 0 else 1


def x_main__mutmut_121(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    parser.add_argument(
        "--registry", type=Path, default=root / "verification/evidence/dataset_registry"
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument(
        "--archive", type=Path, default=root / "verification/evidence/labelled_pool/runs"
    )
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    mismatched = 0
    for job in lb.jobs(args.registry, args.adbench, args.pool):
        stem = job["problem"].replace(":", "_")
        archive_path = args.archive / f"{stem}.json"
        if not archive_path.is_file():
            print(job["problem"], "no archived run")
            mismatched += 1
            continue
        archive = json.loads(archive_path.read_text())
        if "failed" in archive:
            print(job["problem"], "archived run failed; not recoverable")
            mismatched += 1
            continue
        record = recover(None, archive)
        (args.output / f"{stem}.json").write_text(
            json.dumps(record, indent=1, sort_keys=True) + "\n"
        )
        flag = "ok" if record["archive_replay"]["all"] else "REPLAY DIFFERS"
        mismatched += not record["archive_replay"]["all"]
        print(job["problem"], flag, flush=True)
    print(f"{mismatched} problems not confirmed")
    return 0 if mismatched == 0 else 1


def x_main__mutmut_122(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    parser.add_argument(
        "--registry", type=Path, default=root / "verification/evidence/dataset_registry"
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument(
        "--archive", type=Path, default=root / "verification/evidence/labelled_pool/runs"
    )
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    mismatched = 0
    for job in lb.jobs(args.registry, args.adbench, args.pool):
        stem = job["problem"].replace(":", "_")
        archive_path = args.archive / f"{stem}.json"
        if not archive_path.is_file():
            print(job["problem"], "no archived run")
            mismatched += 1
            continue
        archive = json.loads(archive_path.read_text())
        if "failed" in archive:
            print(job["problem"], "archived run failed; not recoverable")
            mismatched += 1
            continue
        record = recover(job, None)
        (args.output / f"{stem}.json").write_text(
            json.dumps(record, indent=1, sort_keys=True) + "\n"
        )
        flag = "ok" if record["archive_replay"]["all"] else "REPLAY DIFFERS"
        mismatched += not record["archive_replay"]["all"]
        print(job["problem"], flag, flush=True)
    print(f"{mismatched} problems not confirmed")
    return 0 if mismatched == 0 else 1


def x_main__mutmut_123(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    parser.add_argument(
        "--registry", type=Path, default=root / "verification/evidence/dataset_registry"
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument(
        "--archive", type=Path, default=root / "verification/evidence/labelled_pool/runs"
    )
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    mismatched = 0
    for job in lb.jobs(args.registry, args.adbench, args.pool):
        stem = job["problem"].replace(":", "_")
        archive_path = args.archive / f"{stem}.json"
        if not archive_path.is_file():
            print(job["problem"], "no archived run")
            mismatched += 1
            continue
        archive = json.loads(archive_path.read_text())
        if "failed" in archive:
            print(job["problem"], "archived run failed; not recoverable")
            mismatched += 1
            continue
        record = recover(archive)
        (args.output / f"{stem}.json").write_text(
            json.dumps(record, indent=1, sort_keys=True) + "\n"
        )
        flag = "ok" if record["archive_replay"]["all"] else "REPLAY DIFFERS"
        mismatched += not record["archive_replay"]["all"]
        print(job["problem"], flag, flush=True)
    print(f"{mismatched} problems not confirmed")
    return 0 if mismatched == 0 else 1


def x_main__mutmut_124(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    parser.add_argument(
        "--registry", type=Path, default=root / "verification/evidence/dataset_registry"
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument(
        "--archive", type=Path, default=root / "verification/evidence/labelled_pool/runs"
    )
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    mismatched = 0
    for job in lb.jobs(args.registry, args.adbench, args.pool):
        stem = job["problem"].replace(":", "_")
        archive_path = args.archive / f"{stem}.json"
        if not archive_path.is_file():
            print(job["problem"], "no archived run")
            mismatched += 1
            continue
        archive = json.loads(archive_path.read_text())
        if "failed" in archive:
            print(job["problem"], "archived run failed; not recoverable")
            mismatched += 1
            continue
        record = recover(job, )
        (args.output / f"{stem}.json").write_text(
            json.dumps(record, indent=1, sort_keys=True) + "\n"
        )
        flag = "ok" if record["archive_replay"]["all"] else "REPLAY DIFFERS"
        mismatched += not record["archive_replay"]["all"]
        print(job["problem"], flag, flush=True)
    print(f"{mismatched} problems not confirmed")
    return 0 if mismatched == 0 else 1


def x_main__mutmut_125(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    parser.add_argument(
        "--registry", type=Path, default=root / "verification/evidence/dataset_registry"
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument(
        "--archive", type=Path, default=root / "verification/evidence/labelled_pool/runs"
    )
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    mismatched = 0
    for job in lb.jobs(args.registry, args.adbench, args.pool):
        stem = job["problem"].replace(":", "_")
        archive_path = args.archive / f"{stem}.json"
        if not archive_path.is_file():
            print(job["problem"], "no archived run")
            mismatched += 1
            continue
        archive = json.loads(archive_path.read_text())
        if "failed" in archive:
            print(job["problem"], "archived run failed; not recoverable")
            mismatched += 1
            continue
        record = recover(job, archive)
        (args.output / f"{stem}.json").write_text(
            None
        )
        flag = "ok" if record["archive_replay"]["all"] else "REPLAY DIFFERS"
        mismatched += not record["archive_replay"]["all"]
        print(job["problem"], flag, flush=True)
    print(f"{mismatched} problems not confirmed")
    return 0 if mismatched == 0 else 1


def x_main__mutmut_126(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    parser.add_argument(
        "--registry", type=Path, default=root / "verification/evidence/dataset_registry"
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument(
        "--archive", type=Path, default=root / "verification/evidence/labelled_pool/runs"
    )
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    mismatched = 0
    for job in lb.jobs(args.registry, args.adbench, args.pool):
        stem = job["problem"].replace(":", "_")
        archive_path = args.archive / f"{stem}.json"
        if not archive_path.is_file():
            print(job["problem"], "no archived run")
            mismatched += 1
            continue
        archive = json.loads(archive_path.read_text())
        if "failed" in archive:
            print(job["problem"], "archived run failed; not recoverable")
            mismatched += 1
            continue
        record = recover(job, archive)
        (args.output * f"{stem}.json").write_text(
            json.dumps(record, indent=1, sort_keys=True) + "\n"
        )
        flag = "ok" if record["archive_replay"]["all"] else "REPLAY DIFFERS"
        mismatched += not record["archive_replay"]["all"]
        print(job["problem"], flag, flush=True)
    print(f"{mismatched} problems not confirmed")
    return 0 if mismatched == 0 else 1


def x_main__mutmut_127(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    parser.add_argument(
        "--registry", type=Path, default=root / "verification/evidence/dataset_registry"
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument(
        "--archive", type=Path, default=root / "verification/evidence/labelled_pool/runs"
    )
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    mismatched = 0
    for job in lb.jobs(args.registry, args.adbench, args.pool):
        stem = job["problem"].replace(":", "_")
        archive_path = args.archive / f"{stem}.json"
        if not archive_path.is_file():
            print(job["problem"], "no archived run")
            mismatched += 1
            continue
        archive = json.loads(archive_path.read_text())
        if "failed" in archive:
            print(job["problem"], "archived run failed; not recoverable")
            mismatched += 1
            continue
        record = recover(job, archive)
        (args.output / f"{stem}.json").write_text(
            json.dumps(record, indent=1, sort_keys=True) - "\n"
        )
        flag = "ok" if record["archive_replay"]["all"] else "REPLAY DIFFERS"
        mismatched += not record["archive_replay"]["all"]
        print(job["problem"], flag, flush=True)
    print(f"{mismatched} problems not confirmed")
    return 0 if mismatched == 0 else 1


def x_main__mutmut_128(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    parser.add_argument(
        "--registry", type=Path, default=root / "verification/evidence/dataset_registry"
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument(
        "--archive", type=Path, default=root / "verification/evidence/labelled_pool/runs"
    )
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    mismatched = 0
    for job in lb.jobs(args.registry, args.adbench, args.pool):
        stem = job["problem"].replace(":", "_")
        archive_path = args.archive / f"{stem}.json"
        if not archive_path.is_file():
            print(job["problem"], "no archived run")
            mismatched += 1
            continue
        archive = json.loads(archive_path.read_text())
        if "failed" in archive:
            print(job["problem"], "archived run failed; not recoverable")
            mismatched += 1
            continue
        record = recover(job, archive)
        (args.output / f"{stem}.json").write_text(
            json.dumps(None, indent=1, sort_keys=True) + "\n"
        )
        flag = "ok" if record["archive_replay"]["all"] else "REPLAY DIFFERS"
        mismatched += not record["archive_replay"]["all"]
        print(job["problem"], flag, flush=True)
    print(f"{mismatched} problems not confirmed")
    return 0 if mismatched == 0 else 1


def x_main__mutmut_129(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    parser.add_argument(
        "--registry", type=Path, default=root / "verification/evidence/dataset_registry"
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument(
        "--archive", type=Path, default=root / "verification/evidence/labelled_pool/runs"
    )
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    mismatched = 0
    for job in lb.jobs(args.registry, args.adbench, args.pool):
        stem = job["problem"].replace(":", "_")
        archive_path = args.archive / f"{stem}.json"
        if not archive_path.is_file():
            print(job["problem"], "no archived run")
            mismatched += 1
            continue
        archive = json.loads(archive_path.read_text())
        if "failed" in archive:
            print(job["problem"], "archived run failed; not recoverable")
            mismatched += 1
            continue
        record = recover(job, archive)
        (args.output / f"{stem}.json").write_text(
            json.dumps(record, indent=None, sort_keys=True) + "\n"
        )
        flag = "ok" if record["archive_replay"]["all"] else "REPLAY DIFFERS"
        mismatched += not record["archive_replay"]["all"]
        print(job["problem"], flag, flush=True)
    print(f"{mismatched} problems not confirmed")
    return 0 if mismatched == 0 else 1


def x_main__mutmut_130(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    parser.add_argument(
        "--registry", type=Path, default=root / "verification/evidence/dataset_registry"
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument(
        "--archive", type=Path, default=root / "verification/evidence/labelled_pool/runs"
    )
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    mismatched = 0
    for job in lb.jobs(args.registry, args.adbench, args.pool):
        stem = job["problem"].replace(":", "_")
        archive_path = args.archive / f"{stem}.json"
        if not archive_path.is_file():
            print(job["problem"], "no archived run")
            mismatched += 1
            continue
        archive = json.loads(archive_path.read_text())
        if "failed" in archive:
            print(job["problem"], "archived run failed; not recoverable")
            mismatched += 1
            continue
        record = recover(job, archive)
        (args.output / f"{stem}.json").write_text(
            json.dumps(record, indent=1, sort_keys=None) + "\n"
        )
        flag = "ok" if record["archive_replay"]["all"] else "REPLAY DIFFERS"
        mismatched += not record["archive_replay"]["all"]
        print(job["problem"], flag, flush=True)
    print(f"{mismatched} problems not confirmed")
    return 0 if mismatched == 0 else 1


def x_main__mutmut_131(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    parser.add_argument(
        "--registry", type=Path, default=root / "verification/evidence/dataset_registry"
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument(
        "--archive", type=Path, default=root / "verification/evidence/labelled_pool/runs"
    )
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    mismatched = 0
    for job in lb.jobs(args.registry, args.adbench, args.pool):
        stem = job["problem"].replace(":", "_")
        archive_path = args.archive / f"{stem}.json"
        if not archive_path.is_file():
            print(job["problem"], "no archived run")
            mismatched += 1
            continue
        archive = json.loads(archive_path.read_text())
        if "failed" in archive:
            print(job["problem"], "archived run failed; not recoverable")
            mismatched += 1
            continue
        record = recover(job, archive)
        (args.output / f"{stem}.json").write_text(
            json.dumps(indent=1, sort_keys=True) + "\n"
        )
        flag = "ok" if record["archive_replay"]["all"] else "REPLAY DIFFERS"
        mismatched += not record["archive_replay"]["all"]
        print(job["problem"], flag, flush=True)
    print(f"{mismatched} problems not confirmed")
    return 0 if mismatched == 0 else 1


def x_main__mutmut_132(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    parser.add_argument(
        "--registry", type=Path, default=root / "verification/evidence/dataset_registry"
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument(
        "--archive", type=Path, default=root / "verification/evidence/labelled_pool/runs"
    )
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    mismatched = 0
    for job in lb.jobs(args.registry, args.adbench, args.pool):
        stem = job["problem"].replace(":", "_")
        archive_path = args.archive / f"{stem}.json"
        if not archive_path.is_file():
            print(job["problem"], "no archived run")
            mismatched += 1
            continue
        archive = json.loads(archive_path.read_text())
        if "failed" in archive:
            print(job["problem"], "archived run failed; not recoverable")
            mismatched += 1
            continue
        record = recover(job, archive)
        (args.output / f"{stem}.json").write_text(
            json.dumps(record, sort_keys=True) + "\n"
        )
        flag = "ok" if record["archive_replay"]["all"] else "REPLAY DIFFERS"
        mismatched += not record["archive_replay"]["all"]
        print(job["problem"], flag, flush=True)
    print(f"{mismatched} problems not confirmed")
    return 0 if mismatched == 0 else 1


def x_main__mutmut_133(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    parser.add_argument(
        "--registry", type=Path, default=root / "verification/evidence/dataset_registry"
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument(
        "--archive", type=Path, default=root / "verification/evidence/labelled_pool/runs"
    )
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    mismatched = 0
    for job in lb.jobs(args.registry, args.adbench, args.pool):
        stem = job["problem"].replace(":", "_")
        archive_path = args.archive / f"{stem}.json"
        if not archive_path.is_file():
            print(job["problem"], "no archived run")
            mismatched += 1
            continue
        archive = json.loads(archive_path.read_text())
        if "failed" in archive:
            print(job["problem"], "archived run failed; not recoverable")
            mismatched += 1
            continue
        record = recover(job, archive)
        (args.output / f"{stem}.json").write_text(
            json.dumps(record, indent=1, ) + "\n"
        )
        flag = "ok" if record["archive_replay"]["all"] else "REPLAY DIFFERS"
        mismatched += not record["archive_replay"]["all"]
        print(job["problem"], flag, flush=True)
    print(f"{mismatched} problems not confirmed")
    return 0 if mismatched == 0 else 1


def x_main__mutmut_134(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    parser.add_argument(
        "--registry", type=Path, default=root / "verification/evidence/dataset_registry"
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument(
        "--archive", type=Path, default=root / "verification/evidence/labelled_pool/runs"
    )
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    mismatched = 0
    for job in lb.jobs(args.registry, args.adbench, args.pool):
        stem = job["problem"].replace(":", "_")
        archive_path = args.archive / f"{stem}.json"
        if not archive_path.is_file():
            print(job["problem"], "no archived run")
            mismatched += 1
            continue
        archive = json.loads(archive_path.read_text())
        if "failed" in archive:
            print(job["problem"], "archived run failed; not recoverable")
            mismatched += 1
            continue
        record = recover(job, archive)
        (args.output / f"{stem}.json").write_text(
            json.dumps(record, indent=2, sort_keys=True) + "\n"
        )
        flag = "ok" if record["archive_replay"]["all"] else "REPLAY DIFFERS"
        mismatched += not record["archive_replay"]["all"]
        print(job["problem"], flag, flush=True)
    print(f"{mismatched} problems not confirmed")
    return 0 if mismatched == 0 else 1


def x_main__mutmut_135(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    parser.add_argument(
        "--registry", type=Path, default=root / "verification/evidence/dataset_registry"
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument(
        "--archive", type=Path, default=root / "verification/evidence/labelled_pool/runs"
    )
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    mismatched = 0
    for job in lb.jobs(args.registry, args.adbench, args.pool):
        stem = job["problem"].replace(":", "_")
        archive_path = args.archive / f"{stem}.json"
        if not archive_path.is_file():
            print(job["problem"], "no archived run")
            mismatched += 1
            continue
        archive = json.loads(archive_path.read_text())
        if "failed" in archive:
            print(job["problem"], "archived run failed; not recoverable")
            mismatched += 1
            continue
        record = recover(job, archive)
        (args.output / f"{stem}.json").write_text(
            json.dumps(record, indent=1, sort_keys=False) + "\n"
        )
        flag = "ok" if record["archive_replay"]["all"] else "REPLAY DIFFERS"
        mismatched += not record["archive_replay"]["all"]
        print(job["problem"], flag, flush=True)
    print(f"{mismatched} problems not confirmed")
    return 0 if mismatched == 0 else 1


def x_main__mutmut_136(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    parser.add_argument(
        "--registry", type=Path, default=root / "verification/evidence/dataset_registry"
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument(
        "--archive", type=Path, default=root / "verification/evidence/labelled_pool/runs"
    )
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    mismatched = 0
    for job in lb.jobs(args.registry, args.adbench, args.pool):
        stem = job["problem"].replace(":", "_")
        archive_path = args.archive / f"{stem}.json"
        if not archive_path.is_file():
            print(job["problem"], "no archived run")
            mismatched += 1
            continue
        archive = json.loads(archive_path.read_text())
        if "failed" in archive:
            print(job["problem"], "archived run failed; not recoverable")
            mismatched += 1
            continue
        record = recover(job, archive)
        (args.output / f"{stem}.json").write_text(
            json.dumps(record, indent=1, sort_keys=True) + "XX\nXX"
        )
        flag = "ok" if record["archive_replay"]["all"] else "REPLAY DIFFERS"
        mismatched += not record["archive_replay"]["all"]
        print(job["problem"], flag, flush=True)
    print(f"{mismatched} problems not confirmed")
    return 0 if mismatched == 0 else 1


def x_main__mutmut_137(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    parser.add_argument(
        "--registry", type=Path, default=root / "verification/evidence/dataset_registry"
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument(
        "--archive", type=Path, default=root / "verification/evidence/labelled_pool/runs"
    )
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    mismatched = 0
    for job in lb.jobs(args.registry, args.adbench, args.pool):
        stem = job["problem"].replace(":", "_")
        archive_path = args.archive / f"{stem}.json"
        if not archive_path.is_file():
            print(job["problem"], "no archived run")
            mismatched += 1
            continue
        archive = json.loads(archive_path.read_text())
        if "failed" in archive:
            print(job["problem"], "archived run failed; not recoverable")
            mismatched += 1
            continue
        record = recover(job, archive)
        (args.output / f"{stem}.json").write_text(
            json.dumps(record, indent=1, sort_keys=True) + "\n"
        )
        flag = None
        mismatched += not record["archive_replay"]["all"]
        print(job["problem"], flag, flush=True)
    print(f"{mismatched} problems not confirmed")
    return 0 if mismatched == 0 else 1


def x_main__mutmut_138(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    parser.add_argument(
        "--registry", type=Path, default=root / "verification/evidence/dataset_registry"
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument(
        "--archive", type=Path, default=root / "verification/evidence/labelled_pool/runs"
    )
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    mismatched = 0
    for job in lb.jobs(args.registry, args.adbench, args.pool):
        stem = job["problem"].replace(":", "_")
        archive_path = args.archive / f"{stem}.json"
        if not archive_path.is_file():
            print(job["problem"], "no archived run")
            mismatched += 1
            continue
        archive = json.loads(archive_path.read_text())
        if "failed" in archive:
            print(job["problem"], "archived run failed; not recoverable")
            mismatched += 1
            continue
        record = recover(job, archive)
        (args.output / f"{stem}.json").write_text(
            json.dumps(record, indent=1, sort_keys=True) + "\n"
        )
        flag = "ok" if (record["archive_replay"]["all"]) and False else "REPLAY DIFFERS"
        mismatched += not record["archive_replay"]["all"]
        print(job["problem"], flag, flush=True)
    print(f"{mismatched} problems not confirmed")
    return 0 if mismatched == 0 else 1


def x_main__mutmut_139(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    parser.add_argument(
        "--registry", type=Path, default=root / "verification/evidence/dataset_registry"
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument(
        "--archive", type=Path, default=root / "verification/evidence/labelled_pool/runs"
    )
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    mismatched = 0
    for job in lb.jobs(args.registry, args.adbench, args.pool):
        stem = job["problem"].replace(":", "_")
        archive_path = args.archive / f"{stem}.json"
        if not archive_path.is_file():
            print(job["problem"], "no archived run")
            mismatched += 1
            continue
        archive = json.loads(archive_path.read_text())
        if "failed" in archive:
            print(job["problem"], "archived run failed; not recoverable")
            mismatched += 1
            continue
        record = recover(job, archive)
        (args.output / f"{stem}.json").write_text(
            json.dumps(record, indent=1, sort_keys=True) + "\n"
        )
        flag = "ok" if (record["archive_replay"]["all"]) or True else "REPLAY DIFFERS"
        mismatched += not record["archive_replay"]["all"]
        print(job["problem"], flag, flush=True)
    print(f"{mismatched} problems not confirmed")
    return 0 if mismatched == 0 else 1


def x_main__mutmut_140(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    parser.add_argument(
        "--registry", type=Path, default=root / "verification/evidence/dataset_registry"
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument(
        "--archive", type=Path, default=root / "verification/evidence/labelled_pool/runs"
    )
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    mismatched = 0
    for job in lb.jobs(args.registry, args.adbench, args.pool):
        stem = job["problem"].replace(":", "_")
        archive_path = args.archive / f"{stem}.json"
        if not archive_path.is_file():
            print(job["problem"], "no archived run")
            mismatched += 1
            continue
        archive = json.loads(archive_path.read_text())
        if "failed" in archive:
            print(job["problem"], "archived run failed; not recoverable")
            mismatched += 1
            continue
        record = recover(job, archive)
        (args.output / f"{stem}.json").write_text(
            json.dumps(record, indent=1, sort_keys=True) + "\n"
        )
        flag = "XXokXX" if record["archive_replay"]["all"] else "REPLAY DIFFERS"
        mismatched += not record["archive_replay"]["all"]
        print(job["problem"], flag, flush=True)
    print(f"{mismatched} problems not confirmed")
    return 0 if mismatched == 0 else 1


def x_main__mutmut_141(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    parser.add_argument(
        "--registry", type=Path, default=root / "verification/evidence/dataset_registry"
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument(
        "--archive", type=Path, default=root / "verification/evidence/labelled_pool/runs"
    )
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    mismatched = 0
    for job in lb.jobs(args.registry, args.adbench, args.pool):
        stem = job["problem"].replace(":", "_")
        archive_path = args.archive / f"{stem}.json"
        if not archive_path.is_file():
            print(job["problem"], "no archived run")
            mismatched += 1
            continue
        archive = json.loads(archive_path.read_text())
        if "failed" in archive:
            print(job["problem"], "archived run failed; not recoverable")
            mismatched += 1
            continue
        record = recover(job, archive)
        (args.output / f"{stem}.json").write_text(
            json.dumps(record, indent=1, sort_keys=True) + "\n"
        )
        flag = "OK" if record["archive_replay"]["all"] else "REPLAY DIFFERS"
        mismatched += not record["archive_replay"]["all"]
        print(job["problem"], flag, flush=True)
    print(f"{mismatched} problems not confirmed")
    return 0 if mismatched == 0 else 1


def x_main__mutmut_142(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    parser.add_argument(
        "--registry", type=Path, default=root / "verification/evidence/dataset_registry"
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument(
        "--archive", type=Path, default=root / "verification/evidence/labelled_pool/runs"
    )
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    mismatched = 0
    for job in lb.jobs(args.registry, args.adbench, args.pool):
        stem = job["problem"].replace(":", "_")
        archive_path = args.archive / f"{stem}.json"
        if not archive_path.is_file():
            print(job["problem"], "no archived run")
            mismatched += 1
            continue
        archive = json.loads(archive_path.read_text())
        if "failed" in archive:
            print(job["problem"], "archived run failed; not recoverable")
            mismatched += 1
            continue
        record = recover(job, archive)
        (args.output / f"{stem}.json").write_text(
            json.dumps(record, indent=1, sort_keys=True) + "\n"
        )
        flag = "ok" if record["XXarchive_replayXX"]["all"] else "REPLAY DIFFERS"
        mismatched += not record["archive_replay"]["all"]
        print(job["problem"], flag, flush=True)
    print(f"{mismatched} problems not confirmed")
    return 0 if mismatched == 0 else 1


def x_main__mutmut_143(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    parser.add_argument(
        "--registry", type=Path, default=root / "verification/evidence/dataset_registry"
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument(
        "--archive", type=Path, default=root / "verification/evidence/labelled_pool/runs"
    )
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    mismatched = 0
    for job in lb.jobs(args.registry, args.adbench, args.pool):
        stem = job["problem"].replace(":", "_")
        archive_path = args.archive / f"{stem}.json"
        if not archive_path.is_file():
            print(job["problem"], "no archived run")
            mismatched += 1
            continue
        archive = json.loads(archive_path.read_text())
        if "failed" in archive:
            print(job["problem"], "archived run failed; not recoverable")
            mismatched += 1
            continue
        record = recover(job, archive)
        (args.output / f"{stem}.json").write_text(
            json.dumps(record, indent=1, sort_keys=True) + "\n"
        )
        flag = "ok" if record["ARCHIVE_REPLAY"]["all"] else "REPLAY DIFFERS"
        mismatched += not record["archive_replay"]["all"]
        print(job["problem"], flag, flush=True)
    print(f"{mismatched} problems not confirmed")
    return 0 if mismatched == 0 else 1


def x_main__mutmut_144(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    parser.add_argument(
        "--registry", type=Path, default=root / "verification/evidence/dataset_registry"
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument(
        "--archive", type=Path, default=root / "verification/evidence/labelled_pool/runs"
    )
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    mismatched = 0
    for job in lb.jobs(args.registry, args.adbench, args.pool):
        stem = job["problem"].replace(":", "_")
        archive_path = args.archive / f"{stem}.json"
        if not archive_path.is_file():
            print(job["problem"], "no archived run")
            mismatched += 1
            continue
        archive = json.loads(archive_path.read_text())
        if "failed" in archive:
            print(job["problem"], "archived run failed; not recoverable")
            mismatched += 1
            continue
        record = recover(job, archive)
        (args.output / f"{stem}.json").write_text(
            json.dumps(record, indent=1, sort_keys=True) + "\n"
        )
        flag = "ok" if record["archive_replay"]["XXallXX"] else "REPLAY DIFFERS"
        mismatched += not record["archive_replay"]["all"]
        print(job["problem"], flag, flush=True)
    print(f"{mismatched} problems not confirmed")
    return 0 if mismatched == 0 else 1


def x_main__mutmut_145(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    parser.add_argument(
        "--registry", type=Path, default=root / "verification/evidence/dataset_registry"
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument(
        "--archive", type=Path, default=root / "verification/evidence/labelled_pool/runs"
    )
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    mismatched = 0
    for job in lb.jobs(args.registry, args.adbench, args.pool):
        stem = job["problem"].replace(":", "_")
        archive_path = args.archive / f"{stem}.json"
        if not archive_path.is_file():
            print(job["problem"], "no archived run")
            mismatched += 1
            continue
        archive = json.loads(archive_path.read_text())
        if "failed" in archive:
            print(job["problem"], "archived run failed; not recoverable")
            mismatched += 1
            continue
        record = recover(job, archive)
        (args.output / f"{stem}.json").write_text(
            json.dumps(record, indent=1, sort_keys=True) + "\n"
        )
        flag = "ok" if record["archive_replay"]["ALL"] else "REPLAY DIFFERS"
        mismatched += not record["archive_replay"]["all"]
        print(job["problem"], flag, flush=True)
    print(f"{mismatched} problems not confirmed")
    return 0 if mismatched == 0 else 1


def x_main__mutmut_146(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    parser.add_argument(
        "--registry", type=Path, default=root / "verification/evidence/dataset_registry"
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument(
        "--archive", type=Path, default=root / "verification/evidence/labelled_pool/runs"
    )
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    mismatched = 0
    for job in lb.jobs(args.registry, args.adbench, args.pool):
        stem = job["problem"].replace(":", "_")
        archive_path = args.archive / f"{stem}.json"
        if not archive_path.is_file():
            print(job["problem"], "no archived run")
            mismatched += 1
            continue
        archive = json.loads(archive_path.read_text())
        if "failed" in archive:
            print(job["problem"], "archived run failed; not recoverable")
            mismatched += 1
            continue
        record = recover(job, archive)
        (args.output / f"{stem}.json").write_text(
            json.dumps(record, indent=1, sort_keys=True) + "\n"
        )
        flag = "ok" if record["archive_replay"]["all"] else "XXREPLAY DIFFERSXX"
        mismatched += not record["archive_replay"]["all"]
        print(job["problem"], flag, flush=True)
    print(f"{mismatched} problems not confirmed")
    return 0 if mismatched == 0 else 1


def x_main__mutmut_147(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    parser.add_argument(
        "--registry", type=Path, default=root / "verification/evidence/dataset_registry"
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument(
        "--archive", type=Path, default=root / "verification/evidence/labelled_pool/runs"
    )
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    mismatched = 0
    for job in lb.jobs(args.registry, args.adbench, args.pool):
        stem = job["problem"].replace(":", "_")
        archive_path = args.archive / f"{stem}.json"
        if not archive_path.is_file():
            print(job["problem"], "no archived run")
            mismatched += 1
            continue
        archive = json.loads(archive_path.read_text())
        if "failed" in archive:
            print(job["problem"], "archived run failed; not recoverable")
            mismatched += 1
            continue
        record = recover(job, archive)
        (args.output / f"{stem}.json").write_text(
            json.dumps(record, indent=1, sort_keys=True) + "\n"
        )
        flag = "ok" if record["archive_replay"]["all"] else "replay differs"
        mismatched += not record["archive_replay"]["all"]
        print(job["problem"], flag, flush=True)
    print(f"{mismatched} problems not confirmed")
    return 0 if mismatched == 0 else 1


def x_main__mutmut_148(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    parser.add_argument(
        "--registry", type=Path, default=root / "verification/evidence/dataset_registry"
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument(
        "--archive", type=Path, default=root / "verification/evidence/labelled_pool/runs"
    )
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    mismatched = 0
    for job in lb.jobs(args.registry, args.adbench, args.pool):
        stem = job["problem"].replace(":", "_")
        archive_path = args.archive / f"{stem}.json"
        if not archive_path.is_file():
            print(job["problem"], "no archived run")
            mismatched += 1
            continue
        archive = json.loads(archive_path.read_text())
        if "failed" in archive:
            print(job["problem"], "archived run failed; not recoverable")
            mismatched += 1
            continue
        record = recover(job, archive)
        (args.output / f"{stem}.json").write_text(
            json.dumps(record, indent=1, sort_keys=True) + "\n"
        )
        flag = "ok" if record["archive_replay"]["all"] else "REPLAY DIFFERS"
        mismatched = not record["archive_replay"]["all"]
        print(job["problem"], flag, flush=True)
    print(f"{mismatched} problems not confirmed")
    return 0 if mismatched == 0 else 1


def x_main__mutmut_149(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    parser.add_argument(
        "--registry", type=Path, default=root / "verification/evidence/dataset_registry"
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument(
        "--archive", type=Path, default=root / "verification/evidence/labelled_pool/runs"
    )
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    mismatched = 0
    for job in lb.jobs(args.registry, args.adbench, args.pool):
        stem = job["problem"].replace(":", "_")
        archive_path = args.archive / f"{stem}.json"
        if not archive_path.is_file():
            print(job["problem"], "no archived run")
            mismatched += 1
            continue
        archive = json.loads(archive_path.read_text())
        if "failed" in archive:
            print(job["problem"], "archived run failed; not recoverable")
            mismatched += 1
            continue
        record = recover(job, archive)
        (args.output / f"{stem}.json").write_text(
            json.dumps(record, indent=1, sort_keys=True) + "\n"
        )
        flag = "ok" if record["archive_replay"]["all"] else "REPLAY DIFFERS"
        mismatched -= not record["archive_replay"]["all"]
        print(job["problem"], flag, flush=True)
    print(f"{mismatched} problems not confirmed")
    return 0 if mismatched == 0 else 1


def x_main__mutmut_150(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    parser.add_argument(
        "--registry", type=Path, default=root / "verification/evidence/dataset_registry"
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument(
        "--archive", type=Path, default=root / "verification/evidence/labelled_pool/runs"
    )
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    mismatched = 0
    for job in lb.jobs(args.registry, args.adbench, args.pool):
        stem = job["problem"].replace(":", "_")
        archive_path = args.archive / f"{stem}.json"
        if not archive_path.is_file():
            print(job["problem"], "no archived run")
            mismatched += 1
            continue
        archive = json.loads(archive_path.read_text())
        if "failed" in archive:
            print(job["problem"], "archived run failed; not recoverable")
            mismatched += 1
            continue
        record = recover(job, archive)
        (args.output / f"{stem}.json").write_text(
            json.dumps(record, indent=1, sort_keys=True) + "\n"
        )
        flag = "ok" if record["archive_replay"]["all"] else "REPLAY DIFFERS"
        mismatched += record["archive_replay"]["all"]
        print(job["problem"], flag, flush=True)
    print(f"{mismatched} problems not confirmed")
    return 0 if mismatched == 0 else 1


def x_main__mutmut_151(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    parser.add_argument(
        "--registry", type=Path, default=root / "verification/evidence/dataset_registry"
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument(
        "--archive", type=Path, default=root / "verification/evidence/labelled_pool/runs"
    )
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    mismatched = 0
    for job in lb.jobs(args.registry, args.adbench, args.pool):
        stem = job["problem"].replace(":", "_")
        archive_path = args.archive / f"{stem}.json"
        if not archive_path.is_file():
            print(job["problem"], "no archived run")
            mismatched += 1
            continue
        archive = json.loads(archive_path.read_text())
        if "failed" in archive:
            print(job["problem"], "archived run failed; not recoverable")
            mismatched += 1
            continue
        record = recover(job, archive)
        (args.output / f"{stem}.json").write_text(
            json.dumps(record, indent=1, sort_keys=True) + "\n"
        )
        flag = "ok" if record["archive_replay"]["all"] else "REPLAY DIFFERS"
        mismatched += not record["XXarchive_replayXX"]["all"]
        print(job["problem"], flag, flush=True)
    print(f"{mismatched} problems not confirmed")
    return 0 if mismatched == 0 else 1


def x_main__mutmut_152(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    parser.add_argument(
        "--registry", type=Path, default=root / "verification/evidence/dataset_registry"
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument(
        "--archive", type=Path, default=root / "verification/evidence/labelled_pool/runs"
    )
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    mismatched = 0
    for job in lb.jobs(args.registry, args.adbench, args.pool):
        stem = job["problem"].replace(":", "_")
        archive_path = args.archive / f"{stem}.json"
        if not archive_path.is_file():
            print(job["problem"], "no archived run")
            mismatched += 1
            continue
        archive = json.loads(archive_path.read_text())
        if "failed" in archive:
            print(job["problem"], "archived run failed; not recoverable")
            mismatched += 1
            continue
        record = recover(job, archive)
        (args.output / f"{stem}.json").write_text(
            json.dumps(record, indent=1, sort_keys=True) + "\n"
        )
        flag = "ok" if record["archive_replay"]["all"] else "REPLAY DIFFERS"
        mismatched += not record["ARCHIVE_REPLAY"]["all"]
        print(job["problem"], flag, flush=True)
    print(f"{mismatched} problems not confirmed")
    return 0 if mismatched == 0 else 1


def x_main__mutmut_153(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    parser.add_argument(
        "--registry", type=Path, default=root / "verification/evidence/dataset_registry"
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument(
        "--archive", type=Path, default=root / "verification/evidence/labelled_pool/runs"
    )
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    mismatched = 0
    for job in lb.jobs(args.registry, args.adbench, args.pool):
        stem = job["problem"].replace(":", "_")
        archive_path = args.archive / f"{stem}.json"
        if not archive_path.is_file():
            print(job["problem"], "no archived run")
            mismatched += 1
            continue
        archive = json.loads(archive_path.read_text())
        if "failed" in archive:
            print(job["problem"], "archived run failed; not recoverable")
            mismatched += 1
            continue
        record = recover(job, archive)
        (args.output / f"{stem}.json").write_text(
            json.dumps(record, indent=1, sort_keys=True) + "\n"
        )
        flag = "ok" if record["archive_replay"]["all"] else "REPLAY DIFFERS"
        mismatched += not record["archive_replay"]["XXallXX"]
        print(job["problem"], flag, flush=True)
    print(f"{mismatched} problems not confirmed")
    return 0 if mismatched == 0 else 1


def x_main__mutmut_154(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    parser.add_argument(
        "--registry", type=Path, default=root / "verification/evidence/dataset_registry"
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument(
        "--archive", type=Path, default=root / "verification/evidence/labelled_pool/runs"
    )
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    mismatched = 0
    for job in lb.jobs(args.registry, args.adbench, args.pool):
        stem = job["problem"].replace(":", "_")
        archive_path = args.archive / f"{stem}.json"
        if not archive_path.is_file():
            print(job["problem"], "no archived run")
            mismatched += 1
            continue
        archive = json.loads(archive_path.read_text())
        if "failed" in archive:
            print(job["problem"], "archived run failed; not recoverable")
            mismatched += 1
            continue
        record = recover(job, archive)
        (args.output / f"{stem}.json").write_text(
            json.dumps(record, indent=1, sort_keys=True) + "\n"
        )
        flag = "ok" if record["archive_replay"]["all"] else "REPLAY DIFFERS"
        mismatched += not record["archive_replay"]["ALL"]
        print(job["problem"], flag, flush=True)
    print(f"{mismatched} problems not confirmed")
    return 0 if mismatched == 0 else 1


def x_main__mutmut_155(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    parser.add_argument(
        "--registry", type=Path, default=root / "verification/evidence/dataset_registry"
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument(
        "--archive", type=Path, default=root / "verification/evidence/labelled_pool/runs"
    )
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    mismatched = 0
    for job in lb.jobs(args.registry, args.adbench, args.pool):
        stem = job["problem"].replace(":", "_")
        archive_path = args.archive / f"{stem}.json"
        if not archive_path.is_file():
            print(job["problem"], "no archived run")
            mismatched += 1
            continue
        archive = json.loads(archive_path.read_text())
        if "failed" in archive:
            print(job["problem"], "archived run failed; not recoverable")
            mismatched += 1
            continue
        record = recover(job, archive)
        (args.output / f"{stem}.json").write_text(
            json.dumps(record, indent=1, sort_keys=True) + "\n"
        )
        flag = "ok" if record["archive_replay"]["all"] else "REPLAY DIFFERS"
        mismatched += not record["archive_replay"]["all"]
        print(None, flag, flush=True)
    print(f"{mismatched} problems not confirmed")
    return 0 if mismatched == 0 else 1


def x_main__mutmut_156(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    parser.add_argument(
        "--registry", type=Path, default=root / "verification/evidence/dataset_registry"
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument(
        "--archive", type=Path, default=root / "verification/evidence/labelled_pool/runs"
    )
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    mismatched = 0
    for job in lb.jobs(args.registry, args.adbench, args.pool):
        stem = job["problem"].replace(":", "_")
        archive_path = args.archive / f"{stem}.json"
        if not archive_path.is_file():
            print(job["problem"], "no archived run")
            mismatched += 1
            continue
        archive = json.loads(archive_path.read_text())
        if "failed" in archive:
            print(job["problem"], "archived run failed; not recoverable")
            mismatched += 1
            continue
        record = recover(job, archive)
        (args.output / f"{stem}.json").write_text(
            json.dumps(record, indent=1, sort_keys=True) + "\n"
        )
        flag = "ok" if record["archive_replay"]["all"] else "REPLAY DIFFERS"
        mismatched += not record["archive_replay"]["all"]
        print(job["problem"], None, flush=True)
    print(f"{mismatched} problems not confirmed")
    return 0 if mismatched == 0 else 1


def x_main__mutmut_157(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    parser.add_argument(
        "--registry", type=Path, default=root / "verification/evidence/dataset_registry"
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument(
        "--archive", type=Path, default=root / "verification/evidence/labelled_pool/runs"
    )
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    mismatched = 0
    for job in lb.jobs(args.registry, args.adbench, args.pool):
        stem = job["problem"].replace(":", "_")
        archive_path = args.archive / f"{stem}.json"
        if not archive_path.is_file():
            print(job["problem"], "no archived run")
            mismatched += 1
            continue
        archive = json.loads(archive_path.read_text())
        if "failed" in archive:
            print(job["problem"], "archived run failed; not recoverable")
            mismatched += 1
            continue
        record = recover(job, archive)
        (args.output / f"{stem}.json").write_text(
            json.dumps(record, indent=1, sort_keys=True) + "\n"
        )
        flag = "ok" if record["archive_replay"]["all"] else "REPLAY DIFFERS"
        mismatched += not record["archive_replay"]["all"]
        print(job["problem"], flag, flush=None)
    print(f"{mismatched} problems not confirmed")
    return 0 if mismatched == 0 else 1


def x_main__mutmut_158(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    parser.add_argument(
        "--registry", type=Path, default=root / "verification/evidence/dataset_registry"
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument(
        "--archive", type=Path, default=root / "verification/evidence/labelled_pool/runs"
    )
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    mismatched = 0
    for job in lb.jobs(args.registry, args.adbench, args.pool):
        stem = job["problem"].replace(":", "_")
        archive_path = args.archive / f"{stem}.json"
        if not archive_path.is_file():
            print(job["problem"], "no archived run")
            mismatched += 1
            continue
        archive = json.loads(archive_path.read_text())
        if "failed" in archive:
            print(job["problem"], "archived run failed; not recoverable")
            mismatched += 1
            continue
        record = recover(job, archive)
        (args.output / f"{stem}.json").write_text(
            json.dumps(record, indent=1, sort_keys=True) + "\n"
        )
        flag = "ok" if record["archive_replay"]["all"] else "REPLAY DIFFERS"
        mismatched += not record["archive_replay"]["all"]
        print(flag, flush=True)
    print(f"{mismatched} problems not confirmed")
    return 0 if mismatched == 0 else 1


def x_main__mutmut_159(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    parser.add_argument(
        "--registry", type=Path, default=root / "verification/evidence/dataset_registry"
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument(
        "--archive", type=Path, default=root / "verification/evidence/labelled_pool/runs"
    )
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    mismatched = 0
    for job in lb.jobs(args.registry, args.adbench, args.pool):
        stem = job["problem"].replace(":", "_")
        archive_path = args.archive / f"{stem}.json"
        if not archive_path.is_file():
            print(job["problem"], "no archived run")
            mismatched += 1
            continue
        archive = json.loads(archive_path.read_text())
        if "failed" in archive:
            print(job["problem"], "archived run failed; not recoverable")
            mismatched += 1
            continue
        record = recover(job, archive)
        (args.output / f"{stem}.json").write_text(
            json.dumps(record, indent=1, sort_keys=True) + "\n"
        )
        flag = "ok" if record["archive_replay"]["all"] else "REPLAY DIFFERS"
        mismatched += not record["archive_replay"]["all"]
        print(job["problem"], flush=True)
    print(f"{mismatched} problems not confirmed")
    return 0 if mismatched == 0 else 1


def x_main__mutmut_160(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    parser.add_argument(
        "--registry", type=Path, default=root / "verification/evidence/dataset_registry"
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument(
        "--archive", type=Path, default=root / "verification/evidence/labelled_pool/runs"
    )
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    mismatched = 0
    for job in lb.jobs(args.registry, args.adbench, args.pool):
        stem = job["problem"].replace(":", "_")
        archive_path = args.archive / f"{stem}.json"
        if not archive_path.is_file():
            print(job["problem"], "no archived run")
            mismatched += 1
            continue
        archive = json.loads(archive_path.read_text())
        if "failed" in archive:
            print(job["problem"], "archived run failed; not recoverable")
            mismatched += 1
            continue
        record = recover(job, archive)
        (args.output / f"{stem}.json").write_text(
            json.dumps(record, indent=1, sort_keys=True) + "\n"
        )
        flag = "ok" if record["archive_replay"]["all"] else "REPLAY DIFFERS"
        mismatched += not record["archive_replay"]["all"]
        print(job["problem"], flag, )
    print(f"{mismatched} problems not confirmed")
    return 0 if mismatched == 0 else 1


def x_main__mutmut_161(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    parser.add_argument(
        "--registry", type=Path, default=root / "verification/evidence/dataset_registry"
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument(
        "--archive", type=Path, default=root / "verification/evidence/labelled_pool/runs"
    )
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    mismatched = 0
    for job in lb.jobs(args.registry, args.adbench, args.pool):
        stem = job["problem"].replace(":", "_")
        archive_path = args.archive / f"{stem}.json"
        if not archive_path.is_file():
            print(job["problem"], "no archived run")
            mismatched += 1
            continue
        archive = json.loads(archive_path.read_text())
        if "failed" in archive:
            print(job["problem"], "archived run failed; not recoverable")
            mismatched += 1
            continue
        record = recover(job, archive)
        (args.output / f"{stem}.json").write_text(
            json.dumps(record, indent=1, sort_keys=True) + "\n"
        )
        flag = "ok" if record["archive_replay"]["all"] else "REPLAY DIFFERS"
        mismatched += not record["archive_replay"]["all"]
        print(job["XXproblemXX"], flag, flush=True)
    print(f"{mismatched} problems not confirmed")
    return 0 if mismatched == 0 else 1


def x_main__mutmut_162(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    parser.add_argument(
        "--registry", type=Path, default=root / "verification/evidence/dataset_registry"
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument(
        "--archive", type=Path, default=root / "verification/evidence/labelled_pool/runs"
    )
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    mismatched = 0
    for job in lb.jobs(args.registry, args.adbench, args.pool):
        stem = job["problem"].replace(":", "_")
        archive_path = args.archive / f"{stem}.json"
        if not archive_path.is_file():
            print(job["problem"], "no archived run")
            mismatched += 1
            continue
        archive = json.loads(archive_path.read_text())
        if "failed" in archive:
            print(job["problem"], "archived run failed; not recoverable")
            mismatched += 1
            continue
        record = recover(job, archive)
        (args.output / f"{stem}.json").write_text(
            json.dumps(record, indent=1, sort_keys=True) + "\n"
        )
        flag = "ok" if record["archive_replay"]["all"] else "REPLAY DIFFERS"
        mismatched += not record["archive_replay"]["all"]
        print(job["PROBLEM"], flag, flush=True)
    print(f"{mismatched} problems not confirmed")
    return 0 if mismatched == 0 else 1


def x_main__mutmut_163(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    parser.add_argument(
        "--registry", type=Path, default=root / "verification/evidence/dataset_registry"
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument(
        "--archive", type=Path, default=root / "verification/evidence/labelled_pool/runs"
    )
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    mismatched = 0
    for job in lb.jobs(args.registry, args.adbench, args.pool):
        stem = job["problem"].replace(":", "_")
        archive_path = args.archive / f"{stem}.json"
        if not archive_path.is_file():
            print(job["problem"], "no archived run")
            mismatched += 1
            continue
        archive = json.loads(archive_path.read_text())
        if "failed" in archive:
            print(job["problem"], "archived run failed; not recoverable")
            mismatched += 1
            continue
        record = recover(job, archive)
        (args.output / f"{stem}.json").write_text(
            json.dumps(record, indent=1, sort_keys=True) + "\n"
        )
        flag = "ok" if record["archive_replay"]["all"] else "REPLAY DIFFERS"
        mismatched += not record["archive_replay"]["all"]
        print(job["problem"], flag, flush=False)
    print(f"{mismatched} problems not confirmed")
    return 0 if mismatched == 0 else 1


def x_main__mutmut_164(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    parser.add_argument(
        "--registry", type=Path, default=root / "verification/evidence/dataset_registry"
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument(
        "--archive", type=Path, default=root / "verification/evidence/labelled_pool/runs"
    )
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    mismatched = 0
    for job in lb.jobs(args.registry, args.adbench, args.pool):
        stem = job["problem"].replace(":", "_")
        archive_path = args.archive / f"{stem}.json"
        if not archive_path.is_file():
            print(job["problem"], "no archived run")
            mismatched += 1
            continue
        archive = json.loads(archive_path.read_text())
        if "failed" in archive:
            print(job["problem"], "archived run failed; not recoverable")
            mismatched += 1
            continue
        record = recover(job, archive)
        (args.output / f"{stem}.json").write_text(
            json.dumps(record, indent=1, sort_keys=True) + "\n"
        )
        flag = "ok" if record["archive_replay"]["all"] else "REPLAY DIFFERS"
        mismatched += not record["archive_replay"]["all"]
        print(job["problem"], flag, flush=True)
    print(None)
    return 0 if mismatched == 0 else 1


def x_main__mutmut_165(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    parser.add_argument(
        "--registry", type=Path, default=root / "verification/evidence/dataset_registry"
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument(
        "--archive", type=Path, default=root / "verification/evidence/labelled_pool/runs"
    )
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    mismatched = 0
    for job in lb.jobs(args.registry, args.adbench, args.pool):
        stem = job["problem"].replace(":", "_")
        archive_path = args.archive / f"{stem}.json"
        if not archive_path.is_file():
            print(job["problem"], "no archived run")
            mismatched += 1
            continue
        archive = json.loads(archive_path.read_text())
        if "failed" in archive:
            print(job["problem"], "archived run failed; not recoverable")
            mismatched += 1
            continue
        record = recover(job, archive)
        (args.output / f"{stem}.json").write_text(
            json.dumps(record, indent=1, sort_keys=True) + "\n"
        )
        flag = "ok" if record["archive_replay"]["all"] else "REPLAY DIFFERS"
        mismatched += not record["archive_replay"]["all"]
        print(job["problem"], flag, flush=True)
    print(f"{mismatched} problems not confirmed")
    return 0 if (mismatched == 0) and False else 1


def x_main__mutmut_166(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    parser.add_argument(
        "--registry", type=Path, default=root / "verification/evidence/dataset_registry"
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument(
        "--archive", type=Path, default=root / "verification/evidence/labelled_pool/runs"
    )
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    mismatched = 0
    for job in lb.jobs(args.registry, args.adbench, args.pool):
        stem = job["problem"].replace(":", "_")
        archive_path = args.archive / f"{stem}.json"
        if not archive_path.is_file():
            print(job["problem"], "no archived run")
            mismatched += 1
            continue
        archive = json.loads(archive_path.read_text())
        if "failed" in archive:
            print(job["problem"], "archived run failed; not recoverable")
            mismatched += 1
            continue
        record = recover(job, archive)
        (args.output / f"{stem}.json").write_text(
            json.dumps(record, indent=1, sort_keys=True) + "\n"
        )
        flag = "ok" if record["archive_replay"]["all"] else "REPLAY DIFFERS"
        mismatched += not record["archive_replay"]["all"]
        print(job["problem"], flag, flush=True)
    print(f"{mismatched} problems not confirmed")
    return 0 if (mismatched == 0) or True else 1


def x_main__mutmut_167(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    parser.add_argument(
        "--registry", type=Path, default=root / "verification/evidence/dataset_registry"
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument(
        "--archive", type=Path, default=root / "verification/evidence/labelled_pool/runs"
    )
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    mismatched = 0
    for job in lb.jobs(args.registry, args.adbench, args.pool):
        stem = job["problem"].replace(":", "_")
        archive_path = args.archive / f"{stem}.json"
        if not archive_path.is_file():
            print(job["problem"], "no archived run")
            mismatched += 1
            continue
        archive = json.loads(archive_path.read_text())
        if "failed" in archive:
            print(job["problem"], "archived run failed; not recoverable")
            mismatched += 1
            continue
        record = recover(job, archive)
        (args.output / f"{stem}.json").write_text(
            json.dumps(record, indent=1, sort_keys=True) + "\n"
        )
        flag = "ok" if record["archive_replay"]["all"] else "REPLAY DIFFERS"
        mismatched += not record["archive_replay"]["all"]
        print(job["problem"], flag, flush=True)
    print(f"{mismatched} problems not confirmed")
    return 1 if mismatched == 0 else 1


def x_main__mutmut_168(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    parser.add_argument(
        "--registry", type=Path, default=root / "verification/evidence/dataset_registry"
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument(
        "--archive", type=Path, default=root / "verification/evidence/labelled_pool/runs"
    )
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    mismatched = 0
    for job in lb.jobs(args.registry, args.adbench, args.pool):
        stem = job["problem"].replace(":", "_")
        archive_path = args.archive / f"{stem}.json"
        if not archive_path.is_file():
            print(job["problem"], "no archived run")
            mismatched += 1
            continue
        archive = json.loads(archive_path.read_text())
        if "failed" in archive:
            print(job["problem"], "archived run failed; not recoverable")
            mismatched += 1
            continue
        record = recover(job, archive)
        (args.output / f"{stem}.json").write_text(
            json.dumps(record, indent=1, sort_keys=True) + "\n"
        )
        flag = "ok" if record["archive_replay"]["all"] else "REPLAY DIFFERS"
        mismatched += not record["archive_replay"]["all"]
        print(job["problem"], flag, flush=True)
    print(f"{mismatched} problems not confirmed")
    return 0 if mismatched != 0 else 1


def x_main__mutmut_169(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    parser.add_argument(
        "--registry", type=Path, default=root / "verification/evidence/dataset_registry"
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument(
        "--archive", type=Path, default=root / "verification/evidence/labelled_pool/runs"
    )
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    mismatched = 0
    for job in lb.jobs(args.registry, args.adbench, args.pool):
        stem = job["problem"].replace(":", "_")
        archive_path = args.archive / f"{stem}.json"
        if not archive_path.is_file():
            print(job["problem"], "no archived run")
            mismatched += 1
            continue
        archive = json.loads(archive_path.read_text())
        if "failed" in archive:
            print(job["problem"], "archived run failed; not recoverable")
            mismatched += 1
            continue
        record = recover(job, archive)
        (args.output / f"{stem}.json").write_text(
            json.dumps(record, indent=1, sort_keys=True) + "\n"
        )
        flag = "ok" if record["archive_replay"]["all"] else "REPLAY DIFFERS"
        mismatched += not record["archive_replay"]["all"]
        print(job["problem"], flag, flush=True)
    print(f"{mismatched} problems not confirmed")
    return 0 if mismatched == 1 else 1


def x_main__mutmut_170(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    parser.add_argument(
        "--registry", type=Path, default=root / "verification/evidence/dataset_registry"
    )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument(
        "--archive", type=Path, default=root / "verification/evidence/labelled_pool/runs"
    )
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    mismatched = 0
    for job in lb.jobs(args.registry, args.adbench, args.pool):
        stem = job["problem"].replace(":", "_")
        archive_path = args.archive / f"{stem}.json"
        if not archive_path.is_file():
            print(job["problem"], "no archived run")
            mismatched += 1
            continue
        archive = json.loads(archive_path.read_text())
        if "failed" in archive:
            print(job["problem"], "archived run failed; not recoverable")
            mismatched += 1
            continue
        record = recover(job, archive)
        (args.output / f"{stem}.json").write_text(
            json.dumps(record, indent=1, sort_keys=True) + "\n"
        )
        flag = "ok" if record["archive_replay"]["all"] else "REPLAY DIFFERS"
        mismatched += not record["archive_replay"]["all"]
        print(job["problem"], flag, flush=True)
    print(f"{mismatched} problems not confirmed")
    return 0 if mismatched == 0 else 2

mutants_x_main__mutmut['_mutmut_orig'] = x_main__mutmut_orig # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_1'] = x_main__mutmut_1 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_2'] = x_main__mutmut_2 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_3'] = x_main__mutmut_3 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_4'] = x_main__mutmut_4 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_5'] = x_main__mutmut_5 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_6'] = x_main__mutmut_6 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_7'] = x_main__mutmut_7 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_8'] = x_main__mutmut_8 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_9'] = x_main__mutmut_9 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_10'] = x_main__mutmut_10 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_11'] = x_main__mutmut_11 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_12'] = x_main__mutmut_12 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_13'] = x_main__mutmut_13 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_14'] = x_main__mutmut_14 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_15'] = x_main__mutmut_15 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_16'] = x_main__mutmut_16 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_17'] = x_main__mutmut_17 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_18'] = x_main__mutmut_18 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_19'] = x_main__mutmut_19 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_20'] = x_main__mutmut_20 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_21'] = x_main__mutmut_21 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_22'] = x_main__mutmut_22 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_23'] = x_main__mutmut_23 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_24'] = x_main__mutmut_24 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_25'] = x_main__mutmut_25 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_26'] = x_main__mutmut_26 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_27'] = x_main__mutmut_27 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_28'] = x_main__mutmut_28 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_29'] = x_main__mutmut_29 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_30'] = x_main__mutmut_30 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_31'] = x_main__mutmut_31 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_32'] = x_main__mutmut_32 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_33'] = x_main__mutmut_33 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_34'] = x_main__mutmut_34 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_35'] = x_main__mutmut_35 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_36'] = x_main__mutmut_36 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_37'] = x_main__mutmut_37 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_38'] = x_main__mutmut_38 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_39'] = x_main__mutmut_39 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_40'] = x_main__mutmut_40 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_41'] = x_main__mutmut_41 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_42'] = x_main__mutmut_42 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_43'] = x_main__mutmut_43 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_44'] = x_main__mutmut_44 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_45'] = x_main__mutmut_45 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_46'] = x_main__mutmut_46 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_47'] = x_main__mutmut_47 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_48'] = x_main__mutmut_48 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_49'] = x_main__mutmut_49 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_50'] = x_main__mutmut_50 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_51'] = x_main__mutmut_51 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_52'] = x_main__mutmut_52 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_53'] = x_main__mutmut_53 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_54'] = x_main__mutmut_54 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_55'] = x_main__mutmut_55 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_56'] = x_main__mutmut_56 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_57'] = x_main__mutmut_57 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_58'] = x_main__mutmut_58 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_59'] = x_main__mutmut_59 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_60'] = x_main__mutmut_60 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_61'] = x_main__mutmut_61 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_62'] = x_main__mutmut_62 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_63'] = x_main__mutmut_63 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_64'] = x_main__mutmut_64 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_65'] = x_main__mutmut_65 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_66'] = x_main__mutmut_66 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_67'] = x_main__mutmut_67 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_68'] = x_main__mutmut_68 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_69'] = x_main__mutmut_69 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_70'] = x_main__mutmut_70 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_71'] = x_main__mutmut_71 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_72'] = x_main__mutmut_72 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_73'] = x_main__mutmut_73 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_74'] = x_main__mutmut_74 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_75'] = x_main__mutmut_75 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_76'] = x_main__mutmut_76 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_77'] = x_main__mutmut_77 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_78'] = x_main__mutmut_78 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_79'] = x_main__mutmut_79 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_80'] = x_main__mutmut_80 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_81'] = x_main__mutmut_81 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_82'] = x_main__mutmut_82 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_83'] = x_main__mutmut_83 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_84'] = x_main__mutmut_84 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_85'] = x_main__mutmut_85 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_86'] = x_main__mutmut_86 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_87'] = x_main__mutmut_87 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_88'] = x_main__mutmut_88 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_89'] = x_main__mutmut_89 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_90'] = x_main__mutmut_90 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_91'] = x_main__mutmut_91 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_92'] = x_main__mutmut_92 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_93'] = x_main__mutmut_93 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_94'] = x_main__mutmut_94 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_95'] = x_main__mutmut_95 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_96'] = x_main__mutmut_96 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_97'] = x_main__mutmut_97 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_98'] = x_main__mutmut_98 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_99'] = x_main__mutmut_99 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_100'] = x_main__mutmut_100 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_101'] = x_main__mutmut_101 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_102'] = x_main__mutmut_102 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_103'] = x_main__mutmut_103 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_104'] = x_main__mutmut_104 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_105'] = x_main__mutmut_105 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_106'] = x_main__mutmut_106 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_107'] = x_main__mutmut_107 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_108'] = x_main__mutmut_108 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_109'] = x_main__mutmut_109 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_110'] = x_main__mutmut_110 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_111'] = x_main__mutmut_111 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_112'] = x_main__mutmut_112 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_113'] = x_main__mutmut_113 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_114'] = x_main__mutmut_114 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_115'] = x_main__mutmut_115 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_116'] = x_main__mutmut_116 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_117'] = x_main__mutmut_117 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_118'] = x_main__mutmut_118 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_119'] = x_main__mutmut_119 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_120'] = x_main__mutmut_120 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_121'] = x_main__mutmut_121 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_122'] = x_main__mutmut_122 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_123'] = x_main__mutmut_123 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_124'] = x_main__mutmut_124 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_125'] = x_main__mutmut_125 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_126'] = x_main__mutmut_126 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_127'] = x_main__mutmut_127 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_128'] = x_main__mutmut_128 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_129'] = x_main__mutmut_129 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_130'] = x_main__mutmut_130 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_131'] = x_main__mutmut_131 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_132'] = x_main__mutmut_132 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_133'] = x_main__mutmut_133 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_134'] = x_main__mutmut_134 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_135'] = x_main__mutmut_135 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_136'] = x_main__mutmut_136 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_137'] = x_main__mutmut_137 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_138'] = x_main__mutmut_138 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_139'] = x_main__mutmut_139 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_140'] = x_main__mutmut_140 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_141'] = x_main__mutmut_141 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_142'] = x_main__mutmut_142 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_143'] = x_main__mutmut_143 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_144'] = x_main__mutmut_144 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_145'] = x_main__mutmut_145 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_146'] = x_main__mutmut_146 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_147'] = x_main__mutmut_147 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_148'] = x_main__mutmut_148 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_149'] = x_main__mutmut_149 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_150'] = x_main__mutmut_150 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_151'] = x_main__mutmut_151 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_152'] = x_main__mutmut_152 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_153'] = x_main__mutmut_153 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_154'] = x_main__mutmut_154 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_155'] = x_main__mutmut_155 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_156'] = x_main__mutmut_156 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_157'] = x_main__mutmut_157 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_158'] = x_main__mutmut_158 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_159'] = x_main__mutmut_159 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_160'] = x_main__mutmut_160 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_161'] = x_main__mutmut_161 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_162'] = x_main__mutmut_162 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_163'] = x_main__mutmut_163 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_164'] = x_main__mutmut_164 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_165'] = x_main__mutmut_165 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_166'] = x_main__mutmut_166 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_167'] = x_main__mutmut_167 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_168'] = x_main__mutmut_168 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_169'] = x_main__mutmut_169 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_170'] = x_main__mutmut_170 # type: ignore # mutmut generated


if __name__ == "__main__":
    raise SystemExit(main())
