"""Pooled summary of the per-dataset typed heatmaps and the pre-registered hypothesis checks.

The thresholds are those of verification/typed_injection.md, written before any result.
"""

from __future__ import annotations

from itertools import combinations
from typing import Any

import numpy as np
import pandas as pd
from scipy.stats import spearmanr

STRUCTURAL = ("missing_value", "duplicate", "invalid_format")
ML = ("isolation_forest", "lof", "ocsvm")


from mutmut.mutation.trampoline import wrap_in_trampoline as _mutmut_mutated, MutantDict
mutants_x_pooled__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_pooled__mutmut)
def pooled(data: dict[str, pd.DataFrame], resamples: int = 2000, seed: int = 0):
    """Median over datasets with a bootstrap interval resampling the datasets."""
    stack = np.stack([m.to_numpy(dtype=float) for m in data.values()])
    rng = np.random.default_rng(seed)
    boot = np.stack(
        [
            np.nanmedian(stack[rng.integers(0, len(stack), len(stack))], axis=0)
            for _ in range(resamples)
        ]
    )
    first = next(iter(data.values()))

    def frame(a: np.ndarray) -> pd.DataFrame:
        return pd.DataFrame(a, index=first.index, columns=first.columns)

    return {
        "median": frame(np.nanmedian(stack, axis=0)),
        "low": frame(np.nanpercentile(boot, 2.5, axis=0)),
        "high": frame(np.nanpercentile(boot, 97.5, axis=0)),
    }


def x_pooled__mutmut_orig(data: dict[str, pd.DataFrame], resamples: int = 2000, seed: int = 0):
    """Median over datasets with a bootstrap interval resampling the datasets."""
    stack = np.stack([m.to_numpy(dtype=float) for m in data.values()])
    rng = np.random.default_rng(seed)
    boot = np.stack(
        [
            np.nanmedian(stack[rng.integers(0, len(stack), len(stack))], axis=0)
            for _ in range(resamples)
        ]
    )
    first = next(iter(data.values()))

    def frame(a: np.ndarray) -> pd.DataFrame:
        return pd.DataFrame(a, index=first.index, columns=first.columns)

    return {
        "median": frame(np.nanmedian(stack, axis=0)),
        "low": frame(np.nanpercentile(boot, 2.5, axis=0)),
        "high": frame(np.nanpercentile(boot, 97.5, axis=0)),
    }


def x_pooled__mutmut_1(data: dict[str, pd.DataFrame], resamples: int = 2001, seed: int = 0):
    """Median over datasets with a bootstrap interval resampling the datasets."""
    stack = np.stack([m.to_numpy(dtype=float) for m in data.values()])
    rng = np.random.default_rng(seed)
    boot = np.stack(
        [
            np.nanmedian(stack[rng.integers(0, len(stack), len(stack))], axis=0)
            for _ in range(resamples)
        ]
    )
    first = next(iter(data.values()))

    def frame(a: np.ndarray) -> pd.DataFrame:
        return pd.DataFrame(a, index=first.index, columns=first.columns)

    return {
        "median": frame(np.nanmedian(stack, axis=0)),
        "low": frame(np.nanpercentile(boot, 2.5, axis=0)),
        "high": frame(np.nanpercentile(boot, 97.5, axis=0)),
    }


def x_pooled__mutmut_2(data: dict[str, pd.DataFrame], resamples: int = 2000, seed: int = 1):
    """Median over datasets with a bootstrap interval resampling the datasets."""
    stack = np.stack([m.to_numpy(dtype=float) for m in data.values()])
    rng = np.random.default_rng(seed)
    boot = np.stack(
        [
            np.nanmedian(stack[rng.integers(0, len(stack), len(stack))], axis=0)
            for _ in range(resamples)
        ]
    )
    first = next(iter(data.values()))

    def frame(a: np.ndarray) -> pd.DataFrame:
        return pd.DataFrame(a, index=first.index, columns=first.columns)

    return {
        "median": frame(np.nanmedian(stack, axis=0)),
        "low": frame(np.nanpercentile(boot, 2.5, axis=0)),
        "high": frame(np.nanpercentile(boot, 97.5, axis=0)),
    }


def x_pooled__mutmut_3(data: dict[str, pd.DataFrame], resamples: int = 2000, seed: int = 0):
    """Median over datasets with a bootstrap interval resampling the datasets."""
    stack = None
    rng = np.random.default_rng(seed)
    boot = np.stack(
        [
            np.nanmedian(stack[rng.integers(0, len(stack), len(stack))], axis=0)
            for _ in range(resamples)
        ]
    )
    first = next(iter(data.values()))

    def frame(a: np.ndarray) -> pd.DataFrame:
        return pd.DataFrame(a, index=first.index, columns=first.columns)

    return {
        "median": frame(np.nanmedian(stack, axis=0)),
        "low": frame(np.nanpercentile(boot, 2.5, axis=0)),
        "high": frame(np.nanpercentile(boot, 97.5, axis=0)),
    }


def x_pooled__mutmut_4(data: dict[str, pd.DataFrame], resamples: int = 2000, seed: int = 0):
    """Median over datasets with a bootstrap interval resampling the datasets."""
    stack = np.stack(None)
    rng = np.random.default_rng(seed)
    boot = np.stack(
        [
            np.nanmedian(stack[rng.integers(0, len(stack), len(stack))], axis=0)
            for _ in range(resamples)
        ]
    )
    first = next(iter(data.values()))

    def frame(a: np.ndarray) -> pd.DataFrame:
        return pd.DataFrame(a, index=first.index, columns=first.columns)

    return {
        "median": frame(np.nanmedian(stack, axis=0)),
        "low": frame(np.nanpercentile(boot, 2.5, axis=0)),
        "high": frame(np.nanpercentile(boot, 97.5, axis=0)),
    }


def x_pooled__mutmut_5(data: dict[str, pd.DataFrame], resamples: int = 2000, seed: int = 0):
    """Median over datasets with a bootstrap interval resampling the datasets."""
    stack = np.stack([m.to_numpy(dtype=None) for m in data.values()])
    rng = np.random.default_rng(seed)
    boot = np.stack(
        [
            np.nanmedian(stack[rng.integers(0, len(stack), len(stack))], axis=0)
            for _ in range(resamples)
        ]
    )
    first = next(iter(data.values()))

    def frame(a: np.ndarray) -> pd.DataFrame:
        return pd.DataFrame(a, index=first.index, columns=first.columns)

    return {
        "median": frame(np.nanmedian(stack, axis=0)),
        "low": frame(np.nanpercentile(boot, 2.5, axis=0)),
        "high": frame(np.nanpercentile(boot, 97.5, axis=0)),
    }


def x_pooled__mutmut_6(data: dict[str, pd.DataFrame], resamples: int = 2000, seed: int = 0):
    """Median over datasets with a bootstrap interval resampling the datasets."""
    stack = np.stack([m.to_numpy(dtype=float) for m in data.values()])
    rng = None
    boot = np.stack(
        [
            np.nanmedian(stack[rng.integers(0, len(stack), len(stack))], axis=0)
            for _ in range(resamples)
        ]
    )
    first = next(iter(data.values()))

    def frame(a: np.ndarray) -> pd.DataFrame:
        return pd.DataFrame(a, index=first.index, columns=first.columns)

    return {
        "median": frame(np.nanmedian(stack, axis=0)),
        "low": frame(np.nanpercentile(boot, 2.5, axis=0)),
        "high": frame(np.nanpercentile(boot, 97.5, axis=0)),
    }


def x_pooled__mutmut_7(data: dict[str, pd.DataFrame], resamples: int = 2000, seed: int = 0):
    """Median over datasets with a bootstrap interval resampling the datasets."""
    stack = np.stack([m.to_numpy(dtype=float) for m in data.values()])
    rng = np.random.default_rng(None)
    boot = np.stack(
        [
            np.nanmedian(stack[rng.integers(0, len(stack), len(stack))], axis=0)
            for _ in range(resamples)
        ]
    )
    first = next(iter(data.values()))

    def frame(a: np.ndarray) -> pd.DataFrame:
        return pd.DataFrame(a, index=first.index, columns=first.columns)

    return {
        "median": frame(np.nanmedian(stack, axis=0)),
        "low": frame(np.nanpercentile(boot, 2.5, axis=0)),
        "high": frame(np.nanpercentile(boot, 97.5, axis=0)),
    }


def x_pooled__mutmut_8(data: dict[str, pd.DataFrame], resamples: int = 2000, seed: int = 0):
    """Median over datasets with a bootstrap interval resampling the datasets."""
    stack = np.stack([m.to_numpy(dtype=float) for m in data.values()])
    rng = np.random.default_rng(seed)
    boot = None
    first = next(iter(data.values()))

    def frame(a: np.ndarray) -> pd.DataFrame:
        return pd.DataFrame(a, index=first.index, columns=first.columns)

    return {
        "median": frame(np.nanmedian(stack, axis=0)),
        "low": frame(np.nanpercentile(boot, 2.5, axis=0)),
        "high": frame(np.nanpercentile(boot, 97.5, axis=0)),
    }


def x_pooled__mutmut_9(data: dict[str, pd.DataFrame], resamples: int = 2000, seed: int = 0):
    """Median over datasets with a bootstrap interval resampling the datasets."""
    stack = np.stack([m.to_numpy(dtype=float) for m in data.values()])
    rng = np.random.default_rng(seed)
    boot = np.stack(
        None
    )
    first = next(iter(data.values()))

    def frame(a: np.ndarray) -> pd.DataFrame:
        return pd.DataFrame(a, index=first.index, columns=first.columns)

    return {
        "median": frame(np.nanmedian(stack, axis=0)),
        "low": frame(np.nanpercentile(boot, 2.5, axis=0)),
        "high": frame(np.nanpercentile(boot, 97.5, axis=0)),
    }


def x_pooled__mutmut_10(data: dict[str, pd.DataFrame], resamples: int = 2000, seed: int = 0):
    """Median over datasets with a bootstrap interval resampling the datasets."""
    stack = np.stack([m.to_numpy(dtype=float) for m in data.values()])
    rng = np.random.default_rng(seed)
    boot = np.stack(
        [
            np.nanmedian(None, axis=0)
            for _ in range(resamples)
        ]
    )
    first = next(iter(data.values()))

    def frame(a: np.ndarray) -> pd.DataFrame:
        return pd.DataFrame(a, index=first.index, columns=first.columns)

    return {
        "median": frame(np.nanmedian(stack, axis=0)),
        "low": frame(np.nanpercentile(boot, 2.5, axis=0)),
        "high": frame(np.nanpercentile(boot, 97.5, axis=0)),
    }


def x_pooled__mutmut_11(data: dict[str, pd.DataFrame], resamples: int = 2000, seed: int = 0):
    """Median over datasets with a bootstrap interval resampling the datasets."""
    stack = np.stack([m.to_numpy(dtype=float) for m in data.values()])
    rng = np.random.default_rng(seed)
    boot = np.stack(
        [
            np.nanmedian(stack[rng.integers(0, len(stack), len(stack))], axis=None)
            for _ in range(resamples)
        ]
    )
    first = next(iter(data.values()))

    def frame(a: np.ndarray) -> pd.DataFrame:
        return pd.DataFrame(a, index=first.index, columns=first.columns)

    return {
        "median": frame(np.nanmedian(stack, axis=0)),
        "low": frame(np.nanpercentile(boot, 2.5, axis=0)),
        "high": frame(np.nanpercentile(boot, 97.5, axis=0)),
    }


def x_pooled__mutmut_12(data: dict[str, pd.DataFrame], resamples: int = 2000, seed: int = 0):
    """Median over datasets with a bootstrap interval resampling the datasets."""
    stack = np.stack([m.to_numpy(dtype=float) for m in data.values()])
    rng = np.random.default_rng(seed)
    boot = np.stack(
        [
            np.nanmedian(axis=0)
            for _ in range(resamples)
        ]
    )
    first = next(iter(data.values()))

    def frame(a: np.ndarray) -> pd.DataFrame:
        return pd.DataFrame(a, index=first.index, columns=first.columns)

    return {
        "median": frame(np.nanmedian(stack, axis=0)),
        "low": frame(np.nanpercentile(boot, 2.5, axis=0)),
        "high": frame(np.nanpercentile(boot, 97.5, axis=0)),
    }


def x_pooled__mutmut_13(data: dict[str, pd.DataFrame], resamples: int = 2000, seed: int = 0):
    """Median over datasets with a bootstrap interval resampling the datasets."""
    stack = np.stack([m.to_numpy(dtype=float) for m in data.values()])
    rng = np.random.default_rng(seed)
    boot = np.stack(
        [
            np.nanmedian(stack[rng.integers(0, len(stack), len(stack))], )
            for _ in range(resamples)
        ]
    )
    first = next(iter(data.values()))

    def frame(a: np.ndarray) -> pd.DataFrame:
        return pd.DataFrame(a, index=first.index, columns=first.columns)

    return {
        "median": frame(np.nanmedian(stack, axis=0)),
        "low": frame(np.nanpercentile(boot, 2.5, axis=0)),
        "high": frame(np.nanpercentile(boot, 97.5, axis=0)),
    }


def x_pooled__mutmut_14(data: dict[str, pd.DataFrame], resamples: int = 2000, seed: int = 0):
    """Median over datasets with a bootstrap interval resampling the datasets."""
    stack = np.stack([m.to_numpy(dtype=float) for m in data.values()])
    rng = np.random.default_rng(seed)
    boot = np.stack(
        [
            np.nanmedian(stack[rng.integers(None, len(stack), len(stack))], axis=0)
            for _ in range(resamples)
        ]
    )
    first = next(iter(data.values()))

    def frame(a: np.ndarray) -> pd.DataFrame:
        return pd.DataFrame(a, index=first.index, columns=first.columns)

    return {
        "median": frame(np.nanmedian(stack, axis=0)),
        "low": frame(np.nanpercentile(boot, 2.5, axis=0)),
        "high": frame(np.nanpercentile(boot, 97.5, axis=0)),
    }


def x_pooled__mutmut_15(data: dict[str, pd.DataFrame], resamples: int = 2000, seed: int = 0):
    """Median over datasets with a bootstrap interval resampling the datasets."""
    stack = np.stack([m.to_numpy(dtype=float) for m in data.values()])
    rng = np.random.default_rng(seed)
    boot = np.stack(
        [
            np.nanmedian(stack[rng.integers(0, None, len(stack))], axis=0)
            for _ in range(resamples)
        ]
    )
    first = next(iter(data.values()))

    def frame(a: np.ndarray) -> pd.DataFrame:
        return pd.DataFrame(a, index=first.index, columns=first.columns)

    return {
        "median": frame(np.nanmedian(stack, axis=0)),
        "low": frame(np.nanpercentile(boot, 2.5, axis=0)),
        "high": frame(np.nanpercentile(boot, 97.5, axis=0)),
    }


def x_pooled__mutmut_16(data: dict[str, pd.DataFrame], resamples: int = 2000, seed: int = 0):
    """Median over datasets with a bootstrap interval resampling the datasets."""
    stack = np.stack([m.to_numpy(dtype=float) for m in data.values()])
    rng = np.random.default_rng(seed)
    boot = np.stack(
        [
            np.nanmedian(stack[rng.integers(0, len(stack), None)], axis=0)
            for _ in range(resamples)
        ]
    )
    first = next(iter(data.values()))

    def frame(a: np.ndarray) -> pd.DataFrame:
        return pd.DataFrame(a, index=first.index, columns=first.columns)

    return {
        "median": frame(np.nanmedian(stack, axis=0)),
        "low": frame(np.nanpercentile(boot, 2.5, axis=0)),
        "high": frame(np.nanpercentile(boot, 97.5, axis=0)),
    }


def x_pooled__mutmut_17(data: dict[str, pd.DataFrame], resamples: int = 2000, seed: int = 0):
    """Median over datasets with a bootstrap interval resampling the datasets."""
    stack = np.stack([m.to_numpy(dtype=float) for m in data.values()])
    rng = np.random.default_rng(seed)
    boot = np.stack(
        [
            np.nanmedian(stack[rng.integers(len(stack), len(stack))], axis=0)
            for _ in range(resamples)
        ]
    )
    first = next(iter(data.values()))

    def frame(a: np.ndarray) -> pd.DataFrame:
        return pd.DataFrame(a, index=first.index, columns=first.columns)

    return {
        "median": frame(np.nanmedian(stack, axis=0)),
        "low": frame(np.nanpercentile(boot, 2.5, axis=0)),
        "high": frame(np.nanpercentile(boot, 97.5, axis=0)),
    }


def x_pooled__mutmut_18(data: dict[str, pd.DataFrame], resamples: int = 2000, seed: int = 0):
    """Median over datasets with a bootstrap interval resampling the datasets."""
    stack = np.stack([m.to_numpy(dtype=float) for m in data.values()])
    rng = np.random.default_rng(seed)
    boot = np.stack(
        [
            np.nanmedian(stack[rng.integers(0, len(stack))], axis=0)
            for _ in range(resamples)
        ]
    )
    first = next(iter(data.values()))

    def frame(a: np.ndarray) -> pd.DataFrame:
        return pd.DataFrame(a, index=first.index, columns=first.columns)

    return {
        "median": frame(np.nanmedian(stack, axis=0)),
        "low": frame(np.nanpercentile(boot, 2.5, axis=0)),
        "high": frame(np.nanpercentile(boot, 97.5, axis=0)),
    }


def x_pooled__mutmut_19(data: dict[str, pd.DataFrame], resamples: int = 2000, seed: int = 0):
    """Median over datasets with a bootstrap interval resampling the datasets."""
    stack = np.stack([m.to_numpy(dtype=float) for m in data.values()])
    rng = np.random.default_rng(seed)
    boot = np.stack(
        [
            np.nanmedian(stack[rng.integers(0, len(stack), )], axis=0)
            for _ in range(resamples)
        ]
    )
    first = next(iter(data.values()))

    def frame(a: np.ndarray) -> pd.DataFrame:
        return pd.DataFrame(a, index=first.index, columns=first.columns)

    return {
        "median": frame(np.nanmedian(stack, axis=0)),
        "low": frame(np.nanpercentile(boot, 2.5, axis=0)),
        "high": frame(np.nanpercentile(boot, 97.5, axis=0)),
    }


def x_pooled__mutmut_20(data: dict[str, pd.DataFrame], resamples: int = 2000, seed: int = 0):
    """Median over datasets with a bootstrap interval resampling the datasets."""
    stack = np.stack([m.to_numpy(dtype=float) for m in data.values()])
    rng = np.random.default_rng(seed)
    boot = np.stack(
        [
            np.nanmedian(stack[rng.integers(1, len(stack), len(stack))], axis=0)
            for _ in range(resamples)
        ]
    )
    first = next(iter(data.values()))

    def frame(a: np.ndarray) -> pd.DataFrame:
        return pd.DataFrame(a, index=first.index, columns=first.columns)

    return {
        "median": frame(np.nanmedian(stack, axis=0)),
        "low": frame(np.nanpercentile(boot, 2.5, axis=0)),
        "high": frame(np.nanpercentile(boot, 97.5, axis=0)),
    }


def x_pooled__mutmut_21(data: dict[str, pd.DataFrame], resamples: int = 2000, seed: int = 0):
    """Median over datasets with a bootstrap interval resampling the datasets."""
    stack = np.stack([m.to_numpy(dtype=float) for m in data.values()])
    rng = np.random.default_rng(seed)
    boot = np.stack(
        [
            np.nanmedian(stack[rng.integers(0, len(stack), len(stack))], axis=1)
            for _ in range(resamples)
        ]
    )
    first = next(iter(data.values()))

    def frame(a: np.ndarray) -> pd.DataFrame:
        return pd.DataFrame(a, index=first.index, columns=first.columns)

    return {
        "median": frame(np.nanmedian(stack, axis=0)),
        "low": frame(np.nanpercentile(boot, 2.5, axis=0)),
        "high": frame(np.nanpercentile(boot, 97.5, axis=0)),
    }


def x_pooled__mutmut_22(data: dict[str, pd.DataFrame], resamples: int = 2000, seed: int = 0):
    """Median over datasets with a bootstrap interval resampling the datasets."""
    stack = np.stack([m.to_numpy(dtype=float) for m in data.values()])
    rng = np.random.default_rng(seed)
    boot = np.stack(
        [
            np.nanmedian(stack[rng.integers(0, len(stack), len(stack))], axis=0)
            for _ in range(None)
        ]
    )
    first = next(iter(data.values()))

    def frame(a: np.ndarray) -> pd.DataFrame:
        return pd.DataFrame(a, index=first.index, columns=first.columns)

    return {
        "median": frame(np.nanmedian(stack, axis=0)),
        "low": frame(np.nanpercentile(boot, 2.5, axis=0)),
        "high": frame(np.nanpercentile(boot, 97.5, axis=0)),
    }


def x_pooled__mutmut_23(data: dict[str, pd.DataFrame], resamples: int = 2000, seed: int = 0):
    """Median over datasets with a bootstrap interval resampling the datasets."""
    stack = np.stack([m.to_numpy(dtype=float) for m in data.values()])
    rng = np.random.default_rng(seed)
    boot = np.stack(
        [
            np.nanmedian(stack[rng.integers(0, len(stack), len(stack))], axis=0)
            for _ in range(resamples)
        ]
    )
    first = None

    def frame(a: np.ndarray) -> pd.DataFrame:
        return pd.DataFrame(a, index=first.index, columns=first.columns)

    return {
        "median": frame(np.nanmedian(stack, axis=0)),
        "low": frame(np.nanpercentile(boot, 2.5, axis=0)),
        "high": frame(np.nanpercentile(boot, 97.5, axis=0)),
    }


def x_pooled__mutmut_24(data: dict[str, pd.DataFrame], resamples: int = 2000, seed: int = 0):
    """Median over datasets with a bootstrap interval resampling the datasets."""
    stack = np.stack([m.to_numpy(dtype=float) for m in data.values()])
    rng = np.random.default_rng(seed)
    boot = np.stack(
        [
            np.nanmedian(stack[rng.integers(0, len(stack), len(stack))], axis=0)
            for _ in range(resamples)
        ]
    )
    first = next(None)

    def frame(a: np.ndarray) -> pd.DataFrame:
        return pd.DataFrame(a, index=first.index, columns=first.columns)

    return {
        "median": frame(np.nanmedian(stack, axis=0)),
        "low": frame(np.nanpercentile(boot, 2.5, axis=0)),
        "high": frame(np.nanpercentile(boot, 97.5, axis=0)),
    }


def x_pooled__mutmut_25(data: dict[str, pd.DataFrame], resamples: int = 2000, seed: int = 0):
    """Median over datasets with a bootstrap interval resampling the datasets."""
    stack = np.stack([m.to_numpy(dtype=float) for m in data.values()])
    rng = np.random.default_rng(seed)
    boot = np.stack(
        [
            np.nanmedian(stack[rng.integers(0, len(stack), len(stack))], axis=0)
            for _ in range(resamples)
        ]
    )
    first = next(iter(None))

    def frame(a: np.ndarray) -> pd.DataFrame:
        return pd.DataFrame(a, index=first.index, columns=first.columns)

    return {
        "median": frame(np.nanmedian(stack, axis=0)),
        "low": frame(np.nanpercentile(boot, 2.5, axis=0)),
        "high": frame(np.nanpercentile(boot, 97.5, axis=0)),
    }


def x_pooled__mutmut_26(data: dict[str, pd.DataFrame], resamples: int = 2000, seed: int = 0):
    """Median over datasets with a bootstrap interval resampling the datasets."""
    stack = np.stack([m.to_numpy(dtype=float) for m in data.values()])
    rng = np.random.default_rng(seed)
    boot = np.stack(
        [
            np.nanmedian(stack[rng.integers(0, len(stack), len(stack))], axis=0)
            for _ in range(resamples)
        ]
    )
    first = next(iter(data.values()))

    def frame(a: np.ndarray) -> pd.DataFrame:
        return pd.DataFrame(None, index=first.index, columns=first.columns)

    return {
        "median": frame(np.nanmedian(stack, axis=0)),
        "low": frame(np.nanpercentile(boot, 2.5, axis=0)),
        "high": frame(np.nanpercentile(boot, 97.5, axis=0)),
    }


def x_pooled__mutmut_27(data: dict[str, pd.DataFrame], resamples: int = 2000, seed: int = 0):
    """Median over datasets with a bootstrap interval resampling the datasets."""
    stack = np.stack([m.to_numpy(dtype=float) for m in data.values()])
    rng = np.random.default_rng(seed)
    boot = np.stack(
        [
            np.nanmedian(stack[rng.integers(0, len(stack), len(stack))], axis=0)
            for _ in range(resamples)
        ]
    )
    first = next(iter(data.values()))

    def frame(a: np.ndarray) -> pd.DataFrame:
        return pd.DataFrame(a, index=None, columns=first.columns)

    return {
        "median": frame(np.nanmedian(stack, axis=0)),
        "low": frame(np.nanpercentile(boot, 2.5, axis=0)),
        "high": frame(np.nanpercentile(boot, 97.5, axis=0)),
    }


def x_pooled__mutmut_28(data: dict[str, pd.DataFrame], resamples: int = 2000, seed: int = 0):
    """Median over datasets with a bootstrap interval resampling the datasets."""
    stack = np.stack([m.to_numpy(dtype=float) for m in data.values()])
    rng = np.random.default_rng(seed)
    boot = np.stack(
        [
            np.nanmedian(stack[rng.integers(0, len(stack), len(stack))], axis=0)
            for _ in range(resamples)
        ]
    )
    first = next(iter(data.values()))

    def frame(a: np.ndarray) -> pd.DataFrame:
        return pd.DataFrame(a, index=first.index, columns=None)

    return {
        "median": frame(np.nanmedian(stack, axis=0)),
        "low": frame(np.nanpercentile(boot, 2.5, axis=0)),
        "high": frame(np.nanpercentile(boot, 97.5, axis=0)),
    }


def x_pooled__mutmut_29(data: dict[str, pd.DataFrame], resamples: int = 2000, seed: int = 0):
    """Median over datasets with a bootstrap interval resampling the datasets."""
    stack = np.stack([m.to_numpy(dtype=float) for m in data.values()])
    rng = np.random.default_rng(seed)
    boot = np.stack(
        [
            np.nanmedian(stack[rng.integers(0, len(stack), len(stack))], axis=0)
            for _ in range(resamples)
        ]
    )
    first = next(iter(data.values()))

    def frame(a: np.ndarray) -> pd.DataFrame:
        return pd.DataFrame(index=first.index, columns=first.columns)

    return {
        "median": frame(np.nanmedian(stack, axis=0)),
        "low": frame(np.nanpercentile(boot, 2.5, axis=0)),
        "high": frame(np.nanpercentile(boot, 97.5, axis=0)),
    }


def x_pooled__mutmut_30(data: dict[str, pd.DataFrame], resamples: int = 2000, seed: int = 0):
    """Median over datasets with a bootstrap interval resampling the datasets."""
    stack = np.stack([m.to_numpy(dtype=float) for m in data.values()])
    rng = np.random.default_rng(seed)
    boot = np.stack(
        [
            np.nanmedian(stack[rng.integers(0, len(stack), len(stack))], axis=0)
            for _ in range(resamples)
        ]
    )
    first = next(iter(data.values()))

    def frame(a: np.ndarray) -> pd.DataFrame:
        return pd.DataFrame(a, columns=first.columns)

    return {
        "median": frame(np.nanmedian(stack, axis=0)),
        "low": frame(np.nanpercentile(boot, 2.5, axis=0)),
        "high": frame(np.nanpercentile(boot, 97.5, axis=0)),
    }


def x_pooled__mutmut_31(data: dict[str, pd.DataFrame], resamples: int = 2000, seed: int = 0):
    """Median over datasets with a bootstrap interval resampling the datasets."""
    stack = np.stack([m.to_numpy(dtype=float) for m in data.values()])
    rng = np.random.default_rng(seed)
    boot = np.stack(
        [
            np.nanmedian(stack[rng.integers(0, len(stack), len(stack))], axis=0)
            for _ in range(resamples)
        ]
    )
    first = next(iter(data.values()))

    def frame(a: np.ndarray) -> pd.DataFrame:
        return pd.DataFrame(a, index=first.index, )

    return {
        "median": frame(np.nanmedian(stack, axis=0)),
        "low": frame(np.nanpercentile(boot, 2.5, axis=0)),
        "high": frame(np.nanpercentile(boot, 97.5, axis=0)),
    }


def x_pooled__mutmut_32(data: dict[str, pd.DataFrame], resamples: int = 2000, seed: int = 0):
    """Median over datasets with a bootstrap interval resampling the datasets."""
    stack = np.stack([m.to_numpy(dtype=float) for m in data.values()])
    rng = np.random.default_rng(seed)
    boot = np.stack(
        [
            np.nanmedian(stack[rng.integers(0, len(stack), len(stack))], axis=0)
            for _ in range(resamples)
        ]
    )
    first = next(iter(data.values()))

    def frame(a: np.ndarray) -> pd.DataFrame:
        return pd.DataFrame(a, index=first.index, columns=first.columns)

    return {
        "XXmedianXX": frame(np.nanmedian(stack, axis=0)),
        "low": frame(np.nanpercentile(boot, 2.5, axis=0)),
        "high": frame(np.nanpercentile(boot, 97.5, axis=0)),
    }


def x_pooled__mutmut_33(data: dict[str, pd.DataFrame], resamples: int = 2000, seed: int = 0):
    """Median over datasets with a bootstrap interval resampling the datasets."""
    stack = np.stack([m.to_numpy(dtype=float) for m in data.values()])
    rng = np.random.default_rng(seed)
    boot = np.stack(
        [
            np.nanmedian(stack[rng.integers(0, len(stack), len(stack))], axis=0)
            for _ in range(resamples)
        ]
    )
    first = next(iter(data.values()))

    def frame(a: np.ndarray) -> pd.DataFrame:
        return pd.DataFrame(a, index=first.index, columns=first.columns)

    return {
        "MEDIAN": frame(np.nanmedian(stack, axis=0)),
        "low": frame(np.nanpercentile(boot, 2.5, axis=0)),
        "high": frame(np.nanpercentile(boot, 97.5, axis=0)),
    }


def x_pooled__mutmut_34(data: dict[str, pd.DataFrame], resamples: int = 2000, seed: int = 0):
    """Median over datasets with a bootstrap interval resampling the datasets."""
    stack = np.stack([m.to_numpy(dtype=float) for m in data.values()])
    rng = np.random.default_rng(seed)
    boot = np.stack(
        [
            np.nanmedian(stack[rng.integers(0, len(stack), len(stack))], axis=0)
            for _ in range(resamples)
        ]
    )
    first = next(iter(data.values()))

    def frame(a: np.ndarray) -> pd.DataFrame:
        return pd.DataFrame(a, index=first.index, columns=first.columns)

    return {
        "median": frame(None),
        "low": frame(np.nanpercentile(boot, 2.5, axis=0)),
        "high": frame(np.nanpercentile(boot, 97.5, axis=0)),
    }


def x_pooled__mutmut_35(data: dict[str, pd.DataFrame], resamples: int = 2000, seed: int = 0):
    """Median over datasets with a bootstrap interval resampling the datasets."""
    stack = np.stack([m.to_numpy(dtype=float) for m in data.values()])
    rng = np.random.default_rng(seed)
    boot = np.stack(
        [
            np.nanmedian(stack[rng.integers(0, len(stack), len(stack))], axis=0)
            for _ in range(resamples)
        ]
    )
    first = next(iter(data.values()))

    def frame(a: np.ndarray) -> pd.DataFrame:
        return pd.DataFrame(a, index=first.index, columns=first.columns)

    return {
        "median": frame(np.nanmedian(None, axis=0)),
        "low": frame(np.nanpercentile(boot, 2.5, axis=0)),
        "high": frame(np.nanpercentile(boot, 97.5, axis=0)),
    }


def x_pooled__mutmut_36(data: dict[str, pd.DataFrame], resamples: int = 2000, seed: int = 0):
    """Median over datasets with a bootstrap interval resampling the datasets."""
    stack = np.stack([m.to_numpy(dtype=float) for m in data.values()])
    rng = np.random.default_rng(seed)
    boot = np.stack(
        [
            np.nanmedian(stack[rng.integers(0, len(stack), len(stack))], axis=0)
            for _ in range(resamples)
        ]
    )
    first = next(iter(data.values()))

    def frame(a: np.ndarray) -> pd.DataFrame:
        return pd.DataFrame(a, index=first.index, columns=first.columns)

    return {
        "median": frame(np.nanmedian(stack, axis=None)),
        "low": frame(np.nanpercentile(boot, 2.5, axis=0)),
        "high": frame(np.nanpercentile(boot, 97.5, axis=0)),
    }


def x_pooled__mutmut_37(data: dict[str, pd.DataFrame], resamples: int = 2000, seed: int = 0):
    """Median over datasets with a bootstrap interval resampling the datasets."""
    stack = np.stack([m.to_numpy(dtype=float) for m in data.values()])
    rng = np.random.default_rng(seed)
    boot = np.stack(
        [
            np.nanmedian(stack[rng.integers(0, len(stack), len(stack))], axis=0)
            for _ in range(resamples)
        ]
    )
    first = next(iter(data.values()))

    def frame(a: np.ndarray) -> pd.DataFrame:
        return pd.DataFrame(a, index=first.index, columns=first.columns)

    return {
        "median": frame(np.nanmedian(axis=0)),
        "low": frame(np.nanpercentile(boot, 2.5, axis=0)),
        "high": frame(np.nanpercentile(boot, 97.5, axis=0)),
    }


def x_pooled__mutmut_38(data: dict[str, pd.DataFrame], resamples: int = 2000, seed: int = 0):
    """Median over datasets with a bootstrap interval resampling the datasets."""
    stack = np.stack([m.to_numpy(dtype=float) for m in data.values()])
    rng = np.random.default_rng(seed)
    boot = np.stack(
        [
            np.nanmedian(stack[rng.integers(0, len(stack), len(stack))], axis=0)
            for _ in range(resamples)
        ]
    )
    first = next(iter(data.values()))

    def frame(a: np.ndarray) -> pd.DataFrame:
        return pd.DataFrame(a, index=first.index, columns=first.columns)

    return {
        "median": frame(np.nanmedian(stack, )),
        "low": frame(np.nanpercentile(boot, 2.5, axis=0)),
        "high": frame(np.nanpercentile(boot, 97.5, axis=0)),
    }


def x_pooled__mutmut_39(data: dict[str, pd.DataFrame], resamples: int = 2000, seed: int = 0):
    """Median over datasets with a bootstrap interval resampling the datasets."""
    stack = np.stack([m.to_numpy(dtype=float) for m in data.values()])
    rng = np.random.default_rng(seed)
    boot = np.stack(
        [
            np.nanmedian(stack[rng.integers(0, len(stack), len(stack))], axis=0)
            for _ in range(resamples)
        ]
    )
    first = next(iter(data.values()))

    def frame(a: np.ndarray) -> pd.DataFrame:
        return pd.DataFrame(a, index=first.index, columns=first.columns)

    return {
        "median": frame(np.nanmedian(stack, axis=1)),
        "low": frame(np.nanpercentile(boot, 2.5, axis=0)),
        "high": frame(np.nanpercentile(boot, 97.5, axis=0)),
    }


def x_pooled__mutmut_40(data: dict[str, pd.DataFrame], resamples: int = 2000, seed: int = 0):
    """Median over datasets with a bootstrap interval resampling the datasets."""
    stack = np.stack([m.to_numpy(dtype=float) for m in data.values()])
    rng = np.random.default_rng(seed)
    boot = np.stack(
        [
            np.nanmedian(stack[rng.integers(0, len(stack), len(stack))], axis=0)
            for _ in range(resamples)
        ]
    )
    first = next(iter(data.values()))

    def frame(a: np.ndarray) -> pd.DataFrame:
        return pd.DataFrame(a, index=first.index, columns=first.columns)

    return {
        "median": frame(np.nanmedian(stack, axis=0)),
        "XXlowXX": frame(np.nanpercentile(boot, 2.5, axis=0)),
        "high": frame(np.nanpercentile(boot, 97.5, axis=0)),
    }


def x_pooled__mutmut_41(data: dict[str, pd.DataFrame], resamples: int = 2000, seed: int = 0):
    """Median over datasets with a bootstrap interval resampling the datasets."""
    stack = np.stack([m.to_numpy(dtype=float) for m in data.values()])
    rng = np.random.default_rng(seed)
    boot = np.stack(
        [
            np.nanmedian(stack[rng.integers(0, len(stack), len(stack))], axis=0)
            for _ in range(resamples)
        ]
    )
    first = next(iter(data.values()))

    def frame(a: np.ndarray) -> pd.DataFrame:
        return pd.DataFrame(a, index=first.index, columns=first.columns)

    return {
        "median": frame(np.nanmedian(stack, axis=0)),
        "LOW": frame(np.nanpercentile(boot, 2.5, axis=0)),
        "high": frame(np.nanpercentile(boot, 97.5, axis=0)),
    }


def x_pooled__mutmut_42(data: dict[str, pd.DataFrame], resamples: int = 2000, seed: int = 0):
    """Median over datasets with a bootstrap interval resampling the datasets."""
    stack = np.stack([m.to_numpy(dtype=float) for m in data.values()])
    rng = np.random.default_rng(seed)
    boot = np.stack(
        [
            np.nanmedian(stack[rng.integers(0, len(stack), len(stack))], axis=0)
            for _ in range(resamples)
        ]
    )
    first = next(iter(data.values()))

    def frame(a: np.ndarray) -> pd.DataFrame:
        return pd.DataFrame(a, index=first.index, columns=first.columns)

    return {
        "median": frame(np.nanmedian(stack, axis=0)),
        "low": frame(None),
        "high": frame(np.nanpercentile(boot, 97.5, axis=0)),
    }


def x_pooled__mutmut_43(data: dict[str, pd.DataFrame], resamples: int = 2000, seed: int = 0):
    """Median over datasets with a bootstrap interval resampling the datasets."""
    stack = np.stack([m.to_numpy(dtype=float) for m in data.values()])
    rng = np.random.default_rng(seed)
    boot = np.stack(
        [
            np.nanmedian(stack[rng.integers(0, len(stack), len(stack))], axis=0)
            for _ in range(resamples)
        ]
    )
    first = next(iter(data.values()))

    def frame(a: np.ndarray) -> pd.DataFrame:
        return pd.DataFrame(a, index=first.index, columns=first.columns)

    return {
        "median": frame(np.nanmedian(stack, axis=0)),
        "low": frame(np.nanpercentile(None, 2.5, axis=0)),
        "high": frame(np.nanpercentile(boot, 97.5, axis=0)),
    }


def x_pooled__mutmut_44(data: dict[str, pd.DataFrame], resamples: int = 2000, seed: int = 0):
    """Median over datasets with a bootstrap interval resampling the datasets."""
    stack = np.stack([m.to_numpy(dtype=float) for m in data.values()])
    rng = np.random.default_rng(seed)
    boot = np.stack(
        [
            np.nanmedian(stack[rng.integers(0, len(stack), len(stack))], axis=0)
            for _ in range(resamples)
        ]
    )
    first = next(iter(data.values()))

    def frame(a: np.ndarray) -> pd.DataFrame:
        return pd.DataFrame(a, index=first.index, columns=first.columns)

    return {
        "median": frame(np.nanmedian(stack, axis=0)),
        "low": frame(np.nanpercentile(boot, None, axis=0)),
        "high": frame(np.nanpercentile(boot, 97.5, axis=0)),
    }


def x_pooled__mutmut_45(data: dict[str, pd.DataFrame], resamples: int = 2000, seed: int = 0):
    """Median over datasets with a bootstrap interval resampling the datasets."""
    stack = np.stack([m.to_numpy(dtype=float) for m in data.values()])
    rng = np.random.default_rng(seed)
    boot = np.stack(
        [
            np.nanmedian(stack[rng.integers(0, len(stack), len(stack))], axis=0)
            for _ in range(resamples)
        ]
    )
    first = next(iter(data.values()))

    def frame(a: np.ndarray) -> pd.DataFrame:
        return pd.DataFrame(a, index=first.index, columns=first.columns)

    return {
        "median": frame(np.nanmedian(stack, axis=0)),
        "low": frame(np.nanpercentile(boot, 2.5, axis=None)),
        "high": frame(np.nanpercentile(boot, 97.5, axis=0)),
    }


def x_pooled__mutmut_46(data: dict[str, pd.DataFrame], resamples: int = 2000, seed: int = 0):
    """Median over datasets with a bootstrap interval resampling the datasets."""
    stack = np.stack([m.to_numpy(dtype=float) for m in data.values()])
    rng = np.random.default_rng(seed)
    boot = np.stack(
        [
            np.nanmedian(stack[rng.integers(0, len(stack), len(stack))], axis=0)
            for _ in range(resamples)
        ]
    )
    first = next(iter(data.values()))

    def frame(a: np.ndarray) -> pd.DataFrame:
        return pd.DataFrame(a, index=first.index, columns=first.columns)

    return {
        "median": frame(np.nanmedian(stack, axis=0)),
        "low": frame(np.nanpercentile(2.5, axis=0)),
        "high": frame(np.nanpercentile(boot, 97.5, axis=0)),
    }


def x_pooled__mutmut_47(data: dict[str, pd.DataFrame], resamples: int = 2000, seed: int = 0):
    """Median over datasets with a bootstrap interval resampling the datasets."""
    stack = np.stack([m.to_numpy(dtype=float) for m in data.values()])
    rng = np.random.default_rng(seed)
    boot = np.stack(
        [
            np.nanmedian(stack[rng.integers(0, len(stack), len(stack))], axis=0)
            for _ in range(resamples)
        ]
    )
    first = next(iter(data.values()))

    def frame(a: np.ndarray) -> pd.DataFrame:
        return pd.DataFrame(a, index=first.index, columns=first.columns)

    return {
        "median": frame(np.nanmedian(stack, axis=0)),
        "low": frame(np.nanpercentile(boot, axis=0)),
        "high": frame(np.nanpercentile(boot, 97.5, axis=0)),
    }


def x_pooled__mutmut_48(data: dict[str, pd.DataFrame], resamples: int = 2000, seed: int = 0):
    """Median over datasets with a bootstrap interval resampling the datasets."""
    stack = np.stack([m.to_numpy(dtype=float) for m in data.values()])
    rng = np.random.default_rng(seed)
    boot = np.stack(
        [
            np.nanmedian(stack[rng.integers(0, len(stack), len(stack))], axis=0)
            for _ in range(resamples)
        ]
    )
    first = next(iter(data.values()))

    def frame(a: np.ndarray) -> pd.DataFrame:
        return pd.DataFrame(a, index=first.index, columns=first.columns)

    return {
        "median": frame(np.nanmedian(stack, axis=0)),
        "low": frame(np.nanpercentile(boot, 2.5, )),
        "high": frame(np.nanpercentile(boot, 97.5, axis=0)),
    }


def x_pooled__mutmut_49(data: dict[str, pd.DataFrame], resamples: int = 2000, seed: int = 0):
    """Median over datasets with a bootstrap interval resampling the datasets."""
    stack = np.stack([m.to_numpy(dtype=float) for m in data.values()])
    rng = np.random.default_rng(seed)
    boot = np.stack(
        [
            np.nanmedian(stack[rng.integers(0, len(stack), len(stack))], axis=0)
            for _ in range(resamples)
        ]
    )
    first = next(iter(data.values()))

    def frame(a: np.ndarray) -> pd.DataFrame:
        return pd.DataFrame(a, index=first.index, columns=first.columns)

    return {
        "median": frame(np.nanmedian(stack, axis=0)),
        "low": frame(np.nanpercentile(boot, 3.5, axis=0)),
        "high": frame(np.nanpercentile(boot, 97.5, axis=0)),
    }


def x_pooled__mutmut_50(data: dict[str, pd.DataFrame], resamples: int = 2000, seed: int = 0):
    """Median over datasets with a bootstrap interval resampling the datasets."""
    stack = np.stack([m.to_numpy(dtype=float) for m in data.values()])
    rng = np.random.default_rng(seed)
    boot = np.stack(
        [
            np.nanmedian(stack[rng.integers(0, len(stack), len(stack))], axis=0)
            for _ in range(resamples)
        ]
    )
    first = next(iter(data.values()))

    def frame(a: np.ndarray) -> pd.DataFrame:
        return pd.DataFrame(a, index=first.index, columns=first.columns)

    return {
        "median": frame(np.nanmedian(stack, axis=0)),
        "low": frame(np.nanpercentile(boot, 2.5, axis=1)),
        "high": frame(np.nanpercentile(boot, 97.5, axis=0)),
    }


def x_pooled__mutmut_51(data: dict[str, pd.DataFrame], resamples: int = 2000, seed: int = 0):
    """Median over datasets with a bootstrap interval resampling the datasets."""
    stack = np.stack([m.to_numpy(dtype=float) for m in data.values()])
    rng = np.random.default_rng(seed)
    boot = np.stack(
        [
            np.nanmedian(stack[rng.integers(0, len(stack), len(stack))], axis=0)
            for _ in range(resamples)
        ]
    )
    first = next(iter(data.values()))

    def frame(a: np.ndarray) -> pd.DataFrame:
        return pd.DataFrame(a, index=first.index, columns=first.columns)

    return {
        "median": frame(np.nanmedian(stack, axis=0)),
        "low": frame(np.nanpercentile(boot, 2.5, axis=0)),
        "XXhighXX": frame(np.nanpercentile(boot, 97.5, axis=0)),
    }


def x_pooled__mutmut_52(data: dict[str, pd.DataFrame], resamples: int = 2000, seed: int = 0):
    """Median over datasets with a bootstrap interval resampling the datasets."""
    stack = np.stack([m.to_numpy(dtype=float) for m in data.values()])
    rng = np.random.default_rng(seed)
    boot = np.stack(
        [
            np.nanmedian(stack[rng.integers(0, len(stack), len(stack))], axis=0)
            for _ in range(resamples)
        ]
    )
    first = next(iter(data.values()))

    def frame(a: np.ndarray) -> pd.DataFrame:
        return pd.DataFrame(a, index=first.index, columns=first.columns)

    return {
        "median": frame(np.nanmedian(stack, axis=0)),
        "low": frame(np.nanpercentile(boot, 2.5, axis=0)),
        "HIGH": frame(np.nanpercentile(boot, 97.5, axis=0)),
    }


def x_pooled__mutmut_53(data: dict[str, pd.DataFrame], resamples: int = 2000, seed: int = 0):
    """Median over datasets with a bootstrap interval resampling the datasets."""
    stack = np.stack([m.to_numpy(dtype=float) for m in data.values()])
    rng = np.random.default_rng(seed)
    boot = np.stack(
        [
            np.nanmedian(stack[rng.integers(0, len(stack), len(stack))], axis=0)
            for _ in range(resamples)
        ]
    )
    first = next(iter(data.values()))

    def frame(a: np.ndarray) -> pd.DataFrame:
        return pd.DataFrame(a, index=first.index, columns=first.columns)

    return {
        "median": frame(np.nanmedian(stack, axis=0)),
        "low": frame(np.nanpercentile(boot, 2.5, axis=0)),
        "high": frame(None),
    }


def x_pooled__mutmut_54(data: dict[str, pd.DataFrame], resamples: int = 2000, seed: int = 0):
    """Median over datasets with a bootstrap interval resampling the datasets."""
    stack = np.stack([m.to_numpy(dtype=float) for m in data.values()])
    rng = np.random.default_rng(seed)
    boot = np.stack(
        [
            np.nanmedian(stack[rng.integers(0, len(stack), len(stack))], axis=0)
            for _ in range(resamples)
        ]
    )
    first = next(iter(data.values()))

    def frame(a: np.ndarray) -> pd.DataFrame:
        return pd.DataFrame(a, index=first.index, columns=first.columns)

    return {
        "median": frame(np.nanmedian(stack, axis=0)),
        "low": frame(np.nanpercentile(boot, 2.5, axis=0)),
        "high": frame(np.nanpercentile(None, 97.5, axis=0)),
    }


def x_pooled__mutmut_55(data: dict[str, pd.DataFrame], resamples: int = 2000, seed: int = 0):
    """Median over datasets with a bootstrap interval resampling the datasets."""
    stack = np.stack([m.to_numpy(dtype=float) for m in data.values()])
    rng = np.random.default_rng(seed)
    boot = np.stack(
        [
            np.nanmedian(stack[rng.integers(0, len(stack), len(stack))], axis=0)
            for _ in range(resamples)
        ]
    )
    first = next(iter(data.values()))

    def frame(a: np.ndarray) -> pd.DataFrame:
        return pd.DataFrame(a, index=first.index, columns=first.columns)

    return {
        "median": frame(np.nanmedian(stack, axis=0)),
        "low": frame(np.nanpercentile(boot, 2.5, axis=0)),
        "high": frame(np.nanpercentile(boot, None, axis=0)),
    }


def x_pooled__mutmut_56(data: dict[str, pd.DataFrame], resamples: int = 2000, seed: int = 0):
    """Median over datasets with a bootstrap interval resampling the datasets."""
    stack = np.stack([m.to_numpy(dtype=float) for m in data.values()])
    rng = np.random.default_rng(seed)
    boot = np.stack(
        [
            np.nanmedian(stack[rng.integers(0, len(stack), len(stack))], axis=0)
            for _ in range(resamples)
        ]
    )
    first = next(iter(data.values()))

    def frame(a: np.ndarray) -> pd.DataFrame:
        return pd.DataFrame(a, index=first.index, columns=first.columns)

    return {
        "median": frame(np.nanmedian(stack, axis=0)),
        "low": frame(np.nanpercentile(boot, 2.5, axis=0)),
        "high": frame(np.nanpercentile(boot, 97.5, axis=None)),
    }


def x_pooled__mutmut_57(data: dict[str, pd.DataFrame], resamples: int = 2000, seed: int = 0):
    """Median over datasets with a bootstrap interval resampling the datasets."""
    stack = np.stack([m.to_numpy(dtype=float) for m in data.values()])
    rng = np.random.default_rng(seed)
    boot = np.stack(
        [
            np.nanmedian(stack[rng.integers(0, len(stack), len(stack))], axis=0)
            for _ in range(resamples)
        ]
    )
    first = next(iter(data.values()))

    def frame(a: np.ndarray) -> pd.DataFrame:
        return pd.DataFrame(a, index=first.index, columns=first.columns)

    return {
        "median": frame(np.nanmedian(stack, axis=0)),
        "low": frame(np.nanpercentile(boot, 2.5, axis=0)),
        "high": frame(np.nanpercentile(97.5, axis=0)),
    }


def x_pooled__mutmut_58(data: dict[str, pd.DataFrame], resamples: int = 2000, seed: int = 0):
    """Median over datasets with a bootstrap interval resampling the datasets."""
    stack = np.stack([m.to_numpy(dtype=float) for m in data.values()])
    rng = np.random.default_rng(seed)
    boot = np.stack(
        [
            np.nanmedian(stack[rng.integers(0, len(stack), len(stack))], axis=0)
            for _ in range(resamples)
        ]
    )
    first = next(iter(data.values()))

    def frame(a: np.ndarray) -> pd.DataFrame:
        return pd.DataFrame(a, index=first.index, columns=first.columns)

    return {
        "median": frame(np.nanmedian(stack, axis=0)),
        "low": frame(np.nanpercentile(boot, 2.5, axis=0)),
        "high": frame(np.nanpercentile(boot, axis=0)),
    }


def x_pooled__mutmut_59(data: dict[str, pd.DataFrame], resamples: int = 2000, seed: int = 0):
    """Median over datasets with a bootstrap interval resampling the datasets."""
    stack = np.stack([m.to_numpy(dtype=float) for m in data.values()])
    rng = np.random.default_rng(seed)
    boot = np.stack(
        [
            np.nanmedian(stack[rng.integers(0, len(stack), len(stack))], axis=0)
            for _ in range(resamples)
        ]
    )
    first = next(iter(data.values()))

    def frame(a: np.ndarray) -> pd.DataFrame:
        return pd.DataFrame(a, index=first.index, columns=first.columns)

    return {
        "median": frame(np.nanmedian(stack, axis=0)),
        "low": frame(np.nanpercentile(boot, 2.5, axis=0)),
        "high": frame(np.nanpercentile(boot, 97.5, )),
    }


def x_pooled__mutmut_60(data: dict[str, pd.DataFrame], resamples: int = 2000, seed: int = 0):
    """Median over datasets with a bootstrap interval resampling the datasets."""
    stack = np.stack([m.to_numpy(dtype=float) for m in data.values()])
    rng = np.random.default_rng(seed)
    boot = np.stack(
        [
            np.nanmedian(stack[rng.integers(0, len(stack), len(stack))], axis=0)
            for _ in range(resamples)
        ]
    )
    first = next(iter(data.values()))

    def frame(a: np.ndarray) -> pd.DataFrame:
        return pd.DataFrame(a, index=first.index, columns=first.columns)

    return {
        "median": frame(np.nanmedian(stack, axis=0)),
        "low": frame(np.nanpercentile(boot, 2.5, axis=0)),
        "high": frame(np.nanpercentile(boot, 98.5, axis=0)),
    }


def x_pooled__mutmut_61(data: dict[str, pd.DataFrame], resamples: int = 2000, seed: int = 0):
    """Median over datasets with a bootstrap interval resampling the datasets."""
    stack = np.stack([m.to_numpy(dtype=float) for m in data.values()])
    rng = np.random.default_rng(seed)
    boot = np.stack(
        [
            np.nanmedian(stack[rng.integers(0, len(stack), len(stack))], axis=0)
            for _ in range(resamples)
        ]
    )
    first = next(iter(data.values()))

    def frame(a: np.ndarray) -> pd.DataFrame:
        return pd.DataFrame(a, index=first.index, columns=first.columns)

    return {
        "median": frame(np.nanmedian(stack, axis=0)),
        "low": frame(np.nanpercentile(boot, 2.5, axis=0)),
        "high": frame(np.nanpercentile(boot, 97.5, axis=1)),
    }

mutants_x_pooled__mutmut['_mutmut_orig'] = x_pooled__mutmut_orig # type: ignore # mutmut generated
mutants_x_pooled__mutmut['x_pooled__mutmut_1'] = x_pooled__mutmut_1 # type: ignore # mutmut generated
mutants_x_pooled__mutmut['x_pooled__mutmut_2'] = x_pooled__mutmut_2 # type: ignore # mutmut generated
mutants_x_pooled__mutmut['x_pooled__mutmut_3'] = x_pooled__mutmut_3 # type: ignore # mutmut generated
mutants_x_pooled__mutmut['x_pooled__mutmut_4'] = x_pooled__mutmut_4 # type: ignore # mutmut generated
mutants_x_pooled__mutmut['x_pooled__mutmut_5'] = x_pooled__mutmut_5 # type: ignore # mutmut generated
mutants_x_pooled__mutmut['x_pooled__mutmut_6'] = x_pooled__mutmut_6 # type: ignore # mutmut generated
mutants_x_pooled__mutmut['x_pooled__mutmut_7'] = x_pooled__mutmut_7 # type: ignore # mutmut generated
mutants_x_pooled__mutmut['x_pooled__mutmut_8'] = x_pooled__mutmut_8 # type: ignore # mutmut generated
mutants_x_pooled__mutmut['x_pooled__mutmut_9'] = x_pooled__mutmut_9 # type: ignore # mutmut generated
mutants_x_pooled__mutmut['x_pooled__mutmut_10'] = x_pooled__mutmut_10 # type: ignore # mutmut generated
mutants_x_pooled__mutmut['x_pooled__mutmut_11'] = x_pooled__mutmut_11 # type: ignore # mutmut generated
mutants_x_pooled__mutmut['x_pooled__mutmut_12'] = x_pooled__mutmut_12 # type: ignore # mutmut generated
mutants_x_pooled__mutmut['x_pooled__mutmut_13'] = x_pooled__mutmut_13 # type: ignore # mutmut generated
mutants_x_pooled__mutmut['x_pooled__mutmut_14'] = x_pooled__mutmut_14 # type: ignore # mutmut generated
mutants_x_pooled__mutmut['x_pooled__mutmut_15'] = x_pooled__mutmut_15 # type: ignore # mutmut generated
mutants_x_pooled__mutmut['x_pooled__mutmut_16'] = x_pooled__mutmut_16 # type: ignore # mutmut generated
mutants_x_pooled__mutmut['x_pooled__mutmut_17'] = x_pooled__mutmut_17 # type: ignore # mutmut generated
mutants_x_pooled__mutmut['x_pooled__mutmut_18'] = x_pooled__mutmut_18 # type: ignore # mutmut generated
mutants_x_pooled__mutmut['x_pooled__mutmut_19'] = x_pooled__mutmut_19 # type: ignore # mutmut generated
mutants_x_pooled__mutmut['x_pooled__mutmut_20'] = x_pooled__mutmut_20 # type: ignore # mutmut generated
mutants_x_pooled__mutmut['x_pooled__mutmut_21'] = x_pooled__mutmut_21 # type: ignore # mutmut generated
mutants_x_pooled__mutmut['x_pooled__mutmut_22'] = x_pooled__mutmut_22 # type: ignore # mutmut generated
mutants_x_pooled__mutmut['x_pooled__mutmut_23'] = x_pooled__mutmut_23 # type: ignore # mutmut generated
mutants_x_pooled__mutmut['x_pooled__mutmut_24'] = x_pooled__mutmut_24 # type: ignore # mutmut generated
mutants_x_pooled__mutmut['x_pooled__mutmut_25'] = x_pooled__mutmut_25 # type: ignore # mutmut generated
mutants_x_pooled__mutmut['x_pooled__mutmut_26'] = x_pooled__mutmut_26 # type: ignore # mutmut generated
mutants_x_pooled__mutmut['x_pooled__mutmut_27'] = x_pooled__mutmut_27 # type: ignore # mutmut generated
mutants_x_pooled__mutmut['x_pooled__mutmut_28'] = x_pooled__mutmut_28 # type: ignore # mutmut generated
mutants_x_pooled__mutmut['x_pooled__mutmut_29'] = x_pooled__mutmut_29 # type: ignore # mutmut generated
mutants_x_pooled__mutmut['x_pooled__mutmut_30'] = x_pooled__mutmut_30 # type: ignore # mutmut generated
mutants_x_pooled__mutmut['x_pooled__mutmut_31'] = x_pooled__mutmut_31 # type: ignore # mutmut generated
mutants_x_pooled__mutmut['x_pooled__mutmut_32'] = x_pooled__mutmut_32 # type: ignore # mutmut generated
mutants_x_pooled__mutmut['x_pooled__mutmut_33'] = x_pooled__mutmut_33 # type: ignore # mutmut generated
mutants_x_pooled__mutmut['x_pooled__mutmut_34'] = x_pooled__mutmut_34 # type: ignore # mutmut generated
mutants_x_pooled__mutmut['x_pooled__mutmut_35'] = x_pooled__mutmut_35 # type: ignore # mutmut generated
mutants_x_pooled__mutmut['x_pooled__mutmut_36'] = x_pooled__mutmut_36 # type: ignore # mutmut generated
mutants_x_pooled__mutmut['x_pooled__mutmut_37'] = x_pooled__mutmut_37 # type: ignore # mutmut generated
mutants_x_pooled__mutmut['x_pooled__mutmut_38'] = x_pooled__mutmut_38 # type: ignore # mutmut generated
mutants_x_pooled__mutmut['x_pooled__mutmut_39'] = x_pooled__mutmut_39 # type: ignore # mutmut generated
mutants_x_pooled__mutmut['x_pooled__mutmut_40'] = x_pooled__mutmut_40 # type: ignore # mutmut generated
mutants_x_pooled__mutmut['x_pooled__mutmut_41'] = x_pooled__mutmut_41 # type: ignore # mutmut generated
mutants_x_pooled__mutmut['x_pooled__mutmut_42'] = x_pooled__mutmut_42 # type: ignore # mutmut generated
mutants_x_pooled__mutmut['x_pooled__mutmut_43'] = x_pooled__mutmut_43 # type: ignore # mutmut generated
mutants_x_pooled__mutmut['x_pooled__mutmut_44'] = x_pooled__mutmut_44 # type: ignore # mutmut generated
mutants_x_pooled__mutmut['x_pooled__mutmut_45'] = x_pooled__mutmut_45 # type: ignore # mutmut generated
mutants_x_pooled__mutmut['x_pooled__mutmut_46'] = x_pooled__mutmut_46 # type: ignore # mutmut generated
mutants_x_pooled__mutmut['x_pooled__mutmut_47'] = x_pooled__mutmut_47 # type: ignore # mutmut generated
mutants_x_pooled__mutmut['x_pooled__mutmut_48'] = x_pooled__mutmut_48 # type: ignore # mutmut generated
mutants_x_pooled__mutmut['x_pooled__mutmut_49'] = x_pooled__mutmut_49 # type: ignore # mutmut generated
mutants_x_pooled__mutmut['x_pooled__mutmut_50'] = x_pooled__mutmut_50 # type: ignore # mutmut generated
mutants_x_pooled__mutmut['x_pooled__mutmut_51'] = x_pooled__mutmut_51 # type: ignore # mutmut generated
mutants_x_pooled__mutmut['x_pooled__mutmut_52'] = x_pooled__mutmut_52 # type: ignore # mutmut generated
mutants_x_pooled__mutmut['x_pooled__mutmut_53'] = x_pooled__mutmut_53 # type: ignore # mutmut generated
mutants_x_pooled__mutmut['x_pooled__mutmut_54'] = x_pooled__mutmut_54 # type: ignore # mutmut generated
mutants_x_pooled__mutmut['x_pooled__mutmut_55'] = x_pooled__mutmut_55 # type: ignore # mutmut generated
mutants_x_pooled__mutmut['x_pooled__mutmut_56'] = x_pooled__mutmut_56 # type: ignore # mutmut generated
mutants_x_pooled__mutmut['x_pooled__mutmut_57'] = x_pooled__mutmut_57 # type: ignore # mutmut generated
mutants_x_pooled__mutmut['x_pooled__mutmut_58'] = x_pooled__mutmut_58 # type: ignore # mutmut generated
mutants_x_pooled__mutmut['x_pooled__mutmut_59'] = x_pooled__mutmut_59 # type: ignore # mutmut generated
mutants_x_pooled__mutmut['x_pooled__mutmut_60'] = x_pooled__mutmut_60 # type: ignore # mutmut generated
mutants_x_pooled__mutmut['x_pooled__mutmut_61'] = x_pooled__mutmut_61 # type: ignore # mutmut generated
mutants_x__mean_rank_correlation__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x__mean_rank_correlation__mutmut)
def _mean_rank_correlation(vectors: list[np.ndarray]) -> float:
    values = []
    for a, b in combinations(vectors, 2):
        if np.ptp(a) == 0 or np.ptp(b) == 0:
            continue
        values.append(float(spearmanr(a, b).statistic))
    return float(np.mean(values)) if values else float("nan")


def x__mean_rank_correlation__mutmut_orig(vectors: list[np.ndarray]) -> float:
    values = []
    for a, b in combinations(vectors, 2):
        if np.ptp(a) == 0 or np.ptp(b) == 0:
            continue
        values.append(float(spearmanr(a, b).statistic))
    return float(np.mean(values)) if values else float("nan")


def x__mean_rank_correlation__mutmut_1(vectors: list[np.ndarray]) -> float:
    values = None
    for a, b in combinations(vectors, 2):
        if np.ptp(a) == 0 or np.ptp(b) == 0:
            continue
        values.append(float(spearmanr(a, b).statistic))
    return float(np.mean(values)) if values else float("nan")


def x__mean_rank_correlation__mutmut_2(vectors: list[np.ndarray]) -> float:
    values = []
    for a, b in combinations(None, 2):
        if np.ptp(a) == 0 or np.ptp(b) == 0:
            continue
        values.append(float(spearmanr(a, b).statistic))
    return float(np.mean(values)) if values else float("nan")


def x__mean_rank_correlation__mutmut_3(vectors: list[np.ndarray]) -> float:
    values = []
    for a, b in combinations(vectors, None):
        if np.ptp(a) == 0 or np.ptp(b) == 0:
            continue
        values.append(float(spearmanr(a, b).statistic))
    return float(np.mean(values)) if values else float("nan")


def x__mean_rank_correlation__mutmut_4(vectors: list[np.ndarray]) -> float:
    values = []
    for a, b in combinations(2):
        if np.ptp(a) == 0 or np.ptp(b) == 0:
            continue
        values.append(float(spearmanr(a, b).statistic))
    return float(np.mean(values)) if values else float("nan")


def x__mean_rank_correlation__mutmut_5(vectors: list[np.ndarray]) -> float:
    values = []
    for a, b in combinations(vectors, ):
        if np.ptp(a) == 0 or np.ptp(b) == 0:
            continue
        values.append(float(spearmanr(a, b).statistic))
    return float(np.mean(values)) if values else float("nan")


def x__mean_rank_correlation__mutmut_6(vectors: list[np.ndarray]) -> float:
    values = []
    for a, b in combinations(vectors, 3):
        if np.ptp(a) == 0 or np.ptp(b) == 0:
            continue
        values.append(float(spearmanr(a, b).statistic))
    return float(np.mean(values)) if values else float("nan")


def x__mean_rank_correlation__mutmut_7(vectors: list[np.ndarray]) -> float:
    values = []
    for a, b in combinations(vectors, 2):
        if np.ptp(a) == 0 and np.ptp(b) == 0:
            continue
        values.append(float(spearmanr(a, b).statistic))
    return float(np.mean(values)) if values else float("nan")


def x__mean_rank_correlation__mutmut_8(vectors: list[np.ndarray]) -> float:
    values = []
    for a, b in combinations(vectors, 2):
        if np.ptp(None) == 0 or np.ptp(b) == 0:
            continue
        values.append(float(spearmanr(a, b).statistic))
    return float(np.mean(values)) if values else float("nan")


def x__mean_rank_correlation__mutmut_9(vectors: list[np.ndarray]) -> float:
    values = []
    for a, b in combinations(vectors, 2):
        if np.ptp(a) != 0 or np.ptp(b) == 0:
            continue
        values.append(float(spearmanr(a, b).statistic))
    return float(np.mean(values)) if values else float("nan")


def x__mean_rank_correlation__mutmut_10(vectors: list[np.ndarray]) -> float:
    values = []
    for a, b in combinations(vectors, 2):
        if np.ptp(a) == 1 or np.ptp(b) == 0:
            continue
        values.append(float(spearmanr(a, b).statistic))
    return float(np.mean(values)) if values else float("nan")


def x__mean_rank_correlation__mutmut_11(vectors: list[np.ndarray]) -> float:
    values = []
    for a, b in combinations(vectors, 2):
        if np.ptp(a) == 0 or np.ptp(None) == 0:
            continue
        values.append(float(spearmanr(a, b).statistic))
    return float(np.mean(values)) if values else float("nan")


def x__mean_rank_correlation__mutmut_12(vectors: list[np.ndarray]) -> float:
    values = []
    for a, b in combinations(vectors, 2):
        if np.ptp(a) == 0 or np.ptp(b) != 0:
            continue
        values.append(float(spearmanr(a, b).statistic))
    return float(np.mean(values)) if values else float("nan")


def x__mean_rank_correlation__mutmut_13(vectors: list[np.ndarray]) -> float:
    values = []
    for a, b in combinations(vectors, 2):
        if np.ptp(a) == 0 or np.ptp(b) == 1:
            continue
        values.append(float(spearmanr(a, b).statistic))
    return float(np.mean(values)) if values else float("nan")


def x__mean_rank_correlation__mutmut_14(vectors: list[np.ndarray]) -> float:
    values = []
    for a, b in combinations(vectors, 2):
        if np.ptp(a) == 0 or np.ptp(b) == 0:
            break
        values.append(float(spearmanr(a, b).statistic))
    return float(np.mean(values)) if values else float("nan")


def x__mean_rank_correlation__mutmut_15(vectors: list[np.ndarray]) -> float:
    values = []
    for a, b in combinations(vectors, 2):
        if np.ptp(a) == 0 or np.ptp(b) == 0:
            continue
        values.append(None)
    return float(np.mean(values)) if values else float("nan")


def x__mean_rank_correlation__mutmut_16(vectors: list[np.ndarray]) -> float:
    values = []
    for a, b in combinations(vectors, 2):
        if np.ptp(a) == 0 or np.ptp(b) == 0:
            continue
        values.append(float(None))
    return float(np.mean(values)) if values else float("nan")


def x__mean_rank_correlation__mutmut_17(vectors: list[np.ndarray]) -> float:
    values = []
    for a, b in combinations(vectors, 2):
        if np.ptp(a) == 0 or np.ptp(b) == 0:
            continue
        values.append(float(spearmanr(None, b).statistic))
    return float(np.mean(values)) if values else float("nan")


def x__mean_rank_correlation__mutmut_18(vectors: list[np.ndarray]) -> float:
    values = []
    for a, b in combinations(vectors, 2):
        if np.ptp(a) == 0 or np.ptp(b) == 0:
            continue
        values.append(float(spearmanr(a, None).statistic))
    return float(np.mean(values)) if values else float("nan")


def x__mean_rank_correlation__mutmut_19(vectors: list[np.ndarray]) -> float:
    values = []
    for a, b in combinations(vectors, 2):
        if np.ptp(a) == 0 or np.ptp(b) == 0:
            continue
        values.append(float(spearmanr(b).statistic))
    return float(np.mean(values)) if values else float("nan")


def x__mean_rank_correlation__mutmut_20(vectors: list[np.ndarray]) -> float:
    values = []
    for a, b in combinations(vectors, 2):
        if np.ptp(a) == 0 or np.ptp(b) == 0:
            continue
        values.append(float(spearmanr(a, ).statistic))
    return float(np.mean(values)) if values else float("nan")


def x__mean_rank_correlation__mutmut_21(vectors: list[np.ndarray]) -> float:
    values = []
    for a, b in combinations(vectors, 2):
        if np.ptp(a) == 0 or np.ptp(b) == 0:
            continue
        values.append(float(spearmanr(a, b).statistic))
    return float(np.mean(values)) if (values) and False else float("nan")


def x__mean_rank_correlation__mutmut_22(vectors: list[np.ndarray]) -> float:
    values = []
    for a, b in combinations(vectors, 2):
        if np.ptp(a) == 0 or np.ptp(b) == 0:
            continue
        values.append(float(spearmanr(a, b).statistic))
    return float(np.mean(values)) if (values) or True else float("nan")


def x__mean_rank_correlation__mutmut_23(vectors: list[np.ndarray]) -> float:
    values = []
    for a, b in combinations(vectors, 2):
        if np.ptp(a) == 0 or np.ptp(b) == 0:
            continue
        values.append(float(spearmanr(a, b).statistic))
    return float(None) if values else float("nan")


def x__mean_rank_correlation__mutmut_24(vectors: list[np.ndarray]) -> float:
    values = []
    for a, b in combinations(vectors, 2):
        if np.ptp(a) == 0 or np.ptp(b) == 0:
            continue
        values.append(float(spearmanr(a, b).statistic))
    return float(np.mean(None)) if values else float("nan")


def x__mean_rank_correlation__mutmut_25(vectors: list[np.ndarray]) -> float:
    values = []
    for a, b in combinations(vectors, 2):
        if np.ptp(a) == 0 or np.ptp(b) == 0:
            continue
        values.append(float(spearmanr(a, b).statistic))
    return float(np.mean(values)) if values else float(None)


def x__mean_rank_correlation__mutmut_26(vectors: list[np.ndarray]) -> float:
    values = []
    for a, b in combinations(vectors, 2):
        if np.ptp(a) == 0 or np.ptp(b) == 0:
            continue
        values.append(float(spearmanr(a, b).statistic))
    return float(np.mean(values)) if values else float("XXnanXX")


def x__mean_rank_correlation__mutmut_27(vectors: list[np.ndarray]) -> float:
    values = []
    for a, b in combinations(vectors, 2):
        if np.ptp(a) == 0 or np.ptp(b) == 0:
            continue
        values.append(float(spearmanr(a, b).statistic))
    return float(np.mean(values)) if values else float("NAN")

mutants_x__mean_rank_correlation__mutmut['_mutmut_orig'] = x__mean_rank_correlation__mutmut_orig # type: ignore # mutmut generated
mutants_x__mean_rank_correlation__mutmut['x__mean_rank_correlation__mutmut_1'] = x__mean_rank_correlation__mutmut_1 # type: ignore # mutmut generated
mutants_x__mean_rank_correlation__mutmut['x__mean_rank_correlation__mutmut_2'] = x__mean_rank_correlation__mutmut_2 # type: ignore # mutmut generated
mutants_x__mean_rank_correlation__mutmut['x__mean_rank_correlation__mutmut_3'] = x__mean_rank_correlation__mutmut_3 # type: ignore # mutmut generated
mutants_x__mean_rank_correlation__mutmut['x__mean_rank_correlation__mutmut_4'] = x__mean_rank_correlation__mutmut_4 # type: ignore # mutmut generated
mutants_x__mean_rank_correlation__mutmut['x__mean_rank_correlation__mutmut_5'] = x__mean_rank_correlation__mutmut_5 # type: ignore # mutmut generated
mutants_x__mean_rank_correlation__mutmut['x__mean_rank_correlation__mutmut_6'] = x__mean_rank_correlation__mutmut_6 # type: ignore # mutmut generated
mutants_x__mean_rank_correlation__mutmut['x__mean_rank_correlation__mutmut_7'] = x__mean_rank_correlation__mutmut_7 # type: ignore # mutmut generated
mutants_x__mean_rank_correlation__mutmut['x__mean_rank_correlation__mutmut_8'] = x__mean_rank_correlation__mutmut_8 # type: ignore # mutmut generated
mutants_x__mean_rank_correlation__mutmut['x__mean_rank_correlation__mutmut_9'] = x__mean_rank_correlation__mutmut_9 # type: ignore # mutmut generated
mutants_x__mean_rank_correlation__mutmut['x__mean_rank_correlation__mutmut_10'] = x__mean_rank_correlation__mutmut_10 # type: ignore # mutmut generated
mutants_x__mean_rank_correlation__mutmut['x__mean_rank_correlation__mutmut_11'] = x__mean_rank_correlation__mutmut_11 # type: ignore # mutmut generated
mutants_x__mean_rank_correlation__mutmut['x__mean_rank_correlation__mutmut_12'] = x__mean_rank_correlation__mutmut_12 # type: ignore # mutmut generated
mutants_x__mean_rank_correlation__mutmut['x__mean_rank_correlation__mutmut_13'] = x__mean_rank_correlation__mutmut_13 # type: ignore # mutmut generated
mutants_x__mean_rank_correlation__mutmut['x__mean_rank_correlation__mutmut_14'] = x__mean_rank_correlation__mutmut_14 # type: ignore # mutmut generated
mutants_x__mean_rank_correlation__mutmut['x__mean_rank_correlation__mutmut_15'] = x__mean_rank_correlation__mutmut_15 # type: ignore # mutmut generated
mutants_x__mean_rank_correlation__mutmut['x__mean_rank_correlation__mutmut_16'] = x__mean_rank_correlation__mutmut_16 # type: ignore # mutmut generated
mutants_x__mean_rank_correlation__mutmut['x__mean_rank_correlation__mutmut_17'] = x__mean_rank_correlation__mutmut_17 # type: ignore # mutmut generated
mutants_x__mean_rank_correlation__mutmut['x__mean_rank_correlation__mutmut_18'] = x__mean_rank_correlation__mutmut_18 # type: ignore # mutmut generated
mutants_x__mean_rank_correlation__mutmut['x__mean_rank_correlation__mutmut_19'] = x__mean_rank_correlation__mutmut_19 # type: ignore # mutmut generated
mutants_x__mean_rank_correlation__mutmut['x__mean_rank_correlation__mutmut_20'] = x__mean_rank_correlation__mutmut_20 # type: ignore # mutmut generated
mutants_x__mean_rank_correlation__mutmut['x__mean_rank_correlation__mutmut_21'] = x__mean_rank_correlation__mutmut_21 # type: ignore # mutmut generated
mutants_x__mean_rank_correlation__mutmut['x__mean_rank_correlation__mutmut_22'] = x__mean_rank_correlation__mutmut_22 # type: ignore # mutmut generated
mutants_x__mean_rank_correlation__mutmut['x__mean_rank_correlation__mutmut_23'] = x__mean_rank_correlation__mutmut_23 # type: ignore # mutmut generated
mutants_x__mean_rank_correlation__mutmut['x__mean_rank_correlation__mutmut_24'] = x__mean_rank_correlation__mutmut_24 # type: ignore # mutmut generated
mutants_x__mean_rank_correlation__mutmut['x__mean_rank_correlation__mutmut_25'] = x__mean_rank_correlation__mutmut_25 # type: ignore # mutmut generated
mutants_x__mean_rank_correlation__mutmut['x__mean_rank_correlation__mutmut_26'] = x__mean_rank_correlation__mutmut_26 # type: ignore # mutmut generated
mutants_x__mean_rank_correlation__mutmut['x__mean_rank_correlation__mutmut_27'] = x__mean_rank_correlation__mutmut_27 # type: ignore # mutmut generated
mutants_x_stability__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_stability__mutmut)
def stability(data: dict[str, pd.DataFrame]) -> dict[str, Any]:
    matrices = list(data.values())
    overall = _mean_rank_correlation([m.to_numpy(dtype=float).ravel() for m in matrices])
    per_type = {
        kind: _mean_rank_correlation([m[kind].to_numpy(dtype=float) for m in matrices])
        for kind in matrices[0].columns
    }
    return {"overall": overall, "per_type": per_type}


def x_stability__mutmut_orig(data: dict[str, pd.DataFrame]) -> dict[str, Any]:
    matrices = list(data.values())
    overall = _mean_rank_correlation([m.to_numpy(dtype=float).ravel() for m in matrices])
    per_type = {
        kind: _mean_rank_correlation([m[kind].to_numpy(dtype=float) for m in matrices])
        for kind in matrices[0].columns
    }
    return {"overall": overall, "per_type": per_type}


def x_stability__mutmut_1(data: dict[str, pd.DataFrame]) -> dict[str, Any]:
    matrices = None
    overall = _mean_rank_correlation([m.to_numpy(dtype=float).ravel() for m in matrices])
    per_type = {
        kind: _mean_rank_correlation([m[kind].to_numpy(dtype=float) for m in matrices])
        for kind in matrices[0].columns
    }
    return {"overall": overall, "per_type": per_type}


def x_stability__mutmut_2(data: dict[str, pd.DataFrame]) -> dict[str, Any]:
    matrices = list(None)
    overall = _mean_rank_correlation([m.to_numpy(dtype=float).ravel() for m in matrices])
    per_type = {
        kind: _mean_rank_correlation([m[kind].to_numpy(dtype=float) for m in matrices])
        for kind in matrices[0].columns
    }
    return {"overall": overall, "per_type": per_type}


def x_stability__mutmut_3(data: dict[str, pd.DataFrame]) -> dict[str, Any]:
    matrices = list(data.values())
    overall = None
    per_type = {
        kind: _mean_rank_correlation([m[kind].to_numpy(dtype=float) for m in matrices])
        for kind in matrices[0].columns
    }
    return {"overall": overall, "per_type": per_type}


def x_stability__mutmut_4(data: dict[str, pd.DataFrame]) -> dict[str, Any]:
    matrices = list(data.values())
    overall = _mean_rank_correlation(None)
    per_type = {
        kind: _mean_rank_correlation([m[kind].to_numpy(dtype=float) for m in matrices])
        for kind in matrices[0].columns
    }
    return {"overall": overall, "per_type": per_type}


def x_stability__mutmut_5(data: dict[str, pd.DataFrame]) -> dict[str, Any]:
    matrices = list(data.values())
    overall = _mean_rank_correlation([m.to_numpy(dtype=None).ravel() for m in matrices])
    per_type = {
        kind: _mean_rank_correlation([m[kind].to_numpy(dtype=float) for m in matrices])
        for kind in matrices[0].columns
    }
    return {"overall": overall, "per_type": per_type}


def x_stability__mutmut_6(data: dict[str, pd.DataFrame]) -> dict[str, Any]:
    matrices = list(data.values())
    overall = _mean_rank_correlation([m.to_numpy(dtype=float).ravel() for m in matrices])
    per_type = None
    return {"overall": overall, "per_type": per_type}


def x_stability__mutmut_7(data: dict[str, pd.DataFrame]) -> dict[str, Any]:
    matrices = list(data.values())
    overall = _mean_rank_correlation([m.to_numpy(dtype=float).ravel() for m in matrices])
    per_type = {
        kind: _mean_rank_correlation(None)
        for kind in matrices[0].columns
    }
    return {"overall": overall, "per_type": per_type}


def x_stability__mutmut_8(data: dict[str, pd.DataFrame]) -> dict[str, Any]:
    matrices = list(data.values())
    overall = _mean_rank_correlation([m.to_numpy(dtype=float).ravel() for m in matrices])
    per_type = {
        kind: _mean_rank_correlation([m[kind].to_numpy(dtype=None) for m in matrices])
        for kind in matrices[0].columns
    }
    return {"overall": overall, "per_type": per_type}


def x_stability__mutmut_9(data: dict[str, pd.DataFrame]) -> dict[str, Any]:
    matrices = list(data.values())
    overall = _mean_rank_correlation([m.to_numpy(dtype=float).ravel() for m in matrices])
    per_type = {
        kind: _mean_rank_correlation([m[kind].to_numpy(dtype=float) for m in matrices])
        for kind in matrices[1].columns
    }
    return {"overall": overall, "per_type": per_type}


def x_stability__mutmut_10(data: dict[str, pd.DataFrame]) -> dict[str, Any]:
    matrices = list(data.values())
    overall = _mean_rank_correlation([m.to_numpy(dtype=float).ravel() for m in matrices])
    per_type = {
        kind: _mean_rank_correlation([m[kind].to_numpy(dtype=float) for m in matrices])
        for kind in matrices[0].columns
    }
    return {"XXoverallXX": overall, "per_type": per_type}


def x_stability__mutmut_11(data: dict[str, pd.DataFrame]) -> dict[str, Any]:
    matrices = list(data.values())
    overall = _mean_rank_correlation([m.to_numpy(dtype=float).ravel() for m in matrices])
    per_type = {
        kind: _mean_rank_correlation([m[kind].to_numpy(dtype=float) for m in matrices])
        for kind in matrices[0].columns
    }
    return {"OVERALL": overall, "per_type": per_type}


def x_stability__mutmut_12(data: dict[str, pd.DataFrame]) -> dict[str, Any]:
    matrices = list(data.values())
    overall = _mean_rank_correlation([m.to_numpy(dtype=float).ravel() for m in matrices])
    per_type = {
        kind: _mean_rank_correlation([m[kind].to_numpy(dtype=float) for m in matrices])
        for kind in matrices[0].columns
    }
    return {"overall": overall, "XXper_typeXX": per_type}


def x_stability__mutmut_13(data: dict[str, pd.DataFrame]) -> dict[str, Any]:
    matrices = list(data.values())
    overall = _mean_rank_correlation([m.to_numpy(dtype=float).ravel() for m in matrices])
    per_type = {
        kind: _mean_rank_correlation([m[kind].to_numpy(dtype=float) for m in matrices])
        for kind in matrices[0].columns
    }
    return {"overall": overall, "PER_TYPE": per_type}

mutants_x_stability__mutmut['_mutmut_orig'] = x_stability__mutmut_orig # type: ignore # mutmut generated
mutants_x_stability__mutmut['x_stability__mutmut_1'] = x_stability__mutmut_1 # type: ignore # mutmut generated
mutants_x_stability__mutmut['x_stability__mutmut_2'] = x_stability__mutmut_2 # type: ignore # mutmut generated
mutants_x_stability__mutmut['x_stability__mutmut_3'] = x_stability__mutmut_3 # type: ignore # mutmut generated
mutants_x_stability__mutmut['x_stability__mutmut_4'] = x_stability__mutmut_4 # type: ignore # mutmut generated
mutants_x_stability__mutmut['x_stability__mutmut_5'] = x_stability__mutmut_5 # type: ignore # mutmut generated
mutants_x_stability__mutmut['x_stability__mutmut_6'] = x_stability__mutmut_6 # type: ignore # mutmut generated
mutants_x_stability__mutmut['x_stability__mutmut_7'] = x_stability__mutmut_7 # type: ignore # mutmut generated
mutants_x_stability__mutmut['x_stability__mutmut_8'] = x_stability__mutmut_8 # type: ignore # mutmut generated
mutants_x_stability__mutmut['x_stability__mutmut_9'] = x_stability__mutmut_9 # type: ignore # mutmut generated
mutants_x_stability__mutmut['x_stability__mutmut_10'] = x_stability__mutmut_10 # type: ignore # mutmut generated
mutants_x_stability__mutmut['x_stability__mutmut_11'] = x_stability__mutmut_11 # type: ignore # mutmut generated
mutants_x_stability__mutmut['x_stability__mutmut_12'] = x_stability__mutmut_12 # type: ignore # mutmut generated
mutants_x_stability__mutmut['x_stability__mutmut_13'] = x_stability__mutmut_13 # type: ignore # mutmut generated
mutants_x__cell__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x__cell__mutmut)
def _cell(data: dict[str, pd.DataFrame], method: str, kind: str) -> np.ndarray:
    return np.array([m.loc[method, kind] for m in data.values()], dtype=float)


def x__cell__mutmut_orig(data: dict[str, pd.DataFrame], method: str, kind: str) -> np.ndarray:
    return np.array([m.loc[method, kind] for m in data.values()], dtype=float)


def x__cell__mutmut_1(data: dict[str, pd.DataFrame], method: str, kind: str) -> np.ndarray:
    return np.array(None, dtype=float)


def x__cell__mutmut_2(data: dict[str, pd.DataFrame], method: str, kind: str) -> np.ndarray:
    return np.array([m.loc[method, kind] for m in data.values()], dtype=None)


def x__cell__mutmut_3(data: dict[str, pd.DataFrame], method: str, kind: str) -> np.ndarray:
    return np.array(dtype=float)


def x__cell__mutmut_4(data: dict[str, pd.DataFrame], method: str, kind: str) -> np.ndarray:
    return np.array([m.loc[method, kind] for m in data.values()], )

mutants_x__cell__mutmut['_mutmut_orig'] = x__cell__mutmut_orig # type: ignore # mutmut generated
mutants_x__cell__mutmut['x__cell__mutmut_1'] = x__cell__mutmut_1 # type: ignore # mutmut generated
mutants_x__cell__mutmut['x__cell__mutmut_2'] = x__cell__mutmut_2 # type: ignore # mutmut generated
mutants_x__cell__mutmut['x__cell__mutmut_3'] = x__cell__mutmut_3 # type: ignore # mutmut generated
mutants_x__cell__mutmut['x__cell__mutmut_4'] = x__cell__mutmut_4 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_hypotheses__mutmut)
def hypotheses(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_orig(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_1(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = None  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_2(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: None  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_3(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(None)  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_4(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(None))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_5(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(None, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_6(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, None, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_7(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, None)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_8(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_9(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_10(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, )))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_11(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = None
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_12(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = None
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_13(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(None)
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_14(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(None))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_15(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(None, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_16(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, None, "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_17(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", None)))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_18(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell("great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_19(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_20(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", )))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_21(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "XXgreat_expectationsXX", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_22(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "GREAT_EXPECTATIONS", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_23(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "XXmissing_valueXX")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_24(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "MISSING_VALUE")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_25(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = None
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_26(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(None)
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_27(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(None))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_28(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(None, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_29(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, None, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_30(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, None)))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_31(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_32(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_33(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, )))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_34(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "XXduplicateXX")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_35(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "DUPLICATE")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_36(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(None).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_37(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(None)).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_38(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m == "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_39(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "XXtransform_dedupXX"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_40(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "TRANSFORM_DEDUP"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_41(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = None
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_42(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(None, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_43(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, None) for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_44(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med("univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_45(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, ) for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_46(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "XXunivariate_outlierXX") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_47(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "UNIVARIATE_OUTLIER") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_48(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("XXzscoreXX", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_49(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("ZSCORE", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_50(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "XXiqrXX", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_51(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "IQR", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_52(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = None
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_53(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["XXH1XX"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_54(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["h1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_55(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "XXholdsXX": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_56(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "HOLDS": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_57(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 or min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_58(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 or max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_59(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min > 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_60(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 1.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_61(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(None) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_62(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) <= 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_63(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 1.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_64(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(None) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_65(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) >= 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_66(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 1.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_67(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "XXge_missing_minXX": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_68(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "GE_MISSING_MIN": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_69(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "XXother_duplicate_maxXX": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_70(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "OTHER_DUPLICATE_MAX": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_71(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(None),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_72(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "XXunivariate_medianXX": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_73(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "UNIVARIATE_MEDIAN": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_74(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = None
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_75(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(None, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_76(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, None) for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_77(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med("multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_78(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, ) for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_79(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "XXmultivariate_outlierXX") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_80(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "MULTIVARIATE_OUTLIER") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_81(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("XXisolation_forestXX", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_82(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("ISOLATION_FOREST", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_83(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "XXocsvmXX", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_84(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "OCSVM", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_85(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "XXzscoreXX", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_86(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "ZSCORE", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_87(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "XXiqrXX")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_88(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "IQR")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_89(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = None
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_90(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) + max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_91(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(None, multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_92(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], None) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_93(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_94(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], ) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_95(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["XXisolation_forestXX"], multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_96(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["ISOLATION_FOREST"], multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_97(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["XXocsvmXX"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_98(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["OCSVM"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_99(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(None, multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_100(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], None)
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_101(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_102(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], )
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_103(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["XXzscoreXX"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_104(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["ZSCORE"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_105(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], multi["XXiqrXX"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_106(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], multi["IQR"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_107(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = None
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_108(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["XXH2XX"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_109(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["h2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_110(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "XXholdsXX": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_111(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "HOLDS": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_112(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 or max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_113(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap > 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_114(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 1.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_115(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(None, multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_116(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], None) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_117(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_118(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], ) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_119(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["XXzscoreXX"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_120(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["ZSCORE"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_121(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["XXiqrXX"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_122(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["IQR"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_123(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) <= 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_124(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 1.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_125(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "XXmedianXX": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_126(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "MEDIAN": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_127(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "XXgapXX": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_128(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "GAP": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_129(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = None
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_130(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(None).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_131(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(None)).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_132(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = None
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_133(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(None, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_134(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, None) for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_135(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med("temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_136(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, ) for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_137(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "XXtemporal_driftXX") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_138(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "TEMPORAL_DRIFT") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_139(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = None
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_140(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["XXH3XX"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_141(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["h3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_142(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"XXholdsXX": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_143(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"HOLDS": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_144(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(None) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_145(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) <= 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_146(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 1.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_147(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "XXmedianXX": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_148(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "MEDIAN": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_149(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = None
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_150(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(None)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_151(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = None
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_152(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(None, s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_153(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], None)
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_154(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_155(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], )
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_156(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["XXper_typeXX"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_157(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["PER_TYPE"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_158(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["XXmultivariate_outlierXX"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_159(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["MULTIVARIATE_OUTLIER"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_160(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["XXper_typeXX"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_161(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["PER_TYPE"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_162(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["XXtemporal_driftXX"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_163(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["TEMPORAL_DRIFT"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_164(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = None
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_165(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(None)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_166(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["XXper_typeXX"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_167(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["PER_TYPE"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_168(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = None
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_169(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["XXH4XX"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_170(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["h4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_171(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"XXholdsXX": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_172(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"HOLDS": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_173(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(None), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_174(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 or hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_175(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["XXoverallXX"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_176(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["OVERALL"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_177(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] > 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_178(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 1.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_179(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard <= easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_180(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "XXstabilityXX": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_181(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "STABILITY": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_182(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = None
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_183(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n not in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_184(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = None
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_185(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        None,
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_186(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        None,
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_187(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_188(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_189(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["XXisolation_forestXX", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_190(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["ISOLATION_FOREST", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_191(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "XXunivariate_outlierXX"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_192(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "UNIVARIATE_OUTLIER"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_193(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = None
    return out


def x_hypotheses__mutmut_194(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["XXH5XX"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_195(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["h5"] = {"holds": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_196(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"XXholdsXX": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_197(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"HOLDS": bool(rho < 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_198(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(None), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_199(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho <= 0), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_200(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 1), "rho": float(rho)}
    return out


def x_hypotheses__mutmut_201(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "XXrhoXX": float(rho)}
    return out


def x_hypotheses__mutmut_202(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "RHO": float(rho)}
    return out


def x_hypotheses__mutmut_203(data: dict[str, pd.DataFrame], n_columns: dict[str, int]) -> dict[str, Any]:
    med = lambda method, kind: float(np.nanmedian(_cell(data, method, kind)))  # noqa: E731
    out: dict[str, Any] = {}
    ge_min = float(np.nanmin(_cell(data, "great_expectations", "missing_value")))
    others_dup = {
        m: float(np.nanmax(_cell(data, m, "duplicate")))
        for m in next(iter(data.values())).index
        if m != "transform_dedup"
    }
    uni = {m: med(m, "univariate_outlier") for m in ("zscore", "iqr", *ML)}
    out["H1"] = {
        "holds": ge_min >= 0.9 and max(others_dup.values()) < 0.9 and min(uni.values()) > 0.7,
        "ge_missing_min": ge_min,
        "other_duplicate_max": max(others_dup.values()),
        "univariate_median": uni,
    }
    multi = {
        m: med(m, "multivariate_outlier") for m in ("isolation_forest", "ocsvm", "zscore", "iqr")
    }
    gap = min(multi["isolation_forest"], multi["ocsvm"]) - max(multi["zscore"], multi["iqr"])
    out["H2"] = {
        "holds": gap >= 0.4 and max(multi["zscore"], multi["iqr"]) < 0.2,
        "median": multi,
        "gap": gap,
    }
    methods = next(iter(data.values())).index
    drift = {m: med(m, "temporal_drift") for m in methods}
    out["H3"] = {"holds": max(drift.values()) < 0.5, "median": drift}
    s = stability(data)
    hard = max(s["per_type"]["multivariate_outlier"], s["per_type"]["temporal_drift"])
    easy = min(s["per_type"][k] for k in STRUCTURAL)
    out["H4"] = {"holds": bool(s["overall"] >= 0.7 and hard < easy), "stability": s}
    names = [n for n in data if n in n_columns]
    rho = spearmanr(
        [n_columns[n] for n in names],
        [data[n].loc["isolation_forest", "univariate_outlier"] for n in names],
    ).statistic
    out["H5"] = {"holds": bool(rho < 0), "rho": float(None)}
    return out

mutants_x_hypotheses__mutmut['_mutmut_orig'] = x_hypotheses__mutmut_orig # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_1'] = x_hypotheses__mutmut_1 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_2'] = x_hypotheses__mutmut_2 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_3'] = x_hypotheses__mutmut_3 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_4'] = x_hypotheses__mutmut_4 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_5'] = x_hypotheses__mutmut_5 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_6'] = x_hypotheses__mutmut_6 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_7'] = x_hypotheses__mutmut_7 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_8'] = x_hypotheses__mutmut_8 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_9'] = x_hypotheses__mutmut_9 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_10'] = x_hypotheses__mutmut_10 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_11'] = x_hypotheses__mutmut_11 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_12'] = x_hypotheses__mutmut_12 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_13'] = x_hypotheses__mutmut_13 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_14'] = x_hypotheses__mutmut_14 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_15'] = x_hypotheses__mutmut_15 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_16'] = x_hypotheses__mutmut_16 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_17'] = x_hypotheses__mutmut_17 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_18'] = x_hypotheses__mutmut_18 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_19'] = x_hypotheses__mutmut_19 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_20'] = x_hypotheses__mutmut_20 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_21'] = x_hypotheses__mutmut_21 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_22'] = x_hypotheses__mutmut_22 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_23'] = x_hypotheses__mutmut_23 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_24'] = x_hypotheses__mutmut_24 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_25'] = x_hypotheses__mutmut_25 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_26'] = x_hypotheses__mutmut_26 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_27'] = x_hypotheses__mutmut_27 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_28'] = x_hypotheses__mutmut_28 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_29'] = x_hypotheses__mutmut_29 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_30'] = x_hypotheses__mutmut_30 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_31'] = x_hypotheses__mutmut_31 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_32'] = x_hypotheses__mutmut_32 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_33'] = x_hypotheses__mutmut_33 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_34'] = x_hypotheses__mutmut_34 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_35'] = x_hypotheses__mutmut_35 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_36'] = x_hypotheses__mutmut_36 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_37'] = x_hypotheses__mutmut_37 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_38'] = x_hypotheses__mutmut_38 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_39'] = x_hypotheses__mutmut_39 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_40'] = x_hypotheses__mutmut_40 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_41'] = x_hypotheses__mutmut_41 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_42'] = x_hypotheses__mutmut_42 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_43'] = x_hypotheses__mutmut_43 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_44'] = x_hypotheses__mutmut_44 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_45'] = x_hypotheses__mutmut_45 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_46'] = x_hypotheses__mutmut_46 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_47'] = x_hypotheses__mutmut_47 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_48'] = x_hypotheses__mutmut_48 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_49'] = x_hypotheses__mutmut_49 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_50'] = x_hypotheses__mutmut_50 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_51'] = x_hypotheses__mutmut_51 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_52'] = x_hypotheses__mutmut_52 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_53'] = x_hypotheses__mutmut_53 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_54'] = x_hypotheses__mutmut_54 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_55'] = x_hypotheses__mutmut_55 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_56'] = x_hypotheses__mutmut_56 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_57'] = x_hypotheses__mutmut_57 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_58'] = x_hypotheses__mutmut_58 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_59'] = x_hypotheses__mutmut_59 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_60'] = x_hypotheses__mutmut_60 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_61'] = x_hypotheses__mutmut_61 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_62'] = x_hypotheses__mutmut_62 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_63'] = x_hypotheses__mutmut_63 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_64'] = x_hypotheses__mutmut_64 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_65'] = x_hypotheses__mutmut_65 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_66'] = x_hypotheses__mutmut_66 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_67'] = x_hypotheses__mutmut_67 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_68'] = x_hypotheses__mutmut_68 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_69'] = x_hypotheses__mutmut_69 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_70'] = x_hypotheses__mutmut_70 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_71'] = x_hypotheses__mutmut_71 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_72'] = x_hypotheses__mutmut_72 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_73'] = x_hypotheses__mutmut_73 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_74'] = x_hypotheses__mutmut_74 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_75'] = x_hypotheses__mutmut_75 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_76'] = x_hypotheses__mutmut_76 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_77'] = x_hypotheses__mutmut_77 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_78'] = x_hypotheses__mutmut_78 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_79'] = x_hypotheses__mutmut_79 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_80'] = x_hypotheses__mutmut_80 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_81'] = x_hypotheses__mutmut_81 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_82'] = x_hypotheses__mutmut_82 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_83'] = x_hypotheses__mutmut_83 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_84'] = x_hypotheses__mutmut_84 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_85'] = x_hypotheses__mutmut_85 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_86'] = x_hypotheses__mutmut_86 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_87'] = x_hypotheses__mutmut_87 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_88'] = x_hypotheses__mutmut_88 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_89'] = x_hypotheses__mutmut_89 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_90'] = x_hypotheses__mutmut_90 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_91'] = x_hypotheses__mutmut_91 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_92'] = x_hypotheses__mutmut_92 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_93'] = x_hypotheses__mutmut_93 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_94'] = x_hypotheses__mutmut_94 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_95'] = x_hypotheses__mutmut_95 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_96'] = x_hypotheses__mutmut_96 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_97'] = x_hypotheses__mutmut_97 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_98'] = x_hypotheses__mutmut_98 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_99'] = x_hypotheses__mutmut_99 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_100'] = x_hypotheses__mutmut_100 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_101'] = x_hypotheses__mutmut_101 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_102'] = x_hypotheses__mutmut_102 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_103'] = x_hypotheses__mutmut_103 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_104'] = x_hypotheses__mutmut_104 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_105'] = x_hypotheses__mutmut_105 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_106'] = x_hypotheses__mutmut_106 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_107'] = x_hypotheses__mutmut_107 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_108'] = x_hypotheses__mutmut_108 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_109'] = x_hypotheses__mutmut_109 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_110'] = x_hypotheses__mutmut_110 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_111'] = x_hypotheses__mutmut_111 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_112'] = x_hypotheses__mutmut_112 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_113'] = x_hypotheses__mutmut_113 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_114'] = x_hypotheses__mutmut_114 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_115'] = x_hypotheses__mutmut_115 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_116'] = x_hypotheses__mutmut_116 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_117'] = x_hypotheses__mutmut_117 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_118'] = x_hypotheses__mutmut_118 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_119'] = x_hypotheses__mutmut_119 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_120'] = x_hypotheses__mutmut_120 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_121'] = x_hypotheses__mutmut_121 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_122'] = x_hypotheses__mutmut_122 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_123'] = x_hypotheses__mutmut_123 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_124'] = x_hypotheses__mutmut_124 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_125'] = x_hypotheses__mutmut_125 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_126'] = x_hypotheses__mutmut_126 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_127'] = x_hypotheses__mutmut_127 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_128'] = x_hypotheses__mutmut_128 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_129'] = x_hypotheses__mutmut_129 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_130'] = x_hypotheses__mutmut_130 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_131'] = x_hypotheses__mutmut_131 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_132'] = x_hypotheses__mutmut_132 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_133'] = x_hypotheses__mutmut_133 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_134'] = x_hypotheses__mutmut_134 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_135'] = x_hypotheses__mutmut_135 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_136'] = x_hypotheses__mutmut_136 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_137'] = x_hypotheses__mutmut_137 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_138'] = x_hypotheses__mutmut_138 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_139'] = x_hypotheses__mutmut_139 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_140'] = x_hypotheses__mutmut_140 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_141'] = x_hypotheses__mutmut_141 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_142'] = x_hypotheses__mutmut_142 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_143'] = x_hypotheses__mutmut_143 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_144'] = x_hypotheses__mutmut_144 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_145'] = x_hypotheses__mutmut_145 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_146'] = x_hypotheses__mutmut_146 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_147'] = x_hypotheses__mutmut_147 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_148'] = x_hypotheses__mutmut_148 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_149'] = x_hypotheses__mutmut_149 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_150'] = x_hypotheses__mutmut_150 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_151'] = x_hypotheses__mutmut_151 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_152'] = x_hypotheses__mutmut_152 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_153'] = x_hypotheses__mutmut_153 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_154'] = x_hypotheses__mutmut_154 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_155'] = x_hypotheses__mutmut_155 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_156'] = x_hypotheses__mutmut_156 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_157'] = x_hypotheses__mutmut_157 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_158'] = x_hypotheses__mutmut_158 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_159'] = x_hypotheses__mutmut_159 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_160'] = x_hypotheses__mutmut_160 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_161'] = x_hypotheses__mutmut_161 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_162'] = x_hypotheses__mutmut_162 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_163'] = x_hypotheses__mutmut_163 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_164'] = x_hypotheses__mutmut_164 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_165'] = x_hypotheses__mutmut_165 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_166'] = x_hypotheses__mutmut_166 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_167'] = x_hypotheses__mutmut_167 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_168'] = x_hypotheses__mutmut_168 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_169'] = x_hypotheses__mutmut_169 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_170'] = x_hypotheses__mutmut_170 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_171'] = x_hypotheses__mutmut_171 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_172'] = x_hypotheses__mutmut_172 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_173'] = x_hypotheses__mutmut_173 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_174'] = x_hypotheses__mutmut_174 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_175'] = x_hypotheses__mutmut_175 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_176'] = x_hypotheses__mutmut_176 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_177'] = x_hypotheses__mutmut_177 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_178'] = x_hypotheses__mutmut_178 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_179'] = x_hypotheses__mutmut_179 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_180'] = x_hypotheses__mutmut_180 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_181'] = x_hypotheses__mutmut_181 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_182'] = x_hypotheses__mutmut_182 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_183'] = x_hypotheses__mutmut_183 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_184'] = x_hypotheses__mutmut_184 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_185'] = x_hypotheses__mutmut_185 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_186'] = x_hypotheses__mutmut_186 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_187'] = x_hypotheses__mutmut_187 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_188'] = x_hypotheses__mutmut_188 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_189'] = x_hypotheses__mutmut_189 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_190'] = x_hypotheses__mutmut_190 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_191'] = x_hypotheses__mutmut_191 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_192'] = x_hypotheses__mutmut_192 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_193'] = x_hypotheses__mutmut_193 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_194'] = x_hypotheses__mutmut_194 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_195'] = x_hypotheses__mutmut_195 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_196'] = x_hypotheses__mutmut_196 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_197'] = x_hypotheses__mutmut_197 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_198'] = x_hypotheses__mutmut_198 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_199'] = x_hypotheses__mutmut_199 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_200'] = x_hypotheses__mutmut_200 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_201'] = x_hypotheses__mutmut_201 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_202'] = x_hypotheses__mutmut_202 # type: ignore # mutmut generated
mutants_x_hypotheses__mutmut['x_hypotheses__mutmut_203'] = x_hypotheses__mutmut_203 # type: ignore # mutmut generated
mutants_x__load__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x__load__mutmut)
def _load(runs):
    import json
    from pathlib import Path

    folders = [runs] if isinstance(runs, Path) else list(runs)
    data, columns, fpr = {}, {}, {}
    for path in sorted(p for folder in folders for p in folder.glob("*.json")):
        run = json.loads(path.read_text())
        split = run["recall_mean"]
        data[run["name"]] = pd.DataFrame(
            split["data"], index=split["index"], columns=split["columns"]
        )
        columns[run["name"]] = len(run["carrier"]["columns"])
        for method, value in run.get("fpr_mean", {}).items():
            fpr.setdefault(method, []).append(value)
    return data, columns, fpr


def x__load__mutmut_orig(runs):
    import json
    from pathlib import Path

    folders = [runs] if isinstance(runs, Path) else list(runs)
    data, columns, fpr = {}, {}, {}
    for path in sorted(p for folder in folders for p in folder.glob("*.json")):
        run = json.loads(path.read_text())
        split = run["recall_mean"]
        data[run["name"]] = pd.DataFrame(
            split["data"], index=split["index"], columns=split["columns"]
        )
        columns[run["name"]] = len(run["carrier"]["columns"])
        for method, value in run.get("fpr_mean", {}).items():
            fpr.setdefault(method, []).append(value)
    return data, columns, fpr


def x__load__mutmut_1(runs):
    import json
    from pathlib import Path

    folders = None
    data, columns, fpr = {}, {}, {}
    for path in sorted(p for folder in folders for p in folder.glob("*.json")):
        run = json.loads(path.read_text())
        split = run["recall_mean"]
        data[run["name"]] = pd.DataFrame(
            split["data"], index=split["index"], columns=split["columns"]
        )
        columns[run["name"]] = len(run["carrier"]["columns"])
        for method, value in run.get("fpr_mean", {}).items():
            fpr.setdefault(method, []).append(value)
    return data, columns, fpr


def x__load__mutmut_2(runs):
    import json
    from pathlib import Path

    folders = [runs] if (isinstance(runs, Path)) and False else list(runs)
    data, columns, fpr = {}, {}, {}
    for path in sorted(p for folder in folders for p in folder.glob("*.json")):
        run = json.loads(path.read_text())
        split = run["recall_mean"]
        data[run["name"]] = pd.DataFrame(
            split["data"], index=split["index"], columns=split["columns"]
        )
        columns[run["name"]] = len(run["carrier"]["columns"])
        for method, value in run.get("fpr_mean", {}).items():
            fpr.setdefault(method, []).append(value)
    return data, columns, fpr


def x__load__mutmut_3(runs):
    import json
    from pathlib import Path

    folders = [runs] if (isinstance(runs, Path)) or True else list(runs)
    data, columns, fpr = {}, {}, {}
    for path in sorted(p for folder in folders for p in folder.glob("*.json")):
        run = json.loads(path.read_text())
        split = run["recall_mean"]
        data[run["name"]] = pd.DataFrame(
            split["data"], index=split["index"], columns=split["columns"]
        )
        columns[run["name"]] = len(run["carrier"]["columns"])
        for method, value in run.get("fpr_mean", {}).items():
            fpr.setdefault(method, []).append(value)
    return data, columns, fpr


def x__load__mutmut_4(runs):
    import json
    from pathlib import Path

    folders = [runs] if isinstance(runs, Path) else list(None)
    data, columns, fpr = {}, {}, {}
    for path in sorted(p for folder in folders for p in folder.glob("*.json")):
        run = json.loads(path.read_text())
        split = run["recall_mean"]
        data[run["name"]] = pd.DataFrame(
            split["data"], index=split["index"], columns=split["columns"]
        )
        columns[run["name"]] = len(run["carrier"]["columns"])
        for method, value in run.get("fpr_mean", {}).items():
            fpr.setdefault(method, []).append(value)
    return data, columns, fpr


def x__load__mutmut_5(runs):
    import json
    from pathlib import Path

    folders = [runs] if isinstance(runs, Path) else list(runs)
    data, columns, fpr = None
    for path in sorted(p for folder in folders for p in folder.glob("*.json")):
        run = json.loads(path.read_text())
        split = run["recall_mean"]
        data[run["name"]] = pd.DataFrame(
            split["data"], index=split["index"], columns=split["columns"]
        )
        columns[run["name"]] = len(run["carrier"]["columns"])
        for method, value in run.get("fpr_mean", {}).items():
            fpr.setdefault(method, []).append(value)
    return data, columns, fpr


def x__load__mutmut_6(runs):
    import json
    from pathlib import Path

    folders = [runs] if isinstance(runs, Path) else list(runs)
    data, columns, fpr = {}, {}, {}
    for path in sorted(None):
        run = json.loads(path.read_text())
        split = run["recall_mean"]
        data[run["name"]] = pd.DataFrame(
            split["data"], index=split["index"], columns=split["columns"]
        )
        columns[run["name"]] = len(run["carrier"]["columns"])
        for method, value in run.get("fpr_mean", {}).items():
            fpr.setdefault(method, []).append(value)
    return data, columns, fpr


def x__load__mutmut_7(runs):
    import json
    from pathlib import Path

    folders = [runs] if isinstance(runs, Path) else list(runs)
    data, columns, fpr = {}, {}, {}
    for path in sorted(p for folder in folders for p in folder.glob(None)):
        run = json.loads(path.read_text())
        split = run["recall_mean"]
        data[run["name"]] = pd.DataFrame(
            split["data"], index=split["index"], columns=split["columns"]
        )
        columns[run["name"]] = len(run["carrier"]["columns"])
        for method, value in run.get("fpr_mean", {}).items():
            fpr.setdefault(method, []).append(value)
    return data, columns, fpr


def x__load__mutmut_8(runs):
    import json
    from pathlib import Path

    folders = [runs] if isinstance(runs, Path) else list(runs)
    data, columns, fpr = {}, {}, {}
    for path in sorted(p for folder in folders for p in folder.glob("XX*.jsonXX")):
        run = json.loads(path.read_text())
        split = run["recall_mean"]
        data[run["name"]] = pd.DataFrame(
            split["data"], index=split["index"], columns=split["columns"]
        )
        columns[run["name"]] = len(run["carrier"]["columns"])
        for method, value in run.get("fpr_mean", {}).items():
            fpr.setdefault(method, []).append(value)
    return data, columns, fpr


def x__load__mutmut_9(runs):
    import json
    from pathlib import Path

    folders = [runs] if isinstance(runs, Path) else list(runs)
    data, columns, fpr = {}, {}, {}
    for path in sorted(p for folder in folders for p in folder.glob("*.JSON")):
        run = json.loads(path.read_text())
        split = run["recall_mean"]
        data[run["name"]] = pd.DataFrame(
            split["data"], index=split["index"], columns=split["columns"]
        )
        columns[run["name"]] = len(run["carrier"]["columns"])
        for method, value in run.get("fpr_mean", {}).items():
            fpr.setdefault(method, []).append(value)
    return data, columns, fpr


def x__load__mutmut_10(runs):
    import json
    from pathlib import Path

    folders = [runs] if isinstance(runs, Path) else list(runs)
    data, columns, fpr = {}, {}, {}
    for path in sorted(p for folder in folders for p in folder.glob("*.json")):
        run = None
        split = run["recall_mean"]
        data[run["name"]] = pd.DataFrame(
            split["data"], index=split["index"], columns=split["columns"]
        )
        columns[run["name"]] = len(run["carrier"]["columns"])
        for method, value in run.get("fpr_mean", {}).items():
            fpr.setdefault(method, []).append(value)
    return data, columns, fpr


def x__load__mutmut_11(runs):
    import json
    from pathlib import Path

    folders = [runs] if isinstance(runs, Path) else list(runs)
    data, columns, fpr = {}, {}, {}
    for path in sorted(p for folder in folders for p in folder.glob("*.json")):
        run = json.loads(None)
        split = run["recall_mean"]
        data[run["name"]] = pd.DataFrame(
            split["data"], index=split["index"], columns=split["columns"]
        )
        columns[run["name"]] = len(run["carrier"]["columns"])
        for method, value in run.get("fpr_mean", {}).items():
            fpr.setdefault(method, []).append(value)
    return data, columns, fpr


def x__load__mutmut_12(runs):
    import json
    from pathlib import Path

    folders = [runs] if isinstance(runs, Path) else list(runs)
    data, columns, fpr = {}, {}, {}
    for path in sorted(p for folder in folders for p in folder.glob("*.json")):
        run = json.loads(path.read_text())
        split = None
        data[run["name"]] = pd.DataFrame(
            split["data"], index=split["index"], columns=split["columns"]
        )
        columns[run["name"]] = len(run["carrier"]["columns"])
        for method, value in run.get("fpr_mean", {}).items():
            fpr.setdefault(method, []).append(value)
    return data, columns, fpr


def x__load__mutmut_13(runs):
    import json
    from pathlib import Path

    folders = [runs] if isinstance(runs, Path) else list(runs)
    data, columns, fpr = {}, {}, {}
    for path in sorted(p for folder in folders for p in folder.glob("*.json")):
        run = json.loads(path.read_text())
        split = run["XXrecall_meanXX"]
        data[run["name"]] = pd.DataFrame(
            split["data"], index=split["index"], columns=split["columns"]
        )
        columns[run["name"]] = len(run["carrier"]["columns"])
        for method, value in run.get("fpr_mean", {}).items():
            fpr.setdefault(method, []).append(value)
    return data, columns, fpr


def x__load__mutmut_14(runs):
    import json
    from pathlib import Path

    folders = [runs] if isinstance(runs, Path) else list(runs)
    data, columns, fpr = {}, {}, {}
    for path in sorted(p for folder in folders for p in folder.glob("*.json")):
        run = json.loads(path.read_text())
        split = run["RECALL_MEAN"]
        data[run["name"]] = pd.DataFrame(
            split["data"], index=split["index"], columns=split["columns"]
        )
        columns[run["name"]] = len(run["carrier"]["columns"])
        for method, value in run.get("fpr_mean", {}).items():
            fpr.setdefault(method, []).append(value)
    return data, columns, fpr


def x__load__mutmut_15(runs):
    import json
    from pathlib import Path

    folders = [runs] if isinstance(runs, Path) else list(runs)
    data, columns, fpr = {}, {}, {}
    for path in sorted(p for folder in folders for p in folder.glob("*.json")):
        run = json.loads(path.read_text())
        split = run["recall_mean"]
        data[run["name"]] = None
        columns[run["name"]] = len(run["carrier"]["columns"])
        for method, value in run.get("fpr_mean", {}).items():
            fpr.setdefault(method, []).append(value)
    return data, columns, fpr


def x__load__mutmut_16(runs):
    import json
    from pathlib import Path

    folders = [runs] if isinstance(runs, Path) else list(runs)
    data, columns, fpr = {}, {}, {}
    for path in sorted(p for folder in folders for p in folder.glob("*.json")):
        run = json.loads(path.read_text())
        split = run["recall_mean"]
        data[run["XXnameXX"]] = pd.DataFrame(
            split["data"], index=split["index"], columns=split["columns"]
        )
        columns[run["name"]] = len(run["carrier"]["columns"])
        for method, value in run.get("fpr_mean", {}).items():
            fpr.setdefault(method, []).append(value)
    return data, columns, fpr


def x__load__mutmut_17(runs):
    import json
    from pathlib import Path

    folders = [runs] if isinstance(runs, Path) else list(runs)
    data, columns, fpr = {}, {}, {}
    for path in sorted(p for folder in folders for p in folder.glob("*.json")):
        run = json.loads(path.read_text())
        split = run["recall_mean"]
        data[run["NAME"]] = pd.DataFrame(
            split["data"], index=split["index"], columns=split["columns"]
        )
        columns[run["name"]] = len(run["carrier"]["columns"])
        for method, value in run.get("fpr_mean", {}).items():
            fpr.setdefault(method, []).append(value)
    return data, columns, fpr


def x__load__mutmut_18(runs):
    import json
    from pathlib import Path

    folders = [runs] if isinstance(runs, Path) else list(runs)
    data, columns, fpr = {}, {}, {}
    for path in sorted(p for folder in folders for p in folder.glob("*.json")):
        run = json.loads(path.read_text())
        split = run["recall_mean"]
        data[run["name"]] = pd.DataFrame(
            None, index=split["index"], columns=split["columns"]
        )
        columns[run["name"]] = len(run["carrier"]["columns"])
        for method, value in run.get("fpr_mean", {}).items():
            fpr.setdefault(method, []).append(value)
    return data, columns, fpr


def x__load__mutmut_19(runs):
    import json
    from pathlib import Path

    folders = [runs] if isinstance(runs, Path) else list(runs)
    data, columns, fpr = {}, {}, {}
    for path in sorted(p for folder in folders for p in folder.glob("*.json")):
        run = json.loads(path.read_text())
        split = run["recall_mean"]
        data[run["name"]] = pd.DataFrame(
            split["data"], index=None, columns=split["columns"]
        )
        columns[run["name"]] = len(run["carrier"]["columns"])
        for method, value in run.get("fpr_mean", {}).items():
            fpr.setdefault(method, []).append(value)
    return data, columns, fpr


def x__load__mutmut_20(runs):
    import json
    from pathlib import Path

    folders = [runs] if isinstance(runs, Path) else list(runs)
    data, columns, fpr = {}, {}, {}
    for path in sorted(p for folder in folders for p in folder.glob("*.json")):
        run = json.loads(path.read_text())
        split = run["recall_mean"]
        data[run["name"]] = pd.DataFrame(
            split["data"], index=split["index"], columns=None
        )
        columns[run["name"]] = len(run["carrier"]["columns"])
        for method, value in run.get("fpr_mean", {}).items():
            fpr.setdefault(method, []).append(value)
    return data, columns, fpr


def x__load__mutmut_21(runs):
    import json
    from pathlib import Path

    folders = [runs] if isinstance(runs, Path) else list(runs)
    data, columns, fpr = {}, {}, {}
    for path in sorted(p for folder in folders for p in folder.glob("*.json")):
        run = json.loads(path.read_text())
        split = run["recall_mean"]
        data[run["name"]] = pd.DataFrame(
            index=split["index"], columns=split["columns"]
        )
        columns[run["name"]] = len(run["carrier"]["columns"])
        for method, value in run.get("fpr_mean", {}).items():
            fpr.setdefault(method, []).append(value)
    return data, columns, fpr


def x__load__mutmut_22(runs):
    import json
    from pathlib import Path

    folders = [runs] if isinstance(runs, Path) else list(runs)
    data, columns, fpr = {}, {}, {}
    for path in sorted(p for folder in folders for p in folder.glob("*.json")):
        run = json.loads(path.read_text())
        split = run["recall_mean"]
        data[run["name"]] = pd.DataFrame(
            split["data"], columns=split["columns"]
        )
        columns[run["name"]] = len(run["carrier"]["columns"])
        for method, value in run.get("fpr_mean", {}).items():
            fpr.setdefault(method, []).append(value)
    return data, columns, fpr


def x__load__mutmut_23(runs):
    import json
    from pathlib import Path

    folders = [runs] if isinstance(runs, Path) else list(runs)
    data, columns, fpr = {}, {}, {}
    for path in sorted(p for folder in folders for p in folder.glob("*.json")):
        run = json.loads(path.read_text())
        split = run["recall_mean"]
        data[run["name"]] = pd.DataFrame(
            split["data"], index=split["index"], )
        columns[run["name"]] = len(run["carrier"]["columns"])
        for method, value in run.get("fpr_mean", {}).items():
            fpr.setdefault(method, []).append(value)
    return data, columns, fpr


def x__load__mutmut_24(runs):
    import json
    from pathlib import Path

    folders = [runs] if isinstance(runs, Path) else list(runs)
    data, columns, fpr = {}, {}, {}
    for path in sorted(p for folder in folders for p in folder.glob("*.json")):
        run = json.loads(path.read_text())
        split = run["recall_mean"]
        data[run["name"]] = pd.DataFrame(
            split["XXdataXX"], index=split["index"], columns=split["columns"]
        )
        columns[run["name"]] = len(run["carrier"]["columns"])
        for method, value in run.get("fpr_mean", {}).items():
            fpr.setdefault(method, []).append(value)
    return data, columns, fpr


def x__load__mutmut_25(runs):
    import json
    from pathlib import Path

    folders = [runs] if isinstance(runs, Path) else list(runs)
    data, columns, fpr = {}, {}, {}
    for path in sorted(p for folder in folders for p in folder.glob("*.json")):
        run = json.loads(path.read_text())
        split = run["recall_mean"]
        data[run["name"]] = pd.DataFrame(
            split["DATA"], index=split["index"], columns=split["columns"]
        )
        columns[run["name"]] = len(run["carrier"]["columns"])
        for method, value in run.get("fpr_mean", {}).items():
            fpr.setdefault(method, []).append(value)
    return data, columns, fpr


def x__load__mutmut_26(runs):
    import json
    from pathlib import Path

    folders = [runs] if isinstance(runs, Path) else list(runs)
    data, columns, fpr = {}, {}, {}
    for path in sorted(p for folder in folders for p in folder.glob("*.json")):
        run = json.loads(path.read_text())
        split = run["recall_mean"]
        data[run["name"]] = pd.DataFrame(
            split["data"], index=split["XXindexXX"], columns=split["columns"]
        )
        columns[run["name"]] = len(run["carrier"]["columns"])
        for method, value in run.get("fpr_mean", {}).items():
            fpr.setdefault(method, []).append(value)
    return data, columns, fpr


def x__load__mutmut_27(runs):
    import json
    from pathlib import Path

    folders = [runs] if isinstance(runs, Path) else list(runs)
    data, columns, fpr = {}, {}, {}
    for path in sorted(p for folder in folders for p in folder.glob("*.json")):
        run = json.loads(path.read_text())
        split = run["recall_mean"]
        data[run["name"]] = pd.DataFrame(
            split["data"], index=split["INDEX"], columns=split["columns"]
        )
        columns[run["name"]] = len(run["carrier"]["columns"])
        for method, value in run.get("fpr_mean", {}).items():
            fpr.setdefault(method, []).append(value)
    return data, columns, fpr


def x__load__mutmut_28(runs):
    import json
    from pathlib import Path

    folders = [runs] if isinstance(runs, Path) else list(runs)
    data, columns, fpr = {}, {}, {}
    for path in sorted(p for folder in folders for p in folder.glob("*.json")):
        run = json.loads(path.read_text())
        split = run["recall_mean"]
        data[run["name"]] = pd.DataFrame(
            split["data"], index=split["index"], columns=split["XXcolumnsXX"]
        )
        columns[run["name"]] = len(run["carrier"]["columns"])
        for method, value in run.get("fpr_mean", {}).items():
            fpr.setdefault(method, []).append(value)
    return data, columns, fpr


def x__load__mutmut_29(runs):
    import json
    from pathlib import Path

    folders = [runs] if isinstance(runs, Path) else list(runs)
    data, columns, fpr = {}, {}, {}
    for path in sorted(p for folder in folders for p in folder.glob("*.json")):
        run = json.loads(path.read_text())
        split = run["recall_mean"]
        data[run["name"]] = pd.DataFrame(
            split["data"], index=split["index"], columns=split["COLUMNS"]
        )
        columns[run["name"]] = len(run["carrier"]["columns"])
        for method, value in run.get("fpr_mean", {}).items():
            fpr.setdefault(method, []).append(value)
    return data, columns, fpr


def x__load__mutmut_30(runs):
    import json
    from pathlib import Path

    folders = [runs] if isinstance(runs, Path) else list(runs)
    data, columns, fpr = {}, {}, {}
    for path in sorted(p for folder in folders for p in folder.glob("*.json")):
        run = json.loads(path.read_text())
        split = run["recall_mean"]
        data[run["name"]] = pd.DataFrame(
            split["data"], index=split["index"], columns=split["columns"]
        )
        columns[run["name"]] = None
        for method, value in run.get("fpr_mean", {}).items():
            fpr.setdefault(method, []).append(value)
    return data, columns, fpr


def x__load__mutmut_31(runs):
    import json
    from pathlib import Path

    folders = [runs] if isinstance(runs, Path) else list(runs)
    data, columns, fpr = {}, {}, {}
    for path in sorted(p for folder in folders for p in folder.glob("*.json")):
        run = json.loads(path.read_text())
        split = run["recall_mean"]
        data[run["name"]] = pd.DataFrame(
            split["data"], index=split["index"], columns=split["columns"]
        )
        columns[run["XXnameXX"]] = len(run["carrier"]["columns"])
        for method, value in run.get("fpr_mean", {}).items():
            fpr.setdefault(method, []).append(value)
    return data, columns, fpr


def x__load__mutmut_32(runs):
    import json
    from pathlib import Path

    folders = [runs] if isinstance(runs, Path) else list(runs)
    data, columns, fpr = {}, {}, {}
    for path in sorted(p for folder in folders for p in folder.glob("*.json")):
        run = json.loads(path.read_text())
        split = run["recall_mean"]
        data[run["name"]] = pd.DataFrame(
            split["data"], index=split["index"], columns=split["columns"]
        )
        columns[run["NAME"]] = len(run["carrier"]["columns"])
        for method, value in run.get("fpr_mean", {}).items():
            fpr.setdefault(method, []).append(value)
    return data, columns, fpr


def x__load__mutmut_33(runs):
    import json
    from pathlib import Path

    folders = [runs] if isinstance(runs, Path) else list(runs)
    data, columns, fpr = {}, {}, {}
    for path in sorted(p for folder in folders for p in folder.glob("*.json")):
        run = json.loads(path.read_text())
        split = run["recall_mean"]
        data[run["name"]] = pd.DataFrame(
            split["data"], index=split["index"], columns=split["columns"]
        )
        columns[run["name"]] = len(run["carrier"]["columns"])
        for method, value in run.get(None, {}).items():
            fpr.setdefault(method, []).append(value)
    return data, columns, fpr


def x__load__mutmut_34(runs):
    import json
    from pathlib import Path

    folders = [runs] if isinstance(runs, Path) else list(runs)
    data, columns, fpr = {}, {}, {}
    for path in sorted(p for folder in folders for p in folder.glob("*.json")):
        run = json.loads(path.read_text())
        split = run["recall_mean"]
        data[run["name"]] = pd.DataFrame(
            split["data"], index=split["index"], columns=split["columns"]
        )
        columns[run["name"]] = len(run["carrier"]["columns"])
        for method, value in run.get("fpr_mean", None).items():
            fpr.setdefault(method, []).append(value)
    return data, columns, fpr


def x__load__mutmut_35(runs):
    import json
    from pathlib import Path

    folders = [runs] if isinstance(runs, Path) else list(runs)
    data, columns, fpr = {}, {}, {}
    for path in sorted(p for folder in folders for p in folder.glob("*.json")):
        run = json.loads(path.read_text())
        split = run["recall_mean"]
        data[run["name"]] = pd.DataFrame(
            split["data"], index=split["index"], columns=split["columns"]
        )
        columns[run["name"]] = len(run["carrier"]["columns"])
        for method, value in run.get({}).items():
            fpr.setdefault(method, []).append(value)
    return data, columns, fpr


def x__load__mutmut_36(runs):
    import json
    from pathlib import Path

    folders = [runs] if isinstance(runs, Path) else list(runs)
    data, columns, fpr = {}, {}, {}
    for path in sorted(p for folder in folders for p in folder.glob("*.json")):
        run = json.loads(path.read_text())
        split = run["recall_mean"]
        data[run["name"]] = pd.DataFrame(
            split["data"], index=split["index"], columns=split["columns"]
        )
        columns[run["name"]] = len(run["carrier"]["columns"])
        for method, value in run.get("fpr_mean", ).items():
            fpr.setdefault(method, []).append(value)
    return data, columns, fpr


def x__load__mutmut_37(runs):
    import json
    from pathlib import Path

    folders = [runs] if isinstance(runs, Path) else list(runs)
    data, columns, fpr = {}, {}, {}
    for path in sorted(p for folder in folders for p in folder.glob("*.json")):
        run = json.loads(path.read_text())
        split = run["recall_mean"]
        data[run["name"]] = pd.DataFrame(
            split["data"], index=split["index"], columns=split["columns"]
        )
        columns[run["name"]] = len(run["carrier"]["columns"])
        for method, value in run.get("XXfpr_meanXX", {}).items():
            fpr.setdefault(method, []).append(value)
    return data, columns, fpr


def x__load__mutmut_38(runs):
    import json
    from pathlib import Path

    folders = [runs] if isinstance(runs, Path) else list(runs)
    data, columns, fpr = {}, {}, {}
    for path in sorted(p for folder in folders for p in folder.glob("*.json")):
        run = json.loads(path.read_text())
        split = run["recall_mean"]
        data[run["name"]] = pd.DataFrame(
            split["data"], index=split["index"], columns=split["columns"]
        )
        columns[run["name"]] = len(run["carrier"]["columns"])
        for method, value in run.get("FPR_MEAN", {}).items():
            fpr.setdefault(method, []).append(value)
    return data, columns, fpr


def x__load__mutmut_39(runs):
    import json
    from pathlib import Path

    folders = [runs] if isinstance(runs, Path) else list(runs)
    data, columns, fpr = {}, {}, {}
    for path in sorted(p for folder in folders for p in folder.glob("*.json")):
        run = json.loads(path.read_text())
        split = run["recall_mean"]
        data[run["name"]] = pd.DataFrame(
            split["data"], index=split["index"], columns=split["columns"]
        )
        columns[run["name"]] = len(run["carrier"]["columns"])
        for method, value in run.get("fpr_mean", {}).items():
            fpr.setdefault(method, []).append(None)
    return data, columns, fpr


def x__load__mutmut_40(runs):
    import json
    from pathlib import Path

    folders = [runs] if isinstance(runs, Path) else list(runs)
    data, columns, fpr = {}, {}, {}
    for path in sorted(p for folder in folders for p in folder.glob("*.json")):
        run = json.loads(path.read_text())
        split = run["recall_mean"]
        data[run["name"]] = pd.DataFrame(
            split["data"], index=split["index"], columns=split["columns"]
        )
        columns[run["name"]] = len(run["carrier"]["columns"])
        for method, value in run.get("fpr_mean", {}).items():
            fpr.setdefault(None, []).append(value)
    return data, columns, fpr


def x__load__mutmut_41(runs):
    import json
    from pathlib import Path

    folders = [runs] if isinstance(runs, Path) else list(runs)
    data, columns, fpr = {}, {}, {}
    for path in sorted(p for folder in folders for p in folder.glob("*.json")):
        run = json.loads(path.read_text())
        split = run["recall_mean"]
        data[run["name"]] = pd.DataFrame(
            split["data"], index=split["index"], columns=split["columns"]
        )
        columns[run["name"]] = len(run["carrier"]["columns"])
        for method, value in run.get("fpr_mean", {}).items():
            fpr.setdefault(method, None).append(value)
    return data, columns, fpr


def x__load__mutmut_42(runs):
    import json
    from pathlib import Path

    folders = [runs] if isinstance(runs, Path) else list(runs)
    data, columns, fpr = {}, {}, {}
    for path in sorted(p for folder in folders for p in folder.glob("*.json")):
        run = json.loads(path.read_text())
        split = run["recall_mean"]
        data[run["name"]] = pd.DataFrame(
            split["data"], index=split["index"], columns=split["columns"]
        )
        columns[run["name"]] = len(run["carrier"]["columns"])
        for method, value in run.get("fpr_mean", {}).items():
            fpr.setdefault([]).append(value)
    return data, columns, fpr


def x__load__mutmut_43(runs):
    import json
    from pathlib import Path

    folders = [runs] if isinstance(runs, Path) else list(runs)
    data, columns, fpr = {}, {}, {}
    for path in sorted(p for folder in folders for p in folder.glob("*.json")):
        run = json.loads(path.read_text())
        split = run["recall_mean"]
        data[run["name"]] = pd.DataFrame(
            split["data"], index=split["index"], columns=split["columns"]
        )
        columns[run["name"]] = len(run["carrier"]["columns"])
        for method, value in run.get("fpr_mean", {}).items():
            fpr.setdefault(method, ).append(value)
    return data, columns, fpr

mutants_x__load__mutmut['_mutmut_orig'] = x__load__mutmut_orig # type: ignore # mutmut generated
mutants_x__load__mutmut['x__load__mutmut_1'] = x__load__mutmut_1 # type: ignore # mutmut generated
mutants_x__load__mutmut['x__load__mutmut_2'] = x__load__mutmut_2 # type: ignore # mutmut generated
mutants_x__load__mutmut['x__load__mutmut_3'] = x__load__mutmut_3 # type: ignore # mutmut generated
mutants_x__load__mutmut['x__load__mutmut_4'] = x__load__mutmut_4 # type: ignore # mutmut generated
mutants_x__load__mutmut['x__load__mutmut_5'] = x__load__mutmut_5 # type: ignore # mutmut generated
mutants_x__load__mutmut['x__load__mutmut_6'] = x__load__mutmut_6 # type: ignore # mutmut generated
mutants_x__load__mutmut['x__load__mutmut_7'] = x__load__mutmut_7 # type: ignore # mutmut generated
mutants_x__load__mutmut['x__load__mutmut_8'] = x__load__mutmut_8 # type: ignore # mutmut generated
mutants_x__load__mutmut['x__load__mutmut_9'] = x__load__mutmut_9 # type: ignore # mutmut generated
mutants_x__load__mutmut['x__load__mutmut_10'] = x__load__mutmut_10 # type: ignore # mutmut generated
mutants_x__load__mutmut['x__load__mutmut_11'] = x__load__mutmut_11 # type: ignore # mutmut generated
mutants_x__load__mutmut['x__load__mutmut_12'] = x__load__mutmut_12 # type: ignore # mutmut generated
mutants_x__load__mutmut['x__load__mutmut_13'] = x__load__mutmut_13 # type: ignore # mutmut generated
mutants_x__load__mutmut['x__load__mutmut_14'] = x__load__mutmut_14 # type: ignore # mutmut generated
mutants_x__load__mutmut['x__load__mutmut_15'] = x__load__mutmut_15 # type: ignore # mutmut generated
mutants_x__load__mutmut['x__load__mutmut_16'] = x__load__mutmut_16 # type: ignore # mutmut generated
mutants_x__load__mutmut['x__load__mutmut_17'] = x__load__mutmut_17 # type: ignore # mutmut generated
mutants_x__load__mutmut['x__load__mutmut_18'] = x__load__mutmut_18 # type: ignore # mutmut generated
mutants_x__load__mutmut['x__load__mutmut_19'] = x__load__mutmut_19 # type: ignore # mutmut generated
mutants_x__load__mutmut['x__load__mutmut_20'] = x__load__mutmut_20 # type: ignore # mutmut generated
mutants_x__load__mutmut['x__load__mutmut_21'] = x__load__mutmut_21 # type: ignore # mutmut generated
mutants_x__load__mutmut['x__load__mutmut_22'] = x__load__mutmut_22 # type: ignore # mutmut generated
mutants_x__load__mutmut['x__load__mutmut_23'] = x__load__mutmut_23 # type: ignore # mutmut generated
mutants_x__load__mutmut['x__load__mutmut_24'] = x__load__mutmut_24 # type: ignore # mutmut generated
mutants_x__load__mutmut['x__load__mutmut_25'] = x__load__mutmut_25 # type: ignore # mutmut generated
mutants_x__load__mutmut['x__load__mutmut_26'] = x__load__mutmut_26 # type: ignore # mutmut generated
mutants_x__load__mutmut['x__load__mutmut_27'] = x__load__mutmut_27 # type: ignore # mutmut generated
mutants_x__load__mutmut['x__load__mutmut_28'] = x__load__mutmut_28 # type: ignore # mutmut generated
mutants_x__load__mutmut['x__load__mutmut_29'] = x__load__mutmut_29 # type: ignore # mutmut generated
mutants_x__load__mutmut['x__load__mutmut_30'] = x__load__mutmut_30 # type: ignore # mutmut generated
mutants_x__load__mutmut['x__load__mutmut_31'] = x__load__mutmut_31 # type: ignore # mutmut generated
mutants_x__load__mutmut['x__load__mutmut_32'] = x__load__mutmut_32 # type: ignore # mutmut generated
mutants_x__load__mutmut['x__load__mutmut_33'] = x__load__mutmut_33 # type: ignore # mutmut generated
mutants_x__load__mutmut['x__load__mutmut_34'] = x__load__mutmut_34 # type: ignore # mutmut generated
mutants_x__load__mutmut['x__load__mutmut_35'] = x__load__mutmut_35 # type: ignore # mutmut generated
mutants_x__load__mutmut['x__load__mutmut_36'] = x__load__mutmut_36 # type: ignore # mutmut generated
mutants_x__load__mutmut['x__load__mutmut_37'] = x__load__mutmut_37 # type: ignore # mutmut generated
mutants_x__load__mutmut['x__load__mutmut_38'] = x__load__mutmut_38 # type: ignore # mutmut generated
mutants_x__load__mutmut['x__load__mutmut_39'] = x__load__mutmut_39 # type: ignore # mutmut generated
mutants_x__load__mutmut['x__load__mutmut_40'] = x__load__mutmut_40 # type: ignore # mutmut generated
mutants_x__load__mutmut['x__load__mutmut_41'] = x__load__mutmut_41 # type: ignore # mutmut generated
mutants_x__load__mutmut['x__load__mutmut_42'] = x__load__mutmut_42 # type: ignore # mutmut generated
mutants_x__load__mutmut['x__load__mutmut_43'] = x__load__mutmut_43 # type: ignore # mutmut generated
mutants_x_main__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_main__mutmut)
def main(argv: list[str] | None = None) -> int:
    import argparse
    import json
    from pathlib import Path

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, nargs="+", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    data, columns, fpr = _load(args.runs)
    summary = pooled(data)
    results = {
        "datasets": len(data),
        "median": json.loads(summary["median"].to_json(orient="split")),
        "low": json.loads(summary["low"].to_json(orient="split")),
        "high": json.loads(summary["high"].to_json(orient="split")),
        "stability": stability(data),
        "hypotheses": hypotheses(data, columns),
        "fpr": {
            m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in fpr.items()
        },
    }
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / "typed_results.json").write_text(
        json.dumps(results, indent=1, sort_keys=True) + "\n"
    )
    lines = [f"Median recall over {len(data)} datasets (95% interval over datasets)", ""]
    kinds = list(summary["median"].columns)
    lines += ["| method | " + " | ".join(kinds) + " |", "|---|" + "---|" * len(kinds)]
    for method in summary["median"].index:
        cells = []
        for k in kinds:
            mid, lo, hi = (summary[n].loc[method, k] for n in ("median", "low", "high"))
            cells.append(f"{mid:.2f} [{lo:.2f}, {hi:.2f}]")
        lines.append(f"| {method} | " + " | ".join(cells) + " |")
    lines += ["", "Clean-row false positive rate (median and maximum over datasets)", ""]
    lines += [f"- {m}: {v['median']:.3f} (max {v['max']:.3f})" for m, v in results["fpr"].items()]
    (args.output / "typed_results.md").write_text("\n".join(lines) + "\n")
    print(f"{len(data)} datasets")
    return 0


def x_main__mutmut_orig(argv: list[str] | None = None) -> int:
    import argparse
    import json
    from pathlib import Path

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, nargs="+", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    data, columns, fpr = _load(args.runs)
    summary = pooled(data)
    results = {
        "datasets": len(data),
        "median": json.loads(summary["median"].to_json(orient="split")),
        "low": json.loads(summary["low"].to_json(orient="split")),
        "high": json.loads(summary["high"].to_json(orient="split")),
        "stability": stability(data),
        "hypotheses": hypotheses(data, columns),
        "fpr": {
            m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in fpr.items()
        },
    }
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / "typed_results.json").write_text(
        json.dumps(results, indent=1, sort_keys=True) + "\n"
    )
    lines = [f"Median recall over {len(data)} datasets (95% interval over datasets)", ""]
    kinds = list(summary["median"].columns)
    lines += ["| method | " + " | ".join(kinds) + " |", "|---|" + "---|" * len(kinds)]
    for method in summary["median"].index:
        cells = []
        for k in kinds:
            mid, lo, hi = (summary[n].loc[method, k] for n in ("median", "low", "high"))
            cells.append(f"{mid:.2f} [{lo:.2f}, {hi:.2f}]")
        lines.append(f"| {method} | " + " | ".join(cells) + " |")
    lines += ["", "Clean-row false positive rate (median and maximum over datasets)", ""]
    lines += [f"- {m}: {v['median']:.3f} (max {v['max']:.3f})" for m, v in results["fpr"].items()]
    (args.output / "typed_results.md").write_text("\n".join(lines) + "\n")
    print(f"{len(data)} datasets")
    return 0


def x_main__mutmut_1(argv: list[str] | None = None) -> int:
    import argparse
    import json
    from pathlib import Path

    parser = None
    parser.add_argument("--runs", type=Path, nargs="+", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    data, columns, fpr = _load(args.runs)
    summary = pooled(data)
    results = {
        "datasets": len(data),
        "median": json.loads(summary["median"].to_json(orient="split")),
        "low": json.loads(summary["low"].to_json(orient="split")),
        "high": json.loads(summary["high"].to_json(orient="split")),
        "stability": stability(data),
        "hypotheses": hypotheses(data, columns),
        "fpr": {
            m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in fpr.items()
        },
    }
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / "typed_results.json").write_text(
        json.dumps(results, indent=1, sort_keys=True) + "\n"
    )
    lines = [f"Median recall over {len(data)} datasets (95% interval over datasets)", ""]
    kinds = list(summary["median"].columns)
    lines += ["| method | " + " | ".join(kinds) + " |", "|---|" + "---|" * len(kinds)]
    for method in summary["median"].index:
        cells = []
        for k in kinds:
            mid, lo, hi = (summary[n].loc[method, k] for n in ("median", "low", "high"))
            cells.append(f"{mid:.2f} [{lo:.2f}, {hi:.2f}]")
        lines.append(f"| {method} | " + " | ".join(cells) + " |")
    lines += ["", "Clean-row false positive rate (median and maximum over datasets)", ""]
    lines += [f"- {m}: {v['median']:.3f} (max {v['max']:.3f})" for m, v in results["fpr"].items()]
    (args.output / "typed_results.md").write_text("\n".join(lines) + "\n")
    print(f"{len(data)} datasets")
    return 0


def x_main__mutmut_2(argv: list[str] | None = None) -> int:
    import argparse
    import json
    from pathlib import Path

    parser = argparse.ArgumentParser(description=None)
    parser.add_argument("--runs", type=Path, nargs="+", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    data, columns, fpr = _load(args.runs)
    summary = pooled(data)
    results = {
        "datasets": len(data),
        "median": json.loads(summary["median"].to_json(orient="split")),
        "low": json.loads(summary["low"].to_json(orient="split")),
        "high": json.loads(summary["high"].to_json(orient="split")),
        "stability": stability(data),
        "hypotheses": hypotheses(data, columns),
        "fpr": {
            m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in fpr.items()
        },
    }
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / "typed_results.json").write_text(
        json.dumps(results, indent=1, sort_keys=True) + "\n"
    )
    lines = [f"Median recall over {len(data)} datasets (95% interval over datasets)", ""]
    kinds = list(summary["median"].columns)
    lines += ["| method | " + " | ".join(kinds) + " |", "|---|" + "---|" * len(kinds)]
    for method in summary["median"].index:
        cells = []
        for k in kinds:
            mid, lo, hi = (summary[n].loc[method, k] for n in ("median", "low", "high"))
            cells.append(f"{mid:.2f} [{lo:.2f}, {hi:.2f}]")
        lines.append(f"| {method} | " + " | ".join(cells) + " |")
    lines += ["", "Clean-row false positive rate (median and maximum over datasets)", ""]
    lines += [f"- {m}: {v['median']:.3f} (max {v['max']:.3f})" for m, v in results["fpr"].items()]
    (args.output / "typed_results.md").write_text("\n".join(lines) + "\n")
    print(f"{len(data)} datasets")
    return 0


def x_main__mutmut_3(argv: list[str] | None = None) -> int:
    import argparse
    import json
    from pathlib import Path

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(None, type=Path, nargs="+", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    data, columns, fpr = _load(args.runs)
    summary = pooled(data)
    results = {
        "datasets": len(data),
        "median": json.loads(summary["median"].to_json(orient="split")),
        "low": json.loads(summary["low"].to_json(orient="split")),
        "high": json.loads(summary["high"].to_json(orient="split")),
        "stability": stability(data),
        "hypotheses": hypotheses(data, columns),
        "fpr": {
            m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in fpr.items()
        },
    }
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / "typed_results.json").write_text(
        json.dumps(results, indent=1, sort_keys=True) + "\n"
    )
    lines = [f"Median recall over {len(data)} datasets (95% interval over datasets)", ""]
    kinds = list(summary["median"].columns)
    lines += ["| method | " + " | ".join(kinds) + " |", "|---|" + "---|" * len(kinds)]
    for method in summary["median"].index:
        cells = []
        for k in kinds:
            mid, lo, hi = (summary[n].loc[method, k] for n in ("median", "low", "high"))
            cells.append(f"{mid:.2f} [{lo:.2f}, {hi:.2f}]")
        lines.append(f"| {method} | " + " | ".join(cells) + " |")
    lines += ["", "Clean-row false positive rate (median and maximum over datasets)", ""]
    lines += [f"- {m}: {v['median']:.3f} (max {v['max']:.3f})" for m, v in results["fpr"].items()]
    (args.output / "typed_results.md").write_text("\n".join(lines) + "\n")
    print(f"{len(data)} datasets")
    return 0


def x_main__mutmut_4(argv: list[str] | None = None) -> int:
    import argparse
    import json
    from pathlib import Path

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=None, nargs="+", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    data, columns, fpr = _load(args.runs)
    summary = pooled(data)
    results = {
        "datasets": len(data),
        "median": json.loads(summary["median"].to_json(orient="split")),
        "low": json.loads(summary["low"].to_json(orient="split")),
        "high": json.loads(summary["high"].to_json(orient="split")),
        "stability": stability(data),
        "hypotheses": hypotheses(data, columns),
        "fpr": {
            m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in fpr.items()
        },
    }
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / "typed_results.json").write_text(
        json.dumps(results, indent=1, sort_keys=True) + "\n"
    )
    lines = [f"Median recall over {len(data)} datasets (95% interval over datasets)", ""]
    kinds = list(summary["median"].columns)
    lines += ["| method | " + " | ".join(kinds) + " |", "|---|" + "---|" * len(kinds)]
    for method in summary["median"].index:
        cells = []
        for k in kinds:
            mid, lo, hi = (summary[n].loc[method, k] for n in ("median", "low", "high"))
            cells.append(f"{mid:.2f} [{lo:.2f}, {hi:.2f}]")
        lines.append(f"| {method} | " + " | ".join(cells) + " |")
    lines += ["", "Clean-row false positive rate (median and maximum over datasets)", ""]
    lines += [f"- {m}: {v['median']:.3f} (max {v['max']:.3f})" for m, v in results["fpr"].items()]
    (args.output / "typed_results.md").write_text("\n".join(lines) + "\n")
    print(f"{len(data)} datasets")
    return 0


def x_main__mutmut_5(argv: list[str] | None = None) -> int:
    import argparse
    import json
    from pathlib import Path

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, nargs=None, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    data, columns, fpr = _load(args.runs)
    summary = pooled(data)
    results = {
        "datasets": len(data),
        "median": json.loads(summary["median"].to_json(orient="split")),
        "low": json.loads(summary["low"].to_json(orient="split")),
        "high": json.loads(summary["high"].to_json(orient="split")),
        "stability": stability(data),
        "hypotheses": hypotheses(data, columns),
        "fpr": {
            m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in fpr.items()
        },
    }
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / "typed_results.json").write_text(
        json.dumps(results, indent=1, sort_keys=True) + "\n"
    )
    lines = [f"Median recall over {len(data)} datasets (95% interval over datasets)", ""]
    kinds = list(summary["median"].columns)
    lines += ["| method | " + " | ".join(kinds) + " |", "|---|" + "---|" * len(kinds)]
    for method in summary["median"].index:
        cells = []
        for k in kinds:
            mid, lo, hi = (summary[n].loc[method, k] for n in ("median", "low", "high"))
            cells.append(f"{mid:.2f} [{lo:.2f}, {hi:.2f}]")
        lines.append(f"| {method} | " + " | ".join(cells) + " |")
    lines += ["", "Clean-row false positive rate (median and maximum over datasets)", ""]
    lines += [f"- {m}: {v['median']:.3f} (max {v['max']:.3f})" for m, v in results["fpr"].items()]
    (args.output / "typed_results.md").write_text("\n".join(lines) + "\n")
    print(f"{len(data)} datasets")
    return 0


def x_main__mutmut_6(argv: list[str] | None = None) -> int:
    import argparse
    import json
    from pathlib import Path

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, nargs="+", required=None)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    data, columns, fpr = _load(args.runs)
    summary = pooled(data)
    results = {
        "datasets": len(data),
        "median": json.loads(summary["median"].to_json(orient="split")),
        "low": json.loads(summary["low"].to_json(orient="split")),
        "high": json.loads(summary["high"].to_json(orient="split")),
        "stability": stability(data),
        "hypotheses": hypotheses(data, columns),
        "fpr": {
            m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in fpr.items()
        },
    }
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / "typed_results.json").write_text(
        json.dumps(results, indent=1, sort_keys=True) + "\n"
    )
    lines = [f"Median recall over {len(data)} datasets (95% interval over datasets)", ""]
    kinds = list(summary["median"].columns)
    lines += ["| method | " + " | ".join(kinds) + " |", "|---|" + "---|" * len(kinds)]
    for method in summary["median"].index:
        cells = []
        for k in kinds:
            mid, lo, hi = (summary[n].loc[method, k] for n in ("median", "low", "high"))
            cells.append(f"{mid:.2f} [{lo:.2f}, {hi:.2f}]")
        lines.append(f"| {method} | " + " | ".join(cells) + " |")
    lines += ["", "Clean-row false positive rate (median and maximum over datasets)", ""]
    lines += [f"- {m}: {v['median']:.3f} (max {v['max']:.3f})" for m, v in results["fpr"].items()]
    (args.output / "typed_results.md").write_text("\n".join(lines) + "\n")
    print(f"{len(data)} datasets")
    return 0


def x_main__mutmut_7(argv: list[str] | None = None) -> int:
    import argparse
    import json
    from pathlib import Path

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(type=Path, nargs="+", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    data, columns, fpr = _load(args.runs)
    summary = pooled(data)
    results = {
        "datasets": len(data),
        "median": json.loads(summary["median"].to_json(orient="split")),
        "low": json.loads(summary["low"].to_json(orient="split")),
        "high": json.loads(summary["high"].to_json(orient="split")),
        "stability": stability(data),
        "hypotheses": hypotheses(data, columns),
        "fpr": {
            m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in fpr.items()
        },
    }
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / "typed_results.json").write_text(
        json.dumps(results, indent=1, sort_keys=True) + "\n"
    )
    lines = [f"Median recall over {len(data)} datasets (95% interval over datasets)", ""]
    kinds = list(summary["median"].columns)
    lines += ["| method | " + " | ".join(kinds) + " |", "|---|" + "---|" * len(kinds)]
    for method in summary["median"].index:
        cells = []
        for k in kinds:
            mid, lo, hi = (summary[n].loc[method, k] for n in ("median", "low", "high"))
            cells.append(f"{mid:.2f} [{lo:.2f}, {hi:.2f}]")
        lines.append(f"| {method} | " + " | ".join(cells) + " |")
    lines += ["", "Clean-row false positive rate (median and maximum over datasets)", ""]
    lines += [f"- {m}: {v['median']:.3f} (max {v['max']:.3f})" for m, v in results["fpr"].items()]
    (args.output / "typed_results.md").write_text("\n".join(lines) + "\n")
    print(f"{len(data)} datasets")
    return 0


def x_main__mutmut_8(argv: list[str] | None = None) -> int:
    import argparse
    import json
    from pathlib import Path

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", nargs="+", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    data, columns, fpr = _load(args.runs)
    summary = pooled(data)
    results = {
        "datasets": len(data),
        "median": json.loads(summary["median"].to_json(orient="split")),
        "low": json.loads(summary["low"].to_json(orient="split")),
        "high": json.loads(summary["high"].to_json(orient="split")),
        "stability": stability(data),
        "hypotheses": hypotheses(data, columns),
        "fpr": {
            m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in fpr.items()
        },
    }
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / "typed_results.json").write_text(
        json.dumps(results, indent=1, sort_keys=True) + "\n"
    )
    lines = [f"Median recall over {len(data)} datasets (95% interval over datasets)", ""]
    kinds = list(summary["median"].columns)
    lines += ["| method | " + " | ".join(kinds) + " |", "|---|" + "---|" * len(kinds)]
    for method in summary["median"].index:
        cells = []
        for k in kinds:
            mid, lo, hi = (summary[n].loc[method, k] for n in ("median", "low", "high"))
            cells.append(f"{mid:.2f} [{lo:.2f}, {hi:.2f}]")
        lines.append(f"| {method} | " + " | ".join(cells) + " |")
    lines += ["", "Clean-row false positive rate (median and maximum over datasets)", ""]
    lines += [f"- {m}: {v['median']:.3f} (max {v['max']:.3f})" for m, v in results["fpr"].items()]
    (args.output / "typed_results.md").write_text("\n".join(lines) + "\n")
    print(f"{len(data)} datasets")
    return 0


def x_main__mutmut_9(argv: list[str] | None = None) -> int:
    import argparse
    import json
    from pathlib import Path

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    data, columns, fpr = _load(args.runs)
    summary = pooled(data)
    results = {
        "datasets": len(data),
        "median": json.loads(summary["median"].to_json(orient="split")),
        "low": json.loads(summary["low"].to_json(orient="split")),
        "high": json.loads(summary["high"].to_json(orient="split")),
        "stability": stability(data),
        "hypotheses": hypotheses(data, columns),
        "fpr": {
            m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in fpr.items()
        },
    }
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / "typed_results.json").write_text(
        json.dumps(results, indent=1, sort_keys=True) + "\n"
    )
    lines = [f"Median recall over {len(data)} datasets (95% interval over datasets)", ""]
    kinds = list(summary["median"].columns)
    lines += ["| method | " + " | ".join(kinds) + " |", "|---|" + "---|" * len(kinds)]
    for method in summary["median"].index:
        cells = []
        for k in kinds:
            mid, lo, hi = (summary[n].loc[method, k] for n in ("median", "low", "high"))
            cells.append(f"{mid:.2f} [{lo:.2f}, {hi:.2f}]")
        lines.append(f"| {method} | " + " | ".join(cells) + " |")
    lines += ["", "Clean-row false positive rate (median and maximum over datasets)", ""]
    lines += [f"- {m}: {v['median']:.3f} (max {v['max']:.3f})" for m, v in results["fpr"].items()]
    (args.output / "typed_results.md").write_text("\n".join(lines) + "\n")
    print(f"{len(data)} datasets")
    return 0


def x_main__mutmut_10(argv: list[str] | None = None) -> int:
    import argparse
    import json
    from pathlib import Path

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, nargs="+", )
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    data, columns, fpr = _load(args.runs)
    summary = pooled(data)
    results = {
        "datasets": len(data),
        "median": json.loads(summary["median"].to_json(orient="split")),
        "low": json.loads(summary["low"].to_json(orient="split")),
        "high": json.loads(summary["high"].to_json(orient="split")),
        "stability": stability(data),
        "hypotheses": hypotheses(data, columns),
        "fpr": {
            m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in fpr.items()
        },
    }
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / "typed_results.json").write_text(
        json.dumps(results, indent=1, sort_keys=True) + "\n"
    )
    lines = [f"Median recall over {len(data)} datasets (95% interval over datasets)", ""]
    kinds = list(summary["median"].columns)
    lines += ["| method | " + " | ".join(kinds) + " |", "|---|" + "---|" * len(kinds)]
    for method in summary["median"].index:
        cells = []
        for k in kinds:
            mid, lo, hi = (summary[n].loc[method, k] for n in ("median", "low", "high"))
            cells.append(f"{mid:.2f} [{lo:.2f}, {hi:.2f}]")
        lines.append(f"| {method} | " + " | ".join(cells) + " |")
    lines += ["", "Clean-row false positive rate (median and maximum over datasets)", ""]
    lines += [f"- {m}: {v['median']:.3f} (max {v['max']:.3f})" for m, v in results["fpr"].items()]
    (args.output / "typed_results.md").write_text("\n".join(lines) + "\n")
    print(f"{len(data)} datasets")
    return 0


def x_main__mutmut_11(argv: list[str] | None = None) -> int:
    import argparse
    import json
    from pathlib import Path

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("XX--runsXX", type=Path, nargs="+", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    data, columns, fpr = _load(args.runs)
    summary = pooled(data)
    results = {
        "datasets": len(data),
        "median": json.loads(summary["median"].to_json(orient="split")),
        "low": json.loads(summary["low"].to_json(orient="split")),
        "high": json.loads(summary["high"].to_json(orient="split")),
        "stability": stability(data),
        "hypotheses": hypotheses(data, columns),
        "fpr": {
            m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in fpr.items()
        },
    }
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / "typed_results.json").write_text(
        json.dumps(results, indent=1, sort_keys=True) + "\n"
    )
    lines = [f"Median recall over {len(data)} datasets (95% interval over datasets)", ""]
    kinds = list(summary["median"].columns)
    lines += ["| method | " + " | ".join(kinds) + " |", "|---|" + "---|" * len(kinds)]
    for method in summary["median"].index:
        cells = []
        for k in kinds:
            mid, lo, hi = (summary[n].loc[method, k] for n in ("median", "low", "high"))
            cells.append(f"{mid:.2f} [{lo:.2f}, {hi:.2f}]")
        lines.append(f"| {method} | " + " | ".join(cells) + " |")
    lines += ["", "Clean-row false positive rate (median and maximum over datasets)", ""]
    lines += [f"- {m}: {v['median']:.3f} (max {v['max']:.3f})" for m, v in results["fpr"].items()]
    (args.output / "typed_results.md").write_text("\n".join(lines) + "\n")
    print(f"{len(data)} datasets")
    return 0


def x_main__mutmut_12(argv: list[str] | None = None) -> int:
    import argparse
    import json
    from pathlib import Path

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--RUNS", type=Path, nargs="+", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    data, columns, fpr = _load(args.runs)
    summary = pooled(data)
    results = {
        "datasets": len(data),
        "median": json.loads(summary["median"].to_json(orient="split")),
        "low": json.loads(summary["low"].to_json(orient="split")),
        "high": json.loads(summary["high"].to_json(orient="split")),
        "stability": stability(data),
        "hypotheses": hypotheses(data, columns),
        "fpr": {
            m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in fpr.items()
        },
    }
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / "typed_results.json").write_text(
        json.dumps(results, indent=1, sort_keys=True) + "\n"
    )
    lines = [f"Median recall over {len(data)} datasets (95% interval over datasets)", ""]
    kinds = list(summary["median"].columns)
    lines += ["| method | " + " | ".join(kinds) + " |", "|---|" + "---|" * len(kinds)]
    for method in summary["median"].index:
        cells = []
        for k in kinds:
            mid, lo, hi = (summary[n].loc[method, k] for n in ("median", "low", "high"))
            cells.append(f"{mid:.2f} [{lo:.2f}, {hi:.2f}]")
        lines.append(f"| {method} | " + " | ".join(cells) + " |")
    lines += ["", "Clean-row false positive rate (median and maximum over datasets)", ""]
    lines += [f"- {m}: {v['median']:.3f} (max {v['max']:.3f})" for m, v in results["fpr"].items()]
    (args.output / "typed_results.md").write_text("\n".join(lines) + "\n")
    print(f"{len(data)} datasets")
    return 0


def x_main__mutmut_13(argv: list[str] | None = None) -> int:
    import argparse
    import json
    from pathlib import Path

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, nargs="XX+XX", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    data, columns, fpr = _load(args.runs)
    summary = pooled(data)
    results = {
        "datasets": len(data),
        "median": json.loads(summary["median"].to_json(orient="split")),
        "low": json.loads(summary["low"].to_json(orient="split")),
        "high": json.loads(summary["high"].to_json(orient="split")),
        "stability": stability(data),
        "hypotheses": hypotheses(data, columns),
        "fpr": {
            m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in fpr.items()
        },
    }
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / "typed_results.json").write_text(
        json.dumps(results, indent=1, sort_keys=True) + "\n"
    )
    lines = [f"Median recall over {len(data)} datasets (95% interval over datasets)", ""]
    kinds = list(summary["median"].columns)
    lines += ["| method | " + " | ".join(kinds) + " |", "|---|" + "---|" * len(kinds)]
    for method in summary["median"].index:
        cells = []
        for k in kinds:
            mid, lo, hi = (summary[n].loc[method, k] for n in ("median", "low", "high"))
            cells.append(f"{mid:.2f} [{lo:.2f}, {hi:.2f}]")
        lines.append(f"| {method} | " + " | ".join(cells) + " |")
    lines += ["", "Clean-row false positive rate (median and maximum over datasets)", ""]
    lines += [f"- {m}: {v['median']:.3f} (max {v['max']:.3f})" for m, v in results["fpr"].items()]
    (args.output / "typed_results.md").write_text("\n".join(lines) + "\n")
    print(f"{len(data)} datasets")
    return 0


def x_main__mutmut_14(argv: list[str] | None = None) -> int:
    import argparse
    import json
    from pathlib import Path

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, nargs="+", required=False)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    data, columns, fpr = _load(args.runs)
    summary = pooled(data)
    results = {
        "datasets": len(data),
        "median": json.loads(summary["median"].to_json(orient="split")),
        "low": json.loads(summary["low"].to_json(orient="split")),
        "high": json.loads(summary["high"].to_json(orient="split")),
        "stability": stability(data),
        "hypotheses": hypotheses(data, columns),
        "fpr": {
            m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in fpr.items()
        },
    }
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / "typed_results.json").write_text(
        json.dumps(results, indent=1, sort_keys=True) + "\n"
    )
    lines = [f"Median recall over {len(data)} datasets (95% interval over datasets)", ""]
    kinds = list(summary["median"].columns)
    lines += ["| method | " + " | ".join(kinds) + " |", "|---|" + "---|" * len(kinds)]
    for method in summary["median"].index:
        cells = []
        for k in kinds:
            mid, lo, hi = (summary[n].loc[method, k] for n in ("median", "low", "high"))
            cells.append(f"{mid:.2f} [{lo:.2f}, {hi:.2f}]")
        lines.append(f"| {method} | " + " | ".join(cells) + " |")
    lines += ["", "Clean-row false positive rate (median and maximum over datasets)", ""]
    lines += [f"- {m}: {v['median']:.3f} (max {v['max']:.3f})" for m, v in results["fpr"].items()]
    (args.output / "typed_results.md").write_text("\n".join(lines) + "\n")
    print(f"{len(data)} datasets")
    return 0


def x_main__mutmut_15(argv: list[str] | None = None) -> int:
    import argparse
    import json
    from pathlib import Path

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, nargs="+", required=True)
    parser.add_argument(None, type=Path, required=True)
    args = parser.parse_args(argv)
    data, columns, fpr = _load(args.runs)
    summary = pooled(data)
    results = {
        "datasets": len(data),
        "median": json.loads(summary["median"].to_json(orient="split")),
        "low": json.loads(summary["low"].to_json(orient="split")),
        "high": json.loads(summary["high"].to_json(orient="split")),
        "stability": stability(data),
        "hypotheses": hypotheses(data, columns),
        "fpr": {
            m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in fpr.items()
        },
    }
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / "typed_results.json").write_text(
        json.dumps(results, indent=1, sort_keys=True) + "\n"
    )
    lines = [f"Median recall over {len(data)} datasets (95% interval over datasets)", ""]
    kinds = list(summary["median"].columns)
    lines += ["| method | " + " | ".join(kinds) + " |", "|---|" + "---|" * len(kinds)]
    for method in summary["median"].index:
        cells = []
        for k in kinds:
            mid, lo, hi = (summary[n].loc[method, k] for n in ("median", "low", "high"))
            cells.append(f"{mid:.2f} [{lo:.2f}, {hi:.2f}]")
        lines.append(f"| {method} | " + " | ".join(cells) + " |")
    lines += ["", "Clean-row false positive rate (median and maximum over datasets)", ""]
    lines += [f"- {m}: {v['median']:.3f} (max {v['max']:.3f})" for m, v in results["fpr"].items()]
    (args.output / "typed_results.md").write_text("\n".join(lines) + "\n")
    print(f"{len(data)} datasets")
    return 0


def x_main__mutmut_16(argv: list[str] | None = None) -> int:
    import argparse
    import json
    from pathlib import Path

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, nargs="+", required=True)
    parser.add_argument("--output", type=None, required=True)
    args = parser.parse_args(argv)
    data, columns, fpr = _load(args.runs)
    summary = pooled(data)
    results = {
        "datasets": len(data),
        "median": json.loads(summary["median"].to_json(orient="split")),
        "low": json.loads(summary["low"].to_json(orient="split")),
        "high": json.loads(summary["high"].to_json(orient="split")),
        "stability": stability(data),
        "hypotheses": hypotheses(data, columns),
        "fpr": {
            m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in fpr.items()
        },
    }
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / "typed_results.json").write_text(
        json.dumps(results, indent=1, sort_keys=True) + "\n"
    )
    lines = [f"Median recall over {len(data)} datasets (95% interval over datasets)", ""]
    kinds = list(summary["median"].columns)
    lines += ["| method | " + " | ".join(kinds) + " |", "|---|" + "---|" * len(kinds)]
    for method in summary["median"].index:
        cells = []
        for k in kinds:
            mid, lo, hi = (summary[n].loc[method, k] for n in ("median", "low", "high"))
            cells.append(f"{mid:.2f} [{lo:.2f}, {hi:.2f}]")
        lines.append(f"| {method} | " + " | ".join(cells) + " |")
    lines += ["", "Clean-row false positive rate (median and maximum over datasets)", ""]
    lines += [f"- {m}: {v['median']:.3f} (max {v['max']:.3f})" for m, v in results["fpr"].items()]
    (args.output / "typed_results.md").write_text("\n".join(lines) + "\n")
    print(f"{len(data)} datasets")
    return 0


def x_main__mutmut_17(argv: list[str] | None = None) -> int:
    import argparse
    import json
    from pathlib import Path

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, nargs="+", required=True)
    parser.add_argument("--output", type=Path, required=None)
    args = parser.parse_args(argv)
    data, columns, fpr = _load(args.runs)
    summary = pooled(data)
    results = {
        "datasets": len(data),
        "median": json.loads(summary["median"].to_json(orient="split")),
        "low": json.loads(summary["low"].to_json(orient="split")),
        "high": json.loads(summary["high"].to_json(orient="split")),
        "stability": stability(data),
        "hypotheses": hypotheses(data, columns),
        "fpr": {
            m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in fpr.items()
        },
    }
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / "typed_results.json").write_text(
        json.dumps(results, indent=1, sort_keys=True) + "\n"
    )
    lines = [f"Median recall over {len(data)} datasets (95% interval over datasets)", ""]
    kinds = list(summary["median"].columns)
    lines += ["| method | " + " | ".join(kinds) + " |", "|---|" + "---|" * len(kinds)]
    for method in summary["median"].index:
        cells = []
        for k in kinds:
            mid, lo, hi = (summary[n].loc[method, k] for n in ("median", "low", "high"))
            cells.append(f"{mid:.2f} [{lo:.2f}, {hi:.2f}]")
        lines.append(f"| {method} | " + " | ".join(cells) + " |")
    lines += ["", "Clean-row false positive rate (median and maximum over datasets)", ""]
    lines += [f"- {m}: {v['median']:.3f} (max {v['max']:.3f})" for m, v in results["fpr"].items()]
    (args.output / "typed_results.md").write_text("\n".join(lines) + "\n")
    print(f"{len(data)} datasets")
    return 0


def x_main__mutmut_18(argv: list[str] | None = None) -> int:
    import argparse
    import json
    from pathlib import Path

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, nargs="+", required=True)
    parser.add_argument(type=Path, required=True)
    args = parser.parse_args(argv)
    data, columns, fpr = _load(args.runs)
    summary = pooled(data)
    results = {
        "datasets": len(data),
        "median": json.loads(summary["median"].to_json(orient="split")),
        "low": json.loads(summary["low"].to_json(orient="split")),
        "high": json.loads(summary["high"].to_json(orient="split")),
        "stability": stability(data),
        "hypotheses": hypotheses(data, columns),
        "fpr": {
            m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in fpr.items()
        },
    }
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / "typed_results.json").write_text(
        json.dumps(results, indent=1, sort_keys=True) + "\n"
    )
    lines = [f"Median recall over {len(data)} datasets (95% interval over datasets)", ""]
    kinds = list(summary["median"].columns)
    lines += ["| method | " + " | ".join(kinds) + " |", "|---|" + "---|" * len(kinds)]
    for method in summary["median"].index:
        cells = []
        for k in kinds:
            mid, lo, hi = (summary[n].loc[method, k] for n in ("median", "low", "high"))
            cells.append(f"{mid:.2f} [{lo:.2f}, {hi:.2f}]")
        lines.append(f"| {method} | " + " | ".join(cells) + " |")
    lines += ["", "Clean-row false positive rate (median and maximum over datasets)", ""]
    lines += [f"- {m}: {v['median']:.3f} (max {v['max']:.3f})" for m, v in results["fpr"].items()]
    (args.output / "typed_results.md").write_text("\n".join(lines) + "\n")
    print(f"{len(data)} datasets")
    return 0


def x_main__mutmut_19(argv: list[str] | None = None) -> int:
    import argparse
    import json
    from pathlib import Path

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, nargs="+", required=True)
    parser.add_argument("--output", required=True)
    args = parser.parse_args(argv)
    data, columns, fpr = _load(args.runs)
    summary = pooled(data)
    results = {
        "datasets": len(data),
        "median": json.loads(summary["median"].to_json(orient="split")),
        "low": json.loads(summary["low"].to_json(orient="split")),
        "high": json.loads(summary["high"].to_json(orient="split")),
        "stability": stability(data),
        "hypotheses": hypotheses(data, columns),
        "fpr": {
            m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in fpr.items()
        },
    }
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / "typed_results.json").write_text(
        json.dumps(results, indent=1, sort_keys=True) + "\n"
    )
    lines = [f"Median recall over {len(data)} datasets (95% interval over datasets)", ""]
    kinds = list(summary["median"].columns)
    lines += ["| method | " + " | ".join(kinds) + " |", "|---|" + "---|" * len(kinds)]
    for method in summary["median"].index:
        cells = []
        for k in kinds:
            mid, lo, hi = (summary[n].loc[method, k] for n in ("median", "low", "high"))
            cells.append(f"{mid:.2f} [{lo:.2f}, {hi:.2f}]")
        lines.append(f"| {method} | " + " | ".join(cells) + " |")
    lines += ["", "Clean-row false positive rate (median and maximum over datasets)", ""]
    lines += [f"- {m}: {v['median']:.3f} (max {v['max']:.3f})" for m, v in results["fpr"].items()]
    (args.output / "typed_results.md").write_text("\n".join(lines) + "\n")
    print(f"{len(data)} datasets")
    return 0


def x_main__mutmut_20(argv: list[str] | None = None) -> int:
    import argparse
    import json
    from pathlib import Path

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, nargs="+", required=True)
    parser.add_argument("--output", type=Path, )
    args = parser.parse_args(argv)
    data, columns, fpr = _load(args.runs)
    summary = pooled(data)
    results = {
        "datasets": len(data),
        "median": json.loads(summary["median"].to_json(orient="split")),
        "low": json.loads(summary["low"].to_json(orient="split")),
        "high": json.loads(summary["high"].to_json(orient="split")),
        "stability": stability(data),
        "hypotheses": hypotheses(data, columns),
        "fpr": {
            m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in fpr.items()
        },
    }
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / "typed_results.json").write_text(
        json.dumps(results, indent=1, sort_keys=True) + "\n"
    )
    lines = [f"Median recall over {len(data)} datasets (95% interval over datasets)", ""]
    kinds = list(summary["median"].columns)
    lines += ["| method | " + " | ".join(kinds) + " |", "|---|" + "---|" * len(kinds)]
    for method in summary["median"].index:
        cells = []
        for k in kinds:
            mid, lo, hi = (summary[n].loc[method, k] for n in ("median", "low", "high"))
            cells.append(f"{mid:.2f} [{lo:.2f}, {hi:.2f}]")
        lines.append(f"| {method} | " + " | ".join(cells) + " |")
    lines += ["", "Clean-row false positive rate (median and maximum over datasets)", ""]
    lines += [f"- {m}: {v['median']:.3f} (max {v['max']:.3f})" for m, v in results["fpr"].items()]
    (args.output / "typed_results.md").write_text("\n".join(lines) + "\n")
    print(f"{len(data)} datasets")
    return 0


def x_main__mutmut_21(argv: list[str] | None = None) -> int:
    import argparse
    import json
    from pathlib import Path

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, nargs="+", required=True)
    parser.add_argument("XX--outputXX", type=Path, required=True)
    args = parser.parse_args(argv)
    data, columns, fpr = _load(args.runs)
    summary = pooled(data)
    results = {
        "datasets": len(data),
        "median": json.loads(summary["median"].to_json(orient="split")),
        "low": json.loads(summary["low"].to_json(orient="split")),
        "high": json.loads(summary["high"].to_json(orient="split")),
        "stability": stability(data),
        "hypotheses": hypotheses(data, columns),
        "fpr": {
            m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in fpr.items()
        },
    }
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / "typed_results.json").write_text(
        json.dumps(results, indent=1, sort_keys=True) + "\n"
    )
    lines = [f"Median recall over {len(data)} datasets (95% interval over datasets)", ""]
    kinds = list(summary["median"].columns)
    lines += ["| method | " + " | ".join(kinds) + " |", "|---|" + "---|" * len(kinds)]
    for method in summary["median"].index:
        cells = []
        for k in kinds:
            mid, lo, hi = (summary[n].loc[method, k] for n in ("median", "low", "high"))
            cells.append(f"{mid:.2f} [{lo:.2f}, {hi:.2f}]")
        lines.append(f"| {method} | " + " | ".join(cells) + " |")
    lines += ["", "Clean-row false positive rate (median and maximum over datasets)", ""]
    lines += [f"- {m}: {v['median']:.3f} (max {v['max']:.3f})" for m, v in results["fpr"].items()]
    (args.output / "typed_results.md").write_text("\n".join(lines) + "\n")
    print(f"{len(data)} datasets")
    return 0


def x_main__mutmut_22(argv: list[str] | None = None) -> int:
    import argparse
    import json
    from pathlib import Path

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, nargs="+", required=True)
    parser.add_argument("--OUTPUT", type=Path, required=True)
    args = parser.parse_args(argv)
    data, columns, fpr = _load(args.runs)
    summary = pooled(data)
    results = {
        "datasets": len(data),
        "median": json.loads(summary["median"].to_json(orient="split")),
        "low": json.loads(summary["low"].to_json(orient="split")),
        "high": json.loads(summary["high"].to_json(orient="split")),
        "stability": stability(data),
        "hypotheses": hypotheses(data, columns),
        "fpr": {
            m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in fpr.items()
        },
    }
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / "typed_results.json").write_text(
        json.dumps(results, indent=1, sort_keys=True) + "\n"
    )
    lines = [f"Median recall over {len(data)} datasets (95% interval over datasets)", ""]
    kinds = list(summary["median"].columns)
    lines += ["| method | " + " | ".join(kinds) + " |", "|---|" + "---|" * len(kinds)]
    for method in summary["median"].index:
        cells = []
        for k in kinds:
            mid, lo, hi = (summary[n].loc[method, k] for n in ("median", "low", "high"))
            cells.append(f"{mid:.2f} [{lo:.2f}, {hi:.2f}]")
        lines.append(f"| {method} | " + " | ".join(cells) + " |")
    lines += ["", "Clean-row false positive rate (median and maximum over datasets)", ""]
    lines += [f"- {m}: {v['median']:.3f} (max {v['max']:.3f})" for m, v in results["fpr"].items()]
    (args.output / "typed_results.md").write_text("\n".join(lines) + "\n")
    print(f"{len(data)} datasets")
    return 0


def x_main__mutmut_23(argv: list[str] | None = None) -> int:
    import argparse
    import json
    from pathlib import Path

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, nargs="+", required=True)
    parser.add_argument("--output", type=Path, required=False)
    args = parser.parse_args(argv)
    data, columns, fpr = _load(args.runs)
    summary = pooled(data)
    results = {
        "datasets": len(data),
        "median": json.loads(summary["median"].to_json(orient="split")),
        "low": json.loads(summary["low"].to_json(orient="split")),
        "high": json.loads(summary["high"].to_json(orient="split")),
        "stability": stability(data),
        "hypotheses": hypotheses(data, columns),
        "fpr": {
            m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in fpr.items()
        },
    }
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / "typed_results.json").write_text(
        json.dumps(results, indent=1, sort_keys=True) + "\n"
    )
    lines = [f"Median recall over {len(data)} datasets (95% interval over datasets)", ""]
    kinds = list(summary["median"].columns)
    lines += ["| method | " + " | ".join(kinds) + " |", "|---|" + "---|" * len(kinds)]
    for method in summary["median"].index:
        cells = []
        for k in kinds:
            mid, lo, hi = (summary[n].loc[method, k] for n in ("median", "low", "high"))
            cells.append(f"{mid:.2f} [{lo:.2f}, {hi:.2f}]")
        lines.append(f"| {method} | " + " | ".join(cells) + " |")
    lines += ["", "Clean-row false positive rate (median and maximum over datasets)", ""]
    lines += [f"- {m}: {v['median']:.3f} (max {v['max']:.3f})" for m, v in results["fpr"].items()]
    (args.output / "typed_results.md").write_text("\n".join(lines) + "\n")
    print(f"{len(data)} datasets")
    return 0


def x_main__mutmut_24(argv: list[str] | None = None) -> int:
    import argparse
    import json
    from pathlib import Path

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, nargs="+", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = None
    data, columns, fpr = _load(args.runs)
    summary = pooled(data)
    results = {
        "datasets": len(data),
        "median": json.loads(summary["median"].to_json(orient="split")),
        "low": json.loads(summary["low"].to_json(orient="split")),
        "high": json.loads(summary["high"].to_json(orient="split")),
        "stability": stability(data),
        "hypotheses": hypotheses(data, columns),
        "fpr": {
            m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in fpr.items()
        },
    }
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / "typed_results.json").write_text(
        json.dumps(results, indent=1, sort_keys=True) + "\n"
    )
    lines = [f"Median recall over {len(data)} datasets (95% interval over datasets)", ""]
    kinds = list(summary["median"].columns)
    lines += ["| method | " + " | ".join(kinds) + " |", "|---|" + "---|" * len(kinds)]
    for method in summary["median"].index:
        cells = []
        for k in kinds:
            mid, lo, hi = (summary[n].loc[method, k] for n in ("median", "low", "high"))
            cells.append(f"{mid:.2f} [{lo:.2f}, {hi:.2f}]")
        lines.append(f"| {method} | " + " | ".join(cells) + " |")
    lines += ["", "Clean-row false positive rate (median and maximum over datasets)", ""]
    lines += [f"- {m}: {v['median']:.3f} (max {v['max']:.3f})" for m, v in results["fpr"].items()]
    (args.output / "typed_results.md").write_text("\n".join(lines) + "\n")
    print(f"{len(data)} datasets")
    return 0


def x_main__mutmut_25(argv: list[str] | None = None) -> int:
    import argparse
    import json
    from pathlib import Path

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, nargs="+", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(None)
    data, columns, fpr = _load(args.runs)
    summary = pooled(data)
    results = {
        "datasets": len(data),
        "median": json.loads(summary["median"].to_json(orient="split")),
        "low": json.loads(summary["low"].to_json(orient="split")),
        "high": json.loads(summary["high"].to_json(orient="split")),
        "stability": stability(data),
        "hypotheses": hypotheses(data, columns),
        "fpr": {
            m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in fpr.items()
        },
    }
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / "typed_results.json").write_text(
        json.dumps(results, indent=1, sort_keys=True) + "\n"
    )
    lines = [f"Median recall over {len(data)} datasets (95% interval over datasets)", ""]
    kinds = list(summary["median"].columns)
    lines += ["| method | " + " | ".join(kinds) + " |", "|---|" + "---|" * len(kinds)]
    for method in summary["median"].index:
        cells = []
        for k in kinds:
            mid, lo, hi = (summary[n].loc[method, k] for n in ("median", "low", "high"))
            cells.append(f"{mid:.2f} [{lo:.2f}, {hi:.2f}]")
        lines.append(f"| {method} | " + " | ".join(cells) + " |")
    lines += ["", "Clean-row false positive rate (median and maximum over datasets)", ""]
    lines += [f"- {m}: {v['median']:.3f} (max {v['max']:.3f})" for m, v in results["fpr"].items()]
    (args.output / "typed_results.md").write_text("\n".join(lines) + "\n")
    print(f"{len(data)} datasets")
    return 0


def x_main__mutmut_26(argv: list[str] | None = None) -> int:
    import argparse
    import json
    from pathlib import Path

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, nargs="+", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    data, columns, fpr = None
    summary = pooled(data)
    results = {
        "datasets": len(data),
        "median": json.loads(summary["median"].to_json(orient="split")),
        "low": json.loads(summary["low"].to_json(orient="split")),
        "high": json.loads(summary["high"].to_json(orient="split")),
        "stability": stability(data),
        "hypotheses": hypotheses(data, columns),
        "fpr": {
            m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in fpr.items()
        },
    }
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / "typed_results.json").write_text(
        json.dumps(results, indent=1, sort_keys=True) + "\n"
    )
    lines = [f"Median recall over {len(data)} datasets (95% interval over datasets)", ""]
    kinds = list(summary["median"].columns)
    lines += ["| method | " + " | ".join(kinds) + " |", "|---|" + "---|" * len(kinds)]
    for method in summary["median"].index:
        cells = []
        for k in kinds:
            mid, lo, hi = (summary[n].loc[method, k] for n in ("median", "low", "high"))
            cells.append(f"{mid:.2f} [{lo:.2f}, {hi:.2f}]")
        lines.append(f"| {method} | " + " | ".join(cells) + " |")
    lines += ["", "Clean-row false positive rate (median and maximum over datasets)", ""]
    lines += [f"- {m}: {v['median']:.3f} (max {v['max']:.3f})" for m, v in results["fpr"].items()]
    (args.output / "typed_results.md").write_text("\n".join(lines) + "\n")
    print(f"{len(data)} datasets")
    return 0


def x_main__mutmut_27(argv: list[str] | None = None) -> int:
    import argparse
    import json
    from pathlib import Path

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, nargs="+", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    data, columns, fpr = _load(None)
    summary = pooled(data)
    results = {
        "datasets": len(data),
        "median": json.loads(summary["median"].to_json(orient="split")),
        "low": json.loads(summary["low"].to_json(orient="split")),
        "high": json.loads(summary["high"].to_json(orient="split")),
        "stability": stability(data),
        "hypotheses": hypotheses(data, columns),
        "fpr": {
            m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in fpr.items()
        },
    }
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / "typed_results.json").write_text(
        json.dumps(results, indent=1, sort_keys=True) + "\n"
    )
    lines = [f"Median recall over {len(data)} datasets (95% interval over datasets)", ""]
    kinds = list(summary["median"].columns)
    lines += ["| method | " + " | ".join(kinds) + " |", "|---|" + "---|" * len(kinds)]
    for method in summary["median"].index:
        cells = []
        for k in kinds:
            mid, lo, hi = (summary[n].loc[method, k] for n in ("median", "low", "high"))
            cells.append(f"{mid:.2f} [{lo:.2f}, {hi:.2f}]")
        lines.append(f"| {method} | " + " | ".join(cells) + " |")
    lines += ["", "Clean-row false positive rate (median and maximum over datasets)", ""]
    lines += [f"- {m}: {v['median']:.3f} (max {v['max']:.3f})" for m, v in results["fpr"].items()]
    (args.output / "typed_results.md").write_text("\n".join(lines) + "\n")
    print(f"{len(data)} datasets")
    return 0


def x_main__mutmut_28(argv: list[str] | None = None) -> int:
    import argparse
    import json
    from pathlib import Path

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, nargs="+", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    data, columns, fpr = _load(args.runs)
    summary = None
    results = {
        "datasets": len(data),
        "median": json.loads(summary["median"].to_json(orient="split")),
        "low": json.loads(summary["low"].to_json(orient="split")),
        "high": json.loads(summary["high"].to_json(orient="split")),
        "stability": stability(data),
        "hypotheses": hypotheses(data, columns),
        "fpr": {
            m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in fpr.items()
        },
    }
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / "typed_results.json").write_text(
        json.dumps(results, indent=1, sort_keys=True) + "\n"
    )
    lines = [f"Median recall over {len(data)} datasets (95% interval over datasets)", ""]
    kinds = list(summary["median"].columns)
    lines += ["| method | " + " | ".join(kinds) + " |", "|---|" + "---|" * len(kinds)]
    for method in summary["median"].index:
        cells = []
        for k in kinds:
            mid, lo, hi = (summary[n].loc[method, k] for n in ("median", "low", "high"))
            cells.append(f"{mid:.2f} [{lo:.2f}, {hi:.2f}]")
        lines.append(f"| {method} | " + " | ".join(cells) + " |")
    lines += ["", "Clean-row false positive rate (median and maximum over datasets)", ""]
    lines += [f"- {m}: {v['median']:.3f} (max {v['max']:.3f})" for m, v in results["fpr"].items()]
    (args.output / "typed_results.md").write_text("\n".join(lines) + "\n")
    print(f"{len(data)} datasets")
    return 0


def x_main__mutmut_29(argv: list[str] | None = None) -> int:
    import argparse
    import json
    from pathlib import Path

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, nargs="+", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    data, columns, fpr = _load(args.runs)
    summary = pooled(None)
    results = {
        "datasets": len(data),
        "median": json.loads(summary["median"].to_json(orient="split")),
        "low": json.loads(summary["low"].to_json(orient="split")),
        "high": json.loads(summary["high"].to_json(orient="split")),
        "stability": stability(data),
        "hypotheses": hypotheses(data, columns),
        "fpr": {
            m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in fpr.items()
        },
    }
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / "typed_results.json").write_text(
        json.dumps(results, indent=1, sort_keys=True) + "\n"
    )
    lines = [f"Median recall over {len(data)} datasets (95% interval over datasets)", ""]
    kinds = list(summary["median"].columns)
    lines += ["| method | " + " | ".join(kinds) + " |", "|---|" + "---|" * len(kinds)]
    for method in summary["median"].index:
        cells = []
        for k in kinds:
            mid, lo, hi = (summary[n].loc[method, k] for n in ("median", "low", "high"))
            cells.append(f"{mid:.2f} [{lo:.2f}, {hi:.2f}]")
        lines.append(f"| {method} | " + " | ".join(cells) + " |")
    lines += ["", "Clean-row false positive rate (median and maximum over datasets)", ""]
    lines += [f"- {m}: {v['median']:.3f} (max {v['max']:.3f})" for m, v in results["fpr"].items()]
    (args.output / "typed_results.md").write_text("\n".join(lines) + "\n")
    print(f"{len(data)} datasets")
    return 0


def x_main__mutmut_30(argv: list[str] | None = None) -> int:
    import argparse
    import json
    from pathlib import Path

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, nargs="+", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    data, columns, fpr = _load(args.runs)
    summary = pooled(data)
    results = None
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / "typed_results.json").write_text(
        json.dumps(results, indent=1, sort_keys=True) + "\n"
    )
    lines = [f"Median recall over {len(data)} datasets (95% interval over datasets)", ""]
    kinds = list(summary["median"].columns)
    lines += ["| method | " + " | ".join(kinds) + " |", "|---|" + "---|" * len(kinds)]
    for method in summary["median"].index:
        cells = []
        for k in kinds:
            mid, lo, hi = (summary[n].loc[method, k] for n in ("median", "low", "high"))
            cells.append(f"{mid:.2f} [{lo:.2f}, {hi:.2f}]")
        lines.append(f"| {method} | " + " | ".join(cells) + " |")
    lines += ["", "Clean-row false positive rate (median and maximum over datasets)", ""]
    lines += [f"- {m}: {v['median']:.3f} (max {v['max']:.3f})" for m, v in results["fpr"].items()]
    (args.output / "typed_results.md").write_text("\n".join(lines) + "\n")
    print(f"{len(data)} datasets")
    return 0


def x_main__mutmut_31(argv: list[str] | None = None) -> int:
    import argparse
    import json
    from pathlib import Path

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, nargs="+", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    data, columns, fpr = _load(args.runs)
    summary = pooled(data)
    results = {
        "XXdatasetsXX": len(data),
        "median": json.loads(summary["median"].to_json(orient="split")),
        "low": json.loads(summary["low"].to_json(orient="split")),
        "high": json.loads(summary["high"].to_json(orient="split")),
        "stability": stability(data),
        "hypotheses": hypotheses(data, columns),
        "fpr": {
            m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in fpr.items()
        },
    }
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / "typed_results.json").write_text(
        json.dumps(results, indent=1, sort_keys=True) + "\n"
    )
    lines = [f"Median recall over {len(data)} datasets (95% interval over datasets)", ""]
    kinds = list(summary["median"].columns)
    lines += ["| method | " + " | ".join(kinds) + " |", "|---|" + "---|" * len(kinds)]
    for method in summary["median"].index:
        cells = []
        for k in kinds:
            mid, lo, hi = (summary[n].loc[method, k] for n in ("median", "low", "high"))
            cells.append(f"{mid:.2f} [{lo:.2f}, {hi:.2f}]")
        lines.append(f"| {method} | " + " | ".join(cells) + " |")
    lines += ["", "Clean-row false positive rate (median and maximum over datasets)", ""]
    lines += [f"- {m}: {v['median']:.3f} (max {v['max']:.3f})" for m, v in results["fpr"].items()]
    (args.output / "typed_results.md").write_text("\n".join(lines) + "\n")
    print(f"{len(data)} datasets")
    return 0


def x_main__mutmut_32(argv: list[str] | None = None) -> int:
    import argparse
    import json
    from pathlib import Path

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, nargs="+", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    data, columns, fpr = _load(args.runs)
    summary = pooled(data)
    results = {
        "DATASETS": len(data),
        "median": json.loads(summary["median"].to_json(orient="split")),
        "low": json.loads(summary["low"].to_json(orient="split")),
        "high": json.loads(summary["high"].to_json(orient="split")),
        "stability": stability(data),
        "hypotheses": hypotheses(data, columns),
        "fpr": {
            m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in fpr.items()
        },
    }
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / "typed_results.json").write_text(
        json.dumps(results, indent=1, sort_keys=True) + "\n"
    )
    lines = [f"Median recall over {len(data)} datasets (95% interval over datasets)", ""]
    kinds = list(summary["median"].columns)
    lines += ["| method | " + " | ".join(kinds) + " |", "|---|" + "---|" * len(kinds)]
    for method in summary["median"].index:
        cells = []
        for k in kinds:
            mid, lo, hi = (summary[n].loc[method, k] for n in ("median", "low", "high"))
            cells.append(f"{mid:.2f} [{lo:.2f}, {hi:.2f}]")
        lines.append(f"| {method} | " + " | ".join(cells) + " |")
    lines += ["", "Clean-row false positive rate (median and maximum over datasets)", ""]
    lines += [f"- {m}: {v['median']:.3f} (max {v['max']:.3f})" for m, v in results["fpr"].items()]
    (args.output / "typed_results.md").write_text("\n".join(lines) + "\n")
    print(f"{len(data)} datasets")
    return 0


def x_main__mutmut_33(argv: list[str] | None = None) -> int:
    import argparse
    import json
    from pathlib import Path

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, nargs="+", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    data, columns, fpr = _load(args.runs)
    summary = pooled(data)
    results = {
        "datasets": len(data),
        "XXmedianXX": json.loads(summary["median"].to_json(orient="split")),
        "low": json.loads(summary["low"].to_json(orient="split")),
        "high": json.loads(summary["high"].to_json(orient="split")),
        "stability": stability(data),
        "hypotheses": hypotheses(data, columns),
        "fpr": {
            m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in fpr.items()
        },
    }
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / "typed_results.json").write_text(
        json.dumps(results, indent=1, sort_keys=True) + "\n"
    )
    lines = [f"Median recall over {len(data)} datasets (95% interval over datasets)", ""]
    kinds = list(summary["median"].columns)
    lines += ["| method | " + " | ".join(kinds) + " |", "|---|" + "---|" * len(kinds)]
    for method in summary["median"].index:
        cells = []
        for k in kinds:
            mid, lo, hi = (summary[n].loc[method, k] for n in ("median", "low", "high"))
            cells.append(f"{mid:.2f} [{lo:.2f}, {hi:.2f}]")
        lines.append(f"| {method} | " + " | ".join(cells) + " |")
    lines += ["", "Clean-row false positive rate (median and maximum over datasets)", ""]
    lines += [f"- {m}: {v['median']:.3f} (max {v['max']:.3f})" for m, v in results["fpr"].items()]
    (args.output / "typed_results.md").write_text("\n".join(lines) + "\n")
    print(f"{len(data)} datasets")
    return 0


def x_main__mutmut_34(argv: list[str] | None = None) -> int:
    import argparse
    import json
    from pathlib import Path

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, nargs="+", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    data, columns, fpr = _load(args.runs)
    summary = pooled(data)
    results = {
        "datasets": len(data),
        "MEDIAN": json.loads(summary["median"].to_json(orient="split")),
        "low": json.loads(summary["low"].to_json(orient="split")),
        "high": json.loads(summary["high"].to_json(orient="split")),
        "stability": stability(data),
        "hypotheses": hypotheses(data, columns),
        "fpr": {
            m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in fpr.items()
        },
    }
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / "typed_results.json").write_text(
        json.dumps(results, indent=1, sort_keys=True) + "\n"
    )
    lines = [f"Median recall over {len(data)} datasets (95% interval over datasets)", ""]
    kinds = list(summary["median"].columns)
    lines += ["| method | " + " | ".join(kinds) + " |", "|---|" + "---|" * len(kinds)]
    for method in summary["median"].index:
        cells = []
        for k in kinds:
            mid, lo, hi = (summary[n].loc[method, k] for n in ("median", "low", "high"))
            cells.append(f"{mid:.2f} [{lo:.2f}, {hi:.2f}]")
        lines.append(f"| {method} | " + " | ".join(cells) + " |")
    lines += ["", "Clean-row false positive rate (median and maximum over datasets)", ""]
    lines += [f"- {m}: {v['median']:.3f} (max {v['max']:.3f})" for m, v in results["fpr"].items()]
    (args.output / "typed_results.md").write_text("\n".join(lines) + "\n")
    print(f"{len(data)} datasets")
    return 0


def x_main__mutmut_35(argv: list[str] | None = None) -> int:
    import argparse
    import json
    from pathlib import Path

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, nargs="+", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    data, columns, fpr = _load(args.runs)
    summary = pooled(data)
    results = {
        "datasets": len(data),
        "median": json.loads(None),
        "low": json.loads(summary["low"].to_json(orient="split")),
        "high": json.loads(summary["high"].to_json(orient="split")),
        "stability": stability(data),
        "hypotheses": hypotheses(data, columns),
        "fpr": {
            m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in fpr.items()
        },
    }
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / "typed_results.json").write_text(
        json.dumps(results, indent=1, sort_keys=True) + "\n"
    )
    lines = [f"Median recall over {len(data)} datasets (95% interval over datasets)", ""]
    kinds = list(summary["median"].columns)
    lines += ["| method | " + " | ".join(kinds) + " |", "|---|" + "---|" * len(kinds)]
    for method in summary["median"].index:
        cells = []
        for k in kinds:
            mid, lo, hi = (summary[n].loc[method, k] for n in ("median", "low", "high"))
            cells.append(f"{mid:.2f} [{lo:.2f}, {hi:.2f}]")
        lines.append(f"| {method} | " + " | ".join(cells) + " |")
    lines += ["", "Clean-row false positive rate (median and maximum over datasets)", ""]
    lines += [f"- {m}: {v['median']:.3f} (max {v['max']:.3f})" for m, v in results["fpr"].items()]
    (args.output / "typed_results.md").write_text("\n".join(lines) + "\n")
    print(f"{len(data)} datasets")
    return 0


def x_main__mutmut_36(argv: list[str] | None = None) -> int:
    import argparse
    import json
    from pathlib import Path

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, nargs="+", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    data, columns, fpr = _load(args.runs)
    summary = pooled(data)
    results = {
        "datasets": len(data),
        "median": json.loads(summary["median"].to_json(orient=None)),
        "low": json.loads(summary["low"].to_json(orient="split")),
        "high": json.loads(summary["high"].to_json(orient="split")),
        "stability": stability(data),
        "hypotheses": hypotheses(data, columns),
        "fpr": {
            m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in fpr.items()
        },
    }
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / "typed_results.json").write_text(
        json.dumps(results, indent=1, sort_keys=True) + "\n"
    )
    lines = [f"Median recall over {len(data)} datasets (95% interval over datasets)", ""]
    kinds = list(summary["median"].columns)
    lines += ["| method | " + " | ".join(kinds) + " |", "|---|" + "---|" * len(kinds)]
    for method in summary["median"].index:
        cells = []
        for k in kinds:
            mid, lo, hi = (summary[n].loc[method, k] for n in ("median", "low", "high"))
            cells.append(f"{mid:.2f} [{lo:.2f}, {hi:.2f}]")
        lines.append(f"| {method} | " + " | ".join(cells) + " |")
    lines += ["", "Clean-row false positive rate (median and maximum over datasets)", ""]
    lines += [f"- {m}: {v['median']:.3f} (max {v['max']:.3f})" for m, v in results["fpr"].items()]
    (args.output / "typed_results.md").write_text("\n".join(lines) + "\n")
    print(f"{len(data)} datasets")
    return 0


def x_main__mutmut_37(argv: list[str] | None = None) -> int:
    import argparse
    import json
    from pathlib import Path

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, nargs="+", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    data, columns, fpr = _load(args.runs)
    summary = pooled(data)
    results = {
        "datasets": len(data),
        "median": json.loads(summary["XXmedianXX"].to_json(orient="split")),
        "low": json.loads(summary["low"].to_json(orient="split")),
        "high": json.loads(summary["high"].to_json(orient="split")),
        "stability": stability(data),
        "hypotheses": hypotheses(data, columns),
        "fpr": {
            m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in fpr.items()
        },
    }
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / "typed_results.json").write_text(
        json.dumps(results, indent=1, sort_keys=True) + "\n"
    )
    lines = [f"Median recall over {len(data)} datasets (95% interval over datasets)", ""]
    kinds = list(summary["median"].columns)
    lines += ["| method | " + " | ".join(kinds) + " |", "|---|" + "---|" * len(kinds)]
    for method in summary["median"].index:
        cells = []
        for k in kinds:
            mid, lo, hi = (summary[n].loc[method, k] for n in ("median", "low", "high"))
            cells.append(f"{mid:.2f} [{lo:.2f}, {hi:.2f}]")
        lines.append(f"| {method} | " + " | ".join(cells) + " |")
    lines += ["", "Clean-row false positive rate (median and maximum over datasets)", ""]
    lines += [f"- {m}: {v['median']:.3f} (max {v['max']:.3f})" for m, v in results["fpr"].items()]
    (args.output / "typed_results.md").write_text("\n".join(lines) + "\n")
    print(f"{len(data)} datasets")
    return 0


def x_main__mutmut_38(argv: list[str] | None = None) -> int:
    import argparse
    import json
    from pathlib import Path

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, nargs="+", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    data, columns, fpr = _load(args.runs)
    summary = pooled(data)
    results = {
        "datasets": len(data),
        "median": json.loads(summary["MEDIAN"].to_json(orient="split")),
        "low": json.loads(summary["low"].to_json(orient="split")),
        "high": json.loads(summary["high"].to_json(orient="split")),
        "stability": stability(data),
        "hypotheses": hypotheses(data, columns),
        "fpr": {
            m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in fpr.items()
        },
    }
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / "typed_results.json").write_text(
        json.dumps(results, indent=1, sort_keys=True) + "\n"
    )
    lines = [f"Median recall over {len(data)} datasets (95% interval over datasets)", ""]
    kinds = list(summary["median"].columns)
    lines += ["| method | " + " | ".join(kinds) + " |", "|---|" + "---|" * len(kinds)]
    for method in summary["median"].index:
        cells = []
        for k in kinds:
            mid, lo, hi = (summary[n].loc[method, k] for n in ("median", "low", "high"))
            cells.append(f"{mid:.2f} [{lo:.2f}, {hi:.2f}]")
        lines.append(f"| {method} | " + " | ".join(cells) + " |")
    lines += ["", "Clean-row false positive rate (median and maximum over datasets)", ""]
    lines += [f"- {m}: {v['median']:.3f} (max {v['max']:.3f})" for m, v in results["fpr"].items()]
    (args.output / "typed_results.md").write_text("\n".join(lines) + "\n")
    print(f"{len(data)} datasets")
    return 0


def x_main__mutmut_39(argv: list[str] | None = None) -> int:
    import argparse
    import json
    from pathlib import Path

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, nargs="+", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    data, columns, fpr = _load(args.runs)
    summary = pooled(data)
    results = {
        "datasets": len(data),
        "median": json.loads(summary["median"].to_json(orient="XXsplitXX")),
        "low": json.loads(summary["low"].to_json(orient="split")),
        "high": json.loads(summary["high"].to_json(orient="split")),
        "stability": stability(data),
        "hypotheses": hypotheses(data, columns),
        "fpr": {
            m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in fpr.items()
        },
    }
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / "typed_results.json").write_text(
        json.dumps(results, indent=1, sort_keys=True) + "\n"
    )
    lines = [f"Median recall over {len(data)} datasets (95% interval over datasets)", ""]
    kinds = list(summary["median"].columns)
    lines += ["| method | " + " | ".join(kinds) + " |", "|---|" + "---|" * len(kinds)]
    for method in summary["median"].index:
        cells = []
        for k in kinds:
            mid, lo, hi = (summary[n].loc[method, k] for n in ("median", "low", "high"))
            cells.append(f"{mid:.2f} [{lo:.2f}, {hi:.2f}]")
        lines.append(f"| {method} | " + " | ".join(cells) + " |")
    lines += ["", "Clean-row false positive rate (median and maximum over datasets)", ""]
    lines += [f"- {m}: {v['median']:.3f} (max {v['max']:.3f})" for m, v in results["fpr"].items()]
    (args.output / "typed_results.md").write_text("\n".join(lines) + "\n")
    print(f"{len(data)} datasets")
    return 0


def x_main__mutmut_40(argv: list[str] | None = None) -> int:
    import argparse
    import json
    from pathlib import Path

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, nargs="+", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    data, columns, fpr = _load(args.runs)
    summary = pooled(data)
    results = {
        "datasets": len(data),
        "median": json.loads(summary["median"].to_json(orient="SPLIT")),
        "low": json.loads(summary["low"].to_json(orient="split")),
        "high": json.loads(summary["high"].to_json(orient="split")),
        "stability": stability(data),
        "hypotheses": hypotheses(data, columns),
        "fpr": {
            m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in fpr.items()
        },
    }
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / "typed_results.json").write_text(
        json.dumps(results, indent=1, sort_keys=True) + "\n"
    )
    lines = [f"Median recall over {len(data)} datasets (95% interval over datasets)", ""]
    kinds = list(summary["median"].columns)
    lines += ["| method | " + " | ".join(kinds) + " |", "|---|" + "---|" * len(kinds)]
    for method in summary["median"].index:
        cells = []
        for k in kinds:
            mid, lo, hi = (summary[n].loc[method, k] for n in ("median", "low", "high"))
            cells.append(f"{mid:.2f} [{lo:.2f}, {hi:.2f}]")
        lines.append(f"| {method} | " + " | ".join(cells) + " |")
    lines += ["", "Clean-row false positive rate (median and maximum over datasets)", ""]
    lines += [f"- {m}: {v['median']:.3f} (max {v['max']:.3f})" for m, v in results["fpr"].items()]
    (args.output / "typed_results.md").write_text("\n".join(lines) + "\n")
    print(f"{len(data)} datasets")
    return 0


def x_main__mutmut_41(argv: list[str] | None = None) -> int:
    import argparse
    import json
    from pathlib import Path

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, nargs="+", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    data, columns, fpr = _load(args.runs)
    summary = pooled(data)
    results = {
        "datasets": len(data),
        "median": json.loads(summary["median"].to_json(orient="split")),
        "XXlowXX": json.loads(summary["low"].to_json(orient="split")),
        "high": json.loads(summary["high"].to_json(orient="split")),
        "stability": stability(data),
        "hypotheses": hypotheses(data, columns),
        "fpr": {
            m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in fpr.items()
        },
    }
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / "typed_results.json").write_text(
        json.dumps(results, indent=1, sort_keys=True) + "\n"
    )
    lines = [f"Median recall over {len(data)} datasets (95% interval over datasets)", ""]
    kinds = list(summary["median"].columns)
    lines += ["| method | " + " | ".join(kinds) + " |", "|---|" + "---|" * len(kinds)]
    for method in summary["median"].index:
        cells = []
        for k in kinds:
            mid, lo, hi = (summary[n].loc[method, k] for n in ("median", "low", "high"))
            cells.append(f"{mid:.2f} [{lo:.2f}, {hi:.2f}]")
        lines.append(f"| {method} | " + " | ".join(cells) + " |")
    lines += ["", "Clean-row false positive rate (median and maximum over datasets)", ""]
    lines += [f"- {m}: {v['median']:.3f} (max {v['max']:.3f})" for m, v in results["fpr"].items()]
    (args.output / "typed_results.md").write_text("\n".join(lines) + "\n")
    print(f"{len(data)} datasets")
    return 0


def x_main__mutmut_42(argv: list[str] | None = None) -> int:
    import argparse
    import json
    from pathlib import Path

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, nargs="+", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    data, columns, fpr = _load(args.runs)
    summary = pooled(data)
    results = {
        "datasets": len(data),
        "median": json.loads(summary["median"].to_json(orient="split")),
        "LOW": json.loads(summary["low"].to_json(orient="split")),
        "high": json.loads(summary["high"].to_json(orient="split")),
        "stability": stability(data),
        "hypotheses": hypotheses(data, columns),
        "fpr": {
            m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in fpr.items()
        },
    }
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / "typed_results.json").write_text(
        json.dumps(results, indent=1, sort_keys=True) + "\n"
    )
    lines = [f"Median recall over {len(data)} datasets (95% interval over datasets)", ""]
    kinds = list(summary["median"].columns)
    lines += ["| method | " + " | ".join(kinds) + " |", "|---|" + "---|" * len(kinds)]
    for method in summary["median"].index:
        cells = []
        for k in kinds:
            mid, lo, hi = (summary[n].loc[method, k] for n in ("median", "low", "high"))
            cells.append(f"{mid:.2f} [{lo:.2f}, {hi:.2f}]")
        lines.append(f"| {method} | " + " | ".join(cells) + " |")
    lines += ["", "Clean-row false positive rate (median and maximum over datasets)", ""]
    lines += [f"- {m}: {v['median']:.3f} (max {v['max']:.3f})" for m, v in results["fpr"].items()]
    (args.output / "typed_results.md").write_text("\n".join(lines) + "\n")
    print(f"{len(data)} datasets")
    return 0


def x_main__mutmut_43(argv: list[str] | None = None) -> int:
    import argparse
    import json
    from pathlib import Path

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, nargs="+", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    data, columns, fpr = _load(args.runs)
    summary = pooled(data)
    results = {
        "datasets": len(data),
        "median": json.loads(summary["median"].to_json(orient="split")),
        "low": json.loads(None),
        "high": json.loads(summary["high"].to_json(orient="split")),
        "stability": stability(data),
        "hypotheses": hypotheses(data, columns),
        "fpr": {
            m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in fpr.items()
        },
    }
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / "typed_results.json").write_text(
        json.dumps(results, indent=1, sort_keys=True) + "\n"
    )
    lines = [f"Median recall over {len(data)} datasets (95% interval over datasets)", ""]
    kinds = list(summary["median"].columns)
    lines += ["| method | " + " | ".join(kinds) + " |", "|---|" + "---|" * len(kinds)]
    for method in summary["median"].index:
        cells = []
        for k in kinds:
            mid, lo, hi = (summary[n].loc[method, k] for n in ("median", "low", "high"))
            cells.append(f"{mid:.2f} [{lo:.2f}, {hi:.2f}]")
        lines.append(f"| {method} | " + " | ".join(cells) + " |")
    lines += ["", "Clean-row false positive rate (median and maximum over datasets)", ""]
    lines += [f"- {m}: {v['median']:.3f} (max {v['max']:.3f})" for m, v in results["fpr"].items()]
    (args.output / "typed_results.md").write_text("\n".join(lines) + "\n")
    print(f"{len(data)} datasets")
    return 0


def x_main__mutmut_44(argv: list[str] | None = None) -> int:
    import argparse
    import json
    from pathlib import Path

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, nargs="+", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    data, columns, fpr = _load(args.runs)
    summary = pooled(data)
    results = {
        "datasets": len(data),
        "median": json.loads(summary["median"].to_json(orient="split")),
        "low": json.loads(summary["low"].to_json(orient=None)),
        "high": json.loads(summary["high"].to_json(orient="split")),
        "stability": stability(data),
        "hypotheses": hypotheses(data, columns),
        "fpr": {
            m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in fpr.items()
        },
    }
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / "typed_results.json").write_text(
        json.dumps(results, indent=1, sort_keys=True) + "\n"
    )
    lines = [f"Median recall over {len(data)} datasets (95% interval over datasets)", ""]
    kinds = list(summary["median"].columns)
    lines += ["| method | " + " | ".join(kinds) + " |", "|---|" + "---|" * len(kinds)]
    for method in summary["median"].index:
        cells = []
        for k in kinds:
            mid, lo, hi = (summary[n].loc[method, k] for n in ("median", "low", "high"))
            cells.append(f"{mid:.2f} [{lo:.2f}, {hi:.2f}]")
        lines.append(f"| {method} | " + " | ".join(cells) + " |")
    lines += ["", "Clean-row false positive rate (median and maximum over datasets)", ""]
    lines += [f"- {m}: {v['median']:.3f} (max {v['max']:.3f})" for m, v in results["fpr"].items()]
    (args.output / "typed_results.md").write_text("\n".join(lines) + "\n")
    print(f"{len(data)} datasets")
    return 0


def x_main__mutmut_45(argv: list[str] | None = None) -> int:
    import argparse
    import json
    from pathlib import Path

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, nargs="+", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    data, columns, fpr = _load(args.runs)
    summary = pooled(data)
    results = {
        "datasets": len(data),
        "median": json.loads(summary["median"].to_json(orient="split")),
        "low": json.loads(summary["XXlowXX"].to_json(orient="split")),
        "high": json.loads(summary["high"].to_json(orient="split")),
        "stability": stability(data),
        "hypotheses": hypotheses(data, columns),
        "fpr": {
            m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in fpr.items()
        },
    }
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / "typed_results.json").write_text(
        json.dumps(results, indent=1, sort_keys=True) + "\n"
    )
    lines = [f"Median recall over {len(data)} datasets (95% interval over datasets)", ""]
    kinds = list(summary["median"].columns)
    lines += ["| method | " + " | ".join(kinds) + " |", "|---|" + "---|" * len(kinds)]
    for method in summary["median"].index:
        cells = []
        for k in kinds:
            mid, lo, hi = (summary[n].loc[method, k] for n in ("median", "low", "high"))
            cells.append(f"{mid:.2f} [{lo:.2f}, {hi:.2f}]")
        lines.append(f"| {method} | " + " | ".join(cells) + " |")
    lines += ["", "Clean-row false positive rate (median and maximum over datasets)", ""]
    lines += [f"- {m}: {v['median']:.3f} (max {v['max']:.3f})" for m, v in results["fpr"].items()]
    (args.output / "typed_results.md").write_text("\n".join(lines) + "\n")
    print(f"{len(data)} datasets")
    return 0


def x_main__mutmut_46(argv: list[str] | None = None) -> int:
    import argparse
    import json
    from pathlib import Path

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, nargs="+", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    data, columns, fpr = _load(args.runs)
    summary = pooled(data)
    results = {
        "datasets": len(data),
        "median": json.loads(summary["median"].to_json(orient="split")),
        "low": json.loads(summary["LOW"].to_json(orient="split")),
        "high": json.loads(summary["high"].to_json(orient="split")),
        "stability": stability(data),
        "hypotheses": hypotheses(data, columns),
        "fpr": {
            m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in fpr.items()
        },
    }
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / "typed_results.json").write_text(
        json.dumps(results, indent=1, sort_keys=True) + "\n"
    )
    lines = [f"Median recall over {len(data)} datasets (95% interval over datasets)", ""]
    kinds = list(summary["median"].columns)
    lines += ["| method | " + " | ".join(kinds) + " |", "|---|" + "---|" * len(kinds)]
    for method in summary["median"].index:
        cells = []
        for k in kinds:
            mid, lo, hi = (summary[n].loc[method, k] for n in ("median", "low", "high"))
            cells.append(f"{mid:.2f} [{lo:.2f}, {hi:.2f}]")
        lines.append(f"| {method} | " + " | ".join(cells) + " |")
    lines += ["", "Clean-row false positive rate (median and maximum over datasets)", ""]
    lines += [f"- {m}: {v['median']:.3f} (max {v['max']:.3f})" for m, v in results["fpr"].items()]
    (args.output / "typed_results.md").write_text("\n".join(lines) + "\n")
    print(f"{len(data)} datasets")
    return 0


def x_main__mutmut_47(argv: list[str] | None = None) -> int:
    import argparse
    import json
    from pathlib import Path

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, nargs="+", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    data, columns, fpr = _load(args.runs)
    summary = pooled(data)
    results = {
        "datasets": len(data),
        "median": json.loads(summary["median"].to_json(orient="split")),
        "low": json.loads(summary["low"].to_json(orient="XXsplitXX")),
        "high": json.loads(summary["high"].to_json(orient="split")),
        "stability": stability(data),
        "hypotheses": hypotheses(data, columns),
        "fpr": {
            m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in fpr.items()
        },
    }
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / "typed_results.json").write_text(
        json.dumps(results, indent=1, sort_keys=True) + "\n"
    )
    lines = [f"Median recall over {len(data)} datasets (95% interval over datasets)", ""]
    kinds = list(summary["median"].columns)
    lines += ["| method | " + " | ".join(kinds) + " |", "|---|" + "---|" * len(kinds)]
    for method in summary["median"].index:
        cells = []
        for k in kinds:
            mid, lo, hi = (summary[n].loc[method, k] for n in ("median", "low", "high"))
            cells.append(f"{mid:.2f} [{lo:.2f}, {hi:.2f}]")
        lines.append(f"| {method} | " + " | ".join(cells) + " |")
    lines += ["", "Clean-row false positive rate (median and maximum over datasets)", ""]
    lines += [f"- {m}: {v['median']:.3f} (max {v['max']:.3f})" for m, v in results["fpr"].items()]
    (args.output / "typed_results.md").write_text("\n".join(lines) + "\n")
    print(f"{len(data)} datasets")
    return 0


def x_main__mutmut_48(argv: list[str] | None = None) -> int:
    import argparse
    import json
    from pathlib import Path

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, nargs="+", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    data, columns, fpr = _load(args.runs)
    summary = pooled(data)
    results = {
        "datasets": len(data),
        "median": json.loads(summary["median"].to_json(orient="split")),
        "low": json.loads(summary["low"].to_json(orient="SPLIT")),
        "high": json.loads(summary["high"].to_json(orient="split")),
        "stability": stability(data),
        "hypotheses": hypotheses(data, columns),
        "fpr": {
            m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in fpr.items()
        },
    }
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / "typed_results.json").write_text(
        json.dumps(results, indent=1, sort_keys=True) + "\n"
    )
    lines = [f"Median recall over {len(data)} datasets (95% interval over datasets)", ""]
    kinds = list(summary["median"].columns)
    lines += ["| method | " + " | ".join(kinds) + " |", "|---|" + "---|" * len(kinds)]
    for method in summary["median"].index:
        cells = []
        for k in kinds:
            mid, lo, hi = (summary[n].loc[method, k] for n in ("median", "low", "high"))
            cells.append(f"{mid:.2f} [{lo:.2f}, {hi:.2f}]")
        lines.append(f"| {method} | " + " | ".join(cells) + " |")
    lines += ["", "Clean-row false positive rate (median and maximum over datasets)", ""]
    lines += [f"- {m}: {v['median']:.3f} (max {v['max']:.3f})" for m, v in results["fpr"].items()]
    (args.output / "typed_results.md").write_text("\n".join(lines) + "\n")
    print(f"{len(data)} datasets")
    return 0


def x_main__mutmut_49(argv: list[str] | None = None) -> int:
    import argparse
    import json
    from pathlib import Path

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, nargs="+", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    data, columns, fpr = _load(args.runs)
    summary = pooled(data)
    results = {
        "datasets": len(data),
        "median": json.loads(summary["median"].to_json(orient="split")),
        "low": json.loads(summary["low"].to_json(orient="split")),
        "XXhighXX": json.loads(summary["high"].to_json(orient="split")),
        "stability": stability(data),
        "hypotheses": hypotheses(data, columns),
        "fpr": {
            m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in fpr.items()
        },
    }
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / "typed_results.json").write_text(
        json.dumps(results, indent=1, sort_keys=True) + "\n"
    )
    lines = [f"Median recall over {len(data)} datasets (95% interval over datasets)", ""]
    kinds = list(summary["median"].columns)
    lines += ["| method | " + " | ".join(kinds) + " |", "|---|" + "---|" * len(kinds)]
    for method in summary["median"].index:
        cells = []
        for k in kinds:
            mid, lo, hi = (summary[n].loc[method, k] for n in ("median", "low", "high"))
            cells.append(f"{mid:.2f} [{lo:.2f}, {hi:.2f}]")
        lines.append(f"| {method} | " + " | ".join(cells) + " |")
    lines += ["", "Clean-row false positive rate (median and maximum over datasets)", ""]
    lines += [f"- {m}: {v['median']:.3f} (max {v['max']:.3f})" for m, v in results["fpr"].items()]
    (args.output / "typed_results.md").write_text("\n".join(lines) + "\n")
    print(f"{len(data)} datasets")
    return 0


def x_main__mutmut_50(argv: list[str] | None = None) -> int:
    import argparse
    import json
    from pathlib import Path

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, nargs="+", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    data, columns, fpr = _load(args.runs)
    summary = pooled(data)
    results = {
        "datasets": len(data),
        "median": json.loads(summary["median"].to_json(orient="split")),
        "low": json.loads(summary["low"].to_json(orient="split")),
        "HIGH": json.loads(summary["high"].to_json(orient="split")),
        "stability": stability(data),
        "hypotheses": hypotheses(data, columns),
        "fpr": {
            m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in fpr.items()
        },
    }
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / "typed_results.json").write_text(
        json.dumps(results, indent=1, sort_keys=True) + "\n"
    )
    lines = [f"Median recall over {len(data)} datasets (95% interval over datasets)", ""]
    kinds = list(summary["median"].columns)
    lines += ["| method | " + " | ".join(kinds) + " |", "|---|" + "---|" * len(kinds)]
    for method in summary["median"].index:
        cells = []
        for k in kinds:
            mid, lo, hi = (summary[n].loc[method, k] for n in ("median", "low", "high"))
            cells.append(f"{mid:.2f} [{lo:.2f}, {hi:.2f}]")
        lines.append(f"| {method} | " + " | ".join(cells) + " |")
    lines += ["", "Clean-row false positive rate (median and maximum over datasets)", ""]
    lines += [f"- {m}: {v['median']:.3f} (max {v['max']:.3f})" for m, v in results["fpr"].items()]
    (args.output / "typed_results.md").write_text("\n".join(lines) + "\n")
    print(f"{len(data)} datasets")
    return 0


def x_main__mutmut_51(argv: list[str] | None = None) -> int:
    import argparse
    import json
    from pathlib import Path

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, nargs="+", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    data, columns, fpr = _load(args.runs)
    summary = pooled(data)
    results = {
        "datasets": len(data),
        "median": json.loads(summary["median"].to_json(orient="split")),
        "low": json.loads(summary["low"].to_json(orient="split")),
        "high": json.loads(None),
        "stability": stability(data),
        "hypotheses": hypotheses(data, columns),
        "fpr": {
            m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in fpr.items()
        },
    }
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / "typed_results.json").write_text(
        json.dumps(results, indent=1, sort_keys=True) + "\n"
    )
    lines = [f"Median recall over {len(data)} datasets (95% interval over datasets)", ""]
    kinds = list(summary["median"].columns)
    lines += ["| method | " + " | ".join(kinds) + " |", "|---|" + "---|" * len(kinds)]
    for method in summary["median"].index:
        cells = []
        for k in kinds:
            mid, lo, hi = (summary[n].loc[method, k] for n in ("median", "low", "high"))
            cells.append(f"{mid:.2f} [{lo:.2f}, {hi:.2f}]")
        lines.append(f"| {method} | " + " | ".join(cells) + " |")
    lines += ["", "Clean-row false positive rate (median and maximum over datasets)", ""]
    lines += [f"- {m}: {v['median']:.3f} (max {v['max']:.3f})" for m, v in results["fpr"].items()]
    (args.output / "typed_results.md").write_text("\n".join(lines) + "\n")
    print(f"{len(data)} datasets")
    return 0


def x_main__mutmut_52(argv: list[str] | None = None) -> int:
    import argparse
    import json
    from pathlib import Path

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, nargs="+", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    data, columns, fpr = _load(args.runs)
    summary = pooled(data)
    results = {
        "datasets": len(data),
        "median": json.loads(summary["median"].to_json(orient="split")),
        "low": json.loads(summary["low"].to_json(orient="split")),
        "high": json.loads(summary["high"].to_json(orient=None)),
        "stability": stability(data),
        "hypotheses": hypotheses(data, columns),
        "fpr": {
            m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in fpr.items()
        },
    }
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / "typed_results.json").write_text(
        json.dumps(results, indent=1, sort_keys=True) + "\n"
    )
    lines = [f"Median recall over {len(data)} datasets (95% interval over datasets)", ""]
    kinds = list(summary["median"].columns)
    lines += ["| method | " + " | ".join(kinds) + " |", "|---|" + "---|" * len(kinds)]
    for method in summary["median"].index:
        cells = []
        for k in kinds:
            mid, lo, hi = (summary[n].loc[method, k] for n in ("median", "low", "high"))
            cells.append(f"{mid:.2f} [{lo:.2f}, {hi:.2f}]")
        lines.append(f"| {method} | " + " | ".join(cells) + " |")
    lines += ["", "Clean-row false positive rate (median and maximum over datasets)", ""]
    lines += [f"- {m}: {v['median']:.3f} (max {v['max']:.3f})" for m, v in results["fpr"].items()]
    (args.output / "typed_results.md").write_text("\n".join(lines) + "\n")
    print(f"{len(data)} datasets")
    return 0


def x_main__mutmut_53(argv: list[str] | None = None) -> int:
    import argparse
    import json
    from pathlib import Path

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, nargs="+", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    data, columns, fpr = _load(args.runs)
    summary = pooled(data)
    results = {
        "datasets": len(data),
        "median": json.loads(summary["median"].to_json(orient="split")),
        "low": json.loads(summary["low"].to_json(orient="split")),
        "high": json.loads(summary["XXhighXX"].to_json(orient="split")),
        "stability": stability(data),
        "hypotheses": hypotheses(data, columns),
        "fpr": {
            m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in fpr.items()
        },
    }
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / "typed_results.json").write_text(
        json.dumps(results, indent=1, sort_keys=True) + "\n"
    )
    lines = [f"Median recall over {len(data)} datasets (95% interval over datasets)", ""]
    kinds = list(summary["median"].columns)
    lines += ["| method | " + " | ".join(kinds) + " |", "|---|" + "---|" * len(kinds)]
    for method in summary["median"].index:
        cells = []
        for k in kinds:
            mid, lo, hi = (summary[n].loc[method, k] for n in ("median", "low", "high"))
            cells.append(f"{mid:.2f} [{lo:.2f}, {hi:.2f}]")
        lines.append(f"| {method} | " + " | ".join(cells) + " |")
    lines += ["", "Clean-row false positive rate (median and maximum over datasets)", ""]
    lines += [f"- {m}: {v['median']:.3f} (max {v['max']:.3f})" for m, v in results["fpr"].items()]
    (args.output / "typed_results.md").write_text("\n".join(lines) + "\n")
    print(f"{len(data)} datasets")
    return 0


def x_main__mutmut_54(argv: list[str] | None = None) -> int:
    import argparse
    import json
    from pathlib import Path

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, nargs="+", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    data, columns, fpr = _load(args.runs)
    summary = pooled(data)
    results = {
        "datasets": len(data),
        "median": json.loads(summary["median"].to_json(orient="split")),
        "low": json.loads(summary["low"].to_json(orient="split")),
        "high": json.loads(summary["HIGH"].to_json(orient="split")),
        "stability": stability(data),
        "hypotheses": hypotheses(data, columns),
        "fpr": {
            m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in fpr.items()
        },
    }
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / "typed_results.json").write_text(
        json.dumps(results, indent=1, sort_keys=True) + "\n"
    )
    lines = [f"Median recall over {len(data)} datasets (95% interval over datasets)", ""]
    kinds = list(summary["median"].columns)
    lines += ["| method | " + " | ".join(kinds) + " |", "|---|" + "---|" * len(kinds)]
    for method in summary["median"].index:
        cells = []
        for k in kinds:
            mid, lo, hi = (summary[n].loc[method, k] for n in ("median", "low", "high"))
            cells.append(f"{mid:.2f} [{lo:.2f}, {hi:.2f}]")
        lines.append(f"| {method} | " + " | ".join(cells) + " |")
    lines += ["", "Clean-row false positive rate (median and maximum over datasets)", ""]
    lines += [f"- {m}: {v['median']:.3f} (max {v['max']:.3f})" for m, v in results["fpr"].items()]
    (args.output / "typed_results.md").write_text("\n".join(lines) + "\n")
    print(f"{len(data)} datasets")
    return 0


def x_main__mutmut_55(argv: list[str] | None = None) -> int:
    import argparse
    import json
    from pathlib import Path

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, nargs="+", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    data, columns, fpr = _load(args.runs)
    summary = pooled(data)
    results = {
        "datasets": len(data),
        "median": json.loads(summary["median"].to_json(orient="split")),
        "low": json.loads(summary["low"].to_json(orient="split")),
        "high": json.loads(summary["high"].to_json(orient="XXsplitXX")),
        "stability": stability(data),
        "hypotheses": hypotheses(data, columns),
        "fpr": {
            m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in fpr.items()
        },
    }
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / "typed_results.json").write_text(
        json.dumps(results, indent=1, sort_keys=True) + "\n"
    )
    lines = [f"Median recall over {len(data)} datasets (95% interval over datasets)", ""]
    kinds = list(summary["median"].columns)
    lines += ["| method | " + " | ".join(kinds) + " |", "|---|" + "---|" * len(kinds)]
    for method in summary["median"].index:
        cells = []
        for k in kinds:
            mid, lo, hi = (summary[n].loc[method, k] for n in ("median", "low", "high"))
            cells.append(f"{mid:.2f} [{lo:.2f}, {hi:.2f}]")
        lines.append(f"| {method} | " + " | ".join(cells) + " |")
    lines += ["", "Clean-row false positive rate (median and maximum over datasets)", ""]
    lines += [f"- {m}: {v['median']:.3f} (max {v['max']:.3f})" for m, v in results["fpr"].items()]
    (args.output / "typed_results.md").write_text("\n".join(lines) + "\n")
    print(f"{len(data)} datasets")
    return 0


def x_main__mutmut_56(argv: list[str] | None = None) -> int:
    import argparse
    import json
    from pathlib import Path

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, nargs="+", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    data, columns, fpr = _load(args.runs)
    summary = pooled(data)
    results = {
        "datasets": len(data),
        "median": json.loads(summary["median"].to_json(orient="split")),
        "low": json.loads(summary["low"].to_json(orient="split")),
        "high": json.loads(summary["high"].to_json(orient="SPLIT")),
        "stability": stability(data),
        "hypotheses": hypotheses(data, columns),
        "fpr": {
            m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in fpr.items()
        },
    }
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / "typed_results.json").write_text(
        json.dumps(results, indent=1, sort_keys=True) + "\n"
    )
    lines = [f"Median recall over {len(data)} datasets (95% interval over datasets)", ""]
    kinds = list(summary["median"].columns)
    lines += ["| method | " + " | ".join(kinds) + " |", "|---|" + "---|" * len(kinds)]
    for method in summary["median"].index:
        cells = []
        for k in kinds:
            mid, lo, hi = (summary[n].loc[method, k] for n in ("median", "low", "high"))
            cells.append(f"{mid:.2f} [{lo:.2f}, {hi:.2f}]")
        lines.append(f"| {method} | " + " | ".join(cells) + " |")
    lines += ["", "Clean-row false positive rate (median and maximum over datasets)", ""]
    lines += [f"- {m}: {v['median']:.3f} (max {v['max']:.3f})" for m, v in results["fpr"].items()]
    (args.output / "typed_results.md").write_text("\n".join(lines) + "\n")
    print(f"{len(data)} datasets")
    return 0


def x_main__mutmut_57(argv: list[str] | None = None) -> int:
    import argparse
    import json
    from pathlib import Path

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, nargs="+", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    data, columns, fpr = _load(args.runs)
    summary = pooled(data)
    results = {
        "datasets": len(data),
        "median": json.loads(summary["median"].to_json(orient="split")),
        "low": json.loads(summary["low"].to_json(orient="split")),
        "high": json.loads(summary["high"].to_json(orient="split")),
        "XXstabilityXX": stability(data),
        "hypotheses": hypotheses(data, columns),
        "fpr": {
            m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in fpr.items()
        },
    }
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / "typed_results.json").write_text(
        json.dumps(results, indent=1, sort_keys=True) + "\n"
    )
    lines = [f"Median recall over {len(data)} datasets (95% interval over datasets)", ""]
    kinds = list(summary["median"].columns)
    lines += ["| method | " + " | ".join(kinds) + " |", "|---|" + "---|" * len(kinds)]
    for method in summary["median"].index:
        cells = []
        for k in kinds:
            mid, lo, hi = (summary[n].loc[method, k] for n in ("median", "low", "high"))
            cells.append(f"{mid:.2f} [{lo:.2f}, {hi:.2f}]")
        lines.append(f"| {method} | " + " | ".join(cells) + " |")
    lines += ["", "Clean-row false positive rate (median and maximum over datasets)", ""]
    lines += [f"- {m}: {v['median']:.3f} (max {v['max']:.3f})" for m, v in results["fpr"].items()]
    (args.output / "typed_results.md").write_text("\n".join(lines) + "\n")
    print(f"{len(data)} datasets")
    return 0


def x_main__mutmut_58(argv: list[str] | None = None) -> int:
    import argparse
    import json
    from pathlib import Path

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, nargs="+", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    data, columns, fpr = _load(args.runs)
    summary = pooled(data)
    results = {
        "datasets": len(data),
        "median": json.loads(summary["median"].to_json(orient="split")),
        "low": json.loads(summary["low"].to_json(orient="split")),
        "high": json.loads(summary["high"].to_json(orient="split")),
        "STABILITY": stability(data),
        "hypotheses": hypotheses(data, columns),
        "fpr": {
            m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in fpr.items()
        },
    }
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / "typed_results.json").write_text(
        json.dumps(results, indent=1, sort_keys=True) + "\n"
    )
    lines = [f"Median recall over {len(data)} datasets (95% interval over datasets)", ""]
    kinds = list(summary["median"].columns)
    lines += ["| method | " + " | ".join(kinds) + " |", "|---|" + "---|" * len(kinds)]
    for method in summary["median"].index:
        cells = []
        for k in kinds:
            mid, lo, hi = (summary[n].loc[method, k] for n in ("median", "low", "high"))
            cells.append(f"{mid:.2f} [{lo:.2f}, {hi:.2f}]")
        lines.append(f"| {method} | " + " | ".join(cells) + " |")
    lines += ["", "Clean-row false positive rate (median and maximum over datasets)", ""]
    lines += [f"- {m}: {v['median']:.3f} (max {v['max']:.3f})" for m, v in results["fpr"].items()]
    (args.output / "typed_results.md").write_text("\n".join(lines) + "\n")
    print(f"{len(data)} datasets")
    return 0


def x_main__mutmut_59(argv: list[str] | None = None) -> int:
    import argparse
    import json
    from pathlib import Path

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, nargs="+", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    data, columns, fpr = _load(args.runs)
    summary = pooled(data)
    results = {
        "datasets": len(data),
        "median": json.loads(summary["median"].to_json(orient="split")),
        "low": json.loads(summary["low"].to_json(orient="split")),
        "high": json.loads(summary["high"].to_json(orient="split")),
        "stability": stability(None),
        "hypotheses": hypotheses(data, columns),
        "fpr": {
            m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in fpr.items()
        },
    }
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / "typed_results.json").write_text(
        json.dumps(results, indent=1, sort_keys=True) + "\n"
    )
    lines = [f"Median recall over {len(data)} datasets (95% interval over datasets)", ""]
    kinds = list(summary["median"].columns)
    lines += ["| method | " + " | ".join(kinds) + " |", "|---|" + "---|" * len(kinds)]
    for method in summary["median"].index:
        cells = []
        for k in kinds:
            mid, lo, hi = (summary[n].loc[method, k] for n in ("median", "low", "high"))
            cells.append(f"{mid:.2f} [{lo:.2f}, {hi:.2f}]")
        lines.append(f"| {method} | " + " | ".join(cells) + " |")
    lines += ["", "Clean-row false positive rate (median and maximum over datasets)", ""]
    lines += [f"- {m}: {v['median']:.3f} (max {v['max']:.3f})" for m, v in results["fpr"].items()]
    (args.output / "typed_results.md").write_text("\n".join(lines) + "\n")
    print(f"{len(data)} datasets")
    return 0


def x_main__mutmut_60(argv: list[str] | None = None) -> int:
    import argparse
    import json
    from pathlib import Path

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, nargs="+", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    data, columns, fpr = _load(args.runs)
    summary = pooled(data)
    results = {
        "datasets": len(data),
        "median": json.loads(summary["median"].to_json(orient="split")),
        "low": json.loads(summary["low"].to_json(orient="split")),
        "high": json.loads(summary["high"].to_json(orient="split")),
        "stability": stability(data),
        "XXhypothesesXX": hypotheses(data, columns),
        "fpr": {
            m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in fpr.items()
        },
    }
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / "typed_results.json").write_text(
        json.dumps(results, indent=1, sort_keys=True) + "\n"
    )
    lines = [f"Median recall over {len(data)} datasets (95% interval over datasets)", ""]
    kinds = list(summary["median"].columns)
    lines += ["| method | " + " | ".join(kinds) + " |", "|---|" + "---|" * len(kinds)]
    for method in summary["median"].index:
        cells = []
        for k in kinds:
            mid, lo, hi = (summary[n].loc[method, k] for n in ("median", "low", "high"))
            cells.append(f"{mid:.2f} [{lo:.2f}, {hi:.2f}]")
        lines.append(f"| {method} | " + " | ".join(cells) + " |")
    lines += ["", "Clean-row false positive rate (median and maximum over datasets)", ""]
    lines += [f"- {m}: {v['median']:.3f} (max {v['max']:.3f})" for m, v in results["fpr"].items()]
    (args.output / "typed_results.md").write_text("\n".join(lines) + "\n")
    print(f"{len(data)} datasets")
    return 0


def x_main__mutmut_61(argv: list[str] | None = None) -> int:
    import argparse
    import json
    from pathlib import Path

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, nargs="+", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    data, columns, fpr = _load(args.runs)
    summary = pooled(data)
    results = {
        "datasets": len(data),
        "median": json.loads(summary["median"].to_json(orient="split")),
        "low": json.loads(summary["low"].to_json(orient="split")),
        "high": json.loads(summary["high"].to_json(orient="split")),
        "stability": stability(data),
        "HYPOTHESES": hypotheses(data, columns),
        "fpr": {
            m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in fpr.items()
        },
    }
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / "typed_results.json").write_text(
        json.dumps(results, indent=1, sort_keys=True) + "\n"
    )
    lines = [f"Median recall over {len(data)} datasets (95% interval over datasets)", ""]
    kinds = list(summary["median"].columns)
    lines += ["| method | " + " | ".join(kinds) + " |", "|---|" + "---|" * len(kinds)]
    for method in summary["median"].index:
        cells = []
        for k in kinds:
            mid, lo, hi = (summary[n].loc[method, k] for n in ("median", "low", "high"))
            cells.append(f"{mid:.2f} [{lo:.2f}, {hi:.2f}]")
        lines.append(f"| {method} | " + " | ".join(cells) + " |")
    lines += ["", "Clean-row false positive rate (median and maximum over datasets)", ""]
    lines += [f"- {m}: {v['median']:.3f} (max {v['max']:.3f})" for m, v in results["fpr"].items()]
    (args.output / "typed_results.md").write_text("\n".join(lines) + "\n")
    print(f"{len(data)} datasets")
    return 0


def x_main__mutmut_62(argv: list[str] | None = None) -> int:
    import argparse
    import json
    from pathlib import Path

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, nargs="+", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    data, columns, fpr = _load(args.runs)
    summary = pooled(data)
    results = {
        "datasets": len(data),
        "median": json.loads(summary["median"].to_json(orient="split")),
        "low": json.loads(summary["low"].to_json(orient="split")),
        "high": json.loads(summary["high"].to_json(orient="split")),
        "stability": stability(data),
        "hypotheses": hypotheses(None, columns),
        "fpr": {
            m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in fpr.items()
        },
    }
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / "typed_results.json").write_text(
        json.dumps(results, indent=1, sort_keys=True) + "\n"
    )
    lines = [f"Median recall over {len(data)} datasets (95% interval over datasets)", ""]
    kinds = list(summary["median"].columns)
    lines += ["| method | " + " | ".join(kinds) + " |", "|---|" + "---|" * len(kinds)]
    for method in summary["median"].index:
        cells = []
        for k in kinds:
            mid, lo, hi = (summary[n].loc[method, k] for n in ("median", "low", "high"))
            cells.append(f"{mid:.2f} [{lo:.2f}, {hi:.2f}]")
        lines.append(f"| {method} | " + " | ".join(cells) + " |")
    lines += ["", "Clean-row false positive rate (median and maximum over datasets)", ""]
    lines += [f"- {m}: {v['median']:.3f} (max {v['max']:.3f})" for m, v in results["fpr"].items()]
    (args.output / "typed_results.md").write_text("\n".join(lines) + "\n")
    print(f"{len(data)} datasets")
    return 0


def x_main__mutmut_63(argv: list[str] | None = None) -> int:
    import argparse
    import json
    from pathlib import Path

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, nargs="+", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    data, columns, fpr = _load(args.runs)
    summary = pooled(data)
    results = {
        "datasets": len(data),
        "median": json.loads(summary["median"].to_json(orient="split")),
        "low": json.loads(summary["low"].to_json(orient="split")),
        "high": json.loads(summary["high"].to_json(orient="split")),
        "stability": stability(data),
        "hypotheses": hypotheses(data, None),
        "fpr": {
            m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in fpr.items()
        },
    }
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / "typed_results.json").write_text(
        json.dumps(results, indent=1, sort_keys=True) + "\n"
    )
    lines = [f"Median recall over {len(data)} datasets (95% interval over datasets)", ""]
    kinds = list(summary["median"].columns)
    lines += ["| method | " + " | ".join(kinds) + " |", "|---|" + "---|" * len(kinds)]
    for method in summary["median"].index:
        cells = []
        for k in kinds:
            mid, lo, hi = (summary[n].loc[method, k] for n in ("median", "low", "high"))
            cells.append(f"{mid:.2f} [{lo:.2f}, {hi:.2f}]")
        lines.append(f"| {method} | " + " | ".join(cells) + " |")
    lines += ["", "Clean-row false positive rate (median and maximum over datasets)", ""]
    lines += [f"- {m}: {v['median']:.3f} (max {v['max']:.3f})" for m, v in results["fpr"].items()]
    (args.output / "typed_results.md").write_text("\n".join(lines) + "\n")
    print(f"{len(data)} datasets")
    return 0


def x_main__mutmut_64(argv: list[str] | None = None) -> int:
    import argparse
    import json
    from pathlib import Path

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, nargs="+", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    data, columns, fpr = _load(args.runs)
    summary = pooled(data)
    results = {
        "datasets": len(data),
        "median": json.loads(summary["median"].to_json(orient="split")),
        "low": json.loads(summary["low"].to_json(orient="split")),
        "high": json.loads(summary["high"].to_json(orient="split")),
        "stability": stability(data),
        "hypotheses": hypotheses(columns),
        "fpr": {
            m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in fpr.items()
        },
    }
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / "typed_results.json").write_text(
        json.dumps(results, indent=1, sort_keys=True) + "\n"
    )
    lines = [f"Median recall over {len(data)} datasets (95% interval over datasets)", ""]
    kinds = list(summary["median"].columns)
    lines += ["| method | " + " | ".join(kinds) + " |", "|---|" + "---|" * len(kinds)]
    for method in summary["median"].index:
        cells = []
        for k in kinds:
            mid, lo, hi = (summary[n].loc[method, k] for n in ("median", "low", "high"))
            cells.append(f"{mid:.2f} [{lo:.2f}, {hi:.2f}]")
        lines.append(f"| {method} | " + " | ".join(cells) + " |")
    lines += ["", "Clean-row false positive rate (median and maximum over datasets)", ""]
    lines += [f"- {m}: {v['median']:.3f} (max {v['max']:.3f})" for m, v in results["fpr"].items()]
    (args.output / "typed_results.md").write_text("\n".join(lines) + "\n")
    print(f"{len(data)} datasets")
    return 0


def x_main__mutmut_65(argv: list[str] | None = None) -> int:
    import argparse
    import json
    from pathlib import Path

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, nargs="+", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    data, columns, fpr = _load(args.runs)
    summary = pooled(data)
    results = {
        "datasets": len(data),
        "median": json.loads(summary["median"].to_json(orient="split")),
        "low": json.loads(summary["low"].to_json(orient="split")),
        "high": json.loads(summary["high"].to_json(orient="split")),
        "stability": stability(data),
        "hypotheses": hypotheses(data, ),
        "fpr": {
            m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in fpr.items()
        },
    }
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / "typed_results.json").write_text(
        json.dumps(results, indent=1, sort_keys=True) + "\n"
    )
    lines = [f"Median recall over {len(data)} datasets (95% interval over datasets)", ""]
    kinds = list(summary["median"].columns)
    lines += ["| method | " + " | ".join(kinds) + " |", "|---|" + "---|" * len(kinds)]
    for method in summary["median"].index:
        cells = []
        for k in kinds:
            mid, lo, hi = (summary[n].loc[method, k] for n in ("median", "low", "high"))
            cells.append(f"{mid:.2f} [{lo:.2f}, {hi:.2f}]")
        lines.append(f"| {method} | " + " | ".join(cells) + " |")
    lines += ["", "Clean-row false positive rate (median and maximum over datasets)", ""]
    lines += [f"- {m}: {v['median']:.3f} (max {v['max']:.3f})" for m, v in results["fpr"].items()]
    (args.output / "typed_results.md").write_text("\n".join(lines) + "\n")
    print(f"{len(data)} datasets")
    return 0


def x_main__mutmut_66(argv: list[str] | None = None) -> int:
    import argparse
    import json
    from pathlib import Path

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, nargs="+", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    data, columns, fpr = _load(args.runs)
    summary = pooled(data)
    results = {
        "datasets": len(data),
        "median": json.loads(summary["median"].to_json(orient="split")),
        "low": json.loads(summary["low"].to_json(orient="split")),
        "high": json.loads(summary["high"].to_json(orient="split")),
        "stability": stability(data),
        "hypotheses": hypotheses(data, columns),
        "XXfprXX": {
            m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in fpr.items()
        },
    }
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / "typed_results.json").write_text(
        json.dumps(results, indent=1, sort_keys=True) + "\n"
    )
    lines = [f"Median recall over {len(data)} datasets (95% interval over datasets)", ""]
    kinds = list(summary["median"].columns)
    lines += ["| method | " + " | ".join(kinds) + " |", "|---|" + "---|" * len(kinds)]
    for method in summary["median"].index:
        cells = []
        for k in kinds:
            mid, lo, hi = (summary[n].loc[method, k] for n in ("median", "low", "high"))
            cells.append(f"{mid:.2f} [{lo:.2f}, {hi:.2f}]")
        lines.append(f"| {method} | " + " | ".join(cells) + " |")
    lines += ["", "Clean-row false positive rate (median and maximum over datasets)", ""]
    lines += [f"- {m}: {v['median']:.3f} (max {v['max']:.3f})" for m, v in results["fpr"].items()]
    (args.output / "typed_results.md").write_text("\n".join(lines) + "\n")
    print(f"{len(data)} datasets")
    return 0


def x_main__mutmut_67(argv: list[str] | None = None) -> int:
    import argparse
    import json
    from pathlib import Path

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, nargs="+", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    data, columns, fpr = _load(args.runs)
    summary = pooled(data)
    results = {
        "datasets": len(data),
        "median": json.loads(summary["median"].to_json(orient="split")),
        "low": json.loads(summary["low"].to_json(orient="split")),
        "high": json.loads(summary["high"].to_json(orient="split")),
        "stability": stability(data),
        "hypotheses": hypotheses(data, columns),
        "FPR": {
            m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in fpr.items()
        },
    }
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / "typed_results.json").write_text(
        json.dumps(results, indent=1, sort_keys=True) + "\n"
    )
    lines = [f"Median recall over {len(data)} datasets (95% interval over datasets)", ""]
    kinds = list(summary["median"].columns)
    lines += ["| method | " + " | ".join(kinds) + " |", "|---|" + "---|" * len(kinds)]
    for method in summary["median"].index:
        cells = []
        for k in kinds:
            mid, lo, hi = (summary[n].loc[method, k] for n in ("median", "low", "high"))
            cells.append(f"{mid:.2f} [{lo:.2f}, {hi:.2f}]")
        lines.append(f"| {method} | " + " | ".join(cells) + " |")
    lines += ["", "Clean-row false positive rate (median and maximum over datasets)", ""]
    lines += [f"- {m}: {v['median']:.3f} (max {v['max']:.3f})" for m, v in results["fpr"].items()]
    (args.output / "typed_results.md").write_text("\n".join(lines) + "\n")
    print(f"{len(data)} datasets")
    return 0


def x_main__mutmut_68(argv: list[str] | None = None) -> int:
    import argparse
    import json
    from pathlib import Path

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, nargs="+", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    data, columns, fpr = _load(args.runs)
    summary = pooled(data)
    results = {
        "datasets": len(data),
        "median": json.loads(summary["median"].to_json(orient="split")),
        "low": json.loads(summary["low"].to_json(orient="split")),
        "high": json.loads(summary["high"].to_json(orient="split")),
        "stability": stability(data),
        "hypotheses": hypotheses(data, columns),
        "fpr": {
            m: {"XXmedianXX": float(np.median(v)), "max": float(np.max(v))} for m, v in fpr.items()
        },
    }
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / "typed_results.json").write_text(
        json.dumps(results, indent=1, sort_keys=True) + "\n"
    )
    lines = [f"Median recall over {len(data)} datasets (95% interval over datasets)", ""]
    kinds = list(summary["median"].columns)
    lines += ["| method | " + " | ".join(kinds) + " |", "|---|" + "---|" * len(kinds)]
    for method in summary["median"].index:
        cells = []
        for k in kinds:
            mid, lo, hi = (summary[n].loc[method, k] for n in ("median", "low", "high"))
            cells.append(f"{mid:.2f} [{lo:.2f}, {hi:.2f}]")
        lines.append(f"| {method} | " + " | ".join(cells) + " |")
    lines += ["", "Clean-row false positive rate (median and maximum over datasets)", ""]
    lines += [f"- {m}: {v['median']:.3f} (max {v['max']:.3f})" for m, v in results["fpr"].items()]
    (args.output / "typed_results.md").write_text("\n".join(lines) + "\n")
    print(f"{len(data)} datasets")
    return 0


def x_main__mutmut_69(argv: list[str] | None = None) -> int:
    import argparse
    import json
    from pathlib import Path

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, nargs="+", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    data, columns, fpr = _load(args.runs)
    summary = pooled(data)
    results = {
        "datasets": len(data),
        "median": json.loads(summary["median"].to_json(orient="split")),
        "low": json.loads(summary["low"].to_json(orient="split")),
        "high": json.loads(summary["high"].to_json(orient="split")),
        "stability": stability(data),
        "hypotheses": hypotheses(data, columns),
        "fpr": {
            m: {"MEDIAN": float(np.median(v)), "max": float(np.max(v))} for m, v in fpr.items()
        },
    }
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / "typed_results.json").write_text(
        json.dumps(results, indent=1, sort_keys=True) + "\n"
    )
    lines = [f"Median recall over {len(data)} datasets (95% interval over datasets)", ""]
    kinds = list(summary["median"].columns)
    lines += ["| method | " + " | ".join(kinds) + " |", "|---|" + "---|" * len(kinds)]
    for method in summary["median"].index:
        cells = []
        for k in kinds:
            mid, lo, hi = (summary[n].loc[method, k] for n in ("median", "low", "high"))
            cells.append(f"{mid:.2f} [{lo:.2f}, {hi:.2f}]")
        lines.append(f"| {method} | " + " | ".join(cells) + " |")
    lines += ["", "Clean-row false positive rate (median and maximum over datasets)", ""]
    lines += [f"- {m}: {v['median']:.3f} (max {v['max']:.3f})" for m, v in results["fpr"].items()]
    (args.output / "typed_results.md").write_text("\n".join(lines) + "\n")
    print(f"{len(data)} datasets")
    return 0


def x_main__mutmut_70(argv: list[str] | None = None) -> int:
    import argparse
    import json
    from pathlib import Path

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, nargs="+", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    data, columns, fpr = _load(args.runs)
    summary = pooled(data)
    results = {
        "datasets": len(data),
        "median": json.loads(summary["median"].to_json(orient="split")),
        "low": json.loads(summary["low"].to_json(orient="split")),
        "high": json.loads(summary["high"].to_json(orient="split")),
        "stability": stability(data),
        "hypotheses": hypotheses(data, columns),
        "fpr": {
            m: {"median": float(None), "max": float(np.max(v))} for m, v in fpr.items()
        },
    }
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / "typed_results.json").write_text(
        json.dumps(results, indent=1, sort_keys=True) + "\n"
    )
    lines = [f"Median recall over {len(data)} datasets (95% interval over datasets)", ""]
    kinds = list(summary["median"].columns)
    lines += ["| method | " + " | ".join(kinds) + " |", "|---|" + "---|" * len(kinds)]
    for method in summary["median"].index:
        cells = []
        for k in kinds:
            mid, lo, hi = (summary[n].loc[method, k] for n in ("median", "low", "high"))
            cells.append(f"{mid:.2f} [{lo:.2f}, {hi:.2f}]")
        lines.append(f"| {method} | " + " | ".join(cells) + " |")
    lines += ["", "Clean-row false positive rate (median and maximum over datasets)", ""]
    lines += [f"- {m}: {v['median']:.3f} (max {v['max']:.3f})" for m, v in results["fpr"].items()]
    (args.output / "typed_results.md").write_text("\n".join(lines) + "\n")
    print(f"{len(data)} datasets")
    return 0


def x_main__mutmut_71(argv: list[str] | None = None) -> int:
    import argparse
    import json
    from pathlib import Path

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, nargs="+", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    data, columns, fpr = _load(args.runs)
    summary = pooled(data)
    results = {
        "datasets": len(data),
        "median": json.loads(summary["median"].to_json(orient="split")),
        "low": json.loads(summary["low"].to_json(orient="split")),
        "high": json.loads(summary["high"].to_json(orient="split")),
        "stability": stability(data),
        "hypotheses": hypotheses(data, columns),
        "fpr": {
            m: {"median": float(np.median(None)), "max": float(np.max(v))} for m, v in fpr.items()
        },
    }
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / "typed_results.json").write_text(
        json.dumps(results, indent=1, sort_keys=True) + "\n"
    )
    lines = [f"Median recall over {len(data)} datasets (95% interval over datasets)", ""]
    kinds = list(summary["median"].columns)
    lines += ["| method | " + " | ".join(kinds) + " |", "|---|" + "---|" * len(kinds)]
    for method in summary["median"].index:
        cells = []
        for k in kinds:
            mid, lo, hi = (summary[n].loc[method, k] for n in ("median", "low", "high"))
            cells.append(f"{mid:.2f} [{lo:.2f}, {hi:.2f}]")
        lines.append(f"| {method} | " + " | ".join(cells) + " |")
    lines += ["", "Clean-row false positive rate (median and maximum over datasets)", ""]
    lines += [f"- {m}: {v['median']:.3f} (max {v['max']:.3f})" for m, v in results["fpr"].items()]
    (args.output / "typed_results.md").write_text("\n".join(lines) + "\n")
    print(f"{len(data)} datasets")
    return 0


def x_main__mutmut_72(argv: list[str] | None = None) -> int:
    import argparse
    import json
    from pathlib import Path

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, nargs="+", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    data, columns, fpr = _load(args.runs)
    summary = pooled(data)
    results = {
        "datasets": len(data),
        "median": json.loads(summary["median"].to_json(orient="split")),
        "low": json.loads(summary["low"].to_json(orient="split")),
        "high": json.loads(summary["high"].to_json(orient="split")),
        "stability": stability(data),
        "hypotheses": hypotheses(data, columns),
        "fpr": {
            m: {"median": float(np.median(v)), "XXmaxXX": float(np.max(v))} for m, v in fpr.items()
        },
    }
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / "typed_results.json").write_text(
        json.dumps(results, indent=1, sort_keys=True) + "\n"
    )
    lines = [f"Median recall over {len(data)} datasets (95% interval over datasets)", ""]
    kinds = list(summary["median"].columns)
    lines += ["| method | " + " | ".join(kinds) + " |", "|---|" + "---|" * len(kinds)]
    for method in summary["median"].index:
        cells = []
        for k in kinds:
            mid, lo, hi = (summary[n].loc[method, k] for n in ("median", "low", "high"))
            cells.append(f"{mid:.2f} [{lo:.2f}, {hi:.2f}]")
        lines.append(f"| {method} | " + " | ".join(cells) + " |")
    lines += ["", "Clean-row false positive rate (median and maximum over datasets)", ""]
    lines += [f"- {m}: {v['median']:.3f} (max {v['max']:.3f})" for m, v in results["fpr"].items()]
    (args.output / "typed_results.md").write_text("\n".join(lines) + "\n")
    print(f"{len(data)} datasets")
    return 0


def x_main__mutmut_73(argv: list[str] | None = None) -> int:
    import argparse
    import json
    from pathlib import Path

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, nargs="+", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    data, columns, fpr = _load(args.runs)
    summary = pooled(data)
    results = {
        "datasets": len(data),
        "median": json.loads(summary["median"].to_json(orient="split")),
        "low": json.loads(summary["low"].to_json(orient="split")),
        "high": json.loads(summary["high"].to_json(orient="split")),
        "stability": stability(data),
        "hypotheses": hypotheses(data, columns),
        "fpr": {
            m: {"median": float(np.median(v)), "MAX": float(np.max(v))} for m, v in fpr.items()
        },
    }
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / "typed_results.json").write_text(
        json.dumps(results, indent=1, sort_keys=True) + "\n"
    )
    lines = [f"Median recall over {len(data)} datasets (95% interval over datasets)", ""]
    kinds = list(summary["median"].columns)
    lines += ["| method | " + " | ".join(kinds) + " |", "|---|" + "---|" * len(kinds)]
    for method in summary["median"].index:
        cells = []
        for k in kinds:
            mid, lo, hi = (summary[n].loc[method, k] for n in ("median", "low", "high"))
            cells.append(f"{mid:.2f} [{lo:.2f}, {hi:.2f}]")
        lines.append(f"| {method} | " + " | ".join(cells) + " |")
    lines += ["", "Clean-row false positive rate (median and maximum over datasets)", ""]
    lines += [f"- {m}: {v['median']:.3f} (max {v['max']:.3f})" for m, v in results["fpr"].items()]
    (args.output / "typed_results.md").write_text("\n".join(lines) + "\n")
    print(f"{len(data)} datasets")
    return 0


def x_main__mutmut_74(argv: list[str] | None = None) -> int:
    import argparse
    import json
    from pathlib import Path

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, nargs="+", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    data, columns, fpr = _load(args.runs)
    summary = pooled(data)
    results = {
        "datasets": len(data),
        "median": json.loads(summary["median"].to_json(orient="split")),
        "low": json.loads(summary["low"].to_json(orient="split")),
        "high": json.loads(summary["high"].to_json(orient="split")),
        "stability": stability(data),
        "hypotheses": hypotheses(data, columns),
        "fpr": {
            m: {"median": float(np.median(v)), "max": float(None)} for m, v in fpr.items()
        },
    }
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / "typed_results.json").write_text(
        json.dumps(results, indent=1, sort_keys=True) + "\n"
    )
    lines = [f"Median recall over {len(data)} datasets (95% interval over datasets)", ""]
    kinds = list(summary["median"].columns)
    lines += ["| method | " + " | ".join(kinds) + " |", "|---|" + "---|" * len(kinds)]
    for method in summary["median"].index:
        cells = []
        for k in kinds:
            mid, lo, hi = (summary[n].loc[method, k] for n in ("median", "low", "high"))
            cells.append(f"{mid:.2f} [{lo:.2f}, {hi:.2f}]")
        lines.append(f"| {method} | " + " | ".join(cells) + " |")
    lines += ["", "Clean-row false positive rate (median and maximum over datasets)", ""]
    lines += [f"- {m}: {v['median']:.3f} (max {v['max']:.3f})" for m, v in results["fpr"].items()]
    (args.output / "typed_results.md").write_text("\n".join(lines) + "\n")
    print(f"{len(data)} datasets")
    return 0


def x_main__mutmut_75(argv: list[str] | None = None) -> int:
    import argparse
    import json
    from pathlib import Path

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, nargs="+", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    data, columns, fpr = _load(args.runs)
    summary = pooled(data)
    results = {
        "datasets": len(data),
        "median": json.loads(summary["median"].to_json(orient="split")),
        "low": json.loads(summary["low"].to_json(orient="split")),
        "high": json.loads(summary["high"].to_json(orient="split")),
        "stability": stability(data),
        "hypotheses": hypotheses(data, columns),
        "fpr": {
            m: {"median": float(np.median(v)), "max": float(np.max(None))} for m, v in fpr.items()
        },
    }
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / "typed_results.json").write_text(
        json.dumps(results, indent=1, sort_keys=True) + "\n"
    )
    lines = [f"Median recall over {len(data)} datasets (95% interval over datasets)", ""]
    kinds = list(summary["median"].columns)
    lines += ["| method | " + " | ".join(kinds) + " |", "|---|" + "---|" * len(kinds)]
    for method in summary["median"].index:
        cells = []
        for k in kinds:
            mid, lo, hi = (summary[n].loc[method, k] for n in ("median", "low", "high"))
            cells.append(f"{mid:.2f} [{lo:.2f}, {hi:.2f}]")
        lines.append(f"| {method} | " + " | ".join(cells) + " |")
    lines += ["", "Clean-row false positive rate (median and maximum over datasets)", ""]
    lines += [f"- {m}: {v['median']:.3f} (max {v['max']:.3f})" for m, v in results["fpr"].items()]
    (args.output / "typed_results.md").write_text("\n".join(lines) + "\n")
    print(f"{len(data)} datasets")
    return 0


def x_main__mutmut_76(argv: list[str] | None = None) -> int:
    import argparse
    import json
    from pathlib import Path

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, nargs="+", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    data, columns, fpr = _load(args.runs)
    summary = pooled(data)
    results = {
        "datasets": len(data),
        "median": json.loads(summary["median"].to_json(orient="split")),
        "low": json.loads(summary["low"].to_json(orient="split")),
        "high": json.loads(summary["high"].to_json(orient="split")),
        "stability": stability(data),
        "hypotheses": hypotheses(data, columns),
        "fpr": {
            m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in fpr.items()
        },
    }
    args.output.mkdir(parents=None, exist_ok=True)
    (args.output / "typed_results.json").write_text(
        json.dumps(results, indent=1, sort_keys=True) + "\n"
    )
    lines = [f"Median recall over {len(data)} datasets (95% interval over datasets)", ""]
    kinds = list(summary["median"].columns)
    lines += ["| method | " + " | ".join(kinds) + " |", "|---|" + "---|" * len(kinds)]
    for method in summary["median"].index:
        cells = []
        for k in kinds:
            mid, lo, hi = (summary[n].loc[method, k] for n in ("median", "low", "high"))
            cells.append(f"{mid:.2f} [{lo:.2f}, {hi:.2f}]")
        lines.append(f"| {method} | " + " | ".join(cells) + " |")
    lines += ["", "Clean-row false positive rate (median and maximum over datasets)", ""]
    lines += [f"- {m}: {v['median']:.3f} (max {v['max']:.3f})" for m, v in results["fpr"].items()]
    (args.output / "typed_results.md").write_text("\n".join(lines) + "\n")
    print(f"{len(data)} datasets")
    return 0


def x_main__mutmut_77(argv: list[str] | None = None) -> int:
    import argparse
    import json
    from pathlib import Path

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, nargs="+", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    data, columns, fpr = _load(args.runs)
    summary = pooled(data)
    results = {
        "datasets": len(data),
        "median": json.loads(summary["median"].to_json(orient="split")),
        "low": json.loads(summary["low"].to_json(orient="split")),
        "high": json.loads(summary["high"].to_json(orient="split")),
        "stability": stability(data),
        "hypotheses": hypotheses(data, columns),
        "fpr": {
            m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in fpr.items()
        },
    }
    args.output.mkdir(parents=True, exist_ok=None)
    (args.output / "typed_results.json").write_text(
        json.dumps(results, indent=1, sort_keys=True) + "\n"
    )
    lines = [f"Median recall over {len(data)} datasets (95% interval over datasets)", ""]
    kinds = list(summary["median"].columns)
    lines += ["| method | " + " | ".join(kinds) + " |", "|---|" + "---|" * len(kinds)]
    for method in summary["median"].index:
        cells = []
        for k in kinds:
            mid, lo, hi = (summary[n].loc[method, k] for n in ("median", "low", "high"))
            cells.append(f"{mid:.2f} [{lo:.2f}, {hi:.2f}]")
        lines.append(f"| {method} | " + " | ".join(cells) + " |")
    lines += ["", "Clean-row false positive rate (median and maximum over datasets)", ""]
    lines += [f"- {m}: {v['median']:.3f} (max {v['max']:.3f})" for m, v in results["fpr"].items()]
    (args.output / "typed_results.md").write_text("\n".join(lines) + "\n")
    print(f"{len(data)} datasets")
    return 0


def x_main__mutmut_78(argv: list[str] | None = None) -> int:
    import argparse
    import json
    from pathlib import Path

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, nargs="+", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    data, columns, fpr = _load(args.runs)
    summary = pooled(data)
    results = {
        "datasets": len(data),
        "median": json.loads(summary["median"].to_json(orient="split")),
        "low": json.loads(summary["low"].to_json(orient="split")),
        "high": json.loads(summary["high"].to_json(orient="split")),
        "stability": stability(data),
        "hypotheses": hypotheses(data, columns),
        "fpr": {
            m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in fpr.items()
        },
    }
    args.output.mkdir(exist_ok=True)
    (args.output / "typed_results.json").write_text(
        json.dumps(results, indent=1, sort_keys=True) + "\n"
    )
    lines = [f"Median recall over {len(data)} datasets (95% interval over datasets)", ""]
    kinds = list(summary["median"].columns)
    lines += ["| method | " + " | ".join(kinds) + " |", "|---|" + "---|" * len(kinds)]
    for method in summary["median"].index:
        cells = []
        for k in kinds:
            mid, lo, hi = (summary[n].loc[method, k] for n in ("median", "low", "high"))
            cells.append(f"{mid:.2f} [{lo:.2f}, {hi:.2f}]")
        lines.append(f"| {method} | " + " | ".join(cells) + " |")
    lines += ["", "Clean-row false positive rate (median and maximum over datasets)", ""]
    lines += [f"- {m}: {v['median']:.3f} (max {v['max']:.3f})" for m, v in results["fpr"].items()]
    (args.output / "typed_results.md").write_text("\n".join(lines) + "\n")
    print(f"{len(data)} datasets")
    return 0


def x_main__mutmut_79(argv: list[str] | None = None) -> int:
    import argparse
    import json
    from pathlib import Path

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, nargs="+", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    data, columns, fpr = _load(args.runs)
    summary = pooled(data)
    results = {
        "datasets": len(data),
        "median": json.loads(summary["median"].to_json(orient="split")),
        "low": json.loads(summary["low"].to_json(orient="split")),
        "high": json.loads(summary["high"].to_json(orient="split")),
        "stability": stability(data),
        "hypotheses": hypotheses(data, columns),
        "fpr": {
            m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in fpr.items()
        },
    }
    args.output.mkdir(parents=True, )
    (args.output / "typed_results.json").write_text(
        json.dumps(results, indent=1, sort_keys=True) + "\n"
    )
    lines = [f"Median recall over {len(data)} datasets (95% interval over datasets)", ""]
    kinds = list(summary["median"].columns)
    lines += ["| method | " + " | ".join(kinds) + " |", "|---|" + "---|" * len(kinds)]
    for method in summary["median"].index:
        cells = []
        for k in kinds:
            mid, lo, hi = (summary[n].loc[method, k] for n in ("median", "low", "high"))
            cells.append(f"{mid:.2f} [{lo:.2f}, {hi:.2f}]")
        lines.append(f"| {method} | " + " | ".join(cells) + " |")
    lines += ["", "Clean-row false positive rate (median and maximum over datasets)", ""]
    lines += [f"- {m}: {v['median']:.3f} (max {v['max']:.3f})" for m, v in results["fpr"].items()]
    (args.output / "typed_results.md").write_text("\n".join(lines) + "\n")
    print(f"{len(data)} datasets")
    return 0


def x_main__mutmut_80(argv: list[str] | None = None) -> int:
    import argparse
    import json
    from pathlib import Path

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, nargs="+", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    data, columns, fpr = _load(args.runs)
    summary = pooled(data)
    results = {
        "datasets": len(data),
        "median": json.loads(summary["median"].to_json(orient="split")),
        "low": json.loads(summary["low"].to_json(orient="split")),
        "high": json.loads(summary["high"].to_json(orient="split")),
        "stability": stability(data),
        "hypotheses": hypotheses(data, columns),
        "fpr": {
            m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in fpr.items()
        },
    }
    args.output.mkdir(parents=False, exist_ok=True)
    (args.output / "typed_results.json").write_text(
        json.dumps(results, indent=1, sort_keys=True) + "\n"
    )
    lines = [f"Median recall over {len(data)} datasets (95% interval over datasets)", ""]
    kinds = list(summary["median"].columns)
    lines += ["| method | " + " | ".join(kinds) + " |", "|---|" + "---|" * len(kinds)]
    for method in summary["median"].index:
        cells = []
        for k in kinds:
            mid, lo, hi = (summary[n].loc[method, k] for n in ("median", "low", "high"))
            cells.append(f"{mid:.2f} [{lo:.2f}, {hi:.2f}]")
        lines.append(f"| {method} | " + " | ".join(cells) + " |")
    lines += ["", "Clean-row false positive rate (median and maximum over datasets)", ""]
    lines += [f"- {m}: {v['median']:.3f} (max {v['max']:.3f})" for m, v in results["fpr"].items()]
    (args.output / "typed_results.md").write_text("\n".join(lines) + "\n")
    print(f"{len(data)} datasets")
    return 0


def x_main__mutmut_81(argv: list[str] | None = None) -> int:
    import argparse
    import json
    from pathlib import Path

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, nargs="+", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    data, columns, fpr = _load(args.runs)
    summary = pooled(data)
    results = {
        "datasets": len(data),
        "median": json.loads(summary["median"].to_json(orient="split")),
        "low": json.loads(summary["low"].to_json(orient="split")),
        "high": json.loads(summary["high"].to_json(orient="split")),
        "stability": stability(data),
        "hypotheses": hypotheses(data, columns),
        "fpr": {
            m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in fpr.items()
        },
    }
    args.output.mkdir(parents=True, exist_ok=False)
    (args.output / "typed_results.json").write_text(
        json.dumps(results, indent=1, sort_keys=True) + "\n"
    )
    lines = [f"Median recall over {len(data)} datasets (95% interval over datasets)", ""]
    kinds = list(summary["median"].columns)
    lines += ["| method | " + " | ".join(kinds) + " |", "|---|" + "---|" * len(kinds)]
    for method in summary["median"].index:
        cells = []
        for k in kinds:
            mid, lo, hi = (summary[n].loc[method, k] for n in ("median", "low", "high"))
            cells.append(f"{mid:.2f} [{lo:.2f}, {hi:.2f}]")
        lines.append(f"| {method} | " + " | ".join(cells) + " |")
    lines += ["", "Clean-row false positive rate (median and maximum over datasets)", ""]
    lines += [f"- {m}: {v['median']:.3f} (max {v['max']:.3f})" for m, v in results["fpr"].items()]
    (args.output / "typed_results.md").write_text("\n".join(lines) + "\n")
    print(f"{len(data)} datasets")
    return 0


def x_main__mutmut_82(argv: list[str] | None = None) -> int:
    import argparse
    import json
    from pathlib import Path

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, nargs="+", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    data, columns, fpr = _load(args.runs)
    summary = pooled(data)
    results = {
        "datasets": len(data),
        "median": json.loads(summary["median"].to_json(orient="split")),
        "low": json.loads(summary["low"].to_json(orient="split")),
        "high": json.loads(summary["high"].to_json(orient="split")),
        "stability": stability(data),
        "hypotheses": hypotheses(data, columns),
        "fpr": {
            m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in fpr.items()
        },
    }
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / "typed_results.json").write_text(
        None
    )
    lines = [f"Median recall over {len(data)} datasets (95% interval over datasets)", ""]
    kinds = list(summary["median"].columns)
    lines += ["| method | " + " | ".join(kinds) + " |", "|---|" + "---|" * len(kinds)]
    for method in summary["median"].index:
        cells = []
        for k in kinds:
            mid, lo, hi = (summary[n].loc[method, k] for n in ("median", "low", "high"))
            cells.append(f"{mid:.2f} [{lo:.2f}, {hi:.2f}]")
        lines.append(f"| {method} | " + " | ".join(cells) + " |")
    lines += ["", "Clean-row false positive rate (median and maximum over datasets)", ""]
    lines += [f"- {m}: {v['median']:.3f} (max {v['max']:.3f})" for m, v in results["fpr"].items()]
    (args.output / "typed_results.md").write_text("\n".join(lines) + "\n")
    print(f"{len(data)} datasets")
    return 0


def x_main__mutmut_83(argv: list[str] | None = None) -> int:
    import argparse
    import json
    from pathlib import Path

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, nargs="+", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    data, columns, fpr = _load(args.runs)
    summary = pooled(data)
    results = {
        "datasets": len(data),
        "median": json.loads(summary["median"].to_json(orient="split")),
        "low": json.loads(summary["low"].to_json(orient="split")),
        "high": json.loads(summary["high"].to_json(orient="split")),
        "stability": stability(data),
        "hypotheses": hypotheses(data, columns),
        "fpr": {
            m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in fpr.items()
        },
    }
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output * "typed_results.json").write_text(
        json.dumps(results, indent=1, sort_keys=True) + "\n"
    )
    lines = [f"Median recall over {len(data)} datasets (95% interval over datasets)", ""]
    kinds = list(summary["median"].columns)
    lines += ["| method | " + " | ".join(kinds) + " |", "|---|" + "---|" * len(kinds)]
    for method in summary["median"].index:
        cells = []
        for k in kinds:
            mid, lo, hi = (summary[n].loc[method, k] for n in ("median", "low", "high"))
            cells.append(f"{mid:.2f} [{lo:.2f}, {hi:.2f}]")
        lines.append(f"| {method} | " + " | ".join(cells) + " |")
    lines += ["", "Clean-row false positive rate (median and maximum over datasets)", ""]
    lines += [f"- {m}: {v['median']:.3f} (max {v['max']:.3f})" for m, v in results["fpr"].items()]
    (args.output / "typed_results.md").write_text("\n".join(lines) + "\n")
    print(f"{len(data)} datasets")
    return 0


def x_main__mutmut_84(argv: list[str] | None = None) -> int:
    import argparse
    import json
    from pathlib import Path

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, nargs="+", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    data, columns, fpr = _load(args.runs)
    summary = pooled(data)
    results = {
        "datasets": len(data),
        "median": json.loads(summary["median"].to_json(orient="split")),
        "low": json.loads(summary["low"].to_json(orient="split")),
        "high": json.loads(summary["high"].to_json(orient="split")),
        "stability": stability(data),
        "hypotheses": hypotheses(data, columns),
        "fpr": {
            m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in fpr.items()
        },
    }
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / "XXtyped_results.jsonXX").write_text(
        json.dumps(results, indent=1, sort_keys=True) + "\n"
    )
    lines = [f"Median recall over {len(data)} datasets (95% interval over datasets)", ""]
    kinds = list(summary["median"].columns)
    lines += ["| method | " + " | ".join(kinds) + " |", "|---|" + "---|" * len(kinds)]
    for method in summary["median"].index:
        cells = []
        for k in kinds:
            mid, lo, hi = (summary[n].loc[method, k] for n in ("median", "low", "high"))
            cells.append(f"{mid:.2f} [{lo:.2f}, {hi:.2f}]")
        lines.append(f"| {method} | " + " | ".join(cells) + " |")
    lines += ["", "Clean-row false positive rate (median and maximum over datasets)", ""]
    lines += [f"- {m}: {v['median']:.3f} (max {v['max']:.3f})" for m, v in results["fpr"].items()]
    (args.output / "typed_results.md").write_text("\n".join(lines) + "\n")
    print(f"{len(data)} datasets")
    return 0


def x_main__mutmut_85(argv: list[str] | None = None) -> int:
    import argparse
    import json
    from pathlib import Path

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, nargs="+", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    data, columns, fpr = _load(args.runs)
    summary = pooled(data)
    results = {
        "datasets": len(data),
        "median": json.loads(summary["median"].to_json(orient="split")),
        "low": json.loads(summary["low"].to_json(orient="split")),
        "high": json.loads(summary["high"].to_json(orient="split")),
        "stability": stability(data),
        "hypotheses": hypotheses(data, columns),
        "fpr": {
            m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in fpr.items()
        },
    }
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / "TYPED_RESULTS.JSON").write_text(
        json.dumps(results, indent=1, sort_keys=True) + "\n"
    )
    lines = [f"Median recall over {len(data)} datasets (95% interval over datasets)", ""]
    kinds = list(summary["median"].columns)
    lines += ["| method | " + " | ".join(kinds) + " |", "|---|" + "---|" * len(kinds)]
    for method in summary["median"].index:
        cells = []
        for k in kinds:
            mid, lo, hi = (summary[n].loc[method, k] for n in ("median", "low", "high"))
            cells.append(f"{mid:.2f} [{lo:.2f}, {hi:.2f}]")
        lines.append(f"| {method} | " + " | ".join(cells) + " |")
    lines += ["", "Clean-row false positive rate (median and maximum over datasets)", ""]
    lines += [f"- {m}: {v['median']:.3f} (max {v['max']:.3f})" for m, v in results["fpr"].items()]
    (args.output / "typed_results.md").write_text("\n".join(lines) + "\n")
    print(f"{len(data)} datasets")
    return 0


def x_main__mutmut_86(argv: list[str] | None = None) -> int:
    import argparse
    import json
    from pathlib import Path

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, nargs="+", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    data, columns, fpr = _load(args.runs)
    summary = pooled(data)
    results = {
        "datasets": len(data),
        "median": json.loads(summary["median"].to_json(orient="split")),
        "low": json.loads(summary["low"].to_json(orient="split")),
        "high": json.loads(summary["high"].to_json(orient="split")),
        "stability": stability(data),
        "hypotheses": hypotheses(data, columns),
        "fpr": {
            m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in fpr.items()
        },
    }
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / "typed_results.json").write_text(
        json.dumps(results, indent=1, sort_keys=True) - "\n"
    )
    lines = [f"Median recall over {len(data)} datasets (95% interval over datasets)", ""]
    kinds = list(summary["median"].columns)
    lines += ["| method | " + " | ".join(kinds) + " |", "|---|" + "---|" * len(kinds)]
    for method in summary["median"].index:
        cells = []
        for k in kinds:
            mid, lo, hi = (summary[n].loc[method, k] for n in ("median", "low", "high"))
            cells.append(f"{mid:.2f} [{lo:.2f}, {hi:.2f}]")
        lines.append(f"| {method} | " + " | ".join(cells) + " |")
    lines += ["", "Clean-row false positive rate (median and maximum over datasets)", ""]
    lines += [f"- {m}: {v['median']:.3f} (max {v['max']:.3f})" for m, v in results["fpr"].items()]
    (args.output / "typed_results.md").write_text("\n".join(lines) + "\n")
    print(f"{len(data)} datasets")
    return 0


def x_main__mutmut_87(argv: list[str] | None = None) -> int:
    import argparse
    import json
    from pathlib import Path

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, nargs="+", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    data, columns, fpr = _load(args.runs)
    summary = pooled(data)
    results = {
        "datasets": len(data),
        "median": json.loads(summary["median"].to_json(orient="split")),
        "low": json.loads(summary["low"].to_json(orient="split")),
        "high": json.loads(summary["high"].to_json(orient="split")),
        "stability": stability(data),
        "hypotheses": hypotheses(data, columns),
        "fpr": {
            m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in fpr.items()
        },
    }
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / "typed_results.json").write_text(
        json.dumps(None, indent=1, sort_keys=True) + "\n"
    )
    lines = [f"Median recall over {len(data)} datasets (95% interval over datasets)", ""]
    kinds = list(summary["median"].columns)
    lines += ["| method | " + " | ".join(kinds) + " |", "|---|" + "---|" * len(kinds)]
    for method in summary["median"].index:
        cells = []
        for k in kinds:
            mid, lo, hi = (summary[n].loc[method, k] for n in ("median", "low", "high"))
            cells.append(f"{mid:.2f} [{lo:.2f}, {hi:.2f}]")
        lines.append(f"| {method} | " + " | ".join(cells) + " |")
    lines += ["", "Clean-row false positive rate (median and maximum over datasets)", ""]
    lines += [f"- {m}: {v['median']:.3f} (max {v['max']:.3f})" for m, v in results["fpr"].items()]
    (args.output / "typed_results.md").write_text("\n".join(lines) + "\n")
    print(f"{len(data)} datasets")
    return 0


def x_main__mutmut_88(argv: list[str] | None = None) -> int:
    import argparse
    import json
    from pathlib import Path

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, nargs="+", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    data, columns, fpr = _load(args.runs)
    summary = pooled(data)
    results = {
        "datasets": len(data),
        "median": json.loads(summary["median"].to_json(orient="split")),
        "low": json.loads(summary["low"].to_json(orient="split")),
        "high": json.loads(summary["high"].to_json(orient="split")),
        "stability": stability(data),
        "hypotheses": hypotheses(data, columns),
        "fpr": {
            m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in fpr.items()
        },
    }
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / "typed_results.json").write_text(
        json.dumps(results, indent=None, sort_keys=True) + "\n"
    )
    lines = [f"Median recall over {len(data)} datasets (95% interval over datasets)", ""]
    kinds = list(summary["median"].columns)
    lines += ["| method | " + " | ".join(kinds) + " |", "|---|" + "---|" * len(kinds)]
    for method in summary["median"].index:
        cells = []
        for k in kinds:
            mid, lo, hi = (summary[n].loc[method, k] for n in ("median", "low", "high"))
            cells.append(f"{mid:.2f} [{lo:.2f}, {hi:.2f}]")
        lines.append(f"| {method} | " + " | ".join(cells) + " |")
    lines += ["", "Clean-row false positive rate (median and maximum over datasets)", ""]
    lines += [f"- {m}: {v['median']:.3f} (max {v['max']:.3f})" for m, v in results["fpr"].items()]
    (args.output / "typed_results.md").write_text("\n".join(lines) + "\n")
    print(f"{len(data)} datasets")
    return 0


def x_main__mutmut_89(argv: list[str] | None = None) -> int:
    import argparse
    import json
    from pathlib import Path

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, nargs="+", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    data, columns, fpr = _load(args.runs)
    summary = pooled(data)
    results = {
        "datasets": len(data),
        "median": json.loads(summary["median"].to_json(orient="split")),
        "low": json.loads(summary["low"].to_json(orient="split")),
        "high": json.loads(summary["high"].to_json(orient="split")),
        "stability": stability(data),
        "hypotheses": hypotheses(data, columns),
        "fpr": {
            m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in fpr.items()
        },
    }
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / "typed_results.json").write_text(
        json.dumps(results, indent=1, sort_keys=None) + "\n"
    )
    lines = [f"Median recall over {len(data)} datasets (95% interval over datasets)", ""]
    kinds = list(summary["median"].columns)
    lines += ["| method | " + " | ".join(kinds) + " |", "|---|" + "---|" * len(kinds)]
    for method in summary["median"].index:
        cells = []
        for k in kinds:
            mid, lo, hi = (summary[n].loc[method, k] for n in ("median", "low", "high"))
            cells.append(f"{mid:.2f} [{lo:.2f}, {hi:.2f}]")
        lines.append(f"| {method} | " + " | ".join(cells) + " |")
    lines += ["", "Clean-row false positive rate (median and maximum over datasets)", ""]
    lines += [f"- {m}: {v['median']:.3f} (max {v['max']:.3f})" for m, v in results["fpr"].items()]
    (args.output / "typed_results.md").write_text("\n".join(lines) + "\n")
    print(f"{len(data)} datasets")
    return 0


def x_main__mutmut_90(argv: list[str] | None = None) -> int:
    import argparse
    import json
    from pathlib import Path

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, nargs="+", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    data, columns, fpr = _load(args.runs)
    summary = pooled(data)
    results = {
        "datasets": len(data),
        "median": json.loads(summary["median"].to_json(orient="split")),
        "low": json.loads(summary["low"].to_json(orient="split")),
        "high": json.loads(summary["high"].to_json(orient="split")),
        "stability": stability(data),
        "hypotheses": hypotheses(data, columns),
        "fpr": {
            m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in fpr.items()
        },
    }
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / "typed_results.json").write_text(
        json.dumps(indent=1, sort_keys=True) + "\n"
    )
    lines = [f"Median recall over {len(data)} datasets (95% interval over datasets)", ""]
    kinds = list(summary["median"].columns)
    lines += ["| method | " + " | ".join(kinds) + " |", "|---|" + "---|" * len(kinds)]
    for method in summary["median"].index:
        cells = []
        for k in kinds:
            mid, lo, hi = (summary[n].loc[method, k] for n in ("median", "low", "high"))
            cells.append(f"{mid:.2f} [{lo:.2f}, {hi:.2f}]")
        lines.append(f"| {method} | " + " | ".join(cells) + " |")
    lines += ["", "Clean-row false positive rate (median and maximum over datasets)", ""]
    lines += [f"- {m}: {v['median']:.3f} (max {v['max']:.3f})" for m, v in results["fpr"].items()]
    (args.output / "typed_results.md").write_text("\n".join(lines) + "\n")
    print(f"{len(data)} datasets")
    return 0


def x_main__mutmut_91(argv: list[str] | None = None) -> int:
    import argparse
    import json
    from pathlib import Path

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, nargs="+", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    data, columns, fpr = _load(args.runs)
    summary = pooled(data)
    results = {
        "datasets": len(data),
        "median": json.loads(summary["median"].to_json(orient="split")),
        "low": json.loads(summary["low"].to_json(orient="split")),
        "high": json.loads(summary["high"].to_json(orient="split")),
        "stability": stability(data),
        "hypotheses": hypotheses(data, columns),
        "fpr": {
            m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in fpr.items()
        },
    }
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / "typed_results.json").write_text(
        json.dumps(results, sort_keys=True) + "\n"
    )
    lines = [f"Median recall over {len(data)} datasets (95% interval over datasets)", ""]
    kinds = list(summary["median"].columns)
    lines += ["| method | " + " | ".join(kinds) + " |", "|---|" + "---|" * len(kinds)]
    for method in summary["median"].index:
        cells = []
        for k in kinds:
            mid, lo, hi = (summary[n].loc[method, k] for n in ("median", "low", "high"))
            cells.append(f"{mid:.2f} [{lo:.2f}, {hi:.2f}]")
        lines.append(f"| {method} | " + " | ".join(cells) + " |")
    lines += ["", "Clean-row false positive rate (median and maximum over datasets)", ""]
    lines += [f"- {m}: {v['median']:.3f} (max {v['max']:.3f})" for m, v in results["fpr"].items()]
    (args.output / "typed_results.md").write_text("\n".join(lines) + "\n")
    print(f"{len(data)} datasets")
    return 0


def x_main__mutmut_92(argv: list[str] | None = None) -> int:
    import argparse
    import json
    from pathlib import Path

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, nargs="+", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    data, columns, fpr = _load(args.runs)
    summary = pooled(data)
    results = {
        "datasets": len(data),
        "median": json.loads(summary["median"].to_json(orient="split")),
        "low": json.loads(summary["low"].to_json(orient="split")),
        "high": json.loads(summary["high"].to_json(orient="split")),
        "stability": stability(data),
        "hypotheses": hypotheses(data, columns),
        "fpr": {
            m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in fpr.items()
        },
    }
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / "typed_results.json").write_text(
        json.dumps(results, indent=1, ) + "\n"
    )
    lines = [f"Median recall over {len(data)} datasets (95% interval over datasets)", ""]
    kinds = list(summary["median"].columns)
    lines += ["| method | " + " | ".join(kinds) + " |", "|---|" + "---|" * len(kinds)]
    for method in summary["median"].index:
        cells = []
        for k in kinds:
            mid, lo, hi = (summary[n].loc[method, k] for n in ("median", "low", "high"))
            cells.append(f"{mid:.2f} [{lo:.2f}, {hi:.2f}]")
        lines.append(f"| {method} | " + " | ".join(cells) + " |")
    lines += ["", "Clean-row false positive rate (median and maximum over datasets)", ""]
    lines += [f"- {m}: {v['median']:.3f} (max {v['max']:.3f})" for m, v in results["fpr"].items()]
    (args.output / "typed_results.md").write_text("\n".join(lines) + "\n")
    print(f"{len(data)} datasets")
    return 0


def x_main__mutmut_93(argv: list[str] | None = None) -> int:
    import argparse
    import json
    from pathlib import Path

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, nargs="+", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    data, columns, fpr = _load(args.runs)
    summary = pooled(data)
    results = {
        "datasets": len(data),
        "median": json.loads(summary["median"].to_json(orient="split")),
        "low": json.loads(summary["low"].to_json(orient="split")),
        "high": json.loads(summary["high"].to_json(orient="split")),
        "stability": stability(data),
        "hypotheses": hypotheses(data, columns),
        "fpr": {
            m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in fpr.items()
        },
    }
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / "typed_results.json").write_text(
        json.dumps(results, indent=2, sort_keys=True) + "\n"
    )
    lines = [f"Median recall over {len(data)} datasets (95% interval over datasets)", ""]
    kinds = list(summary["median"].columns)
    lines += ["| method | " + " | ".join(kinds) + " |", "|---|" + "---|" * len(kinds)]
    for method in summary["median"].index:
        cells = []
        for k in kinds:
            mid, lo, hi = (summary[n].loc[method, k] for n in ("median", "low", "high"))
            cells.append(f"{mid:.2f} [{lo:.2f}, {hi:.2f}]")
        lines.append(f"| {method} | " + " | ".join(cells) + " |")
    lines += ["", "Clean-row false positive rate (median and maximum over datasets)", ""]
    lines += [f"- {m}: {v['median']:.3f} (max {v['max']:.3f})" for m, v in results["fpr"].items()]
    (args.output / "typed_results.md").write_text("\n".join(lines) + "\n")
    print(f"{len(data)} datasets")
    return 0


def x_main__mutmut_94(argv: list[str] | None = None) -> int:
    import argparse
    import json
    from pathlib import Path

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, nargs="+", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    data, columns, fpr = _load(args.runs)
    summary = pooled(data)
    results = {
        "datasets": len(data),
        "median": json.loads(summary["median"].to_json(orient="split")),
        "low": json.loads(summary["low"].to_json(orient="split")),
        "high": json.loads(summary["high"].to_json(orient="split")),
        "stability": stability(data),
        "hypotheses": hypotheses(data, columns),
        "fpr": {
            m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in fpr.items()
        },
    }
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / "typed_results.json").write_text(
        json.dumps(results, indent=1, sort_keys=False) + "\n"
    )
    lines = [f"Median recall over {len(data)} datasets (95% interval over datasets)", ""]
    kinds = list(summary["median"].columns)
    lines += ["| method | " + " | ".join(kinds) + " |", "|---|" + "---|" * len(kinds)]
    for method in summary["median"].index:
        cells = []
        for k in kinds:
            mid, lo, hi = (summary[n].loc[method, k] for n in ("median", "low", "high"))
            cells.append(f"{mid:.2f} [{lo:.2f}, {hi:.2f}]")
        lines.append(f"| {method} | " + " | ".join(cells) + " |")
    lines += ["", "Clean-row false positive rate (median and maximum over datasets)", ""]
    lines += [f"- {m}: {v['median']:.3f} (max {v['max']:.3f})" for m, v in results["fpr"].items()]
    (args.output / "typed_results.md").write_text("\n".join(lines) + "\n")
    print(f"{len(data)} datasets")
    return 0


def x_main__mutmut_95(argv: list[str] | None = None) -> int:
    import argparse
    import json
    from pathlib import Path

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, nargs="+", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    data, columns, fpr = _load(args.runs)
    summary = pooled(data)
    results = {
        "datasets": len(data),
        "median": json.loads(summary["median"].to_json(orient="split")),
        "low": json.loads(summary["low"].to_json(orient="split")),
        "high": json.loads(summary["high"].to_json(orient="split")),
        "stability": stability(data),
        "hypotheses": hypotheses(data, columns),
        "fpr": {
            m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in fpr.items()
        },
    }
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / "typed_results.json").write_text(
        json.dumps(results, indent=1, sort_keys=True) + "XX\nXX"
    )
    lines = [f"Median recall over {len(data)} datasets (95% interval over datasets)", ""]
    kinds = list(summary["median"].columns)
    lines += ["| method | " + " | ".join(kinds) + " |", "|---|" + "---|" * len(kinds)]
    for method in summary["median"].index:
        cells = []
        for k in kinds:
            mid, lo, hi = (summary[n].loc[method, k] for n in ("median", "low", "high"))
            cells.append(f"{mid:.2f} [{lo:.2f}, {hi:.2f}]")
        lines.append(f"| {method} | " + " | ".join(cells) + " |")
    lines += ["", "Clean-row false positive rate (median and maximum over datasets)", ""]
    lines += [f"- {m}: {v['median']:.3f} (max {v['max']:.3f})" for m, v in results["fpr"].items()]
    (args.output / "typed_results.md").write_text("\n".join(lines) + "\n")
    print(f"{len(data)} datasets")
    return 0


def x_main__mutmut_96(argv: list[str] | None = None) -> int:
    import argparse
    import json
    from pathlib import Path

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, nargs="+", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    data, columns, fpr = _load(args.runs)
    summary = pooled(data)
    results = {
        "datasets": len(data),
        "median": json.loads(summary["median"].to_json(orient="split")),
        "low": json.loads(summary["low"].to_json(orient="split")),
        "high": json.loads(summary["high"].to_json(orient="split")),
        "stability": stability(data),
        "hypotheses": hypotheses(data, columns),
        "fpr": {
            m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in fpr.items()
        },
    }
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / "typed_results.json").write_text(
        json.dumps(results, indent=1, sort_keys=True) + "\n"
    )
    lines = None
    kinds = list(summary["median"].columns)
    lines += ["| method | " + " | ".join(kinds) + " |", "|---|" + "---|" * len(kinds)]
    for method in summary["median"].index:
        cells = []
        for k in kinds:
            mid, lo, hi = (summary[n].loc[method, k] for n in ("median", "low", "high"))
            cells.append(f"{mid:.2f} [{lo:.2f}, {hi:.2f}]")
        lines.append(f"| {method} | " + " | ".join(cells) + " |")
    lines += ["", "Clean-row false positive rate (median and maximum over datasets)", ""]
    lines += [f"- {m}: {v['median']:.3f} (max {v['max']:.3f})" for m, v in results["fpr"].items()]
    (args.output / "typed_results.md").write_text("\n".join(lines) + "\n")
    print(f"{len(data)} datasets")
    return 0


def x_main__mutmut_97(argv: list[str] | None = None) -> int:
    import argparse
    import json
    from pathlib import Path

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, nargs="+", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    data, columns, fpr = _load(args.runs)
    summary = pooled(data)
    results = {
        "datasets": len(data),
        "median": json.loads(summary["median"].to_json(orient="split")),
        "low": json.loads(summary["low"].to_json(orient="split")),
        "high": json.loads(summary["high"].to_json(orient="split")),
        "stability": stability(data),
        "hypotheses": hypotheses(data, columns),
        "fpr": {
            m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in fpr.items()
        },
    }
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / "typed_results.json").write_text(
        json.dumps(results, indent=1, sort_keys=True) + "\n"
    )
    lines = [f"Median recall over {len(data)} datasets (95% interval over datasets)", "XXXX"]
    kinds = list(summary["median"].columns)
    lines += ["| method | " + " | ".join(kinds) + " |", "|---|" + "---|" * len(kinds)]
    for method in summary["median"].index:
        cells = []
        for k in kinds:
            mid, lo, hi = (summary[n].loc[method, k] for n in ("median", "low", "high"))
            cells.append(f"{mid:.2f} [{lo:.2f}, {hi:.2f}]")
        lines.append(f"| {method} | " + " | ".join(cells) + " |")
    lines += ["", "Clean-row false positive rate (median and maximum over datasets)", ""]
    lines += [f"- {m}: {v['median']:.3f} (max {v['max']:.3f})" for m, v in results["fpr"].items()]
    (args.output / "typed_results.md").write_text("\n".join(lines) + "\n")
    print(f"{len(data)} datasets")
    return 0


def x_main__mutmut_98(argv: list[str] | None = None) -> int:
    import argparse
    import json
    from pathlib import Path

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, nargs="+", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    data, columns, fpr = _load(args.runs)
    summary = pooled(data)
    results = {
        "datasets": len(data),
        "median": json.loads(summary["median"].to_json(orient="split")),
        "low": json.loads(summary["low"].to_json(orient="split")),
        "high": json.loads(summary["high"].to_json(orient="split")),
        "stability": stability(data),
        "hypotheses": hypotheses(data, columns),
        "fpr": {
            m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in fpr.items()
        },
    }
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / "typed_results.json").write_text(
        json.dumps(results, indent=1, sort_keys=True) + "\n"
    )
    lines = [f"Median recall over {len(data)} datasets (95% interval over datasets)", ""]
    kinds = None
    lines += ["| method | " + " | ".join(kinds) + " |", "|---|" + "---|" * len(kinds)]
    for method in summary["median"].index:
        cells = []
        for k in kinds:
            mid, lo, hi = (summary[n].loc[method, k] for n in ("median", "low", "high"))
            cells.append(f"{mid:.2f} [{lo:.2f}, {hi:.2f}]")
        lines.append(f"| {method} | " + " | ".join(cells) + " |")
    lines += ["", "Clean-row false positive rate (median and maximum over datasets)", ""]
    lines += [f"- {m}: {v['median']:.3f} (max {v['max']:.3f})" for m, v in results["fpr"].items()]
    (args.output / "typed_results.md").write_text("\n".join(lines) + "\n")
    print(f"{len(data)} datasets")
    return 0


def x_main__mutmut_99(argv: list[str] | None = None) -> int:
    import argparse
    import json
    from pathlib import Path

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, nargs="+", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    data, columns, fpr = _load(args.runs)
    summary = pooled(data)
    results = {
        "datasets": len(data),
        "median": json.loads(summary["median"].to_json(orient="split")),
        "low": json.loads(summary["low"].to_json(orient="split")),
        "high": json.loads(summary["high"].to_json(orient="split")),
        "stability": stability(data),
        "hypotheses": hypotheses(data, columns),
        "fpr": {
            m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in fpr.items()
        },
    }
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / "typed_results.json").write_text(
        json.dumps(results, indent=1, sort_keys=True) + "\n"
    )
    lines = [f"Median recall over {len(data)} datasets (95% interval over datasets)", ""]
    kinds = list(None)
    lines += ["| method | " + " | ".join(kinds) + " |", "|---|" + "---|" * len(kinds)]
    for method in summary["median"].index:
        cells = []
        for k in kinds:
            mid, lo, hi = (summary[n].loc[method, k] for n in ("median", "low", "high"))
            cells.append(f"{mid:.2f} [{lo:.2f}, {hi:.2f}]")
        lines.append(f"| {method} | " + " | ".join(cells) + " |")
    lines += ["", "Clean-row false positive rate (median and maximum over datasets)", ""]
    lines += [f"- {m}: {v['median']:.3f} (max {v['max']:.3f})" for m, v in results["fpr"].items()]
    (args.output / "typed_results.md").write_text("\n".join(lines) + "\n")
    print(f"{len(data)} datasets")
    return 0


def x_main__mutmut_100(argv: list[str] | None = None) -> int:
    import argparse
    import json
    from pathlib import Path

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, nargs="+", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    data, columns, fpr = _load(args.runs)
    summary = pooled(data)
    results = {
        "datasets": len(data),
        "median": json.loads(summary["median"].to_json(orient="split")),
        "low": json.loads(summary["low"].to_json(orient="split")),
        "high": json.loads(summary["high"].to_json(orient="split")),
        "stability": stability(data),
        "hypotheses": hypotheses(data, columns),
        "fpr": {
            m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in fpr.items()
        },
    }
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / "typed_results.json").write_text(
        json.dumps(results, indent=1, sort_keys=True) + "\n"
    )
    lines = [f"Median recall over {len(data)} datasets (95% interval over datasets)", ""]
    kinds = list(summary["XXmedianXX"].columns)
    lines += ["| method | " + " | ".join(kinds) + " |", "|---|" + "---|" * len(kinds)]
    for method in summary["median"].index:
        cells = []
        for k in kinds:
            mid, lo, hi = (summary[n].loc[method, k] for n in ("median", "low", "high"))
            cells.append(f"{mid:.2f} [{lo:.2f}, {hi:.2f}]")
        lines.append(f"| {method} | " + " | ".join(cells) + " |")
    lines += ["", "Clean-row false positive rate (median and maximum over datasets)", ""]
    lines += [f"- {m}: {v['median']:.3f} (max {v['max']:.3f})" for m, v in results["fpr"].items()]
    (args.output / "typed_results.md").write_text("\n".join(lines) + "\n")
    print(f"{len(data)} datasets")
    return 0


def x_main__mutmut_101(argv: list[str] | None = None) -> int:
    import argparse
    import json
    from pathlib import Path

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, nargs="+", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    data, columns, fpr = _load(args.runs)
    summary = pooled(data)
    results = {
        "datasets": len(data),
        "median": json.loads(summary["median"].to_json(orient="split")),
        "low": json.loads(summary["low"].to_json(orient="split")),
        "high": json.loads(summary["high"].to_json(orient="split")),
        "stability": stability(data),
        "hypotheses": hypotheses(data, columns),
        "fpr": {
            m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in fpr.items()
        },
    }
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / "typed_results.json").write_text(
        json.dumps(results, indent=1, sort_keys=True) + "\n"
    )
    lines = [f"Median recall over {len(data)} datasets (95% interval over datasets)", ""]
    kinds = list(summary["MEDIAN"].columns)
    lines += ["| method | " + " | ".join(kinds) + " |", "|---|" + "---|" * len(kinds)]
    for method in summary["median"].index:
        cells = []
        for k in kinds:
            mid, lo, hi = (summary[n].loc[method, k] for n in ("median", "low", "high"))
            cells.append(f"{mid:.2f} [{lo:.2f}, {hi:.2f}]")
        lines.append(f"| {method} | " + " | ".join(cells) + " |")
    lines += ["", "Clean-row false positive rate (median and maximum over datasets)", ""]
    lines += [f"- {m}: {v['median']:.3f} (max {v['max']:.3f})" for m, v in results["fpr"].items()]
    (args.output / "typed_results.md").write_text("\n".join(lines) + "\n")
    print(f"{len(data)} datasets")
    return 0


def x_main__mutmut_102(argv: list[str] | None = None) -> int:
    import argparse
    import json
    from pathlib import Path

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, nargs="+", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    data, columns, fpr = _load(args.runs)
    summary = pooled(data)
    results = {
        "datasets": len(data),
        "median": json.loads(summary["median"].to_json(orient="split")),
        "low": json.loads(summary["low"].to_json(orient="split")),
        "high": json.loads(summary["high"].to_json(orient="split")),
        "stability": stability(data),
        "hypotheses": hypotheses(data, columns),
        "fpr": {
            m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in fpr.items()
        },
    }
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / "typed_results.json").write_text(
        json.dumps(results, indent=1, sort_keys=True) + "\n"
    )
    lines = [f"Median recall over {len(data)} datasets (95% interval over datasets)", ""]
    kinds = list(summary["median"].columns)
    lines = ["| method | " + " | ".join(kinds) + " |", "|---|" + "---|" * len(kinds)]
    for method in summary["median"].index:
        cells = []
        for k in kinds:
            mid, lo, hi = (summary[n].loc[method, k] for n in ("median", "low", "high"))
            cells.append(f"{mid:.2f} [{lo:.2f}, {hi:.2f}]")
        lines.append(f"| {method} | " + " | ".join(cells) + " |")
    lines += ["", "Clean-row false positive rate (median and maximum over datasets)", ""]
    lines += [f"- {m}: {v['median']:.3f} (max {v['max']:.3f})" for m, v in results["fpr"].items()]
    (args.output / "typed_results.md").write_text("\n".join(lines) + "\n")
    print(f"{len(data)} datasets")
    return 0


def x_main__mutmut_103(argv: list[str] | None = None) -> int:
    import argparse
    import json
    from pathlib import Path

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, nargs="+", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    data, columns, fpr = _load(args.runs)
    summary = pooled(data)
    results = {
        "datasets": len(data),
        "median": json.loads(summary["median"].to_json(orient="split")),
        "low": json.loads(summary["low"].to_json(orient="split")),
        "high": json.loads(summary["high"].to_json(orient="split")),
        "stability": stability(data),
        "hypotheses": hypotheses(data, columns),
        "fpr": {
            m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in fpr.items()
        },
    }
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / "typed_results.json").write_text(
        json.dumps(results, indent=1, sort_keys=True) + "\n"
    )
    lines = [f"Median recall over {len(data)} datasets (95% interval over datasets)", ""]
    kinds = list(summary["median"].columns)
    lines -= ["| method | " + " | ".join(kinds) + " |", "|---|" + "---|" * len(kinds)]
    for method in summary["median"].index:
        cells = []
        for k in kinds:
            mid, lo, hi = (summary[n].loc[method, k] for n in ("median", "low", "high"))
            cells.append(f"{mid:.2f} [{lo:.2f}, {hi:.2f}]")
        lines.append(f"| {method} | " + " | ".join(cells) + " |")
    lines += ["", "Clean-row false positive rate (median and maximum over datasets)", ""]
    lines += [f"- {m}: {v['median']:.3f} (max {v['max']:.3f})" for m, v in results["fpr"].items()]
    (args.output / "typed_results.md").write_text("\n".join(lines) + "\n")
    print(f"{len(data)} datasets")
    return 0


def x_main__mutmut_104(argv: list[str] | None = None) -> int:
    import argparse
    import json
    from pathlib import Path

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, nargs="+", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    data, columns, fpr = _load(args.runs)
    summary = pooled(data)
    results = {
        "datasets": len(data),
        "median": json.loads(summary["median"].to_json(orient="split")),
        "low": json.loads(summary["low"].to_json(orient="split")),
        "high": json.loads(summary["high"].to_json(orient="split")),
        "stability": stability(data),
        "hypotheses": hypotheses(data, columns),
        "fpr": {
            m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in fpr.items()
        },
    }
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / "typed_results.json").write_text(
        json.dumps(results, indent=1, sort_keys=True) + "\n"
    )
    lines = [f"Median recall over {len(data)} datasets (95% interval over datasets)", ""]
    kinds = list(summary["median"].columns)
    lines += ["| method | " + " | ".join(kinds) - " |", "|---|" + "---|" * len(kinds)]
    for method in summary["median"].index:
        cells = []
        for k in kinds:
            mid, lo, hi = (summary[n].loc[method, k] for n in ("median", "low", "high"))
            cells.append(f"{mid:.2f} [{lo:.2f}, {hi:.2f}]")
        lines.append(f"| {method} | " + " | ".join(cells) + " |")
    lines += ["", "Clean-row false positive rate (median and maximum over datasets)", ""]
    lines += [f"- {m}: {v['median']:.3f} (max {v['max']:.3f})" for m, v in results["fpr"].items()]
    (args.output / "typed_results.md").write_text("\n".join(lines) + "\n")
    print(f"{len(data)} datasets")
    return 0


def x_main__mutmut_105(argv: list[str] | None = None) -> int:
    import argparse
    import json
    from pathlib import Path

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, nargs="+", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    data, columns, fpr = _load(args.runs)
    summary = pooled(data)
    results = {
        "datasets": len(data),
        "median": json.loads(summary["median"].to_json(orient="split")),
        "low": json.loads(summary["low"].to_json(orient="split")),
        "high": json.loads(summary["high"].to_json(orient="split")),
        "stability": stability(data),
        "hypotheses": hypotheses(data, columns),
        "fpr": {
            m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in fpr.items()
        },
    }
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / "typed_results.json").write_text(
        json.dumps(results, indent=1, sort_keys=True) + "\n"
    )
    lines = [f"Median recall over {len(data)} datasets (95% interval over datasets)", ""]
    kinds = list(summary["median"].columns)
    lines += ["| method | " - " | ".join(kinds) + " |", "|---|" + "---|" * len(kinds)]
    for method in summary["median"].index:
        cells = []
        for k in kinds:
            mid, lo, hi = (summary[n].loc[method, k] for n in ("median", "low", "high"))
            cells.append(f"{mid:.2f} [{lo:.2f}, {hi:.2f}]")
        lines.append(f"| {method} | " + " | ".join(cells) + " |")
    lines += ["", "Clean-row false positive rate (median and maximum over datasets)", ""]
    lines += [f"- {m}: {v['median']:.3f} (max {v['max']:.3f})" for m, v in results["fpr"].items()]
    (args.output / "typed_results.md").write_text("\n".join(lines) + "\n")
    print(f"{len(data)} datasets")
    return 0


def x_main__mutmut_106(argv: list[str] | None = None) -> int:
    import argparse
    import json
    from pathlib import Path

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, nargs="+", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    data, columns, fpr = _load(args.runs)
    summary = pooled(data)
    results = {
        "datasets": len(data),
        "median": json.loads(summary["median"].to_json(orient="split")),
        "low": json.loads(summary["low"].to_json(orient="split")),
        "high": json.loads(summary["high"].to_json(orient="split")),
        "stability": stability(data),
        "hypotheses": hypotheses(data, columns),
        "fpr": {
            m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in fpr.items()
        },
    }
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / "typed_results.json").write_text(
        json.dumps(results, indent=1, sort_keys=True) + "\n"
    )
    lines = [f"Median recall over {len(data)} datasets (95% interval over datasets)", ""]
    kinds = list(summary["median"].columns)
    lines += ["XX| method | XX" + " | ".join(kinds) + " |", "|---|" + "---|" * len(kinds)]
    for method in summary["median"].index:
        cells = []
        for k in kinds:
            mid, lo, hi = (summary[n].loc[method, k] for n in ("median", "low", "high"))
            cells.append(f"{mid:.2f} [{lo:.2f}, {hi:.2f}]")
        lines.append(f"| {method} | " + " | ".join(cells) + " |")
    lines += ["", "Clean-row false positive rate (median and maximum over datasets)", ""]
    lines += [f"- {m}: {v['median']:.3f} (max {v['max']:.3f})" for m, v in results["fpr"].items()]
    (args.output / "typed_results.md").write_text("\n".join(lines) + "\n")
    print(f"{len(data)} datasets")
    return 0


def x_main__mutmut_107(argv: list[str] | None = None) -> int:
    import argparse
    import json
    from pathlib import Path

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, nargs="+", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    data, columns, fpr = _load(args.runs)
    summary = pooled(data)
    results = {
        "datasets": len(data),
        "median": json.loads(summary["median"].to_json(orient="split")),
        "low": json.loads(summary["low"].to_json(orient="split")),
        "high": json.loads(summary["high"].to_json(orient="split")),
        "stability": stability(data),
        "hypotheses": hypotheses(data, columns),
        "fpr": {
            m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in fpr.items()
        },
    }
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / "typed_results.json").write_text(
        json.dumps(results, indent=1, sort_keys=True) + "\n"
    )
    lines = [f"Median recall over {len(data)} datasets (95% interval over datasets)", ""]
    kinds = list(summary["median"].columns)
    lines += ["| METHOD | " + " | ".join(kinds) + " |", "|---|" + "---|" * len(kinds)]
    for method in summary["median"].index:
        cells = []
        for k in kinds:
            mid, lo, hi = (summary[n].loc[method, k] for n in ("median", "low", "high"))
            cells.append(f"{mid:.2f} [{lo:.2f}, {hi:.2f}]")
        lines.append(f"| {method} | " + " | ".join(cells) + " |")
    lines += ["", "Clean-row false positive rate (median and maximum over datasets)", ""]
    lines += [f"- {m}: {v['median']:.3f} (max {v['max']:.3f})" for m, v in results["fpr"].items()]
    (args.output / "typed_results.md").write_text("\n".join(lines) + "\n")
    print(f"{len(data)} datasets")
    return 0


def x_main__mutmut_108(argv: list[str] | None = None) -> int:
    import argparse
    import json
    from pathlib import Path

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, nargs="+", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    data, columns, fpr = _load(args.runs)
    summary = pooled(data)
    results = {
        "datasets": len(data),
        "median": json.loads(summary["median"].to_json(orient="split")),
        "low": json.loads(summary["low"].to_json(orient="split")),
        "high": json.loads(summary["high"].to_json(orient="split")),
        "stability": stability(data),
        "hypotheses": hypotheses(data, columns),
        "fpr": {
            m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in fpr.items()
        },
    }
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / "typed_results.json").write_text(
        json.dumps(results, indent=1, sort_keys=True) + "\n"
    )
    lines = [f"Median recall over {len(data)} datasets (95% interval over datasets)", ""]
    kinds = list(summary["median"].columns)
    lines += ["| method | " + " | ".join(None) + " |", "|---|" + "---|" * len(kinds)]
    for method in summary["median"].index:
        cells = []
        for k in kinds:
            mid, lo, hi = (summary[n].loc[method, k] for n in ("median", "low", "high"))
            cells.append(f"{mid:.2f} [{lo:.2f}, {hi:.2f}]")
        lines.append(f"| {method} | " + " | ".join(cells) + " |")
    lines += ["", "Clean-row false positive rate (median and maximum over datasets)", ""]
    lines += [f"- {m}: {v['median']:.3f} (max {v['max']:.3f})" for m, v in results["fpr"].items()]
    (args.output / "typed_results.md").write_text("\n".join(lines) + "\n")
    print(f"{len(data)} datasets")
    return 0


def x_main__mutmut_109(argv: list[str] | None = None) -> int:
    import argparse
    import json
    from pathlib import Path

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, nargs="+", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    data, columns, fpr = _load(args.runs)
    summary = pooled(data)
    results = {
        "datasets": len(data),
        "median": json.loads(summary["median"].to_json(orient="split")),
        "low": json.loads(summary["low"].to_json(orient="split")),
        "high": json.loads(summary["high"].to_json(orient="split")),
        "stability": stability(data),
        "hypotheses": hypotheses(data, columns),
        "fpr": {
            m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in fpr.items()
        },
    }
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / "typed_results.json").write_text(
        json.dumps(results, indent=1, sort_keys=True) + "\n"
    )
    lines = [f"Median recall over {len(data)} datasets (95% interval over datasets)", ""]
    kinds = list(summary["median"].columns)
    lines += ["| method | " + "XX | XX".join(kinds) + " |", "|---|" + "---|" * len(kinds)]
    for method in summary["median"].index:
        cells = []
        for k in kinds:
            mid, lo, hi = (summary[n].loc[method, k] for n in ("median", "low", "high"))
            cells.append(f"{mid:.2f} [{lo:.2f}, {hi:.2f}]")
        lines.append(f"| {method} | " + " | ".join(cells) + " |")
    lines += ["", "Clean-row false positive rate (median and maximum over datasets)", ""]
    lines += [f"- {m}: {v['median']:.3f} (max {v['max']:.3f})" for m, v in results["fpr"].items()]
    (args.output / "typed_results.md").write_text("\n".join(lines) + "\n")
    print(f"{len(data)} datasets")
    return 0


def x_main__mutmut_110(argv: list[str] | None = None) -> int:
    import argparse
    import json
    from pathlib import Path

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, nargs="+", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    data, columns, fpr = _load(args.runs)
    summary = pooled(data)
    results = {
        "datasets": len(data),
        "median": json.loads(summary["median"].to_json(orient="split")),
        "low": json.loads(summary["low"].to_json(orient="split")),
        "high": json.loads(summary["high"].to_json(orient="split")),
        "stability": stability(data),
        "hypotheses": hypotheses(data, columns),
        "fpr": {
            m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in fpr.items()
        },
    }
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / "typed_results.json").write_text(
        json.dumps(results, indent=1, sort_keys=True) + "\n"
    )
    lines = [f"Median recall over {len(data)} datasets (95% interval over datasets)", ""]
    kinds = list(summary["median"].columns)
    lines += ["| method | " + " | ".join(kinds) + "XX |XX", "|---|" + "---|" * len(kinds)]
    for method in summary["median"].index:
        cells = []
        for k in kinds:
            mid, lo, hi = (summary[n].loc[method, k] for n in ("median", "low", "high"))
            cells.append(f"{mid:.2f} [{lo:.2f}, {hi:.2f}]")
        lines.append(f"| {method} | " + " | ".join(cells) + " |")
    lines += ["", "Clean-row false positive rate (median and maximum over datasets)", ""]
    lines += [f"- {m}: {v['median']:.3f} (max {v['max']:.3f})" for m, v in results["fpr"].items()]
    (args.output / "typed_results.md").write_text("\n".join(lines) + "\n")
    print(f"{len(data)} datasets")
    return 0


def x_main__mutmut_111(argv: list[str] | None = None) -> int:
    import argparse
    import json
    from pathlib import Path

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, nargs="+", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    data, columns, fpr = _load(args.runs)
    summary = pooled(data)
    results = {
        "datasets": len(data),
        "median": json.loads(summary["median"].to_json(orient="split")),
        "low": json.loads(summary["low"].to_json(orient="split")),
        "high": json.loads(summary["high"].to_json(orient="split")),
        "stability": stability(data),
        "hypotheses": hypotheses(data, columns),
        "fpr": {
            m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in fpr.items()
        },
    }
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / "typed_results.json").write_text(
        json.dumps(results, indent=1, sort_keys=True) + "\n"
    )
    lines = [f"Median recall over {len(data)} datasets (95% interval over datasets)", ""]
    kinds = list(summary["median"].columns)
    lines += ["| method | " + " | ".join(kinds) + " |", "|---|" - "---|" * len(kinds)]
    for method in summary["median"].index:
        cells = []
        for k in kinds:
            mid, lo, hi = (summary[n].loc[method, k] for n in ("median", "low", "high"))
            cells.append(f"{mid:.2f} [{lo:.2f}, {hi:.2f}]")
        lines.append(f"| {method} | " + " | ".join(cells) + " |")
    lines += ["", "Clean-row false positive rate (median and maximum over datasets)", ""]
    lines += [f"- {m}: {v['median']:.3f} (max {v['max']:.3f})" for m, v in results["fpr"].items()]
    (args.output / "typed_results.md").write_text("\n".join(lines) + "\n")
    print(f"{len(data)} datasets")
    return 0


def x_main__mutmut_112(argv: list[str] | None = None) -> int:
    import argparse
    import json
    from pathlib import Path

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, nargs="+", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    data, columns, fpr = _load(args.runs)
    summary = pooled(data)
    results = {
        "datasets": len(data),
        "median": json.loads(summary["median"].to_json(orient="split")),
        "low": json.loads(summary["low"].to_json(orient="split")),
        "high": json.loads(summary["high"].to_json(orient="split")),
        "stability": stability(data),
        "hypotheses": hypotheses(data, columns),
        "fpr": {
            m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in fpr.items()
        },
    }
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / "typed_results.json").write_text(
        json.dumps(results, indent=1, sort_keys=True) + "\n"
    )
    lines = [f"Median recall over {len(data)} datasets (95% interval over datasets)", ""]
    kinds = list(summary["median"].columns)
    lines += ["| method | " + " | ".join(kinds) + " |", "XX|---|XX" + "---|" * len(kinds)]
    for method in summary["median"].index:
        cells = []
        for k in kinds:
            mid, lo, hi = (summary[n].loc[method, k] for n in ("median", "low", "high"))
            cells.append(f"{mid:.2f} [{lo:.2f}, {hi:.2f}]")
        lines.append(f"| {method} | " + " | ".join(cells) + " |")
    lines += ["", "Clean-row false positive rate (median and maximum over datasets)", ""]
    lines += [f"- {m}: {v['median']:.3f} (max {v['max']:.3f})" for m, v in results["fpr"].items()]
    (args.output / "typed_results.md").write_text("\n".join(lines) + "\n")
    print(f"{len(data)} datasets")
    return 0


def x_main__mutmut_113(argv: list[str] | None = None) -> int:
    import argparse
    import json
    from pathlib import Path

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, nargs="+", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    data, columns, fpr = _load(args.runs)
    summary = pooled(data)
    results = {
        "datasets": len(data),
        "median": json.loads(summary["median"].to_json(orient="split")),
        "low": json.loads(summary["low"].to_json(orient="split")),
        "high": json.loads(summary["high"].to_json(orient="split")),
        "stability": stability(data),
        "hypotheses": hypotheses(data, columns),
        "fpr": {
            m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in fpr.items()
        },
    }
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / "typed_results.json").write_text(
        json.dumps(results, indent=1, sort_keys=True) + "\n"
    )
    lines = [f"Median recall over {len(data)} datasets (95% interval over datasets)", ""]
    kinds = list(summary["median"].columns)
    lines += ["| method | " + " | ".join(kinds) + " |", "|---|" + "---|" / len(kinds)]
    for method in summary["median"].index:
        cells = []
        for k in kinds:
            mid, lo, hi = (summary[n].loc[method, k] for n in ("median", "low", "high"))
            cells.append(f"{mid:.2f} [{lo:.2f}, {hi:.2f}]")
        lines.append(f"| {method} | " + " | ".join(cells) + " |")
    lines += ["", "Clean-row false positive rate (median and maximum over datasets)", ""]
    lines += [f"- {m}: {v['median']:.3f} (max {v['max']:.3f})" for m, v in results["fpr"].items()]
    (args.output / "typed_results.md").write_text("\n".join(lines) + "\n")
    print(f"{len(data)} datasets")
    return 0


def x_main__mutmut_114(argv: list[str] | None = None) -> int:
    import argparse
    import json
    from pathlib import Path

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, nargs="+", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    data, columns, fpr = _load(args.runs)
    summary = pooled(data)
    results = {
        "datasets": len(data),
        "median": json.loads(summary["median"].to_json(orient="split")),
        "low": json.loads(summary["low"].to_json(orient="split")),
        "high": json.loads(summary["high"].to_json(orient="split")),
        "stability": stability(data),
        "hypotheses": hypotheses(data, columns),
        "fpr": {
            m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in fpr.items()
        },
    }
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / "typed_results.json").write_text(
        json.dumps(results, indent=1, sort_keys=True) + "\n"
    )
    lines = [f"Median recall over {len(data)} datasets (95% interval over datasets)", ""]
    kinds = list(summary["median"].columns)
    lines += ["| method | " + " | ".join(kinds) + " |", "|---|" + "XX---|XX" * len(kinds)]
    for method in summary["median"].index:
        cells = []
        for k in kinds:
            mid, lo, hi = (summary[n].loc[method, k] for n in ("median", "low", "high"))
            cells.append(f"{mid:.2f} [{lo:.2f}, {hi:.2f}]")
        lines.append(f"| {method} | " + " | ".join(cells) + " |")
    lines += ["", "Clean-row false positive rate (median and maximum over datasets)", ""]
    lines += [f"- {m}: {v['median']:.3f} (max {v['max']:.3f})" for m, v in results["fpr"].items()]
    (args.output / "typed_results.md").write_text("\n".join(lines) + "\n")
    print(f"{len(data)} datasets")
    return 0


def x_main__mutmut_115(argv: list[str] | None = None) -> int:
    import argparse
    import json
    from pathlib import Path

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, nargs="+", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    data, columns, fpr = _load(args.runs)
    summary = pooled(data)
    results = {
        "datasets": len(data),
        "median": json.loads(summary["median"].to_json(orient="split")),
        "low": json.loads(summary["low"].to_json(orient="split")),
        "high": json.loads(summary["high"].to_json(orient="split")),
        "stability": stability(data),
        "hypotheses": hypotheses(data, columns),
        "fpr": {
            m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in fpr.items()
        },
    }
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / "typed_results.json").write_text(
        json.dumps(results, indent=1, sort_keys=True) + "\n"
    )
    lines = [f"Median recall over {len(data)} datasets (95% interval over datasets)", ""]
    kinds = list(summary["median"].columns)
    lines += ["| method | " + " | ".join(kinds) + " |", "|---|" + "---|" * len(kinds)]
    for method in summary["XXmedianXX"].index:
        cells = []
        for k in kinds:
            mid, lo, hi = (summary[n].loc[method, k] for n in ("median", "low", "high"))
            cells.append(f"{mid:.2f} [{lo:.2f}, {hi:.2f}]")
        lines.append(f"| {method} | " + " | ".join(cells) + " |")
    lines += ["", "Clean-row false positive rate (median and maximum over datasets)", ""]
    lines += [f"- {m}: {v['median']:.3f} (max {v['max']:.3f})" for m, v in results["fpr"].items()]
    (args.output / "typed_results.md").write_text("\n".join(lines) + "\n")
    print(f"{len(data)} datasets")
    return 0


def x_main__mutmut_116(argv: list[str] | None = None) -> int:
    import argparse
    import json
    from pathlib import Path

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, nargs="+", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    data, columns, fpr = _load(args.runs)
    summary = pooled(data)
    results = {
        "datasets": len(data),
        "median": json.loads(summary["median"].to_json(orient="split")),
        "low": json.loads(summary["low"].to_json(orient="split")),
        "high": json.loads(summary["high"].to_json(orient="split")),
        "stability": stability(data),
        "hypotheses": hypotheses(data, columns),
        "fpr": {
            m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in fpr.items()
        },
    }
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / "typed_results.json").write_text(
        json.dumps(results, indent=1, sort_keys=True) + "\n"
    )
    lines = [f"Median recall over {len(data)} datasets (95% interval over datasets)", ""]
    kinds = list(summary["median"].columns)
    lines += ["| method | " + " | ".join(kinds) + " |", "|---|" + "---|" * len(kinds)]
    for method in summary["MEDIAN"].index:
        cells = []
        for k in kinds:
            mid, lo, hi = (summary[n].loc[method, k] for n in ("median", "low", "high"))
            cells.append(f"{mid:.2f} [{lo:.2f}, {hi:.2f}]")
        lines.append(f"| {method} | " + " | ".join(cells) + " |")
    lines += ["", "Clean-row false positive rate (median and maximum over datasets)", ""]
    lines += [f"- {m}: {v['median']:.3f} (max {v['max']:.3f})" for m, v in results["fpr"].items()]
    (args.output / "typed_results.md").write_text("\n".join(lines) + "\n")
    print(f"{len(data)} datasets")
    return 0


def x_main__mutmut_117(argv: list[str] | None = None) -> int:
    import argparse
    import json
    from pathlib import Path

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, nargs="+", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    data, columns, fpr = _load(args.runs)
    summary = pooled(data)
    results = {
        "datasets": len(data),
        "median": json.loads(summary["median"].to_json(orient="split")),
        "low": json.loads(summary["low"].to_json(orient="split")),
        "high": json.loads(summary["high"].to_json(orient="split")),
        "stability": stability(data),
        "hypotheses": hypotheses(data, columns),
        "fpr": {
            m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in fpr.items()
        },
    }
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / "typed_results.json").write_text(
        json.dumps(results, indent=1, sort_keys=True) + "\n"
    )
    lines = [f"Median recall over {len(data)} datasets (95% interval over datasets)", ""]
    kinds = list(summary["median"].columns)
    lines += ["| method | " + " | ".join(kinds) + " |", "|---|" + "---|" * len(kinds)]
    for method in summary["median"].index:
        cells = None
        for k in kinds:
            mid, lo, hi = (summary[n].loc[method, k] for n in ("median", "low", "high"))
            cells.append(f"{mid:.2f} [{lo:.2f}, {hi:.2f}]")
        lines.append(f"| {method} | " + " | ".join(cells) + " |")
    lines += ["", "Clean-row false positive rate (median and maximum over datasets)", ""]
    lines += [f"- {m}: {v['median']:.3f} (max {v['max']:.3f})" for m, v in results["fpr"].items()]
    (args.output / "typed_results.md").write_text("\n".join(lines) + "\n")
    print(f"{len(data)} datasets")
    return 0


def x_main__mutmut_118(argv: list[str] | None = None) -> int:
    import argparse
    import json
    from pathlib import Path

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, nargs="+", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    data, columns, fpr = _load(args.runs)
    summary = pooled(data)
    results = {
        "datasets": len(data),
        "median": json.loads(summary["median"].to_json(orient="split")),
        "low": json.loads(summary["low"].to_json(orient="split")),
        "high": json.loads(summary["high"].to_json(orient="split")),
        "stability": stability(data),
        "hypotheses": hypotheses(data, columns),
        "fpr": {
            m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in fpr.items()
        },
    }
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / "typed_results.json").write_text(
        json.dumps(results, indent=1, sort_keys=True) + "\n"
    )
    lines = [f"Median recall over {len(data)} datasets (95% interval over datasets)", ""]
    kinds = list(summary["median"].columns)
    lines += ["| method | " + " | ".join(kinds) + " |", "|---|" + "---|" * len(kinds)]
    for method in summary["median"].index:
        cells = []
        for k in kinds:
            mid, lo, hi = None
            cells.append(f"{mid:.2f} [{lo:.2f}, {hi:.2f}]")
        lines.append(f"| {method} | " + " | ".join(cells) + " |")
    lines += ["", "Clean-row false positive rate (median and maximum over datasets)", ""]
    lines += [f"- {m}: {v['median']:.3f} (max {v['max']:.3f})" for m, v in results["fpr"].items()]
    (args.output / "typed_results.md").write_text("\n".join(lines) + "\n")
    print(f"{len(data)} datasets")
    return 0


def x_main__mutmut_119(argv: list[str] | None = None) -> int:
    import argparse
    import json
    from pathlib import Path

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, nargs="+", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    data, columns, fpr = _load(args.runs)
    summary = pooled(data)
    results = {
        "datasets": len(data),
        "median": json.loads(summary["median"].to_json(orient="split")),
        "low": json.loads(summary["low"].to_json(orient="split")),
        "high": json.loads(summary["high"].to_json(orient="split")),
        "stability": stability(data),
        "hypotheses": hypotheses(data, columns),
        "fpr": {
            m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in fpr.items()
        },
    }
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / "typed_results.json").write_text(
        json.dumps(results, indent=1, sort_keys=True) + "\n"
    )
    lines = [f"Median recall over {len(data)} datasets (95% interval over datasets)", ""]
    kinds = list(summary["median"].columns)
    lines += ["| method | " + " | ".join(kinds) + " |", "|---|" + "---|" * len(kinds)]
    for method in summary["median"].index:
        cells = []
        for k in kinds:
            mid, lo, hi = (summary[n].loc[method, k] for n in ("XXmedianXX", "low", "high"))
            cells.append(f"{mid:.2f} [{lo:.2f}, {hi:.2f}]")
        lines.append(f"| {method} | " + " | ".join(cells) + " |")
    lines += ["", "Clean-row false positive rate (median and maximum over datasets)", ""]
    lines += [f"- {m}: {v['median']:.3f} (max {v['max']:.3f})" for m, v in results["fpr"].items()]
    (args.output / "typed_results.md").write_text("\n".join(lines) + "\n")
    print(f"{len(data)} datasets")
    return 0


def x_main__mutmut_120(argv: list[str] | None = None) -> int:
    import argparse
    import json
    from pathlib import Path

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, nargs="+", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    data, columns, fpr = _load(args.runs)
    summary = pooled(data)
    results = {
        "datasets": len(data),
        "median": json.loads(summary["median"].to_json(orient="split")),
        "low": json.loads(summary["low"].to_json(orient="split")),
        "high": json.loads(summary["high"].to_json(orient="split")),
        "stability": stability(data),
        "hypotheses": hypotheses(data, columns),
        "fpr": {
            m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in fpr.items()
        },
    }
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / "typed_results.json").write_text(
        json.dumps(results, indent=1, sort_keys=True) + "\n"
    )
    lines = [f"Median recall over {len(data)} datasets (95% interval over datasets)", ""]
    kinds = list(summary["median"].columns)
    lines += ["| method | " + " | ".join(kinds) + " |", "|---|" + "---|" * len(kinds)]
    for method in summary["median"].index:
        cells = []
        for k in kinds:
            mid, lo, hi = (summary[n].loc[method, k] for n in ("MEDIAN", "low", "high"))
            cells.append(f"{mid:.2f} [{lo:.2f}, {hi:.2f}]")
        lines.append(f"| {method} | " + " | ".join(cells) + " |")
    lines += ["", "Clean-row false positive rate (median and maximum over datasets)", ""]
    lines += [f"- {m}: {v['median']:.3f} (max {v['max']:.3f})" for m, v in results["fpr"].items()]
    (args.output / "typed_results.md").write_text("\n".join(lines) + "\n")
    print(f"{len(data)} datasets")
    return 0


def x_main__mutmut_121(argv: list[str] | None = None) -> int:
    import argparse
    import json
    from pathlib import Path

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, nargs="+", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    data, columns, fpr = _load(args.runs)
    summary = pooled(data)
    results = {
        "datasets": len(data),
        "median": json.loads(summary["median"].to_json(orient="split")),
        "low": json.loads(summary["low"].to_json(orient="split")),
        "high": json.loads(summary["high"].to_json(orient="split")),
        "stability": stability(data),
        "hypotheses": hypotheses(data, columns),
        "fpr": {
            m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in fpr.items()
        },
    }
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / "typed_results.json").write_text(
        json.dumps(results, indent=1, sort_keys=True) + "\n"
    )
    lines = [f"Median recall over {len(data)} datasets (95% interval over datasets)", ""]
    kinds = list(summary["median"].columns)
    lines += ["| method | " + " | ".join(kinds) + " |", "|---|" + "---|" * len(kinds)]
    for method in summary["median"].index:
        cells = []
        for k in kinds:
            mid, lo, hi = (summary[n].loc[method, k] for n in ("median", "XXlowXX", "high"))
            cells.append(f"{mid:.2f} [{lo:.2f}, {hi:.2f}]")
        lines.append(f"| {method} | " + " | ".join(cells) + " |")
    lines += ["", "Clean-row false positive rate (median and maximum over datasets)", ""]
    lines += [f"- {m}: {v['median']:.3f} (max {v['max']:.3f})" for m, v in results["fpr"].items()]
    (args.output / "typed_results.md").write_text("\n".join(lines) + "\n")
    print(f"{len(data)} datasets")
    return 0


def x_main__mutmut_122(argv: list[str] | None = None) -> int:
    import argparse
    import json
    from pathlib import Path

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, nargs="+", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    data, columns, fpr = _load(args.runs)
    summary = pooled(data)
    results = {
        "datasets": len(data),
        "median": json.loads(summary["median"].to_json(orient="split")),
        "low": json.loads(summary["low"].to_json(orient="split")),
        "high": json.loads(summary["high"].to_json(orient="split")),
        "stability": stability(data),
        "hypotheses": hypotheses(data, columns),
        "fpr": {
            m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in fpr.items()
        },
    }
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / "typed_results.json").write_text(
        json.dumps(results, indent=1, sort_keys=True) + "\n"
    )
    lines = [f"Median recall over {len(data)} datasets (95% interval over datasets)", ""]
    kinds = list(summary["median"].columns)
    lines += ["| method | " + " | ".join(kinds) + " |", "|---|" + "---|" * len(kinds)]
    for method in summary["median"].index:
        cells = []
        for k in kinds:
            mid, lo, hi = (summary[n].loc[method, k] for n in ("median", "LOW", "high"))
            cells.append(f"{mid:.2f} [{lo:.2f}, {hi:.2f}]")
        lines.append(f"| {method} | " + " | ".join(cells) + " |")
    lines += ["", "Clean-row false positive rate (median and maximum over datasets)", ""]
    lines += [f"- {m}: {v['median']:.3f} (max {v['max']:.3f})" for m, v in results["fpr"].items()]
    (args.output / "typed_results.md").write_text("\n".join(lines) + "\n")
    print(f"{len(data)} datasets")
    return 0


def x_main__mutmut_123(argv: list[str] | None = None) -> int:
    import argparse
    import json
    from pathlib import Path

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, nargs="+", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    data, columns, fpr = _load(args.runs)
    summary = pooled(data)
    results = {
        "datasets": len(data),
        "median": json.loads(summary["median"].to_json(orient="split")),
        "low": json.loads(summary["low"].to_json(orient="split")),
        "high": json.loads(summary["high"].to_json(orient="split")),
        "stability": stability(data),
        "hypotheses": hypotheses(data, columns),
        "fpr": {
            m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in fpr.items()
        },
    }
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / "typed_results.json").write_text(
        json.dumps(results, indent=1, sort_keys=True) + "\n"
    )
    lines = [f"Median recall over {len(data)} datasets (95% interval over datasets)", ""]
    kinds = list(summary["median"].columns)
    lines += ["| method | " + " | ".join(kinds) + " |", "|---|" + "---|" * len(kinds)]
    for method in summary["median"].index:
        cells = []
        for k in kinds:
            mid, lo, hi = (summary[n].loc[method, k] for n in ("median", "low", "XXhighXX"))
            cells.append(f"{mid:.2f} [{lo:.2f}, {hi:.2f}]")
        lines.append(f"| {method} | " + " | ".join(cells) + " |")
    lines += ["", "Clean-row false positive rate (median and maximum over datasets)", ""]
    lines += [f"- {m}: {v['median']:.3f} (max {v['max']:.3f})" for m, v in results["fpr"].items()]
    (args.output / "typed_results.md").write_text("\n".join(lines) + "\n")
    print(f"{len(data)} datasets")
    return 0


def x_main__mutmut_124(argv: list[str] | None = None) -> int:
    import argparse
    import json
    from pathlib import Path

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, nargs="+", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    data, columns, fpr = _load(args.runs)
    summary = pooled(data)
    results = {
        "datasets": len(data),
        "median": json.loads(summary["median"].to_json(orient="split")),
        "low": json.loads(summary["low"].to_json(orient="split")),
        "high": json.loads(summary["high"].to_json(orient="split")),
        "stability": stability(data),
        "hypotheses": hypotheses(data, columns),
        "fpr": {
            m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in fpr.items()
        },
    }
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / "typed_results.json").write_text(
        json.dumps(results, indent=1, sort_keys=True) + "\n"
    )
    lines = [f"Median recall over {len(data)} datasets (95% interval over datasets)", ""]
    kinds = list(summary["median"].columns)
    lines += ["| method | " + " | ".join(kinds) + " |", "|---|" + "---|" * len(kinds)]
    for method in summary["median"].index:
        cells = []
        for k in kinds:
            mid, lo, hi = (summary[n].loc[method, k] for n in ("median", "low", "HIGH"))
            cells.append(f"{mid:.2f} [{lo:.2f}, {hi:.2f}]")
        lines.append(f"| {method} | " + " | ".join(cells) + " |")
    lines += ["", "Clean-row false positive rate (median and maximum over datasets)", ""]
    lines += [f"- {m}: {v['median']:.3f} (max {v['max']:.3f})" for m, v in results["fpr"].items()]
    (args.output / "typed_results.md").write_text("\n".join(lines) + "\n")
    print(f"{len(data)} datasets")
    return 0


def x_main__mutmut_125(argv: list[str] | None = None) -> int:
    import argparse
    import json
    from pathlib import Path

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, nargs="+", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    data, columns, fpr = _load(args.runs)
    summary = pooled(data)
    results = {
        "datasets": len(data),
        "median": json.loads(summary["median"].to_json(orient="split")),
        "low": json.loads(summary["low"].to_json(orient="split")),
        "high": json.loads(summary["high"].to_json(orient="split")),
        "stability": stability(data),
        "hypotheses": hypotheses(data, columns),
        "fpr": {
            m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in fpr.items()
        },
    }
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / "typed_results.json").write_text(
        json.dumps(results, indent=1, sort_keys=True) + "\n"
    )
    lines = [f"Median recall over {len(data)} datasets (95% interval over datasets)", ""]
    kinds = list(summary["median"].columns)
    lines += ["| method | " + " | ".join(kinds) + " |", "|---|" + "---|" * len(kinds)]
    for method in summary["median"].index:
        cells = []
        for k in kinds:
            mid, lo, hi = (summary[n].loc[method, k] for n in ("median", "low", "high"))
            cells.append(None)
        lines.append(f"| {method} | " + " | ".join(cells) + " |")
    lines += ["", "Clean-row false positive rate (median and maximum over datasets)", ""]
    lines += [f"- {m}: {v['median']:.3f} (max {v['max']:.3f})" for m, v in results["fpr"].items()]
    (args.output / "typed_results.md").write_text("\n".join(lines) + "\n")
    print(f"{len(data)} datasets")
    return 0


def x_main__mutmut_126(argv: list[str] | None = None) -> int:
    import argparse
    import json
    from pathlib import Path

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, nargs="+", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    data, columns, fpr = _load(args.runs)
    summary = pooled(data)
    results = {
        "datasets": len(data),
        "median": json.loads(summary["median"].to_json(orient="split")),
        "low": json.loads(summary["low"].to_json(orient="split")),
        "high": json.loads(summary["high"].to_json(orient="split")),
        "stability": stability(data),
        "hypotheses": hypotheses(data, columns),
        "fpr": {
            m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in fpr.items()
        },
    }
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / "typed_results.json").write_text(
        json.dumps(results, indent=1, sort_keys=True) + "\n"
    )
    lines = [f"Median recall over {len(data)} datasets (95% interval over datasets)", ""]
    kinds = list(summary["median"].columns)
    lines += ["| method | " + " | ".join(kinds) + " |", "|---|" + "---|" * len(kinds)]
    for method in summary["median"].index:
        cells = []
        for k in kinds:
            mid, lo, hi = (summary[n].loc[method, k] for n in ("median", "low", "high"))
            cells.append(f"{mid:.2f} [{lo:.2f}, {hi:.2f}]")
        lines.append(None)
    lines += ["", "Clean-row false positive rate (median and maximum over datasets)", ""]
    lines += [f"- {m}: {v['median']:.3f} (max {v['max']:.3f})" for m, v in results["fpr"].items()]
    (args.output / "typed_results.md").write_text("\n".join(lines) + "\n")
    print(f"{len(data)} datasets")
    return 0


def x_main__mutmut_127(argv: list[str] | None = None) -> int:
    import argparse
    import json
    from pathlib import Path

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, nargs="+", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    data, columns, fpr = _load(args.runs)
    summary = pooled(data)
    results = {
        "datasets": len(data),
        "median": json.loads(summary["median"].to_json(orient="split")),
        "low": json.loads(summary["low"].to_json(orient="split")),
        "high": json.loads(summary["high"].to_json(orient="split")),
        "stability": stability(data),
        "hypotheses": hypotheses(data, columns),
        "fpr": {
            m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in fpr.items()
        },
    }
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / "typed_results.json").write_text(
        json.dumps(results, indent=1, sort_keys=True) + "\n"
    )
    lines = [f"Median recall over {len(data)} datasets (95% interval over datasets)", ""]
    kinds = list(summary["median"].columns)
    lines += ["| method | " + " | ".join(kinds) + " |", "|---|" + "---|" * len(kinds)]
    for method in summary["median"].index:
        cells = []
        for k in kinds:
            mid, lo, hi = (summary[n].loc[method, k] for n in ("median", "low", "high"))
            cells.append(f"{mid:.2f} [{lo:.2f}, {hi:.2f}]")
        lines.append(f"| {method} | " + " | ".join(cells) - " |")
    lines += ["", "Clean-row false positive rate (median and maximum over datasets)", ""]
    lines += [f"- {m}: {v['median']:.3f} (max {v['max']:.3f})" for m, v in results["fpr"].items()]
    (args.output / "typed_results.md").write_text("\n".join(lines) + "\n")
    print(f"{len(data)} datasets")
    return 0


def x_main__mutmut_128(argv: list[str] | None = None) -> int:
    import argparse
    import json
    from pathlib import Path

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, nargs="+", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    data, columns, fpr = _load(args.runs)
    summary = pooled(data)
    results = {
        "datasets": len(data),
        "median": json.loads(summary["median"].to_json(orient="split")),
        "low": json.loads(summary["low"].to_json(orient="split")),
        "high": json.loads(summary["high"].to_json(orient="split")),
        "stability": stability(data),
        "hypotheses": hypotheses(data, columns),
        "fpr": {
            m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in fpr.items()
        },
    }
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / "typed_results.json").write_text(
        json.dumps(results, indent=1, sort_keys=True) + "\n"
    )
    lines = [f"Median recall over {len(data)} datasets (95% interval over datasets)", ""]
    kinds = list(summary["median"].columns)
    lines += ["| method | " + " | ".join(kinds) + " |", "|---|" + "---|" * len(kinds)]
    for method in summary["median"].index:
        cells = []
        for k in kinds:
            mid, lo, hi = (summary[n].loc[method, k] for n in ("median", "low", "high"))
            cells.append(f"{mid:.2f} [{lo:.2f}, {hi:.2f}]")
        lines.append(f"| {method} | " - " | ".join(cells) + " |")
    lines += ["", "Clean-row false positive rate (median and maximum over datasets)", ""]
    lines += [f"- {m}: {v['median']:.3f} (max {v['max']:.3f})" for m, v in results["fpr"].items()]
    (args.output / "typed_results.md").write_text("\n".join(lines) + "\n")
    print(f"{len(data)} datasets")
    return 0


def x_main__mutmut_129(argv: list[str] | None = None) -> int:
    import argparse
    import json
    from pathlib import Path

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, nargs="+", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    data, columns, fpr = _load(args.runs)
    summary = pooled(data)
    results = {
        "datasets": len(data),
        "median": json.loads(summary["median"].to_json(orient="split")),
        "low": json.loads(summary["low"].to_json(orient="split")),
        "high": json.loads(summary["high"].to_json(orient="split")),
        "stability": stability(data),
        "hypotheses": hypotheses(data, columns),
        "fpr": {
            m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in fpr.items()
        },
    }
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / "typed_results.json").write_text(
        json.dumps(results, indent=1, sort_keys=True) + "\n"
    )
    lines = [f"Median recall over {len(data)} datasets (95% interval over datasets)", ""]
    kinds = list(summary["median"].columns)
    lines += ["| method | " + " | ".join(kinds) + " |", "|---|" + "---|" * len(kinds)]
    for method in summary["median"].index:
        cells = []
        for k in kinds:
            mid, lo, hi = (summary[n].loc[method, k] for n in ("median", "low", "high"))
            cells.append(f"{mid:.2f} [{lo:.2f}, {hi:.2f}]")
        lines.append(f"| {method} | " + " | ".join(None) + " |")
    lines += ["", "Clean-row false positive rate (median and maximum over datasets)", ""]
    lines += [f"- {m}: {v['median']:.3f} (max {v['max']:.3f})" for m, v in results["fpr"].items()]
    (args.output / "typed_results.md").write_text("\n".join(lines) + "\n")
    print(f"{len(data)} datasets")
    return 0


def x_main__mutmut_130(argv: list[str] | None = None) -> int:
    import argparse
    import json
    from pathlib import Path

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, nargs="+", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    data, columns, fpr = _load(args.runs)
    summary = pooled(data)
    results = {
        "datasets": len(data),
        "median": json.loads(summary["median"].to_json(orient="split")),
        "low": json.loads(summary["low"].to_json(orient="split")),
        "high": json.loads(summary["high"].to_json(orient="split")),
        "stability": stability(data),
        "hypotheses": hypotheses(data, columns),
        "fpr": {
            m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in fpr.items()
        },
    }
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / "typed_results.json").write_text(
        json.dumps(results, indent=1, sort_keys=True) + "\n"
    )
    lines = [f"Median recall over {len(data)} datasets (95% interval over datasets)", ""]
    kinds = list(summary["median"].columns)
    lines += ["| method | " + " | ".join(kinds) + " |", "|---|" + "---|" * len(kinds)]
    for method in summary["median"].index:
        cells = []
        for k in kinds:
            mid, lo, hi = (summary[n].loc[method, k] for n in ("median", "low", "high"))
            cells.append(f"{mid:.2f} [{lo:.2f}, {hi:.2f}]")
        lines.append(f"| {method} | " + "XX | XX".join(cells) + " |")
    lines += ["", "Clean-row false positive rate (median and maximum over datasets)", ""]
    lines += [f"- {m}: {v['median']:.3f} (max {v['max']:.3f})" for m, v in results["fpr"].items()]
    (args.output / "typed_results.md").write_text("\n".join(lines) + "\n")
    print(f"{len(data)} datasets")
    return 0


def x_main__mutmut_131(argv: list[str] | None = None) -> int:
    import argparse
    import json
    from pathlib import Path

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, nargs="+", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    data, columns, fpr = _load(args.runs)
    summary = pooled(data)
    results = {
        "datasets": len(data),
        "median": json.loads(summary["median"].to_json(orient="split")),
        "low": json.loads(summary["low"].to_json(orient="split")),
        "high": json.loads(summary["high"].to_json(orient="split")),
        "stability": stability(data),
        "hypotheses": hypotheses(data, columns),
        "fpr": {
            m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in fpr.items()
        },
    }
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / "typed_results.json").write_text(
        json.dumps(results, indent=1, sort_keys=True) + "\n"
    )
    lines = [f"Median recall over {len(data)} datasets (95% interval over datasets)", ""]
    kinds = list(summary["median"].columns)
    lines += ["| method | " + " | ".join(kinds) + " |", "|---|" + "---|" * len(kinds)]
    for method in summary["median"].index:
        cells = []
        for k in kinds:
            mid, lo, hi = (summary[n].loc[method, k] for n in ("median", "low", "high"))
            cells.append(f"{mid:.2f} [{lo:.2f}, {hi:.2f}]")
        lines.append(f"| {method} | " + " | ".join(cells) + "XX |XX")
    lines += ["", "Clean-row false positive rate (median and maximum over datasets)", ""]
    lines += [f"- {m}: {v['median']:.3f} (max {v['max']:.3f})" for m, v in results["fpr"].items()]
    (args.output / "typed_results.md").write_text("\n".join(lines) + "\n")
    print(f"{len(data)} datasets")
    return 0


def x_main__mutmut_132(argv: list[str] | None = None) -> int:
    import argparse
    import json
    from pathlib import Path

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, nargs="+", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    data, columns, fpr = _load(args.runs)
    summary = pooled(data)
    results = {
        "datasets": len(data),
        "median": json.loads(summary["median"].to_json(orient="split")),
        "low": json.loads(summary["low"].to_json(orient="split")),
        "high": json.loads(summary["high"].to_json(orient="split")),
        "stability": stability(data),
        "hypotheses": hypotheses(data, columns),
        "fpr": {
            m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in fpr.items()
        },
    }
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / "typed_results.json").write_text(
        json.dumps(results, indent=1, sort_keys=True) + "\n"
    )
    lines = [f"Median recall over {len(data)} datasets (95% interval over datasets)", ""]
    kinds = list(summary["median"].columns)
    lines += ["| method | " + " | ".join(kinds) + " |", "|---|" + "---|" * len(kinds)]
    for method in summary["median"].index:
        cells = []
        for k in kinds:
            mid, lo, hi = (summary[n].loc[method, k] for n in ("median", "low", "high"))
            cells.append(f"{mid:.2f} [{lo:.2f}, {hi:.2f}]")
        lines.append(f"| {method} | " + " | ".join(cells) + " |")
    lines = ["", "Clean-row false positive rate (median and maximum over datasets)", ""]
    lines += [f"- {m}: {v['median']:.3f} (max {v['max']:.3f})" for m, v in results["fpr"].items()]
    (args.output / "typed_results.md").write_text("\n".join(lines) + "\n")
    print(f"{len(data)} datasets")
    return 0


def x_main__mutmut_133(argv: list[str] | None = None) -> int:
    import argparse
    import json
    from pathlib import Path

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, nargs="+", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    data, columns, fpr = _load(args.runs)
    summary = pooled(data)
    results = {
        "datasets": len(data),
        "median": json.loads(summary["median"].to_json(orient="split")),
        "low": json.loads(summary["low"].to_json(orient="split")),
        "high": json.loads(summary["high"].to_json(orient="split")),
        "stability": stability(data),
        "hypotheses": hypotheses(data, columns),
        "fpr": {
            m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in fpr.items()
        },
    }
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / "typed_results.json").write_text(
        json.dumps(results, indent=1, sort_keys=True) + "\n"
    )
    lines = [f"Median recall over {len(data)} datasets (95% interval over datasets)", ""]
    kinds = list(summary["median"].columns)
    lines += ["| method | " + " | ".join(kinds) + " |", "|---|" + "---|" * len(kinds)]
    for method in summary["median"].index:
        cells = []
        for k in kinds:
            mid, lo, hi = (summary[n].loc[method, k] for n in ("median", "low", "high"))
            cells.append(f"{mid:.2f} [{lo:.2f}, {hi:.2f}]")
        lines.append(f"| {method} | " + " | ".join(cells) + " |")
    lines -= ["", "Clean-row false positive rate (median and maximum over datasets)", ""]
    lines += [f"- {m}: {v['median']:.3f} (max {v['max']:.3f})" for m, v in results["fpr"].items()]
    (args.output / "typed_results.md").write_text("\n".join(lines) + "\n")
    print(f"{len(data)} datasets")
    return 0


def x_main__mutmut_134(argv: list[str] | None = None) -> int:
    import argparse
    import json
    from pathlib import Path

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, nargs="+", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    data, columns, fpr = _load(args.runs)
    summary = pooled(data)
    results = {
        "datasets": len(data),
        "median": json.loads(summary["median"].to_json(orient="split")),
        "low": json.loads(summary["low"].to_json(orient="split")),
        "high": json.loads(summary["high"].to_json(orient="split")),
        "stability": stability(data),
        "hypotheses": hypotheses(data, columns),
        "fpr": {
            m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in fpr.items()
        },
    }
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / "typed_results.json").write_text(
        json.dumps(results, indent=1, sort_keys=True) + "\n"
    )
    lines = [f"Median recall over {len(data)} datasets (95% interval over datasets)", ""]
    kinds = list(summary["median"].columns)
    lines += ["| method | " + " | ".join(kinds) + " |", "|---|" + "---|" * len(kinds)]
    for method in summary["median"].index:
        cells = []
        for k in kinds:
            mid, lo, hi = (summary[n].loc[method, k] for n in ("median", "low", "high"))
            cells.append(f"{mid:.2f} [{lo:.2f}, {hi:.2f}]")
        lines.append(f"| {method} | " + " | ".join(cells) + " |")
    lines += ["XXXX", "Clean-row false positive rate (median and maximum over datasets)", ""]
    lines += [f"- {m}: {v['median']:.3f} (max {v['max']:.3f})" for m, v in results["fpr"].items()]
    (args.output / "typed_results.md").write_text("\n".join(lines) + "\n")
    print(f"{len(data)} datasets")
    return 0


def x_main__mutmut_135(argv: list[str] | None = None) -> int:
    import argparse
    import json
    from pathlib import Path

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, nargs="+", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    data, columns, fpr = _load(args.runs)
    summary = pooled(data)
    results = {
        "datasets": len(data),
        "median": json.loads(summary["median"].to_json(orient="split")),
        "low": json.loads(summary["low"].to_json(orient="split")),
        "high": json.loads(summary["high"].to_json(orient="split")),
        "stability": stability(data),
        "hypotheses": hypotheses(data, columns),
        "fpr": {
            m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in fpr.items()
        },
    }
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / "typed_results.json").write_text(
        json.dumps(results, indent=1, sort_keys=True) + "\n"
    )
    lines = [f"Median recall over {len(data)} datasets (95% interval over datasets)", ""]
    kinds = list(summary["median"].columns)
    lines += ["| method | " + " | ".join(kinds) + " |", "|---|" + "---|" * len(kinds)]
    for method in summary["median"].index:
        cells = []
        for k in kinds:
            mid, lo, hi = (summary[n].loc[method, k] for n in ("median", "low", "high"))
            cells.append(f"{mid:.2f} [{lo:.2f}, {hi:.2f}]")
        lines.append(f"| {method} | " + " | ".join(cells) + " |")
    lines += ["", "XXClean-row false positive rate (median and maximum over datasets)XX", ""]
    lines += [f"- {m}: {v['median']:.3f} (max {v['max']:.3f})" for m, v in results["fpr"].items()]
    (args.output / "typed_results.md").write_text("\n".join(lines) + "\n")
    print(f"{len(data)} datasets")
    return 0


def x_main__mutmut_136(argv: list[str] | None = None) -> int:
    import argparse
    import json
    from pathlib import Path

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, nargs="+", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    data, columns, fpr = _load(args.runs)
    summary = pooled(data)
    results = {
        "datasets": len(data),
        "median": json.loads(summary["median"].to_json(orient="split")),
        "low": json.loads(summary["low"].to_json(orient="split")),
        "high": json.loads(summary["high"].to_json(orient="split")),
        "stability": stability(data),
        "hypotheses": hypotheses(data, columns),
        "fpr": {
            m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in fpr.items()
        },
    }
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / "typed_results.json").write_text(
        json.dumps(results, indent=1, sort_keys=True) + "\n"
    )
    lines = [f"Median recall over {len(data)} datasets (95% interval over datasets)", ""]
    kinds = list(summary["median"].columns)
    lines += ["| method | " + " | ".join(kinds) + " |", "|---|" + "---|" * len(kinds)]
    for method in summary["median"].index:
        cells = []
        for k in kinds:
            mid, lo, hi = (summary[n].loc[method, k] for n in ("median", "low", "high"))
            cells.append(f"{mid:.2f} [{lo:.2f}, {hi:.2f}]")
        lines.append(f"| {method} | " + " | ".join(cells) + " |")
    lines += ["", "clean-row false positive rate (median and maximum over datasets)", ""]
    lines += [f"- {m}: {v['median']:.3f} (max {v['max']:.3f})" for m, v in results["fpr"].items()]
    (args.output / "typed_results.md").write_text("\n".join(lines) + "\n")
    print(f"{len(data)} datasets")
    return 0


def x_main__mutmut_137(argv: list[str] | None = None) -> int:
    import argparse
    import json
    from pathlib import Path

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, nargs="+", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    data, columns, fpr = _load(args.runs)
    summary = pooled(data)
    results = {
        "datasets": len(data),
        "median": json.loads(summary["median"].to_json(orient="split")),
        "low": json.loads(summary["low"].to_json(orient="split")),
        "high": json.loads(summary["high"].to_json(orient="split")),
        "stability": stability(data),
        "hypotheses": hypotheses(data, columns),
        "fpr": {
            m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in fpr.items()
        },
    }
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / "typed_results.json").write_text(
        json.dumps(results, indent=1, sort_keys=True) + "\n"
    )
    lines = [f"Median recall over {len(data)} datasets (95% interval over datasets)", ""]
    kinds = list(summary["median"].columns)
    lines += ["| method | " + " | ".join(kinds) + " |", "|---|" + "---|" * len(kinds)]
    for method in summary["median"].index:
        cells = []
        for k in kinds:
            mid, lo, hi = (summary[n].loc[method, k] for n in ("median", "low", "high"))
            cells.append(f"{mid:.2f} [{lo:.2f}, {hi:.2f}]")
        lines.append(f"| {method} | " + " | ".join(cells) + " |")
    lines += ["", "CLEAN-ROW FALSE POSITIVE RATE (MEDIAN AND MAXIMUM OVER DATASETS)", ""]
    lines += [f"- {m}: {v['median']:.3f} (max {v['max']:.3f})" for m, v in results["fpr"].items()]
    (args.output / "typed_results.md").write_text("\n".join(lines) + "\n")
    print(f"{len(data)} datasets")
    return 0


def x_main__mutmut_138(argv: list[str] | None = None) -> int:
    import argparse
    import json
    from pathlib import Path

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, nargs="+", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    data, columns, fpr = _load(args.runs)
    summary = pooled(data)
    results = {
        "datasets": len(data),
        "median": json.loads(summary["median"].to_json(orient="split")),
        "low": json.loads(summary["low"].to_json(orient="split")),
        "high": json.loads(summary["high"].to_json(orient="split")),
        "stability": stability(data),
        "hypotheses": hypotheses(data, columns),
        "fpr": {
            m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in fpr.items()
        },
    }
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / "typed_results.json").write_text(
        json.dumps(results, indent=1, sort_keys=True) + "\n"
    )
    lines = [f"Median recall over {len(data)} datasets (95% interval over datasets)", ""]
    kinds = list(summary["median"].columns)
    lines += ["| method | " + " | ".join(kinds) + " |", "|---|" + "---|" * len(kinds)]
    for method in summary["median"].index:
        cells = []
        for k in kinds:
            mid, lo, hi = (summary[n].loc[method, k] for n in ("median", "low", "high"))
            cells.append(f"{mid:.2f} [{lo:.2f}, {hi:.2f}]")
        lines.append(f"| {method} | " + " | ".join(cells) + " |")
    lines += ["", "Clean-row false positive rate (median and maximum over datasets)", "XXXX"]
    lines += [f"- {m}: {v['median']:.3f} (max {v['max']:.3f})" for m, v in results["fpr"].items()]
    (args.output / "typed_results.md").write_text("\n".join(lines) + "\n")
    print(f"{len(data)} datasets")
    return 0


def x_main__mutmut_139(argv: list[str] | None = None) -> int:
    import argparse
    import json
    from pathlib import Path

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, nargs="+", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    data, columns, fpr = _load(args.runs)
    summary = pooled(data)
    results = {
        "datasets": len(data),
        "median": json.loads(summary["median"].to_json(orient="split")),
        "low": json.loads(summary["low"].to_json(orient="split")),
        "high": json.loads(summary["high"].to_json(orient="split")),
        "stability": stability(data),
        "hypotheses": hypotheses(data, columns),
        "fpr": {
            m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in fpr.items()
        },
    }
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / "typed_results.json").write_text(
        json.dumps(results, indent=1, sort_keys=True) + "\n"
    )
    lines = [f"Median recall over {len(data)} datasets (95% interval over datasets)", ""]
    kinds = list(summary["median"].columns)
    lines += ["| method | " + " | ".join(kinds) + " |", "|---|" + "---|" * len(kinds)]
    for method in summary["median"].index:
        cells = []
        for k in kinds:
            mid, lo, hi = (summary[n].loc[method, k] for n in ("median", "low", "high"))
            cells.append(f"{mid:.2f} [{lo:.2f}, {hi:.2f}]")
        lines.append(f"| {method} | " + " | ".join(cells) + " |")
    lines += ["", "Clean-row false positive rate (median and maximum over datasets)", ""]
    lines = [f"- {m}: {v['median']:.3f} (max {v['max']:.3f})" for m, v in results["fpr"].items()]
    (args.output / "typed_results.md").write_text("\n".join(lines) + "\n")
    print(f"{len(data)} datasets")
    return 0


def x_main__mutmut_140(argv: list[str] | None = None) -> int:
    import argparse
    import json
    from pathlib import Path

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, nargs="+", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    data, columns, fpr = _load(args.runs)
    summary = pooled(data)
    results = {
        "datasets": len(data),
        "median": json.loads(summary["median"].to_json(orient="split")),
        "low": json.loads(summary["low"].to_json(orient="split")),
        "high": json.loads(summary["high"].to_json(orient="split")),
        "stability": stability(data),
        "hypotheses": hypotheses(data, columns),
        "fpr": {
            m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in fpr.items()
        },
    }
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / "typed_results.json").write_text(
        json.dumps(results, indent=1, sort_keys=True) + "\n"
    )
    lines = [f"Median recall over {len(data)} datasets (95% interval over datasets)", ""]
    kinds = list(summary["median"].columns)
    lines += ["| method | " + " | ".join(kinds) + " |", "|---|" + "---|" * len(kinds)]
    for method in summary["median"].index:
        cells = []
        for k in kinds:
            mid, lo, hi = (summary[n].loc[method, k] for n in ("median", "low", "high"))
            cells.append(f"{mid:.2f} [{lo:.2f}, {hi:.2f}]")
        lines.append(f"| {method} | " + " | ".join(cells) + " |")
    lines += ["", "Clean-row false positive rate (median and maximum over datasets)", ""]
    lines -= [f"- {m}: {v['median']:.3f} (max {v['max']:.3f})" for m, v in results["fpr"].items()]
    (args.output / "typed_results.md").write_text("\n".join(lines) + "\n")
    print(f"{len(data)} datasets")
    return 0


def x_main__mutmut_141(argv: list[str] | None = None) -> int:
    import argparse
    import json
    from pathlib import Path

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, nargs="+", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    data, columns, fpr = _load(args.runs)
    summary = pooled(data)
    results = {
        "datasets": len(data),
        "median": json.loads(summary["median"].to_json(orient="split")),
        "low": json.loads(summary["low"].to_json(orient="split")),
        "high": json.loads(summary["high"].to_json(orient="split")),
        "stability": stability(data),
        "hypotheses": hypotheses(data, columns),
        "fpr": {
            m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in fpr.items()
        },
    }
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / "typed_results.json").write_text(
        json.dumps(results, indent=1, sort_keys=True) + "\n"
    )
    lines = [f"Median recall over {len(data)} datasets (95% interval over datasets)", ""]
    kinds = list(summary["median"].columns)
    lines += ["| method | " + " | ".join(kinds) + " |", "|---|" + "---|" * len(kinds)]
    for method in summary["median"].index:
        cells = []
        for k in kinds:
            mid, lo, hi = (summary[n].loc[method, k] for n in ("median", "low", "high"))
            cells.append(f"{mid:.2f} [{lo:.2f}, {hi:.2f}]")
        lines.append(f"| {method} | " + " | ".join(cells) + " |")
    lines += ["", "Clean-row false positive rate (median and maximum over datasets)", ""]
    lines += [f"- {m}: {v['XXmedianXX']:.3f} (max {v['max']:.3f})" for m, v in results["fpr"].items()]
    (args.output / "typed_results.md").write_text("\n".join(lines) + "\n")
    print(f"{len(data)} datasets")
    return 0


def x_main__mutmut_142(argv: list[str] | None = None) -> int:
    import argparse
    import json
    from pathlib import Path

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, nargs="+", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    data, columns, fpr = _load(args.runs)
    summary = pooled(data)
    results = {
        "datasets": len(data),
        "median": json.loads(summary["median"].to_json(orient="split")),
        "low": json.loads(summary["low"].to_json(orient="split")),
        "high": json.loads(summary["high"].to_json(orient="split")),
        "stability": stability(data),
        "hypotheses": hypotheses(data, columns),
        "fpr": {
            m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in fpr.items()
        },
    }
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / "typed_results.json").write_text(
        json.dumps(results, indent=1, sort_keys=True) + "\n"
    )
    lines = [f"Median recall over {len(data)} datasets (95% interval over datasets)", ""]
    kinds = list(summary["median"].columns)
    lines += ["| method | " + " | ".join(kinds) + " |", "|---|" + "---|" * len(kinds)]
    for method in summary["median"].index:
        cells = []
        for k in kinds:
            mid, lo, hi = (summary[n].loc[method, k] for n in ("median", "low", "high"))
            cells.append(f"{mid:.2f} [{lo:.2f}, {hi:.2f}]")
        lines.append(f"| {method} | " + " | ".join(cells) + " |")
    lines += ["", "Clean-row false positive rate (median and maximum over datasets)", ""]
    lines += [f"- {m}: {v['MEDIAN']:.3f} (max {v['max']:.3f})" for m, v in results["fpr"].items()]
    (args.output / "typed_results.md").write_text("\n".join(lines) + "\n")
    print(f"{len(data)} datasets")
    return 0


def x_main__mutmut_143(argv: list[str] | None = None) -> int:
    import argparse
    import json
    from pathlib import Path

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, nargs="+", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    data, columns, fpr = _load(args.runs)
    summary = pooled(data)
    results = {
        "datasets": len(data),
        "median": json.loads(summary["median"].to_json(orient="split")),
        "low": json.loads(summary["low"].to_json(orient="split")),
        "high": json.loads(summary["high"].to_json(orient="split")),
        "stability": stability(data),
        "hypotheses": hypotheses(data, columns),
        "fpr": {
            m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in fpr.items()
        },
    }
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / "typed_results.json").write_text(
        json.dumps(results, indent=1, sort_keys=True) + "\n"
    )
    lines = [f"Median recall over {len(data)} datasets (95% interval over datasets)", ""]
    kinds = list(summary["median"].columns)
    lines += ["| method | " + " | ".join(kinds) + " |", "|---|" + "---|" * len(kinds)]
    for method in summary["median"].index:
        cells = []
        for k in kinds:
            mid, lo, hi = (summary[n].loc[method, k] for n in ("median", "low", "high"))
            cells.append(f"{mid:.2f} [{lo:.2f}, {hi:.2f}]")
        lines.append(f"| {method} | " + " | ".join(cells) + " |")
    lines += ["", "Clean-row false positive rate (median and maximum over datasets)", ""]
    lines += [f"- {m}: {v['median']:.3f} (max {v['XXmaxXX']:.3f})" for m, v in results["fpr"].items()]
    (args.output / "typed_results.md").write_text("\n".join(lines) + "\n")
    print(f"{len(data)} datasets")
    return 0


def x_main__mutmut_144(argv: list[str] | None = None) -> int:
    import argparse
    import json
    from pathlib import Path

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, nargs="+", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    data, columns, fpr = _load(args.runs)
    summary = pooled(data)
    results = {
        "datasets": len(data),
        "median": json.loads(summary["median"].to_json(orient="split")),
        "low": json.loads(summary["low"].to_json(orient="split")),
        "high": json.loads(summary["high"].to_json(orient="split")),
        "stability": stability(data),
        "hypotheses": hypotheses(data, columns),
        "fpr": {
            m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in fpr.items()
        },
    }
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / "typed_results.json").write_text(
        json.dumps(results, indent=1, sort_keys=True) + "\n"
    )
    lines = [f"Median recall over {len(data)} datasets (95% interval over datasets)", ""]
    kinds = list(summary["median"].columns)
    lines += ["| method | " + " | ".join(kinds) + " |", "|---|" + "---|" * len(kinds)]
    for method in summary["median"].index:
        cells = []
        for k in kinds:
            mid, lo, hi = (summary[n].loc[method, k] for n in ("median", "low", "high"))
            cells.append(f"{mid:.2f} [{lo:.2f}, {hi:.2f}]")
        lines.append(f"| {method} | " + " | ".join(cells) + " |")
    lines += ["", "Clean-row false positive rate (median and maximum over datasets)", ""]
    lines += [f"- {m}: {v['median']:.3f} (max {v['MAX']:.3f})" for m, v in results["fpr"].items()]
    (args.output / "typed_results.md").write_text("\n".join(lines) + "\n")
    print(f"{len(data)} datasets")
    return 0


def x_main__mutmut_145(argv: list[str] | None = None) -> int:
    import argparse
    import json
    from pathlib import Path

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, nargs="+", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    data, columns, fpr = _load(args.runs)
    summary = pooled(data)
    results = {
        "datasets": len(data),
        "median": json.loads(summary["median"].to_json(orient="split")),
        "low": json.loads(summary["low"].to_json(orient="split")),
        "high": json.loads(summary["high"].to_json(orient="split")),
        "stability": stability(data),
        "hypotheses": hypotheses(data, columns),
        "fpr": {
            m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in fpr.items()
        },
    }
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / "typed_results.json").write_text(
        json.dumps(results, indent=1, sort_keys=True) + "\n"
    )
    lines = [f"Median recall over {len(data)} datasets (95% interval over datasets)", ""]
    kinds = list(summary["median"].columns)
    lines += ["| method | " + " | ".join(kinds) + " |", "|---|" + "---|" * len(kinds)]
    for method in summary["median"].index:
        cells = []
        for k in kinds:
            mid, lo, hi = (summary[n].loc[method, k] for n in ("median", "low", "high"))
            cells.append(f"{mid:.2f} [{lo:.2f}, {hi:.2f}]")
        lines.append(f"| {method} | " + " | ".join(cells) + " |")
    lines += ["", "Clean-row false positive rate (median and maximum over datasets)", ""]
    lines += [f"- {m}: {v['median']:.3f} (max {v['max']:.3f})" for m, v in results["XXfprXX"].items()]
    (args.output / "typed_results.md").write_text("\n".join(lines) + "\n")
    print(f"{len(data)} datasets")
    return 0


def x_main__mutmut_146(argv: list[str] | None = None) -> int:
    import argparse
    import json
    from pathlib import Path

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, nargs="+", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    data, columns, fpr = _load(args.runs)
    summary = pooled(data)
    results = {
        "datasets": len(data),
        "median": json.loads(summary["median"].to_json(orient="split")),
        "low": json.loads(summary["low"].to_json(orient="split")),
        "high": json.loads(summary["high"].to_json(orient="split")),
        "stability": stability(data),
        "hypotheses": hypotheses(data, columns),
        "fpr": {
            m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in fpr.items()
        },
    }
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / "typed_results.json").write_text(
        json.dumps(results, indent=1, sort_keys=True) + "\n"
    )
    lines = [f"Median recall over {len(data)} datasets (95% interval over datasets)", ""]
    kinds = list(summary["median"].columns)
    lines += ["| method | " + " | ".join(kinds) + " |", "|---|" + "---|" * len(kinds)]
    for method in summary["median"].index:
        cells = []
        for k in kinds:
            mid, lo, hi = (summary[n].loc[method, k] for n in ("median", "low", "high"))
            cells.append(f"{mid:.2f} [{lo:.2f}, {hi:.2f}]")
        lines.append(f"| {method} | " + " | ".join(cells) + " |")
    lines += ["", "Clean-row false positive rate (median and maximum over datasets)", ""]
    lines += [f"- {m}: {v['median']:.3f} (max {v['max']:.3f})" for m, v in results["FPR"].items()]
    (args.output / "typed_results.md").write_text("\n".join(lines) + "\n")
    print(f"{len(data)} datasets")
    return 0


def x_main__mutmut_147(argv: list[str] | None = None) -> int:
    import argparse
    import json
    from pathlib import Path

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, nargs="+", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    data, columns, fpr = _load(args.runs)
    summary = pooled(data)
    results = {
        "datasets": len(data),
        "median": json.loads(summary["median"].to_json(orient="split")),
        "low": json.loads(summary["low"].to_json(orient="split")),
        "high": json.loads(summary["high"].to_json(orient="split")),
        "stability": stability(data),
        "hypotheses": hypotheses(data, columns),
        "fpr": {
            m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in fpr.items()
        },
    }
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / "typed_results.json").write_text(
        json.dumps(results, indent=1, sort_keys=True) + "\n"
    )
    lines = [f"Median recall over {len(data)} datasets (95% interval over datasets)", ""]
    kinds = list(summary["median"].columns)
    lines += ["| method | " + " | ".join(kinds) + " |", "|---|" + "---|" * len(kinds)]
    for method in summary["median"].index:
        cells = []
        for k in kinds:
            mid, lo, hi = (summary[n].loc[method, k] for n in ("median", "low", "high"))
            cells.append(f"{mid:.2f} [{lo:.2f}, {hi:.2f}]")
        lines.append(f"| {method} | " + " | ".join(cells) + " |")
    lines += ["", "Clean-row false positive rate (median and maximum over datasets)", ""]
    lines += [f"- {m}: {v['median']:.3f} (max {v['max']:.3f})" for m, v in results["fpr"].items()]
    (args.output / "typed_results.md").write_text(None)
    print(f"{len(data)} datasets")
    return 0


def x_main__mutmut_148(argv: list[str] | None = None) -> int:
    import argparse
    import json
    from pathlib import Path

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, nargs="+", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    data, columns, fpr = _load(args.runs)
    summary = pooled(data)
    results = {
        "datasets": len(data),
        "median": json.loads(summary["median"].to_json(orient="split")),
        "low": json.loads(summary["low"].to_json(orient="split")),
        "high": json.loads(summary["high"].to_json(orient="split")),
        "stability": stability(data),
        "hypotheses": hypotheses(data, columns),
        "fpr": {
            m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in fpr.items()
        },
    }
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / "typed_results.json").write_text(
        json.dumps(results, indent=1, sort_keys=True) + "\n"
    )
    lines = [f"Median recall over {len(data)} datasets (95% interval over datasets)", ""]
    kinds = list(summary["median"].columns)
    lines += ["| method | " + " | ".join(kinds) + " |", "|---|" + "---|" * len(kinds)]
    for method in summary["median"].index:
        cells = []
        for k in kinds:
            mid, lo, hi = (summary[n].loc[method, k] for n in ("median", "low", "high"))
            cells.append(f"{mid:.2f} [{lo:.2f}, {hi:.2f}]")
        lines.append(f"| {method} | " + " | ".join(cells) + " |")
    lines += ["", "Clean-row false positive rate (median and maximum over datasets)", ""]
    lines += [f"- {m}: {v['median']:.3f} (max {v['max']:.3f})" for m, v in results["fpr"].items()]
    (args.output * "typed_results.md").write_text("\n".join(lines) + "\n")
    print(f"{len(data)} datasets")
    return 0


def x_main__mutmut_149(argv: list[str] | None = None) -> int:
    import argparse
    import json
    from pathlib import Path

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, nargs="+", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    data, columns, fpr = _load(args.runs)
    summary = pooled(data)
    results = {
        "datasets": len(data),
        "median": json.loads(summary["median"].to_json(orient="split")),
        "low": json.loads(summary["low"].to_json(orient="split")),
        "high": json.loads(summary["high"].to_json(orient="split")),
        "stability": stability(data),
        "hypotheses": hypotheses(data, columns),
        "fpr": {
            m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in fpr.items()
        },
    }
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / "typed_results.json").write_text(
        json.dumps(results, indent=1, sort_keys=True) + "\n"
    )
    lines = [f"Median recall over {len(data)} datasets (95% interval over datasets)", ""]
    kinds = list(summary["median"].columns)
    lines += ["| method | " + " | ".join(kinds) + " |", "|---|" + "---|" * len(kinds)]
    for method in summary["median"].index:
        cells = []
        for k in kinds:
            mid, lo, hi = (summary[n].loc[method, k] for n in ("median", "low", "high"))
            cells.append(f"{mid:.2f} [{lo:.2f}, {hi:.2f}]")
        lines.append(f"| {method} | " + " | ".join(cells) + " |")
    lines += ["", "Clean-row false positive rate (median and maximum over datasets)", ""]
    lines += [f"- {m}: {v['median']:.3f} (max {v['max']:.3f})" for m, v in results["fpr"].items()]
    (args.output / "XXtyped_results.mdXX").write_text("\n".join(lines) + "\n")
    print(f"{len(data)} datasets")
    return 0


def x_main__mutmut_150(argv: list[str] | None = None) -> int:
    import argparse
    import json
    from pathlib import Path

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, nargs="+", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    data, columns, fpr = _load(args.runs)
    summary = pooled(data)
    results = {
        "datasets": len(data),
        "median": json.loads(summary["median"].to_json(orient="split")),
        "low": json.loads(summary["low"].to_json(orient="split")),
        "high": json.loads(summary["high"].to_json(orient="split")),
        "stability": stability(data),
        "hypotheses": hypotheses(data, columns),
        "fpr": {
            m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in fpr.items()
        },
    }
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / "typed_results.json").write_text(
        json.dumps(results, indent=1, sort_keys=True) + "\n"
    )
    lines = [f"Median recall over {len(data)} datasets (95% interval over datasets)", ""]
    kinds = list(summary["median"].columns)
    lines += ["| method | " + " | ".join(kinds) + " |", "|---|" + "---|" * len(kinds)]
    for method in summary["median"].index:
        cells = []
        for k in kinds:
            mid, lo, hi = (summary[n].loc[method, k] for n in ("median", "low", "high"))
            cells.append(f"{mid:.2f} [{lo:.2f}, {hi:.2f}]")
        lines.append(f"| {method} | " + " | ".join(cells) + " |")
    lines += ["", "Clean-row false positive rate (median and maximum over datasets)", ""]
    lines += [f"- {m}: {v['median']:.3f} (max {v['max']:.3f})" for m, v in results["fpr"].items()]
    (args.output / "TYPED_RESULTS.MD").write_text("\n".join(lines) + "\n")
    print(f"{len(data)} datasets")
    return 0


def x_main__mutmut_151(argv: list[str] | None = None) -> int:
    import argparse
    import json
    from pathlib import Path

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, nargs="+", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    data, columns, fpr = _load(args.runs)
    summary = pooled(data)
    results = {
        "datasets": len(data),
        "median": json.loads(summary["median"].to_json(orient="split")),
        "low": json.loads(summary["low"].to_json(orient="split")),
        "high": json.loads(summary["high"].to_json(orient="split")),
        "stability": stability(data),
        "hypotheses": hypotheses(data, columns),
        "fpr": {
            m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in fpr.items()
        },
    }
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / "typed_results.json").write_text(
        json.dumps(results, indent=1, sort_keys=True) + "\n"
    )
    lines = [f"Median recall over {len(data)} datasets (95% interval over datasets)", ""]
    kinds = list(summary["median"].columns)
    lines += ["| method | " + " | ".join(kinds) + " |", "|---|" + "---|" * len(kinds)]
    for method in summary["median"].index:
        cells = []
        for k in kinds:
            mid, lo, hi = (summary[n].loc[method, k] for n in ("median", "low", "high"))
            cells.append(f"{mid:.2f} [{lo:.2f}, {hi:.2f}]")
        lines.append(f"| {method} | " + " | ".join(cells) + " |")
    lines += ["", "Clean-row false positive rate (median and maximum over datasets)", ""]
    lines += [f"- {m}: {v['median']:.3f} (max {v['max']:.3f})" for m, v in results["fpr"].items()]
    (args.output / "typed_results.md").write_text("\n".join(lines) - "\n")
    print(f"{len(data)} datasets")
    return 0


def x_main__mutmut_152(argv: list[str] | None = None) -> int:
    import argparse
    import json
    from pathlib import Path

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, nargs="+", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    data, columns, fpr = _load(args.runs)
    summary = pooled(data)
    results = {
        "datasets": len(data),
        "median": json.loads(summary["median"].to_json(orient="split")),
        "low": json.loads(summary["low"].to_json(orient="split")),
        "high": json.loads(summary["high"].to_json(orient="split")),
        "stability": stability(data),
        "hypotheses": hypotheses(data, columns),
        "fpr": {
            m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in fpr.items()
        },
    }
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / "typed_results.json").write_text(
        json.dumps(results, indent=1, sort_keys=True) + "\n"
    )
    lines = [f"Median recall over {len(data)} datasets (95% interval over datasets)", ""]
    kinds = list(summary["median"].columns)
    lines += ["| method | " + " | ".join(kinds) + " |", "|---|" + "---|" * len(kinds)]
    for method in summary["median"].index:
        cells = []
        for k in kinds:
            mid, lo, hi = (summary[n].loc[method, k] for n in ("median", "low", "high"))
            cells.append(f"{mid:.2f} [{lo:.2f}, {hi:.2f}]")
        lines.append(f"| {method} | " + " | ".join(cells) + " |")
    lines += ["", "Clean-row false positive rate (median and maximum over datasets)", ""]
    lines += [f"- {m}: {v['median']:.3f} (max {v['max']:.3f})" for m, v in results["fpr"].items()]
    (args.output / "typed_results.md").write_text("\n".join(None) + "\n")
    print(f"{len(data)} datasets")
    return 0


def x_main__mutmut_153(argv: list[str] | None = None) -> int:
    import argparse
    import json
    from pathlib import Path

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, nargs="+", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    data, columns, fpr = _load(args.runs)
    summary = pooled(data)
    results = {
        "datasets": len(data),
        "median": json.loads(summary["median"].to_json(orient="split")),
        "low": json.loads(summary["low"].to_json(orient="split")),
        "high": json.loads(summary["high"].to_json(orient="split")),
        "stability": stability(data),
        "hypotheses": hypotheses(data, columns),
        "fpr": {
            m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in fpr.items()
        },
    }
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / "typed_results.json").write_text(
        json.dumps(results, indent=1, sort_keys=True) + "\n"
    )
    lines = [f"Median recall over {len(data)} datasets (95% interval over datasets)", ""]
    kinds = list(summary["median"].columns)
    lines += ["| method | " + " | ".join(kinds) + " |", "|---|" + "---|" * len(kinds)]
    for method in summary["median"].index:
        cells = []
        for k in kinds:
            mid, lo, hi = (summary[n].loc[method, k] for n in ("median", "low", "high"))
            cells.append(f"{mid:.2f} [{lo:.2f}, {hi:.2f}]")
        lines.append(f"| {method} | " + " | ".join(cells) + " |")
    lines += ["", "Clean-row false positive rate (median and maximum over datasets)", ""]
    lines += [f"- {m}: {v['median']:.3f} (max {v['max']:.3f})" for m, v in results["fpr"].items()]
    (args.output / "typed_results.md").write_text("XX\nXX".join(lines) + "\n")
    print(f"{len(data)} datasets")
    return 0


def x_main__mutmut_154(argv: list[str] | None = None) -> int:
    import argparse
    import json
    from pathlib import Path

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, nargs="+", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    data, columns, fpr = _load(args.runs)
    summary = pooled(data)
    results = {
        "datasets": len(data),
        "median": json.loads(summary["median"].to_json(orient="split")),
        "low": json.loads(summary["low"].to_json(orient="split")),
        "high": json.loads(summary["high"].to_json(orient="split")),
        "stability": stability(data),
        "hypotheses": hypotheses(data, columns),
        "fpr": {
            m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in fpr.items()
        },
    }
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / "typed_results.json").write_text(
        json.dumps(results, indent=1, sort_keys=True) + "\n"
    )
    lines = [f"Median recall over {len(data)} datasets (95% interval over datasets)", ""]
    kinds = list(summary["median"].columns)
    lines += ["| method | " + " | ".join(kinds) + " |", "|---|" + "---|" * len(kinds)]
    for method in summary["median"].index:
        cells = []
        for k in kinds:
            mid, lo, hi = (summary[n].loc[method, k] for n in ("median", "low", "high"))
            cells.append(f"{mid:.2f} [{lo:.2f}, {hi:.2f}]")
        lines.append(f"| {method} | " + " | ".join(cells) + " |")
    lines += ["", "Clean-row false positive rate (median and maximum over datasets)", ""]
    lines += [f"- {m}: {v['median']:.3f} (max {v['max']:.3f})" for m, v in results["fpr"].items()]
    (args.output / "typed_results.md").write_text("\n".join(lines) + "XX\nXX")
    print(f"{len(data)} datasets")
    return 0


def x_main__mutmut_155(argv: list[str] | None = None) -> int:
    import argparse
    import json
    from pathlib import Path

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, nargs="+", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    data, columns, fpr = _load(args.runs)
    summary = pooled(data)
    results = {
        "datasets": len(data),
        "median": json.loads(summary["median"].to_json(orient="split")),
        "low": json.loads(summary["low"].to_json(orient="split")),
        "high": json.loads(summary["high"].to_json(orient="split")),
        "stability": stability(data),
        "hypotheses": hypotheses(data, columns),
        "fpr": {
            m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in fpr.items()
        },
    }
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / "typed_results.json").write_text(
        json.dumps(results, indent=1, sort_keys=True) + "\n"
    )
    lines = [f"Median recall over {len(data)} datasets (95% interval over datasets)", ""]
    kinds = list(summary["median"].columns)
    lines += ["| method | " + " | ".join(kinds) + " |", "|---|" + "---|" * len(kinds)]
    for method in summary["median"].index:
        cells = []
        for k in kinds:
            mid, lo, hi = (summary[n].loc[method, k] for n in ("median", "low", "high"))
            cells.append(f"{mid:.2f} [{lo:.2f}, {hi:.2f}]")
        lines.append(f"| {method} | " + " | ".join(cells) + " |")
    lines += ["", "Clean-row false positive rate (median and maximum over datasets)", ""]
    lines += [f"- {m}: {v['median']:.3f} (max {v['max']:.3f})" for m, v in results["fpr"].items()]
    (args.output / "typed_results.md").write_text("\n".join(lines) + "\n")
    print(None)
    return 0


def x_main__mutmut_156(argv: list[str] | None = None) -> int:
    import argparse
    import json
    from pathlib import Path

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, nargs="+", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    data, columns, fpr = _load(args.runs)
    summary = pooled(data)
    results = {
        "datasets": len(data),
        "median": json.loads(summary["median"].to_json(orient="split")),
        "low": json.loads(summary["low"].to_json(orient="split")),
        "high": json.loads(summary["high"].to_json(orient="split")),
        "stability": stability(data),
        "hypotheses": hypotheses(data, columns),
        "fpr": {
            m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in fpr.items()
        },
    }
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / "typed_results.json").write_text(
        json.dumps(results, indent=1, sort_keys=True) + "\n"
    )
    lines = [f"Median recall over {len(data)} datasets (95% interval over datasets)", ""]
    kinds = list(summary["median"].columns)
    lines += ["| method | " + " | ".join(kinds) + " |", "|---|" + "---|" * len(kinds)]
    for method in summary["median"].index:
        cells = []
        for k in kinds:
            mid, lo, hi = (summary[n].loc[method, k] for n in ("median", "low", "high"))
            cells.append(f"{mid:.2f} [{lo:.2f}, {hi:.2f}]")
        lines.append(f"| {method} | " + " | ".join(cells) + " |")
    lines += ["", "Clean-row false positive rate (median and maximum over datasets)", ""]
    lines += [f"- {m}: {v['median']:.3f} (max {v['max']:.3f})" for m, v in results["fpr"].items()]
    (args.output / "typed_results.md").write_text("\n".join(lines) + "\n")
    print(f"{len(data)} datasets")
    return 1

mutants_x_main__mutmut['_mutmut_orig'] = x_main__mutmut_orig # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_1'] = x_main__mutmut_1 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_2'] = x_main__mutmut_2 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_3'] = x_main__mutmut_3 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_4'] = x_main__mutmut_4 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_5'] = x_main__mutmut_5 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_6'] = x_main__mutmut_6 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_7'] = x_main__mutmut_7 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_8'] = x_main__mutmut_8 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_9'] = x_main__mutmut_9 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_10'] = x_main__mutmut_10 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_11'] = x_main__mutmut_11 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_12'] = x_main__mutmut_12 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_13'] = x_main__mutmut_13 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_14'] = x_main__mutmut_14 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_15'] = x_main__mutmut_15 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_16'] = x_main__mutmut_16 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_17'] = x_main__mutmut_17 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_18'] = x_main__mutmut_18 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_19'] = x_main__mutmut_19 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_20'] = x_main__mutmut_20 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_21'] = x_main__mutmut_21 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_22'] = x_main__mutmut_22 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_23'] = x_main__mutmut_23 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_24'] = x_main__mutmut_24 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_25'] = x_main__mutmut_25 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_26'] = x_main__mutmut_26 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_27'] = x_main__mutmut_27 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_28'] = x_main__mutmut_28 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_29'] = x_main__mutmut_29 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_30'] = x_main__mutmut_30 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_31'] = x_main__mutmut_31 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_32'] = x_main__mutmut_32 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_33'] = x_main__mutmut_33 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_34'] = x_main__mutmut_34 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_35'] = x_main__mutmut_35 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_36'] = x_main__mutmut_36 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_37'] = x_main__mutmut_37 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_38'] = x_main__mutmut_38 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_39'] = x_main__mutmut_39 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_40'] = x_main__mutmut_40 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_41'] = x_main__mutmut_41 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_42'] = x_main__mutmut_42 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_43'] = x_main__mutmut_43 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_44'] = x_main__mutmut_44 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_45'] = x_main__mutmut_45 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_46'] = x_main__mutmut_46 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_47'] = x_main__mutmut_47 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_48'] = x_main__mutmut_48 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_49'] = x_main__mutmut_49 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_50'] = x_main__mutmut_50 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_51'] = x_main__mutmut_51 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_52'] = x_main__mutmut_52 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_53'] = x_main__mutmut_53 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_54'] = x_main__mutmut_54 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_55'] = x_main__mutmut_55 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_56'] = x_main__mutmut_56 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_57'] = x_main__mutmut_57 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_58'] = x_main__mutmut_58 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_59'] = x_main__mutmut_59 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_60'] = x_main__mutmut_60 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_61'] = x_main__mutmut_61 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_62'] = x_main__mutmut_62 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_63'] = x_main__mutmut_63 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_64'] = x_main__mutmut_64 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_65'] = x_main__mutmut_65 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_66'] = x_main__mutmut_66 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_67'] = x_main__mutmut_67 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_68'] = x_main__mutmut_68 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_69'] = x_main__mutmut_69 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_70'] = x_main__mutmut_70 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_71'] = x_main__mutmut_71 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_72'] = x_main__mutmut_72 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_73'] = x_main__mutmut_73 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_74'] = x_main__mutmut_74 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_75'] = x_main__mutmut_75 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_76'] = x_main__mutmut_76 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_77'] = x_main__mutmut_77 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_78'] = x_main__mutmut_78 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_79'] = x_main__mutmut_79 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_80'] = x_main__mutmut_80 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_81'] = x_main__mutmut_81 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_82'] = x_main__mutmut_82 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_83'] = x_main__mutmut_83 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_84'] = x_main__mutmut_84 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_85'] = x_main__mutmut_85 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_86'] = x_main__mutmut_86 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_87'] = x_main__mutmut_87 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_88'] = x_main__mutmut_88 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_89'] = x_main__mutmut_89 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_90'] = x_main__mutmut_90 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_91'] = x_main__mutmut_91 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_92'] = x_main__mutmut_92 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_93'] = x_main__mutmut_93 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_94'] = x_main__mutmut_94 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_95'] = x_main__mutmut_95 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_96'] = x_main__mutmut_96 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_97'] = x_main__mutmut_97 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_98'] = x_main__mutmut_98 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_99'] = x_main__mutmut_99 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_100'] = x_main__mutmut_100 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_101'] = x_main__mutmut_101 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_102'] = x_main__mutmut_102 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_103'] = x_main__mutmut_103 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_104'] = x_main__mutmut_104 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_105'] = x_main__mutmut_105 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_106'] = x_main__mutmut_106 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_107'] = x_main__mutmut_107 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_108'] = x_main__mutmut_108 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_109'] = x_main__mutmut_109 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_110'] = x_main__mutmut_110 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_111'] = x_main__mutmut_111 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_112'] = x_main__mutmut_112 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_113'] = x_main__mutmut_113 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_114'] = x_main__mutmut_114 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_115'] = x_main__mutmut_115 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_116'] = x_main__mutmut_116 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_117'] = x_main__mutmut_117 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_118'] = x_main__mutmut_118 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_119'] = x_main__mutmut_119 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_120'] = x_main__mutmut_120 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_121'] = x_main__mutmut_121 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_122'] = x_main__mutmut_122 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_123'] = x_main__mutmut_123 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_124'] = x_main__mutmut_124 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_125'] = x_main__mutmut_125 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_126'] = x_main__mutmut_126 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_127'] = x_main__mutmut_127 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_128'] = x_main__mutmut_128 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_129'] = x_main__mutmut_129 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_130'] = x_main__mutmut_130 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_131'] = x_main__mutmut_131 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_132'] = x_main__mutmut_132 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_133'] = x_main__mutmut_133 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_134'] = x_main__mutmut_134 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_135'] = x_main__mutmut_135 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_136'] = x_main__mutmut_136 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_137'] = x_main__mutmut_137 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_138'] = x_main__mutmut_138 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_139'] = x_main__mutmut_139 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_140'] = x_main__mutmut_140 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_141'] = x_main__mutmut_141 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_142'] = x_main__mutmut_142 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_143'] = x_main__mutmut_143 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_144'] = x_main__mutmut_144 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_145'] = x_main__mutmut_145 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_146'] = x_main__mutmut_146 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_147'] = x_main__mutmut_147 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_148'] = x_main__mutmut_148 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_149'] = x_main__mutmut_149 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_150'] = x_main__mutmut_150 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_151'] = x_main__mutmut_151 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_152'] = x_main__mutmut_152 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_153'] = x_main__mutmut_153 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_154'] = x_main__mutmut_154 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_155'] = x_main__mutmut_155 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_156'] = x_main__mutmut_156 # type: ignore # mutmut generated


if __name__ == "__main__":
    raise SystemExit(main())
