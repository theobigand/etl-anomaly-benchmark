"""One pass over the labelled pool for every threshold-dependent table (pool_extension.md).

For each problem, seed and detector one fit gives: the metrics at the training-prevalence
threshold, the metrics at the label-free threshold of 0.02, the metrics of the contamination grid
of the sweep, the stage times and, for the seed of the curves, the precision-recall curve. The
thresholds other than the fitted one are read from the scores kept at fit: the flag threshold of a
detector is the ``1 - contamination`` quantile of its fit scores and does not change the model. A
test checks this equivalence against a refit for every detector of the registry.
"""

from __future__ import annotations

import argparse
import json
import os
import sys
import warnings
from concurrent.futures import ProcessPoolExecutor
from functools import partial as bind
from pathlib import Path
from typing import Any

os.environ.setdefault("TQDM_DISABLE", "1")

import numpy as np  # noqa: E402
import pandas as pd  # noqa: E402
from sklearn.metrics import average_precision_score, precision_recall_curve  # noqa: E402

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import labelled_benchmark as lb  # noqa: E402
import normalise as nm  # noqa: E402
from deep_support import build, capped  # noqa: E402

from etl_benchmark import config  # noqa: E402
from etl_benchmark.metrics import compute_metrics  # noqa: E402
from etl_benchmark.pipeline import detect  # noqa: E402
from etl_benchmark.registry import DEEP_NAMES, DETECTOR_NAMES, clip_contamination  # noqa: E402

FIXED = 0.02
GRID = (0.001, 0.01, 0.05, 0.10, 0.20)
CURVE_SEED = 42
CURVE_POINTS = 200
SWEEP_METHOD = "isolation_forest"
KNOWN = [*DETECTOR_NAMES, *DEEP_NAMES]


from mutmut.mutation.trampoline import wrap_in_trampoline as _mutmut_mutated, MutantDict
mutants_x_fit_scores__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_fit_scores__mutmut)
def fit_scores(detector: Any, fit_df: pd.DataFrame) -> np.ndarray | None:
    """The scores whose quantile is the flag threshold; ``None`` when contamination is not used."""
    model = getattr(detector, "_model", None)
    if model is None:
        return None
    scores = getattr(model, "decision_scores_", None)
    if scores is None:  # the project's own estimators threshold the scores of the fit rows
        scores = detector.score(fit_df)
    return np.asarray(scores, dtype=float)


def x_fit_scores__mutmut_orig(detector: Any, fit_df: pd.DataFrame) -> np.ndarray | None:
    """The scores whose quantile is the flag threshold; ``None`` when contamination is not used."""
    model = getattr(detector, "_model", None)
    if model is None:
        return None
    scores = getattr(model, "decision_scores_", None)
    if scores is None:  # the project's own estimators threshold the scores of the fit rows
        scores = detector.score(fit_df)
    return np.asarray(scores, dtype=float)


def x_fit_scores__mutmut_1(detector: Any, fit_df: pd.DataFrame) -> np.ndarray | None:
    """The scores whose quantile is the flag threshold; ``None`` when contamination is not used."""
    model = None
    if model is None:
        return None
    scores = getattr(model, "decision_scores_", None)
    if scores is None:  # the project's own estimators threshold the scores of the fit rows
        scores = detector.score(fit_df)
    return np.asarray(scores, dtype=float)


def x_fit_scores__mutmut_2(detector: Any, fit_df: pd.DataFrame) -> np.ndarray | None:
    """The scores whose quantile is the flag threshold; ``None`` when contamination is not used."""
    model = getattr(None, "_model", None)
    if model is None:
        return None
    scores = getattr(model, "decision_scores_", None)
    if scores is None:  # the project's own estimators threshold the scores of the fit rows
        scores = detector.score(fit_df)
    return np.asarray(scores, dtype=float)


def x_fit_scores__mutmut_3(detector: Any, fit_df: pd.DataFrame) -> np.ndarray | None:
    """The scores whose quantile is the flag threshold; ``None`` when contamination is not used."""
    model = getattr(detector, None, None)
    if model is None:
        return None
    scores = getattr(model, "decision_scores_", None)
    if scores is None:  # the project's own estimators threshold the scores of the fit rows
        scores = detector.score(fit_df)
    return np.asarray(scores, dtype=float)


def x_fit_scores__mutmut_4(detector: Any, fit_df: pd.DataFrame) -> np.ndarray | None:
    """The scores whose quantile is the flag threshold; ``None`` when contamination is not used."""
    model = getattr("_model", None)
    if model is None:
        return None
    scores = getattr(model, "decision_scores_", None)
    if scores is None:  # the project's own estimators threshold the scores of the fit rows
        scores = detector.score(fit_df)
    return np.asarray(scores, dtype=float)


def x_fit_scores__mutmut_5(detector: Any, fit_df: pd.DataFrame) -> np.ndarray | None:
    """The scores whose quantile is the flag threshold; ``None`` when contamination is not used."""
    model = getattr(detector, None)
    if model is None:
        return None
    scores = getattr(model, "decision_scores_", None)
    if scores is None:  # the project's own estimators threshold the scores of the fit rows
        scores = detector.score(fit_df)
    return np.asarray(scores, dtype=float)


def x_fit_scores__mutmut_6(detector: Any, fit_df: pd.DataFrame) -> np.ndarray | None:
    """The scores whose quantile is the flag threshold; ``None`` when contamination is not used."""
    model = getattr(detector, "_model", )
    if model is None:
        return None
    scores = getattr(model, "decision_scores_", None)
    if scores is None:  # the project's own estimators threshold the scores of the fit rows
        scores = detector.score(fit_df)
    return np.asarray(scores, dtype=float)


def x_fit_scores__mutmut_7(detector: Any, fit_df: pd.DataFrame) -> np.ndarray | None:
    """The scores whose quantile is the flag threshold; ``None`` when contamination is not used."""
    model = getattr(detector, "XX_modelXX", None)
    if model is None:
        return None
    scores = getattr(model, "decision_scores_", None)
    if scores is None:  # the project's own estimators threshold the scores of the fit rows
        scores = detector.score(fit_df)
    return np.asarray(scores, dtype=float)


def x_fit_scores__mutmut_8(detector: Any, fit_df: pd.DataFrame) -> np.ndarray | None:
    """The scores whose quantile is the flag threshold; ``None`` when contamination is not used."""
    model = getattr(detector, "_MODEL", None)
    if model is None:
        return None
    scores = getattr(model, "decision_scores_", None)
    if scores is None:  # the project's own estimators threshold the scores of the fit rows
        scores = detector.score(fit_df)
    return np.asarray(scores, dtype=float)


def x_fit_scores__mutmut_9(detector: Any, fit_df: pd.DataFrame) -> np.ndarray | None:
    """The scores whose quantile is the flag threshold; ``None`` when contamination is not used."""
    model = getattr(detector, "_model", None)
    if model is not None:
        return None
    scores = getattr(model, "decision_scores_", None)
    if scores is None:  # the project's own estimators threshold the scores of the fit rows
        scores = detector.score(fit_df)
    return np.asarray(scores, dtype=float)


def x_fit_scores__mutmut_10(detector: Any, fit_df: pd.DataFrame) -> np.ndarray | None:
    """The scores whose quantile is the flag threshold; ``None`` when contamination is not used."""
    model = getattr(detector, "_model", None)
    if model is None:
        return None
    scores = None
    if scores is None:  # the project's own estimators threshold the scores of the fit rows
        scores = detector.score(fit_df)
    return np.asarray(scores, dtype=float)


def x_fit_scores__mutmut_11(detector: Any, fit_df: pd.DataFrame) -> np.ndarray | None:
    """The scores whose quantile is the flag threshold; ``None`` when contamination is not used."""
    model = getattr(detector, "_model", None)
    if model is None:
        return None
    scores = getattr(None, "decision_scores_", None)
    if scores is None:  # the project's own estimators threshold the scores of the fit rows
        scores = detector.score(fit_df)
    return np.asarray(scores, dtype=float)


def x_fit_scores__mutmut_12(detector: Any, fit_df: pd.DataFrame) -> np.ndarray | None:
    """The scores whose quantile is the flag threshold; ``None`` when contamination is not used."""
    model = getattr(detector, "_model", None)
    if model is None:
        return None
    scores = getattr(model, None, None)
    if scores is None:  # the project's own estimators threshold the scores of the fit rows
        scores = detector.score(fit_df)
    return np.asarray(scores, dtype=float)


def x_fit_scores__mutmut_13(detector: Any, fit_df: pd.DataFrame) -> np.ndarray | None:
    """The scores whose quantile is the flag threshold; ``None`` when contamination is not used."""
    model = getattr(detector, "_model", None)
    if model is None:
        return None
    scores = getattr("decision_scores_", None)
    if scores is None:  # the project's own estimators threshold the scores of the fit rows
        scores = detector.score(fit_df)
    return np.asarray(scores, dtype=float)


def x_fit_scores__mutmut_14(detector: Any, fit_df: pd.DataFrame) -> np.ndarray | None:
    """The scores whose quantile is the flag threshold; ``None`` when contamination is not used."""
    model = getattr(detector, "_model", None)
    if model is None:
        return None
    scores = getattr(model, None)
    if scores is None:  # the project's own estimators threshold the scores of the fit rows
        scores = detector.score(fit_df)
    return np.asarray(scores, dtype=float)


def x_fit_scores__mutmut_15(detector: Any, fit_df: pd.DataFrame) -> np.ndarray | None:
    """The scores whose quantile is the flag threshold; ``None`` when contamination is not used."""
    model = getattr(detector, "_model", None)
    if model is None:
        return None
    scores = getattr(model, "decision_scores_", )
    if scores is None:  # the project's own estimators threshold the scores of the fit rows
        scores = detector.score(fit_df)
    return np.asarray(scores, dtype=float)


def x_fit_scores__mutmut_16(detector: Any, fit_df: pd.DataFrame) -> np.ndarray | None:
    """The scores whose quantile is the flag threshold; ``None`` when contamination is not used."""
    model = getattr(detector, "_model", None)
    if model is None:
        return None
    scores = getattr(model, "XXdecision_scores_XX", None)
    if scores is None:  # the project's own estimators threshold the scores of the fit rows
        scores = detector.score(fit_df)
    return np.asarray(scores, dtype=float)


def x_fit_scores__mutmut_17(detector: Any, fit_df: pd.DataFrame) -> np.ndarray | None:
    """The scores whose quantile is the flag threshold; ``None`` when contamination is not used."""
    model = getattr(detector, "_model", None)
    if model is None:
        return None
    scores = getattr(model, "DECISION_SCORES_", None)
    if scores is None:  # the project's own estimators threshold the scores of the fit rows
        scores = detector.score(fit_df)
    return np.asarray(scores, dtype=float)


def x_fit_scores__mutmut_18(detector: Any, fit_df: pd.DataFrame) -> np.ndarray | None:
    """The scores whose quantile is the flag threshold; ``None`` when contamination is not used."""
    model = getattr(detector, "_model", None)
    if model is None:
        return None
    scores = getattr(model, "decision_scores_", None)
    if scores is not None:  # the project's own estimators threshold the scores of the fit rows
        scores = detector.score(fit_df)
    return np.asarray(scores, dtype=float)


def x_fit_scores__mutmut_19(detector: Any, fit_df: pd.DataFrame) -> np.ndarray | None:
    """The scores whose quantile is the flag threshold; ``None`` when contamination is not used."""
    model = getattr(detector, "_model", None)
    if model is None:
        return None
    scores = getattr(model, "decision_scores_", None)
    if scores is None:  # the project's own estimators threshold the scores of the fit rows
        scores = None
    return np.asarray(scores, dtype=float)


def x_fit_scores__mutmut_20(detector: Any, fit_df: pd.DataFrame) -> np.ndarray | None:
    """The scores whose quantile is the flag threshold; ``None`` when contamination is not used."""
    model = getattr(detector, "_model", None)
    if model is None:
        return None
    scores = getattr(model, "decision_scores_", None)
    if scores is None:  # the project's own estimators threshold the scores of the fit rows
        scores = detector.score(None)
    return np.asarray(scores, dtype=float)


def x_fit_scores__mutmut_21(detector: Any, fit_df: pd.DataFrame) -> np.ndarray | None:
    """The scores whose quantile is the flag threshold; ``None`` when contamination is not used."""
    model = getattr(detector, "_model", None)
    if model is None:
        return None
    scores = getattr(model, "decision_scores_", None)
    if scores is None:  # the project's own estimators threshold the scores of the fit rows
        scores = detector.score(fit_df)
    return np.asarray(None, dtype=float)


def x_fit_scores__mutmut_22(detector: Any, fit_df: pd.DataFrame) -> np.ndarray | None:
    """The scores whose quantile is the flag threshold; ``None`` when contamination is not used."""
    model = getattr(detector, "_model", None)
    if model is None:
        return None
    scores = getattr(model, "decision_scores_", None)
    if scores is None:  # the project's own estimators threshold the scores of the fit rows
        scores = detector.score(fit_df)
    return np.asarray(scores, dtype=None)


def x_fit_scores__mutmut_23(detector: Any, fit_df: pd.DataFrame) -> np.ndarray | None:
    """The scores whose quantile is the flag threshold; ``None`` when contamination is not used."""
    model = getattr(detector, "_model", None)
    if model is None:
        return None
    scores = getattr(model, "decision_scores_", None)
    if scores is None:  # the project's own estimators threshold the scores of the fit rows
        scores = detector.score(fit_df)
    return np.asarray(dtype=float)


def x_fit_scores__mutmut_24(detector: Any, fit_df: pd.DataFrame) -> np.ndarray | None:
    """The scores whose quantile is the flag threshold; ``None`` when contamination is not used."""
    model = getattr(detector, "_model", None)
    if model is None:
        return None
    scores = getattr(model, "decision_scores_", None)
    if scores is None:  # the project's own estimators threshold the scores of the fit rows
        scores = detector.score(fit_df)
    return np.asarray(scores, )

mutants_x_fit_scores__mutmut['_mutmut_orig'] = x_fit_scores__mutmut_orig # type: ignore # mutmut generated
mutants_x_fit_scores__mutmut['x_fit_scores__mutmut_1'] = x_fit_scores__mutmut_1 # type: ignore # mutmut generated
mutants_x_fit_scores__mutmut['x_fit_scores__mutmut_2'] = x_fit_scores__mutmut_2 # type: ignore # mutmut generated
mutants_x_fit_scores__mutmut['x_fit_scores__mutmut_3'] = x_fit_scores__mutmut_3 # type: ignore # mutmut generated
mutants_x_fit_scores__mutmut['x_fit_scores__mutmut_4'] = x_fit_scores__mutmut_4 # type: ignore # mutmut generated
mutants_x_fit_scores__mutmut['x_fit_scores__mutmut_5'] = x_fit_scores__mutmut_5 # type: ignore # mutmut generated
mutants_x_fit_scores__mutmut['x_fit_scores__mutmut_6'] = x_fit_scores__mutmut_6 # type: ignore # mutmut generated
mutants_x_fit_scores__mutmut['x_fit_scores__mutmut_7'] = x_fit_scores__mutmut_7 # type: ignore # mutmut generated
mutants_x_fit_scores__mutmut['x_fit_scores__mutmut_8'] = x_fit_scores__mutmut_8 # type: ignore # mutmut generated
mutants_x_fit_scores__mutmut['x_fit_scores__mutmut_9'] = x_fit_scores__mutmut_9 # type: ignore # mutmut generated
mutants_x_fit_scores__mutmut['x_fit_scores__mutmut_10'] = x_fit_scores__mutmut_10 # type: ignore # mutmut generated
mutants_x_fit_scores__mutmut['x_fit_scores__mutmut_11'] = x_fit_scores__mutmut_11 # type: ignore # mutmut generated
mutants_x_fit_scores__mutmut['x_fit_scores__mutmut_12'] = x_fit_scores__mutmut_12 # type: ignore # mutmut generated
mutants_x_fit_scores__mutmut['x_fit_scores__mutmut_13'] = x_fit_scores__mutmut_13 # type: ignore # mutmut generated
mutants_x_fit_scores__mutmut['x_fit_scores__mutmut_14'] = x_fit_scores__mutmut_14 # type: ignore # mutmut generated
mutants_x_fit_scores__mutmut['x_fit_scores__mutmut_15'] = x_fit_scores__mutmut_15 # type: ignore # mutmut generated
mutants_x_fit_scores__mutmut['x_fit_scores__mutmut_16'] = x_fit_scores__mutmut_16 # type: ignore # mutmut generated
mutants_x_fit_scores__mutmut['x_fit_scores__mutmut_17'] = x_fit_scores__mutmut_17 # type: ignore # mutmut generated
mutants_x_fit_scores__mutmut['x_fit_scores__mutmut_18'] = x_fit_scores__mutmut_18 # type: ignore # mutmut generated
mutants_x_fit_scores__mutmut['x_fit_scores__mutmut_19'] = x_fit_scores__mutmut_19 # type: ignore # mutmut generated
mutants_x_fit_scores__mutmut['x_fit_scores__mutmut_20'] = x_fit_scores__mutmut_20 # type: ignore # mutmut generated
mutants_x_fit_scores__mutmut['x_fit_scores__mutmut_21'] = x_fit_scores__mutmut_21 # type: ignore # mutmut generated
mutants_x_fit_scores__mutmut['x_fit_scores__mutmut_22'] = x_fit_scores__mutmut_22 # type: ignore # mutmut generated
mutants_x_fit_scores__mutmut['x_fit_scores__mutmut_23'] = x_fit_scores__mutmut_23 # type: ignore # mutmut generated
mutants_x_fit_scores__mutmut['x_fit_scores__mutmut_24'] = x_fit_scores__mutmut_24 # type: ignore # mutmut generated
mutants_x_flags_at__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_flags_at__mutmut)
def flags_at(fit_score: np.ndarray, test_scores: np.ndarray, contamination: float) -> np.ndarray:
    """Flags a detector fitted with this contamination would raise (PyOD's threshold rule)."""
    threshold = np.percentile(fit_score, 100 * (1 - clip_contamination(contamination)))
    return np.asarray(test_scores) > threshold


def x_flags_at__mutmut_orig(fit_score: np.ndarray, test_scores: np.ndarray, contamination: float) -> np.ndarray:
    """Flags a detector fitted with this contamination would raise (PyOD's threshold rule)."""
    threshold = np.percentile(fit_score, 100 * (1 - clip_contamination(contamination)))
    return np.asarray(test_scores) > threshold


def x_flags_at__mutmut_1(fit_score: np.ndarray, test_scores: np.ndarray, contamination: float) -> np.ndarray:
    """Flags a detector fitted with this contamination would raise (PyOD's threshold rule)."""
    threshold = None
    return np.asarray(test_scores) > threshold


def x_flags_at__mutmut_2(fit_score: np.ndarray, test_scores: np.ndarray, contamination: float) -> np.ndarray:
    """Flags a detector fitted with this contamination would raise (PyOD's threshold rule)."""
    threshold = np.percentile(None, 100 * (1 - clip_contamination(contamination)))
    return np.asarray(test_scores) > threshold


def x_flags_at__mutmut_3(fit_score: np.ndarray, test_scores: np.ndarray, contamination: float) -> np.ndarray:
    """Flags a detector fitted with this contamination would raise (PyOD's threshold rule)."""
    threshold = np.percentile(fit_score, None)
    return np.asarray(test_scores) > threshold


def x_flags_at__mutmut_4(fit_score: np.ndarray, test_scores: np.ndarray, contamination: float) -> np.ndarray:
    """Flags a detector fitted with this contamination would raise (PyOD's threshold rule)."""
    threshold = np.percentile(100 * (1 - clip_contamination(contamination)))
    return np.asarray(test_scores) > threshold


def x_flags_at__mutmut_5(fit_score: np.ndarray, test_scores: np.ndarray, contamination: float) -> np.ndarray:
    """Flags a detector fitted with this contamination would raise (PyOD's threshold rule)."""
    threshold = np.percentile(fit_score, )
    return np.asarray(test_scores) > threshold


def x_flags_at__mutmut_6(fit_score: np.ndarray, test_scores: np.ndarray, contamination: float) -> np.ndarray:
    """Flags a detector fitted with this contamination would raise (PyOD's threshold rule)."""
    threshold = np.percentile(fit_score, 100 / (1 - clip_contamination(contamination)))
    return np.asarray(test_scores) > threshold


def x_flags_at__mutmut_7(fit_score: np.ndarray, test_scores: np.ndarray, contamination: float) -> np.ndarray:
    """Flags a detector fitted with this contamination would raise (PyOD's threshold rule)."""
    threshold = np.percentile(fit_score, 101 * (1 - clip_contamination(contamination)))
    return np.asarray(test_scores) > threshold


def x_flags_at__mutmut_8(fit_score: np.ndarray, test_scores: np.ndarray, contamination: float) -> np.ndarray:
    """Flags a detector fitted with this contamination would raise (PyOD's threshold rule)."""
    threshold = np.percentile(fit_score, 100 * (1 + clip_contamination(contamination)))
    return np.asarray(test_scores) > threshold


def x_flags_at__mutmut_9(fit_score: np.ndarray, test_scores: np.ndarray, contamination: float) -> np.ndarray:
    """Flags a detector fitted with this contamination would raise (PyOD's threshold rule)."""
    threshold = np.percentile(fit_score, 100 * (2 - clip_contamination(contamination)))
    return np.asarray(test_scores) > threshold


def x_flags_at__mutmut_10(fit_score: np.ndarray, test_scores: np.ndarray, contamination: float) -> np.ndarray:
    """Flags a detector fitted with this contamination would raise (PyOD's threshold rule)."""
    threshold = np.percentile(fit_score, 100 * (1 - clip_contamination(None)))
    return np.asarray(test_scores) > threshold


def x_flags_at__mutmut_11(fit_score: np.ndarray, test_scores: np.ndarray, contamination: float) -> np.ndarray:
    """Flags a detector fitted with this contamination would raise (PyOD's threshold rule)."""
    threshold = np.percentile(fit_score, 100 * (1 - clip_contamination(contamination)))
    return np.asarray(None) > threshold


def x_flags_at__mutmut_12(fit_score: np.ndarray, test_scores: np.ndarray, contamination: float) -> np.ndarray:
    """Flags a detector fitted with this contamination would raise (PyOD's threshold rule)."""
    threshold = np.percentile(fit_score, 100 * (1 - clip_contamination(contamination)))
    return np.asarray(test_scores) >= threshold

mutants_x_flags_at__mutmut['_mutmut_orig'] = x_flags_at__mutmut_orig # type: ignore # mutmut generated
mutants_x_flags_at__mutmut['x_flags_at__mutmut_1'] = x_flags_at__mutmut_1 # type: ignore # mutmut generated
mutants_x_flags_at__mutmut['x_flags_at__mutmut_2'] = x_flags_at__mutmut_2 # type: ignore # mutmut generated
mutants_x_flags_at__mutmut['x_flags_at__mutmut_3'] = x_flags_at__mutmut_3 # type: ignore # mutmut generated
mutants_x_flags_at__mutmut['x_flags_at__mutmut_4'] = x_flags_at__mutmut_4 # type: ignore # mutmut generated
mutants_x_flags_at__mutmut['x_flags_at__mutmut_5'] = x_flags_at__mutmut_5 # type: ignore # mutmut generated
mutants_x_flags_at__mutmut['x_flags_at__mutmut_6'] = x_flags_at__mutmut_6 # type: ignore # mutmut generated
mutants_x_flags_at__mutmut['x_flags_at__mutmut_7'] = x_flags_at__mutmut_7 # type: ignore # mutmut generated
mutants_x_flags_at__mutmut['x_flags_at__mutmut_8'] = x_flags_at__mutmut_8 # type: ignore # mutmut generated
mutants_x_flags_at__mutmut['x_flags_at__mutmut_9'] = x_flags_at__mutmut_9 # type: ignore # mutmut generated
mutants_x_flags_at__mutmut['x_flags_at__mutmut_10'] = x_flags_at__mutmut_10 # type: ignore # mutmut generated
mutants_x_flags_at__mutmut['x_flags_at__mutmut_11'] = x_flags_at__mutmut_11 # type: ignore # mutmut generated
mutants_x_flags_at__mutmut['x_flags_at__mutmut_12'] = x_flags_at__mutmut_12 # type: ignore # mutmut generated
mutants_x__curve__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x__curve__mutmut)
def _curve(y: np.ndarray, scores: np.ndarray) -> dict[str, Any]:
    precision, recall, _ = precision_recall_curve(y, scores)
    keep = np.unique(
        np.linspace(0, len(precision) - 1, min(CURVE_POINTS, len(precision))).astype(int)
    )
    return {
        "precision": precision[keep].tolist(),
        "recall": recall[keep].tolist(),
        "average_precision": float(average_precision_score(y, scores)),
    }


def x__curve__mutmut_orig(y: np.ndarray, scores: np.ndarray) -> dict[str, Any]:
    precision, recall, _ = precision_recall_curve(y, scores)
    keep = np.unique(
        np.linspace(0, len(precision) - 1, min(CURVE_POINTS, len(precision))).astype(int)
    )
    return {
        "precision": precision[keep].tolist(),
        "recall": recall[keep].tolist(),
        "average_precision": float(average_precision_score(y, scores)),
    }


def x__curve__mutmut_1(y: np.ndarray, scores: np.ndarray) -> dict[str, Any]:
    precision, recall, _ = None
    keep = np.unique(
        np.linspace(0, len(precision) - 1, min(CURVE_POINTS, len(precision))).astype(int)
    )
    return {
        "precision": precision[keep].tolist(),
        "recall": recall[keep].tolist(),
        "average_precision": float(average_precision_score(y, scores)),
    }


def x__curve__mutmut_2(y: np.ndarray, scores: np.ndarray) -> dict[str, Any]:
    precision, recall, _ = precision_recall_curve(None, scores)
    keep = np.unique(
        np.linspace(0, len(precision) - 1, min(CURVE_POINTS, len(precision))).astype(int)
    )
    return {
        "precision": precision[keep].tolist(),
        "recall": recall[keep].tolist(),
        "average_precision": float(average_precision_score(y, scores)),
    }


def x__curve__mutmut_3(y: np.ndarray, scores: np.ndarray) -> dict[str, Any]:
    precision, recall, _ = precision_recall_curve(y, None)
    keep = np.unique(
        np.linspace(0, len(precision) - 1, min(CURVE_POINTS, len(precision))).astype(int)
    )
    return {
        "precision": precision[keep].tolist(),
        "recall": recall[keep].tolist(),
        "average_precision": float(average_precision_score(y, scores)),
    }


def x__curve__mutmut_4(y: np.ndarray, scores: np.ndarray) -> dict[str, Any]:
    precision, recall, _ = precision_recall_curve(scores)
    keep = np.unique(
        np.linspace(0, len(precision) - 1, min(CURVE_POINTS, len(precision))).astype(int)
    )
    return {
        "precision": precision[keep].tolist(),
        "recall": recall[keep].tolist(),
        "average_precision": float(average_precision_score(y, scores)),
    }


def x__curve__mutmut_5(y: np.ndarray, scores: np.ndarray) -> dict[str, Any]:
    precision, recall, _ = precision_recall_curve(y, )
    keep = np.unique(
        np.linspace(0, len(precision) - 1, min(CURVE_POINTS, len(precision))).astype(int)
    )
    return {
        "precision": precision[keep].tolist(),
        "recall": recall[keep].tolist(),
        "average_precision": float(average_precision_score(y, scores)),
    }


def x__curve__mutmut_6(y: np.ndarray, scores: np.ndarray) -> dict[str, Any]:
    precision, recall, _ = precision_recall_curve(y, scores)
    keep = None
    return {
        "precision": precision[keep].tolist(),
        "recall": recall[keep].tolist(),
        "average_precision": float(average_precision_score(y, scores)),
    }


def x__curve__mutmut_7(y: np.ndarray, scores: np.ndarray) -> dict[str, Any]:
    precision, recall, _ = precision_recall_curve(y, scores)
    keep = np.unique(
        None
    )
    return {
        "precision": precision[keep].tolist(),
        "recall": recall[keep].tolist(),
        "average_precision": float(average_precision_score(y, scores)),
    }


def x__curve__mutmut_8(y: np.ndarray, scores: np.ndarray) -> dict[str, Any]:
    precision, recall, _ = precision_recall_curve(y, scores)
    keep = np.unique(
        np.linspace(0, len(precision) - 1, min(CURVE_POINTS, len(precision))).astype(None)
    )
    return {
        "precision": precision[keep].tolist(),
        "recall": recall[keep].tolist(),
        "average_precision": float(average_precision_score(y, scores)),
    }


def x__curve__mutmut_9(y: np.ndarray, scores: np.ndarray) -> dict[str, Any]:
    precision, recall, _ = precision_recall_curve(y, scores)
    keep = np.unique(
        np.linspace(None, len(precision) - 1, min(CURVE_POINTS, len(precision))).astype(int)
    )
    return {
        "precision": precision[keep].tolist(),
        "recall": recall[keep].tolist(),
        "average_precision": float(average_precision_score(y, scores)),
    }


def x__curve__mutmut_10(y: np.ndarray, scores: np.ndarray) -> dict[str, Any]:
    precision, recall, _ = precision_recall_curve(y, scores)
    keep = np.unique(
        np.linspace(0, None, min(CURVE_POINTS, len(precision))).astype(int)
    )
    return {
        "precision": precision[keep].tolist(),
        "recall": recall[keep].tolist(),
        "average_precision": float(average_precision_score(y, scores)),
    }


def x__curve__mutmut_11(y: np.ndarray, scores: np.ndarray) -> dict[str, Any]:
    precision, recall, _ = precision_recall_curve(y, scores)
    keep = np.unique(
        np.linspace(0, len(precision) - 1, None).astype(int)
    )
    return {
        "precision": precision[keep].tolist(),
        "recall": recall[keep].tolist(),
        "average_precision": float(average_precision_score(y, scores)),
    }


def x__curve__mutmut_12(y: np.ndarray, scores: np.ndarray) -> dict[str, Any]:
    precision, recall, _ = precision_recall_curve(y, scores)
    keep = np.unique(
        np.linspace(len(precision) - 1, min(CURVE_POINTS, len(precision))).astype(int)
    )
    return {
        "precision": precision[keep].tolist(),
        "recall": recall[keep].tolist(),
        "average_precision": float(average_precision_score(y, scores)),
    }


def x__curve__mutmut_13(y: np.ndarray, scores: np.ndarray) -> dict[str, Any]:
    precision, recall, _ = precision_recall_curve(y, scores)
    keep = np.unique(
        np.linspace(0, min(CURVE_POINTS, len(precision))).astype(int)
    )
    return {
        "precision": precision[keep].tolist(),
        "recall": recall[keep].tolist(),
        "average_precision": float(average_precision_score(y, scores)),
    }


def x__curve__mutmut_14(y: np.ndarray, scores: np.ndarray) -> dict[str, Any]:
    precision, recall, _ = precision_recall_curve(y, scores)
    keep = np.unique(
        np.linspace(0, len(precision) - 1, ).astype(int)
    )
    return {
        "precision": precision[keep].tolist(),
        "recall": recall[keep].tolist(),
        "average_precision": float(average_precision_score(y, scores)),
    }


def x__curve__mutmut_15(y: np.ndarray, scores: np.ndarray) -> dict[str, Any]:
    precision, recall, _ = precision_recall_curve(y, scores)
    keep = np.unique(
        np.linspace(1, len(precision) - 1, min(CURVE_POINTS, len(precision))).astype(int)
    )
    return {
        "precision": precision[keep].tolist(),
        "recall": recall[keep].tolist(),
        "average_precision": float(average_precision_score(y, scores)),
    }


def x__curve__mutmut_16(y: np.ndarray, scores: np.ndarray) -> dict[str, Any]:
    precision, recall, _ = precision_recall_curve(y, scores)
    keep = np.unique(
        np.linspace(0, len(precision) + 1, min(CURVE_POINTS, len(precision))).astype(int)
    )
    return {
        "precision": precision[keep].tolist(),
        "recall": recall[keep].tolist(),
        "average_precision": float(average_precision_score(y, scores)),
    }


def x__curve__mutmut_17(y: np.ndarray, scores: np.ndarray) -> dict[str, Any]:
    precision, recall, _ = precision_recall_curve(y, scores)
    keep = np.unique(
        np.linspace(0, len(precision) - 2, min(CURVE_POINTS, len(precision))).astype(int)
    )
    return {
        "precision": precision[keep].tolist(),
        "recall": recall[keep].tolist(),
        "average_precision": float(average_precision_score(y, scores)),
    }


def x__curve__mutmut_18(y: np.ndarray, scores: np.ndarray) -> dict[str, Any]:
    precision, recall, _ = precision_recall_curve(y, scores)
    keep = np.unique(
        np.linspace(0, len(precision) - 1, min(None, len(precision))).astype(int)
    )
    return {
        "precision": precision[keep].tolist(),
        "recall": recall[keep].tolist(),
        "average_precision": float(average_precision_score(y, scores)),
    }


def x__curve__mutmut_19(y: np.ndarray, scores: np.ndarray) -> dict[str, Any]:
    precision, recall, _ = precision_recall_curve(y, scores)
    keep = np.unique(
        np.linspace(0, len(precision) - 1, min(CURVE_POINTS, None)).astype(int)
    )
    return {
        "precision": precision[keep].tolist(),
        "recall": recall[keep].tolist(),
        "average_precision": float(average_precision_score(y, scores)),
    }


def x__curve__mutmut_20(y: np.ndarray, scores: np.ndarray) -> dict[str, Any]:
    precision, recall, _ = precision_recall_curve(y, scores)
    keep = np.unique(
        np.linspace(0, len(precision) - 1, min(len(precision))).astype(int)
    )
    return {
        "precision": precision[keep].tolist(),
        "recall": recall[keep].tolist(),
        "average_precision": float(average_precision_score(y, scores)),
    }


def x__curve__mutmut_21(y: np.ndarray, scores: np.ndarray) -> dict[str, Any]:
    precision, recall, _ = precision_recall_curve(y, scores)
    keep = np.unique(
        np.linspace(0, len(precision) - 1, min(CURVE_POINTS, )).astype(int)
    )
    return {
        "precision": precision[keep].tolist(),
        "recall": recall[keep].tolist(),
        "average_precision": float(average_precision_score(y, scores)),
    }


def x__curve__mutmut_22(y: np.ndarray, scores: np.ndarray) -> dict[str, Any]:
    precision, recall, _ = precision_recall_curve(y, scores)
    keep = np.unique(
        np.linspace(0, len(precision) - 1, min(CURVE_POINTS, len(precision))).astype(int)
    )
    return {
        "XXprecisionXX": precision[keep].tolist(),
        "recall": recall[keep].tolist(),
        "average_precision": float(average_precision_score(y, scores)),
    }


def x__curve__mutmut_23(y: np.ndarray, scores: np.ndarray) -> dict[str, Any]:
    precision, recall, _ = precision_recall_curve(y, scores)
    keep = np.unique(
        np.linspace(0, len(precision) - 1, min(CURVE_POINTS, len(precision))).astype(int)
    )
    return {
        "PRECISION": precision[keep].tolist(),
        "recall": recall[keep].tolist(),
        "average_precision": float(average_precision_score(y, scores)),
    }


def x__curve__mutmut_24(y: np.ndarray, scores: np.ndarray) -> dict[str, Any]:
    precision, recall, _ = precision_recall_curve(y, scores)
    keep = np.unique(
        np.linspace(0, len(precision) - 1, min(CURVE_POINTS, len(precision))).astype(int)
    )
    return {
        "precision": precision[keep].tolist(),
        "XXrecallXX": recall[keep].tolist(),
        "average_precision": float(average_precision_score(y, scores)),
    }


def x__curve__mutmut_25(y: np.ndarray, scores: np.ndarray) -> dict[str, Any]:
    precision, recall, _ = precision_recall_curve(y, scores)
    keep = np.unique(
        np.linspace(0, len(precision) - 1, min(CURVE_POINTS, len(precision))).astype(int)
    )
    return {
        "precision": precision[keep].tolist(),
        "RECALL": recall[keep].tolist(),
        "average_precision": float(average_precision_score(y, scores)),
    }


def x__curve__mutmut_26(y: np.ndarray, scores: np.ndarray) -> dict[str, Any]:
    precision, recall, _ = precision_recall_curve(y, scores)
    keep = np.unique(
        np.linspace(0, len(precision) - 1, min(CURVE_POINTS, len(precision))).astype(int)
    )
    return {
        "precision": precision[keep].tolist(),
        "recall": recall[keep].tolist(),
        "XXaverage_precisionXX": float(average_precision_score(y, scores)),
    }


def x__curve__mutmut_27(y: np.ndarray, scores: np.ndarray) -> dict[str, Any]:
    precision, recall, _ = precision_recall_curve(y, scores)
    keep = np.unique(
        np.linspace(0, len(precision) - 1, min(CURVE_POINTS, len(precision))).astype(int)
    )
    return {
        "precision": precision[keep].tolist(),
        "recall": recall[keep].tolist(),
        "AVERAGE_PRECISION": float(average_precision_score(y, scores)),
    }


def x__curve__mutmut_28(y: np.ndarray, scores: np.ndarray) -> dict[str, Any]:
    precision, recall, _ = precision_recall_curve(y, scores)
    keep = np.unique(
        np.linspace(0, len(precision) - 1, min(CURVE_POINTS, len(precision))).astype(int)
    )
    return {
        "precision": precision[keep].tolist(),
        "recall": recall[keep].tolist(),
        "average_precision": float(None),
    }


def x__curve__mutmut_29(y: np.ndarray, scores: np.ndarray) -> dict[str, Any]:
    precision, recall, _ = precision_recall_curve(y, scores)
    keep = np.unique(
        np.linspace(0, len(precision) - 1, min(CURVE_POINTS, len(precision))).astype(int)
    )
    return {
        "precision": precision[keep].tolist(),
        "recall": recall[keep].tolist(),
        "average_precision": float(average_precision_score(None, scores)),
    }


def x__curve__mutmut_30(y: np.ndarray, scores: np.ndarray) -> dict[str, Any]:
    precision, recall, _ = precision_recall_curve(y, scores)
    keep = np.unique(
        np.linspace(0, len(precision) - 1, min(CURVE_POINTS, len(precision))).astype(int)
    )
    return {
        "precision": precision[keep].tolist(),
        "recall": recall[keep].tolist(),
        "average_precision": float(average_precision_score(y, None)),
    }


def x__curve__mutmut_31(y: np.ndarray, scores: np.ndarray) -> dict[str, Any]:
    precision, recall, _ = precision_recall_curve(y, scores)
    keep = np.unique(
        np.linspace(0, len(precision) - 1, min(CURVE_POINTS, len(precision))).astype(int)
    )
    return {
        "precision": precision[keep].tolist(),
        "recall": recall[keep].tolist(),
        "average_precision": float(average_precision_score(scores)),
    }


def x__curve__mutmut_32(y: np.ndarray, scores: np.ndarray) -> dict[str, Any]:
    precision, recall, _ = precision_recall_curve(y, scores)
    keep = np.unique(
        np.linspace(0, len(precision) - 1, min(CURVE_POINTS, len(precision))).astype(int)
    )
    return {
        "precision": precision[keep].tolist(),
        "recall": recall[keep].tolist(),
        "average_precision": float(average_precision_score(y, )),
    }

mutants_x__curve__mutmut['_mutmut_orig'] = x__curve__mutmut_orig # type: ignore # mutmut generated
mutants_x__curve__mutmut['x__curve__mutmut_1'] = x__curve__mutmut_1 # type: ignore # mutmut generated
mutants_x__curve__mutmut['x__curve__mutmut_2'] = x__curve__mutmut_2 # type: ignore # mutmut generated
mutants_x__curve__mutmut['x__curve__mutmut_3'] = x__curve__mutmut_3 # type: ignore # mutmut generated
mutants_x__curve__mutmut['x__curve__mutmut_4'] = x__curve__mutmut_4 # type: ignore # mutmut generated
mutants_x__curve__mutmut['x__curve__mutmut_5'] = x__curve__mutmut_5 # type: ignore # mutmut generated
mutants_x__curve__mutmut['x__curve__mutmut_6'] = x__curve__mutmut_6 # type: ignore # mutmut generated
mutants_x__curve__mutmut['x__curve__mutmut_7'] = x__curve__mutmut_7 # type: ignore # mutmut generated
mutants_x__curve__mutmut['x__curve__mutmut_8'] = x__curve__mutmut_8 # type: ignore # mutmut generated
mutants_x__curve__mutmut['x__curve__mutmut_9'] = x__curve__mutmut_9 # type: ignore # mutmut generated
mutants_x__curve__mutmut['x__curve__mutmut_10'] = x__curve__mutmut_10 # type: ignore # mutmut generated
mutants_x__curve__mutmut['x__curve__mutmut_11'] = x__curve__mutmut_11 # type: ignore # mutmut generated
mutants_x__curve__mutmut['x__curve__mutmut_12'] = x__curve__mutmut_12 # type: ignore # mutmut generated
mutants_x__curve__mutmut['x__curve__mutmut_13'] = x__curve__mutmut_13 # type: ignore # mutmut generated
mutants_x__curve__mutmut['x__curve__mutmut_14'] = x__curve__mutmut_14 # type: ignore # mutmut generated
mutants_x__curve__mutmut['x__curve__mutmut_15'] = x__curve__mutmut_15 # type: ignore # mutmut generated
mutants_x__curve__mutmut['x__curve__mutmut_16'] = x__curve__mutmut_16 # type: ignore # mutmut generated
mutants_x__curve__mutmut['x__curve__mutmut_17'] = x__curve__mutmut_17 # type: ignore # mutmut generated
mutants_x__curve__mutmut['x__curve__mutmut_18'] = x__curve__mutmut_18 # type: ignore # mutmut generated
mutants_x__curve__mutmut['x__curve__mutmut_19'] = x__curve__mutmut_19 # type: ignore # mutmut generated
mutants_x__curve__mutmut['x__curve__mutmut_20'] = x__curve__mutmut_20 # type: ignore # mutmut generated
mutants_x__curve__mutmut['x__curve__mutmut_21'] = x__curve__mutmut_21 # type: ignore # mutmut generated
mutants_x__curve__mutmut['x__curve__mutmut_22'] = x__curve__mutmut_22 # type: ignore # mutmut generated
mutants_x__curve__mutmut['x__curve__mutmut_23'] = x__curve__mutmut_23 # type: ignore # mutmut generated
mutants_x__curve__mutmut['x__curve__mutmut_24'] = x__curve__mutmut_24 # type: ignore # mutmut generated
mutants_x__curve__mutmut['x__curve__mutmut_25'] = x__curve__mutmut_25 # type: ignore # mutmut generated
mutants_x__curve__mutmut['x__curve__mutmut_26'] = x__curve__mutmut_26 # type: ignore # mutmut generated
mutants_x__curve__mutmut['x__curve__mutmut_27'] = x__curve__mutmut_27 # type: ignore # mutmut generated
mutants_x__curve__mutmut['x__curve__mutmut_28'] = x__curve__mutmut_28 # type: ignore # mutmut generated
mutants_x__curve__mutmut['x__curve__mutmut_29'] = x__curve__mutmut_29 # type: ignore # mutmut generated
mutants_x__curve__mutmut['x__curve__mutmut_30'] = x__curve__mutmut_30 # type: ignore # mutmut generated
mutants_x__curve__mutmut['x__curve__mutmut_31'] = x__curve__mutmut_31 # type: ignore # mutmut generated
mutants_x__curve__mutmut['x__curve__mutmut_32'] = x__curve__mutmut_32 # type: ignore # mutmut generated
mutants_x_run_method__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_run_method__mutmut)
def run_method(
    method: str,
    train: pd.DataFrame,
    test: pd.DataFrame,
    y: np.ndarray,
    seed: int,
    prevalence: float,
) -> dict[str, Any]:
    detector = build(method, clip_contamination(prevalence), seed)
    fit = capped(train, method, seed)
    result = detect(test, detector, fit_df=fit)
    scores = result.scores.to_numpy()
    flags = result.flags.to_numpy()
    row: dict[str, Any] = {
        "seed": seed,
        "metrics": compute_metrics(y, flags, scores),
        "fit_s": result.fit_s,
        "predict_s": result.predict_s,
        "score_s": result.score_s,
        "fit_rows": int(len(fit)),
    }
    kept = fit_scores(detector, fit)
    if kept is None:
        row["fixed"] = row["metrics"]  # a rule does not read the contamination
        row["fixed_is_same"] = True
    else:
        row["fixed"] = compute_metrics(y, flags_at(kept, scores, FIXED), scores)
        if method == SWEEP_METHOD:
            row["sweep"] = {
                str(c): compute_metrics(y, flags_at(kept, scores, c), scores) for c in GRID
            }
    if seed == CURVE_SEED:
        row["curve"] = _curve(y, scores)
    return row


def x_run_method__mutmut_orig(
    method: str,
    train: pd.DataFrame,
    test: pd.DataFrame,
    y: np.ndarray,
    seed: int,
    prevalence: float,
) -> dict[str, Any]:
    detector = build(method, clip_contamination(prevalence), seed)
    fit = capped(train, method, seed)
    result = detect(test, detector, fit_df=fit)
    scores = result.scores.to_numpy()
    flags = result.flags.to_numpy()
    row: dict[str, Any] = {
        "seed": seed,
        "metrics": compute_metrics(y, flags, scores),
        "fit_s": result.fit_s,
        "predict_s": result.predict_s,
        "score_s": result.score_s,
        "fit_rows": int(len(fit)),
    }
    kept = fit_scores(detector, fit)
    if kept is None:
        row["fixed"] = row["metrics"]  # a rule does not read the contamination
        row["fixed_is_same"] = True
    else:
        row["fixed"] = compute_metrics(y, flags_at(kept, scores, FIXED), scores)
        if method == SWEEP_METHOD:
            row["sweep"] = {
                str(c): compute_metrics(y, flags_at(kept, scores, c), scores) for c in GRID
            }
    if seed == CURVE_SEED:
        row["curve"] = _curve(y, scores)
    return row


def x_run_method__mutmut_1(
    method: str,
    train: pd.DataFrame,
    test: pd.DataFrame,
    y: np.ndarray,
    seed: int,
    prevalence: float,
) -> dict[str, Any]:
    detector = None
    fit = capped(train, method, seed)
    result = detect(test, detector, fit_df=fit)
    scores = result.scores.to_numpy()
    flags = result.flags.to_numpy()
    row: dict[str, Any] = {
        "seed": seed,
        "metrics": compute_metrics(y, flags, scores),
        "fit_s": result.fit_s,
        "predict_s": result.predict_s,
        "score_s": result.score_s,
        "fit_rows": int(len(fit)),
    }
    kept = fit_scores(detector, fit)
    if kept is None:
        row["fixed"] = row["metrics"]  # a rule does not read the contamination
        row["fixed_is_same"] = True
    else:
        row["fixed"] = compute_metrics(y, flags_at(kept, scores, FIXED), scores)
        if method == SWEEP_METHOD:
            row["sweep"] = {
                str(c): compute_metrics(y, flags_at(kept, scores, c), scores) for c in GRID
            }
    if seed == CURVE_SEED:
        row["curve"] = _curve(y, scores)
    return row


def x_run_method__mutmut_2(
    method: str,
    train: pd.DataFrame,
    test: pd.DataFrame,
    y: np.ndarray,
    seed: int,
    prevalence: float,
) -> dict[str, Any]:
    detector = build(None, clip_contamination(prevalence), seed)
    fit = capped(train, method, seed)
    result = detect(test, detector, fit_df=fit)
    scores = result.scores.to_numpy()
    flags = result.flags.to_numpy()
    row: dict[str, Any] = {
        "seed": seed,
        "metrics": compute_metrics(y, flags, scores),
        "fit_s": result.fit_s,
        "predict_s": result.predict_s,
        "score_s": result.score_s,
        "fit_rows": int(len(fit)),
    }
    kept = fit_scores(detector, fit)
    if kept is None:
        row["fixed"] = row["metrics"]  # a rule does not read the contamination
        row["fixed_is_same"] = True
    else:
        row["fixed"] = compute_metrics(y, flags_at(kept, scores, FIXED), scores)
        if method == SWEEP_METHOD:
            row["sweep"] = {
                str(c): compute_metrics(y, flags_at(kept, scores, c), scores) for c in GRID
            }
    if seed == CURVE_SEED:
        row["curve"] = _curve(y, scores)
    return row


def x_run_method__mutmut_3(
    method: str,
    train: pd.DataFrame,
    test: pd.DataFrame,
    y: np.ndarray,
    seed: int,
    prevalence: float,
) -> dict[str, Any]:
    detector = build(method, None, seed)
    fit = capped(train, method, seed)
    result = detect(test, detector, fit_df=fit)
    scores = result.scores.to_numpy()
    flags = result.flags.to_numpy()
    row: dict[str, Any] = {
        "seed": seed,
        "metrics": compute_metrics(y, flags, scores),
        "fit_s": result.fit_s,
        "predict_s": result.predict_s,
        "score_s": result.score_s,
        "fit_rows": int(len(fit)),
    }
    kept = fit_scores(detector, fit)
    if kept is None:
        row["fixed"] = row["metrics"]  # a rule does not read the contamination
        row["fixed_is_same"] = True
    else:
        row["fixed"] = compute_metrics(y, flags_at(kept, scores, FIXED), scores)
        if method == SWEEP_METHOD:
            row["sweep"] = {
                str(c): compute_metrics(y, flags_at(kept, scores, c), scores) for c in GRID
            }
    if seed == CURVE_SEED:
        row["curve"] = _curve(y, scores)
    return row


def x_run_method__mutmut_4(
    method: str,
    train: pd.DataFrame,
    test: pd.DataFrame,
    y: np.ndarray,
    seed: int,
    prevalence: float,
) -> dict[str, Any]:
    detector = build(method, clip_contamination(prevalence), None)
    fit = capped(train, method, seed)
    result = detect(test, detector, fit_df=fit)
    scores = result.scores.to_numpy()
    flags = result.flags.to_numpy()
    row: dict[str, Any] = {
        "seed": seed,
        "metrics": compute_metrics(y, flags, scores),
        "fit_s": result.fit_s,
        "predict_s": result.predict_s,
        "score_s": result.score_s,
        "fit_rows": int(len(fit)),
    }
    kept = fit_scores(detector, fit)
    if kept is None:
        row["fixed"] = row["metrics"]  # a rule does not read the contamination
        row["fixed_is_same"] = True
    else:
        row["fixed"] = compute_metrics(y, flags_at(kept, scores, FIXED), scores)
        if method == SWEEP_METHOD:
            row["sweep"] = {
                str(c): compute_metrics(y, flags_at(kept, scores, c), scores) for c in GRID
            }
    if seed == CURVE_SEED:
        row["curve"] = _curve(y, scores)
    return row


def x_run_method__mutmut_5(
    method: str,
    train: pd.DataFrame,
    test: pd.DataFrame,
    y: np.ndarray,
    seed: int,
    prevalence: float,
) -> dict[str, Any]:
    detector = build(clip_contamination(prevalence), seed)
    fit = capped(train, method, seed)
    result = detect(test, detector, fit_df=fit)
    scores = result.scores.to_numpy()
    flags = result.flags.to_numpy()
    row: dict[str, Any] = {
        "seed": seed,
        "metrics": compute_metrics(y, flags, scores),
        "fit_s": result.fit_s,
        "predict_s": result.predict_s,
        "score_s": result.score_s,
        "fit_rows": int(len(fit)),
    }
    kept = fit_scores(detector, fit)
    if kept is None:
        row["fixed"] = row["metrics"]  # a rule does not read the contamination
        row["fixed_is_same"] = True
    else:
        row["fixed"] = compute_metrics(y, flags_at(kept, scores, FIXED), scores)
        if method == SWEEP_METHOD:
            row["sweep"] = {
                str(c): compute_metrics(y, flags_at(kept, scores, c), scores) for c in GRID
            }
    if seed == CURVE_SEED:
        row["curve"] = _curve(y, scores)
    return row


def x_run_method__mutmut_6(
    method: str,
    train: pd.DataFrame,
    test: pd.DataFrame,
    y: np.ndarray,
    seed: int,
    prevalence: float,
) -> dict[str, Any]:
    detector = build(method, seed)
    fit = capped(train, method, seed)
    result = detect(test, detector, fit_df=fit)
    scores = result.scores.to_numpy()
    flags = result.flags.to_numpy()
    row: dict[str, Any] = {
        "seed": seed,
        "metrics": compute_metrics(y, flags, scores),
        "fit_s": result.fit_s,
        "predict_s": result.predict_s,
        "score_s": result.score_s,
        "fit_rows": int(len(fit)),
    }
    kept = fit_scores(detector, fit)
    if kept is None:
        row["fixed"] = row["metrics"]  # a rule does not read the contamination
        row["fixed_is_same"] = True
    else:
        row["fixed"] = compute_metrics(y, flags_at(kept, scores, FIXED), scores)
        if method == SWEEP_METHOD:
            row["sweep"] = {
                str(c): compute_metrics(y, flags_at(kept, scores, c), scores) for c in GRID
            }
    if seed == CURVE_SEED:
        row["curve"] = _curve(y, scores)
    return row


def x_run_method__mutmut_7(
    method: str,
    train: pd.DataFrame,
    test: pd.DataFrame,
    y: np.ndarray,
    seed: int,
    prevalence: float,
) -> dict[str, Any]:
    detector = build(method, clip_contamination(prevalence), )
    fit = capped(train, method, seed)
    result = detect(test, detector, fit_df=fit)
    scores = result.scores.to_numpy()
    flags = result.flags.to_numpy()
    row: dict[str, Any] = {
        "seed": seed,
        "metrics": compute_metrics(y, flags, scores),
        "fit_s": result.fit_s,
        "predict_s": result.predict_s,
        "score_s": result.score_s,
        "fit_rows": int(len(fit)),
    }
    kept = fit_scores(detector, fit)
    if kept is None:
        row["fixed"] = row["metrics"]  # a rule does not read the contamination
        row["fixed_is_same"] = True
    else:
        row["fixed"] = compute_metrics(y, flags_at(kept, scores, FIXED), scores)
        if method == SWEEP_METHOD:
            row["sweep"] = {
                str(c): compute_metrics(y, flags_at(kept, scores, c), scores) for c in GRID
            }
    if seed == CURVE_SEED:
        row["curve"] = _curve(y, scores)
    return row


def x_run_method__mutmut_8(
    method: str,
    train: pd.DataFrame,
    test: pd.DataFrame,
    y: np.ndarray,
    seed: int,
    prevalence: float,
) -> dict[str, Any]:
    detector = build(method, clip_contamination(None), seed)
    fit = capped(train, method, seed)
    result = detect(test, detector, fit_df=fit)
    scores = result.scores.to_numpy()
    flags = result.flags.to_numpy()
    row: dict[str, Any] = {
        "seed": seed,
        "metrics": compute_metrics(y, flags, scores),
        "fit_s": result.fit_s,
        "predict_s": result.predict_s,
        "score_s": result.score_s,
        "fit_rows": int(len(fit)),
    }
    kept = fit_scores(detector, fit)
    if kept is None:
        row["fixed"] = row["metrics"]  # a rule does not read the contamination
        row["fixed_is_same"] = True
    else:
        row["fixed"] = compute_metrics(y, flags_at(kept, scores, FIXED), scores)
        if method == SWEEP_METHOD:
            row["sweep"] = {
                str(c): compute_metrics(y, flags_at(kept, scores, c), scores) for c in GRID
            }
    if seed == CURVE_SEED:
        row["curve"] = _curve(y, scores)
    return row


def x_run_method__mutmut_9(
    method: str,
    train: pd.DataFrame,
    test: pd.DataFrame,
    y: np.ndarray,
    seed: int,
    prevalence: float,
) -> dict[str, Any]:
    detector = build(method, clip_contamination(prevalence), seed)
    fit = None
    result = detect(test, detector, fit_df=fit)
    scores = result.scores.to_numpy()
    flags = result.flags.to_numpy()
    row: dict[str, Any] = {
        "seed": seed,
        "metrics": compute_metrics(y, flags, scores),
        "fit_s": result.fit_s,
        "predict_s": result.predict_s,
        "score_s": result.score_s,
        "fit_rows": int(len(fit)),
    }
    kept = fit_scores(detector, fit)
    if kept is None:
        row["fixed"] = row["metrics"]  # a rule does not read the contamination
        row["fixed_is_same"] = True
    else:
        row["fixed"] = compute_metrics(y, flags_at(kept, scores, FIXED), scores)
        if method == SWEEP_METHOD:
            row["sweep"] = {
                str(c): compute_metrics(y, flags_at(kept, scores, c), scores) for c in GRID
            }
    if seed == CURVE_SEED:
        row["curve"] = _curve(y, scores)
    return row


def x_run_method__mutmut_10(
    method: str,
    train: pd.DataFrame,
    test: pd.DataFrame,
    y: np.ndarray,
    seed: int,
    prevalence: float,
) -> dict[str, Any]:
    detector = build(method, clip_contamination(prevalence), seed)
    fit = capped(None, method, seed)
    result = detect(test, detector, fit_df=fit)
    scores = result.scores.to_numpy()
    flags = result.flags.to_numpy()
    row: dict[str, Any] = {
        "seed": seed,
        "metrics": compute_metrics(y, flags, scores),
        "fit_s": result.fit_s,
        "predict_s": result.predict_s,
        "score_s": result.score_s,
        "fit_rows": int(len(fit)),
    }
    kept = fit_scores(detector, fit)
    if kept is None:
        row["fixed"] = row["metrics"]  # a rule does not read the contamination
        row["fixed_is_same"] = True
    else:
        row["fixed"] = compute_metrics(y, flags_at(kept, scores, FIXED), scores)
        if method == SWEEP_METHOD:
            row["sweep"] = {
                str(c): compute_metrics(y, flags_at(kept, scores, c), scores) for c in GRID
            }
    if seed == CURVE_SEED:
        row["curve"] = _curve(y, scores)
    return row


def x_run_method__mutmut_11(
    method: str,
    train: pd.DataFrame,
    test: pd.DataFrame,
    y: np.ndarray,
    seed: int,
    prevalence: float,
) -> dict[str, Any]:
    detector = build(method, clip_contamination(prevalence), seed)
    fit = capped(train, None, seed)
    result = detect(test, detector, fit_df=fit)
    scores = result.scores.to_numpy()
    flags = result.flags.to_numpy()
    row: dict[str, Any] = {
        "seed": seed,
        "metrics": compute_metrics(y, flags, scores),
        "fit_s": result.fit_s,
        "predict_s": result.predict_s,
        "score_s": result.score_s,
        "fit_rows": int(len(fit)),
    }
    kept = fit_scores(detector, fit)
    if kept is None:
        row["fixed"] = row["metrics"]  # a rule does not read the contamination
        row["fixed_is_same"] = True
    else:
        row["fixed"] = compute_metrics(y, flags_at(kept, scores, FIXED), scores)
        if method == SWEEP_METHOD:
            row["sweep"] = {
                str(c): compute_metrics(y, flags_at(kept, scores, c), scores) for c in GRID
            }
    if seed == CURVE_SEED:
        row["curve"] = _curve(y, scores)
    return row


def x_run_method__mutmut_12(
    method: str,
    train: pd.DataFrame,
    test: pd.DataFrame,
    y: np.ndarray,
    seed: int,
    prevalence: float,
) -> dict[str, Any]:
    detector = build(method, clip_contamination(prevalence), seed)
    fit = capped(train, method, None)
    result = detect(test, detector, fit_df=fit)
    scores = result.scores.to_numpy()
    flags = result.flags.to_numpy()
    row: dict[str, Any] = {
        "seed": seed,
        "metrics": compute_metrics(y, flags, scores),
        "fit_s": result.fit_s,
        "predict_s": result.predict_s,
        "score_s": result.score_s,
        "fit_rows": int(len(fit)),
    }
    kept = fit_scores(detector, fit)
    if kept is None:
        row["fixed"] = row["metrics"]  # a rule does not read the contamination
        row["fixed_is_same"] = True
    else:
        row["fixed"] = compute_metrics(y, flags_at(kept, scores, FIXED), scores)
        if method == SWEEP_METHOD:
            row["sweep"] = {
                str(c): compute_metrics(y, flags_at(kept, scores, c), scores) for c in GRID
            }
    if seed == CURVE_SEED:
        row["curve"] = _curve(y, scores)
    return row


def x_run_method__mutmut_13(
    method: str,
    train: pd.DataFrame,
    test: pd.DataFrame,
    y: np.ndarray,
    seed: int,
    prevalence: float,
) -> dict[str, Any]:
    detector = build(method, clip_contamination(prevalence), seed)
    fit = capped(method, seed)
    result = detect(test, detector, fit_df=fit)
    scores = result.scores.to_numpy()
    flags = result.flags.to_numpy()
    row: dict[str, Any] = {
        "seed": seed,
        "metrics": compute_metrics(y, flags, scores),
        "fit_s": result.fit_s,
        "predict_s": result.predict_s,
        "score_s": result.score_s,
        "fit_rows": int(len(fit)),
    }
    kept = fit_scores(detector, fit)
    if kept is None:
        row["fixed"] = row["metrics"]  # a rule does not read the contamination
        row["fixed_is_same"] = True
    else:
        row["fixed"] = compute_metrics(y, flags_at(kept, scores, FIXED), scores)
        if method == SWEEP_METHOD:
            row["sweep"] = {
                str(c): compute_metrics(y, flags_at(kept, scores, c), scores) for c in GRID
            }
    if seed == CURVE_SEED:
        row["curve"] = _curve(y, scores)
    return row


def x_run_method__mutmut_14(
    method: str,
    train: pd.DataFrame,
    test: pd.DataFrame,
    y: np.ndarray,
    seed: int,
    prevalence: float,
) -> dict[str, Any]:
    detector = build(method, clip_contamination(prevalence), seed)
    fit = capped(train, seed)
    result = detect(test, detector, fit_df=fit)
    scores = result.scores.to_numpy()
    flags = result.flags.to_numpy()
    row: dict[str, Any] = {
        "seed": seed,
        "metrics": compute_metrics(y, flags, scores),
        "fit_s": result.fit_s,
        "predict_s": result.predict_s,
        "score_s": result.score_s,
        "fit_rows": int(len(fit)),
    }
    kept = fit_scores(detector, fit)
    if kept is None:
        row["fixed"] = row["metrics"]  # a rule does not read the contamination
        row["fixed_is_same"] = True
    else:
        row["fixed"] = compute_metrics(y, flags_at(kept, scores, FIXED), scores)
        if method == SWEEP_METHOD:
            row["sweep"] = {
                str(c): compute_metrics(y, flags_at(kept, scores, c), scores) for c in GRID
            }
    if seed == CURVE_SEED:
        row["curve"] = _curve(y, scores)
    return row


def x_run_method__mutmut_15(
    method: str,
    train: pd.DataFrame,
    test: pd.DataFrame,
    y: np.ndarray,
    seed: int,
    prevalence: float,
) -> dict[str, Any]:
    detector = build(method, clip_contamination(prevalence), seed)
    fit = capped(train, method, )
    result = detect(test, detector, fit_df=fit)
    scores = result.scores.to_numpy()
    flags = result.flags.to_numpy()
    row: dict[str, Any] = {
        "seed": seed,
        "metrics": compute_metrics(y, flags, scores),
        "fit_s": result.fit_s,
        "predict_s": result.predict_s,
        "score_s": result.score_s,
        "fit_rows": int(len(fit)),
    }
    kept = fit_scores(detector, fit)
    if kept is None:
        row["fixed"] = row["metrics"]  # a rule does not read the contamination
        row["fixed_is_same"] = True
    else:
        row["fixed"] = compute_metrics(y, flags_at(kept, scores, FIXED), scores)
        if method == SWEEP_METHOD:
            row["sweep"] = {
                str(c): compute_metrics(y, flags_at(kept, scores, c), scores) for c in GRID
            }
    if seed == CURVE_SEED:
        row["curve"] = _curve(y, scores)
    return row


def x_run_method__mutmut_16(
    method: str,
    train: pd.DataFrame,
    test: pd.DataFrame,
    y: np.ndarray,
    seed: int,
    prevalence: float,
) -> dict[str, Any]:
    detector = build(method, clip_contamination(prevalence), seed)
    fit = capped(train, method, seed)
    result = None
    scores = result.scores.to_numpy()
    flags = result.flags.to_numpy()
    row: dict[str, Any] = {
        "seed": seed,
        "metrics": compute_metrics(y, flags, scores),
        "fit_s": result.fit_s,
        "predict_s": result.predict_s,
        "score_s": result.score_s,
        "fit_rows": int(len(fit)),
    }
    kept = fit_scores(detector, fit)
    if kept is None:
        row["fixed"] = row["metrics"]  # a rule does not read the contamination
        row["fixed_is_same"] = True
    else:
        row["fixed"] = compute_metrics(y, flags_at(kept, scores, FIXED), scores)
        if method == SWEEP_METHOD:
            row["sweep"] = {
                str(c): compute_metrics(y, flags_at(kept, scores, c), scores) for c in GRID
            }
    if seed == CURVE_SEED:
        row["curve"] = _curve(y, scores)
    return row


def x_run_method__mutmut_17(
    method: str,
    train: pd.DataFrame,
    test: pd.DataFrame,
    y: np.ndarray,
    seed: int,
    prevalence: float,
) -> dict[str, Any]:
    detector = build(method, clip_contamination(prevalence), seed)
    fit = capped(train, method, seed)
    result = detect(None, detector, fit_df=fit)
    scores = result.scores.to_numpy()
    flags = result.flags.to_numpy()
    row: dict[str, Any] = {
        "seed": seed,
        "metrics": compute_metrics(y, flags, scores),
        "fit_s": result.fit_s,
        "predict_s": result.predict_s,
        "score_s": result.score_s,
        "fit_rows": int(len(fit)),
    }
    kept = fit_scores(detector, fit)
    if kept is None:
        row["fixed"] = row["metrics"]  # a rule does not read the contamination
        row["fixed_is_same"] = True
    else:
        row["fixed"] = compute_metrics(y, flags_at(kept, scores, FIXED), scores)
        if method == SWEEP_METHOD:
            row["sweep"] = {
                str(c): compute_metrics(y, flags_at(kept, scores, c), scores) for c in GRID
            }
    if seed == CURVE_SEED:
        row["curve"] = _curve(y, scores)
    return row


def x_run_method__mutmut_18(
    method: str,
    train: pd.DataFrame,
    test: pd.DataFrame,
    y: np.ndarray,
    seed: int,
    prevalence: float,
) -> dict[str, Any]:
    detector = build(method, clip_contamination(prevalence), seed)
    fit = capped(train, method, seed)
    result = detect(test, None, fit_df=fit)
    scores = result.scores.to_numpy()
    flags = result.flags.to_numpy()
    row: dict[str, Any] = {
        "seed": seed,
        "metrics": compute_metrics(y, flags, scores),
        "fit_s": result.fit_s,
        "predict_s": result.predict_s,
        "score_s": result.score_s,
        "fit_rows": int(len(fit)),
    }
    kept = fit_scores(detector, fit)
    if kept is None:
        row["fixed"] = row["metrics"]  # a rule does not read the contamination
        row["fixed_is_same"] = True
    else:
        row["fixed"] = compute_metrics(y, flags_at(kept, scores, FIXED), scores)
        if method == SWEEP_METHOD:
            row["sweep"] = {
                str(c): compute_metrics(y, flags_at(kept, scores, c), scores) for c in GRID
            }
    if seed == CURVE_SEED:
        row["curve"] = _curve(y, scores)
    return row


def x_run_method__mutmut_19(
    method: str,
    train: pd.DataFrame,
    test: pd.DataFrame,
    y: np.ndarray,
    seed: int,
    prevalence: float,
) -> dict[str, Any]:
    detector = build(method, clip_contamination(prevalence), seed)
    fit = capped(train, method, seed)
    result = detect(test, detector, fit_df=None)
    scores = result.scores.to_numpy()
    flags = result.flags.to_numpy()
    row: dict[str, Any] = {
        "seed": seed,
        "metrics": compute_metrics(y, flags, scores),
        "fit_s": result.fit_s,
        "predict_s": result.predict_s,
        "score_s": result.score_s,
        "fit_rows": int(len(fit)),
    }
    kept = fit_scores(detector, fit)
    if kept is None:
        row["fixed"] = row["metrics"]  # a rule does not read the contamination
        row["fixed_is_same"] = True
    else:
        row["fixed"] = compute_metrics(y, flags_at(kept, scores, FIXED), scores)
        if method == SWEEP_METHOD:
            row["sweep"] = {
                str(c): compute_metrics(y, flags_at(kept, scores, c), scores) for c in GRID
            }
    if seed == CURVE_SEED:
        row["curve"] = _curve(y, scores)
    return row


def x_run_method__mutmut_20(
    method: str,
    train: pd.DataFrame,
    test: pd.DataFrame,
    y: np.ndarray,
    seed: int,
    prevalence: float,
) -> dict[str, Any]:
    detector = build(method, clip_contamination(prevalence), seed)
    fit = capped(train, method, seed)
    result = detect(detector, fit_df=fit)
    scores = result.scores.to_numpy()
    flags = result.flags.to_numpy()
    row: dict[str, Any] = {
        "seed": seed,
        "metrics": compute_metrics(y, flags, scores),
        "fit_s": result.fit_s,
        "predict_s": result.predict_s,
        "score_s": result.score_s,
        "fit_rows": int(len(fit)),
    }
    kept = fit_scores(detector, fit)
    if kept is None:
        row["fixed"] = row["metrics"]  # a rule does not read the contamination
        row["fixed_is_same"] = True
    else:
        row["fixed"] = compute_metrics(y, flags_at(kept, scores, FIXED), scores)
        if method == SWEEP_METHOD:
            row["sweep"] = {
                str(c): compute_metrics(y, flags_at(kept, scores, c), scores) for c in GRID
            }
    if seed == CURVE_SEED:
        row["curve"] = _curve(y, scores)
    return row


def x_run_method__mutmut_21(
    method: str,
    train: pd.DataFrame,
    test: pd.DataFrame,
    y: np.ndarray,
    seed: int,
    prevalence: float,
) -> dict[str, Any]:
    detector = build(method, clip_contamination(prevalence), seed)
    fit = capped(train, method, seed)
    result = detect(test, fit_df=fit)
    scores = result.scores.to_numpy()
    flags = result.flags.to_numpy()
    row: dict[str, Any] = {
        "seed": seed,
        "metrics": compute_metrics(y, flags, scores),
        "fit_s": result.fit_s,
        "predict_s": result.predict_s,
        "score_s": result.score_s,
        "fit_rows": int(len(fit)),
    }
    kept = fit_scores(detector, fit)
    if kept is None:
        row["fixed"] = row["metrics"]  # a rule does not read the contamination
        row["fixed_is_same"] = True
    else:
        row["fixed"] = compute_metrics(y, flags_at(kept, scores, FIXED), scores)
        if method == SWEEP_METHOD:
            row["sweep"] = {
                str(c): compute_metrics(y, flags_at(kept, scores, c), scores) for c in GRID
            }
    if seed == CURVE_SEED:
        row["curve"] = _curve(y, scores)
    return row


def x_run_method__mutmut_22(
    method: str,
    train: pd.DataFrame,
    test: pd.DataFrame,
    y: np.ndarray,
    seed: int,
    prevalence: float,
) -> dict[str, Any]:
    detector = build(method, clip_contamination(prevalence), seed)
    fit = capped(train, method, seed)
    result = detect(test, detector, )
    scores = result.scores.to_numpy()
    flags = result.flags.to_numpy()
    row: dict[str, Any] = {
        "seed": seed,
        "metrics": compute_metrics(y, flags, scores),
        "fit_s": result.fit_s,
        "predict_s": result.predict_s,
        "score_s": result.score_s,
        "fit_rows": int(len(fit)),
    }
    kept = fit_scores(detector, fit)
    if kept is None:
        row["fixed"] = row["metrics"]  # a rule does not read the contamination
        row["fixed_is_same"] = True
    else:
        row["fixed"] = compute_metrics(y, flags_at(kept, scores, FIXED), scores)
        if method == SWEEP_METHOD:
            row["sweep"] = {
                str(c): compute_metrics(y, flags_at(kept, scores, c), scores) for c in GRID
            }
    if seed == CURVE_SEED:
        row["curve"] = _curve(y, scores)
    return row


def x_run_method__mutmut_23(
    method: str,
    train: pd.DataFrame,
    test: pd.DataFrame,
    y: np.ndarray,
    seed: int,
    prevalence: float,
) -> dict[str, Any]:
    detector = build(method, clip_contamination(prevalence), seed)
    fit = capped(train, method, seed)
    result = detect(test, detector, fit_df=fit)
    scores = None
    flags = result.flags.to_numpy()
    row: dict[str, Any] = {
        "seed": seed,
        "metrics": compute_metrics(y, flags, scores),
        "fit_s": result.fit_s,
        "predict_s": result.predict_s,
        "score_s": result.score_s,
        "fit_rows": int(len(fit)),
    }
    kept = fit_scores(detector, fit)
    if kept is None:
        row["fixed"] = row["metrics"]  # a rule does not read the contamination
        row["fixed_is_same"] = True
    else:
        row["fixed"] = compute_metrics(y, flags_at(kept, scores, FIXED), scores)
        if method == SWEEP_METHOD:
            row["sweep"] = {
                str(c): compute_metrics(y, flags_at(kept, scores, c), scores) for c in GRID
            }
    if seed == CURVE_SEED:
        row["curve"] = _curve(y, scores)
    return row


def x_run_method__mutmut_24(
    method: str,
    train: pd.DataFrame,
    test: pd.DataFrame,
    y: np.ndarray,
    seed: int,
    prevalence: float,
) -> dict[str, Any]:
    detector = build(method, clip_contamination(prevalence), seed)
    fit = capped(train, method, seed)
    result = detect(test, detector, fit_df=fit)
    scores = result.scores.to_numpy()
    flags = None
    row: dict[str, Any] = {
        "seed": seed,
        "metrics": compute_metrics(y, flags, scores),
        "fit_s": result.fit_s,
        "predict_s": result.predict_s,
        "score_s": result.score_s,
        "fit_rows": int(len(fit)),
    }
    kept = fit_scores(detector, fit)
    if kept is None:
        row["fixed"] = row["metrics"]  # a rule does not read the contamination
        row["fixed_is_same"] = True
    else:
        row["fixed"] = compute_metrics(y, flags_at(kept, scores, FIXED), scores)
        if method == SWEEP_METHOD:
            row["sweep"] = {
                str(c): compute_metrics(y, flags_at(kept, scores, c), scores) for c in GRID
            }
    if seed == CURVE_SEED:
        row["curve"] = _curve(y, scores)
    return row


def x_run_method__mutmut_25(
    method: str,
    train: pd.DataFrame,
    test: pd.DataFrame,
    y: np.ndarray,
    seed: int,
    prevalence: float,
) -> dict[str, Any]:
    detector = build(method, clip_contamination(prevalence), seed)
    fit = capped(train, method, seed)
    result = detect(test, detector, fit_df=fit)
    scores = result.scores.to_numpy()
    flags = result.flags.to_numpy()
    row: dict[str, Any] = None
    kept = fit_scores(detector, fit)
    if kept is None:
        row["fixed"] = row["metrics"]  # a rule does not read the contamination
        row["fixed_is_same"] = True
    else:
        row["fixed"] = compute_metrics(y, flags_at(kept, scores, FIXED), scores)
        if method == SWEEP_METHOD:
            row["sweep"] = {
                str(c): compute_metrics(y, flags_at(kept, scores, c), scores) for c in GRID
            }
    if seed == CURVE_SEED:
        row["curve"] = _curve(y, scores)
    return row


def x_run_method__mutmut_26(
    method: str,
    train: pd.DataFrame,
    test: pd.DataFrame,
    y: np.ndarray,
    seed: int,
    prevalence: float,
) -> dict[str, Any]:
    detector = build(method, clip_contamination(prevalence), seed)
    fit = capped(train, method, seed)
    result = detect(test, detector, fit_df=fit)
    scores = result.scores.to_numpy()
    flags = result.flags.to_numpy()
    row: dict[str, Any] = {
        "XXseedXX": seed,
        "metrics": compute_metrics(y, flags, scores),
        "fit_s": result.fit_s,
        "predict_s": result.predict_s,
        "score_s": result.score_s,
        "fit_rows": int(len(fit)),
    }
    kept = fit_scores(detector, fit)
    if kept is None:
        row["fixed"] = row["metrics"]  # a rule does not read the contamination
        row["fixed_is_same"] = True
    else:
        row["fixed"] = compute_metrics(y, flags_at(kept, scores, FIXED), scores)
        if method == SWEEP_METHOD:
            row["sweep"] = {
                str(c): compute_metrics(y, flags_at(kept, scores, c), scores) for c in GRID
            }
    if seed == CURVE_SEED:
        row["curve"] = _curve(y, scores)
    return row


def x_run_method__mutmut_27(
    method: str,
    train: pd.DataFrame,
    test: pd.DataFrame,
    y: np.ndarray,
    seed: int,
    prevalence: float,
) -> dict[str, Any]:
    detector = build(method, clip_contamination(prevalence), seed)
    fit = capped(train, method, seed)
    result = detect(test, detector, fit_df=fit)
    scores = result.scores.to_numpy()
    flags = result.flags.to_numpy()
    row: dict[str, Any] = {
        "SEED": seed,
        "metrics": compute_metrics(y, flags, scores),
        "fit_s": result.fit_s,
        "predict_s": result.predict_s,
        "score_s": result.score_s,
        "fit_rows": int(len(fit)),
    }
    kept = fit_scores(detector, fit)
    if kept is None:
        row["fixed"] = row["metrics"]  # a rule does not read the contamination
        row["fixed_is_same"] = True
    else:
        row["fixed"] = compute_metrics(y, flags_at(kept, scores, FIXED), scores)
        if method == SWEEP_METHOD:
            row["sweep"] = {
                str(c): compute_metrics(y, flags_at(kept, scores, c), scores) for c in GRID
            }
    if seed == CURVE_SEED:
        row["curve"] = _curve(y, scores)
    return row


def x_run_method__mutmut_28(
    method: str,
    train: pd.DataFrame,
    test: pd.DataFrame,
    y: np.ndarray,
    seed: int,
    prevalence: float,
) -> dict[str, Any]:
    detector = build(method, clip_contamination(prevalence), seed)
    fit = capped(train, method, seed)
    result = detect(test, detector, fit_df=fit)
    scores = result.scores.to_numpy()
    flags = result.flags.to_numpy()
    row: dict[str, Any] = {
        "seed": seed,
        "XXmetricsXX": compute_metrics(y, flags, scores),
        "fit_s": result.fit_s,
        "predict_s": result.predict_s,
        "score_s": result.score_s,
        "fit_rows": int(len(fit)),
    }
    kept = fit_scores(detector, fit)
    if kept is None:
        row["fixed"] = row["metrics"]  # a rule does not read the contamination
        row["fixed_is_same"] = True
    else:
        row["fixed"] = compute_metrics(y, flags_at(kept, scores, FIXED), scores)
        if method == SWEEP_METHOD:
            row["sweep"] = {
                str(c): compute_metrics(y, flags_at(kept, scores, c), scores) for c in GRID
            }
    if seed == CURVE_SEED:
        row["curve"] = _curve(y, scores)
    return row


def x_run_method__mutmut_29(
    method: str,
    train: pd.DataFrame,
    test: pd.DataFrame,
    y: np.ndarray,
    seed: int,
    prevalence: float,
) -> dict[str, Any]:
    detector = build(method, clip_contamination(prevalence), seed)
    fit = capped(train, method, seed)
    result = detect(test, detector, fit_df=fit)
    scores = result.scores.to_numpy()
    flags = result.flags.to_numpy()
    row: dict[str, Any] = {
        "seed": seed,
        "METRICS": compute_metrics(y, flags, scores),
        "fit_s": result.fit_s,
        "predict_s": result.predict_s,
        "score_s": result.score_s,
        "fit_rows": int(len(fit)),
    }
    kept = fit_scores(detector, fit)
    if kept is None:
        row["fixed"] = row["metrics"]  # a rule does not read the contamination
        row["fixed_is_same"] = True
    else:
        row["fixed"] = compute_metrics(y, flags_at(kept, scores, FIXED), scores)
        if method == SWEEP_METHOD:
            row["sweep"] = {
                str(c): compute_metrics(y, flags_at(kept, scores, c), scores) for c in GRID
            }
    if seed == CURVE_SEED:
        row["curve"] = _curve(y, scores)
    return row


def x_run_method__mutmut_30(
    method: str,
    train: pd.DataFrame,
    test: pd.DataFrame,
    y: np.ndarray,
    seed: int,
    prevalence: float,
) -> dict[str, Any]:
    detector = build(method, clip_contamination(prevalence), seed)
    fit = capped(train, method, seed)
    result = detect(test, detector, fit_df=fit)
    scores = result.scores.to_numpy()
    flags = result.flags.to_numpy()
    row: dict[str, Any] = {
        "seed": seed,
        "metrics": compute_metrics(None, flags, scores),
        "fit_s": result.fit_s,
        "predict_s": result.predict_s,
        "score_s": result.score_s,
        "fit_rows": int(len(fit)),
    }
    kept = fit_scores(detector, fit)
    if kept is None:
        row["fixed"] = row["metrics"]  # a rule does not read the contamination
        row["fixed_is_same"] = True
    else:
        row["fixed"] = compute_metrics(y, flags_at(kept, scores, FIXED), scores)
        if method == SWEEP_METHOD:
            row["sweep"] = {
                str(c): compute_metrics(y, flags_at(kept, scores, c), scores) for c in GRID
            }
    if seed == CURVE_SEED:
        row["curve"] = _curve(y, scores)
    return row


def x_run_method__mutmut_31(
    method: str,
    train: pd.DataFrame,
    test: pd.DataFrame,
    y: np.ndarray,
    seed: int,
    prevalence: float,
) -> dict[str, Any]:
    detector = build(method, clip_contamination(prevalence), seed)
    fit = capped(train, method, seed)
    result = detect(test, detector, fit_df=fit)
    scores = result.scores.to_numpy()
    flags = result.flags.to_numpy()
    row: dict[str, Any] = {
        "seed": seed,
        "metrics": compute_metrics(y, None, scores),
        "fit_s": result.fit_s,
        "predict_s": result.predict_s,
        "score_s": result.score_s,
        "fit_rows": int(len(fit)),
    }
    kept = fit_scores(detector, fit)
    if kept is None:
        row["fixed"] = row["metrics"]  # a rule does not read the contamination
        row["fixed_is_same"] = True
    else:
        row["fixed"] = compute_metrics(y, flags_at(kept, scores, FIXED), scores)
        if method == SWEEP_METHOD:
            row["sweep"] = {
                str(c): compute_metrics(y, flags_at(kept, scores, c), scores) for c in GRID
            }
    if seed == CURVE_SEED:
        row["curve"] = _curve(y, scores)
    return row


def x_run_method__mutmut_32(
    method: str,
    train: pd.DataFrame,
    test: pd.DataFrame,
    y: np.ndarray,
    seed: int,
    prevalence: float,
) -> dict[str, Any]:
    detector = build(method, clip_contamination(prevalence), seed)
    fit = capped(train, method, seed)
    result = detect(test, detector, fit_df=fit)
    scores = result.scores.to_numpy()
    flags = result.flags.to_numpy()
    row: dict[str, Any] = {
        "seed": seed,
        "metrics": compute_metrics(y, flags, None),
        "fit_s": result.fit_s,
        "predict_s": result.predict_s,
        "score_s": result.score_s,
        "fit_rows": int(len(fit)),
    }
    kept = fit_scores(detector, fit)
    if kept is None:
        row["fixed"] = row["metrics"]  # a rule does not read the contamination
        row["fixed_is_same"] = True
    else:
        row["fixed"] = compute_metrics(y, flags_at(kept, scores, FIXED), scores)
        if method == SWEEP_METHOD:
            row["sweep"] = {
                str(c): compute_metrics(y, flags_at(kept, scores, c), scores) for c in GRID
            }
    if seed == CURVE_SEED:
        row["curve"] = _curve(y, scores)
    return row


def x_run_method__mutmut_33(
    method: str,
    train: pd.DataFrame,
    test: pd.DataFrame,
    y: np.ndarray,
    seed: int,
    prevalence: float,
) -> dict[str, Any]:
    detector = build(method, clip_contamination(prevalence), seed)
    fit = capped(train, method, seed)
    result = detect(test, detector, fit_df=fit)
    scores = result.scores.to_numpy()
    flags = result.flags.to_numpy()
    row: dict[str, Any] = {
        "seed": seed,
        "metrics": compute_metrics(flags, scores),
        "fit_s": result.fit_s,
        "predict_s": result.predict_s,
        "score_s": result.score_s,
        "fit_rows": int(len(fit)),
    }
    kept = fit_scores(detector, fit)
    if kept is None:
        row["fixed"] = row["metrics"]  # a rule does not read the contamination
        row["fixed_is_same"] = True
    else:
        row["fixed"] = compute_metrics(y, flags_at(kept, scores, FIXED), scores)
        if method == SWEEP_METHOD:
            row["sweep"] = {
                str(c): compute_metrics(y, flags_at(kept, scores, c), scores) for c in GRID
            }
    if seed == CURVE_SEED:
        row["curve"] = _curve(y, scores)
    return row


def x_run_method__mutmut_34(
    method: str,
    train: pd.DataFrame,
    test: pd.DataFrame,
    y: np.ndarray,
    seed: int,
    prevalence: float,
) -> dict[str, Any]:
    detector = build(method, clip_contamination(prevalence), seed)
    fit = capped(train, method, seed)
    result = detect(test, detector, fit_df=fit)
    scores = result.scores.to_numpy()
    flags = result.flags.to_numpy()
    row: dict[str, Any] = {
        "seed": seed,
        "metrics": compute_metrics(y, scores),
        "fit_s": result.fit_s,
        "predict_s": result.predict_s,
        "score_s": result.score_s,
        "fit_rows": int(len(fit)),
    }
    kept = fit_scores(detector, fit)
    if kept is None:
        row["fixed"] = row["metrics"]  # a rule does not read the contamination
        row["fixed_is_same"] = True
    else:
        row["fixed"] = compute_metrics(y, flags_at(kept, scores, FIXED), scores)
        if method == SWEEP_METHOD:
            row["sweep"] = {
                str(c): compute_metrics(y, flags_at(kept, scores, c), scores) for c in GRID
            }
    if seed == CURVE_SEED:
        row["curve"] = _curve(y, scores)
    return row


def x_run_method__mutmut_35(
    method: str,
    train: pd.DataFrame,
    test: pd.DataFrame,
    y: np.ndarray,
    seed: int,
    prevalence: float,
) -> dict[str, Any]:
    detector = build(method, clip_contamination(prevalence), seed)
    fit = capped(train, method, seed)
    result = detect(test, detector, fit_df=fit)
    scores = result.scores.to_numpy()
    flags = result.flags.to_numpy()
    row: dict[str, Any] = {
        "seed": seed,
        "metrics": compute_metrics(y, flags, ),
        "fit_s": result.fit_s,
        "predict_s": result.predict_s,
        "score_s": result.score_s,
        "fit_rows": int(len(fit)),
    }
    kept = fit_scores(detector, fit)
    if kept is None:
        row["fixed"] = row["metrics"]  # a rule does not read the contamination
        row["fixed_is_same"] = True
    else:
        row["fixed"] = compute_metrics(y, flags_at(kept, scores, FIXED), scores)
        if method == SWEEP_METHOD:
            row["sweep"] = {
                str(c): compute_metrics(y, flags_at(kept, scores, c), scores) for c in GRID
            }
    if seed == CURVE_SEED:
        row["curve"] = _curve(y, scores)
    return row


def x_run_method__mutmut_36(
    method: str,
    train: pd.DataFrame,
    test: pd.DataFrame,
    y: np.ndarray,
    seed: int,
    prevalence: float,
) -> dict[str, Any]:
    detector = build(method, clip_contamination(prevalence), seed)
    fit = capped(train, method, seed)
    result = detect(test, detector, fit_df=fit)
    scores = result.scores.to_numpy()
    flags = result.flags.to_numpy()
    row: dict[str, Any] = {
        "seed": seed,
        "metrics": compute_metrics(y, flags, scores),
        "XXfit_sXX": result.fit_s,
        "predict_s": result.predict_s,
        "score_s": result.score_s,
        "fit_rows": int(len(fit)),
    }
    kept = fit_scores(detector, fit)
    if kept is None:
        row["fixed"] = row["metrics"]  # a rule does not read the contamination
        row["fixed_is_same"] = True
    else:
        row["fixed"] = compute_metrics(y, flags_at(kept, scores, FIXED), scores)
        if method == SWEEP_METHOD:
            row["sweep"] = {
                str(c): compute_metrics(y, flags_at(kept, scores, c), scores) for c in GRID
            }
    if seed == CURVE_SEED:
        row["curve"] = _curve(y, scores)
    return row


def x_run_method__mutmut_37(
    method: str,
    train: pd.DataFrame,
    test: pd.DataFrame,
    y: np.ndarray,
    seed: int,
    prevalence: float,
) -> dict[str, Any]:
    detector = build(method, clip_contamination(prevalence), seed)
    fit = capped(train, method, seed)
    result = detect(test, detector, fit_df=fit)
    scores = result.scores.to_numpy()
    flags = result.flags.to_numpy()
    row: dict[str, Any] = {
        "seed": seed,
        "metrics": compute_metrics(y, flags, scores),
        "FIT_S": result.fit_s,
        "predict_s": result.predict_s,
        "score_s": result.score_s,
        "fit_rows": int(len(fit)),
    }
    kept = fit_scores(detector, fit)
    if kept is None:
        row["fixed"] = row["metrics"]  # a rule does not read the contamination
        row["fixed_is_same"] = True
    else:
        row["fixed"] = compute_metrics(y, flags_at(kept, scores, FIXED), scores)
        if method == SWEEP_METHOD:
            row["sweep"] = {
                str(c): compute_metrics(y, flags_at(kept, scores, c), scores) for c in GRID
            }
    if seed == CURVE_SEED:
        row["curve"] = _curve(y, scores)
    return row


def x_run_method__mutmut_38(
    method: str,
    train: pd.DataFrame,
    test: pd.DataFrame,
    y: np.ndarray,
    seed: int,
    prevalence: float,
) -> dict[str, Any]:
    detector = build(method, clip_contamination(prevalence), seed)
    fit = capped(train, method, seed)
    result = detect(test, detector, fit_df=fit)
    scores = result.scores.to_numpy()
    flags = result.flags.to_numpy()
    row: dict[str, Any] = {
        "seed": seed,
        "metrics": compute_metrics(y, flags, scores),
        "fit_s": result.fit_s,
        "XXpredict_sXX": result.predict_s,
        "score_s": result.score_s,
        "fit_rows": int(len(fit)),
    }
    kept = fit_scores(detector, fit)
    if kept is None:
        row["fixed"] = row["metrics"]  # a rule does not read the contamination
        row["fixed_is_same"] = True
    else:
        row["fixed"] = compute_metrics(y, flags_at(kept, scores, FIXED), scores)
        if method == SWEEP_METHOD:
            row["sweep"] = {
                str(c): compute_metrics(y, flags_at(kept, scores, c), scores) for c in GRID
            }
    if seed == CURVE_SEED:
        row["curve"] = _curve(y, scores)
    return row


def x_run_method__mutmut_39(
    method: str,
    train: pd.DataFrame,
    test: pd.DataFrame,
    y: np.ndarray,
    seed: int,
    prevalence: float,
) -> dict[str, Any]:
    detector = build(method, clip_contamination(prevalence), seed)
    fit = capped(train, method, seed)
    result = detect(test, detector, fit_df=fit)
    scores = result.scores.to_numpy()
    flags = result.flags.to_numpy()
    row: dict[str, Any] = {
        "seed": seed,
        "metrics": compute_metrics(y, flags, scores),
        "fit_s": result.fit_s,
        "PREDICT_S": result.predict_s,
        "score_s": result.score_s,
        "fit_rows": int(len(fit)),
    }
    kept = fit_scores(detector, fit)
    if kept is None:
        row["fixed"] = row["metrics"]  # a rule does not read the contamination
        row["fixed_is_same"] = True
    else:
        row["fixed"] = compute_metrics(y, flags_at(kept, scores, FIXED), scores)
        if method == SWEEP_METHOD:
            row["sweep"] = {
                str(c): compute_metrics(y, flags_at(kept, scores, c), scores) for c in GRID
            }
    if seed == CURVE_SEED:
        row["curve"] = _curve(y, scores)
    return row


def x_run_method__mutmut_40(
    method: str,
    train: pd.DataFrame,
    test: pd.DataFrame,
    y: np.ndarray,
    seed: int,
    prevalence: float,
) -> dict[str, Any]:
    detector = build(method, clip_contamination(prevalence), seed)
    fit = capped(train, method, seed)
    result = detect(test, detector, fit_df=fit)
    scores = result.scores.to_numpy()
    flags = result.flags.to_numpy()
    row: dict[str, Any] = {
        "seed": seed,
        "metrics": compute_metrics(y, flags, scores),
        "fit_s": result.fit_s,
        "predict_s": result.predict_s,
        "XXscore_sXX": result.score_s,
        "fit_rows": int(len(fit)),
    }
    kept = fit_scores(detector, fit)
    if kept is None:
        row["fixed"] = row["metrics"]  # a rule does not read the contamination
        row["fixed_is_same"] = True
    else:
        row["fixed"] = compute_metrics(y, flags_at(kept, scores, FIXED), scores)
        if method == SWEEP_METHOD:
            row["sweep"] = {
                str(c): compute_metrics(y, flags_at(kept, scores, c), scores) for c in GRID
            }
    if seed == CURVE_SEED:
        row["curve"] = _curve(y, scores)
    return row


def x_run_method__mutmut_41(
    method: str,
    train: pd.DataFrame,
    test: pd.DataFrame,
    y: np.ndarray,
    seed: int,
    prevalence: float,
) -> dict[str, Any]:
    detector = build(method, clip_contamination(prevalence), seed)
    fit = capped(train, method, seed)
    result = detect(test, detector, fit_df=fit)
    scores = result.scores.to_numpy()
    flags = result.flags.to_numpy()
    row: dict[str, Any] = {
        "seed": seed,
        "metrics": compute_metrics(y, flags, scores),
        "fit_s": result.fit_s,
        "predict_s": result.predict_s,
        "SCORE_S": result.score_s,
        "fit_rows": int(len(fit)),
    }
    kept = fit_scores(detector, fit)
    if kept is None:
        row["fixed"] = row["metrics"]  # a rule does not read the contamination
        row["fixed_is_same"] = True
    else:
        row["fixed"] = compute_metrics(y, flags_at(kept, scores, FIXED), scores)
        if method == SWEEP_METHOD:
            row["sweep"] = {
                str(c): compute_metrics(y, flags_at(kept, scores, c), scores) for c in GRID
            }
    if seed == CURVE_SEED:
        row["curve"] = _curve(y, scores)
    return row


def x_run_method__mutmut_42(
    method: str,
    train: pd.DataFrame,
    test: pd.DataFrame,
    y: np.ndarray,
    seed: int,
    prevalence: float,
) -> dict[str, Any]:
    detector = build(method, clip_contamination(prevalence), seed)
    fit = capped(train, method, seed)
    result = detect(test, detector, fit_df=fit)
    scores = result.scores.to_numpy()
    flags = result.flags.to_numpy()
    row: dict[str, Any] = {
        "seed": seed,
        "metrics": compute_metrics(y, flags, scores),
        "fit_s": result.fit_s,
        "predict_s": result.predict_s,
        "score_s": result.score_s,
        "XXfit_rowsXX": int(len(fit)),
    }
    kept = fit_scores(detector, fit)
    if kept is None:
        row["fixed"] = row["metrics"]  # a rule does not read the contamination
        row["fixed_is_same"] = True
    else:
        row["fixed"] = compute_metrics(y, flags_at(kept, scores, FIXED), scores)
        if method == SWEEP_METHOD:
            row["sweep"] = {
                str(c): compute_metrics(y, flags_at(kept, scores, c), scores) for c in GRID
            }
    if seed == CURVE_SEED:
        row["curve"] = _curve(y, scores)
    return row


def x_run_method__mutmut_43(
    method: str,
    train: pd.DataFrame,
    test: pd.DataFrame,
    y: np.ndarray,
    seed: int,
    prevalence: float,
) -> dict[str, Any]:
    detector = build(method, clip_contamination(prevalence), seed)
    fit = capped(train, method, seed)
    result = detect(test, detector, fit_df=fit)
    scores = result.scores.to_numpy()
    flags = result.flags.to_numpy()
    row: dict[str, Any] = {
        "seed": seed,
        "metrics": compute_metrics(y, flags, scores),
        "fit_s": result.fit_s,
        "predict_s": result.predict_s,
        "score_s": result.score_s,
        "FIT_ROWS": int(len(fit)),
    }
    kept = fit_scores(detector, fit)
    if kept is None:
        row["fixed"] = row["metrics"]  # a rule does not read the contamination
        row["fixed_is_same"] = True
    else:
        row["fixed"] = compute_metrics(y, flags_at(kept, scores, FIXED), scores)
        if method == SWEEP_METHOD:
            row["sweep"] = {
                str(c): compute_metrics(y, flags_at(kept, scores, c), scores) for c in GRID
            }
    if seed == CURVE_SEED:
        row["curve"] = _curve(y, scores)
    return row


def x_run_method__mutmut_44(
    method: str,
    train: pd.DataFrame,
    test: pd.DataFrame,
    y: np.ndarray,
    seed: int,
    prevalence: float,
) -> dict[str, Any]:
    detector = build(method, clip_contamination(prevalence), seed)
    fit = capped(train, method, seed)
    result = detect(test, detector, fit_df=fit)
    scores = result.scores.to_numpy()
    flags = result.flags.to_numpy()
    row: dict[str, Any] = {
        "seed": seed,
        "metrics": compute_metrics(y, flags, scores),
        "fit_s": result.fit_s,
        "predict_s": result.predict_s,
        "score_s": result.score_s,
        "fit_rows": int(None),
    }
    kept = fit_scores(detector, fit)
    if kept is None:
        row["fixed"] = row["metrics"]  # a rule does not read the contamination
        row["fixed_is_same"] = True
    else:
        row["fixed"] = compute_metrics(y, flags_at(kept, scores, FIXED), scores)
        if method == SWEEP_METHOD:
            row["sweep"] = {
                str(c): compute_metrics(y, flags_at(kept, scores, c), scores) for c in GRID
            }
    if seed == CURVE_SEED:
        row["curve"] = _curve(y, scores)
    return row


def x_run_method__mutmut_45(
    method: str,
    train: pd.DataFrame,
    test: pd.DataFrame,
    y: np.ndarray,
    seed: int,
    prevalence: float,
) -> dict[str, Any]:
    detector = build(method, clip_contamination(prevalence), seed)
    fit = capped(train, method, seed)
    result = detect(test, detector, fit_df=fit)
    scores = result.scores.to_numpy()
    flags = result.flags.to_numpy()
    row: dict[str, Any] = {
        "seed": seed,
        "metrics": compute_metrics(y, flags, scores),
        "fit_s": result.fit_s,
        "predict_s": result.predict_s,
        "score_s": result.score_s,
        "fit_rows": int(len(fit)),
    }
    kept = None
    if kept is None:
        row["fixed"] = row["metrics"]  # a rule does not read the contamination
        row["fixed_is_same"] = True
    else:
        row["fixed"] = compute_metrics(y, flags_at(kept, scores, FIXED), scores)
        if method == SWEEP_METHOD:
            row["sweep"] = {
                str(c): compute_metrics(y, flags_at(kept, scores, c), scores) for c in GRID
            }
    if seed == CURVE_SEED:
        row["curve"] = _curve(y, scores)
    return row


def x_run_method__mutmut_46(
    method: str,
    train: pd.DataFrame,
    test: pd.DataFrame,
    y: np.ndarray,
    seed: int,
    prevalence: float,
) -> dict[str, Any]:
    detector = build(method, clip_contamination(prevalence), seed)
    fit = capped(train, method, seed)
    result = detect(test, detector, fit_df=fit)
    scores = result.scores.to_numpy()
    flags = result.flags.to_numpy()
    row: dict[str, Any] = {
        "seed": seed,
        "metrics": compute_metrics(y, flags, scores),
        "fit_s": result.fit_s,
        "predict_s": result.predict_s,
        "score_s": result.score_s,
        "fit_rows": int(len(fit)),
    }
    kept = fit_scores(None, fit)
    if kept is None:
        row["fixed"] = row["metrics"]  # a rule does not read the contamination
        row["fixed_is_same"] = True
    else:
        row["fixed"] = compute_metrics(y, flags_at(kept, scores, FIXED), scores)
        if method == SWEEP_METHOD:
            row["sweep"] = {
                str(c): compute_metrics(y, flags_at(kept, scores, c), scores) for c in GRID
            }
    if seed == CURVE_SEED:
        row["curve"] = _curve(y, scores)
    return row


def x_run_method__mutmut_47(
    method: str,
    train: pd.DataFrame,
    test: pd.DataFrame,
    y: np.ndarray,
    seed: int,
    prevalence: float,
) -> dict[str, Any]:
    detector = build(method, clip_contamination(prevalence), seed)
    fit = capped(train, method, seed)
    result = detect(test, detector, fit_df=fit)
    scores = result.scores.to_numpy()
    flags = result.flags.to_numpy()
    row: dict[str, Any] = {
        "seed": seed,
        "metrics": compute_metrics(y, flags, scores),
        "fit_s": result.fit_s,
        "predict_s": result.predict_s,
        "score_s": result.score_s,
        "fit_rows": int(len(fit)),
    }
    kept = fit_scores(detector, None)
    if kept is None:
        row["fixed"] = row["metrics"]  # a rule does not read the contamination
        row["fixed_is_same"] = True
    else:
        row["fixed"] = compute_metrics(y, flags_at(kept, scores, FIXED), scores)
        if method == SWEEP_METHOD:
            row["sweep"] = {
                str(c): compute_metrics(y, flags_at(kept, scores, c), scores) for c in GRID
            }
    if seed == CURVE_SEED:
        row["curve"] = _curve(y, scores)
    return row


def x_run_method__mutmut_48(
    method: str,
    train: pd.DataFrame,
    test: pd.DataFrame,
    y: np.ndarray,
    seed: int,
    prevalence: float,
) -> dict[str, Any]:
    detector = build(method, clip_contamination(prevalence), seed)
    fit = capped(train, method, seed)
    result = detect(test, detector, fit_df=fit)
    scores = result.scores.to_numpy()
    flags = result.flags.to_numpy()
    row: dict[str, Any] = {
        "seed": seed,
        "metrics": compute_metrics(y, flags, scores),
        "fit_s": result.fit_s,
        "predict_s": result.predict_s,
        "score_s": result.score_s,
        "fit_rows": int(len(fit)),
    }
    kept = fit_scores(fit)
    if kept is None:
        row["fixed"] = row["metrics"]  # a rule does not read the contamination
        row["fixed_is_same"] = True
    else:
        row["fixed"] = compute_metrics(y, flags_at(kept, scores, FIXED), scores)
        if method == SWEEP_METHOD:
            row["sweep"] = {
                str(c): compute_metrics(y, flags_at(kept, scores, c), scores) for c in GRID
            }
    if seed == CURVE_SEED:
        row["curve"] = _curve(y, scores)
    return row


def x_run_method__mutmut_49(
    method: str,
    train: pd.DataFrame,
    test: pd.DataFrame,
    y: np.ndarray,
    seed: int,
    prevalence: float,
) -> dict[str, Any]:
    detector = build(method, clip_contamination(prevalence), seed)
    fit = capped(train, method, seed)
    result = detect(test, detector, fit_df=fit)
    scores = result.scores.to_numpy()
    flags = result.flags.to_numpy()
    row: dict[str, Any] = {
        "seed": seed,
        "metrics": compute_metrics(y, flags, scores),
        "fit_s": result.fit_s,
        "predict_s": result.predict_s,
        "score_s": result.score_s,
        "fit_rows": int(len(fit)),
    }
    kept = fit_scores(detector, )
    if kept is None:
        row["fixed"] = row["metrics"]  # a rule does not read the contamination
        row["fixed_is_same"] = True
    else:
        row["fixed"] = compute_metrics(y, flags_at(kept, scores, FIXED), scores)
        if method == SWEEP_METHOD:
            row["sweep"] = {
                str(c): compute_metrics(y, flags_at(kept, scores, c), scores) for c in GRID
            }
    if seed == CURVE_SEED:
        row["curve"] = _curve(y, scores)
    return row


def x_run_method__mutmut_50(
    method: str,
    train: pd.DataFrame,
    test: pd.DataFrame,
    y: np.ndarray,
    seed: int,
    prevalence: float,
) -> dict[str, Any]:
    detector = build(method, clip_contamination(prevalence), seed)
    fit = capped(train, method, seed)
    result = detect(test, detector, fit_df=fit)
    scores = result.scores.to_numpy()
    flags = result.flags.to_numpy()
    row: dict[str, Any] = {
        "seed": seed,
        "metrics": compute_metrics(y, flags, scores),
        "fit_s": result.fit_s,
        "predict_s": result.predict_s,
        "score_s": result.score_s,
        "fit_rows": int(len(fit)),
    }
    kept = fit_scores(detector, fit)
    if kept is not None:
        row["fixed"] = row["metrics"]  # a rule does not read the contamination
        row["fixed_is_same"] = True
    else:
        row["fixed"] = compute_metrics(y, flags_at(kept, scores, FIXED), scores)
        if method == SWEEP_METHOD:
            row["sweep"] = {
                str(c): compute_metrics(y, flags_at(kept, scores, c), scores) for c in GRID
            }
    if seed == CURVE_SEED:
        row["curve"] = _curve(y, scores)
    return row


def x_run_method__mutmut_51(
    method: str,
    train: pd.DataFrame,
    test: pd.DataFrame,
    y: np.ndarray,
    seed: int,
    prevalence: float,
) -> dict[str, Any]:
    detector = build(method, clip_contamination(prevalence), seed)
    fit = capped(train, method, seed)
    result = detect(test, detector, fit_df=fit)
    scores = result.scores.to_numpy()
    flags = result.flags.to_numpy()
    row: dict[str, Any] = {
        "seed": seed,
        "metrics": compute_metrics(y, flags, scores),
        "fit_s": result.fit_s,
        "predict_s": result.predict_s,
        "score_s": result.score_s,
        "fit_rows": int(len(fit)),
    }
    kept = fit_scores(detector, fit)
    if kept is None:
        row["fixed"] = None  # a rule does not read the contamination
        row["fixed_is_same"] = True
    else:
        row["fixed"] = compute_metrics(y, flags_at(kept, scores, FIXED), scores)
        if method == SWEEP_METHOD:
            row["sweep"] = {
                str(c): compute_metrics(y, flags_at(kept, scores, c), scores) for c in GRID
            }
    if seed == CURVE_SEED:
        row["curve"] = _curve(y, scores)
    return row


def x_run_method__mutmut_52(
    method: str,
    train: pd.DataFrame,
    test: pd.DataFrame,
    y: np.ndarray,
    seed: int,
    prevalence: float,
) -> dict[str, Any]:
    detector = build(method, clip_contamination(prevalence), seed)
    fit = capped(train, method, seed)
    result = detect(test, detector, fit_df=fit)
    scores = result.scores.to_numpy()
    flags = result.flags.to_numpy()
    row: dict[str, Any] = {
        "seed": seed,
        "metrics": compute_metrics(y, flags, scores),
        "fit_s": result.fit_s,
        "predict_s": result.predict_s,
        "score_s": result.score_s,
        "fit_rows": int(len(fit)),
    }
    kept = fit_scores(detector, fit)
    if kept is None:
        row["XXfixedXX"] = row["metrics"]  # a rule does not read the contamination
        row["fixed_is_same"] = True
    else:
        row["fixed"] = compute_metrics(y, flags_at(kept, scores, FIXED), scores)
        if method == SWEEP_METHOD:
            row["sweep"] = {
                str(c): compute_metrics(y, flags_at(kept, scores, c), scores) for c in GRID
            }
    if seed == CURVE_SEED:
        row["curve"] = _curve(y, scores)
    return row


def x_run_method__mutmut_53(
    method: str,
    train: pd.DataFrame,
    test: pd.DataFrame,
    y: np.ndarray,
    seed: int,
    prevalence: float,
) -> dict[str, Any]:
    detector = build(method, clip_contamination(prevalence), seed)
    fit = capped(train, method, seed)
    result = detect(test, detector, fit_df=fit)
    scores = result.scores.to_numpy()
    flags = result.flags.to_numpy()
    row: dict[str, Any] = {
        "seed": seed,
        "metrics": compute_metrics(y, flags, scores),
        "fit_s": result.fit_s,
        "predict_s": result.predict_s,
        "score_s": result.score_s,
        "fit_rows": int(len(fit)),
    }
    kept = fit_scores(detector, fit)
    if kept is None:
        row["FIXED"] = row["metrics"]  # a rule does not read the contamination
        row["fixed_is_same"] = True
    else:
        row["fixed"] = compute_metrics(y, flags_at(kept, scores, FIXED), scores)
        if method == SWEEP_METHOD:
            row["sweep"] = {
                str(c): compute_metrics(y, flags_at(kept, scores, c), scores) for c in GRID
            }
    if seed == CURVE_SEED:
        row["curve"] = _curve(y, scores)
    return row


def x_run_method__mutmut_54(
    method: str,
    train: pd.DataFrame,
    test: pd.DataFrame,
    y: np.ndarray,
    seed: int,
    prevalence: float,
) -> dict[str, Any]:
    detector = build(method, clip_contamination(prevalence), seed)
    fit = capped(train, method, seed)
    result = detect(test, detector, fit_df=fit)
    scores = result.scores.to_numpy()
    flags = result.flags.to_numpy()
    row: dict[str, Any] = {
        "seed": seed,
        "metrics": compute_metrics(y, flags, scores),
        "fit_s": result.fit_s,
        "predict_s": result.predict_s,
        "score_s": result.score_s,
        "fit_rows": int(len(fit)),
    }
    kept = fit_scores(detector, fit)
    if kept is None:
        row["fixed"] = row["XXmetricsXX"]  # a rule does not read the contamination
        row["fixed_is_same"] = True
    else:
        row["fixed"] = compute_metrics(y, flags_at(kept, scores, FIXED), scores)
        if method == SWEEP_METHOD:
            row["sweep"] = {
                str(c): compute_metrics(y, flags_at(kept, scores, c), scores) for c in GRID
            }
    if seed == CURVE_SEED:
        row["curve"] = _curve(y, scores)
    return row


def x_run_method__mutmut_55(
    method: str,
    train: pd.DataFrame,
    test: pd.DataFrame,
    y: np.ndarray,
    seed: int,
    prevalence: float,
) -> dict[str, Any]:
    detector = build(method, clip_contamination(prevalence), seed)
    fit = capped(train, method, seed)
    result = detect(test, detector, fit_df=fit)
    scores = result.scores.to_numpy()
    flags = result.flags.to_numpy()
    row: dict[str, Any] = {
        "seed": seed,
        "metrics": compute_metrics(y, flags, scores),
        "fit_s": result.fit_s,
        "predict_s": result.predict_s,
        "score_s": result.score_s,
        "fit_rows": int(len(fit)),
    }
    kept = fit_scores(detector, fit)
    if kept is None:
        row["fixed"] = row["METRICS"]  # a rule does not read the contamination
        row["fixed_is_same"] = True
    else:
        row["fixed"] = compute_metrics(y, flags_at(kept, scores, FIXED), scores)
        if method == SWEEP_METHOD:
            row["sweep"] = {
                str(c): compute_metrics(y, flags_at(kept, scores, c), scores) for c in GRID
            }
    if seed == CURVE_SEED:
        row["curve"] = _curve(y, scores)
    return row


def x_run_method__mutmut_56(
    method: str,
    train: pd.DataFrame,
    test: pd.DataFrame,
    y: np.ndarray,
    seed: int,
    prevalence: float,
) -> dict[str, Any]:
    detector = build(method, clip_contamination(prevalence), seed)
    fit = capped(train, method, seed)
    result = detect(test, detector, fit_df=fit)
    scores = result.scores.to_numpy()
    flags = result.flags.to_numpy()
    row: dict[str, Any] = {
        "seed": seed,
        "metrics": compute_metrics(y, flags, scores),
        "fit_s": result.fit_s,
        "predict_s": result.predict_s,
        "score_s": result.score_s,
        "fit_rows": int(len(fit)),
    }
    kept = fit_scores(detector, fit)
    if kept is None:
        row["fixed"] = row["metrics"]  # a rule does not read the contamination
        row["fixed_is_same"] = None
    else:
        row["fixed"] = compute_metrics(y, flags_at(kept, scores, FIXED), scores)
        if method == SWEEP_METHOD:
            row["sweep"] = {
                str(c): compute_metrics(y, flags_at(kept, scores, c), scores) for c in GRID
            }
    if seed == CURVE_SEED:
        row["curve"] = _curve(y, scores)
    return row


def x_run_method__mutmut_57(
    method: str,
    train: pd.DataFrame,
    test: pd.DataFrame,
    y: np.ndarray,
    seed: int,
    prevalence: float,
) -> dict[str, Any]:
    detector = build(method, clip_contamination(prevalence), seed)
    fit = capped(train, method, seed)
    result = detect(test, detector, fit_df=fit)
    scores = result.scores.to_numpy()
    flags = result.flags.to_numpy()
    row: dict[str, Any] = {
        "seed": seed,
        "metrics": compute_metrics(y, flags, scores),
        "fit_s": result.fit_s,
        "predict_s": result.predict_s,
        "score_s": result.score_s,
        "fit_rows": int(len(fit)),
    }
    kept = fit_scores(detector, fit)
    if kept is None:
        row["fixed"] = row["metrics"]  # a rule does not read the contamination
        row["XXfixed_is_sameXX"] = True
    else:
        row["fixed"] = compute_metrics(y, flags_at(kept, scores, FIXED), scores)
        if method == SWEEP_METHOD:
            row["sweep"] = {
                str(c): compute_metrics(y, flags_at(kept, scores, c), scores) for c in GRID
            }
    if seed == CURVE_SEED:
        row["curve"] = _curve(y, scores)
    return row


def x_run_method__mutmut_58(
    method: str,
    train: pd.DataFrame,
    test: pd.DataFrame,
    y: np.ndarray,
    seed: int,
    prevalence: float,
) -> dict[str, Any]:
    detector = build(method, clip_contamination(prevalence), seed)
    fit = capped(train, method, seed)
    result = detect(test, detector, fit_df=fit)
    scores = result.scores.to_numpy()
    flags = result.flags.to_numpy()
    row: dict[str, Any] = {
        "seed": seed,
        "metrics": compute_metrics(y, flags, scores),
        "fit_s": result.fit_s,
        "predict_s": result.predict_s,
        "score_s": result.score_s,
        "fit_rows": int(len(fit)),
    }
    kept = fit_scores(detector, fit)
    if kept is None:
        row["fixed"] = row["metrics"]  # a rule does not read the contamination
        row["FIXED_IS_SAME"] = True
    else:
        row["fixed"] = compute_metrics(y, flags_at(kept, scores, FIXED), scores)
        if method == SWEEP_METHOD:
            row["sweep"] = {
                str(c): compute_metrics(y, flags_at(kept, scores, c), scores) for c in GRID
            }
    if seed == CURVE_SEED:
        row["curve"] = _curve(y, scores)
    return row


def x_run_method__mutmut_59(
    method: str,
    train: pd.DataFrame,
    test: pd.DataFrame,
    y: np.ndarray,
    seed: int,
    prevalence: float,
) -> dict[str, Any]:
    detector = build(method, clip_contamination(prevalence), seed)
    fit = capped(train, method, seed)
    result = detect(test, detector, fit_df=fit)
    scores = result.scores.to_numpy()
    flags = result.flags.to_numpy()
    row: dict[str, Any] = {
        "seed": seed,
        "metrics": compute_metrics(y, flags, scores),
        "fit_s": result.fit_s,
        "predict_s": result.predict_s,
        "score_s": result.score_s,
        "fit_rows": int(len(fit)),
    }
    kept = fit_scores(detector, fit)
    if kept is None:
        row["fixed"] = row["metrics"]  # a rule does not read the contamination
        row["fixed_is_same"] = False
    else:
        row["fixed"] = compute_metrics(y, flags_at(kept, scores, FIXED), scores)
        if method == SWEEP_METHOD:
            row["sweep"] = {
                str(c): compute_metrics(y, flags_at(kept, scores, c), scores) for c in GRID
            }
    if seed == CURVE_SEED:
        row["curve"] = _curve(y, scores)
    return row


def x_run_method__mutmut_60(
    method: str,
    train: pd.DataFrame,
    test: pd.DataFrame,
    y: np.ndarray,
    seed: int,
    prevalence: float,
) -> dict[str, Any]:
    detector = build(method, clip_contamination(prevalence), seed)
    fit = capped(train, method, seed)
    result = detect(test, detector, fit_df=fit)
    scores = result.scores.to_numpy()
    flags = result.flags.to_numpy()
    row: dict[str, Any] = {
        "seed": seed,
        "metrics": compute_metrics(y, flags, scores),
        "fit_s": result.fit_s,
        "predict_s": result.predict_s,
        "score_s": result.score_s,
        "fit_rows": int(len(fit)),
    }
    kept = fit_scores(detector, fit)
    if kept is None:
        row["fixed"] = row["metrics"]  # a rule does not read the contamination
        row["fixed_is_same"] = True
    else:
        row["fixed"] = None
        if method == SWEEP_METHOD:
            row["sweep"] = {
                str(c): compute_metrics(y, flags_at(kept, scores, c), scores) for c in GRID
            }
    if seed == CURVE_SEED:
        row["curve"] = _curve(y, scores)
    return row


def x_run_method__mutmut_61(
    method: str,
    train: pd.DataFrame,
    test: pd.DataFrame,
    y: np.ndarray,
    seed: int,
    prevalence: float,
) -> dict[str, Any]:
    detector = build(method, clip_contamination(prevalence), seed)
    fit = capped(train, method, seed)
    result = detect(test, detector, fit_df=fit)
    scores = result.scores.to_numpy()
    flags = result.flags.to_numpy()
    row: dict[str, Any] = {
        "seed": seed,
        "metrics": compute_metrics(y, flags, scores),
        "fit_s": result.fit_s,
        "predict_s": result.predict_s,
        "score_s": result.score_s,
        "fit_rows": int(len(fit)),
    }
    kept = fit_scores(detector, fit)
    if kept is None:
        row["fixed"] = row["metrics"]  # a rule does not read the contamination
        row["fixed_is_same"] = True
    else:
        row["XXfixedXX"] = compute_metrics(y, flags_at(kept, scores, FIXED), scores)
        if method == SWEEP_METHOD:
            row["sweep"] = {
                str(c): compute_metrics(y, flags_at(kept, scores, c), scores) for c in GRID
            }
    if seed == CURVE_SEED:
        row["curve"] = _curve(y, scores)
    return row


def x_run_method__mutmut_62(
    method: str,
    train: pd.DataFrame,
    test: pd.DataFrame,
    y: np.ndarray,
    seed: int,
    prevalence: float,
) -> dict[str, Any]:
    detector = build(method, clip_contamination(prevalence), seed)
    fit = capped(train, method, seed)
    result = detect(test, detector, fit_df=fit)
    scores = result.scores.to_numpy()
    flags = result.flags.to_numpy()
    row: dict[str, Any] = {
        "seed": seed,
        "metrics": compute_metrics(y, flags, scores),
        "fit_s": result.fit_s,
        "predict_s": result.predict_s,
        "score_s": result.score_s,
        "fit_rows": int(len(fit)),
    }
    kept = fit_scores(detector, fit)
    if kept is None:
        row["fixed"] = row["metrics"]  # a rule does not read the contamination
        row["fixed_is_same"] = True
    else:
        row["FIXED"] = compute_metrics(y, flags_at(kept, scores, FIXED), scores)
        if method == SWEEP_METHOD:
            row["sweep"] = {
                str(c): compute_metrics(y, flags_at(kept, scores, c), scores) for c in GRID
            }
    if seed == CURVE_SEED:
        row["curve"] = _curve(y, scores)
    return row


def x_run_method__mutmut_63(
    method: str,
    train: pd.DataFrame,
    test: pd.DataFrame,
    y: np.ndarray,
    seed: int,
    prevalence: float,
) -> dict[str, Any]:
    detector = build(method, clip_contamination(prevalence), seed)
    fit = capped(train, method, seed)
    result = detect(test, detector, fit_df=fit)
    scores = result.scores.to_numpy()
    flags = result.flags.to_numpy()
    row: dict[str, Any] = {
        "seed": seed,
        "metrics": compute_metrics(y, flags, scores),
        "fit_s": result.fit_s,
        "predict_s": result.predict_s,
        "score_s": result.score_s,
        "fit_rows": int(len(fit)),
    }
    kept = fit_scores(detector, fit)
    if kept is None:
        row["fixed"] = row["metrics"]  # a rule does not read the contamination
        row["fixed_is_same"] = True
    else:
        row["fixed"] = compute_metrics(None, flags_at(kept, scores, FIXED), scores)
        if method == SWEEP_METHOD:
            row["sweep"] = {
                str(c): compute_metrics(y, flags_at(kept, scores, c), scores) for c in GRID
            }
    if seed == CURVE_SEED:
        row["curve"] = _curve(y, scores)
    return row


def x_run_method__mutmut_64(
    method: str,
    train: pd.DataFrame,
    test: pd.DataFrame,
    y: np.ndarray,
    seed: int,
    prevalence: float,
) -> dict[str, Any]:
    detector = build(method, clip_contamination(prevalence), seed)
    fit = capped(train, method, seed)
    result = detect(test, detector, fit_df=fit)
    scores = result.scores.to_numpy()
    flags = result.flags.to_numpy()
    row: dict[str, Any] = {
        "seed": seed,
        "metrics": compute_metrics(y, flags, scores),
        "fit_s": result.fit_s,
        "predict_s": result.predict_s,
        "score_s": result.score_s,
        "fit_rows": int(len(fit)),
    }
    kept = fit_scores(detector, fit)
    if kept is None:
        row["fixed"] = row["metrics"]  # a rule does not read the contamination
        row["fixed_is_same"] = True
    else:
        row["fixed"] = compute_metrics(y, None, scores)
        if method == SWEEP_METHOD:
            row["sweep"] = {
                str(c): compute_metrics(y, flags_at(kept, scores, c), scores) for c in GRID
            }
    if seed == CURVE_SEED:
        row["curve"] = _curve(y, scores)
    return row


def x_run_method__mutmut_65(
    method: str,
    train: pd.DataFrame,
    test: pd.DataFrame,
    y: np.ndarray,
    seed: int,
    prevalence: float,
) -> dict[str, Any]:
    detector = build(method, clip_contamination(prevalence), seed)
    fit = capped(train, method, seed)
    result = detect(test, detector, fit_df=fit)
    scores = result.scores.to_numpy()
    flags = result.flags.to_numpy()
    row: dict[str, Any] = {
        "seed": seed,
        "metrics": compute_metrics(y, flags, scores),
        "fit_s": result.fit_s,
        "predict_s": result.predict_s,
        "score_s": result.score_s,
        "fit_rows": int(len(fit)),
    }
    kept = fit_scores(detector, fit)
    if kept is None:
        row["fixed"] = row["metrics"]  # a rule does not read the contamination
        row["fixed_is_same"] = True
    else:
        row["fixed"] = compute_metrics(y, flags_at(kept, scores, FIXED), None)
        if method == SWEEP_METHOD:
            row["sweep"] = {
                str(c): compute_metrics(y, flags_at(kept, scores, c), scores) for c in GRID
            }
    if seed == CURVE_SEED:
        row["curve"] = _curve(y, scores)
    return row


def x_run_method__mutmut_66(
    method: str,
    train: pd.DataFrame,
    test: pd.DataFrame,
    y: np.ndarray,
    seed: int,
    prevalence: float,
) -> dict[str, Any]:
    detector = build(method, clip_contamination(prevalence), seed)
    fit = capped(train, method, seed)
    result = detect(test, detector, fit_df=fit)
    scores = result.scores.to_numpy()
    flags = result.flags.to_numpy()
    row: dict[str, Any] = {
        "seed": seed,
        "metrics": compute_metrics(y, flags, scores),
        "fit_s": result.fit_s,
        "predict_s": result.predict_s,
        "score_s": result.score_s,
        "fit_rows": int(len(fit)),
    }
    kept = fit_scores(detector, fit)
    if kept is None:
        row["fixed"] = row["metrics"]  # a rule does not read the contamination
        row["fixed_is_same"] = True
    else:
        row["fixed"] = compute_metrics(flags_at(kept, scores, FIXED), scores)
        if method == SWEEP_METHOD:
            row["sweep"] = {
                str(c): compute_metrics(y, flags_at(kept, scores, c), scores) for c in GRID
            }
    if seed == CURVE_SEED:
        row["curve"] = _curve(y, scores)
    return row


def x_run_method__mutmut_67(
    method: str,
    train: pd.DataFrame,
    test: pd.DataFrame,
    y: np.ndarray,
    seed: int,
    prevalence: float,
) -> dict[str, Any]:
    detector = build(method, clip_contamination(prevalence), seed)
    fit = capped(train, method, seed)
    result = detect(test, detector, fit_df=fit)
    scores = result.scores.to_numpy()
    flags = result.flags.to_numpy()
    row: dict[str, Any] = {
        "seed": seed,
        "metrics": compute_metrics(y, flags, scores),
        "fit_s": result.fit_s,
        "predict_s": result.predict_s,
        "score_s": result.score_s,
        "fit_rows": int(len(fit)),
    }
    kept = fit_scores(detector, fit)
    if kept is None:
        row["fixed"] = row["metrics"]  # a rule does not read the contamination
        row["fixed_is_same"] = True
    else:
        row["fixed"] = compute_metrics(y, scores)
        if method == SWEEP_METHOD:
            row["sweep"] = {
                str(c): compute_metrics(y, flags_at(kept, scores, c), scores) for c in GRID
            }
    if seed == CURVE_SEED:
        row["curve"] = _curve(y, scores)
    return row


def x_run_method__mutmut_68(
    method: str,
    train: pd.DataFrame,
    test: pd.DataFrame,
    y: np.ndarray,
    seed: int,
    prevalence: float,
) -> dict[str, Any]:
    detector = build(method, clip_contamination(prevalence), seed)
    fit = capped(train, method, seed)
    result = detect(test, detector, fit_df=fit)
    scores = result.scores.to_numpy()
    flags = result.flags.to_numpy()
    row: dict[str, Any] = {
        "seed": seed,
        "metrics": compute_metrics(y, flags, scores),
        "fit_s": result.fit_s,
        "predict_s": result.predict_s,
        "score_s": result.score_s,
        "fit_rows": int(len(fit)),
    }
    kept = fit_scores(detector, fit)
    if kept is None:
        row["fixed"] = row["metrics"]  # a rule does not read the contamination
        row["fixed_is_same"] = True
    else:
        row["fixed"] = compute_metrics(y, flags_at(kept, scores, FIXED), )
        if method == SWEEP_METHOD:
            row["sweep"] = {
                str(c): compute_metrics(y, flags_at(kept, scores, c), scores) for c in GRID
            }
    if seed == CURVE_SEED:
        row["curve"] = _curve(y, scores)
    return row


def x_run_method__mutmut_69(
    method: str,
    train: pd.DataFrame,
    test: pd.DataFrame,
    y: np.ndarray,
    seed: int,
    prevalence: float,
) -> dict[str, Any]:
    detector = build(method, clip_contamination(prevalence), seed)
    fit = capped(train, method, seed)
    result = detect(test, detector, fit_df=fit)
    scores = result.scores.to_numpy()
    flags = result.flags.to_numpy()
    row: dict[str, Any] = {
        "seed": seed,
        "metrics": compute_metrics(y, flags, scores),
        "fit_s": result.fit_s,
        "predict_s": result.predict_s,
        "score_s": result.score_s,
        "fit_rows": int(len(fit)),
    }
    kept = fit_scores(detector, fit)
    if kept is None:
        row["fixed"] = row["metrics"]  # a rule does not read the contamination
        row["fixed_is_same"] = True
    else:
        row["fixed"] = compute_metrics(y, flags_at(None, scores, FIXED), scores)
        if method == SWEEP_METHOD:
            row["sweep"] = {
                str(c): compute_metrics(y, flags_at(kept, scores, c), scores) for c in GRID
            }
    if seed == CURVE_SEED:
        row["curve"] = _curve(y, scores)
    return row


def x_run_method__mutmut_70(
    method: str,
    train: pd.DataFrame,
    test: pd.DataFrame,
    y: np.ndarray,
    seed: int,
    prevalence: float,
) -> dict[str, Any]:
    detector = build(method, clip_contamination(prevalence), seed)
    fit = capped(train, method, seed)
    result = detect(test, detector, fit_df=fit)
    scores = result.scores.to_numpy()
    flags = result.flags.to_numpy()
    row: dict[str, Any] = {
        "seed": seed,
        "metrics": compute_metrics(y, flags, scores),
        "fit_s": result.fit_s,
        "predict_s": result.predict_s,
        "score_s": result.score_s,
        "fit_rows": int(len(fit)),
    }
    kept = fit_scores(detector, fit)
    if kept is None:
        row["fixed"] = row["metrics"]  # a rule does not read the contamination
        row["fixed_is_same"] = True
    else:
        row["fixed"] = compute_metrics(y, flags_at(kept, None, FIXED), scores)
        if method == SWEEP_METHOD:
            row["sweep"] = {
                str(c): compute_metrics(y, flags_at(kept, scores, c), scores) for c in GRID
            }
    if seed == CURVE_SEED:
        row["curve"] = _curve(y, scores)
    return row


def x_run_method__mutmut_71(
    method: str,
    train: pd.DataFrame,
    test: pd.DataFrame,
    y: np.ndarray,
    seed: int,
    prevalence: float,
) -> dict[str, Any]:
    detector = build(method, clip_contamination(prevalence), seed)
    fit = capped(train, method, seed)
    result = detect(test, detector, fit_df=fit)
    scores = result.scores.to_numpy()
    flags = result.flags.to_numpy()
    row: dict[str, Any] = {
        "seed": seed,
        "metrics": compute_metrics(y, flags, scores),
        "fit_s": result.fit_s,
        "predict_s": result.predict_s,
        "score_s": result.score_s,
        "fit_rows": int(len(fit)),
    }
    kept = fit_scores(detector, fit)
    if kept is None:
        row["fixed"] = row["metrics"]  # a rule does not read the contamination
        row["fixed_is_same"] = True
    else:
        row["fixed"] = compute_metrics(y, flags_at(kept, scores, None), scores)
        if method == SWEEP_METHOD:
            row["sweep"] = {
                str(c): compute_metrics(y, flags_at(kept, scores, c), scores) for c in GRID
            }
    if seed == CURVE_SEED:
        row["curve"] = _curve(y, scores)
    return row


def x_run_method__mutmut_72(
    method: str,
    train: pd.DataFrame,
    test: pd.DataFrame,
    y: np.ndarray,
    seed: int,
    prevalence: float,
) -> dict[str, Any]:
    detector = build(method, clip_contamination(prevalence), seed)
    fit = capped(train, method, seed)
    result = detect(test, detector, fit_df=fit)
    scores = result.scores.to_numpy()
    flags = result.flags.to_numpy()
    row: dict[str, Any] = {
        "seed": seed,
        "metrics": compute_metrics(y, flags, scores),
        "fit_s": result.fit_s,
        "predict_s": result.predict_s,
        "score_s": result.score_s,
        "fit_rows": int(len(fit)),
    }
    kept = fit_scores(detector, fit)
    if kept is None:
        row["fixed"] = row["metrics"]  # a rule does not read the contamination
        row["fixed_is_same"] = True
    else:
        row["fixed"] = compute_metrics(y, flags_at(scores, FIXED), scores)
        if method == SWEEP_METHOD:
            row["sweep"] = {
                str(c): compute_metrics(y, flags_at(kept, scores, c), scores) for c in GRID
            }
    if seed == CURVE_SEED:
        row["curve"] = _curve(y, scores)
    return row


def x_run_method__mutmut_73(
    method: str,
    train: pd.DataFrame,
    test: pd.DataFrame,
    y: np.ndarray,
    seed: int,
    prevalence: float,
) -> dict[str, Any]:
    detector = build(method, clip_contamination(prevalence), seed)
    fit = capped(train, method, seed)
    result = detect(test, detector, fit_df=fit)
    scores = result.scores.to_numpy()
    flags = result.flags.to_numpy()
    row: dict[str, Any] = {
        "seed": seed,
        "metrics": compute_metrics(y, flags, scores),
        "fit_s": result.fit_s,
        "predict_s": result.predict_s,
        "score_s": result.score_s,
        "fit_rows": int(len(fit)),
    }
    kept = fit_scores(detector, fit)
    if kept is None:
        row["fixed"] = row["metrics"]  # a rule does not read the contamination
        row["fixed_is_same"] = True
    else:
        row["fixed"] = compute_metrics(y, flags_at(kept, FIXED), scores)
        if method == SWEEP_METHOD:
            row["sweep"] = {
                str(c): compute_metrics(y, flags_at(kept, scores, c), scores) for c in GRID
            }
    if seed == CURVE_SEED:
        row["curve"] = _curve(y, scores)
    return row


def x_run_method__mutmut_74(
    method: str,
    train: pd.DataFrame,
    test: pd.DataFrame,
    y: np.ndarray,
    seed: int,
    prevalence: float,
) -> dict[str, Any]:
    detector = build(method, clip_contamination(prevalence), seed)
    fit = capped(train, method, seed)
    result = detect(test, detector, fit_df=fit)
    scores = result.scores.to_numpy()
    flags = result.flags.to_numpy()
    row: dict[str, Any] = {
        "seed": seed,
        "metrics": compute_metrics(y, flags, scores),
        "fit_s": result.fit_s,
        "predict_s": result.predict_s,
        "score_s": result.score_s,
        "fit_rows": int(len(fit)),
    }
    kept = fit_scores(detector, fit)
    if kept is None:
        row["fixed"] = row["metrics"]  # a rule does not read the contamination
        row["fixed_is_same"] = True
    else:
        row["fixed"] = compute_metrics(y, flags_at(kept, scores, ), scores)
        if method == SWEEP_METHOD:
            row["sweep"] = {
                str(c): compute_metrics(y, flags_at(kept, scores, c), scores) for c in GRID
            }
    if seed == CURVE_SEED:
        row["curve"] = _curve(y, scores)
    return row


def x_run_method__mutmut_75(
    method: str,
    train: pd.DataFrame,
    test: pd.DataFrame,
    y: np.ndarray,
    seed: int,
    prevalence: float,
) -> dict[str, Any]:
    detector = build(method, clip_contamination(prevalence), seed)
    fit = capped(train, method, seed)
    result = detect(test, detector, fit_df=fit)
    scores = result.scores.to_numpy()
    flags = result.flags.to_numpy()
    row: dict[str, Any] = {
        "seed": seed,
        "metrics": compute_metrics(y, flags, scores),
        "fit_s": result.fit_s,
        "predict_s": result.predict_s,
        "score_s": result.score_s,
        "fit_rows": int(len(fit)),
    }
    kept = fit_scores(detector, fit)
    if kept is None:
        row["fixed"] = row["metrics"]  # a rule does not read the contamination
        row["fixed_is_same"] = True
    else:
        row["fixed"] = compute_metrics(y, flags_at(kept, scores, FIXED), scores)
        if method != SWEEP_METHOD:
            row["sweep"] = {
                str(c): compute_metrics(y, flags_at(kept, scores, c), scores) for c in GRID
            }
    if seed == CURVE_SEED:
        row["curve"] = _curve(y, scores)
    return row


def x_run_method__mutmut_76(
    method: str,
    train: pd.DataFrame,
    test: pd.DataFrame,
    y: np.ndarray,
    seed: int,
    prevalence: float,
) -> dict[str, Any]:
    detector = build(method, clip_contamination(prevalence), seed)
    fit = capped(train, method, seed)
    result = detect(test, detector, fit_df=fit)
    scores = result.scores.to_numpy()
    flags = result.flags.to_numpy()
    row: dict[str, Any] = {
        "seed": seed,
        "metrics": compute_metrics(y, flags, scores),
        "fit_s": result.fit_s,
        "predict_s": result.predict_s,
        "score_s": result.score_s,
        "fit_rows": int(len(fit)),
    }
    kept = fit_scores(detector, fit)
    if kept is None:
        row["fixed"] = row["metrics"]  # a rule does not read the contamination
        row["fixed_is_same"] = True
    else:
        row["fixed"] = compute_metrics(y, flags_at(kept, scores, FIXED), scores)
        if method == SWEEP_METHOD:
            row["sweep"] = None
    if seed == CURVE_SEED:
        row["curve"] = _curve(y, scores)
    return row


def x_run_method__mutmut_77(
    method: str,
    train: pd.DataFrame,
    test: pd.DataFrame,
    y: np.ndarray,
    seed: int,
    prevalence: float,
) -> dict[str, Any]:
    detector = build(method, clip_contamination(prevalence), seed)
    fit = capped(train, method, seed)
    result = detect(test, detector, fit_df=fit)
    scores = result.scores.to_numpy()
    flags = result.flags.to_numpy()
    row: dict[str, Any] = {
        "seed": seed,
        "metrics": compute_metrics(y, flags, scores),
        "fit_s": result.fit_s,
        "predict_s": result.predict_s,
        "score_s": result.score_s,
        "fit_rows": int(len(fit)),
    }
    kept = fit_scores(detector, fit)
    if kept is None:
        row["fixed"] = row["metrics"]  # a rule does not read the contamination
        row["fixed_is_same"] = True
    else:
        row["fixed"] = compute_metrics(y, flags_at(kept, scores, FIXED), scores)
        if method == SWEEP_METHOD:
            row["XXsweepXX"] = {
                str(c): compute_metrics(y, flags_at(kept, scores, c), scores) for c in GRID
            }
    if seed == CURVE_SEED:
        row["curve"] = _curve(y, scores)
    return row


def x_run_method__mutmut_78(
    method: str,
    train: pd.DataFrame,
    test: pd.DataFrame,
    y: np.ndarray,
    seed: int,
    prevalence: float,
) -> dict[str, Any]:
    detector = build(method, clip_contamination(prevalence), seed)
    fit = capped(train, method, seed)
    result = detect(test, detector, fit_df=fit)
    scores = result.scores.to_numpy()
    flags = result.flags.to_numpy()
    row: dict[str, Any] = {
        "seed": seed,
        "metrics": compute_metrics(y, flags, scores),
        "fit_s": result.fit_s,
        "predict_s": result.predict_s,
        "score_s": result.score_s,
        "fit_rows": int(len(fit)),
    }
    kept = fit_scores(detector, fit)
    if kept is None:
        row["fixed"] = row["metrics"]  # a rule does not read the contamination
        row["fixed_is_same"] = True
    else:
        row["fixed"] = compute_metrics(y, flags_at(kept, scores, FIXED), scores)
        if method == SWEEP_METHOD:
            row["SWEEP"] = {
                str(c): compute_metrics(y, flags_at(kept, scores, c), scores) for c in GRID
            }
    if seed == CURVE_SEED:
        row["curve"] = _curve(y, scores)
    return row


def x_run_method__mutmut_79(
    method: str,
    train: pd.DataFrame,
    test: pd.DataFrame,
    y: np.ndarray,
    seed: int,
    prevalence: float,
) -> dict[str, Any]:
    detector = build(method, clip_contamination(prevalence), seed)
    fit = capped(train, method, seed)
    result = detect(test, detector, fit_df=fit)
    scores = result.scores.to_numpy()
    flags = result.flags.to_numpy()
    row: dict[str, Any] = {
        "seed": seed,
        "metrics": compute_metrics(y, flags, scores),
        "fit_s": result.fit_s,
        "predict_s": result.predict_s,
        "score_s": result.score_s,
        "fit_rows": int(len(fit)),
    }
    kept = fit_scores(detector, fit)
    if kept is None:
        row["fixed"] = row["metrics"]  # a rule does not read the contamination
        row["fixed_is_same"] = True
    else:
        row["fixed"] = compute_metrics(y, flags_at(kept, scores, FIXED), scores)
        if method == SWEEP_METHOD:
            row["sweep"] = {
                str(None): compute_metrics(y, flags_at(kept, scores, c), scores) for c in GRID
            }
    if seed == CURVE_SEED:
        row["curve"] = _curve(y, scores)
    return row


def x_run_method__mutmut_80(
    method: str,
    train: pd.DataFrame,
    test: pd.DataFrame,
    y: np.ndarray,
    seed: int,
    prevalence: float,
) -> dict[str, Any]:
    detector = build(method, clip_contamination(prevalence), seed)
    fit = capped(train, method, seed)
    result = detect(test, detector, fit_df=fit)
    scores = result.scores.to_numpy()
    flags = result.flags.to_numpy()
    row: dict[str, Any] = {
        "seed": seed,
        "metrics": compute_metrics(y, flags, scores),
        "fit_s": result.fit_s,
        "predict_s": result.predict_s,
        "score_s": result.score_s,
        "fit_rows": int(len(fit)),
    }
    kept = fit_scores(detector, fit)
    if kept is None:
        row["fixed"] = row["metrics"]  # a rule does not read the contamination
        row["fixed_is_same"] = True
    else:
        row["fixed"] = compute_metrics(y, flags_at(kept, scores, FIXED), scores)
        if method == SWEEP_METHOD:
            row["sweep"] = {
                str(c): compute_metrics(None, flags_at(kept, scores, c), scores) for c in GRID
            }
    if seed == CURVE_SEED:
        row["curve"] = _curve(y, scores)
    return row


def x_run_method__mutmut_81(
    method: str,
    train: pd.DataFrame,
    test: pd.DataFrame,
    y: np.ndarray,
    seed: int,
    prevalence: float,
) -> dict[str, Any]:
    detector = build(method, clip_contamination(prevalence), seed)
    fit = capped(train, method, seed)
    result = detect(test, detector, fit_df=fit)
    scores = result.scores.to_numpy()
    flags = result.flags.to_numpy()
    row: dict[str, Any] = {
        "seed": seed,
        "metrics": compute_metrics(y, flags, scores),
        "fit_s": result.fit_s,
        "predict_s": result.predict_s,
        "score_s": result.score_s,
        "fit_rows": int(len(fit)),
    }
    kept = fit_scores(detector, fit)
    if kept is None:
        row["fixed"] = row["metrics"]  # a rule does not read the contamination
        row["fixed_is_same"] = True
    else:
        row["fixed"] = compute_metrics(y, flags_at(kept, scores, FIXED), scores)
        if method == SWEEP_METHOD:
            row["sweep"] = {
                str(c): compute_metrics(y, None, scores) for c in GRID
            }
    if seed == CURVE_SEED:
        row["curve"] = _curve(y, scores)
    return row


def x_run_method__mutmut_82(
    method: str,
    train: pd.DataFrame,
    test: pd.DataFrame,
    y: np.ndarray,
    seed: int,
    prevalence: float,
) -> dict[str, Any]:
    detector = build(method, clip_contamination(prevalence), seed)
    fit = capped(train, method, seed)
    result = detect(test, detector, fit_df=fit)
    scores = result.scores.to_numpy()
    flags = result.flags.to_numpy()
    row: dict[str, Any] = {
        "seed": seed,
        "metrics": compute_metrics(y, flags, scores),
        "fit_s": result.fit_s,
        "predict_s": result.predict_s,
        "score_s": result.score_s,
        "fit_rows": int(len(fit)),
    }
    kept = fit_scores(detector, fit)
    if kept is None:
        row["fixed"] = row["metrics"]  # a rule does not read the contamination
        row["fixed_is_same"] = True
    else:
        row["fixed"] = compute_metrics(y, flags_at(kept, scores, FIXED), scores)
        if method == SWEEP_METHOD:
            row["sweep"] = {
                str(c): compute_metrics(y, flags_at(kept, scores, c), None) for c in GRID
            }
    if seed == CURVE_SEED:
        row["curve"] = _curve(y, scores)
    return row


def x_run_method__mutmut_83(
    method: str,
    train: pd.DataFrame,
    test: pd.DataFrame,
    y: np.ndarray,
    seed: int,
    prevalence: float,
) -> dict[str, Any]:
    detector = build(method, clip_contamination(prevalence), seed)
    fit = capped(train, method, seed)
    result = detect(test, detector, fit_df=fit)
    scores = result.scores.to_numpy()
    flags = result.flags.to_numpy()
    row: dict[str, Any] = {
        "seed": seed,
        "metrics": compute_metrics(y, flags, scores),
        "fit_s": result.fit_s,
        "predict_s": result.predict_s,
        "score_s": result.score_s,
        "fit_rows": int(len(fit)),
    }
    kept = fit_scores(detector, fit)
    if kept is None:
        row["fixed"] = row["metrics"]  # a rule does not read the contamination
        row["fixed_is_same"] = True
    else:
        row["fixed"] = compute_metrics(y, flags_at(kept, scores, FIXED), scores)
        if method == SWEEP_METHOD:
            row["sweep"] = {
                str(c): compute_metrics(flags_at(kept, scores, c), scores) for c in GRID
            }
    if seed == CURVE_SEED:
        row["curve"] = _curve(y, scores)
    return row


def x_run_method__mutmut_84(
    method: str,
    train: pd.DataFrame,
    test: pd.DataFrame,
    y: np.ndarray,
    seed: int,
    prevalence: float,
) -> dict[str, Any]:
    detector = build(method, clip_contamination(prevalence), seed)
    fit = capped(train, method, seed)
    result = detect(test, detector, fit_df=fit)
    scores = result.scores.to_numpy()
    flags = result.flags.to_numpy()
    row: dict[str, Any] = {
        "seed": seed,
        "metrics": compute_metrics(y, flags, scores),
        "fit_s": result.fit_s,
        "predict_s": result.predict_s,
        "score_s": result.score_s,
        "fit_rows": int(len(fit)),
    }
    kept = fit_scores(detector, fit)
    if kept is None:
        row["fixed"] = row["metrics"]  # a rule does not read the contamination
        row["fixed_is_same"] = True
    else:
        row["fixed"] = compute_metrics(y, flags_at(kept, scores, FIXED), scores)
        if method == SWEEP_METHOD:
            row["sweep"] = {
                str(c): compute_metrics(y, scores) for c in GRID
            }
    if seed == CURVE_SEED:
        row["curve"] = _curve(y, scores)
    return row


def x_run_method__mutmut_85(
    method: str,
    train: pd.DataFrame,
    test: pd.DataFrame,
    y: np.ndarray,
    seed: int,
    prevalence: float,
) -> dict[str, Any]:
    detector = build(method, clip_contamination(prevalence), seed)
    fit = capped(train, method, seed)
    result = detect(test, detector, fit_df=fit)
    scores = result.scores.to_numpy()
    flags = result.flags.to_numpy()
    row: dict[str, Any] = {
        "seed": seed,
        "metrics": compute_metrics(y, flags, scores),
        "fit_s": result.fit_s,
        "predict_s": result.predict_s,
        "score_s": result.score_s,
        "fit_rows": int(len(fit)),
    }
    kept = fit_scores(detector, fit)
    if kept is None:
        row["fixed"] = row["metrics"]  # a rule does not read the contamination
        row["fixed_is_same"] = True
    else:
        row["fixed"] = compute_metrics(y, flags_at(kept, scores, FIXED), scores)
        if method == SWEEP_METHOD:
            row["sweep"] = {
                str(c): compute_metrics(y, flags_at(kept, scores, c), ) for c in GRID
            }
    if seed == CURVE_SEED:
        row["curve"] = _curve(y, scores)
    return row


def x_run_method__mutmut_86(
    method: str,
    train: pd.DataFrame,
    test: pd.DataFrame,
    y: np.ndarray,
    seed: int,
    prevalence: float,
) -> dict[str, Any]:
    detector = build(method, clip_contamination(prevalence), seed)
    fit = capped(train, method, seed)
    result = detect(test, detector, fit_df=fit)
    scores = result.scores.to_numpy()
    flags = result.flags.to_numpy()
    row: dict[str, Any] = {
        "seed": seed,
        "metrics": compute_metrics(y, flags, scores),
        "fit_s": result.fit_s,
        "predict_s": result.predict_s,
        "score_s": result.score_s,
        "fit_rows": int(len(fit)),
    }
    kept = fit_scores(detector, fit)
    if kept is None:
        row["fixed"] = row["metrics"]  # a rule does not read the contamination
        row["fixed_is_same"] = True
    else:
        row["fixed"] = compute_metrics(y, flags_at(kept, scores, FIXED), scores)
        if method == SWEEP_METHOD:
            row["sweep"] = {
                str(c): compute_metrics(y, flags_at(None, scores, c), scores) for c in GRID
            }
    if seed == CURVE_SEED:
        row["curve"] = _curve(y, scores)
    return row


def x_run_method__mutmut_87(
    method: str,
    train: pd.DataFrame,
    test: pd.DataFrame,
    y: np.ndarray,
    seed: int,
    prevalence: float,
) -> dict[str, Any]:
    detector = build(method, clip_contamination(prevalence), seed)
    fit = capped(train, method, seed)
    result = detect(test, detector, fit_df=fit)
    scores = result.scores.to_numpy()
    flags = result.flags.to_numpy()
    row: dict[str, Any] = {
        "seed": seed,
        "metrics": compute_metrics(y, flags, scores),
        "fit_s": result.fit_s,
        "predict_s": result.predict_s,
        "score_s": result.score_s,
        "fit_rows": int(len(fit)),
    }
    kept = fit_scores(detector, fit)
    if kept is None:
        row["fixed"] = row["metrics"]  # a rule does not read the contamination
        row["fixed_is_same"] = True
    else:
        row["fixed"] = compute_metrics(y, flags_at(kept, scores, FIXED), scores)
        if method == SWEEP_METHOD:
            row["sweep"] = {
                str(c): compute_metrics(y, flags_at(kept, None, c), scores) for c in GRID
            }
    if seed == CURVE_SEED:
        row["curve"] = _curve(y, scores)
    return row


def x_run_method__mutmut_88(
    method: str,
    train: pd.DataFrame,
    test: pd.DataFrame,
    y: np.ndarray,
    seed: int,
    prevalence: float,
) -> dict[str, Any]:
    detector = build(method, clip_contamination(prevalence), seed)
    fit = capped(train, method, seed)
    result = detect(test, detector, fit_df=fit)
    scores = result.scores.to_numpy()
    flags = result.flags.to_numpy()
    row: dict[str, Any] = {
        "seed": seed,
        "metrics": compute_metrics(y, flags, scores),
        "fit_s": result.fit_s,
        "predict_s": result.predict_s,
        "score_s": result.score_s,
        "fit_rows": int(len(fit)),
    }
    kept = fit_scores(detector, fit)
    if kept is None:
        row["fixed"] = row["metrics"]  # a rule does not read the contamination
        row["fixed_is_same"] = True
    else:
        row["fixed"] = compute_metrics(y, flags_at(kept, scores, FIXED), scores)
        if method == SWEEP_METHOD:
            row["sweep"] = {
                str(c): compute_metrics(y, flags_at(kept, scores, None), scores) for c in GRID
            }
    if seed == CURVE_SEED:
        row["curve"] = _curve(y, scores)
    return row


def x_run_method__mutmut_89(
    method: str,
    train: pd.DataFrame,
    test: pd.DataFrame,
    y: np.ndarray,
    seed: int,
    prevalence: float,
) -> dict[str, Any]:
    detector = build(method, clip_contamination(prevalence), seed)
    fit = capped(train, method, seed)
    result = detect(test, detector, fit_df=fit)
    scores = result.scores.to_numpy()
    flags = result.flags.to_numpy()
    row: dict[str, Any] = {
        "seed": seed,
        "metrics": compute_metrics(y, flags, scores),
        "fit_s": result.fit_s,
        "predict_s": result.predict_s,
        "score_s": result.score_s,
        "fit_rows": int(len(fit)),
    }
    kept = fit_scores(detector, fit)
    if kept is None:
        row["fixed"] = row["metrics"]  # a rule does not read the contamination
        row["fixed_is_same"] = True
    else:
        row["fixed"] = compute_metrics(y, flags_at(kept, scores, FIXED), scores)
        if method == SWEEP_METHOD:
            row["sweep"] = {
                str(c): compute_metrics(y, flags_at(scores, c), scores) for c in GRID
            }
    if seed == CURVE_SEED:
        row["curve"] = _curve(y, scores)
    return row


def x_run_method__mutmut_90(
    method: str,
    train: pd.DataFrame,
    test: pd.DataFrame,
    y: np.ndarray,
    seed: int,
    prevalence: float,
) -> dict[str, Any]:
    detector = build(method, clip_contamination(prevalence), seed)
    fit = capped(train, method, seed)
    result = detect(test, detector, fit_df=fit)
    scores = result.scores.to_numpy()
    flags = result.flags.to_numpy()
    row: dict[str, Any] = {
        "seed": seed,
        "metrics": compute_metrics(y, flags, scores),
        "fit_s": result.fit_s,
        "predict_s": result.predict_s,
        "score_s": result.score_s,
        "fit_rows": int(len(fit)),
    }
    kept = fit_scores(detector, fit)
    if kept is None:
        row["fixed"] = row["metrics"]  # a rule does not read the contamination
        row["fixed_is_same"] = True
    else:
        row["fixed"] = compute_metrics(y, flags_at(kept, scores, FIXED), scores)
        if method == SWEEP_METHOD:
            row["sweep"] = {
                str(c): compute_metrics(y, flags_at(kept, c), scores) for c in GRID
            }
    if seed == CURVE_SEED:
        row["curve"] = _curve(y, scores)
    return row


def x_run_method__mutmut_91(
    method: str,
    train: pd.DataFrame,
    test: pd.DataFrame,
    y: np.ndarray,
    seed: int,
    prevalence: float,
) -> dict[str, Any]:
    detector = build(method, clip_contamination(prevalence), seed)
    fit = capped(train, method, seed)
    result = detect(test, detector, fit_df=fit)
    scores = result.scores.to_numpy()
    flags = result.flags.to_numpy()
    row: dict[str, Any] = {
        "seed": seed,
        "metrics": compute_metrics(y, flags, scores),
        "fit_s": result.fit_s,
        "predict_s": result.predict_s,
        "score_s": result.score_s,
        "fit_rows": int(len(fit)),
    }
    kept = fit_scores(detector, fit)
    if kept is None:
        row["fixed"] = row["metrics"]  # a rule does not read the contamination
        row["fixed_is_same"] = True
    else:
        row["fixed"] = compute_metrics(y, flags_at(kept, scores, FIXED), scores)
        if method == SWEEP_METHOD:
            row["sweep"] = {
                str(c): compute_metrics(y, flags_at(kept, scores, ), scores) for c in GRID
            }
    if seed == CURVE_SEED:
        row["curve"] = _curve(y, scores)
    return row


def x_run_method__mutmut_92(
    method: str,
    train: pd.DataFrame,
    test: pd.DataFrame,
    y: np.ndarray,
    seed: int,
    prevalence: float,
) -> dict[str, Any]:
    detector = build(method, clip_contamination(prevalence), seed)
    fit = capped(train, method, seed)
    result = detect(test, detector, fit_df=fit)
    scores = result.scores.to_numpy()
    flags = result.flags.to_numpy()
    row: dict[str, Any] = {
        "seed": seed,
        "metrics": compute_metrics(y, flags, scores),
        "fit_s": result.fit_s,
        "predict_s": result.predict_s,
        "score_s": result.score_s,
        "fit_rows": int(len(fit)),
    }
    kept = fit_scores(detector, fit)
    if kept is None:
        row["fixed"] = row["metrics"]  # a rule does not read the contamination
        row["fixed_is_same"] = True
    else:
        row["fixed"] = compute_metrics(y, flags_at(kept, scores, FIXED), scores)
        if method == SWEEP_METHOD:
            row["sweep"] = {
                str(c): compute_metrics(y, flags_at(kept, scores, c), scores) for c in GRID
            }
    if seed != CURVE_SEED:
        row["curve"] = _curve(y, scores)
    return row


def x_run_method__mutmut_93(
    method: str,
    train: pd.DataFrame,
    test: pd.DataFrame,
    y: np.ndarray,
    seed: int,
    prevalence: float,
) -> dict[str, Any]:
    detector = build(method, clip_contamination(prevalence), seed)
    fit = capped(train, method, seed)
    result = detect(test, detector, fit_df=fit)
    scores = result.scores.to_numpy()
    flags = result.flags.to_numpy()
    row: dict[str, Any] = {
        "seed": seed,
        "metrics": compute_metrics(y, flags, scores),
        "fit_s": result.fit_s,
        "predict_s": result.predict_s,
        "score_s": result.score_s,
        "fit_rows": int(len(fit)),
    }
    kept = fit_scores(detector, fit)
    if kept is None:
        row["fixed"] = row["metrics"]  # a rule does not read the contamination
        row["fixed_is_same"] = True
    else:
        row["fixed"] = compute_metrics(y, flags_at(kept, scores, FIXED), scores)
        if method == SWEEP_METHOD:
            row["sweep"] = {
                str(c): compute_metrics(y, flags_at(kept, scores, c), scores) for c in GRID
            }
    if seed == CURVE_SEED:
        row["curve"] = None
    return row


def x_run_method__mutmut_94(
    method: str,
    train: pd.DataFrame,
    test: pd.DataFrame,
    y: np.ndarray,
    seed: int,
    prevalence: float,
) -> dict[str, Any]:
    detector = build(method, clip_contamination(prevalence), seed)
    fit = capped(train, method, seed)
    result = detect(test, detector, fit_df=fit)
    scores = result.scores.to_numpy()
    flags = result.flags.to_numpy()
    row: dict[str, Any] = {
        "seed": seed,
        "metrics": compute_metrics(y, flags, scores),
        "fit_s": result.fit_s,
        "predict_s": result.predict_s,
        "score_s": result.score_s,
        "fit_rows": int(len(fit)),
    }
    kept = fit_scores(detector, fit)
    if kept is None:
        row["fixed"] = row["metrics"]  # a rule does not read the contamination
        row["fixed_is_same"] = True
    else:
        row["fixed"] = compute_metrics(y, flags_at(kept, scores, FIXED), scores)
        if method == SWEEP_METHOD:
            row["sweep"] = {
                str(c): compute_metrics(y, flags_at(kept, scores, c), scores) for c in GRID
            }
    if seed == CURVE_SEED:
        row["XXcurveXX"] = _curve(y, scores)
    return row


def x_run_method__mutmut_95(
    method: str,
    train: pd.DataFrame,
    test: pd.DataFrame,
    y: np.ndarray,
    seed: int,
    prevalence: float,
) -> dict[str, Any]:
    detector = build(method, clip_contamination(prevalence), seed)
    fit = capped(train, method, seed)
    result = detect(test, detector, fit_df=fit)
    scores = result.scores.to_numpy()
    flags = result.flags.to_numpy()
    row: dict[str, Any] = {
        "seed": seed,
        "metrics": compute_metrics(y, flags, scores),
        "fit_s": result.fit_s,
        "predict_s": result.predict_s,
        "score_s": result.score_s,
        "fit_rows": int(len(fit)),
    }
    kept = fit_scores(detector, fit)
    if kept is None:
        row["fixed"] = row["metrics"]  # a rule does not read the contamination
        row["fixed_is_same"] = True
    else:
        row["fixed"] = compute_metrics(y, flags_at(kept, scores, FIXED), scores)
        if method == SWEEP_METHOD:
            row["sweep"] = {
                str(c): compute_metrics(y, flags_at(kept, scores, c), scores) for c in GRID
            }
    if seed == CURVE_SEED:
        row["CURVE"] = _curve(y, scores)
    return row


def x_run_method__mutmut_96(
    method: str,
    train: pd.DataFrame,
    test: pd.DataFrame,
    y: np.ndarray,
    seed: int,
    prevalence: float,
) -> dict[str, Any]:
    detector = build(method, clip_contamination(prevalence), seed)
    fit = capped(train, method, seed)
    result = detect(test, detector, fit_df=fit)
    scores = result.scores.to_numpy()
    flags = result.flags.to_numpy()
    row: dict[str, Any] = {
        "seed": seed,
        "metrics": compute_metrics(y, flags, scores),
        "fit_s": result.fit_s,
        "predict_s": result.predict_s,
        "score_s": result.score_s,
        "fit_rows": int(len(fit)),
    }
    kept = fit_scores(detector, fit)
    if kept is None:
        row["fixed"] = row["metrics"]  # a rule does not read the contamination
        row["fixed_is_same"] = True
    else:
        row["fixed"] = compute_metrics(y, flags_at(kept, scores, FIXED), scores)
        if method == SWEEP_METHOD:
            row["sweep"] = {
                str(c): compute_metrics(y, flags_at(kept, scores, c), scores) for c in GRID
            }
    if seed == CURVE_SEED:
        row["curve"] = _curve(None, scores)
    return row


def x_run_method__mutmut_97(
    method: str,
    train: pd.DataFrame,
    test: pd.DataFrame,
    y: np.ndarray,
    seed: int,
    prevalence: float,
) -> dict[str, Any]:
    detector = build(method, clip_contamination(prevalence), seed)
    fit = capped(train, method, seed)
    result = detect(test, detector, fit_df=fit)
    scores = result.scores.to_numpy()
    flags = result.flags.to_numpy()
    row: dict[str, Any] = {
        "seed": seed,
        "metrics": compute_metrics(y, flags, scores),
        "fit_s": result.fit_s,
        "predict_s": result.predict_s,
        "score_s": result.score_s,
        "fit_rows": int(len(fit)),
    }
    kept = fit_scores(detector, fit)
    if kept is None:
        row["fixed"] = row["metrics"]  # a rule does not read the contamination
        row["fixed_is_same"] = True
    else:
        row["fixed"] = compute_metrics(y, flags_at(kept, scores, FIXED), scores)
        if method == SWEEP_METHOD:
            row["sweep"] = {
                str(c): compute_metrics(y, flags_at(kept, scores, c), scores) for c in GRID
            }
    if seed == CURVE_SEED:
        row["curve"] = _curve(y, None)
    return row


def x_run_method__mutmut_98(
    method: str,
    train: pd.DataFrame,
    test: pd.DataFrame,
    y: np.ndarray,
    seed: int,
    prevalence: float,
) -> dict[str, Any]:
    detector = build(method, clip_contamination(prevalence), seed)
    fit = capped(train, method, seed)
    result = detect(test, detector, fit_df=fit)
    scores = result.scores.to_numpy()
    flags = result.flags.to_numpy()
    row: dict[str, Any] = {
        "seed": seed,
        "metrics": compute_metrics(y, flags, scores),
        "fit_s": result.fit_s,
        "predict_s": result.predict_s,
        "score_s": result.score_s,
        "fit_rows": int(len(fit)),
    }
    kept = fit_scores(detector, fit)
    if kept is None:
        row["fixed"] = row["metrics"]  # a rule does not read the contamination
        row["fixed_is_same"] = True
    else:
        row["fixed"] = compute_metrics(y, flags_at(kept, scores, FIXED), scores)
        if method == SWEEP_METHOD:
            row["sweep"] = {
                str(c): compute_metrics(y, flags_at(kept, scores, c), scores) for c in GRID
            }
    if seed == CURVE_SEED:
        row["curve"] = _curve(scores)
    return row


def x_run_method__mutmut_99(
    method: str,
    train: pd.DataFrame,
    test: pd.DataFrame,
    y: np.ndarray,
    seed: int,
    prevalence: float,
) -> dict[str, Any]:
    detector = build(method, clip_contamination(prevalence), seed)
    fit = capped(train, method, seed)
    result = detect(test, detector, fit_df=fit)
    scores = result.scores.to_numpy()
    flags = result.flags.to_numpy()
    row: dict[str, Any] = {
        "seed": seed,
        "metrics": compute_metrics(y, flags, scores),
        "fit_s": result.fit_s,
        "predict_s": result.predict_s,
        "score_s": result.score_s,
        "fit_rows": int(len(fit)),
    }
    kept = fit_scores(detector, fit)
    if kept is None:
        row["fixed"] = row["metrics"]  # a rule does not read the contamination
        row["fixed_is_same"] = True
    else:
        row["fixed"] = compute_metrics(y, flags_at(kept, scores, FIXED), scores)
        if method == SWEEP_METHOD:
            row["sweep"] = {
                str(c): compute_metrics(y, flags_at(kept, scores, c), scores) for c in GRID
            }
    if seed == CURVE_SEED:
        row["curve"] = _curve(y, )
    return row

mutants_x_run_method__mutmut['_mutmut_orig'] = x_run_method__mutmut_orig # type: ignore # mutmut generated
mutants_x_run_method__mutmut['x_run_method__mutmut_1'] = x_run_method__mutmut_1 # type: ignore # mutmut generated
mutants_x_run_method__mutmut['x_run_method__mutmut_2'] = x_run_method__mutmut_2 # type: ignore # mutmut generated
mutants_x_run_method__mutmut['x_run_method__mutmut_3'] = x_run_method__mutmut_3 # type: ignore # mutmut generated
mutants_x_run_method__mutmut['x_run_method__mutmut_4'] = x_run_method__mutmut_4 # type: ignore # mutmut generated
mutants_x_run_method__mutmut['x_run_method__mutmut_5'] = x_run_method__mutmut_5 # type: ignore # mutmut generated
mutants_x_run_method__mutmut['x_run_method__mutmut_6'] = x_run_method__mutmut_6 # type: ignore # mutmut generated
mutants_x_run_method__mutmut['x_run_method__mutmut_7'] = x_run_method__mutmut_7 # type: ignore # mutmut generated
mutants_x_run_method__mutmut['x_run_method__mutmut_8'] = x_run_method__mutmut_8 # type: ignore # mutmut generated
mutants_x_run_method__mutmut['x_run_method__mutmut_9'] = x_run_method__mutmut_9 # type: ignore # mutmut generated
mutants_x_run_method__mutmut['x_run_method__mutmut_10'] = x_run_method__mutmut_10 # type: ignore # mutmut generated
mutants_x_run_method__mutmut['x_run_method__mutmut_11'] = x_run_method__mutmut_11 # type: ignore # mutmut generated
mutants_x_run_method__mutmut['x_run_method__mutmut_12'] = x_run_method__mutmut_12 # type: ignore # mutmut generated
mutants_x_run_method__mutmut['x_run_method__mutmut_13'] = x_run_method__mutmut_13 # type: ignore # mutmut generated
mutants_x_run_method__mutmut['x_run_method__mutmut_14'] = x_run_method__mutmut_14 # type: ignore # mutmut generated
mutants_x_run_method__mutmut['x_run_method__mutmut_15'] = x_run_method__mutmut_15 # type: ignore # mutmut generated
mutants_x_run_method__mutmut['x_run_method__mutmut_16'] = x_run_method__mutmut_16 # type: ignore # mutmut generated
mutants_x_run_method__mutmut['x_run_method__mutmut_17'] = x_run_method__mutmut_17 # type: ignore # mutmut generated
mutants_x_run_method__mutmut['x_run_method__mutmut_18'] = x_run_method__mutmut_18 # type: ignore # mutmut generated
mutants_x_run_method__mutmut['x_run_method__mutmut_19'] = x_run_method__mutmut_19 # type: ignore # mutmut generated
mutants_x_run_method__mutmut['x_run_method__mutmut_20'] = x_run_method__mutmut_20 # type: ignore # mutmut generated
mutants_x_run_method__mutmut['x_run_method__mutmut_21'] = x_run_method__mutmut_21 # type: ignore # mutmut generated
mutants_x_run_method__mutmut['x_run_method__mutmut_22'] = x_run_method__mutmut_22 # type: ignore # mutmut generated
mutants_x_run_method__mutmut['x_run_method__mutmut_23'] = x_run_method__mutmut_23 # type: ignore # mutmut generated
mutants_x_run_method__mutmut['x_run_method__mutmut_24'] = x_run_method__mutmut_24 # type: ignore # mutmut generated
mutants_x_run_method__mutmut['x_run_method__mutmut_25'] = x_run_method__mutmut_25 # type: ignore # mutmut generated
mutants_x_run_method__mutmut['x_run_method__mutmut_26'] = x_run_method__mutmut_26 # type: ignore # mutmut generated
mutants_x_run_method__mutmut['x_run_method__mutmut_27'] = x_run_method__mutmut_27 # type: ignore # mutmut generated
mutants_x_run_method__mutmut['x_run_method__mutmut_28'] = x_run_method__mutmut_28 # type: ignore # mutmut generated
mutants_x_run_method__mutmut['x_run_method__mutmut_29'] = x_run_method__mutmut_29 # type: ignore # mutmut generated
mutants_x_run_method__mutmut['x_run_method__mutmut_30'] = x_run_method__mutmut_30 # type: ignore # mutmut generated
mutants_x_run_method__mutmut['x_run_method__mutmut_31'] = x_run_method__mutmut_31 # type: ignore # mutmut generated
mutants_x_run_method__mutmut['x_run_method__mutmut_32'] = x_run_method__mutmut_32 # type: ignore # mutmut generated
mutants_x_run_method__mutmut['x_run_method__mutmut_33'] = x_run_method__mutmut_33 # type: ignore # mutmut generated
mutants_x_run_method__mutmut['x_run_method__mutmut_34'] = x_run_method__mutmut_34 # type: ignore # mutmut generated
mutants_x_run_method__mutmut['x_run_method__mutmut_35'] = x_run_method__mutmut_35 # type: ignore # mutmut generated
mutants_x_run_method__mutmut['x_run_method__mutmut_36'] = x_run_method__mutmut_36 # type: ignore # mutmut generated
mutants_x_run_method__mutmut['x_run_method__mutmut_37'] = x_run_method__mutmut_37 # type: ignore # mutmut generated
mutants_x_run_method__mutmut['x_run_method__mutmut_38'] = x_run_method__mutmut_38 # type: ignore # mutmut generated
mutants_x_run_method__mutmut['x_run_method__mutmut_39'] = x_run_method__mutmut_39 # type: ignore # mutmut generated
mutants_x_run_method__mutmut['x_run_method__mutmut_40'] = x_run_method__mutmut_40 # type: ignore # mutmut generated
mutants_x_run_method__mutmut['x_run_method__mutmut_41'] = x_run_method__mutmut_41 # type: ignore # mutmut generated
mutants_x_run_method__mutmut['x_run_method__mutmut_42'] = x_run_method__mutmut_42 # type: ignore # mutmut generated
mutants_x_run_method__mutmut['x_run_method__mutmut_43'] = x_run_method__mutmut_43 # type: ignore # mutmut generated
mutants_x_run_method__mutmut['x_run_method__mutmut_44'] = x_run_method__mutmut_44 # type: ignore # mutmut generated
mutants_x_run_method__mutmut['x_run_method__mutmut_45'] = x_run_method__mutmut_45 # type: ignore # mutmut generated
mutants_x_run_method__mutmut['x_run_method__mutmut_46'] = x_run_method__mutmut_46 # type: ignore # mutmut generated
mutants_x_run_method__mutmut['x_run_method__mutmut_47'] = x_run_method__mutmut_47 # type: ignore # mutmut generated
mutants_x_run_method__mutmut['x_run_method__mutmut_48'] = x_run_method__mutmut_48 # type: ignore # mutmut generated
mutants_x_run_method__mutmut['x_run_method__mutmut_49'] = x_run_method__mutmut_49 # type: ignore # mutmut generated
mutants_x_run_method__mutmut['x_run_method__mutmut_50'] = x_run_method__mutmut_50 # type: ignore # mutmut generated
mutants_x_run_method__mutmut['x_run_method__mutmut_51'] = x_run_method__mutmut_51 # type: ignore # mutmut generated
mutants_x_run_method__mutmut['x_run_method__mutmut_52'] = x_run_method__mutmut_52 # type: ignore # mutmut generated
mutants_x_run_method__mutmut['x_run_method__mutmut_53'] = x_run_method__mutmut_53 # type: ignore # mutmut generated
mutants_x_run_method__mutmut['x_run_method__mutmut_54'] = x_run_method__mutmut_54 # type: ignore # mutmut generated
mutants_x_run_method__mutmut['x_run_method__mutmut_55'] = x_run_method__mutmut_55 # type: ignore # mutmut generated
mutants_x_run_method__mutmut['x_run_method__mutmut_56'] = x_run_method__mutmut_56 # type: ignore # mutmut generated
mutants_x_run_method__mutmut['x_run_method__mutmut_57'] = x_run_method__mutmut_57 # type: ignore # mutmut generated
mutants_x_run_method__mutmut['x_run_method__mutmut_58'] = x_run_method__mutmut_58 # type: ignore # mutmut generated
mutants_x_run_method__mutmut['x_run_method__mutmut_59'] = x_run_method__mutmut_59 # type: ignore # mutmut generated
mutants_x_run_method__mutmut['x_run_method__mutmut_60'] = x_run_method__mutmut_60 # type: ignore # mutmut generated
mutants_x_run_method__mutmut['x_run_method__mutmut_61'] = x_run_method__mutmut_61 # type: ignore # mutmut generated
mutants_x_run_method__mutmut['x_run_method__mutmut_62'] = x_run_method__mutmut_62 # type: ignore # mutmut generated
mutants_x_run_method__mutmut['x_run_method__mutmut_63'] = x_run_method__mutmut_63 # type: ignore # mutmut generated
mutants_x_run_method__mutmut['x_run_method__mutmut_64'] = x_run_method__mutmut_64 # type: ignore # mutmut generated
mutants_x_run_method__mutmut['x_run_method__mutmut_65'] = x_run_method__mutmut_65 # type: ignore # mutmut generated
mutants_x_run_method__mutmut['x_run_method__mutmut_66'] = x_run_method__mutmut_66 # type: ignore # mutmut generated
mutants_x_run_method__mutmut['x_run_method__mutmut_67'] = x_run_method__mutmut_67 # type: ignore # mutmut generated
mutants_x_run_method__mutmut['x_run_method__mutmut_68'] = x_run_method__mutmut_68 # type: ignore # mutmut generated
mutants_x_run_method__mutmut['x_run_method__mutmut_69'] = x_run_method__mutmut_69 # type: ignore # mutmut generated
mutants_x_run_method__mutmut['x_run_method__mutmut_70'] = x_run_method__mutmut_70 # type: ignore # mutmut generated
mutants_x_run_method__mutmut['x_run_method__mutmut_71'] = x_run_method__mutmut_71 # type: ignore # mutmut generated
mutants_x_run_method__mutmut['x_run_method__mutmut_72'] = x_run_method__mutmut_72 # type: ignore # mutmut generated
mutants_x_run_method__mutmut['x_run_method__mutmut_73'] = x_run_method__mutmut_73 # type: ignore # mutmut generated
mutants_x_run_method__mutmut['x_run_method__mutmut_74'] = x_run_method__mutmut_74 # type: ignore # mutmut generated
mutants_x_run_method__mutmut['x_run_method__mutmut_75'] = x_run_method__mutmut_75 # type: ignore # mutmut generated
mutants_x_run_method__mutmut['x_run_method__mutmut_76'] = x_run_method__mutmut_76 # type: ignore # mutmut generated
mutants_x_run_method__mutmut['x_run_method__mutmut_77'] = x_run_method__mutmut_77 # type: ignore # mutmut generated
mutants_x_run_method__mutmut['x_run_method__mutmut_78'] = x_run_method__mutmut_78 # type: ignore # mutmut generated
mutants_x_run_method__mutmut['x_run_method__mutmut_79'] = x_run_method__mutmut_79 # type: ignore # mutmut generated
mutants_x_run_method__mutmut['x_run_method__mutmut_80'] = x_run_method__mutmut_80 # type: ignore # mutmut generated
mutants_x_run_method__mutmut['x_run_method__mutmut_81'] = x_run_method__mutmut_81 # type: ignore # mutmut generated
mutants_x_run_method__mutmut['x_run_method__mutmut_82'] = x_run_method__mutmut_82 # type: ignore # mutmut generated
mutants_x_run_method__mutmut['x_run_method__mutmut_83'] = x_run_method__mutmut_83 # type: ignore # mutmut generated
mutants_x_run_method__mutmut['x_run_method__mutmut_84'] = x_run_method__mutmut_84 # type: ignore # mutmut generated
mutants_x_run_method__mutmut['x_run_method__mutmut_85'] = x_run_method__mutmut_85 # type: ignore # mutmut generated
mutants_x_run_method__mutmut['x_run_method__mutmut_86'] = x_run_method__mutmut_86 # type: ignore # mutmut generated
mutants_x_run_method__mutmut['x_run_method__mutmut_87'] = x_run_method__mutmut_87 # type: ignore # mutmut generated
mutants_x_run_method__mutmut['x_run_method__mutmut_88'] = x_run_method__mutmut_88 # type: ignore # mutmut generated
mutants_x_run_method__mutmut['x_run_method__mutmut_89'] = x_run_method__mutmut_89 # type: ignore # mutmut generated
mutants_x_run_method__mutmut['x_run_method__mutmut_90'] = x_run_method__mutmut_90 # type: ignore # mutmut generated
mutants_x_run_method__mutmut['x_run_method__mutmut_91'] = x_run_method__mutmut_91 # type: ignore # mutmut generated
mutants_x_run_method__mutmut['x_run_method__mutmut_92'] = x_run_method__mutmut_92 # type: ignore # mutmut generated
mutants_x_run_method__mutmut['x_run_method__mutmut_93'] = x_run_method__mutmut_93 # type: ignore # mutmut generated
mutants_x_run_method__mutmut['x_run_method__mutmut_94'] = x_run_method__mutmut_94 # type: ignore # mutmut generated
mutants_x_run_method__mutmut['x_run_method__mutmut_95'] = x_run_method__mutmut_95 # type: ignore # mutmut generated
mutants_x_run_method__mutmut['x_run_method__mutmut_96'] = x_run_method__mutmut_96 # type: ignore # mutmut generated
mutants_x_run_method__mutmut['x_run_method__mutmut_97'] = x_run_method__mutmut_97 # type: ignore # mutmut generated
mutants_x_run_method__mutmut['x_run_method__mutmut_98'] = x_run_method__mutmut_98 # type: ignore # mutmut generated
mutants_x_run_method__mutmut['x_run_method__mutmut_99'] = x_run_method__mutmut_99 # type: ignore # mutmut generated
mutants_x_run_problem__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_run_problem__mutmut)
def run_problem(
    x: np.ndarray,
    y: np.ndarray,
    seeds: tuple[int, ...] = config.BENCHMARK_SEEDS,
    methods: list[str] | None = None,
) -> dict[str, Any]:
    methods = methods or list(DETECTOR_NAMES)
    unknown = [m for m in methods if m not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    runs: dict[str, list[dict[str, Any]]] = {}
    errors: dict[str, list[dict[str, Any]]] = {}
    skipped: list[str] = []
    for seed in seeds:
        part = nm.split(x, y, seed)
        names = [f"f{i}" for i in range(x.shape[1])]
        train = pd.DataFrame(part["x_train"], columns=names)
        test = pd.DataFrame(part["x_test"], columns=names)
        prevalence = float(part["y_train"].mean())
        skip = nm.skipped_detectors(len(train))
        skipped = [m for m in methods if m in skip]
        for method in methods:
            if method in skip:
                continue
            try:
                row = run_method(method, train, test, part["y_test"], seed, prevalence)
            except Exception as error:  # a failing model is recorded, not hidden
                errors.setdefault(method, []).append({"seed": seed, "error": repr(error)})
                continue
            runs.setdefault(method, []).append(row)
    return {"seeds": list(seeds), "runs": runs, "skipped": skipped, "errors": errors}


def x_run_problem__mutmut_orig(
    x: np.ndarray,
    y: np.ndarray,
    seeds: tuple[int, ...] = config.BENCHMARK_SEEDS,
    methods: list[str] | None = None,
) -> dict[str, Any]:
    methods = methods or list(DETECTOR_NAMES)
    unknown = [m for m in methods if m not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    runs: dict[str, list[dict[str, Any]]] = {}
    errors: dict[str, list[dict[str, Any]]] = {}
    skipped: list[str] = []
    for seed in seeds:
        part = nm.split(x, y, seed)
        names = [f"f{i}" for i in range(x.shape[1])]
        train = pd.DataFrame(part["x_train"], columns=names)
        test = pd.DataFrame(part["x_test"], columns=names)
        prevalence = float(part["y_train"].mean())
        skip = nm.skipped_detectors(len(train))
        skipped = [m for m in methods if m in skip]
        for method in methods:
            if method in skip:
                continue
            try:
                row = run_method(method, train, test, part["y_test"], seed, prevalence)
            except Exception as error:  # a failing model is recorded, not hidden
                errors.setdefault(method, []).append({"seed": seed, "error": repr(error)})
                continue
            runs.setdefault(method, []).append(row)
    return {"seeds": list(seeds), "runs": runs, "skipped": skipped, "errors": errors}


def x_run_problem__mutmut_1(
    x: np.ndarray,
    y: np.ndarray,
    seeds: tuple[int, ...] = config.BENCHMARK_SEEDS,
    methods: list[str] | None = None,
) -> dict[str, Any]:
    methods = None
    unknown = [m for m in methods if m not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    runs: dict[str, list[dict[str, Any]]] = {}
    errors: dict[str, list[dict[str, Any]]] = {}
    skipped: list[str] = []
    for seed in seeds:
        part = nm.split(x, y, seed)
        names = [f"f{i}" for i in range(x.shape[1])]
        train = pd.DataFrame(part["x_train"], columns=names)
        test = pd.DataFrame(part["x_test"], columns=names)
        prevalence = float(part["y_train"].mean())
        skip = nm.skipped_detectors(len(train))
        skipped = [m for m in methods if m in skip]
        for method in methods:
            if method in skip:
                continue
            try:
                row = run_method(method, train, test, part["y_test"], seed, prevalence)
            except Exception as error:  # a failing model is recorded, not hidden
                errors.setdefault(method, []).append({"seed": seed, "error": repr(error)})
                continue
            runs.setdefault(method, []).append(row)
    return {"seeds": list(seeds), "runs": runs, "skipped": skipped, "errors": errors}


def x_run_problem__mutmut_2(
    x: np.ndarray,
    y: np.ndarray,
    seeds: tuple[int, ...] = config.BENCHMARK_SEEDS,
    methods: list[str] | None = None,
) -> dict[str, Any]:
    methods = methods and list(DETECTOR_NAMES)
    unknown = [m for m in methods if m not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    runs: dict[str, list[dict[str, Any]]] = {}
    errors: dict[str, list[dict[str, Any]]] = {}
    skipped: list[str] = []
    for seed in seeds:
        part = nm.split(x, y, seed)
        names = [f"f{i}" for i in range(x.shape[1])]
        train = pd.DataFrame(part["x_train"], columns=names)
        test = pd.DataFrame(part["x_test"], columns=names)
        prevalence = float(part["y_train"].mean())
        skip = nm.skipped_detectors(len(train))
        skipped = [m for m in methods if m in skip]
        for method in methods:
            if method in skip:
                continue
            try:
                row = run_method(method, train, test, part["y_test"], seed, prevalence)
            except Exception as error:  # a failing model is recorded, not hidden
                errors.setdefault(method, []).append({"seed": seed, "error": repr(error)})
                continue
            runs.setdefault(method, []).append(row)
    return {"seeds": list(seeds), "runs": runs, "skipped": skipped, "errors": errors}


def x_run_problem__mutmut_3(
    x: np.ndarray,
    y: np.ndarray,
    seeds: tuple[int, ...] = config.BENCHMARK_SEEDS,
    methods: list[str] | None = None,
) -> dict[str, Any]:
    methods = methods or list(None)
    unknown = [m for m in methods if m not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    runs: dict[str, list[dict[str, Any]]] = {}
    errors: dict[str, list[dict[str, Any]]] = {}
    skipped: list[str] = []
    for seed in seeds:
        part = nm.split(x, y, seed)
        names = [f"f{i}" for i in range(x.shape[1])]
        train = pd.DataFrame(part["x_train"], columns=names)
        test = pd.DataFrame(part["x_test"], columns=names)
        prevalence = float(part["y_train"].mean())
        skip = nm.skipped_detectors(len(train))
        skipped = [m for m in methods if m in skip]
        for method in methods:
            if method in skip:
                continue
            try:
                row = run_method(method, train, test, part["y_test"], seed, prevalence)
            except Exception as error:  # a failing model is recorded, not hidden
                errors.setdefault(method, []).append({"seed": seed, "error": repr(error)})
                continue
            runs.setdefault(method, []).append(row)
    return {"seeds": list(seeds), "runs": runs, "skipped": skipped, "errors": errors}


def x_run_problem__mutmut_4(
    x: np.ndarray,
    y: np.ndarray,
    seeds: tuple[int, ...] = config.BENCHMARK_SEEDS,
    methods: list[str] | None = None,
) -> dict[str, Any]:
    methods = methods or list(DETECTOR_NAMES)
    unknown = None
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    runs: dict[str, list[dict[str, Any]]] = {}
    errors: dict[str, list[dict[str, Any]]] = {}
    skipped: list[str] = []
    for seed in seeds:
        part = nm.split(x, y, seed)
        names = [f"f{i}" for i in range(x.shape[1])]
        train = pd.DataFrame(part["x_train"], columns=names)
        test = pd.DataFrame(part["x_test"], columns=names)
        prevalence = float(part["y_train"].mean())
        skip = nm.skipped_detectors(len(train))
        skipped = [m for m in methods if m in skip]
        for method in methods:
            if method in skip:
                continue
            try:
                row = run_method(method, train, test, part["y_test"], seed, prevalence)
            except Exception as error:  # a failing model is recorded, not hidden
                errors.setdefault(method, []).append({"seed": seed, "error": repr(error)})
                continue
            runs.setdefault(method, []).append(row)
    return {"seeds": list(seeds), "runs": runs, "skipped": skipped, "errors": errors}


def x_run_problem__mutmut_5(
    x: np.ndarray,
    y: np.ndarray,
    seeds: tuple[int, ...] = config.BENCHMARK_SEEDS,
    methods: list[str] | None = None,
) -> dict[str, Any]:
    methods = methods or list(DETECTOR_NAMES)
    unknown = [m for m in methods if m in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    runs: dict[str, list[dict[str, Any]]] = {}
    errors: dict[str, list[dict[str, Any]]] = {}
    skipped: list[str] = []
    for seed in seeds:
        part = nm.split(x, y, seed)
        names = [f"f{i}" for i in range(x.shape[1])]
        train = pd.DataFrame(part["x_train"], columns=names)
        test = pd.DataFrame(part["x_test"], columns=names)
        prevalence = float(part["y_train"].mean())
        skip = nm.skipped_detectors(len(train))
        skipped = [m for m in methods if m in skip]
        for method in methods:
            if method in skip:
                continue
            try:
                row = run_method(method, train, test, part["y_test"], seed, prevalence)
            except Exception as error:  # a failing model is recorded, not hidden
                errors.setdefault(method, []).append({"seed": seed, "error": repr(error)})
                continue
            runs.setdefault(method, []).append(row)
    return {"seeds": list(seeds), "runs": runs, "skipped": skipped, "errors": errors}


def x_run_problem__mutmut_6(
    x: np.ndarray,
    y: np.ndarray,
    seeds: tuple[int, ...] = config.BENCHMARK_SEEDS,
    methods: list[str] | None = None,
) -> dict[str, Any]:
    methods = methods or list(DETECTOR_NAMES)
    unknown = [m for m in methods if m not in KNOWN]
    if unknown:
        raise ValueError(None)
    runs: dict[str, list[dict[str, Any]]] = {}
    errors: dict[str, list[dict[str, Any]]] = {}
    skipped: list[str] = []
    for seed in seeds:
        part = nm.split(x, y, seed)
        names = [f"f{i}" for i in range(x.shape[1])]
        train = pd.DataFrame(part["x_train"], columns=names)
        test = pd.DataFrame(part["x_test"], columns=names)
        prevalence = float(part["y_train"].mean())
        skip = nm.skipped_detectors(len(train))
        skipped = [m for m in methods if m in skip]
        for method in methods:
            if method in skip:
                continue
            try:
                row = run_method(method, train, test, part["y_test"], seed, prevalence)
            except Exception as error:  # a failing model is recorded, not hidden
                errors.setdefault(method, []).append({"seed": seed, "error": repr(error)})
                continue
            runs.setdefault(method, []).append(row)
    return {"seeds": list(seeds), "runs": runs, "skipped": skipped, "errors": errors}


def x_run_problem__mutmut_7(
    x: np.ndarray,
    y: np.ndarray,
    seeds: tuple[int, ...] = config.BENCHMARK_SEEDS,
    methods: list[str] | None = None,
) -> dict[str, Any]:
    methods = methods or list(DETECTOR_NAMES)
    unknown = [m for m in methods if m not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    runs: dict[str, list[dict[str, Any]]] = None
    errors: dict[str, list[dict[str, Any]]] = {}
    skipped: list[str] = []
    for seed in seeds:
        part = nm.split(x, y, seed)
        names = [f"f{i}" for i in range(x.shape[1])]
        train = pd.DataFrame(part["x_train"], columns=names)
        test = pd.DataFrame(part["x_test"], columns=names)
        prevalence = float(part["y_train"].mean())
        skip = nm.skipped_detectors(len(train))
        skipped = [m for m in methods if m in skip]
        for method in methods:
            if method in skip:
                continue
            try:
                row = run_method(method, train, test, part["y_test"], seed, prevalence)
            except Exception as error:  # a failing model is recorded, not hidden
                errors.setdefault(method, []).append({"seed": seed, "error": repr(error)})
                continue
            runs.setdefault(method, []).append(row)
    return {"seeds": list(seeds), "runs": runs, "skipped": skipped, "errors": errors}


def x_run_problem__mutmut_8(
    x: np.ndarray,
    y: np.ndarray,
    seeds: tuple[int, ...] = config.BENCHMARK_SEEDS,
    methods: list[str] | None = None,
) -> dict[str, Any]:
    methods = methods or list(DETECTOR_NAMES)
    unknown = [m for m in methods if m not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    runs: dict[str, list[dict[str, Any]]] = {}
    errors: dict[str, list[dict[str, Any]]] = None
    skipped: list[str] = []
    for seed in seeds:
        part = nm.split(x, y, seed)
        names = [f"f{i}" for i in range(x.shape[1])]
        train = pd.DataFrame(part["x_train"], columns=names)
        test = pd.DataFrame(part["x_test"], columns=names)
        prevalence = float(part["y_train"].mean())
        skip = nm.skipped_detectors(len(train))
        skipped = [m for m in methods if m in skip]
        for method in methods:
            if method in skip:
                continue
            try:
                row = run_method(method, train, test, part["y_test"], seed, prevalence)
            except Exception as error:  # a failing model is recorded, not hidden
                errors.setdefault(method, []).append({"seed": seed, "error": repr(error)})
                continue
            runs.setdefault(method, []).append(row)
    return {"seeds": list(seeds), "runs": runs, "skipped": skipped, "errors": errors}


def x_run_problem__mutmut_9(
    x: np.ndarray,
    y: np.ndarray,
    seeds: tuple[int, ...] = config.BENCHMARK_SEEDS,
    methods: list[str] | None = None,
) -> dict[str, Any]:
    methods = methods or list(DETECTOR_NAMES)
    unknown = [m for m in methods if m not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    runs: dict[str, list[dict[str, Any]]] = {}
    errors: dict[str, list[dict[str, Any]]] = {}
    skipped: list[str] = None
    for seed in seeds:
        part = nm.split(x, y, seed)
        names = [f"f{i}" for i in range(x.shape[1])]
        train = pd.DataFrame(part["x_train"], columns=names)
        test = pd.DataFrame(part["x_test"], columns=names)
        prevalence = float(part["y_train"].mean())
        skip = nm.skipped_detectors(len(train))
        skipped = [m for m in methods if m in skip]
        for method in methods:
            if method in skip:
                continue
            try:
                row = run_method(method, train, test, part["y_test"], seed, prevalence)
            except Exception as error:  # a failing model is recorded, not hidden
                errors.setdefault(method, []).append({"seed": seed, "error": repr(error)})
                continue
            runs.setdefault(method, []).append(row)
    return {"seeds": list(seeds), "runs": runs, "skipped": skipped, "errors": errors}


def x_run_problem__mutmut_10(
    x: np.ndarray,
    y: np.ndarray,
    seeds: tuple[int, ...] = config.BENCHMARK_SEEDS,
    methods: list[str] | None = None,
) -> dict[str, Any]:
    methods = methods or list(DETECTOR_NAMES)
    unknown = [m for m in methods if m not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    runs: dict[str, list[dict[str, Any]]] = {}
    errors: dict[str, list[dict[str, Any]]] = {}
    skipped: list[str] = []
    for seed in seeds:
        part = None
        names = [f"f{i}" for i in range(x.shape[1])]
        train = pd.DataFrame(part["x_train"], columns=names)
        test = pd.DataFrame(part["x_test"], columns=names)
        prevalence = float(part["y_train"].mean())
        skip = nm.skipped_detectors(len(train))
        skipped = [m for m in methods if m in skip]
        for method in methods:
            if method in skip:
                continue
            try:
                row = run_method(method, train, test, part["y_test"], seed, prevalence)
            except Exception as error:  # a failing model is recorded, not hidden
                errors.setdefault(method, []).append({"seed": seed, "error": repr(error)})
                continue
            runs.setdefault(method, []).append(row)
    return {"seeds": list(seeds), "runs": runs, "skipped": skipped, "errors": errors}


def x_run_problem__mutmut_11(
    x: np.ndarray,
    y: np.ndarray,
    seeds: tuple[int, ...] = config.BENCHMARK_SEEDS,
    methods: list[str] | None = None,
) -> dict[str, Any]:
    methods = methods or list(DETECTOR_NAMES)
    unknown = [m for m in methods if m not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    runs: dict[str, list[dict[str, Any]]] = {}
    errors: dict[str, list[dict[str, Any]]] = {}
    skipped: list[str] = []
    for seed in seeds:
        part = nm.split(None, y, seed)
        names = [f"f{i}" for i in range(x.shape[1])]
        train = pd.DataFrame(part["x_train"], columns=names)
        test = pd.DataFrame(part["x_test"], columns=names)
        prevalence = float(part["y_train"].mean())
        skip = nm.skipped_detectors(len(train))
        skipped = [m for m in methods if m in skip]
        for method in methods:
            if method in skip:
                continue
            try:
                row = run_method(method, train, test, part["y_test"], seed, prevalence)
            except Exception as error:  # a failing model is recorded, not hidden
                errors.setdefault(method, []).append({"seed": seed, "error": repr(error)})
                continue
            runs.setdefault(method, []).append(row)
    return {"seeds": list(seeds), "runs": runs, "skipped": skipped, "errors": errors}


def x_run_problem__mutmut_12(
    x: np.ndarray,
    y: np.ndarray,
    seeds: tuple[int, ...] = config.BENCHMARK_SEEDS,
    methods: list[str] | None = None,
) -> dict[str, Any]:
    methods = methods or list(DETECTOR_NAMES)
    unknown = [m for m in methods if m not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    runs: dict[str, list[dict[str, Any]]] = {}
    errors: dict[str, list[dict[str, Any]]] = {}
    skipped: list[str] = []
    for seed in seeds:
        part = nm.split(x, None, seed)
        names = [f"f{i}" for i in range(x.shape[1])]
        train = pd.DataFrame(part["x_train"], columns=names)
        test = pd.DataFrame(part["x_test"], columns=names)
        prevalence = float(part["y_train"].mean())
        skip = nm.skipped_detectors(len(train))
        skipped = [m for m in methods if m in skip]
        for method in methods:
            if method in skip:
                continue
            try:
                row = run_method(method, train, test, part["y_test"], seed, prevalence)
            except Exception as error:  # a failing model is recorded, not hidden
                errors.setdefault(method, []).append({"seed": seed, "error": repr(error)})
                continue
            runs.setdefault(method, []).append(row)
    return {"seeds": list(seeds), "runs": runs, "skipped": skipped, "errors": errors}


def x_run_problem__mutmut_13(
    x: np.ndarray,
    y: np.ndarray,
    seeds: tuple[int, ...] = config.BENCHMARK_SEEDS,
    methods: list[str] | None = None,
) -> dict[str, Any]:
    methods = methods or list(DETECTOR_NAMES)
    unknown = [m for m in methods if m not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    runs: dict[str, list[dict[str, Any]]] = {}
    errors: dict[str, list[dict[str, Any]]] = {}
    skipped: list[str] = []
    for seed in seeds:
        part = nm.split(x, y, None)
        names = [f"f{i}" for i in range(x.shape[1])]
        train = pd.DataFrame(part["x_train"], columns=names)
        test = pd.DataFrame(part["x_test"], columns=names)
        prevalence = float(part["y_train"].mean())
        skip = nm.skipped_detectors(len(train))
        skipped = [m for m in methods if m in skip]
        for method in methods:
            if method in skip:
                continue
            try:
                row = run_method(method, train, test, part["y_test"], seed, prevalence)
            except Exception as error:  # a failing model is recorded, not hidden
                errors.setdefault(method, []).append({"seed": seed, "error": repr(error)})
                continue
            runs.setdefault(method, []).append(row)
    return {"seeds": list(seeds), "runs": runs, "skipped": skipped, "errors": errors}


def x_run_problem__mutmut_14(
    x: np.ndarray,
    y: np.ndarray,
    seeds: tuple[int, ...] = config.BENCHMARK_SEEDS,
    methods: list[str] | None = None,
) -> dict[str, Any]:
    methods = methods or list(DETECTOR_NAMES)
    unknown = [m for m in methods if m not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    runs: dict[str, list[dict[str, Any]]] = {}
    errors: dict[str, list[dict[str, Any]]] = {}
    skipped: list[str] = []
    for seed in seeds:
        part = nm.split(y, seed)
        names = [f"f{i}" for i in range(x.shape[1])]
        train = pd.DataFrame(part["x_train"], columns=names)
        test = pd.DataFrame(part["x_test"], columns=names)
        prevalence = float(part["y_train"].mean())
        skip = nm.skipped_detectors(len(train))
        skipped = [m for m in methods if m in skip]
        for method in methods:
            if method in skip:
                continue
            try:
                row = run_method(method, train, test, part["y_test"], seed, prevalence)
            except Exception as error:  # a failing model is recorded, not hidden
                errors.setdefault(method, []).append({"seed": seed, "error": repr(error)})
                continue
            runs.setdefault(method, []).append(row)
    return {"seeds": list(seeds), "runs": runs, "skipped": skipped, "errors": errors}


def x_run_problem__mutmut_15(
    x: np.ndarray,
    y: np.ndarray,
    seeds: tuple[int, ...] = config.BENCHMARK_SEEDS,
    methods: list[str] | None = None,
) -> dict[str, Any]:
    methods = methods or list(DETECTOR_NAMES)
    unknown = [m for m in methods if m not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    runs: dict[str, list[dict[str, Any]]] = {}
    errors: dict[str, list[dict[str, Any]]] = {}
    skipped: list[str] = []
    for seed in seeds:
        part = nm.split(x, seed)
        names = [f"f{i}" for i in range(x.shape[1])]
        train = pd.DataFrame(part["x_train"], columns=names)
        test = pd.DataFrame(part["x_test"], columns=names)
        prevalence = float(part["y_train"].mean())
        skip = nm.skipped_detectors(len(train))
        skipped = [m for m in methods if m in skip]
        for method in methods:
            if method in skip:
                continue
            try:
                row = run_method(method, train, test, part["y_test"], seed, prevalence)
            except Exception as error:  # a failing model is recorded, not hidden
                errors.setdefault(method, []).append({"seed": seed, "error": repr(error)})
                continue
            runs.setdefault(method, []).append(row)
    return {"seeds": list(seeds), "runs": runs, "skipped": skipped, "errors": errors}


def x_run_problem__mutmut_16(
    x: np.ndarray,
    y: np.ndarray,
    seeds: tuple[int, ...] = config.BENCHMARK_SEEDS,
    methods: list[str] | None = None,
) -> dict[str, Any]:
    methods = methods or list(DETECTOR_NAMES)
    unknown = [m for m in methods if m not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    runs: dict[str, list[dict[str, Any]]] = {}
    errors: dict[str, list[dict[str, Any]]] = {}
    skipped: list[str] = []
    for seed in seeds:
        part = nm.split(x, y, )
        names = [f"f{i}" for i in range(x.shape[1])]
        train = pd.DataFrame(part["x_train"], columns=names)
        test = pd.DataFrame(part["x_test"], columns=names)
        prevalence = float(part["y_train"].mean())
        skip = nm.skipped_detectors(len(train))
        skipped = [m for m in methods if m in skip]
        for method in methods:
            if method in skip:
                continue
            try:
                row = run_method(method, train, test, part["y_test"], seed, prevalence)
            except Exception as error:  # a failing model is recorded, not hidden
                errors.setdefault(method, []).append({"seed": seed, "error": repr(error)})
                continue
            runs.setdefault(method, []).append(row)
    return {"seeds": list(seeds), "runs": runs, "skipped": skipped, "errors": errors}


def x_run_problem__mutmut_17(
    x: np.ndarray,
    y: np.ndarray,
    seeds: tuple[int, ...] = config.BENCHMARK_SEEDS,
    methods: list[str] | None = None,
) -> dict[str, Any]:
    methods = methods or list(DETECTOR_NAMES)
    unknown = [m for m in methods if m not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    runs: dict[str, list[dict[str, Any]]] = {}
    errors: dict[str, list[dict[str, Any]]] = {}
    skipped: list[str] = []
    for seed in seeds:
        part = nm.split(x, y, seed)
        names = None
        train = pd.DataFrame(part["x_train"], columns=names)
        test = pd.DataFrame(part["x_test"], columns=names)
        prevalence = float(part["y_train"].mean())
        skip = nm.skipped_detectors(len(train))
        skipped = [m for m in methods if m in skip]
        for method in methods:
            if method in skip:
                continue
            try:
                row = run_method(method, train, test, part["y_test"], seed, prevalence)
            except Exception as error:  # a failing model is recorded, not hidden
                errors.setdefault(method, []).append({"seed": seed, "error": repr(error)})
                continue
            runs.setdefault(method, []).append(row)
    return {"seeds": list(seeds), "runs": runs, "skipped": skipped, "errors": errors}


def x_run_problem__mutmut_18(
    x: np.ndarray,
    y: np.ndarray,
    seeds: tuple[int, ...] = config.BENCHMARK_SEEDS,
    methods: list[str] | None = None,
) -> dict[str, Any]:
    methods = methods or list(DETECTOR_NAMES)
    unknown = [m for m in methods if m not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    runs: dict[str, list[dict[str, Any]]] = {}
    errors: dict[str, list[dict[str, Any]]] = {}
    skipped: list[str] = []
    for seed in seeds:
        part = nm.split(x, y, seed)
        names = [f"f{i}" for i in range(None)]
        train = pd.DataFrame(part["x_train"], columns=names)
        test = pd.DataFrame(part["x_test"], columns=names)
        prevalence = float(part["y_train"].mean())
        skip = nm.skipped_detectors(len(train))
        skipped = [m for m in methods if m in skip]
        for method in methods:
            if method in skip:
                continue
            try:
                row = run_method(method, train, test, part["y_test"], seed, prevalence)
            except Exception as error:  # a failing model is recorded, not hidden
                errors.setdefault(method, []).append({"seed": seed, "error": repr(error)})
                continue
            runs.setdefault(method, []).append(row)
    return {"seeds": list(seeds), "runs": runs, "skipped": skipped, "errors": errors}


def x_run_problem__mutmut_19(
    x: np.ndarray,
    y: np.ndarray,
    seeds: tuple[int, ...] = config.BENCHMARK_SEEDS,
    methods: list[str] | None = None,
) -> dict[str, Any]:
    methods = methods or list(DETECTOR_NAMES)
    unknown = [m for m in methods if m not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    runs: dict[str, list[dict[str, Any]]] = {}
    errors: dict[str, list[dict[str, Any]]] = {}
    skipped: list[str] = []
    for seed in seeds:
        part = nm.split(x, y, seed)
        names = [f"f{i}" for i in range(x.shape[2])]
        train = pd.DataFrame(part["x_train"], columns=names)
        test = pd.DataFrame(part["x_test"], columns=names)
        prevalence = float(part["y_train"].mean())
        skip = nm.skipped_detectors(len(train))
        skipped = [m for m in methods if m in skip]
        for method in methods:
            if method in skip:
                continue
            try:
                row = run_method(method, train, test, part["y_test"], seed, prevalence)
            except Exception as error:  # a failing model is recorded, not hidden
                errors.setdefault(method, []).append({"seed": seed, "error": repr(error)})
                continue
            runs.setdefault(method, []).append(row)
    return {"seeds": list(seeds), "runs": runs, "skipped": skipped, "errors": errors}


def x_run_problem__mutmut_20(
    x: np.ndarray,
    y: np.ndarray,
    seeds: tuple[int, ...] = config.BENCHMARK_SEEDS,
    methods: list[str] | None = None,
) -> dict[str, Any]:
    methods = methods or list(DETECTOR_NAMES)
    unknown = [m for m in methods if m not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    runs: dict[str, list[dict[str, Any]]] = {}
    errors: dict[str, list[dict[str, Any]]] = {}
    skipped: list[str] = []
    for seed in seeds:
        part = nm.split(x, y, seed)
        names = [f"f{i}" for i in range(x.shape[1])]
        train = None
        test = pd.DataFrame(part["x_test"], columns=names)
        prevalence = float(part["y_train"].mean())
        skip = nm.skipped_detectors(len(train))
        skipped = [m for m in methods if m in skip]
        for method in methods:
            if method in skip:
                continue
            try:
                row = run_method(method, train, test, part["y_test"], seed, prevalence)
            except Exception as error:  # a failing model is recorded, not hidden
                errors.setdefault(method, []).append({"seed": seed, "error": repr(error)})
                continue
            runs.setdefault(method, []).append(row)
    return {"seeds": list(seeds), "runs": runs, "skipped": skipped, "errors": errors}


def x_run_problem__mutmut_21(
    x: np.ndarray,
    y: np.ndarray,
    seeds: tuple[int, ...] = config.BENCHMARK_SEEDS,
    methods: list[str] | None = None,
) -> dict[str, Any]:
    methods = methods or list(DETECTOR_NAMES)
    unknown = [m for m in methods if m not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    runs: dict[str, list[dict[str, Any]]] = {}
    errors: dict[str, list[dict[str, Any]]] = {}
    skipped: list[str] = []
    for seed in seeds:
        part = nm.split(x, y, seed)
        names = [f"f{i}" for i in range(x.shape[1])]
        train = pd.DataFrame(None, columns=names)
        test = pd.DataFrame(part["x_test"], columns=names)
        prevalence = float(part["y_train"].mean())
        skip = nm.skipped_detectors(len(train))
        skipped = [m for m in methods if m in skip]
        for method in methods:
            if method in skip:
                continue
            try:
                row = run_method(method, train, test, part["y_test"], seed, prevalence)
            except Exception as error:  # a failing model is recorded, not hidden
                errors.setdefault(method, []).append({"seed": seed, "error": repr(error)})
                continue
            runs.setdefault(method, []).append(row)
    return {"seeds": list(seeds), "runs": runs, "skipped": skipped, "errors": errors}


def x_run_problem__mutmut_22(
    x: np.ndarray,
    y: np.ndarray,
    seeds: tuple[int, ...] = config.BENCHMARK_SEEDS,
    methods: list[str] | None = None,
) -> dict[str, Any]:
    methods = methods or list(DETECTOR_NAMES)
    unknown = [m for m in methods if m not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    runs: dict[str, list[dict[str, Any]]] = {}
    errors: dict[str, list[dict[str, Any]]] = {}
    skipped: list[str] = []
    for seed in seeds:
        part = nm.split(x, y, seed)
        names = [f"f{i}" for i in range(x.shape[1])]
        train = pd.DataFrame(part["x_train"], columns=None)
        test = pd.DataFrame(part["x_test"], columns=names)
        prevalence = float(part["y_train"].mean())
        skip = nm.skipped_detectors(len(train))
        skipped = [m for m in methods if m in skip]
        for method in methods:
            if method in skip:
                continue
            try:
                row = run_method(method, train, test, part["y_test"], seed, prevalence)
            except Exception as error:  # a failing model is recorded, not hidden
                errors.setdefault(method, []).append({"seed": seed, "error": repr(error)})
                continue
            runs.setdefault(method, []).append(row)
    return {"seeds": list(seeds), "runs": runs, "skipped": skipped, "errors": errors}


def x_run_problem__mutmut_23(
    x: np.ndarray,
    y: np.ndarray,
    seeds: tuple[int, ...] = config.BENCHMARK_SEEDS,
    methods: list[str] | None = None,
) -> dict[str, Any]:
    methods = methods or list(DETECTOR_NAMES)
    unknown = [m for m in methods if m not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    runs: dict[str, list[dict[str, Any]]] = {}
    errors: dict[str, list[dict[str, Any]]] = {}
    skipped: list[str] = []
    for seed in seeds:
        part = nm.split(x, y, seed)
        names = [f"f{i}" for i in range(x.shape[1])]
        train = pd.DataFrame(columns=names)
        test = pd.DataFrame(part["x_test"], columns=names)
        prevalence = float(part["y_train"].mean())
        skip = nm.skipped_detectors(len(train))
        skipped = [m for m in methods if m in skip]
        for method in methods:
            if method in skip:
                continue
            try:
                row = run_method(method, train, test, part["y_test"], seed, prevalence)
            except Exception as error:  # a failing model is recorded, not hidden
                errors.setdefault(method, []).append({"seed": seed, "error": repr(error)})
                continue
            runs.setdefault(method, []).append(row)
    return {"seeds": list(seeds), "runs": runs, "skipped": skipped, "errors": errors}


def x_run_problem__mutmut_24(
    x: np.ndarray,
    y: np.ndarray,
    seeds: tuple[int, ...] = config.BENCHMARK_SEEDS,
    methods: list[str] | None = None,
) -> dict[str, Any]:
    methods = methods or list(DETECTOR_NAMES)
    unknown = [m for m in methods if m not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    runs: dict[str, list[dict[str, Any]]] = {}
    errors: dict[str, list[dict[str, Any]]] = {}
    skipped: list[str] = []
    for seed in seeds:
        part = nm.split(x, y, seed)
        names = [f"f{i}" for i in range(x.shape[1])]
        train = pd.DataFrame(part["x_train"], )
        test = pd.DataFrame(part["x_test"], columns=names)
        prevalence = float(part["y_train"].mean())
        skip = nm.skipped_detectors(len(train))
        skipped = [m for m in methods if m in skip]
        for method in methods:
            if method in skip:
                continue
            try:
                row = run_method(method, train, test, part["y_test"], seed, prevalence)
            except Exception as error:  # a failing model is recorded, not hidden
                errors.setdefault(method, []).append({"seed": seed, "error": repr(error)})
                continue
            runs.setdefault(method, []).append(row)
    return {"seeds": list(seeds), "runs": runs, "skipped": skipped, "errors": errors}


def x_run_problem__mutmut_25(
    x: np.ndarray,
    y: np.ndarray,
    seeds: tuple[int, ...] = config.BENCHMARK_SEEDS,
    methods: list[str] | None = None,
) -> dict[str, Any]:
    methods = methods or list(DETECTOR_NAMES)
    unknown = [m for m in methods if m not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    runs: dict[str, list[dict[str, Any]]] = {}
    errors: dict[str, list[dict[str, Any]]] = {}
    skipped: list[str] = []
    for seed in seeds:
        part = nm.split(x, y, seed)
        names = [f"f{i}" for i in range(x.shape[1])]
        train = pd.DataFrame(part["XXx_trainXX"], columns=names)
        test = pd.DataFrame(part["x_test"], columns=names)
        prevalence = float(part["y_train"].mean())
        skip = nm.skipped_detectors(len(train))
        skipped = [m for m in methods if m in skip]
        for method in methods:
            if method in skip:
                continue
            try:
                row = run_method(method, train, test, part["y_test"], seed, prevalence)
            except Exception as error:  # a failing model is recorded, not hidden
                errors.setdefault(method, []).append({"seed": seed, "error": repr(error)})
                continue
            runs.setdefault(method, []).append(row)
    return {"seeds": list(seeds), "runs": runs, "skipped": skipped, "errors": errors}


def x_run_problem__mutmut_26(
    x: np.ndarray,
    y: np.ndarray,
    seeds: tuple[int, ...] = config.BENCHMARK_SEEDS,
    methods: list[str] | None = None,
) -> dict[str, Any]:
    methods = methods or list(DETECTOR_NAMES)
    unknown = [m for m in methods if m not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    runs: dict[str, list[dict[str, Any]]] = {}
    errors: dict[str, list[dict[str, Any]]] = {}
    skipped: list[str] = []
    for seed in seeds:
        part = nm.split(x, y, seed)
        names = [f"f{i}" for i in range(x.shape[1])]
        train = pd.DataFrame(part["X_TRAIN"], columns=names)
        test = pd.DataFrame(part["x_test"], columns=names)
        prevalence = float(part["y_train"].mean())
        skip = nm.skipped_detectors(len(train))
        skipped = [m for m in methods if m in skip]
        for method in methods:
            if method in skip:
                continue
            try:
                row = run_method(method, train, test, part["y_test"], seed, prevalence)
            except Exception as error:  # a failing model is recorded, not hidden
                errors.setdefault(method, []).append({"seed": seed, "error": repr(error)})
                continue
            runs.setdefault(method, []).append(row)
    return {"seeds": list(seeds), "runs": runs, "skipped": skipped, "errors": errors}


def x_run_problem__mutmut_27(
    x: np.ndarray,
    y: np.ndarray,
    seeds: tuple[int, ...] = config.BENCHMARK_SEEDS,
    methods: list[str] | None = None,
) -> dict[str, Any]:
    methods = methods or list(DETECTOR_NAMES)
    unknown = [m for m in methods if m not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    runs: dict[str, list[dict[str, Any]]] = {}
    errors: dict[str, list[dict[str, Any]]] = {}
    skipped: list[str] = []
    for seed in seeds:
        part = nm.split(x, y, seed)
        names = [f"f{i}" for i in range(x.shape[1])]
        train = pd.DataFrame(part["x_train"], columns=names)
        test = None
        prevalence = float(part["y_train"].mean())
        skip = nm.skipped_detectors(len(train))
        skipped = [m for m in methods if m in skip]
        for method in methods:
            if method in skip:
                continue
            try:
                row = run_method(method, train, test, part["y_test"], seed, prevalence)
            except Exception as error:  # a failing model is recorded, not hidden
                errors.setdefault(method, []).append({"seed": seed, "error": repr(error)})
                continue
            runs.setdefault(method, []).append(row)
    return {"seeds": list(seeds), "runs": runs, "skipped": skipped, "errors": errors}


def x_run_problem__mutmut_28(
    x: np.ndarray,
    y: np.ndarray,
    seeds: tuple[int, ...] = config.BENCHMARK_SEEDS,
    methods: list[str] | None = None,
) -> dict[str, Any]:
    methods = methods or list(DETECTOR_NAMES)
    unknown = [m for m in methods if m not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    runs: dict[str, list[dict[str, Any]]] = {}
    errors: dict[str, list[dict[str, Any]]] = {}
    skipped: list[str] = []
    for seed in seeds:
        part = nm.split(x, y, seed)
        names = [f"f{i}" for i in range(x.shape[1])]
        train = pd.DataFrame(part["x_train"], columns=names)
        test = pd.DataFrame(None, columns=names)
        prevalence = float(part["y_train"].mean())
        skip = nm.skipped_detectors(len(train))
        skipped = [m for m in methods if m in skip]
        for method in methods:
            if method in skip:
                continue
            try:
                row = run_method(method, train, test, part["y_test"], seed, prevalence)
            except Exception as error:  # a failing model is recorded, not hidden
                errors.setdefault(method, []).append({"seed": seed, "error": repr(error)})
                continue
            runs.setdefault(method, []).append(row)
    return {"seeds": list(seeds), "runs": runs, "skipped": skipped, "errors": errors}


def x_run_problem__mutmut_29(
    x: np.ndarray,
    y: np.ndarray,
    seeds: tuple[int, ...] = config.BENCHMARK_SEEDS,
    methods: list[str] | None = None,
) -> dict[str, Any]:
    methods = methods or list(DETECTOR_NAMES)
    unknown = [m for m in methods if m not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    runs: dict[str, list[dict[str, Any]]] = {}
    errors: dict[str, list[dict[str, Any]]] = {}
    skipped: list[str] = []
    for seed in seeds:
        part = nm.split(x, y, seed)
        names = [f"f{i}" for i in range(x.shape[1])]
        train = pd.DataFrame(part["x_train"], columns=names)
        test = pd.DataFrame(part["x_test"], columns=None)
        prevalence = float(part["y_train"].mean())
        skip = nm.skipped_detectors(len(train))
        skipped = [m for m in methods if m in skip]
        for method in methods:
            if method in skip:
                continue
            try:
                row = run_method(method, train, test, part["y_test"], seed, prevalence)
            except Exception as error:  # a failing model is recorded, not hidden
                errors.setdefault(method, []).append({"seed": seed, "error": repr(error)})
                continue
            runs.setdefault(method, []).append(row)
    return {"seeds": list(seeds), "runs": runs, "skipped": skipped, "errors": errors}


def x_run_problem__mutmut_30(
    x: np.ndarray,
    y: np.ndarray,
    seeds: tuple[int, ...] = config.BENCHMARK_SEEDS,
    methods: list[str] | None = None,
) -> dict[str, Any]:
    methods = methods or list(DETECTOR_NAMES)
    unknown = [m for m in methods if m not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    runs: dict[str, list[dict[str, Any]]] = {}
    errors: dict[str, list[dict[str, Any]]] = {}
    skipped: list[str] = []
    for seed in seeds:
        part = nm.split(x, y, seed)
        names = [f"f{i}" for i in range(x.shape[1])]
        train = pd.DataFrame(part["x_train"], columns=names)
        test = pd.DataFrame(columns=names)
        prevalence = float(part["y_train"].mean())
        skip = nm.skipped_detectors(len(train))
        skipped = [m for m in methods if m in skip]
        for method in methods:
            if method in skip:
                continue
            try:
                row = run_method(method, train, test, part["y_test"], seed, prevalence)
            except Exception as error:  # a failing model is recorded, not hidden
                errors.setdefault(method, []).append({"seed": seed, "error": repr(error)})
                continue
            runs.setdefault(method, []).append(row)
    return {"seeds": list(seeds), "runs": runs, "skipped": skipped, "errors": errors}


def x_run_problem__mutmut_31(
    x: np.ndarray,
    y: np.ndarray,
    seeds: tuple[int, ...] = config.BENCHMARK_SEEDS,
    methods: list[str] | None = None,
) -> dict[str, Any]:
    methods = methods or list(DETECTOR_NAMES)
    unknown = [m for m in methods if m not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    runs: dict[str, list[dict[str, Any]]] = {}
    errors: dict[str, list[dict[str, Any]]] = {}
    skipped: list[str] = []
    for seed in seeds:
        part = nm.split(x, y, seed)
        names = [f"f{i}" for i in range(x.shape[1])]
        train = pd.DataFrame(part["x_train"], columns=names)
        test = pd.DataFrame(part["x_test"], )
        prevalence = float(part["y_train"].mean())
        skip = nm.skipped_detectors(len(train))
        skipped = [m for m in methods if m in skip]
        for method in methods:
            if method in skip:
                continue
            try:
                row = run_method(method, train, test, part["y_test"], seed, prevalence)
            except Exception as error:  # a failing model is recorded, not hidden
                errors.setdefault(method, []).append({"seed": seed, "error": repr(error)})
                continue
            runs.setdefault(method, []).append(row)
    return {"seeds": list(seeds), "runs": runs, "skipped": skipped, "errors": errors}


def x_run_problem__mutmut_32(
    x: np.ndarray,
    y: np.ndarray,
    seeds: tuple[int, ...] = config.BENCHMARK_SEEDS,
    methods: list[str] | None = None,
) -> dict[str, Any]:
    methods = methods or list(DETECTOR_NAMES)
    unknown = [m for m in methods if m not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    runs: dict[str, list[dict[str, Any]]] = {}
    errors: dict[str, list[dict[str, Any]]] = {}
    skipped: list[str] = []
    for seed in seeds:
        part = nm.split(x, y, seed)
        names = [f"f{i}" for i in range(x.shape[1])]
        train = pd.DataFrame(part["x_train"], columns=names)
        test = pd.DataFrame(part["XXx_testXX"], columns=names)
        prevalence = float(part["y_train"].mean())
        skip = nm.skipped_detectors(len(train))
        skipped = [m for m in methods if m in skip]
        for method in methods:
            if method in skip:
                continue
            try:
                row = run_method(method, train, test, part["y_test"], seed, prevalence)
            except Exception as error:  # a failing model is recorded, not hidden
                errors.setdefault(method, []).append({"seed": seed, "error": repr(error)})
                continue
            runs.setdefault(method, []).append(row)
    return {"seeds": list(seeds), "runs": runs, "skipped": skipped, "errors": errors}


def x_run_problem__mutmut_33(
    x: np.ndarray,
    y: np.ndarray,
    seeds: tuple[int, ...] = config.BENCHMARK_SEEDS,
    methods: list[str] | None = None,
) -> dict[str, Any]:
    methods = methods or list(DETECTOR_NAMES)
    unknown = [m for m in methods if m not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    runs: dict[str, list[dict[str, Any]]] = {}
    errors: dict[str, list[dict[str, Any]]] = {}
    skipped: list[str] = []
    for seed in seeds:
        part = nm.split(x, y, seed)
        names = [f"f{i}" for i in range(x.shape[1])]
        train = pd.DataFrame(part["x_train"], columns=names)
        test = pd.DataFrame(part["X_TEST"], columns=names)
        prevalence = float(part["y_train"].mean())
        skip = nm.skipped_detectors(len(train))
        skipped = [m for m in methods if m in skip]
        for method in methods:
            if method in skip:
                continue
            try:
                row = run_method(method, train, test, part["y_test"], seed, prevalence)
            except Exception as error:  # a failing model is recorded, not hidden
                errors.setdefault(method, []).append({"seed": seed, "error": repr(error)})
                continue
            runs.setdefault(method, []).append(row)
    return {"seeds": list(seeds), "runs": runs, "skipped": skipped, "errors": errors}


def x_run_problem__mutmut_34(
    x: np.ndarray,
    y: np.ndarray,
    seeds: tuple[int, ...] = config.BENCHMARK_SEEDS,
    methods: list[str] | None = None,
) -> dict[str, Any]:
    methods = methods or list(DETECTOR_NAMES)
    unknown = [m for m in methods if m not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    runs: dict[str, list[dict[str, Any]]] = {}
    errors: dict[str, list[dict[str, Any]]] = {}
    skipped: list[str] = []
    for seed in seeds:
        part = nm.split(x, y, seed)
        names = [f"f{i}" for i in range(x.shape[1])]
        train = pd.DataFrame(part["x_train"], columns=names)
        test = pd.DataFrame(part["x_test"], columns=names)
        prevalence = None
        skip = nm.skipped_detectors(len(train))
        skipped = [m for m in methods if m in skip]
        for method in methods:
            if method in skip:
                continue
            try:
                row = run_method(method, train, test, part["y_test"], seed, prevalence)
            except Exception as error:  # a failing model is recorded, not hidden
                errors.setdefault(method, []).append({"seed": seed, "error": repr(error)})
                continue
            runs.setdefault(method, []).append(row)
    return {"seeds": list(seeds), "runs": runs, "skipped": skipped, "errors": errors}


def x_run_problem__mutmut_35(
    x: np.ndarray,
    y: np.ndarray,
    seeds: tuple[int, ...] = config.BENCHMARK_SEEDS,
    methods: list[str] | None = None,
) -> dict[str, Any]:
    methods = methods or list(DETECTOR_NAMES)
    unknown = [m for m in methods if m not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    runs: dict[str, list[dict[str, Any]]] = {}
    errors: dict[str, list[dict[str, Any]]] = {}
    skipped: list[str] = []
    for seed in seeds:
        part = nm.split(x, y, seed)
        names = [f"f{i}" for i in range(x.shape[1])]
        train = pd.DataFrame(part["x_train"], columns=names)
        test = pd.DataFrame(part["x_test"], columns=names)
        prevalence = float(None)
        skip = nm.skipped_detectors(len(train))
        skipped = [m for m in methods if m in skip]
        for method in methods:
            if method in skip:
                continue
            try:
                row = run_method(method, train, test, part["y_test"], seed, prevalence)
            except Exception as error:  # a failing model is recorded, not hidden
                errors.setdefault(method, []).append({"seed": seed, "error": repr(error)})
                continue
            runs.setdefault(method, []).append(row)
    return {"seeds": list(seeds), "runs": runs, "skipped": skipped, "errors": errors}


def x_run_problem__mutmut_36(
    x: np.ndarray,
    y: np.ndarray,
    seeds: tuple[int, ...] = config.BENCHMARK_SEEDS,
    methods: list[str] | None = None,
) -> dict[str, Any]:
    methods = methods or list(DETECTOR_NAMES)
    unknown = [m for m in methods if m not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    runs: dict[str, list[dict[str, Any]]] = {}
    errors: dict[str, list[dict[str, Any]]] = {}
    skipped: list[str] = []
    for seed in seeds:
        part = nm.split(x, y, seed)
        names = [f"f{i}" for i in range(x.shape[1])]
        train = pd.DataFrame(part["x_train"], columns=names)
        test = pd.DataFrame(part["x_test"], columns=names)
        prevalence = float(part["XXy_trainXX"].mean())
        skip = nm.skipped_detectors(len(train))
        skipped = [m for m in methods if m in skip]
        for method in methods:
            if method in skip:
                continue
            try:
                row = run_method(method, train, test, part["y_test"], seed, prevalence)
            except Exception as error:  # a failing model is recorded, not hidden
                errors.setdefault(method, []).append({"seed": seed, "error": repr(error)})
                continue
            runs.setdefault(method, []).append(row)
    return {"seeds": list(seeds), "runs": runs, "skipped": skipped, "errors": errors}


def x_run_problem__mutmut_37(
    x: np.ndarray,
    y: np.ndarray,
    seeds: tuple[int, ...] = config.BENCHMARK_SEEDS,
    methods: list[str] | None = None,
) -> dict[str, Any]:
    methods = methods or list(DETECTOR_NAMES)
    unknown = [m for m in methods if m not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    runs: dict[str, list[dict[str, Any]]] = {}
    errors: dict[str, list[dict[str, Any]]] = {}
    skipped: list[str] = []
    for seed in seeds:
        part = nm.split(x, y, seed)
        names = [f"f{i}" for i in range(x.shape[1])]
        train = pd.DataFrame(part["x_train"], columns=names)
        test = pd.DataFrame(part["x_test"], columns=names)
        prevalence = float(part["Y_TRAIN"].mean())
        skip = nm.skipped_detectors(len(train))
        skipped = [m for m in methods if m in skip]
        for method in methods:
            if method in skip:
                continue
            try:
                row = run_method(method, train, test, part["y_test"], seed, prevalence)
            except Exception as error:  # a failing model is recorded, not hidden
                errors.setdefault(method, []).append({"seed": seed, "error": repr(error)})
                continue
            runs.setdefault(method, []).append(row)
    return {"seeds": list(seeds), "runs": runs, "skipped": skipped, "errors": errors}


def x_run_problem__mutmut_38(
    x: np.ndarray,
    y: np.ndarray,
    seeds: tuple[int, ...] = config.BENCHMARK_SEEDS,
    methods: list[str] | None = None,
) -> dict[str, Any]:
    methods = methods or list(DETECTOR_NAMES)
    unknown = [m for m in methods if m not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    runs: dict[str, list[dict[str, Any]]] = {}
    errors: dict[str, list[dict[str, Any]]] = {}
    skipped: list[str] = []
    for seed in seeds:
        part = nm.split(x, y, seed)
        names = [f"f{i}" for i in range(x.shape[1])]
        train = pd.DataFrame(part["x_train"], columns=names)
        test = pd.DataFrame(part["x_test"], columns=names)
        prevalence = float(part["y_train"].mean())
        skip = None
        skipped = [m for m in methods if m in skip]
        for method in methods:
            if method in skip:
                continue
            try:
                row = run_method(method, train, test, part["y_test"], seed, prevalence)
            except Exception as error:  # a failing model is recorded, not hidden
                errors.setdefault(method, []).append({"seed": seed, "error": repr(error)})
                continue
            runs.setdefault(method, []).append(row)
    return {"seeds": list(seeds), "runs": runs, "skipped": skipped, "errors": errors}


def x_run_problem__mutmut_39(
    x: np.ndarray,
    y: np.ndarray,
    seeds: tuple[int, ...] = config.BENCHMARK_SEEDS,
    methods: list[str] | None = None,
) -> dict[str, Any]:
    methods = methods or list(DETECTOR_NAMES)
    unknown = [m for m in methods if m not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    runs: dict[str, list[dict[str, Any]]] = {}
    errors: dict[str, list[dict[str, Any]]] = {}
    skipped: list[str] = []
    for seed in seeds:
        part = nm.split(x, y, seed)
        names = [f"f{i}" for i in range(x.shape[1])]
        train = pd.DataFrame(part["x_train"], columns=names)
        test = pd.DataFrame(part["x_test"], columns=names)
        prevalence = float(part["y_train"].mean())
        skip = nm.skipped_detectors(None)
        skipped = [m for m in methods if m in skip]
        for method in methods:
            if method in skip:
                continue
            try:
                row = run_method(method, train, test, part["y_test"], seed, prevalence)
            except Exception as error:  # a failing model is recorded, not hidden
                errors.setdefault(method, []).append({"seed": seed, "error": repr(error)})
                continue
            runs.setdefault(method, []).append(row)
    return {"seeds": list(seeds), "runs": runs, "skipped": skipped, "errors": errors}


def x_run_problem__mutmut_40(
    x: np.ndarray,
    y: np.ndarray,
    seeds: tuple[int, ...] = config.BENCHMARK_SEEDS,
    methods: list[str] | None = None,
) -> dict[str, Any]:
    methods = methods or list(DETECTOR_NAMES)
    unknown = [m for m in methods if m not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    runs: dict[str, list[dict[str, Any]]] = {}
    errors: dict[str, list[dict[str, Any]]] = {}
    skipped: list[str] = []
    for seed in seeds:
        part = nm.split(x, y, seed)
        names = [f"f{i}" for i in range(x.shape[1])]
        train = pd.DataFrame(part["x_train"], columns=names)
        test = pd.DataFrame(part["x_test"], columns=names)
        prevalence = float(part["y_train"].mean())
        skip = nm.skipped_detectors(len(train))
        skipped = None
        for method in methods:
            if method in skip:
                continue
            try:
                row = run_method(method, train, test, part["y_test"], seed, prevalence)
            except Exception as error:  # a failing model is recorded, not hidden
                errors.setdefault(method, []).append({"seed": seed, "error": repr(error)})
                continue
            runs.setdefault(method, []).append(row)
    return {"seeds": list(seeds), "runs": runs, "skipped": skipped, "errors": errors}


def x_run_problem__mutmut_41(
    x: np.ndarray,
    y: np.ndarray,
    seeds: tuple[int, ...] = config.BENCHMARK_SEEDS,
    methods: list[str] | None = None,
) -> dict[str, Any]:
    methods = methods or list(DETECTOR_NAMES)
    unknown = [m for m in methods if m not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    runs: dict[str, list[dict[str, Any]]] = {}
    errors: dict[str, list[dict[str, Any]]] = {}
    skipped: list[str] = []
    for seed in seeds:
        part = nm.split(x, y, seed)
        names = [f"f{i}" for i in range(x.shape[1])]
        train = pd.DataFrame(part["x_train"], columns=names)
        test = pd.DataFrame(part["x_test"], columns=names)
        prevalence = float(part["y_train"].mean())
        skip = nm.skipped_detectors(len(train))
        skipped = [m for m in methods if m not in skip]
        for method in methods:
            if method in skip:
                continue
            try:
                row = run_method(method, train, test, part["y_test"], seed, prevalence)
            except Exception as error:  # a failing model is recorded, not hidden
                errors.setdefault(method, []).append({"seed": seed, "error": repr(error)})
                continue
            runs.setdefault(method, []).append(row)
    return {"seeds": list(seeds), "runs": runs, "skipped": skipped, "errors": errors}


def x_run_problem__mutmut_42(
    x: np.ndarray,
    y: np.ndarray,
    seeds: tuple[int, ...] = config.BENCHMARK_SEEDS,
    methods: list[str] | None = None,
) -> dict[str, Any]:
    methods = methods or list(DETECTOR_NAMES)
    unknown = [m for m in methods if m not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    runs: dict[str, list[dict[str, Any]]] = {}
    errors: dict[str, list[dict[str, Any]]] = {}
    skipped: list[str] = []
    for seed in seeds:
        part = nm.split(x, y, seed)
        names = [f"f{i}" for i in range(x.shape[1])]
        train = pd.DataFrame(part["x_train"], columns=names)
        test = pd.DataFrame(part["x_test"], columns=names)
        prevalence = float(part["y_train"].mean())
        skip = nm.skipped_detectors(len(train))
        skipped = [m for m in methods if m in skip]
        for method in methods:
            if method not in skip:
                continue
            try:
                row = run_method(method, train, test, part["y_test"], seed, prevalence)
            except Exception as error:  # a failing model is recorded, not hidden
                errors.setdefault(method, []).append({"seed": seed, "error": repr(error)})
                continue
            runs.setdefault(method, []).append(row)
    return {"seeds": list(seeds), "runs": runs, "skipped": skipped, "errors": errors}


def x_run_problem__mutmut_43(
    x: np.ndarray,
    y: np.ndarray,
    seeds: tuple[int, ...] = config.BENCHMARK_SEEDS,
    methods: list[str] | None = None,
) -> dict[str, Any]:
    methods = methods or list(DETECTOR_NAMES)
    unknown = [m for m in methods if m not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    runs: dict[str, list[dict[str, Any]]] = {}
    errors: dict[str, list[dict[str, Any]]] = {}
    skipped: list[str] = []
    for seed in seeds:
        part = nm.split(x, y, seed)
        names = [f"f{i}" for i in range(x.shape[1])]
        train = pd.DataFrame(part["x_train"], columns=names)
        test = pd.DataFrame(part["x_test"], columns=names)
        prevalence = float(part["y_train"].mean())
        skip = nm.skipped_detectors(len(train))
        skipped = [m for m in methods if m in skip]
        for method in methods:
            if method in skip:
                break
            try:
                row = run_method(method, train, test, part["y_test"], seed, prevalence)
            except Exception as error:  # a failing model is recorded, not hidden
                errors.setdefault(method, []).append({"seed": seed, "error": repr(error)})
                continue
            runs.setdefault(method, []).append(row)
    return {"seeds": list(seeds), "runs": runs, "skipped": skipped, "errors": errors}


def x_run_problem__mutmut_44(
    x: np.ndarray,
    y: np.ndarray,
    seeds: tuple[int, ...] = config.BENCHMARK_SEEDS,
    methods: list[str] | None = None,
) -> dict[str, Any]:
    methods = methods or list(DETECTOR_NAMES)
    unknown = [m for m in methods if m not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    runs: dict[str, list[dict[str, Any]]] = {}
    errors: dict[str, list[dict[str, Any]]] = {}
    skipped: list[str] = []
    for seed in seeds:
        part = nm.split(x, y, seed)
        names = [f"f{i}" for i in range(x.shape[1])]
        train = pd.DataFrame(part["x_train"], columns=names)
        test = pd.DataFrame(part["x_test"], columns=names)
        prevalence = float(part["y_train"].mean())
        skip = nm.skipped_detectors(len(train))
        skipped = [m for m in methods if m in skip]
        for method in methods:
            if method in skip:
                continue
            try:
                row = None
            except Exception as error:  # a failing model is recorded, not hidden
                errors.setdefault(method, []).append({"seed": seed, "error": repr(error)})
                continue
            runs.setdefault(method, []).append(row)
    return {"seeds": list(seeds), "runs": runs, "skipped": skipped, "errors": errors}


def x_run_problem__mutmut_45(
    x: np.ndarray,
    y: np.ndarray,
    seeds: tuple[int, ...] = config.BENCHMARK_SEEDS,
    methods: list[str] | None = None,
) -> dict[str, Any]:
    methods = methods or list(DETECTOR_NAMES)
    unknown = [m for m in methods if m not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    runs: dict[str, list[dict[str, Any]]] = {}
    errors: dict[str, list[dict[str, Any]]] = {}
    skipped: list[str] = []
    for seed in seeds:
        part = nm.split(x, y, seed)
        names = [f"f{i}" for i in range(x.shape[1])]
        train = pd.DataFrame(part["x_train"], columns=names)
        test = pd.DataFrame(part["x_test"], columns=names)
        prevalence = float(part["y_train"].mean())
        skip = nm.skipped_detectors(len(train))
        skipped = [m for m in methods if m in skip]
        for method in methods:
            if method in skip:
                continue
            try:
                row = run_method(None, train, test, part["y_test"], seed, prevalence)
            except Exception as error:  # a failing model is recorded, not hidden
                errors.setdefault(method, []).append({"seed": seed, "error": repr(error)})
                continue
            runs.setdefault(method, []).append(row)
    return {"seeds": list(seeds), "runs": runs, "skipped": skipped, "errors": errors}


def x_run_problem__mutmut_46(
    x: np.ndarray,
    y: np.ndarray,
    seeds: tuple[int, ...] = config.BENCHMARK_SEEDS,
    methods: list[str] | None = None,
) -> dict[str, Any]:
    methods = methods or list(DETECTOR_NAMES)
    unknown = [m for m in methods if m not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    runs: dict[str, list[dict[str, Any]]] = {}
    errors: dict[str, list[dict[str, Any]]] = {}
    skipped: list[str] = []
    for seed in seeds:
        part = nm.split(x, y, seed)
        names = [f"f{i}" for i in range(x.shape[1])]
        train = pd.DataFrame(part["x_train"], columns=names)
        test = pd.DataFrame(part["x_test"], columns=names)
        prevalence = float(part["y_train"].mean())
        skip = nm.skipped_detectors(len(train))
        skipped = [m for m in methods if m in skip]
        for method in methods:
            if method in skip:
                continue
            try:
                row = run_method(method, None, test, part["y_test"], seed, prevalence)
            except Exception as error:  # a failing model is recorded, not hidden
                errors.setdefault(method, []).append({"seed": seed, "error": repr(error)})
                continue
            runs.setdefault(method, []).append(row)
    return {"seeds": list(seeds), "runs": runs, "skipped": skipped, "errors": errors}


def x_run_problem__mutmut_47(
    x: np.ndarray,
    y: np.ndarray,
    seeds: tuple[int, ...] = config.BENCHMARK_SEEDS,
    methods: list[str] | None = None,
) -> dict[str, Any]:
    methods = methods or list(DETECTOR_NAMES)
    unknown = [m for m in methods if m not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    runs: dict[str, list[dict[str, Any]]] = {}
    errors: dict[str, list[dict[str, Any]]] = {}
    skipped: list[str] = []
    for seed in seeds:
        part = nm.split(x, y, seed)
        names = [f"f{i}" for i in range(x.shape[1])]
        train = pd.DataFrame(part["x_train"], columns=names)
        test = pd.DataFrame(part["x_test"], columns=names)
        prevalence = float(part["y_train"].mean())
        skip = nm.skipped_detectors(len(train))
        skipped = [m for m in methods if m in skip]
        for method in methods:
            if method in skip:
                continue
            try:
                row = run_method(method, train, None, part["y_test"], seed, prevalence)
            except Exception as error:  # a failing model is recorded, not hidden
                errors.setdefault(method, []).append({"seed": seed, "error": repr(error)})
                continue
            runs.setdefault(method, []).append(row)
    return {"seeds": list(seeds), "runs": runs, "skipped": skipped, "errors": errors}


def x_run_problem__mutmut_48(
    x: np.ndarray,
    y: np.ndarray,
    seeds: tuple[int, ...] = config.BENCHMARK_SEEDS,
    methods: list[str] | None = None,
) -> dict[str, Any]:
    methods = methods or list(DETECTOR_NAMES)
    unknown = [m for m in methods if m not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    runs: dict[str, list[dict[str, Any]]] = {}
    errors: dict[str, list[dict[str, Any]]] = {}
    skipped: list[str] = []
    for seed in seeds:
        part = nm.split(x, y, seed)
        names = [f"f{i}" for i in range(x.shape[1])]
        train = pd.DataFrame(part["x_train"], columns=names)
        test = pd.DataFrame(part["x_test"], columns=names)
        prevalence = float(part["y_train"].mean())
        skip = nm.skipped_detectors(len(train))
        skipped = [m for m in methods if m in skip]
        for method in methods:
            if method in skip:
                continue
            try:
                row = run_method(method, train, test, None, seed, prevalence)
            except Exception as error:  # a failing model is recorded, not hidden
                errors.setdefault(method, []).append({"seed": seed, "error": repr(error)})
                continue
            runs.setdefault(method, []).append(row)
    return {"seeds": list(seeds), "runs": runs, "skipped": skipped, "errors": errors}


def x_run_problem__mutmut_49(
    x: np.ndarray,
    y: np.ndarray,
    seeds: tuple[int, ...] = config.BENCHMARK_SEEDS,
    methods: list[str] | None = None,
) -> dict[str, Any]:
    methods = methods or list(DETECTOR_NAMES)
    unknown = [m for m in methods if m not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    runs: dict[str, list[dict[str, Any]]] = {}
    errors: dict[str, list[dict[str, Any]]] = {}
    skipped: list[str] = []
    for seed in seeds:
        part = nm.split(x, y, seed)
        names = [f"f{i}" for i in range(x.shape[1])]
        train = pd.DataFrame(part["x_train"], columns=names)
        test = pd.DataFrame(part["x_test"], columns=names)
        prevalence = float(part["y_train"].mean())
        skip = nm.skipped_detectors(len(train))
        skipped = [m for m in methods if m in skip]
        for method in methods:
            if method in skip:
                continue
            try:
                row = run_method(method, train, test, part["y_test"], None, prevalence)
            except Exception as error:  # a failing model is recorded, not hidden
                errors.setdefault(method, []).append({"seed": seed, "error": repr(error)})
                continue
            runs.setdefault(method, []).append(row)
    return {"seeds": list(seeds), "runs": runs, "skipped": skipped, "errors": errors}


def x_run_problem__mutmut_50(
    x: np.ndarray,
    y: np.ndarray,
    seeds: tuple[int, ...] = config.BENCHMARK_SEEDS,
    methods: list[str] | None = None,
) -> dict[str, Any]:
    methods = methods or list(DETECTOR_NAMES)
    unknown = [m for m in methods if m not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    runs: dict[str, list[dict[str, Any]]] = {}
    errors: dict[str, list[dict[str, Any]]] = {}
    skipped: list[str] = []
    for seed in seeds:
        part = nm.split(x, y, seed)
        names = [f"f{i}" for i in range(x.shape[1])]
        train = pd.DataFrame(part["x_train"], columns=names)
        test = pd.DataFrame(part["x_test"], columns=names)
        prevalence = float(part["y_train"].mean())
        skip = nm.skipped_detectors(len(train))
        skipped = [m for m in methods if m in skip]
        for method in methods:
            if method in skip:
                continue
            try:
                row = run_method(method, train, test, part["y_test"], seed, None)
            except Exception as error:  # a failing model is recorded, not hidden
                errors.setdefault(method, []).append({"seed": seed, "error": repr(error)})
                continue
            runs.setdefault(method, []).append(row)
    return {"seeds": list(seeds), "runs": runs, "skipped": skipped, "errors": errors}


def x_run_problem__mutmut_51(
    x: np.ndarray,
    y: np.ndarray,
    seeds: tuple[int, ...] = config.BENCHMARK_SEEDS,
    methods: list[str] | None = None,
) -> dict[str, Any]:
    methods = methods or list(DETECTOR_NAMES)
    unknown = [m for m in methods if m not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    runs: dict[str, list[dict[str, Any]]] = {}
    errors: dict[str, list[dict[str, Any]]] = {}
    skipped: list[str] = []
    for seed in seeds:
        part = nm.split(x, y, seed)
        names = [f"f{i}" for i in range(x.shape[1])]
        train = pd.DataFrame(part["x_train"], columns=names)
        test = pd.DataFrame(part["x_test"], columns=names)
        prevalence = float(part["y_train"].mean())
        skip = nm.skipped_detectors(len(train))
        skipped = [m for m in methods if m in skip]
        for method in methods:
            if method in skip:
                continue
            try:
                row = run_method(train, test, part["y_test"], seed, prevalence)
            except Exception as error:  # a failing model is recorded, not hidden
                errors.setdefault(method, []).append({"seed": seed, "error": repr(error)})
                continue
            runs.setdefault(method, []).append(row)
    return {"seeds": list(seeds), "runs": runs, "skipped": skipped, "errors": errors}


def x_run_problem__mutmut_52(
    x: np.ndarray,
    y: np.ndarray,
    seeds: tuple[int, ...] = config.BENCHMARK_SEEDS,
    methods: list[str] | None = None,
) -> dict[str, Any]:
    methods = methods or list(DETECTOR_NAMES)
    unknown = [m for m in methods if m not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    runs: dict[str, list[dict[str, Any]]] = {}
    errors: dict[str, list[dict[str, Any]]] = {}
    skipped: list[str] = []
    for seed in seeds:
        part = nm.split(x, y, seed)
        names = [f"f{i}" for i in range(x.shape[1])]
        train = pd.DataFrame(part["x_train"], columns=names)
        test = pd.DataFrame(part["x_test"], columns=names)
        prevalence = float(part["y_train"].mean())
        skip = nm.skipped_detectors(len(train))
        skipped = [m for m in methods if m in skip]
        for method in methods:
            if method in skip:
                continue
            try:
                row = run_method(method, test, part["y_test"], seed, prevalence)
            except Exception as error:  # a failing model is recorded, not hidden
                errors.setdefault(method, []).append({"seed": seed, "error": repr(error)})
                continue
            runs.setdefault(method, []).append(row)
    return {"seeds": list(seeds), "runs": runs, "skipped": skipped, "errors": errors}


def x_run_problem__mutmut_53(
    x: np.ndarray,
    y: np.ndarray,
    seeds: tuple[int, ...] = config.BENCHMARK_SEEDS,
    methods: list[str] | None = None,
) -> dict[str, Any]:
    methods = methods or list(DETECTOR_NAMES)
    unknown = [m for m in methods if m not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    runs: dict[str, list[dict[str, Any]]] = {}
    errors: dict[str, list[dict[str, Any]]] = {}
    skipped: list[str] = []
    for seed in seeds:
        part = nm.split(x, y, seed)
        names = [f"f{i}" for i in range(x.shape[1])]
        train = pd.DataFrame(part["x_train"], columns=names)
        test = pd.DataFrame(part["x_test"], columns=names)
        prevalence = float(part["y_train"].mean())
        skip = nm.skipped_detectors(len(train))
        skipped = [m for m in methods if m in skip]
        for method in methods:
            if method in skip:
                continue
            try:
                row = run_method(method, train, part["y_test"], seed, prevalence)
            except Exception as error:  # a failing model is recorded, not hidden
                errors.setdefault(method, []).append({"seed": seed, "error": repr(error)})
                continue
            runs.setdefault(method, []).append(row)
    return {"seeds": list(seeds), "runs": runs, "skipped": skipped, "errors": errors}


def x_run_problem__mutmut_54(
    x: np.ndarray,
    y: np.ndarray,
    seeds: tuple[int, ...] = config.BENCHMARK_SEEDS,
    methods: list[str] | None = None,
) -> dict[str, Any]:
    methods = methods or list(DETECTOR_NAMES)
    unknown = [m for m in methods if m not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    runs: dict[str, list[dict[str, Any]]] = {}
    errors: dict[str, list[dict[str, Any]]] = {}
    skipped: list[str] = []
    for seed in seeds:
        part = nm.split(x, y, seed)
        names = [f"f{i}" for i in range(x.shape[1])]
        train = pd.DataFrame(part["x_train"], columns=names)
        test = pd.DataFrame(part["x_test"], columns=names)
        prevalence = float(part["y_train"].mean())
        skip = nm.skipped_detectors(len(train))
        skipped = [m for m in methods if m in skip]
        for method in methods:
            if method in skip:
                continue
            try:
                row = run_method(method, train, test, seed, prevalence)
            except Exception as error:  # a failing model is recorded, not hidden
                errors.setdefault(method, []).append({"seed": seed, "error": repr(error)})
                continue
            runs.setdefault(method, []).append(row)
    return {"seeds": list(seeds), "runs": runs, "skipped": skipped, "errors": errors}


def x_run_problem__mutmut_55(
    x: np.ndarray,
    y: np.ndarray,
    seeds: tuple[int, ...] = config.BENCHMARK_SEEDS,
    methods: list[str] | None = None,
) -> dict[str, Any]:
    methods = methods or list(DETECTOR_NAMES)
    unknown = [m for m in methods if m not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    runs: dict[str, list[dict[str, Any]]] = {}
    errors: dict[str, list[dict[str, Any]]] = {}
    skipped: list[str] = []
    for seed in seeds:
        part = nm.split(x, y, seed)
        names = [f"f{i}" for i in range(x.shape[1])]
        train = pd.DataFrame(part["x_train"], columns=names)
        test = pd.DataFrame(part["x_test"], columns=names)
        prevalence = float(part["y_train"].mean())
        skip = nm.skipped_detectors(len(train))
        skipped = [m for m in methods if m in skip]
        for method in methods:
            if method in skip:
                continue
            try:
                row = run_method(method, train, test, part["y_test"], prevalence)
            except Exception as error:  # a failing model is recorded, not hidden
                errors.setdefault(method, []).append({"seed": seed, "error": repr(error)})
                continue
            runs.setdefault(method, []).append(row)
    return {"seeds": list(seeds), "runs": runs, "skipped": skipped, "errors": errors}


def x_run_problem__mutmut_56(
    x: np.ndarray,
    y: np.ndarray,
    seeds: tuple[int, ...] = config.BENCHMARK_SEEDS,
    methods: list[str] | None = None,
) -> dict[str, Any]:
    methods = methods or list(DETECTOR_NAMES)
    unknown = [m for m in methods if m not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    runs: dict[str, list[dict[str, Any]]] = {}
    errors: dict[str, list[dict[str, Any]]] = {}
    skipped: list[str] = []
    for seed in seeds:
        part = nm.split(x, y, seed)
        names = [f"f{i}" for i in range(x.shape[1])]
        train = pd.DataFrame(part["x_train"], columns=names)
        test = pd.DataFrame(part["x_test"], columns=names)
        prevalence = float(part["y_train"].mean())
        skip = nm.skipped_detectors(len(train))
        skipped = [m for m in methods if m in skip]
        for method in methods:
            if method in skip:
                continue
            try:
                row = run_method(method, train, test, part["y_test"], seed, )
            except Exception as error:  # a failing model is recorded, not hidden
                errors.setdefault(method, []).append({"seed": seed, "error": repr(error)})
                continue
            runs.setdefault(method, []).append(row)
    return {"seeds": list(seeds), "runs": runs, "skipped": skipped, "errors": errors}


def x_run_problem__mutmut_57(
    x: np.ndarray,
    y: np.ndarray,
    seeds: tuple[int, ...] = config.BENCHMARK_SEEDS,
    methods: list[str] | None = None,
) -> dict[str, Any]:
    methods = methods or list(DETECTOR_NAMES)
    unknown = [m for m in methods if m not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    runs: dict[str, list[dict[str, Any]]] = {}
    errors: dict[str, list[dict[str, Any]]] = {}
    skipped: list[str] = []
    for seed in seeds:
        part = nm.split(x, y, seed)
        names = [f"f{i}" for i in range(x.shape[1])]
        train = pd.DataFrame(part["x_train"], columns=names)
        test = pd.DataFrame(part["x_test"], columns=names)
        prevalence = float(part["y_train"].mean())
        skip = nm.skipped_detectors(len(train))
        skipped = [m for m in methods if m in skip]
        for method in methods:
            if method in skip:
                continue
            try:
                row = run_method(method, train, test, part["XXy_testXX"], seed, prevalence)
            except Exception as error:  # a failing model is recorded, not hidden
                errors.setdefault(method, []).append({"seed": seed, "error": repr(error)})
                continue
            runs.setdefault(method, []).append(row)
    return {"seeds": list(seeds), "runs": runs, "skipped": skipped, "errors": errors}


def x_run_problem__mutmut_58(
    x: np.ndarray,
    y: np.ndarray,
    seeds: tuple[int, ...] = config.BENCHMARK_SEEDS,
    methods: list[str] | None = None,
) -> dict[str, Any]:
    methods = methods or list(DETECTOR_NAMES)
    unknown = [m for m in methods if m not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    runs: dict[str, list[dict[str, Any]]] = {}
    errors: dict[str, list[dict[str, Any]]] = {}
    skipped: list[str] = []
    for seed in seeds:
        part = nm.split(x, y, seed)
        names = [f"f{i}" for i in range(x.shape[1])]
        train = pd.DataFrame(part["x_train"], columns=names)
        test = pd.DataFrame(part["x_test"], columns=names)
        prevalence = float(part["y_train"].mean())
        skip = nm.skipped_detectors(len(train))
        skipped = [m for m in methods if m in skip]
        for method in methods:
            if method in skip:
                continue
            try:
                row = run_method(method, train, test, part["Y_TEST"], seed, prevalence)
            except Exception as error:  # a failing model is recorded, not hidden
                errors.setdefault(method, []).append({"seed": seed, "error": repr(error)})
                continue
            runs.setdefault(method, []).append(row)
    return {"seeds": list(seeds), "runs": runs, "skipped": skipped, "errors": errors}


def x_run_problem__mutmut_59(
    x: np.ndarray,
    y: np.ndarray,
    seeds: tuple[int, ...] = config.BENCHMARK_SEEDS,
    methods: list[str] | None = None,
) -> dict[str, Any]:
    methods = methods or list(DETECTOR_NAMES)
    unknown = [m for m in methods if m not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    runs: dict[str, list[dict[str, Any]]] = {}
    errors: dict[str, list[dict[str, Any]]] = {}
    skipped: list[str] = []
    for seed in seeds:
        part = nm.split(x, y, seed)
        names = [f"f{i}" for i in range(x.shape[1])]
        train = pd.DataFrame(part["x_train"], columns=names)
        test = pd.DataFrame(part["x_test"], columns=names)
        prevalence = float(part["y_train"].mean())
        skip = nm.skipped_detectors(len(train))
        skipped = [m for m in methods if m in skip]
        for method in methods:
            if method in skip:
                continue
            try:
                row = run_method(method, train, test, part["y_test"], seed, prevalence)
            except Exception as error:  # a failing model is recorded, not hidden
                errors.setdefault(method, []).append(None)
                continue
            runs.setdefault(method, []).append(row)
    return {"seeds": list(seeds), "runs": runs, "skipped": skipped, "errors": errors}


def x_run_problem__mutmut_60(
    x: np.ndarray,
    y: np.ndarray,
    seeds: tuple[int, ...] = config.BENCHMARK_SEEDS,
    methods: list[str] | None = None,
) -> dict[str, Any]:
    methods = methods or list(DETECTOR_NAMES)
    unknown = [m for m in methods if m not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    runs: dict[str, list[dict[str, Any]]] = {}
    errors: dict[str, list[dict[str, Any]]] = {}
    skipped: list[str] = []
    for seed in seeds:
        part = nm.split(x, y, seed)
        names = [f"f{i}" for i in range(x.shape[1])]
        train = pd.DataFrame(part["x_train"], columns=names)
        test = pd.DataFrame(part["x_test"], columns=names)
        prevalence = float(part["y_train"].mean())
        skip = nm.skipped_detectors(len(train))
        skipped = [m for m in methods if m in skip]
        for method in methods:
            if method in skip:
                continue
            try:
                row = run_method(method, train, test, part["y_test"], seed, prevalence)
            except Exception as error:  # a failing model is recorded, not hidden
                errors.setdefault(None, []).append({"seed": seed, "error": repr(error)})
                continue
            runs.setdefault(method, []).append(row)
    return {"seeds": list(seeds), "runs": runs, "skipped": skipped, "errors": errors}


def x_run_problem__mutmut_61(
    x: np.ndarray,
    y: np.ndarray,
    seeds: tuple[int, ...] = config.BENCHMARK_SEEDS,
    methods: list[str] | None = None,
) -> dict[str, Any]:
    methods = methods or list(DETECTOR_NAMES)
    unknown = [m for m in methods if m not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    runs: dict[str, list[dict[str, Any]]] = {}
    errors: dict[str, list[dict[str, Any]]] = {}
    skipped: list[str] = []
    for seed in seeds:
        part = nm.split(x, y, seed)
        names = [f"f{i}" for i in range(x.shape[1])]
        train = pd.DataFrame(part["x_train"], columns=names)
        test = pd.DataFrame(part["x_test"], columns=names)
        prevalence = float(part["y_train"].mean())
        skip = nm.skipped_detectors(len(train))
        skipped = [m for m in methods if m in skip]
        for method in methods:
            if method in skip:
                continue
            try:
                row = run_method(method, train, test, part["y_test"], seed, prevalence)
            except Exception as error:  # a failing model is recorded, not hidden
                errors.setdefault(method, None).append({"seed": seed, "error": repr(error)})
                continue
            runs.setdefault(method, []).append(row)
    return {"seeds": list(seeds), "runs": runs, "skipped": skipped, "errors": errors}


def x_run_problem__mutmut_62(
    x: np.ndarray,
    y: np.ndarray,
    seeds: tuple[int, ...] = config.BENCHMARK_SEEDS,
    methods: list[str] | None = None,
) -> dict[str, Any]:
    methods = methods or list(DETECTOR_NAMES)
    unknown = [m for m in methods if m not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    runs: dict[str, list[dict[str, Any]]] = {}
    errors: dict[str, list[dict[str, Any]]] = {}
    skipped: list[str] = []
    for seed in seeds:
        part = nm.split(x, y, seed)
        names = [f"f{i}" for i in range(x.shape[1])]
        train = pd.DataFrame(part["x_train"], columns=names)
        test = pd.DataFrame(part["x_test"], columns=names)
        prevalence = float(part["y_train"].mean())
        skip = nm.skipped_detectors(len(train))
        skipped = [m for m in methods if m in skip]
        for method in methods:
            if method in skip:
                continue
            try:
                row = run_method(method, train, test, part["y_test"], seed, prevalence)
            except Exception as error:  # a failing model is recorded, not hidden
                errors.setdefault([]).append({"seed": seed, "error": repr(error)})
                continue
            runs.setdefault(method, []).append(row)
    return {"seeds": list(seeds), "runs": runs, "skipped": skipped, "errors": errors}


def x_run_problem__mutmut_63(
    x: np.ndarray,
    y: np.ndarray,
    seeds: tuple[int, ...] = config.BENCHMARK_SEEDS,
    methods: list[str] | None = None,
) -> dict[str, Any]:
    methods = methods or list(DETECTOR_NAMES)
    unknown = [m for m in methods if m not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    runs: dict[str, list[dict[str, Any]]] = {}
    errors: dict[str, list[dict[str, Any]]] = {}
    skipped: list[str] = []
    for seed in seeds:
        part = nm.split(x, y, seed)
        names = [f"f{i}" for i in range(x.shape[1])]
        train = pd.DataFrame(part["x_train"], columns=names)
        test = pd.DataFrame(part["x_test"], columns=names)
        prevalence = float(part["y_train"].mean())
        skip = nm.skipped_detectors(len(train))
        skipped = [m for m in methods if m in skip]
        for method in methods:
            if method in skip:
                continue
            try:
                row = run_method(method, train, test, part["y_test"], seed, prevalence)
            except Exception as error:  # a failing model is recorded, not hidden
                errors.setdefault(method, ).append({"seed": seed, "error": repr(error)})
                continue
            runs.setdefault(method, []).append(row)
    return {"seeds": list(seeds), "runs": runs, "skipped": skipped, "errors": errors}


def x_run_problem__mutmut_64(
    x: np.ndarray,
    y: np.ndarray,
    seeds: tuple[int, ...] = config.BENCHMARK_SEEDS,
    methods: list[str] | None = None,
) -> dict[str, Any]:
    methods = methods or list(DETECTOR_NAMES)
    unknown = [m for m in methods if m not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    runs: dict[str, list[dict[str, Any]]] = {}
    errors: dict[str, list[dict[str, Any]]] = {}
    skipped: list[str] = []
    for seed in seeds:
        part = nm.split(x, y, seed)
        names = [f"f{i}" for i in range(x.shape[1])]
        train = pd.DataFrame(part["x_train"], columns=names)
        test = pd.DataFrame(part["x_test"], columns=names)
        prevalence = float(part["y_train"].mean())
        skip = nm.skipped_detectors(len(train))
        skipped = [m for m in methods if m in skip]
        for method in methods:
            if method in skip:
                continue
            try:
                row = run_method(method, train, test, part["y_test"], seed, prevalence)
            except Exception as error:  # a failing model is recorded, not hidden
                errors.setdefault(method, []).append({"XXseedXX": seed, "error": repr(error)})
                continue
            runs.setdefault(method, []).append(row)
    return {"seeds": list(seeds), "runs": runs, "skipped": skipped, "errors": errors}


def x_run_problem__mutmut_65(
    x: np.ndarray,
    y: np.ndarray,
    seeds: tuple[int, ...] = config.BENCHMARK_SEEDS,
    methods: list[str] | None = None,
) -> dict[str, Any]:
    methods = methods or list(DETECTOR_NAMES)
    unknown = [m for m in methods if m not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    runs: dict[str, list[dict[str, Any]]] = {}
    errors: dict[str, list[dict[str, Any]]] = {}
    skipped: list[str] = []
    for seed in seeds:
        part = nm.split(x, y, seed)
        names = [f"f{i}" for i in range(x.shape[1])]
        train = pd.DataFrame(part["x_train"], columns=names)
        test = pd.DataFrame(part["x_test"], columns=names)
        prevalence = float(part["y_train"].mean())
        skip = nm.skipped_detectors(len(train))
        skipped = [m for m in methods if m in skip]
        for method in methods:
            if method in skip:
                continue
            try:
                row = run_method(method, train, test, part["y_test"], seed, prevalence)
            except Exception as error:  # a failing model is recorded, not hidden
                errors.setdefault(method, []).append({"SEED": seed, "error": repr(error)})
                continue
            runs.setdefault(method, []).append(row)
    return {"seeds": list(seeds), "runs": runs, "skipped": skipped, "errors": errors}


def x_run_problem__mutmut_66(
    x: np.ndarray,
    y: np.ndarray,
    seeds: tuple[int, ...] = config.BENCHMARK_SEEDS,
    methods: list[str] | None = None,
) -> dict[str, Any]:
    methods = methods or list(DETECTOR_NAMES)
    unknown = [m for m in methods if m not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    runs: dict[str, list[dict[str, Any]]] = {}
    errors: dict[str, list[dict[str, Any]]] = {}
    skipped: list[str] = []
    for seed in seeds:
        part = nm.split(x, y, seed)
        names = [f"f{i}" for i in range(x.shape[1])]
        train = pd.DataFrame(part["x_train"], columns=names)
        test = pd.DataFrame(part["x_test"], columns=names)
        prevalence = float(part["y_train"].mean())
        skip = nm.skipped_detectors(len(train))
        skipped = [m for m in methods if m in skip]
        for method in methods:
            if method in skip:
                continue
            try:
                row = run_method(method, train, test, part["y_test"], seed, prevalence)
            except Exception as error:  # a failing model is recorded, not hidden
                errors.setdefault(method, []).append({"seed": seed, "XXerrorXX": repr(error)})
                continue
            runs.setdefault(method, []).append(row)
    return {"seeds": list(seeds), "runs": runs, "skipped": skipped, "errors": errors}


def x_run_problem__mutmut_67(
    x: np.ndarray,
    y: np.ndarray,
    seeds: tuple[int, ...] = config.BENCHMARK_SEEDS,
    methods: list[str] | None = None,
) -> dict[str, Any]:
    methods = methods or list(DETECTOR_NAMES)
    unknown = [m for m in methods if m not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    runs: dict[str, list[dict[str, Any]]] = {}
    errors: dict[str, list[dict[str, Any]]] = {}
    skipped: list[str] = []
    for seed in seeds:
        part = nm.split(x, y, seed)
        names = [f"f{i}" for i in range(x.shape[1])]
        train = pd.DataFrame(part["x_train"], columns=names)
        test = pd.DataFrame(part["x_test"], columns=names)
        prevalence = float(part["y_train"].mean())
        skip = nm.skipped_detectors(len(train))
        skipped = [m for m in methods if m in skip]
        for method in methods:
            if method in skip:
                continue
            try:
                row = run_method(method, train, test, part["y_test"], seed, prevalence)
            except Exception as error:  # a failing model is recorded, not hidden
                errors.setdefault(method, []).append({"seed": seed, "ERROR": repr(error)})
                continue
            runs.setdefault(method, []).append(row)
    return {"seeds": list(seeds), "runs": runs, "skipped": skipped, "errors": errors}


def x_run_problem__mutmut_68(
    x: np.ndarray,
    y: np.ndarray,
    seeds: tuple[int, ...] = config.BENCHMARK_SEEDS,
    methods: list[str] | None = None,
) -> dict[str, Any]:
    methods = methods or list(DETECTOR_NAMES)
    unknown = [m for m in methods if m not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    runs: dict[str, list[dict[str, Any]]] = {}
    errors: dict[str, list[dict[str, Any]]] = {}
    skipped: list[str] = []
    for seed in seeds:
        part = nm.split(x, y, seed)
        names = [f"f{i}" for i in range(x.shape[1])]
        train = pd.DataFrame(part["x_train"], columns=names)
        test = pd.DataFrame(part["x_test"], columns=names)
        prevalence = float(part["y_train"].mean())
        skip = nm.skipped_detectors(len(train))
        skipped = [m for m in methods if m in skip]
        for method in methods:
            if method in skip:
                continue
            try:
                row = run_method(method, train, test, part["y_test"], seed, prevalence)
            except Exception as error:  # a failing model is recorded, not hidden
                errors.setdefault(method, []).append({"seed": seed, "error": repr(None)})
                continue
            runs.setdefault(method, []).append(row)
    return {"seeds": list(seeds), "runs": runs, "skipped": skipped, "errors": errors}


def x_run_problem__mutmut_69(
    x: np.ndarray,
    y: np.ndarray,
    seeds: tuple[int, ...] = config.BENCHMARK_SEEDS,
    methods: list[str] | None = None,
) -> dict[str, Any]:
    methods = methods or list(DETECTOR_NAMES)
    unknown = [m for m in methods if m not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    runs: dict[str, list[dict[str, Any]]] = {}
    errors: dict[str, list[dict[str, Any]]] = {}
    skipped: list[str] = []
    for seed in seeds:
        part = nm.split(x, y, seed)
        names = [f"f{i}" for i in range(x.shape[1])]
        train = pd.DataFrame(part["x_train"], columns=names)
        test = pd.DataFrame(part["x_test"], columns=names)
        prevalence = float(part["y_train"].mean())
        skip = nm.skipped_detectors(len(train))
        skipped = [m for m in methods if m in skip]
        for method in methods:
            if method in skip:
                continue
            try:
                row = run_method(method, train, test, part["y_test"], seed, prevalence)
            except Exception as error:  # a failing model is recorded, not hidden
                errors.setdefault(method, []).append({"seed": seed, "error": repr(error)})
                break
            runs.setdefault(method, []).append(row)
    return {"seeds": list(seeds), "runs": runs, "skipped": skipped, "errors": errors}


def x_run_problem__mutmut_70(
    x: np.ndarray,
    y: np.ndarray,
    seeds: tuple[int, ...] = config.BENCHMARK_SEEDS,
    methods: list[str] | None = None,
) -> dict[str, Any]:
    methods = methods or list(DETECTOR_NAMES)
    unknown = [m for m in methods if m not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    runs: dict[str, list[dict[str, Any]]] = {}
    errors: dict[str, list[dict[str, Any]]] = {}
    skipped: list[str] = []
    for seed in seeds:
        part = nm.split(x, y, seed)
        names = [f"f{i}" for i in range(x.shape[1])]
        train = pd.DataFrame(part["x_train"], columns=names)
        test = pd.DataFrame(part["x_test"], columns=names)
        prevalence = float(part["y_train"].mean())
        skip = nm.skipped_detectors(len(train))
        skipped = [m for m in methods if m in skip]
        for method in methods:
            if method in skip:
                continue
            try:
                row = run_method(method, train, test, part["y_test"], seed, prevalence)
            except Exception as error:  # a failing model is recorded, not hidden
                errors.setdefault(method, []).append({"seed": seed, "error": repr(error)})
                continue
            runs.setdefault(method, []).append(None)
    return {"seeds": list(seeds), "runs": runs, "skipped": skipped, "errors": errors}


def x_run_problem__mutmut_71(
    x: np.ndarray,
    y: np.ndarray,
    seeds: tuple[int, ...] = config.BENCHMARK_SEEDS,
    methods: list[str] | None = None,
) -> dict[str, Any]:
    methods = methods or list(DETECTOR_NAMES)
    unknown = [m for m in methods if m not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    runs: dict[str, list[dict[str, Any]]] = {}
    errors: dict[str, list[dict[str, Any]]] = {}
    skipped: list[str] = []
    for seed in seeds:
        part = nm.split(x, y, seed)
        names = [f"f{i}" for i in range(x.shape[1])]
        train = pd.DataFrame(part["x_train"], columns=names)
        test = pd.DataFrame(part["x_test"], columns=names)
        prevalence = float(part["y_train"].mean())
        skip = nm.skipped_detectors(len(train))
        skipped = [m for m in methods if m in skip]
        for method in methods:
            if method in skip:
                continue
            try:
                row = run_method(method, train, test, part["y_test"], seed, prevalence)
            except Exception as error:  # a failing model is recorded, not hidden
                errors.setdefault(method, []).append({"seed": seed, "error": repr(error)})
                continue
            runs.setdefault(None, []).append(row)
    return {"seeds": list(seeds), "runs": runs, "skipped": skipped, "errors": errors}


def x_run_problem__mutmut_72(
    x: np.ndarray,
    y: np.ndarray,
    seeds: tuple[int, ...] = config.BENCHMARK_SEEDS,
    methods: list[str] | None = None,
) -> dict[str, Any]:
    methods = methods or list(DETECTOR_NAMES)
    unknown = [m for m in methods if m not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    runs: dict[str, list[dict[str, Any]]] = {}
    errors: dict[str, list[dict[str, Any]]] = {}
    skipped: list[str] = []
    for seed in seeds:
        part = nm.split(x, y, seed)
        names = [f"f{i}" for i in range(x.shape[1])]
        train = pd.DataFrame(part["x_train"], columns=names)
        test = pd.DataFrame(part["x_test"], columns=names)
        prevalence = float(part["y_train"].mean())
        skip = nm.skipped_detectors(len(train))
        skipped = [m for m in methods if m in skip]
        for method in methods:
            if method in skip:
                continue
            try:
                row = run_method(method, train, test, part["y_test"], seed, prevalence)
            except Exception as error:  # a failing model is recorded, not hidden
                errors.setdefault(method, []).append({"seed": seed, "error": repr(error)})
                continue
            runs.setdefault(method, None).append(row)
    return {"seeds": list(seeds), "runs": runs, "skipped": skipped, "errors": errors}


def x_run_problem__mutmut_73(
    x: np.ndarray,
    y: np.ndarray,
    seeds: tuple[int, ...] = config.BENCHMARK_SEEDS,
    methods: list[str] | None = None,
) -> dict[str, Any]:
    methods = methods or list(DETECTOR_NAMES)
    unknown = [m for m in methods if m not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    runs: dict[str, list[dict[str, Any]]] = {}
    errors: dict[str, list[dict[str, Any]]] = {}
    skipped: list[str] = []
    for seed in seeds:
        part = nm.split(x, y, seed)
        names = [f"f{i}" for i in range(x.shape[1])]
        train = pd.DataFrame(part["x_train"], columns=names)
        test = pd.DataFrame(part["x_test"], columns=names)
        prevalence = float(part["y_train"].mean())
        skip = nm.skipped_detectors(len(train))
        skipped = [m for m in methods if m in skip]
        for method in methods:
            if method in skip:
                continue
            try:
                row = run_method(method, train, test, part["y_test"], seed, prevalence)
            except Exception as error:  # a failing model is recorded, not hidden
                errors.setdefault(method, []).append({"seed": seed, "error": repr(error)})
                continue
            runs.setdefault([]).append(row)
    return {"seeds": list(seeds), "runs": runs, "skipped": skipped, "errors": errors}


def x_run_problem__mutmut_74(
    x: np.ndarray,
    y: np.ndarray,
    seeds: tuple[int, ...] = config.BENCHMARK_SEEDS,
    methods: list[str] | None = None,
) -> dict[str, Any]:
    methods = methods or list(DETECTOR_NAMES)
    unknown = [m for m in methods if m not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    runs: dict[str, list[dict[str, Any]]] = {}
    errors: dict[str, list[dict[str, Any]]] = {}
    skipped: list[str] = []
    for seed in seeds:
        part = nm.split(x, y, seed)
        names = [f"f{i}" for i in range(x.shape[1])]
        train = pd.DataFrame(part["x_train"], columns=names)
        test = pd.DataFrame(part["x_test"], columns=names)
        prevalence = float(part["y_train"].mean())
        skip = nm.skipped_detectors(len(train))
        skipped = [m for m in methods if m in skip]
        for method in methods:
            if method in skip:
                continue
            try:
                row = run_method(method, train, test, part["y_test"], seed, prevalence)
            except Exception as error:  # a failing model is recorded, not hidden
                errors.setdefault(method, []).append({"seed": seed, "error": repr(error)})
                continue
            runs.setdefault(method, ).append(row)
    return {"seeds": list(seeds), "runs": runs, "skipped": skipped, "errors": errors}


def x_run_problem__mutmut_75(
    x: np.ndarray,
    y: np.ndarray,
    seeds: tuple[int, ...] = config.BENCHMARK_SEEDS,
    methods: list[str] | None = None,
) -> dict[str, Any]:
    methods = methods or list(DETECTOR_NAMES)
    unknown = [m for m in methods if m not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    runs: dict[str, list[dict[str, Any]]] = {}
    errors: dict[str, list[dict[str, Any]]] = {}
    skipped: list[str] = []
    for seed in seeds:
        part = nm.split(x, y, seed)
        names = [f"f{i}" for i in range(x.shape[1])]
        train = pd.DataFrame(part["x_train"], columns=names)
        test = pd.DataFrame(part["x_test"], columns=names)
        prevalence = float(part["y_train"].mean())
        skip = nm.skipped_detectors(len(train))
        skipped = [m for m in methods if m in skip]
        for method in methods:
            if method in skip:
                continue
            try:
                row = run_method(method, train, test, part["y_test"], seed, prevalence)
            except Exception as error:  # a failing model is recorded, not hidden
                errors.setdefault(method, []).append({"seed": seed, "error": repr(error)})
                continue
            runs.setdefault(method, []).append(row)
    return {"XXseedsXX": list(seeds), "runs": runs, "skipped": skipped, "errors": errors}


def x_run_problem__mutmut_76(
    x: np.ndarray,
    y: np.ndarray,
    seeds: tuple[int, ...] = config.BENCHMARK_SEEDS,
    methods: list[str] | None = None,
) -> dict[str, Any]:
    methods = methods or list(DETECTOR_NAMES)
    unknown = [m for m in methods if m not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    runs: dict[str, list[dict[str, Any]]] = {}
    errors: dict[str, list[dict[str, Any]]] = {}
    skipped: list[str] = []
    for seed in seeds:
        part = nm.split(x, y, seed)
        names = [f"f{i}" for i in range(x.shape[1])]
        train = pd.DataFrame(part["x_train"], columns=names)
        test = pd.DataFrame(part["x_test"], columns=names)
        prevalence = float(part["y_train"].mean())
        skip = nm.skipped_detectors(len(train))
        skipped = [m for m in methods if m in skip]
        for method in methods:
            if method in skip:
                continue
            try:
                row = run_method(method, train, test, part["y_test"], seed, prevalence)
            except Exception as error:  # a failing model is recorded, not hidden
                errors.setdefault(method, []).append({"seed": seed, "error": repr(error)})
                continue
            runs.setdefault(method, []).append(row)
    return {"SEEDS": list(seeds), "runs": runs, "skipped": skipped, "errors": errors}


def x_run_problem__mutmut_77(
    x: np.ndarray,
    y: np.ndarray,
    seeds: tuple[int, ...] = config.BENCHMARK_SEEDS,
    methods: list[str] | None = None,
) -> dict[str, Any]:
    methods = methods or list(DETECTOR_NAMES)
    unknown = [m for m in methods if m not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    runs: dict[str, list[dict[str, Any]]] = {}
    errors: dict[str, list[dict[str, Any]]] = {}
    skipped: list[str] = []
    for seed in seeds:
        part = nm.split(x, y, seed)
        names = [f"f{i}" for i in range(x.shape[1])]
        train = pd.DataFrame(part["x_train"], columns=names)
        test = pd.DataFrame(part["x_test"], columns=names)
        prevalence = float(part["y_train"].mean())
        skip = nm.skipped_detectors(len(train))
        skipped = [m for m in methods if m in skip]
        for method in methods:
            if method in skip:
                continue
            try:
                row = run_method(method, train, test, part["y_test"], seed, prevalence)
            except Exception as error:  # a failing model is recorded, not hidden
                errors.setdefault(method, []).append({"seed": seed, "error": repr(error)})
                continue
            runs.setdefault(method, []).append(row)
    return {"seeds": list(None), "runs": runs, "skipped": skipped, "errors": errors}


def x_run_problem__mutmut_78(
    x: np.ndarray,
    y: np.ndarray,
    seeds: tuple[int, ...] = config.BENCHMARK_SEEDS,
    methods: list[str] | None = None,
) -> dict[str, Any]:
    methods = methods or list(DETECTOR_NAMES)
    unknown = [m for m in methods if m not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    runs: dict[str, list[dict[str, Any]]] = {}
    errors: dict[str, list[dict[str, Any]]] = {}
    skipped: list[str] = []
    for seed in seeds:
        part = nm.split(x, y, seed)
        names = [f"f{i}" for i in range(x.shape[1])]
        train = pd.DataFrame(part["x_train"], columns=names)
        test = pd.DataFrame(part["x_test"], columns=names)
        prevalence = float(part["y_train"].mean())
        skip = nm.skipped_detectors(len(train))
        skipped = [m for m in methods if m in skip]
        for method in methods:
            if method in skip:
                continue
            try:
                row = run_method(method, train, test, part["y_test"], seed, prevalence)
            except Exception as error:  # a failing model is recorded, not hidden
                errors.setdefault(method, []).append({"seed": seed, "error": repr(error)})
                continue
            runs.setdefault(method, []).append(row)
    return {"seeds": list(seeds), "XXrunsXX": runs, "skipped": skipped, "errors": errors}


def x_run_problem__mutmut_79(
    x: np.ndarray,
    y: np.ndarray,
    seeds: tuple[int, ...] = config.BENCHMARK_SEEDS,
    methods: list[str] | None = None,
) -> dict[str, Any]:
    methods = methods or list(DETECTOR_NAMES)
    unknown = [m for m in methods if m not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    runs: dict[str, list[dict[str, Any]]] = {}
    errors: dict[str, list[dict[str, Any]]] = {}
    skipped: list[str] = []
    for seed in seeds:
        part = nm.split(x, y, seed)
        names = [f"f{i}" for i in range(x.shape[1])]
        train = pd.DataFrame(part["x_train"], columns=names)
        test = pd.DataFrame(part["x_test"], columns=names)
        prevalence = float(part["y_train"].mean())
        skip = nm.skipped_detectors(len(train))
        skipped = [m for m in methods if m in skip]
        for method in methods:
            if method in skip:
                continue
            try:
                row = run_method(method, train, test, part["y_test"], seed, prevalence)
            except Exception as error:  # a failing model is recorded, not hidden
                errors.setdefault(method, []).append({"seed": seed, "error": repr(error)})
                continue
            runs.setdefault(method, []).append(row)
    return {"seeds": list(seeds), "RUNS": runs, "skipped": skipped, "errors": errors}


def x_run_problem__mutmut_80(
    x: np.ndarray,
    y: np.ndarray,
    seeds: tuple[int, ...] = config.BENCHMARK_SEEDS,
    methods: list[str] | None = None,
) -> dict[str, Any]:
    methods = methods or list(DETECTOR_NAMES)
    unknown = [m for m in methods if m not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    runs: dict[str, list[dict[str, Any]]] = {}
    errors: dict[str, list[dict[str, Any]]] = {}
    skipped: list[str] = []
    for seed in seeds:
        part = nm.split(x, y, seed)
        names = [f"f{i}" for i in range(x.shape[1])]
        train = pd.DataFrame(part["x_train"], columns=names)
        test = pd.DataFrame(part["x_test"], columns=names)
        prevalence = float(part["y_train"].mean())
        skip = nm.skipped_detectors(len(train))
        skipped = [m for m in methods if m in skip]
        for method in methods:
            if method in skip:
                continue
            try:
                row = run_method(method, train, test, part["y_test"], seed, prevalence)
            except Exception as error:  # a failing model is recorded, not hidden
                errors.setdefault(method, []).append({"seed": seed, "error": repr(error)})
                continue
            runs.setdefault(method, []).append(row)
    return {"seeds": list(seeds), "runs": runs, "XXskippedXX": skipped, "errors": errors}


def x_run_problem__mutmut_81(
    x: np.ndarray,
    y: np.ndarray,
    seeds: tuple[int, ...] = config.BENCHMARK_SEEDS,
    methods: list[str] | None = None,
) -> dict[str, Any]:
    methods = methods or list(DETECTOR_NAMES)
    unknown = [m for m in methods if m not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    runs: dict[str, list[dict[str, Any]]] = {}
    errors: dict[str, list[dict[str, Any]]] = {}
    skipped: list[str] = []
    for seed in seeds:
        part = nm.split(x, y, seed)
        names = [f"f{i}" for i in range(x.shape[1])]
        train = pd.DataFrame(part["x_train"], columns=names)
        test = pd.DataFrame(part["x_test"], columns=names)
        prevalence = float(part["y_train"].mean())
        skip = nm.skipped_detectors(len(train))
        skipped = [m for m in methods if m in skip]
        for method in methods:
            if method in skip:
                continue
            try:
                row = run_method(method, train, test, part["y_test"], seed, prevalence)
            except Exception as error:  # a failing model is recorded, not hidden
                errors.setdefault(method, []).append({"seed": seed, "error": repr(error)})
                continue
            runs.setdefault(method, []).append(row)
    return {"seeds": list(seeds), "runs": runs, "SKIPPED": skipped, "errors": errors}


def x_run_problem__mutmut_82(
    x: np.ndarray,
    y: np.ndarray,
    seeds: tuple[int, ...] = config.BENCHMARK_SEEDS,
    methods: list[str] | None = None,
) -> dict[str, Any]:
    methods = methods or list(DETECTOR_NAMES)
    unknown = [m for m in methods if m not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    runs: dict[str, list[dict[str, Any]]] = {}
    errors: dict[str, list[dict[str, Any]]] = {}
    skipped: list[str] = []
    for seed in seeds:
        part = nm.split(x, y, seed)
        names = [f"f{i}" for i in range(x.shape[1])]
        train = pd.DataFrame(part["x_train"], columns=names)
        test = pd.DataFrame(part["x_test"], columns=names)
        prevalence = float(part["y_train"].mean())
        skip = nm.skipped_detectors(len(train))
        skipped = [m for m in methods if m in skip]
        for method in methods:
            if method in skip:
                continue
            try:
                row = run_method(method, train, test, part["y_test"], seed, prevalence)
            except Exception as error:  # a failing model is recorded, not hidden
                errors.setdefault(method, []).append({"seed": seed, "error": repr(error)})
                continue
            runs.setdefault(method, []).append(row)
    return {"seeds": list(seeds), "runs": runs, "skipped": skipped, "XXerrorsXX": errors}


def x_run_problem__mutmut_83(
    x: np.ndarray,
    y: np.ndarray,
    seeds: tuple[int, ...] = config.BENCHMARK_SEEDS,
    methods: list[str] | None = None,
) -> dict[str, Any]:
    methods = methods or list(DETECTOR_NAMES)
    unknown = [m for m in methods if m not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    runs: dict[str, list[dict[str, Any]]] = {}
    errors: dict[str, list[dict[str, Any]]] = {}
    skipped: list[str] = []
    for seed in seeds:
        part = nm.split(x, y, seed)
        names = [f"f{i}" for i in range(x.shape[1])]
        train = pd.DataFrame(part["x_train"], columns=names)
        test = pd.DataFrame(part["x_test"], columns=names)
        prevalence = float(part["y_train"].mean())
        skip = nm.skipped_detectors(len(train))
        skipped = [m for m in methods if m in skip]
        for method in methods:
            if method in skip:
                continue
            try:
                row = run_method(method, train, test, part["y_test"], seed, prevalence)
            except Exception as error:  # a failing model is recorded, not hidden
                errors.setdefault(method, []).append({"seed": seed, "error": repr(error)})
                continue
            runs.setdefault(method, []).append(row)
    return {"seeds": list(seeds), "runs": runs, "skipped": skipped, "ERRORS": errors}

mutants_x_run_problem__mutmut['_mutmut_orig'] = x_run_problem__mutmut_orig # type: ignore # mutmut generated
mutants_x_run_problem__mutmut['x_run_problem__mutmut_1'] = x_run_problem__mutmut_1 # type: ignore # mutmut generated
mutants_x_run_problem__mutmut['x_run_problem__mutmut_2'] = x_run_problem__mutmut_2 # type: ignore # mutmut generated
mutants_x_run_problem__mutmut['x_run_problem__mutmut_3'] = x_run_problem__mutmut_3 # type: ignore # mutmut generated
mutants_x_run_problem__mutmut['x_run_problem__mutmut_4'] = x_run_problem__mutmut_4 # type: ignore # mutmut generated
mutants_x_run_problem__mutmut['x_run_problem__mutmut_5'] = x_run_problem__mutmut_5 # type: ignore # mutmut generated
mutants_x_run_problem__mutmut['x_run_problem__mutmut_6'] = x_run_problem__mutmut_6 # type: ignore # mutmut generated
mutants_x_run_problem__mutmut['x_run_problem__mutmut_7'] = x_run_problem__mutmut_7 # type: ignore # mutmut generated
mutants_x_run_problem__mutmut['x_run_problem__mutmut_8'] = x_run_problem__mutmut_8 # type: ignore # mutmut generated
mutants_x_run_problem__mutmut['x_run_problem__mutmut_9'] = x_run_problem__mutmut_9 # type: ignore # mutmut generated
mutants_x_run_problem__mutmut['x_run_problem__mutmut_10'] = x_run_problem__mutmut_10 # type: ignore # mutmut generated
mutants_x_run_problem__mutmut['x_run_problem__mutmut_11'] = x_run_problem__mutmut_11 # type: ignore # mutmut generated
mutants_x_run_problem__mutmut['x_run_problem__mutmut_12'] = x_run_problem__mutmut_12 # type: ignore # mutmut generated
mutants_x_run_problem__mutmut['x_run_problem__mutmut_13'] = x_run_problem__mutmut_13 # type: ignore # mutmut generated
mutants_x_run_problem__mutmut['x_run_problem__mutmut_14'] = x_run_problem__mutmut_14 # type: ignore # mutmut generated
mutants_x_run_problem__mutmut['x_run_problem__mutmut_15'] = x_run_problem__mutmut_15 # type: ignore # mutmut generated
mutants_x_run_problem__mutmut['x_run_problem__mutmut_16'] = x_run_problem__mutmut_16 # type: ignore # mutmut generated
mutants_x_run_problem__mutmut['x_run_problem__mutmut_17'] = x_run_problem__mutmut_17 # type: ignore # mutmut generated
mutants_x_run_problem__mutmut['x_run_problem__mutmut_18'] = x_run_problem__mutmut_18 # type: ignore # mutmut generated
mutants_x_run_problem__mutmut['x_run_problem__mutmut_19'] = x_run_problem__mutmut_19 # type: ignore # mutmut generated
mutants_x_run_problem__mutmut['x_run_problem__mutmut_20'] = x_run_problem__mutmut_20 # type: ignore # mutmut generated
mutants_x_run_problem__mutmut['x_run_problem__mutmut_21'] = x_run_problem__mutmut_21 # type: ignore # mutmut generated
mutants_x_run_problem__mutmut['x_run_problem__mutmut_22'] = x_run_problem__mutmut_22 # type: ignore # mutmut generated
mutants_x_run_problem__mutmut['x_run_problem__mutmut_23'] = x_run_problem__mutmut_23 # type: ignore # mutmut generated
mutants_x_run_problem__mutmut['x_run_problem__mutmut_24'] = x_run_problem__mutmut_24 # type: ignore # mutmut generated
mutants_x_run_problem__mutmut['x_run_problem__mutmut_25'] = x_run_problem__mutmut_25 # type: ignore # mutmut generated
mutants_x_run_problem__mutmut['x_run_problem__mutmut_26'] = x_run_problem__mutmut_26 # type: ignore # mutmut generated
mutants_x_run_problem__mutmut['x_run_problem__mutmut_27'] = x_run_problem__mutmut_27 # type: ignore # mutmut generated
mutants_x_run_problem__mutmut['x_run_problem__mutmut_28'] = x_run_problem__mutmut_28 # type: ignore # mutmut generated
mutants_x_run_problem__mutmut['x_run_problem__mutmut_29'] = x_run_problem__mutmut_29 # type: ignore # mutmut generated
mutants_x_run_problem__mutmut['x_run_problem__mutmut_30'] = x_run_problem__mutmut_30 # type: ignore # mutmut generated
mutants_x_run_problem__mutmut['x_run_problem__mutmut_31'] = x_run_problem__mutmut_31 # type: ignore # mutmut generated
mutants_x_run_problem__mutmut['x_run_problem__mutmut_32'] = x_run_problem__mutmut_32 # type: ignore # mutmut generated
mutants_x_run_problem__mutmut['x_run_problem__mutmut_33'] = x_run_problem__mutmut_33 # type: ignore # mutmut generated
mutants_x_run_problem__mutmut['x_run_problem__mutmut_34'] = x_run_problem__mutmut_34 # type: ignore # mutmut generated
mutants_x_run_problem__mutmut['x_run_problem__mutmut_35'] = x_run_problem__mutmut_35 # type: ignore # mutmut generated
mutants_x_run_problem__mutmut['x_run_problem__mutmut_36'] = x_run_problem__mutmut_36 # type: ignore # mutmut generated
mutants_x_run_problem__mutmut['x_run_problem__mutmut_37'] = x_run_problem__mutmut_37 # type: ignore # mutmut generated
mutants_x_run_problem__mutmut['x_run_problem__mutmut_38'] = x_run_problem__mutmut_38 # type: ignore # mutmut generated
mutants_x_run_problem__mutmut['x_run_problem__mutmut_39'] = x_run_problem__mutmut_39 # type: ignore # mutmut generated
mutants_x_run_problem__mutmut['x_run_problem__mutmut_40'] = x_run_problem__mutmut_40 # type: ignore # mutmut generated
mutants_x_run_problem__mutmut['x_run_problem__mutmut_41'] = x_run_problem__mutmut_41 # type: ignore # mutmut generated
mutants_x_run_problem__mutmut['x_run_problem__mutmut_42'] = x_run_problem__mutmut_42 # type: ignore # mutmut generated
mutants_x_run_problem__mutmut['x_run_problem__mutmut_43'] = x_run_problem__mutmut_43 # type: ignore # mutmut generated
mutants_x_run_problem__mutmut['x_run_problem__mutmut_44'] = x_run_problem__mutmut_44 # type: ignore # mutmut generated
mutants_x_run_problem__mutmut['x_run_problem__mutmut_45'] = x_run_problem__mutmut_45 # type: ignore # mutmut generated
mutants_x_run_problem__mutmut['x_run_problem__mutmut_46'] = x_run_problem__mutmut_46 # type: ignore # mutmut generated
mutants_x_run_problem__mutmut['x_run_problem__mutmut_47'] = x_run_problem__mutmut_47 # type: ignore # mutmut generated
mutants_x_run_problem__mutmut['x_run_problem__mutmut_48'] = x_run_problem__mutmut_48 # type: ignore # mutmut generated
mutants_x_run_problem__mutmut['x_run_problem__mutmut_49'] = x_run_problem__mutmut_49 # type: ignore # mutmut generated
mutants_x_run_problem__mutmut['x_run_problem__mutmut_50'] = x_run_problem__mutmut_50 # type: ignore # mutmut generated
mutants_x_run_problem__mutmut['x_run_problem__mutmut_51'] = x_run_problem__mutmut_51 # type: ignore # mutmut generated
mutants_x_run_problem__mutmut['x_run_problem__mutmut_52'] = x_run_problem__mutmut_52 # type: ignore # mutmut generated
mutants_x_run_problem__mutmut['x_run_problem__mutmut_53'] = x_run_problem__mutmut_53 # type: ignore # mutmut generated
mutants_x_run_problem__mutmut['x_run_problem__mutmut_54'] = x_run_problem__mutmut_54 # type: ignore # mutmut generated
mutants_x_run_problem__mutmut['x_run_problem__mutmut_55'] = x_run_problem__mutmut_55 # type: ignore # mutmut generated
mutants_x_run_problem__mutmut['x_run_problem__mutmut_56'] = x_run_problem__mutmut_56 # type: ignore # mutmut generated
mutants_x_run_problem__mutmut['x_run_problem__mutmut_57'] = x_run_problem__mutmut_57 # type: ignore # mutmut generated
mutants_x_run_problem__mutmut['x_run_problem__mutmut_58'] = x_run_problem__mutmut_58 # type: ignore # mutmut generated
mutants_x_run_problem__mutmut['x_run_problem__mutmut_59'] = x_run_problem__mutmut_59 # type: ignore # mutmut generated
mutants_x_run_problem__mutmut['x_run_problem__mutmut_60'] = x_run_problem__mutmut_60 # type: ignore # mutmut generated
mutants_x_run_problem__mutmut['x_run_problem__mutmut_61'] = x_run_problem__mutmut_61 # type: ignore # mutmut generated
mutants_x_run_problem__mutmut['x_run_problem__mutmut_62'] = x_run_problem__mutmut_62 # type: ignore # mutmut generated
mutants_x_run_problem__mutmut['x_run_problem__mutmut_63'] = x_run_problem__mutmut_63 # type: ignore # mutmut generated
mutants_x_run_problem__mutmut['x_run_problem__mutmut_64'] = x_run_problem__mutmut_64 # type: ignore # mutmut generated
mutants_x_run_problem__mutmut['x_run_problem__mutmut_65'] = x_run_problem__mutmut_65 # type: ignore # mutmut generated
mutants_x_run_problem__mutmut['x_run_problem__mutmut_66'] = x_run_problem__mutmut_66 # type: ignore # mutmut generated
mutants_x_run_problem__mutmut['x_run_problem__mutmut_67'] = x_run_problem__mutmut_67 # type: ignore # mutmut generated
mutants_x_run_problem__mutmut['x_run_problem__mutmut_68'] = x_run_problem__mutmut_68 # type: ignore # mutmut generated
mutants_x_run_problem__mutmut['x_run_problem__mutmut_69'] = x_run_problem__mutmut_69 # type: ignore # mutmut generated
mutants_x_run_problem__mutmut['x_run_problem__mutmut_70'] = x_run_problem__mutmut_70 # type: ignore # mutmut generated
mutants_x_run_problem__mutmut['x_run_problem__mutmut_71'] = x_run_problem__mutmut_71 # type: ignore # mutmut generated
mutants_x_run_problem__mutmut['x_run_problem__mutmut_72'] = x_run_problem__mutmut_72 # type: ignore # mutmut generated
mutants_x_run_problem__mutmut['x_run_problem__mutmut_73'] = x_run_problem__mutmut_73 # type: ignore # mutmut generated
mutants_x_run_problem__mutmut['x_run_problem__mutmut_74'] = x_run_problem__mutmut_74 # type: ignore # mutmut generated
mutants_x_run_problem__mutmut['x_run_problem__mutmut_75'] = x_run_problem__mutmut_75 # type: ignore # mutmut generated
mutants_x_run_problem__mutmut['x_run_problem__mutmut_76'] = x_run_problem__mutmut_76 # type: ignore # mutmut generated
mutants_x_run_problem__mutmut['x_run_problem__mutmut_77'] = x_run_problem__mutmut_77 # type: ignore # mutmut generated
mutants_x_run_problem__mutmut['x_run_problem__mutmut_78'] = x_run_problem__mutmut_78 # type: ignore # mutmut generated
mutants_x_run_problem__mutmut['x_run_problem__mutmut_79'] = x_run_problem__mutmut_79 # type: ignore # mutmut generated
mutants_x_run_problem__mutmut['x_run_problem__mutmut_80'] = x_run_problem__mutmut_80 # type: ignore # mutmut generated
mutants_x_run_problem__mutmut['x_run_problem__mutmut_81'] = x_run_problem__mutmut_81 # type: ignore # mutmut generated
mutants_x_run_problem__mutmut['x_run_problem__mutmut_82'] = x_run_problem__mutmut_82 # type: ignore # mutmut generated
mutants_x_run_problem__mutmut['x_run_problem__mutmut_83'] = x_run_problem__mutmut_83 # type: ignore # mutmut generated
mutants_x_run_job__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_run_job__mutmut)
def run_job(job: dict[str, Any], methods: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    try:
        if job["source"] == "adbench":
            x, y, report = lb.load_adbench(job["name"], Path(job["path"]))
        else:
            x, y, report = lb.load_uci(job["meta"], Path(job["path"]))
        result = run_problem(x, y, methods=methods)
    except Exception as error:  # recorded, never dropped silently
        return {"problem": job["problem"], "source": job["source"], "failed": repr(error)}
    return {
        "problem": job["problem"],
        "source": job["source"],
        "name": report["name"],
        "prevalence": float(y.mean()),
        "rows": int(len(y)),
        "features": int(x.shape[1]),
        **result,
    }


def x_run_job__mutmut_orig(job: dict[str, Any], methods: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    try:
        if job["source"] == "adbench":
            x, y, report = lb.load_adbench(job["name"], Path(job["path"]))
        else:
            x, y, report = lb.load_uci(job["meta"], Path(job["path"]))
        result = run_problem(x, y, methods=methods)
    except Exception as error:  # recorded, never dropped silently
        return {"problem": job["problem"], "source": job["source"], "failed": repr(error)}
    return {
        "problem": job["problem"],
        "source": job["source"],
        "name": report["name"],
        "prevalence": float(y.mean()),
        "rows": int(len(y)),
        "features": int(x.shape[1]),
        **result,
    }


def x_run_job__mutmut_1(job: dict[str, Any], methods: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings(None)
    try:
        if job["source"] == "adbench":
            x, y, report = lb.load_adbench(job["name"], Path(job["path"]))
        else:
            x, y, report = lb.load_uci(job["meta"], Path(job["path"]))
        result = run_problem(x, y, methods=methods)
    except Exception as error:  # recorded, never dropped silently
        return {"problem": job["problem"], "source": job["source"], "failed": repr(error)}
    return {
        "problem": job["problem"],
        "source": job["source"],
        "name": report["name"],
        "prevalence": float(y.mean()),
        "rows": int(len(y)),
        "features": int(x.shape[1]),
        **result,
    }


def x_run_job__mutmut_2(job: dict[str, Any], methods: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("XXignoreXX")
    try:
        if job["source"] == "adbench":
            x, y, report = lb.load_adbench(job["name"], Path(job["path"]))
        else:
            x, y, report = lb.load_uci(job["meta"], Path(job["path"]))
        result = run_problem(x, y, methods=methods)
    except Exception as error:  # recorded, never dropped silently
        return {"problem": job["problem"], "source": job["source"], "failed": repr(error)}
    return {
        "problem": job["problem"],
        "source": job["source"],
        "name": report["name"],
        "prevalence": float(y.mean()),
        "rows": int(len(y)),
        "features": int(x.shape[1]),
        **result,
    }


def x_run_job__mutmut_3(job: dict[str, Any], methods: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("IGNORE")
    try:
        if job["source"] == "adbench":
            x, y, report = lb.load_adbench(job["name"], Path(job["path"]))
        else:
            x, y, report = lb.load_uci(job["meta"], Path(job["path"]))
        result = run_problem(x, y, methods=methods)
    except Exception as error:  # recorded, never dropped silently
        return {"problem": job["problem"], "source": job["source"], "failed": repr(error)}
    return {
        "problem": job["problem"],
        "source": job["source"],
        "name": report["name"],
        "prevalence": float(y.mean()),
        "rows": int(len(y)),
        "features": int(x.shape[1]),
        **result,
    }


def x_run_job__mutmut_4(job: dict[str, Any], methods: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    try:
        if job["XXsourceXX"] == "adbench":
            x, y, report = lb.load_adbench(job["name"], Path(job["path"]))
        else:
            x, y, report = lb.load_uci(job["meta"], Path(job["path"]))
        result = run_problem(x, y, methods=methods)
    except Exception as error:  # recorded, never dropped silently
        return {"problem": job["problem"], "source": job["source"], "failed": repr(error)}
    return {
        "problem": job["problem"],
        "source": job["source"],
        "name": report["name"],
        "prevalence": float(y.mean()),
        "rows": int(len(y)),
        "features": int(x.shape[1]),
        **result,
    }


def x_run_job__mutmut_5(job: dict[str, Any], methods: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    try:
        if job["SOURCE"] == "adbench":
            x, y, report = lb.load_adbench(job["name"], Path(job["path"]))
        else:
            x, y, report = lb.load_uci(job["meta"], Path(job["path"]))
        result = run_problem(x, y, methods=methods)
    except Exception as error:  # recorded, never dropped silently
        return {"problem": job["problem"], "source": job["source"], "failed": repr(error)}
    return {
        "problem": job["problem"],
        "source": job["source"],
        "name": report["name"],
        "prevalence": float(y.mean()),
        "rows": int(len(y)),
        "features": int(x.shape[1]),
        **result,
    }


def x_run_job__mutmut_6(job: dict[str, Any], methods: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    try:
        if job["source"] != "adbench":
            x, y, report = lb.load_adbench(job["name"], Path(job["path"]))
        else:
            x, y, report = lb.load_uci(job["meta"], Path(job["path"]))
        result = run_problem(x, y, methods=methods)
    except Exception as error:  # recorded, never dropped silently
        return {"problem": job["problem"], "source": job["source"], "failed": repr(error)}
    return {
        "problem": job["problem"],
        "source": job["source"],
        "name": report["name"],
        "prevalence": float(y.mean()),
        "rows": int(len(y)),
        "features": int(x.shape[1]),
        **result,
    }


def x_run_job__mutmut_7(job: dict[str, Any], methods: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    try:
        if job["source"] == "XXadbenchXX":
            x, y, report = lb.load_adbench(job["name"], Path(job["path"]))
        else:
            x, y, report = lb.load_uci(job["meta"], Path(job["path"]))
        result = run_problem(x, y, methods=methods)
    except Exception as error:  # recorded, never dropped silently
        return {"problem": job["problem"], "source": job["source"], "failed": repr(error)}
    return {
        "problem": job["problem"],
        "source": job["source"],
        "name": report["name"],
        "prevalence": float(y.mean()),
        "rows": int(len(y)),
        "features": int(x.shape[1]),
        **result,
    }


def x_run_job__mutmut_8(job: dict[str, Any], methods: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    try:
        if job["source"] == "ADBENCH":
            x, y, report = lb.load_adbench(job["name"], Path(job["path"]))
        else:
            x, y, report = lb.load_uci(job["meta"], Path(job["path"]))
        result = run_problem(x, y, methods=methods)
    except Exception as error:  # recorded, never dropped silently
        return {"problem": job["problem"], "source": job["source"], "failed": repr(error)}
    return {
        "problem": job["problem"],
        "source": job["source"],
        "name": report["name"],
        "prevalence": float(y.mean()),
        "rows": int(len(y)),
        "features": int(x.shape[1]),
        **result,
    }


def x_run_job__mutmut_9(job: dict[str, Any], methods: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    try:
        if job["source"] == "adbench":
            x, y, report = None
        else:
            x, y, report = lb.load_uci(job["meta"], Path(job["path"]))
        result = run_problem(x, y, methods=methods)
    except Exception as error:  # recorded, never dropped silently
        return {"problem": job["problem"], "source": job["source"], "failed": repr(error)}
    return {
        "problem": job["problem"],
        "source": job["source"],
        "name": report["name"],
        "prevalence": float(y.mean()),
        "rows": int(len(y)),
        "features": int(x.shape[1]),
        **result,
    }


def x_run_job__mutmut_10(job: dict[str, Any], methods: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    try:
        if job["source"] == "adbench":
            x, y, report = lb.load_adbench(None, Path(job["path"]))
        else:
            x, y, report = lb.load_uci(job["meta"], Path(job["path"]))
        result = run_problem(x, y, methods=methods)
    except Exception as error:  # recorded, never dropped silently
        return {"problem": job["problem"], "source": job["source"], "failed": repr(error)}
    return {
        "problem": job["problem"],
        "source": job["source"],
        "name": report["name"],
        "prevalence": float(y.mean()),
        "rows": int(len(y)),
        "features": int(x.shape[1]),
        **result,
    }


def x_run_job__mutmut_11(job: dict[str, Any], methods: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    try:
        if job["source"] == "adbench":
            x, y, report = lb.load_adbench(job["name"], None)
        else:
            x, y, report = lb.load_uci(job["meta"], Path(job["path"]))
        result = run_problem(x, y, methods=methods)
    except Exception as error:  # recorded, never dropped silently
        return {"problem": job["problem"], "source": job["source"], "failed": repr(error)}
    return {
        "problem": job["problem"],
        "source": job["source"],
        "name": report["name"],
        "prevalence": float(y.mean()),
        "rows": int(len(y)),
        "features": int(x.shape[1]),
        **result,
    }


def x_run_job__mutmut_12(job: dict[str, Any], methods: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    try:
        if job["source"] == "adbench":
            x, y, report = lb.load_adbench(Path(job["path"]))
        else:
            x, y, report = lb.load_uci(job["meta"], Path(job["path"]))
        result = run_problem(x, y, methods=methods)
    except Exception as error:  # recorded, never dropped silently
        return {"problem": job["problem"], "source": job["source"], "failed": repr(error)}
    return {
        "problem": job["problem"],
        "source": job["source"],
        "name": report["name"],
        "prevalence": float(y.mean()),
        "rows": int(len(y)),
        "features": int(x.shape[1]),
        **result,
    }


def x_run_job__mutmut_13(job: dict[str, Any], methods: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    try:
        if job["source"] == "adbench":
            x, y, report = lb.load_adbench(job["name"], )
        else:
            x, y, report = lb.load_uci(job["meta"], Path(job["path"]))
        result = run_problem(x, y, methods=methods)
    except Exception as error:  # recorded, never dropped silently
        return {"problem": job["problem"], "source": job["source"], "failed": repr(error)}
    return {
        "problem": job["problem"],
        "source": job["source"],
        "name": report["name"],
        "prevalence": float(y.mean()),
        "rows": int(len(y)),
        "features": int(x.shape[1]),
        **result,
    }


def x_run_job__mutmut_14(job: dict[str, Any], methods: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    try:
        if job["source"] == "adbench":
            x, y, report = lb.load_adbench(job["XXnameXX"], Path(job["path"]))
        else:
            x, y, report = lb.load_uci(job["meta"], Path(job["path"]))
        result = run_problem(x, y, methods=methods)
    except Exception as error:  # recorded, never dropped silently
        return {"problem": job["problem"], "source": job["source"], "failed": repr(error)}
    return {
        "problem": job["problem"],
        "source": job["source"],
        "name": report["name"],
        "prevalence": float(y.mean()),
        "rows": int(len(y)),
        "features": int(x.shape[1]),
        **result,
    }


def x_run_job__mutmut_15(job: dict[str, Any], methods: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    try:
        if job["source"] == "adbench":
            x, y, report = lb.load_adbench(job["NAME"], Path(job["path"]))
        else:
            x, y, report = lb.load_uci(job["meta"], Path(job["path"]))
        result = run_problem(x, y, methods=methods)
    except Exception as error:  # recorded, never dropped silently
        return {"problem": job["problem"], "source": job["source"], "failed": repr(error)}
    return {
        "problem": job["problem"],
        "source": job["source"],
        "name": report["name"],
        "prevalence": float(y.mean()),
        "rows": int(len(y)),
        "features": int(x.shape[1]),
        **result,
    }


def x_run_job__mutmut_16(job: dict[str, Any], methods: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    try:
        if job["source"] == "adbench":
            x, y, report = lb.load_adbench(job["name"], Path(None))
        else:
            x, y, report = lb.load_uci(job["meta"], Path(job["path"]))
        result = run_problem(x, y, methods=methods)
    except Exception as error:  # recorded, never dropped silently
        return {"problem": job["problem"], "source": job["source"], "failed": repr(error)}
    return {
        "problem": job["problem"],
        "source": job["source"],
        "name": report["name"],
        "prevalence": float(y.mean()),
        "rows": int(len(y)),
        "features": int(x.shape[1]),
        **result,
    }


def x_run_job__mutmut_17(job: dict[str, Any], methods: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    try:
        if job["source"] == "adbench":
            x, y, report = lb.load_adbench(job["name"], Path(job["XXpathXX"]))
        else:
            x, y, report = lb.load_uci(job["meta"], Path(job["path"]))
        result = run_problem(x, y, methods=methods)
    except Exception as error:  # recorded, never dropped silently
        return {"problem": job["problem"], "source": job["source"], "failed": repr(error)}
    return {
        "problem": job["problem"],
        "source": job["source"],
        "name": report["name"],
        "prevalence": float(y.mean()),
        "rows": int(len(y)),
        "features": int(x.shape[1]),
        **result,
    }


def x_run_job__mutmut_18(job: dict[str, Any], methods: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    try:
        if job["source"] == "adbench":
            x, y, report = lb.load_adbench(job["name"], Path(job["PATH"]))
        else:
            x, y, report = lb.load_uci(job["meta"], Path(job["path"]))
        result = run_problem(x, y, methods=methods)
    except Exception as error:  # recorded, never dropped silently
        return {"problem": job["problem"], "source": job["source"], "failed": repr(error)}
    return {
        "problem": job["problem"],
        "source": job["source"],
        "name": report["name"],
        "prevalence": float(y.mean()),
        "rows": int(len(y)),
        "features": int(x.shape[1]),
        **result,
    }


def x_run_job__mutmut_19(job: dict[str, Any], methods: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    try:
        if job["source"] == "adbench":
            x, y, report = lb.load_adbench(job["name"], Path(job["path"]))
        else:
            x, y, report = None
        result = run_problem(x, y, methods=methods)
    except Exception as error:  # recorded, never dropped silently
        return {"problem": job["problem"], "source": job["source"], "failed": repr(error)}
    return {
        "problem": job["problem"],
        "source": job["source"],
        "name": report["name"],
        "prevalence": float(y.mean()),
        "rows": int(len(y)),
        "features": int(x.shape[1]),
        **result,
    }


def x_run_job__mutmut_20(job: dict[str, Any], methods: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    try:
        if job["source"] == "adbench":
            x, y, report = lb.load_adbench(job["name"], Path(job["path"]))
        else:
            x, y, report = lb.load_uci(None, Path(job["path"]))
        result = run_problem(x, y, methods=methods)
    except Exception as error:  # recorded, never dropped silently
        return {"problem": job["problem"], "source": job["source"], "failed": repr(error)}
    return {
        "problem": job["problem"],
        "source": job["source"],
        "name": report["name"],
        "prevalence": float(y.mean()),
        "rows": int(len(y)),
        "features": int(x.shape[1]),
        **result,
    }


def x_run_job__mutmut_21(job: dict[str, Any], methods: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    try:
        if job["source"] == "adbench":
            x, y, report = lb.load_adbench(job["name"], Path(job["path"]))
        else:
            x, y, report = lb.load_uci(job["meta"], None)
        result = run_problem(x, y, methods=methods)
    except Exception as error:  # recorded, never dropped silently
        return {"problem": job["problem"], "source": job["source"], "failed": repr(error)}
    return {
        "problem": job["problem"],
        "source": job["source"],
        "name": report["name"],
        "prevalence": float(y.mean()),
        "rows": int(len(y)),
        "features": int(x.shape[1]),
        **result,
    }


def x_run_job__mutmut_22(job: dict[str, Any], methods: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    try:
        if job["source"] == "adbench":
            x, y, report = lb.load_adbench(job["name"], Path(job["path"]))
        else:
            x, y, report = lb.load_uci(Path(job["path"]))
        result = run_problem(x, y, methods=methods)
    except Exception as error:  # recorded, never dropped silently
        return {"problem": job["problem"], "source": job["source"], "failed": repr(error)}
    return {
        "problem": job["problem"],
        "source": job["source"],
        "name": report["name"],
        "prevalence": float(y.mean()),
        "rows": int(len(y)),
        "features": int(x.shape[1]),
        **result,
    }


def x_run_job__mutmut_23(job: dict[str, Any], methods: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    try:
        if job["source"] == "adbench":
            x, y, report = lb.load_adbench(job["name"], Path(job["path"]))
        else:
            x, y, report = lb.load_uci(job["meta"], )
        result = run_problem(x, y, methods=methods)
    except Exception as error:  # recorded, never dropped silently
        return {"problem": job["problem"], "source": job["source"], "failed": repr(error)}
    return {
        "problem": job["problem"],
        "source": job["source"],
        "name": report["name"],
        "prevalence": float(y.mean()),
        "rows": int(len(y)),
        "features": int(x.shape[1]),
        **result,
    }


def x_run_job__mutmut_24(job: dict[str, Any], methods: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    try:
        if job["source"] == "adbench":
            x, y, report = lb.load_adbench(job["name"], Path(job["path"]))
        else:
            x, y, report = lb.load_uci(job["XXmetaXX"], Path(job["path"]))
        result = run_problem(x, y, methods=methods)
    except Exception as error:  # recorded, never dropped silently
        return {"problem": job["problem"], "source": job["source"], "failed": repr(error)}
    return {
        "problem": job["problem"],
        "source": job["source"],
        "name": report["name"],
        "prevalence": float(y.mean()),
        "rows": int(len(y)),
        "features": int(x.shape[1]),
        **result,
    }


def x_run_job__mutmut_25(job: dict[str, Any], methods: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    try:
        if job["source"] == "adbench":
            x, y, report = lb.load_adbench(job["name"], Path(job["path"]))
        else:
            x, y, report = lb.load_uci(job["META"], Path(job["path"]))
        result = run_problem(x, y, methods=methods)
    except Exception as error:  # recorded, never dropped silently
        return {"problem": job["problem"], "source": job["source"], "failed": repr(error)}
    return {
        "problem": job["problem"],
        "source": job["source"],
        "name": report["name"],
        "prevalence": float(y.mean()),
        "rows": int(len(y)),
        "features": int(x.shape[1]),
        **result,
    }


def x_run_job__mutmut_26(job: dict[str, Any], methods: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    try:
        if job["source"] == "adbench":
            x, y, report = lb.load_adbench(job["name"], Path(job["path"]))
        else:
            x, y, report = lb.load_uci(job["meta"], Path(None))
        result = run_problem(x, y, methods=methods)
    except Exception as error:  # recorded, never dropped silently
        return {"problem": job["problem"], "source": job["source"], "failed": repr(error)}
    return {
        "problem": job["problem"],
        "source": job["source"],
        "name": report["name"],
        "prevalence": float(y.mean()),
        "rows": int(len(y)),
        "features": int(x.shape[1]),
        **result,
    }


def x_run_job__mutmut_27(job: dict[str, Any], methods: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    try:
        if job["source"] == "adbench":
            x, y, report = lb.load_adbench(job["name"], Path(job["path"]))
        else:
            x, y, report = lb.load_uci(job["meta"], Path(job["XXpathXX"]))
        result = run_problem(x, y, methods=methods)
    except Exception as error:  # recorded, never dropped silently
        return {"problem": job["problem"], "source": job["source"], "failed": repr(error)}
    return {
        "problem": job["problem"],
        "source": job["source"],
        "name": report["name"],
        "prevalence": float(y.mean()),
        "rows": int(len(y)),
        "features": int(x.shape[1]),
        **result,
    }


def x_run_job__mutmut_28(job: dict[str, Any], methods: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    try:
        if job["source"] == "adbench":
            x, y, report = lb.load_adbench(job["name"], Path(job["path"]))
        else:
            x, y, report = lb.load_uci(job["meta"], Path(job["PATH"]))
        result = run_problem(x, y, methods=methods)
    except Exception as error:  # recorded, never dropped silently
        return {"problem": job["problem"], "source": job["source"], "failed": repr(error)}
    return {
        "problem": job["problem"],
        "source": job["source"],
        "name": report["name"],
        "prevalence": float(y.mean()),
        "rows": int(len(y)),
        "features": int(x.shape[1]),
        **result,
    }


def x_run_job__mutmut_29(job: dict[str, Any], methods: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    try:
        if job["source"] == "adbench":
            x, y, report = lb.load_adbench(job["name"], Path(job["path"]))
        else:
            x, y, report = lb.load_uci(job["meta"], Path(job["path"]))
        result = None
    except Exception as error:  # recorded, never dropped silently
        return {"problem": job["problem"], "source": job["source"], "failed": repr(error)}
    return {
        "problem": job["problem"],
        "source": job["source"],
        "name": report["name"],
        "prevalence": float(y.mean()),
        "rows": int(len(y)),
        "features": int(x.shape[1]),
        **result,
    }


def x_run_job__mutmut_30(job: dict[str, Any], methods: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    try:
        if job["source"] == "adbench":
            x, y, report = lb.load_adbench(job["name"], Path(job["path"]))
        else:
            x, y, report = lb.load_uci(job["meta"], Path(job["path"]))
        result = run_problem(None, y, methods=methods)
    except Exception as error:  # recorded, never dropped silently
        return {"problem": job["problem"], "source": job["source"], "failed": repr(error)}
    return {
        "problem": job["problem"],
        "source": job["source"],
        "name": report["name"],
        "prevalence": float(y.mean()),
        "rows": int(len(y)),
        "features": int(x.shape[1]),
        **result,
    }


def x_run_job__mutmut_31(job: dict[str, Any], methods: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    try:
        if job["source"] == "adbench":
            x, y, report = lb.load_adbench(job["name"], Path(job["path"]))
        else:
            x, y, report = lb.load_uci(job["meta"], Path(job["path"]))
        result = run_problem(x, None, methods=methods)
    except Exception as error:  # recorded, never dropped silently
        return {"problem": job["problem"], "source": job["source"], "failed": repr(error)}
    return {
        "problem": job["problem"],
        "source": job["source"],
        "name": report["name"],
        "prevalence": float(y.mean()),
        "rows": int(len(y)),
        "features": int(x.shape[1]),
        **result,
    }


def x_run_job__mutmut_32(job: dict[str, Any], methods: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    try:
        if job["source"] == "adbench":
            x, y, report = lb.load_adbench(job["name"], Path(job["path"]))
        else:
            x, y, report = lb.load_uci(job["meta"], Path(job["path"]))
        result = run_problem(x, y, methods=None)
    except Exception as error:  # recorded, never dropped silently
        return {"problem": job["problem"], "source": job["source"], "failed": repr(error)}
    return {
        "problem": job["problem"],
        "source": job["source"],
        "name": report["name"],
        "prevalence": float(y.mean()),
        "rows": int(len(y)),
        "features": int(x.shape[1]),
        **result,
    }


def x_run_job__mutmut_33(job: dict[str, Any], methods: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    try:
        if job["source"] == "adbench":
            x, y, report = lb.load_adbench(job["name"], Path(job["path"]))
        else:
            x, y, report = lb.load_uci(job["meta"], Path(job["path"]))
        result = run_problem(y, methods=methods)
    except Exception as error:  # recorded, never dropped silently
        return {"problem": job["problem"], "source": job["source"], "failed": repr(error)}
    return {
        "problem": job["problem"],
        "source": job["source"],
        "name": report["name"],
        "prevalence": float(y.mean()),
        "rows": int(len(y)),
        "features": int(x.shape[1]),
        **result,
    }


def x_run_job__mutmut_34(job: dict[str, Any], methods: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    try:
        if job["source"] == "adbench":
            x, y, report = lb.load_adbench(job["name"], Path(job["path"]))
        else:
            x, y, report = lb.load_uci(job["meta"], Path(job["path"]))
        result = run_problem(x, methods=methods)
    except Exception as error:  # recorded, never dropped silently
        return {"problem": job["problem"], "source": job["source"], "failed": repr(error)}
    return {
        "problem": job["problem"],
        "source": job["source"],
        "name": report["name"],
        "prevalence": float(y.mean()),
        "rows": int(len(y)),
        "features": int(x.shape[1]),
        **result,
    }


def x_run_job__mutmut_35(job: dict[str, Any], methods: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    try:
        if job["source"] == "adbench":
            x, y, report = lb.load_adbench(job["name"], Path(job["path"]))
        else:
            x, y, report = lb.load_uci(job["meta"], Path(job["path"]))
        result = run_problem(x, y, )
    except Exception as error:  # recorded, never dropped silently
        return {"problem": job["problem"], "source": job["source"], "failed": repr(error)}
    return {
        "problem": job["problem"],
        "source": job["source"],
        "name": report["name"],
        "prevalence": float(y.mean()),
        "rows": int(len(y)),
        "features": int(x.shape[1]),
        **result,
    }


def x_run_job__mutmut_36(job: dict[str, Any], methods: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    try:
        if job["source"] == "adbench":
            x, y, report = lb.load_adbench(job["name"], Path(job["path"]))
        else:
            x, y, report = lb.load_uci(job["meta"], Path(job["path"]))
        result = run_problem(x, y, methods=methods)
    except Exception as error:  # recorded, never dropped silently
        return {"XXproblemXX": job["problem"], "source": job["source"], "failed": repr(error)}
    return {
        "problem": job["problem"],
        "source": job["source"],
        "name": report["name"],
        "prevalence": float(y.mean()),
        "rows": int(len(y)),
        "features": int(x.shape[1]),
        **result,
    }


def x_run_job__mutmut_37(job: dict[str, Any], methods: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    try:
        if job["source"] == "adbench":
            x, y, report = lb.load_adbench(job["name"], Path(job["path"]))
        else:
            x, y, report = lb.load_uci(job["meta"], Path(job["path"]))
        result = run_problem(x, y, methods=methods)
    except Exception as error:  # recorded, never dropped silently
        return {"PROBLEM": job["problem"], "source": job["source"], "failed": repr(error)}
    return {
        "problem": job["problem"],
        "source": job["source"],
        "name": report["name"],
        "prevalence": float(y.mean()),
        "rows": int(len(y)),
        "features": int(x.shape[1]),
        **result,
    }


def x_run_job__mutmut_38(job: dict[str, Any], methods: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    try:
        if job["source"] == "adbench":
            x, y, report = lb.load_adbench(job["name"], Path(job["path"]))
        else:
            x, y, report = lb.load_uci(job["meta"], Path(job["path"]))
        result = run_problem(x, y, methods=methods)
    except Exception as error:  # recorded, never dropped silently
        return {"problem": job["XXproblemXX"], "source": job["source"], "failed": repr(error)}
    return {
        "problem": job["problem"],
        "source": job["source"],
        "name": report["name"],
        "prevalence": float(y.mean()),
        "rows": int(len(y)),
        "features": int(x.shape[1]),
        **result,
    }


def x_run_job__mutmut_39(job: dict[str, Any], methods: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    try:
        if job["source"] == "adbench":
            x, y, report = lb.load_adbench(job["name"], Path(job["path"]))
        else:
            x, y, report = lb.load_uci(job["meta"], Path(job["path"]))
        result = run_problem(x, y, methods=methods)
    except Exception as error:  # recorded, never dropped silently
        return {"problem": job["PROBLEM"], "source": job["source"], "failed": repr(error)}
    return {
        "problem": job["problem"],
        "source": job["source"],
        "name": report["name"],
        "prevalence": float(y.mean()),
        "rows": int(len(y)),
        "features": int(x.shape[1]),
        **result,
    }


def x_run_job__mutmut_40(job: dict[str, Any], methods: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    try:
        if job["source"] == "adbench":
            x, y, report = lb.load_adbench(job["name"], Path(job["path"]))
        else:
            x, y, report = lb.load_uci(job["meta"], Path(job["path"]))
        result = run_problem(x, y, methods=methods)
    except Exception as error:  # recorded, never dropped silently
        return {"problem": job["problem"], "XXsourceXX": job["source"], "failed": repr(error)}
    return {
        "problem": job["problem"],
        "source": job["source"],
        "name": report["name"],
        "prevalence": float(y.mean()),
        "rows": int(len(y)),
        "features": int(x.shape[1]),
        **result,
    }


def x_run_job__mutmut_41(job: dict[str, Any], methods: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    try:
        if job["source"] == "adbench":
            x, y, report = lb.load_adbench(job["name"], Path(job["path"]))
        else:
            x, y, report = lb.load_uci(job["meta"], Path(job["path"]))
        result = run_problem(x, y, methods=methods)
    except Exception as error:  # recorded, never dropped silently
        return {"problem": job["problem"], "SOURCE": job["source"], "failed": repr(error)}
    return {
        "problem": job["problem"],
        "source": job["source"],
        "name": report["name"],
        "prevalence": float(y.mean()),
        "rows": int(len(y)),
        "features": int(x.shape[1]),
        **result,
    }


def x_run_job__mutmut_42(job: dict[str, Any], methods: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    try:
        if job["source"] == "adbench":
            x, y, report = lb.load_adbench(job["name"], Path(job["path"]))
        else:
            x, y, report = lb.load_uci(job["meta"], Path(job["path"]))
        result = run_problem(x, y, methods=methods)
    except Exception as error:  # recorded, never dropped silently
        return {"problem": job["problem"], "source": job["XXsourceXX"], "failed": repr(error)}
    return {
        "problem": job["problem"],
        "source": job["source"],
        "name": report["name"],
        "prevalence": float(y.mean()),
        "rows": int(len(y)),
        "features": int(x.shape[1]),
        **result,
    }


def x_run_job__mutmut_43(job: dict[str, Any], methods: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    try:
        if job["source"] == "adbench":
            x, y, report = lb.load_adbench(job["name"], Path(job["path"]))
        else:
            x, y, report = lb.load_uci(job["meta"], Path(job["path"]))
        result = run_problem(x, y, methods=methods)
    except Exception as error:  # recorded, never dropped silently
        return {"problem": job["problem"], "source": job["SOURCE"], "failed": repr(error)}
    return {
        "problem": job["problem"],
        "source": job["source"],
        "name": report["name"],
        "prevalence": float(y.mean()),
        "rows": int(len(y)),
        "features": int(x.shape[1]),
        **result,
    }


def x_run_job__mutmut_44(job: dict[str, Any], methods: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    try:
        if job["source"] == "adbench":
            x, y, report = lb.load_adbench(job["name"], Path(job["path"]))
        else:
            x, y, report = lb.load_uci(job["meta"], Path(job["path"]))
        result = run_problem(x, y, methods=methods)
    except Exception as error:  # recorded, never dropped silently
        return {"problem": job["problem"], "source": job["source"], "XXfailedXX": repr(error)}
    return {
        "problem": job["problem"],
        "source": job["source"],
        "name": report["name"],
        "prevalence": float(y.mean()),
        "rows": int(len(y)),
        "features": int(x.shape[1]),
        **result,
    }


def x_run_job__mutmut_45(job: dict[str, Any], methods: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    try:
        if job["source"] == "adbench":
            x, y, report = lb.load_adbench(job["name"], Path(job["path"]))
        else:
            x, y, report = lb.load_uci(job["meta"], Path(job["path"]))
        result = run_problem(x, y, methods=methods)
    except Exception as error:  # recorded, never dropped silently
        return {"problem": job["problem"], "source": job["source"], "FAILED": repr(error)}
    return {
        "problem": job["problem"],
        "source": job["source"],
        "name": report["name"],
        "prevalence": float(y.mean()),
        "rows": int(len(y)),
        "features": int(x.shape[1]),
        **result,
    }


def x_run_job__mutmut_46(job: dict[str, Any], methods: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    try:
        if job["source"] == "adbench":
            x, y, report = lb.load_adbench(job["name"], Path(job["path"]))
        else:
            x, y, report = lb.load_uci(job["meta"], Path(job["path"]))
        result = run_problem(x, y, methods=methods)
    except Exception as error:  # recorded, never dropped silently
        return {"problem": job["problem"], "source": job["source"], "failed": repr(None)}
    return {
        "problem": job["problem"],
        "source": job["source"],
        "name": report["name"],
        "prevalence": float(y.mean()),
        "rows": int(len(y)),
        "features": int(x.shape[1]),
        **result,
    }


def x_run_job__mutmut_47(job: dict[str, Any], methods: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    try:
        if job["source"] == "adbench":
            x, y, report = lb.load_adbench(job["name"], Path(job["path"]))
        else:
            x, y, report = lb.load_uci(job["meta"], Path(job["path"]))
        result = run_problem(x, y, methods=methods)
    except Exception as error:  # recorded, never dropped silently
        return {"problem": job["problem"], "source": job["source"], "failed": repr(error)}
    return {
        "XXproblemXX": job["problem"],
        "source": job["source"],
        "name": report["name"],
        "prevalence": float(y.mean()),
        "rows": int(len(y)),
        "features": int(x.shape[1]),
        **result,
    }


def x_run_job__mutmut_48(job: dict[str, Any], methods: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    try:
        if job["source"] == "adbench":
            x, y, report = lb.load_adbench(job["name"], Path(job["path"]))
        else:
            x, y, report = lb.load_uci(job["meta"], Path(job["path"]))
        result = run_problem(x, y, methods=methods)
    except Exception as error:  # recorded, never dropped silently
        return {"problem": job["problem"], "source": job["source"], "failed": repr(error)}
    return {
        "PROBLEM": job["problem"],
        "source": job["source"],
        "name": report["name"],
        "prevalence": float(y.mean()),
        "rows": int(len(y)),
        "features": int(x.shape[1]),
        **result,
    }


def x_run_job__mutmut_49(job: dict[str, Any], methods: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    try:
        if job["source"] == "adbench":
            x, y, report = lb.load_adbench(job["name"], Path(job["path"]))
        else:
            x, y, report = lb.load_uci(job["meta"], Path(job["path"]))
        result = run_problem(x, y, methods=methods)
    except Exception as error:  # recorded, never dropped silently
        return {"problem": job["problem"], "source": job["source"], "failed": repr(error)}
    return {
        "problem": job["XXproblemXX"],
        "source": job["source"],
        "name": report["name"],
        "prevalence": float(y.mean()),
        "rows": int(len(y)),
        "features": int(x.shape[1]),
        **result,
    }


def x_run_job__mutmut_50(job: dict[str, Any], methods: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    try:
        if job["source"] == "adbench":
            x, y, report = lb.load_adbench(job["name"], Path(job["path"]))
        else:
            x, y, report = lb.load_uci(job["meta"], Path(job["path"]))
        result = run_problem(x, y, methods=methods)
    except Exception as error:  # recorded, never dropped silently
        return {"problem": job["problem"], "source": job["source"], "failed": repr(error)}
    return {
        "problem": job["PROBLEM"],
        "source": job["source"],
        "name": report["name"],
        "prevalence": float(y.mean()),
        "rows": int(len(y)),
        "features": int(x.shape[1]),
        **result,
    }


def x_run_job__mutmut_51(job: dict[str, Any], methods: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    try:
        if job["source"] == "adbench":
            x, y, report = lb.load_adbench(job["name"], Path(job["path"]))
        else:
            x, y, report = lb.load_uci(job["meta"], Path(job["path"]))
        result = run_problem(x, y, methods=methods)
    except Exception as error:  # recorded, never dropped silently
        return {"problem": job["problem"], "source": job["source"], "failed": repr(error)}
    return {
        "problem": job["problem"],
        "XXsourceXX": job["source"],
        "name": report["name"],
        "prevalence": float(y.mean()),
        "rows": int(len(y)),
        "features": int(x.shape[1]),
        **result,
    }


def x_run_job__mutmut_52(job: dict[str, Any], methods: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    try:
        if job["source"] == "adbench":
            x, y, report = lb.load_adbench(job["name"], Path(job["path"]))
        else:
            x, y, report = lb.load_uci(job["meta"], Path(job["path"]))
        result = run_problem(x, y, methods=methods)
    except Exception as error:  # recorded, never dropped silently
        return {"problem": job["problem"], "source": job["source"], "failed": repr(error)}
    return {
        "problem": job["problem"],
        "SOURCE": job["source"],
        "name": report["name"],
        "prevalence": float(y.mean()),
        "rows": int(len(y)),
        "features": int(x.shape[1]),
        **result,
    }


def x_run_job__mutmut_53(job: dict[str, Any], methods: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    try:
        if job["source"] == "adbench":
            x, y, report = lb.load_adbench(job["name"], Path(job["path"]))
        else:
            x, y, report = lb.load_uci(job["meta"], Path(job["path"]))
        result = run_problem(x, y, methods=methods)
    except Exception as error:  # recorded, never dropped silently
        return {"problem": job["problem"], "source": job["source"], "failed": repr(error)}
    return {
        "problem": job["problem"],
        "source": job["XXsourceXX"],
        "name": report["name"],
        "prevalence": float(y.mean()),
        "rows": int(len(y)),
        "features": int(x.shape[1]),
        **result,
    }


def x_run_job__mutmut_54(job: dict[str, Any], methods: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    try:
        if job["source"] == "adbench":
            x, y, report = lb.load_adbench(job["name"], Path(job["path"]))
        else:
            x, y, report = lb.load_uci(job["meta"], Path(job["path"]))
        result = run_problem(x, y, methods=methods)
    except Exception as error:  # recorded, never dropped silently
        return {"problem": job["problem"], "source": job["source"], "failed": repr(error)}
    return {
        "problem": job["problem"],
        "source": job["SOURCE"],
        "name": report["name"],
        "prevalence": float(y.mean()),
        "rows": int(len(y)),
        "features": int(x.shape[1]),
        **result,
    }


def x_run_job__mutmut_55(job: dict[str, Any], methods: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    try:
        if job["source"] == "adbench":
            x, y, report = lb.load_adbench(job["name"], Path(job["path"]))
        else:
            x, y, report = lb.load_uci(job["meta"], Path(job["path"]))
        result = run_problem(x, y, methods=methods)
    except Exception as error:  # recorded, never dropped silently
        return {"problem": job["problem"], "source": job["source"], "failed": repr(error)}
    return {
        "problem": job["problem"],
        "source": job["source"],
        "XXnameXX": report["name"],
        "prevalence": float(y.mean()),
        "rows": int(len(y)),
        "features": int(x.shape[1]),
        **result,
    }


def x_run_job__mutmut_56(job: dict[str, Any], methods: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    try:
        if job["source"] == "adbench":
            x, y, report = lb.load_adbench(job["name"], Path(job["path"]))
        else:
            x, y, report = lb.load_uci(job["meta"], Path(job["path"]))
        result = run_problem(x, y, methods=methods)
    except Exception as error:  # recorded, never dropped silently
        return {"problem": job["problem"], "source": job["source"], "failed": repr(error)}
    return {
        "problem": job["problem"],
        "source": job["source"],
        "NAME": report["name"],
        "prevalence": float(y.mean()),
        "rows": int(len(y)),
        "features": int(x.shape[1]),
        **result,
    }


def x_run_job__mutmut_57(job: dict[str, Any], methods: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    try:
        if job["source"] == "adbench":
            x, y, report = lb.load_adbench(job["name"], Path(job["path"]))
        else:
            x, y, report = lb.load_uci(job["meta"], Path(job["path"]))
        result = run_problem(x, y, methods=methods)
    except Exception as error:  # recorded, never dropped silently
        return {"problem": job["problem"], "source": job["source"], "failed": repr(error)}
    return {
        "problem": job["problem"],
        "source": job["source"],
        "name": report["XXnameXX"],
        "prevalence": float(y.mean()),
        "rows": int(len(y)),
        "features": int(x.shape[1]),
        **result,
    }


def x_run_job__mutmut_58(job: dict[str, Any], methods: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    try:
        if job["source"] == "adbench":
            x, y, report = lb.load_adbench(job["name"], Path(job["path"]))
        else:
            x, y, report = lb.load_uci(job["meta"], Path(job["path"]))
        result = run_problem(x, y, methods=methods)
    except Exception as error:  # recorded, never dropped silently
        return {"problem": job["problem"], "source": job["source"], "failed": repr(error)}
    return {
        "problem": job["problem"],
        "source": job["source"],
        "name": report["NAME"],
        "prevalence": float(y.mean()),
        "rows": int(len(y)),
        "features": int(x.shape[1]),
        **result,
    }


def x_run_job__mutmut_59(job: dict[str, Any], methods: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    try:
        if job["source"] == "adbench":
            x, y, report = lb.load_adbench(job["name"], Path(job["path"]))
        else:
            x, y, report = lb.load_uci(job["meta"], Path(job["path"]))
        result = run_problem(x, y, methods=methods)
    except Exception as error:  # recorded, never dropped silently
        return {"problem": job["problem"], "source": job["source"], "failed": repr(error)}
    return {
        "problem": job["problem"],
        "source": job["source"],
        "name": report["name"],
        "XXprevalenceXX": float(y.mean()),
        "rows": int(len(y)),
        "features": int(x.shape[1]),
        **result,
    }


def x_run_job__mutmut_60(job: dict[str, Any], methods: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    try:
        if job["source"] == "adbench":
            x, y, report = lb.load_adbench(job["name"], Path(job["path"]))
        else:
            x, y, report = lb.load_uci(job["meta"], Path(job["path"]))
        result = run_problem(x, y, methods=methods)
    except Exception as error:  # recorded, never dropped silently
        return {"problem": job["problem"], "source": job["source"], "failed": repr(error)}
    return {
        "problem": job["problem"],
        "source": job["source"],
        "name": report["name"],
        "PREVALENCE": float(y.mean()),
        "rows": int(len(y)),
        "features": int(x.shape[1]),
        **result,
    }


def x_run_job__mutmut_61(job: dict[str, Any], methods: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    try:
        if job["source"] == "adbench":
            x, y, report = lb.load_adbench(job["name"], Path(job["path"]))
        else:
            x, y, report = lb.load_uci(job["meta"], Path(job["path"]))
        result = run_problem(x, y, methods=methods)
    except Exception as error:  # recorded, never dropped silently
        return {"problem": job["problem"], "source": job["source"], "failed": repr(error)}
    return {
        "problem": job["problem"],
        "source": job["source"],
        "name": report["name"],
        "prevalence": float(None),
        "rows": int(len(y)),
        "features": int(x.shape[1]),
        **result,
    }


def x_run_job__mutmut_62(job: dict[str, Any], methods: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    try:
        if job["source"] == "adbench":
            x, y, report = lb.load_adbench(job["name"], Path(job["path"]))
        else:
            x, y, report = lb.load_uci(job["meta"], Path(job["path"]))
        result = run_problem(x, y, methods=methods)
    except Exception as error:  # recorded, never dropped silently
        return {"problem": job["problem"], "source": job["source"], "failed": repr(error)}
    return {
        "problem": job["problem"],
        "source": job["source"],
        "name": report["name"],
        "prevalence": float(y.mean()),
        "XXrowsXX": int(len(y)),
        "features": int(x.shape[1]),
        **result,
    }


def x_run_job__mutmut_63(job: dict[str, Any], methods: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    try:
        if job["source"] == "adbench":
            x, y, report = lb.load_adbench(job["name"], Path(job["path"]))
        else:
            x, y, report = lb.load_uci(job["meta"], Path(job["path"]))
        result = run_problem(x, y, methods=methods)
    except Exception as error:  # recorded, never dropped silently
        return {"problem": job["problem"], "source": job["source"], "failed": repr(error)}
    return {
        "problem": job["problem"],
        "source": job["source"],
        "name": report["name"],
        "prevalence": float(y.mean()),
        "ROWS": int(len(y)),
        "features": int(x.shape[1]),
        **result,
    }


def x_run_job__mutmut_64(job: dict[str, Any], methods: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    try:
        if job["source"] == "adbench":
            x, y, report = lb.load_adbench(job["name"], Path(job["path"]))
        else:
            x, y, report = lb.load_uci(job["meta"], Path(job["path"]))
        result = run_problem(x, y, methods=methods)
    except Exception as error:  # recorded, never dropped silently
        return {"problem": job["problem"], "source": job["source"], "failed": repr(error)}
    return {
        "problem": job["problem"],
        "source": job["source"],
        "name": report["name"],
        "prevalence": float(y.mean()),
        "rows": int(None),
        "features": int(x.shape[1]),
        **result,
    }


def x_run_job__mutmut_65(job: dict[str, Any], methods: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    try:
        if job["source"] == "adbench":
            x, y, report = lb.load_adbench(job["name"], Path(job["path"]))
        else:
            x, y, report = lb.load_uci(job["meta"], Path(job["path"]))
        result = run_problem(x, y, methods=methods)
    except Exception as error:  # recorded, never dropped silently
        return {"problem": job["problem"], "source": job["source"], "failed": repr(error)}
    return {
        "problem": job["problem"],
        "source": job["source"],
        "name": report["name"],
        "prevalence": float(y.mean()),
        "rows": int(len(y)),
        "XXfeaturesXX": int(x.shape[1]),
        **result,
    }


def x_run_job__mutmut_66(job: dict[str, Any], methods: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    try:
        if job["source"] == "adbench":
            x, y, report = lb.load_adbench(job["name"], Path(job["path"]))
        else:
            x, y, report = lb.load_uci(job["meta"], Path(job["path"]))
        result = run_problem(x, y, methods=methods)
    except Exception as error:  # recorded, never dropped silently
        return {"problem": job["problem"], "source": job["source"], "failed": repr(error)}
    return {
        "problem": job["problem"],
        "source": job["source"],
        "name": report["name"],
        "prevalence": float(y.mean()),
        "rows": int(len(y)),
        "FEATURES": int(x.shape[1]),
        **result,
    }


def x_run_job__mutmut_67(job: dict[str, Any], methods: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    try:
        if job["source"] == "adbench":
            x, y, report = lb.load_adbench(job["name"], Path(job["path"]))
        else:
            x, y, report = lb.load_uci(job["meta"], Path(job["path"]))
        result = run_problem(x, y, methods=methods)
    except Exception as error:  # recorded, never dropped silently
        return {"problem": job["problem"], "source": job["source"], "failed": repr(error)}
    return {
        "problem": job["problem"],
        "source": job["source"],
        "name": report["name"],
        "prevalence": float(y.mean()),
        "rows": int(len(y)),
        "features": int(None),
        **result,
    }


def x_run_job__mutmut_68(job: dict[str, Any], methods: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    try:
        if job["source"] == "adbench":
            x, y, report = lb.load_adbench(job["name"], Path(job["path"]))
        else:
            x, y, report = lb.load_uci(job["meta"], Path(job["path"]))
        result = run_problem(x, y, methods=methods)
    except Exception as error:  # recorded, never dropped silently
        return {"problem": job["problem"], "source": job["source"], "failed": repr(error)}
    return {
        "problem": job["problem"],
        "source": job["source"],
        "name": report["name"],
        "prevalence": float(y.mean()),
        "rows": int(len(y)),
        "features": int(x.shape[2]),
        **result,
    }

mutants_x_run_job__mutmut['_mutmut_orig'] = x_run_job__mutmut_orig # type: ignore # mutmut generated
mutants_x_run_job__mutmut['x_run_job__mutmut_1'] = x_run_job__mutmut_1 # type: ignore # mutmut generated
mutants_x_run_job__mutmut['x_run_job__mutmut_2'] = x_run_job__mutmut_2 # type: ignore # mutmut generated
mutants_x_run_job__mutmut['x_run_job__mutmut_3'] = x_run_job__mutmut_3 # type: ignore # mutmut generated
mutants_x_run_job__mutmut['x_run_job__mutmut_4'] = x_run_job__mutmut_4 # type: ignore # mutmut generated
mutants_x_run_job__mutmut['x_run_job__mutmut_5'] = x_run_job__mutmut_5 # type: ignore # mutmut generated
mutants_x_run_job__mutmut['x_run_job__mutmut_6'] = x_run_job__mutmut_6 # type: ignore # mutmut generated
mutants_x_run_job__mutmut['x_run_job__mutmut_7'] = x_run_job__mutmut_7 # type: ignore # mutmut generated
mutants_x_run_job__mutmut['x_run_job__mutmut_8'] = x_run_job__mutmut_8 # type: ignore # mutmut generated
mutants_x_run_job__mutmut['x_run_job__mutmut_9'] = x_run_job__mutmut_9 # type: ignore # mutmut generated
mutants_x_run_job__mutmut['x_run_job__mutmut_10'] = x_run_job__mutmut_10 # type: ignore # mutmut generated
mutants_x_run_job__mutmut['x_run_job__mutmut_11'] = x_run_job__mutmut_11 # type: ignore # mutmut generated
mutants_x_run_job__mutmut['x_run_job__mutmut_12'] = x_run_job__mutmut_12 # type: ignore # mutmut generated
mutants_x_run_job__mutmut['x_run_job__mutmut_13'] = x_run_job__mutmut_13 # type: ignore # mutmut generated
mutants_x_run_job__mutmut['x_run_job__mutmut_14'] = x_run_job__mutmut_14 # type: ignore # mutmut generated
mutants_x_run_job__mutmut['x_run_job__mutmut_15'] = x_run_job__mutmut_15 # type: ignore # mutmut generated
mutants_x_run_job__mutmut['x_run_job__mutmut_16'] = x_run_job__mutmut_16 # type: ignore # mutmut generated
mutants_x_run_job__mutmut['x_run_job__mutmut_17'] = x_run_job__mutmut_17 # type: ignore # mutmut generated
mutants_x_run_job__mutmut['x_run_job__mutmut_18'] = x_run_job__mutmut_18 # type: ignore # mutmut generated
mutants_x_run_job__mutmut['x_run_job__mutmut_19'] = x_run_job__mutmut_19 # type: ignore # mutmut generated
mutants_x_run_job__mutmut['x_run_job__mutmut_20'] = x_run_job__mutmut_20 # type: ignore # mutmut generated
mutants_x_run_job__mutmut['x_run_job__mutmut_21'] = x_run_job__mutmut_21 # type: ignore # mutmut generated
mutants_x_run_job__mutmut['x_run_job__mutmut_22'] = x_run_job__mutmut_22 # type: ignore # mutmut generated
mutants_x_run_job__mutmut['x_run_job__mutmut_23'] = x_run_job__mutmut_23 # type: ignore # mutmut generated
mutants_x_run_job__mutmut['x_run_job__mutmut_24'] = x_run_job__mutmut_24 # type: ignore # mutmut generated
mutants_x_run_job__mutmut['x_run_job__mutmut_25'] = x_run_job__mutmut_25 # type: ignore # mutmut generated
mutants_x_run_job__mutmut['x_run_job__mutmut_26'] = x_run_job__mutmut_26 # type: ignore # mutmut generated
mutants_x_run_job__mutmut['x_run_job__mutmut_27'] = x_run_job__mutmut_27 # type: ignore # mutmut generated
mutants_x_run_job__mutmut['x_run_job__mutmut_28'] = x_run_job__mutmut_28 # type: ignore # mutmut generated
mutants_x_run_job__mutmut['x_run_job__mutmut_29'] = x_run_job__mutmut_29 # type: ignore # mutmut generated
mutants_x_run_job__mutmut['x_run_job__mutmut_30'] = x_run_job__mutmut_30 # type: ignore # mutmut generated
mutants_x_run_job__mutmut['x_run_job__mutmut_31'] = x_run_job__mutmut_31 # type: ignore # mutmut generated
mutants_x_run_job__mutmut['x_run_job__mutmut_32'] = x_run_job__mutmut_32 # type: ignore # mutmut generated
mutants_x_run_job__mutmut['x_run_job__mutmut_33'] = x_run_job__mutmut_33 # type: ignore # mutmut generated
mutants_x_run_job__mutmut['x_run_job__mutmut_34'] = x_run_job__mutmut_34 # type: ignore # mutmut generated
mutants_x_run_job__mutmut['x_run_job__mutmut_35'] = x_run_job__mutmut_35 # type: ignore # mutmut generated
mutants_x_run_job__mutmut['x_run_job__mutmut_36'] = x_run_job__mutmut_36 # type: ignore # mutmut generated
mutants_x_run_job__mutmut['x_run_job__mutmut_37'] = x_run_job__mutmut_37 # type: ignore # mutmut generated
mutants_x_run_job__mutmut['x_run_job__mutmut_38'] = x_run_job__mutmut_38 # type: ignore # mutmut generated
mutants_x_run_job__mutmut['x_run_job__mutmut_39'] = x_run_job__mutmut_39 # type: ignore # mutmut generated
mutants_x_run_job__mutmut['x_run_job__mutmut_40'] = x_run_job__mutmut_40 # type: ignore # mutmut generated
mutants_x_run_job__mutmut['x_run_job__mutmut_41'] = x_run_job__mutmut_41 # type: ignore # mutmut generated
mutants_x_run_job__mutmut['x_run_job__mutmut_42'] = x_run_job__mutmut_42 # type: ignore # mutmut generated
mutants_x_run_job__mutmut['x_run_job__mutmut_43'] = x_run_job__mutmut_43 # type: ignore # mutmut generated
mutants_x_run_job__mutmut['x_run_job__mutmut_44'] = x_run_job__mutmut_44 # type: ignore # mutmut generated
mutants_x_run_job__mutmut['x_run_job__mutmut_45'] = x_run_job__mutmut_45 # type: ignore # mutmut generated
mutants_x_run_job__mutmut['x_run_job__mutmut_46'] = x_run_job__mutmut_46 # type: ignore # mutmut generated
mutants_x_run_job__mutmut['x_run_job__mutmut_47'] = x_run_job__mutmut_47 # type: ignore # mutmut generated
mutants_x_run_job__mutmut['x_run_job__mutmut_48'] = x_run_job__mutmut_48 # type: ignore # mutmut generated
mutants_x_run_job__mutmut['x_run_job__mutmut_49'] = x_run_job__mutmut_49 # type: ignore # mutmut generated
mutants_x_run_job__mutmut['x_run_job__mutmut_50'] = x_run_job__mutmut_50 # type: ignore # mutmut generated
mutants_x_run_job__mutmut['x_run_job__mutmut_51'] = x_run_job__mutmut_51 # type: ignore # mutmut generated
mutants_x_run_job__mutmut['x_run_job__mutmut_52'] = x_run_job__mutmut_52 # type: ignore # mutmut generated
mutants_x_run_job__mutmut['x_run_job__mutmut_53'] = x_run_job__mutmut_53 # type: ignore # mutmut generated
mutants_x_run_job__mutmut['x_run_job__mutmut_54'] = x_run_job__mutmut_54 # type: ignore # mutmut generated
mutants_x_run_job__mutmut['x_run_job__mutmut_55'] = x_run_job__mutmut_55 # type: ignore # mutmut generated
mutants_x_run_job__mutmut['x_run_job__mutmut_56'] = x_run_job__mutmut_56 # type: ignore # mutmut generated
mutants_x_run_job__mutmut['x_run_job__mutmut_57'] = x_run_job__mutmut_57 # type: ignore # mutmut generated
mutants_x_run_job__mutmut['x_run_job__mutmut_58'] = x_run_job__mutmut_58 # type: ignore # mutmut generated
mutants_x_run_job__mutmut['x_run_job__mutmut_59'] = x_run_job__mutmut_59 # type: ignore # mutmut generated
mutants_x_run_job__mutmut['x_run_job__mutmut_60'] = x_run_job__mutmut_60 # type: ignore # mutmut generated
mutants_x_run_job__mutmut['x_run_job__mutmut_61'] = x_run_job__mutmut_61 # type: ignore # mutmut generated
mutants_x_run_job__mutmut['x_run_job__mutmut_62'] = x_run_job__mutmut_62 # type: ignore # mutmut generated
mutants_x_run_job__mutmut['x_run_job__mutmut_63'] = x_run_job__mutmut_63 # type: ignore # mutmut generated
mutants_x_run_job__mutmut['x_run_job__mutmut_64'] = x_run_job__mutmut_64 # type: ignore # mutmut generated
mutants_x_run_job__mutmut['x_run_job__mutmut_65'] = x_run_job__mutmut_65 # type: ignore # mutmut generated
mutants_x_run_job__mutmut['x_run_job__mutmut_66'] = x_run_job__mutmut_66 # type: ignore # mutmut generated
mutants_x_run_job__mutmut['x_run_job__mutmut_67'] = x_run_job__mutmut_67 # type: ignore # mutmut generated
mutants_x_run_job__mutmut['x_run_job__mutmut_68'] = x_run_job__mutmut_68 # type: ignore # mutmut generated
mutants_x_main__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_main__mutmut)
def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument("--resume", action="store_true", help="skip the problems already written")
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_orig(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument("--resume", action="store_true", help="skip the problems already written")
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_1(argv: list[str] | None = None) -> int:
    parser = None
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument("--resume", action="store_true", help="skip the problems already written")
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_2(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=None)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument("--resume", action="store_true", help="skip the problems already written")
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_3(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = None
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument("--resume", action="store_true", help="skip the problems already written")
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_4(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = None
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument("--resume", action="store_true", help="skip the problems already written")
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_5(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" * "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument("--resume", action="store_true", help="skip the problems already written")
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_6(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" * "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument("--resume", action="store_true", help="skip the problems already written")
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_7(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root * "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument("--resume", action="store_true", help="skip the problems already written")
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_8(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "XXverificationXX" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument("--resume", action="store_true", help="skip the problems already written")
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_9(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "VERIFICATION" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument("--resume", action="store_true", help="skip the problems already written")
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_10(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "XXevidenceXX" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument("--resume", action="store_true", help="skip the problems already written")
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_11(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "EVIDENCE" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument("--resume", action="store_true", help="skip the problems already written")
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_12(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "XXdataset_registryXX"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument("--resume", action="store_true", help="skip the problems already written")
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_13(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "DATASET_REGISTRY"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument("--resume", action="store_true", help="skip the problems already written")
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_14(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument(None, type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument("--resume", action="store_true", help="skip the problems already written")
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_15(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=None, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument("--resume", action="store_true", help="skip the problems already written")
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_16(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=None)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument("--resume", action="store_true", help="skip the problems already written")
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_17(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument(type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument("--resume", action="store_true", help="skip the problems already written")
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_18(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument("--resume", action="store_true", help="skip the problems already written")
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_19(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument("--resume", action="store_true", help="skip the problems already written")
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_20(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("XX--registryXX", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument("--resume", action="store_true", help="skip the problems already written")
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_21(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--REGISTRY", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument("--resume", action="store_true", help="skip the problems already written")
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_22(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument(None, type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument("--resume", action="store_true", help="skip the problems already written")
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_23(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=None, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument("--resume", action="store_true", help="skip the problems already written")
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_24(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=None)
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument("--resume", action="store_true", help="skip the problems already written")
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_25(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument(type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument("--resume", action="store_true", help="skip the problems already written")
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_26(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument("--resume", action="store_true", help="skip the problems already written")
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_27(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, )
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument("--resume", action="store_true", help="skip the problems already written")
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_28(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("XX--adbenchXX", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument("--resume", action="store_true", help="skip the problems already written")
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_29(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--ADBENCH", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument("--resume", action="store_true", help="skip the problems already written")
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_30(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" * "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument("--resume", action="store_true", help="skip the problems already written")
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_31(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root * "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument("--resume", action="store_true", help="skip the problems already written")
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_32(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "XXdataXX" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument("--resume", action="store_true", help="skip the problems already written")
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_33(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "DATA" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument("--resume", action="store_true", help="skip the problems already written")
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_34(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "XXadbenchXX")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument("--resume", action="store_true", help="skip the problems already written")
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_35(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "ADBENCH")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument("--resume", action="store_true", help="skip the problems already written")
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_36(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument(None, type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument("--resume", action="store_true", help="skip the problems already written")
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_37(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=None, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument("--resume", action="store_true", help="skip the problems already written")
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_38(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=None)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument("--resume", action="store_true", help="skip the problems already written")
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_39(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument(type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument("--resume", action="store_true", help="skip the problems already written")
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_40(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument("--resume", action="store_true", help="skip the problems already written")
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_41(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, )
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument("--resume", action="store_true", help="skip the problems already written")
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_42(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("XX--poolXX", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument("--resume", action="store_true", help="skip the problems already written")
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_43(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--POOL", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument("--resume", action="store_true", help="skip the problems already written")
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_44(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" * "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument("--resume", action="store_true", help="skip the problems already written")
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_45(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root * "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument("--resume", action="store_true", help="skip the problems already written")
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_46(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "XXdataXX" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument("--resume", action="store_true", help="skip the problems already written")
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_47(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "DATA" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument("--resume", action="store_true", help="skip the problems already written")
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_48(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "XXpoolXX")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument("--resume", action="store_true", help="skip the problems already written")
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_49(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "POOL")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument("--resume", action="store_true", help="skip the problems already written")
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_50(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument(None, type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument("--resume", action="store_true", help="skip the problems already written")
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_51(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=None, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument("--resume", action="store_true", help="skip the problems already written")
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_52(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=None)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument("--resume", action="store_true", help="skip the problems already written")
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_53(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument(type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument("--resume", action="store_true", help="skip the problems already written")
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_54(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument("--resume", action="store_true", help="skip the problems already written")
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_55(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, )
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument("--resume", action="store_true", help="skip the problems already written")
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_56(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("XX--outputXX", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument("--resume", action="store_true", help="skip the problems already written")
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_57(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--OUTPUT", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument("--resume", action="store_true", help="skip the problems already written")
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_58(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=False)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument("--resume", action="store_true", help="skip the problems already written")
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_59(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument(None, type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument("--resume", action="store_true", help="skip the problems already written")
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_60(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=None, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument("--resume", action="store_true", help="skip the problems already written")
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_61(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=None)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument("--resume", action="store_true", help="skip the problems already written")
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_62(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument(type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument("--resume", action="store_true", help="skip the problems already written")
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_63(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument("--resume", action="store_true", help="skip the problems already written")
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_64(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, )
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument("--resume", action="store_true", help="skip the problems already written")
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_65(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("XX--workersXX", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument("--resume", action="store_true", help="skip the problems already written")
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_66(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--WORKERS", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument("--resume", action="store_true", help="skip the problems already written")
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_67(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=5)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument("--resume", action="store_true", help="skip the problems already written")
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_68(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument(None, nargs="*", help="problem ids, for a quick check")
    parser.add_argument("--resume", action="store_true", help="skip the problems already written")
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_69(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs=None, help="problem ids, for a quick check")
    parser.add_argument("--resume", action="store_true", help="skip the problems already written")
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_70(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help=None)
    parser.add_argument("--resume", action="store_true", help="skip the problems already written")
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_71(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument(nargs="*", help="problem ids, for a quick check")
    parser.add_argument("--resume", action="store_true", help="skip the problems already written")
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_72(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", help="problem ids, for a quick check")
    parser.add_argument("--resume", action="store_true", help="skip the problems already written")
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_73(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", )
    parser.add_argument("--resume", action="store_true", help="skip the problems already written")
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_74(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("XX--onlyXX", nargs="*", help="problem ids, for a quick check")
    parser.add_argument("--resume", action="store_true", help="skip the problems already written")
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_75(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--ONLY", nargs="*", help="problem ids, for a quick check")
    parser.add_argument("--resume", action="store_true", help="skip the problems already written")
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_76(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="XX*XX", help="problem ids, for a quick check")
    parser.add_argument("--resume", action="store_true", help="skip the problems already written")
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_77(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="XXproblem ids, for a quick checkXX")
    parser.add_argument("--resume", action="store_true", help="skip the problems already written")
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_78(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="PROBLEM IDS, FOR A QUICK CHECK")
    parser.add_argument("--resume", action="store_true", help="skip the problems already written")
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_79(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(None, action="store_true", help="skip the problems already written")
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_80(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument("--resume", action=None, help="skip the problems already written")
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_81(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument("--resume", action="store_true", help=None)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_82(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(action="store_true", help="skip the problems already written")
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_83(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument("--resume", help="skip the problems already written")
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_84(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument("--resume", action="store_true", )
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_85(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument("XX--resumeXX", action="store_true", help="skip the problems already written")
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_86(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument("--RESUME", action="store_true", help="skip the problems already written")
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_87(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument("--resume", action="XXstore_trueXX", help="skip the problems already written")
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_88(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument("--resume", action="STORE_TRUE", help="skip the problems already written")
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_89(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument("--resume", action="store_true", help="XXskip the problems already writtenXX")
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_90(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument("--resume", action="store_true", help="SKIP THE PROBLEMS ALREADY WRITTEN")
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_91(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument("--resume", action="store_true", help="skip the problems already written")
    parser.add_argument(None, choices=("classical", "deep"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_92(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument("--resume", action="store_true", help="skip the problems already written")
    parser.add_argument("--methods", choices=None, default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_93(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument("--resume", action="store_true", help="skip the problems already written")
    parser.add_argument("--methods", choices=("classical", "deep"), default=None)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_94(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument("--resume", action="store_true", help="skip the problems already written")
    parser.add_argument(choices=("classical", "deep"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_95(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument("--resume", action="store_true", help="skip the problems already written")
    parser.add_argument("--methods", default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_96(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument("--resume", action="store_true", help="skip the problems already written")
    parser.add_argument("--methods", choices=("classical", "deep"), )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_97(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument("--resume", action="store_true", help="skip the problems already written")
    parser.add_argument("XX--methodsXX", choices=("classical", "deep"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_98(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument("--resume", action="store_true", help="skip the problems already written")
    parser.add_argument("--METHODS", choices=("classical", "deep"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_99(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument("--resume", action="store_true", help="skip the problems already written")
    parser.add_argument("--methods", choices=("XXclassicalXX", "deep"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_100(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument("--resume", action="store_true", help="skip the problems already written")
    parser.add_argument("--methods", choices=("CLASSICAL", "deep"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_101(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument("--resume", action="store_true", help="skip the problems already written")
    parser.add_argument("--methods", choices=("classical", "XXdeepXX"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_102(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument("--resume", action="store_true", help="skip the problems already written")
    parser.add_argument("--methods", choices=("classical", "DEEP"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_103(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument("--resume", action="store_true", help="skip the problems already written")
    parser.add_argument("--methods", choices=("classical", "deep"), default="XXclassicalXX")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_104(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument("--resume", action="store_true", help="skip the problems already written")
    parser.add_argument("--methods", choices=("classical", "deep"), default="CLASSICAL")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_105(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument("--resume", action="store_true", help="skip the problems already written")
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    args = None
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_106(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument("--resume", action="store_true", help="skip the problems already written")
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    args = parser.parse_args(None)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_107(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument("--resume", action="store_true", help="skip the problems already written")
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = None
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_108(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument("--resume", action="store_true", help="skip the problems already written")
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(None, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_109(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument("--resume", action="store_true", help="skip the problems already written")
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, None, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_110(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument("--resume", action="store_true", help="skip the problems already written")
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, None)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_111(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument("--resume", action="store_true", help="skip the problems already written")
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_112(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument("--resume", action="store_true", help="skip the problems already written")
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_113(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument("--resume", action="store_true", help="skip the problems already written")
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, )
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_114(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument("--resume", action="store_true", help="skip the problems already written")
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only and j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_115(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument("--resume", action="store_true", help="skip the problems already written")
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_116(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument("--resume", action="store_true", help="skip the problems already written")
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["XXproblemXX"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_117(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument("--resume", action="store_true", help="skip the problems already written")
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["PROBLEM"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_118(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument("--resume", action="store_true", help="skip the problems already written")
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] not in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_119(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument("--resume", action="store_true", help="skip the problems already written")
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=None, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_120(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument("--resume", action="store_true", help="skip the problems already written")
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=None)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_121(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument("--resume", action="store_true", help="skip the problems already written")
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_122(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument("--resume", action="store_true", help="skip the problems already written")
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, )
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_123(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument("--resume", action="store_true", help="skip the problems already written")
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=False, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_124(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument("--resume", action="store_true", help="skip the problems already written")
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=False)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_125(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument("--resume", action="store_true", help="skip the problems already written")
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = None
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_126(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument("--resume", action="store_true", help="skip the problems already written")
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_127(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument("--resume", action="store_true", help="skip the problems already written")
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output * f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_128(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument("--resume", action="store_true", help="skip the problems already written")
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(None, '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_129(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument("--resume", action="store_true", help="skip the problems already written")
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', None)}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_130(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument("--resume", action="store_true", help="skip the problems already written")
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace('_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_131(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument("--resume", action="store_true", help="skip the problems already written")
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', )}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_132(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument("--resume", action="store_true", help="skip the problems already written")
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['XXproblemXX'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_133(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument("--resume", action="store_true", help="skip the problems already written")
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['PROBLEM'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_134(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument("--resume", action="store_true", help="skip the problems already written")
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace('XX:XX', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_135(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument("--resume", action="store_true", help="skip the problems already written")
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', 'XX_XX')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_136(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument("--resume", action="store_true", help="skip the problems already written")
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = None
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_137(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument("--resume", action="store_true", help="skip the problems already written")
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if (args.methods == "deep") and False else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_138(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument("--resume", action="store_true", help="skip the problems already written")
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if (args.methods == "deep") or True else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_139(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument("--resume", action="store_true", help="skip the problems already written")
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = list(None) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_140(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument("--resume", action="store_true", help="skip the problems already written")
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods != "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_141(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument("--resume", action="store_true", help="skip the problems already written")
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "XXdeepXX" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_142(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument("--resume", action="store_true", help="skip the problems already written")
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "DEEP" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_143(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument("--resume", action="store_true", help="skip the problems already written")
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(None)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_144(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument("--resume", action="store_true", help="skip the problems already written")
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = None
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_145(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument("--resume", action="store_true", help="skip the problems already written")
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 1
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_146(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument("--resume", action="store_true", help="skip the problems already written")
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=None) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_147(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument("--resume", action="store_true", help="skip the problems already written")
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(None, todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_148(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument("--resume", action="store_true", help="skip the problems already written")
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), None):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_149(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument("--resume", action="store_true", help="skip the problems already written")
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_150(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument("--resume", action="store_true", help="skip the problems already written")
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), ):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_151(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument("--resume", action="store_true", help="skip the problems already written")
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(None, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_152(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument("--resume", action="store_true", help="skip the problems already written")
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=None), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_153(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument("--resume", action="store_true", help="skip the problems already written")
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_154(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument("--resume", action="store_true", help="skip the problems already written")
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, ), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_155(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument("--resume", action="store_true", help="skip the problems already written")
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed = "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_156(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument("--resume", action="store_true", help="skip the problems already written")
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed -= "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_157(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument("--resume", action="store_true", help="skip the problems already written")
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "XXfailedXX" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_158(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument("--resume", action="store_true", help="skip the problems already written")
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "FAILED" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_159(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument("--resume", action="store_true", help="skip the problems already written")
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" not in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_160(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument("--resume", action="store_true", help="skip the problems already written")
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = None
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_161(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument("--resume", action="store_true", help="skip the problems already written")
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(None, "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_162(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument("--resume", action="store_true", help="skip the problems already written")
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", None)
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_163(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument("--resume", action="store_true", help="skip the problems already written")
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace("_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_164(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument("--resume", action="store_true", help="skip the problems already written")
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", )
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_165(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument("--resume", action="store_true", help="skip the problems already written")
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["XXproblemXX"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_166(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument("--resume", action="store_true", help="skip the problems already written")
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["PROBLEM"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_167(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument("--resume", action="store_true", help="skip the problems already written")
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace("XX:XX", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_168(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument("--resume", action="store_true", help="skip the problems already written")
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "XX_XX")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_169(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument("--resume", action="store_true", help="skip the problems already written")
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(None) as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_170(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument("--resume", action="store_true", help="skip the problems already written")
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output * f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_171(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument("--resume", action="store_true", help="skip the problems already written")
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(None)
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_172(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument("--resume", action="store_true", help="skip the problems already written")
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) - "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_173(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument("--resume", action="store_true", help="skip the problems already written")
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(None, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_174(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument("--resume", action="store_true", help="skip the problems already written")
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=None) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_175(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument("--resume", action="store_true", help="skip the problems already written")
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_176(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument("--resume", action="store_true", help="skip the problems already written")
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, ) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_177(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument("--resume", action="store_true", help="skip the problems already written")
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=False) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_178(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument("--resume", action="store_true", help="skip the problems already written")
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "XX\nXX")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_179(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument("--resume", action="store_true", help="skip the problems already written")
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(None, result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_180(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument("--resume", action="store_true", help="skip the problems already written")
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["problem"], None, flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_181(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument("--resume", action="store_true", help="skip the problems already written")
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=None)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_182(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument("--resume", action="store_true", help="skip the problems already written")
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_183(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument("--resume", action="store_true", help="skip the problems already written")
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["problem"], flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_184(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument("--resume", action="store_true", help="skip the problems already written")
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), )
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_185(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument("--resume", action="store_true", help="skip the problems already written")
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["XXproblemXX"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_186(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument("--resume", action="store_true", help="skip the problems already written")
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["PROBLEM"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_187(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument("--resume", action="store_true", help="skip the problems already written")
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["problem"], result.get(None, "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_188(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument("--resume", action="store_true", help="skip the problems already written")
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", None), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_189(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument("--resume", action="store_true", help="skip the problems already written")
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["problem"], result.get("ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_190(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument("--resume", action="store_true", help="skip the problems already written")
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", ), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_191(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument("--resume", action="store_true", help="skip the problems already written")
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["problem"], result.get("XXfailedXX", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_192(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument("--resume", action="store_true", help="skip the problems already written")
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["problem"], result.get("FAILED", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_193(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument("--resume", action="store_true", help="skip the problems already written")
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "XXokXX"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_194(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument("--resume", action="store_true", help="skip the problems already written")
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "OK"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_195(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument("--resume", action="store_true", help="skip the problems already written")
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=False)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_196(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument("--resume", action="store_true", help="skip the problems already written")
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(None)
    return 0


def x_main__mutmut_197(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument("--resume", action="store_true", help="skip the problems already written")
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in lb.jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(DETECTOR_NAMES)
    failed = 0
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 1

mutants_x_main__mutmut['_mutmut_orig'] = x_main__mutmut_orig # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_1'] = x_main__mutmut_1 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_2'] = x_main__mutmut_2 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_3'] = x_main__mutmut_3 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_4'] = x_main__mutmut_4 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_5'] = x_main__mutmut_5 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_6'] = x_main__mutmut_6 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_7'] = x_main__mutmut_7 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_8'] = x_main__mutmut_8 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_9'] = x_main__mutmut_9 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_10'] = x_main__mutmut_10 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_11'] = x_main__mutmut_11 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_12'] = x_main__mutmut_12 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_13'] = x_main__mutmut_13 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_14'] = x_main__mutmut_14 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_15'] = x_main__mutmut_15 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_16'] = x_main__mutmut_16 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_17'] = x_main__mutmut_17 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_18'] = x_main__mutmut_18 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_19'] = x_main__mutmut_19 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_20'] = x_main__mutmut_20 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_21'] = x_main__mutmut_21 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_22'] = x_main__mutmut_22 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_23'] = x_main__mutmut_23 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_24'] = x_main__mutmut_24 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_25'] = x_main__mutmut_25 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_26'] = x_main__mutmut_26 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_27'] = x_main__mutmut_27 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_28'] = x_main__mutmut_28 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_29'] = x_main__mutmut_29 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_30'] = x_main__mutmut_30 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_31'] = x_main__mutmut_31 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_32'] = x_main__mutmut_32 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_33'] = x_main__mutmut_33 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_34'] = x_main__mutmut_34 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_35'] = x_main__mutmut_35 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_36'] = x_main__mutmut_36 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_37'] = x_main__mutmut_37 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_38'] = x_main__mutmut_38 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_39'] = x_main__mutmut_39 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_40'] = x_main__mutmut_40 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_41'] = x_main__mutmut_41 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_42'] = x_main__mutmut_42 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_43'] = x_main__mutmut_43 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_44'] = x_main__mutmut_44 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_45'] = x_main__mutmut_45 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_46'] = x_main__mutmut_46 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_47'] = x_main__mutmut_47 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_48'] = x_main__mutmut_48 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_49'] = x_main__mutmut_49 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_50'] = x_main__mutmut_50 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_51'] = x_main__mutmut_51 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_52'] = x_main__mutmut_52 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_53'] = x_main__mutmut_53 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_54'] = x_main__mutmut_54 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_55'] = x_main__mutmut_55 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_56'] = x_main__mutmut_56 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_57'] = x_main__mutmut_57 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_58'] = x_main__mutmut_58 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_59'] = x_main__mutmut_59 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_60'] = x_main__mutmut_60 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_61'] = x_main__mutmut_61 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_62'] = x_main__mutmut_62 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_63'] = x_main__mutmut_63 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_64'] = x_main__mutmut_64 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_65'] = x_main__mutmut_65 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_66'] = x_main__mutmut_66 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_67'] = x_main__mutmut_67 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_68'] = x_main__mutmut_68 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_69'] = x_main__mutmut_69 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_70'] = x_main__mutmut_70 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_71'] = x_main__mutmut_71 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_72'] = x_main__mutmut_72 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_73'] = x_main__mutmut_73 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_74'] = x_main__mutmut_74 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_75'] = x_main__mutmut_75 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_76'] = x_main__mutmut_76 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_77'] = x_main__mutmut_77 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_78'] = x_main__mutmut_78 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_79'] = x_main__mutmut_79 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_80'] = x_main__mutmut_80 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_81'] = x_main__mutmut_81 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_82'] = x_main__mutmut_82 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_83'] = x_main__mutmut_83 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_84'] = x_main__mutmut_84 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_85'] = x_main__mutmut_85 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_86'] = x_main__mutmut_86 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_87'] = x_main__mutmut_87 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_88'] = x_main__mutmut_88 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_89'] = x_main__mutmut_89 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_90'] = x_main__mutmut_90 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_91'] = x_main__mutmut_91 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_92'] = x_main__mutmut_92 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_93'] = x_main__mutmut_93 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_94'] = x_main__mutmut_94 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_95'] = x_main__mutmut_95 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_96'] = x_main__mutmut_96 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_97'] = x_main__mutmut_97 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_98'] = x_main__mutmut_98 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_99'] = x_main__mutmut_99 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_100'] = x_main__mutmut_100 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_101'] = x_main__mutmut_101 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_102'] = x_main__mutmut_102 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_103'] = x_main__mutmut_103 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_104'] = x_main__mutmut_104 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_105'] = x_main__mutmut_105 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_106'] = x_main__mutmut_106 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_107'] = x_main__mutmut_107 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_108'] = x_main__mutmut_108 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_109'] = x_main__mutmut_109 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_110'] = x_main__mutmut_110 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_111'] = x_main__mutmut_111 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_112'] = x_main__mutmut_112 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_113'] = x_main__mutmut_113 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_114'] = x_main__mutmut_114 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_115'] = x_main__mutmut_115 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_116'] = x_main__mutmut_116 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_117'] = x_main__mutmut_117 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_118'] = x_main__mutmut_118 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_119'] = x_main__mutmut_119 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_120'] = x_main__mutmut_120 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_121'] = x_main__mutmut_121 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_122'] = x_main__mutmut_122 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_123'] = x_main__mutmut_123 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_124'] = x_main__mutmut_124 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_125'] = x_main__mutmut_125 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_126'] = x_main__mutmut_126 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_127'] = x_main__mutmut_127 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_128'] = x_main__mutmut_128 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_129'] = x_main__mutmut_129 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_130'] = x_main__mutmut_130 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_131'] = x_main__mutmut_131 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_132'] = x_main__mutmut_132 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_133'] = x_main__mutmut_133 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_134'] = x_main__mutmut_134 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_135'] = x_main__mutmut_135 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_136'] = x_main__mutmut_136 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_137'] = x_main__mutmut_137 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_138'] = x_main__mutmut_138 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_139'] = x_main__mutmut_139 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_140'] = x_main__mutmut_140 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_141'] = x_main__mutmut_141 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_142'] = x_main__mutmut_142 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_143'] = x_main__mutmut_143 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_144'] = x_main__mutmut_144 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_145'] = x_main__mutmut_145 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_146'] = x_main__mutmut_146 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_147'] = x_main__mutmut_147 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_148'] = x_main__mutmut_148 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_149'] = x_main__mutmut_149 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_150'] = x_main__mutmut_150 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_151'] = x_main__mutmut_151 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_152'] = x_main__mutmut_152 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_153'] = x_main__mutmut_153 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_154'] = x_main__mutmut_154 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_155'] = x_main__mutmut_155 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_156'] = x_main__mutmut_156 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_157'] = x_main__mutmut_157 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_158'] = x_main__mutmut_158 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_159'] = x_main__mutmut_159 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_160'] = x_main__mutmut_160 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_161'] = x_main__mutmut_161 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_162'] = x_main__mutmut_162 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_163'] = x_main__mutmut_163 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_164'] = x_main__mutmut_164 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_165'] = x_main__mutmut_165 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_166'] = x_main__mutmut_166 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_167'] = x_main__mutmut_167 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_168'] = x_main__mutmut_168 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_169'] = x_main__mutmut_169 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_170'] = x_main__mutmut_170 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_171'] = x_main__mutmut_171 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_172'] = x_main__mutmut_172 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_173'] = x_main__mutmut_173 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_174'] = x_main__mutmut_174 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_175'] = x_main__mutmut_175 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_176'] = x_main__mutmut_176 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_177'] = x_main__mutmut_177 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_178'] = x_main__mutmut_178 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_179'] = x_main__mutmut_179 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_180'] = x_main__mutmut_180 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_181'] = x_main__mutmut_181 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_182'] = x_main__mutmut_182 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_183'] = x_main__mutmut_183 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_184'] = x_main__mutmut_184 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_185'] = x_main__mutmut_185 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_186'] = x_main__mutmut_186 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_187'] = x_main__mutmut_187 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_188'] = x_main__mutmut_188 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_189'] = x_main__mutmut_189 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_190'] = x_main__mutmut_190 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_191'] = x_main__mutmut_191 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_192'] = x_main__mutmut_192 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_193'] = x_main__mutmut_193 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_194'] = x_main__mutmut_194 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_195'] = x_main__mutmut_195 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_196'] = x_main__mutmut_196 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_197'] = x_main__mutmut_197 # type: ignore # mutmut generated


if __name__ == "__main__":
    raise SystemExit(main())
