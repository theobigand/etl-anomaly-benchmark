"""Heatmaps of the typed-injection results: pooled median and six panels chosen by UCI id."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
import numpy as np  # noqa: E402
import pandas as pd  # noqa: E402

LABELS = {
    "missing_value": "missing",
    "duplicate": "duplicate",
    "univariate_outlier": "univariate",
    "multivariate_outlier": "multivariate",
    "temporal_drift": "drift",
    "invalid_format": "invalid",
}


from mutmut.mutation.trampoline import wrap_in_trampoline as _mutmut_mutated, MutantDict
mutants_x__draw__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x__draw__mutmut)
def _draw(ax, frame: pd.DataFrame, title: str, annotate: bool = True) -> None:
    ax.imshow(frame.to_numpy(dtype=float), cmap="YlGnBu", vmin=0, vmax=1, aspect="auto")
    ax.set_xticks(
        range(frame.shape[1]), [LABELS.get(c, c) for c in frame.columns], rotation=35, ha="right"
    )
    ax.set_yticks(range(frame.shape[0]), list(frame.index))
    ax.set_title(title, fontsize=9)
    if annotate:
        for i in range(frame.shape[0]):
            for j in range(frame.shape[1]):
                v = frame.iloc[i, j]
                ax.text(
                    j,
                    i,
                    f"{v:.2f}",
                    ha="center",
                    va="center",
                    fontsize=6.5,
                    color="white" if v > 0.6 else "black",
                )


def x__draw__mutmut_orig(ax, frame: pd.DataFrame, title: str, annotate: bool = True) -> None:
    ax.imshow(frame.to_numpy(dtype=float), cmap="YlGnBu", vmin=0, vmax=1, aspect="auto")
    ax.set_xticks(
        range(frame.shape[1]), [LABELS.get(c, c) for c in frame.columns], rotation=35, ha="right"
    )
    ax.set_yticks(range(frame.shape[0]), list(frame.index))
    ax.set_title(title, fontsize=9)
    if annotate:
        for i in range(frame.shape[0]):
            for j in range(frame.shape[1]):
                v = frame.iloc[i, j]
                ax.text(
                    j,
                    i,
                    f"{v:.2f}",
                    ha="center",
                    va="center",
                    fontsize=6.5,
                    color="white" if v > 0.6 else "black",
                )


def x__draw__mutmut_1(ax, frame: pd.DataFrame, title: str, annotate: bool = False) -> None:
    ax.imshow(frame.to_numpy(dtype=float), cmap="YlGnBu", vmin=0, vmax=1, aspect="auto")
    ax.set_xticks(
        range(frame.shape[1]), [LABELS.get(c, c) for c in frame.columns], rotation=35, ha="right"
    )
    ax.set_yticks(range(frame.shape[0]), list(frame.index))
    ax.set_title(title, fontsize=9)
    if annotate:
        for i in range(frame.shape[0]):
            for j in range(frame.shape[1]):
                v = frame.iloc[i, j]
                ax.text(
                    j,
                    i,
                    f"{v:.2f}",
                    ha="center",
                    va="center",
                    fontsize=6.5,
                    color="white" if v > 0.6 else "black",
                )


def x__draw__mutmut_2(ax, frame: pd.DataFrame, title: str, annotate: bool = True) -> None:
    ax.imshow(None, cmap="YlGnBu", vmin=0, vmax=1, aspect="auto")
    ax.set_xticks(
        range(frame.shape[1]), [LABELS.get(c, c) for c in frame.columns], rotation=35, ha="right"
    )
    ax.set_yticks(range(frame.shape[0]), list(frame.index))
    ax.set_title(title, fontsize=9)
    if annotate:
        for i in range(frame.shape[0]):
            for j in range(frame.shape[1]):
                v = frame.iloc[i, j]
                ax.text(
                    j,
                    i,
                    f"{v:.2f}",
                    ha="center",
                    va="center",
                    fontsize=6.5,
                    color="white" if v > 0.6 else "black",
                )


def x__draw__mutmut_3(ax, frame: pd.DataFrame, title: str, annotate: bool = True) -> None:
    ax.imshow(frame.to_numpy(dtype=float), cmap=None, vmin=0, vmax=1, aspect="auto")
    ax.set_xticks(
        range(frame.shape[1]), [LABELS.get(c, c) for c in frame.columns], rotation=35, ha="right"
    )
    ax.set_yticks(range(frame.shape[0]), list(frame.index))
    ax.set_title(title, fontsize=9)
    if annotate:
        for i in range(frame.shape[0]):
            for j in range(frame.shape[1]):
                v = frame.iloc[i, j]
                ax.text(
                    j,
                    i,
                    f"{v:.2f}",
                    ha="center",
                    va="center",
                    fontsize=6.5,
                    color="white" if v > 0.6 else "black",
                )


def x__draw__mutmut_4(ax, frame: pd.DataFrame, title: str, annotate: bool = True) -> None:
    ax.imshow(frame.to_numpy(dtype=float), cmap="YlGnBu", vmin=None, vmax=1, aspect="auto")
    ax.set_xticks(
        range(frame.shape[1]), [LABELS.get(c, c) for c in frame.columns], rotation=35, ha="right"
    )
    ax.set_yticks(range(frame.shape[0]), list(frame.index))
    ax.set_title(title, fontsize=9)
    if annotate:
        for i in range(frame.shape[0]):
            for j in range(frame.shape[1]):
                v = frame.iloc[i, j]
                ax.text(
                    j,
                    i,
                    f"{v:.2f}",
                    ha="center",
                    va="center",
                    fontsize=6.5,
                    color="white" if v > 0.6 else "black",
                )


def x__draw__mutmut_5(ax, frame: pd.DataFrame, title: str, annotate: bool = True) -> None:
    ax.imshow(frame.to_numpy(dtype=float), cmap="YlGnBu", vmin=0, vmax=None, aspect="auto")
    ax.set_xticks(
        range(frame.shape[1]), [LABELS.get(c, c) for c in frame.columns], rotation=35, ha="right"
    )
    ax.set_yticks(range(frame.shape[0]), list(frame.index))
    ax.set_title(title, fontsize=9)
    if annotate:
        for i in range(frame.shape[0]):
            for j in range(frame.shape[1]):
                v = frame.iloc[i, j]
                ax.text(
                    j,
                    i,
                    f"{v:.2f}",
                    ha="center",
                    va="center",
                    fontsize=6.5,
                    color="white" if v > 0.6 else "black",
                )


def x__draw__mutmut_6(ax, frame: pd.DataFrame, title: str, annotate: bool = True) -> None:
    ax.imshow(frame.to_numpy(dtype=float), cmap="YlGnBu", vmin=0, vmax=1, aspect=None)
    ax.set_xticks(
        range(frame.shape[1]), [LABELS.get(c, c) for c in frame.columns], rotation=35, ha="right"
    )
    ax.set_yticks(range(frame.shape[0]), list(frame.index))
    ax.set_title(title, fontsize=9)
    if annotate:
        for i in range(frame.shape[0]):
            for j in range(frame.shape[1]):
                v = frame.iloc[i, j]
                ax.text(
                    j,
                    i,
                    f"{v:.2f}",
                    ha="center",
                    va="center",
                    fontsize=6.5,
                    color="white" if v > 0.6 else "black",
                )


def x__draw__mutmut_7(ax, frame: pd.DataFrame, title: str, annotate: bool = True) -> None:
    ax.imshow(cmap="YlGnBu", vmin=0, vmax=1, aspect="auto")
    ax.set_xticks(
        range(frame.shape[1]), [LABELS.get(c, c) for c in frame.columns], rotation=35, ha="right"
    )
    ax.set_yticks(range(frame.shape[0]), list(frame.index))
    ax.set_title(title, fontsize=9)
    if annotate:
        for i in range(frame.shape[0]):
            for j in range(frame.shape[1]):
                v = frame.iloc[i, j]
                ax.text(
                    j,
                    i,
                    f"{v:.2f}",
                    ha="center",
                    va="center",
                    fontsize=6.5,
                    color="white" if v > 0.6 else "black",
                )


def x__draw__mutmut_8(ax, frame: pd.DataFrame, title: str, annotate: bool = True) -> None:
    ax.imshow(frame.to_numpy(dtype=float), vmin=0, vmax=1, aspect="auto")
    ax.set_xticks(
        range(frame.shape[1]), [LABELS.get(c, c) for c in frame.columns], rotation=35, ha="right"
    )
    ax.set_yticks(range(frame.shape[0]), list(frame.index))
    ax.set_title(title, fontsize=9)
    if annotate:
        for i in range(frame.shape[0]):
            for j in range(frame.shape[1]):
                v = frame.iloc[i, j]
                ax.text(
                    j,
                    i,
                    f"{v:.2f}",
                    ha="center",
                    va="center",
                    fontsize=6.5,
                    color="white" if v > 0.6 else "black",
                )


def x__draw__mutmut_9(ax, frame: pd.DataFrame, title: str, annotate: bool = True) -> None:
    ax.imshow(frame.to_numpy(dtype=float), cmap="YlGnBu", vmax=1, aspect="auto")
    ax.set_xticks(
        range(frame.shape[1]), [LABELS.get(c, c) for c in frame.columns], rotation=35, ha="right"
    )
    ax.set_yticks(range(frame.shape[0]), list(frame.index))
    ax.set_title(title, fontsize=9)
    if annotate:
        for i in range(frame.shape[0]):
            for j in range(frame.shape[1]):
                v = frame.iloc[i, j]
                ax.text(
                    j,
                    i,
                    f"{v:.2f}",
                    ha="center",
                    va="center",
                    fontsize=6.5,
                    color="white" if v > 0.6 else "black",
                )


def x__draw__mutmut_10(ax, frame: pd.DataFrame, title: str, annotate: bool = True) -> None:
    ax.imshow(frame.to_numpy(dtype=float), cmap="YlGnBu", vmin=0, aspect="auto")
    ax.set_xticks(
        range(frame.shape[1]), [LABELS.get(c, c) for c in frame.columns], rotation=35, ha="right"
    )
    ax.set_yticks(range(frame.shape[0]), list(frame.index))
    ax.set_title(title, fontsize=9)
    if annotate:
        for i in range(frame.shape[0]):
            for j in range(frame.shape[1]):
                v = frame.iloc[i, j]
                ax.text(
                    j,
                    i,
                    f"{v:.2f}",
                    ha="center",
                    va="center",
                    fontsize=6.5,
                    color="white" if v > 0.6 else "black",
                )


def x__draw__mutmut_11(ax, frame: pd.DataFrame, title: str, annotate: bool = True) -> None:
    ax.imshow(frame.to_numpy(dtype=float), cmap="YlGnBu", vmin=0, vmax=1, )
    ax.set_xticks(
        range(frame.shape[1]), [LABELS.get(c, c) for c in frame.columns], rotation=35, ha="right"
    )
    ax.set_yticks(range(frame.shape[0]), list(frame.index))
    ax.set_title(title, fontsize=9)
    if annotate:
        for i in range(frame.shape[0]):
            for j in range(frame.shape[1]):
                v = frame.iloc[i, j]
                ax.text(
                    j,
                    i,
                    f"{v:.2f}",
                    ha="center",
                    va="center",
                    fontsize=6.5,
                    color="white" if v > 0.6 else "black",
                )


def x__draw__mutmut_12(ax, frame: pd.DataFrame, title: str, annotate: bool = True) -> None:
    ax.imshow(frame.to_numpy(dtype=None), cmap="YlGnBu", vmin=0, vmax=1, aspect="auto")
    ax.set_xticks(
        range(frame.shape[1]), [LABELS.get(c, c) for c in frame.columns], rotation=35, ha="right"
    )
    ax.set_yticks(range(frame.shape[0]), list(frame.index))
    ax.set_title(title, fontsize=9)
    if annotate:
        for i in range(frame.shape[0]):
            for j in range(frame.shape[1]):
                v = frame.iloc[i, j]
                ax.text(
                    j,
                    i,
                    f"{v:.2f}",
                    ha="center",
                    va="center",
                    fontsize=6.5,
                    color="white" if v > 0.6 else "black",
                )


def x__draw__mutmut_13(ax, frame: pd.DataFrame, title: str, annotate: bool = True) -> None:
    ax.imshow(frame.to_numpy(dtype=float), cmap="XXYlGnBuXX", vmin=0, vmax=1, aspect="auto")
    ax.set_xticks(
        range(frame.shape[1]), [LABELS.get(c, c) for c in frame.columns], rotation=35, ha="right"
    )
    ax.set_yticks(range(frame.shape[0]), list(frame.index))
    ax.set_title(title, fontsize=9)
    if annotate:
        for i in range(frame.shape[0]):
            for j in range(frame.shape[1]):
                v = frame.iloc[i, j]
                ax.text(
                    j,
                    i,
                    f"{v:.2f}",
                    ha="center",
                    va="center",
                    fontsize=6.5,
                    color="white" if v > 0.6 else "black",
                )


def x__draw__mutmut_14(ax, frame: pd.DataFrame, title: str, annotate: bool = True) -> None:
    ax.imshow(frame.to_numpy(dtype=float), cmap="ylgnbu", vmin=0, vmax=1, aspect="auto")
    ax.set_xticks(
        range(frame.shape[1]), [LABELS.get(c, c) for c in frame.columns], rotation=35, ha="right"
    )
    ax.set_yticks(range(frame.shape[0]), list(frame.index))
    ax.set_title(title, fontsize=9)
    if annotate:
        for i in range(frame.shape[0]):
            for j in range(frame.shape[1]):
                v = frame.iloc[i, j]
                ax.text(
                    j,
                    i,
                    f"{v:.2f}",
                    ha="center",
                    va="center",
                    fontsize=6.5,
                    color="white" if v > 0.6 else "black",
                )


def x__draw__mutmut_15(ax, frame: pd.DataFrame, title: str, annotate: bool = True) -> None:
    ax.imshow(frame.to_numpy(dtype=float), cmap="YLGNBU", vmin=0, vmax=1, aspect="auto")
    ax.set_xticks(
        range(frame.shape[1]), [LABELS.get(c, c) for c in frame.columns], rotation=35, ha="right"
    )
    ax.set_yticks(range(frame.shape[0]), list(frame.index))
    ax.set_title(title, fontsize=9)
    if annotate:
        for i in range(frame.shape[0]):
            for j in range(frame.shape[1]):
                v = frame.iloc[i, j]
                ax.text(
                    j,
                    i,
                    f"{v:.2f}",
                    ha="center",
                    va="center",
                    fontsize=6.5,
                    color="white" if v > 0.6 else "black",
                )


def x__draw__mutmut_16(ax, frame: pd.DataFrame, title: str, annotate: bool = True) -> None:
    ax.imshow(frame.to_numpy(dtype=float), cmap="YlGnBu", vmin=1, vmax=1, aspect="auto")
    ax.set_xticks(
        range(frame.shape[1]), [LABELS.get(c, c) for c in frame.columns], rotation=35, ha="right"
    )
    ax.set_yticks(range(frame.shape[0]), list(frame.index))
    ax.set_title(title, fontsize=9)
    if annotate:
        for i in range(frame.shape[0]):
            for j in range(frame.shape[1]):
                v = frame.iloc[i, j]
                ax.text(
                    j,
                    i,
                    f"{v:.2f}",
                    ha="center",
                    va="center",
                    fontsize=6.5,
                    color="white" if v > 0.6 else "black",
                )


def x__draw__mutmut_17(ax, frame: pd.DataFrame, title: str, annotate: bool = True) -> None:
    ax.imshow(frame.to_numpy(dtype=float), cmap="YlGnBu", vmin=0, vmax=2, aspect="auto")
    ax.set_xticks(
        range(frame.shape[1]), [LABELS.get(c, c) for c in frame.columns], rotation=35, ha="right"
    )
    ax.set_yticks(range(frame.shape[0]), list(frame.index))
    ax.set_title(title, fontsize=9)
    if annotate:
        for i in range(frame.shape[0]):
            for j in range(frame.shape[1]):
                v = frame.iloc[i, j]
                ax.text(
                    j,
                    i,
                    f"{v:.2f}",
                    ha="center",
                    va="center",
                    fontsize=6.5,
                    color="white" if v > 0.6 else "black",
                )


def x__draw__mutmut_18(ax, frame: pd.DataFrame, title: str, annotate: bool = True) -> None:
    ax.imshow(frame.to_numpy(dtype=float), cmap="YlGnBu", vmin=0, vmax=1, aspect="XXautoXX")
    ax.set_xticks(
        range(frame.shape[1]), [LABELS.get(c, c) for c in frame.columns], rotation=35, ha="right"
    )
    ax.set_yticks(range(frame.shape[0]), list(frame.index))
    ax.set_title(title, fontsize=9)
    if annotate:
        for i in range(frame.shape[0]):
            for j in range(frame.shape[1]):
                v = frame.iloc[i, j]
                ax.text(
                    j,
                    i,
                    f"{v:.2f}",
                    ha="center",
                    va="center",
                    fontsize=6.5,
                    color="white" if v > 0.6 else "black",
                )


def x__draw__mutmut_19(ax, frame: pd.DataFrame, title: str, annotate: bool = True) -> None:
    ax.imshow(frame.to_numpy(dtype=float), cmap="YlGnBu", vmin=0, vmax=1, aspect="AUTO")
    ax.set_xticks(
        range(frame.shape[1]), [LABELS.get(c, c) for c in frame.columns], rotation=35, ha="right"
    )
    ax.set_yticks(range(frame.shape[0]), list(frame.index))
    ax.set_title(title, fontsize=9)
    if annotate:
        for i in range(frame.shape[0]):
            for j in range(frame.shape[1]):
                v = frame.iloc[i, j]
                ax.text(
                    j,
                    i,
                    f"{v:.2f}",
                    ha="center",
                    va="center",
                    fontsize=6.5,
                    color="white" if v > 0.6 else "black",
                )


def x__draw__mutmut_20(ax, frame: pd.DataFrame, title: str, annotate: bool = True) -> None:
    ax.imshow(frame.to_numpy(dtype=float), cmap="YlGnBu", vmin=0, vmax=1, aspect="auto")
    ax.set_xticks(
        None, [LABELS.get(c, c) for c in frame.columns], rotation=35, ha="right"
    )
    ax.set_yticks(range(frame.shape[0]), list(frame.index))
    ax.set_title(title, fontsize=9)
    if annotate:
        for i in range(frame.shape[0]):
            for j in range(frame.shape[1]):
                v = frame.iloc[i, j]
                ax.text(
                    j,
                    i,
                    f"{v:.2f}",
                    ha="center",
                    va="center",
                    fontsize=6.5,
                    color="white" if v > 0.6 else "black",
                )


def x__draw__mutmut_21(ax, frame: pd.DataFrame, title: str, annotate: bool = True) -> None:
    ax.imshow(frame.to_numpy(dtype=float), cmap="YlGnBu", vmin=0, vmax=1, aspect="auto")
    ax.set_xticks(
        range(frame.shape[1]), None, rotation=35, ha="right"
    )
    ax.set_yticks(range(frame.shape[0]), list(frame.index))
    ax.set_title(title, fontsize=9)
    if annotate:
        for i in range(frame.shape[0]):
            for j in range(frame.shape[1]):
                v = frame.iloc[i, j]
                ax.text(
                    j,
                    i,
                    f"{v:.2f}",
                    ha="center",
                    va="center",
                    fontsize=6.5,
                    color="white" if v > 0.6 else "black",
                )


def x__draw__mutmut_22(ax, frame: pd.DataFrame, title: str, annotate: bool = True) -> None:
    ax.imshow(frame.to_numpy(dtype=float), cmap="YlGnBu", vmin=0, vmax=1, aspect="auto")
    ax.set_xticks(
        range(frame.shape[1]), [LABELS.get(c, c) for c in frame.columns], rotation=None, ha="right"
    )
    ax.set_yticks(range(frame.shape[0]), list(frame.index))
    ax.set_title(title, fontsize=9)
    if annotate:
        for i in range(frame.shape[0]):
            for j in range(frame.shape[1]):
                v = frame.iloc[i, j]
                ax.text(
                    j,
                    i,
                    f"{v:.2f}",
                    ha="center",
                    va="center",
                    fontsize=6.5,
                    color="white" if v > 0.6 else "black",
                )


def x__draw__mutmut_23(ax, frame: pd.DataFrame, title: str, annotate: bool = True) -> None:
    ax.imshow(frame.to_numpy(dtype=float), cmap="YlGnBu", vmin=0, vmax=1, aspect="auto")
    ax.set_xticks(
        range(frame.shape[1]), [LABELS.get(c, c) for c in frame.columns], rotation=35, ha=None
    )
    ax.set_yticks(range(frame.shape[0]), list(frame.index))
    ax.set_title(title, fontsize=9)
    if annotate:
        for i in range(frame.shape[0]):
            for j in range(frame.shape[1]):
                v = frame.iloc[i, j]
                ax.text(
                    j,
                    i,
                    f"{v:.2f}",
                    ha="center",
                    va="center",
                    fontsize=6.5,
                    color="white" if v > 0.6 else "black",
                )


def x__draw__mutmut_24(ax, frame: pd.DataFrame, title: str, annotate: bool = True) -> None:
    ax.imshow(frame.to_numpy(dtype=float), cmap="YlGnBu", vmin=0, vmax=1, aspect="auto")
    ax.set_xticks(
        [LABELS.get(c, c) for c in frame.columns], rotation=35, ha="right"
    )
    ax.set_yticks(range(frame.shape[0]), list(frame.index))
    ax.set_title(title, fontsize=9)
    if annotate:
        for i in range(frame.shape[0]):
            for j in range(frame.shape[1]):
                v = frame.iloc[i, j]
                ax.text(
                    j,
                    i,
                    f"{v:.2f}",
                    ha="center",
                    va="center",
                    fontsize=6.5,
                    color="white" if v > 0.6 else "black",
                )


def x__draw__mutmut_25(ax, frame: pd.DataFrame, title: str, annotate: bool = True) -> None:
    ax.imshow(frame.to_numpy(dtype=float), cmap="YlGnBu", vmin=0, vmax=1, aspect="auto")
    ax.set_xticks(
        range(frame.shape[1]), rotation=35, ha="right"
    )
    ax.set_yticks(range(frame.shape[0]), list(frame.index))
    ax.set_title(title, fontsize=9)
    if annotate:
        for i in range(frame.shape[0]):
            for j in range(frame.shape[1]):
                v = frame.iloc[i, j]
                ax.text(
                    j,
                    i,
                    f"{v:.2f}",
                    ha="center",
                    va="center",
                    fontsize=6.5,
                    color="white" if v > 0.6 else "black",
                )


def x__draw__mutmut_26(ax, frame: pd.DataFrame, title: str, annotate: bool = True) -> None:
    ax.imshow(frame.to_numpy(dtype=float), cmap="YlGnBu", vmin=0, vmax=1, aspect="auto")
    ax.set_xticks(
        range(frame.shape[1]), [LABELS.get(c, c) for c in frame.columns], ha="right"
    )
    ax.set_yticks(range(frame.shape[0]), list(frame.index))
    ax.set_title(title, fontsize=9)
    if annotate:
        for i in range(frame.shape[0]):
            for j in range(frame.shape[1]):
                v = frame.iloc[i, j]
                ax.text(
                    j,
                    i,
                    f"{v:.2f}",
                    ha="center",
                    va="center",
                    fontsize=6.5,
                    color="white" if v > 0.6 else "black",
                )


def x__draw__mutmut_27(ax, frame: pd.DataFrame, title: str, annotate: bool = True) -> None:
    ax.imshow(frame.to_numpy(dtype=float), cmap="YlGnBu", vmin=0, vmax=1, aspect="auto")
    ax.set_xticks(
        range(frame.shape[1]), [LABELS.get(c, c) for c in frame.columns], rotation=35, )
    ax.set_yticks(range(frame.shape[0]), list(frame.index))
    ax.set_title(title, fontsize=9)
    if annotate:
        for i in range(frame.shape[0]):
            for j in range(frame.shape[1]):
                v = frame.iloc[i, j]
                ax.text(
                    j,
                    i,
                    f"{v:.2f}",
                    ha="center",
                    va="center",
                    fontsize=6.5,
                    color="white" if v > 0.6 else "black",
                )


def x__draw__mutmut_28(ax, frame: pd.DataFrame, title: str, annotate: bool = True) -> None:
    ax.imshow(frame.to_numpy(dtype=float), cmap="YlGnBu", vmin=0, vmax=1, aspect="auto")
    ax.set_xticks(
        range(None), [LABELS.get(c, c) for c in frame.columns], rotation=35, ha="right"
    )
    ax.set_yticks(range(frame.shape[0]), list(frame.index))
    ax.set_title(title, fontsize=9)
    if annotate:
        for i in range(frame.shape[0]):
            for j in range(frame.shape[1]):
                v = frame.iloc[i, j]
                ax.text(
                    j,
                    i,
                    f"{v:.2f}",
                    ha="center",
                    va="center",
                    fontsize=6.5,
                    color="white" if v > 0.6 else "black",
                )


def x__draw__mutmut_29(ax, frame: pd.DataFrame, title: str, annotate: bool = True) -> None:
    ax.imshow(frame.to_numpy(dtype=float), cmap="YlGnBu", vmin=0, vmax=1, aspect="auto")
    ax.set_xticks(
        range(frame.shape[2]), [LABELS.get(c, c) for c in frame.columns], rotation=35, ha="right"
    )
    ax.set_yticks(range(frame.shape[0]), list(frame.index))
    ax.set_title(title, fontsize=9)
    if annotate:
        for i in range(frame.shape[0]):
            for j in range(frame.shape[1]):
                v = frame.iloc[i, j]
                ax.text(
                    j,
                    i,
                    f"{v:.2f}",
                    ha="center",
                    va="center",
                    fontsize=6.5,
                    color="white" if v > 0.6 else "black",
                )


def x__draw__mutmut_30(ax, frame: pd.DataFrame, title: str, annotate: bool = True) -> None:
    ax.imshow(frame.to_numpy(dtype=float), cmap="YlGnBu", vmin=0, vmax=1, aspect="auto")
    ax.set_xticks(
        range(frame.shape[1]), [LABELS.get(None, c) for c in frame.columns], rotation=35, ha="right"
    )
    ax.set_yticks(range(frame.shape[0]), list(frame.index))
    ax.set_title(title, fontsize=9)
    if annotate:
        for i in range(frame.shape[0]):
            for j in range(frame.shape[1]):
                v = frame.iloc[i, j]
                ax.text(
                    j,
                    i,
                    f"{v:.2f}",
                    ha="center",
                    va="center",
                    fontsize=6.5,
                    color="white" if v > 0.6 else "black",
                )


def x__draw__mutmut_31(ax, frame: pd.DataFrame, title: str, annotate: bool = True) -> None:
    ax.imshow(frame.to_numpy(dtype=float), cmap="YlGnBu", vmin=0, vmax=1, aspect="auto")
    ax.set_xticks(
        range(frame.shape[1]), [LABELS.get(c, None) for c in frame.columns], rotation=35, ha="right"
    )
    ax.set_yticks(range(frame.shape[0]), list(frame.index))
    ax.set_title(title, fontsize=9)
    if annotate:
        for i in range(frame.shape[0]):
            for j in range(frame.shape[1]):
                v = frame.iloc[i, j]
                ax.text(
                    j,
                    i,
                    f"{v:.2f}",
                    ha="center",
                    va="center",
                    fontsize=6.5,
                    color="white" if v > 0.6 else "black",
                )


def x__draw__mutmut_32(ax, frame: pd.DataFrame, title: str, annotate: bool = True) -> None:
    ax.imshow(frame.to_numpy(dtype=float), cmap="YlGnBu", vmin=0, vmax=1, aspect="auto")
    ax.set_xticks(
        range(frame.shape[1]), [LABELS.get(c) for c in frame.columns], rotation=35, ha="right"
    )
    ax.set_yticks(range(frame.shape[0]), list(frame.index))
    ax.set_title(title, fontsize=9)
    if annotate:
        for i in range(frame.shape[0]):
            for j in range(frame.shape[1]):
                v = frame.iloc[i, j]
                ax.text(
                    j,
                    i,
                    f"{v:.2f}",
                    ha="center",
                    va="center",
                    fontsize=6.5,
                    color="white" if v > 0.6 else "black",
                )


def x__draw__mutmut_33(ax, frame: pd.DataFrame, title: str, annotate: bool = True) -> None:
    ax.imshow(frame.to_numpy(dtype=float), cmap="YlGnBu", vmin=0, vmax=1, aspect="auto")
    ax.set_xticks(
        range(frame.shape[1]), [LABELS.get(c, ) for c in frame.columns], rotation=35, ha="right"
    )
    ax.set_yticks(range(frame.shape[0]), list(frame.index))
    ax.set_title(title, fontsize=9)
    if annotate:
        for i in range(frame.shape[0]):
            for j in range(frame.shape[1]):
                v = frame.iloc[i, j]
                ax.text(
                    j,
                    i,
                    f"{v:.2f}",
                    ha="center",
                    va="center",
                    fontsize=6.5,
                    color="white" if v > 0.6 else "black",
                )


def x__draw__mutmut_34(ax, frame: pd.DataFrame, title: str, annotate: bool = True) -> None:
    ax.imshow(frame.to_numpy(dtype=float), cmap="YlGnBu", vmin=0, vmax=1, aspect="auto")
    ax.set_xticks(
        range(frame.shape[1]), [LABELS.get(c, c) for c in frame.columns], rotation=36, ha="right"
    )
    ax.set_yticks(range(frame.shape[0]), list(frame.index))
    ax.set_title(title, fontsize=9)
    if annotate:
        for i in range(frame.shape[0]):
            for j in range(frame.shape[1]):
                v = frame.iloc[i, j]
                ax.text(
                    j,
                    i,
                    f"{v:.2f}",
                    ha="center",
                    va="center",
                    fontsize=6.5,
                    color="white" if v > 0.6 else "black",
                )


def x__draw__mutmut_35(ax, frame: pd.DataFrame, title: str, annotate: bool = True) -> None:
    ax.imshow(frame.to_numpy(dtype=float), cmap="YlGnBu", vmin=0, vmax=1, aspect="auto")
    ax.set_xticks(
        range(frame.shape[1]), [LABELS.get(c, c) for c in frame.columns], rotation=35, ha="XXrightXX"
    )
    ax.set_yticks(range(frame.shape[0]), list(frame.index))
    ax.set_title(title, fontsize=9)
    if annotate:
        for i in range(frame.shape[0]):
            for j in range(frame.shape[1]):
                v = frame.iloc[i, j]
                ax.text(
                    j,
                    i,
                    f"{v:.2f}",
                    ha="center",
                    va="center",
                    fontsize=6.5,
                    color="white" if v > 0.6 else "black",
                )


def x__draw__mutmut_36(ax, frame: pd.DataFrame, title: str, annotate: bool = True) -> None:
    ax.imshow(frame.to_numpy(dtype=float), cmap="YlGnBu", vmin=0, vmax=1, aspect="auto")
    ax.set_xticks(
        range(frame.shape[1]), [LABELS.get(c, c) for c in frame.columns], rotation=35, ha="RIGHT"
    )
    ax.set_yticks(range(frame.shape[0]), list(frame.index))
    ax.set_title(title, fontsize=9)
    if annotate:
        for i in range(frame.shape[0]):
            for j in range(frame.shape[1]):
                v = frame.iloc[i, j]
                ax.text(
                    j,
                    i,
                    f"{v:.2f}",
                    ha="center",
                    va="center",
                    fontsize=6.5,
                    color="white" if v > 0.6 else "black",
                )


def x__draw__mutmut_37(ax, frame: pd.DataFrame, title: str, annotate: bool = True) -> None:
    ax.imshow(frame.to_numpy(dtype=float), cmap="YlGnBu", vmin=0, vmax=1, aspect="auto")
    ax.set_xticks(
        range(frame.shape[1]), [LABELS.get(c, c) for c in frame.columns], rotation=35, ha="right"
    )
    ax.set_yticks(None, list(frame.index))
    ax.set_title(title, fontsize=9)
    if annotate:
        for i in range(frame.shape[0]):
            for j in range(frame.shape[1]):
                v = frame.iloc[i, j]
                ax.text(
                    j,
                    i,
                    f"{v:.2f}",
                    ha="center",
                    va="center",
                    fontsize=6.5,
                    color="white" if v > 0.6 else "black",
                )


def x__draw__mutmut_38(ax, frame: pd.DataFrame, title: str, annotate: bool = True) -> None:
    ax.imshow(frame.to_numpy(dtype=float), cmap="YlGnBu", vmin=0, vmax=1, aspect="auto")
    ax.set_xticks(
        range(frame.shape[1]), [LABELS.get(c, c) for c in frame.columns], rotation=35, ha="right"
    )
    ax.set_yticks(range(frame.shape[0]), None)
    ax.set_title(title, fontsize=9)
    if annotate:
        for i in range(frame.shape[0]):
            for j in range(frame.shape[1]):
                v = frame.iloc[i, j]
                ax.text(
                    j,
                    i,
                    f"{v:.2f}",
                    ha="center",
                    va="center",
                    fontsize=6.5,
                    color="white" if v > 0.6 else "black",
                )


def x__draw__mutmut_39(ax, frame: pd.DataFrame, title: str, annotate: bool = True) -> None:
    ax.imshow(frame.to_numpy(dtype=float), cmap="YlGnBu", vmin=0, vmax=1, aspect="auto")
    ax.set_xticks(
        range(frame.shape[1]), [LABELS.get(c, c) for c in frame.columns], rotation=35, ha="right"
    )
    ax.set_yticks(list(frame.index))
    ax.set_title(title, fontsize=9)
    if annotate:
        for i in range(frame.shape[0]):
            for j in range(frame.shape[1]):
                v = frame.iloc[i, j]
                ax.text(
                    j,
                    i,
                    f"{v:.2f}",
                    ha="center",
                    va="center",
                    fontsize=6.5,
                    color="white" if v > 0.6 else "black",
                )


def x__draw__mutmut_40(ax, frame: pd.DataFrame, title: str, annotate: bool = True) -> None:
    ax.imshow(frame.to_numpy(dtype=float), cmap="YlGnBu", vmin=0, vmax=1, aspect="auto")
    ax.set_xticks(
        range(frame.shape[1]), [LABELS.get(c, c) for c in frame.columns], rotation=35, ha="right"
    )
    ax.set_yticks(range(frame.shape[0]), )
    ax.set_title(title, fontsize=9)
    if annotate:
        for i in range(frame.shape[0]):
            for j in range(frame.shape[1]):
                v = frame.iloc[i, j]
                ax.text(
                    j,
                    i,
                    f"{v:.2f}",
                    ha="center",
                    va="center",
                    fontsize=6.5,
                    color="white" if v > 0.6 else "black",
                )


def x__draw__mutmut_41(ax, frame: pd.DataFrame, title: str, annotate: bool = True) -> None:
    ax.imshow(frame.to_numpy(dtype=float), cmap="YlGnBu", vmin=0, vmax=1, aspect="auto")
    ax.set_xticks(
        range(frame.shape[1]), [LABELS.get(c, c) for c in frame.columns], rotation=35, ha="right"
    )
    ax.set_yticks(range(None), list(frame.index))
    ax.set_title(title, fontsize=9)
    if annotate:
        for i in range(frame.shape[0]):
            for j in range(frame.shape[1]):
                v = frame.iloc[i, j]
                ax.text(
                    j,
                    i,
                    f"{v:.2f}",
                    ha="center",
                    va="center",
                    fontsize=6.5,
                    color="white" if v > 0.6 else "black",
                )


def x__draw__mutmut_42(ax, frame: pd.DataFrame, title: str, annotate: bool = True) -> None:
    ax.imshow(frame.to_numpy(dtype=float), cmap="YlGnBu", vmin=0, vmax=1, aspect="auto")
    ax.set_xticks(
        range(frame.shape[1]), [LABELS.get(c, c) for c in frame.columns], rotation=35, ha="right"
    )
    ax.set_yticks(range(frame.shape[1]), list(frame.index))
    ax.set_title(title, fontsize=9)
    if annotate:
        for i in range(frame.shape[0]):
            for j in range(frame.shape[1]):
                v = frame.iloc[i, j]
                ax.text(
                    j,
                    i,
                    f"{v:.2f}",
                    ha="center",
                    va="center",
                    fontsize=6.5,
                    color="white" if v > 0.6 else "black",
                )


def x__draw__mutmut_43(ax, frame: pd.DataFrame, title: str, annotate: bool = True) -> None:
    ax.imshow(frame.to_numpy(dtype=float), cmap="YlGnBu", vmin=0, vmax=1, aspect="auto")
    ax.set_xticks(
        range(frame.shape[1]), [LABELS.get(c, c) for c in frame.columns], rotation=35, ha="right"
    )
    ax.set_yticks(range(frame.shape[0]), list(None))
    ax.set_title(title, fontsize=9)
    if annotate:
        for i in range(frame.shape[0]):
            for j in range(frame.shape[1]):
                v = frame.iloc[i, j]
                ax.text(
                    j,
                    i,
                    f"{v:.2f}",
                    ha="center",
                    va="center",
                    fontsize=6.5,
                    color="white" if v > 0.6 else "black",
                )


def x__draw__mutmut_44(ax, frame: pd.DataFrame, title: str, annotate: bool = True) -> None:
    ax.imshow(frame.to_numpy(dtype=float), cmap="YlGnBu", vmin=0, vmax=1, aspect="auto")
    ax.set_xticks(
        range(frame.shape[1]), [LABELS.get(c, c) for c in frame.columns], rotation=35, ha="right"
    )
    ax.set_yticks(range(frame.shape[0]), list(frame.index))
    ax.set_title(None, fontsize=9)
    if annotate:
        for i in range(frame.shape[0]):
            for j in range(frame.shape[1]):
                v = frame.iloc[i, j]
                ax.text(
                    j,
                    i,
                    f"{v:.2f}",
                    ha="center",
                    va="center",
                    fontsize=6.5,
                    color="white" if v > 0.6 else "black",
                )


def x__draw__mutmut_45(ax, frame: pd.DataFrame, title: str, annotate: bool = True) -> None:
    ax.imshow(frame.to_numpy(dtype=float), cmap="YlGnBu", vmin=0, vmax=1, aspect="auto")
    ax.set_xticks(
        range(frame.shape[1]), [LABELS.get(c, c) for c in frame.columns], rotation=35, ha="right"
    )
    ax.set_yticks(range(frame.shape[0]), list(frame.index))
    ax.set_title(title, fontsize=None)
    if annotate:
        for i in range(frame.shape[0]):
            for j in range(frame.shape[1]):
                v = frame.iloc[i, j]
                ax.text(
                    j,
                    i,
                    f"{v:.2f}",
                    ha="center",
                    va="center",
                    fontsize=6.5,
                    color="white" if v > 0.6 else "black",
                )


def x__draw__mutmut_46(ax, frame: pd.DataFrame, title: str, annotate: bool = True) -> None:
    ax.imshow(frame.to_numpy(dtype=float), cmap="YlGnBu", vmin=0, vmax=1, aspect="auto")
    ax.set_xticks(
        range(frame.shape[1]), [LABELS.get(c, c) for c in frame.columns], rotation=35, ha="right"
    )
    ax.set_yticks(range(frame.shape[0]), list(frame.index))
    ax.set_title(fontsize=9)
    if annotate:
        for i in range(frame.shape[0]):
            for j in range(frame.shape[1]):
                v = frame.iloc[i, j]
                ax.text(
                    j,
                    i,
                    f"{v:.2f}",
                    ha="center",
                    va="center",
                    fontsize=6.5,
                    color="white" if v > 0.6 else "black",
                )


def x__draw__mutmut_47(ax, frame: pd.DataFrame, title: str, annotate: bool = True) -> None:
    ax.imshow(frame.to_numpy(dtype=float), cmap="YlGnBu", vmin=0, vmax=1, aspect="auto")
    ax.set_xticks(
        range(frame.shape[1]), [LABELS.get(c, c) for c in frame.columns], rotation=35, ha="right"
    )
    ax.set_yticks(range(frame.shape[0]), list(frame.index))
    ax.set_title(title, )
    if annotate:
        for i in range(frame.shape[0]):
            for j in range(frame.shape[1]):
                v = frame.iloc[i, j]
                ax.text(
                    j,
                    i,
                    f"{v:.2f}",
                    ha="center",
                    va="center",
                    fontsize=6.5,
                    color="white" if v > 0.6 else "black",
                )


def x__draw__mutmut_48(ax, frame: pd.DataFrame, title: str, annotate: bool = True) -> None:
    ax.imshow(frame.to_numpy(dtype=float), cmap="YlGnBu", vmin=0, vmax=1, aspect="auto")
    ax.set_xticks(
        range(frame.shape[1]), [LABELS.get(c, c) for c in frame.columns], rotation=35, ha="right"
    )
    ax.set_yticks(range(frame.shape[0]), list(frame.index))
    ax.set_title(title, fontsize=10)
    if annotate:
        for i in range(frame.shape[0]):
            for j in range(frame.shape[1]):
                v = frame.iloc[i, j]
                ax.text(
                    j,
                    i,
                    f"{v:.2f}",
                    ha="center",
                    va="center",
                    fontsize=6.5,
                    color="white" if v > 0.6 else "black",
                )


def x__draw__mutmut_49(ax, frame: pd.DataFrame, title: str, annotate: bool = True) -> None:
    ax.imshow(frame.to_numpy(dtype=float), cmap="YlGnBu", vmin=0, vmax=1, aspect="auto")
    ax.set_xticks(
        range(frame.shape[1]), [LABELS.get(c, c) for c in frame.columns], rotation=35, ha="right"
    )
    ax.set_yticks(range(frame.shape[0]), list(frame.index))
    ax.set_title(title, fontsize=9)
    if annotate:
        for i in range(None):
            for j in range(frame.shape[1]):
                v = frame.iloc[i, j]
                ax.text(
                    j,
                    i,
                    f"{v:.2f}",
                    ha="center",
                    va="center",
                    fontsize=6.5,
                    color="white" if v > 0.6 else "black",
                )


def x__draw__mutmut_50(ax, frame: pd.DataFrame, title: str, annotate: bool = True) -> None:
    ax.imshow(frame.to_numpy(dtype=float), cmap="YlGnBu", vmin=0, vmax=1, aspect="auto")
    ax.set_xticks(
        range(frame.shape[1]), [LABELS.get(c, c) for c in frame.columns], rotation=35, ha="right"
    )
    ax.set_yticks(range(frame.shape[0]), list(frame.index))
    ax.set_title(title, fontsize=9)
    if annotate:
        for i in range(frame.shape[1]):
            for j in range(frame.shape[1]):
                v = frame.iloc[i, j]
                ax.text(
                    j,
                    i,
                    f"{v:.2f}",
                    ha="center",
                    va="center",
                    fontsize=6.5,
                    color="white" if v > 0.6 else "black",
                )


def x__draw__mutmut_51(ax, frame: pd.DataFrame, title: str, annotate: bool = True) -> None:
    ax.imshow(frame.to_numpy(dtype=float), cmap="YlGnBu", vmin=0, vmax=1, aspect="auto")
    ax.set_xticks(
        range(frame.shape[1]), [LABELS.get(c, c) for c in frame.columns], rotation=35, ha="right"
    )
    ax.set_yticks(range(frame.shape[0]), list(frame.index))
    ax.set_title(title, fontsize=9)
    if annotate:
        for i in range(frame.shape[0]):
            for j in range(None):
                v = frame.iloc[i, j]
                ax.text(
                    j,
                    i,
                    f"{v:.2f}",
                    ha="center",
                    va="center",
                    fontsize=6.5,
                    color="white" if v > 0.6 else "black",
                )


def x__draw__mutmut_52(ax, frame: pd.DataFrame, title: str, annotate: bool = True) -> None:
    ax.imshow(frame.to_numpy(dtype=float), cmap="YlGnBu", vmin=0, vmax=1, aspect="auto")
    ax.set_xticks(
        range(frame.shape[1]), [LABELS.get(c, c) for c in frame.columns], rotation=35, ha="right"
    )
    ax.set_yticks(range(frame.shape[0]), list(frame.index))
    ax.set_title(title, fontsize=9)
    if annotate:
        for i in range(frame.shape[0]):
            for j in range(frame.shape[2]):
                v = frame.iloc[i, j]
                ax.text(
                    j,
                    i,
                    f"{v:.2f}",
                    ha="center",
                    va="center",
                    fontsize=6.5,
                    color="white" if v > 0.6 else "black",
                )


def x__draw__mutmut_53(ax, frame: pd.DataFrame, title: str, annotate: bool = True) -> None:
    ax.imshow(frame.to_numpy(dtype=float), cmap="YlGnBu", vmin=0, vmax=1, aspect="auto")
    ax.set_xticks(
        range(frame.shape[1]), [LABELS.get(c, c) for c in frame.columns], rotation=35, ha="right"
    )
    ax.set_yticks(range(frame.shape[0]), list(frame.index))
    ax.set_title(title, fontsize=9)
    if annotate:
        for i in range(frame.shape[0]):
            for j in range(frame.shape[1]):
                v = None
                ax.text(
                    j,
                    i,
                    f"{v:.2f}",
                    ha="center",
                    va="center",
                    fontsize=6.5,
                    color="white" if v > 0.6 else "black",
                )


def x__draw__mutmut_54(ax, frame: pd.DataFrame, title: str, annotate: bool = True) -> None:
    ax.imshow(frame.to_numpy(dtype=float), cmap="YlGnBu", vmin=0, vmax=1, aspect="auto")
    ax.set_xticks(
        range(frame.shape[1]), [LABELS.get(c, c) for c in frame.columns], rotation=35, ha="right"
    )
    ax.set_yticks(range(frame.shape[0]), list(frame.index))
    ax.set_title(title, fontsize=9)
    if annotate:
        for i in range(frame.shape[0]):
            for j in range(frame.shape[1]):
                v = frame.iloc[i, j]
                ax.text(
                    None,
                    i,
                    f"{v:.2f}",
                    ha="center",
                    va="center",
                    fontsize=6.5,
                    color="white" if v > 0.6 else "black",
                )


def x__draw__mutmut_55(ax, frame: pd.DataFrame, title: str, annotate: bool = True) -> None:
    ax.imshow(frame.to_numpy(dtype=float), cmap="YlGnBu", vmin=0, vmax=1, aspect="auto")
    ax.set_xticks(
        range(frame.shape[1]), [LABELS.get(c, c) for c in frame.columns], rotation=35, ha="right"
    )
    ax.set_yticks(range(frame.shape[0]), list(frame.index))
    ax.set_title(title, fontsize=9)
    if annotate:
        for i in range(frame.shape[0]):
            for j in range(frame.shape[1]):
                v = frame.iloc[i, j]
                ax.text(
                    j,
                    None,
                    f"{v:.2f}",
                    ha="center",
                    va="center",
                    fontsize=6.5,
                    color="white" if v > 0.6 else "black",
                )


def x__draw__mutmut_56(ax, frame: pd.DataFrame, title: str, annotate: bool = True) -> None:
    ax.imshow(frame.to_numpy(dtype=float), cmap="YlGnBu", vmin=0, vmax=1, aspect="auto")
    ax.set_xticks(
        range(frame.shape[1]), [LABELS.get(c, c) for c in frame.columns], rotation=35, ha="right"
    )
    ax.set_yticks(range(frame.shape[0]), list(frame.index))
    ax.set_title(title, fontsize=9)
    if annotate:
        for i in range(frame.shape[0]):
            for j in range(frame.shape[1]):
                v = frame.iloc[i, j]
                ax.text(
                    j,
                    i,
                    None,
                    ha="center",
                    va="center",
                    fontsize=6.5,
                    color="white" if v > 0.6 else "black",
                )


def x__draw__mutmut_57(ax, frame: pd.DataFrame, title: str, annotate: bool = True) -> None:
    ax.imshow(frame.to_numpy(dtype=float), cmap="YlGnBu", vmin=0, vmax=1, aspect="auto")
    ax.set_xticks(
        range(frame.shape[1]), [LABELS.get(c, c) for c in frame.columns], rotation=35, ha="right"
    )
    ax.set_yticks(range(frame.shape[0]), list(frame.index))
    ax.set_title(title, fontsize=9)
    if annotate:
        for i in range(frame.shape[0]):
            for j in range(frame.shape[1]):
                v = frame.iloc[i, j]
                ax.text(
                    j,
                    i,
                    f"{v:.2f}",
                    ha=None,
                    va="center",
                    fontsize=6.5,
                    color="white" if v > 0.6 else "black",
                )


def x__draw__mutmut_58(ax, frame: pd.DataFrame, title: str, annotate: bool = True) -> None:
    ax.imshow(frame.to_numpy(dtype=float), cmap="YlGnBu", vmin=0, vmax=1, aspect="auto")
    ax.set_xticks(
        range(frame.shape[1]), [LABELS.get(c, c) for c in frame.columns], rotation=35, ha="right"
    )
    ax.set_yticks(range(frame.shape[0]), list(frame.index))
    ax.set_title(title, fontsize=9)
    if annotate:
        for i in range(frame.shape[0]):
            for j in range(frame.shape[1]):
                v = frame.iloc[i, j]
                ax.text(
                    j,
                    i,
                    f"{v:.2f}",
                    ha="center",
                    va=None,
                    fontsize=6.5,
                    color="white" if v > 0.6 else "black",
                )


def x__draw__mutmut_59(ax, frame: pd.DataFrame, title: str, annotate: bool = True) -> None:
    ax.imshow(frame.to_numpy(dtype=float), cmap="YlGnBu", vmin=0, vmax=1, aspect="auto")
    ax.set_xticks(
        range(frame.shape[1]), [LABELS.get(c, c) for c in frame.columns], rotation=35, ha="right"
    )
    ax.set_yticks(range(frame.shape[0]), list(frame.index))
    ax.set_title(title, fontsize=9)
    if annotate:
        for i in range(frame.shape[0]):
            for j in range(frame.shape[1]):
                v = frame.iloc[i, j]
                ax.text(
                    j,
                    i,
                    f"{v:.2f}",
                    ha="center",
                    va="center",
                    fontsize=None,
                    color="white" if v > 0.6 else "black",
                )


def x__draw__mutmut_60(ax, frame: pd.DataFrame, title: str, annotate: bool = True) -> None:
    ax.imshow(frame.to_numpy(dtype=float), cmap="YlGnBu", vmin=0, vmax=1, aspect="auto")
    ax.set_xticks(
        range(frame.shape[1]), [LABELS.get(c, c) for c in frame.columns], rotation=35, ha="right"
    )
    ax.set_yticks(range(frame.shape[0]), list(frame.index))
    ax.set_title(title, fontsize=9)
    if annotate:
        for i in range(frame.shape[0]):
            for j in range(frame.shape[1]):
                v = frame.iloc[i, j]
                ax.text(
                    j,
                    i,
                    f"{v:.2f}",
                    ha="center",
                    va="center",
                    fontsize=6.5,
                    color=None,
                )


def x__draw__mutmut_61(ax, frame: pd.DataFrame, title: str, annotate: bool = True) -> None:
    ax.imshow(frame.to_numpy(dtype=float), cmap="YlGnBu", vmin=0, vmax=1, aspect="auto")
    ax.set_xticks(
        range(frame.shape[1]), [LABELS.get(c, c) for c in frame.columns], rotation=35, ha="right"
    )
    ax.set_yticks(range(frame.shape[0]), list(frame.index))
    ax.set_title(title, fontsize=9)
    if annotate:
        for i in range(frame.shape[0]):
            for j in range(frame.shape[1]):
                v = frame.iloc[i, j]
                ax.text(
                    i,
                    f"{v:.2f}",
                    ha="center",
                    va="center",
                    fontsize=6.5,
                    color="white" if v > 0.6 else "black",
                )


def x__draw__mutmut_62(ax, frame: pd.DataFrame, title: str, annotate: bool = True) -> None:
    ax.imshow(frame.to_numpy(dtype=float), cmap="YlGnBu", vmin=0, vmax=1, aspect="auto")
    ax.set_xticks(
        range(frame.shape[1]), [LABELS.get(c, c) for c in frame.columns], rotation=35, ha="right"
    )
    ax.set_yticks(range(frame.shape[0]), list(frame.index))
    ax.set_title(title, fontsize=9)
    if annotate:
        for i in range(frame.shape[0]):
            for j in range(frame.shape[1]):
                v = frame.iloc[i, j]
                ax.text(
                    j,
                    f"{v:.2f}",
                    ha="center",
                    va="center",
                    fontsize=6.5,
                    color="white" if v > 0.6 else "black",
                )


def x__draw__mutmut_63(ax, frame: pd.DataFrame, title: str, annotate: bool = True) -> None:
    ax.imshow(frame.to_numpy(dtype=float), cmap="YlGnBu", vmin=0, vmax=1, aspect="auto")
    ax.set_xticks(
        range(frame.shape[1]), [LABELS.get(c, c) for c in frame.columns], rotation=35, ha="right"
    )
    ax.set_yticks(range(frame.shape[0]), list(frame.index))
    ax.set_title(title, fontsize=9)
    if annotate:
        for i in range(frame.shape[0]):
            for j in range(frame.shape[1]):
                v = frame.iloc[i, j]
                ax.text(
                    j,
                    i,
                    ha="center",
                    va="center",
                    fontsize=6.5,
                    color="white" if v > 0.6 else "black",
                )


def x__draw__mutmut_64(ax, frame: pd.DataFrame, title: str, annotate: bool = True) -> None:
    ax.imshow(frame.to_numpy(dtype=float), cmap="YlGnBu", vmin=0, vmax=1, aspect="auto")
    ax.set_xticks(
        range(frame.shape[1]), [LABELS.get(c, c) for c in frame.columns], rotation=35, ha="right"
    )
    ax.set_yticks(range(frame.shape[0]), list(frame.index))
    ax.set_title(title, fontsize=9)
    if annotate:
        for i in range(frame.shape[0]):
            for j in range(frame.shape[1]):
                v = frame.iloc[i, j]
                ax.text(
                    j,
                    i,
                    f"{v:.2f}",
                    va="center",
                    fontsize=6.5,
                    color="white" if v > 0.6 else "black",
                )


def x__draw__mutmut_65(ax, frame: pd.DataFrame, title: str, annotate: bool = True) -> None:
    ax.imshow(frame.to_numpy(dtype=float), cmap="YlGnBu", vmin=0, vmax=1, aspect="auto")
    ax.set_xticks(
        range(frame.shape[1]), [LABELS.get(c, c) for c in frame.columns], rotation=35, ha="right"
    )
    ax.set_yticks(range(frame.shape[0]), list(frame.index))
    ax.set_title(title, fontsize=9)
    if annotate:
        for i in range(frame.shape[0]):
            for j in range(frame.shape[1]):
                v = frame.iloc[i, j]
                ax.text(
                    j,
                    i,
                    f"{v:.2f}",
                    ha="center",
                    fontsize=6.5,
                    color="white" if v > 0.6 else "black",
                )


def x__draw__mutmut_66(ax, frame: pd.DataFrame, title: str, annotate: bool = True) -> None:
    ax.imshow(frame.to_numpy(dtype=float), cmap="YlGnBu", vmin=0, vmax=1, aspect="auto")
    ax.set_xticks(
        range(frame.shape[1]), [LABELS.get(c, c) for c in frame.columns], rotation=35, ha="right"
    )
    ax.set_yticks(range(frame.shape[0]), list(frame.index))
    ax.set_title(title, fontsize=9)
    if annotate:
        for i in range(frame.shape[0]):
            for j in range(frame.shape[1]):
                v = frame.iloc[i, j]
                ax.text(
                    j,
                    i,
                    f"{v:.2f}",
                    ha="center",
                    va="center",
                    color="white" if v > 0.6 else "black",
                )


def x__draw__mutmut_67(ax, frame: pd.DataFrame, title: str, annotate: bool = True) -> None:
    ax.imshow(frame.to_numpy(dtype=float), cmap="YlGnBu", vmin=0, vmax=1, aspect="auto")
    ax.set_xticks(
        range(frame.shape[1]), [LABELS.get(c, c) for c in frame.columns], rotation=35, ha="right"
    )
    ax.set_yticks(range(frame.shape[0]), list(frame.index))
    ax.set_title(title, fontsize=9)
    if annotate:
        for i in range(frame.shape[0]):
            for j in range(frame.shape[1]):
                v = frame.iloc[i, j]
                ax.text(
                    j,
                    i,
                    f"{v:.2f}",
                    ha="center",
                    va="center",
                    fontsize=6.5,
                    )


def x__draw__mutmut_68(ax, frame: pd.DataFrame, title: str, annotate: bool = True) -> None:
    ax.imshow(frame.to_numpy(dtype=float), cmap="YlGnBu", vmin=0, vmax=1, aspect="auto")
    ax.set_xticks(
        range(frame.shape[1]), [LABELS.get(c, c) for c in frame.columns], rotation=35, ha="right"
    )
    ax.set_yticks(range(frame.shape[0]), list(frame.index))
    ax.set_title(title, fontsize=9)
    if annotate:
        for i in range(frame.shape[0]):
            for j in range(frame.shape[1]):
                v = frame.iloc[i, j]
                ax.text(
                    j,
                    i,
                    f"{v:.2f}",
                    ha="XXcenterXX",
                    va="center",
                    fontsize=6.5,
                    color="white" if v > 0.6 else "black",
                )


def x__draw__mutmut_69(ax, frame: pd.DataFrame, title: str, annotate: bool = True) -> None:
    ax.imshow(frame.to_numpy(dtype=float), cmap="YlGnBu", vmin=0, vmax=1, aspect="auto")
    ax.set_xticks(
        range(frame.shape[1]), [LABELS.get(c, c) for c in frame.columns], rotation=35, ha="right"
    )
    ax.set_yticks(range(frame.shape[0]), list(frame.index))
    ax.set_title(title, fontsize=9)
    if annotate:
        for i in range(frame.shape[0]):
            for j in range(frame.shape[1]):
                v = frame.iloc[i, j]
                ax.text(
                    j,
                    i,
                    f"{v:.2f}",
                    ha="CENTER",
                    va="center",
                    fontsize=6.5,
                    color="white" if v > 0.6 else "black",
                )


def x__draw__mutmut_70(ax, frame: pd.DataFrame, title: str, annotate: bool = True) -> None:
    ax.imshow(frame.to_numpy(dtype=float), cmap="YlGnBu", vmin=0, vmax=1, aspect="auto")
    ax.set_xticks(
        range(frame.shape[1]), [LABELS.get(c, c) for c in frame.columns], rotation=35, ha="right"
    )
    ax.set_yticks(range(frame.shape[0]), list(frame.index))
    ax.set_title(title, fontsize=9)
    if annotate:
        for i in range(frame.shape[0]):
            for j in range(frame.shape[1]):
                v = frame.iloc[i, j]
                ax.text(
                    j,
                    i,
                    f"{v:.2f}",
                    ha="center",
                    va="XXcenterXX",
                    fontsize=6.5,
                    color="white" if v > 0.6 else "black",
                )


def x__draw__mutmut_71(ax, frame: pd.DataFrame, title: str, annotate: bool = True) -> None:
    ax.imshow(frame.to_numpy(dtype=float), cmap="YlGnBu", vmin=0, vmax=1, aspect="auto")
    ax.set_xticks(
        range(frame.shape[1]), [LABELS.get(c, c) for c in frame.columns], rotation=35, ha="right"
    )
    ax.set_yticks(range(frame.shape[0]), list(frame.index))
    ax.set_title(title, fontsize=9)
    if annotate:
        for i in range(frame.shape[0]):
            for j in range(frame.shape[1]):
                v = frame.iloc[i, j]
                ax.text(
                    j,
                    i,
                    f"{v:.2f}",
                    ha="center",
                    va="CENTER",
                    fontsize=6.5,
                    color="white" if v > 0.6 else "black",
                )


def x__draw__mutmut_72(ax, frame: pd.DataFrame, title: str, annotate: bool = True) -> None:
    ax.imshow(frame.to_numpy(dtype=float), cmap="YlGnBu", vmin=0, vmax=1, aspect="auto")
    ax.set_xticks(
        range(frame.shape[1]), [LABELS.get(c, c) for c in frame.columns], rotation=35, ha="right"
    )
    ax.set_yticks(range(frame.shape[0]), list(frame.index))
    ax.set_title(title, fontsize=9)
    if annotate:
        for i in range(frame.shape[0]):
            for j in range(frame.shape[1]):
                v = frame.iloc[i, j]
                ax.text(
                    j,
                    i,
                    f"{v:.2f}",
                    ha="center",
                    va="center",
                    fontsize=7.5,
                    color="white" if v > 0.6 else "black",
                )


def x__draw__mutmut_73(ax, frame: pd.DataFrame, title: str, annotate: bool = True) -> None:
    ax.imshow(frame.to_numpy(dtype=float), cmap="YlGnBu", vmin=0, vmax=1, aspect="auto")
    ax.set_xticks(
        range(frame.shape[1]), [LABELS.get(c, c) for c in frame.columns], rotation=35, ha="right"
    )
    ax.set_yticks(range(frame.shape[0]), list(frame.index))
    ax.set_title(title, fontsize=9)
    if annotate:
        for i in range(frame.shape[0]):
            for j in range(frame.shape[1]):
                v = frame.iloc[i, j]
                ax.text(
                    j,
                    i,
                    f"{v:.2f}",
                    ha="center",
                    va="center",
                    fontsize=6.5,
                    color="white" if (v > 0.6) and False else "black",
                )


def x__draw__mutmut_74(ax, frame: pd.DataFrame, title: str, annotate: bool = True) -> None:
    ax.imshow(frame.to_numpy(dtype=float), cmap="YlGnBu", vmin=0, vmax=1, aspect="auto")
    ax.set_xticks(
        range(frame.shape[1]), [LABELS.get(c, c) for c in frame.columns], rotation=35, ha="right"
    )
    ax.set_yticks(range(frame.shape[0]), list(frame.index))
    ax.set_title(title, fontsize=9)
    if annotate:
        for i in range(frame.shape[0]):
            for j in range(frame.shape[1]):
                v = frame.iloc[i, j]
                ax.text(
                    j,
                    i,
                    f"{v:.2f}",
                    ha="center",
                    va="center",
                    fontsize=6.5,
                    color="white" if (v > 0.6) or True else "black",
                )


def x__draw__mutmut_75(ax, frame: pd.DataFrame, title: str, annotate: bool = True) -> None:
    ax.imshow(frame.to_numpy(dtype=float), cmap="YlGnBu", vmin=0, vmax=1, aspect="auto")
    ax.set_xticks(
        range(frame.shape[1]), [LABELS.get(c, c) for c in frame.columns], rotation=35, ha="right"
    )
    ax.set_yticks(range(frame.shape[0]), list(frame.index))
    ax.set_title(title, fontsize=9)
    if annotate:
        for i in range(frame.shape[0]):
            for j in range(frame.shape[1]):
                v = frame.iloc[i, j]
                ax.text(
                    j,
                    i,
                    f"{v:.2f}",
                    ha="center",
                    va="center",
                    fontsize=6.5,
                    color="XXwhiteXX" if v > 0.6 else "black",
                )


def x__draw__mutmut_76(ax, frame: pd.DataFrame, title: str, annotate: bool = True) -> None:
    ax.imshow(frame.to_numpy(dtype=float), cmap="YlGnBu", vmin=0, vmax=1, aspect="auto")
    ax.set_xticks(
        range(frame.shape[1]), [LABELS.get(c, c) for c in frame.columns], rotation=35, ha="right"
    )
    ax.set_yticks(range(frame.shape[0]), list(frame.index))
    ax.set_title(title, fontsize=9)
    if annotate:
        for i in range(frame.shape[0]):
            for j in range(frame.shape[1]):
                v = frame.iloc[i, j]
                ax.text(
                    j,
                    i,
                    f"{v:.2f}",
                    ha="center",
                    va="center",
                    fontsize=6.5,
                    color="WHITE" if v > 0.6 else "black",
                )


def x__draw__mutmut_77(ax, frame: pd.DataFrame, title: str, annotate: bool = True) -> None:
    ax.imshow(frame.to_numpy(dtype=float), cmap="YlGnBu", vmin=0, vmax=1, aspect="auto")
    ax.set_xticks(
        range(frame.shape[1]), [LABELS.get(c, c) for c in frame.columns], rotation=35, ha="right"
    )
    ax.set_yticks(range(frame.shape[0]), list(frame.index))
    ax.set_title(title, fontsize=9)
    if annotate:
        for i in range(frame.shape[0]):
            for j in range(frame.shape[1]):
                v = frame.iloc[i, j]
                ax.text(
                    j,
                    i,
                    f"{v:.2f}",
                    ha="center",
                    va="center",
                    fontsize=6.5,
                    color="white" if v >= 0.6 else "black",
                )


def x__draw__mutmut_78(ax, frame: pd.DataFrame, title: str, annotate: bool = True) -> None:
    ax.imshow(frame.to_numpy(dtype=float), cmap="YlGnBu", vmin=0, vmax=1, aspect="auto")
    ax.set_xticks(
        range(frame.shape[1]), [LABELS.get(c, c) for c in frame.columns], rotation=35, ha="right"
    )
    ax.set_yticks(range(frame.shape[0]), list(frame.index))
    ax.set_title(title, fontsize=9)
    if annotate:
        for i in range(frame.shape[0]):
            for j in range(frame.shape[1]):
                v = frame.iloc[i, j]
                ax.text(
                    j,
                    i,
                    f"{v:.2f}",
                    ha="center",
                    va="center",
                    fontsize=6.5,
                    color="white" if v > 1.6 else "black",
                )


def x__draw__mutmut_79(ax, frame: pd.DataFrame, title: str, annotate: bool = True) -> None:
    ax.imshow(frame.to_numpy(dtype=float), cmap="YlGnBu", vmin=0, vmax=1, aspect="auto")
    ax.set_xticks(
        range(frame.shape[1]), [LABELS.get(c, c) for c in frame.columns], rotation=35, ha="right"
    )
    ax.set_yticks(range(frame.shape[0]), list(frame.index))
    ax.set_title(title, fontsize=9)
    if annotate:
        for i in range(frame.shape[0]):
            for j in range(frame.shape[1]):
                v = frame.iloc[i, j]
                ax.text(
                    j,
                    i,
                    f"{v:.2f}",
                    ha="center",
                    va="center",
                    fontsize=6.5,
                    color="white" if v > 0.6 else "XXblackXX",
                )


def x__draw__mutmut_80(ax, frame: pd.DataFrame, title: str, annotate: bool = True) -> None:
    ax.imshow(frame.to_numpy(dtype=float), cmap="YlGnBu", vmin=0, vmax=1, aspect="auto")
    ax.set_xticks(
        range(frame.shape[1]), [LABELS.get(c, c) for c in frame.columns], rotation=35, ha="right"
    )
    ax.set_yticks(range(frame.shape[0]), list(frame.index))
    ax.set_title(title, fontsize=9)
    if annotate:
        for i in range(frame.shape[0]):
            for j in range(frame.shape[1]):
                v = frame.iloc[i, j]
                ax.text(
                    j,
                    i,
                    f"{v:.2f}",
                    ha="center",
                    va="center",
                    fontsize=6.5,
                    color="white" if v > 0.6 else "BLACK",
                )

mutants_x__draw__mutmut['_mutmut_orig'] = x__draw__mutmut_orig # type: ignore # mutmut generated
mutants_x__draw__mutmut['x__draw__mutmut_1'] = x__draw__mutmut_1 # type: ignore # mutmut generated
mutants_x__draw__mutmut['x__draw__mutmut_2'] = x__draw__mutmut_2 # type: ignore # mutmut generated
mutants_x__draw__mutmut['x__draw__mutmut_3'] = x__draw__mutmut_3 # type: ignore # mutmut generated
mutants_x__draw__mutmut['x__draw__mutmut_4'] = x__draw__mutmut_4 # type: ignore # mutmut generated
mutants_x__draw__mutmut['x__draw__mutmut_5'] = x__draw__mutmut_5 # type: ignore # mutmut generated
mutants_x__draw__mutmut['x__draw__mutmut_6'] = x__draw__mutmut_6 # type: ignore # mutmut generated
mutants_x__draw__mutmut['x__draw__mutmut_7'] = x__draw__mutmut_7 # type: ignore # mutmut generated
mutants_x__draw__mutmut['x__draw__mutmut_8'] = x__draw__mutmut_8 # type: ignore # mutmut generated
mutants_x__draw__mutmut['x__draw__mutmut_9'] = x__draw__mutmut_9 # type: ignore # mutmut generated
mutants_x__draw__mutmut['x__draw__mutmut_10'] = x__draw__mutmut_10 # type: ignore # mutmut generated
mutants_x__draw__mutmut['x__draw__mutmut_11'] = x__draw__mutmut_11 # type: ignore # mutmut generated
mutants_x__draw__mutmut['x__draw__mutmut_12'] = x__draw__mutmut_12 # type: ignore # mutmut generated
mutants_x__draw__mutmut['x__draw__mutmut_13'] = x__draw__mutmut_13 # type: ignore # mutmut generated
mutants_x__draw__mutmut['x__draw__mutmut_14'] = x__draw__mutmut_14 # type: ignore # mutmut generated
mutants_x__draw__mutmut['x__draw__mutmut_15'] = x__draw__mutmut_15 # type: ignore # mutmut generated
mutants_x__draw__mutmut['x__draw__mutmut_16'] = x__draw__mutmut_16 # type: ignore # mutmut generated
mutants_x__draw__mutmut['x__draw__mutmut_17'] = x__draw__mutmut_17 # type: ignore # mutmut generated
mutants_x__draw__mutmut['x__draw__mutmut_18'] = x__draw__mutmut_18 # type: ignore # mutmut generated
mutants_x__draw__mutmut['x__draw__mutmut_19'] = x__draw__mutmut_19 # type: ignore # mutmut generated
mutants_x__draw__mutmut['x__draw__mutmut_20'] = x__draw__mutmut_20 # type: ignore # mutmut generated
mutants_x__draw__mutmut['x__draw__mutmut_21'] = x__draw__mutmut_21 # type: ignore # mutmut generated
mutants_x__draw__mutmut['x__draw__mutmut_22'] = x__draw__mutmut_22 # type: ignore # mutmut generated
mutants_x__draw__mutmut['x__draw__mutmut_23'] = x__draw__mutmut_23 # type: ignore # mutmut generated
mutants_x__draw__mutmut['x__draw__mutmut_24'] = x__draw__mutmut_24 # type: ignore # mutmut generated
mutants_x__draw__mutmut['x__draw__mutmut_25'] = x__draw__mutmut_25 # type: ignore # mutmut generated
mutants_x__draw__mutmut['x__draw__mutmut_26'] = x__draw__mutmut_26 # type: ignore # mutmut generated
mutants_x__draw__mutmut['x__draw__mutmut_27'] = x__draw__mutmut_27 # type: ignore # mutmut generated
mutants_x__draw__mutmut['x__draw__mutmut_28'] = x__draw__mutmut_28 # type: ignore # mutmut generated
mutants_x__draw__mutmut['x__draw__mutmut_29'] = x__draw__mutmut_29 # type: ignore # mutmut generated
mutants_x__draw__mutmut['x__draw__mutmut_30'] = x__draw__mutmut_30 # type: ignore # mutmut generated
mutants_x__draw__mutmut['x__draw__mutmut_31'] = x__draw__mutmut_31 # type: ignore # mutmut generated
mutants_x__draw__mutmut['x__draw__mutmut_32'] = x__draw__mutmut_32 # type: ignore # mutmut generated
mutants_x__draw__mutmut['x__draw__mutmut_33'] = x__draw__mutmut_33 # type: ignore # mutmut generated
mutants_x__draw__mutmut['x__draw__mutmut_34'] = x__draw__mutmut_34 # type: ignore # mutmut generated
mutants_x__draw__mutmut['x__draw__mutmut_35'] = x__draw__mutmut_35 # type: ignore # mutmut generated
mutants_x__draw__mutmut['x__draw__mutmut_36'] = x__draw__mutmut_36 # type: ignore # mutmut generated
mutants_x__draw__mutmut['x__draw__mutmut_37'] = x__draw__mutmut_37 # type: ignore # mutmut generated
mutants_x__draw__mutmut['x__draw__mutmut_38'] = x__draw__mutmut_38 # type: ignore # mutmut generated
mutants_x__draw__mutmut['x__draw__mutmut_39'] = x__draw__mutmut_39 # type: ignore # mutmut generated
mutants_x__draw__mutmut['x__draw__mutmut_40'] = x__draw__mutmut_40 # type: ignore # mutmut generated
mutants_x__draw__mutmut['x__draw__mutmut_41'] = x__draw__mutmut_41 # type: ignore # mutmut generated
mutants_x__draw__mutmut['x__draw__mutmut_42'] = x__draw__mutmut_42 # type: ignore # mutmut generated
mutants_x__draw__mutmut['x__draw__mutmut_43'] = x__draw__mutmut_43 # type: ignore # mutmut generated
mutants_x__draw__mutmut['x__draw__mutmut_44'] = x__draw__mutmut_44 # type: ignore # mutmut generated
mutants_x__draw__mutmut['x__draw__mutmut_45'] = x__draw__mutmut_45 # type: ignore # mutmut generated
mutants_x__draw__mutmut['x__draw__mutmut_46'] = x__draw__mutmut_46 # type: ignore # mutmut generated
mutants_x__draw__mutmut['x__draw__mutmut_47'] = x__draw__mutmut_47 # type: ignore # mutmut generated
mutants_x__draw__mutmut['x__draw__mutmut_48'] = x__draw__mutmut_48 # type: ignore # mutmut generated
mutants_x__draw__mutmut['x__draw__mutmut_49'] = x__draw__mutmut_49 # type: ignore # mutmut generated
mutants_x__draw__mutmut['x__draw__mutmut_50'] = x__draw__mutmut_50 # type: ignore # mutmut generated
mutants_x__draw__mutmut['x__draw__mutmut_51'] = x__draw__mutmut_51 # type: ignore # mutmut generated
mutants_x__draw__mutmut['x__draw__mutmut_52'] = x__draw__mutmut_52 # type: ignore # mutmut generated
mutants_x__draw__mutmut['x__draw__mutmut_53'] = x__draw__mutmut_53 # type: ignore # mutmut generated
mutants_x__draw__mutmut['x__draw__mutmut_54'] = x__draw__mutmut_54 # type: ignore # mutmut generated
mutants_x__draw__mutmut['x__draw__mutmut_55'] = x__draw__mutmut_55 # type: ignore # mutmut generated
mutants_x__draw__mutmut['x__draw__mutmut_56'] = x__draw__mutmut_56 # type: ignore # mutmut generated
mutants_x__draw__mutmut['x__draw__mutmut_57'] = x__draw__mutmut_57 # type: ignore # mutmut generated
mutants_x__draw__mutmut['x__draw__mutmut_58'] = x__draw__mutmut_58 # type: ignore # mutmut generated
mutants_x__draw__mutmut['x__draw__mutmut_59'] = x__draw__mutmut_59 # type: ignore # mutmut generated
mutants_x__draw__mutmut['x__draw__mutmut_60'] = x__draw__mutmut_60 # type: ignore # mutmut generated
mutants_x__draw__mutmut['x__draw__mutmut_61'] = x__draw__mutmut_61 # type: ignore # mutmut generated
mutants_x__draw__mutmut['x__draw__mutmut_62'] = x__draw__mutmut_62 # type: ignore # mutmut generated
mutants_x__draw__mutmut['x__draw__mutmut_63'] = x__draw__mutmut_63 # type: ignore # mutmut generated
mutants_x__draw__mutmut['x__draw__mutmut_64'] = x__draw__mutmut_64 # type: ignore # mutmut generated
mutants_x__draw__mutmut['x__draw__mutmut_65'] = x__draw__mutmut_65 # type: ignore # mutmut generated
mutants_x__draw__mutmut['x__draw__mutmut_66'] = x__draw__mutmut_66 # type: ignore # mutmut generated
mutants_x__draw__mutmut['x__draw__mutmut_67'] = x__draw__mutmut_67 # type: ignore # mutmut generated
mutants_x__draw__mutmut['x__draw__mutmut_68'] = x__draw__mutmut_68 # type: ignore # mutmut generated
mutants_x__draw__mutmut['x__draw__mutmut_69'] = x__draw__mutmut_69 # type: ignore # mutmut generated
mutants_x__draw__mutmut['x__draw__mutmut_70'] = x__draw__mutmut_70 # type: ignore # mutmut generated
mutants_x__draw__mutmut['x__draw__mutmut_71'] = x__draw__mutmut_71 # type: ignore # mutmut generated
mutants_x__draw__mutmut['x__draw__mutmut_72'] = x__draw__mutmut_72 # type: ignore # mutmut generated
mutants_x__draw__mutmut['x__draw__mutmut_73'] = x__draw__mutmut_73 # type: ignore # mutmut generated
mutants_x__draw__mutmut['x__draw__mutmut_74'] = x__draw__mutmut_74 # type: ignore # mutmut generated
mutants_x__draw__mutmut['x__draw__mutmut_75'] = x__draw__mutmut_75 # type: ignore # mutmut generated
mutants_x__draw__mutmut['x__draw__mutmut_76'] = x__draw__mutmut_76 # type: ignore # mutmut generated
mutants_x__draw__mutmut['x__draw__mutmut_77'] = x__draw__mutmut_77 # type: ignore # mutmut generated
mutants_x__draw__mutmut['x__draw__mutmut_78'] = x__draw__mutmut_78 # type: ignore # mutmut generated
mutants_x__draw__mutmut['x__draw__mutmut_79'] = x__draw__mutmut_79 # type: ignore # mutmut generated
mutants_x__draw__mutmut['x__draw__mutmut_80'] = x__draw__mutmut_80 # type: ignore # mutmut generated
mutants_x_main__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_main__mutmut)
def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--panels", type=int, default=6)
    args = parser.parse_args(argv)
    runs = sorted(
        (json.loads(p.read_text()) for p in args.runs.glob("*.json")), key=lambda r: r["uci_id"]
    )
    frames = {
        r["name"]: pd.DataFrame(
            r["recall_mean"]["data"],
            index=r["recall_mean"]["index"],
            columns=r["recall_mean"]["columns"],
        )
        for r in runs
    }
    args.output.mkdir(parents=True, exist_ok=True)
    median = pd.DataFrame(
        np.nanmedian(np.stack([f.to_numpy(dtype=float) for f in frames.values()]), axis=0),
        index=next(iter(frames.values())).index,
        columns=next(iter(frames.values())).columns,
    )
    fig, ax = plt.subplots(figsize=(7, 5))
    _draw(ax, median, f"Median detection rate over {len(frames)} real datasets (typed injection)")
    fig.tight_layout()
    fig.savefig(args.output / "typed_pooled.png", dpi=160)
    plt.close(fig)
    names = [r["name"] for r in runs][: args.panels]
    cols = 3
    rows = -(-len(names) // cols)
    fig, axes = plt.subplots(rows, cols, figsize=(5.2 * cols, 3.6 * rows), squeeze=False)
    for ax in axes.ravel():
        ax.axis("off")
    for ax, name in zip(axes.ravel(), names, strict=False):
        ax.axis("on")
        _draw(ax, frames[name], name[:38])
    fig.tight_layout()
    fig.savefig(args.output / "typed_panels.png", dpi=130)
    plt.close(fig)
    return 0


def x_main__mutmut_orig(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--panels", type=int, default=6)
    args = parser.parse_args(argv)
    runs = sorted(
        (json.loads(p.read_text()) for p in args.runs.glob("*.json")), key=lambda r: r["uci_id"]
    )
    frames = {
        r["name"]: pd.DataFrame(
            r["recall_mean"]["data"],
            index=r["recall_mean"]["index"],
            columns=r["recall_mean"]["columns"],
        )
        for r in runs
    }
    args.output.mkdir(parents=True, exist_ok=True)
    median = pd.DataFrame(
        np.nanmedian(np.stack([f.to_numpy(dtype=float) for f in frames.values()]), axis=0),
        index=next(iter(frames.values())).index,
        columns=next(iter(frames.values())).columns,
    )
    fig, ax = plt.subplots(figsize=(7, 5))
    _draw(ax, median, f"Median detection rate over {len(frames)} real datasets (typed injection)")
    fig.tight_layout()
    fig.savefig(args.output / "typed_pooled.png", dpi=160)
    plt.close(fig)
    names = [r["name"] for r in runs][: args.panels]
    cols = 3
    rows = -(-len(names) // cols)
    fig, axes = plt.subplots(rows, cols, figsize=(5.2 * cols, 3.6 * rows), squeeze=False)
    for ax in axes.ravel():
        ax.axis("off")
    for ax, name in zip(axes.ravel(), names, strict=False):
        ax.axis("on")
        _draw(ax, frames[name], name[:38])
    fig.tight_layout()
    fig.savefig(args.output / "typed_panels.png", dpi=130)
    plt.close(fig)
    return 0


def x_main__mutmut_1(argv: list[str] | None = None) -> int:
    parser = None
    parser.add_argument("--runs", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--panels", type=int, default=6)
    args = parser.parse_args(argv)
    runs = sorted(
        (json.loads(p.read_text()) for p in args.runs.glob("*.json")), key=lambda r: r["uci_id"]
    )
    frames = {
        r["name"]: pd.DataFrame(
            r["recall_mean"]["data"],
            index=r["recall_mean"]["index"],
            columns=r["recall_mean"]["columns"],
        )
        for r in runs
    }
    args.output.mkdir(parents=True, exist_ok=True)
    median = pd.DataFrame(
        np.nanmedian(np.stack([f.to_numpy(dtype=float) for f in frames.values()]), axis=0),
        index=next(iter(frames.values())).index,
        columns=next(iter(frames.values())).columns,
    )
    fig, ax = plt.subplots(figsize=(7, 5))
    _draw(ax, median, f"Median detection rate over {len(frames)} real datasets (typed injection)")
    fig.tight_layout()
    fig.savefig(args.output / "typed_pooled.png", dpi=160)
    plt.close(fig)
    names = [r["name"] for r in runs][: args.panels]
    cols = 3
    rows = -(-len(names) // cols)
    fig, axes = plt.subplots(rows, cols, figsize=(5.2 * cols, 3.6 * rows), squeeze=False)
    for ax in axes.ravel():
        ax.axis("off")
    for ax, name in zip(axes.ravel(), names, strict=False):
        ax.axis("on")
        _draw(ax, frames[name], name[:38])
    fig.tight_layout()
    fig.savefig(args.output / "typed_panels.png", dpi=130)
    plt.close(fig)
    return 0


def x_main__mutmut_2(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=None)
    parser.add_argument("--runs", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--panels", type=int, default=6)
    args = parser.parse_args(argv)
    runs = sorted(
        (json.loads(p.read_text()) for p in args.runs.glob("*.json")), key=lambda r: r["uci_id"]
    )
    frames = {
        r["name"]: pd.DataFrame(
            r["recall_mean"]["data"],
            index=r["recall_mean"]["index"],
            columns=r["recall_mean"]["columns"],
        )
        for r in runs
    }
    args.output.mkdir(parents=True, exist_ok=True)
    median = pd.DataFrame(
        np.nanmedian(np.stack([f.to_numpy(dtype=float) for f in frames.values()]), axis=0),
        index=next(iter(frames.values())).index,
        columns=next(iter(frames.values())).columns,
    )
    fig, ax = plt.subplots(figsize=(7, 5))
    _draw(ax, median, f"Median detection rate over {len(frames)} real datasets (typed injection)")
    fig.tight_layout()
    fig.savefig(args.output / "typed_pooled.png", dpi=160)
    plt.close(fig)
    names = [r["name"] for r in runs][: args.panels]
    cols = 3
    rows = -(-len(names) // cols)
    fig, axes = plt.subplots(rows, cols, figsize=(5.2 * cols, 3.6 * rows), squeeze=False)
    for ax in axes.ravel():
        ax.axis("off")
    for ax, name in zip(axes.ravel(), names, strict=False):
        ax.axis("on")
        _draw(ax, frames[name], name[:38])
    fig.tight_layout()
    fig.savefig(args.output / "typed_panels.png", dpi=130)
    plt.close(fig)
    return 0


def x_main__mutmut_3(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(None, type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--panels", type=int, default=6)
    args = parser.parse_args(argv)
    runs = sorted(
        (json.loads(p.read_text()) for p in args.runs.glob("*.json")), key=lambda r: r["uci_id"]
    )
    frames = {
        r["name"]: pd.DataFrame(
            r["recall_mean"]["data"],
            index=r["recall_mean"]["index"],
            columns=r["recall_mean"]["columns"],
        )
        for r in runs
    }
    args.output.mkdir(parents=True, exist_ok=True)
    median = pd.DataFrame(
        np.nanmedian(np.stack([f.to_numpy(dtype=float) for f in frames.values()]), axis=0),
        index=next(iter(frames.values())).index,
        columns=next(iter(frames.values())).columns,
    )
    fig, ax = plt.subplots(figsize=(7, 5))
    _draw(ax, median, f"Median detection rate over {len(frames)} real datasets (typed injection)")
    fig.tight_layout()
    fig.savefig(args.output / "typed_pooled.png", dpi=160)
    plt.close(fig)
    names = [r["name"] for r in runs][: args.panels]
    cols = 3
    rows = -(-len(names) // cols)
    fig, axes = plt.subplots(rows, cols, figsize=(5.2 * cols, 3.6 * rows), squeeze=False)
    for ax in axes.ravel():
        ax.axis("off")
    for ax, name in zip(axes.ravel(), names, strict=False):
        ax.axis("on")
        _draw(ax, frames[name], name[:38])
    fig.tight_layout()
    fig.savefig(args.output / "typed_panels.png", dpi=130)
    plt.close(fig)
    return 0


def x_main__mutmut_4(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=None, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--panels", type=int, default=6)
    args = parser.parse_args(argv)
    runs = sorted(
        (json.loads(p.read_text()) for p in args.runs.glob("*.json")), key=lambda r: r["uci_id"]
    )
    frames = {
        r["name"]: pd.DataFrame(
            r["recall_mean"]["data"],
            index=r["recall_mean"]["index"],
            columns=r["recall_mean"]["columns"],
        )
        for r in runs
    }
    args.output.mkdir(parents=True, exist_ok=True)
    median = pd.DataFrame(
        np.nanmedian(np.stack([f.to_numpy(dtype=float) for f in frames.values()]), axis=0),
        index=next(iter(frames.values())).index,
        columns=next(iter(frames.values())).columns,
    )
    fig, ax = plt.subplots(figsize=(7, 5))
    _draw(ax, median, f"Median detection rate over {len(frames)} real datasets (typed injection)")
    fig.tight_layout()
    fig.savefig(args.output / "typed_pooled.png", dpi=160)
    plt.close(fig)
    names = [r["name"] for r in runs][: args.panels]
    cols = 3
    rows = -(-len(names) // cols)
    fig, axes = plt.subplots(rows, cols, figsize=(5.2 * cols, 3.6 * rows), squeeze=False)
    for ax in axes.ravel():
        ax.axis("off")
    for ax, name in zip(axes.ravel(), names, strict=False):
        ax.axis("on")
        _draw(ax, frames[name], name[:38])
    fig.tight_layout()
    fig.savefig(args.output / "typed_panels.png", dpi=130)
    plt.close(fig)
    return 0


def x_main__mutmut_5(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=None)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--panels", type=int, default=6)
    args = parser.parse_args(argv)
    runs = sorted(
        (json.loads(p.read_text()) for p in args.runs.glob("*.json")), key=lambda r: r["uci_id"]
    )
    frames = {
        r["name"]: pd.DataFrame(
            r["recall_mean"]["data"],
            index=r["recall_mean"]["index"],
            columns=r["recall_mean"]["columns"],
        )
        for r in runs
    }
    args.output.mkdir(parents=True, exist_ok=True)
    median = pd.DataFrame(
        np.nanmedian(np.stack([f.to_numpy(dtype=float) for f in frames.values()]), axis=0),
        index=next(iter(frames.values())).index,
        columns=next(iter(frames.values())).columns,
    )
    fig, ax = plt.subplots(figsize=(7, 5))
    _draw(ax, median, f"Median detection rate over {len(frames)} real datasets (typed injection)")
    fig.tight_layout()
    fig.savefig(args.output / "typed_pooled.png", dpi=160)
    plt.close(fig)
    names = [r["name"] for r in runs][: args.panels]
    cols = 3
    rows = -(-len(names) // cols)
    fig, axes = plt.subplots(rows, cols, figsize=(5.2 * cols, 3.6 * rows), squeeze=False)
    for ax in axes.ravel():
        ax.axis("off")
    for ax, name in zip(axes.ravel(), names, strict=False):
        ax.axis("on")
        _draw(ax, frames[name], name[:38])
    fig.tight_layout()
    fig.savefig(args.output / "typed_panels.png", dpi=130)
    plt.close(fig)
    return 0


def x_main__mutmut_6(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--panels", type=int, default=6)
    args = parser.parse_args(argv)
    runs = sorted(
        (json.loads(p.read_text()) for p in args.runs.glob("*.json")), key=lambda r: r["uci_id"]
    )
    frames = {
        r["name"]: pd.DataFrame(
            r["recall_mean"]["data"],
            index=r["recall_mean"]["index"],
            columns=r["recall_mean"]["columns"],
        )
        for r in runs
    }
    args.output.mkdir(parents=True, exist_ok=True)
    median = pd.DataFrame(
        np.nanmedian(np.stack([f.to_numpy(dtype=float) for f in frames.values()]), axis=0),
        index=next(iter(frames.values())).index,
        columns=next(iter(frames.values())).columns,
    )
    fig, ax = plt.subplots(figsize=(7, 5))
    _draw(ax, median, f"Median detection rate over {len(frames)} real datasets (typed injection)")
    fig.tight_layout()
    fig.savefig(args.output / "typed_pooled.png", dpi=160)
    plt.close(fig)
    names = [r["name"] for r in runs][: args.panels]
    cols = 3
    rows = -(-len(names) // cols)
    fig, axes = plt.subplots(rows, cols, figsize=(5.2 * cols, 3.6 * rows), squeeze=False)
    for ax in axes.ravel():
        ax.axis("off")
    for ax, name in zip(axes.ravel(), names, strict=False):
        ax.axis("on")
        _draw(ax, frames[name], name[:38])
    fig.tight_layout()
    fig.savefig(args.output / "typed_panels.png", dpi=130)
    plt.close(fig)
    return 0


def x_main__mutmut_7(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--panels", type=int, default=6)
    args = parser.parse_args(argv)
    runs = sorted(
        (json.loads(p.read_text()) for p in args.runs.glob("*.json")), key=lambda r: r["uci_id"]
    )
    frames = {
        r["name"]: pd.DataFrame(
            r["recall_mean"]["data"],
            index=r["recall_mean"]["index"],
            columns=r["recall_mean"]["columns"],
        )
        for r in runs
    }
    args.output.mkdir(parents=True, exist_ok=True)
    median = pd.DataFrame(
        np.nanmedian(np.stack([f.to_numpy(dtype=float) for f in frames.values()]), axis=0),
        index=next(iter(frames.values())).index,
        columns=next(iter(frames.values())).columns,
    )
    fig, ax = plt.subplots(figsize=(7, 5))
    _draw(ax, median, f"Median detection rate over {len(frames)} real datasets (typed injection)")
    fig.tight_layout()
    fig.savefig(args.output / "typed_pooled.png", dpi=160)
    plt.close(fig)
    names = [r["name"] for r in runs][: args.panels]
    cols = 3
    rows = -(-len(names) // cols)
    fig, axes = plt.subplots(rows, cols, figsize=(5.2 * cols, 3.6 * rows), squeeze=False)
    for ax in axes.ravel():
        ax.axis("off")
    for ax, name in zip(axes.ravel(), names, strict=False):
        ax.axis("on")
        _draw(ax, frames[name], name[:38])
    fig.tight_layout()
    fig.savefig(args.output / "typed_panels.png", dpi=130)
    plt.close(fig)
    return 0


def x_main__mutmut_8(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, )
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--panels", type=int, default=6)
    args = parser.parse_args(argv)
    runs = sorted(
        (json.loads(p.read_text()) for p in args.runs.glob("*.json")), key=lambda r: r["uci_id"]
    )
    frames = {
        r["name"]: pd.DataFrame(
            r["recall_mean"]["data"],
            index=r["recall_mean"]["index"],
            columns=r["recall_mean"]["columns"],
        )
        for r in runs
    }
    args.output.mkdir(parents=True, exist_ok=True)
    median = pd.DataFrame(
        np.nanmedian(np.stack([f.to_numpy(dtype=float) for f in frames.values()]), axis=0),
        index=next(iter(frames.values())).index,
        columns=next(iter(frames.values())).columns,
    )
    fig, ax = plt.subplots(figsize=(7, 5))
    _draw(ax, median, f"Median detection rate over {len(frames)} real datasets (typed injection)")
    fig.tight_layout()
    fig.savefig(args.output / "typed_pooled.png", dpi=160)
    plt.close(fig)
    names = [r["name"] for r in runs][: args.panels]
    cols = 3
    rows = -(-len(names) // cols)
    fig, axes = plt.subplots(rows, cols, figsize=(5.2 * cols, 3.6 * rows), squeeze=False)
    for ax in axes.ravel():
        ax.axis("off")
    for ax, name in zip(axes.ravel(), names, strict=False):
        ax.axis("on")
        _draw(ax, frames[name], name[:38])
    fig.tight_layout()
    fig.savefig(args.output / "typed_panels.png", dpi=130)
    plt.close(fig)
    return 0


def x_main__mutmut_9(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("XX--runsXX", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--panels", type=int, default=6)
    args = parser.parse_args(argv)
    runs = sorted(
        (json.loads(p.read_text()) for p in args.runs.glob("*.json")), key=lambda r: r["uci_id"]
    )
    frames = {
        r["name"]: pd.DataFrame(
            r["recall_mean"]["data"],
            index=r["recall_mean"]["index"],
            columns=r["recall_mean"]["columns"],
        )
        for r in runs
    }
    args.output.mkdir(parents=True, exist_ok=True)
    median = pd.DataFrame(
        np.nanmedian(np.stack([f.to_numpy(dtype=float) for f in frames.values()]), axis=0),
        index=next(iter(frames.values())).index,
        columns=next(iter(frames.values())).columns,
    )
    fig, ax = plt.subplots(figsize=(7, 5))
    _draw(ax, median, f"Median detection rate over {len(frames)} real datasets (typed injection)")
    fig.tight_layout()
    fig.savefig(args.output / "typed_pooled.png", dpi=160)
    plt.close(fig)
    names = [r["name"] for r in runs][: args.panels]
    cols = 3
    rows = -(-len(names) // cols)
    fig, axes = plt.subplots(rows, cols, figsize=(5.2 * cols, 3.6 * rows), squeeze=False)
    for ax in axes.ravel():
        ax.axis("off")
    for ax, name in zip(axes.ravel(), names, strict=False):
        ax.axis("on")
        _draw(ax, frames[name], name[:38])
    fig.tight_layout()
    fig.savefig(args.output / "typed_panels.png", dpi=130)
    plt.close(fig)
    return 0


def x_main__mutmut_10(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--RUNS", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--panels", type=int, default=6)
    args = parser.parse_args(argv)
    runs = sorted(
        (json.loads(p.read_text()) for p in args.runs.glob("*.json")), key=lambda r: r["uci_id"]
    )
    frames = {
        r["name"]: pd.DataFrame(
            r["recall_mean"]["data"],
            index=r["recall_mean"]["index"],
            columns=r["recall_mean"]["columns"],
        )
        for r in runs
    }
    args.output.mkdir(parents=True, exist_ok=True)
    median = pd.DataFrame(
        np.nanmedian(np.stack([f.to_numpy(dtype=float) for f in frames.values()]), axis=0),
        index=next(iter(frames.values())).index,
        columns=next(iter(frames.values())).columns,
    )
    fig, ax = plt.subplots(figsize=(7, 5))
    _draw(ax, median, f"Median detection rate over {len(frames)} real datasets (typed injection)")
    fig.tight_layout()
    fig.savefig(args.output / "typed_pooled.png", dpi=160)
    plt.close(fig)
    names = [r["name"] for r in runs][: args.panels]
    cols = 3
    rows = -(-len(names) // cols)
    fig, axes = plt.subplots(rows, cols, figsize=(5.2 * cols, 3.6 * rows), squeeze=False)
    for ax in axes.ravel():
        ax.axis("off")
    for ax, name in zip(axes.ravel(), names, strict=False):
        ax.axis("on")
        _draw(ax, frames[name], name[:38])
    fig.tight_layout()
    fig.savefig(args.output / "typed_panels.png", dpi=130)
    plt.close(fig)
    return 0


def x_main__mutmut_11(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=False)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--panels", type=int, default=6)
    args = parser.parse_args(argv)
    runs = sorted(
        (json.loads(p.read_text()) for p in args.runs.glob("*.json")), key=lambda r: r["uci_id"]
    )
    frames = {
        r["name"]: pd.DataFrame(
            r["recall_mean"]["data"],
            index=r["recall_mean"]["index"],
            columns=r["recall_mean"]["columns"],
        )
        for r in runs
    }
    args.output.mkdir(parents=True, exist_ok=True)
    median = pd.DataFrame(
        np.nanmedian(np.stack([f.to_numpy(dtype=float) for f in frames.values()]), axis=0),
        index=next(iter(frames.values())).index,
        columns=next(iter(frames.values())).columns,
    )
    fig, ax = plt.subplots(figsize=(7, 5))
    _draw(ax, median, f"Median detection rate over {len(frames)} real datasets (typed injection)")
    fig.tight_layout()
    fig.savefig(args.output / "typed_pooled.png", dpi=160)
    plt.close(fig)
    names = [r["name"] for r in runs][: args.panels]
    cols = 3
    rows = -(-len(names) // cols)
    fig, axes = plt.subplots(rows, cols, figsize=(5.2 * cols, 3.6 * rows), squeeze=False)
    for ax in axes.ravel():
        ax.axis("off")
    for ax, name in zip(axes.ravel(), names, strict=False):
        ax.axis("on")
        _draw(ax, frames[name], name[:38])
    fig.tight_layout()
    fig.savefig(args.output / "typed_panels.png", dpi=130)
    plt.close(fig)
    return 0


def x_main__mutmut_12(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True)
    parser.add_argument(None, type=Path, required=True)
    parser.add_argument("--panels", type=int, default=6)
    args = parser.parse_args(argv)
    runs = sorted(
        (json.loads(p.read_text()) for p in args.runs.glob("*.json")), key=lambda r: r["uci_id"]
    )
    frames = {
        r["name"]: pd.DataFrame(
            r["recall_mean"]["data"],
            index=r["recall_mean"]["index"],
            columns=r["recall_mean"]["columns"],
        )
        for r in runs
    }
    args.output.mkdir(parents=True, exist_ok=True)
    median = pd.DataFrame(
        np.nanmedian(np.stack([f.to_numpy(dtype=float) for f in frames.values()]), axis=0),
        index=next(iter(frames.values())).index,
        columns=next(iter(frames.values())).columns,
    )
    fig, ax = plt.subplots(figsize=(7, 5))
    _draw(ax, median, f"Median detection rate over {len(frames)} real datasets (typed injection)")
    fig.tight_layout()
    fig.savefig(args.output / "typed_pooled.png", dpi=160)
    plt.close(fig)
    names = [r["name"] for r in runs][: args.panels]
    cols = 3
    rows = -(-len(names) // cols)
    fig, axes = plt.subplots(rows, cols, figsize=(5.2 * cols, 3.6 * rows), squeeze=False)
    for ax in axes.ravel():
        ax.axis("off")
    for ax, name in zip(axes.ravel(), names, strict=False):
        ax.axis("on")
        _draw(ax, frames[name], name[:38])
    fig.tight_layout()
    fig.savefig(args.output / "typed_panels.png", dpi=130)
    plt.close(fig)
    return 0


def x_main__mutmut_13(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True)
    parser.add_argument("--output", type=None, required=True)
    parser.add_argument("--panels", type=int, default=6)
    args = parser.parse_args(argv)
    runs = sorted(
        (json.loads(p.read_text()) for p in args.runs.glob("*.json")), key=lambda r: r["uci_id"]
    )
    frames = {
        r["name"]: pd.DataFrame(
            r["recall_mean"]["data"],
            index=r["recall_mean"]["index"],
            columns=r["recall_mean"]["columns"],
        )
        for r in runs
    }
    args.output.mkdir(parents=True, exist_ok=True)
    median = pd.DataFrame(
        np.nanmedian(np.stack([f.to_numpy(dtype=float) for f in frames.values()]), axis=0),
        index=next(iter(frames.values())).index,
        columns=next(iter(frames.values())).columns,
    )
    fig, ax = plt.subplots(figsize=(7, 5))
    _draw(ax, median, f"Median detection rate over {len(frames)} real datasets (typed injection)")
    fig.tight_layout()
    fig.savefig(args.output / "typed_pooled.png", dpi=160)
    plt.close(fig)
    names = [r["name"] for r in runs][: args.panels]
    cols = 3
    rows = -(-len(names) // cols)
    fig, axes = plt.subplots(rows, cols, figsize=(5.2 * cols, 3.6 * rows), squeeze=False)
    for ax in axes.ravel():
        ax.axis("off")
    for ax, name in zip(axes.ravel(), names, strict=False):
        ax.axis("on")
        _draw(ax, frames[name], name[:38])
    fig.tight_layout()
    fig.savefig(args.output / "typed_panels.png", dpi=130)
    plt.close(fig)
    return 0


def x_main__mutmut_14(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=None)
    parser.add_argument("--panels", type=int, default=6)
    args = parser.parse_args(argv)
    runs = sorted(
        (json.loads(p.read_text()) for p in args.runs.glob("*.json")), key=lambda r: r["uci_id"]
    )
    frames = {
        r["name"]: pd.DataFrame(
            r["recall_mean"]["data"],
            index=r["recall_mean"]["index"],
            columns=r["recall_mean"]["columns"],
        )
        for r in runs
    }
    args.output.mkdir(parents=True, exist_ok=True)
    median = pd.DataFrame(
        np.nanmedian(np.stack([f.to_numpy(dtype=float) for f in frames.values()]), axis=0),
        index=next(iter(frames.values())).index,
        columns=next(iter(frames.values())).columns,
    )
    fig, ax = plt.subplots(figsize=(7, 5))
    _draw(ax, median, f"Median detection rate over {len(frames)} real datasets (typed injection)")
    fig.tight_layout()
    fig.savefig(args.output / "typed_pooled.png", dpi=160)
    plt.close(fig)
    names = [r["name"] for r in runs][: args.panels]
    cols = 3
    rows = -(-len(names) // cols)
    fig, axes = plt.subplots(rows, cols, figsize=(5.2 * cols, 3.6 * rows), squeeze=False)
    for ax in axes.ravel():
        ax.axis("off")
    for ax, name in zip(axes.ravel(), names, strict=False):
        ax.axis("on")
        _draw(ax, frames[name], name[:38])
    fig.tight_layout()
    fig.savefig(args.output / "typed_panels.png", dpi=130)
    plt.close(fig)
    return 0


def x_main__mutmut_15(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True)
    parser.add_argument(type=Path, required=True)
    parser.add_argument("--panels", type=int, default=6)
    args = parser.parse_args(argv)
    runs = sorted(
        (json.loads(p.read_text()) for p in args.runs.glob("*.json")), key=lambda r: r["uci_id"]
    )
    frames = {
        r["name"]: pd.DataFrame(
            r["recall_mean"]["data"],
            index=r["recall_mean"]["index"],
            columns=r["recall_mean"]["columns"],
        )
        for r in runs
    }
    args.output.mkdir(parents=True, exist_ok=True)
    median = pd.DataFrame(
        np.nanmedian(np.stack([f.to_numpy(dtype=float) for f in frames.values()]), axis=0),
        index=next(iter(frames.values())).index,
        columns=next(iter(frames.values())).columns,
    )
    fig, ax = plt.subplots(figsize=(7, 5))
    _draw(ax, median, f"Median detection rate over {len(frames)} real datasets (typed injection)")
    fig.tight_layout()
    fig.savefig(args.output / "typed_pooled.png", dpi=160)
    plt.close(fig)
    names = [r["name"] for r in runs][: args.panels]
    cols = 3
    rows = -(-len(names) // cols)
    fig, axes = plt.subplots(rows, cols, figsize=(5.2 * cols, 3.6 * rows), squeeze=False)
    for ax in axes.ravel():
        ax.axis("off")
    for ax, name in zip(axes.ravel(), names, strict=False):
        ax.axis("on")
        _draw(ax, frames[name], name[:38])
    fig.tight_layout()
    fig.savefig(args.output / "typed_panels.png", dpi=130)
    plt.close(fig)
    return 0


def x_main__mutmut_16(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--panels", type=int, default=6)
    args = parser.parse_args(argv)
    runs = sorted(
        (json.loads(p.read_text()) for p in args.runs.glob("*.json")), key=lambda r: r["uci_id"]
    )
    frames = {
        r["name"]: pd.DataFrame(
            r["recall_mean"]["data"],
            index=r["recall_mean"]["index"],
            columns=r["recall_mean"]["columns"],
        )
        for r in runs
    }
    args.output.mkdir(parents=True, exist_ok=True)
    median = pd.DataFrame(
        np.nanmedian(np.stack([f.to_numpy(dtype=float) for f in frames.values()]), axis=0),
        index=next(iter(frames.values())).index,
        columns=next(iter(frames.values())).columns,
    )
    fig, ax = plt.subplots(figsize=(7, 5))
    _draw(ax, median, f"Median detection rate over {len(frames)} real datasets (typed injection)")
    fig.tight_layout()
    fig.savefig(args.output / "typed_pooled.png", dpi=160)
    plt.close(fig)
    names = [r["name"] for r in runs][: args.panels]
    cols = 3
    rows = -(-len(names) // cols)
    fig, axes = plt.subplots(rows, cols, figsize=(5.2 * cols, 3.6 * rows), squeeze=False)
    for ax in axes.ravel():
        ax.axis("off")
    for ax, name in zip(axes.ravel(), names, strict=False):
        ax.axis("on")
        _draw(ax, frames[name], name[:38])
    fig.tight_layout()
    fig.savefig(args.output / "typed_panels.png", dpi=130)
    plt.close(fig)
    return 0


def x_main__mutmut_17(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True)
    parser.add_argument("--output", type=Path, )
    parser.add_argument("--panels", type=int, default=6)
    args = parser.parse_args(argv)
    runs = sorted(
        (json.loads(p.read_text()) for p in args.runs.glob("*.json")), key=lambda r: r["uci_id"]
    )
    frames = {
        r["name"]: pd.DataFrame(
            r["recall_mean"]["data"],
            index=r["recall_mean"]["index"],
            columns=r["recall_mean"]["columns"],
        )
        for r in runs
    }
    args.output.mkdir(parents=True, exist_ok=True)
    median = pd.DataFrame(
        np.nanmedian(np.stack([f.to_numpy(dtype=float) for f in frames.values()]), axis=0),
        index=next(iter(frames.values())).index,
        columns=next(iter(frames.values())).columns,
    )
    fig, ax = plt.subplots(figsize=(7, 5))
    _draw(ax, median, f"Median detection rate over {len(frames)} real datasets (typed injection)")
    fig.tight_layout()
    fig.savefig(args.output / "typed_pooled.png", dpi=160)
    plt.close(fig)
    names = [r["name"] for r in runs][: args.panels]
    cols = 3
    rows = -(-len(names) // cols)
    fig, axes = plt.subplots(rows, cols, figsize=(5.2 * cols, 3.6 * rows), squeeze=False)
    for ax in axes.ravel():
        ax.axis("off")
    for ax, name in zip(axes.ravel(), names, strict=False):
        ax.axis("on")
        _draw(ax, frames[name], name[:38])
    fig.tight_layout()
    fig.savefig(args.output / "typed_panels.png", dpi=130)
    plt.close(fig)
    return 0


def x_main__mutmut_18(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True)
    parser.add_argument("XX--outputXX", type=Path, required=True)
    parser.add_argument("--panels", type=int, default=6)
    args = parser.parse_args(argv)
    runs = sorted(
        (json.loads(p.read_text()) for p in args.runs.glob("*.json")), key=lambda r: r["uci_id"]
    )
    frames = {
        r["name"]: pd.DataFrame(
            r["recall_mean"]["data"],
            index=r["recall_mean"]["index"],
            columns=r["recall_mean"]["columns"],
        )
        for r in runs
    }
    args.output.mkdir(parents=True, exist_ok=True)
    median = pd.DataFrame(
        np.nanmedian(np.stack([f.to_numpy(dtype=float) for f in frames.values()]), axis=0),
        index=next(iter(frames.values())).index,
        columns=next(iter(frames.values())).columns,
    )
    fig, ax = plt.subplots(figsize=(7, 5))
    _draw(ax, median, f"Median detection rate over {len(frames)} real datasets (typed injection)")
    fig.tight_layout()
    fig.savefig(args.output / "typed_pooled.png", dpi=160)
    plt.close(fig)
    names = [r["name"] for r in runs][: args.panels]
    cols = 3
    rows = -(-len(names) // cols)
    fig, axes = plt.subplots(rows, cols, figsize=(5.2 * cols, 3.6 * rows), squeeze=False)
    for ax in axes.ravel():
        ax.axis("off")
    for ax, name in zip(axes.ravel(), names, strict=False):
        ax.axis("on")
        _draw(ax, frames[name], name[:38])
    fig.tight_layout()
    fig.savefig(args.output / "typed_panels.png", dpi=130)
    plt.close(fig)
    return 0


def x_main__mutmut_19(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True)
    parser.add_argument("--OUTPUT", type=Path, required=True)
    parser.add_argument("--panels", type=int, default=6)
    args = parser.parse_args(argv)
    runs = sorted(
        (json.loads(p.read_text()) for p in args.runs.glob("*.json")), key=lambda r: r["uci_id"]
    )
    frames = {
        r["name"]: pd.DataFrame(
            r["recall_mean"]["data"],
            index=r["recall_mean"]["index"],
            columns=r["recall_mean"]["columns"],
        )
        for r in runs
    }
    args.output.mkdir(parents=True, exist_ok=True)
    median = pd.DataFrame(
        np.nanmedian(np.stack([f.to_numpy(dtype=float) for f in frames.values()]), axis=0),
        index=next(iter(frames.values())).index,
        columns=next(iter(frames.values())).columns,
    )
    fig, ax = plt.subplots(figsize=(7, 5))
    _draw(ax, median, f"Median detection rate over {len(frames)} real datasets (typed injection)")
    fig.tight_layout()
    fig.savefig(args.output / "typed_pooled.png", dpi=160)
    plt.close(fig)
    names = [r["name"] for r in runs][: args.panels]
    cols = 3
    rows = -(-len(names) // cols)
    fig, axes = plt.subplots(rows, cols, figsize=(5.2 * cols, 3.6 * rows), squeeze=False)
    for ax in axes.ravel():
        ax.axis("off")
    for ax, name in zip(axes.ravel(), names, strict=False):
        ax.axis("on")
        _draw(ax, frames[name], name[:38])
    fig.tight_layout()
    fig.savefig(args.output / "typed_panels.png", dpi=130)
    plt.close(fig)
    return 0


def x_main__mutmut_20(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=False)
    parser.add_argument("--panels", type=int, default=6)
    args = parser.parse_args(argv)
    runs = sorted(
        (json.loads(p.read_text()) for p in args.runs.glob("*.json")), key=lambda r: r["uci_id"]
    )
    frames = {
        r["name"]: pd.DataFrame(
            r["recall_mean"]["data"],
            index=r["recall_mean"]["index"],
            columns=r["recall_mean"]["columns"],
        )
        for r in runs
    }
    args.output.mkdir(parents=True, exist_ok=True)
    median = pd.DataFrame(
        np.nanmedian(np.stack([f.to_numpy(dtype=float) for f in frames.values()]), axis=0),
        index=next(iter(frames.values())).index,
        columns=next(iter(frames.values())).columns,
    )
    fig, ax = plt.subplots(figsize=(7, 5))
    _draw(ax, median, f"Median detection rate over {len(frames)} real datasets (typed injection)")
    fig.tight_layout()
    fig.savefig(args.output / "typed_pooled.png", dpi=160)
    plt.close(fig)
    names = [r["name"] for r in runs][: args.panels]
    cols = 3
    rows = -(-len(names) // cols)
    fig, axes = plt.subplots(rows, cols, figsize=(5.2 * cols, 3.6 * rows), squeeze=False)
    for ax in axes.ravel():
        ax.axis("off")
    for ax, name in zip(axes.ravel(), names, strict=False):
        ax.axis("on")
        _draw(ax, frames[name], name[:38])
    fig.tight_layout()
    fig.savefig(args.output / "typed_panels.png", dpi=130)
    plt.close(fig)
    return 0


def x_main__mutmut_21(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument(None, type=int, default=6)
    args = parser.parse_args(argv)
    runs = sorted(
        (json.loads(p.read_text()) for p in args.runs.glob("*.json")), key=lambda r: r["uci_id"]
    )
    frames = {
        r["name"]: pd.DataFrame(
            r["recall_mean"]["data"],
            index=r["recall_mean"]["index"],
            columns=r["recall_mean"]["columns"],
        )
        for r in runs
    }
    args.output.mkdir(parents=True, exist_ok=True)
    median = pd.DataFrame(
        np.nanmedian(np.stack([f.to_numpy(dtype=float) for f in frames.values()]), axis=0),
        index=next(iter(frames.values())).index,
        columns=next(iter(frames.values())).columns,
    )
    fig, ax = plt.subplots(figsize=(7, 5))
    _draw(ax, median, f"Median detection rate over {len(frames)} real datasets (typed injection)")
    fig.tight_layout()
    fig.savefig(args.output / "typed_pooled.png", dpi=160)
    plt.close(fig)
    names = [r["name"] for r in runs][: args.panels]
    cols = 3
    rows = -(-len(names) // cols)
    fig, axes = plt.subplots(rows, cols, figsize=(5.2 * cols, 3.6 * rows), squeeze=False)
    for ax in axes.ravel():
        ax.axis("off")
    for ax, name in zip(axes.ravel(), names, strict=False):
        ax.axis("on")
        _draw(ax, frames[name], name[:38])
    fig.tight_layout()
    fig.savefig(args.output / "typed_panels.png", dpi=130)
    plt.close(fig)
    return 0


def x_main__mutmut_22(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--panels", type=None, default=6)
    args = parser.parse_args(argv)
    runs = sorted(
        (json.loads(p.read_text()) for p in args.runs.glob("*.json")), key=lambda r: r["uci_id"]
    )
    frames = {
        r["name"]: pd.DataFrame(
            r["recall_mean"]["data"],
            index=r["recall_mean"]["index"],
            columns=r["recall_mean"]["columns"],
        )
        for r in runs
    }
    args.output.mkdir(parents=True, exist_ok=True)
    median = pd.DataFrame(
        np.nanmedian(np.stack([f.to_numpy(dtype=float) for f in frames.values()]), axis=0),
        index=next(iter(frames.values())).index,
        columns=next(iter(frames.values())).columns,
    )
    fig, ax = plt.subplots(figsize=(7, 5))
    _draw(ax, median, f"Median detection rate over {len(frames)} real datasets (typed injection)")
    fig.tight_layout()
    fig.savefig(args.output / "typed_pooled.png", dpi=160)
    plt.close(fig)
    names = [r["name"] for r in runs][: args.panels]
    cols = 3
    rows = -(-len(names) // cols)
    fig, axes = plt.subplots(rows, cols, figsize=(5.2 * cols, 3.6 * rows), squeeze=False)
    for ax in axes.ravel():
        ax.axis("off")
    for ax, name in zip(axes.ravel(), names, strict=False):
        ax.axis("on")
        _draw(ax, frames[name], name[:38])
    fig.tight_layout()
    fig.savefig(args.output / "typed_panels.png", dpi=130)
    plt.close(fig)
    return 0


def x_main__mutmut_23(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--panels", type=int, default=None)
    args = parser.parse_args(argv)
    runs = sorted(
        (json.loads(p.read_text()) for p in args.runs.glob("*.json")), key=lambda r: r["uci_id"]
    )
    frames = {
        r["name"]: pd.DataFrame(
            r["recall_mean"]["data"],
            index=r["recall_mean"]["index"],
            columns=r["recall_mean"]["columns"],
        )
        for r in runs
    }
    args.output.mkdir(parents=True, exist_ok=True)
    median = pd.DataFrame(
        np.nanmedian(np.stack([f.to_numpy(dtype=float) for f in frames.values()]), axis=0),
        index=next(iter(frames.values())).index,
        columns=next(iter(frames.values())).columns,
    )
    fig, ax = plt.subplots(figsize=(7, 5))
    _draw(ax, median, f"Median detection rate over {len(frames)} real datasets (typed injection)")
    fig.tight_layout()
    fig.savefig(args.output / "typed_pooled.png", dpi=160)
    plt.close(fig)
    names = [r["name"] for r in runs][: args.panels]
    cols = 3
    rows = -(-len(names) // cols)
    fig, axes = plt.subplots(rows, cols, figsize=(5.2 * cols, 3.6 * rows), squeeze=False)
    for ax in axes.ravel():
        ax.axis("off")
    for ax, name in zip(axes.ravel(), names, strict=False):
        ax.axis("on")
        _draw(ax, frames[name], name[:38])
    fig.tight_layout()
    fig.savefig(args.output / "typed_panels.png", dpi=130)
    plt.close(fig)
    return 0


def x_main__mutmut_24(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument(type=int, default=6)
    args = parser.parse_args(argv)
    runs = sorted(
        (json.loads(p.read_text()) for p in args.runs.glob("*.json")), key=lambda r: r["uci_id"]
    )
    frames = {
        r["name"]: pd.DataFrame(
            r["recall_mean"]["data"],
            index=r["recall_mean"]["index"],
            columns=r["recall_mean"]["columns"],
        )
        for r in runs
    }
    args.output.mkdir(parents=True, exist_ok=True)
    median = pd.DataFrame(
        np.nanmedian(np.stack([f.to_numpy(dtype=float) for f in frames.values()]), axis=0),
        index=next(iter(frames.values())).index,
        columns=next(iter(frames.values())).columns,
    )
    fig, ax = plt.subplots(figsize=(7, 5))
    _draw(ax, median, f"Median detection rate over {len(frames)} real datasets (typed injection)")
    fig.tight_layout()
    fig.savefig(args.output / "typed_pooled.png", dpi=160)
    plt.close(fig)
    names = [r["name"] for r in runs][: args.panels]
    cols = 3
    rows = -(-len(names) // cols)
    fig, axes = plt.subplots(rows, cols, figsize=(5.2 * cols, 3.6 * rows), squeeze=False)
    for ax in axes.ravel():
        ax.axis("off")
    for ax, name in zip(axes.ravel(), names, strict=False):
        ax.axis("on")
        _draw(ax, frames[name], name[:38])
    fig.tight_layout()
    fig.savefig(args.output / "typed_panels.png", dpi=130)
    plt.close(fig)
    return 0


def x_main__mutmut_25(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--panels", default=6)
    args = parser.parse_args(argv)
    runs = sorted(
        (json.loads(p.read_text()) for p in args.runs.glob("*.json")), key=lambda r: r["uci_id"]
    )
    frames = {
        r["name"]: pd.DataFrame(
            r["recall_mean"]["data"],
            index=r["recall_mean"]["index"],
            columns=r["recall_mean"]["columns"],
        )
        for r in runs
    }
    args.output.mkdir(parents=True, exist_ok=True)
    median = pd.DataFrame(
        np.nanmedian(np.stack([f.to_numpy(dtype=float) for f in frames.values()]), axis=0),
        index=next(iter(frames.values())).index,
        columns=next(iter(frames.values())).columns,
    )
    fig, ax = plt.subplots(figsize=(7, 5))
    _draw(ax, median, f"Median detection rate over {len(frames)} real datasets (typed injection)")
    fig.tight_layout()
    fig.savefig(args.output / "typed_pooled.png", dpi=160)
    plt.close(fig)
    names = [r["name"] for r in runs][: args.panels]
    cols = 3
    rows = -(-len(names) // cols)
    fig, axes = plt.subplots(rows, cols, figsize=(5.2 * cols, 3.6 * rows), squeeze=False)
    for ax in axes.ravel():
        ax.axis("off")
    for ax, name in zip(axes.ravel(), names, strict=False):
        ax.axis("on")
        _draw(ax, frames[name], name[:38])
    fig.tight_layout()
    fig.savefig(args.output / "typed_panels.png", dpi=130)
    plt.close(fig)
    return 0


def x_main__mutmut_26(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--panels", type=int, )
    args = parser.parse_args(argv)
    runs = sorted(
        (json.loads(p.read_text()) for p in args.runs.glob("*.json")), key=lambda r: r["uci_id"]
    )
    frames = {
        r["name"]: pd.DataFrame(
            r["recall_mean"]["data"],
            index=r["recall_mean"]["index"],
            columns=r["recall_mean"]["columns"],
        )
        for r in runs
    }
    args.output.mkdir(parents=True, exist_ok=True)
    median = pd.DataFrame(
        np.nanmedian(np.stack([f.to_numpy(dtype=float) for f in frames.values()]), axis=0),
        index=next(iter(frames.values())).index,
        columns=next(iter(frames.values())).columns,
    )
    fig, ax = plt.subplots(figsize=(7, 5))
    _draw(ax, median, f"Median detection rate over {len(frames)} real datasets (typed injection)")
    fig.tight_layout()
    fig.savefig(args.output / "typed_pooled.png", dpi=160)
    plt.close(fig)
    names = [r["name"] for r in runs][: args.panels]
    cols = 3
    rows = -(-len(names) // cols)
    fig, axes = plt.subplots(rows, cols, figsize=(5.2 * cols, 3.6 * rows), squeeze=False)
    for ax in axes.ravel():
        ax.axis("off")
    for ax, name in zip(axes.ravel(), names, strict=False):
        ax.axis("on")
        _draw(ax, frames[name], name[:38])
    fig.tight_layout()
    fig.savefig(args.output / "typed_panels.png", dpi=130)
    plt.close(fig)
    return 0


def x_main__mutmut_27(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("XX--panelsXX", type=int, default=6)
    args = parser.parse_args(argv)
    runs = sorted(
        (json.loads(p.read_text()) for p in args.runs.glob("*.json")), key=lambda r: r["uci_id"]
    )
    frames = {
        r["name"]: pd.DataFrame(
            r["recall_mean"]["data"],
            index=r["recall_mean"]["index"],
            columns=r["recall_mean"]["columns"],
        )
        for r in runs
    }
    args.output.mkdir(parents=True, exist_ok=True)
    median = pd.DataFrame(
        np.nanmedian(np.stack([f.to_numpy(dtype=float) for f in frames.values()]), axis=0),
        index=next(iter(frames.values())).index,
        columns=next(iter(frames.values())).columns,
    )
    fig, ax = plt.subplots(figsize=(7, 5))
    _draw(ax, median, f"Median detection rate over {len(frames)} real datasets (typed injection)")
    fig.tight_layout()
    fig.savefig(args.output / "typed_pooled.png", dpi=160)
    plt.close(fig)
    names = [r["name"] for r in runs][: args.panels]
    cols = 3
    rows = -(-len(names) // cols)
    fig, axes = plt.subplots(rows, cols, figsize=(5.2 * cols, 3.6 * rows), squeeze=False)
    for ax in axes.ravel():
        ax.axis("off")
    for ax, name in zip(axes.ravel(), names, strict=False):
        ax.axis("on")
        _draw(ax, frames[name], name[:38])
    fig.tight_layout()
    fig.savefig(args.output / "typed_panels.png", dpi=130)
    plt.close(fig)
    return 0


def x_main__mutmut_28(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--PANELS", type=int, default=6)
    args = parser.parse_args(argv)
    runs = sorted(
        (json.loads(p.read_text()) for p in args.runs.glob("*.json")), key=lambda r: r["uci_id"]
    )
    frames = {
        r["name"]: pd.DataFrame(
            r["recall_mean"]["data"],
            index=r["recall_mean"]["index"],
            columns=r["recall_mean"]["columns"],
        )
        for r in runs
    }
    args.output.mkdir(parents=True, exist_ok=True)
    median = pd.DataFrame(
        np.nanmedian(np.stack([f.to_numpy(dtype=float) for f in frames.values()]), axis=0),
        index=next(iter(frames.values())).index,
        columns=next(iter(frames.values())).columns,
    )
    fig, ax = plt.subplots(figsize=(7, 5))
    _draw(ax, median, f"Median detection rate over {len(frames)} real datasets (typed injection)")
    fig.tight_layout()
    fig.savefig(args.output / "typed_pooled.png", dpi=160)
    plt.close(fig)
    names = [r["name"] for r in runs][: args.panels]
    cols = 3
    rows = -(-len(names) // cols)
    fig, axes = plt.subplots(rows, cols, figsize=(5.2 * cols, 3.6 * rows), squeeze=False)
    for ax in axes.ravel():
        ax.axis("off")
    for ax, name in zip(axes.ravel(), names, strict=False):
        ax.axis("on")
        _draw(ax, frames[name], name[:38])
    fig.tight_layout()
    fig.savefig(args.output / "typed_panels.png", dpi=130)
    plt.close(fig)
    return 0


def x_main__mutmut_29(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--panels", type=int, default=7)
    args = parser.parse_args(argv)
    runs = sorted(
        (json.loads(p.read_text()) for p in args.runs.glob("*.json")), key=lambda r: r["uci_id"]
    )
    frames = {
        r["name"]: pd.DataFrame(
            r["recall_mean"]["data"],
            index=r["recall_mean"]["index"],
            columns=r["recall_mean"]["columns"],
        )
        for r in runs
    }
    args.output.mkdir(parents=True, exist_ok=True)
    median = pd.DataFrame(
        np.nanmedian(np.stack([f.to_numpy(dtype=float) for f in frames.values()]), axis=0),
        index=next(iter(frames.values())).index,
        columns=next(iter(frames.values())).columns,
    )
    fig, ax = plt.subplots(figsize=(7, 5))
    _draw(ax, median, f"Median detection rate over {len(frames)} real datasets (typed injection)")
    fig.tight_layout()
    fig.savefig(args.output / "typed_pooled.png", dpi=160)
    plt.close(fig)
    names = [r["name"] for r in runs][: args.panels]
    cols = 3
    rows = -(-len(names) // cols)
    fig, axes = plt.subplots(rows, cols, figsize=(5.2 * cols, 3.6 * rows), squeeze=False)
    for ax in axes.ravel():
        ax.axis("off")
    for ax, name in zip(axes.ravel(), names, strict=False):
        ax.axis("on")
        _draw(ax, frames[name], name[:38])
    fig.tight_layout()
    fig.savefig(args.output / "typed_panels.png", dpi=130)
    plt.close(fig)
    return 0


def x_main__mutmut_30(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--panels", type=int, default=6)
    args = None
    runs = sorted(
        (json.loads(p.read_text()) for p in args.runs.glob("*.json")), key=lambda r: r["uci_id"]
    )
    frames = {
        r["name"]: pd.DataFrame(
            r["recall_mean"]["data"],
            index=r["recall_mean"]["index"],
            columns=r["recall_mean"]["columns"],
        )
        for r in runs
    }
    args.output.mkdir(parents=True, exist_ok=True)
    median = pd.DataFrame(
        np.nanmedian(np.stack([f.to_numpy(dtype=float) for f in frames.values()]), axis=0),
        index=next(iter(frames.values())).index,
        columns=next(iter(frames.values())).columns,
    )
    fig, ax = plt.subplots(figsize=(7, 5))
    _draw(ax, median, f"Median detection rate over {len(frames)} real datasets (typed injection)")
    fig.tight_layout()
    fig.savefig(args.output / "typed_pooled.png", dpi=160)
    plt.close(fig)
    names = [r["name"] for r in runs][: args.panels]
    cols = 3
    rows = -(-len(names) // cols)
    fig, axes = plt.subplots(rows, cols, figsize=(5.2 * cols, 3.6 * rows), squeeze=False)
    for ax in axes.ravel():
        ax.axis("off")
    for ax, name in zip(axes.ravel(), names, strict=False):
        ax.axis("on")
        _draw(ax, frames[name], name[:38])
    fig.tight_layout()
    fig.savefig(args.output / "typed_panels.png", dpi=130)
    plt.close(fig)
    return 0


def x_main__mutmut_31(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--panels", type=int, default=6)
    args = parser.parse_args(None)
    runs = sorted(
        (json.loads(p.read_text()) for p in args.runs.glob("*.json")), key=lambda r: r["uci_id"]
    )
    frames = {
        r["name"]: pd.DataFrame(
            r["recall_mean"]["data"],
            index=r["recall_mean"]["index"],
            columns=r["recall_mean"]["columns"],
        )
        for r in runs
    }
    args.output.mkdir(parents=True, exist_ok=True)
    median = pd.DataFrame(
        np.nanmedian(np.stack([f.to_numpy(dtype=float) for f in frames.values()]), axis=0),
        index=next(iter(frames.values())).index,
        columns=next(iter(frames.values())).columns,
    )
    fig, ax = plt.subplots(figsize=(7, 5))
    _draw(ax, median, f"Median detection rate over {len(frames)} real datasets (typed injection)")
    fig.tight_layout()
    fig.savefig(args.output / "typed_pooled.png", dpi=160)
    plt.close(fig)
    names = [r["name"] for r in runs][: args.panels]
    cols = 3
    rows = -(-len(names) // cols)
    fig, axes = plt.subplots(rows, cols, figsize=(5.2 * cols, 3.6 * rows), squeeze=False)
    for ax in axes.ravel():
        ax.axis("off")
    for ax, name in zip(axes.ravel(), names, strict=False):
        ax.axis("on")
        _draw(ax, frames[name], name[:38])
    fig.tight_layout()
    fig.savefig(args.output / "typed_panels.png", dpi=130)
    plt.close(fig)
    return 0


def x_main__mutmut_32(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--panels", type=int, default=6)
    args = parser.parse_args(argv)
    runs = None
    frames = {
        r["name"]: pd.DataFrame(
            r["recall_mean"]["data"],
            index=r["recall_mean"]["index"],
            columns=r["recall_mean"]["columns"],
        )
        for r in runs
    }
    args.output.mkdir(parents=True, exist_ok=True)
    median = pd.DataFrame(
        np.nanmedian(np.stack([f.to_numpy(dtype=float) for f in frames.values()]), axis=0),
        index=next(iter(frames.values())).index,
        columns=next(iter(frames.values())).columns,
    )
    fig, ax = plt.subplots(figsize=(7, 5))
    _draw(ax, median, f"Median detection rate over {len(frames)} real datasets (typed injection)")
    fig.tight_layout()
    fig.savefig(args.output / "typed_pooled.png", dpi=160)
    plt.close(fig)
    names = [r["name"] for r in runs][: args.panels]
    cols = 3
    rows = -(-len(names) // cols)
    fig, axes = plt.subplots(rows, cols, figsize=(5.2 * cols, 3.6 * rows), squeeze=False)
    for ax in axes.ravel():
        ax.axis("off")
    for ax, name in zip(axes.ravel(), names, strict=False):
        ax.axis("on")
        _draw(ax, frames[name], name[:38])
    fig.tight_layout()
    fig.savefig(args.output / "typed_panels.png", dpi=130)
    plt.close(fig)
    return 0


def x_main__mutmut_33(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--panels", type=int, default=6)
    args = parser.parse_args(argv)
    runs = sorted(
        None, key=lambda r: r["uci_id"]
    )
    frames = {
        r["name"]: pd.DataFrame(
            r["recall_mean"]["data"],
            index=r["recall_mean"]["index"],
            columns=r["recall_mean"]["columns"],
        )
        for r in runs
    }
    args.output.mkdir(parents=True, exist_ok=True)
    median = pd.DataFrame(
        np.nanmedian(np.stack([f.to_numpy(dtype=float) for f in frames.values()]), axis=0),
        index=next(iter(frames.values())).index,
        columns=next(iter(frames.values())).columns,
    )
    fig, ax = plt.subplots(figsize=(7, 5))
    _draw(ax, median, f"Median detection rate over {len(frames)} real datasets (typed injection)")
    fig.tight_layout()
    fig.savefig(args.output / "typed_pooled.png", dpi=160)
    plt.close(fig)
    names = [r["name"] for r in runs][: args.panels]
    cols = 3
    rows = -(-len(names) // cols)
    fig, axes = plt.subplots(rows, cols, figsize=(5.2 * cols, 3.6 * rows), squeeze=False)
    for ax in axes.ravel():
        ax.axis("off")
    for ax, name in zip(axes.ravel(), names, strict=False):
        ax.axis("on")
        _draw(ax, frames[name], name[:38])
    fig.tight_layout()
    fig.savefig(args.output / "typed_panels.png", dpi=130)
    plt.close(fig)
    return 0


def x_main__mutmut_34(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--panels", type=int, default=6)
    args = parser.parse_args(argv)
    runs = sorted(
        (json.loads(p.read_text()) for p in args.runs.glob("*.json")), key=None
    )
    frames = {
        r["name"]: pd.DataFrame(
            r["recall_mean"]["data"],
            index=r["recall_mean"]["index"],
            columns=r["recall_mean"]["columns"],
        )
        for r in runs
    }
    args.output.mkdir(parents=True, exist_ok=True)
    median = pd.DataFrame(
        np.nanmedian(np.stack([f.to_numpy(dtype=float) for f in frames.values()]), axis=0),
        index=next(iter(frames.values())).index,
        columns=next(iter(frames.values())).columns,
    )
    fig, ax = plt.subplots(figsize=(7, 5))
    _draw(ax, median, f"Median detection rate over {len(frames)} real datasets (typed injection)")
    fig.tight_layout()
    fig.savefig(args.output / "typed_pooled.png", dpi=160)
    plt.close(fig)
    names = [r["name"] for r in runs][: args.panels]
    cols = 3
    rows = -(-len(names) // cols)
    fig, axes = plt.subplots(rows, cols, figsize=(5.2 * cols, 3.6 * rows), squeeze=False)
    for ax in axes.ravel():
        ax.axis("off")
    for ax, name in zip(axes.ravel(), names, strict=False):
        ax.axis("on")
        _draw(ax, frames[name], name[:38])
    fig.tight_layout()
    fig.savefig(args.output / "typed_panels.png", dpi=130)
    plt.close(fig)
    return 0


def x_main__mutmut_35(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--panels", type=int, default=6)
    args = parser.parse_args(argv)
    runs = sorted(
        key=lambda r: r["uci_id"]
    )
    frames = {
        r["name"]: pd.DataFrame(
            r["recall_mean"]["data"],
            index=r["recall_mean"]["index"],
            columns=r["recall_mean"]["columns"],
        )
        for r in runs
    }
    args.output.mkdir(parents=True, exist_ok=True)
    median = pd.DataFrame(
        np.nanmedian(np.stack([f.to_numpy(dtype=float) for f in frames.values()]), axis=0),
        index=next(iter(frames.values())).index,
        columns=next(iter(frames.values())).columns,
    )
    fig, ax = plt.subplots(figsize=(7, 5))
    _draw(ax, median, f"Median detection rate over {len(frames)} real datasets (typed injection)")
    fig.tight_layout()
    fig.savefig(args.output / "typed_pooled.png", dpi=160)
    plt.close(fig)
    names = [r["name"] for r in runs][: args.panels]
    cols = 3
    rows = -(-len(names) // cols)
    fig, axes = plt.subplots(rows, cols, figsize=(5.2 * cols, 3.6 * rows), squeeze=False)
    for ax in axes.ravel():
        ax.axis("off")
    for ax, name in zip(axes.ravel(), names, strict=False):
        ax.axis("on")
        _draw(ax, frames[name], name[:38])
    fig.tight_layout()
    fig.savefig(args.output / "typed_panels.png", dpi=130)
    plt.close(fig)
    return 0


def x_main__mutmut_36(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--panels", type=int, default=6)
    args = parser.parse_args(argv)
    runs = sorted(
        (json.loads(p.read_text()) for p in args.runs.glob("*.json")), )
    frames = {
        r["name"]: pd.DataFrame(
            r["recall_mean"]["data"],
            index=r["recall_mean"]["index"],
            columns=r["recall_mean"]["columns"],
        )
        for r in runs
    }
    args.output.mkdir(parents=True, exist_ok=True)
    median = pd.DataFrame(
        np.nanmedian(np.stack([f.to_numpy(dtype=float) for f in frames.values()]), axis=0),
        index=next(iter(frames.values())).index,
        columns=next(iter(frames.values())).columns,
    )
    fig, ax = plt.subplots(figsize=(7, 5))
    _draw(ax, median, f"Median detection rate over {len(frames)} real datasets (typed injection)")
    fig.tight_layout()
    fig.savefig(args.output / "typed_pooled.png", dpi=160)
    plt.close(fig)
    names = [r["name"] for r in runs][: args.panels]
    cols = 3
    rows = -(-len(names) // cols)
    fig, axes = plt.subplots(rows, cols, figsize=(5.2 * cols, 3.6 * rows), squeeze=False)
    for ax in axes.ravel():
        ax.axis("off")
    for ax, name in zip(axes.ravel(), names, strict=False):
        ax.axis("on")
        _draw(ax, frames[name], name[:38])
    fig.tight_layout()
    fig.savefig(args.output / "typed_panels.png", dpi=130)
    plt.close(fig)
    return 0


def x_main__mutmut_37(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--panels", type=int, default=6)
    args = parser.parse_args(argv)
    runs = sorted(
        (json.loads(None) for p in args.runs.glob("*.json")), key=lambda r: r["uci_id"]
    )
    frames = {
        r["name"]: pd.DataFrame(
            r["recall_mean"]["data"],
            index=r["recall_mean"]["index"],
            columns=r["recall_mean"]["columns"],
        )
        for r in runs
    }
    args.output.mkdir(parents=True, exist_ok=True)
    median = pd.DataFrame(
        np.nanmedian(np.stack([f.to_numpy(dtype=float) for f in frames.values()]), axis=0),
        index=next(iter(frames.values())).index,
        columns=next(iter(frames.values())).columns,
    )
    fig, ax = plt.subplots(figsize=(7, 5))
    _draw(ax, median, f"Median detection rate over {len(frames)} real datasets (typed injection)")
    fig.tight_layout()
    fig.savefig(args.output / "typed_pooled.png", dpi=160)
    plt.close(fig)
    names = [r["name"] for r in runs][: args.panels]
    cols = 3
    rows = -(-len(names) // cols)
    fig, axes = plt.subplots(rows, cols, figsize=(5.2 * cols, 3.6 * rows), squeeze=False)
    for ax in axes.ravel():
        ax.axis("off")
    for ax, name in zip(axes.ravel(), names, strict=False):
        ax.axis("on")
        _draw(ax, frames[name], name[:38])
    fig.tight_layout()
    fig.savefig(args.output / "typed_panels.png", dpi=130)
    plt.close(fig)
    return 0


def x_main__mutmut_38(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--panels", type=int, default=6)
    args = parser.parse_args(argv)
    runs = sorted(
        (json.loads(p.read_text()) for p in args.runs.glob(None)), key=lambda r: r["uci_id"]
    )
    frames = {
        r["name"]: pd.DataFrame(
            r["recall_mean"]["data"],
            index=r["recall_mean"]["index"],
            columns=r["recall_mean"]["columns"],
        )
        for r in runs
    }
    args.output.mkdir(parents=True, exist_ok=True)
    median = pd.DataFrame(
        np.nanmedian(np.stack([f.to_numpy(dtype=float) for f in frames.values()]), axis=0),
        index=next(iter(frames.values())).index,
        columns=next(iter(frames.values())).columns,
    )
    fig, ax = plt.subplots(figsize=(7, 5))
    _draw(ax, median, f"Median detection rate over {len(frames)} real datasets (typed injection)")
    fig.tight_layout()
    fig.savefig(args.output / "typed_pooled.png", dpi=160)
    plt.close(fig)
    names = [r["name"] for r in runs][: args.panels]
    cols = 3
    rows = -(-len(names) // cols)
    fig, axes = plt.subplots(rows, cols, figsize=(5.2 * cols, 3.6 * rows), squeeze=False)
    for ax in axes.ravel():
        ax.axis("off")
    for ax, name in zip(axes.ravel(), names, strict=False):
        ax.axis("on")
        _draw(ax, frames[name], name[:38])
    fig.tight_layout()
    fig.savefig(args.output / "typed_panels.png", dpi=130)
    plt.close(fig)
    return 0


def x_main__mutmut_39(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--panels", type=int, default=6)
    args = parser.parse_args(argv)
    runs = sorted(
        (json.loads(p.read_text()) for p in args.runs.glob("XX*.jsonXX")), key=lambda r: r["uci_id"]
    )
    frames = {
        r["name"]: pd.DataFrame(
            r["recall_mean"]["data"],
            index=r["recall_mean"]["index"],
            columns=r["recall_mean"]["columns"],
        )
        for r in runs
    }
    args.output.mkdir(parents=True, exist_ok=True)
    median = pd.DataFrame(
        np.nanmedian(np.stack([f.to_numpy(dtype=float) for f in frames.values()]), axis=0),
        index=next(iter(frames.values())).index,
        columns=next(iter(frames.values())).columns,
    )
    fig, ax = plt.subplots(figsize=(7, 5))
    _draw(ax, median, f"Median detection rate over {len(frames)} real datasets (typed injection)")
    fig.tight_layout()
    fig.savefig(args.output / "typed_pooled.png", dpi=160)
    plt.close(fig)
    names = [r["name"] for r in runs][: args.panels]
    cols = 3
    rows = -(-len(names) // cols)
    fig, axes = plt.subplots(rows, cols, figsize=(5.2 * cols, 3.6 * rows), squeeze=False)
    for ax in axes.ravel():
        ax.axis("off")
    for ax, name in zip(axes.ravel(), names, strict=False):
        ax.axis("on")
        _draw(ax, frames[name], name[:38])
    fig.tight_layout()
    fig.savefig(args.output / "typed_panels.png", dpi=130)
    plt.close(fig)
    return 0


def x_main__mutmut_40(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--panels", type=int, default=6)
    args = parser.parse_args(argv)
    runs = sorted(
        (json.loads(p.read_text()) for p in args.runs.glob("*.JSON")), key=lambda r: r["uci_id"]
    )
    frames = {
        r["name"]: pd.DataFrame(
            r["recall_mean"]["data"],
            index=r["recall_mean"]["index"],
            columns=r["recall_mean"]["columns"],
        )
        for r in runs
    }
    args.output.mkdir(parents=True, exist_ok=True)
    median = pd.DataFrame(
        np.nanmedian(np.stack([f.to_numpy(dtype=float) for f in frames.values()]), axis=0),
        index=next(iter(frames.values())).index,
        columns=next(iter(frames.values())).columns,
    )
    fig, ax = plt.subplots(figsize=(7, 5))
    _draw(ax, median, f"Median detection rate over {len(frames)} real datasets (typed injection)")
    fig.tight_layout()
    fig.savefig(args.output / "typed_pooled.png", dpi=160)
    plt.close(fig)
    names = [r["name"] for r in runs][: args.panels]
    cols = 3
    rows = -(-len(names) // cols)
    fig, axes = plt.subplots(rows, cols, figsize=(5.2 * cols, 3.6 * rows), squeeze=False)
    for ax in axes.ravel():
        ax.axis("off")
    for ax, name in zip(axes.ravel(), names, strict=False):
        ax.axis("on")
        _draw(ax, frames[name], name[:38])
    fig.tight_layout()
    fig.savefig(args.output / "typed_panels.png", dpi=130)
    plt.close(fig)
    return 0


def x_main__mutmut_41(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--panels", type=int, default=6)
    args = parser.parse_args(argv)
    runs = sorted(
        (json.loads(p.read_text()) for p in args.runs.glob("*.json")), key=lambda r: None
    )
    frames = {
        r["name"]: pd.DataFrame(
            r["recall_mean"]["data"],
            index=r["recall_mean"]["index"],
            columns=r["recall_mean"]["columns"],
        )
        for r in runs
    }
    args.output.mkdir(parents=True, exist_ok=True)
    median = pd.DataFrame(
        np.nanmedian(np.stack([f.to_numpy(dtype=float) for f in frames.values()]), axis=0),
        index=next(iter(frames.values())).index,
        columns=next(iter(frames.values())).columns,
    )
    fig, ax = plt.subplots(figsize=(7, 5))
    _draw(ax, median, f"Median detection rate over {len(frames)} real datasets (typed injection)")
    fig.tight_layout()
    fig.savefig(args.output / "typed_pooled.png", dpi=160)
    plt.close(fig)
    names = [r["name"] for r in runs][: args.panels]
    cols = 3
    rows = -(-len(names) // cols)
    fig, axes = plt.subplots(rows, cols, figsize=(5.2 * cols, 3.6 * rows), squeeze=False)
    for ax in axes.ravel():
        ax.axis("off")
    for ax, name in zip(axes.ravel(), names, strict=False):
        ax.axis("on")
        _draw(ax, frames[name], name[:38])
    fig.tight_layout()
    fig.savefig(args.output / "typed_panels.png", dpi=130)
    plt.close(fig)
    return 0


def x_main__mutmut_42(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--panels", type=int, default=6)
    args = parser.parse_args(argv)
    runs = sorted(
        (json.loads(p.read_text()) for p in args.runs.glob("*.json")), key=lambda r: r["XXuci_idXX"]
    )
    frames = {
        r["name"]: pd.DataFrame(
            r["recall_mean"]["data"],
            index=r["recall_mean"]["index"],
            columns=r["recall_mean"]["columns"],
        )
        for r in runs
    }
    args.output.mkdir(parents=True, exist_ok=True)
    median = pd.DataFrame(
        np.nanmedian(np.stack([f.to_numpy(dtype=float) for f in frames.values()]), axis=0),
        index=next(iter(frames.values())).index,
        columns=next(iter(frames.values())).columns,
    )
    fig, ax = plt.subplots(figsize=(7, 5))
    _draw(ax, median, f"Median detection rate over {len(frames)} real datasets (typed injection)")
    fig.tight_layout()
    fig.savefig(args.output / "typed_pooled.png", dpi=160)
    plt.close(fig)
    names = [r["name"] for r in runs][: args.panels]
    cols = 3
    rows = -(-len(names) // cols)
    fig, axes = plt.subplots(rows, cols, figsize=(5.2 * cols, 3.6 * rows), squeeze=False)
    for ax in axes.ravel():
        ax.axis("off")
    for ax, name in zip(axes.ravel(), names, strict=False):
        ax.axis("on")
        _draw(ax, frames[name], name[:38])
    fig.tight_layout()
    fig.savefig(args.output / "typed_panels.png", dpi=130)
    plt.close(fig)
    return 0


def x_main__mutmut_43(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--panels", type=int, default=6)
    args = parser.parse_args(argv)
    runs = sorted(
        (json.loads(p.read_text()) for p in args.runs.glob("*.json")), key=lambda r: r["UCI_ID"]
    )
    frames = {
        r["name"]: pd.DataFrame(
            r["recall_mean"]["data"],
            index=r["recall_mean"]["index"],
            columns=r["recall_mean"]["columns"],
        )
        for r in runs
    }
    args.output.mkdir(parents=True, exist_ok=True)
    median = pd.DataFrame(
        np.nanmedian(np.stack([f.to_numpy(dtype=float) for f in frames.values()]), axis=0),
        index=next(iter(frames.values())).index,
        columns=next(iter(frames.values())).columns,
    )
    fig, ax = plt.subplots(figsize=(7, 5))
    _draw(ax, median, f"Median detection rate over {len(frames)} real datasets (typed injection)")
    fig.tight_layout()
    fig.savefig(args.output / "typed_pooled.png", dpi=160)
    plt.close(fig)
    names = [r["name"] for r in runs][: args.panels]
    cols = 3
    rows = -(-len(names) // cols)
    fig, axes = plt.subplots(rows, cols, figsize=(5.2 * cols, 3.6 * rows), squeeze=False)
    for ax in axes.ravel():
        ax.axis("off")
    for ax, name in zip(axes.ravel(), names, strict=False):
        ax.axis("on")
        _draw(ax, frames[name], name[:38])
    fig.tight_layout()
    fig.savefig(args.output / "typed_panels.png", dpi=130)
    plt.close(fig)
    return 0


def x_main__mutmut_44(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--panels", type=int, default=6)
    args = parser.parse_args(argv)
    runs = sorted(
        (json.loads(p.read_text()) for p in args.runs.glob("*.json")), key=lambda r: r["uci_id"]
    )
    frames = None
    args.output.mkdir(parents=True, exist_ok=True)
    median = pd.DataFrame(
        np.nanmedian(np.stack([f.to_numpy(dtype=float) for f in frames.values()]), axis=0),
        index=next(iter(frames.values())).index,
        columns=next(iter(frames.values())).columns,
    )
    fig, ax = plt.subplots(figsize=(7, 5))
    _draw(ax, median, f"Median detection rate over {len(frames)} real datasets (typed injection)")
    fig.tight_layout()
    fig.savefig(args.output / "typed_pooled.png", dpi=160)
    plt.close(fig)
    names = [r["name"] for r in runs][: args.panels]
    cols = 3
    rows = -(-len(names) // cols)
    fig, axes = plt.subplots(rows, cols, figsize=(5.2 * cols, 3.6 * rows), squeeze=False)
    for ax in axes.ravel():
        ax.axis("off")
    for ax, name in zip(axes.ravel(), names, strict=False):
        ax.axis("on")
        _draw(ax, frames[name], name[:38])
    fig.tight_layout()
    fig.savefig(args.output / "typed_panels.png", dpi=130)
    plt.close(fig)
    return 0


def x_main__mutmut_45(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--panels", type=int, default=6)
    args = parser.parse_args(argv)
    runs = sorted(
        (json.loads(p.read_text()) for p in args.runs.glob("*.json")), key=lambda r: r["uci_id"]
    )
    frames = {
        r["XXnameXX"]: pd.DataFrame(
            r["recall_mean"]["data"],
            index=r["recall_mean"]["index"],
            columns=r["recall_mean"]["columns"],
        )
        for r in runs
    }
    args.output.mkdir(parents=True, exist_ok=True)
    median = pd.DataFrame(
        np.nanmedian(np.stack([f.to_numpy(dtype=float) for f in frames.values()]), axis=0),
        index=next(iter(frames.values())).index,
        columns=next(iter(frames.values())).columns,
    )
    fig, ax = plt.subplots(figsize=(7, 5))
    _draw(ax, median, f"Median detection rate over {len(frames)} real datasets (typed injection)")
    fig.tight_layout()
    fig.savefig(args.output / "typed_pooled.png", dpi=160)
    plt.close(fig)
    names = [r["name"] for r in runs][: args.panels]
    cols = 3
    rows = -(-len(names) // cols)
    fig, axes = plt.subplots(rows, cols, figsize=(5.2 * cols, 3.6 * rows), squeeze=False)
    for ax in axes.ravel():
        ax.axis("off")
    for ax, name in zip(axes.ravel(), names, strict=False):
        ax.axis("on")
        _draw(ax, frames[name], name[:38])
    fig.tight_layout()
    fig.savefig(args.output / "typed_panels.png", dpi=130)
    plt.close(fig)
    return 0


def x_main__mutmut_46(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--panels", type=int, default=6)
    args = parser.parse_args(argv)
    runs = sorted(
        (json.loads(p.read_text()) for p in args.runs.glob("*.json")), key=lambda r: r["uci_id"]
    )
    frames = {
        r["NAME"]: pd.DataFrame(
            r["recall_mean"]["data"],
            index=r["recall_mean"]["index"],
            columns=r["recall_mean"]["columns"],
        )
        for r in runs
    }
    args.output.mkdir(parents=True, exist_ok=True)
    median = pd.DataFrame(
        np.nanmedian(np.stack([f.to_numpy(dtype=float) for f in frames.values()]), axis=0),
        index=next(iter(frames.values())).index,
        columns=next(iter(frames.values())).columns,
    )
    fig, ax = plt.subplots(figsize=(7, 5))
    _draw(ax, median, f"Median detection rate over {len(frames)} real datasets (typed injection)")
    fig.tight_layout()
    fig.savefig(args.output / "typed_pooled.png", dpi=160)
    plt.close(fig)
    names = [r["name"] for r in runs][: args.panels]
    cols = 3
    rows = -(-len(names) // cols)
    fig, axes = plt.subplots(rows, cols, figsize=(5.2 * cols, 3.6 * rows), squeeze=False)
    for ax in axes.ravel():
        ax.axis("off")
    for ax, name in zip(axes.ravel(), names, strict=False):
        ax.axis("on")
        _draw(ax, frames[name], name[:38])
    fig.tight_layout()
    fig.savefig(args.output / "typed_panels.png", dpi=130)
    plt.close(fig)
    return 0


def x_main__mutmut_47(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--panels", type=int, default=6)
    args = parser.parse_args(argv)
    runs = sorted(
        (json.loads(p.read_text()) for p in args.runs.glob("*.json")), key=lambda r: r["uci_id"]
    )
    frames = {
        r["name"]: pd.DataFrame(
            None,
            index=r["recall_mean"]["index"],
            columns=r["recall_mean"]["columns"],
        )
        for r in runs
    }
    args.output.mkdir(parents=True, exist_ok=True)
    median = pd.DataFrame(
        np.nanmedian(np.stack([f.to_numpy(dtype=float) for f in frames.values()]), axis=0),
        index=next(iter(frames.values())).index,
        columns=next(iter(frames.values())).columns,
    )
    fig, ax = plt.subplots(figsize=(7, 5))
    _draw(ax, median, f"Median detection rate over {len(frames)} real datasets (typed injection)")
    fig.tight_layout()
    fig.savefig(args.output / "typed_pooled.png", dpi=160)
    plt.close(fig)
    names = [r["name"] for r in runs][: args.panels]
    cols = 3
    rows = -(-len(names) // cols)
    fig, axes = plt.subplots(rows, cols, figsize=(5.2 * cols, 3.6 * rows), squeeze=False)
    for ax in axes.ravel():
        ax.axis("off")
    for ax, name in zip(axes.ravel(), names, strict=False):
        ax.axis("on")
        _draw(ax, frames[name], name[:38])
    fig.tight_layout()
    fig.savefig(args.output / "typed_panels.png", dpi=130)
    plt.close(fig)
    return 0


def x_main__mutmut_48(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--panels", type=int, default=6)
    args = parser.parse_args(argv)
    runs = sorted(
        (json.loads(p.read_text()) for p in args.runs.glob("*.json")), key=lambda r: r["uci_id"]
    )
    frames = {
        r["name"]: pd.DataFrame(
            r["recall_mean"]["data"],
            index=None,
            columns=r["recall_mean"]["columns"],
        )
        for r in runs
    }
    args.output.mkdir(parents=True, exist_ok=True)
    median = pd.DataFrame(
        np.nanmedian(np.stack([f.to_numpy(dtype=float) for f in frames.values()]), axis=0),
        index=next(iter(frames.values())).index,
        columns=next(iter(frames.values())).columns,
    )
    fig, ax = plt.subplots(figsize=(7, 5))
    _draw(ax, median, f"Median detection rate over {len(frames)} real datasets (typed injection)")
    fig.tight_layout()
    fig.savefig(args.output / "typed_pooled.png", dpi=160)
    plt.close(fig)
    names = [r["name"] for r in runs][: args.panels]
    cols = 3
    rows = -(-len(names) // cols)
    fig, axes = plt.subplots(rows, cols, figsize=(5.2 * cols, 3.6 * rows), squeeze=False)
    for ax in axes.ravel():
        ax.axis("off")
    for ax, name in zip(axes.ravel(), names, strict=False):
        ax.axis("on")
        _draw(ax, frames[name], name[:38])
    fig.tight_layout()
    fig.savefig(args.output / "typed_panels.png", dpi=130)
    plt.close(fig)
    return 0


def x_main__mutmut_49(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--panels", type=int, default=6)
    args = parser.parse_args(argv)
    runs = sorted(
        (json.loads(p.read_text()) for p in args.runs.glob("*.json")), key=lambda r: r["uci_id"]
    )
    frames = {
        r["name"]: pd.DataFrame(
            r["recall_mean"]["data"],
            index=r["recall_mean"]["index"],
            columns=None,
        )
        for r in runs
    }
    args.output.mkdir(parents=True, exist_ok=True)
    median = pd.DataFrame(
        np.nanmedian(np.stack([f.to_numpy(dtype=float) for f in frames.values()]), axis=0),
        index=next(iter(frames.values())).index,
        columns=next(iter(frames.values())).columns,
    )
    fig, ax = plt.subplots(figsize=(7, 5))
    _draw(ax, median, f"Median detection rate over {len(frames)} real datasets (typed injection)")
    fig.tight_layout()
    fig.savefig(args.output / "typed_pooled.png", dpi=160)
    plt.close(fig)
    names = [r["name"] for r in runs][: args.panels]
    cols = 3
    rows = -(-len(names) // cols)
    fig, axes = plt.subplots(rows, cols, figsize=(5.2 * cols, 3.6 * rows), squeeze=False)
    for ax in axes.ravel():
        ax.axis("off")
    for ax, name in zip(axes.ravel(), names, strict=False):
        ax.axis("on")
        _draw(ax, frames[name], name[:38])
    fig.tight_layout()
    fig.savefig(args.output / "typed_panels.png", dpi=130)
    plt.close(fig)
    return 0


def x_main__mutmut_50(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--panels", type=int, default=6)
    args = parser.parse_args(argv)
    runs = sorted(
        (json.loads(p.read_text()) for p in args.runs.glob("*.json")), key=lambda r: r["uci_id"]
    )
    frames = {
        r["name"]: pd.DataFrame(
            index=r["recall_mean"]["index"],
            columns=r["recall_mean"]["columns"],
        )
        for r in runs
    }
    args.output.mkdir(parents=True, exist_ok=True)
    median = pd.DataFrame(
        np.nanmedian(np.stack([f.to_numpy(dtype=float) for f in frames.values()]), axis=0),
        index=next(iter(frames.values())).index,
        columns=next(iter(frames.values())).columns,
    )
    fig, ax = plt.subplots(figsize=(7, 5))
    _draw(ax, median, f"Median detection rate over {len(frames)} real datasets (typed injection)")
    fig.tight_layout()
    fig.savefig(args.output / "typed_pooled.png", dpi=160)
    plt.close(fig)
    names = [r["name"] for r in runs][: args.panels]
    cols = 3
    rows = -(-len(names) // cols)
    fig, axes = plt.subplots(rows, cols, figsize=(5.2 * cols, 3.6 * rows), squeeze=False)
    for ax in axes.ravel():
        ax.axis("off")
    for ax, name in zip(axes.ravel(), names, strict=False):
        ax.axis("on")
        _draw(ax, frames[name], name[:38])
    fig.tight_layout()
    fig.savefig(args.output / "typed_panels.png", dpi=130)
    plt.close(fig)
    return 0


def x_main__mutmut_51(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--panels", type=int, default=6)
    args = parser.parse_args(argv)
    runs = sorted(
        (json.loads(p.read_text()) for p in args.runs.glob("*.json")), key=lambda r: r["uci_id"]
    )
    frames = {
        r["name"]: pd.DataFrame(
            r["recall_mean"]["data"],
            columns=r["recall_mean"]["columns"],
        )
        for r in runs
    }
    args.output.mkdir(parents=True, exist_ok=True)
    median = pd.DataFrame(
        np.nanmedian(np.stack([f.to_numpy(dtype=float) for f in frames.values()]), axis=0),
        index=next(iter(frames.values())).index,
        columns=next(iter(frames.values())).columns,
    )
    fig, ax = plt.subplots(figsize=(7, 5))
    _draw(ax, median, f"Median detection rate over {len(frames)} real datasets (typed injection)")
    fig.tight_layout()
    fig.savefig(args.output / "typed_pooled.png", dpi=160)
    plt.close(fig)
    names = [r["name"] for r in runs][: args.panels]
    cols = 3
    rows = -(-len(names) // cols)
    fig, axes = plt.subplots(rows, cols, figsize=(5.2 * cols, 3.6 * rows), squeeze=False)
    for ax in axes.ravel():
        ax.axis("off")
    for ax, name in zip(axes.ravel(), names, strict=False):
        ax.axis("on")
        _draw(ax, frames[name], name[:38])
    fig.tight_layout()
    fig.savefig(args.output / "typed_panels.png", dpi=130)
    plt.close(fig)
    return 0


def x_main__mutmut_52(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--panels", type=int, default=6)
    args = parser.parse_args(argv)
    runs = sorted(
        (json.loads(p.read_text()) for p in args.runs.glob("*.json")), key=lambda r: r["uci_id"]
    )
    frames = {
        r["name"]: pd.DataFrame(
            r["recall_mean"]["data"],
            index=r["recall_mean"]["index"],
            )
        for r in runs
    }
    args.output.mkdir(parents=True, exist_ok=True)
    median = pd.DataFrame(
        np.nanmedian(np.stack([f.to_numpy(dtype=float) for f in frames.values()]), axis=0),
        index=next(iter(frames.values())).index,
        columns=next(iter(frames.values())).columns,
    )
    fig, ax = plt.subplots(figsize=(7, 5))
    _draw(ax, median, f"Median detection rate over {len(frames)} real datasets (typed injection)")
    fig.tight_layout()
    fig.savefig(args.output / "typed_pooled.png", dpi=160)
    plt.close(fig)
    names = [r["name"] for r in runs][: args.panels]
    cols = 3
    rows = -(-len(names) // cols)
    fig, axes = plt.subplots(rows, cols, figsize=(5.2 * cols, 3.6 * rows), squeeze=False)
    for ax in axes.ravel():
        ax.axis("off")
    for ax, name in zip(axes.ravel(), names, strict=False):
        ax.axis("on")
        _draw(ax, frames[name], name[:38])
    fig.tight_layout()
    fig.savefig(args.output / "typed_panels.png", dpi=130)
    plt.close(fig)
    return 0


def x_main__mutmut_53(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--panels", type=int, default=6)
    args = parser.parse_args(argv)
    runs = sorted(
        (json.loads(p.read_text()) for p in args.runs.glob("*.json")), key=lambda r: r["uci_id"]
    )
    frames = {
        r["name"]: pd.DataFrame(
            r["XXrecall_meanXX"]["data"],
            index=r["recall_mean"]["index"],
            columns=r["recall_mean"]["columns"],
        )
        for r in runs
    }
    args.output.mkdir(parents=True, exist_ok=True)
    median = pd.DataFrame(
        np.nanmedian(np.stack([f.to_numpy(dtype=float) for f in frames.values()]), axis=0),
        index=next(iter(frames.values())).index,
        columns=next(iter(frames.values())).columns,
    )
    fig, ax = plt.subplots(figsize=(7, 5))
    _draw(ax, median, f"Median detection rate over {len(frames)} real datasets (typed injection)")
    fig.tight_layout()
    fig.savefig(args.output / "typed_pooled.png", dpi=160)
    plt.close(fig)
    names = [r["name"] for r in runs][: args.panels]
    cols = 3
    rows = -(-len(names) // cols)
    fig, axes = plt.subplots(rows, cols, figsize=(5.2 * cols, 3.6 * rows), squeeze=False)
    for ax in axes.ravel():
        ax.axis("off")
    for ax, name in zip(axes.ravel(), names, strict=False):
        ax.axis("on")
        _draw(ax, frames[name], name[:38])
    fig.tight_layout()
    fig.savefig(args.output / "typed_panels.png", dpi=130)
    plt.close(fig)
    return 0


def x_main__mutmut_54(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--panels", type=int, default=6)
    args = parser.parse_args(argv)
    runs = sorted(
        (json.loads(p.read_text()) for p in args.runs.glob("*.json")), key=lambda r: r["uci_id"]
    )
    frames = {
        r["name"]: pd.DataFrame(
            r["RECALL_MEAN"]["data"],
            index=r["recall_mean"]["index"],
            columns=r["recall_mean"]["columns"],
        )
        for r in runs
    }
    args.output.mkdir(parents=True, exist_ok=True)
    median = pd.DataFrame(
        np.nanmedian(np.stack([f.to_numpy(dtype=float) for f in frames.values()]), axis=0),
        index=next(iter(frames.values())).index,
        columns=next(iter(frames.values())).columns,
    )
    fig, ax = plt.subplots(figsize=(7, 5))
    _draw(ax, median, f"Median detection rate over {len(frames)} real datasets (typed injection)")
    fig.tight_layout()
    fig.savefig(args.output / "typed_pooled.png", dpi=160)
    plt.close(fig)
    names = [r["name"] for r in runs][: args.panels]
    cols = 3
    rows = -(-len(names) // cols)
    fig, axes = plt.subplots(rows, cols, figsize=(5.2 * cols, 3.6 * rows), squeeze=False)
    for ax in axes.ravel():
        ax.axis("off")
    for ax, name in zip(axes.ravel(), names, strict=False):
        ax.axis("on")
        _draw(ax, frames[name], name[:38])
    fig.tight_layout()
    fig.savefig(args.output / "typed_panels.png", dpi=130)
    plt.close(fig)
    return 0


def x_main__mutmut_55(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--panels", type=int, default=6)
    args = parser.parse_args(argv)
    runs = sorted(
        (json.loads(p.read_text()) for p in args.runs.glob("*.json")), key=lambda r: r["uci_id"]
    )
    frames = {
        r["name"]: pd.DataFrame(
            r["recall_mean"]["XXdataXX"],
            index=r["recall_mean"]["index"],
            columns=r["recall_mean"]["columns"],
        )
        for r in runs
    }
    args.output.mkdir(parents=True, exist_ok=True)
    median = pd.DataFrame(
        np.nanmedian(np.stack([f.to_numpy(dtype=float) for f in frames.values()]), axis=0),
        index=next(iter(frames.values())).index,
        columns=next(iter(frames.values())).columns,
    )
    fig, ax = plt.subplots(figsize=(7, 5))
    _draw(ax, median, f"Median detection rate over {len(frames)} real datasets (typed injection)")
    fig.tight_layout()
    fig.savefig(args.output / "typed_pooled.png", dpi=160)
    plt.close(fig)
    names = [r["name"] for r in runs][: args.panels]
    cols = 3
    rows = -(-len(names) // cols)
    fig, axes = plt.subplots(rows, cols, figsize=(5.2 * cols, 3.6 * rows), squeeze=False)
    for ax in axes.ravel():
        ax.axis("off")
    for ax, name in zip(axes.ravel(), names, strict=False):
        ax.axis("on")
        _draw(ax, frames[name], name[:38])
    fig.tight_layout()
    fig.savefig(args.output / "typed_panels.png", dpi=130)
    plt.close(fig)
    return 0


def x_main__mutmut_56(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--panels", type=int, default=6)
    args = parser.parse_args(argv)
    runs = sorted(
        (json.loads(p.read_text()) for p in args.runs.glob("*.json")), key=lambda r: r["uci_id"]
    )
    frames = {
        r["name"]: pd.DataFrame(
            r["recall_mean"]["DATA"],
            index=r["recall_mean"]["index"],
            columns=r["recall_mean"]["columns"],
        )
        for r in runs
    }
    args.output.mkdir(parents=True, exist_ok=True)
    median = pd.DataFrame(
        np.nanmedian(np.stack([f.to_numpy(dtype=float) for f in frames.values()]), axis=0),
        index=next(iter(frames.values())).index,
        columns=next(iter(frames.values())).columns,
    )
    fig, ax = plt.subplots(figsize=(7, 5))
    _draw(ax, median, f"Median detection rate over {len(frames)} real datasets (typed injection)")
    fig.tight_layout()
    fig.savefig(args.output / "typed_pooled.png", dpi=160)
    plt.close(fig)
    names = [r["name"] for r in runs][: args.panels]
    cols = 3
    rows = -(-len(names) // cols)
    fig, axes = plt.subplots(rows, cols, figsize=(5.2 * cols, 3.6 * rows), squeeze=False)
    for ax in axes.ravel():
        ax.axis("off")
    for ax, name in zip(axes.ravel(), names, strict=False):
        ax.axis("on")
        _draw(ax, frames[name], name[:38])
    fig.tight_layout()
    fig.savefig(args.output / "typed_panels.png", dpi=130)
    plt.close(fig)
    return 0


def x_main__mutmut_57(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--panels", type=int, default=6)
    args = parser.parse_args(argv)
    runs = sorted(
        (json.loads(p.read_text()) for p in args.runs.glob("*.json")), key=lambda r: r["uci_id"]
    )
    frames = {
        r["name"]: pd.DataFrame(
            r["recall_mean"]["data"],
            index=r["XXrecall_meanXX"]["index"],
            columns=r["recall_mean"]["columns"],
        )
        for r in runs
    }
    args.output.mkdir(parents=True, exist_ok=True)
    median = pd.DataFrame(
        np.nanmedian(np.stack([f.to_numpy(dtype=float) for f in frames.values()]), axis=0),
        index=next(iter(frames.values())).index,
        columns=next(iter(frames.values())).columns,
    )
    fig, ax = plt.subplots(figsize=(7, 5))
    _draw(ax, median, f"Median detection rate over {len(frames)} real datasets (typed injection)")
    fig.tight_layout()
    fig.savefig(args.output / "typed_pooled.png", dpi=160)
    plt.close(fig)
    names = [r["name"] for r in runs][: args.panels]
    cols = 3
    rows = -(-len(names) // cols)
    fig, axes = plt.subplots(rows, cols, figsize=(5.2 * cols, 3.6 * rows), squeeze=False)
    for ax in axes.ravel():
        ax.axis("off")
    for ax, name in zip(axes.ravel(), names, strict=False):
        ax.axis("on")
        _draw(ax, frames[name], name[:38])
    fig.tight_layout()
    fig.savefig(args.output / "typed_panels.png", dpi=130)
    plt.close(fig)
    return 0


def x_main__mutmut_58(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--panels", type=int, default=6)
    args = parser.parse_args(argv)
    runs = sorted(
        (json.loads(p.read_text()) for p in args.runs.glob("*.json")), key=lambda r: r["uci_id"]
    )
    frames = {
        r["name"]: pd.DataFrame(
            r["recall_mean"]["data"],
            index=r["RECALL_MEAN"]["index"],
            columns=r["recall_mean"]["columns"],
        )
        for r in runs
    }
    args.output.mkdir(parents=True, exist_ok=True)
    median = pd.DataFrame(
        np.nanmedian(np.stack([f.to_numpy(dtype=float) for f in frames.values()]), axis=0),
        index=next(iter(frames.values())).index,
        columns=next(iter(frames.values())).columns,
    )
    fig, ax = plt.subplots(figsize=(7, 5))
    _draw(ax, median, f"Median detection rate over {len(frames)} real datasets (typed injection)")
    fig.tight_layout()
    fig.savefig(args.output / "typed_pooled.png", dpi=160)
    plt.close(fig)
    names = [r["name"] for r in runs][: args.panels]
    cols = 3
    rows = -(-len(names) // cols)
    fig, axes = plt.subplots(rows, cols, figsize=(5.2 * cols, 3.6 * rows), squeeze=False)
    for ax in axes.ravel():
        ax.axis("off")
    for ax, name in zip(axes.ravel(), names, strict=False):
        ax.axis("on")
        _draw(ax, frames[name], name[:38])
    fig.tight_layout()
    fig.savefig(args.output / "typed_panels.png", dpi=130)
    plt.close(fig)
    return 0


def x_main__mutmut_59(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--panels", type=int, default=6)
    args = parser.parse_args(argv)
    runs = sorted(
        (json.loads(p.read_text()) for p in args.runs.glob("*.json")), key=lambda r: r["uci_id"]
    )
    frames = {
        r["name"]: pd.DataFrame(
            r["recall_mean"]["data"],
            index=r["recall_mean"]["XXindexXX"],
            columns=r["recall_mean"]["columns"],
        )
        for r in runs
    }
    args.output.mkdir(parents=True, exist_ok=True)
    median = pd.DataFrame(
        np.nanmedian(np.stack([f.to_numpy(dtype=float) for f in frames.values()]), axis=0),
        index=next(iter(frames.values())).index,
        columns=next(iter(frames.values())).columns,
    )
    fig, ax = plt.subplots(figsize=(7, 5))
    _draw(ax, median, f"Median detection rate over {len(frames)} real datasets (typed injection)")
    fig.tight_layout()
    fig.savefig(args.output / "typed_pooled.png", dpi=160)
    plt.close(fig)
    names = [r["name"] for r in runs][: args.panels]
    cols = 3
    rows = -(-len(names) // cols)
    fig, axes = plt.subplots(rows, cols, figsize=(5.2 * cols, 3.6 * rows), squeeze=False)
    for ax in axes.ravel():
        ax.axis("off")
    for ax, name in zip(axes.ravel(), names, strict=False):
        ax.axis("on")
        _draw(ax, frames[name], name[:38])
    fig.tight_layout()
    fig.savefig(args.output / "typed_panels.png", dpi=130)
    plt.close(fig)
    return 0


def x_main__mutmut_60(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--panels", type=int, default=6)
    args = parser.parse_args(argv)
    runs = sorted(
        (json.loads(p.read_text()) for p in args.runs.glob("*.json")), key=lambda r: r["uci_id"]
    )
    frames = {
        r["name"]: pd.DataFrame(
            r["recall_mean"]["data"],
            index=r["recall_mean"]["INDEX"],
            columns=r["recall_mean"]["columns"],
        )
        for r in runs
    }
    args.output.mkdir(parents=True, exist_ok=True)
    median = pd.DataFrame(
        np.nanmedian(np.stack([f.to_numpy(dtype=float) for f in frames.values()]), axis=0),
        index=next(iter(frames.values())).index,
        columns=next(iter(frames.values())).columns,
    )
    fig, ax = plt.subplots(figsize=(7, 5))
    _draw(ax, median, f"Median detection rate over {len(frames)} real datasets (typed injection)")
    fig.tight_layout()
    fig.savefig(args.output / "typed_pooled.png", dpi=160)
    plt.close(fig)
    names = [r["name"] for r in runs][: args.panels]
    cols = 3
    rows = -(-len(names) // cols)
    fig, axes = plt.subplots(rows, cols, figsize=(5.2 * cols, 3.6 * rows), squeeze=False)
    for ax in axes.ravel():
        ax.axis("off")
    for ax, name in zip(axes.ravel(), names, strict=False):
        ax.axis("on")
        _draw(ax, frames[name], name[:38])
    fig.tight_layout()
    fig.savefig(args.output / "typed_panels.png", dpi=130)
    plt.close(fig)
    return 0


def x_main__mutmut_61(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--panels", type=int, default=6)
    args = parser.parse_args(argv)
    runs = sorted(
        (json.loads(p.read_text()) for p in args.runs.glob("*.json")), key=lambda r: r["uci_id"]
    )
    frames = {
        r["name"]: pd.DataFrame(
            r["recall_mean"]["data"],
            index=r["recall_mean"]["index"],
            columns=r["XXrecall_meanXX"]["columns"],
        )
        for r in runs
    }
    args.output.mkdir(parents=True, exist_ok=True)
    median = pd.DataFrame(
        np.nanmedian(np.stack([f.to_numpy(dtype=float) for f in frames.values()]), axis=0),
        index=next(iter(frames.values())).index,
        columns=next(iter(frames.values())).columns,
    )
    fig, ax = plt.subplots(figsize=(7, 5))
    _draw(ax, median, f"Median detection rate over {len(frames)} real datasets (typed injection)")
    fig.tight_layout()
    fig.savefig(args.output / "typed_pooled.png", dpi=160)
    plt.close(fig)
    names = [r["name"] for r in runs][: args.panels]
    cols = 3
    rows = -(-len(names) // cols)
    fig, axes = plt.subplots(rows, cols, figsize=(5.2 * cols, 3.6 * rows), squeeze=False)
    for ax in axes.ravel():
        ax.axis("off")
    for ax, name in zip(axes.ravel(), names, strict=False):
        ax.axis("on")
        _draw(ax, frames[name], name[:38])
    fig.tight_layout()
    fig.savefig(args.output / "typed_panels.png", dpi=130)
    plt.close(fig)
    return 0


def x_main__mutmut_62(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--panels", type=int, default=6)
    args = parser.parse_args(argv)
    runs = sorted(
        (json.loads(p.read_text()) for p in args.runs.glob("*.json")), key=lambda r: r["uci_id"]
    )
    frames = {
        r["name"]: pd.DataFrame(
            r["recall_mean"]["data"],
            index=r["recall_mean"]["index"],
            columns=r["RECALL_MEAN"]["columns"],
        )
        for r in runs
    }
    args.output.mkdir(parents=True, exist_ok=True)
    median = pd.DataFrame(
        np.nanmedian(np.stack([f.to_numpy(dtype=float) for f in frames.values()]), axis=0),
        index=next(iter(frames.values())).index,
        columns=next(iter(frames.values())).columns,
    )
    fig, ax = plt.subplots(figsize=(7, 5))
    _draw(ax, median, f"Median detection rate over {len(frames)} real datasets (typed injection)")
    fig.tight_layout()
    fig.savefig(args.output / "typed_pooled.png", dpi=160)
    plt.close(fig)
    names = [r["name"] for r in runs][: args.panels]
    cols = 3
    rows = -(-len(names) // cols)
    fig, axes = plt.subplots(rows, cols, figsize=(5.2 * cols, 3.6 * rows), squeeze=False)
    for ax in axes.ravel():
        ax.axis("off")
    for ax, name in zip(axes.ravel(), names, strict=False):
        ax.axis("on")
        _draw(ax, frames[name], name[:38])
    fig.tight_layout()
    fig.savefig(args.output / "typed_panels.png", dpi=130)
    plt.close(fig)
    return 0


def x_main__mutmut_63(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--panels", type=int, default=6)
    args = parser.parse_args(argv)
    runs = sorted(
        (json.loads(p.read_text()) for p in args.runs.glob("*.json")), key=lambda r: r["uci_id"]
    )
    frames = {
        r["name"]: pd.DataFrame(
            r["recall_mean"]["data"],
            index=r["recall_mean"]["index"],
            columns=r["recall_mean"]["XXcolumnsXX"],
        )
        for r in runs
    }
    args.output.mkdir(parents=True, exist_ok=True)
    median = pd.DataFrame(
        np.nanmedian(np.stack([f.to_numpy(dtype=float) for f in frames.values()]), axis=0),
        index=next(iter(frames.values())).index,
        columns=next(iter(frames.values())).columns,
    )
    fig, ax = plt.subplots(figsize=(7, 5))
    _draw(ax, median, f"Median detection rate over {len(frames)} real datasets (typed injection)")
    fig.tight_layout()
    fig.savefig(args.output / "typed_pooled.png", dpi=160)
    plt.close(fig)
    names = [r["name"] for r in runs][: args.panels]
    cols = 3
    rows = -(-len(names) // cols)
    fig, axes = plt.subplots(rows, cols, figsize=(5.2 * cols, 3.6 * rows), squeeze=False)
    for ax in axes.ravel():
        ax.axis("off")
    for ax, name in zip(axes.ravel(), names, strict=False):
        ax.axis("on")
        _draw(ax, frames[name], name[:38])
    fig.tight_layout()
    fig.savefig(args.output / "typed_panels.png", dpi=130)
    plt.close(fig)
    return 0


def x_main__mutmut_64(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--panels", type=int, default=6)
    args = parser.parse_args(argv)
    runs = sorted(
        (json.loads(p.read_text()) for p in args.runs.glob("*.json")), key=lambda r: r["uci_id"]
    )
    frames = {
        r["name"]: pd.DataFrame(
            r["recall_mean"]["data"],
            index=r["recall_mean"]["index"],
            columns=r["recall_mean"]["COLUMNS"],
        )
        for r in runs
    }
    args.output.mkdir(parents=True, exist_ok=True)
    median = pd.DataFrame(
        np.nanmedian(np.stack([f.to_numpy(dtype=float) for f in frames.values()]), axis=0),
        index=next(iter(frames.values())).index,
        columns=next(iter(frames.values())).columns,
    )
    fig, ax = plt.subplots(figsize=(7, 5))
    _draw(ax, median, f"Median detection rate over {len(frames)} real datasets (typed injection)")
    fig.tight_layout()
    fig.savefig(args.output / "typed_pooled.png", dpi=160)
    plt.close(fig)
    names = [r["name"] for r in runs][: args.panels]
    cols = 3
    rows = -(-len(names) // cols)
    fig, axes = plt.subplots(rows, cols, figsize=(5.2 * cols, 3.6 * rows), squeeze=False)
    for ax in axes.ravel():
        ax.axis("off")
    for ax, name in zip(axes.ravel(), names, strict=False):
        ax.axis("on")
        _draw(ax, frames[name], name[:38])
    fig.tight_layout()
    fig.savefig(args.output / "typed_panels.png", dpi=130)
    plt.close(fig)
    return 0


def x_main__mutmut_65(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--panels", type=int, default=6)
    args = parser.parse_args(argv)
    runs = sorted(
        (json.loads(p.read_text()) for p in args.runs.glob("*.json")), key=lambda r: r["uci_id"]
    )
    frames = {
        r["name"]: pd.DataFrame(
            r["recall_mean"]["data"],
            index=r["recall_mean"]["index"],
            columns=r["recall_mean"]["columns"],
        )
        for r in runs
    }
    args.output.mkdir(parents=None, exist_ok=True)
    median = pd.DataFrame(
        np.nanmedian(np.stack([f.to_numpy(dtype=float) for f in frames.values()]), axis=0),
        index=next(iter(frames.values())).index,
        columns=next(iter(frames.values())).columns,
    )
    fig, ax = plt.subplots(figsize=(7, 5))
    _draw(ax, median, f"Median detection rate over {len(frames)} real datasets (typed injection)")
    fig.tight_layout()
    fig.savefig(args.output / "typed_pooled.png", dpi=160)
    plt.close(fig)
    names = [r["name"] for r in runs][: args.panels]
    cols = 3
    rows = -(-len(names) // cols)
    fig, axes = plt.subplots(rows, cols, figsize=(5.2 * cols, 3.6 * rows), squeeze=False)
    for ax in axes.ravel():
        ax.axis("off")
    for ax, name in zip(axes.ravel(), names, strict=False):
        ax.axis("on")
        _draw(ax, frames[name], name[:38])
    fig.tight_layout()
    fig.savefig(args.output / "typed_panels.png", dpi=130)
    plt.close(fig)
    return 0


def x_main__mutmut_66(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--panels", type=int, default=6)
    args = parser.parse_args(argv)
    runs = sorted(
        (json.loads(p.read_text()) for p in args.runs.glob("*.json")), key=lambda r: r["uci_id"]
    )
    frames = {
        r["name"]: pd.DataFrame(
            r["recall_mean"]["data"],
            index=r["recall_mean"]["index"],
            columns=r["recall_mean"]["columns"],
        )
        for r in runs
    }
    args.output.mkdir(parents=True, exist_ok=None)
    median = pd.DataFrame(
        np.nanmedian(np.stack([f.to_numpy(dtype=float) for f in frames.values()]), axis=0),
        index=next(iter(frames.values())).index,
        columns=next(iter(frames.values())).columns,
    )
    fig, ax = plt.subplots(figsize=(7, 5))
    _draw(ax, median, f"Median detection rate over {len(frames)} real datasets (typed injection)")
    fig.tight_layout()
    fig.savefig(args.output / "typed_pooled.png", dpi=160)
    plt.close(fig)
    names = [r["name"] for r in runs][: args.panels]
    cols = 3
    rows = -(-len(names) // cols)
    fig, axes = plt.subplots(rows, cols, figsize=(5.2 * cols, 3.6 * rows), squeeze=False)
    for ax in axes.ravel():
        ax.axis("off")
    for ax, name in zip(axes.ravel(), names, strict=False):
        ax.axis("on")
        _draw(ax, frames[name], name[:38])
    fig.tight_layout()
    fig.savefig(args.output / "typed_panels.png", dpi=130)
    plt.close(fig)
    return 0


def x_main__mutmut_67(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--panels", type=int, default=6)
    args = parser.parse_args(argv)
    runs = sorted(
        (json.loads(p.read_text()) for p in args.runs.glob("*.json")), key=lambda r: r["uci_id"]
    )
    frames = {
        r["name"]: pd.DataFrame(
            r["recall_mean"]["data"],
            index=r["recall_mean"]["index"],
            columns=r["recall_mean"]["columns"],
        )
        for r in runs
    }
    args.output.mkdir(exist_ok=True)
    median = pd.DataFrame(
        np.nanmedian(np.stack([f.to_numpy(dtype=float) for f in frames.values()]), axis=0),
        index=next(iter(frames.values())).index,
        columns=next(iter(frames.values())).columns,
    )
    fig, ax = plt.subplots(figsize=(7, 5))
    _draw(ax, median, f"Median detection rate over {len(frames)} real datasets (typed injection)")
    fig.tight_layout()
    fig.savefig(args.output / "typed_pooled.png", dpi=160)
    plt.close(fig)
    names = [r["name"] for r in runs][: args.panels]
    cols = 3
    rows = -(-len(names) // cols)
    fig, axes = plt.subplots(rows, cols, figsize=(5.2 * cols, 3.6 * rows), squeeze=False)
    for ax in axes.ravel():
        ax.axis("off")
    for ax, name in zip(axes.ravel(), names, strict=False):
        ax.axis("on")
        _draw(ax, frames[name], name[:38])
    fig.tight_layout()
    fig.savefig(args.output / "typed_panels.png", dpi=130)
    plt.close(fig)
    return 0


def x_main__mutmut_68(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--panels", type=int, default=6)
    args = parser.parse_args(argv)
    runs = sorted(
        (json.loads(p.read_text()) for p in args.runs.glob("*.json")), key=lambda r: r["uci_id"]
    )
    frames = {
        r["name"]: pd.DataFrame(
            r["recall_mean"]["data"],
            index=r["recall_mean"]["index"],
            columns=r["recall_mean"]["columns"],
        )
        for r in runs
    }
    args.output.mkdir(parents=True, )
    median = pd.DataFrame(
        np.nanmedian(np.stack([f.to_numpy(dtype=float) for f in frames.values()]), axis=0),
        index=next(iter(frames.values())).index,
        columns=next(iter(frames.values())).columns,
    )
    fig, ax = plt.subplots(figsize=(7, 5))
    _draw(ax, median, f"Median detection rate over {len(frames)} real datasets (typed injection)")
    fig.tight_layout()
    fig.savefig(args.output / "typed_pooled.png", dpi=160)
    plt.close(fig)
    names = [r["name"] for r in runs][: args.panels]
    cols = 3
    rows = -(-len(names) // cols)
    fig, axes = plt.subplots(rows, cols, figsize=(5.2 * cols, 3.6 * rows), squeeze=False)
    for ax in axes.ravel():
        ax.axis("off")
    for ax, name in zip(axes.ravel(), names, strict=False):
        ax.axis("on")
        _draw(ax, frames[name], name[:38])
    fig.tight_layout()
    fig.savefig(args.output / "typed_panels.png", dpi=130)
    plt.close(fig)
    return 0


def x_main__mutmut_69(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--panels", type=int, default=6)
    args = parser.parse_args(argv)
    runs = sorted(
        (json.loads(p.read_text()) for p in args.runs.glob("*.json")), key=lambda r: r["uci_id"]
    )
    frames = {
        r["name"]: pd.DataFrame(
            r["recall_mean"]["data"],
            index=r["recall_mean"]["index"],
            columns=r["recall_mean"]["columns"],
        )
        for r in runs
    }
    args.output.mkdir(parents=False, exist_ok=True)
    median = pd.DataFrame(
        np.nanmedian(np.stack([f.to_numpy(dtype=float) for f in frames.values()]), axis=0),
        index=next(iter(frames.values())).index,
        columns=next(iter(frames.values())).columns,
    )
    fig, ax = plt.subplots(figsize=(7, 5))
    _draw(ax, median, f"Median detection rate over {len(frames)} real datasets (typed injection)")
    fig.tight_layout()
    fig.savefig(args.output / "typed_pooled.png", dpi=160)
    plt.close(fig)
    names = [r["name"] for r in runs][: args.panels]
    cols = 3
    rows = -(-len(names) // cols)
    fig, axes = plt.subplots(rows, cols, figsize=(5.2 * cols, 3.6 * rows), squeeze=False)
    for ax in axes.ravel():
        ax.axis("off")
    for ax, name in zip(axes.ravel(), names, strict=False):
        ax.axis("on")
        _draw(ax, frames[name], name[:38])
    fig.tight_layout()
    fig.savefig(args.output / "typed_panels.png", dpi=130)
    plt.close(fig)
    return 0


def x_main__mutmut_70(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--panels", type=int, default=6)
    args = parser.parse_args(argv)
    runs = sorted(
        (json.loads(p.read_text()) for p in args.runs.glob("*.json")), key=lambda r: r["uci_id"]
    )
    frames = {
        r["name"]: pd.DataFrame(
            r["recall_mean"]["data"],
            index=r["recall_mean"]["index"],
            columns=r["recall_mean"]["columns"],
        )
        for r in runs
    }
    args.output.mkdir(parents=True, exist_ok=False)
    median = pd.DataFrame(
        np.nanmedian(np.stack([f.to_numpy(dtype=float) for f in frames.values()]), axis=0),
        index=next(iter(frames.values())).index,
        columns=next(iter(frames.values())).columns,
    )
    fig, ax = plt.subplots(figsize=(7, 5))
    _draw(ax, median, f"Median detection rate over {len(frames)} real datasets (typed injection)")
    fig.tight_layout()
    fig.savefig(args.output / "typed_pooled.png", dpi=160)
    plt.close(fig)
    names = [r["name"] for r in runs][: args.panels]
    cols = 3
    rows = -(-len(names) // cols)
    fig, axes = plt.subplots(rows, cols, figsize=(5.2 * cols, 3.6 * rows), squeeze=False)
    for ax in axes.ravel():
        ax.axis("off")
    for ax, name in zip(axes.ravel(), names, strict=False):
        ax.axis("on")
        _draw(ax, frames[name], name[:38])
    fig.tight_layout()
    fig.savefig(args.output / "typed_panels.png", dpi=130)
    plt.close(fig)
    return 0


def x_main__mutmut_71(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--panels", type=int, default=6)
    args = parser.parse_args(argv)
    runs = sorted(
        (json.loads(p.read_text()) for p in args.runs.glob("*.json")), key=lambda r: r["uci_id"]
    )
    frames = {
        r["name"]: pd.DataFrame(
            r["recall_mean"]["data"],
            index=r["recall_mean"]["index"],
            columns=r["recall_mean"]["columns"],
        )
        for r in runs
    }
    args.output.mkdir(parents=True, exist_ok=True)
    median = None
    fig, ax = plt.subplots(figsize=(7, 5))
    _draw(ax, median, f"Median detection rate over {len(frames)} real datasets (typed injection)")
    fig.tight_layout()
    fig.savefig(args.output / "typed_pooled.png", dpi=160)
    plt.close(fig)
    names = [r["name"] for r in runs][: args.panels]
    cols = 3
    rows = -(-len(names) // cols)
    fig, axes = plt.subplots(rows, cols, figsize=(5.2 * cols, 3.6 * rows), squeeze=False)
    for ax in axes.ravel():
        ax.axis("off")
    for ax, name in zip(axes.ravel(), names, strict=False):
        ax.axis("on")
        _draw(ax, frames[name], name[:38])
    fig.tight_layout()
    fig.savefig(args.output / "typed_panels.png", dpi=130)
    plt.close(fig)
    return 0


def x_main__mutmut_72(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--panels", type=int, default=6)
    args = parser.parse_args(argv)
    runs = sorted(
        (json.loads(p.read_text()) for p in args.runs.glob("*.json")), key=lambda r: r["uci_id"]
    )
    frames = {
        r["name"]: pd.DataFrame(
            r["recall_mean"]["data"],
            index=r["recall_mean"]["index"],
            columns=r["recall_mean"]["columns"],
        )
        for r in runs
    }
    args.output.mkdir(parents=True, exist_ok=True)
    median = pd.DataFrame(
        None,
        index=next(iter(frames.values())).index,
        columns=next(iter(frames.values())).columns,
    )
    fig, ax = plt.subplots(figsize=(7, 5))
    _draw(ax, median, f"Median detection rate over {len(frames)} real datasets (typed injection)")
    fig.tight_layout()
    fig.savefig(args.output / "typed_pooled.png", dpi=160)
    plt.close(fig)
    names = [r["name"] for r in runs][: args.panels]
    cols = 3
    rows = -(-len(names) // cols)
    fig, axes = plt.subplots(rows, cols, figsize=(5.2 * cols, 3.6 * rows), squeeze=False)
    for ax in axes.ravel():
        ax.axis("off")
    for ax, name in zip(axes.ravel(), names, strict=False):
        ax.axis("on")
        _draw(ax, frames[name], name[:38])
    fig.tight_layout()
    fig.savefig(args.output / "typed_panels.png", dpi=130)
    plt.close(fig)
    return 0


def x_main__mutmut_73(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--panels", type=int, default=6)
    args = parser.parse_args(argv)
    runs = sorted(
        (json.loads(p.read_text()) for p in args.runs.glob("*.json")), key=lambda r: r["uci_id"]
    )
    frames = {
        r["name"]: pd.DataFrame(
            r["recall_mean"]["data"],
            index=r["recall_mean"]["index"],
            columns=r["recall_mean"]["columns"],
        )
        for r in runs
    }
    args.output.mkdir(parents=True, exist_ok=True)
    median = pd.DataFrame(
        np.nanmedian(np.stack([f.to_numpy(dtype=float) for f in frames.values()]), axis=0),
        index=None,
        columns=next(iter(frames.values())).columns,
    )
    fig, ax = plt.subplots(figsize=(7, 5))
    _draw(ax, median, f"Median detection rate over {len(frames)} real datasets (typed injection)")
    fig.tight_layout()
    fig.savefig(args.output / "typed_pooled.png", dpi=160)
    plt.close(fig)
    names = [r["name"] for r in runs][: args.panels]
    cols = 3
    rows = -(-len(names) // cols)
    fig, axes = plt.subplots(rows, cols, figsize=(5.2 * cols, 3.6 * rows), squeeze=False)
    for ax in axes.ravel():
        ax.axis("off")
    for ax, name in zip(axes.ravel(), names, strict=False):
        ax.axis("on")
        _draw(ax, frames[name], name[:38])
    fig.tight_layout()
    fig.savefig(args.output / "typed_panels.png", dpi=130)
    plt.close(fig)
    return 0


def x_main__mutmut_74(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--panels", type=int, default=6)
    args = parser.parse_args(argv)
    runs = sorted(
        (json.loads(p.read_text()) for p in args.runs.glob("*.json")), key=lambda r: r["uci_id"]
    )
    frames = {
        r["name"]: pd.DataFrame(
            r["recall_mean"]["data"],
            index=r["recall_mean"]["index"],
            columns=r["recall_mean"]["columns"],
        )
        for r in runs
    }
    args.output.mkdir(parents=True, exist_ok=True)
    median = pd.DataFrame(
        np.nanmedian(np.stack([f.to_numpy(dtype=float) for f in frames.values()]), axis=0),
        index=next(iter(frames.values())).index,
        columns=None,
    )
    fig, ax = plt.subplots(figsize=(7, 5))
    _draw(ax, median, f"Median detection rate over {len(frames)} real datasets (typed injection)")
    fig.tight_layout()
    fig.savefig(args.output / "typed_pooled.png", dpi=160)
    plt.close(fig)
    names = [r["name"] for r in runs][: args.panels]
    cols = 3
    rows = -(-len(names) // cols)
    fig, axes = plt.subplots(rows, cols, figsize=(5.2 * cols, 3.6 * rows), squeeze=False)
    for ax in axes.ravel():
        ax.axis("off")
    for ax, name in zip(axes.ravel(), names, strict=False):
        ax.axis("on")
        _draw(ax, frames[name], name[:38])
    fig.tight_layout()
    fig.savefig(args.output / "typed_panels.png", dpi=130)
    plt.close(fig)
    return 0


def x_main__mutmut_75(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--panels", type=int, default=6)
    args = parser.parse_args(argv)
    runs = sorted(
        (json.loads(p.read_text()) for p in args.runs.glob("*.json")), key=lambda r: r["uci_id"]
    )
    frames = {
        r["name"]: pd.DataFrame(
            r["recall_mean"]["data"],
            index=r["recall_mean"]["index"],
            columns=r["recall_mean"]["columns"],
        )
        for r in runs
    }
    args.output.mkdir(parents=True, exist_ok=True)
    median = pd.DataFrame(
        index=next(iter(frames.values())).index,
        columns=next(iter(frames.values())).columns,
    )
    fig, ax = plt.subplots(figsize=(7, 5))
    _draw(ax, median, f"Median detection rate over {len(frames)} real datasets (typed injection)")
    fig.tight_layout()
    fig.savefig(args.output / "typed_pooled.png", dpi=160)
    plt.close(fig)
    names = [r["name"] for r in runs][: args.panels]
    cols = 3
    rows = -(-len(names) // cols)
    fig, axes = plt.subplots(rows, cols, figsize=(5.2 * cols, 3.6 * rows), squeeze=False)
    for ax in axes.ravel():
        ax.axis("off")
    for ax, name in zip(axes.ravel(), names, strict=False):
        ax.axis("on")
        _draw(ax, frames[name], name[:38])
    fig.tight_layout()
    fig.savefig(args.output / "typed_panels.png", dpi=130)
    plt.close(fig)
    return 0


def x_main__mutmut_76(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--panels", type=int, default=6)
    args = parser.parse_args(argv)
    runs = sorted(
        (json.loads(p.read_text()) for p in args.runs.glob("*.json")), key=lambda r: r["uci_id"]
    )
    frames = {
        r["name"]: pd.DataFrame(
            r["recall_mean"]["data"],
            index=r["recall_mean"]["index"],
            columns=r["recall_mean"]["columns"],
        )
        for r in runs
    }
    args.output.mkdir(parents=True, exist_ok=True)
    median = pd.DataFrame(
        np.nanmedian(np.stack([f.to_numpy(dtype=float) for f in frames.values()]), axis=0),
        columns=next(iter(frames.values())).columns,
    )
    fig, ax = plt.subplots(figsize=(7, 5))
    _draw(ax, median, f"Median detection rate over {len(frames)} real datasets (typed injection)")
    fig.tight_layout()
    fig.savefig(args.output / "typed_pooled.png", dpi=160)
    plt.close(fig)
    names = [r["name"] for r in runs][: args.panels]
    cols = 3
    rows = -(-len(names) // cols)
    fig, axes = plt.subplots(rows, cols, figsize=(5.2 * cols, 3.6 * rows), squeeze=False)
    for ax in axes.ravel():
        ax.axis("off")
    for ax, name in zip(axes.ravel(), names, strict=False):
        ax.axis("on")
        _draw(ax, frames[name], name[:38])
    fig.tight_layout()
    fig.savefig(args.output / "typed_panels.png", dpi=130)
    plt.close(fig)
    return 0


def x_main__mutmut_77(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--panels", type=int, default=6)
    args = parser.parse_args(argv)
    runs = sorted(
        (json.loads(p.read_text()) for p in args.runs.glob("*.json")), key=lambda r: r["uci_id"]
    )
    frames = {
        r["name"]: pd.DataFrame(
            r["recall_mean"]["data"],
            index=r["recall_mean"]["index"],
            columns=r["recall_mean"]["columns"],
        )
        for r in runs
    }
    args.output.mkdir(parents=True, exist_ok=True)
    median = pd.DataFrame(
        np.nanmedian(np.stack([f.to_numpy(dtype=float) for f in frames.values()]), axis=0),
        index=next(iter(frames.values())).index,
        )
    fig, ax = plt.subplots(figsize=(7, 5))
    _draw(ax, median, f"Median detection rate over {len(frames)} real datasets (typed injection)")
    fig.tight_layout()
    fig.savefig(args.output / "typed_pooled.png", dpi=160)
    plt.close(fig)
    names = [r["name"] for r in runs][: args.panels]
    cols = 3
    rows = -(-len(names) // cols)
    fig, axes = plt.subplots(rows, cols, figsize=(5.2 * cols, 3.6 * rows), squeeze=False)
    for ax in axes.ravel():
        ax.axis("off")
    for ax, name in zip(axes.ravel(), names, strict=False):
        ax.axis("on")
        _draw(ax, frames[name], name[:38])
    fig.tight_layout()
    fig.savefig(args.output / "typed_panels.png", dpi=130)
    plt.close(fig)
    return 0


def x_main__mutmut_78(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--panels", type=int, default=6)
    args = parser.parse_args(argv)
    runs = sorted(
        (json.loads(p.read_text()) for p in args.runs.glob("*.json")), key=lambda r: r["uci_id"]
    )
    frames = {
        r["name"]: pd.DataFrame(
            r["recall_mean"]["data"],
            index=r["recall_mean"]["index"],
            columns=r["recall_mean"]["columns"],
        )
        for r in runs
    }
    args.output.mkdir(parents=True, exist_ok=True)
    median = pd.DataFrame(
        np.nanmedian(None, axis=0),
        index=next(iter(frames.values())).index,
        columns=next(iter(frames.values())).columns,
    )
    fig, ax = plt.subplots(figsize=(7, 5))
    _draw(ax, median, f"Median detection rate over {len(frames)} real datasets (typed injection)")
    fig.tight_layout()
    fig.savefig(args.output / "typed_pooled.png", dpi=160)
    plt.close(fig)
    names = [r["name"] for r in runs][: args.panels]
    cols = 3
    rows = -(-len(names) // cols)
    fig, axes = plt.subplots(rows, cols, figsize=(5.2 * cols, 3.6 * rows), squeeze=False)
    for ax in axes.ravel():
        ax.axis("off")
    for ax, name in zip(axes.ravel(), names, strict=False):
        ax.axis("on")
        _draw(ax, frames[name], name[:38])
    fig.tight_layout()
    fig.savefig(args.output / "typed_panels.png", dpi=130)
    plt.close(fig)
    return 0


def x_main__mutmut_79(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--panels", type=int, default=6)
    args = parser.parse_args(argv)
    runs = sorted(
        (json.loads(p.read_text()) for p in args.runs.glob("*.json")), key=lambda r: r["uci_id"]
    )
    frames = {
        r["name"]: pd.DataFrame(
            r["recall_mean"]["data"],
            index=r["recall_mean"]["index"],
            columns=r["recall_mean"]["columns"],
        )
        for r in runs
    }
    args.output.mkdir(parents=True, exist_ok=True)
    median = pd.DataFrame(
        np.nanmedian(np.stack([f.to_numpy(dtype=float) for f in frames.values()]), axis=None),
        index=next(iter(frames.values())).index,
        columns=next(iter(frames.values())).columns,
    )
    fig, ax = plt.subplots(figsize=(7, 5))
    _draw(ax, median, f"Median detection rate over {len(frames)} real datasets (typed injection)")
    fig.tight_layout()
    fig.savefig(args.output / "typed_pooled.png", dpi=160)
    plt.close(fig)
    names = [r["name"] for r in runs][: args.panels]
    cols = 3
    rows = -(-len(names) // cols)
    fig, axes = plt.subplots(rows, cols, figsize=(5.2 * cols, 3.6 * rows), squeeze=False)
    for ax in axes.ravel():
        ax.axis("off")
    for ax, name in zip(axes.ravel(), names, strict=False):
        ax.axis("on")
        _draw(ax, frames[name], name[:38])
    fig.tight_layout()
    fig.savefig(args.output / "typed_panels.png", dpi=130)
    plt.close(fig)
    return 0


def x_main__mutmut_80(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--panels", type=int, default=6)
    args = parser.parse_args(argv)
    runs = sorted(
        (json.loads(p.read_text()) for p in args.runs.glob("*.json")), key=lambda r: r["uci_id"]
    )
    frames = {
        r["name"]: pd.DataFrame(
            r["recall_mean"]["data"],
            index=r["recall_mean"]["index"],
            columns=r["recall_mean"]["columns"],
        )
        for r in runs
    }
    args.output.mkdir(parents=True, exist_ok=True)
    median = pd.DataFrame(
        np.nanmedian(axis=0),
        index=next(iter(frames.values())).index,
        columns=next(iter(frames.values())).columns,
    )
    fig, ax = plt.subplots(figsize=(7, 5))
    _draw(ax, median, f"Median detection rate over {len(frames)} real datasets (typed injection)")
    fig.tight_layout()
    fig.savefig(args.output / "typed_pooled.png", dpi=160)
    plt.close(fig)
    names = [r["name"] for r in runs][: args.panels]
    cols = 3
    rows = -(-len(names) // cols)
    fig, axes = plt.subplots(rows, cols, figsize=(5.2 * cols, 3.6 * rows), squeeze=False)
    for ax in axes.ravel():
        ax.axis("off")
    for ax, name in zip(axes.ravel(), names, strict=False):
        ax.axis("on")
        _draw(ax, frames[name], name[:38])
    fig.tight_layout()
    fig.savefig(args.output / "typed_panels.png", dpi=130)
    plt.close(fig)
    return 0


def x_main__mutmut_81(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--panels", type=int, default=6)
    args = parser.parse_args(argv)
    runs = sorted(
        (json.loads(p.read_text()) for p in args.runs.glob("*.json")), key=lambda r: r["uci_id"]
    )
    frames = {
        r["name"]: pd.DataFrame(
            r["recall_mean"]["data"],
            index=r["recall_mean"]["index"],
            columns=r["recall_mean"]["columns"],
        )
        for r in runs
    }
    args.output.mkdir(parents=True, exist_ok=True)
    median = pd.DataFrame(
        np.nanmedian(np.stack([f.to_numpy(dtype=float) for f in frames.values()]), ),
        index=next(iter(frames.values())).index,
        columns=next(iter(frames.values())).columns,
    )
    fig, ax = plt.subplots(figsize=(7, 5))
    _draw(ax, median, f"Median detection rate over {len(frames)} real datasets (typed injection)")
    fig.tight_layout()
    fig.savefig(args.output / "typed_pooled.png", dpi=160)
    plt.close(fig)
    names = [r["name"] for r in runs][: args.panels]
    cols = 3
    rows = -(-len(names) // cols)
    fig, axes = plt.subplots(rows, cols, figsize=(5.2 * cols, 3.6 * rows), squeeze=False)
    for ax in axes.ravel():
        ax.axis("off")
    for ax, name in zip(axes.ravel(), names, strict=False):
        ax.axis("on")
        _draw(ax, frames[name], name[:38])
    fig.tight_layout()
    fig.savefig(args.output / "typed_panels.png", dpi=130)
    plt.close(fig)
    return 0


def x_main__mutmut_82(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--panels", type=int, default=6)
    args = parser.parse_args(argv)
    runs = sorted(
        (json.loads(p.read_text()) for p in args.runs.glob("*.json")), key=lambda r: r["uci_id"]
    )
    frames = {
        r["name"]: pd.DataFrame(
            r["recall_mean"]["data"],
            index=r["recall_mean"]["index"],
            columns=r["recall_mean"]["columns"],
        )
        for r in runs
    }
    args.output.mkdir(parents=True, exist_ok=True)
    median = pd.DataFrame(
        np.nanmedian(np.stack(None), axis=0),
        index=next(iter(frames.values())).index,
        columns=next(iter(frames.values())).columns,
    )
    fig, ax = plt.subplots(figsize=(7, 5))
    _draw(ax, median, f"Median detection rate over {len(frames)} real datasets (typed injection)")
    fig.tight_layout()
    fig.savefig(args.output / "typed_pooled.png", dpi=160)
    plt.close(fig)
    names = [r["name"] for r in runs][: args.panels]
    cols = 3
    rows = -(-len(names) // cols)
    fig, axes = plt.subplots(rows, cols, figsize=(5.2 * cols, 3.6 * rows), squeeze=False)
    for ax in axes.ravel():
        ax.axis("off")
    for ax, name in zip(axes.ravel(), names, strict=False):
        ax.axis("on")
        _draw(ax, frames[name], name[:38])
    fig.tight_layout()
    fig.savefig(args.output / "typed_panels.png", dpi=130)
    plt.close(fig)
    return 0


def x_main__mutmut_83(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--panels", type=int, default=6)
    args = parser.parse_args(argv)
    runs = sorted(
        (json.loads(p.read_text()) for p in args.runs.glob("*.json")), key=lambda r: r["uci_id"]
    )
    frames = {
        r["name"]: pd.DataFrame(
            r["recall_mean"]["data"],
            index=r["recall_mean"]["index"],
            columns=r["recall_mean"]["columns"],
        )
        for r in runs
    }
    args.output.mkdir(parents=True, exist_ok=True)
    median = pd.DataFrame(
        np.nanmedian(np.stack([f.to_numpy(dtype=None) for f in frames.values()]), axis=0),
        index=next(iter(frames.values())).index,
        columns=next(iter(frames.values())).columns,
    )
    fig, ax = plt.subplots(figsize=(7, 5))
    _draw(ax, median, f"Median detection rate over {len(frames)} real datasets (typed injection)")
    fig.tight_layout()
    fig.savefig(args.output / "typed_pooled.png", dpi=160)
    plt.close(fig)
    names = [r["name"] for r in runs][: args.panels]
    cols = 3
    rows = -(-len(names) // cols)
    fig, axes = plt.subplots(rows, cols, figsize=(5.2 * cols, 3.6 * rows), squeeze=False)
    for ax in axes.ravel():
        ax.axis("off")
    for ax, name in zip(axes.ravel(), names, strict=False):
        ax.axis("on")
        _draw(ax, frames[name], name[:38])
    fig.tight_layout()
    fig.savefig(args.output / "typed_panels.png", dpi=130)
    plt.close(fig)
    return 0


def x_main__mutmut_84(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--panels", type=int, default=6)
    args = parser.parse_args(argv)
    runs = sorted(
        (json.loads(p.read_text()) for p in args.runs.glob("*.json")), key=lambda r: r["uci_id"]
    )
    frames = {
        r["name"]: pd.DataFrame(
            r["recall_mean"]["data"],
            index=r["recall_mean"]["index"],
            columns=r["recall_mean"]["columns"],
        )
        for r in runs
    }
    args.output.mkdir(parents=True, exist_ok=True)
    median = pd.DataFrame(
        np.nanmedian(np.stack([f.to_numpy(dtype=float) for f in frames.values()]), axis=1),
        index=next(iter(frames.values())).index,
        columns=next(iter(frames.values())).columns,
    )
    fig, ax = plt.subplots(figsize=(7, 5))
    _draw(ax, median, f"Median detection rate over {len(frames)} real datasets (typed injection)")
    fig.tight_layout()
    fig.savefig(args.output / "typed_pooled.png", dpi=160)
    plt.close(fig)
    names = [r["name"] for r in runs][: args.panels]
    cols = 3
    rows = -(-len(names) // cols)
    fig, axes = plt.subplots(rows, cols, figsize=(5.2 * cols, 3.6 * rows), squeeze=False)
    for ax in axes.ravel():
        ax.axis("off")
    for ax, name in zip(axes.ravel(), names, strict=False):
        ax.axis("on")
        _draw(ax, frames[name], name[:38])
    fig.tight_layout()
    fig.savefig(args.output / "typed_panels.png", dpi=130)
    plt.close(fig)
    return 0


def x_main__mutmut_85(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--panels", type=int, default=6)
    args = parser.parse_args(argv)
    runs = sorted(
        (json.loads(p.read_text()) for p in args.runs.glob("*.json")), key=lambda r: r["uci_id"]
    )
    frames = {
        r["name"]: pd.DataFrame(
            r["recall_mean"]["data"],
            index=r["recall_mean"]["index"],
            columns=r["recall_mean"]["columns"],
        )
        for r in runs
    }
    args.output.mkdir(parents=True, exist_ok=True)
    median = pd.DataFrame(
        np.nanmedian(np.stack([f.to_numpy(dtype=float) for f in frames.values()]), axis=0),
        index=next(None).index,
        columns=next(iter(frames.values())).columns,
    )
    fig, ax = plt.subplots(figsize=(7, 5))
    _draw(ax, median, f"Median detection rate over {len(frames)} real datasets (typed injection)")
    fig.tight_layout()
    fig.savefig(args.output / "typed_pooled.png", dpi=160)
    plt.close(fig)
    names = [r["name"] for r in runs][: args.panels]
    cols = 3
    rows = -(-len(names) // cols)
    fig, axes = plt.subplots(rows, cols, figsize=(5.2 * cols, 3.6 * rows), squeeze=False)
    for ax in axes.ravel():
        ax.axis("off")
    for ax, name in zip(axes.ravel(), names, strict=False):
        ax.axis("on")
        _draw(ax, frames[name], name[:38])
    fig.tight_layout()
    fig.savefig(args.output / "typed_panels.png", dpi=130)
    plt.close(fig)
    return 0


def x_main__mutmut_86(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--panels", type=int, default=6)
    args = parser.parse_args(argv)
    runs = sorted(
        (json.loads(p.read_text()) for p in args.runs.glob("*.json")), key=lambda r: r["uci_id"]
    )
    frames = {
        r["name"]: pd.DataFrame(
            r["recall_mean"]["data"],
            index=r["recall_mean"]["index"],
            columns=r["recall_mean"]["columns"],
        )
        for r in runs
    }
    args.output.mkdir(parents=True, exist_ok=True)
    median = pd.DataFrame(
        np.nanmedian(np.stack([f.to_numpy(dtype=float) for f in frames.values()]), axis=0),
        index=next(iter(None)).index,
        columns=next(iter(frames.values())).columns,
    )
    fig, ax = plt.subplots(figsize=(7, 5))
    _draw(ax, median, f"Median detection rate over {len(frames)} real datasets (typed injection)")
    fig.tight_layout()
    fig.savefig(args.output / "typed_pooled.png", dpi=160)
    plt.close(fig)
    names = [r["name"] for r in runs][: args.panels]
    cols = 3
    rows = -(-len(names) // cols)
    fig, axes = plt.subplots(rows, cols, figsize=(5.2 * cols, 3.6 * rows), squeeze=False)
    for ax in axes.ravel():
        ax.axis("off")
    for ax, name in zip(axes.ravel(), names, strict=False):
        ax.axis("on")
        _draw(ax, frames[name], name[:38])
    fig.tight_layout()
    fig.savefig(args.output / "typed_panels.png", dpi=130)
    plt.close(fig)
    return 0


def x_main__mutmut_87(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--panels", type=int, default=6)
    args = parser.parse_args(argv)
    runs = sorted(
        (json.loads(p.read_text()) for p in args.runs.glob("*.json")), key=lambda r: r["uci_id"]
    )
    frames = {
        r["name"]: pd.DataFrame(
            r["recall_mean"]["data"],
            index=r["recall_mean"]["index"],
            columns=r["recall_mean"]["columns"],
        )
        for r in runs
    }
    args.output.mkdir(parents=True, exist_ok=True)
    median = pd.DataFrame(
        np.nanmedian(np.stack([f.to_numpy(dtype=float) for f in frames.values()]), axis=0),
        index=next(iter(frames.values())).index,
        columns=next(None).columns,
    )
    fig, ax = plt.subplots(figsize=(7, 5))
    _draw(ax, median, f"Median detection rate over {len(frames)} real datasets (typed injection)")
    fig.tight_layout()
    fig.savefig(args.output / "typed_pooled.png", dpi=160)
    plt.close(fig)
    names = [r["name"] for r in runs][: args.panels]
    cols = 3
    rows = -(-len(names) // cols)
    fig, axes = plt.subplots(rows, cols, figsize=(5.2 * cols, 3.6 * rows), squeeze=False)
    for ax in axes.ravel():
        ax.axis("off")
    for ax, name in zip(axes.ravel(), names, strict=False):
        ax.axis("on")
        _draw(ax, frames[name], name[:38])
    fig.tight_layout()
    fig.savefig(args.output / "typed_panels.png", dpi=130)
    plt.close(fig)
    return 0


def x_main__mutmut_88(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--panels", type=int, default=6)
    args = parser.parse_args(argv)
    runs = sorted(
        (json.loads(p.read_text()) for p in args.runs.glob("*.json")), key=lambda r: r["uci_id"]
    )
    frames = {
        r["name"]: pd.DataFrame(
            r["recall_mean"]["data"],
            index=r["recall_mean"]["index"],
            columns=r["recall_mean"]["columns"],
        )
        for r in runs
    }
    args.output.mkdir(parents=True, exist_ok=True)
    median = pd.DataFrame(
        np.nanmedian(np.stack([f.to_numpy(dtype=float) for f in frames.values()]), axis=0),
        index=next(iter(frames.values())).index,
        columns=next(iter(None)).columns,
    )
    fig, ax = plt.subplots(figsize=(7, 5))
    _draw(ax, median, f"Median detection rate over {len(frames)} real datasets (typed injection)")
    fig.tight_layout()
    fig.savefig(args.output / "typed_pooled.png", dpi=160)
    plt.close(fig)
    names = [r["name"] for r in runs][: args.panels]
    cols = 3
    rows = -(-len(names) // cols)
    fig, axes = plt.subplots(rows, cols, figsize=(5.2 * cols, 3.6 * rows), squeeze=False)
    for ax in axes.ravel():
        ax.axis("off")
    for ax, name in zip(axes.ravel(), names, strict=False):
        ax.axis("on")
        _draw(ax, frames[name], name[:38])
    fig.tight_layout()
    fig.savefig(args.output / "typed_panels.png", dpi=130)
    plt.close(fig)
    return 0


def x_main__mutmut_89(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--panels", type=int, default=6)
    args = parser.parse_args(argv)
    runs = sorted(
        (json.loads(p.read_text()) for p in args.runs.glob("*.json")), key=lambda r: r["uci_id"]
    )
    frames = {
        r["name"]: pd.DataFrame(
            r["recall_mean"]["data"],
            index=r["recall_mean"]["index"],
            columns=r["recall_mean"]["columns"],
        )
        for r in runs
    }
    args.output.mkdir(parents=True, exist_ok=True)
    median = pd.DataFrame(
        np.nanmedian(np.stack([f.to_numpy(dtype=float) for f in frames.values()]), axis=0),
        index=next(iter(frames.values())).index,
        columns=next(iter(frames.values())).columns,
    )
    fig, ax = None
    _draw(ax, median, f"Median detection rate over {len(frames)} real datasets (typed injection)")
    fig.tight_layout()
    fig.savefig(args.output / "typed_pooled.png", dpi=160)
    plt.close(fig)
    names = [r["name"] for r in runs][: args.panels]
    cols = 3
    rows = -(-len(names) // cols)
    fig, axes = plt.subplots(rows, cols, figsize=(5.2 * cols, 3.6 * rows), squeeze=False)
    for ax in axes.ravel():
        ax.axis("off")
    for ax, name in zip(axes.ravel(), names, strict=False):
        ax.axis("on")
        _draw(ax, frames[name], name[:38])
    fig.tight_layout()
    fig.savefig(args.output / "typed_panels.png", dpi=130)
    plt.close(fig)
    return 0


def x_main__mutmut_90(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--panels", type=int, default=6)
    args = parser.parse_args(argv)
    runs = sorted(
        (json.loads(p.read_text()) for p in args.runs.glob("*.json")), key=lambda r: r["uci_id"]
    )
    frames = {
        r["name"]: pd.DataFrame(
            r["recall_mean"]["data"],
            index=r["recall_mean"]["index"],
            columns=r["recall_mean"]["columns"],
        )
        for r in runs
    }
    args.output.mkdir(parents=True, exist_ok=True)
    median = pd.DataFrame(
        np.nanmedian(np.stack([f.to_numpy(dtype=float) for f in frames.values()]), axis=0),
        index=next(iter(frames.values())).index,
        columns=next(iter(frames.values())).columns,
    )
    fig, ax = plt.subplots(figsize=None)
    _draw(ax, median, f"Median detection rate over {len(frames)} real datasets (typed injection)")
    fig.tight_layout()
    fig.savefig(args.output / "typed_pooled.png", dpi=160)
    plt.close(fig)
    names = [r["name"] for r in runs][: args.panels]
    cols = 3
    rows = -(-len(names) // cols)
    fig, axes = plt.subplots(rows, cols, figsize=(5.2 * cols, 3.6 * rows), squeeze=False)
    for ax in axes.ravel():
        ax.axis("off")
    for ax, name in zip(axes.ravel(), names, strict=False):
        ax.axis("on")
        _draw(ax, frames[name], name[:38])
    fig.tight_layout()
    fig.savefig(args.output / "typed_panels.png", dpi=130)
    plt.close(fig)
    return 0


def x_main__mutmut_91(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--panels", type=int, default=6)
    args = parser.parse_args(argv)
    runs = sorted(
        (json.loads(p.read_text()) for p in args.runs.glob("*.json")), key=lambda r: r["uci_id"]
    )
    frames = {
        r["name"]: pd.DataFrame(
            r["recall_mean"]["data"],
            index=r["recall_mean"]["index"],
            columns=r["recall_mean"]["columns"],
        )
        for r in runs
    }
    args.output.mkdir(parents=True, exist_ok=True)
    median = pd.DataFrame(
        np.nanmedian(np.stack([f.to_numpy(dtype=float) for f in frames.values()]), axis=0),
        index=next(iter(frames.values())).index,
        columns=next(iter(frames.values())).columns,
    )
    fig, ax = plt.subplots(figsize=(8, 5))
    _draw(ax, median, f"Median detection rate over {len(frames)} real datasets (typed injection)")
    fig.tight_layout()
    fig.savefig(args.output / "typed_pooled.png", dpi=160)
    plt.close(fig)
    names = [r["name"] for r in runs][: args.panels]
    cols = 3
    rows = -(-len(names) // cols)
    fig, axes = plt.subplots(rows, cols, figsize=(5.2 * cols, 3.6 * rows), squeeze=False)
    for ax in axes.ravel():
        ax.axis("off")
    for ax, name in zip(axes.ravel(), names, strict=False):
        ax.axis("on")
        _draw(ax, frames[name], name[:38])
    fig.tight_layout()
    fig.savefig(args.output / "typed_panels.png", dpi=130)
    plt.close(fig)
    return 0


def x_main__mutmut_92(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--panels", type=int, default=6)
    args = parser.parse_args(argv)
    runs = sorted(
        (json.loads(p.read_text()) for p in args.runs.glob("*.json")), key=lambda r: r["uci_id"]
    )
    frames = {
        r["name"]: pd.DataFrame(
            r["recall_mean"]["data"],
            index=r["recall_mean"]["index"],
            columns=r["recall_mean"]["columns"],
        )
        for r in runs
    }
    args.output.mkdir(parents=True, exist_ok=True)
    median = pd.DataFrame(
        np.nanmedian(np.stack([f.to_numpy(dtype=float) for f in frames.values()]), axis=0),
        index=next(iter(frames.values())).index,
        columns=next(iter(frames.values())).columns,
    )
    fig, ax = plt.subplots(figsize=(7, 6))
    _draw(ax, median, f"Median detection rate over {len(frames)} real datasets (typed injection)")
    fig.tight_layout()
    fig.savefig(args.output / "typed_pooled.png", dpi=160)
    plt.close(fig)
    names = [r["name"] for r in runs][: args.panels]
    cols = 3
    rows = -(-len(names) // cols)
    fig, axes = plt.subplots(rows, cols, figsize=(5.2 * cols, 3.6 * rows), squeeze=False)
    for ax in axes.ravel():
        ax.axis("off")
    for ax, name in zip(axes.ravel(), names, strict=False):
        ax.axis("on")
        _draw(ax, frames[name], name[:38])
    fig.tight_layout()
    fig.savefig(args.output / "typed_panels.png", dpi=130)
    plt.close(fig)
    return 0


def x_main__mutmut_93(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--panels", type=int, default=6)
    args = parser.parse_args(argv)
    runs = sorted(
        (json.loads(p.read_text()) for p in args.runs.glob("*.json")), key=lambda r: r["uci_id"]
    )
    frames = {
        r["name"]: pd.DataFrame(
            r["recall_mean"]["data"],
            index=r["recall_mean"]["index"],
            columns=r["recall_mean"]["columns"],
        )
        for r in runs
    }
    args.output.mkdir(parents=True, exist_ok=True)
    median = pd.DataFrame(
        np.nanmedian(np.stack([f.to_numpy(dtype=float) for f in frames.values()]), axis=0),
        index=next(iter(frames.values())).index,
        columns=next(iter(frames.values())).columns,
    )
    fig, ax = plt.subplots(figsize=(7, 5))
    _draw(None, median, f"Median detection rate over {len(frames)} real datasets (typed injection)")
    fig.tight_layout()
    fig.savefig(args.output / "typed_pooled.png", dpi=160)
    plt.close(fig)
    names = [r["name"] for r in runs][: args.panels]
    cols = 3
    rows = -(-len(names) // cols)
    fig, axes = plt.subplots(rows, cols, figsize=(5.2 * cols, 3.6 * rows), squeeze=False)
    for ax in axes.ravel():
        ax.axis("off")
    for ax, name in zip(axes.ravel(), names, strict=False):
        ax.axis("on")
        _draw(ax, frames[name], name[:38])
    fig.tight_layout()
    fig.savefig(args.output / "typed_panels.png", dpi=130)
    plt.close(fig)
    return 0


def x_main__mutmut_94(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--panels", type=int, default=6)
    args = parser.parse_args(argv)
    runs = sorted(
        (json.loads(p.read_text()) for p in args.runs.glob("*.json")), key=lambda r: r["uci_id"]
    )
    frames = {
        r["name"]: pd.DataFrame(
            r["recall_mean"]["data"],
            index=r["recall_mean"]["index"],
            columns=r["recall_mean"]["columns"],
        )
        for r in runs
    }
    args.output.mkdir(parents=True, exist_ok=True)
    median = pd.DataFrame(
        np.nanmedian(np.stack([f.to_numpy(dtype=float) for f in frames.values()]), axis=0),
        index=next(iter(frames.values())).index,
        columns=next(iter(frames.values())).columns,
    )
    fig, ax = plt.subplots(figsize=(7, 5))
    _draw(ax, None, f"Median detection rate over {len(frames)} real datasets (typed injection)")
    fig.tight_layout()
    fig.savefig(args.output / "typed_pooled.png", dpi=160)
    plt.close(fig)
    names = [r["name"] for r in runs][: args.panels]
    cols = 3
    rows = -(-len(names) // cols)
    fig, axes = plt.subplots(rows, cols, figsize=(5.2 * cols, 3.6 * rows), squeeze=False)
    for ax in axes.ravel():
        ax.axis("off")
    for ax, name in zip(axes.ravel(), names, strict=False):
        ax.axis("on")
        _draw(ax, frames[name], name[:38])
    fig.tight_layout()
    fig.savefig(args.output / "typed_panels.png", dpi=130)
    plt.close(fig)
    return 0


def x_main__mutmut_95(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--panels", type=int, default=6)
    args = parser.parse_args(argv)
    runs = sorted(
        (json.loads(p.read_text()) for p in args.runs.glob("*.json")), key=lambda r: r["uci_id"]
    )
    frames = {
        r["name"]: pd.DataFrame(
            r["recall_mean"]["data"],
            index=r["recall_mean"]["index"],
            columns=r["recall_mean"]["columns"],
        )
        for r in runs
    }
    args.output.mkdir(parents=True, exist_ok=True)
    median = pd.DataFrame(
        np.nanmedian(np.stack([f.to_numpy(dtype=float) for f in frames.values()]), axis=0),
        index=next(iter(frames.values())).index,
        columns=next(iter(frames.values())).columns,
    )
    fig, ax = plt.subplots(figsize=(7, 5))
    _draw(ax, median, None)
    fig.tight_layout()
    fig.savefig(args.output / "typed_pooled.png", dpi=160)
    plt.close(fig)
    names = [r["name"] for r in runs][: args.panels]
    cols = 3
    rows = -(-len(names) // cols)
    fig, axes = plt.subplots(rows, cols, figsize=(5.2 * cols, 3.6 * rows), squeeze=False)
    for ax in axes.ravel():
        ax.axis("off")
    for ax, name in zip(axes.ravel(), names, strict=False):
        ax.axis("on")
        _draw(ax, frames[name], name[:38])
    fig.tight_layout()
    fig.savefig(args.output / "typed_panels.png", dpi=130)
    plt.close(fig)
    return 0


def x_main__mutmut_96(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--panels", type=int, default=6)
    args = parser.parse_args(argv)
    runs = sorted(
        (json.loads(p.read_text()) for p in args.runs.glob("*.json")), key=lambda r: r["uci_id"]
    )
    frames = {
        r["name"]: pd.DataFrame(
            r["recall_mean"]["data"],
            index=r["recall_mean"]["index"],
            columns=r["recall_mean"]["columns"],
        )
        for r in runs
    }
    args.output.mkdir(parents=True, exist_ok=True)
    median = pd.DataFrame(
        np.nanmedian(np.stack([f.to_numpy(dtype=float) for f in frames.values()]), axis=0),
        index=next(iter(frames.values())).index,
        columns=next(iter(frames.values())).columns,
    )
    fig, ax = plt.subplots(figsize=(7, 5))
    _draw(median, f"Median detection rate over {len(frames)} real datasets (typed injection)")
    fig.tight_layout()
    fig.savefig(args.output / "typed_pooled.png", dpi=160)
    plt.close(fig)
    names = [r["name"] for r in runs][: args.panels]
    cols = 3
    rows = -(-len(names) // cols)
    fig, axes = plt.subplots(rows, cols, figsize=(5.2 * cols, 3.6 * rows), squeeze=False)
    for ax in axes.ravel():
        ax.axis("off")
    for ax, name in zip(axes.ravel(), names, strict=False):
        ax.axis("on")
        _draw(ax, frames[name], name[:38])
    fig.tight_layout()
    fig.savefig(args.output / "typed_panels.png", dpi=130)
    plt.close(fig)
    return 0


def x_main__mutmut_97(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--panels", type=int, default=6)
    args = parser.parse_args(argv)
    runs = sorted(
        (json.loads(p.read_text()) for p in args.runs.glob("*.json")), key=lambda r: r["uci_id"]
    )
    frames = {
        r["name"]: pd.DataFrame(
            r["recall_mean"]["data"],
            index=r["recall_mean"]["index"],
            columns=r["recall_mean"]["columns"],
        )
        for r in runs
    }
    args.output.mkdir(parents=True, exist_ok=True)
    median = pd.DataFrame(
        np.nanmedian(np.stack([f.to_numpy(dtype=float) for f in frames.values()]), axis=0),
        index=next(iter(frames.values())).index,
        columns=next(iter(frames.values())).columns,
    )
    fig, ax = plt.subplots(figsize=(7, 5))
    _draw(ax, f"Median detection rate over {len(frames)} real datasets (typed injection)")
    fig.tight_layout()
    fig.savefig(args.output / "typed_pooled.png", dpi=160)
    plt.close(fig)
    names = [r["name"] for r in runs][: args.panels]
    cols = 3
    rows = -(-len(names) // cols)
    fig, axes = plt.subplots(rows, cols, figsize=(5.2 * cols, 3.6 * rows), squeeze=False)
    for ax in axes.ravel():
        ax.axis("off")
    for ax, name in zip(axes.ravel(), names, strict=False):
        ax.axis("on")
        _draw(ax, frames[name], name[:38])
    fig.tight_layout()
    fig.savefig(args.output / "typed_panels.png", dpi=130)
    plt.close(fig)
    return 0


def x_main__mutmut_98(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--panels", type=int, default=6)
    args = parser.parse_args(argv)
    runs = sorted(
        (json.loads(p.read_text()) for p in args.runs.glob("*.json")), key=lambda r: r["uci_id"]
    )
    frames = {
        r["name"]: pd.DataFrame(
            r["recall_mean"]["data"],
            index=r["recall_mean"]["index"],
            columns=r["recall_mean"]["columns"],
        )
        for r in runs
    }
    args.output.mkdir(parents=True, exist_ok=True)
    median = pd.DataFrame(
        np.nanmedian(np.stack([f.to_numpy(dtype=float) for f in frames.values()]), axis=0),
        index=next(iter(frames.values())).index,
        columns=next(iter(frames.values())).columns,
    )
    fig, ax = plt.subplots(figsize=(7, 5))
    _draw(ax, median, )
    fig.tight_layout()
    fig.savefig(args.output / "typed_pooled.png", dpi=160)
    plt.close(fig)
    names = [r["name"] for r in runs][: args.panels]
    cols = 3
    rows = -(-len(names) // cols)
    fig, axes = plt.subplots(rows, cols, figsize=(5.2 * cols, 3.6 * rows), squeeze=False)
    for ax in axes.ravel():
        ax.axis("off")
    for ax, name in zip(axes.ravel(), names, strict=False):
        ax.axis("on")
        _draw(ax, frames[name], name[:38])
    fig.tight_layout()
    fig.savefig(args.output / "typed_panels.png", dpi=130)
    plt.close(fig)
    return 0


def x_main__mutmut_99(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--panels", type=int, default=6)
    args = parser.parse_args(argv)
    runs = sorted(
        (json.loads(p.read_text()) for p in args.runs.glob("*.json")), key=lambda r: r["uci_id"]
    )
    frames = {
        r["name"]: pd.DataFrame(
            r["recall_mean"]["data"],
            index=r["recall_mean"]["index"],
            columns=r["recall_mean"]["columns"],
        )
        for r in runs
    }
    args.output.mkdir(parents=True, exist_ok=True)
    median = pd.DataFrame(
        np.nanmedian(np.stack([f.to_numpy(dtype=float) for f in frames.values()]), axis=0),
        index=next(iter(frames.values())).index,
        columns=next(iter(frames.values())).columns,
    )
    fig, ax = plt.subplots(figsize=(7, 5))
    _draw(ax, median, f"Median detection rate over {len(frames)} real datasets (typed injection)")
    fig.tight_layout()
    fig.savefig(None, dpi=160)
    plt.close(fig)
    names = [r["name"] for r in runs][: args.panels]
    cols = 3
    rows = -(-len(names) // cols)
    fig, axes = plt.subplots(rows, cols, figsize=(5.2 * cols, 3.6 * rows), squeeze=False)
    for ax in axes.ravel():
        ax.axis("off")
    for ax, name in zip(axes.ravel(), names, strict=False):
        ax.axis("on")
        _draw(ax, frames[name], name[:38])
    fig.tight_layout()
    fig.savefig(args.output / "typed_panels.png", dpi=130)
    plt.close(fig)
    return 0


def x_main__mutmut_100(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--panels", type=int, default=6)
    args = parser.parse_args(argv)
    runs = sorted(
        (json.loads(p.read_text()) for p in args.runs.glob("*.json")), key=lambda r: r["uci_id"]
    )
    frames = {
        r["name"]: pd.DataFrame(
            r["recall_mean"]["data"],
            index=r["recall_mean"]["index"],
            columns=r["recall_mean"]["columns"],
        )
        for r in runs
    }
    args.output.mkdir(parents=True, exist_ok=True)
    median = pd.DataFrame(
        np.nanmedian(np.stack([f.to_numpy(dtype=float) for f in frames.values()]), axis=0),
        index=next(iter(frames.values())).index,
        columns=next(iter(frames.values())).columns,
    )
    fig, ax = plt.subplots(figsize=(7, 5))
    _draw(ax, median, f"Median detection rate over {len(frames)} real datasets (typed injection)")
    fig.tight_layout()
    fig.savefig(args.output / "typed_pooled.png", dpi=None)
    plt.close(fig)
    names = [r["name"] for r in runs][: args.panels]
    cols = 3
    rows = -(-len(names) // cols)
    fig, axes = plt.subplots(rows, cols, figsize=(5.2 * cols, 3.6 * rows), squeeze=False)
    for ax in axes.ravel():
        ax.axis("off")
    for ax, name in zip(axes.ravel(), names, strict=False):
        ax.axis("on")
        _draw(ax, frames[name], name[:38])
    fig.tight_layout()
    fig.savefig(args.output / "typed_panels.png", dpi=130)
    plt.close(fig)
    return 0


def x_main__mutmut_101(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--panels", type=int, default=6)
    args = parser.parse_args(argv)
    runs = sorted(
        (json.loads(p.read_text()) for p in args.runs.glob("*.json")), key=lambda r: r["uci_id"]
    )
    frames = {
        r["name"]: pd.DataFrame(
            r["recall_mean"]["data"],
            index=r["recall_mean"]["index"],
            columns=r["recall_mean"]["columns"],
        )
        for r in runs
    }
    args.output.mkdir(parents=True, exist_ok=True)
    median = pd.DataFrame(
        np.nanmedian(np.stack([f.to_numpy(dtype=float) for f in frames.values()]), axis=0),
        index=next(iter(frames.values())).index,
        columns=next(iter(frames.values())).columns,
    )
    fig, ax = plt.subplots(figsize=(7, 5))
    _draw(ax, median, f"Median detection rate over {len(frames)} real datasets (typed injection)")
    fig.tight_layout()
    fig.savefig(dpi=160)
    plt.close(fig)
    names = [r["name"] for r in runs][: args.panels]
    cols = 3
    rows = -(-len(names) // cols)
    fig, axes = plt.subplots(rows, cols, figsize=(5.2 * cols, 3.6 * rows), squeeze=False)
    for ax in axes.ravel():
        ax.axis("off")
    for ax, name in zip(axes.ravel(), names, strict=False):
        ax.axis("on")
        _draw(ax, frames[name], name[:38])
    fig.tight_layout()
    fig.savefig(args.output / "typed_panels.png", dpi=130)
    plt.close(fig)
    return 0


def x_main__mutmut_102(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--panels", type=int, default=6)
    args = parser.parse_args(argv)
    runs = sorted(
        (json.loads(p.read_text()) for p in args.runs.glob("*.json")), key=lambda r: r["uci_id"]
    )
    frames = {
        r["name"]: pd.DataFrame(
            r["recall_mean"]["data"],
            index=r["recall_mean"]["index"],
            columns=r["recall_mean"]["columns"],
        )
        for r in runs
    }
    args.output.mkdir(parents=True, exist_ok=True)
    median = pd.DataFrame(
        np.nanmedian(np.stack([f.to_numpy(dtype=float) for f in frames.values()]), axis=0),
        index=next(iter(frames.values())).index,
        columns=next(iter(frames.values())).columns,
    )
    fig, ax = plt.subplots(figsize=(7, 5))
    _draw(ax, median, f"Median detection rate over {len(frames)} real datasets (typed injection)")
    fig.tight_layout()
    fig.savefig(args.output / "typed_pooled.png", )
    plt.close(fig)
    names = [r["name"] for r in runs][: args.panels]
    cols = 3
    rows = -(-len(names) // cols)
    fig, axes = plt.subplots(rows, cols, figsize=(5.2 * cols, 3.6 * rows), squeeze=False)
    for ax in axes.ravel():
        ax.axis("off")
    for ax, name in zip(axes.ravel(), names, strict=False):
        ax.axis("on")
        _draw(ax, frames[name], name[:38])
    fig.tight_layout()
    fig.savefig(args.output / "typed_panels.png", dpi=130)
    plt.close(fig)
    return 0


def x_main__mutmut_103(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--panels", type=int, default=6)
    args = parser.parse_args(argv)
    runs = sorted(
        (json.loads(p.read_text()) for p in args.runs.glob("*.json")), key=lambda r: r["uci_id"]
    )
    frames = {
        r["name"]: pd.DataFrame(
            r["recall_mean"]["data"],
            index=r["recall_mean"]["index"],
            columns=r["recall_mean"]["columns"],
        )
        for r in runs
    }
    args.output.mkdir(parents=True, exist_ok=True)
    median = pd.DataFrame(
        np.nanmedian(np.stack([f.to_numpy(dtype=float) for f in frames.values()]), axis=0),
        index=next(iter(frames.values())).index,
        columns=next(iter(frames.values())).columns,
    )
    fig, ax = plt.subplots(figsize=(7, 5))
    _draw(ax, median, f"Median detection rate over {len(frames)} real datasets (typed injection)")
    fig.tight_layout()
    fig.savefig(args.output * "typed_pooled.png", dpi=160)
    plt.close(fig)
    names = [r["name"] for r in runs][: args.panels]
    cols = 3
    rows = -(-len(names) // cols)
    fig, axes = plt.subplots(rows, cols, figsize=(5.2 * cols, 3.6 * rows), squeeze=False)
    for ax in axes.ravel():
        ax.axis("off")
    for ax, name in zip(axes.ravel(), names, strict=False):
        ax.axis("on")
        _draw(ax, frames[name], name[:38])
    fig.tight_layout()
    fig.savefig(args.output / "typed_panels.png", dpi=130)
    plt.close(fig)
    return 0


def x_main__mutmut_104(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--panels", type=int, default=6)
    args = parser.parse_args(argv)
    runs = sorted(
        (json.loads(p.read_text()) for p in args.runs.glob("*.json")), key=lambda r: r["uci_id"]
    )
    frames = {
        r["name"]: pd.DataFrame(
            r["recall_mean"]["data"],
            index=r["recall_mean"]["index"],
            columns=r["recall_mean"]["columns"],
        )
        for r in runs
    }
    args.output.mkdir(parents=True, exist_ok=True)
    median = pd.DataFrame(
        np.nanmedian(np.stack([f.to_numpy(dtype=float) for f in frames.values()]), axis=0),
        index=next(iter(frames.values())).index,
        columns=next(iter(frames.values())).columns,
    )
    fig, ax = plt.subplots(figsize=(7, 5))
    _draw(ax, median, f"Median detection rate over {len(frames)} real datasets (typed injection)")
    fig.tight_layout()
    fig.savefig(args.output / "XXtyped_pooled.pngXX", dpi=160)
    plt.close(fig)
    names = [r["name"] for r in runs][: args.panels]
    cols = 3
    rows = -(-len(names) // cols)
    fig, axes = plt.subplots(rows, cols, figsize=(5.2 * cols, 3.6 * rows), squeeze=False)
    for ax in axes.ravel():
        ax.axis("off")
    for ax, name in zip(axes.ravel(), names, strict=False):
        ax.axis("on")
        _draw(ax, frames[name], name[:38])
    fig.tight_layout()
    fig.savefig(args.output / "typed_panels.png", dpi=130)
    plt.close(fig)
    return 0


def x_main__mutmut_105(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--panels", type=int, default=6)
    args = parser.parse_args(argv)
    runs = sorted(
        (json.loads(p.read_text()) for p in args.runs.glob("*.json")), key=lambda r: r["uci_id"]
    )
    frames = {
        r["name"]: pd.DataFrame(
            r["recall_mean"]["data"],
            index=r["recall_mean"]["index"],
            columns=r["recall_mean"]["columns"],
        )
        for r in runs
    }
    args.output.mkdir(parents=True, exist_ok=True)
    median = pd.DataFrame(
        np.nanmedian(np.stack([f.to_numpy(dtype=float) for f in frames.values()]), axis=0),
        index=next(iter(frames.values())).index,
        columns=next(iter(frames.values())).columns,
    )
    fig, ax = plt.subplots(figsize=(7, 5))
    _draw(ax, median, f"Median detection rate over {len(frames)} real datasets (typed injection)")
    fig.tight_layout()
    fig.savefig(args.output / "TYPED_POOLED.PNG", dpi=160)
    plt.close(fig)
    names = [r["name"] for r in runs][: args.panels]
    cols = 3
    rows = -(-len(names) // cols)
    fig, axes = plt.subplots(rows, cols, figsize=(5.2 * cols, 3.6 * rows), squeeze=False)
    for ax in axes.ravel():
        ax.axis("off")
    for ax, name in zip(axes.ravel(), names, strict=False):
        ax.axis("on")
        _draw(ax, frames[name], name[:38])
    fig.tight_layout()
    fig.savefig(args.output / "typed_panels.png", dpi=130)
    plt.close(fig)
    return 0


def x_main__mutmut_106(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--panels", type=int, default=6)
    args = parser.parse_args(argv)
    runs = sorted(
        (json.loads(p.read_text()) for p in args.runs.glob("*.json")), key=lambda r: r["uci_id"]
    )
    frames = {
        r["name"]: pd.DataFrame(
            r["recall_mean"]["data"],
            index=r["recall_mean"]["index"],
            columns=r["recall_mean"]["columns"],
        )
        for r in runs
    }
    args.output.mkdir(parents=True, exist_ok=True)
    median = pd.DataFrame(
        np.nanmedian(np.stack([f.to_numpy(dtype=float) for f in frames.values()]), axis=0),
        index=next(iter(frames.values())).index,
        columns=next(iter(frames.values())).columns,
    )
    fig, ax = plt.subplots(figsize=(7, 5))
    _draw(ax, median, f"Median detection rate over {len(frames)} real datasets (typed injection)")
    fig.tight_layout()
    fig.savefig(args.output / "typed_pooled.png", dpi=161)
    plt.close(fig)
    names = [r["name"] for r in runs][: args.panels]
    cols = 3
    rows = -(-len(names) // cols)
    fig, axes = plt.subplots(rows, cols, figsize=(5.2 * cols, 3.6 * rows), squeeze=False)
    for ax in axes.ravel():
        ax.axis("off")
    for ax, name in zip(axes.ravel(), names, strict=False):
        ax.axis("on")
        _draw(ax, frames[name], name[:38])
    fig.tight_layout()
    fig.savefig(args.output / "typed_panels.png", dpi=130)
    plt.close(fig)
    return 0


def x_main__mutmut_107(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--panels", type=int, default=6)
    args = parser.parse_args(argv)
    runs = sorted(
        (json.loads(p.read_text()) for p in args.runs.glob("*.json")), key=lambda r: r["uci_id"]
    )
    frames = {
        r["name"]: pd.DataFrame(
            r["recall_mean"]["data"],
            index=r["recall_mean"]["index"],
            columns=r["recall_mean"]["columns"],
        )
        for r in runs
    }
    args.output.mkdir(parents=True, exist_ok=True)
    median = pd.DataFrame(
        np.nanmedian(np.stack([f.to_numpy(dtype=float) for f in frames.values()]), axis=0),
        index=next(iter(frames.values())).index,
        columns=next(iter(frames.values())).columns,
    )
    fig, ax = plt.subplots(figsize=(7, 5))
    _draw(ax, median, f"Median detection rate over {len(frames)} real datasets (typed injection)")
    fig.tight_layout()
    fig.savefig(args.output / "typed_pooled.png", dpi=160)
    plt.close(None)
    names = [r["name"] for r in runs][: args.panels]
    cols = 3
    rows = -(-len(names) // cols)
    fig, axes = plt.subplots(rows, cols, figsize=(5.2 * cols, 3.6 * rows), squeeze=False)
    for ax in axes.ravel():
        ax.axis("off")
    for ax, name in zip(axes.ravel(), names, strict=False):
        ax.axis("on")
        _draw(ax, frames[name], name[:38])
    fig.tight_layout()
    fig.savefig(args.output / "typed_panels.png", dpi=130)
    plt.close(fig)
    return 0


def x_main__mutmut_108(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--panels", type=int, default=6)
    args = parser.parse_args(argv)
    runs = sorted(
        (json.loads(p.read_text()) for p in args.runs.glob("*.json")), key=lambda r: r["uci_id"]
    )
    frames = {
        r["name"]: pd.DataFrame(
            r["recall_mean"]["data"],
            index=r["recall_mean"]["index"],
            columns=r["recall_mean"]["columns"],
        )
        for r in runs
    }
    args.output.mkdir(parents=True, exist_ok=True)
    median = pd.DataFrame(
        np.nanmedian(np.stack([f.to_numpy(dtype=float) for f in frames.values()]), axis=0),
        index=next(iter(frames.values())).index,
        columns=next(iter(frames.values())).columns,
    )
    fig, ax = plt.subplots(figsize=(7, 5))
    _draw(ax, median, f"Median detection rate over {len(frames)} real datasets (typed injection)")
    fig.tight_layout()
    fig.savefig(args.output / "typed_pooled.png", dpi=160)
    plt.close(fig)
    names = None
    cols = 3
    rows = -(-len(names) // cols)
    fig, axes = plt.subplots(rows, cols, figsize=(5.2 * cols, 3.6 * rows), squeeze=False)
    for ax in axes.ravel():
        ax.axis("off")
    for ax, name in zip(axes.ravel(), names, strict=False):
        ax.axis("on")
        _draw(ax, frames[name], name[:38])
    fig.tight_layout()
    fig.savefig(args.output / "typed_panels.png", dpi=130)
    plt.close(fig)
    return 0


def x_main__mutmut_109(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--panels", type=int, default=6)
    args = parser.parse_args(argv)
    runs = sorted(
        (json.loads(p.read_text()) for p in args.runs.glob("*.json")), key=lambda r: r["uci_id"]
    )
    frames = {
        r["name"]: pd.DataFrame(
            r["recall_mean"]["data"],
            index=r["recall_mean"]["index"],
            columns=r["recall_mean"]["columns"],
        )
        for r in runs
    }
    args.output.mkdir(parents=True, exist_ok=True)
    median = pd.DataFrame(
        np.nanmedian(np.stack([f.to_numpy(dtype=float) for f in frames.values()]), axis=0),
        index=next(iter(frames.values())).index,
        columns=next(iter(frames.values())).columns,
    )
    fig, ax = plt.subplots(figsize=(7, 5))
    _draw(ax, median, f"Median detection rate over {len(frames)} real datasets (typed injection)")
    fig.tight_layout()
    fig.savefig(args.output / "typed_pooled.png", dpi=160)
    plt.close(fig)
    names = [r["XXnameXX"] for r in runs][: args.panels]
    cols = 3
    rows = -(-len(names) // cols)
    fig, axes = plt.subplots(rows, cols, figsize=(5.2 * cols, 3.6 * rows), squeeze=False)
    for ax in axes.ravel():
        ax.axis("off")
    for ax, name in zip(axes.ravel(), names, strict=False):
        ax.axis("on")
        _draw(ax, frames[name], name[:38])
    fig.tight_layout()
    fig.savefig(args.output / "typed_panels.png", dpi=130)
    plt.close(fig)
    return 0


def x_main__mutmut_110(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--panels", type=int, default=6)
    args = parser.parse_args(argv)
    runs = sorted(
        (json.loads(p.read_text()) for p in args.runs.glob("*.json")), key=lambda r: r["uci_id"]
    )
    frames = {
        r["name"]: pd.DataFrame(
            r["recall_mean"]["data"],
            index=r["recall_mean"]["index"],
            columns=r["recall_mean"]["columns"],
        )
        for r in runs
    }
    args.output.mkdir(parents=True, exist_ok=True)
    median = pd.DataFrame(
        np.nanmedian(np.stack([f.to_numpy(dtype=float) for f in frames.values()]), axis=0),
        index=next(iter(frames.values())).index,
        columns=next(iter(frames.values())).columns,
    )
    fig, ax = plt.subplots(figsize=(7, 5))
    _draw(ax, median, f"Median detection rate over {len(frames)} real datasets (typed injection)")
    fig.tight_layout()
    fig.savefig(args.output / "typed_pooled.png", dpi=160)
    plt.close(fig)
    names = [r["NAME"] for r in runs][: args.panels]
    cols = 3
    rows = -(-len(names) // cols)
    fig, axes = plt.subplots(rows, cols, figsize=(5.2 * cols, 3.6 * rows), squeeze=False)
    for ax in axes.ravel():
        ax.axis("off")
    for ax, name in zip(axes.ravel(), names, strict=False):
        ax.axis("on")
        _draw(ax, frames[name], name[:38])
    fig.tight_layout()
    fig.savefig(args.output / "typed_panels.png", dpi=130)
    plt.close(fig)
    return 0


def x_main__mutmut_111(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--panels", type=int, default=6)
    args = parser.parse_args(argv)
    runs = sorted(
        (json.loads(p.read_text()) for p in args.runs.glob("*.json")), key=lambda r: r["uci_id"]
    )
    frames = {
        r["name"]: pd.DataFrame(
            r["recall_mean"]["data"],
            index=r["recall_mean"]["index"],
            columns=r["recall_mean"]["columns"],
        )
        for r in runs
    }
    args.output.mkdir(parents=True, exist_ok=True)
    median = pd.DataFrame(
        np.nanmedian(np.stack([f.to_numpy(dtype=float) for f in frames.values()]), axis=0),
        index=next(iter(frames.values())).index,
        columns=next(iter(frames.values())).columns,
    )
    fig, ax = plt.subplots(figsize=(7, 5))
    _draw(ax, median, f"Median detection rate over {len(frames)} real datasets (typed injection)")
    fig.tight_layout()
    fig.savefig(args.output / "typed_pooled.png", dpi=160)
    plt.close(fig)
    names = [r["name"] for r in runs][: args.panels]
    cols = None
    rows = -(-len(names) // cols)
    fig, axes = plt.subplots(rows, cols, figsize=(5.2 * cols, 3.6 * rows), squeeze=False)
    for ax in axes.ravel():
        ax.axis("off")
    for ax, name in zip(axes.ravel(), names, strict=False):
        ax.axis("on")
        _draw(ax, frames[name], name[:38])
    fig.tight_layout()
    fig.savefig(args.output / "typed_panels.png", dpi=130)
    plt.close(fig)
    return 0


def x_main__mutmut_112(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--panels", type=int, default=6)
    args = parser.parse_args(argv)
    runs = sorted(
        (json.loads(p.read_text()) for p in args.runs.glob("*.json")), key=lambda r: r["uci_id"]
    )
    frames = {
        r["name"]: pd.DataFrame(
            r["recall_mean"]["data"],
            index=r["recall_mean"]["index"],
            columns=r["recall_mean"]["columns"],
        )
        for r in runs
    }
    args.output.mkdir(parents=True, exist_ok=True)
    median = pd.DataFrame(
        np.nanmedian(np.stack([f.to_numpy(dtype=float) for f in frames.values()]), axis=0),
        index=next(iter(frames.values())).index,
        columns=next(iter(frames.values())).columns,
    )
    fig, ax = plt.subplots(figsize=(7, 5))
    _draw(ax, median, f"Median detection rate over {len(frames)} real datasets (typed injection)")
    fig.tight_layout()
    fig.savefig(args.output / "typed_pooled.png", dpi=160)
    plt.close(fig)
    names = [r["name"] for r in runs][: args.panels]
    cols = 4
    rows = -(-len(names) // cols)
    fig, axes = plt.subplots(rows, cols, figsize=(5.2 * cols, 3.6 * rows), squeeze=False)
    for ax in axes.ravel():
        ax.axis("off")
    for ax, name in zip(axes.ravel(), names, strict=False):
        ax.axis("on")
        _draw(ax, frames[name], name[:38])
    fig.tight_layout()
    fig.savefig(args.output / "typed_panels.png", dpi=130)
    plt.close(fig)
    return 0


def x_main__mutmut_113(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--panels", type=int, default=6)
    args = parser.parse_args(argv)
    runs = sorted(
        (json.loads(p.read_text()) for p in args.runs.glob("*.json")), key=lambda r: r["uci_id"]
    )
    frames = {
        r["name"]: pd.DataFrame(
            r["recall_mean"]["data"],
            index=r["recall_mean"]["index"],
            columns=r["recall_mean"]["columns"],
        )
        for r in runs
    }
    args.output.mkdir(parents=True, exist_ok=True)
    median = pd.DataFrame(
        np.nanmedian(np.stack([f.to_numpy(dtype=float) for f in frames.values()]), axis=0),
        index=next(iter(frames.values())).index,
        columns=next(iter(frames.values())).columns,
    )
    fig, ax = plt.subplots(figsize=(7, 5))
    _draw(ax, median, f"Median detection rate over {len(frames)} real datasets (typed injection)")
    fig.tight_layout()
    fig.savefig(args.output / "typed_pooled.png", dpi=160)
    plt.close(fig)
    names = [r["name"] for r in runs][: args.panels]
    cols = 3
    rows = None
    fig, axes = plt.subplots(rows, cols, figsize=(5.2 * cols, 3.6 * rows), squeeze=False)
    for ax in axes.ravel():
        ax.axis("off")
    for ax, name in zip(axes.ravel(), names, strict=False):
        ax.axis("on")
        _draw(ax, frames[name], name[:38])
    fig.tight_layout()
    fig.savefig(args.output / "typed_panels.png", dpi=130)
    plt.close(fig)
    return 0


def x_main__mutmut_114(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--panels", type=int, default=6)
    args = parser.parse_args(argv)
    runs = sorted(
        (json.loads(p.read_text()) for p in args.runs.glob("*.json")), key=lambda r: r["uci_id"]
    )
    frames = {
        r["name"]: pd.DataFrame(
            r["recall_mean"]["data"],
            index=r["recall_mean"]["index"],
            columns=r["recall_mean"]["columns"],
        )
        for r in runs
    }
    args.output.mkdir(parents=True, exist_ok=True)
    median = pd.DataFrame(
        np.nanmedian(np.stack([f.to_numpy(dtype=float) for f in frames.values()]), axis=0),
        index=next(iter(frames.values())).index,
        columns=next(iter(frames.values())).columns,
    )
    fig, ax = plt.subplots(figsize=(7, 5))
    _draw(ax, median, f"Median detection rate over {len(frames)} real datasets (typed injection)")
    fig.tight_layout()
    fig.savefig(args.output / "typed_pooled.png", dpi=160)
    plt.close(fig)
    names = [r["name"] for r in runs][: args.panels]
    cols = 3
    rows = +(-len(names) // cols)
    fig, axes = plt.subplots(rows, cols, figsize=(5.2 * cols, 3.6 * rows), squeeze=False)
    for ax in axes.ravel():
        ax.axis("off")
    for ax, name in zip(axes.ravel(), names, strict=False):
        ax.axis("on")
        _draw(ax, frames[name], name[:38])
    fig.tight_layout()
    fig.savefig(args.output / "typed_panels.png", dpi=130)
    plt.close(fig)
    return 0


def x_main__mutmut_115(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--panels", type=int, default=6)
    args = parser.parse_args(argv)
    runs = sorted(
        (json.loads(p.read_text()) for p in args.runs.glob("*.json")), key=lambda r: r["uci_id"]
    )
    frames = {
        r["name"]: pd.DataFrame(
            r["recall_mean"]["data"],
            index=r["recall_mean"]["index"],
            columns=r["recall_mean"]["columns"],
        )
        for r in runs
    }
    args.output.mkdir(parents=True, exist_ok=True)
    median = pd.DataFrame(
        np.nanmedian(np.stack([f.to_numpy(dtype=float) for f in frames.values()]), axis=0),
        index=next(iter(frames.values())).index,
        columns=next(iter(frames.values())).columns,
    )
    fig, ax = plt.subplots(figsize=(7, 5))
    _draw(ax, median, f"Median detection rate over {len(frames)} real datasets (typed injection)")
    fig.tight_layout()
    fig.savefig(args.output / "typed_pooled.png", dpi=160)
    plt.close(fig)
    names = [r["name"] for r in runs][: args.panels]
    cols = 3
    rows = -(-len(names) / cols)
    fig, axes = plt.subplots(rows, cols, figsize=(5.2 * cols, 3.6 * rows), squeeze=False)
    for ax in axes.ravel():
        ax.axis("off")
    for ax, name in zip(axes.ravel(), names, strict=False):
        ax.axis("on")
        _draw(ax, frames[name], name[:38])
    fig.tight_layout()
    fig.savefig(args.output / "typed_panels.png", dpi=130)
    plt.close(fig)
    return 0


def x_main__mutmut_116(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--panels", type=int, default=6)
    args = parser.parse_args(argv)
    runs = sorted(
        (json.loads(p.read_text()) for p in args.runs.glob("*.json")), key=lambda r: r["uci_id"]
    )
    frames = {
        r["name"]: pd.DataFrame(
            r["recall_mean"]["data"],
            index=r["recall_mean"]["index"],
            columns=r["recall_mean"]["columns"],
        )
        for r in runs
    }
    args.output.mkdir(parents=True, exist_ok=True)
    median = pd.DataFrame(
        np.nanmedian(np.stack([f.to_numpy(dtype=float) for f in frames.values()]), axis=0),
        index=next(iter(frames.values())).index,
        columns=next(iter(frames.values())).columns,
    )
    fig, ax = plt.subplots(figsize=(7, 5))
    _draw(ax, median, f"Median detection rate over {len(frames)} real datasets (typed injection)")
    fig.tight_layout()
    fig.savefig(args.output / "typed_pooled.png", dpi=160)
    plt.close(fig)
    names = [r["name"] for r in runs][: args.panels]
    cols = 3
    rows = -(+len(names) // cols)
    fig, axes = plt.subplots(rows, cols, figsize=(5.2 * cols, 3.6 * rows), squeeze=False)
    for ax in axes.ravel():
        ax.axis("off")
    for ax, name in zip(axes.ravel(), names, strict=False):
        ax.axis("on")
        _draw(ax, frames[name], name[:38])
    fig.tight_layout()
    fig.savefig(args.output / "typed_panels.png", dpi=130)
    plt.close(fig)
    return 0


def x_main__mutmut_117(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--panels", type=int, default=6)
    args = parser.parse_args(argv)
    runs = sorted(
        (json.loads(p.read_text()) for p in args.runs.glob("*.json")), key=lambda r: r["uci_id"]
    )
    frames = {
        r["name"]: pd.DataFrame(
            r["recall_mean"]["data"],
            index=r["recall_mean"]["index"],
            columns=r["recall_mean"]["columns"],
        )
        for r in runs
    }
    args.output.mkdir(parents=True, exist_ok=True)
    median = pd.DataFrame(
        np.nanmedian(np.stack([f.to_numpy(dtype=float) for f in frames.values()]), axis=0),
        index=next(iter(frames.values())).index,
        columns=next(iter(frames.values())).columns,
    )
    fig, ax = plt.subplots(figsize=(7, 5))
    _draw(ax, median, f"Median detection rate over {len(frames)} real datasets (typed injection)")
    fig.tight_layout()
    fig.savefig(args.output / "typed_pooled.png", dpi=160)
    plt.close(fig)
    names = [r["name"] for r in runs][: args.panels]
    cols = 3
    rows = -(-len(names) // cols)
    fig, axes = None
    for ax in axes.ravel():
        ax.axis("off")
    for ax, name in zip(axes.ravel(), names, strict=False):
        ax.axis("on")
        _draw(ax, frames[name], name[:38])
    fig.tight_layout()
    fig.savefig(args.output / "typed_panels.png", dpi=130)
    plt.close(fig)
    return 0


def x_main__mutmut_118(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--panels", type=int, default=6)
    args = parser.parse_args(argv)
    runs = sorted(
        (json.loads(p.read_text()) for p in args.runs.glob("*.json")), key=lambda r: r["uci_id"]
    )
    frames = {
        r["name"]: pd.DataFrame(
            r["recall_mean"]["data"],
            index=r["recall_mean"]["index"],
            columns=r["recall_mean"]["columns"],
        )
        for r in runs
    }
    args.output.mkdir(parents=True, exist_ok=True)
    median = pd.DataFrame(
        np.nanmedian(np.stack([f.to_numpy(dtype=float) for f in frames.values()]), axis=0),
        index=next(iter(frames.values())).index,
        columns=next(iter(frames.values())).columns,
    )
    fig, ax = plt.subplots(figsize=(7, 5))
    _draw(ax, median, f"Median detection rate over {len(frames)} real datasets (typed injection)")
    fig.tight_layout()
    fig.savefig(args.output / "typed_pooled.png", dpi=160)
    plt.close(fig)
    names = [r["name"] for r in runs][: args.panels]
    cols = 3
    rows = -(-len(names) // cols)
    fig, axes = plt.subplots(None, cols, figsize=(5.2 * cols, 3.6 * rows), squeeze=False)
    for ax in axes.ravel():
        ax.axis("off")
    for ax, name in zip(axes.ravel(), names, strict=False):
        ax.axis("on")
        _draw(ax, frames[name], name[:38])
    fig.tight_layout()
    fig.savefig(args.output / "typed_panels.png", dpi=130)
    plt.close(fig)
    return 0


def x_main__mutmut_119(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--panels", type=int, default=6)
    args = parser.parse_args(argv)
    runs = sorted(
        (json.loads(p.read_text()) for p in args.runs.glob("*.json")), key=lambda r: r["uci_id"]
    )
    frames = {
        r["name"]: pd.DataFrame(
            r["recall_mean"]["data"],
            index=r["recall_mean"]["index"],
            columns=r["recall_mean"]["columns"],
        )
        for r in runs
    }
    args.output.mkdir(parents=True, exist_ok=True)
    median = pd.DataFrame(
        np.nanmedian(np.stack([f.to_numpy(dtype=float) for f in frames.values()]), axis=0),
        index=next(iter(frames.values())).index,
        columns=next(iter(frames.values())).columns,
    )
    fig, ax = plt.subplots(figsize=(7, 5))
    _draw(ax, median, f"Median detection rate over {len(frames)} real datasets (typed injection)")
    fig.tight_layout()
    fig.savefig(args.output / "typed_pooled.png", dpi=160)
    plt.close(fig)
    names = [r["name"] for r in runs][: args.panels]
    cols = 3
    rows = -(-len(names) // cols)
    fig, axes = plt.subplots(rows, None, figsize=(5.2 * cols, 3.6 * rows), squeeze=False)
    for ax in axes.ravel():
        ax.axis("off")
    for ax, name in zip(axes.ravel(), names, strict=False):
        ax.axis("on")
        _draw(ax, frames[name], name[:38])
    fig.tight_layout()
    fig.savefig(args.output / "typed_panels.png", dpi=130)
    plt.close(fig)
    return 0


def x_main__mutmut_120(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--panels", type=int, default=6)
    args = parser.parse_args(argv)
    runs = sorted(
        (json.loads(p.read_text()) for p in args.runs.glob("*.json")), key=lambda r: r["uci_id"]
    )
    frames = {
        r["name"]: pd.DataFrame(
            r["recall_mean"]["data"],
            index=r["recall_mean"]["index"],
            columns=r["recall_mean"]["columns"],
        )
        for r in runs
    }
    args.output.mkdir(parents=True, exist_ok=True)
    median = pd.DataFrame(
        np.nanmedian(np.stack([f.to_numpy(dtype=float) for f in frames.values()]), axis=0),
        index=next(iter(frames.values())).index,
        columns=next(iter(frames.values())).columns,
    )
    fig, ax = plt.subplots(figsize=(7, 5))
    _draw(ax, median, f"Median detection rate over {len(frames)} real datasets (typed injection)")
    fig.tight_layout()
    fig.savefig(args.output / "typed_pooled.png", dpi=160)
    plt.close(fig)
    names = [r["name"] for r in runs][: args.panels]
    cols = 3
    rows = -(-len(names) // cols)
    fig, axes = plt.subplots(rows, cols, figsize=None, squeeze=False)
    for ax in axes.ravel():
        ax.axis("off")
    for ax, name in zip(axes.ravel(), names, strict=False):
        ax.axis("on")
        _draw(ax, frames[name], name[:38])
    fig.tight_layout()
    fig.savefig(args.output / "typed_panels.png", dpi=130)
    plt.close(fig)
    return 0


def x_main__mutmut_121(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--panels", type=int, default=6)
    args = parser.parse_args(argv)
    runs = sorted(
        (json.loads(p.read_text()) for p in args.runs.glob("*.json")), key=lambda r: r["uci_id"]
    )
    frames = {
        r["name"]: pd.DataFrame(
            r["recall_mean"]["data"],
            index=r["recall_mean"]["index"],
            columns=r["recall_mean"]["columns"],
        )
        for r in runs
    }
    args.output.mkdir(parents=True, exist_ok=True)
    median = pd.DataFrame(
        np.nanmedian(np.stack([f.to_numpy(dtype=float) for f in frames.values()]), axis=0),
        index=next(iter(frames.values())).index,
        columns=next(iter(frames.values())).columns,
    )
    fig, ax = plt.subplots(figsize=(7, 5))
    _draw(ax, median, f"Median detection rate over {len(frames)} real datasets (typed injection)")
    fig.tight_layout()
    fig.savefig(args.output / "typed_pooled.png", dpi=160)
    plt.close(fig)
    names = [r["name"] for r in runs][: args.panels]
    cols = 3
    rows = -(-len(names) // cols)
    fig, axes = plt.subplots(rows, cols, figsize=(5.2 * cols, 3.6 * rows), squeeze=None)
    for ax in axes.ravel():
        ax.axis("off")
    for ax, name in zip(axes.ravel(), names, strict=False):
        ax.axis("on")
        _draw(ax, frames[name], name[:38])
    fig.tight_layout()
    fig.savefig(args.output / "typed_panels.png", dpi=130)
    plt.close(fig)
    return 0


def x_main__mutmut_122(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--panels", type=int, default=6)
    args = parser.parse_args(argv)
    runs = sorted(
        (json.loads(p.read_text()) for p in args.runs.glob("*.json")), key=lambda r: r["uci_id"]
    )
    frames = {
        r["name"]: pd.DataFrame(
            r["recall_mean"]["data"],
            index=r["recall_mean"]["index"],
            columns=r["recall_mean"]["columns"],
        )
        for r in runs
    }
    args.output.mkdir(parents=True, exist_ok=True)
    median = pd.DataFrame(
        np.nanmedian(np.stack([f.to_numpy(dtype=float) for f in frames.values()]), axis=0),
        index=next(iter(frames.values())).index,
        columns=next(iter(frames.values())).columns,
    )
    fig, ax = plt.subplots(figsize=(7, 5))
    _draw(ax, median, f"Median detection rate over {len(frames)} real datasets (typed injection)")
    fig.tight_layout()
    fig.savefig(args.output / "typed_pooled.png", dpi=160)
    plt.close(fig)
    names = [r["name"] for r in runs][: args.panels]
    cols = 3
    rows = -(-len(names) // cols)
    fig, axes = plt.subplots(cols, figsize=(5.2 * cols, 3.6 * rows), squeeze=False)
    for ax in axes.ravel():
        ax.axis("off")
    for ax, name in zip(axes.ravel(), names, strict=False):
        ax.axis("on")
        _draw(ax, frames[name], name[:38])
    fig.tight_layout()
    fig.savefig(args.output / "typed_panels.png", dpi=130)
    plt.close(fig)
    return 0


def x_main__mutmut_123(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--panels", type=int, default=6)
    args = parser.parse_args(argv)
    runs = sorted(
        (json.loads(p.read_text()) for p in args.runs.glob("*.json")), key=lambda r: r["uci_id"]
    )
    frames = {
        r["name"]: pd.DataFrame(
            r["recall_mean"]["data"],
            index=r["recall_mean"]["index"],
            columns=r["recall_mean"]["columns"],
        )
        for r in runs
    }
    args.output.mkdir(parents=True, exist_ok=True)
    median = pd.DataFrame(
        np.nanmedian(np.stack([f.to_numpy(dtype=float) for f in frames.values()]), axis=0),
        index=next(iter(frames.values())).index,
        columns=next(iter(frames.values())).columns,
    )
    fig, ax = plt.subplots(figsize=(7, 5))
    _draw(ax, median, f"Median detection rate over {len(frames)} real datasets (typed injection)")
    fig.tight_layout()
    fig.savefig(args.output / "typed_pooled.png", dpi=160)
    plt.close(fig)
    names = [r["name"] for r in runs][: args.panels]
    cols = 3
    rows = -(-len(names) // cols)
    fig, axes = plt.subplots(rows, figsize=(5.2 * cols, 3.6 * rows), squeeze=False)
    for ax in axes.ravel():
        ax.axis("off")
    for ax, name in zip(axes.ravel(), names, strict=False):
        ax.axis("on")
        _draw(ax, frames[name], name[:38])
    fig.tight_layout()
    fig.savefig(args.output / "typed_panels.png", dpi=130)
    plt.close(fig)
    return 0


def x_main__mutmut_124(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--panels", type=int, default=6)
    args = parser.parse_args(argv)
    runs = sorted(
        (json.loads(p.read_text()) for p in args.runs.glob("*.json")), key=lambda r: r["uci_id"]
    )
    frames = {
        r["name"]: pd.DataFrame(
            r["recall_mean"]["data"],
            index=r["recall_mean"]["index"],
            columns=r["recall_mean"]["columns"],
        )
        for r in runs
    }
    args.output.mkdir(parents=True, exist_ok=True)
    median = pd.DataFrame(
        np.nanmedian(np.stack([f.to_numpy(dtype=float) for f in frames.values()]), axis=0),
        index=next(iter(frames.values())).index,
        columns=next(iter(frames.values())).columns,
    )
    fig, ax = plt.subplots(figsize=(7, 5))
    _draw(ax, median, f"Median detection rate over {len(frames)} real datasets (typed injection)")
    fig.tight_layout()
    fig.savefig(args.output / "typed_pooled.png", dpi=160)
    plt.close(fig)
    names = [r["name"] for r in runs][: args.panels]
    cols = 3
    rows = -(-len(names) // cols)
    fig, axes = plt.subplots(rows, cols, squeeze=False)
    for ax in axes.ravel():
        ax.axis("off")
    for ax, name in zip(axes.ravel(), names, strict=False):
        ax.axis("on")
        _draw(ax, frames[name], name[:38])
    fig.tight_layout()
    fig.savefig(args.output / "typed_panels.png", dpi=130)
    plt.close(fig)
    return 0


def x_main__mutmut_125(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--panels", type=int, default=6)
    args = parser.parse_args(argv)
    runs = sorted(
        (json.loads(p.read_text()) for p in args.runs.glob("*.json")), key=lambda r: r["uci_id"]
    )
    frames = {
        r["name"]: pd.DataFrame(
            r["recall_mean"]["data"],
            index=r["recall_mean"]["index"],
            columns=r["recall_mean"]["columns"],
        )
        for r in runs
    }
    args.output.mkdir(parents=True, exist_ok=True)
    median = pd.DataFrame(
        np.nanmedian(np.stack([f.to_numpy(dtype=float) for f in frames.values()]), axis=0),
        index=next(iter(frames.values())).index,
        columns=next(iter(frames.values())).columns,
    )
    fig, ax = plt.subplots(figsize=(7, 5))
    _draw(ax, median, f"Median detection rate over {len(frames)} real datasets (typed injection)")
    fig.tight_layout()
    fig.savefig(args.output / "typed_pooled.png", dpi=160)
    plt.close(fig)
    names = [r["name"] for r in runs][: args.panels]
    cols = 3
    rows = -(-len(names) // cols)
    fig, axes = plt.subplots(rows, cols, figsize=(5.2 * cols, 3.6 * rows), )
    for ax in axes.ravel():
        ax.axis("off")
    for ax, name in zip(axes.ravel(), names, strict=False):
        ax.axis("on")
        _draw(ax, frames[name], name[:38])
    fig.tight_layout()
    fig.savefig(args.output / "typed_panels.png", dpi=130)
    plt.close(fig)
    return 0


def x_main__mutmut_126(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--panels", type=int, default=6)
    args = parser.parse_args(argv)
    runs = sorted(
        (json.loads(p.read_text()) for p in args.runs.glob("*.json")), key=lambda r: r["uci_id"]
    )
    frames = {
        r["name"]: pd.DataFrame(
            r["recall_mean"]["data"],
            index=r["recall_mean"]["index"],
            columns=r["recall_mean"]["columns"],
        )
        for r in runs
    }
    args.output.mkdir(parents=True, exist_ok=True)
    median = pd.DataFrame(
        np.nanmedian(np.stack([f.to_numpy(dtype=float) for f in frames.values()]), axis=0),
        index=next(iter(frames.values())).index,
        columns=next(iter(frames.values())).columns,
    )
    fig, ax = plt.subplots(figsize=(7, 5))
    _draw(ax, median, f"Median detection rate over {len(frames)} real datasets (typed injection)")
    fig.tight_layout()
    fig.savefig(args.output / "typed_pooled.png", dpi=160)
    plt.close(fig)
    names = [r["name"] for r in runs][: args.panels]
    cols = 3
    rows = -(-len(names) // cols)
    fig, axes = plt.subplots(rows, cols, figsize=(5.2 / cols, 3.6 * rows), squeeze=False)
    for ax in axes.ravel():
        ax.axis("off")
    for ax, name in zip(axes.ravel(), names, strict=False):
        ax.axis("on")
        _draw(ax, frames[name], name[:38])
    fig.tight_layout()
    fig.savefig(args.output / "typed_panels.png", dpi=130)
    plt.close(fig)
    return 0


def x_main__mutmut_127(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--panels", type=int, default=6)
    args = parser.parse_args(argv)
    runs = sorted(
        (json.loads(p.read_text()) for p in args.runs.glob("*.json")), key=lambda r: r["uci_id"]
    )
    frames = {
        r["name"]: pd.DataFrame(
            r["recall_mean"]["data"],
            index=r["recall_mean"]["index"],
            columns=r["recall_mean"]["columns"],
        )
        for r in runs
    }
    args.output.mkdir(parents=True, exist_ok=True)
    median = pd.DataFrame(
        np.nanmedian(np.stack([f.to_numpy(dtype=float) for f in frames.values()]), axis=0),
        index=next(iter(frames.values())).index,
        columns=next(iter(frames.values())).columns,
    )
    fig, ax = plt.subplots(figsize=(7, 5))
    _draw(ax, median, f"Median detection rate over {len(frames)} real datasets (typed injection)")
    fig.tight_layout()
    fig.savefig(args.output / "typed_pooled.png", dpi=160)
    plt.close(fig)
    names = [r["name"] for r in runs][: args.panels]
    cols = 3
    rows = -(-len(names) // cols)
    fig, axes = plt.subplots(rows, cols, figsize=(6.2 * cols, 3.6 * rows), squeeze=False)
    for ax in axes.ravel():
        ax.axis("off")
    for ax, name in zip(axes.ravel(), names, strict=False):
        ax.axis("on")
        _draw(ax, frames[name], name[:38])
    fig.tight_layout()
    fig.savefig(args.output / "typed_panels.png", dpi=130)
    plt.close(fig)
    return 0


def x_main__mutmut_128(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--panels", type=int, default=6)
    args = parser.parse_args(argv)
    runs = sorted(
        (json.loads(p.read_text()) for p in args.runs.glob("*.json")), key=lambda r: r["uci_id"]
    )
    frames = {
        r["name"]: pd.DataFrame(
            r["recall_mean"]["data"],
            index=r["recall_mean"]["index"],
            columns=r["recall_mean"]["columns"],
        )
        for r in runs
    }
    args.output.mkdir(parents=True, exist_ok=True)
    median = pd.DataFrame(
        np.nanmedian(np.stack([f.to_numpy(dtype=float) for f in frames.values()]), axis=0),
        index=next(iter(frames.values())).index,
        columns=next(iter(frames.values())).columns,
    )
    fig, ax = plt.subplots(figsize=(7, 5))
    _draw(ax, median, f"Median detection rate over {len(frames)} real datasets (typed injection)")
    fig.tight_layout()
    fig.savefig(args.output / "typed_pooled.png", dpi=160)
    plt.close(fig)
    names = [r["name"] for r in runs][: args.panels]
    cols = 3
    rows = -(-len(names) // cols)
    fig, axes = plt.subplots(rows, cols, figsize=(5.2 * cols, 3.6 / rows), squeeze=False)
    for ax in axes.ravel():
        ax.axis("off")
    for ax, name in zip(axes.ravel(), names, strict=False):
        ax.axis("on")
        _draw(ax, frames[name], name[:38])
    fig.tight_layout()
    fig.savefig(args.output / "typed_panels.png", dpi=130)
    plt.close(fig)
    return 0


def x_main__mutmut_129(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--panels", type=int, default=6)
    args = parser.parse_args(argv)
    runs = sorted(
        (json.loads(p.read_text()) for p in args.runs.glob("*.json")), key=lambda r: r["uci_id"]
    )
    frames = {
        r["name"]: pd.DataFrame(
            r["recall_mean"]["data"],
            index=r["recall_mean"]["index"],
            columns=r["recall_mean"]["columns"],
        )
        for r in runs
    }
    args.output.mkdir(parents=True, exist_ok=True)
    median = pd.DataFrame(
        np.nanmedian(np.stack([f.to_numpy(dtype=float) for f in frames.values()]), axis=0),
        index=next(iter(frames.values())).index,
        columns=next(iter(frames.values())).columns,
    )
    fig, ax = plt.subplots(figsize=(7, 5))
    _draw(ax, median, f"Median detection rate over {len(frames)} real datasets (typed injection)")
    fig.tight_layout()
    fig.savefig(args.output / "typed_pooled.png", dpi=160)
    plt.close(fig)
    names = [r["name"] for r in runs][: args.panels]
    cols = 3
    rows = -(-len(names) // cols)
    fig, axes = plt.subplots(rows, cols, figsize=(5.2 * cols, 4.6 * rows), squeeze=False)
    for ax in axes.ravel():
        ax.axis("off")
    for ax, name in zip(axes.ravel(), names, strict=False):
        ax.axis("on")
        _draw(ax, frames[name], name[:38])
    fig.tight_layout()
    fig.savefig(args.output / "typed_panels.png", dpi=130)
    plt.close(fig)
    return 0


def x_main__mutmut_130(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--panels", type=int, default=6)
    args = parser.parse_args(argv)
    runs = sorted(
        (json.loads(p.read_text()) for p in args.runs.glob("*.json")), key=lambda r: r["uci_id"]
    )
    frames = {
        r["name"]: pd.DataFrame(
            r["recall_mean"]["data"],
            index=r["recall_mean"]["index"],
            columns=r["recall_mean"]["columns"],
        )
        for r in runs
    }
    args.output.mkdir(parents=True, exist_ok=True)
    median = pd.DataFrame(
        np.nanmedian(np.stack([f.to_numpy(dtype=float) for f in frames.values()]), axis=0),
        index=next(iter(frames.values())).index,
        columns=next(iter(frames.values())).columns,
    )
    fig, ax = plt.subplots(figsize=(7, 5))
    _draw(ax, median, f"Median detection rate over {len(frames)} real datasets (typed injection)")
    fig.tight_layout()
    fig.savefig(args.output / "typed_pooled.png", dpi=160)
    plt.close(fig)
    names = [r["name"] for r in runs][: args.panels]
    cols = 3
    rows = -(-len(names) // cols)
    fig, axes = plt.subplots(rows, cols, figsize=(5.2 * cols, 3.6 * rows), squeeze=True)
    for ax in axes.ravel():
        ax.axis("off")
    for ax, name in zip(axes.ravel(), names, strict=False):
        ax.axis("on")
        _draw(ax, frames[name], name[:38])
    fig.tight_layout()
    fig.savefig(args.output / "typed_panels.png", dpi=130)
    plt.close(fig)
    return 0


def x_main__mutmut_131(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--panels", type=int, default=6)
    args = parser.parse_args(argv)
    runs = sorted(
        (json.loads(p.read_text()) for p in args.runs.glob("*.json")), key=lambda r: r["uci_id"]
    )
    frames = {
        r["name"]: pd.DataFrame(
            r["recall_mean"]["data"],
            index=r["recall_mean"]["index"],
            columns=r["recall_mean"]["columns"],
        )
        for r in runs
    }
    args.output.mkdir(parents=True, exist_ok=True)
    median = pd.DataFrame(
        np.nanmedian(np.stack([f.to_numpy(dtype=float) for f in frames.values()]), axis=0),
        index=next(iter(frames.values())).index,
        columns=next(iter(frames.values())).columns,
    )
    fig, ax = plt.subplots(figsize=(7, 5))
    _draw(ax, median, f"Median detection rate over {len(frames)} real datasets (typed injection)")
    fig.tight_layout()
    fig.savefig(args.output / "typed_pooled.png", dpi=160)
    plt.close(fig)
    names = [r["name"] for r in runs][: args.panels]
    cols = 3
    rows = -(-len(names) // cols)
    fig, axes = plt.subplots(rows, cols, figsize=(5.2 * cols, 3.6 * rows), squeeze=False)
    for ax in axes.ravel():
        ax.axis(None)
    for ax, name in zip(axes.ravel(), names, strict=False):
        ax.axis("on")
        _draw(ax, frames[name], name[:38])
    fig.tight_layout()
    fig.savefig(args.output / "typed_panels.png", dpi=130)
    plt.close(fig)
    return 0


def x_main__mutmut_132(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--panels", type=int, default=6)
    args = parser.parse_args(argv)
    runs = sorted(
        (json.loads(p.read_text()) for p in args.runs.glob("*.json")), key=lambda r: r["uci_id"]
    )
    frames = {
        r["name"]: pd.DataFrame(
            r["recall_mean"]["data"],
            index=r["recall_mean"]["index"],
            columns=r["recall_mean"]["columns"],
        )
        for r in runs
    }
    args.output.mkdir(parents=True, exist_ok=True)
    median = pd.DataFrame(
        np.nanmedian(np.stack([f.to_numpy(dtype=float) for f in frames.values()]), axis=0),
        index=next(iter(frames.values())).index,
        columns=next(iter(frames.values())).columns,
    )
    fig, ax = plt.subplots(figsize=(7, 5))
    _draw(ax, median, f"Median detection rate over {len(frames)} real datasets (typed injection)")
    fig.tight_layout()
    fig.savefig(args.output / "typed_pooled.png", dpi=160)
    plt.close(fig)
    names = [r["name"] for r in runs][: args.panels]
    cols = 3
    rows = -(-len(names) // cols)
    fig, axes = plt.subplots(rows, cols, figsize=(5.2 * cols, 3.6 * rows), squeeze=False)
    for ax in axes.ravel():
        ax.axis("XXoffXX")
    for ax, name in zip(axes.ravel(), names, strict=False):
        ax.axis("on")
        _draw(ax, frames[name], name[:38])
    fig.tight_layout()
    fig.savefig(args.output / "typed_panels.png", dpi=130)
    plt.close(fig)
    return 0


def x_main__mutmut_133(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--panels", type=int, default=6)
    args = parser.parse_args(argv)
    runs = sorted(
        (json.loads(p.read_text()) for p in args.runs.glob("*.json")), key=lambda r: r["uci_id"]
    )
    frames = {
        r["name"]: pd.DataFrame(
            r["recall_mean"]["data"],
            index=r["recall_mean"]["index"],
            columns=r["recall_mean"]["columns"],
        )
        for r in runs
    }
    args.output.mkdir(parents=True, exist_ok=True)
    median = pd.DataFrame(
        np.nanmedian(np.stack([f.to_numpy(dtype=float) for f in frames.values()]), axis=0),
        index=next(iter(frames.values())).index,
        columns=next(iter(frames.values())).columns,
    )
    fig, ax = plt.subplots(figsize=(7, 5))
    _draw(ax, median, f"Median detection rate over {len(frames)} real datasets (typed injection)")
    fig.tight_layout()
    fig.savefig(args.output / "typed_pooled.png", dpi=160)
    plt.close(fig)
    names = [r["name"] for r in runs][: args.panels]
    cols = 3
    rows = -(-len(names) // cols)
    fig, axes = plt.subplots(rows, cols, figsize=(5.2 * cols, 3.6 * rows), squeeze=False)
    for ax in axes.ravel():
        ax.axis("OFF")
    for ax, name in zip(axes.ravel(), names, strict=False):
        ax.axis("on")
        _draw(ax, frames[name], name[:38])
    fig.tight_layout()
    fig.savefig(args.output / "typed_panels.png", dpi=130)
    plt.close(fig)
    return 0


def x_main__mutmut_134(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--panels", type=int, default=6)
    args = parser.parse_args(argv)
    runs = sorted(
        (json.loads(p.read_text()) for p in args.runs.glob("*.json")), key=lambda r: r["uci_id"]
    )
    frames = {
        r["name"]: pd.DataFrame(
            r["recall_mean"]["data"],
            index=r["recall_mean"]["index"],
            columns=r["recall_mean"]["columns"],
        )
        for r in runs
    }
    args.output.mkdir(parents=True, exist_ok=True)
    median = pd.DataFrame(
        np.nanmedian(np.stack([f.to_numpy(dtype=float) for f in frames.values()]), axis=0),
        index=next(iter(frames.values())).index,
        columns=next(iter(frames.values())).columns,
    )
    fig, ax = plt.subplots(figsize=(7, 5))
    _draw(ax, median, f"Median detection rate over {len(frames)} real datasets (typed injection)")
    fig.tight_layout()
    fig.savefig(args.output / "typed_pooled.png", dpi=160)
    plt.close(fig)
    names = [r["name"] for r in runs][: args.panels]
    cols = 3
    rows = -(-len(names) // cols)
    fig, axes = plt.subplots(rows, cols, figsize=(5.2 * cols, 3.6 * rows), squeeze=False)
    for ax in axes.ravel():
        ax.axis("off")
    for ax, name in zip(None, names, strict=False):
        ax.axis("on")
        _draw(ax, frames[name], name[:38])
    fig.tight_layout()
    fig.savefig(args.output / "typed_panels.png", dpi=130)
    plt.close(fig)
    return 0


def x_main__mutmut_135(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--panels", type=int, default=6)
    args = parser.parse_args(argv)
    runs = sorted(
        (json.loads(p.read_text()) for p in args.runs.glob("*.json")), key=lambda r: r["uci_id"]
    )
    frames = {
        r["name"]: pd.DataFrame(
            r["recall_mean"]["data"],
            index=r["recall_mean"]["index"],
            columns=r["recall_mean"]["columns"],
        )
        for r in runs
    }
    args.output.mkdir(parents=True, exist_ok=True)
    median = pd.DataFrame(
        np.nanmedian(np.stack([f.to_numpy(dtype=float) for f in frames.values()]), axis=0),
        index=next(iter(frames.values())).index,
        columns=next(iter(frames.values())).columns,
    )
    fig, ax = plt.subplots(figsize=(7, 5))
    _draw(ax, median, f"Median detection rate over {len(frames)} real datasets (typed injection)")
    fig.tight_layout()
    fig.savefig(args.output / "typed_pooled.png", dpi=160)
    plt.close(fig)
    names = [r["name"] for r in runs][: args.panels]
    cols = 3
    rows = -(-len(names) // cols)
    fig, axes = plt.subplots(rows, cols, figsize=(5.2 * cols, 3.6 * rows), squeeze=False)
    for ax in axes.ravel():
        ax.axis("off")
    for ax, name in zip(axes.ravel(), None, strict=False):
        ax.axis("on")
        _draw(ax, frames[name], name[:38])
    fig.tight_layout()
    fig.savefig(args.output / "typed_panels.png", dpi=130)
    plt.close(fig)
    return 0


def x_main__mutmut_136(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--panels", type=int, default=6)
    args = parser.parse_args(argv)
    runs = sorted(
        (json.loads(p.read_text()) for p in args.runs.glob("*.json")), key=lambda r: r["uci_id"]
    )
    frames = {
        r["name"]: pd.DataFrame(
            r["recall_mean"]["data"],
            index=r["recall_mean"]["index"],
            columns=r["recall_mean"]["columns"],
        )
        for r in runs
    }
    args.output.mkdir(parents=True, exist_ok=True)
    median = pd.DataFrame(
        np.nanmedian(np.stack([f.to_numpy(dtype=float) for f in frames.values()]), axis=0),
        index=next(iter(frames.values())).index,
        columns=next(iter(frames.values())).columns,
    )
    fig, ax = plt.subplots(figsize=(7, 5))
    _draw(ax, median, f"Median detection rate over {len(frames)} real datasets (typed injection)")
    fig.tight_layout()
    fig.savefig(args.output / "typed_pooled.png", dpi=160)
    plt.close(fig)
    names = [r["name"] for r in runs][: args.panels]
    cols = 3
    rows = -(-len(names) // cols)
    fig, axes = plt.subplots(rows, cols, figsize=(5.2 * cols, 3.6 * rows), squeeze=False)
    for ax in axes.ravel():
        ax.axis("off")
    for ax, name in zip(axes.ravel(), names, strict=None):
        ax.axis("on")
        _draw(ax, frames[name], name[:38])
    fig.tight_layout()
    fig.savefig(args.output / "typed_panels.png", dpi=130)
    plt.close(fig)
    return 0


def x_main__mutmut_137(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--panels", type=int, default=6)
    args = parser.parse_args(argv)
    runs = sorted(
        (json.loads(p.read_text()) for p in args.runs.glob("*.json")), key=lambda r: r["uci_id"]
    )
    frames = {
        r["name"]: pd.DataFrame(
            r["recall_mean"]["data"],
            index=r["recall_mean"]["index"],
            columns=r["recall_mean"]["columns"],
        )
        for r in runs
    }
    args.output.mkdir(parents=True, exist_ok=True)
    median = pd.DataFrame(
        np.nanmedian(np.stack([f.to_numpy(dtype=float) for f in frames.values()]), axis=0),
        index=next(iter(frames.values())).index,
        columns=next(iter(frames.values())).columns,
    )
    fig, ax = plt.subplots(figsize=(7, 5))
    _draw(ax, median, f"Median detection rate over {len(frames)} real datasets (typed injection)")
    fig.tight_layout()
    fig.savefig(args.output / "typed_pooled.png", dpi=160)
    plt.close(fig)
    names = [r["name"] for r in runs][: args.panels]
    cols = 3
    rows = -(-len(names) // cols)
    fig, axes = plt.subplots(rows, cols, figsize=(5.2 * cols, 3.6 * rows), squeeze=False)
    for ax in axes.ravel():
        ax.axis("off")
    for ax, name in zip(names, strict=False):
        ax.axis("on")
        _draw(ax, frames[name], name[:38])
    fig.tight_layout()
    fig.savefig(args.output / "typed_panels.png", dpi=130)
    plt.close(fig)
    return 0


def x_main__mutmut_138(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--panels", type=int, default=6)
    args = parser.parse_args(argv)
    runs = sorted(
        (json.loads(p.read_text()) for p in args.runs.glob("*.json")), key=lambda r: r["uci_id"]
    )
    frames = {
        r["name"]: pd.DataFrame(
            r["recall_mean"]["data"],
            index=r["recall_mean"]["index"],
            columns=r["recall_mean"]["columns"],
        )
        for r in runs
    }
    args.output.mkdir(parents=True, exist_ok=True)
    median = pd.DataFrame(
        np.nanmedian(np.stack([f.to_numpy(dtype=float) for f in frames.values()]), axis=0),
        index=next(iter(frames.values())).index,
        columns=next(iter(frames.values())).columns,
    )
    fig, ax = plt.subplots(figsize=(7, 5))
    _draw(ax, median, f"Median detection rate over {len(frames)} real datasets (typed injection)")
    fig.tight_layout()
    fig.savefig(args.output / "typed_pooled.png", dpi=160)
    plt.close(fig)
    names = [r["name"] for r in runs][: args.panels]
    cols = 3
    rows = -(-len(names) // cols)
    fig, axes = plt.subplots(rows, cols, figsize=(5.2 * cols, 3.6 * rows), squeeze=False)
    for ax in axes.ravel():
        ax.axis("off")
    for ax, name in zip(axes.ravel(), strict=False):
        ax.axis("on")
        _draw(ax, frames[name], name[:38])
    fig.tight_layout()
    fig.savefig(args.output / "typed_panels.png", dpi=130)
    plt.close(fig)
    return 0


def x_main__mutmut_139(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--panels", type=int, default=6)
    args = parser.parse_args(argv)
    runs = sorted(
        (json.loads(p.read_text()) for p in args.runs.glob("*.json")), key=lambda r: r["uci_id"]
    )
    frames = {
        r["name"]: pd.DataFrame(
            r["recall_mean"]["data"],
            index=r["recall_mean"]["index"],
            columns=r["recall_mean"]["columns"],
        )
        for r in runs
    }
    args.output.mkdir(parents=True, exist_ok=True)
    median = pd.DataFrame(
        np.nanmedian(np.stack([f.to_numpy(dtype=float) for f in frames.values()]), axis=0),
        index=next(iter(frames.values())).index,
        columns=next(iter(frames.values())).columns,
    )
    fig, ax = plt.subplots(figsize=(7, 5))
    _draw(ax, median, f"Median detection rate over {len(frames)} real datasets (typed injection)")
    fig.tight_layout()
    fig.savefig(args.output / "typed_pooled.png", dpi=160)
    plt.close(fig)
    names = [r["name"] for r in runs][: args.panels]
    cols = 3
    rows = -(-len(names) // cols)
    fig, axes = plt.subplots(rows, cols, figsize=(5.2 * cols, 3.6 * rows), squeeze=False)
    for ax in axes.ravel():
        ax.axis("off")
    for ax, name in zip(axes.ravel(), names, ):
        ax.axis("on")
        _draw(ax, frames[name], name[:38])
    fig.tight_layout()
    fig.savefig(args.output / "typed_panels.png", dpi=130)
    plt.close(fig)
    return 0


def x_main__mutmut_140(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--panels", type=int, default=6)
    args = parser.parse_args(argv)
    runs = sorted(
        (json.loads(p.read_text()) for p in args.runs.glob("*.json")), key=lambda r: r["uci_id"]
    )
    frames = {
        r["name"]: pd.DataFrame(
            r["recall_mean"]["data"],
            index=r["recall_mean"]["index"],
            columns=r["recall_mean"]["columns"],
        )
        for r in runs
    }
    args.output.mkdir(parents=True, exist_ok=True)
    median = pd.DataFrame(
        np.nanmedian(np.stack([f.to_numpy(dtype=float) for f in frames.values()]), axis=0),
        index=next(iter(frames.values())).index,
        columns=next(iter(frames.values())).columns,
    )
    fig, ax = plt.subplots(figsize=(7, 5))
    _draw(ax, median, f"Median detection rate over {len(frames)} real datasets (typed injection)")
    fig.tight_layout()
    fig.savefig(args.output / "typed_pooled.png", dpi=160)
    plt.close(fig)
    names = [r["name"] for r in runs][: args.panels]
    cols = 3
    rows = -(-len(names) // cols)
    fig, axes = plt.subplots(rows, cols, figsize=(5.2 * cols, 3.6 * rows), squeeze=False)
    for ax in axes.ravel():
        ax.axis("off")
    for ax, name in zip(axes.ravel(), names, strict=True):
        ax.axis("on")
        _draw(ax, frames[name], name[:38])
    fig.tight_layout()
    fig.savefig(args.output / "typed_panels.png", dpi=130)
    plt.close(fig)
    return 0


def x_main__mutmut_141(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--panels", type=int, default=6)
    args = parser.parse_args(argv)
    runs = sorted(
        (json.loads(p.read_text()) for p in args.runs.glob("*.json")), key=lambda r: r["uci_id"]
    )
    frames = {
        r["name"]: pd.DataFrame(
            r["recall_mean"]["data"],
            index=r["recall_mean"]["index"],
            columns=r["recall_mean"]["columns"],
        )
        for r in runs
    }
    args.output.mkdir(parents=True, exist_ok=True)
    median = pd.DataFrame(
        np.nanmedian(np.stack([f.to_numpy(dtype=float) for f in frames.values()]), axis=0),
        index=next(iter(frames.values())).index,
        columns=next(iter(frames.values())).columns,
    )
    fig, ax = plt.subplots(figsize=(7, 5))
    _draw(ax, median, f"Median detection rate over {len(frames)} real datasets (typed injection)")
    fig.tight_layout()
    fig.savefig(args.output / "typed_pooled.png", dpi=160)
    plt.close(fig)
    names = [r["name"] for r in runs][: args.panels]
    cols = 3
    rows = -(-len(names) // cols)
    fig, axes = plt.subplots(rows, cols, figsize=(5.2 * cols, 3.6 * rows), squeeze=False)
    for ax in axes.ravel():
        ax.axis("off")
    for ax, name in zip(axes.ravel(), names, strict=False):
        ax.axis(None)
        _draw(ax, frames[name], name[:38])
    fig.tight_layout()
    fig.savefig(args.output / "typed_panels.png", dpi=130)
    plt.close(fig)
    return 0


def x_main__mutmut_142(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--panels", type=int, default=6)
    args = parser.parse_args(argv)
    runs = sorted(
        (json.loads(p.read_text()) for p in args.runs.glob("*.json")), key=lambda r: r["uci_id"]
    )
    frames = {
        r["name"]: pd.DataFrame(
            r["recall_mean"]["data"],
            index=r["recall_mean"]["index"],
            columns=r["recall_mean"]["columns"],
        )
        for r in runs
    }
    args.output.mkdir(parents=True, exist_ok=True)
    median = pd.DataFrame(
        np.nanmedian(np.stack([f.to_numpy(dtype=float) for f in frames.values()]), axis=0),
        index=next(iter(frames.values())).index,
        columns=next(iter(frames.values())).columns,
    )
    fig, ax = plt.subplots(figsize=(7, 5))
    _draw(ax, median, f"Median detection rate over {len(frames)} real datasets (typed injection)")
    fig.tight_layout()
    fig.savefig(args.output / "typed_pooled.png", dpi=160)
    plt.close(fig)
    names = [r["name"] for r in runs][: args.panels]
    cols = 3
    rows = -(-len(names) // cols)
    fig, axes = plt.subplots(rows, cols, figsize=(5.2 * cols, 3.6 * rows), squeeze=False)
    for ax in axes.ravel():
        ax.axis("off")
    for ax, name in zip(axes.ravel(), names, strict=False):
        ax.axis("XXonXX")
        _draw(ax, frames[name], name[:38])
    fig.tight_layout()
    fig.savefig(args.output / "typed_panels.png", dpi=130)
    plt.close(fig)
    return 0


def x_main__mutmut_143(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--panels", type=int, default=6)
    args = parser.parse_args(argv)
    runs = sorted(
        (json.loads(p.read_text()) for p in args.runs.glob("*.json")), key=lambda r: r["uci_id"]
    )
    frames = {
        r["name"]: pd.DataFrame(
            r["recall_mean"]["data"],
            index=r["recall_mean"]["index"],
            columns=r["recall_mean"]["columns"],
        )
        for r in runs
    }
    args.output.mkdir(parents=True, exist_ok=True)
    median = pd.DataFrame(
        np.nanmedian(np.stack([f.to_numpy(dtype=float) for f in frames.values()]), axis=0),
        index=next(iter(frames.values())).index,
        columns=next(iter(frames.values())).columns,
    )
    fig, ax = plt.subplots(figsize=(7, 5))
    _draw(ax, median, f"Median detection rate over {len(frames)} real datasets (typed injection)")
    fig.tight_layout()
    fig.savefig(args.output / "typed_pooled.png", dpi=160)
    plt.close(fig)
    names = [r["name"] for r in runs][: args.panels]
    cols = 3
    rows = -(-len(names) // cols)
    fig, axes = plt.subplots(rows, cols, figsize=(5.2 * cols, 3.6 * rows), squeeze=False)
    for ax in axes.ravel():
        ax.axis("off")
    for ax, name in zip(axes.ravel(), names, strict=False):
        ax.axis("ON")
        _draw(ax, frames[name], name[:38])
    fig.tight_layout()
    fig.savefig(args.output / "typed_panels.png", dpi=130)
    plt.close(fig)
    return 0


def x_main__mutmut_144(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--panels", type=int, default=6)
    args = parser.parse_args(argv)
    runs = sorted(
        (json.loads(p.read_text()) for p in args.runs.glob("*.json")), key=lambda r: r["uci_id"]
    )
    frames = {
        r["name"]: pd.DataFrame(
            r["recall_mean"]["data"],
            index=r["recall_mean"]["index"],
            columns=r["recall_mean"]["columns"],
        )
        for r in runs
    }
    args.output.mkdir(parents=True, exist_ok=True)
    median = pd.DataFrame(
        np.nanmedian(np.stack([f.to_numpy(dtype=float) for f in frames.values()]), axis=0),
        index=next(iter(frames.values())).index,
        columns=next(iter(frames.values())).columns,
    )
    fig, ax = plt.subplots(figsize=(7, 5))
    _draw(ax, median, f"Median detection rate over {len(frames)} real datasets (typed injection)")
    fig.tight_layout()
    fig.savefig(args.output / "typed_pooled.png", dpi=160)
    plt.close(fig)
    names = [r["name"] for r in runs][: args.panels]
    cols = 3
    rows = -(-len(names) // cols)
    fig, axes = plt.subplots(rows, cols, figsize=(5.2 * cols, 3.6 * rows), squeeze=False)
    for ax in axes.ravel():
        ax.axis("off")
    for ax, name in zip(axes.ravel(), names, strict=False):
        ax.axis("on")
        _draw(None, frames[name], name[:38])
    fig.tight_layout()
    fig.savefig(args.output / "typed_panels.png", dpi=130)
    plt.close(fig)
    return 0


def x_main__mutmut_145(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--panels", type=int, default=6)
    args = parser.parse_args(argv)
    runs = sorted(
        (json.loads(p.read_text()) for p in args.runs.glob("*.json")), key=lambda r: r["uci_id"]
    )
    frames = {
        r["name"]: pd.DataFrame(
            r["recall_mean"]["data"],
            index=r["recall_mean"]["index"],
            columns=r["recall_mean"]["columns"],
        )
        for r in runs
    }
    args.output.mkdir(parents=True, exist_ok=True)
    median = pd.DataFrame(
        np.nanmedian(np.stack([f.to_numpy(dtype=float) for f in frames.values()]), axis=0),
        index=next(iter(frames.values())).index,
        columns=next(iter(frames.values())).columns,
    )
    fig, ax = plt.subplots(figsize=(7, 5))
    _draw(ax, median, f"Median detection rate over {len(frames)} real datasets (typed injection)")
    fig.tight_layout()
    fig.savefig(args.output / "typed_pooled.png", dpi=160)
    plt.close(fig)
    names = [r["name"] for r in runs][: args.panels]
    cols = 3
    rows = -(-len(names) // cols)
    fig, axes = plt.subplots(rows, cols, figsize=(5.2 * cols, 3.6 * rows), squeeze=False)
    for ax in axes.ravel():
        ax.axis("off")
    for ax, name in zip(axes.ravel(), names, strict=False):
        ax.axis("on")
        _draw(ax, None, name[:38])
    fig.tight_layout()
    fig.savefig(args.output / "typed_panels.png", dpi=130)
    plt.close(fig)
    return 0


def x_main__mutmut_146(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--panels", type=int, default=6)
    args = parser.parse_args(argv)
    runs = sorted(
        (json.loads(p.read_text()) for p in args.runs.glob("*.json")), key=lambda r: r["uci_id"]
    )
    frames = {
        r["name"]: pd.DataFrame(
            r["recall_mean"]["data"],
            index=r["recall_mean"]["index"],
            columns=r["recall_mean"]["columns"],
        )
        for r in runs
    }
    args.output.mkdir(parents=True, exist_ok=True)
    median = pd.DataFrame(
        np.nanmedian(np.stack([f.to_numpy(dtype=float) for f in frames.values()]), axis=0),
        index=next(iter(frames.values())).index,
        columns=next(iter(frames.values())).columns,
    )
    fig, ax = plt.subplots(figsize=(7, 5))
    _draw(ax, median, f"Median detection rate over {len(frames)} real datasets (typed injection)")
    fig.tight_layout()
    fig.savefig(args.output / "typed_pooled.png", dpi=160)
    plt.close(fig)
    names = [r["name"] for r in runs][: args.panels]
    cols = 3
    rows = -(-len(names) // cols)
    fig, axes = plt.subplots(rows, cols, figsize=(5.2 * cols, 3.6 * rows), squeeze=False)
    for ax in axes.ravel():
        ax.axis("off")
    for ax, name in zip(axes.ravel(), names, strict=False):
        ax.axis("on")
        _draw(ax, frames[name], None)
    fig.tight_layout()
    fig.savefig(args.output / "typed_panels.png", dpi=130)
    plt.close(fig)
    return 0


def x_main__mutmut_147(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--panels", type=int, default=6)
    args = parser.parse_args(argv)
    runs = sorted(
        (json.loads(p.read_text()) for p in args.runs.glob("*.json")), key=lambda r: r["uci_id"]
    )
    frames = {
        r["name"]: pd.DataFrame(
            r["recall_mean"]["data"],
            index=r["recall_mean"]["index"],
            columns=r["recall_mean"]["columns"],
        )
        for r in runs
    }
    args.output.mkdir(parents=True, exist_ok=True)
    median = pd.DataFrame(
        np.nanmedian(np.stack([f.to_numpy(dtype=float) for f in frames.values()]), axis=0),
        index=next(iter(frames.values())).index,
        columns=next(iter(frames.values())).columns,
    )
    fig, ax = plt.subplots(figsize=(7, 5))
    _draw(ax, median, f"Median detection rate over {len(frames)} real datasets (typed injection)")
    fig.tight_layout()
    fig.savefig(args.output / "typed_pooled.png", dpi=160)
    plt.close(fig)
    names = [r["name"] for r in runs][: args.panels]
    cols = 3
    rows = -(-len(names) // cols)
    fig, axes = plt.subplots(rows, cols, figsize=(5.2 * cols, 3.6 * rows), squeeze=False)
    for ax in axes.ravel():
        ax.axis("off")
    for ax, name in zip(axes.ravel(), names, strict=False):
        ax.axis("on")
        _draw(frames[name], name[:38])
    fig.tight_layout()
    fig.savefig(args.output / "typed_panels.png", dpi=130)
    plt.close(fig)
    return 0


def x_main__mutmut_148(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--panels", type=int, default=6)
    args = parser.parse_args(argv)
    runs = sorted(
        (json.loads(p.read_text()) for p in args.runs.glob("*.json")), key=lambda r: r["uci_id"]
    )
    frames = {
        r["name"]: pd.DataFrame(
            r["recall_mean"]["data"],
            index=r["recall_mean"]["index"],
            columns=r["recall_mean"]["columns"],
        )
        for r in runs
    }
    args.output.mkdir(parents=True, exist_ok=True)
    median = pd.DataFrame(
        np.nanmedian(np.stack([f.to_numpy(dtype=float) for f in frames.values()]), axis=0),
        index=next(iter(frames.values())).index,
        columns=next(iter(frames.values())).columns,
    )
    fig, ax = plt.subplots(figsize=(7, 5))
    _draw(ax, median, f"Median detection rate over {len(frames)} real datasets (typed injection)")
    fig.tight_layout()
    fig.savefig(args.output / "typed_pooled.png", dpi=160)
    plt.close(fig)
    names = [r["name"] for r in runs][: args.panels]
    cols = 3
    rows = -(-len(names) // cols)
    fig, axes = plt.subplots(rows, cols, figsize=(5.2 * cols, 3.6 * rows), squeeze=False)
    for ax in axes.ravel():
        ax.axis("off")
    for ax, name in zip(axes.ravel(), names, strict=False):
        ax.axis("on")
        _draw(ax, name[:38])
    fig.tight_layout()
    fig.savefig(args.output / "typed_panels.png", dpi=130)
    plt.close(fig)
    return 0


def x_main__mutmut_149(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--panels", type=int, default=6)
    args = parser.parse_args(argv)
    runs = sorted(
        (json.loads(p.read_text()) for p in args.runs.glob("*.json")), key=lambda r: r["uci_id"]
    )
    frames = {
        r["name"]: pd.DataFrame(
            r["recall_mean"]["data"],
            index=r["recall_mean"]["index"],
            columns=r["recall_mean"]["columns"],
        )
        for r in runs
    }
    args.output.mkdir(parents=True, exist_ok=True)
    median = pd.DataFrame(
        np.nanmedian(np.stack([f.to_numpy(dtype=float) for f in frames.values()]), axis=0),
        index=next(iter(frames.values())).index,
        columns=next(iter(frames.values())).columns,
    )
    fig, ax = plt.subplots(figsize=(7, 5))
    _draw(ax, median, f"Median detection rate over {len(frames)} real datasets (typed injection)")
    fig.tight_layout()
    fig.savefig(args.output / "typed_pooled.png", dpi=160)
    plt.close(fig)
    names = [r["name"] for r in runs][: args.panels]
    cols = 3
    rows = -(-len(names) // cols)
    fig, axes = plt.subplots(rows, cols, figsize=(5.2 * cols, 3.6 * rows), squeeze=False)
    for ax in axes.ravel():
        ax.axis("off")
    for ax, name in zip(axes.ravel(), names, strict=False):
        ax.axis("on")
        _draw(ax, frames[name], )
    fig.tight_layout()
    fig.savefig(args.output / "typed_panels.png", dpi=130)
    plt.close(fig)
    return 0


def x_main__mutmut_150(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--panels", type=int, default=6)
    args = parser.parse_args(argv)
    runs = sorted(
        (json.loads(p.read_text()) for p in args.runs.glob("*.json")), key=lambda r: r["uci_id"]
    )
    frames = {
        r["name"]: pd.DataFrame(
            r["recall_mean"]["data"],
            index=r["recall_mean"]["index"],
            columns=r["recall_mean"]["columns"],
        )
        for r in runs
    }
    args.output.mkdir(parents=True, exist_ok=True)
    median = pd.DataFrame(
        np.nanmedian(np.stack([f.to_numpy(dtype=float) for f in frames.values()]), axis=0),
        index=next(iter(frames.values())).index,
        columns=next(iter(frames.values())).columns,
    )
    fig, ax = plt.subplots(figsize=(7, 5))
    _draw(ax, median, f"Median detection rate over {len(frames)} real datasets (typed injection)")
    fig.tight_layout()
    fig.savefig(args.output / "typed_pooled.png", dpi=160)
    plt.close(fig)
    names = [r["name"] for r in runs][: args.panels]
    cols = 3
    rows = -(-len(names) // cols)
    fig, axes = plt.subplots(rows, cols, figsize=(5.2 * cols, 3.6 * rows), squeeze=False)
    for ax in axes.ravel():
        ax.axis("off")
    for ax, name in zip(axes.ravel(), names, strict=False):
        ax.axis("on")
        _draw(ax, frames[name], name[:39])
    fig.tight_layout()
    fig.savefig(args.output / "typed_panels.png", dpi=130)
    plt.close(fig)
    return 0


def x_main__mutmut_151(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--panels", type=int, default=6)
    args = parser.parse_args(argv)
    runs = sorted(
        (json.loads(p.read_text()) for p in args.runs.glob("*.json")), key=lambda r: r["uci_id"]
    )
    frames = {
        r["name"]: pd.DataFrame(
            r["recall_mean"]["data"],
            index=r["recall_mean"]["index"],
            columns=r["recall_mean"]["columns"],
        )
        for r in runs
    }
    args.output.mkdir(parents=True, exist_ok=True)
    median = pd.DataFrame(
        np.nanmedian(np.stack([f.to_numpy(dtype=float) for f in frames.values()]), axis=0),
        index=next(iter(frames.values())).index,
        columns=next(iter(frames.values())).columns,
    )
    fig, ax = plt.subplots(figsize=(7, 5))
    _draw(ax, median, f"Median detection rate over {len(frames)} real datasets (typed injection)")
    fig.tight_layout()
    fig.savefig(args.output / "typed_pooled.png", dpi=160)
    plt.close(fig)
    names = [r["name"] for r in runs][: args.panels]
    cols = 3
    rows = -(-len(names) // cols)
    fig, axes = plt.subplots(rows, cols, figsize=(5.2 * cols, 3.6 * rows), squeeze=False)
    for ax in axes.ravel():
        ax.axis("off")
    for ax, name in zip(axes.ravel(), names, strict=False):
        ax.axis("on")
        _draw(ax, frames[name], name[:38])
    fig.tight_layout()
    fig.savefig(None, dpi=130)
    plt.close(fig)
    return 0


def x_main__mutmut_152(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--panels", type=int, default=6)
    args = parser.parse_args(argv)
    runs = sorted(
        (json.loads(p.read_text()) for p in args.runs.glob("*.json")), key=lambda r: r["uci_id"]
    )
    frames = {
        r["name"]: pd.DataFrame(
            r["recall_mean"]["data"],
            index=r["recall_mean"]["index"],
            columns=r["recall_mean"]["columns"],
        )
        for r in runs
    }
    args.output.mkdir(parents=True, exist_ok=True)
    median = pd.DataFrame(
        np.nanmedian(np.stack([f.to_numpy(dtype=float) for f in frames.values()]), axis=0),
        index=next(iter(frames.values())).index,
        columns=next(iter(frames.values())).columns,
    )
    fig, ax = plt.subplots(figsize=(7, 5))
    _draw(ax, median, f"Median detection rate over {len(frames)} real datasets (typed injection)")
    fig.tight_layout()
    fig.savefig(args.output / "typed_pooled.png", dpi=160)
    plt.close(fig)
    names = [r["name"] for r in runs][: args.panels]
    cols = 3
    rows = -(-len(names) // cols)
    fig, axes = plt.subplots(rows, cols, figsize=(5.2 * cols, 3.6 * rows), squeeze=False)
    for ax in axes.ravel():
        ax.axis("off")
    for ax, name in zip(axes.ravel(), names, strict=False):
        ax.axis("on")
        _draw(ax, frames[name], name[:38])
    fig.tight_layout()
    fig.savefig(args.output / "typed_panels.png", dpi=None)
    plt.close(fig)
    return 0


def x_main__mutmut_153(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--panels", type=int, default=6)
    args = parser.parse_args(argv)
    runs = sorted(
        (json.loads(p.read_text()) for p in args.runs.glob("*.json")), key=lambda r: r["uci_id"]
    )
    frames = {
        r["name"]: pd.DataFrame(
            r["recall_mean"]["data"],
            index=r["recall_mean"]["index"],
            columns=r["recall_mean"]["columns"],
        )
        for r in runs
    }
    args.output.mkdir(parents=True, exist_ok=True)
    median = pd.DataFrame(
        np.nanmedian(np.stack([f.to_numpy(dtype=float) for f in frames.values()]), axis=0),
        index=next(iter(frames.values())).index,
        columns=next(iter(frames.values())).columns,
    )
    fig, ax = plt.subplots(figsize=(7, 5))
    _draw(ax, median, f"Median detection rate over {len(frames)} real datasets (typed injection)")
    fig.tight_layout()
    fig.savefig(args.output / "typed_pooled.png", dpi=160)
    plt.close(fig)
    names = [r["name"] for r in runs][: args.panels]
    cols = 3
    rows = -(-len(names) // cols)
    fig, axes = plt.subplots(rows, cols, figsize=(5.2 * cols, 3.6 * rows), squeeze=False)
    for ax in axes.ravel():
        ax.axis("off")
    for ax, name in zip(axes.ravel(), names, strict=False):
        ax.axis("on")
        _draw(ax, frames[name], name[:38])
    fig.tight_layout()
    fig.savefig(dpi=130)
    plt.close(fig)
    return 0


def x_main__mutmut_154(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--panels", type=int, default=6)
    args = parser.parse_args(argv)
    runs = sorted(
        (json.loads(p.read_text()) for p in args.runs.glob("*.json")), key=lambda r: r["uci_id"]
    )
    frames = {
        r["name"]: pd.DataFrame(
            r["recall_mean"]["data"],
            index=r["recall_mean"]["index"],
            columns=r["recall_mean"]["columns"],
        )
        for r in runs
    }
    args.output.mkdir(parents=True, exist_ok=True)
    median = pd.DataFrame(
        np.nanmedian(np.stack([f.to_numpy(dtype=float) for f in frames.values()]), axis=0),
        index=next(iter(frames.values())).index,
        columns=next(iter(frames.values())).columns,
    )
    fig, ax = plt.subplots(figsize=(7, 5))
    _draw(ax, median, f"Median detection rate over {len(frames)} real datasets (typed injection)")
    fig.tight_layout()
    fig.savefig(args.output / "typed_pooled.png", dpi=160)
    plt.close(fig)
    names = [r["name"] for r in runs][: args.panels]
    cols = 3
    rows = -(-len(names) // cols)
    fig, axes = plt.subplots(rows, cols, figsize=(5.2 * cols, 3.6 * rows), squeeze=False)
    for ax in axes.ravel():
        ax.axis("off")
    for ax, name in zip(axes.ravel(), names, strict=False):
        ax.axis("on")
        _draw(ax, frames[name], name[:38])
    fig.tight_layout()
    fig.savefig(args.output / "typed_panels.png", )
    plt.close(fig)
    return 0


def x_main__mutmut_155(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--panels", type=int, default=6)
    args = parser.parse_args(argv)
    runs = sorted(
        (json.loads(p.read_text()) for p in args.runs.glob("*.json")), key=lambda r: r["uci_id"]
    )
    frames = {
        r["name"]: pd.DataFrame(
            r["recall_mean"]["data"],
            index=r["recall_mean"]["index"],
            columns=r["recall_mean"]["columns"],
        )
        for r in runs
    }
    args.output.mkdir(parents=True, exist_ok=True)
    median = pd.DataFrame(
        np.nanmedian(np.stack([f.to_numpy(dtype=float) for f in frames.values()]), axis=0),
        index=next(iter(frames.values())).index,
        columns=next(iter(frames.values())).columns,
    )
    fig, ax = plt.subplots(figsize=(7, 5))
    _draw(ax, median, f"Median detection rate over {len(frames)} real datasets (typed injection)")
    fig.tight_layout()
    fig.savefig(args.output / "typed_pooled.png", dpi=160)
    plt.close(fig)
    names = [r["name"] for r in runs][: args.panels]
    cols = 3
    rows = -(-len(names) // cols)
    fig, axes = plt.subplots(rows, cols, figsize=(5.2 * cols, 3.6 * rows), squeeze=False)
    for ax in axes.ravel():
        ax.axis("off")
    for ax, name in zip(axes.ravel(), names, strict=False):
        ax.axis("on")
        _draw(ax, frames[name], name[:38])
    fig.tight_layout()
    fig.savefig(args.output * "typed_panels.png", dpi=130)
    plt.close(fig)
    return 0


def x_main__mutmut_156(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--panels", type=int, default=6)
    args = parser.parse_args(argv)
    runs = sorted(
        (json.loads(p.read_text()) for p in args.runs.glob("*.json")), key=lambda r: r["uci_id"]
    )
    frames = {
        r["name"]: pd.DataFrame(
            r["recall_mean"]["data"],
            index=r["recall_mean"]["index"],
            columns=r["recall_mean"]["columns"],
        )
        for r in runs
    }
    args.output.mkdir(parents=True, exist_ok=True)
    median = pd.DataFrame(
        np.nanmedian(np.stack([f.to_numpy(dtype=float) for f in frames.values()]), axis=0),
        index=next(iter(frames.values())).index,
        columns=next(iter(frames.values())).columns,
    )
    fig, ax = plt.subplots(figsize=(7, 5))
    _draw(ax, median, f"Median detection rate over {len(frames)} real datasets (typed injection)")
    fig.tight_layout()
    fig.savefig(args.output / "typed_pooled.png", dpi=160)
    plt.close(fig)
    names = [r["name"] for r in runs][: args.panels]
    cols = 3
    rows = -(-len(names) // cols)
    fig, axes = plt.subplots(rows, cols, figsize=(5.2 * cols, 3.6 * rows), squeeze=False)
    for ax in axes.ravel():
        ax.axis("off")
    for ax, name in zip(axes.ravel(), names, strict=False):
        ax.axis("on")
        _draw(ax, frames[name], name[:38])
    fig.tight_layout()
    fig.savefig(args.output / "XXtyped_panels.pngXX", dpi=130)
    plt.close(fig)
    return 0


def x_main__mutmut_157(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--panels", type=int, default=6)
    args = parser.parse_args(argv)
    runs = sorted(
        (json.loads(p.read_text()) for p in args.runs.glob("*.json")), key=lambda r: r["uci_id"]
    )
    frames = {
        r["name"]: pd.DataFrame(
            r["recall_mean"]["data"],
            index=r["recall_mean"]["index"],
            columns=r["recall_mean"]["columns"],
        )
        for r in runs
    }
    args.output.mkdir(parents=True, exist_ok=True)
    median = pd.DataFrame(
        np.nanmedian(np.stack([f.to_numpy(dtype=float) for f in frames.values()]), axis=0),
        index=next(iter(frames.values())).index,
        columns=next(iter(frames.values())).columns,
    )
    fig, ax = plt.subplots(figsize=(7, 5))
    _draw(ax, median, f"Median detection rate over {len(frames)} real datasets (typed injection)")
    fig.tight_layout()
    fig.savefig(args.output / "typed_pooled.png", dpi=160)
    plt.close(fig)
    names = [r["name"] for r in runs][: args.panels]
    cols = 3
    rows = -(-len(names) // cols)
    fig, axes = plt.subplots(rows, cols, figsize=(5.2 * cols, 3.6 * rows), squeeze=False)
    for ax in axes.ravel():
        ax.axis("off")
    for ax, name in zip(axes.ravel(), names, strict=False):
        ax.axis("on")
        _draw(ax, frames[name], name[:38])
    fig.tight_layout()
    fig.savefig(args.output / "TYPED_PANELS.PNG", dpi=130)
    plt.close(fig)
    return 0


def x_main__mutmut_158(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--panels", type=int, default=6)
    args = parser.parse_args(argv)
    runs = sorted(
        (json.loads(p.read_text()) for p in args.runs.glob("*.json")), key=lambda r: r["uci_id"]
    )
    frames = {
        r["name"]: pd.DataFrame(
            r["recall_mean"]["data"],
            index=r["recall_mean"]["index"],
            columns=r["recall_mean"]["columns"],
        )
        for r in runs
    }
    args.output.mkdir(parents=True, exist_ok=True)
    median = pd.DataFrame(
        np.nanmedian(np.stack([f.to_numpy(dtype=float) for f in frames.values()]), axis=0),
        index=next(iter(frames.values())).index,
        columns=next(iter(frames.values())).columns,
    )
    fig, ax = plt.subplots(figsize=(7, 5))
    _draw(ax, median, f"Median detection rate over {len(frames)} real datasets (typed injection)")
    fig.tight_layout()
    fig.savefig(args.output / "typed_pooled.png", dpi=160)
    plt.close(fig)
    names = [r["name"] for r in runs][: args.panels]
    cols = 3
    rows = -(-len(names) // cols)
    fig, axes = plt.subplots(rows, cols, figsize=(5.2 * cols, 3.6 * rows), squeeze=False)
    for ax in axes.ravel():
        ax.axis("off")
    for ax, name in zip(axes.ravel(), names, strict=False):
        ax.axis("on")
        _draw(ax, frames[name], name[:38])
    fig.tight_layout()
    fig.savefig(args.output / "typed_panels.png", dpi=131)
    plt.close(fig)
    return 0


def x_main__mutmut_159(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--panels", type=int, default=6)
    args = parser.parse_args(argv)
    runs = sorted(
        (json.loads(p.read_text()) for p in args.runs.glob("*.json")), key=lambda r: r["uci_id"]
    )
    frames = {
        r["name"]: pd.DataFrame(
            r["recall_mean"]["data"],
            index=r["recall_mean"]["index"],
            columns=r["recall_mean"]["columns"],
        )
        for r in runs
    }
    args.output.mkdir(parents=True, exist_ok=True)
    median = pd.DataFrame(
        np.nanmedian(np.stack([f.to_numpy(dtype=float) for f in frames.values()]), axis=0),
        index=next(iter(frames.values())).index,
        columns=next(iter(frames.values())).columns,
    )
    fig, ax = plt.subplots(figsize=(7, 5))
    _draw(ax, median, f"Median detection rate over {len(frames)} real datasets (typed injection)")
    fig.tight_layout()
    fig.savefig(args.output / "typed_pooled.png", dpi=160)
    plt.close(fig)
    names = [r["name"] for r in runs][: args.panels]
    cols = 3
    rows = -(-len(names) // cols)
    fig, axes = plt.subplots(rows, cols, figsize=(5.2 * cols, 3.6 * rows), squeeze=False)
    for ax in axes.ravel():
        ax.axis("off")
    for ax, name in zip(axes.ravel(), names, strict=False):
        ax.axis("on")
        _draw(ax, frames[name], name[:38])
    fig.tight_layout()
    fig.savefig(args.output / "typed_panels.png", dpi=130)
    plt.close(None)
    return 0


def x_main__mutmut_160(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--panels", type=int, default=6)
    args = parser.parse_args(argv)
    runs = sorted(
        (json.loads(p.read_text()) for p in args.runs.glob("*.json")), key=lambda r: r["uci_id"]
    )
    frames = {
        r["name"]: pd.DataFrame(
            r["recall_mean"]["data"],
            index=r["recall_mean"]["index"],
            columns=r["recall_mean"]["columns"],
        )
        for r in runs
    }
    args.output.mkdir(parents=True, exist_ok=True)
    median = pd.DataFrame(
        np.nanmedian(np.stack([f.to_numpy(dtype=float) for f in frames.values()]), axis=0),
        index=next(iter(frames.values())).index,
        columns=next(iter(frames.values())).columns,
    )
    fig, ax = plt.subplots(figsize=(7, 5))
    _draw(ax, median, f"Median detection rate over {len(frames)} real datasets (typed injection)")
    fig.tight_layout()
    fig.savefig(args.output / "typed_pooled.png", dpi=160)
    plt.close(fig)
    names = [r["name"] for r in runs][: args.panels]
    cols = 3
    rows = -(-len(names) // cols)
    fig, axes = plt.subplots(rows, cols, figsize=(5.2 * cols, 3.6 * rows), squeeze=False)
    for ax in axes.ravel():
        ax.axis("off")
    for ax, name in zip(axes.ravel(), names, strict=False):
        ax.axis("on")
        _draw(ax, frames[name], name[:38])
    fig.tight_layout()
    fig.savefig(args.output / "typed_panels.png", dpi=130)
    plt.close(fig)
    return 1

mutants_x_main__mutmut['_mutmut_orig'] = x_main__mutmut_orig # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_1'] = x_main__mutmut_1 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_2'] = x_main__mutmut_2 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_3'] = x_main__mutmut_3 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_4'] = x_main__mutmut_4 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_5'] = x_main__mutmut_5 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_6'] = x_main__mutmut_6 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_7'] = x_main__mutmut_7 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_8'] = x_main__mutmut_8 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_9'] = x_main__mutmut_9 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_10'] = x_main__mutmut_10 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_11'] = x_main__mutmut_11 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_12'] = x_main__mutmut_12 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_13'] = x_main__mutmut_13 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_14'] = x_main__mutmut_14 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_15'] = x_main__mutmut_15 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_16'] = x_main__mutmut_16 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_17'] = x_main__mutmut_17 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_18'] = x_main__mutmut_18 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_19'] = x_main__mutmut_19 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_20'] = x_main__mutmut_20 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_21'] = x_main__mutmut_21 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_22'] = x_main__mutmut_22 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_23'] = x_main__mutmut_23 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_24'] = x_main__mutmut_24 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_25'] = x_main__mutmut_25 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_26'] = x_main__mutmut_26 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_27'] = x_main__mutmut_27 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_28'] = x_main__mutmut_28 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_29'] = x_main__mutmut_29 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_30'] = x_main__mutmut_30 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_31'] = x_main__mutmut_31 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_32'] = x_main__mutmut_32 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_33'] = x_main__mutmut_33 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_34'] = x_main__mutmut_34 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_35'] = x_main__mutmut_35 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_36'] = x_main__mutmut_36 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_37'] = x_main__mutmut_37 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_38'] = x_main__mutmut_38 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_39'] = x_main__mutmut_39 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_40'] = x_main__mutmut_40 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_41'] = x_main__mutmut_41 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_42'] = x_main__mutmut_42 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_43'] = x_main__mutmut_43 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_44'] = x_main__mutmut_44 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_45'] = x_main__mutmut_45 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_46'] = x_main__mutmut_46 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_47'] = x_main__mutmut_47 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_48'] = x_main__mutmut_48 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_49'] = x_main__mutmut_49 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_50'] = x_main__mutmut_50 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_51'] = x_main__mutmut_51 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_52'] = x_main__mutmut_52 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_53'] = x_main__mutmut_53 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_54'] = x_main__mutmut_54 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_55'] = x_main__mutmut_55 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_56'] = x_main__mutmut_56 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_57'] = x_main__mutmut_57 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_58'] = x_main__mutmut_58 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_59'] = x_main__mutmut_59 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_60'] = x_main__mutmut_60 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_61'] = x_main__mutmut_61 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_62'] = x_main__mutmut_62 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_63'] = x_main__mutmut_63 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_64'] = x_main__mutmut_64 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_65'] = x_main__mutmut_65 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_66'] = x_main__mutmut_66 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_67'] = x_main__mutmut_67 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_68'] = x_main__mutmut_68 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_69'] = x_main__mutmut_69 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_70'] = x_main__mutmut_70 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_71'] = x_main__mutmut_71 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_72'] = x_main__mutmut_72 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_73'] = x_main__mutmut_73 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_74'] = x_main__mutmut_74 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_75'] = x_main__mutmut_75 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_76'] = x_main__mutmut_76 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_77'] = x_main__mutmut_77 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_78'] = x_main__mutmut_78 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_79'] = x_main__mutmut_79 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_80'] = x_main__mutmut_80 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_81'] = x_main__mutmut_81 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_82'] = x_main__mutmut_82 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_83'] = x_main__mutmut_83 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_84'] = x_main__mutmut_84 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_85'] = x_main__mutmut_85 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_86'] = x_main__mutmut_86 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_87'] = x_main__mutmut_87 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_88'] = x_main__mutmut_88 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_89'] = x_main__mutmut_89 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_90'] = x_main__mutmut_90 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_91'] = x_main__mutmut_91 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_92'] = x_main__mutmut_92 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_93'] = x_main__mutmut_93 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_94'] = x_main__mutmut_94 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_95'] = x_main__mutmut_95 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_96'] = x_main__mutmut_96 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_97'] = x_main__mutmut_97 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_98'] = x_main__mutmut_98 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_99'] = x_main__mutmut_99 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_100'] = x_main__mutmut_100 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_101'] = x_main__mutmut_101 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_102'] = x_main__mutmut_102 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_103'] = x_main__mutmut_103 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_104'] = x_main__mutmut_104 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_105'] = x_main__mutmut_105 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_106'] = x_main__mutmut_106 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_107'] = x_main__mutmut_107 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_108'] = x_main__mutmut_108 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_109'] = x_main__mutmut_109 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_110'] = x_main__mutmut_110 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_111'] = x_main__mutmut_111 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_112'] = x_main__mutmut_112 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_113'] = x_main__mutmut_113 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_114'] = x_main__mutmut_114 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_115'] = x_main__mutmut_115 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_116'] = x_main__mutmut_116 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_117'] = x_main__mutmut_117 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_118'] = x_main__mutmut_118 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_119'] = x_main__mutmut_119 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_120'] = x_main__mutmut_120 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_121'] = x_main__mutmut_121 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_122'] = x_main__mutmut_122 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_123'] = x_main__mutmut_123 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_124'] = x_main__mutmut_124 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_125'] = x_main__mutmut_125 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_126'] = x_main__mutmut_126 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_127'] = x_main__mutmut_127 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_128'] = x_main__mutmut_128 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_129'] = x_main__mutmut_129 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_130'] = x_main__mutmut_130 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_131'] = x_main__mutmut_131 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_132'] = x_main__mutmut_132 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_133'] = x_main__mutmut_133 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_134'] = x_main__mutmut_134 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_135'] = x_main__mutmut_135 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_136'] = x_main__mutmut_136 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_137'] = x_main__mutmut_137 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_138'] = x_main__mutmut_138 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_139'] = x_main__mutmut_139 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_140'] = x_main__mutmut_140 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_141'] = x_main__mutmut_141 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_142'] = x_main__mutmut_142 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_143'] = x_main__mutmut_143 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_144'] = x_main__mutmut_144 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_145'] = x_main__mutmut_145 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_146'] = x_main__mutmut_146 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_147'] = x_main__mutmut_147 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_148'] = x_main__mutmut_148 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_149'] = x_main__mutmut_149 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_150'] = x_main__mutmut_150 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_151'] = x_main__mutmut_151 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_152'] = x_main__mutmut_152 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_153'] = x_main__mutmut_153 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_154'] = x_main__mutmut_154 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_155'] = x_main__mutmut_155 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_156'] = x_main__mutmut_156 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_157'] = x_main__mutmut_157 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_158'] = x_main__mutmut_158 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_159'] = x_main__mutmut_159 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_160'] = x_main__mutmut_160 # type: ignore # mutmut generated


if __name__ == "__main__":
    raise SystemExit(main())
