"""Read a UCI table as a carrier (features only) or as a labelled anomaly set by a fixed rule.

The rule is set before any detector runs: the rarest class is the anomaly class (at least 20
rows), every other class is normal; when the anomaly class holds more than 10 percent of the
rows it is downsampled to 10 percent with seed 0, and the natural rate is recorded.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd

MIN_ANOMALIES = 20
TARGET_RATE = 0.10
SEED = 0


from mutmut.mutation.trampoline import wrap_in_trampoline as _mutmut_mutated, MutantDict


class NoLabels(Exception):
    """The set can serve as a carrier but not as a labelled anomaly set."""
mutants_x_read_table__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_read_table__mutmut)
def read_table(path: Path) -> pd.DataFrame:
    """Read the CSV and repair two known quirks of the repository files, recorded not hidden:
    header lines repeated when several files were concatenated, and libsvm-style index:value
    tokens."""
    frame = pd.read_csv(path, low_memory=False)
    repeated = (frame.astype(str) == pd.Series(frame.columns, index=frame.columns)).all(axis=1)
    frame = frame[~repeated].reset_index(drop=True)
    for name in frame.columns[frame.dtypes.map(lambda t: not pd.api.types.is_numeric_dtype(t))]:
        text = frame[name].dropna().astype(str)
        if len(text) and text.str.fullmatch(r"\d+:-?[\d.eE+-]+").mean() >= 0.99:
            frame[name] = frame[name].astype("string").str.split(":").str[1]
        number = pd.to_numeric(frame[name], errors="coerce")
        if len(text) and number.notna().sum() >= 0.99 * len(text):
            frame[name] = number
    return frame


def x_read_table__mutmut_orig(path: Path) -> pd.DataFrame:
    """Read the CSV and repair two known quirks of the repository files, recorded not hidden:
    header lines repeated when several files were concatenated, and libsvm-style index:value
    tokens."""
    frame = pd.read_csv(path, low_memory=False)
    repeated = (frame.astype(str) == pd.Series(frame.columns, index=frame.columns)).all(axis=1)
    frame = frame[~repeated].reset_index(drop=True)
    for name in frame.columns[frame.dtypes.map(lambda t: not pd.api.types.is_numeric_dtype(t))]:
        text = frame[name].dropna().astype(str)
        if len(text) and text.str.fullmatch(r"\d+:-?[\d.eE+-]+").mean() >= 0.99:
            frame[name] = frame[name].astype("string").str.split(":").str[1]
        number = pd.to_numeric(frame[name], errors="coerce")
        if len(text) and number.notna().sum() >= 0.99 * len(text):
            frame[name] = number
    return frame


def x_read_table__mutmut_1(path: Path) -> pd.DataFrame:
    """Read the CSV and repair two known quirks of the repository files, recorded not hidden:
    header lines repeated when several files were concatenated, and libsvm-style index:value
    tokens."""
    frame = None
    repeated = (frame.astype(str) == pd.Series(frame.columns, index=frame.columns)).all(axis=1)
    frame = frame[~repeated].reset_index(drop=True)
    for name in frame.columns[frame.dtypes.map(lambda t: not pd.api.types.is_numeric_dtype(t))]:
        text = frame[name].dropna().astype(str)
        if len(text) and text.str.fullmatch(r"\d+:-?[\d.eE+-]+").mean() >= 0.99:
            frame[name] = frame[name].astype("string").str.split(":").str[1]
        number = pd.to_numeric(frame[name], errors="coerce")
        if len(text) and number.notna().sum() >= 0.99 * len(text):
            frame[name] = number
    return frame


def x_read_table__mutmut_2(path: Path) -> pd.DataFrame:
    """Read the CSV and repair two known quirks of the repository files, recorded not hidden:
    header lines repeated when several files were concatenated, and libsvm-style index:value
    tokens."""
    frame = pd.read_csv(None, low_memory=False)
    repeated = (frame.astype(str) == pd.Series(frame.columns, index=frame.columns)).all(axis=1)
    frame = frame[~repeated].reset_index(drop=True)
    for name in frame.columns[frame.dtypes.map(lambda t: not pd.api.types.is_numeric_dtype(t))]:
        text = frame[name].dropna().astype(str)
        if len(text) and text.str.fullmatch(r"\d+:-?[\d.eE+-]+").mean() >= 0.99:
            frame[name] = frame[name].astype("string").str.split(":").str[1]
        number = pd.to_numeric(frame[name], errors="coerce")
        if len(text) and number.notna().sum() >= 0.99 * len(text):
            frame[name] = number
    return frame


def x_read_table__mutmut_3(path: Path) -> pd.DataFrame:
    """Read the CSV and repair two known quirks of the repository files, recorded not hidden:
    header lines repeated when several files were concatenated, and libsvm-style index:value
    tokens."""
    frame = pd.read_csv(path, low_memory=None)
    repeated = (frame.astype(str) == pd.Series(frame.columns, index=frame.columns)).all(axis=1)
    frame = frame[~repeated].reset_index(drop=True)
    for name in frame.columns[frame.dtypes.map(lambda t: not pd.api.types.is_numeric_dtype(t))]:
        text = frame[name].dropna().astype(str)
        if len(text) and text.str.fullmatch(r"\d+:-?[\d.eE+-]+").mean() >= 0.99:
            frame[name] = frame[name].astype("string").str.split(":").str[1]
        number = pd.to_numeric(frame[name], errors="coerce")
        if len(text) and number.notna().sum() >= 0.99 * len(text):
            frame[name] = number
    return frame


def x_read_table__mutmut_4(path: Path) -> pd.DataFrame:
    """Read the CSV and repair two known quirks of the repository files, recorded not hidden:
    header lines repeated when several files were concatenated, and libsvm-style index:value
    tokens."""
    frame = pd.read_csv(low_memory=False)
    repeated = (frame.astype(str) == pd.Series(frame.columns, index=frame.columns)).all(axis=1)
    frame = frame[~repeated].reset_index(drop=True)
    for name in frame.columns[frame.dtypes.map(lambda t: not pd.api.types.is_numeric_dtype(t))]:
        text = frame[name].dropna().astype(str)
        if len(text) and text.str.fullmatch(r"\d+:-?[\d.eE+-]+").mean() >= 0.99:
            frame[name] = frame[name].astype("string").str.split(":").str[1]
        number = pd.to_numeric(frame[name], errors="coerce")
        if len(text) and number.notna().sum() >= 0.99 * len(text):
            frame[name] = number
    return frame


def x_read_table__mutmut_5(path: Path) -> pd.DataFrame:
    """Read the CSV and repair two known quirks of the repository files, recorded not hidden:
    header lines repeated when several files were concatenated, and libsvm-style index:value
    tokens."""
    frame = pd.read_csv(path, )
    repeated = (frame.astype(str) == pd.Series(frame.columns, index=frame.columns)).all(axis=1)
    frame = frame[~repeated].reset_index(drop=True)
    for name in frame.columns[frame.dtypes.map(lambda t: not pd.api.types.is_numeric_dtype(t))]:
        text = frame[name].dropna().astype(str)
        if len(text) and text.str.fullmatch(r"\d+:-?[\d.eE+-]+").mean() >= 0.99:
            frame[name] = frame[name].astype("string").str.split(":").str[1]
        number = pd.to_numeric(frame[name], errors="coerce")
        if len(text) and number.notna().sum() >= 0.99 * len(text):
            frame[name] = number
    return frame


def x_read_table__mutmut_6(path: Path) -> pd.DataFrame:
    """Read the CSV and repair two known quirks of the repository files, recorded not hidden:
    header lines repeated when several files were concatenated, and libsvm-style index:value
    tokens."""
    frame = pd.read_csv(path, low_memory=True)
    repeated = (frame.astype(str) == pd.Series(frame.columns, index=frame.columns)).all(axis=1)
    frame = frame[~repeated].reset_index(drop=True)
    for name in frame.columns[frame.dtypes.map(lambda t: not pd.api.types.is_numeric_dtype(t))]:
        text = frame[name].dropna().astype(str)
        if len(text) and text.str.fullmatch(r"\d+:-?[\d.eE+-]+").mean() >= 0.99:
            frame[name] = frame[name].astype("string").str.split(":").str[1]
        number = pd.to_numeric(frame[name], errors="coerce")
        if len(text) and number.notna().sum() >= 0.99 * len(text):
            frame[name] = number
    return frame


def x_read_table__mutmut_7(path: Path) -> pd.DataFrame:
    """Read the CSV and repair two known quirks of the repository files, recorded not hidden:
    header lines repeated when several files were concatenated, and libsvm-style index:value
    tokens."""
    frame = pd.read_csv(path, low_memory=False)
    repeated = None
    frame = frame[~repeated].reset_index(drop=True)
    for name in frame.columns[frame.dtypes.map(lambda t: not pd.api.types.is_numeric_dtype(t))]:
        text = frame[name].dropna().astype(str)
        if len(text) and text.str.fullmatch(r"\d+:-?[\d.eE+-]+").mean() >= 0.99:
            frame[name] = frame[name].astype("string").str.split(":").str[1]
        number = pd.to_numeric(frame[name], errors="coerce")
        if len(text) and number.notna().sum() >= 0.99 * len(text):
            frame[name] = number
    return frame


def x_read_table__mutmut_8(path: Path) -> pd.DataFrame:
    """Read the CSV and repair two known quirks of the repository files, recorded not hidden:
    header lines repeated when several files were concatenated, and libsvm-style index:value
    tokens."""
    frame = pd.read_csv(path, low_memory=False)
    repeated = (frame.astype(str) == pd.Series(frame.columns, index=frame.columns)).all(axis=None)
    frame = frame[~repeated].reset_index(drop=True)
    for name in frame.columns[frame.dtypes.map(lambda t: not pd.api.types.is_numeric_dtype(t))]:
        text = frame[name].dropna().astype(str)
        if len(text) and text.str.fullmatch(r"\d+:-?[\d.eE+-]+").mean() >= 0.99:
            frame[name] = frame[name].astype("string").str.split(":").str[1]
        number = pd.to_numeric(frame[name], errors="coerce")
        if len(text) and number.notna().sum() >= 0.99 * len(text):
            frame[name] = number
    return frame


def x_read_table__mutmut_9(path: Path) -> pd.DataFrame:
    """Read the CSV and repair two known quirks of the repository files, recorded not hidden:
    header lines repeated when several files were concatenated, and libsvm-style index:value
    tokens."""
    frame = pd.read_csv(path, low_memory=False)
    repeated = (frame.astype(None) == pd.Series(frame.columns, index=frame.columns)).all(axis=1)
    frame = frame[~repeated].reset_index(drop=True)
    for name in frame.columns[frame.dtypes.map(lambda t: not pd.api.types.is_numeric_dtype(t))]:
        text = frame[name].dropna().astype(str)
        if len(text) and text.str.fullmatch(r"\d+:-?[\d.eE+-]+").mean() >= 0.99:
            frame[name] = frame[name].astype("string").str.split(":").str[1]
        number = pd.to_numeric(frame[name], errors="coerce")
        if len(text) and number.notna().sum() >= 0.99 * len(text):
            frame[name] = number
    return frame


def x_read_table__mutmut_10(path: Path) -> pd.DataFrame:
    """Read the CSV and repair two known quirks of the repository files, recorded not hidden:
    header lines repeated when several files were concatenated, and libsvm-style index:value
    tokens."""
    frame = pd.read_csv(path, low_memory=False)
    repeated = (frame.astype(str) != pd.Series(frame.columns, index=frame.columns)).all(axis=1)
    frame = frame[~repeated].reset_index(drop=True)
    for name in frame.columns[frame.dtypes.map(lambda t: not pd.api.types.is_numeric_dtype(t))]:
        text = frame[name].dropna().astype(str)
        if len(text) and text.str.fullmatch(r"\d+:-?[\d.eE+-]+").mean() >= 0.99:
            frame[name] = frame[name].astype("string").str.split(":").str[1]
        number = pd.to_numeric(frame[name], errors="coerce")
        if len(text) and number.notna().sum() >= 0.99 * len(text):
            frame[name] = number
    return frame


def x_read_table__mutmut_11(path: Path) -> pd.DataFrame:
    """Read the CSV and repair two known quirks of the repository files, recorded not hidden:
    header lines repeated when several files were concatenated, and libsvm-style index:value
    tokens."""
    frame = pd.read_csv(path, low_memory=False)
    repeated = (frame.astype(str) == pd.Series(None, index=frame.columns)).all(axis=1)
    frame = frame[~repeated].reset_index(drop=True)
    for name in frame.columns[frame.dtypes.map(lambda t: not pd.api.types.is_numeric_dtype(t))]:
        text = frame[name].dropna().astype(str)
        if len(text) and text.str.fullmatch(r"\d+:-?[\d.eE+-]+").mean() >= 0.99:
            frame[name] = frame[name].astype("string").str.split(":").str[1]
        number = pd.to_numeric(frame[name], errors="coerce")
        if len(text) and number.notna().sum() >= 0.99 * len(text):
            frame[name] = number
    return frame


def x_read_table__mutmut_12(path: Path) -> pd.DataFrame:
    """Read the CSV and repair two known quirks of the repository files, recorded not hidden:
    header lines repeated when several files were concatenated, and libsvm-style index:value
    tokens."""
    frame = pd.read_csv(path, low_memory=False)
    repeated = (frame.astype(str) == pd.Series(frame.columns, index=None)).all(axis=1)
    frame = frame[~repeated].reset_index(drop=True)
    for name in frame.columns[frame.dtypes.map(lambda t: not pd.api.types.is_numeric_dtype(t))]:
        text = frame[name].dropna().astype(str)
        if len(text) and text.str.fullmatch(r"\d+:-?[\d.eE+-]+").mean() >= 0.99:
            frame[name] = frame[name].astype("string").str.split(":").str[1]
        number = pd.to_numeric(frame[name], errors="coerce")
        if len(text) and number.notna().sum() >= 0.99 * len(text):
            frame[name] = number
    return frame


def x_read_table__mutmut_13(path: Path) -> pd.DataFrame:
    """Read the CSV and repair two known quirks of the repository files, recorded not hidden:
    header lines repeated when several files were concatenated, and libsvm-style index:value
    tokens."""
    frame = pd.read_csv(path, low_memory=False)
    repeated = (frame.astype(str) == pd.Series(index=frame.columns)).all(axis=1)
    frame = frame[~repeated].reset_index(drop=True)
    for name in frame.columns[frame.dtypes.map(lambda t: not pd.api.types.is_numeric_dtype(t))]:
        text = frame[name].dropna().astype(str)
        if len(text) and text.str.fullmatch(r"\d+:-?[\d.eE+-]+").mean() >= 0.99:
            frame[name] = frame[name].astype("string").str.split(":").str[1]
        number = pd.to_numeric(frame[name], errors="coerce")
        if len(text) and number.notna().sum() >= 0.99 * len(text):
            frame[name] = number
    return frame


def x_read_table__mutmut_14(path: Path) -> pd.DataFrame:
    """Read the CSV and repair two known quirks of the repository files, recorded not hidden:
    header lines repeated when several files were concatenated, and libsvm-style index:value
    tokens."""
    frame = pd.read_csv(path, low_memory=False)
    repeated = (frame.astype(str) == pd.Series(frame.columns, )).all(axis=1)
    frame = frame[~repeated].reset_index(drop=True)
    for name in frame.columns[frame.dtypes.map(lambda t: not pd.api.types.is_numeric_dtype(t))]:
        text = frame[name].dropna().astype(str)
        if len(text) and text.str.fullmatch(r"\d+:-?[\d.eE+-]+").mean() >= 0.99:
            frame[name] = frame[name].astype("string").str.split(":").str[1]
        number = pd.to_numeric(frame[name], errors="coerce")
        if len(text) and number.notna().sum() >= 0.99 * len(text):
            frame[name] = number
    return frame


def x_read_table__mutmut_15(path: Path) -> pd.DataFrame:
    """Read the CSV and repair two known quirks of the repository files, recorded not hidden:
    header lines repeated when several files were concatenated, and libsvm-style index:value
    tokens."""
    frame = pd.read_csv(path, low_memory=False)
    repeated = (frame.astype(str) == pd.Series(frame.columns, index=frame.columns)).all(axis=2)
    frame = frame[~repeated].reset_index(drop=True)
    for name in frame.columns[frame.dtypes.map(lambda t: not pd.api.types.is_numeric_dtype(t))]:
        text = frame[name].dropna().astype(str)
        if len(text) and text.str.fullmatch(r"\d+:-?[\d.eE+-]+").mean() >= 0.99:
            frame[name] = frame[name].astype("string").str.split(":").str[1]
        number = pd.to_numeric(frame[name], errors="coerce")
        if len(text) and number.notna().sum() >= 0.99 * len(text):
            frame[name] = number
    return frame


def x_read_table__mutmut_16(path: Path) -> pd.DataFrame:
    """Read the CSV and repair two known quirks of the repository files, recorded not hidden:
    header lines repeated when several files were concatenated, and libsvm-style index:value
    tokens."""
    frame = pd.read_csv(path, low_memory=False)
    repeated = (frame.astype(str) == pd.Series(frame.columns, index=frame.columns)).all(axis=1)
    frame = None
    for name in frame.columns[frame.dtypes.map(lambda t: not pd.api.types.is_numeric_dtype(t))]:
        text = frame[name].dropna().astype(str)
        if len(text) and text.str.fullmatch(r"\d+:-?[\d.eE+-]+").mean() >= 0.99:
            frame[name] = frame[name].astype("string").str.split(":").str[1]
        number = pd.to_numeric(frame[name], errors="coerce")
        if len(text) and number.notna().sum() >= 0.99 * len(text):
            frame[name] = number
    return frame


def x_read_table__mutmut_17(path: Path) -> pd.DataFrame:
    """Read the CSV and repair two known quirks of the repository files, recorded not hidden:
    header lines repeated when several files were concatenated, and libsvm-style index:value
    tokens."""
    frame = pd.read_csv(path, low_memory=False)
    repeated = (frame.astype(str) == pd.Series(frame.columns, index=frame.columns)).all(axis=1)
    frame = frame[~repeated].reset_index(drop=None)
    for name in frame.columns[frame.dtypes.map(lambda t: not pd.api.types.is_numeric_dtype(t))]:
        text = frame[name].dropna().astype(str)
        if len(text) and text.str.fullmatch(r"\d+:-?[\d.eE+-]+").mean() >= 0.99:
            frame[name] = frame[name].astype("string").str.split(":").str[1]
        number = pd.to_numeric(frame[name], errors="coerce")
        if len(text) and number.notna().sum() >= 0.99 * len(text):
            frame[name] = number
    return frame


def x_read_table__mutmut_18(path: Path) -> pd.DataFrame:
    """Read the CSV and repair two known quirks of the repository files, recorded not hidden:
    header lines repeated when several files were concatenated, and libsvm-style index:value
    tokens."""
    frame = pd.read_csv(path, low_memory=False)
    repeated = (frame.astype(str) == pd.Series(frame.columns, index=frame.columns)).all(axis=1)
    frame = frame[repeated].reset_index(drop=True)
    for name in frame.columns[frame.dtypes.map(lambda t: not pd.api.types.is_numeric_dtype(t))]:
        text = frame[name].dropna().astype(str)
        if len(text) and text.str.fullmatch(r"\d+:-?[\d.eE+-]+").mean() >= 0.99:
            frame[name] = frame[name].astype("string").str.split(":").str[1]
        number = pd.to_numeric(frame[name], errors="coerce")
        if len(text) and number.notna().sum() >= 0.99 * len(text):
            frame[name] = number
    return frame


def x_read_table__mutmut_19(path: Path) -> pd.DataFrame:
    """Read the CSV and repair two known quirks of the repository files, recorded not hidden:
    header lines repeated when several files were concatenated, and libsvm-style index:value
    tokens."""
    frame = pd.read_csv(path, low_memory=False)
    repeated = (frame.astype(str) == pd.Series(frame.columns, index=frame.columns)).all(axis=1)
    frame = frame[~repeated].reset_index(drop=False)
    for name in frame.columns[frame.dtypes.map(lambda t: not pd.api.types.is_numeric_dtype(t))]:
        text = frame[name].dropna().astype(str)
        if len(text) and text.str.fullmatch(r"\d+:-?[\d.eE+-]+").mean() >= 0.99:
            frame[name] = frame[name].astype("string").str.split(":").str[1]
        number = pd.to_numeric(frame[name], errors="coerce")
        if len(text) and number.notna().sum() >= 0.99 * len(text):
            frame[name] = number
    return frame


def x_read_table__mutmut_20(path: Path) -> pd.DataFrame:
    """Read the CSV and repair two known quirks of the repository files, recorded not hidden:
    header lines repeated when several files were concatenated, and libsvm-style index:value
    tokens."""
    frame = pd.read_csv(path, low_memory=False)
    repeated = (frame.astype(str) == pd.Series(frame.columns, index=frame.columns)).all(axis=1)
    frame = frame[~repeated].reset_index(drop=True)
    for name in frame.columns[frame.dtypes.map(None)]:
        text = frame[name].dropna().astype(str)
        if len(text) and text.str.fullmatch(r"\d+:-?[\d.eE+-]+").mean() >= 0.99:
            frame[name] = frame[name].astype("string").str.split(":").str[1]
        number = pd.to_numeric(frame[name], errors="coerce")
        if len(text) and number.notna().sum() >= 0.99 * len(text):
            frame[name] = number
    return frame


def x_read_table__mutmut_21(path: Path) -> pd.DataFrame:
    """Read the CSV and repair two known quirks of the repository files, recorded not hidden:
    header lines repeated when several files were concatenated, and libsvm-style index:value
    tokens."""
    frame = pd.read_csv(path, low_memory=False)
    repeated = (frame.astype(str) == pd.Series(frame.columns, index=frame.columns)).all(axis=1)
    frame = frame[~repeated].reset_index(drop=True)
    for name in frame.columns[frame.dtypes.map(lambda t: None)]:
        text = frame[name].dropna().astype(str)
        if len(text) and text.str.fullmatch(r"\d+:-?[\d.eE+-]+").mean() >= 0.99:
            frame[name] = frame[name].astype("string").str.split(":").str[1]
        number = pd.to_numeric(frame[name], errors="coerce")
        if len(text) and number.notna().sum() >= 0.99 * len(text):
            frame[name] = number
    return frame


def x_read_table__mutmut_22(path: Path) -> pd.DataFrame:
    """Read the CSV and repair two known quirks of the repository files, recorded not hidden:
    header lines repeated when several files were concatenated, and libsvm-style index:value
    tokens."""
    frame = pd.read_csv(path, low_memory=False)
    repeated = (frame.astype(str) == pd.Series(frame.columns, index=frame.columns)).all(axis=1)
    frame = frame[~repeated].reset_index(drop=True)
    for name in frame.columns[frame.dtypes.map(lambda t: pd.api.types.is_numeric_dtype(t))]:
        text = frame[name].dropna().astype(str)
        if len(text) and text.str.fullmatch(r"\d+:-?[\d.eE+-]+").mean() >= 0.99:
            frame[name] = frame[name].astype("string").str.split(":").str[1]
        number = pd.to_numeric(frame[name], errors="coerce")
        if len(text) and number.notna().sum() >= 0.99 * len(text):
            frame[name] = number
    return frame


def x_read_table__mutmut_23(path: Path) -> pd.DataFrame:
    """Read the CSV and repair two known quirks of the repository files, recorded not hidden:
    header lines repeated when several files were concatenated, and libsvm-style index:value
    tokens."""
    frame = pd.read_csv(path, low_memory=False)
    repeated = (frame.astype(str) == pd.Series(frame.columns, index=frame.columns)).all(axis=1)
    frame = frame[~repeated].reset_index(drop=True)
    for name in frame.columns[frame.dtypes.map(lambda t: not pd.api.types.is_numeric_dtype(None))]:
        text = frame[name].dropna().astype(str)
        if len(text) and text.str.fullmatch(r"\d+:-?[\d.eE+-]+").mean() >= 0.99:
            frame[name] = frame[name].astype("string").str.split(":").str[1]
        number = pd.to_numeric(frame[name], errors="coerce")
        if len(text) and number.notna().sum() >= 0.99 * len(text):
            frame[name] = number
    return frame


def x_read_table__mutmut_24(path: Path) -> pd.DataFrame:
    """Read the CSV and repair two known quirks of the repository files, recorded not hidden:
    header lines repeated when several files were concatenated, and libsvm-style index:value
    tokens."""
    frame = pd.read_csv(path, low_memory=False)
    repeated = (frame.astype(str) == pd.Series(frame.columns, index=frame.columns)).all(axis=1)
    frame = frame[~repeated].reset_index(drop=True)
    for name in frame.columns[frame.dtypes.map(lambda t: not pd.api.types.is_numeric_dtype(t))]:
        text = None
        if len(text) and text.str.fullmatch(r"\d+:-?[\d.eE+-]+").mean() >= 0.99:
            frame[name] = frame[name].astype("string").str.split(":").str[1]
        number = pd.to_numeric(frame[name], errors="coerce")
        if len(text) and number.notna().sum() >= 0.99 * len(text):
            frame[name] = number
    return frame


def x_read_table__mutmut_25(path: Path) -> pd.DataFrame:
    """Read the CSV and repair two known quirks of the repository files, recorded not hidden:
    header lines repeated when several files were concatenated, and libsvm-style index:value
    tokens."""
    frame = pd.read_csv(path, low_memory=False)
    repeated = (frame.astype(str) == pd.Series(frame.columns, index=frame.columns)).all(axis=1)
    frame = frame[~repeated].reset_index(drop=True)
    for name in frame.columns[frame.dtypes.map(lambda t: not pd.api.types.is_numeric_dtype(t))]:
        text = frame[name].dropna().astype(None)
        if len(text) and text.str.fullmatch(r"\d+:-?[\d.eE+-]+").mean() >= 0.99:
            frame[name] = frame[name].astype("string").str.split(":").str[1]
        number = pd.to_numeric(frame[name], errors="coerce")
        if len(text) and number.notna().sum() >= 0.99 * len(text):
            frame[name] = number
    return frame


def x_read_table__mutmut_26(path: Path) -> pd.DataFrame:
    """Read the CSV and repair two known quirks of the repository files, recorded not hidden:
    header lines repeated when several files were concatenated, and libsvm-style index:value
    tokens."""
    frame = pd.read_csv(path, low_memory=False)
    repeated = (frame.astype(str) == pd.Series(frame.columns, index=frame.columns)).all(axis=1)
    frame = frame[~repeated].reset_index(drop=True)
    for name in frame.columns[frame.dtypes.map(lambda t: not pd.api.types.is_numeric_dtype(t))]:
        text = frame[name].dropna().astype(str)
        if len(text) or text.str.fullmatch(r"\d+:-?[\d.eE+-]+").mean() >= 0.99:
            frame[name] = frame[name].astype("string").str.split(":").str[1]
        number = pd.to_numeric(frame[name], errors="coerce")
        if len(text) and number.notna().sum() >= 0.99 * len(text):
            frame[name] = number
    return frame


def x_read_table__mutmut_27(path: Path) -> pd.DataFrame:
    """Read the CSV and repair two known quirks of the repository files, recorded not hidden:
    header lines repeated when several files were concatenated, and libsvm-style index:value
    tokens."""
    frame = pd.read_csv(path, low_memory=False)
    repeated = (frame.astype(str) == pd.Series(frame.columns, index=frame.columns)).all(axis=1)
    frame = frame[~repeated].reset_index(drop=True)
    for name in frame.columns[frame.dtypes.map(lambda t: not pd.api.types.is_numeric_dtype(t))]:
        text = frame[name].dropna().astype(str)
        if len(text) and text.str.fullmatch(None).mean() >= 0.99:
            frame[name] = frame[name].astype("string").str.split(":").str[1]
        number = pd.to_numeric(frame[name], errors="coerce")
        if len(text) and number.notna().sum() >= 0.99 * len(text):
            frame[name] = number
    return frame


def x_read_table__mutmut_28(path: Path) -> pd.DataFrame:
    """Read the CSV and repair two known quirks of the repository files, recorded not hidden:
    header lines repeated when several files were concatenated, and libsvm-style index:value
    tokens."""
    frame = pd.read_csv(path, low_memory=False)
    repeated = (frame.astype(str) == pd.Series(frame.columns, index=frame.columns)).all(axis=1)
    frame = frame[~repeated].reset_index(drop=True)
    for name in frame.columns[frame.dtypes.map(lambda t: not pd.api.types.is_numeric_dtype(t))]:
        text = frame[name].dropna().astype(str)
        if len(text) and text.str.fullmatch(r"XX\d+:-?[\d.eE+-]+XX").mean() >= 0.99:
            frame[name] = frame[name].astype("string").str.split(":").str[1]
        number = pd.to_numeric(frame[name], errors="coerce")
        if len(text) and number.notna().sum() >= 0.99 * len(text):
            frame[name] = number
    return frame


def x_read_table__mutmut_29(path: Path) -> pd.DataFrame:
    """Read the CSV and repair two known quirks of the repository files, recorded not hidden:
    header lines repeated when several files were concatenated, and libsvm-style index:value
    tokens."""
    frame = pd.read_csv(path, low_memory=False)
    repeated = (frame.astype(str) == pd.Series(frame.columns, index=frame.columns)).all(axis=1)
    frame = frame[~repeated].reset_index(drop=True)
    for name in frame.columns[frame.dtypes.map(lambda t: not pd.api.types.is_numeric_dtype(t))]:
        text = frame[name].dropna().astype(str)
        if len(text) and text.str.fullmatch(r"\d+:-?[\d.ee+-]+").mean() >= 0.99:
            frame[name] = frame[name].astype("string").str.split(":").str[1]
        number = pd.to_numeric(frame[name], errors="coerce")
        if len(text) and number.notna().sum() >= 0.99 * len(text):
            frame[name] = number
    return frame


def x_read_table__mutmut_30(path: Path) -> pd.DataFrame:
    """Read the CSV and repair two known quirks of the repository files, recorded not hidden:
    header lines repeated when several files were concatenated, and libsvm-style index:value
    tokens."""
    frame = pd.read_csv(path, low_memory=False)
    repeated = (frame.astype(str) == pd.Series(frame.columns, index=frame.columns)).all(axis=1)
    frame = frame[~repeated].reset_index(drop=True)
    for name in frame.columns[frame.dtypes.map(lambda t: not pd.api.types.is_numeric_dtype(t))]:
        text = frame[name].dropna().astype(str)
        if len(text) and text.str.fullmatch(r"\d+:-?[\d.EE+-]+").mean() >= 0.99:
            frame[name] = frame[name].astype("string").str.split(":").str[1]
        number = pd.to_numeric(frame[name], errors="coerce")
        if len(text) and number.notna().sum() >= 0.99 * len(text):
            frame[name] = number
    return frame


def x_read_table__mutmut_31(path: Path) -> pd.DataFrame:
    """Read the CSV and repair two known quirks of the repository files, recorded not hidden:
    header lines repeated when several files were concatenated, and libsvm-style index:value
    tokens."""
    frame = pd.read_csv(path, low_memory=False)
    repeated = (frame.astype(str) == pd.Series(frame.columns, index=frame.columns)).all(axis=1)
    frame = frame[~repeated].reset_index(drop=True)
    for name in frame.columns[frame.dtypes.map(lambda t: not pd.api.types.is_numeric_dtype(t))]:
        text = frame[name].dropna().astype(str)
        if len(text) and text.str.fullmatch(r"\d+:-?[\d.eE+-]+").mean() > 0.99:
            frame[name] = frame[name].astype("string").str.split(":").str[1]
        number = pd.to_numeric(frame[name], errors="coerce")
        if len(text) and number.notna().sum() >= 0.99 * len(text):
            frame[name] = number
    return frame


def x_read_table__mutmut_32(path: Path) -> pd.DataFrame:
    """Read the CSV and repair two known quirks of the repository files, recorded not hidden:
    header lines repeated when several files were concatenated, and libsvm-style index:value
    tokens."""
    frame = pd.read_csv(path, low_memory=False)
    repeated = (frame.astype(str) == pd.Series(frame.columns, index=frame.columns)).all(axis=1)
    frame = frame[~repeated].reset_index(drop=True)
    for name in frame.columns[frame.dtypes.map(lambda t: not pd.api.types.is_numeric_dtype(t))]:
        text = frame[name].dropna().astype(str)
        if len(text) and text.str.fullmatch(r"\d+:-?[\d.eE+-]+").mean() >= 1.99:
            frame[name] = frame[name].astype("string").str.split(":").str[1]
        number = pd.to_numeric(frame[name], errors="coerce")
        if len(text) and number.notna().sum() >= 0.99 * len(text):
            frame[name] = number
    return frame


def x_read_table__mutmut_33(path: Path) -> pd.DataFrame:
    """Read the CSV and repair two known quirks of the repository files, recorded not hidden:
    header lines repeated when several files were concatenated, and libsvm-style index:value
    tokens."""
    frame = pd.read_csv(path, low_memory=False)
    repeated = (frame.astype(str) == pd.Series(frame.columns, index=frame.columns)).all(axis=1)
    frame = frame[~repeated].reset_index(drop=True)
    for name in frame.columns[frame.dtypes.map(lambda t: not pd.api.types.is_numeric_dtype(t))]:
        text = frame[name].dropna().astype(str)
        if len(text) and text.str.fullmatch(r"\d+:-?[\d.eE+-]+").mean() >= 0.99:
            frame[name] = None
        number = pd.to_numeric(frame[name], errors="coerce")
        if len(text) and number.notna().sum() >= 0.99 * len(text):
            frame[name] = number
    return frame


def x_read_table__mutmut_34(path: Path) -> pd.DataFrame:
    """Read the CSV and repair two known quirks of the repository files, recorded not hidden:
    header lines repeated when several files were concatenated, and libsvm-style index:value
    tokens."""
    frame = pd.read_csv(path, low_memory=False)
    repeated = (frame.astype(str) == pd.Series(frame.columns, index=frame.columns)).all(axis=1)
    frame = frame[~repeated].reset_index(drop=True)
    for name in frame.columns[frame.dtypes.map(lambda t: not pd.api.types.is_numeric_dtype(t))]:
        text = frame[name].dropna().astype(str)
        if len(text) and text.str.fullmatch(r"\d+:-?[\d.eE+-]+").mean() >= 0.99:
            frame[name] = frame[name].astype("string").str.split(None).str[1]
        number = pd.to_numeric(frame[name], errors="coerce")
        if len(text) and number.notna().sum() >= 0.99 * len(text):
            frame[name] = number
    return frame


def x_read_table__mutmut_35(path: Path) -> pd.DataFrame:
    """Read the CSV and repair two known quirks of the repository files, recorded not hidden:
    header lines repeated when several files were concatenated, and libsvm-style index:value
    tokens."""
    frame = pd.read_csv(path, low_memory=False)
    repeated = (frame.astype(str) == pd.Series(frame.columns, index=frame.columns)).all(axis=1)
    frame = frame[~repeated].reset_index(drop=True)
    for name in frame.columns[frame.dtypes.map(lambda t: not pd.api.types.is_numeric_dtype(t))]:
        text = frame[name].dropna().astype(str)
        if len(text) and text.str.fullmatch(r"\d+:-?[\d.eE+-]+").mean() >= 0.99:
            frame[name] = frame[name].astype(None).str.split(":").str[1]
        number = pd.to_numeric(frame[name], errors="coerce")
        if len(text) and number.notna().sum() >= 0.99 * len(text):
            frame[name] = number
    return frame


def x_read_table__mutmut_36(path: Path) -> pd.DataFrame:
    """Read the CSV and repair two known quirks of the repository files, recorded not hidden:
    header lines repeated when several files were concatenated, and libsvm-style index:value
    tokens."""
    frame = pd.read_csv(path, low_memory=False)
    repeated = (frame.astype(str) == pd.Series(frame.columns, index=frame.columns)).all(axis=1)
    frame = frame[~repeated].reset_index(drop=True)
    for name in frame.columns[frame.dtypes.map(lambda t: not pd.api.types.is_numeric_dtype(t))]:
        text = frame[name].dropna().astype(str)
        if len(text) and text.str.fullmatch(r"\d+:-?[\d.eE+-]+").mean() >= 0.99:
            frame[name] = frame[name].astype("XXstringXX").str.split(":").str[1]
        number = pd.to_numeric(frame[name], errors="coerce")
        if len(text) and number.notna().sum() >= 0.99 * len(text):
            frame[name] = number
    return frame


def x_read_table__mutmut_37(path: Path) -> pd.DataFrame:
    """Read the CSV and repair two known quirks of the repository files, recorded not hidden:
    header lines repeated when several files were concatenated, and libsvm-style index:value
    tokens."""
    frame = pd.read_csv(path, low_memory=False)
    repeated = (frame.astype(str) == pd.Series(frame.columns, index=frame.columns)).all(axis=1)
    frame = frame[~repeated].reset_index(drop=True)
    for name in frame.columns[frame.dtypes.map(lambda t: not pd.api.types.is_numeric_dtype(t))]:
        text = frame[name].dropna().astype(str)
        if len(text) and text.str.fullmatch(r"\d+:-?[\d.eE+-]+").mean() >= 0.99:
            frame[name] = frame[name].astype("STRING").str.split(":").str[1]
        number = pd.to_numeric(frame[name], errors="coerce")
        if len(text) and number.notna().sum() >= 0.99 * len(text):
            frame[name] = number
    return frame


def x_read_table__mutmut_38(path: Path) -> pd.DataFrame:
    """Read the CSV and repair two known quirks of the repository files, recorded not hidden:
    header lines repeated when several files were concatenated, and libsvm-style index:value
    tokens."""
    frame = pd.read_csv(path, low_memory=False)
    repeated = (frame.astype(str) == pd.Series(frame.columns, index=frame.columns)).all(axis=1)
    frame = frame[~repeated].reset_index(drop=True)
    for name in frame.columns[frame.dtypes.map(lambda t: not pd.api.types.is_numeric_dtype(t))]:
        text = frame[name].dropna().astype(str)
        if len(text) and text.str.fullmatch(r"\d+:-?[\d.eE+-]+").mean() >= 0.99:
            frame[name] = frame[name].astype("string").str.split("XX:XX").str[1]
        number = pd.to_numeric(frame[name], errors="coerce")
        if len(text) and number.notna().sum() >= 0.99 * len(text):
            frame[name] = number
    return frame


def x_read_table__mutmut_39(path: Path) -> pd.DataFrame:
    """Read the CSV and repair two known quirks of the repository files, recorded not hidden:
    header lines repeated when several files were concatenated, and libsvm-style index:value
    tokens."""
    frame = pd.read_csv(path, low_memory=False)
    repeated = (frame.astype(str) == pd.Series(frame.columns, index=frame.columns)).all(axis=1)
    frame = frame[~repeated].reset_index(drop=True)
    for name in frame.columns[frame.dtypes.map(lambda t: not pd.api.types.is_numeric_dtype(t))]:
        text = frame[name].dropna().astype(str)
        if len(text) and text.str.fullmatch(r"\d+:-?[\d.eE+-]+").mean() >= 0.99:
            frame[name] = frame[name].astype("string").str.split(":").str[2]
        number = pd.to_numeric(frame[name], errors="coerce")
        if len(text) and number.notna().sum() >= 0.99 * len(text):
            frame[name] = number
    return frame


def x_read_table__mutmut_40(path: Path) -> pd.DataFrame:
    """Read the CSV and repair two known quirks of the repository files, recorded not hidden:
    header lines repeated when several files were concatenated, and libsvm-style index:value
    tokens."""
    frame = pd.read_csv(path, low_memory=False)
    repeated = (frame.astype(str) == pd.Series(frame.columns, index=frame.columns)).all(axis=1)
    frame = frame[~repeated].reset_index(drop=True)
    for name in frame.columns[frame.dtypes.map(lambda t: not pd.api.types.is_numeric_dtype(t))]:
        text = frame[name].dropna().astype(str)
        if len(text) and text.str.fullmatch(r"\d+:-?[\d.eE+-]+").mean() >= 0.99:
            frame[name] = frame[name].astype("string").str.split(":").str[1]
        number = None
        if len(text) and number.notna().sum() >= 0.99 * len(text):
            frame[name] = number
    return frame


def x_read_table__mutmut_41(path: Path) -> pd.DataFrame:
    """Read the CSV and repair two known quirks of the repository files, recorded not hidden:
    header lines repeated when several files were concatenated, and libsvm-style index:value
    tokens."""
    frame = pd.read_csv(path, low_memory=False)
    repeated = (frame.astype(str) == pd.Series(frame.columns, index=frame.columns)).all(axis=1)
    frame = frame[~repeated].reset_index(drop=True)
    for name in frame.columns[frame.dtypes.map(lambda t: not pd.api.types.is_numeric_dtype(t))]:
        text = frame[name].dropna().astype(str)
        if len(text) and text.str.fullmatch(r"\d+:-?[\d.eE+-]+").mean() >= 0.99:
            frame[name] = frame[name].astype("string").str.split(":").str[1]
        number = pd.to_numeric(None, errors="coerce")
        if len(text) and number.notna().sum() >= 0.99 * len(text):
            frame[name] = number
    return frame


def x_read_table__mutmut_42(path: Path) -> pd.DataFrame:
    """Read the CSV and repair two known quirks of the repository files, recorded not hidden:
    header lines repeated when several files were concatenated, and libsvm-style index:value
    tokens."""
    frame = pd.read_csv(path, low_memory=False)
    repeated = (frame.astype(str) == pd.Series(frame.columns, index=frame.columns)).all(axis=1)
    frame = frame[~repeated].reset_index(drop=True)
    for name in frame.columns[frame.dtypes.map(lambda t: not pd.api.types.is_numeric_dtype(t))]:
        text = frame[name].dropna().astype(str)
        if len(text) and text.str.fullmatch(r"\d+:-?[\d.eE+-]+").mean() >= 0.99:
            frame[name] = frame[name].astype("string").str.split(":").str[1]
        number = pd.to_numeric(frame[name], errors=None)
        if len(text) and number.notna().sum() >= 0.99 * len(text):
            frame[name] = number
    return frame


def x_read_table__mutmut_43(path: Path) -> pd.DataFrame:
    """Read the CSV and repair two known quirks of the repository files, recorded not hidden:
    header lines repeated when several files were concatenated, and libsvm-style index:value
    tokens."""
    frame = pd.read_csv(path, low_memory=False)
    repeated = (frame.astype(str) == pd.Series(frame.columns, index=frame.columns)).all(axis=1)
    frame = frame[~repeated].reset_index(drop=True)
    for name in frame.columns[frame.dtypes.map(lambda t: not pd.api.types.is_numeric_dtype(t))]:
        text = frame[name].dropna().astype(str)
        if len(text) and text.str.fullmatch(r"\d+:-?[\d.eE+-]+").mean() >= 0.99:
            frame[name] = frame[name].astype("string").str.split(":").str[1]
        number = pd.to_numeric(errors="coerce")
        if len(text) and number.notna().sum() >= 0.99 * len(text):
            frame[name] = number
    return frame


def x_read_table__mutmut_44(path: Path) -> pd.DataFrame:
    """Read the CSV and repair two known quirks of the repository files, recorded not hidden:
    header lines repeated when several files were concatenated, and libsvm-style index:value
    tokens."""
    frame = pd.read_csv(path, low_memory=False)
    repeated = (frame.astype(str) == pd.Series(frame.columns, index=frame.columns)).all(axis=1)
    frame = frame[~repeated].reset_index(drop=True)
    for name in frame.columns[frame.dtypes.map(lambda t: not pd.api.types.is_numeric_dtype(t))]:
        text = frame[name].dropna().astype(str)
        if len(text) and text.str.fullmatch(r"\d+:-?[\d.eE+-]+").mean() >= 0.99:
            frame[name] = frame[name].astype("string").str.split(":").str[1]
        number = pd.to_numeric(frame[name], )
        if len(text) and number.notna().sum() >= 0.99 * len(text):
            frame[name] = number
    return frame


def x_read_table__mutmut_45(path: Path) -> pd.DataFrame:
    """Read the CSV and repair two known quirks of the repository files, recorded not hidden:
    header lines repeated when several files were concatenated, and libsvm-style index:value
    tokens."""
    frame = pd.read_csv(path, low_memory=False)
    repeated = (frame.astype(str) == pd.Series(frame.columns, index=frame.columns)).all(axis=1)
    frame = frame[~repeated].reset_index(drop=True)
    for name in frame.columns[frame.dtypes.map(lambda t: not pd.api.types.is_numeric_dtype(t))]:
        text = frame[name].dropna().astype(str)
        if len(text) and text.str.fullmatch(r"\d+:-?[\d.eE+-]+").mean() >= 0.99:
            frame[name] = frame[name].astype("string").str.split(":").str[1]
        number = pd.to_numeric(frame[name], errors="XXcoerceXX")
        if len(text) and number.notna().sum() >= 0.99 * len(text):
            frame[name] = number
    return frame


def x_read_table__mutmut_46(path: Path) -> pd.DataFrame:
    """Read the CSV and repair two known quirks of the repository files, recorded not hidden:
    header lines repeated when several files were concatenated, and libsvm-style index:value
    tokens."""
    frame = pd.read_csv(path, low_memory=False)
    repeated = (frame.astype(str) == pd.Series(frame.columns, index=frame.columns)).all(axis=1)
    frame = frame[~repeated].reset_index(drop=True)
    for name in frame.columns[frame.dtypes.map(lambda t: not pd.api.types.is_numeric_dtype(t))]:
        text = frame[name].dropna().astype(str)
        if len(text) and text.str.fullmatch(r"\d+:-?[\d.eE+-]+").mean() >= 0.99:
            frame[name] = frame[name].astype("string").str.split(":").str[1]
        number = pd.to_numeric(frame[name], errors="COERCE")
        if len(text) and number.notna().sum() >= 0.99 * len(text):
            frame[name] = number
    return frame


def x_read_table__mutmut_47(path: Path) -> pd.DataFrame:
    """Read the CSV and repair two known quirks of the repository files, recorded not hidden:
    header lines repeated when several files were concatenated, and libsvm-style index:value
    tokens."""
    frame = pd.read_csv(path, low_memory=False)
    repeated = (frame.astype(str) == pd.Series(frame.columns, index=frame.columns)).all(axis=1)
    frame = frame[~repeated].reset_index(drop=True)
    for name in frame.columns[frame.dtypes.map(lambda t: not pd.api.types.is_numeric_dtype(t))]:
        text = frame[name].dropna().astype(str)
        if len(text) and text.str.fullmatch(r"\d+:-?[\d.eE+-]+").mean() >= 0.99:
            frame[name] = frame[name].astype("string").str.split(":").str[1]
        number = pd.to_numeric(frame[name], errors="coerce")
        if len(text) or number.notna().sum() >= 0.99 * len(text):
            frame[name] = number
    return frame


def x_read_table__mutmut_48(path: Path) -> pd.DataFrame:
    """Read the CSV and repair two known quirks of the repository files, recorded not hidden:
    header lines repeated when several files were concatenated, and libsvm-style index:value
    tokens."""
    frame = pd.read_csv(path, low_memory=False)
    repeated = (frame.astype(str) == pd.Series(frame.columns, index=frame.columns)).all(axis=1)
    frame = frame[~repeated].reset_index(drop=True)
    for name in frame.columns[frame.dtypes.map(lambda t: not pd.api.types.is_numeric_dtype(t))]:
        text = frame[name].dropna().astype(str)
        if len(text) and text.str.fullmatch(r"\d+:-?[\d.eE+-]+").mean() >= 0.99:
            frame[name] = frame[name].astype("string").str.split(":").str[1]
        number = pd.to_numeric(frame[name], errors="coerce")
        if len(text) and number.notna().sum() > 0.99 * len(text):
            frame[name] = number
    return frame


def x_read_table__mutmut_49(path: Path) -> pd.DataFrame:
    """Read the CSV and repair two known quirks of the repository files, recorded not hidden:
    header lines repeated when several files were concatenated, and libsvm-style index:value
    tokens."""
    frame = pd.read_csv(path, low_memory=False)
    repeated = (frame.astype(str) == pd.Series(frame.columns, index=frame.columns)).all(axis=1)
    frame = frame[~repeated].reset_index(drop=True)
    for name in frame.columns[frame.dtypes.map(lambda t: not pd.api.types.is_numeric_dtype(t))]:
        text = frame[name].dropna().astype(str)
        if len(text) and text.str.fullmatch(r"\d+:-?[\d.eE+-]+").mean() >= 0.99:
            frame[name] = frame[name].astype("string").str.split(":").str[1]
        number = pd.to_numeric(frame[name], errors="coerce")
        if len(text) and number.notna().sum() >= 0.99 / len(text):
            frame[name] = number
    return frame


def x_read_table__mutmut_50(path: Path) -> pd.DataFrame:
    """Read the CSV and repair two known quirks of the repository files, recorded not hidden:
    header lines repeated when several files were concatenated, and libsvm-style index:value
    tokens."""
    frame = pd.read_csv(path, low_memory=False)
    repeated = (frame.astype(str) == pd.Series(frame.columns, index=frame.columns)).all(axis=1)
    frame = frame[~repeated].reset_index(drop=True)
    for name in frame.columns[frame.dtypes.map(lambda t: not pd.api.types.is_numeric_dtype(t))]:
        text = frame[name].dropna().astype(str)
        if len(text) and text.str.fullmatch(r"\d+:-?[\d.eE+-]+").mean() >= 0.99:
            frame[name] = frame[name].astype("string").str.split(":").str[1]
        number = pd.to_numeric(frame[name], errors="coerce")
        if len(text) and number.notna().sum() >= 1.99 * len(text):
            frame[name] = number
    return frame


def x_read_table__mutmut_51(path: Path) -> pd.DataFrame:
    """Read the CSV and repair two known quirks of the repository files, recorded not hidden:
    header lines repeated when several files were concatenated, and libsvm-style index:value
    tokens."""
    frame = pd.read_csv(path, low_memory=False)
    repeated = (frame.astype(str) == pd.Series(frame.columns, index=frame.columns)).all(axis=1)
    frame = frame[~repeated].reset_index(drop=True)
    for name in frame.columns[frame.dtypes.map(lambda t: not pd.api.types.is_numeric_dtype(t))]:
        text = frame[name].dropna().astype(str)
        if len(text) and text.str.fullmatch(r"\d+:-?[\d.eE+-]+").mean() >= 0.99:
            frame[name] = frame[name].astype("string").str.split(":").str[1]
        number = pd.to_numeric(frame[name], errors="coerce")
        if len(text) and number.notna().sum() >= 0.99 * len(text):
            frame[name] = None
    return frame

mutants_x_read_table__mutmut['_mutmut_orig'] = x_read_table__mutmut_orig # type: ignore # mutmut generated
mutants_x_read_table__mutmut['x_read_table__mutmut_1'] = x_read_table__mutmut_1 # type: ignore # mutmut generated
mutants_x_read_table__mutmut['x_read_table__mutmut_2'] = x_read_table__mutmut_2 # type: ignore # mutmut generated
mutants_x_read_table__mutmut['x_read_table__mutmut_3'] = x_read_table__mutmut_3 # type: ignore # mutmut generated
mutants_x_read_table__mutmut['x_read_table__mutmut_4'] = x_read_table__mutmut_4 # type: ignore # mutmut generated
mutants_x_read_table__mutmut['x_read_table__mutmut_5'] = x_read_table__mutmut_5 # type: ignore # mutmut generated
mutants_x_read_table__mutmut['x_read_table__mutmut_6'] = x_read_table__mutmut_6 # type: ignore # mutmut generated
mutants_x_read_table__mutmut['x_read_table__mutmut_7'] = x_read_table__mutmut_7 # type: ignore # mutmut generated
mutants_x_read_table__mutmut['x_read_table__mutmut_8'] = x_read_table__mutmut_8 # type: ignore # mutmut generated
mutants_x_read_table__mutmut['x_read_table__mutmut_9'] = x_read_table__mutmut_9 # type: ignore # mutmut generated
mutants_x_read_table__mutmut['x_read_table__mutmut_10'] = x_read_table__mutmut_10 # type: ignore # mutmut generated
mutants_x_read_table__mutmut['x_read_table__mutmut_11'] = x_read_table__mutmut_11 # type: ignore # mutmut generated
mutants_x_read_table__mutmut['x_read_table__mutmut_12'] = x_read_table__mutmut_12 # type: ignore # mutmut generated
mutants_x_read_table__mutmut['x_read_table__mutmut_13'] = x_read_table__mutmut_13 # type: ignore # mutmut generated
mutants_x_read_table__mutmut['x_read_table__mutmut_14'] = x_read_table__mutmut_14 # type: ignore # mutmut generated
mutants_x_read_table__mutmut['x_read_table__mutmut_15'] = x_read_table__mutmut_15 # type: ignore # mutmut generated
mutants_x_read_table__mutmut['x_read_table__mutmut_16'] = x_read_table__mutmut_16 # type: ignore # mutmut generated
mutants_x_read_table__mutmut['x_read_table__mutmut_17'] = x_read_table__mutmut_17 # type: ignore # mutmut generated
mutants_x_read_table__mutmut['x_read_table__mutmut_18'] = x_read_table__mutmut_18 # type: ignore # mutmut generated
mutants_x_read_table__mutmut['x_read_table__mutmut_19'] = x_read_table__mutmut_19 # type: ignore # mutmut generated
mutants_x_read_table__mutmut['x_read_table__mutmut_20'] = x_read_table__mutmut_20 # type: ignore # mutmut generated
mutants_x_read_table__mutmut['x_read_table__mutmut_21'] = x_read_table__mutmut_21 # type: ignore # mutmut generated
mutants_x_read_table__mutmut['x_read_table__mutmut_22'] = x_read_table__mutmut_22 # type: ignore # mutmut generated
mutants_x_read_table__mutmut['x_read_table__mutmut_23'] = x_read_table__mutmut_23 # type: ignore # mutmut generated
mutants_x_read_table__mutmut['x_read_table__mutmut_24'] = x_read_table__mutmut_24 # type: ignore # mutmut generated
mutants_x_read_table__mutmut['x_read_table__mutmut_25'] = x_read_table__mutmut_25 # type: ignore # mutmut generated
mutants_x_read_table__mutmut['x_read_table__mutmut_26'] = x_read_table__mutmut_26 # type: ignore # mutmut generated
mutants_x_read_table__mutmut['x_read_table__mutmut_27'] = x_read_table__mutmut_27 # type: ignore # mutmut generated
mutants_x_read_table__mutmut['x_read_table__mutmut_28'] = x_read_table__mutmut_28 # type: ignore # mutmut generated
mutants_x_read_table__mutmut['x_read_table__mutmut_29'] = x_read_table__mutmut_29 # type: ignore # mutmut generated
mutants_x_read_table__mutmut['x_read_table__mutmut_30'] = x_read_table__mutmut_30 # type: ignore # mutmut generated
mutants_x_read_table__mutmut['x_read_table__mutmut_31'] = x_read_table__mutmut_31 # type: ignore # mutmut generated
mutants_x_read_table__mutmut['x_read_table__mutmut_32'] = x_read_table__mutmut_32 # type: ignore # mutmut generated
mutants_x_read_table__mutmut['x_read_table__mutmut_33'] = x_read_table__mutmut_33 # type: ignore # mutmut generated
mutants_x_read_table__mutmut['x_read_table__mutmut_34'] = x_read_table__mutmut_34 # type: ignore # mutmut generated
mutants_x_read_table__mutmut['x_read_table__mutmut_35'] = x_read_table__mutmut_35 # type: ignore # mutmut generated
mutants_x_read_table__mutmut['x_read_table__mutmut_36'] = x_read_table__mutmut_36 # type: ignore # mutmut generated
mutants_x_read_table__mutmut['x_read_table__mutmut_37'] = x_read_table__mutmut_37 # type: ignore # mutmut generated
mutants_x_read_table__mutmut['x_read_table__mutmut_38'] = x_read_table__mutmut_38 # type: ignore # mutmut generated
mutants_x_read_table__mutmut['x_read_table__mutmut_39'] = x_read_table__mutmut_39 # type: ignore # mutmut generated
mutants_x_read_table__mutmut['x_read_table__mutmut_40'] = x_read_table__mutmut_40 # type: ignore # mutmut generated
mutants_x_read_table__mutmut['x_read_table__mutmut_41'] = x_read_table__mutmut_41 # type: ignore # mutmut generated
mutants_x_read_table__mutmut['x_read_table__mutmut_42'] = x_read_table__mutmut_42 # type: ignore # mutmut generated
mutants_x_read_table__mutmut['x_read_table__mutmut_43'] = x_read_table__mutmut_43 # type: ignore # mutmut generated
mutants_x_read_table__mutmut['x_read_table__mutmut_44'] = x_read_table__mutmut_44 # type: ignore # mutmut generated
mutants_x_read_table__mutmut['x_read_table__mutmut_45'] = x_read_table__mutmut_45 # type: ignore # mutmut generated
mutants_x_read_table__mutmut['x_read_table__mutmut_46'] = x_read_table__mutmut_46 # type: ignore # mutmut generated
mutants_x_read_table__mutmut['x_read_table__mutmut_47'] = x_read_table__mutmut_47 # type: ignore # mutmut generated
mutants_x_read_table__mutmut['x_read_table__mutmut_48'] = x_read_table__mutmut_48 # type: ignore # mutmut generated
mutants_x_read_table__mutmut['x_read_table__mutmut_49'] = x_read_table__mutmut_49 # type: ignore # mutmut generated
mutants_x_read_table__mutmut['x_read_table__mutmut_50'] = x_read_table__mutmut_50 # type: ignore # mutmut generated
mutants_x_read_table__mutmut['x_read_table__mutmut_51'] = x_read_table__mutmut_51 # type: ignore # mutmut generated
mutants_x_split_columns__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_split_columns__mutmut)
def split_columns(frame: pd.DataFrame, meta: dict[str, Any]) -> tuple[pd.DataFrame, pd.Series]:
    targets = [c for c in meta.get("target_col") or [] if c in frame.columns]
    roles = {v["name"]: v.get("role") for v in meta.get("variables") or []}
    drop = set(targets) | {c for c, role in roles.items() if role in {"ID", "Other"}}
    features = frame[[c for c in frame.columns if c not in drop]]
    target = frame[targets[0]] if len(targets) == 1 else pd.Series(np.nan, index=frame.index)
    return features, target


def x_split_columns__mutmut_orig(frame: pd.DataFrame, meta: dict[str, Any]) -> tuple[pd.DataFrame, pd.Series]:
    targets = [c for c in meta.get("target_col") or [] if c in frame.columns]
    roles = {v["name"]: v.get("role") for v in meta.get("variables") or []}
    drop = set(targets) | {c for c, role in roles.items() if role in {"ID", "Other"}}
    features = frame[[c for c in frame.columns if c not in drop]]
    target = frame[targets[0]] if len(targets) == 1 else pd.Series(np.nan, index=frame.index)
    return features, target


def x_split_columns__mutmut_1(frame: pd.DataFrame, meta: dict[str, Any]) -> tuple[pd.DataFrame, pd.Series]:
    targets = None
    roles = {v["name"]: v.get("role") for v in meta.get("variables") or []}
    drop = set(targets) | {c for c, role in roles.items() if role in {"ID", "Other"}}
    features = frame[[c for c in frame.columns if c not in drop]]
    target = frame[targets[0]] if len(targets) == 1 else pd.Series(np.nan, index=frame.index)
    return features, target


def x_split_columns__mutmut_2(frame: pd.DataFrame, meta: dict[str, Any]) -> tuple[pd.DataFrame, pd.Series]:
    targets = [c for c in meta.get("target_col") and [] if c in frame.columns]
    roles = {v["name"]: v.get("role") for v in meta.get("variables") or []}
    drop = set(targets) | {c for c, role in roles.items() if role in {"ID", "Other"}}
    features = frame[[c for c in frame.columns if c not in drop]]
    target = frame[targets[0]] if len(targets) == 1 else pd.Series(np.nan, index=frame.index)
    return features, target


def x_split_columns__mutmut_3(frame: pd.DataFrame, meta: dict[str, Any]) -> tuple[pd.DataFrame, pd.Series]:
    targets = [c for c in meta.get(None) or [] if c in frame.columns]
    roles = {v["name"]: v.get("role") for v in meta.get("variables") or []}
    drop = set(targets) | {c for c, role in roles.items() if role in {"ID", "Other"}}
    features = frame[[c for c in frame.columns if c not in drop]]
    target = frame[targets[0]] if len(targets) == 1 else pd.Series(np.nan, index=frame.index)
    return features, target


def x_split_columns__mutmut_4(frame: pd.DataFrame, meta: dict[str, Any]) -> tuple[pd.DataFrame, pd.Series]:
    targets = [c for c in meta.get("XXtarget_colXX") or [] if c in frame.columns]
    roles = {v["name"]: v.get("role") for v in meta.get("variables") or []}
    drop = set(targets) | {c for c, role in roles.items() if role in {"ID", "Other"}}
    features = frame[[c for c in frame.columns if c not in drop]]
    target = frame[targets[0]] if len(targets) == 1 else pd.Series(np.nan, index=frame.index)
    return features, target


def x_split_columns__mutmut_5(frame: pd.DataFrame, meta: dict[str, Any]) -> tuple[pd.DataFrame, pd.Series]:
    targets = [c for c in meta.get("TARGET_COL") or [] if c in frame.columns]
    roles = {v["name"]: v.get("role") for v in meta.get("variables") or []}
    drop = set(targets) | {c for c, role in roles.items() if role in {"ID", "Other"}}
    features = frame[[c for c in frame.columns if c not in drop]]
    target = frame[targets[0]] if len(targets) == 1 else pd.Series(np.nan, index=frame.index)
    return features, target


def x_split_columns__mutmut_6(frame: pd.DataFrame, meta: dict[str, Any]) -> tuple[pd.DataFrame, pd.Series]:
    targets = [c for c in meta.get("target_col") or [] if c not in frame.columns]
    roles = {v["name"]: v.get("role") for v in meta.get("variables") or []}
    drop = set(targets) | {c for c, role in roles.items() if role in {"ID", "Other"}}
    features = frame[[c for c in frame.columns if c not in drop]]
    target = frame[targets[0]] if len(targets) == 1 else pd.Series(np.nan, index=frame.index)
    return features, target


def x_split_columns__mutmut_7(frame: pd.DataFrame, meta: dict[str, Any]) -> tuple[pd.DataFrame, pd.Series]:
    targets = [c for c in meta.get("target_col") or [] if c in frame.columns]
    roles = None
    drop = set(targets) | {c for c, role in roles.items() if role in {"ID", "Other"}}
    features = frame[[c for c in frame.columns if c not in drop]]
    target = frame[targets[0]] if len(targets) == 1 else pd.Series(np.nan, index=frame.index)
    return features, target


def x_split_columns__mutmut_8(frame: pd.DataFrame, meta: dict[str, Any]) -> tuple[pd.DataFrame, pd.Series]:
    targets = [c for c in meta.get("target_col") or [] if c in frame.columns]
    roles = {v["XXnameXX"]: v.get("role") for v in meta.get("variables") or []}
    drop = set(targets) | {c for c, role in roles.items() if role in {"ID", "Other"}}
    features = frame[[c for c in frame.columns if c not in drop]]
    target = frame[targets[0]] if len(targets) == 1 else pd.Series(np.nan, index=frame.index)
    return features, target


def x_split_columns__mutmut_9(frame: pd.DataFrame, meta: dict[str, Any]) -> tuple[pd.DataFrame, pd.Series]:
    targets = [c for c in meta.get("target_col") or [] if c in frame.columns]
    roles = {v["NAME"]: v.get("role") for v in meta.get("variables") or []}
    drop = set(targets) | {c for c, role in roles.items() if role in {"ID", "Other"}}
    features = frame[[c for c in frame.columns if c not in drop]]
    target = frame[targets[0]] if len(targets) == 1 else pd.Series(np.nan, index=frame.index)
    return features, target


def x_split_columns__mutmut_10(frame: pd.DataFrame, meta: dict[str, Any]) -> tuple[pd.DataFrame, pd.Series]:
    targets = [c for c in meta.get("target_col") or [] if c in frame.columns]
    roles = {v["name"]: v.get(None) for v in meta.get("variables") or []}
    drop = set(targets) | {c for c, role in roles.items() if role in {"ID", "Other"}}
    features = frame[[c for c in frame.columns if c not in drop]]
    target = frame[targets[0]] if len(targets) == 1 else pd.Series(np.nan, index=frame.index)
    return features, target


def x_split_columns__mutmut_11(frame: pd.DataFrame, meta: dict[str, Any]) -> tuple[pd.DataFrame, pd.Series]:
    targets = [c for c in meta.get("target_col") or [] if c in frame.columns]
    roles = {v["name"]: v.get("XXroleXX") for v in meta.get("variables") or []}
    drop = set(targets) | {c for c, role in roles.items() if role in {"ID", "Other"}}
    features = frame[[c for c in frame.columns if c not in drop]]
    target = frame[targets[0]] if len(targets) == 1 else pd.Series(np.nan, index=frame.index)
    return features, target


def x_split_columns__mutmut_12(frame: pd.DataFrame, meta: dict[str, Any]) -> tuple[pd.DataFrame, pd.Series]:
    targets = [c for c in meta.get("target_col") or [] if c in frame.columns]
    roles = {v["name"]: v.get("ROLE") for v in meta.get("variables") or []}
    drop = set(targets) | {c for c, role in roles.items() if role in {"ID", "Other"}}
    features = frame[[c for c in frame.columns if c not in drop]]
    target = frame[targets[0]] if len(targets) == 1 else pd.Series(np.nan, index=frame.index)
    return features, target


def x_split_columns__mutmut_13(frame: pd.DataFrame, meta: dict[str, Any]) -> tuple[pd.DataFrame, pd.Series]:
    targets = [c for c in meta.get("target_col") or [] if c in frame.columns]
    roles = {v["name"]: v.get("role") for v in meta.get("variables") and []}
    drop = set(targets) | {c for c, role in roles.items() if role in {"ID", "Other"}}
    features = frame[[c for c in frame.columns if c not in drop]]
    target = frame[targets[0]] if len(targets) == 1 else pd.Series(np.nan, index=frame.index)
    return features, target


def x_split_columns__mutmut_14(frame: pd.DataFrame, meta: dict[str, Any]) -> tuple[pd.DataFrame, pd.Series]:
    targets = [c for c in meta.get("target_col") or [] if c in frame.columns]
    roles = {v["name"]: v.get("role") for v in meta.get(None) or []}
    drop = set(targets) | {c for c, role in roles.items() if role in {"ID", "Other"}}
    features = frame[[c for c in frame.columns if c not in drop]]
    target = frame[targets[0]] if len(targets) == 1 else pd.Series(np.nan, index=frame.index)
    return features, target


def x_split_columns__mutmut_15(frame: pd.DataFrame, meta: dict[str, Any]) -> tuple[pd.DataFrame, pd.Series]:
    targets = [c for c in meta.get("target_col") or [] if c in frame.columns]
    roles = {v["name"]: v.get("role") for v in meta.get("XXvariablesXX") or []}
    drop = set(targets) | {c for c, role in roles.items() if role in {"ID", "Other"}}
    features = frame[[c for c in frame.columns if c not in drop]]
    target = frame[targets[0]] if len(targets) == 1 else pd.Series(np.nan, index=frame.index)
    return features, target


def x_split_columns__mutmut_16(frame: pd.DataFrame, meta: dict[str, Any]) -> tuple[pd.DataFrame, pd.Series]:
    targets = [c for c in meta.get("target_col") or [] if c in frame.columns]
    roles = {v["name"]: v.get("role") for v in meta.get("VARIABLES") or []}
    drop = set(targets) | {c for c, role in roles.items() if role in {"ID", "Other"}}
    features = frame[[c for c in frame.columns if c not in drop]]
    target = frame[targets[0]] if len(targets) == 1 else pd.Series(np.nan, index=frame.index)
    return features, target


def x_split_columns__mutmut_17(frame: pd.DataFrame, meta: dict[str, Any]) -> tuple[pd.DataFrame, pd.Series]:
    targets = [c for c in meta.get("target_col") or [] if c in frame.columns]
    roles = {v["name"]: v.get("role") for v in meta.get("variables") or []}
    drop = None
    features = frame[[c for c in frame.columns if c not in drop]]
    target = frame[targets[0]] if len(targets) == 1 else pd.Series(np.nan, index=frame.index)
    return features, target


def x_split_columns__mutmut_18(frame: pd.DataFrame, meta: dict[str, Any]) -> tuple[pd.DataFrame, pd.Series]:
    targets = [c for c in meta.get("target_col") or [] if c in frame.columns]
    roles = {v["name"]: v.get("role") for v in meta.get("variables") or []}
    drop = set(targets) & {c for c, role in roles.items() if role in {"ID", "Other"}}
    features = frame[[c for c in frame.columns if c not in drop]]
    target = frame[targets[0]] if len(targets) == 1 else pd.Series(np.nan, index=frame.index)
    return features, target


def x_split_columns__mutmut_19(frame: pd.DataFrame, meta: dict[str, Any]) -> tuple[pd.DataFrame, pd.Series]:
    targets = [c for c in meta.get("target_col") or [] if c in frame.columns]
    roles = {v["name"]: v.get("role") for v in meta.get("variables") or []}
    drop = set(None) | {c for c, role in roles.items() if role in {"ID", "Other"}}
    features = frame[[c for c in frame.columns if c not in drop]]
    target = frame[targets[0]] if len(targets) == 1 else pd.Series(np.nan, index=frame.index)
    return features, target


def x_split_columns__mutmut_20(frame: pd.DataFrame, meta: dict[str, Any]) -> tuple[pd.DataFrame, pd.Series]:
    targets = [c for c in meta.get("target_col") or [] if c in frame.columns]
    roles = {v["name"]: v.get("role") for v in meta.get("variables") or []}
    drop = set(targets) | {c for c, role in roles.items() if role not in {"ID", "Other"}}
    features = frame[[c for c in frame.columns if c not in drop]]
    target = frame[targets[0]] if len(targets) == 1 else pd.Series(np.nan, index=frame.index)
    return features, target


def x_split_columns__mutmut_21(frame: pd.DataFrame, meta: dict[str, Any]) -> tuple[pd.DataFrame, pd.Series]:
    targets = [c for c in meta.get("target_col") or [] if c in frame.columns]
    roles = {v["name"]: v.get("role") for v in meta.get("variables") or []}
    drop = set(targets) | {c for c, role in roles.items() if role in {"XXIDXX", "Other"}}
    features = frame[[c for c in frame.columns if c not in drop]]
    target = frame[targets[0]] if len(targets) == 1 else pd.Series(np.nan, index=frame.index)
    return features, target


def x_split_columns__mutmut_22(frame: pd.DataFrame, meta: dict[str, Any]) -> tuple[pd.DataFrame, pd.Series]:
    targets = [c for c in meta.get("target_col") or [] if c in frame.columns]
    roles = {v["name"]: v.get("role") for v in meta.get("variables") or []}
    drop = set(targets) | {c for c, role in roles.items() if role in {"id", "Other"}}
    features = frame[[c for c in frame.columns if c not in drop]]
    target = frame[targets[0]] if len(targets) == 1 else pd.Series(np.nan, index=frame.index)
    return features, target


def x_split_columns__mutmut_23(frame: pd.DataFrame, meta: dict[str, Any]) -> tuple[pd.DataFrame, pd.Series]:
    targets = [c for c in meta.get("target_col") or [] if c in frame.columns]
    roles = {v["name"]: v.get("role") for v in meta.get("variables") or []}
    drop = set(targets) | {c for c, role in roles.items() if role in {"ID", "XXOtherXX"}}
    features = frame[[c for c in frame.columns if c not in drop]]
    target = frame[targets[0]] if len(targets) == 1 else pd.Series(np.nan, index=frame.index)
    return features, target


def x_split_columns__mutmut_24(frame: pd.DataFrame, meta: dict[str, Any]) -> tuple[pd.DataFrame, pd.Series]:
    targets = [c for c in meta.get("target_col") or [] if c in frame.columns]
    roles = {v["name"]: v.get("role") for v in meta.get("variables") or []}
    drop = set(targets) | {c for c, role in roles.items() if role in {"ID", "other"}}
    features = frame[[c for c in frame.columns if c not in drop]]
    target = frame[targets[0]] if len(targets) == 1 else pd.Series(np.nan, index=frame.index)
    return features, target


def x_split_columns__mutmut_25(frame: pd.DataFrame, meta: dict[str, Any]) -> tuple[pd.DataFrame, pd.Series]:
    targets = [c for c in meta.get("target_col") or [] if c in frame.columns]
    roles = {v["name"]: v.get("role") for v in meta.get("variables") or []}
    drop = set(targets) | {c for c, role in roles.items() if role in {"ID", "OTHER"}}
    features = frame[[c for c in frame.columns if c not in drop]]
    target = frame[targets[0]] if len(targets) == 1 else pd.Series(np.nan, index=frame.index)
    return features, target


def x_split_columns__mutmut_26(frame: pd.DataFrame, meta: dict[str, Any]) -> tuple[pd.DataFrame, pd.Series]:
    targets = [c for c in meta.get("target_col") or [] if c in frame.columns]
    roles = {v["name"]: v.get("role") for v in meta.get("variables") or []}
    drop = set(targets) | {c for c, role in roles.items() if role in {"ID", "Other"}}
    features = None
    target = frame[targets[0]] if len(targets) == 1 else pd.Series(np.nan, index=frame.index)
    return features, target


def x_split_columns__mutmut_27(frame: pd.DataFrame, meta: dict[str, Any]) -> tuple[pd.DataFrame, pd.Series]:
    targets = [c for c in meta.get("target_col") or [] if c in frame.columns]
    roles = {v["name"]: v.get("role") for v in meta.get("variables") or []}
    drop = set(targets) | {c for c, role in roles.items() if role in {"ID", "Other"}}
    features = frame[[c for c in frame.columns if c in drop]]
    target = frame[targets[0]] if len(targets) == 1 else pd.Series(np.nan, index=frame.index)
    return features, target


def x_split_columns__mutmut_28(frame: pd.DataFrame, meta: dict[str, Any]) -> tuple[pd.DataFrame, pd.Series]:
    targets = [c for c in meta.get("target_col") or [] if c in frame.columns]
    roles = {v["name"]: v.get("role") for v in meta.get("variables") or []}
    drop = set(targets) | {c for c, role in roles.items() if role in {"ID", "Other"}}
    features = frame[[c for c in frame.columns if c not in drop]]
    target = None
    return features, target


def x_split_columns__mutmut_29(frame: pd.DataFrame, meta: dict[str, Any]) -> tuple[pd.DataFrame, pd.Series]:
    targets = [c for c in meta.get("target_col") or [] if c in frame.columns]
    roles = {v["name"]: v.get("role") for v in meta.get("variables") or []}
    drop = set(targets) | {c for c, role in roles.items() if role in {"ID", "Other"}}
    features = frame[[c for c in frame.columns if c not in drop]]
    target = frame[targets[0]] if (len(targets) == 1) and False else pd.Series(np.nan, index=frame.index)
    return features, target


def x_split_columns__mutmut_30(frame: pd.DataFrame, meta: dict[str, Any]) -> tuple[pd.DataFrame, pd.Series]:
    targets = [c for c in meta.get("target_col") or [] if c in frame.columns]
    roles = {v["name"]: v.get("role") for v in meta.get("variables") or []}
    drop = set(targets) | {c for c, role in roles.items() if role in {"ID", "Other"}}
    features = frame[[c for c in frame.columns if c not in drop]]
    target = frame[targets[0]] if (len(targets) == 1) or True else pd.Series(np.nan, index=frame.index)
    return features, target


def x_split_columns__mutmut_31(frame: pd.DataFrame, meta: dict[str, Any]) -> tuple[pd.DataFrame, pd.Series]:
    targets = [c for c in meta.get("target_col") or [] if c in frame.columns]
    roles = {v["name"]: v.get("role") for v in meta.get("variables") or []}
    drop = set(targets) | {c for c, role in roles.items() if role in {"ID", "Other"}}
    features = frame[[c for c in frame.columns if c not in drop]]
    target = frame[targets[1]] if len(targets) == 1 else pd.Series(np.nan, index=frame.index)
    return features, target


def x_split_columns__mutmut_32(frame: pd.DataFrame, meta: dict[str, Any]) -> tuple[pd.DataFrame, pd.Series]:
    targets = [c for c in meta.get("target_col") or [] if c in frame.columns]
    roles = {v["name"]: v.get("role") for v in meta.get("variables") or []}
    drop = set(targets) | {c for c, role in roles.items() if role in {"ID", "Other"}}
    features = frame[[c for c in frame.columns if c not in drop]]
    target = frame[targets[0]] if len(targets) != 1 else pd.Series(np.nan, index=frame.index)
    return features, target


def x_split_columns__mutmut_33(frame: pd.DataFrame, meta: dict[str, Any]) -> tuple[pd.DataFrame, pd.Series]:
    targets = [c for c in meta.get("target_col") or [] if c in frame.columns]
    roles = {v["name"]: v.get("role") for v in meta.get("variables") or []}
    drop = set(targets) | {c for c, role in roles.items() if role in {"ID", "Other"}}
    features = frame[[c for c in frame.columns if c not in drop]]
    target = frame[targets[0]] if len(targets) == 2 else pd.Series(np.nan, index=frame.index)
    return features, target


def x_split_columns__mutmut_34(frame: pd.DataFrame, meta: dict[str, Any]) -> tuple[pd.DataFrame, pd.Series]:
    targets = [c for c in meta.get("target_col") or [] if c in frame.columns]
    roles = {v["name"]: v.get("role") for v in meta.get("variables") or []}
    drop = set(targets) | {c for c, role in roles.items() if role in {"ID", "Other"}}
    features = frame[[c for c in frame.columns if c not in drop]]
    target = frame[targets[0]] if len(targets) == 1 else pd.Series(None, index=frame.index)
    return features, target


def x_split_columns__mutmut_35(frame: pd.DataFrame, meta: dict[str, Any]) -> tuple[pd.DataFrame, pd.Series]:
    targets = [c for c in meta.get("target_col") or [] if c in frame.columns]
    roles = {v["name"]: v.get("role") for v in meta.get("variables") or []}
    drop = set(targets) | {c for c, role in roles.items() if role in {"ID", "Other"}}
    features = frame[[c for c in frame.columns if c not in drop]]
    target = frame[targets[0]] if len(targets) == 1 else pd.Series(np.nan, index=None)
    return features, target


def x_split_columns__mutmut_36(frame: pd.DataFrame, meta: dict[str, Any]) -> tuple[pd.DataFrame, pd.Series]:
    targets = [c for c in meta.get("target_col") or [] if c in frame.columns]
    roles = {v["name"]: v.get("role") for v in meta.get("variables") or []}
    drop = set(targets) | {c for c, role in roles.items() if role in {"ID", "Other"}}
    features = frame[[c for c in frame.columns if c not in drop]]
    target = frame[targets[0]] if len(targets) == 1 else pd.Series(index=frame.index)
    return features, target


def x_split_columns__mutmut_37(frame: pd.DataFrame, meta: dict[str, Any]) -> tuple[pd.DataFrame, pd.Series]:
    targets = [c for c in meta.get("target_col") or [] if c in frame.columns]
    roles = {v["name"]: v.get("role") for v in meta.get("variables") or []}
    drop = set(targets) | {c for c, role in roles.items() if role in {"ID", "Other"}}
    features = frame[[c for c in frame.columns if c not in drop]]
    target = frame[targets[0]] if len(targets) == 1 else pd.Series(np.nan, )
    return features, target

mutants_x_split_columns__mutmut['_mutmut_orig'] = x_split_columns__mutmut_orig # type: ignore # mutmut generated
mutants_x_split_columns__mutmut['x_split_columns__mutmut_1'] = x_split_columns__mutmut_1 # type: ignore # mutmut generated
mutants_x_split_columns__mutmut['x_split_columns__mutmut_2'] = x_split_columns__mutmut_2 # type: ignore # mutmut generated
mutants_x_split_columns__mutmut['x_split_columns__mutmut_3'] = x_split_columns__mutmut_3 # type: ignore # mutmut generated
mutants_x_split_columns__mutmut['x_split_columns__mutmut_4'] = x_split_columns__mutmut_4 # type: ignore # mutmut generated
mutants_x_split_columns__mutmut['x_split_columns__mutmut_5'] = x_split_columns__mutmut_5 # type: ignore # mutmut generated
mutants_x_split_columns__mutmut['x_split_columns__mutmut_6'] = x_split_columns__mutmut_6 # type: ignore # mutmut generated
mutants_x_split_columns__mutmut['x_split_columns__mutmut_7'] = x_split_columns__mutmut_7 # type: ignore # mutmut generated
mutants_x_split_columns__mutmut['x_split_columns__mutmut_8'] = x_split_columns__mutmut_8 # type: ignore # mutmut generated
mutants_x_split_columns__mutmut['x_split_columns__mutmut_9'] = x_split_columns__mutmut_9 # type: ignore # mutmut generated
mutants_x_split_columns__mutmut['x_split_columns__mutmut_10'] = x_split_columns__mutmut_10 # type: ignore # mutmut generated
mutants_x_split_columns__mutmut['x_split_columns__mutmut_11'] = x_split_columns__mutmut_11 # type: ignore # mutmut generated
mutants_x_split_columns__mutmut['x_split_columns__mutmut_12'] = x_split_columns__mutmut_12 # type: ignore # mutmut generated
mutants_x_split_columns__mutmut['x_split_columns__mutmut_13'] = x_split_columns__mutmut_13 # type: ignore # mutmut generated
mutants_x_split_columns__mutmut['x_split_columns__mutmut_14'] = x_split_columns__mutmut_14 # type: ignore # mutmut generated
mutants_x_split_columns__mutmut['x_split_columns__mutmut_15'] = x_split_columns__mutmut_15 # type: ignore # mutmut generated
mutants_x_split_columns__mutmut['x_split_columns__mutmut_16'] = x_split_columns__mutmut_16 # type: ignore # mutmut generated
mutants_x_split_columns__mutmut['x_split_columns__mutmut_17'] = x_split_columns__mutmut_17 # type: ignore # mutmut generated
mutants_x_split_columns__mutmut['x_split_columns__mutmut_18'] = x_split_columns__mutmut_18 # type: ignore # mutmut generated
mutants_x_split_columns__mutmut['x_split_columns__mutmut_19'] = x_split_columns__mutmut_19 # type: ignore # mutmut generated
mutants_x_split_columns__mutmut['x_split_columns__mutmut_20'] = x_split_columns__mutmut_20 # type: ignore # mutmut generated
mutants_x_split_columns__mutmut['x_split_columns__mutmut_21'] = x_split_columns__mutmut_21 # type: ignore # mutmut generated
mutants_x_split_columns__mutmut['x_split_columns__mutmut_22'] = x_split_columns__mutmut_22 # type: ignore # mutmut generated
mutants_x_split_columns__mutmut['x_split_columns__mutmut_23'] = x_split_columns__mutmut_23 # type: ignore # mutmut generated
mutants_x_split_columns__mutmut['x_split_columns__mutmut_24'] = x_split_columns__mutmut_24 # type: ignore # mutmut generated
mutants_x_split_columns__mutmut['x_split_columns__mutmut_25'] = x_split_columns__mutmut_25 # type: ignore # mutmut generated
mutants_x_split_columns__mutmut['x_split_columns__mutmut_26'] = x_split_columns__mutmut_26 # type: ignore # mutmut generated
mutants_x_split_columns__mutmut['x_split_columns__mutmut_27'] = x_split_columns__mutmut_27 # type: ignore # mutmut generated
mutants_x_split_columns__mutmut['x_split_columns__mutmut_28'] = x_split_columns__mutmut_28 # type: ignore # mutmut generated
mutants_x_split_columns__mutmut['x_split_columns__mutmut_29'] = x_split_columns__mutmut_29 # type: ignore # mutmut generated
mutants_x_split_columns__mutmut['x_split_columns__mutmut_30'] = x_split_columns__mutmut_30 # type: ignore # mutmut generated
mutants_x_split_columns__mutmut['x_split_columns__mutmut_31'] = x_split_columns__mutmut_31 # type: ignore # mutmut generated
mutants_x_split_columns__mutmut['x_split_columns__mutmut_32'] = x_split_columns__mutmut_32 # type: ignore # mutmut generated
mutants_x_split_columns__mutmut['x_split_columns__mutmut_33'] = x_split_columns__mutmut_33 # type: ignore # mutmut generated
mutants_x_split_columns__mutmut['x_split_columns__mutmut_34'] = x_split_columns__mutmut_34 # type: ignore # mutmut generated
mutants_x_split_columns__mutmut['x_split_columns__mutmut_35'] = x_split_columns__mutmut_35 # type: ignore # mutmut generated
mutants_x_split_columns__mutmut['x_split_columns__mutmut_36'] = x_split_columns__mutmut_36 # type: ignore # mutmut generated
mutants_x_split_columns__mutmut['x_split_columns__mutmut_37'] = x_split_columns__mutmut_37 # type: ignore # mutmut generated
mutants_x_derive_labels__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_derive_labels__mutmut)
def derive_labels(
    frame: pd.DataFrame, meta: dict[str, Any]
) -> tuple[pd.DataFrame, np.ndarray, dict[str, Any]]:
    if "Classification" not in (meta.get("tasks") or []):
        raise NoLabels("not a classification task")
    features, target = split_columns(frame, meta)
    known = target.notna().to_numpy()
    features, target = features[known].reset_index(drop=True), target[known].reset_index(drop=True)
    counts = target.astype(str).value_counts()
    if len(counts) < 2:
        raise NoLabels("fewer than 2 classes")
    rare = str(counts.index[-1])
    if counts.iloc[-1] < MIN_ANOMALIES:
        raise NoLabels(f"fewer than {MIN_ANOMALIES} rows in the rarest class")
    is_rare = (target.astype(str) == rare).to_numpy()
    natural = float(is_rare.mean())
    info: dict[str, Any] = {
        "anomaly_class": rare,
        "classes": int(len(counts)),
        "natural_rate": natural,
        "kind": "native_rare",
    }
    keep = np.ones(len(target), dtype=bool)
    if natural > TARGET_RATE:
        n_normal = int((~is_rare).sum())
        k = round(n_normal * TARGET_RATE / (1 - TARGET_RATE))
        chosen = np.random.default_rng(SEED).choice(np.flatnonzero(is_rare), k, replace=False)
        keep = ~is_rare
        keep[chosen] = True
        info["kind"] = "downsampled"
    labels = is_rare[keep].astype(int)
    info.update(rows=int(keep.sum()), anomalies=int(labels.sum()))
    return features[keep].reset_index(drop=True), labels, info


def x_derive_labels__mutmut_orig(
    frame: pd.DataFrame, meta: dict[str, Any]
) -> tuple[pd.DataFrame, np.ndarray, dict[str, Any]]:
    if "Classification" not in (meta.get("tasks") or []):
        raise NoLabels("not a classification task")
    features, target = split_columns(frame, meta)
    known = target.notna().to_numpy()
    features, target = features[known].reset_index(drop=True), target[known].reset_index(drop=True)
    counts = target.astype(str).value_counts()
    if len(counts) < 2:
        raise NoLabels("fewer than 2 classes")
    rare = str(counts.index[-1])
    if counts.iloc[-1] < MIN_ANOMALIES:
        raise NoLabels(f"fewer than {MIN_ANOMALIES} rows in the rarest class")
    is_rare = (target.astype(str) == rare).to_numpy()
    natural = float(is_rare.mean())
    info: dict[str, Any] = {
        "anomaly_class": rare,
        "classes": int(len(counts)),
        "natural_rate": natural,
        "kind": "native_rare",
    }
    keep = np.ones(len(target), dtype=bool)
    if natural > TARGET_RATE:
        n_normal = int((~is_rare).sum())
        k = round(n_normal * TARGET_RATE / (1 - TARGET_RATE))
        chosen = np.random.default_rng(SEED).choice(np.flatnonzero(is_rare), k, replace=False)
        keep = ~is_rare
        keep[chosen] = True
        info["kind"] = "downsampled"
    labels = is_rare[keep].astype(int)
    info.update(rows=int(keep.sum()), anomalies=int(labels.sum()))
    return features[keep].reset_index(drop=True), labels, info


def x_derive_labels__mutmut_1(
    frame: pd.DataFrame, meta: dict[str, Any]
) -> tuple[pd.DataFrame, np.ndarray, dict[str, Any]]:
    if "XXClassificationXX" not in (meta.get("tasks") or []):
        raise NoLabels("not a classification task")
    features, target = split_columns(frame, meta)
    known = target.notna().to_numpy()
    features, target = features[known].reset_index(drop=True), target[known].reset_index(drop=True)
    counts = target.astype(str).value_counts()
    if len(counts) < 2:
        raise NoLabels("fewer than 2 classes")
    rare = str(counts.index[-1])
    if counts.iloc[-1] < MIN_ANOMALIES:
        raise NoLabels(f"fewer than {MIN_ANOMALIES} rows in the rarest class")
    is_rare = (target.astype(str) == rare).to_numpy()
    natural = float(is_rare.mean())
    info: dict[str, Any] = {
        "anomaly_class": rare,
        "classes": int(len(counts)),
        "natural_rate": natural,
        "kind": "native_rare",
    }
    keep = np.ones(len(target), dtype=bool)
    if natural > TARGET_RATE:
        n_normal = int((~is_rare).sum())
        k = round(n_normal * TARGET_RATE / (1 - TARGET_RATE))
        chosen = np.random.default_rng(SEED).choice(np.flatnonzero(is_rare), k, replace=False)
        keep = ~is_rare
        keep[chosen] = True
        info["kind"] = "downsampled"
    labels = is_rare[keep].astype(int)
    info.update(rows=int(keep.sum()), anomalies=int(labels.sum()))
    return features[keep].reset_index(drop=True), labels, info


def x_derive_labels__mutmut_2(
    frame: pd.DataFrame, meta: dict[str, Any]
) -> tuple[pd.DataFrame, np.ndarray, dict[str, Any]]:
    if "classification" not in (meta.get("tasks") or []):
        raise NoLabels("not a classification task")
    features, target = split_columns(frame, meta)
    known = target.notna().to_numpy()
    features, target = features[known].reset_index(drop=True), target[known].reset_index(drop=True)
    counts = target.astype(str).value_counts()
    if len(counts) < 2:
        raise NoLabels("fewer than 2 classes")
    rare = str(counts.index[-1])
    if counts.iloc[-1] < MIN_ANOMALIES:
        raise NoLabels(f"fewer than {MIN_ANOMALIES} rows in the rarest class")
    is_rare = (target.astype(str) == rare).to_numpy()
    natural = float(is_rare.mean())
    info: dict[str, Any] = {
        "anomaly_class": rare,
        "classes": int(len(counts)),
        "natural_rate": natural,
        "kind": "native_rare",
    }
    keep = np.ones(len(target), dtype=bool)
    if natural > TARGET_RATE:
        n_normal = int((~is_rare).sum())
        k = round(n_normal * TARGET_RATE / (1 - TARGET_RATE))
        chosen = np.random.default_rng(SEED).choice(np.flatnonzero(is_rare), k, replace=False)
        keep = ~is_rare
        keep[chosen] = True
        info["kind"] = "downsampled"
    labels = is_rare[keep].astype(int)
    info.update(rows=int(keep.sum()), anomalies=int(labels.sum()))
    return features[keep].reset_index(drop=True), labels, info


def x_derive_labels__mutmut_3(
    frame: pd.DataFrame, meta: dict[str, Any]
) -> tuple[pd.DataFrame, np.ndarray, dict[str, Any]]:
    if "CLASSIFICATION" not in (meta.get("tasks") or []):
        raise NoLabels("not a classification task")
    features, target = split_columns(frame, meta)
    known = target.notna().to_numpy()
    features, target = features[known].reset_index(drop=True), target[known].reset_index(drop=True)
    counts = target.astype(str).value_counts()
    if len(counts) < 2:
        raise NoLabels("fewer than 2 classes")
    rare = str(counts.index[-1])
    if counts.iloc[-1] < MIN_ANOMALIES:
        raise NoLabels(f"fewer than {MIN_ANOMALIES} rows in the rarest class")
    is_rare = (target.astype(str) == rare).to_numpy()
    natural = float(is_rare.mean())
    info: dict[str, Any] = {
        "anomaly_class": rare,
        "classes": int(len(counts)),
        "natural_rate": natural,
        "kind": "native_rare",
    }
    keep = np.ones(len(target), dtype=bool)
    if natural > TARGET_RATE:
        n_normal = int((~is_rare).sum())
        k = round(n_normal * TARGET_RATE / (1 - TARGET_RATE))
        chosen = np.random.default_rng(SEED).choice(np.flatnonzero(is_rare), k, replace=False)
        keep = ~is_rare
        keep[chosen] = True
        info["kind"] = "downsampled"
    labels = is_rare[keep].astype(int)
    info.update(rows=int(keep.sum()), anomalies=int(labels.sum()))
    return features[keep].reset_index(drop=True), labels, info


def x_derive_labels__mutmut_4(
    frame: pd.DataFrame, meta: dict[str, Any]
) -> tuple[pd.DataFrame, np.ndarray, dict[str, Any]]:
    if "Classification" in (meta.get("tasks") or []):
        raise NoLabels("not a classification task")
    features, target = split_columns(frame, meta)
    known = target.notna().to_numpy()
    features, target = features[known].reset_index(drop=True), target[known].reset_index(drop=True)
    counts = target.astype(str).value_counts()
    if len(counts) < 2:
        raise NoLabels("fewer than 2 classes")
    rare = str(counts.index[-1])
    if counts.iloc[-1] < MIN_ANOMALIES:
        raise NoLabels(f"fewer than {MIN_ANOMALIES} rows in the rarest class")
    is_rare = (target.astype(str) == rare).to_numpy()
    natural = float(is_rare.mean())
    info: dict[str, Any] = {
        "anomaly_class": rare,
        "classes": int(len(counts)),
        "natural_rate": natural,
        "kind": "native_rare",
    }
    keep = np.ones(len(target), dtype=bool)
    if natural > TARGET_RATE:
        n_normal = int((~is_rare).sum())
        k = round(n_normal * TARGET_RATE / (1 - TARGET_RATE))
        chosen = np.random.default_rng(SEED).choice(np.flatnonzero(is_rare), k, replace=False)
        keep = ~is_rare
        keep[chosen] = True
        info["kind"] = "downsampled"
    labels = is_rare[keep].astype(int)
    info.update(rows=int(keep.sum()), anomalies=int(labels.sum()))
    return features[keep].reset_index(drop=True), labels, info


def x_derive_labels__mutmut_5(
    frame: pd.DataFrame, meta: dict[str, Any]
) -> tuple[pd.DataFrame, np.ndarray, dict[str, Any]]:
    if "Classification" not in (meta.get("tasks") and []):
        raise NoLabels("not a classification task")
    features, target = split_columns(frame, meta)
    known = target.notna().to_numpy()
    features, target = features[known].reset_index(drop=True), target[known].reset_index(drop=True)
    counts = target.astype(str).value_counts()
    if len(counts) < 2:
        raise NoLabels("fewer than 2 classes")
    rare = str(counts.index[-1])
    if counts.iloc[-1] < MIN_ANOMALIES:
        raise NoLabels(f"fewer than {MIN_ANOMALIES} rows in the rarest class")
    is_rare = (target.astype(str) == rare).to_numpy()
    natural = float(is_rare.mean())
    info: dict[str, Any] = {
        "anomaly_class": rare,
        "classes": int(len(counts)),
        "natural_rate": natural,
        "kind": "native_rare",
    }
    keep = np.ones(len(target), dtype=bool)
    if natural > TARGET_RATE:
        n_normal = int((~is_rare).sum())
        k = round(n_normal * TARGET_RATE / (1 - TARGET_RATE))
        chosen = np.random.default_rng(SEED).choice(np.flatnonzero(is_rare), k, replace=False)
        keep = ~is_rare
        keep[chosen] = True
        info["kind"] = "downsampled"
    labels = is_rare[keep].astype(int)
    info.update(rows=int(keep.sum()), anomalies=int(labels.sum()))
    return features[keep].reset_index(drop=True), labels, info


def x_derive_labels__mutmut_6(
    frame: pd.DataFrame, meta: dict[str, Any]
) -> tuple[pd.DataFrame, np.ndarray, dict[str, Any]]:
    if "Classification" not in (meta.get(None) or []):
        raise NoLabels("not a classification task")
    features, target = split_columns(frame, meta)
    known = target.notna().to_numpy()
    features, target = features[known].reset_index(drop=True), target[known].reset_index(drop=True)
    counts = target.astype(str).value_counts()
    if len(counts) < 2:
        raise NoLabels("fewer than 2 classes")
    rare = str(counts.index[-1])
    if counts.iloc[-1] < MIN_ANOMALIES:
        raise NoLabels(f"fewer than {MIN_ANOMALIES} rows in the rarest class")
    is_rare = (target.astype(str) == rare).to_numpy()
    natural = float(is_rare.mean())
    info: dict[str, Any] = {
        "anomaly_class": rare,
        "classes": int(len(counts)),
        "natural_rate": natural,
        "kind": "native_rare",
    }
    keep = np.ones(len(target), dtype=bool)
    if natural > TARGET_RATE:
        n_normal = int((~is_rare).sum())
        k = round(n_normal * TARGET_RATE / (1 - TARGET_RATE))
        chosen = np.random.default_rng(SEED).choice(np.flatnonzero(is_rare), k, replace=False)
        keep = ~is_rare
        keep[chosen] = True
        info["kind"] = "downsampled"
    labels = is_rare[keep].astype(int)
    info.update(rows=int(keep.sum()), anomalies=int(labels.sum()))
    return features[keep].reset_index(drop=True), labels, info


def x_derive_labels__mutmut_7(
    frame: pd.DataFrame, meta: dict[str, Any]
) -> tuple[pd.DataFrame, np.ndarray, dict[str, Any]]:
    if "Classification" not in (meta.get("XXtasksXX") or []):
        raise NoLabels("not a classification task")
    features, target = split_columns(frame, meta)
    known = target.notna().to_numpy()
    features, target = features[known].reset_index(drop=True), target[known].reset_index(drop=True)
    counts = target.astype(str).value_counts()
    if len(counts) < 2:
        raise NoLabels("fewer than 2 classes")
    rare = str(counts.index[-1])
    if counts.iloc[-1] < MIN_ANOMALIES:
        raise NoLabels(f"fewer than {MIN_ANOMALIES} rows in the rarest class")
    is_rare = (target.astype(str) == rare).to_numpy()
    natural = float(is_rare.mean())
    info: dict[str, Any] = {
        "anomaly_class": rare,
        "classes": int(len(counts)),
        "natural_rate": natural,
        "kind": "native_rare",
    }
    keep = np.ones(len(target), dtype=bool)
    if natural > TARGET_RATE:
        n_normal = int((~is_rare).sum())
        k = round(n_normal * TARGET_RATE / (1 - TARGET_RATE))
        chosen = np.random.default_rng(SEED).choice(np.flatnonzero(is_rare), k, replace=False)
        keep = ~is_rare
        keep[chosen] = True
        info["kind"] = "downsampled"
    labels = is_rare[keep].astype(int)
    info.update(rows=int(keep.sum()), anomalies=int(labels.sum()))
    return features[keep].reset_index(drop=True), labels, info


def x_derive_labels__mutmut_8(
    frame: pd.DataFrame, meta: dict[str, Any]
) -> tuple[pd.DataFrame, np.ndarray, dict[str, Any]]:
    if "Classification" not in (meta.get("TASKS") or []):
        raise NoLabels("not a classification task")
    features, target = split_columns(frame, meta)
    known = target.notna().to_numpy()
    features, target = features[known].reset_index(drop=True), target[known].reset_index(drop=True)
    counts = target.astype(str).value_counts()
    if len(counts) < 2:
        raise NoLabels("fewer than 2 classes")
    rare = str(counts.index[-1])
    if counts.iloc[-1] < MIN_ANOMALIES:
        raise NoLabels(f"fewer than {MIN_ANOMALIES} rows in the rarest class")
    is_rare = (target.astype(str) == rare).to_numpy()
    natural = float(is_rare.mean())
    info: dict[str, Any] = {
        "anomaly_class": rare,
        "classes": int(len(counts)),
        "natural_rate": natural,
        "kind": "native_rare",
    }
    keep = np.ones(len(target), dtype=bool)
    if natural > TARGET_RATE:
        n_normal = int((~is_rare).sum())
        k = round(n_normal * TARGET_RATE / (1 - TARGET_RATE))
        chosen = np.random.default_rng(SEED).choice(np.flatnonzero(is_rare), k, replace=False)
        keep = ~is_rare
        keep[chosen] = True
        info["kind"] = "downsampled"
    labels = is_rare[keep].astype(int)
    info.update(rows=int(keep.sum()), anomalies=int(labels.sum()))
    return features[keep].reset_index(drop=True), labels, info


def x_derive_labels__mutmut_9(
    frame: pd.DataFrame, meta: dict[str, Any]
) -> tuple[pd.DataFrame, np.ndarray, dict[str, Any]]:
    if "Classification" not in (meta.get("tasks") or []):
        raise NoLabels(None)
    features, target = split_columns(frame, meta)
    known = target.notna().to_numpy()
    features, target = features[known].reset_index(drop=True), target[known].reset_index(drop=True)
    counts = target.astype(str).value_counts()
    if len(counts) < 2:
        raise NoLabels("fewer than 2 classes")
    rare = str(counts.index[-1])
    if counts.iloc[-1] < MIN_ANOMALIES:
        raise NoLabels(f"fewer than {MIN_ANOMALIES} rows in the rarest class")
    is_rare = (target.astype(str) == rare).to_numpy()
    natural = float(is_rare.mean())
    info: dict[str, Any] = {
        "anomaly_class": rare,
        "classes": int(len(counts)),
        "natural_rate": natural,
        "kind": "native_rare",
    }
    keep = np.ones(len(target), dtype=bool)
    if natural > TARGET_RATE:
        n_normal = int((~is_rare).sum())
        k = round(n_normal * TARGET_RATE / (1 - TARGET_RATE))
        chosen = np.random.default_rng(SEED).choice(np.flatnonzero(is_rare), k, replace=False)
        keep = ~is_rare
        keep[chosen] = True
        info["kind"] = "downsampled"
    labels = is_rare[keep].astype(int)
    info.update(rows=int(keep.sum()), anomalies=int(labels.sum()))
    return features[keep].reset_index(drop=True), labels, info


def x_derive_labels__mutmut_10(
    frame: pd.DataFrame, meta: dict[str, Any]
) -> tuple[pd.DataFrame, np.ndarray, dict[str, Any]]:
    if "Classification" not in (meta.get("tasks") or []):
        raise NoLabels("XXnot a classification taskXX")
    features, target = split_columns(frame, meta)
    known = target.notna().to_numpy()
    features, target = features[known].reset_index(drop=True), target[known].reset_index(drop=True)
    counts = target.astype(str).value_counts()
    if len(counts) < 2:
        raise NoLabels("fewer than 2 classes")
    rare = str(counts.index[-1])
    if counts.iloc[-1] < MIN_ANOMALIES:
        raise NoLabels(f"fewer than {MIN_ANOMALIES} rows in the rarest class")
    is_rare = (target.astype(str) == rare).to_numpy()
    natural = float(is_rare.mean())
    info: dict[str, Any] = {
        "anomaly_class": rare,
        "classes": int(len(counts)),
        "natural_rate": natural,
        "kind": "native_rare",
    }
    keep = np.ones(len(target), dtype=bool)
    if natural > TARGET_RATE:
        n_normal = int((~is_rare).sum())
        k = round(n_normal * TARGET_RATE / (1 - TARGET_RATE))
        chosen = np.random.default_rng(SEED).choice(np.flatnonzero(is_rare), k, replace=False)
        keep = ~is_rare
        keep[chosen] = True
        info["kind"] = "downsampled"
    labels = is_rare[keep].astype(int)
    info.update(rows=int(keep.sum()), anomalies=int(labels.sum()))
    return features[keep].reset_index(drop=True), labels, info


def x_derive_labels__mutmut_11(
    frame: pd.DataFrame, meta: dict[str, Any]
) -> tuple[pd.DataFrame, np.ndarray, dict[str, Any]]:
    if "Classification" not in (meta.get("tasks") or []):
        raise NoLabels("NOT A CLASSIFICATION TASK")
    features, target = split_columns(frame, meta)
    known = target.notna().to_numpy()
    features, target = features[known].reset_index(drop=True), target[known].reset_index(drop=True)
    counts = target.astype(str).value_counts()
    if len(counts) < 2:
        raise NoLabels("fewer than 2 classes")
    rare = str(counts.index[-1])
    if counts.iloc[-1] < MIN_ANOMALIES:
        raise NoLabels(f"fewer than {MIN_ANOMALIES} rows in the rarest class")
    is_rare = (target.astype(str) == rare).to_numpy()
    natural = float(is_rare.mean())
    info: dict[str, Any] = {
        "anomaly_class": rare,
        "classes": int(len(counts)),
        "natural_rate": natural,
        "kind": "native_rare",
    }
    keep = np.ones(len(target), dtype=bool)
    if natural > TARGET_RATE:
        n_normal = int((~is_rare).sum())
        k = round(n_normal * TARGET_RATE / (1 - TARGET_RATE))
        chosen = np.random.default_rng(SEED).choice(np.flatnonzero(is_rare), k, replace=False)
        keep = ~is_rare
        keep[chosen] = True
        info["kind"] = "downsampled"
    labels = is_rare[keep].astype(int)
    info.update(rows=int(keep.sum()), anomalies=int(labels.sum()))
    return features[keep].reset_index(drop=True), labels, info


def x_derive_labels__mutmut_12(
    frame: pd.DataFrame, meta: dict[str, Any]
) -> tuple[pd.DataFrame, np.ndarray, dict[str, Any]]:
    if "Classification" not in (meta.get("tasks") or []):
        raise NoLabels("not a classification task")
    features, target = None
    known = target.notna().to_numpy()
    features, target = features[known].reset_index(drop=True), target[known].reset_index(drop=True)
    counts = target.astype(str).value_counts()
    if len(counts) < 2:
        raise NoLabels("fewer than 2 classes")
    rare = str(counts.index[-1])
    if counts.iloc[-1] < MIN_ANOMALIES:
        raise NoLabels(f"fewer than {MIN_ANOMALIES} rows in the rarest class")
    is_rare = (target.astype(str) == rare).to_numpy()
    natural = float(is_rare.mean())
    info: dict[str, Any] = {
        "anomaly_class": rare,
        "classes": int(len(counts)),
        "natural_rate": natural,
        "kind": "native_rare",
    }
    keep = np.ones(len(target), dtype=bool)
    if natural > TARGET_RATE:
        n_normal = int((~is_rare).sum())
        k = round(n_normal * TARGET_RATE / (1 - TARGET_RATE))
        chosen = np.random.default_rng(SEED).choice(np.flatnonzero(is_rare), k, replace=False)
        keep = ~is_rare
        keep[chosen] = True
        info["kind"] = "downsampled"
    labels = is_rare[keep].astype(int)
    info.update(rows=int(keep.sum()), anomalies=int(labels.sum()))
    return features[keep].reset_index(drop=True), labels, info


def x_derive_labels__mutmut_13(
    frame: pd.DataFrame, meta: dict[str, Any]
) -> tuple[pd.DataFrame, np.ndarray, dict[str, Any]]:
    if "Classification" not in (meta.get("tasks") or []):
        raise NoLabels("not a classification task")
    features, target = split_columns(None, meta)
    known = target.notna().to_numpy()
    features, target = features[known].reset_index(drop=True), target[known].reset_index(drop=True)
    counts = target.astype(str).value_counts()
    if len(counts) < 2:
        raise NoLabels("fewer than 2 classes")
    rare = str(counts.index[-1])
    if counts.iloc[-1] < MIN_ANOMALIES:
        raise NoLabels(f"fewer than {MIN_ANOMALIES} rows in the rarest class")
    is_rare = (target.astype(str) == rare).to_numpy()
    natural = float(is_rare.mean())
    info: dict[str, Any] = {
        "anomaly_class": rare,
        "classes": int(len(counts)),
        "natural_rate": natural,
        "kind": "native_rare",
    }
    keep = np.ones(len(target), dtype=bool)
    if natural > TARGET_RATE:
        n_normal = int((~is_rare).sum())
        k = round(n_normal * TARGET_RATE / (1 - TARGET_RATE))
        chosen = np.random.default_rng(SEED).choice(np.flatnonzero(is_rare), k, replace=False)
        keep = ~is_rare
        keep[chosen] = True
        info["kind"] = "downsampled"
    labels = is_rare[keep].astype(int)
    info.update(rows=int(keep.sum()), anomalies=int(labels.sum()))
    return features[keep].reset_index(drop=True), labels, info


def x_derive_labels__mutmut_14(
    frame: pd.DataFrame, meta: dict[str, Any]
) -> tuple[pd.DataFrame, np.ndarray, dict[str, Any]]:
    if "Classification" not in (meta.get("tasks") or []):
        raise NoLabels("not a classification task")
    features, target = split_columns(frame, None)
    known = target.notna().to_numpy()
    features, target = features[known].reset_index(drop=True), target[known].reset_index(drop=True)
    counts = target.astype(str).value_counts()
    if len(counts) < 2:
        raise NoLabels("fewer than 2 classes")
    rare = str(counts.index[-1])
    if counts.iloc[-1] < MIN_ANOMALIES:
        raise NoLabels(f"fewer than {MIN_ANOMALIES} rows in the rarest class")
    is_rare = (target.astype(str) == rare).to_numpy()
    natural = float(is_rare.mean())
    info: dict[str, Any] = {
        "anomaly_class": rare,
        "classes": int(len(counts)),
        "natural_rate": natural,
        "kind": "native_rare",
    }
    keep = np.ones(len(target), dtype=bool)
    if natural > TARGET_RATE:
        n_normal = int((~is_rare).sum())
        k = round(n_normal * TARGET_RATE / (1 - TARGET_RATE))
        chosen = np.random.default_rng(SEED).choice(np.flatnonzero(is_rare), k, replace=False)
        keep = ~is_rare
        keep[chosen] = True
        info["kind"] = "downsampled"
    labels = is_rare[keep].astype(int)
    info.update(rows=int(keep.sum()), anomalies=int(labels.sum()))
    return features[keep].reset_index(drop=True), labels, info


def x_derive_labels__mutmut_15(
    frame: pd.DataFrame, meta: dict[str, Any]
) -> tuple[pd.DataFrame, np.ndarray, dict[str, Any]]:
    if "Classification" not in (meta.get("tasks") or []):
        raise NoLabels("not a classification task")
    features, target = split_columns(meta)
    known = target.notna().to_numpy()
    features, target = features[known].reset_index(drop=True), target[known].reset_index(drop=True)
    counts = target.astype(str).value_counts()
    if len(counts) < 2:
        raise NoLabels("fewer than 2 classes")
    rare = str(counts.index[-1])
    if counts.iloc[-1] < MIN_ANOMALIES:
        raise NoLabels(f"fewer than {MIN_ANOMALIES} rows in the rarest class")
    is_rare = (target.astype(str) == rare).to_numpy()
    natural = float(is_rare.mean())
    info: dict[str, Any] = {
        "anomaly_class": rare,
        "classes": int(len(counts)),
        "natural_rate": natural,
        "kind": "native_rare",
    }
    keep = np.ones(len(target), dtype=bool)
    if natural > TARGET_RATE:
        n_normal = int((~is_rare).sum())
        k = round(n_normal * TARGET_RATE / (1 - TARGET_RATE))
        chosen = np.random.default_rng(SEED).choice(np.flatnonzero(is_rare), k, replace=False)
        keep = ~is_rare
        keep[chosen] = True
        info["kind"] = "downsampled"
    labels = is_rare[keep].astype(int)
    info.update(rows=int(keep.sum()), anomalies=int(labels.sum()))
    return features[keep].reset_index(drop=True), labels, info


def x_derive_labels__mutmut_16(
    frame: pd.DataFrame, meta: dict[str, Any]
) -> tuple[pd.DataFrame, np.ndarray, dict[str, Any]]:
    if "Classification" not in (meta.get("tasks") or []):
        raise NoLabels("not a classification task")
    features, target = split_columns(frame, )
    known = target.notna().to_numpy()
    features, target = features[known].reset_index(drop=True), target[known].reset_index(drop=True)
    counts = target.astype(str).value_counts()
    if len(counts) < 2:
        raise NoLabels("fewer than 2 classes")
    rare = str(counts.index[-1])
    if counts.iloc[-1] < MIN_ANOMALIES:
        raise NoLabels(f"fewer than {MIN_ANOMALIES} rows in the rarest class")
    is_rare = (target.astype(str) == rare).to_numpy()
    natural = float(is_rare.mean())
    info: dict[str, Any] = {
        "anomaly_class": rare,
        "classes": int(len(counts)),
        "natural_rate": natural,
        "kind": "native_rare",
    }
    keep = np.ones(len(target), dtype=bool)
    if natural > TARGET_RATE:
        n_normal = int((~is_rare).sum())
        k = round(n_normal * TARGET_RATE / (1 - TARGET_RATE))
        chosen = np.random.default_rng(SEED).choice(np.flatnonzero(is_rare), k, replace=False)
        keep = ~is_rare
        keep[chosen] = True
        info["kind"] = "downsampled"
    labels = is_rare[keep].astype(int)
    info.update(rows=int(keep.sum()), anomalies=int(labels.sum()))
    return features[keep].reset_index(drop=True), labels, info


def x_derive_labels__mutmut_17(
    frame: pd.DataFrame, meta: dict[str, Any]
) -> tuple[pd.DataFrame, np.ndarray, dict[str, Any]]:
    if "Classification" not in (meta.get("tasks") or []):
        raise NoLabels("not a classification task")
    features, target = split_columns(frame, meta)
    known = None
    features, target = features[known].reset_index(drop=True), target[known].reset_index(drop=True)
    counts = target.astype(str).value_counts()
    if len(counts) < 2:
        raise NoLabels("fewer than 2 classes")
    rare = str(counts.index[-1])
    if counts.iloc[-1] < MIN_ANOMALIES:
        raise NoLabels(f"fewer than {MIN_ANOMALIES} rows in the rarest class")
    is_rare = (target.astype(str) == rare).to_numpy()
    natural = float(is_rare.mean())
    info: dict[str, Any] = {
        "anomaly_class": rare,
        "classes": int(len(counts)),
        "natural_rate": natural,
        "kind": "native_rare",
    }
    keep = np.ones(len(target), dtype=bool)
    if natural > TARGET_RATE:
        n_normal = int((~is_rare).sum())
        k = round(n_normal * TARGET_RATE / (1 - TARGET_RATE))
        chosen = np.random.default_rng(SEED).choice(np.flatnonzero(is_rare), k, replace=False)
        keep = ~is_rare
        keep[chosen] = True
        info["kind"] = "downsampled"
    labels = is_rare[keep].astype(int)
    info.update(rows=int(keep.sum()), anomalies=int(labels.sum()))
    return features[keep].reset_index(drop=True), labels, info


def x_derive_labels__mutmut_18(
    frame: pd.DataFrame, meta: dict[str, Any]
) -> tuple[pd.DataFrame, np.ndarray, dict[str, Any]]:
    if "Classification" not in (meta.get("tasks") or []):
        raise NoLabels("not a classification task")
    features, target = split_columns(frame, meta)
    known = target.notna().to_numpy()
    features, target = None
    counts = target.astype(str).value_counts()
    if len(counts) < 2:
        raise NoLabels("fewer than 2 classes")
    rare = str(counts.index[-1])
    if counts.iloc[-1] < MIN_ANOMALIES:
        raise NoLabels(f"fewer than {MIN_ANOMALIES} rows in the rarest class")
    is_rare = (target.astype(str) == rare).to_numpy()
    natural = float(is_rare.mean())
    info: dict[str, Any] = {
        "anomaly_class": rare,
        "classes": int(len(counts)),
        "natural_rate": natural,
        "kind": "native_rare",
    }
    keep = np.ones(len(target), dtype=bool)
    if natural > TARGET_RATE:
        n_normal = int((~is_rare).sum())
        k = round(n_normal * TARGET_RATE / (1 - TARGET_RATE))
        chosen = np.random.default_rng(SEED).choice(np.flatnonzero(is_rare), k, replace=False)
        keep = ~is_rare
        keep[chosen] = True
        info["kind"] = "downsampled"
    labels = is_rare[keep].astype(int)
    info.update(rows=int(keep.sum()), anomalies=int(labels.sum()))
    return features[keep].reset_index(drop=True), labels, info


def x_derive_labels__mutmut_19(
    frame: pd.DataFrame, meta: dict[str, Any]
) -> tuple[pd.DataFrame, np.ndarray, dict[str, Any]]:
    if "Classification" not in (meta.get("tasks") or []):
        raise NoLabels("not a classification task")
    features, target = split_columns(frame, meta)
    known = target.notna().to_numpy()
    features, target = features[known].reset_index(drop=None), target[known].reset_index(drop=True)
    counts = target.astype(str).value_counts()
    if len(counts) < 2:
        raise NoLabels("fewer than 2 classes")
    rare = str(counts.index[-1])
    if counts.iloc[-1] < MIN_ANOMALIES:
        raise NoLabels(f"fewer than {MIN_ANOMALIES} rows in the rarest class")
    is_rare = (target.astype(str) == rare).to_numpy()
    natural = float(is_rare.mean())
    info: dict[str, Any] = {
        "anomaly_class": rare,
        "classes": int(len(counts)),
        "natural_rate": natural,
        "kind": "native_rare",
    }
    keep = np.ones(len(target), dtype=bool)
    if natural > TARGET_RATE:
        n_normal = int((~is_rare).sum())
        k = round(n_normal * TARGET_RATE / (1 - TARGET_RATE))
        chosen = np.random.default_rng(SEED).choice(np.flatnonzero(is_rare), k, replace=False)
        keep = ~is_rare
        keep[chosen] = True
        info["kind"] = "downsampled"
    labels = is_rare[keep].astype(int)
    info.update(rows=int(keep.sum()), anomalies=int(labels.sum()))
    return features[keep].reset_index(drop=True), labels, info


def x_derive_labels__mutmut_20(
    frame: pd.DataFrame, meta: dict[str, Any]
) -> tuple[pd.DataFrame, np.ndarray, dict[str, Any]]:
    if "Classification" not in (meta.get("tasks") or []):
        raise NoLabels("not a classification task")
    features, target = split_columns(frame, meta)
    known = target.notna().to_numpy()
    features, target = features[known].reset_index(drop=False), target[known].reset_index(drop=True)
    counts = target.astype(str).value_counts()
    if len(counts) < 2:
        raise NoLabels("fewer than 2 classes")
    rare = str(counts.index[-1])
    if counts.iloc[-1] < MIN_ANOMALIES:
        raise NoLabels(f"fewer than {MIN_ANOMALIES} rows in the rarest class")
    is_rare = (target.astype(str) == rare).to_numpy()
    natural = float(is_rare.mean())
    info: dict[str, Any] = {
        "anomaly_class": rare,
        "classes": int(len(counts)),
        "natural_rate": natural,
        "kind": "native_rare",
    }
    keep = np.ones(len(target), dtype=bool)
    if natural > TARGET_RATE:
        n_normal = int((~is_rare).sum())
        k = round(n_normal * TARGET_RATE / (1 - TARGET_RATE))
        chosen = np.random.default_rng(SEED).choice(np.flatnonzero(is_rare), k, replace=False)
        keep = ~is_rare
        keep[chosen] = True
        info["kind"] = "downsampled"
    labels = is_rare[keep].astype(int)
    info.update(rows=int(keep.sum()), anomalies=int(labels.sum()))
    return features[keep].reset_index(drop=True), labels, info


def x_derive_labels__mutmut_21(
    frame: pd.DataFrame, meta: dict[str, Any]
) -> tuple[pd.DataFrame, np.ndarray, dict[str, Any]]:
    if "Classification" not in (meta.get("tasks") or []):
        raise NoLabels("not a classification task")
    features, target = split_columns(frame, meta)
    known = target.notna().to_numpy()
    features, target = features[known].reset_index(drop=True), target[known].reset_index(drop=None)
    counts = target.astype(str).value_counts()
    if len(counts) < 2:
        raise NoLabels("fewer than 2 classes")
    rare = str(counts.index[-1])
    if counts.iloc[-1] < MIN_ANOMALIES:
        raise NoLabels(f"fewer than {MIN_ANOMALIES} rows in the rarest class")
    is_rare = (target.astype(str) == rare).to_numpy()
    natural = float(is_rare.mean())
    info: dict[str, Any] = {
        "anomaly_class": rare,
        "classes": int(len(counts)),
        "natural_rate": natural,
        "kind": "native_rare",
    }
    keep = np.ones(len(target), dtype=bool)
    if natural > TARGET_RATE:
        n_normal = int((~is_rare).sum())
        k = round(n_normal * TARGET_RATE / (1 - TARGET_RATE))
        chosen = np.random.default_rng(SEED).choice(np.flatnonzero(is_rare), k, replace=False)
        keep = ~is_rare
        keep[chosen] = True
        info["kind"] = "downsampled"
    labels = is_rare[keep].astype(int)
    info.update(rows=int(keep.sum()), anomalies=int(labels.sum()))
    return features[keep].reset_index(drop=True), labels, info


def x_derive_labels__mutmut_22(
    frame: pd.DataFrame, meta: dict[str, Any]
) -> tuple[pd.DataFrame, np.ndarray, dict[str, Any]]:
    if "Classification" not in (meta.get("tasks") or []):
        raise NoLabels("not a classification task")
    features, target = split_columns(frame, meta)
    known = target.notna().to_numpy()
    features, target = features[known].reset_index(drop=True), target[known].reset_index(drop=False)
    counts = target.astype(str).value_counts()
    if len(counts) < 2:
        raise NoLabels("fewer than 2 classes")
    rare = str(counts.index[-1])
    if counts.iloc[-1] < MIN_ANOMALIES:
        raise NoLabels(f"fewer than {MIN_ANOMALIES} rows in the rarest class")
    is_rare = (target.astype(str) == rare).to_numpy()
    natural = float(is_rare.mean())
    info: dict[str, Any] = {
        "anomaly_class": rare,
        "classes": int(len(counts)),
        "natural_rate": natural,
        "kind": "native_rare",
    }
    keep = np.ones(len(target), dtype=bool)
    if natural > TARGET_RATE:
        n_normal = int((~is_rare).sum())
        k = round(n_normal * TARGET_RATE / (1 - TARGET_RATE))
        chosen = np.random.default_rng(SEED).choice(np.flatnonzero(is_rare), k, replace=False)
        keep = ~is_rare
        keep[chosen] = True
        info["kind"] = "downsampled"
    labels = is_rare[keep].astype(int)
    info.update(rows=int(keep.sum()), anomalies=int(labels.sum()))
    return features[keep].reset_index(drop=True), labels, info


def x_derive_labels__mutmut_23(
    frame: pd.DataFrame, meta: dict[str, Any]
) -> tuple[pd.DataFrame, np.ndarray, dict[str, Any]]:
    if "Classification" not in (meta.get("tasks") or []):
        raise NoLabels("not a classification task")
    features, target = split_columns(frame, meta)
    known = target.notna().to_numpy()
    features, target = features[known].reset_index(drop=True), target[known].reset_index(drop=True)
    counts = None
    if len(counts) < 2:
        raise NoLabels("fewer than 2 classes")
    rare = str(counts.index[-1])
    if counts.iloc[-1] < MIN_ANOMALIES:
        raise NoLabels(f"fewer than {MIN_ANOMALIES} rows in the rarest class")
    is_rare = (target.astype(str) == rare).to_numpy()
    natural = float(is_rare.mean())
    info: dict[str, Any] = {
        "anomaly_class": rare,
        "classes": int(len(counts)),
        "natural_rate": natural,
        "kind": "native_rare",
    }
    keep = np.ones(len(target), dtype=bool)
    if natural > TARGET_RATE:
        n_normal = int((~is_rare).sum())
        k = round(n_normal * TARGET_RATE / (1 - TARGET_RATE))
        chosen = np.random.default_rng(SEED).choice(np.flatnonzero(is_rare), k, replace=False)
        keep = ~is_rare
        keep[chosen] = True
        info["kind"] = "downsampled"
    labels = is_rare[keep].astype(int)
    info.update(rows=int(keep.sum()), anomalies=int(labels.sum()))
    return features[keep].reset_index(drop=True), labels, info


def x_derive_labels__mutmut_24(
    frame: pd.DataFrame, meta: dict[str, Any]
) -> tuple[pd.DataFrame, np.ndarray, dict[str, Any]]:
    if "Classification" not in (meta.get("tasks") or []):
        raise NoLabels("not a classification task")
    features, target = split_columns(frame, meta)
    known = target.notna().to_numpy()
    features, target = features[known].reset_index(drop=True), target[known].reset_index(drop=True)
    counts = target.astype(None).value_counts()
    if len(counts) < 2:
        raise NoLabels("fewer than 2 classes")
    rare = str(counts.index[-1])
    if counts.iloc[-1] < MIN_ANOMALIES:
        raise NoLabels(f"fewer than {MIN_ANOMALIES} rows in the rarest class")
    is_rare = (target.astype(str) == rare).to_numpy()
    natural = float(is_rare.mean())
    info: dict[str, Any] = {
        "anomaly_class": rare,
        "classes": int(len(counts)),
        "natural_rate": natural,
        "kind": "native_rare",
    }
    keep = np.ones(len(target), dtype=bool)
    if natural > TARGET_RATE:
        n_normal = int((~is_rare).sum())
        k = round(n_normal * TARGET_RATE / (1 - TARGET_RATE))
        chosen = np.random.default_rng(SEED).choice(np.flatnonzero(is_rare), k, replace=False)
        keep = ~is_rare
        keep[chosen] = True
        info["kind"] = "downsampled"
    labels = is_rare[keep].astype(int)
    info.update(rows=int(keep.sum()), anomalies=int(labels.sum()))
    return features[keep].reset_index(drop=True), labels, info


def x_derive_labels__mutmut_25(
    frame: pd.DataFrame, meta: dict[str, Any]
) -> tuple[pd.DataFrame, np.ndarray, dict[str, Any]]:
    if "Classification" not in (meta.get("tasks") or []):
        raise NoLabels("not a classification task")
    features, target = split_columns(frame, meta)
    known = target.notna().to_numpy()
    features, target = features[known].reset_index(drop=True), target[known].reset_index(drop=True)
    counts = target.astype(str).value_counts()
    if len(counts) <= 2:
        raise NoLabels("fewer than 2 classes")
    rare = str(counts.index[-1])
    if counts.iloc[-1] < MIN_ANOMALIES:
        raise NoLabels(f"fewer than {MIN_ANOMALIES} rows in the rarest class")
    is_rare = (target.astype(str) == rare).to_numpy()
    natural = float(is_rare.mean())
    info: dict[str, Any] = {
        "anomaly_class": rare,
        "classes": int(len(counts)),
        "natural_rate": natural,
        "kind": "native_rare",
    }
    keep = np.ones(len(target), dtype=bool)
    if natural > TARGET_RATE:
        n_normal = int((~is_rare).sum())
        k = round(n_normal * TARGET_RATE / (1 - TARGET_RATE))
        chosen = np.random.default_rng(SEED).choice(np.flatnonzero(is_rare), k, replace=False)
        keep = ~is_rare
        keep[chosen] = True
        info["kind"] = "downsampled"
    labels = is_rare[keep].astype(int)
    info.update(rows=int(keep.sum()), anomalies=int(labels.sum()))
    return features[keep].reset_index(drop=True), labels, info


def x_derive_labels__mutmut_26(
    frame: pd.DataFrame, meta: dict[str, Any]
) -> tuple[pd.DataFrame, np.ndarray, dict[str, Any]]:
    if "Classification" not in (meta.get("tasks") or []):
        raise NoLabels("not a classification task")
    features, target = split_columns(frame, meta)
    known = target.notna().to_numpy()
    features, target = features[known].reset_index(drop=True), target[known].reset_index(drop=True)
    counts = target.astype(str).value_counts()
    if len(counts) < 3:
        raise NoLabels("fewer than 2 classes")
    rare = str(counts.index[-1])
    if counts.iloc[-1] < MIN_ANOMALIES:
        raise NoLabels(f"fewer than {MIN_ANOMALIES} rows in the rarest class")
    is_rare = (target.astype(str) == rare).to_numpy()
    natural = float(is_rare.mean())
    info: dict[str, Any] = {
        "anomaly_class": rare,
        "classes": int(len(counts)),
        "natural_rate": natural,
        "kind": "native_rare",
    }
    keep = np.ones(len(target), dtype=bool)
    if natural > TARGET_RATE:
        n_normal = int((~is_rare).sum())
        k = round(n_normal * TARGET_RATE / (1 - TARGET_RATE))
        chosen = np.random.default_rng(SEED).choice(np.flatnonzero(is_rare), k, replace=False)
        keep = ~is_rare
        keep[chosen] = True
        info["kind"] = "downsampled"
    labels = is_rare[keep].astype(int)
    info.update(rows=int(keep.sum()), anomalies=int(labels.sum()))
    return features[keep].reset_index(drop=True), labels, info


def x_derive_labels__mutmut_27(
    frame: pd.DataFrame, meta: dict[str, Any]
) -> tuple[pd.DataFrame, np.ndarray, dict[str, Any]]:
    if "Classification" not in (meta.get("tasks") or []):
        raise NoLabels("not a classification task")
    features, target = split_columns(frame, meta)
    known = target.notna().to_numpy()
    features, target = features[known].reset_index(drop=True), target[known].reset_index(drop=True)
    counts = target.astype(str).value_counts()
    if len(counts) < 2:
        raise NoLabels(None)
    rare = str(counts.index[-1])
    if counts.iloc[-1] < MIN_ANOMALIES:
        raise NoLabels(f"fewer than {MIN_ANOMALIES} rows in the rarest class")
    is_rare = (target.astype(str) == rare).to_numpy()
    natural = float(is_rare.mean())
    info: dict[str, Any] = {
        "anomaly_class": rare,
        "classes": int(len(counts)),
        "natural_rate": natural,
        "kind": "native_rare",
    }
    keep = np.ones(len(target), dtype=bool)
    if natural > TARGET_RATE:
        n_normal = int((~is_rare).sum())
        k = round(n_normal * TARGET_RATE / (1 - TARGET_RATE))
        chosen = np.random.default_rng(SEED).choice(np.flatnonzero(is_rare), k, replace=False)
        keep = ~is_rare
        keep[chosen] = True
        info["kind"] = "downsampled"
    labels = is_rare[keep].astype(int)
    info.update(rows=int(keep.sum()), anomalies=int(labels.sum()))
    return features[keep].reset_index(drop=True), labels, info


def x_derive_labels__mutmut_28(
    frame: pd.DataFrame, meta: dict[str, Any]
) -> tuple[pd.DataFrame, np.ndarray, dict[str, Any]]:
    if "Classification" not in (meta.get("tasks") or []):
        raise NoLabels("not a classification task")
    features, target = split_columns(frame, meta)
    known = target.notna().to_numpy()
    features, target = features[known].reset_index(drop=True), target[known].reset_index(drop=True)
    counts = target.astype(str).value_counts()
    if len(counts) < 2:
        raise NoLabels("XXfewer than 2 classesXX")
    rare = str(counts.index[-1])
    if counts.iloc[-1] < MIN_ANOMALIES:
        raise NoLabels(f"fewer than {MIN_ANOMALIES} rows in the rarest class")
    is_rare = (target.astype(str) == rare).to_numpy()
    natural = float(is_rare.mean())
    info: dict[str, Any] = {
        "anomaly_class": rare,
        "classes": int(len(counts)),
        "natural_rate": natural,
        "kind": "native_rare",
    }
    keep = np.ones(len(target), dtype=bool)
    if natural > TARGET_RATE:
        n_normal = int((~is_rare).sum())
        k = round(n_normal * TARGET_RATE / (1 - TARGET_RATE))
        chosen = np.random.default_rng(SEED).choice(np.flatnonzero(is_rare), k, replace=False)
        keep = ~is_rare
        keep[chosen] = True
        info["kind"] = "downsampled"
    labels = is_rare[keep].astype(int)
    info.update(rows=int(keep.sum()), anomalies=int(labels.sum()))
    return features[keep].reset_index(drop=True), labels, info


def x_derive_labels__mutmut_29(
    frame: pd.DataFrame, meta: dict[str, Any]
) -> tuple[pd.DataFrame, np.ndarray, dict[str, Any]]:
    if "Classification" not in (meta.get("tasks") or []):
        raise NoLabels("not a classification task")
    features, target = split_columns(frame, meta)
    known = target.notna().to_numpy()
    features, target = features[known].reset_index(drop=True), target[known].reset_index(drop=True)
    counts = target.astype(str).value_counts()
    if len(counts) < 2:
        raise NoLabels("FEWER THAN 2 CLASSES")
    rare = str(counts.index[-1])
    if counts.iloc[-1] < MIN_ANOMALIES:
        raise NoLabels(f"fewer than {MIN_ANOMALIES} rows in the rarest class")
    is_rare = (target.astype(str) == rare).to_numpy()
    natural = float(is_rare.mean())
    info: dict[str, Any] = {
        "anomaly_class": rare,
        "classes": int(len(counts)),
        "natural_rate": natural,
        "kind": "native_rare",
    }
    keep = np.ones(len(target), dtype=bool)
    if natural > TARGET_RATE:
        n_normal = int((~is_rare).sum())
        k = round(n_normal * TARGET_RATE / (1 - TARGET_RATE))
        chosen = np.random.default_rng(SEED).choice(np.flatnonzero(is_rare), k, replace=False)
        keep = ~is_rare
        keep[chosen] = True
        info["kind"] = "downsampled"
    labels = is_rare[keep].astype(int)
    info.update(rows=int(keep.sum()), anomalies=int(labels.sum()))
    return features[keep].reset_index(drop=True), labels, info


def x_derive_labels__mutmut_30(
    frame: pd.DataFrame, meta: dict[str, Any]
) -> tuple[pd.DataFrame, np.ndarray, dict[str, Any]]:
    if "Classification" not in (meta.get("tasks") or []):
        raise NoLabels("not a classification task")
    features, target = split_columns(frame, meta)
    known = target.notna().to_numpy()
    features, target = features[known].reset_index(drop=True), target[known].reset_index(drop=True)
    counts = target.astype(str).value_counts()
    if len(counts) < 2:
        raise NoLabels("fewer than 2 classes")
    rare = None
    if counts.iloc[-1] < MIN_ANOMALIES:
        raise NoLabels(f"fewer than {MIN_ANOMALIES} rows in the rarest class")
    is_rare = (target.astype(str) == rare).to_numpy()
    natural = float(is_rare.mean())
    info: dict[str, Any] = {
        "anomaly_class": rare,
        "classes": int(len(counts)),
        "natural_rate": natural,
        "kind": "native_rare",
    }
    keep = np.ones(len(target), dtype=bool)
    if natural > TARGET_RATE:
        n_normal = int((~is_rare).sum())
        k = round(n_normal * TARGET_RATE / (1 - TARGET_RATE))
        chosen = np.random.default_rng(SEED).choice(np.flatnonzero(is_rare), k, replace=False)
        keep = ~is_rare
        keep[chosen] = True
        info["kind"] = "downsampled"
    labels = is_rare[keep].astype(int)
    info.update(rows=int(keep.sum()), anomalies=int(labels.sum()))
    return features[keep].reset_index(drop=True), labels, info


def x_derive_labels__mutmut_31(
    frame: pd.DataFrame, meta: dict[str, Any]
) -> tuple[pd.DataFrame, np.ndarray, dict[str, Any]]:
    if "Classification" not in (meta.get("tasks") or []):
        raise NoLabels("not a classification task")
    features, target = split_columns(frame, meta)
    known = target.notna().to_numpy()
    features, target = features[known].reset_index(drop=True), target[known].reset_index(drop=True)
    counts = target.astype(str).value_counts()
    if len(counts) < 2:
        raise NoLabels("fewer than 2 classes")
    rare = str(None)
    if counts.iloc[-1] < MIN_ANOMALIES:
        raise NoLabels(f"fewer than {MIN_ANOMALIES} rows in the rarest class")
    is_rare = (target.astype(str) == rare).to_numpy()
    natural = float(is_rare.mean())
    info: dict[str, Any] = {
        "anomaly_class": rare,
        "classes": int(len(counts)),
        "natural_rate": natural,
        "kind": "native_rare",
    }
    keep = np.ones(len(target), dtype=bool)
    if natural > TARGET_RATE:
        n_normal = int((~is_rare).sum())
        k = round(n_normal * TARGET_RATE / (1 - TARGET_RATE))
        chosen = np.random.default_rng(SEED).choice(np.flatnonzero(is_rare), k, replace=False)
        keep = ~is_rare
        keep[chosen] = True
        info["kind"] = "downsampled"
    labels = is_rare[keep].astype(int)
    info.update(rows=int(keep.sum()), anomalies=int(labels.sum()))
    return features[keep].reset_index(drop=True), labels, info


def x_derive_labels__mutmut_32(
    frame: pd.DataFrame, meta: dict[str, Any]
) -> tuple[pd.DataFrame, np.ndarray, dict[str, Any]]:
    if "Classification" not in (meta.get("tasks") or []):
        raise NoLabels("not a classification task")
    features, target = split_columns(frame, meta)
    known = target.notna().to_numpy()
    features, target = features[known].reset_index(drop=True), target[known].reset_index(drop=True)
    counts = target.astype(str).value_counts()
    if len(counts) < 2:
        raise NoLabels("fewer than 2 classes")
    rare = str(counts.index[+1])
    if counts.iloc[-1] < MIN_ANOMALIES:
        raise NoLabels(f"fewer than {MIN_ANOMALIES} rows in the rarest class")
    is_rare = (target.astype(str) == rare).to_numpy()
    natural = float(is_rare.mean())
    info: dict[str, Any] = {
        "anomaly_class": rare,
        "classes": int(len(counts)),
        "natural_rate": natural,
        "kind": "native_rare",
    }
    keep = np.ones(len(target), dtype=bool)
    if natural > TARGET_RATE:
        n_normal = int((~is_rare).sum())
        k = round(n_normal * TARGET_RATE / (1 - TARGET_RATE))
        chosen = np.random.default_rng(SEED).choice(np.flatnonzero(is_rare), k, replace=False)
        keep = ~is_rare
        keep[chosen] = True
        info["kind"] = "downsampled"
    labels = is_rare[keep].astype(int)
    info.update(rows=int(keep.sum()), anomalies=int(labels.sum()))
    return features[keep].reset_index(drop=True), labels, info


def x_derive_labels__mutmut_33(
    frame: pd.DataFrame, meta: dict[str, Any]
) -> tuple[pd.DataFrame, np.ndarray, dict[str, Any]]:
    if "Classification" not in (meta.get("tasks") or []):
        raise NoLabels("not a classification task")
    features, target = split_columns(frame, meta)
    known = target.notna().to_numpy()
    features, target = features[known].reset_index(drop=True), target[known].reset_index(drop=True)
    counts = target.astype(str).value_counts()
    if len(counts) < 2:
        raise NoLabels("fewer than 2 classes")
    rare = str(counts.index[-2])
    if counts.iloc[-1] < MIN_ANOMALIES:
        raise NoLabels(f"fewer than {MIN_ANOMALIES} rows in the rarest class")
    is_rare = (target.astype(str) == rare).to_numpy()
    natural = float(is_rare.mean())
    info: dict[str, Any] = {
        "anomaly_class": rare,
        "classes": int(len(counts)),
        "natural_rate": natural,
        "kind": "native_rare",
    }
    keep = np.ones(len(target), dtype=bool)
    if natural > TARGET_RATE:
        n_normal = int((~is_rare).sum())
        k = round(n_normal * TARGET_RATE / (1 - TARGET_RATE))
        chosen = np.random.default_rng(SEED).choice(np.flatnonzero(is_rare), k, replace=False)
        keep = ~is_rare
        keep[chosen] = True
        info["kind"] = "downsampled"
    labels = is_rare[keep].astype(int)
    info.update(rows=int(keep.sum()), anomalies=int(labels.sum()))
    return features[keep].reset_index(drop=True), labels, info


def x_derive_labels__mutmut_34(
    frame: pd.DataFrame, meta: dict[str, Any]
) -> tuple[pd.DataFrame, np.ndarray, dict[str, Any]]:
    if "Classification" not in (meta.get("tasks") or []):
        raise NoLabels("not a classification task")
    features, target = split_columns(frame, meta)
    known = target.notna().to_numpy()
    features, target = features[known].reset_index(drop=True), target[known].reset_index(drop=True)
    counts = target.astype(str).value_counts()
    if len(counts) < 2:
        raise NoLabels("fewer than 2 classes")
    rare = str(counts.index[-1])
    if counts.iloc[+1] < MIN_ANOMALIES:
        raise NoLabels(f"fewer than {MIN_ANOMALIES} rows in the rarest class")
    is_rare = (target.astype(str) == rare).to_numpy()
    natural = float(is_rare.mean())
    info: dict[str, Any] = {
        "anomaly_class": rare,
        "classes": int(len(counts)),
        "natural_rate": natural,
        "kind": "native_rare",
    }
    keep = np.ones(len(target), dtype=bool)
    if natural > TARGET_RATE:
        n_normal = int((~is_rare).sum())
        k = round(n_normal * TARGET_RATE / (1 - TARGET_RATE))
        chosen = np.random.default_rng(SEED).choice(np.flatnonzero(is_rare), k, replace=False)
        keep = ~is_rare
        keep[chosen] = True
        info["kind"] = "downsampled"
    labels = is_rare[keep].astype(int)
    info.update(rows=int(keep.sum()), anomalies=int(labels.sum()))
    return features[keep].reset_index(drop=True), labels, info


def x_derive_labels__mutmut_35(
    frame: pd.DataFrame, meta: dict[str, Any]
) -> tuple[pd.DataFrame, np.ndarray, dict[str, Any]]:
    if "Classification" not in (meta.get("tasks") or []):
        raise NoLabels("not a classification task")
    features, target = split_columns(frame, meta)
    known = target.notna().to_numpy()
    features, target = features[known].reset_index(drop=True), target[known].reset_index(drop=True)
    counts = target.astype(str).value_counts()
    if len(counts) < 2:
        raise NoLabels("fewer than 2 classes")
    rare = str(counts.index[-1])
    if counts.iloc[-2] < MIN_ANOMALIES:
        raise NoLabels(f"fewer than {MIN_ANOMALIES} rows in the rarest class")
    is_rare = (target.astype(str) == rare).to_numpy()
    natural = float(is_rare.mean())
    info: dict[str, Any] = {
        "anomaly_class": rare,
        "classes": int(len(counts)),
        "natural_rate": natural,
        "kind": "native_rare",
    }
    keep = np.ones(len(target), dtype=bool)
    if natural > TARGET_RATE:
        n_normal = int((~is_rare).sum())
        k = round(n_normal * TARGET_RATE / (1 - TARGET_RATE))
        chosen = np.random.default_rng(SEED).choice(np.flatnonzero(is_rare), k, replace=False)
        keep = ~is_rare
        keep[chosen] = True
        info["kind"] = "downsampled"
    labels = is_rare[keep].astype(int)
    info.update(rows=int(keep.sum()), anomalies=int(labels.sum()))
    return features[keep].reset_index(drop=True), labels, info


def x_derive_labels__mutmut_36(
    frame: pd.DataFrame, meta: dict[str, Any]
) -> tuple[pd.DataFrame, np.ndarray, dict[str, Any]]:
    if "Classification" not in (meta.get("tasks") or []):
        raise NoLabels("not a classification task")
    features, target = split_columns(frame, meta)
    known = target.notna().to_numpy()
    features, target = features[known].reset_index(drop=True), target[known].reset_index(drop=True)
    counts = target.astype(str).value_counts()
    if len(counts) < 2:
        raise NoLabels("fewer than 2 classes")
    rare = str(counts.index[-1])
    if counts.iloc[-1] <= MIN_ANOMALIES:
        raise NoLabels(f"fewer than {MIN_ANOMALIES} rows in the rarest class")
    is_rare = (target.astype(str) == rare).to_numpy()
    natural = float(is_rare.mean())
    info: dict[str, Any] = {
        "anomaly_class": rare,
        "classes": int(len(counts)),
        "natural_rate": natural,
        "kind": "native_rare",
    }
    keep = np.ones(len(target), dtype=bool)
    if natural > TARGET_RATE:
        n_normal = int((~is_rare).sum())
        k = round(n_normal * TARGET_RATE / (1 - TARGET_RATE))
        chosen = np.random.default_rng(SEED).choice(np.flatnonzero(is_rare), k, replace=False)
        keep = ~is_rare
        keep[chosen] = True
        info["kind"] = "downsampled"
    labels = is_rare[keep].astype(int)
    info.update(rows=int(keep.sum()), anomalies=int(labels.sum()))
    return features[keep].reset_index(drop=True), labels, info


def x_derive_labels__mutmut_37(
    frame: pd.DataFrame, meta: dict[str, Any]
) -> tuple[pd.DataFrame, np.ndarray, dict[str, Any]]:
    if "Classification" not in (meta.get("tasks") or []):
        raise NoLabels("not a classification task")
    features, target = split_columns(frame, meta)
    known = target.notna().to_numpy()
    features, target = features[known].reset_index(drop=True), target[known].reset_index(drop=True)
    counts = target.astype(str).value_counts()
    if len(counts) < 2:
        raise NoLabels("fewer than 2 classes")
    rare = str(counts.index[-1])
    if counts.iloc[-1] < MIN_ANOMALIES:
        raise NoLabels(None)
    is_rare = (target.astype(str) == rare).to_numpy()
    natural = float(is_rare.mean())
    info: dict[str, Any] = {
        "anomaly_class": rare,
        "classes": int(len(counts)),
        "natural_rate": natural,
        "kind": "native_rare",
    }
    keep = np.ones(len(target), dtype=bool)
    if natural > TARGET_RATE:
        n_normal = int((~is_rare).sum())
        k = round(n_normal * TARGET_RATE / (1 - TARGET_RATE))
        chosen = np.random.default_rng(SEED).choice(np.flatnonzero(is_rare), k, replace=False)
        keep = ~is_rare
        keep[chosen] = True
        info["kind"] = "downsampled"
    labels = is_rare[keep].astype(int)
    info.update(rows=int(keep.sum()), anomalies=int(labels.sum()))
    return features[keep].reset_index(drop=True), labels, info


def x_derive_labels__mutmut_38(
    frame: pd.DataFrame, meta: dict[str, Any]
) -> tuple[pd.DataFrame, np.ndarray, dict[str, Any]]:
    if "Classification" not in (meta.get("tasks") or []):
        raise NoLabels("not a classification task")
    features, target = split_columns(frame, meta)
    known = target.notna().to_numpy()
    features, target = features[known].reset_index(drop=True), target[known].reset_index(drop=True)
    counts = target.astype(str).value_counts()
    if len(counts) < 2:
        raise NoLabels("fewer than 2 classes")
    rare = str(counts.index[-1])
    if counts.iloc[-1] < MIN_ANOMALIES:
        raise NoLabels(f"fewer than {MIN_ANOMALIES} rows in the rarest class")
    is_rare = None
    natural = float(is_rare.mean())
    info: dict[str, Any] = {
        "anomaly_class": rare,
        "classes": int(len(counts)),
        "natural_rate": natural,
        "kind": "native_rare",
    }
    keep = np.ones(len(target), dtype=bool)
    if natural > TARGET_RATE:
        n_normal = int((~is_rare).sum())
        k = round(n_normal * TARGET_RATE / (1 - TARGET_RATE))
        chosen = np.random.default_rng(SEED).choice(np.flatnonzero(is_rare), k, replace=False)
        keep = ~is_rare
        keep[chosen] = True
        info["kind"] = "downsampled"
    labels = is_rare[keep].astype(int)
    info.update(rows=int(keep.sum()), anomalies=int(labels.sum()))
    return features[keep].reset_index(drop=True), labels, info


def x_derive_labels__mutmut_39(
    frame: pd.DataFrame, meta: dict[str, Any]
) -> tuple[pd.DataFrame, np.ndarray, dict[str, Any]]:
    if "Classification" not in (meta.get("tasks") or []):
        raise NoLabels("not a classification task")
    features, target = split_columns(frame, meta)
    known = target.notna().to_numpy()
    features, target = features[known].reset_index(drop=True), target[known].reset_index(drop=True)
    counts = target.astype(str).value_counts()
    if len(counts) < 2:
        raise NoLabels("fewer than 2 classes")
    rare = str(counts.index[-1])
    if counts.iloc[-1] < MIN_ANOMALIES:
        raise NoLabels(f"fewer than {MIN_ANOMALIES} rows in the rarest class")
    is_rare = (target.astype(None) == rare).to_numpy()
    natural = float(is_rare.mean())
    info: dict[str, Any] = {
        "anomaly_class": rare,
        "classes": int(len(counts)),
        "natural_rate": natural,
        "kind": "native_rare",
    }
    keep = np.ones(len(target), dtype=bool)
    if natural > TARGET_RATE:
        n_normal = int((~is_rare).sum())
        k = round(n_normal * TARGET_RATE / (1 - TARGET_RATE))
        chosen = np.random.default_rng(SEED).choice(np.flatnonzero(is_rare), k, replace=False)
        keep = ~is_rare
        keep[chosen] = True
        info["kind"] = "downsampled"
    labels = is_rare[keep].astype(int)
    info.update(rows=int(keep.sum()), anomalies=int(labels.sum()))
    return features[keep].reset_index(drop=True), labels, info


def x_derive_labels__mutmut_40(
    frame: pd.DataFrame, meta: dict[str, Any]
) -> tuple[pd.DataFrame, np.ndarray, dict[str, Any]]:
    if "Classification" not in (meta.get("tasks") or []):
        raise NoLabels("not a classification task")
    features, target = split_columns(frame, meta)
    known = target.notna().to_numpy()
    features, target = features[known].reset_index(drop=True), target[known].reset_index(drop=True)
    counts = target.astype(str).value_counts()
    if len(counts) < 2:
        raise NoLabels("fewer than 2 classes")
    rare = str(counts.index[-1])
    if counts.iloc[-1] < MIN_ANOMALIES:
        raise NoLabels(f"fewer than {MIN_ANOMALIES} rows in the rarest class")
    is_rare = (target.astype(str) != rare).to_numpy()
    natural = float(is_rare.mean())
    info: dict[str, Any] = {
        "anomaly_class": rare,
        "classes": int(len(counts)),
        "natural_rate": natural,
        "kind": "native_rare",
    }
    keep = np.ones(len(target), dtype=bool)
    if natural > TARGET_RATE:
        n_normal = int((~is_rare).sum())
        k = round(n_normal * TARGET_RATE / (1 - TARGET_RATE))
        chosen = np.random.default_rng(SEED).choice(np.flatnonzero(is_rare), k, replace=False)
        keep = ~is_rare
        keep[chosen] = True
        info["kind"] = "downsampled"
    labels = is_rare[keep].astype(int)
    info.update(rows=int(keep.sum()), anomalies=int(labels.sum()))
    return features[keep].reset_index(drop=True), labels, info


def x_derive_labels__mutmut_41(
    frame: pd.DataFrame, meta: dict[str, Any]
) -> tuple[pd.DataFrame, np.ndarray, dict[str, Any]]:
    if "Classification" not in (meta.get("tasks") or []):
        raise NoLabels("not a classification task")
    features, target = split_columns(frame, meta)
    known = target.notna().to_numpy()
    features, target = features[known].reset_index(drop=True), target[known].reset_index(drop=True)
    counts = target.astype(str).value_counts()
    if len(counts) < 2:
        raise NoLabels("fewer than 2 classes")
    rare = str(counts.index[-1])
    if counts.iloc[-1] < MIN_ANOMALIES:
        raise NoLabels(f"fewer than {MIN_ANOMALIES} rows in the rarest class")
    is_rare = (target.astype(str) == rare).to_numpy()
    natural = None
    info: dict[str, Any] = {
        "anomaly_class": rare,
        "classes": int(len(counts)),
        "natural_rate": natural,
        "kind": "native_rare",
    }
    keep = np.ones(len(target), dtype=bool)
    if natural > TARGET_RATE:
        n_normal = int((~is_rare).sum())
        k = round(n_normal * TARGET_RATE / (1 - TARGET_RATE))
        chosen = np.random.default_rng(SEED).choice(np.flatnonzero(is_rare), k, replace=False)
        keep = ~is_rare
        keep[chosen] = True
        info["kind"] = "downsampled"
    labels = is_rare[keep].astype(int)
    info.update(rows=int(keep.sum()), anomalies=int(labels.sum()))
    return features[keep].reset_index(drop=True), labels, info


def x_derive_labels__mutmut_42(
    frame: pd.DataFrame, meta: dict[str, Any]
) -> tuple[pd.DataFrame, np.ndarray, dict[str, Any]]:
    if "Classification" not in (meta.get("tasks") or []):
        raise NoLabels("not a classification task")
    features, target = split_columns(frame, meta)
    known = target.notna().to_numpy()
    features, target = features[known].reset_index(drop=True), target[known].reset_index(drop=True)
    counts = target.astype(str).value_counts()
    if len(counts) < 2:
        raise NoLabels("fewer than 2 classes")
    rare = str(counts.index[-1])
    if counts.iloc[-1] < MIN_ANOMALIES:
        raise NoLabels(f"fewer than {MIN_ANOMALIES} rows in the rarest class")
    is_rare = (target.astype(str) == rare).to_numpy()
    natural = float(None)
    info: dict[str, Any] = {
        "anomaly_class": rare,
        "classes": int(len(counts)),
        "natural_rate": natural,
        "kind": "native_rare",
    }
    keep = np.ones(len(target), dtype=bool)
    if natural > TARGET_RATE:
        n_normal = int((~is_rare).sum())
        k = round(n_normal * TARGET_RATE / (1 - TARGET_RATE))
        chosen = np.random.default_rng(SEED).choice(np.flatnonzero(is_rare), k, replace=False)
        keep = ~is_rare
        keep[chosen] = True
        info["kind"] = "downsampled"
    labels = is_rare[keep].astype(int)
    info.update(rows=int(keep.sum()), anomalies=int(labels.sum()))
    return features[keep].reset_index(drop=True), labels, info


def x_derive_labels__mutmut_43(
    frame: pd.DataFrame, meta: dict[str, Any]
) -> tuple[pd.DataFrame, np.ndarray, dict[str, Any]]:
    if "Classification" not in (meta.get("tasks") or []):
        raise NoLabels("not a classification task")
    features, target = split_columns(frame, meta)
    known = target.notna().to_numpy()
    features, target = features[known].reset_index(drop=True), target[known].reset_index(drop=True)
    counts = target.astype(str).value_counts()
    if len(counts) < 2:
        raise NoLabels("fewer than 2 classes")
    rare = str(counts.index[-1])
    if counts.iloc[-1] < MIN_ANOMALIES:
        raise NoLabels(f"fewer than {MIN_ANOMALIES} rows in the rarest class")
    is_rare = (target.astype(str) == rare).to_numpy()
    natural = float(is_rare.mean())
    info: dict[str, Any] = None
    keep = np.ones(len(target), dtype=bool)
    if natural > TARGET_RATE:
        n_normal = int((~is_rare).sum())
        k = round(n_normal * TARGET_RATE / (1 - TARGET_RATE))
        chosen = np.random.default_rng(SEED).choice(np.flatnonzero(is_rare), k, replace=False)
        keep = ~is_rare
        keep[chosen] = True
        info["kind"] = "downsampled"
    labels = is_rare[keep].astype(int)
    info.update(rows=int(keep.sum()), anomalies=int(labels.sum()))
    return features[keep].reset_index(drop=True), labels, info


def x_derive_labels__mutmut_44(
    frame: pd.DataFrame, meta: dict[str, Any]
) -> tuple[pd.DataFrame, np.ndarray, dict[str, Any]]:
    if "Classification" not in (meta.get("tasks") or []):
        raise NoLabels("not a classification task")
    features, target = split_columns(frame, meta)
    known = target.notna().to_numpy()
    features, target = features[known].reset_index(drop=True), target[known].reset_index(drop=True)
    counts = target.astype(str).value_counts()
    if len(counts) < 2:
        raise NoLabels("fewer than 2 classes")
    rare = str(counts.index[-1])
    if counts.iloc[-1] < MIN_ANOMALIES:
        raise NoLabels(f"fewer than {MIN_ANOMALIES} rows in the rarest class")
    is_rare = (target.astype(str) == rare).to_numpy()
    natural = float(is_rare.mean())
    info: dict[str, Any] = {
        "XXanomaly_classXX": rare,
        "classes": int(len(counts)),
        "natural_rate": natural,
        "kind": "native_rare",
    }
    keep = np.ones(len(target), dtype=bool)
    if natural > TARGET_RATE:
        n_normal = int((~is_rare).sum())
        k = round(n_normal * TARGET_RATE / (1 - TARGET_RATE))
        chosen = np.random.default_rng(SEED).choice(np.flatnonzero(is_rare), k, replace=False)
        keep = ~is_rare
        keep[chosen] = True
        info["kind"] = "downsampled"
    labels = is_rare[keep].astype(int)
    info.update(rows=int(keep.sum()), anomalies=int(labels.sum()))
    return features[keep].reset_index(drop=True), labels, info


def x_derive_labels__mutmut_45(
    frame: pd.DataFrame, meta: dict[str, Any]
) -> tuple[pd.DataFrame, np.ndarray, dict[str, Any]]:
    if "Classification" not in (meta.get("tasks") or []):
        raise NoLabels("not a classification task")
    features, target = split_columns(frame, meta)
    known = target.notna().to_numpy()
    features, target = features[known].reset_index(drop=True), target[known].reset_index(drop=True)
    counts = target.astype(str).value_counts()
    if len(counts) < 2:
        raise NoLabels("fewer than 2 classes")
    rare = str(counts.index[-1])
    if counts.iloc[-1] < MIN_ANOMALIES:
        raise NoLabels(f"fewer than {MIN_ANOMALIES} rows in the rarest class")
    is_rare = (target.astype(str) == rare).to_numpy()
    natural = float(is_rare.mean())
    info: dict[str, Any] = {
        "ANOMALY_CLASS": rare,
        "classes": int(len(counts)),
        "natural_rate": natural,
        "kind": "native_rare",
    }
    keep = np.ones(len(target), dtype=bool)
    if natural > TARGET_RATE:
        n_normal = int((~is_rare).sum())
        k = round(n_normal * TARGET_RATE / (1 - TARGET_RATE))
        chosen = np.random.default_rng(SEED).choice(np.flatnonzero(is_rare), k, replace=False)
        keep = ~is_rare
        keep[chosen] = True
        info["kind"] = "downsampled"
    labels = is_rare[keep].astype(int)
    info.update(rows=int(keep.sum()), anomalies=int(labels.sum()))
    return features[keep].reset_index(drop=True), labels, info


def x_derive_labels__mutmut_46(
    frame: pd.DataFrame, meta: dict[str, Any]
) -> tuple[pd.DataFrame, np.ndarray, dict[str, Any]]:
    if "Classification" not in (meta.get("tasks") or []):
        raise NoLabels("not a classification task")
    features, target = split_columns(frame, meta)
    known = target.notna().to_numpy()
    features, target = features[known].reset_index(drop=True), target[known].reset_index(drop=True)
    counts = target.astype(str).value_counts()
    if len(counts) < 2:
        raise NoLabels("fewer than 2 classes")
    rare = str(counts.index[-1])
    if counts.iloc[-1] < MIN_ANOMALIES:
        raise NoLabels(f"fewer than {MIN_ANOMALIES} rows in the rarest class")
    is_rare = (target.astype(str) == rare).to_numpy()
    natural = float(is_rare.mean())
    info: dict[str, Any] = {
        "anomaly_class": rare,
        "XXclassesXX": int(len(counts)),
        "natural_rate": natural,
        "kind": "native_rare",
    }
    keep = np.ones(len(target), dtype=bool)
    if natural > TARGET_RATE:
        n_normal = int((~is_rare).sum())
        k = round(n_normal * TARGET_RATE / (1 - TARGET_RATE))
        chosen = np.random.default_rng(SEED).choice(np.flatnonzero(is_rare), k, replace=False)
        keep = ~is_rare
        keep[chosen] = True
        info["kind"] = "downsampled"
    labels = is_rare[keep].astype(int)
    info.update(rows=int(keep.sum()), anomalies=int(labels.sum()))
    return features[keep].reset_index(drop=True), labels, info


def x_derive_labels__mutmut_47(
    frame: pd.DataFrame, meta: dict[str, Any]
) -> tuple[pd.DataFrame, np.ndarray, dict[str, Any]]:
    if "Classification" not in (meta.get("tasks") or []):
        raise NoLabels("not a classification task")
    features, target = split_columns(frame, meta)
    known = target.notna().to_numpy()
    features, target = features[known].reset_index(drop=True), target[known].reset_index(drop=True)
    counts = target.astype(str).value_counts()
    if len(counts) < 2:
        raise NoLabels("fewer than 2 classes")
    rare = str(counts.index[-1])
    if counts.iloc[-1] < MIN_ANOMALIES:
        raise NoLabels(f"fewer than {MIN_ANOMALIES} rows in the rarest class")
    is_rare = (target.astype(str) == rare).to_numpy()
    natural = float(is_rare.mean())
    info: dict[str, Any] = {
        "anomaly_class": rare,
        "CLASSES": int(len(counts)),
        "natural_rate": natural,
        "kind": "native_rare",
    }
    keep = np.ones(len(target), dtype=bool)
    if natural > TARGET_RATE:
        n_normal = int((~is_rare).sum())
        k = round(n_normal * TARGET_RATE / (1 - TARGET_RATE))
        chosen = np.random.default_rng(SEED).choice(np.flatnonzero(is_rare), k, replace=False)
        keep = ~is_rare
        keep[chosen] = True
        info["kind"] = "downsampled"
    labels = is_rare[keep].astype(int)
    info.update(rows=int(keep.sum()), anomalies=int(labels.sum()))
    return features[keep].reset_index(drop=True), labels, info


def x_derive_labels__mutmut_48(
    frame: pd.DataFrame, meta: dict[str, Any]
) -> tuple[pd.DataFrame, np.ndarray, dict[str, Any]]:
    if "Classification" not in (meta.get("tasks") or []):
        raise NoLabels("not a classification task")
    features, target = split_columns(frame, meta)
    known = target.notna().to_numpy()
    features, target = features[known].reset_index(drop=True), target[known].reset_index(drop=True)
    counts = target.astype(str).value_counts()
    if len(counts) < 2:
        raise NoLabels("fewer than 2 classes")
    rare = str(counts.index[-1])
    if counts.iloc[-1] < MIN_ANOMALIES:
        raise NoLabels(f"fewer than {MIN_ANOMALIES} rows in the rarest class")
    is_rare = (target.astype(str) == rare).to_numpy()
    natural = float(is_rare.mean())
    info: dict[str, Any] = {
        "anomaly_class": rare,
        "classes": int(None),
        "natural_rate": natural,
        "kind": "native_rare",
    }
    keep = np.ones(len(target), dtype=bool)
    if natural > TARGET_RATE:
        n_normal = int((~is_rare).sum())
        k = round(n_normal * TARGET_RATE / (1 - TARGET_RATE))
        chosen = np.random.default_rng(SEED).choice(np.flatnonzero(is_rare), k, replace=False)
        keep = ~is_rare
        keep[chosen] = True
        info["kind"] = "downsampled"
    labels = is_rare[keep].astype(int)
    info.update(rows=int(keep.sum()), anomalies=int(labels.sum()))
    return features[keep].reset_index(drop=True), labels, info


def x_derive_labels__mutmut_49(
    frame: pd.DataFrame, meta: dict[str, Any]
) -> tuple[pd.DataFrame, np.ndarray, dict[str, Any]]:
    if "Classification" not in (meta.get("tasks") or []):
        raise NoLabels("not a classification task")
    features, target = split_columns(frame, meta)
    known = target.notna().to_numpy()
    features, target = features[known].reset_index(drop=True), target[known].reset_index(drop=True)
    counts = target.astype(str).value_counts()
    if len(counts) < 2:
        raise NoLabels("fewer than 2 classes")
    rare = str(counts.index[-1])
    if counts.iloc[-1] < MIN_ANOMALIES:
        raise NoLabels(f"fewer than {MIN_ANOMALIES} rows in the rarest class")
    is_rare = (target.astype(str) == rare).to_numpy()
    natural = float(is_rare.mean())
    info: dict[str, Any] = {
        "anomaly_class": rare,
        "classes": int(len(counts)),
        "XXnatural_rateXX": natural,
        "kind": "native_rare",
    }
    keep = np.ones(len(target), dtype=bool)
    if natural > TARGET_RATE:
        n_normal = int((~is_rare).sum())
        k = round(n_normal * TARGET_RATE / (1 - TARGET_RATE))
        chosen = np.random.default_rng(SEED).choice(np.flatnonzero(is_rare), k, replace=False)
        keep = ~is_rare
        keep[chosen] = True
        info["kind"] = "downsampled"
    labels = is_rare[keep].astype(int)
    info.update(rows=int(keep.sum()), anomalies=int(labels.sum()))
    return features[keep].reset_index(drop=True), labels, info


def x_derive_labels__mutmut_50(
    frame: pd.DataFrame, meta: dict[str, Any]
) -> tuple[pd.DataFrame, np.ndarray, dict[str, Any]]:
    if "Classification" not in (meta.get("tasks") or []):
        raise NoLabels("not a classification task")
    features, target = split_columns(frame, meta)
    known = target.notna().to_numpy()
    features, target = features[known].reset_index(drop=True), target[known].reset_index(drop=True)
    counts = target.astype(str).value_counts()
    if len(counts) < 2:
        raise NoLabels("fewer than 2 classes")
    rare = str(counts.index[-1])
    if counts.iloc[-1] < MIN_ANOMALIES:
        raise NoLabels(f"fewer than {MIN_ANOMALIES} rows in the rarest class")
    is_rare = (target.astype(str) == rare).to_numpy()
    natural = float(is_rare.mean())
    info: dict[str, Any] = {
        "anomaly_class": rare,
        "classes": int(len(counts)),
        "NATURAL_RATE": natural,
        "kind": "native_rare",
    }
    keep = np.ones(len(target), dtype=bool)
    if natural > TARGET_RATE:
        n_normal = int((~is_rare).sum())
        k = round(n_normal * TARGET_RATE / (1 - TARGET_RATE))
        chosen = np.random.default_rng(SEED).choice(np.flatnonzero(is_rare), k, replace=False)
        keep = ~is_rare
        keep[chosen] = True
        info["kind"] = "downsampled"
    labels = is_rare[keep].astype(int)
    info.update(rows=int(keep.sum()), anomalies=int(labels.sum()))
    return features[keep].reset_index(drop=True), labels, info


def x_derive_labels__mutmut_51(
    frame: pd.DataFrame, meta: dict[str, Any]
) -> tuple[pd.DataFrame, np.ndarray, dict[str, Any]]:
    if "Classification" not in (meta.get("tasks") or []):
        raise NoLabels("not a classification task")
    features, target = split_columns(frame, meta)
    known = target.notna().to_numpy()
    features, target = features[known].reset_index(drop=True), target[known].reset_index(drop=True)
    counts = target.astype(str).value_counts()
    if len(counts) < 2:
        raise NoLabels("fewer than 2 classes")
    rare = str(counts.index[-1])
    if counts.iloc[-1] < MIN_ANOMALIES:
        raise NoLabels(f"fewer than {MIN_ANOMALIES} rows in the rarest class")
    is_rare = (target.astype(str) == rare).to_numpy()
    natural = float(is_rare.mean())
    info: dict[str, Any] = {
        "anomaly_class": rare,
        "classes": int(len(counts)),
        "natural_rate": natural,
        "XXkindXX": "native_rare",
    }
    keep = np.ones(len(target), dtype=bool)
    if natural > TARGET_RATE:
        n_normal = int((~is_rare).sum())
        k = round(n_normal * TARGET_RATE / (1 - TARGET_RATE))
        chosen = np.random.default_rng(SEED).choice(np.flatnonzero(is_rare), k, replace=False)
        keep = ~is_rare
        keep[chosen] = True
        info["kind"] = "downsampled"
    labels = is_rare[keep].astype(int)
    info.update(rows=int(keep.sum()), anomalies=int(labels.sum()))
    return features[keep].reset_index(drop=True), labels, info


def x_derive_labels__mutmut_52(
    frame: pd.DataFrame, meta: dict[str, Any]
) -> tuple[pd.DataFrame, np.ndarray, dict[str, Any]]:
    if "Classification" not in (meta.get("tasks") or []):
        raise NoLabels("not a classification task")
    features, target = split_columns(frame, meta)
    known = target.notna().to_numpy()
    features, target = features[known].reset_index(drop=True), target[known].reset_index(drop=True)
    counts = target.astype(str).value_counts()
    if len(counts) < 2:
        raise NoLabels("fewer than 2 classes")
    rare = str(counts.index[-1])
    if counts.iloc[-1] < MIN_ANOMALIES:
        raise NoLabels(f"fewer than {MIN_ANOMALIES} rows in the rarest class")
    is_rare = (target.astype(str) == rare).to_numpy()
    natural = float(is_rare.mean())
    info: dict[str, Any] = {
        "anomaly_class": rare,
        "classes": int(len(counts)),
        "natural_rate": natural,
        "KIND": "native_rare",
    }
    keep = np.ones(len(target), dtype=bool)
    if natural > TARGET_RATE:
        n_normal = int((~is_rare).sum())
        k = round(n_normal * TARGET_RATE / (1 - TARGET_RATE))
        chosen = np.random.default_rng(SEED).choice(np.flatnonzero(is_rare), k, replace=False)
        keep = ~is_rare
        keep[chosen] = True
        info["kind"] = "downsampled"
    labels = is_rare[keep].astype(int)
    info.update(rows=int(keep.sum()), anomalies=int(labels.sum()))
    return features[keep].reset_index(drop=True), labels, info


def x_derive_labels__mutmut_53(
    frame: pd.DataFrame, meta: dict[str, Any]
) -> tuple[pd.DataFrame, np.ndarray, dict[str, Any]]:
    if "Classification" not in (meta.get("tasks") or []):
        raise NoLabels("not a classification task")
    features, target = split_columns(frame, meta)
    known = target.notna().to_numpy()
    features, target = features[known].reset_index(drop=True), target[known].reset_index(drop=True)
    counts = target.astype(str).value_counts()
    if len(counts) < 2:
        raise NoLabels("fewer than 2 classes")
    rare = str(counts.index[-1])
    if counts.iloc[-1] < MIN_ANOMALIES:
        raise NoLabels(f"fewer than {MIN_ANOMALIES} rows in the rarest class")
    is_rare = (target.astype(str) == rare).to_numpy()
    natural = float(is_rare.mean())
    info: dict[str, Any] = {
        "anomaly_class": rare,
        "classes": int(len(counts)),
        "natural_rate": natural,
        "kind": "XXnative_rareXX",
    }
    keep = np.ones(len(target), dtype=bool)
    if natural > TARGET_RATE:
        n_normal = int((~is_rare).sum())
        k = round(n_normal * TARGET_RATE / (1 - TARGET_RATE))
        chosen = np.random.default_rng(SEED).choice(np.flatnonzero(is_rare), k, replace=False)
        keep = ~is_rare
        keep[chosen] = True
        info["kind"] = "downsampled"
    labels = is_rare[keep].astype(int)
    info.update(rows=int(keep.sum()), anomalies=int(labels.sum()))
    return features[keep].reset_index(drop=True), labels, info


def x_derive_labels__mutmut_54(
    frame: pd.DataFrame, meta: dict[str, Any]
) -> tuple[pd.DataFrame, np.ndarray, dict[str, Any]]:
    if "Classification" not in (meta.get("tasks") or []):
        raise NoLabels("not a classification task")
    features, target = split_columns(frame, meta)
    known = target.notna().to_numpy()
    features, target = features[known].reset_index(drop=True), target[known].reset_index(drop=True)
    counts = target.astype(str).value_counts()
    if len(counts) < 2:
        raise NoLabels("fewer than 2 classes")
    rare = str(counts.index[-1])
    if counts.iloc[-1] < MIN_ANOMALIES:
        raise NoLabels(f"fewer than {MIN_ANOMALIES} rows in the rarest class")
    is_rare = (target.astype(str) == rare).to_numpy()
    natural = float(is_rare.mean())
    info: dict[str, Any] = {
        "anomaly_class": rare,
        "classes": int(len(counts)),
        "natural_rate": natural,
        "kind": "NATIVE_RARE",
    }
    keep = np.ones(len(target), dtype=bool)
    if natural > TARGET_RATE:
        n_normal = int((~is_rare).sum())
        k = round(n_normal * TARGET_RATE / (1 - TARGET_RATE))
        chosen = np.random.default_rng(SEED).choice(np.flatnonzero(is_rare), k, replace=False)
        keep = ~is_rare
        keep[chosen] = True
        info["kind"] = "downsampled"
    labels = is_rare[keep].astype(int)
    info.update(rows=int(keep.sum()), anomalies=int(labels.sum()))
    return features[keep].reset_index(drop=True), labels, info


def x_derive_labels__mutmut_55(
    frame: pd.DataFrame, meta: dict[str, Any]
) -> tuple[pd.DataFrame, np.ndarray, dict[str, Any]]:
    if "Classification" not in (meta.get("tasks") or []):
        raise NoLabels("not a classification task")
    features, target = split_columns(frame, meta)
    known = target.notna().to_numpy()
    features, target = features[known].reset_index(drop=True), target[known].reset_index(drop=True)
    counts = target.astype(str).value_counts()
    if len(counts) < 2:
        raise NoLabels("fewer than 2 classes")
    rare = str(counts.index[-1])
    if counts.iloc[-1] < MIN_ANOMALIES:
        raise NoLabels(f"fewer than {MIN_ANOMALIES} rows in the rarest class")
    is_rare = (target.astype(str) == rare).to_numpy()
    natural = float(is_rare.mean())
    info: dict[str, Any] = {
        "anomaly_class": rare,
        "classes": int(len(counts)),
        "natural_rate": natural,
        "kind": "native_rare",
    }
    keep = None
    if natural > TARGET_RATE:
        n_normal = int((~is_rare).sum())
        k = round(n_normal * TARGET_RATE / (1 - TARGET_RATE))
        chosen = np.random.default_rng(SEED).choice(np.flatnonzero(is_rare), k, replace=False)
        keep = ~is_rare
        keep[chosen] = True
        info["kind"] = "downsampled"
    labels = is_rare[keep].astype(int)
    info.update(rows=int(keep.sum()), anomalies=int(labels.sum()))
    return features[keep].reset_index(drop=True), labels, info


def x_derive_labels__mutmut_56(
    frame: pd.DataFrame, meta: dict[str, Any]
) -> tuple[pd.DataFrame, np.ndarray, dict[str, Any]]:
    if "Classification" not in (meta.get("tasks") or []):
        raise NoLabels("not a classification task")
    features, target = split_columns(frame, meta)
    known = target.notna().to_numpy()
    features, target = features[known].reset_index(drop=True), target[known].reset_index(drop=True)
    counts = target.astype(str).value_counts()
    if len(counts) < 2:
        raise NoLabels("fewer than 2 classes")
    rare = str(counts.index[-1])
    if counts.iloc[-1] < MIN_ANOMALIES:
        raise NoLabels(f"fewer than {MIN_ANOMALIES} rows in the rarest class")
    is_rare = (target.astype(str) == rare).to_numpy()
    natural = float(is_rare.mean())
    info: dict[str, Any] = {
        "anomaly_class": rare,
        "classes": int(len(counts)),
        "natural_rate": natural,
        "kind": "native_rare",
    }
    keep = np.ones(None, dtype=bool)
    if natural > TARGET_RATE:
        n_normal = int((~is_rare).sum())
        k = round(n_normal * TARGET_RATE / (1 - TARGET_RATE))
        chosen = np.random.default_rng(SEED).choice(np.flatnonzero(is_rare), k, replace=False)
        keep = ~is_rare
        keep[chosen] = True
        info["kind"] = "downsampled"
    labels = is_rare[keep].astype(int)
    info.update(rows=int(keep.sum()), anomalies=int(labels.sum()))
    return features[keep].reset_index(drop=True), labels, info


def x_derive_labels__mutmut_57(
    frame: pd.DataFrame, meta: dict[str, Any]
) -> tuple[pd.DataFrame, np.ndarray, dict[str, Any]]:
    if "Classification" not in (meta.get("tasks") or []):
        raise NoLabels("not a classification task")
    features, target = split_columns(frame, meta)
    known = target.notna().to_numpy()
    features, target = features[known].reset_index(drop=True), target[known].reset_index(drop=True)
    counts = target.astype(str).value_counts()
    if len(counts) < 2:
        raise NoLabels("fewer than 2 classes")
    rare = str(counts.index[-1])
    if counts.iloc[-1] < MIN_ANOMALIES:
        raise NoLabels(f"fewer than {MIN_ANOMALIES} rows in the rarest class")
    is_rare = (target.astype(str) == rare).to_numpy()
    natural = float(is_rare.mean())
    info: dict[str, Any] = {
        "anomaly_class": rare,
        "classes": int(len(counts)),
        "natural_rate": natural,
        "kind": "native_rare",
    }
    keep = np.ones(len(target), dtype=None)
    if natural > TARGET_RATE:
        n_normal = int((~is_rare).sum())
        k = round(n_normal * TARGET_RATE / (1 - TARGET_RATE))
        chosen = np.random.default_rng(SEED).choice(np.flatnonzero(is_rare), k, replace=False)
        keep = ~is_rare
        keep[chosen] = True
        info["kind"] = "downsampled"
    labels = is_rare[keep].astype(int)
    info.update(rows=int(keep.sum()), anomalies=int(labels.sum()))
    return features[keep].reset_index(drop=True), labels, info


def x_derive_labels__mutmut_58(
    frame: pd.DataFrame, meta: dict[str, Any]
) -> tuple[pd.DataFrame, np.ndarray, dict[str, Any]]:
    if "Classification" not in (meta.get("tasks") or []):
        raise NoLabels("not a classification task")
    features, target = split_columns(frame, meta)
    known = target.notna().to_numpy()
    features, target = features[known].reset_index(drop=True), target[known].reset_index(drop=True)
    counts = target.astype(str).value_counts()
    if len(counts) < 2:
        raise NoLabels("fewer than 2 classes")
    rare = str(counts.index[-1])
    if counts.iloc[-1] < MIN_ANOMALIES:
        raise NoLabels(f"fewer than {MIN_ANOMALIES} rows in the rarest class")
    is_rare = (target.astype(str) == rare).to_numpy()
    natural = float(is_rare.mean())
    info: dict[str, Any] = {
        "anomaly_class": rare,
        "classes": int(len(counts)),
        "natural_rate": natural,
        "kind": "native_rare",
    }
    keep = np.ones(dtype=bool)
    if natural > TARGET_RATE:
        n_normal = int((~is_rare).sum())
        k = round(n_normal * TARGET_RATE / (1 - TARGET_RATE))
        chosen = np.random.default_rng(SEED).choice(np.flatnonzero(is_rare), k, replace=False)
        keep = ~is_rare
        keep[chosen] = True
        info["kind"] = "downsampled"
    labels = is_rare[keep].astype(int)
    info.update(rows=int(keep.sum()), anomalies=int(labels.sum()))
    return features[keep].reset_index(drop=True), labels, info


def x_derive_labels__mutmut_59(
    frame: pd.DataFrame, meta: dict[str, Any]
) -> tuple[pd.DataFrame, np.ndarray, dict[str, Any]]:
    if "Classification" not in (meta.get("tasks") or []):
        raise NoLabels("not a classification task")
    features, target = split_columns(frame, meta)
    known = target.notna().to_numpy()
    features, target = features[known].reset_index(drop=True), target[known].reset_index(drop=True)
    counts = target.astype(str).value_counts()
    if len(counts) < 2:
        raise NoLabels("fewer than 2 classes")
    rare = str(counts.index[-1])
    if counts.iloc[-1] < MIN_ANOMALIES:
        raise NoLabels(f"fewer than {MIN_ANOMALIES} rows in the rarest class")
    is_rare = (target.astype(str) == rare).to_numpy()
    natural = float(is_rare.mean())
    info: dict[str, Any] = {
        "anomaly_class": rare,
        "classes": int(len(counts)),
        "natural_rate": natural,
        "kind": "native_rare",
    }
    keep = np.ones(len(target), )
    if natural > TARGET_RATE:
        n_normal = int((~is_rare).sum())
        k = round(n_normal * TARGET_RATE / (1 - TARGET_RATE))
        chosen = np.random.default_rng(SEED).choice(np.flatnonzero(is_rare), k, replace=False)
        keep = ~is_rare
        keep[chosen] = True
        info["kind"] = "downsampled"
    labels = is_rare[keep].astype(int)
    info.update(rows=int(keep.sum()), anomalies=int(labels.sum()))
    return features[keep].reset_index(drop=True), labels, info


def x_derive_labels__mutmut_60(
    frame: pd.DataFrame, meta: dict[str, Any]
) -> tuple[pd.DataFrame, np.ndarray, dict[str, Any]]:
    if "Classification" not in (meta.get("tasks") or []):
        raise NoLabels("not a classification task")
    features, target = split_columns(frame, meta)
    known = target.notna().to_numpy()
    features, target = features[known].reset_index(drop=True), target[known].reset_index(drop=True)
    counts = target.astype(str).value_counts()
    if len(counts) < 2:
        raise NoLabels("fewer than 2 classes")
    rare = str(counts.index[-1])
    if counts.iloc[-1] < MIN_ANOMALIES:
        raise NoLabels(f"fewer than {MIN_ANOMALIES} rows in the rarest class")
    is_rare = (target.astype(str) == rare).to_numpy()
    natural = float(is_rare.mean())
    info: dict[str, Any] = {
        "anomaly_class": rare,
        "classes": int(len(counts)),
        "natural_rate": natural,
        "kind": "native_rare",
    }
    keep = np.ones(len(target), dtype=bool)
    if natural >= TARGET_RATE:
        n_normal = int((~is_rare).sum())
        k = round(n_normal * TARGET_RATE / (1 - TARGET_RATE))
        chosen = np.random.default_rng(SEED).choice(np.flatnonzero(is_rare), k, replace=False)
        keep = ~is_rare
        keep[chosen] = True
        info["kind"] = "downsampled"
    labels = is_rare[keep].astype(int)
    info.update(rows=int(keep.sum()), anomalies=int(labels.sum()))
    return features[keep].reset_index(drop=True), labels, info


def x_derive_labels__mutmut_61(
    frame: pd.DataFrame, meta: dict[str, Any]
) -> tuple[pd.DataFrame, np.ndarray, dict[str, Any]]:
    if "Classification" not in (meta.get("tasks") or []):
        raise NoLabels("not a classification task")
    features, target = split_columns(frame, meta)
    known = target.notna().to_numpy()
    features, target = features[known].reset_index(drop=True), target[known].reset_index(drop=True)
    counts = target.astype(str).value_counts()
    if len(counts) < 2:
        raise NoLabels("fewer than 2 classes")
    rare = str(counts.index[-1])
    if counts.iloc[-1] < MIN_ANOMALIES:
        raise NoLabels(f"fewer than {MIN_ANOMALIES} rows in the rarest class")
    is_rare = (target.astype(str) == rare).to_numpy()
    natural = float(is_rare.mean())
    info: dict[str, Any] = {
        "anomaly_class": rare,
        "classes": int(len(counts)),
        "natural_rate": natural,
        "kind": "native_rare",
    }
    keep = np.ones(len(target), dtype=bool)
    if natural > TARGET_RATE:
        n_normal = None
        k = round(n_normal * TARGET_RATE / (1 - TARGET_RATE))
        chosen = np.random.default_rng(SEED).choice(np.flatnonzero(is_rare), k, replace=False)
        keep = ~is_rare
        keep[chosen] = True
        info["kind"] = "downsampled"
    labels = is_rare[keep].astype(int)
    info.update(rows=int(keep.sum()), anomalies=int(labels.sum()))
    return features[keep].reset_index(drop=True), labels, info


def x_derive_labels__mutmut_62(
    frame: pd.DataFrame, meta: dict[str, Any]
) -> tuple[pd.DataFrame, np.ndarray, dict[str, Any]]:
    if "Classification" not in (meta.get("tasks") or []):
        raise NoLabels("not a classification task")
    features, target = split_columns(frame, meta)
    known = target.notna().to_numpy()
    features, target = features[known].reset_index(drop=True), target[known].reset_index(drop=True)
    counts = target.astype(str).value_counts()
    if len(counts) < 2:
        raise NoLabels("fewer than 2 classes")
    rare = str(counts.index[-1])
    if counts.iloc[-1] < MIN_ANOMALIES:
        raise NoLabels(f"fewer than {MIN_ANOMALIES} rows in the rarest class")
    is_rare = (target.astype(str) == rare).to_numpy()
    natural = float(is_rare.mean())
    info: dict[str, Any] = {
        "anomaly_class": rare,
        "classes": int(len(counts)),
        "natural_rate": natural,
        "kind": "native_rare",
    }
    keep = np.ones(len(target), dtype=bool)
    if natural > TARGET_RATE:
        n_normal = int(None)
        k = round(n_normal * TARGET_RATE / (1 - TARGET_RATE))
        chosen = np.random.default_rng(SEED).choice(np.flatnonzero(is_rare), k, replace=False)
        keep = ~is_rare
        keep[chosen] = True
        info["kind"] = "downsampled"
    labels = is_rare[keep].astype(int)
    info.update(rows=int(keep.sum()), anomalies=int(labels.sum()))
    return features[keep].reset_index(drop=True), labels, info


def x_derive_labels__mutmut_63(
    frame: pd.DataFrame, meta: dict[str, Any]
) -> tuple[pd.DataFrame, np.ndarray, dict[str, Any]]:
    if "Classification" not in (meta.get("tasks") or []):
        raise NoLabels("not a classification task")
    features, target = split_columns(frame, meta)
    known = target.notna().to_numpy()
    features, target = features[known].reset_index(drop=True), target[known].reset_index(drop=True)
    counts = target.astype(str).value_counts()
    if len(counts) < 2:
        raise NoLabels("fewer than 2 classes")
    rare = str(counts.index[-1])
    if counts.iloc[-1] < MIN_ANOMALIES:
        raise NoLabels(f"fewer than {MIN_ANOMALIES} rows in the rarest class")
    is_rare = (target.astype(str) == rare).to_numpy()
    natural = float(is_rare.mean())
    info: dict[str, Any] = {
        "anomaly_class": rare,
        "classes": int(len(counts)),
        "natural_rate": natural,
        "kind": "native_rare",
    }
    keep = np.ones(len(target), dtype=bool)
    if natural > TARGET_RATE:
        n_normal = int(is_rare.sum())
        k = round(n_normal * TARGET_RATE / (1 - TARGET_RATE))
        chosen = np.random.default_rng(SEED).choice(np.flatnonzero(is_rare), k, replace=False)
        keep = ~is_rare
        keep[chosen] = True
        info["kind"] = "downsampled"
    labels = is_rare[keep].astype(int)
    info.update(rows=int(keep.sum()), anomalies=int(labels.sum()))
    return features[keep].reset_index(drop=True), labels, info


def x_derive_labels__mutmut_64(
    frame: pd.DataFrame, meta: dict[str, Any]
) -> tuple[pd.DataFrame, np.ndarray, dict[str, Any]]:
    if "Classification" not in (meta.get("tasks") or []):
        raise NoLabels("not a classification task")
    features, target = split_columns(frame, meta)
    known = target.notna().to_numpy()
    features, target = features[known].reset_index(drop=True), target[known].reset_index(drop=True)
    counts = target.astype(str).value_counts()
    if len(counts) < 2:
        raise NoLabels("fewer than 2 classes")
    rare = str(counts.index[-1])
    if counts.iloc[-1] < MIN_ANOMALIES:
        raise NoLabels(f"fewer than {MIN_ANOMALIES} rows in the rarest class")
    is_rare = (target.astype(str) == rare).to_numpy()
    natural = float(is_rare.mean())
    info: dict[str, Any] = {
        "anomaly_class": rare,
        "classes": int(len(counts)),
        "natural_rate": natural,
        "kind": "native_rare",
    }
    keep = np.ones(len(target), dtype=bool)
    if natural > TARGET_RATE:
        n_normal = int((~is_rare).sum())
        k = None
        chosen = np.random.default_rng(SEED).choice(np.flatnonzero(is_rare), k, replace=False)
        keep = ~is_rare
        keep[chosen] = True
        info["kind"] = "downsampled"
    labels = is_rare[keep].astype(int)
    info.update(rows=int(keep.sum()), anomalies=int(labels.sum()))
    return features[keep].reset_index(drop=True), labels, info


def x_derive_labels__mutmut_65(
    frame: pd.DataFrame, meta: dict[str, Any]
) -> tuple[pd.DataFrame, np.ndarray, dict[str, Any]]:
    if "Classification" not in (meta.get("tasks") or []):
        raise NoLabels("not a classification task")
    features, target = split_columns(frame, meta)
    known = target.notna().to_numpy()
    features, target = features[known].reset_index(drop=True), target[known].reset_index(drop=True)
    counts = target.astype(str).value_counts()
    if len(counts) < 2:
        raise NoLabels("fewer than 2 classes")
    rare = str(counts.index[-1])
    if counts.iloc[-1] < MIN_ANOMALIES:
        raise NoLabels(f"fewer than {MIN_ANOMALIES} rows in the rarest class")
    is_rare = (target.astype(str) == rare).to_numpy()
    natural = float(is_rare.mean())
    info: dict[str, Any] = {
        "anomaly_class": rare,
        "classes": int(len(counts)),
        "natural_rate": natural,
        "kind": "native_rare",
    }
    keep = np.ones(len(target), dtype=bool)
    if natural > TARGET_RATE:
        n_normal = int((~is_rare).sum())
        k = round(None)
        chosen = np.random.default_rng(SEED).choice(np.flatnonzero(is_rare), k, replace=False)
        keep = ~is_rare
        keep[chosen] = True
        info["kind"] = "downsampled"
    labels = is_rare[keep].astype(int)
    info.update(rows=int(keep.sum()), anomalies=int(labels.sum()))
    return features[keep].reset_index(drop=True), labels, info


def x_derive_labels__mutmut_66(
    frame: pd.DataFrame, meta: dict[str, Any]
) -> tuple[pd.DataFrame, np.ndarray, dict[str, Any]]:
    if "Classification" not in (meta.get("tasks") or []):
        raise NoLabels("not a classification task")
    features, target = split_columns(frame, meta)
    known = target.notna().to_numpy()
    features, target = features[known].reset_index(drop=True), target[known].reset_index(drop=True)
    counts = target.astype(str).value_counts()
    if len(counts) < 2:
        raise NoLabels("fewer than 2 classes")
    rare = str(counts.index[-1])
    if counts.iloc[-1] < MIN_ANOMALIES:
        raise NoLabels(f"fewer than {MIN_ANOMALIES} rows in the rarest class")
    is_rare = (target.astype(str) == rare).to_numpy()
    natural = float(is_rare.mean())
    info: dict[str, Any] = {
        "anomaly_class": rare,
        "classes": int(len(counts)),
        "natural_rate": natural,
        "kind": "native_rare",
    }
    keep = np.ones(len(target), dtype=bool)
    if natural > TARGET_RATE:
        n_normal = int((~is_rare).sum())
        k = round(n_normal * TARGET_RATE * (1 - TARGET_RATE))
        chosen = np.random.default_rng(SEED).choice(np.flatnonzero(is_rare), k, replace=False)
        keep = ~is_rare
        keep[chosen] = True
        info["kind"] = "downsampled"
    labels = is_rare[keep].astype(int)
    info.update(rows=int(keep.sum()), anomalies=int(labels.sum()))
    return features[keep].reset_index(drop=True), labels, info


def x_derive_labels__mutmut_67(
    frame: pd.DataFrame, meta: dict[str, Any]
) -> tuple[pd.DataFrame, np.ndarray, dict[str, Any]]:
    if "Classification" not in (meta.get("tasks") or []):
        raise NoLabels("not a classification task")
    features, target = split_columns(frame, meta)
    known = target.notna().to_numpy()
    features, target = features[known].reset_index(drop=True), target[known].reset_index(drop=True)
    counts = target.astype(str).value_counts()
    if len(counts) < 2:
        raise NoLabels("fewer than 2 classes")
    rare = str(counts.index[-1])
    if counts.iloc[-1] < MIN_ANOMALIES:
        raise NoLabels(f"fewer than {MIN_ANOMALIES} rows in the rarest class")
    is_rare = (target.astype(str) == rare).to_numpy()
    natural = float(is_rare.mean())
    info: dict[str, Any] = {
        "anomaly_class": rare,
        "classes": int(len(counts)),
        "natural_rate": natural,
        "kind": "native_rare",
    }
    keep = np.ones(len(target), dtype=bool)
    if natural > TARGET_RATE:
        n_normal = int((~is_rare).sum())
        k = round(n_normal / TARGET_RATE / (1 - TARGET_RATE))
        chosen = np.random.default_rng(SEED).choice(np.flatnonzero(is_rare), k, replace=False)
        keep = ~is_rare
        keep[chosen] = True
        info["kind"] = "downsampled"
    labels = is_rare[keep].astype(int)
    info.update(rows=int(keep.sum()), anomalies=int(labels.sum()))
    return features[keep].reset_index(drop=True), labels, info


def x_derive_labels__mutmut_68(
    frame: pd.DataFrame, meta: dict[str, Any]
) -> tuple[pd.DataFrame, np.ndarray, dict[str, Any]]:
    if "Classification" not in (meta.get("tasks") or []):
        raise NoLabels("not a classification task")
    features, target = split_columns(frame, meta)
    known = target.notna().to_numpy()
    features, target = features[known].reset_index(drop=True), target[known].reset_index(drop=True)
    counts = target.astype(str).value_counts()
    if len(counts) < 2:
        raise NoLabels("fewer than 2 classes")
    rare = str(counts.index[-1])
    if counts.iloc[-1] < MIN_ANOMALIES:
        raise NoLabels(f"fewer than {MIN_ANOMALIES} rows in the rarest class")
    is_rare = (target.astype(str) == rare).to_numpy()
    natural = float(is_rare.mean())
    info: dict[str, Any] = {
        "anomaly_class": rare,
        "classes": int(len(counts)),
        "natural_rate": natural,
        "kind": "native_rare",
    }
    keep = np.ones(len(target), dtype=bool)
    if natural > TARGET_RATE:
        n_normal = int((~is_rare).sum())
        k = round(n_normal * TARGET_RATE / (1 + TARGET_RATE))
        chosen = np.random.default_rng(SEED).choice(np.flatnonzero(is_rare), k, replace=False)
        keep = ~is_rare
        keep[chosen] = True
        info["kind"] = "downsampled"
    labels = is_rare[keep].astype(int)
    info.update(rows=int(keep.sum()), anomalies=int(labels.sum()))
    return features[keep].reset_index(drop=True), labels, info


def x_derive_labels__mutmut_69(
    frame: pd.DataFrame, meta: dict[str, Any]
) -> tuple[pd.DataFrame, np.ndarray, dict[str, Any]]:
    if "Classification" not in (meta.get("tasks") or []):
        raise NoLabels("not a classification task")
    features, target = split_columns(frame, meta)
    known = target.notna().to_numpy()
    features, target = features[known].reset_index(drop=True), target[known].reset_index(drop=True)
    counts = target.astype(str).value_counts()
    if len(counts) < 2:
        raise NoLabels("fewer than 2 classes")
    rare = str(counts.index[-1])
    if counts.iloc[-1] < MIN_ANOMALIES:
        raise NoLabels(f"fewer than {MIN_ANOMALIES} rows in the rarest class")
    is_rare = (target.astype(str) == rare).to_numpy()
    natural = float(is_rare.mean())
    info: dict[str, Any] = {
        "anomaly_class": rare,
        "classes": int(len(counts)),
        "natural_rate": natural,
        "kind": "native_rare",
    }
    keep = np.ones(len(target), dtype=bool)
    if natural > TARGET_RATE:
        n_normal = int((~is_rare).sum())
        k = round(n_normal * TARGET_RATE / (2 - TARGET_RATE))
        chosen = np.random.default_rng(SEED).choice(np.flatnonzero(is_rare), k, replace=False)
        keep = ~is_rare
        keep[chosen] = True
        info["kind"] = "downsampled"
    labels = is_rare[keep].astype(int)
    info.update(rows=int(keep.sum()), anomalies=int(labels.sum()))
    return features[keep].reset_index(drop=True), labels, info


def x_derive_labels__mutmut_70(
    frame: pd.DataFrame, meta: dict[str, Any]
) -> tuple[pd.DataFrame, np.ndarray, dict[str, Any]]:
    if "Classification" not in (meta.get("tasks") or []):
        raise NoLabels("not a classification task")
    features, target = split_columns(frame, meta)
    known = target.notna().to_numpy()
    features, target = features[known].reset_index(drop=True), target[known].reset_index(drop=True)
    counts = target.astype(str).value_counts()
    if len(counts) < 2:
        raise NoLabels("fewer than 2 classes")
    rare = str(counts.index[-1])
    if counts.iloc[-1] < MIN_ANOMALIES:
        raise NoLabels(f"fewer than {MIN_ANOMALIES} rows in the rarest class")
    is_rare = (target.astype(str) == rare).to_numpy()
    natural = float(is_rare.mean())
    info: dict[str, Any] = {
        "anomaly_class": rare,
        "classes": int(len(counts)),
        "natural_rate": natural,
        "kind": "native_rare",
    }
    keep = np.ones(len(target), dtype=bool)
    if natural > TARGET_RATE:
        n_normal = int((~is_rare).sum())
        k = round(n_normal * TARGET_RATE / (1 - TARGET_RATE))
        chosen = None
        keep = ~is_rare
        keep[chosen] = True
        info["kind"] = "downsampled"
    labels = is_rare[keep].astype(int)
    info.update(rows=int(keep.sum()), anomalies=int(labels.sum()))
    return features[keep].reset_index(drop=True), labels, info


def x_derive_labels__mutmut_71(
    frame: pd.DataFrame, meta: dict[str, Any]
) -> tuple[pd.DataFrame, np.ndarray, dict[str, Any]]:
    if "Classification" not in (meta.get("tasks") or []):
        raise NoLabels("not a classification task")
    features, target = split_columns(frame, meta)
    known = target.notna().to_numpy()
    features, target = features[known].reset_index(drop=True), target[known].reset_index(drop=True)
    counts = target.astype(str).value_counts()
    if len(counts) < 2:
        raise NoLabels("fewer than 2 classes")
    rare = str(counts.index[-1])
    if counts.iloc[-1] < MIN_ANOMALIES:
        raise NoLabels(f"fewer than {MIN_ANOMALIES} rows in the rarest class")
    is_rare = (target.astype(str) == rare).to_numpy()
    natural = float(is_rare.mean())
    info: dict[str, Any] = {
        "anomaly_class": rare,
        "classes": int(len(counts)),
        "natural_rate": natural,
        "kind": "native_rare",
    }
    keep = np.ones(len(target), dtype=bool)
    if natural > TARGET_RATE:
        n_normal = int((~is_rare).sum())
        k = round(n_normal * TARGET_RATE / (1 - TARGET_RATE))
        chosen = np.random.default_rng(SEED).choice(None, k, replace=False)
        keep = ~is_rare
        keep[chosen] = True
        info["kind"] = "downsampled"
    labels = is_rare[keep].astype(int)
    info.update(rows=int(keep.sum()), anomalies=int(labels.sum()))
    return features[keep].reset_index(drop=True), labels, info


def x_derive_labels__mutmut_72(
    frame: pd.DataFrame, meta: dict[str, Any]
) -> tuple[pd.DataFrame, np.ndarray, dict[str, Any]]:
    if "Classification" not in (meta.get("tasks") or []):
        raise NoLabels("not a classification task")
    features, target = split_columns(frame, meta)
    known = target.notna().to_numpy()
    features, target = features[known].reset_index(drop=True), target[known].reset_index(drop=True)
    counts = target.astype(str).value_counts()
    if len(counts) < 2:
        raise NoLabels("fewer than 2 classes")
    rare = str(counts.index[-1])
    if counts.iloc[-1] < MIN_ANOMALIES:
        raise NoLabels(f"fewer than {MIN_ANOMALIES} rows in the rarest class")
    is_rare = (target.astype(str) == rare).to_numpy()
    natural = float(is_rare.mean())
    info: dict[str, Any] = {
        "anomaly_class": rare,
        "classes": int(len(counts)),
        "natural_rate": natural,
        "kind": "native_rare",
    }
    keep = np.ones(len(target), dtype=bool)
    if natural > TARGET_RATE:
        n_normal = int((~is_rare).sum())
        k = round(n_normal * TARGET_RATE / (1 - TARGET_RATE))
        chosen = np.random.default_rng(SEED).choice(np.flatnonzero(is_rare), None, replace=False)
        keep = ~is_rare
        keep[chosen] = True
        info["kind"] = "downsampled"
    labels = is_rare[keep].astype(int)
    info.update(rows=int(keep.sum()), anomalies=int(labels.sum()))
    return features[keep].reset_index(drop=True), labels, info


def x_derive_labels__mutmut_73(
    frame: pd.DataFrame, meta: dict[str, Any]
) -> tuple[pd.DataFrame, np.ndarray, dict[str, Any]]:
    if "Classification" not in (meta.get("tasks") or []):
        raise NoLabels("not a classification task")
    features, target = split_columns(frame, meta)
    known = target.notna().to_numpy()
    features, target = features[known].reset_index(drop=True), target[known].reset_index(drop=True)
    counts = target.astype(str).value_counts()
    if len(counts) < 2:
        raise NoLabels("fewer than 2 classes")
    rare = str(counts.index[-1])
    if counts.iloc[-1] < MIN_ANOMALIES:
        raise NoLabels(f"fewer than {MIN_ANOMALIES} rows in the rarest class")
    is_rare = (target.astype(str) == rare).to_numpy()
    natural = float(is_rare.mean())
    info: dict[str, Any] = {
        "anomaly_class": rare,
        "classes": int(len(counts)),
        "natural_rate": natural,
        "kind": "native_rare",
    }
    keep = np.ones(len(target), dtype=bool)
    if natural > TARGET_RATE:
        n_normal = int((~is_rare).sum())
        k = round(n_normal * TARGET_RATE / (1 - TARGET_RATE))
        chosen = np.random.default_rng(SEED).choice(np.flatnonzero(is_rare), k, replace=None)
        keep = ~is_rare
        keep[chosen] = True
        info["kind"] = "downsampled"
    labels = is_rare[keep].astype(int)
    info.update(rows=int(keep.sum()), anomalies=int(labels.sum()))
    return features[keep].reset_index(drop=True), labels, info


def x_derive_labels__mutmut_74(
    frame: pd.DataFrame, meta: dict[str, Any]
) -> tuple[pd.DataFrame, np.ndarray, dict[str, Any]]:
    if "Classification" not in (meta.get("tasks") or []):
        raise NoLabels("not a classification task")
    features, target = split_columns(frame, meta)
    known = target.notna().to_numpy()
    features, target = features[known].reset_index(drop=True), target[known].reset_index(drop=True)
    counts = target.astype(str).value_counts()
    if len(counts) < 2:
        raise NoLabels("fewer than 2 classes")
    rare = str(counts.index[-1])
    if counts.iloc[-1] < MIN_ANOMALIES:
        raise NoLabels(f"fewer than {MIN_ANOMALIES} rows in the rarest class")
    is_rare = (target.astype(str) == rare).to_numpy()
    natural = float(is_rare.mean())
    info: dict[str, Any] = {
        "anomaly_class": rare,
        "classes": int(len(counts)),
        "natural_rate": natural,
        "kind": "native_rare",
    }
    keep = np.ones(len(target), dtype=bool)
    if natural > TARGET_RATE:
        n_normal = int((~is_rare).sum())
        k = round(n_normal * TARGET_RATE / (1 - TARGET_RATE))
        chosen = np.random.default_rng(SEED).choice(k, replace=False)
        keep = ~is_rare
        keep[chosen] = True
        info["kind"] = "downsampled"
    labels = is_rare[keep].astype(int)
    info.update(rows=int(keep.sum()), anomalies=int(labels.sum()))
    return features[keep].reset_index(drop=True), labels, info


def x_derive_labels__mutmut_75(
    frame: pd.DataFrame, meta: dict[str, Any]
) -> tuple[pd.DataFrame, np.ndarray, dict[str, Any]]:
    if "Classification" not in (meta.get("tasks") or []):
        raise NoLabels("not a classification task")
    features, target = split_columns(frame, meta)
    known = target.notna().to_numpy()
    features, target = features[known].reset_index(drop=True), target[known].reset_index(drop=True)
    counts = target.astype(str).value_counts()
    if len(counts) < 2:
        raise NoLabels("fewer than 2 classes")
    rare = str(counts.index[-1])
    if counts.iloc[-1] < MIN_ANOMALIES:
        raise NoLabels(f"fewer than {MIN_ANOMALIES} rows in the rarest class")
    is_rare = (target.astype(str) == rare).to_numpy()
    natural = float(is_rare.mean())
    info: dict[str, Any] = {
        "anomaly_class": rare,
        "classes": int(len(counts)),
        "natural_rate": natural,
        "kind": "native_rare",
    }
    keep = np.ones(len(target), dtype=bool)
    if natural > TARGET_RATE:
        n_normal = int((~is_rare).sum())
        k = round(n_normal * TARGET_RATE / (1 - TARGET_RATE))
        chosen = np.random.default_rng(SEED).choice(np.flatnonzero(is_rare), replace=False)
        keep = ~is_rare
        keep[chosen] = True
        info["kind"] = "downsampled"
    labels = is_rare[keep].astype(int)
    info.update(rows=int(keep.sum()), anomalies=int(labels.sum()))
    return features[keep].reset_index(drop=True), labels, info


def x_derive_labels__mutmut_76(
    frame: pd.DataFrame, meta: dict[str, Any]
) -> tuple[pd.DataFrame, np.ndarray, dict[str, Any]]:
    if "Classification" not in (meta.get("tasks") or []):
        raise NoLabels("not a classification task")
    features, target = split_columns(frame, meta)
    known = target.notna().to_numpy()
    features, target = features[known].reset_index(drop=True), target[known].reset_index(drop=True)
    counts = target.astype(str).value_counts()
    if len(counts) < 2:
        raise NoLabels("fewer than 2 classes")
    rare = str(counts.index[-1])
    if counts.iloc[-1] < MIN_ANOMALIES:
        raise NoLabels(f"fewer than {MIN_ANOMALIES} rows in the rarest class")
    is_rare = (target.astype(str) == rare).to_numpy()
    natural = float(is_rare.mean())
    info: dict[str, Any] = {
        "anomaly_class": rare,
        "classes": int(len(counts)),
        "natural_rate": natural,
        "kind": "native_rare",
    }
    keep = np.ones(len(target), dtype=bool)
    if natural > TARGET_RATE:
        n_normal = int((~is_rare).sum())
        k = round(n_normal * TARGET_RATE / (1 - TARGET_RATE))
        chosen = np.random.default_rng(SEED).choice(np.flatnonzero(is_rare), k, )
        keep = ~is_rare
        keep[chosen] = True
        info["kind"] = "downsampled"
    labels = is_rare[keep].astype(int)
    info.update(rows=int(keep.sum()), anomalies=int(labels.sum()))
    return features[keep].reset_index(drop=True), labels, info


def x_derive_labels__mutmut_77(
    frame: pd.DataFrame, meta: dict[str, Any]
) -> tuple[pd.DataFrame, np.ndarray, dict[str, Any]]:
    if "Classification" not in (meta.get("tasks") or []):
        raise NoLabels("not a classification task")
    features, target = split_columns(frame, meta)
    known = target.notna().to_numpy()
    features, target = features[known].reset_index(drop=True), target[known].reset_index(drop=True)
    counts = target.astype(str).value_counts()
    if len(counts) < 2:
        raise NoLabels("fewer than 2 classes")
    rare = str(counts.index[-1])
    if counts.iloc[-1] < MIN_ANOMALIES:
        raise NoLabels(f"fewer than {MIN_ANOMALIES} rows in the rarest class")
    is_rare = (target.astype(str) == rare).to_numpy()
    natural = float(is_rare.mean())
    info: dict[str, Any] = {
        "anomaly_class": rare,
        "classes": int(len(counts)),
        "natural_rate": natural,
        "kind": "native_rare",
    }
    keep = np.ones(len(target), dtype=bool)
    if natural > TARGET_RATE:
        n_normal = int((~is_rare).sum())
        k = round(n_normal * TARGET_RATE / (1 - TARGET_RATE))
        chosen = np.random.default_rng(None).choice(np.flatnonzero(is_rare), k, replace=False)
        keep = ~is_rare
        keep[chosen] = True
        info["kind"] = "downsampled"
    labels = is_rare[keep].astype(int)
    info.update(rows=int(keep.sum()), anomalies=int(labels.sum()))
    return features[keep].reset_index(drop=True), labels, info


def x_derive_labels__mutmut_78(
    frame: pd.DataFrame, meta: dict[str, Any]
) -> tuple[pd.DataFrame, np.ndarray, dict[str, Any]]:
    if "Classification" not in (meta.get("tasks") or []):
        raise NoLabels("not a classification task")
    features, target = split_columns(frame, meta)
    known = target.notna().to_numpy()
    features, target = features[known].reset_index(drop=True), target[known].reset_index(drop=True)
    counts = target.astype(str).value_counts()
    if len(counts) < 2:
        raise NoLabels("fewer than 2 classes")
    rare = str(counts.index[-1])
    if counts.iloc[-1] < MIN_ANOMALIES:
        raise NoLabels(f"fewer than {MIN_ANOMALIES} rows in the rarest class")
    is_rare = (target.astype(str) == rare).to_numpy()
    natural = float(is_rare.mean())
    info: dict[str, Any] = {
        "anomaly_class": rare,
        "classes": int(len(counts)),
        "natural_rate": natural,
        "kind": "native_rare",
    }
    keep = np.ones(len(target), dtype=bool)
    if natural > TARGET_RATE:
        n_normal = int((~is_rare).sum())
        k = round(n_normal * TARGET_RATE / (1 - TARGET_RATE))
        chosen = np.random.default_rng(SEED).choice(np.flatnonzero(None), k, replace=False)
        keep = ~is_rare
        keep[chosen] = True
        info["kind"] = "downsampled"
    labels = is_rare[keep].astype(int)
    info.update(rows=int(keep.sum()), anomalies=int(labels.sum()))
    return features[keep].reset_index(drop=True), labels, info


def x_derive_labels__mutmut_79(
    frame: pd.DataFrame, meta: dict[str, Any]
) -> tuple[pd.DataFrame, np.ndarray, dict[str, Any]]:
    if "Classification" not in (meta.get("tasks") or []):
        raise NoLabels("not a classification task")
    features, target = split_columns(frame, meta)
    known = target.notna().to_numpy()
    features, target = features[known].reset_index(drop=True), target[known].reset_index(drop=True)
    counts = target.astype(str).value_counts()
    if len(counts) < 2:
        raise NoLabels("fewer than 2 classes")
    rare = str(counts.index[-1])
    if counts.iloc[-1] < MIN_ANOMALIES:
        raise NoLabels(f"fewer than {MIN_ANOMALIES} rows in the rarest class")
    is_rare = (target.astype(str) == rare).to_numpy()
    natural = float(is_rare.mean())
    info: dict[str, Any] = {
        "anomaly_class": rare,
        "classes": int(len(counts)),
        "natural_rate": natural,
        "kind": "native_rare",
    }
    keep = np.ones(len(target), dtype=bool)
    if natural > TARGET_RATE:
        n_normal = int((~is_rare).sum())
        k = round(n_normal * TARGET_RATE / (1 - TARGET_RATE))
        chosen = np.random.default_rng(SEED).choice(np.flatnonzero(is_rare), k, replace=True)
        keep = ~is_rare
        keep[chosen] = True
        info["kind"] = "downsampled"
    labels = is_rare[keep].astype(int)
    info.update(rows=int(keep.sum()), anomalies=int(labels.sum()))
    return features[keep].reset_index(drop=True), labels, info


def x_derive_labels__mutmut_80(
    frame: pd.DataFrame, meta: dict[str, Any]
) -> tuple[pd.DataFrame, np.ndarray, dict[str, Any]]:
    if "Classification" not in (meta.get("tasks") or []):
        raise NoLabels("not a classification task")
    features, target = split_columns(frame, meta)
    known = target.notna().to_numpy()
    features, target = features[known].reset_index(drop=True), target[known].reset_index(drop=True)
    counts = target.astype(str).value_counts()
    if len(counts) < 2:
        raise NoLabels("fewer than 2 classes")
    rare = str(counts.index[-1])
    if counts.iloc[-1] < MIN_ANOMALIES:
        raise NoLabels(f"fewer than {MIN_ANOMALIES} rows in the rarest class")
    is_rare = (target.astype(str) == rare).to_numpy()
    natural = float(is_rare.mean())
    info: dict[str, Any] = {
        "anomaly_class": rare,
        "classes": int(len(counts)),
        "natural_rate": natural,
        "kind": "native_rare",
    }
    keep = np.ones(len(target), dtype=bool)
    if natural > TARGET_RATE:
        n_normal = int((~is_rare).sum())
        k = round(n_normal * TARGET_RATE / (1 - TARGET_RATE))
        chosen = np.random.default_rng(SEED).choice(np.flatnonzero(is_rare), k, replace=False)
        keep = None
        keep[chosen] = True
        info["kind"] = "downsampled"
    labels = is_rare[keep].astype(int)
    info.update(rows=int(keep.sum()), anomalies=int(labels.sum()))
    return features[keep].reset_index(drop=True), labels, info


def x_derive_labels__mutmut_81(
    frame: pd.DataFrame, meta: dict[str, Any]
) -> tuple[pd.DataFrame, np.ndarray, dict[str, Any]]:
    if "Classification" not in (meta.get("tasks") or []):
        raise NoLabels("not a classification task")
    features, target = split_columns(frame, meta)
    known = target.notna().to_numpy()
    features, target = features[known].reset_index(drop=True), target[known].reset_index(drop=True)
    counts = target.astype(str).value_counts()
    if len(counts) < 2:
        raise NoLabels("fewer than 2 classes")
    rare = str(counts.index[-1])
    if counts.iloc[-1] < MIN_ANOMALIES:
        raise NoLabels(f"fewer than {MIN_ANOMALIES} rows in the rarest class")
    is_rare = (target.astype(str) == rare).to_numpy()
    natural = float(is_rare.mean())
    info: dict[str, Any] = {
        "anomaly_class": rare,
        "classes": int(len(counts)),
        "natural_rate": natural,
        "kind": "native_rare",
    }
    keep = np.ones(len(target), dtype=bool)
    if natural > TARGET_RATE:
        n_normal = int((~is_rare).sum())
        k = round(n_normal * TARGET_RATE / (1 - TARGET_RATE))
        chosen = np.random.default_rng(SEED).choice(np.flatnonzero(is_rare), k, replace=False)
        keep = is_rare
        keep[chosen] = True
        info["kind"] = "downsampled"
    labels = is_rare[keep].astype(int)
    info.update(rows=int(keep.sum()), anomalies=int(labels.sum()))
    return features[keep].reset_index(drop=True), labels, info


def x_derive_labels__mutmut_82(
    frame: pd.DataFrame, meta: dict[str, Any]
) -> tuple[pd.DataFrame, np.ndarray, dict[str, Any]]:
    if "Classification" not in (meta.get("tasks") or []):
        raise NoLabels("not a classification task")
    features, target = split_columns(frame, meta)
    known = target.notna().to_numpy()
    features, target = features[known].reset_index(drop=True), target[known].reset_index(drop=True)
    counts = target.astype(str).value_counts()
    if len(counts) < 2:
        raise NoLabels("fewer than 2 classes")
    rare = str(counts.index[-1])
    if counts.iloc[-1] < MIN_ANOMALIES:
        raise NoLabels(f"fewer than {MIN_ANOMALIES} rows in the rarest class")
    is_rare = (target.astype(str) == rare).to_numpy()
    natural = float(is_rare.mean())
    info: dict[str, Any] = {
        "anomaly_class": rare,
        "classes": int(len(counts)),
        "natural_rate": natural,
        "kind": "native_rare",
    }
    keep = np.ones(len(target), dtype=bool)
    if natural > TARGET_RATE:
        n_normal = int((~is_rare).sum())
        k = round(n_normal * TARGET_RATE / (1 - TARGET_RATE))
        chosen = np.random.default_rng(SEED).choice(np.flatnonzero(is_rare), k, replace=False)
        keep = ~is_rare
        keep[chosen] = None
        info["kind"] = "downsampled"
    labels = is_rare[keep].astype(int)
    info.update(rows=int(keep.sum()), anomalies=int(labels.sum()))
    return features[keep].reset_index(drop=True), labels, info


def x_derive_labels__mutmut_83(
    frame: pd.DataFrame, meta: dict[str, Any]
) -> tuple[pd.DataFrame, np.ndarray, dict[str, Any]]:
    if "Classification" not in (meta.get("tasks") or []):
        raise NoLabels("not a classification task")
    features, target = split_columns(frame, meta)
    known = target.notna().to_numpy()
    features, target = features[known].reset_index(drop=True), target[known].reset_index(drop=True)
    counts = target.astype(str).value_counts()
    if len(counts) < 2:
        raise NoLabels("fewer than 2 classes")
    rare = str(counts.index[-1])
    if counts.iloc[-1] < MIN_ANOMALIES:
        raise NoLabels(f"fewer than {MIN_ANOMALIES} rows in the rarest class")
    is_rare = (target.astype(str) == rare).to_numpy()
    natural = float(is_rare.mean())
    info: dict[str, Any] = {
        "anomaly_class": rare,
        "classes": int(len(counts)),
        "natural_rate": natural,
        "kind": "native_rare",
    }
    keep = np.ones(len(target), dtype=bool)
    if natural > TARGET_RATE:
        n_normal = int((~is_rare).sum())
        k = round(n_normal * TARGET_RATE / (1 - TARGET_RATE))
        chosen = np.random.default_rng(SEED).choice(np.flatnonzero(is_rare), k, replace=False)
        keep = ~is_rare
        keep[chosen] = False
        info["kind"] = "downsampled"
    labels = is_rare[keep].astype(int)
    info.update(rows=int(keep.sum()), anomalies=int(labels.sum()))
    return features[keep].reset_index(drop=True), labels, info


def x_derive_labels__mutmut_84(
    frame: pd.DataFrame, meta: dict[str, Any]
) -> tuple[pd.DataFrame, np.ndarray, dict[str, Any]]:
    if "Classification" not in (meta.get("tasks") or []):
        raise NoLabels("not a classification task")
    features, target = split_columns(frame, meta)
    known = target.notna().to_numpy()
    features, target = features[known].reset_index(drop=True), target[known].reset_index(drop=True)
    counts = target.astype(str).value_counts()
    if len(counts) < 2:
        raise NoLabels("fewer than 2 classes")
    rare = str(counts.index[-1])
    if counts.iloc[-1] < MIN_ANOMALIES:
        raise NoLabels(f"fewer than {MIN_ANOMALIES} rows in the rarest class")
    is_rare = (target.astype(str) == rare).to_numpy()
    natural = float(is_rare.mean())
    info: dict[str, Any] = {
        "anomaly_class": rare,
        "classes": int(len(counts)),
        "natural_rate": natural,
        "kind": "native_rare",
    }
    keep = np.ones(len(target), dtype=bool)
    if natural > TARGET_RATE:
        n_normal = int((~is_rare).sum())
        k = round(n_normal * TARGET_RATE / (1 - TARGET_RATE))
        chosen = np.random.default_rng(SEED).choice(np.flatnonzero(is_rare), k, replace=False)
        keep = ~is_rare
        keep[chosen] = True
        info["kind"] = None
    labels = is_rare[keep].astype(int)
    info.update(rows=int(keep.sum()), anomalies=int(labels.sum()))
    return features[keep].reset_index(drop=True), labels, info


def x_derive_labels__mutmut_85(
    frame: pd.DataFrame, meta: dict[str, Any]
) -> tuple[pd.DataFrame, np.ndarray, dict[str, Any]]:
    if "Classification" not in (meta.get("tasks") or []):
        raise NoLabels("not a classification task")
    features, target = split_columns(frame, meta)
    known = target.notna().to_numpy()
    features, target = features[known].reset_index(drop=True), target[known].reset_index(drop=True)
    counts = target.astype(str).value_counts()
    if len(counts) < 2:
        raise NoLabels("fewer than 2 classes")
    rare = str(counts.index[-1])
    if counts.iloc[-1] < MIN_ANOMALIES:
        raise NoLabels(f"fewer than {MIN_ANOMALIES} rows in the rarest class")
    is_rare = (target.astype(str) == rare).to_numpy()
    natural = float(is_rare.mean())
    info: dict[str, Any] = {
        "anomaly_class": rare,
        "classes": int(len(counts)),
        "natural_rate": natural,
        "kind": "native_rare",
    }
    keep = np.ones(len(target), dtype=bool)
    if natural > TARGET_RATE:
        n_normal = int((~is_rare).sum())
        k = round(n_normal * TARGET_RATE / (1 - TARGET_RATE))
        chosen = np.random.default_rng(SEED).choice(np.flatnonzero(is_rare), k, replace=False)
        keep = ~is_rare
        keep[chosen] = True
        info["XXkindXX"] = "downsampled"
    labels = is_rare[keep].astype(int)
    info.update(rows=int(keep.sum()), anomalies=int(labels.sum()))
    return features[keep].reset_index(drop=True), labels, info


def x_derive_labels__mutmut_86(
    frame: pd.DataFrame, meta: dict[str, Any]
) -> tuple[pd.DataFrame, np.ndarray, dict[str, Any]]:
    if "Classification" not in (meta.get("tasks") or []):
        raise NoLabels("not a classification task")
    features, target = split_columns(frame, meta)
    known = target.notna().to_numpy()
    features, target = features[known].reset_index(drop=True), target[known].reset_index(drop=True)
    counts = target.astype(str).value_counts()
    if len(counts) < 2:
        raise NoLabels("fewer than 2 classes")
    rare = str(counts.index[-1])
    if counts.iloc[-1] < MIN_ANOMALIES:
        raise NoLabels(f"fewer than {MIN_ANOMALIES} rows in the rarest class")
    is_rare = (target.astype(str) == rare).to_numpy()
    natural = float(is_rare.mean())
    info: dict[str, Any] = {
        "anomaly_class": rare,
        "classes": int(len(counts)),
        "natural_rate": natural,
        "kind": "native_rare",
    }
    keep = np.ones(len(target), dtype=bool)
    if natural > TARGET_RATE:
        n_normal = int((~is_rare).sum())
        k = round(n_normal * TARGET_RATE / (1 - TARGET_RATE))
        chosen = np.random.default_rng(SEED).choice(np.flatnonzero(is_rare), k, replace=False)
        keep = ~is_rare
        keep[chosen] = True
        info["KIND"] = "downsampled"
    labels = is_rare[keep].astype(int)
    info.update(rows=int(keep.sum()), anomalies=int(labels.sum()))
    return features[keep].reset_index(drop=True), labels, info


def x_derive_labels__mutmut_87(
    frame: pd.DataFrame, meta: dict[str, Any]
) -> tuple[pd.DataFrame, np.ndarray, dict[str, Any]]:
    if "Classification" not in (meta.get("tasks") or []):
        raise NoLabels("not a classification task")
    features, target = split_columns(frame, meta)
    known = target.notna().to_numpy()
    features, target = features[known].reset_index(drop=True), target[known].reset_index(drop=True)
    counts = target.astype(str).value_counts()
    if len(counts) < 2:
        raise NoLabels("fewer than 2 classes")
    rare = str(counts.index[-1])
    if counts.iloc[-1] < MIN_ANOMALIES:
        raise NoLabels(f"fewer than {MIN_ANOMALIES} rows in the rarest class")
    is_rare = (target.astype(str) == rare).to_numpy()
    natural = float(is_rare.mean())
    info: dict[str, Any] = {
        "anomaly_class": rare,
        "classes": int(len(counts)),
        "natural_rate": natural,
        "kind": "native_rare",
    }
    keep = np.ones(len(target), dtype=bool)
    if natural > TARGET_RATE:
        n_normal = int((~is_rare).sum())
        k = round(n_normal * TARGET_RATE / (1 - TARGET_RATE))
        chosen = np.random.default_rng(SEED).choice(np.flatnonzero(is_rare), k, replace=False)
        keep = ~is_rare
        keep[chosen] = True
        info["kind"] = "XXdownsampledXX"
    labels = is_rare[keep].astype(int)
    info.update(rows=int(keep.sum()), anomalies=int(labels.sum()))
    return features[keep].reset_index(drop=True), labels, info


def x_derive_labels__mutmut_88(
    frame: pd.DataFrame, meta: dict[str, Any]
) -> tuple[pd.DataFrame, np.ndarray, dict[str, Any]]:
    if "Classification" not in (meta.get("tasks") or []):
        raise NoLabels("not a classification task")
    features, target = split_columns(frame, meta)
    known = target.notna().to_numpy()
    features, target = features[known].reset_index(drop=True), target[known].reset_index(drop=True)
    counts = target.astype(str).value_counts()
    if len(counts) < 2:
        raise NoLabels("fewer than 2 classes")
    rare = str(counts.index[-1])
    if counts.iloc[-1] < MIN_ANOMALIES:
        raise NoLabels(f"fewer than {MIN_ANOMALIES} rows in the rarest class")
    is_rare = (target.astype(str) == rare).to_numpy()
    natural = float(is_rare.mean())
    info: dict[str, Any] = {
        "anomaly_class": rare,
        "classes": int(len(counts)),
        "natural_rate": natural,
        "kind": "native_rare",
    }
    keep = np.ones(len(target), dtype=bool)
    if natural > TARGET_RATE:
        n_normal = int((~is_rare).sum())
        k = round(n_normal * TARGET_RATE / (1 - TARGET_RATE))
        chosen = np.random.default_rng(SEED).choice(np.flatnonzero(is_rare), k, replace=False)
        keep = ~is_rare
        keep[chosen] = True
        info["kind"] = "DOWNSAMPLED"
    labels = is_rare[keep].astype(int)
    info.update(rows=int(keep.sum()), anomalies=int(labels.sum()))
    return features[keep].reset_index(drop=True), labels, info


def x_derive_labels__mutmut_89(
    frame: pd.DataFrame, meta: dict[str, Any]
) -> tuple[pd.DataFrame, np.ndarray, dict[str, Any]]:
    if "Classification" not in (meta.get("tasks") or []):
        raise NoLabels("not a classification task")
    features, target = split_columns(frame, meta)
    known = target.notna().to_numpy()
    features, target = features[known].reset_index(drop=True), target[known].reset_index(drop=True)
    counts = target.astype(str).value_counts()
    if len(counts) < 2:
        raise NoLabels("fewer than 2 classes")
    rare = str(counts.index[-1])
    if counts.iloc[-1] < MIN_ANOMALIES:
        raise NoLabels(f"fewer than {MIN_ANOMALIES} rows in the rarest class")
    is_rare = (target.astype(str) == rare).to_numpy()
    natural = float(is_rare.mean())
    info: dict[str, Any] = {
        "anomaly_class": rare,
        "classes": int(len(counts)),
        "natural_rate": natural,
        "kind": "native_rare",
    }
    keep = np.ones(len(target), dtype=bool)
    if natural > TARGET_RATE:
        n_normal = int((~is_rare).sum())
        k = round(n_normal * TARGET_RATE / (1 - TARGET_RATE))
        chosen = np.random.default_rng(SEED).choice(np.flatnonzero(is_rare), k, replace=False)
        keep = ~is_rare
        keep[chosen] = True
        info["kind"] = "downsampled"
    labels = None
    info.update(rows=int(keep.sum()), anomalies=int(labels.sum()))
    return features[keep].reset_index(drop=True), labels, info


def x_derive_labels__mutmut_90(
    frame: pd.DataFrame, meta: dict[str, Any]
) -> tuple[pd.DataFrame, np.ndarray, dict[str, Any]]:
    if "Classification" not in (meta.get("tasks") or []):
        raise NoLabels("not a classification task")
    features, target = split_columns(frame, meta)
    known = target.notna().to_numpy()
    features, target = features[known].reset_index(drop=True), target[known].reset_index(drop=True)
    counts = target.astype(str).value_counts()
    if len(counts) < 2:
        raise NoLabels("fewer than 2 classes")
    rare = str(counts.index[-1])
    if counts.iloc[-1] < MIN_ANOMALIES:
        raise NoLabels(f"fewer than {MIN_ANOMALIES} rows in the rarest class")
    is_rare = (target.astype(str) == rare).to_numpy()
    natural = float(is_rare.mean())
    info: dict[str, Any] = {
        "anomaly_class": rare,
        "classes": int(len(counts)),
        "natural_rate": natural,
        "kind": "native_rare",
    }
    keep = np.ones(len(target), dtype=bool)
    if natural > TARGET_RATE:
        n_normal = int((~is_rare).sum())
        k = round(n_normal * TARGET_RATE / (1 - TARGET_RATE))
        chosen = np.random.default_rng(SEED).choice(np.flatnonzero(is_rare), k, replace=False)
        keep = ~is_rare
        keep[chosen] = True
        info["kind"] = "downsampled"
    labels = is_rare[keep].astype(None)
    info.update(rows=int(keep.sum()), anomalies=int(labels.sum()))
    return features[keep].reset_index(drop=True), labels, info


def x_derive_labels__mutmut_91(
    frame: pd.DataFrame, meta: dict[str, Any]
) -> tuple[pd.DataFrame, np.ndarray, dict[str, Any]]:
    if "Classification" not in (meta.get("tasks") or []):
        raise NoLabels("not a classification task")
    features, target = split_columns(frame, meta)
    known = target.notna().to_numpy()
    features, target = features[known].reset_index(drop=True), target[known].reset_index(drop=True)
    counts = target.astype(str).value_counts()
    if len(counts) < 2:
        raise NoLabels("fewer than 2 classes")
    rare = str(counts.index[-1])
    if counts.iloc[-1] < MIN_ANOMALIES:
        raise NoLabels(f"fewer than {MIN_ANOMALIES} rows in the rarest class")
    is_rare = (target.astype(str) == rare).to_numpy()
    natural = float(is_rare.mean())
    info: dict[str, Any] = {
        "anomaly_class": rare,
        "classes": int(len(counts)),
        "natural_rate": natural,
        "kind": "native_rare",
    }
    keep = np.ones(len(target), dtype=bool)
    if natural > TARGET_RATE:
        n_normal = int((~is_rare).sum())
        k = round(n_normal * TARGET_RATE / (1 - TARGET_RATE))
        chosen = np.random.default_rng(SEED).choice(np.flatnonzero(is_rare), k, replace=False)
        keep = ~is_rare
        keep[chosen] = True
        info["kind"] = "downsampled"
    labels = is_rare[keep].astype(int)
    info.update(rows=None, anomalies=int(labels.sum()))
    return features[keep].reset_index(drop=True), labels, info


def x_derive_labels__mutmut_92(
    frame: pd.DataFrame, meta: dict[str, Any]
) -> tuple[pd.DataFrame, np.ndarray, dict[str, Any]]:
    if "Classification" not in (meta.get("tasks") or []):
        raise NoLabels("not a classification task")
    features, target = split_columns(frame, meta)
    known = target.notna().to_numpy()
    features, target = features[known].reset_index(drop=True), target[known].reset_index(drop=True)
    counts = target.astype(str).value_counts()
    if len(counts) < 2:
        raise NoLabels("fewer than 2 classes")
    rare = str(counts.index[-1])
    if counts.iloc[-1] < MIN_ANOMALIES:
        raise NoLabels(f"fewer than {MIN_ANOMALIES} rows in the rarest class")
    is_rare = (target.astype(str) == rare).to_numpy()
    natural = float(is_rare.mean())
    info: dict[str, Any] = {
        "anomaly_class": rare,
        "classes": int(len(counts)),
        "natural_rate": natural,
        "kind": "native_rare",
    }
    keep = np.ones(len(target), dtype=bool)
    if natural > TARGET_RATE:
        n_normal = int((~is_rare).sum())
        k = round(n_normal * TARGET_RATE / (1 - TARGET_RATE))
        chosen = np.random.default_rng(SEED).choice(np.flatnonzero(is_rare), k, replace=False)
        keep = ~is_rare
        keep[chosen] = True
        info["kind"] = "downsampled"
    labels = is_rare[keep].astype(int)
    info.update(rows=int(keep.sum()), anomalies=None)
    return features[keep].reset_index(drop=True), labels, info


def x_derive_labels__mutmut_93(
    frame: pd.DataFrame, meta: dict[str, Any]
) -> tuple[pd.DataFrame, np.ndarray, dict[str, Any]]:
    if "Classification" not in (meta.get("tasks") or []):
        raise NoLabels("not a classification task")
    features, target = split_columns(frame, meta)
    known = target.notna().to_numpy()
    features, target = features[known].reset_index(drop=True), target[known].reset_index(drop=True)
    counts = target.astype(str).value_counts()
    if len(counts) < 2:
        raise NoLabels("fewer than 2 classes")
    rare = str(counts.index[-1])
    if counts.iloc[-1] < MIN_ANOMALIES:
        raise NoLabels(f"fewer than {MIN_ANOMALIES} rows in the rarest class")
    is_rare = (target.astype(str) == rare).to_numpy()
    natural = float(is_rare.mean())
    info: dict[str, Any] = {
        "anomaly_class": rare,
        "classes": int(len(counts)),
        "natural_rate": natural,
        "kind": "native_rare",
    }
    keep = np.ones(len(target), dtype=bool)
    if natural > TARGET_RATE:
        n_normal = int((~is_rare).sum())
        k = round(n_normal * TARGET_RATE / (1 - TARGET_RATE))
        chosen = np.random.default_rng(SEED).choice(np.flatnonzero(is_rare), k, replace=False)
        keep = ~is_rare
        keep[chosen] = True
        info["kind"] = "downsampled"
    labels = is_rare[keep].astype(int)
    info.update(anomalies=int(labels.sum()))
    return features[keep].reset_index(drop=True), labels, info


def x_derive_labels__mutmut_94(
    frame: pd.DataFrame, meta: dict[str, Any]
) -> tuple[pd.DataFrame, np.ndarray, dict[str, Any]]:
    if "Classification" not in (meta.get("tasks") or []):
        raise NoLabels("not a classification task")
    features, target = split_columns(frame, meta)
    known = target.notna().to_numpy()
    features, target = features[known].reset_index(drop=True), target[known].reset_index(drop=True)
    counts = target.astype(str).value_counts()
    if len(counts) < 2:
        raise NoLabels("fewer than 2 classes")
    rare = str(counts.index[-1])
    if counts.iloc[-1] < MIN_ANOMALIES:
        raise NoLabels(f"fewer than {MIN_ANOMALIES} rows in the rarest class")
    is_rare = (target.astype(str) == rare).to_numpy()
    natural = float(is_rare.mean())
    info: dict[str, Any] = {
        "anomaly_class": rare,
        "classes": int(len(counts)),
        "natural_rate": natural,
        "kind": "native_rare",
    }
    keep = np.ones(len(target), dtype=bool)
    if natural > TARGET_RATE:
        n_normal = int((~is_rare).sum())
        k = round(n_normal * TARGET_RATE / (1 - TARGET_RATE))
        chosen = np.random.default_rng(SEED).choice(np.flatnonzero(is_rare), k, replace=False)
        keep = ~is_rare
        keep[chosen] = True
        info["kind"] = "downsampled"
    labels = is_rare[keep].astype(int)
    info.update(rows=int(keep.sum()), )
    return features[keep].reset_index(drop=True), labels, info


def x_derive_labels__mutmut_95(
    frame: pd.DataFrame, meta: dict[str, Any]
) -> tuple[pd.DataFrame, np.ndarray, dict[str, Any]]:
    if "Classification" not in (meta.get("tasks") or []):
        raise NoLabels("not a classification task")
    features, target = split_columns(frame, meta)
    known = target.notna().to_numpy()
    features, target = features[known].reset_index(drop=True), target[known].reset_index(drop=True)
    counts = target.astype(str).value_counts()
    if len(counts) < 2:
        raise NoLabels("fewer than 2 classes")
    rare = str(counts.index[-1])
    if counts.iloc[-1] < MIN_ANOMALIES:
        raise NoLabels(f"fewer than {MIN_ANOMALIES} rows in the rarest class")
    is_rare = (target.astype(str) == rare).to_numpy()
    natural = float(is_rare.mean())
    info: dict[str, Any] = {
        "anomaly_class": rare,
        "classes": int(len(counts)),
        "natural_rate": natural,
        "kind": "native_rare",
    }
    keep = np.ones(len(target), dtype=bool)
    if natural > TARGET_RATE:
        n_normal = int((~is_rare).sum())
        k = round(n_normal * TARGET_RATE / (1 - TARGET_RATE))
        chosen = np.random.default_rng(SEED).choice(np.flatnonzero(is_rare), k, replace=False)
        keep = ~is_rare
        keep[chosen] = True
        info["kind"] = "downsampled"
    labels = is_rare[keep].astype(int)
    info.update(rows=int(None), anomalies=int(labels.sum()))
    return features[keep].reset_index(drop=True), labels, info


def x_derive_labels__mutmut_96(
    frame: pd.DataFrame, meta: dict[str, Any]
) -> tuple[pd.DataFrame, np.ndarray, dict[str, Any]]:
    if "Classification" not in (meta.get("tasks") or []):
        raise NoLabels("not a classification task")
    features, target = split_columns(frame, meta)
    known = target.notna().to_numpy()
    features, target = features[known].reset_index(drop=True), target[known].reset_index(drop=True)
    counts = target.astype(str).value_counts()
    if len(counts) < 2:
        raise NoLabels("fewer than 2 classes")
    rare = str(counts.index[-1])
    if counts.iloc[-1] < MIN_ANOMALIES:
        raise NoLabels(f"fewer than {MIN_ANOMALIES} rows in the rarest class")
    is_rare = (target.astype(str) == rare).to_numpy()
    natural = float(is_rare.mean())
    info: dict[str, Any] = {
        "anomaly_class": rare,
        "classes": int(len(counts)),
        "natural_rate": natural,
        "kind": "native_rare",
    }
    keep = np.ones(len(target), dtype=bool)
    if natural > TARGET_RATE:
        n_normal = int((~is_rare).sum())
        k = round(n_normal * TARGET_RATE / (1 - TARGET_RATE))
        chosen = np.random.default_rng(SEED).choice(np.flatnonzero(is_rare), k, replace=False)
        keep = ~is_rare
        keep[chosen] = True
        info["kind"] = "downsampled"
    labels = is_rare[keep].astype(int)
    info.update(rows=int(keep.sum()), anomalies=int(None))
    return features[keep].reset_index(drop=True), labels, info


def x_derive_labels__mutmut_97(
    frame: pd.DataFrame, meta: dict[str, Any]
) -> tuple[pd.DataFrame, np.ndarray, dict[str, Any]]:
    if "Classification" not in (meta.get("tasks") or []):
        raise NoLabels("not a classification task")
    features, target = split_columns(frame, meta)
    known = target.notna().to_numpy()
    features, target = features[known].reset_index(drop=True), target[known].reset_index(drop=True)
    counts = target.astype(str).value_counts()
    if len(counts) < 2:
        raise NoLabels("fewer than 2 classes")
    rare = str(counts.index[-1])
    if counts.iloc[-1] < MIN_ANOMALIES:
        raise NoLabels(f"fewer than {MIN_ANOMALIES} rows in the rarest class")
    is_rare = (target.astype(str) == rare).to_numpy()
    natural = float(is_rare.mean())
    info: dict[str, Any] = {
        "anomaly_class": rare,
        "classes": int(len(counts)),
        "natural_rate": natural,
        "kind": "native_rare",
    }
    keep = np.ones(len(target), dtype=bool)
    if natural > TARGET_RATE:
        n_normal = int((~is_rare).sum())
        k = round(n_normal * TARGET_RATE / (1 - TARGET_RATE))
        chosen = np.random.default_rng(SEED).choice(np.flatnonzero(is_rare), k, replace=False)
        keep = ~is_rare
        keep[chosen] = True
        info["kind"] = "downsampled"
    labels = is_rare[keep].astype(int)
    info.update(rows=int(keep.sum()), anomalies=int(labels.sum()))
    return features[keep].reset_index(drop=None), labels, info


def x_derive_labels__mutmut_98(
    frame: pd.DataFrame, meta: dict[str, Any]
) -> tuple[pd.DataFrame, np.ndarray, dict[str, Any]]:
    if "Classification" not in (meta.get("tasks") or []):
        raise NoLabels("not a classification task")
    features, target = split_columns(frame, meta)
    known = target.notna().to_numpy()
    features, target = features[known].reset_index(drop=True), target[known].reset_index(drop=True)
    counts = target.astype(str).value_counts()
    if len(counts) < 2:
        raise NoLabels("fewer than 2 classes")
    rare = str(counts.index[-1])
    if counts.iloc[-1] < MIN_ANOMALIES:
        raise NoLabels(f"fewer than {MIN_ANOMALIES} rows in the rarest class")
    is_rare = (target.astype(str) == rare).to_numpy()
    natural = float(is_rare.mean())
    info: dict[str, Any] = {
        "anomaly_class": rare,
        "classes": int(len(counts)),
        "natural_rate": natural,
        "kind": "native_rare",
    }
    keep = np.ones(len(target), dtype=bool)
    if natural > TARGET_RATE:
        n_normal = int((~is_rare).sum())
        k = round(n_normal * TARGET_RATE / (1 - TARGET_RATE))
        chosen = np.random.default_rng(SEED).choice(np.flatnonzero(is_rare), k, replace=False)
        keep = ~is_rare
        keep[chosen] = True
        info["kind"] = "downsampled"
    labels = is_rare[keep].astype(int)
    info.update(rows=int(keep.sum()), anomalies=int(labels.sum()))
    return features[keep].reset_index(drop=False), labels, info

mutants_x_derive_labels__mutmut['_mutmut_orig'] = x_derive_labels__mutmut_orig # type: ignore # mutmut generated
mutants_x_derive_labels__mutmut['x_derive_labels__mutmut_1'] = x_derive_labels__mutmut_1 # type: ignore # mutmut generated
mutants_x_derive_labels__mutmut['x_derive_labels__mutmut_2'] = x_derive_labels__mutmut_2 # type: ignore # mutmut generated
mutants_x_derive_labels__mutmut['x_derive_labels__mutmut_3'] = x_derive_labels__mutmut_3 # type: ignore # mutmut generated
mutants_x_derive_labels__mutmut['x_derive_labels__mutmut_4'] = x_derive_labels__mutmut_4 # type: ignore # mutmut generated
mutants_x_derive_labels__mutmut['x_derive_labels__mutmut_5'] = x_derive_labels__mutmut_5 # type: ignore # mutmut generated
mutants_x_derive_labels__mutmut['x_derive_labels__mutmut_6'] = x_derive_labels__mutmut_6 # type: ignore # mutmut generated
mutants_x_derive_labels__mutmut['x_derive_labels__mutmut_7'] = x_derive_labels__mutmut_7 # type: ignore # mutmut generated
mutants_x_derive_labels__mutmut['x_derive_labels__mutmut_8'] = x_derive_labels__mutmut_8 # type: ignore # mutmut generated
mutants_x_derive_labels__mutmut['x_derive_labels__mutmut_9'] = x_derive_labels__mutmut_9 # type: ignore # mutmut generated
mutants_x_derive_labels__mutmut['x_derive_labels__mutmut_10'] = x_derive_labels__mutmut_10 # type: ignore # mutmut generated
mutants_x_derive_labels__mutmut['x_derive_labels__mutmut_11'] = x_derive_labels__mutmut_11 # type: ignore # mutmut generated
mutants_x_derive_labels__mutmut['x_derive_labels__mutmut_12'] = x_derive_labels__mutmut_12 # type: ignore # mutmut generated
mutants_x_derive_labels__mutmut['x_derive_labels__mutmut_13'] = x_derive_labels__mutmut_13 # type: ignore # mutmut generated
mutants_x_derive_labels__mutmut['x_derive_labels__mutmut_14'] = x_derive_labels__mutmut_14 # type: ignore # mutmut generated
mutants_x_derive_labels__mutmut['x_derive_labels__mutmut_15'] = x_derive_labels__mutmut_15 # type: ignore # mutmut generated
mutants_x_derive_labels__mutmut['x_derive_labels__mutmut_16'] = x_derive_labels__mutmut_16 # type: ignore # mutmut generated
mutants_x_derive_labels__mutmut['x_derive_labels__mutmut_17'] = x_derive_labels__mutmut_17 # type: ignore # mutmut generated
mutants_x_derive_labels__mutmut['x_derive_labels__mutmut_18'] = x_derive_labels__mutmut_18 # type: ignore # mutmut generated
mutants_x_derive_labels__mutmut['x_derive_labels__mutmut_19'] = x_derive_labels__mutmut_19 # type: ignore # mutmut generated
mutants_x_derive_labels__mutmut['x_derive_labels__mutmut_20'] = x_derive_labels__mutmut_20 # type: ignore # mutmut generated
mutants_x_derive_labels__mutmut['x_derive_labels__mutmut_21'] = x_derive_labels__mutmut_21 # type: ignore # mutmut generated
mutants_x_derive_labels__mutmut['x_derive_labels__mutmut_22'] = x_derive_labels__mutmut_22 # type: ignore # mutmut generated
mutants_x_derive_labels__mutmut['x_derive_labels__mutmut_23'] = x_derive_labels__mutmut_23 # type: ignore # mutmut generated
mutants_x_derive_labels__mutmut['x_derive_labels__mutmut_24'] = x_derive_labels__mutmut_24 # type: ignore # mutmut generated
mutants_x_derive_labels__mutmut['x_derive_labels__mutmut_25'] = x_derive_labels__mutmut_25 # type: ignore # mutmut generated
mutants_x_derive_labels__mutmut['x_derive_labels__mutmut_26'] = x_derive_labels__mutmut_26 # type: ignore # mutmut generated
mutants_x_derive_labels__mutmut['x_derive_labels__mutmut_27'] = x_derive_labels__mutmut_27 # type: ignore # mutmut generated
mutants_x_derive_labels__mutmut['x_derive_labels__mutmut_28'] = x_derive_labels__mutmut_28 # type: ignore # mutmut generated
mutants_x_derive_labels__mutmut['x_derive_labels__mutmut_29'] = x_derive_labels__mutmut_29 # type: ignore # mutmut generated
mutants_x_derive_labels__mutmut['x_derive_labels__mutmut_30'] = x_derive_labels__mutmut_30 # type: ignore # mutmut generated
mutants_x_derive_labels__mutmut['x_derive_labels__mutmut_31'] = x_derive_labels__mutmut_31 # type: ignore # mutmut generated
mutants_x_derive_labels__mutmut['x_derive_labels__mutmut_32'] = x_derive_labels__mutmut_32 # type: ignore # mutmut generated
mutants_x_derive_labels__mutmut['x_derive_labels__mutmut_33'] = x_derive_labels__mutmut_33 # type: ignore # mutmut generated
mutants_x_derive_labels__mutmut['x_derive_labels__mutmut_34'] = x_derive_labels__mutmut_34 # type: ignore # mutmut generated
mutants_x_derive_labels__mutmut['x_derive_labels__mutmut_35'] = x_derive_labels__mutmut_35 # type: ignore # mutmut generated
mutants_x_derive_labels__mutmut['x_derive_labels__mutmut_36'] = x_derive_labels__mutmut_36 # type: ignore # mutmut generated
mutants_x_derive_labels__mutmut['x_derive_labels__mutmut_37'] = x_derive_labels__mutmut_37 # type: ignore # mutmut generated
mutants_x_derive_labels__mutmut['x_derive_labels__mutmut_38'] = x_derive_labels__mutmut_38 # type: ignore # mutmut generated
mutants_x_derive_labels__mutmut['x_derive_labels__mutmut_39'] = x_derive_labels__mutmut_39 # type: ignore # mutmut generated
mutants_x_derive_labels__mutmut['x_derive_labels__mutmut_40'] = x_derive_labels__mutmut_40 # type: ignore # mutmut generated
mutants_x_derive_labels__mutmut['x_derive_labels__mutmut_41'] = x_derive_labels__mutmut_41 # type: ignore # mutmut generated
mutants_x_derive_labels__mutmut['x_derive_labels__mutmut_42'] = x_derive_labels__mutmut_42 # type: ignore # mutmut generated
mutants_x_derive_labels__mutmut['x_derive_labels__mutmut_43'] = x_derive_labels__mutmut_43 # type: ignore # mutmut generated
mutants_x_derive_labels__mutmut['x_derive_labels__mutmut_44'] = x_derive_labels__mutmut_44 # type: ignore # mutmut generated
mutants_x_derive_labels__mutmut['x_derive_labels__mutmut_45'] = x_derive_labels__mutmut_45 # type: ignore # mutmut generated
mutants_x_derive_labels__mutmut['x_derive_labels__mutmut_46'] = x_derive_labels__mutmut_46 # type: ignore # mutmut generated
mutants_x_derive_labels__mutmut['x_derive_labels__mutmut_47'] = x_derive_labels__mutmut_47 # type: ignore # mutmut generated
mutants_x_derive_labels__mutmut['x_derive_labels__mutmut_48'] = x_derive_labels__mutmut_48 # type: ignore # mutmut generated
mutants_x_derive_labels__mutmut['x_derive_labels__mutmut_49'] = x_derive_labels__mutmut_49 # type: ignore # mutmut generated
mutants_x_derive_labels__mutmut['x_derive_labels__mutmut_50'] = x_derive_labels__mutmut_50 # type: ignore # mutmut generated
mutants_x_derive_labels__mutmut['x_derive_labels__mutmut_51'] = x_derive_labels__mutmut_51 # type: ignore # mutmut generated
mutants_x_derive_labels__mutmut['x_derive_labels__mutmut_52'] = x_derive_labels__mutmut_52 # type: ignore # mutmut generated
mutants_x_derive_labels__mutmut['x_derive_labels__mutmut_53'] = x_derive_labels__mutmut_53 # type: ignore # mutmut generated
mutants_x_derive_labels__mutmut['x_derive_labels__mutmut_54'] = x_derive_labels__mutmut_54 # type: ignore # mutmut generated
mutants_x_derive_labels__mutmut['x_derive_labels__mutmut_55'] = x_derive_labels__mutmut_55 # type: ignore # mutmut generated
mutants_x_derive_labels__mutmut['x_derive_labels__mutmut_56'] = x_derive_labels__mutmut_56 # type: ignore # mutmut generated
mutants_x_derive_labels__mutmut['x_derive_labels__mutmut_57'] = x_derive_labels__mutmut_57 # type: ignore # mutmut generated
mutants_x_derive_labels__mutmut['x_derive_labels__mutmut_58'] = x_derive_labels__mutmut_58 # type: ignore # mutmut generated
mutants_x_derive_labels__mutmut['x_derive_labels__mutmut_59'] = x_derive_labels__mutmut_59 # type: ignore # mutmut generated
mutants_x_derive_labels__mutmut['x_derive_labels__mutmut_60'] = x_derive_labels__mutmut_60 # type: ignore # mutmut generated
mutants_x_derive_labels__mutmut['x_derive_labels__mutmut_61'] = x_derive_labels__mutmut_61 # type: ignore # mutmut generated
mutants_x_derive_labels__mutmut['x_derive_labels__mutmut_62'] = x_derive_labels__mutmut_62 # type: ignore # mutmut generated
mutants_x_derive_labels__mutmut['x_derive_labels__mutmut_63'] = x_derive_labels__mutmut_63 # type: ignore # mutmut generated
mutants_x_derive_labels__mutmut['x_derive_labels__mutmut_64'] = x_derive_labels__mutmut_64 # type: ignore # mutmut generated
mutants_x_derive_labels__mutmut['x_derive_labels__mutmut_65'] = x_derive_labels__mutmut_65 # type: ignore # mutmut generated
mutants_x_derive_labels__mutmut['x_derive_labels__mutmut_66'] = x_derive_labels__mutmut_66 # type: ignore # mutmut generated
mutants_x_derive_labels__mutmut['x_derive_labels__mutmut_67'] = x_derive_labels__mutmut_67 # type: ignore # mutmut generated
mutants_x_derive_labels__mutmut['x_derive_labels__mutmut_68'] = x_derive_labels__mutmut_68 # type: ignore # mutmut generated
mutants_x_derive_labels__mutmut['x_derive_labels__mutmut_69'] = x_derive_labels__mutmut_69 # type: ignore # mutmut generated
mutants_x_derive_labels__mutmut['x_derive_labels__mutmut_70'] = x_derive_labels__mutmut_70 # type: ignore # mutmut generated
mutants_x_derive_labels__mutmut['x_derive_labels__mutmut_71'] = x_derive_labels__mutmut_71 # type: ignore # mutmut generated
mutants_x_derive_labels__mutmut['x_derive_labels__mutmut_72'] = x_derive_labels__mutmut_72 # type: ignore # mutmut generated
mutants_x_derive_labels__mutmut['x_derive_labels__mutmut_73'] = x_derive_labels__mutmut_73 # type: ignore # mutmut generated
mutants_x_derive_labels__mutmut['x_derive_labels__mutmut_74'] = x_derive_labels__mutmut_74 # type: ignore # mutmut generated
mutants_x_derive_labels__mutmut['x_derive_labels__mutmut_75'] = x_derive_labels__mutmut_75 # type: ignore # mutmut generated
mutants_x_derive_labels__mutmut['x_derive_labels__mutmut_76'] = x_derive_labels__mutmut_76 # type: ignore # mutmut generated
mutants_x_derive_labels__mutmut['x_derive_labels__mutmut_77'] = x_derive_labels__mutmut_77 # type: ignore # mutmut generated
mutants_x_derive_labels__mutmut['x_derive_labels__mutmut_78'] = x_derive_labels__mutmut_78 # type: ignore # mutmut generated
mutants_x_derive_labels__mutmut['x_derive_labels__mutmut_79'] = x_derive_labels__mutmut_79 # type: ignore # mutmut generated
mutants_x_derive_labels__mutmut['x_derive_labels__mutmut_80'] = x_derive_labels__mutmut_80 # type: ignore # mutmut generated
mutants_x_derive_labels__mutmut['x_derive_labels__mutmut_81'] = x_derive_labels__mutmut_81 # type: ignore # mutmut generated
mutants_x_derive_labels__mutmut['x_derive_labels__mutmut_82'] = x_derive_labels__mutmut_82 # type: ignore # mutmut generated
mutants_x_derive_labels__mutmut['x_derive_labels__mutmut_83'] = x_derive_labels__mutmut_83 # type: ignore # mutmut generated
mutants_x_derive_labels__mutmut['x_derive_labels__mutmut_84'] = x_derive_labels__mutmut_84 # type: ignore # mutmut generated
mutants_x_derive_labels__mutmut['x_derive_labels__mutmut_85'] = x_derive_labels__mutmut_85 # type: ignore # mutmut generated
mutants_x_derive_labels__mutmut['x_derive_labels__mutmut_86'] = x_derive_labels__mutmut_86 # type: ignore # mutmut generated
mutants_x_derive_labels__mutmut['x_derive_labels__mutmut_87'] = x_derive_labels__mutmut_87 # type: ignore # mutmut generated
mutants_x_derive_labels__mutmut['x_derive_labels__mutmut_88'] = x_derive_labels__mutmut_88 # type: ignore # mutmut generated
mutants_x_derive_labels__mutmut['x_derive_labels__mutmut_89'] = x_derive_labels__mutmut_89 # type: ignore # mutmut generated
mutants_x_derive_labels__mutmut['x_derive_labels__mutmut_90'] = x_derive_labels__mutmut_90 # type: ignore # mutmut generated
mutants_x_derive_labels__mutmut['x_derive_labels__mutmut_91'] = x_derive_labels__mutmut_91 # type: ignore # mutmut generated
mutants_x_derive_labels__mutmut['x_derive_labels__mutmut_92'] = x_derive_labels__mutmut_92 # type: ignore # mutmut generated
mutants_x_derive_labels__mutmut['x_derive_labels__mutmut_93'] = x_derive_labels__mutmut_93 # type: ignore # mutmut generated
mutants_x_derive_labels__mutmut['x_derive_labels__mutmut_94'] = x_derive_labels__mutmut_94 # type: ignore # mutmut generated
mutants_x_derive_labels__mutmut['x_derive_labels__mutmut_95'] = x_derive_labels__mutmut_95 # type: ignore # mutmut generated
mutants_x_derive_labels__mutmut['x_derive_labels__mutmut_96'] = x_derive_labels__mutmut_96 # type: ignore # mutmut generated
mutants_x_derive_labels__mutmut['x_derive_labels__mutmut_97'] = x_derive_labels__mutmut_97 # type: ignore # mutmut generated
mutants_x_derive_labels__mutmut['x_derive_labels__mutmut_98'] = x_derive_labels__mutmut_98 # type: ignore # mutmut generated
