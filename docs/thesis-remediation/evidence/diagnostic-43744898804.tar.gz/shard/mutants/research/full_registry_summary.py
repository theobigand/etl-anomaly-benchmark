"""Tables and figures of the complete-registry study (protocol verification/full_registry.md).

Merges the classical runs archived by the usual experiments with the neural runs of
``full_registry.py``, ``labelled_benchmark.py --methods deep``, ``typed_run.py --methods deep`` and
``multi_schema.py --methods deep``, so that every table and figure lists the whole registry.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
import numpy as np  # noqa: E402
import pandas as pd  # noqa: E402
import typed_figures as tf  # noqa: E402
import typed_summary as ts  # noqa: E402

ROOT = Path(__file__).resolve().parents[1]
EVIDENCE = ROOT / "verification" / "evidence"
ORDER = [
    "zscore",
    "iqr",
    "great_expectations",
    "isolation_forest",
    "lof",
    "ocsvm",
    "ecod",
    "copod",
    "hbos",
    "knn",
    "pca",
    "autoencoder",
    "vae",
    "deep_svdd",
    "dif",
    "ae1svm",
    "lunar",
    "lstm_autoencoder",
    "drift",
    "transform_dedup",
]
TYPES = [
    "missing_value",
    "duplicate",
    "univariate_outlier",
    "multivariate_outlier",
    "temporal_drift",
    "invalid_format",
]


from mutmut.mutation.trampoline import wrap_in_trampoline as _mutmut_mutated, MutantDict
mutants_x_ordered__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_ordered__mutmut)
def ordered(frame: pd.DataFrame) -> pd.DataFrame:
    """Rows in registry order (families together), unknown names last."""
    rank = {name: i for i, name in enumerate(ORDER)}
    return frame.iloc[sorted(range(len(frame)), key=lambda i: rank.get(frame.index[i], 99))]


def x_ordered__mutmut_orig(frame: pd.DataFrame) -> pd.DataFrame:
    """Rows in registry order (families together), unknown names last."""
    rank = {name: i for i, name in enumerate(ORDER)}
    return frame.iloc[sorted(range(len(frame)), key=lambda i: rank.get(frame.index[i], 99))]


def x_ordered__mutmut_1(frame: pd.DataFrame) -> pd.DataFrame:
    """Rows in registry order (families together), unknown names last."""
    rank = None
    return frame.iloc[sorted(range(len(frame)), key=lambda i: rank.get(frame.index[i], 99))]


def x_ordered__mutmut_2(frame: pd.DataFrame) -> pd.DataFrame:
    """Rows in registry order (families together), unknown names last."""
    rank = {name: i for i, name in enumerate(None)}
    return frame.iloc[sorted(range(len(frame)), key=lambda i: rank.get(frame.index[i], 99))]


def x_ordered__mutmut_3(frame: pd.DataFrame) -> pd.DataFrame:
    """Rows in registry order (families together), unknown names last."""
    rank = {name: i for i, name in enumerate(ORDER)}
    return frame.iloc[sorted(None, key=lambda i: rank.get(frame.index[i], 99))]


def x_ordered__mutmut_4(frame: pd.DataFrame) -> pd.DataFrame:
    """Rows in registry order (families together), unknown names last."""
    rank = {name: i for i, name in enumerate(ORDER)}
    return frame.iloc[sorted(range(len(frame)), key=None)]


def x_ordered__mutmut_5(frame: pd.DataFrame) -> pd.DataFrame:
    """Rows in registry order (families together), unknown names last."""
    rank = {name: i for i, name in enumerate(ORDER)}
    return frame.iloc[sorted(key=lambda i: rank.get(frame.index[i], 99))]


def x_ordered__mutmut_6(frame: pd.DataFrame) -> pd.DataFrame:
    """Rows in registry order (families together), unknown names last."""
    rank = {name: i for i, name in enumerate(ORDER)}
    return frame.iloc[sorted(range(len(frame)), )]


def x_ordered__mutmut_7(frame: pd.DataFrame) -> pd.DataFrame:
    """Rows in registry order (families together), unknown names last."""
    rank = {name: i for i, name in enumerate(ORDER)}
    return frame.iloc[sorted(range(None), key=lambda i: rank.get(frame.index[i], 99))]


def x_ordered__mutmut_8(frame: pd.DataFrame) -> pd.DataFrame:
    """Rows in registry order (families together), unknown names last."""
    rank = {name: i for i, name in enumerate(ORDER)}
    return frame.iloc[sorted(range(len(frame)), key=lambda i: None)]


def x_ordered__mutmut_9(frame: pd.DataFrame) -> pd.DataFrame:
    """Rows in registry order (families together), unknown names last."""
    rank = {name: i for i, name in enumerate(ORDER)}
    return frame.iloc[sorted(range(len(frame)), key=lambda i: rank.get(None, 99))]


def x_ordered__mutmut_10(frame: pd.DataFrame) -> pd.DataFrame:
    """Rows in registry order (families together), unknown names last."""
    rank = {name: i for i, name in enumerate(ORDER)}
    return frame.iloc[sorted(range(len(frame)), key=lambda i: rank.get(frame.index[i], None))]


def x_ordered__mutmut_11(frame: pd.DataFrame) -> pd.DataFrame:
    """Rows in registry order (families together), unknown names last."""
    rank = {name: i for i, name in enumerate(ORDER)}
    return frame.iloc[sorted(range(len(frame)), key=lambda i: rank.get(99))]


def x_ordered__mutmut_12(frame: pd.DataFrame) -> pd.DataFrame:
    """Rows in registry order (families together), unknown names last."""
    rank = {name: i for i, name in enumerate(ORDER)}
    return frame.iloc[sorted(range(len(frame)), key=lambda i: rank.get(frame.index[i], ))]


def x_ordered__mutmut_13(frame: pd.DataFrame) -> pd.DataFrame:
    """Rows in registry order (families together), unknown names last."""
    rank = {name: i for i, name in enumerate(ORDER)}
    return frame.iloc[sorted(range(len(frame)), key=lambda i: rank.get(frame.index[i], 100))]

mutants_x_ordered__mutmut['_mutmut_orig'] = x_ordered__mutmut_orig # type: ignore # mutmut generated
mutants_x_ordered__mutmut['x_ordered__mutmut_1'] = x_ordered__mutmut_1 # type: ignore # mutmut generated
mutants_x_ordered__mutmut['x_ordered__mutmut_2'] = x_ordered__mutmut_2 # type: ignore # mutmut generated
mutants_x_ordered__mutmut['x_ordered__mutmut_3'] = x_ordered__mutmut_3 # type: ignore # mutmut generated
mutants_x_ordered__mutmut['x_ordered__mutmut_4'] = x_ordered__mutmut_4 # type: ignore # mutmut generated
mutants_x_ordered__mutmut['x_ordered__mutmut_5'] = x_ordered__mutmut_5 # type: ignore # mutmut generated
mutants_x_ordered__mutmut['x_ordered__mutmut_6'] = x_ordered__mutmut_6 # type: ignore # mutmut generated
mutants_x_ordered__mutmut['x_ordered__mutmut_7'] = x_ordered__mutmut_7 # type: ignore # mutmut generated
mutants_x_ordered__mutmut['x_ordered__mutmut_8'] = x_ordered__mutmut_8 # type: ignore # mutmut generated
mutants_x_ordered__mutmut['x_ordered__mutmut_9'] = x_ordered__mutmut_9 # type: ignore # mutmut generated
mutants_x_ordered__mutmut['x_ordered__mutmut_10'] = x_ordered__mutmut_10 # type: ignore # mutmut generated
mutants_x_ordered__mutmut['x_ordered__mutmut_11'] = x_ordered__mutmut_11 # type: ignore # mutmut generated
mutants_x_ordered__mutmut['x_ordered__mutmut_12'] = x_ordered__mutmut_12 # type: ignore # mutmut generated
mutants_x_ordered__mutmut['x_ordered__mutmut_13'] = x_ordered__mutmut_13 # type: ignore # mutmut generated
mutants_x__split__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x__split__mutmut)
def _split(payload: dict) -> pd.DataFrame:
    return pd.DataFrame(payload["data"], payload["index"], payload["columns"])


def x__split__mutmut_orig(payload: dict) -> pd.DataFrame:
    return pd.DataFrame(payload["data"], payload["index"], payload["columns"])


def x__split__mutmut_1(payload: dict) -> pd.DataFrame:
    return pd.DataFrame(None, payload["index"], payload["columns"])


def x__split__mutmut_2(payload: dict) -> pd.DataFrame:
    return pd.DataFrame(payload["data"], None, payload["columns"])


def x__split__mutmut_3(payload: dict) -> pd.DataFrame:
    return pd.DataFrame(payload["data"], payload["index"], None)


def x__split__mutmut_4(payload: dict) -> pd.DataFrame:
    return pd.DataFrame(payload["index"], payload["columns"])


def x__split__mutmut_5(payload: dict) -> pd.DataFrame:
    return pd.DataFrame(payload["data"], payload["columns"])


def x__split__mutmut_6(payload: dict) -> pd.DataFrame:
    return pd.DataFrame(payload["data"], payload["index"], )


def x__split__mutmut_7(payload: dict) -> pd.DataFrame:
    return pd.DataFrame(payload["XXdataXX"], payload["index"], payload["columns"])


def x__split__mutmut_8(payload: dict) -> pd.DataFrame:
    return pd.DataFrame(payload["DATA"], payload["index"], payload["columns"])


def x__split__mutmut_9(payload: dict) -> pd.DataFrame:
    return pd.DataFrame(payload["data"], payload["XXindexXX"], payload["columns"])


def x__split__mutmut_10(payload: dict) -> pd.DataFrame:
    return pd.DataFrame(payload["data"], payload["INDEX"], payload["columns"])


def x__split__mutmut_11(payload: dict) -> pd.DataFrame:
    return pd.DataFrame(payload["data"], payload["index"], payload["XXcolumnsXX"])


def x__split__mutmut_12(payload: dict) -> pd.DataFrame:
    return pd.DataFrame(payload["data"], payload["index"], payload["COLUMNS"])

mutants_x__split__mutmut['_mutmut_orig'] = x__split__mutmut_orig # type: ignore # mutmut generated
mutants_x__split__mutmut['x__split__mutmut_1'] = x__split__mutmut_1 # type: ignore # mutmut generated
mutants_x__split__mutmut['x__split__mutmut_2'] = x__split__mutmut_2 # type: ignore # mutmut generated
mutants_x__split__mutmut['x__split__mutmut_3'] = x__split__mutmut_3 # type: ignore # mutmut generated
mutants_x__split__mutmut['x__split__mutmut_4'] = x__split__mutmut_4 # type: ignore # mutmut generated
mutants_x__split__mutmut['x__split__mutmut_5'] = x__split__mutmut_5 # type: ignore # mutmut generated
mutants_x__split__mutmut['x__split__mutmut_6'] = x__split__mutmut_6 # type: ignore # mutmut generated
mutants_x__split__mutmut['x__split__mutmut_7'] = x__split__mutmut_7 # type: ignore # mutmut generated
mutants_x__split__mutmut['x__split__mutmut_8'] = x__split__mutmut_8 # type: ignore # mutmut generated
mutants_x__split__mutmut['x__split__mutmut_9'] = x__split__mutmut_9 # type: ignore # mutmut generated
mutants_x__split__mutmut['x__split__mutmut_10'] = x__split__mutmut_10 # type: ignore # mutmut generated
mutants_x__split__mutmut['x__split__mutmut_11'] = x__split__mutmut_11 # type: ignore # mutmut generated
mutants_x__split__mutmut['x__split__mutmut_12'] = x__split__mutmut_12 # type: ignore # mutmut generated
mutants_x_merged_typed__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_merged_typed__mutmut)
def merged_typed(classical: Path, deep: Path) -> dict[str, pd.DataFrame]:
    """One matrix per carrier: the classical rows, then the neural rows of the same carrier."""
    out = {}
    for path in sorted(classical.glob("*.json")):
        base = _split(json.loads(path.read_text())["recall_mean"])
        extra = deep / path.name
        if extra.is_file():
            rows = _split(json.loads(extra.read_text())["recall_mean"])
            base = pd.concat([base, rows.drop(index="transform_dedup", errors="ignore")])
        out[json.loads(path.read_text())["name"]] = ordered(base)
    return out


def x_merged_typed__mutmut_orig(classical: Path, deep: Path) -> dict[str, pd.DataFrame]:
    """One matrix per carrier: the classical rows, then the neural rows of the same carrier."""
    out = {}
    for path in sorted(classical.glob("*.json")):
        base = _split(json.loads(path.read_text())["recall_mean"])
        extra = deep / path.name
        if extra.is_file():
            rows = _split(json.loads(extra.read_text())["recall_mean"])
            base = pd.concat([base, rows.drop(index="transform_dedup", errors="ignore")])
        out[json.loads(path.read_text())["name"]] = ordered(base)
    return out


def x_merged_typed__mutmut_1(classical: Path, deep: Path) -> dict[str, pd.DataFrame]:
    """One matrix per carrier: the classical rows, then the neural rows of the same carrier."""
    out = None
    for path in sorted(classical.glob("*.json")):
        base = _split(json.loads(path.read_text())["recall_mean"])
        extra = deep / path.name
        if extra.is_file():
            rows = _split(json.loads(extra.read_text())["recall_mean"])
            base = pd.concat([base, rows.drop(index="transform_dedup", errors="ignore")])
        out[json.loads(path.read_text())["name"]] = ordered(base)
    return out


def x_merged_typed__mutmut_2(classical: Path, deep: Path) -> dict[str, pd.DataFrame]:
    """One matrix per carrier: the classical rows, then the neural rows of the same carrier."""
    out = {}
    for path in sorted(None):
        base = _split(json.loads(path.read_text())["recall_mean"])
        extra = deep / path.name
        if extra.is_file():
            rows = _split(json.loads(extra.read_text())["recall_mean"])
            base = pd.concat([base, rows.drop(index="transform_dedup", errors="ignore")])
        out[json.loads(path.read_text())["name"]] = ordered(base)
    return out


def x_merged_typed__mutmut_3(classical: Path, deep: Path) -> dict[str, pd.DataFrame]:
    """One matrix per carrier: the classical rows, then the neural rows of the same carrier."""
    out = {}
    for path in sorted(classical.glob(None)):
        base = _split(json.loads(path.read_text())["recall_mean"])
        extra = deep / path.name
        if extra.is_file():
            rows = _split(json.loads(extra.read_text())["recall_mean"])
            base = pd.concat([base, rows.drop(index="transform_dedup", errors="ignore")])
        out[json.loads(path.read_text())["name"]] = ordered(base)
    return out


def x_merged_typed__mutmut_4(classical: Path, deep: Path) -> dict[str, pd.DataFrame]:
    """One matrix per carrier: the classical rows, then the neural rows of the same carrier."""
    out = {}
    for path in sorted(classical.glob("XX*.jsonXX")):
        base = _split(json.loads(path.read_text())["recall_mean"])
        extra = deep / path.name
        if extra.is_file():
            rows = _split(json.loads(extra.read_text())["recall_mean"])
            base = pd.concat([base, rows.drop(index="transform_dedup", errors="ignore")])
        out[json.loads(path.read_text())["name"]] = ordered(base)
    return out


def x_merged_typed__mutmut_5(classical: Path, deep: Path) -> dict[str, pd.DataFrame]:
    """One matrix per carrier: the classical rows, then the neural rows of the same carrier."""
    out = {}
    for path in sorted(classical.glob("*.JSON")):
        base = _split(json.loads(path.read_text())["recall_mean"])
        extra = deep / path.name
        if extra.is_file():
            rows = _split(json.loads(extra.read_text())["recall_mean"])
            base = pd.concat([base, rows.drop(index="transform_dedup", errors="ignore")])
        out[json.loads(path.read_text())["name"]] = ordered(base)
    return out


def x_merged_typed__mutmut_6(classical: Path, deep: Path) -> dict[str, pd.DataFrame]:
    """One matrix per carrier: the classical rows, then the neural rows of the same carrier."""
    out = {}
    for path in sorted(classical.glob("*.json")):
        base = None
        extra = deep / path.name
        if extra.is_file():
            rows = _split(json.loads(extra.read_text())["recall_mean"])
            base = pd.concat([base, rows.drop(index="transform_dedup", errors="ignore")])
        out[json.loads(path.read_text())["name"]] = ordered(base)
    return out


def x_merged_typed__mutmut_7(classical: Path, deep: Path) -> dict[str, pd.DataFrame]:
    """One matrix per carrier: the classical rows, then the neural rows of the same carrier."""
    out = {}
    for path in sorted(classical.glob("*.json")):
        base = _split(None)
        extra = deep / path.name
        if extra.is_file():
            rows = _split(json.loads(extra.read_text())["recall_mean"])
            base = pd.concat([base, rows.drop(index="transform_dedup", errors="ignore")])
        out[json.loads(path.read_text())["name"]] = ordered(base)
    return out


def x_merged_typed__mutmut_8(classical: Path, deep: Path) -> dict[str, pd.DataFrame]:
    """One matrix per carrier: the classical rows, then the neural rows of the same carrier."""
    out = {}
    for path in sorted(classical.glob("*.json")):
        base = _split(json.loads(None)["recall_mean"])
        extra = deep / path.name
        if extra.is_file():
            rows = _split(json.loads(extra.read_text())["recall_mean"])
            base = pd.concat([base, rows.drop(index="transform_dedup", errors="ignore")])
        out[json.loads(path.read_text())["name"]] = ordered(base)
    return out


def x_merged_typed__mutmut_9(classical: Path, deep: Path) -> dict[str, pd.DataFrame]:
    """One matrix per carrier: the classical rows, then the neural rows of the same carrier."""
    out = {}
    for path in sorted(classical.glob("*.json")):
        base = _split(json.loads(path.read_text())["XXrecall_meanXX"])
        extra = deep / path.name
        if extra.is_file():
            rows = _split(json.loads(extra.read_text())["recall_mean"])
            base = pd.concat([base, rows.drop(index="transform_dedup", errors="ignore")])
        out[json.loads(path.read_text())["name"]] = ordered(base)
    return out


def x_merged_typed__mutmut_10(classical: Path, deep: Path) -> dict[str, pd.DataFrame]:
    """One matrix per carrier: the classical rows, then the neural rows of the same carrier."""
    out = {}
    for path in sorted(classical.glob("*.json")):
        base = _split(json.loads(path.read_text())["RECALL_MEAN"])
        extra = deep / path.name
        if extra.is_file():
            rows = _split(json.loads(extra.read_text())["recall_mean"])
            base = pd.concat([base, rows.drop(index="transform_dedup", errors="ignore")])
        out[json.loads(path.read_text())["name"]] = ordered(base)
    return out


def x_merged_typed__mutmut_11(classical: Path, deep: Path) -> dict[str, pd.DataFrame]:
    """One matrix per carrier: the classical rows, then the neural rows of the same carrier."""
    out = {}
    for path in sorted(classical.glob("*.json")):
        base = _split(json.loads(path.read_text())["recall_mean"])
        extra = None
        if extra.is_file():
            rows = _split(json.loads(extra.read_text())["recall_mean"])
            base = pd.concat([base, rows.drop(index="transform_dedup", errors="ignore")])
        out[json.loads(path.read_text())["name"]] = ordered(base)
    return out


def x_merged_typed__mutmut_12(classical: Path, deep: Path) -> dict[str, pd.DataFrame]:
    """One matrix per carrier: the classical rows, then the neural rows of the same carrier."""
    out = {}
    for path in sorted(classical.glob("*.json")):
        base = _split(json.loads(path.read_text())["recall_mean"])
        extra = deep * path.name
        if extra.is_file():
            rows = _split(json.loads(extra.read_text())["recall_mean"])
            base = pd.concat([base, rows.drop(index="transform_dedup", errors="ignore")])
        out[json.loads(path.read_text())["name"]] = ordered(base)
    return out


def x_merged_typed__mutmut_13(classical: Path, deep: Path) -> dict[str, pd.DataFrame]:
    """One matrix per carrier: the classical rows, then the neural rows of the same carrier."""
    out = {}
    for path in sorted(classical.glob("*.json")):
        base = _split(json.loads(path.read_text())["recall_mean"])
        extra = deep / path.name
        if extra.is_file():
            rows = None
            base = pd.concat([base, rows.drop(index="transform_dedup", errors="ignore")])
        out[json.loads(path.read_text())["name"]] = ordered(base)
    return out


def x_merged_typed__mutmut_14(classical: Path, deep: Path) -> dict[str, pd.DataFrame]:
    """One matrix per carrier: the classical rows, then the neural rows of the same carrier."""
    out = {}
    for path in sorted(classical.glob("*.json")):
        base = _split(json.loads(path.read_text())["recall_mean"])
        extra = deep / path.name
        if extra.is_file():
            rows = _split(None)
            base = pd.concat([base, rows.drop(index="transform_dedup", errors="ignore")])
        out[json.loads(path.read_text())["name"]] = ordered(base)
    return out


def x_merged_typed__mutmut_15(classical: Path, deep: Path) -> dict[str, pd.DataFrame]:
    """One matrix per carrier: the classical rows, then the neural rows of the same carrier."""
    out = {}
    for path in sorted(classical.glob("*.json")):
        base = _split(json.loads(path.read_text())["recall_mean"])
        extra = deep / path.name
        if extra.is_file():
            rows = _split(json.loads(None)["recall_mean"])
            base = pd.concat([base, rows.drop(index="transform_dedup", errors="ignore")])
        out[json.loads(path.read_text())["name"]] = ordered(base)
    return out


def x_merged_typed__mutmut_16(classical: Path, deep: Path) -> dict[str, pd.DataFrame]:
    """One matrix per carrier: the classical rows, then the neural rows of the same carrier."""
    out = {}
    for path in sorted(classical.glob("*.json")):
        base = _split(json.loads(path.read_text())["recall_mean"])
        extra = deep / path.name
        if extra.is_file():
            rows = _split(json.loads(extra.read_text())["XXrecall_meanXX"])
            base = pd.concat([base, rows.drop(index="transform_dedup", errors="ignore")])
        out[json.loads(path.read_text())["name"]] = ordered(base)
    return out


def x_merged_typed__mutmut_17(classical: Path, deep: Path) -> dict[str, pd.DataFrame]:
    """One matrix per carrier: the classical rows, then the neural rows of the same carrier."""
    out = {}
    for path in sorted(classical.glob("*.json")):
        base = _split(json.loads(path.read_text())["recall_mean"])
        extra = deep / path.name
        if extra.is_file():
            rows = _split(json.loads(extra.read_text())["RECALL_MEAN"])
            base = pd.concat([base, rows.drop(index="transform_dedup", errors="ignore")])
        out[json.loads(path.read_text())["name"]] = ordered(base)
    return out


def x_merged_typed__mutmut_18(classical: Path, deep: Path) -> dict[str, pd.DataFrame]:
    """One matrix per carrier: the classical rows, then the neural rows of the same carrier."""
    out = {}
    for path in sorted(classical.glob("*.json")):
        base = _split(json.loads(path.read_text())["recall_mean"])
        extra = deep / path.name
        if extra.is_file():
            rows = _split(json.loads(extra.read_text())["recall_mean"])
            base = None
        out[json.loads(path.read_text())["name"]] = ordered(base)
    return out


def x_merged_typed__mutmut_19(classical: Path, deep: Path) -> dict[str, pd.DataFrame]:
    """One matrix per carrier: the classical rows, then the neural rows of the same carrier."""
    out = {}
    for path in sorted(classical.glob("*.json")):
        base = _split(json.loads(path.read_text())["recall_mean"])
        extra = deep / path.name
        if extra.is_file():
            rows = _split(json.loads(extra.read_text())["recall_mean"])
            base = pd.concat(None)
        out[json.loads(path.read_text())["name"]] = ordered(base)
    return out


def x_merged_typed__mutmut_20(classical: Path, deep: Path) -> dict[str, pd.DataFrame]:
    """One matrix per carrier: the classical rows, then the neural rows of the same carrier."""
    out = {}
    for path in sorted(classical.glob("*.json")):
        base = _split(json.loads(path.read_text())["recall_mean"])
        extra = deep / path.name
        if extra.is_file():
            rows = _split(json.loads(extra.read_text())["recall_mean"])
            base = pd.concat([base, rows.drop(index=None, errors="ignore")])
        out[json.loads(path.read_text())["name"]] = ordered(base)
    return out


def x_merged_typed__mutmut_21(classical: Path, deep: Path) -> dict[str, pd.DataFrame]:
    """One matrix per carrier: the classical rows, then the neural rows of the same carrier."""
    out = {}
    for path in sorted(classical.glob("*.json")):
        base = _split(json.loads(path.read_text())["recall_mean"])
        extra = deep / path.name
        if extra.is_file():
            rows = _split(json.loads(extra.read_text())["recall_mean"])
            base = pd.concat([base, rows.drop(index="transform_dedup", errors=None)])
        out[json.loads(path.read_text())["name"]] = ordered(base)
    return out


def x_merged_typed__mutmut_22(classical: Path, deep: Path) -> dict[str, pd.DataFrame]:
    """One matrix per carrier: the classical rows, then the neural rows of the same carrier."""
    out = {}
    for path in sorted(classical.glob("*.json")):
        base = _split(json.loads(path.read_text())["recall_mean"])
        extra = deep / path.name
        if extra.is_file():
            rows = _split(json.loads(extra.read_text())["recall_mean"])
            base = pd.concat([base, rows.drop(errors="ignore")])
        out[json.loads(path.read_text())["name"]] = ordered(base)
    return out


def x_merged_typed__mutmut_23(classical: Path, deep: Path) -> dict[str, pd.DataFrame]:
    """One matrix per carrier: the classical rows, then the neural rows of the same carrier."""
    out = {}
    for path in sorted(classical.glob("*.json")):
        base = _split(json.loads(path.read_text())["recall_mean"])
        extra = deep / path.name
        if extra.is_file():
            rows = _split(json.loads(extra.read_text())["recall_mean"])
            base = pd.concat([base, rows.drop(index="transform_dedup", )])
        out[json.loads(path.read_text())["name"]] = ordered(base)
    return out


def x_merged_typed__mutmut_24(classical: Path, deep: Path) -> dict[str, pd.DataFrame]:
    """One matrix per carrier: the classical rows, then the neural rows of the same carrier."""
    out = {}
    for path in sorted(classical.glob("*.json")):
        base = _split(json.loads(path.read_text())["recall_mean"])
        extra = deep / path.name
        if extra.is_file():
            rows = _split(json.loads(extra.read_text())["recall_mean"])
            base = pd.concat([base, rows.drop(index="XXtransform_dedupXX", errors="ignore")])
        out[json.loads(path.read_text())["name"]] = ordered(base)
    return out


def x_merged_typed__mutmut_25(classical: Path, deep: Path) -> dict[str, pd.DataFrame]:
    """One matrix per carrier: the classical rows, then the neural rows of the same carrier."""
    out = {}
    for path in sorted(classical.glob("*.json")):
        base = _split(json.loads(path.read_text())["recall_mean"])
        extra = deep / path.name
        if extra.is_file():
            rows = _split(json.loads(extra.read_text())["recall_mean"])
            base = pd.concat([base, rows.drop(index="TRANSFORM_DEDUP", errors="ignore")])
        out[json.loads(path.read_text())["name"]] = ordered(base)
    return out


def x_merged_typed__mutmut_26(classical: Path, deep: Path) -> dict[str, pd.DataFrame]:
    """One matrix per carrier: the classical rows, then the neural rows of the same carrier."""
    out = {}
    for path in sorted(classical.glob("*.json")):
        base = _split(json.loads(path.read_text())["recall_mean"])
        extra = deep / path.name
        if extra.is_file():
            rows = _split(json.loads(extra.read_text())["recall_mean"])
            base = pd.concat([base, rows.drop(index="transform_dedup", errors="XXignoreXX")])
        out[json.loads(path.read_text())["name"]] = ordered(base)
    return out


def x_merged_typed__mutmut_27(classical: Path, deep: Path) -> dict[str, pd.DataFrame]:
    """One matrix per carrier: the classical rows, then the neural rows of the same carrier."""
    out = {}
    for path in sorted(classical.glob("*.json")):
        base = _split(json.loads(path.read_text())["recall_mean"])
        extra = deep / path.name
        if extra.is_file():
            rows = _split(json.loads(extra.read_text())["recall_mean"])
            base = pd.concat([base, rows.drop(index="transform_dedup", errors="IGNORE")])
        out[json.loads(path.read_text())["name"]] = ordered(base)
    return out


def x_merged_typed__mutmut_28(classical: Path, deep: Path) -> dict[str, pd.DataFrame]:
    """One matrix per carrier: the classical rows, then the neural rows of the same carrier."""
    out = {}
    for path in sorted(classical.glob("*.json")):
        base = _split(json.loads(path.read_text())["recall_mean"])
        extra = deep / path.name
        if extra.is_file():
            rows = _split(json.loads(extra.read_text())["recall_mean"])
            base = pd.concat([base, rows.drop(index="transform_dedup", errors="ignore")])
        out[json.loads(path.read_text())["name"]] = None
    return out


def x_merged_typed__mutmut_29(classical: Path, deep: Path) -> dict[str, pd.DataFrame]:
    """One matrix per carrier: the classical rows, then the neural rows of the same carrier."""
    out = {}
    for path in sorted(classical.glob("*.json")):
        base = _split(json.loads(path.read_text())["recall_mean"])
        extra = deep / path.name
        if extra.is_file():
            rows = _split(json.loads(extra.read_text())["recall_mean"])
            base = pd.concat([base, rows.drop(index="transform_dedup", errors="ignore")])
        out[json.loads(None)["name"]] = ordered(base)
    return out


def x_merged_typed__mutmut_30(classical: Path, deep: Path) -> dict[str, pd.DataFrame]:
    """One matrix per carrier: the classical rows, then the neural rows of the same carrier."""
    out = {}
    for path in sorted(classical.glob("*.json")):
        base = _split(json.loads(path.read_text())["recall_mean"])
        extra = deep / path.name
        if extra.is_file():
            rows = _split(json.loads(extra.read_text())["recall_mean"])
            base = pd.concat([base, rows.drop(index="transform_dedup", errors="ignore")])
        out[json.loads(path.read_text())["XXnameXX"]] = ordered(base)
    return out


def x_merged_typed__mutmut_31(classical: Path, deep: Path) -> dict[str, pd.DataFrame]:
    """One matrix per carrier: the classical rows, then the neural rows of the same carrier."""
    out = {}
    for path in sorted(classical.glob("*.json")):
        base = _split(json.loads(path.read_text())["recall_mean"])
        extra = deep / path.name
        if extra.is_file():
            rows = _split(json.loads(extra.read_text())["recall_mean"])
            base = pd.concat([base, rows.drop(index="transform_dedup", errors="ignore")])
        out[json.loads(path.read_text())["NAME"]] = ordered(base)
    return out


def x_merged_typed__mutmut_32(classical: Path, deep: Path) -> dict[str, pd.DataFrame]:
    """One matrix per carrier: the classical rows, then the neural rows of the same carrier."""
    out = {}
    for path in sorted(classical.glob("*.json")):
        base = _split(json.loads(path.read_text())["recall_mean"])
        extra = deep / path.name
        if extra.is_file():
            rows = _split(json.loads(extra.read_text())["recall_mean"])
            base = pd.concat([base, rows.drop(index="transform_dedup", errors="ignore")])
        out[json.loads(path.read_text())["name"]] = ordered(None)
    return out

mutants_x_merged_typed__mutmut['_mutmut_orig'] = x_merged_typed__mutmut_orig # type: ignore # mutmut generated
mutants_x_merged_typed__mutmut['x_merged_typed__mutmut_1'] = x_merged_typed__mutmut_1 # type: ignore # mutmut generated
mutants_x_merged_typed__mutmut['x_merged_typed__mutmut_2'] = x_merged_typed__mutmut_2 # type: ignore # mutmut generated
mutants_x_merged_typed__mutmut['x_merged_typed__mutmut_3'] = x_merged_typed__mutmut_3 # type: ignore # mutmut generated
mutants_x_merged_typed__mutmut['x_merged_typed__mutmut_4'] = x_merged_typed__mutmut_4 # type: ignore # mutmut generated
mutants_x_merged_typed__mutmut['x_merged_typed__mutmut_5'] = x_merged_typed__mutmut_5 # type: ignore # mutmut generated
mutants_x_merged_typed__mutmut['x_merged_typed__mutmut_6'] = x_merged_typed__mutmut_6 # type: ignore # mutmut generated
mutants_x_merged_typed__mutmut['x_merged_typed__mutmut_7'] = x_merged_typed__mutmut_7 # type: ignore # mutmut generated
mutants_x_merged_typed__mutmut['x_merged_typed__mutmut_8'] = x_merged_typed__mutmut_8 # type: ignore # mutmut generated
mutants_x_merged_typed__mutmut['x_merged_typed__mutmut_9'] = x_merged_typed__mutmut_9 # type: ignore # mutmut generated
mutants_x_merged_typed__mutmut['x_merged_typed__mutmut_10'] = x_merged_typed__mutmut_10 # type: ignore # mutmut generated
mutants_x_merged_typed__mutmut['x_merged_typed__mutmut_11'] = x_merged_typed__mutmut_11 # type: ignore # mutmut generated
mutants_x_merged_typed__mutmut['x_merged_typed__mutmut_12'] = x_merged_typed__mutmut_12 # type: ignore # mutmut generated
mutants_x_merged_typed__mutmut['x_merged_typed__mutmut_13'] = x_merged_typed__mutmut_13 # type: ignore # mutmut generated
mutants_x_merged_typed__mutmut['x_merged_typed__mutmut_14'] = x_merged_typed__mutmut_14 # type: ignore # mutmut generated
mutants_x_merged_typed__mutmut['x_merged_typed__mutmut_15'] = x_merged_typed__mutmut_15 # type: ignore # mutmut generated
mutants_x_merged_typed__mutmut['x_merged_typed__mutmut_16'] = x_merged_typed__mutmut_16 # type: ignore # mutmut generated
mutants_x_merged_typed__mutmut['x_merged_typed__mutmut_17'] = x_merged_typed__mutmut_17 # type: ignore # mutmut generated
mutants_x_merged_typed__mutmut['x_merged_typed__mutmut_18'] = x_merged_typed__mutmut_18 # type: ignore # mutmut generated
mutants_x_merged_typed__mutmut['x_merged_typed__mutmut_19'] = x_merged_typed__mutmut_19 # type: ignore # mutmut generated
mutants_x_merged_typed__mutmut['x_merged_typed__mutmut_20'] = x_merged_typed__mutmut_20 # type: ignore # mutmut generated
mutants_x_merged_typed__mutmut['x_merged_typed__mutmut_21'] = x_merged_typed__mutmut_21 # type: ignore # mutmut generated
mutants_x_merged_typed__mutmut['x_merged_typed__mutmut_22'] = x_merged_typed__mutmut_22 # type: ignore # mutmut generated
mutants_x_merged_typed__mutmut['x_merged_typed__mutmut_23'] = x_merged_typed__mutmut_23 # type: ignore # mutmut generated
mutants_x_merged_typed__mutmut['x_merged_typed__mutmut_24'] = x_merged_typed__mutmut_24 # type: ignore # mutmut generated
mutants_x_merged_typed__mutmut['x_merged_typed__mutmut_25'] = x_merged_typed__mutmut_25 # type: ignore # mutmut generated
mutants_x_merged_typed__mutmut['x_merged_typed__mutmut_26'] = x_merged_typed__mutmut_26 # type: ignore # mutmut generated
mutants_x_merged_typed__mutmut['x_merged_typed__mutmut_27'] = x_merged_typed__mutmut_27 # type: ignore # mutmut generated
mutants_x_merged_typed__mutmut['x_merged_typed__mutmut_28'] = x_merged_typed__mutmut_28 # type: ignore # mutmut generated
mutants_x_merged_typed__mutmut['x_merged_typed__mutmut_29'] = x_merged_typed__mutmut_29 # type: ignore # mutmut generated
mutants_x_merged_typed__mutmut['x_merged_typed__mutmut_30'] = x_merged_typed__mutmut_30 # type: ignore # mutmut generated
mutants_x_merged_typed__mutmut['x_merged_typed__mutmut_31'] = x_merged_typed__mutmut_31 # type: ignore # mutmut generated
mutants_x_merged_typed__mutmut['x_merged_typed__mutmut_32'] = x_merged_typed__mutmut_32 # type: ignore # mutmut generated
mutants_x_typed_fpr__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_typed_fpr__mutmut)
def typed_fpr(classical: Path, deep: Path) -> pd.DataFrame:
    """Median and maximum over carriers of the share of clean rows each method flags."""
    columns: dict[str, list[float]] = {}
    for path in sorted(classical.glob("*.json")):
        for directory in (classical, deep):
            file = directory / path.name
            if file.is_file():
                for method, value in json.loads(file.read_text())["fpr_mean"].items():
                    columns.setdefault(method, []).append(value)
    table = pd.DataFrame(
        {m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in columns.items()}
    ).T
    return ordered(table)


def x_typed_fpr__mutmut_orig(classical: Path, deep: Path) -> pd.DataFrame:
    """Median and maximum over carriers of the share of clean rows each method flags."""
    columns: dict[str, list[float]] = {}
    for path in sorted(classical.glob("*.json")):
        for directory in (classical, deep):
            file = directory / path.name
            if file.is_file():
                for method, value in json.loads(file.read_text())["fpr_mean"].items():
                    columns.setdefault(method, []).append(value)
    table = pd.DataFrame(
        {m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in columns.items()}
    ).T
    return ordered(table)


def x_typed_fpr__mutmut_1(classical: Path, deep: Path) -> pd.DataFrame:
    """Median and maximum over carriers of the share of clean rows each method flags."""
    columns: dict[str, list[float]] = None
    for path in sorted(classical.glob("*.json")):
        for directory in (classical, deep):
            file = directory / path.name
            if file.is_file():
                for method, value in json.loads(file.read_text())["fpr_mean"].items():
                    columns.setdefault(method, []).append(value)
    table = pd.DataFrame(
        {m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in columns.items()}
    ).T
    return ordered(table)


def x_typed_fpr__mutmut_2(classical: Path, deep: Path) -> pd.DataFrame:
    """Median and maximum over carriers of the share of clean rows each method flags."""
    columns: dict[str, list[float]] = {}
    for path in sorted(None):
        for directory in (classical, deep):
            file = directory / path.name
            if file.is_file():
                for method, value in json.loads(file.read_text())["fpr_mean"].items():
                    columns.setdefault(method, []).append(value)
    table = pd.DataFrame(
        {m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in columns.items()}
    ).T
    return ordered(table)


def x_typed_fpr__mutmut_3(classical: Path, deep: Path) -> pd.DataFrame:
    """Median and maximum over carriers of the share of clean rows each method flags."""
    columns: dict[str, list[float]] = {}
    for path in sorted(classical.glob(None)):
        for directory in (classical, deep):
            file = directory / path.name
            if file.is_file():
                for method, value in json.loads(file.read_text())["fpr_mean"].items():
                    columns.setdefault(method, []).append(value)
    table = pd.DataFrame(
        {m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in columns.items()}
    ).T
    return ordered(table)


def x_typed_fpr__mutmut_4(classical: Path, deep: Path) -> pd.DataFrame:
    """Median and maximum over carriers of the share of clean rows each method flags."""
    columns: dict[str, list[float]] = {}
    for path in sorted(classical.glob("XX*.jsonXX")):
        for directory in (classical, deep):
            file = directory / path.name
            if file.is_file():
                for method, value in json.loads(file.read_text())["fpr_mean"].items():
                    columns.setdefault(method, []).append(value)
    table = pd.DataFrame(
        {m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in columns.items()}
    ).T
    return ordered(table)


def x_typed_fpr__mutmut_5(classical: Path, deep: Path) -> pd.DataFrame:
    """Median and maximum over carriers of the share of clean rows each method flags."""
    columns: dict[str, list[float]] = {}
    for path in sorted(classical.glob("*.JSON")):
        for directory in (classical, deep):
            file = directory / path.name
            if file.is_file():
                for method, value in json.loads(file.read_text())["fpr_mean"].items():
                    columns.setdefault(method, []).append(value)
    table = pd.DataFrame(
        {m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in columns.items()}
    ).T
    return ordered(table)


def x_typed_fpr__mutmut_6(classical: Path, deep: Path) -> pd.DataFrame:
    """Median and maximum over carriers of the share of clean rows each method flags."""
    columns: dict[str, list[float]] = {}
    for path in sorted(classical.glob("*.json")):
        for directory in (classical, deep):
            file = None
            if file.is_file():
                for method, value in json.loads(file.read_text())["fpr_mean"].items():
                    columns.setdefault(method, []).append(value)
    table = pd.DataFrame(
        {m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in columns.items()}
    ).T
    return ordered(table)


def x_typed_fpr__mutmut_7(classical: Path, deep: Path) -> pd.DataFrame:
    """Median and maximum over carriers of the share of clean rows each method flags."""
    columns: dict[str, list[float]] = {}
    for path in sorted(classical.glob("*.json")):
        for directory in (classical, deep):
            file = directory * path.name
            if file.is_file():
                for method, value in json.loads(file.read_text())["fpr_mean"].items():
                    columns.setdefault(method, []).append(value)
    table = pd.DataFrame(
        {m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in columns.items()}
    ).T
    return ordered(table)


def x_typed_fpr__mutmut_8(classical: Path, deep: Path) -> pd.DataFrame:
    """Median and maximum over carriers of the share of clean rows each method flags."""
    columns: dict[str, list[float]] = {}
    for path in sorted(classical.glob("*.json")):
        for directory in (classical, deep):
            file = directory / path.name
            if file.is_file():
                for method, value in json.loads(None)["fpr_mean"].items():
                    columns.setdefault(method, []).append(value)
    table = pd.DataFrame(
        {m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in columns.items()}
    ).T
    return ordered(table)


def x_typed_fpr__mutmut_9(classical: Path, deep: Path) -> pd.DataFrame:
    """Median and maximum over carriers of the share of clean rows each method flags."""
    columns: dict[str, list[float]] = {}
    for path in sorted(classical.glob("*.json")):
        for directory in (classical, deep):
            file = directory / path.name
            if file.is_file():
                for method, value in json.loads(file.read_text())["XXfpr_meanXX"].items():
                    columns.setdefault(method, []).append(value)
    table = pd.DataFrame(
        {m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in columns.items()}
    ).T
    return ordered(table)


def x_typed_fpr__mutmut_10(classical: Path, deep: Path) -> pd.DataFrame:
    """Median and maximum over carriers of the share of clean rows each method flags."""
    columns: dict[str, list[float]] = {}
    for path in sorted(classical.glob("*.json")):
        for directory in (classical, deep):
            file = directory / path.name
            if file.is_file():
                for method, value in json.loads(file.read_text())["FPR_MEAN"].items():
                    columns.setdefault(method, []).append(value)
    table = pd.DataFrame(
        {m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in columns.items()}
    ).T
    return ordered(table)


def x_typed_fpr__mutmut_11(classical: Path, deep: Path) -> pd.DataFrame:
    """Median and maximum over carriers of the share of clean rows each method flags."""
    columns: dict[str, list[float]] = {}
    for path in sorted(classical.glob("*.json")):
        for directory in (classical, deep):
            file = directory / path.name
            if file.is_file():
                for method, value in json.loads(file.read_text())["fpr_mean"].items():
                    columns.setdefault(method, []).append(None)
    table = pd.DataFrame(
        {m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in columns.items()}
    ).T
    return ordered(table)


def x_typed_fpr__mutmut_12(classical: Path, deep: Path) -> pd.DataFrame:
    """Median and maximum over carriers of the share of clean rows each method flags."""
    columns: dict[str, list[float]] = {}
    for path in sorted(classical.glob("*.json")):
        for directory in (classical, deep):
            file = directory / path.name
            if file.is_file():
                for method, value in json.loads(file.read_text())["fpr_mean"].items():
                    columns.setdefault(None, []).append(value)
    table = pd.DataFrame(
        {m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in columns.items()}
    ).T
    return ordered(table)


def x_typed_fpr__mutmut_13(classical: Path, deep: Path) -> pd.DataFrame:
    """Median and maximum over carriers of the share of clean rows each method flags."""
    columns: dict[str, list[float]] = {}
    for path in sorted(classical.glob("*.json")):
        for directory in (classical, deep):
            file = directory / path.name
            if file.is_file():
                for method, value in json.loads(file.read_text())["fpr_mean"].items():
                    columns.setdefault(method, None).append(value)
    table = pd.DataFrame(
        {m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in columns.items()}
    ).T
    return ordered(table)


def x_typed_fpr__mutmut_14(classical: Path, deep: Path) -> pd.DataFrame:
    """Median and maximum over carriers of the share of clean rows each method flags."""
    columns: dict[str, list[float]] = {}
    for path in sorted(classical.glob("*.json")):
        for directory in (classical, deep):
            file = directory / path.name
            if file.is_file():
                for method, value in json.loads(file.read_text())["fpr_mean"].items():
                    columns.setdefault([]).append(value)
    table = pd.DataFrame(
        {m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in columns.items()}
    ).T
    return ordered(table)


def x_typed_fpr__mutmut_15(classical: Path, deep: Path) -> pd.DataFrame:
    """Median and maximum over carriers of the share of clean rows each method flags."""
    columns: dict[str, list[float]] = {}
    for path in sorted(classical.glob("*.json")):
        for directory in (classical, deep):
            file = directory / path.name
            if file.is_file():
                for method, value in json.loads(file.read_text())["fpr_mean"].items():
                    columns.setdefault(method, ).append(value)
    table = pd.DataFrame(
        {m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in columns.items()}
    ).T
    return ordered(table)


def x_typed_fpr__mutmut_16(classical: Path, deep: Path) -> pd.DataFrame:
    """Median and maximum over carriers of the share of clean rows each method flags."""
    columns: dict[str, list[float]] = {}
    for path in sorted(classical.glob("*.json")):
        for directory in (classical, deep):
            file = directory / path.name
            if file.is_file():
                for method, value in json.loads(file.read_text())["fpr_mean"].items():
                    columns.setdefault(method, []).append(value)
    table = None
    return ordered(table)


def x_typed_fpr__mutmut_17(classical: Path, deep: Path) -> pd.DataFrame:
    """Median and maximum over carriers of the share of clean rows each method flags."""
    columns: dict[str, list[float]] = {}
    for path in sorted(classical.glob("*.json")):
        for directory in (classical, deep):
            file = directory / path.name
            if file.is_file():
                for method, value in json.loads(file.read_text())["fpr_mean"].items():
                    columns.setdefault(method, []).append(value)
    table = pd.DataFrame(
        None
    ).T
    return ordered(table)


def x_typed_fpr__mutmut_18(classical: Path, deep: Path) -> pd.DataFrame:
    """Median and maximum over carriers of the share of clean rows each method flags."""
    columns: dict[str, list[float]] = {}
    for path in sorted(classical.glob("*.json")):
        for directory in (classical, deep):
            file = directory / path.name
            if file.is_file():
                for method, value in json.loads(file.read_text())["fpr_mean"].items():
                    columns.setdefault(method, []).append(value)
    table = pd.DataFrame(
        {m: {"XXmedianXX": float(np.median(v)), "max": float(np.max(v))} for m, v in columns.items()}
    ).T
    return ordered(table)


def x_typed_fpr__mutmut_19(classical: Path, deep: Path) -> pd.DataFrame:
    """Median and maximum over carriers of the share of clean rows each method flags."""
    columns: dict[str, list[float]] = {}
    for path in sorted(classical.glob("*.json")):
        for directory in (classical, deep):
            file = directory / path.name
            if file.is_file():
                for method, value in json.loads(file.read_text())["fpr_mean"].items():
                    columns.setdefault(method, []).append(value)
    table = pd.DataFrame(
        {m: {"MEDIAN": float(np.median(v)), "max": float(np.max(v))} for m, v in columns.items()}
    ).T
    return ordered(table)


def x_typed_fpr__mutmut_20(classical: Path, deep: Path) -> pd.DataFrame:
    """Median and maximum over carriers of the share of clean rows each method flags."""
    columns: dict[str, list[float]] = {}
    for path in sorted(classical.glob("*.json")):
        for directory in (classical, deep):
            file = directory / path.name
            if file.is_file():
                for method, value in json.loads(file.read_text())["fpr_mean"].items():
                    columns.setdefault(method, []).append(value)
    table = pd.DataFrame(
        {m: {"median": float(None), "max": float(np.max(v))} for m, v in columns.items()}
    ).T
    return ordered(table)


def x_typed_fpr__mutmut_21(classical: Path, deep: Path) -> pd.DataFrame:
    """Median and maximum over carriers of the share of clean rows each method flags."""
    columns: dict[str, list[float]] = {}
    for path in sorted(classical.glob("*.json")):
        for directory in (classical, deep):
            file = directory / path.name
            if file.is_file():
                for method, value in json.loads(file.read_text())["fpr_mean"].items():
                    columns.setdefault(method, []).append(value)
    table = pd.DataFrame(
        {m: {"median": float(np.median(None)), "max": float(np.max(v))} for m, v in columns.items()}
    ).T
    return ordered(table)


def x_typed_fpr__mutmut_22(classical: Path, deep: Path) -> pd.DataFrame:
    """Median and maximum over carriers of the share of clean rows each method flags."""
    columns: dict[str, list[float]] = {}
    for path in sorted(classical.glob("*.json")):
        for directory in (classical, deep):
            file = directory / path.name
            if file.is_file():
                for method, value in json.loads(file.read_text())["fpr_mean"].items():
                    columns.setdefault(method, []).append(value)
    table = pd.DataFrame(
        {m: {"median": float(np.median(v)), "XXmaxXX": float(np.max(v))} for m, v in columns.items()}
    ).T
    return ordered(table)


def x_typed_fpr__mutmut_23(classical: Path, deep: Path) -> pd.DataFrame:
    """Median and maximum over carriers of the share of clean rows each method flags."""
    columns: dict[str, list[float]] = {}
    for path in sorted(classical.glob("*.json")):
        for directory in (classical, deep):
            file = directory / path.name
            if file.is_file():
                for method, value in json.loads(file.read_text())["fpr_mean"].items():
                    columns.setdefault(method, []).append(value)
    table = pd.DataFrame(
        {m: {"median": float(np.median(v)), "MAX": float(np.max(v))} for m, v in columns.items()}
    ).T
    return ordered(table)


def x_typed_fpr__mutmut_24(classical: Path, deep: Path) -> pd.DataFrame:
    """Median and maximum over carriers of the share of clean rows each method flags."""
    columns: dict[str, list[float]] = {}
    for path in sorted(classical.glob("*.json")):
        for directory in (classical, deep):
            file = directory / path.name
            if file.is_file():
                for method, value in json.loads(file.read_text())["fpr_mean"].items():
                    columns.setdefault(method, []).append(value)
    table = pd.DataFrame(
        {m: {"median": float(np.median(v)), "max": float(None)} for m, v in columns.items()}
    ).T
    return ordered(table)


def x_typed_fpr__mutmut_25(classical: Path, deep: Path) -> pd.DataFrame:
    """Median and maximum over carriers of the share of clean rows each method flags."""
    columns: dict[str, list[float]] = {}
    for path in sorted(classical.glob("*.json")):
        for directory in (classical, deep):
            file = directory / path.name
            if file.is_file():
                for method, value in json.loads(file.read_text())["fpr_mean"].items():
                    columns.setdefault(method, []).append(value)
    table = pd.DataFrame(
        {m: {"median": float(np.median(v)), "max": float(np.max(None))} for m, v in columns.items()}
    ).T
    return ordered(table)


def x_typed_fpr__mutmut_26(classical: Path, deep: Path) -> pd.DataFrame:
    """Median and maximum over carriers of the share of clean rows each method flags."""
    columns: dict[str, list[float]] = {}
    for path in sorted(classical.glob("*.json")):
        for directory in (classical, deep):
            file = directory / path.name
            if file.is_file():
                for method, value in json.loads(file.read_text())["fpr_mean"].items():
                    columns.setdefault(method, []).append(value)
    table = pd.DataFrame(
        {m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in columns.items()}
    ).T
    return ordered(None)

mutants_x_typed_fpr__mutmut['_mutmut_orig'] = x_typed_fpr__mutmut_orig # type: ignore # mutmut generated
mutants_x_typed_fpr__mutmut['x_typed_fpr__mutmut_1'] = x_typed_fpr__mutmut_1 # type: ignore # mutmut generated
mutants_x_typed_fpr__mutmut['x_typed_fpr__mutmut_2'] = x_typed_fpr__mutmut_2 # type: ignore # mutmut generated
mutants_x_typed_fpr__mutmut['x_typed_fpr__mutmut_3'] = x_typed_fpr__mutmut_3 # type: ignore # mutmut generated
mutants_x_typed_fpr__mutmut['x_typed_fpr__mutmut_4'] = x_typed_fpr__mutmut_4 # type: ignore # mutmut generated
mutants_x_typed_fpr__mutmut['x_typed_fpr__mutmut_5'] = x_typed_fpr__mutmut_5 # type: ignore # mutmut generated
mutants_x_typed_fpr__mutmut['x_typed_fpr__mutmut_6'] = x_typed_fpr__mutmut_6 # type: ignore # mutmut generated
mutants_x_typed_fpr__mutmut['x_typed_fpr__mutmut_7'] = x_typed_fpr__mutmut_7 # type: ignore # mutmut generated
mutants_x_typed_fpr__mutmut['x_typed_fpr__mutmut_8'] = x_typed_fpr__mutmut_8 # type: ignore # mutmut generated
mutants_x_typed_fpr__mutmut['x_typed_fpr__mutmut_9'] = x_typed_fpr__mutmut_9 # type: ignore # mutmut generated
mutants_x_typed_fpr__mutmut['x_typed_fpr__mutmut_10'] = x_typed_fpr__mutmut_10 # type: ignore # mutmut generated
mutants_x_typed_fpr__mutmut['x_typed_fpr__mutmut_11'] = x_typed_fpr__mutmut_11 # type: ignore # mutmut generated
mutants_x_typed_fpr__mutmut['x_typed_fpr__mutmut_12'] = x_typed_fpr__mutmut_12 # type: ignore # mutmut generated
mutants_x_typed_fpr__mutmut['x_typed_fpr__mutmut_13'] = x_typed_fpr__mutmut_13 # type: ignore # mutmut generated
mutants_x_typed_fpr__mutmut['x_typed_fpr__mutmut_14'] = x_typed_fpr__mutmut_14 # type: ignore # mutmut generated
mutants_x_typed_fpr__mutmut['x_typed_fpr__mutmut_15'] = x_typed_fpr__mutmut_15 # type: ignore # mutmut generated
mutants_x_typed_fpr__mutmut['x_typed_fpr__mutmut_16'] = x_typed_fpr__mutmut_16 # type: ignore # mutmut generated
mutants_x_typed_fpr__mutmut['x_typed_fpr__mutmut_17'] = x_typed_fpr__mutmut_17 # type: ignore # mutmut generated
mutants_x_typed_fpr__mutmut['x_typed_fpr__mutmut_18'] = x_typed_fpr__mutmut_18 # type: ignore # mutmut generated
mutants_x_typed_fpr__mutmut['x_typed_fpr__mutmut_19'] = x_typed_fpr__mutmut_19 # type: ignore # mutmut generated
mutants_x_typed_fpr__mutmut['x_typed_fpr__mutmut_20'] = x_typed_fpr__mutmut_20 # type: ignore # mutmut generated
mutants_x_typed_fpr__mutmut['x_typed_fpr__mutmut_21'] = x_typed_fpr__mutmut_21 # type: ignore # mutmut generated
mutants_x_typed_fpr__mutmut['x_typed_fpr__mutmut_22'] = x_typed_fpr__mutmut_22 # type: ignore # mutmut generated
mutants_x_typed_fpr__mutmut['x_typed_fpr__mutmut_23'] = x_typed_fpr__mutmut_23 # type: ignore # mutmut generated
mutants_x_typed_fpr__mutmut['x_typed_fpr__mutmut_24'] = x_typed_fpr__mutmut_24 # type: ignore # mutmut generated
mutants_x_typed_fpr__mutmut['x_typed_fpr__mutmut_25'] = x_typed_fpr__mutmut_25 # type: ignore # mutmut generated
mutants_x_typed_fpr__mutmut['x_typed_fpr__mutmut_26'] = x_typed_fpr__mutmut_26 # type: ignore # mutmut generated
mutants_x__merge_fpr__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x__merge_fpr__mutmut)
def _merge_fpr(evidence: Path, out: Path, extra: Path) -> pd.DataFrame:
    """Clean-row flag rate over the UCI carriers and the ADBench ones together."""
    columns: dict[str, list[float]] = {}
    for classical, deep in (
        (evidence / "typed_injection" / "runs", out / "typed_deep" / "runs"),
        (extra / "reference_classical", extra / "reference_deep"),
    ):
        for path in sorted(classical.glob("*.json")):
            for folder in (classical, deep):
                file = folder / path.name
                if file.is_file():
                    for method, value in json.loads(file.read_text())["fpr_mean"].items():
                        columns.setdefault(method, []).append(value)
    table = pd.DataFrame(
        {m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in columns.items()}
    ).T
    return ordered(table)


def x__merge_fpr__mutmut_orig(evidence: Path, out: Path, extra: Path) -> pd.DataFrame:
    """Clean-row flag rate over the UCI carriers and the ADBench ones together."""
    columns: dict[str, list[float]] = {}
    for classical, deep in (
        (evidence / "typed_injection" / "runs", out / "typed_deep" / "runs"),
        (extra / "reference_classical", extra / "reference_deep"),
    ):
        for path in sorted(classical.glob("*.json")):
            for folder in (classical, deep):
                file = folder / path.name
                if file.is_file():
                    for method, value in json.loads(file.read_text())["fpr_mean"].items():
                        columns.setdefault(method, []).append(value)
    table = pd.DataFrame(
        {m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in columns.items()}
    ).T
    return ordered(table)


def x__merge_fpr__mutmut_1(evidence: Path, out: Path, extra: Path) -> pd.DataFrame:
    """Clean-row flag rate over the UCI carriers and the ADBench ones together."""
    columns: dict[str, list[float]] = None
    for classical, deep in (
        (evidence / "typed_injection" / "runs", out / "typed_deep" / "runs"),
        (extra / "reference_classical", extra / "reference_deep"),
    ):
        for path in sorted(classical.glob("*.json")):
            for folder in (classical, deep):
                file = folder / path.name
                if file.is_file():
                    for method, value in json.loads(file.read_text())["fpr_mean"].items():
                        columns.setdefault(method, []).append(value)
    table = pd.DataFrame(
        {m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in columns.items()}
    ).T
    return ordered(table)


def x__merge_fpr__mutmut_2(evidence: Path, out: Path, extra: Path) -> pd.DataFrame:
    """Clean-row flag rate over the UCI carriers and the ADBench ones together."""
    columns: dict[str, list[float]] = {}
    for classical, deep in (
        (evidence / "typed_injection" * "runs", out / "typed_deep" / "runs"),
        (extra / "reference_classical", extra / "reference_deep"),
    ):
        for path in sorted(classical.glob("*.json")):
            for folder in (classical, deep):
                file = folder / path.name
                if file.is_file():
                    for method, value in json.loads(file.read_text())["fpr_mean"].items():
                        columns.setdefault(method, []).append(value)
    table = pd.DataFrame(
        {m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in columns.items()}
    ).T
    return ordered(table)


def x__merge_fpr__mutmut_3(evidence: Path, out: Path, extra: Path) -> pd.DataFrame:
    """Clean-row flag rate over the UCI carriers and the ADBench ones together."""
    columns: dict[str, list[float]] = {}
    for classical, deep in (
        (evidence * "typed_injection" / "runs", out / "typed_deep" / "runs"),
        (extra / "reference_classical", extra / "reference_deep"),
    ):
        for path in sorted(classical.glob("*.json")):
            for folder in (classical, deep):
                file = folder / path.name
                if file.is_file():
                    for method, value in json.loads(file.read_text())["fpr_mean"].items():
                        columns.setdefault(method, []).append(value)
    table = pd.DataFrame(
        {m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in columns.items()}
    ).T
    return ordered(table)


def x__merge_fpr__mutmut_4(evidence: Path, out: Path, extra: Path) -> pd.DataFrame:
    """Clean-row flag rate over the UCI carriers and the ADBench ones together."""
    columns: dict[str, list[float]] = {}
    for classical, deep in (
        (evidence / "XXtyped_injectionXX" / "runs", out / "typed_deep" / "runs"),
        (extra / "reference_classical", extra / "reference_deep"),
    ):
        for path in sorted(classical.glob("*.json")):
            for folder in (classical, deep):
                file = folder / path.name
                if file.is_file():
                    for method, value in json.loads(file.read_text())["fpr_mean"].items():
                        columns.setdefault(method, []).append(value)
    table = pd.DataFrame(
        {m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in columns.items()}
    ).T
    return ordered(table)


def x__merge_fpr__mutmut_5(evidence: Path, out: Path, extra: Path) -> pd.DataFrame:
    """Clean-row flag rate over the UCI carriers and the ADBench ones together."""
    columns: dict[str, list[float]] = {}
    for classical, deep in (
        (evidence / "TYPED_INJECTION" / "runs", out / "typed_deep" / "runs"),
        (extra / "reference_classical", extra / "reference_deep"),
    ):
        for path in sorted(classical.glob("*.json")):
            for folder in (classical, deep):
                file = folder / path.name
                if file.is_file():
                    for method, value in json.loads(file.read_text())["fpr_mean"].items():
                        columns.setdefault(method, []).append(value)
    table = pd.DataFrame(
        {m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in columns.items()}
    ).T
    return ordered(table)


def x__merge_fpr__mutmut_6(evidence: Path, out: Path, extra: Path) -> pd.DataFrame:
    """Clean-row flag rate over the UCI carriers and the ADBench ones together."""
    columns: dict[str, list[float]] = {}
    for classical, deep in (
        (evidence / "typed_injection" / "XXrunsXX", out / "typed_deep" / "runs"),
        (extra / "reference_classical", extra / "reference_deep"),
    ):
        for path in sorted(classical.glob("*.json")):
            for folder in (classical, deep):
                file = folder / path.name
                if file.is_file():
                    for method, value in json.loads(file.read_text())["fpr_mean"].items():
                        columns.setdefault(method, []).append(value)
    table = pd.DataFrame(
        {m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in columns.items()}
    ).T
    return ordered(table)


def x__merge_fpr__mutmut_7(evidence: Path, out: Path, extra: Path) -> pd.DataFrame:
    """Clean-row flag rate over the UCI carriers and the ADBench ones together."""
    columns: dict[str, list[float]] = {}
    for classical, deep in (
        (evidence / "typed_injection" / "RUNS", out / "typed_deep" / "runs"),
        (extra / "reference_classical", extra / "reference_deep"),
    ):
        for path in sorted(classical.glob("*.json")):
            for folder in (classical, deep):
                file = folder / path.name
                if file.is_file():
                    for method, value in json.loads(file.read_text())["fpr_mean"].items():
                        columns.setdefault(method, []).append(value)
    table = pd.DataFrame(
        {m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in columns.items()}
    ).T
    return ordered(table)


def x__merge_fpr__mutmut_8(evidence: Path, out: Path, extra: Path) -> pd.DataFrame:
    """Clean-row flag rate over the UCI carriers and the ADBench ones together."""
    columns: dict[str, list[float]] = {}
    for classical, deep in (
        (evidence / "typed_injection" / "runs", out / "typed_deep" * "runs"),
        (extra / "reference_classical", extra / "reference_deep"),
    ):
        for path in sorted(classical.glob("*.json")):
            for folder in (classical, deep):
                file = folder / path.name
                if file.is_file():
                    for method, value in json.loads(file.read_text())["fpr_mean"].items():
                        columns.setdefault(method, []).append(value)
    table = pd.DataFrame(
        {m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in columns.items()}
    ).T
    return ordered(table)


def x__merge_fpr__mutmut_9(evidence: Path, out: Path, extra: Path) -> pd.DataFrame:
    """Clean-row flag rate over the UCI carriers and the ADBench ones together."""
    columns: dict[str, list[float]] = {}
    for classical, deep in (
        (evidence / "typed_injection" / "runs", out * "typed_deep" / "runs"),
        (extra / "reference_classical", extra / "reference_deep"),
    ):
        for path in sorted(classical.glob("*.json")):
            for folder in (classical, deep):
                file = folder / path.name
                if file.is_file():
                    for method, value in json.loads(file.read_text())["fpr_mean"].items():
                        columns.setdefault(method, []).append(value)
    table = pd.DataFrame(
        {m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in columns.items()}
    ).T
    return ordered(table)


def x__merge_fpr__mutmut_10(evidence: Path, out: Path, extra: Path) -> pd.DataFrame:
    """Clean-row flag rate over the UCI carriers and the ADBench ones together."""
    columns: dict[str, list[float]] = {}
    for classical, deep in (
        (evidence / "typed_injection" / "runs", out / "XXtyped_deepXX" / "runs"),
        (extra / "reference_classical", extra / "reference_deep"),
    ):
        for path in sorted(classical.glob("*.json")):
            for folder in (classical, deep):
                file = folder / path.name
                if file.is_file():
                    for method, value in json.loads(file.read_text())["fpr_mean"].items():
                        columns.setdefault(method, []).append(value)
    table = pd.DataFrame(
        {m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in columns.items()}
    ).T
    return ordered(table)


def x__merge_fpr__mutmut_11(evidence: Path, out: Path, extra: Path) -> pd.DataFrame:
    """Clean-row flag rate over the UCI carriers and the ADBench ones together."""
    columns: dict[str, list[float]] = {}
    for classical, deep in (
        (evidence / "typed_injection" / "runs", out / "TYPED_DEEP" / "runs"),
        (extra / "reference_classical", extra / "reference_deep"),
    ):
        for path in sorted(classical.glob("*.json")):
            for folder in (classical, deep):
                file = folder / path.name
                if file.is_file():
                    for method, value in json.loads(file.read_text())["fpr_mean"].items():
                        columns.setdefault(method, []).append(value)
    table = pd.DataFrame(
        {m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in columns.items()}
    ).T
    return ordered(table)


def x__merge_fpr__mutmut_12(evidence: Path, out: Path, extra: Path) -> pd.DataFrame:
    """Clean-row flag rate over the UCI carriers and the ADBench ones together."""
    columns: dict[str, list[float]] = {}
    for classical, deep in (
        (evidence / "typed_injection" / "runs", out / "typed_deep" / "XXrunsXX"),
        (extra / "reference_classical", extra / "reference_deep"),
    ):
        for path in sorted(classical.glob("*.json")):
            for folder in (classical, deep):
                file = folder / path.name
                if file.is_file():
                    for method, value in json.loads(file.read_text())["fpr_mean"].items():
                        columns.setdefault(method, []).append(value)
    table = pd.DataFrame(
        {m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in columns.items()}
    ).T
    return ordered(table)


def x__merge_fpr__mutmut_13(evidence: Path, out: Path, extra: Path) -> pd.DataFrame:
    """Clean-row flag rate over the UCI carriers and the ADBench ones together."""
    columns: dict[str, list[float]] = {}
    for classical, deep in (
        (evidence / "typed_injection" / "runs", out / "typed_deep" / "RUNS"),
        (extra / "reference_classical", extra / "reference_deep"),
    ):
        for path in sorted(classical.glob("*.json")):
            for folder in (classical, deep):
                file = folder / path.name
                if file.is_file():
                    for method, value in json.loads(file.read_text())["fpr_mean"].items():
                        columns.setdefault(method, []).append(value)
    table = pd.DataFrame(
        {m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in columns.items()}
    ).T
    return ordered(table)


def x__merge_fpr__mutmut_14(evidence: Path, out: Path, extra: Path) -> pd.DataFrame:
    """Clean-row flag rate over the UCI carriers and the ADBench ones together."""
    columns: dict[str, list[float]] = {}
    for classical, deep in (
        (evidence / "typed_injection" / "runs", out / "typed_deep" / "runs"),
        (extra * "reference_classical", extra / "reference_deep"),
    ):
        for path in sorted(classical.glob("*.json")):
            for folder in (classical, deep):
                file = folder / path.name
                if file.is_file():
                    for method, value in json.loads(file.read_text())["fpr_mean"].items():
                        columns.setdefault(method, []).append(value)
    table = pd.DataFrame(
        {m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in columns.items()}
    ).T
    return ordered(table)


def x__merge_fpr__mutmut_15(evidence: Path, out: Path, extra: Path) -> pd.DataFrame:
    """Clean-row flag rate over the UCI carriers and the ADBench ones together."""
    columns: dict[str, list[float]] = {}
    for classical, deep in (
        (evidence / "typed_injection" / "runs", out / "typed_deep" / "runs"),
        (extra / "XXreference_classicalXX", extra / "reference_deep"),
    ):
        for path in sorted(classical.glob("*.json")):
            for folder in (classical, deep):
                file = folder / path.name
                if file.is_file():
                    for method, value in json.loads(file.read_text())["fpr_mean"].items():
                        columns.setdefault(method, []).append(value)
    table = pd.DataFrame(
        {m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in columns.items()}
    ).T
    return ordered(table)


def x__merge_fpr__mutmut_16(evidence: Path, out: Path, extra: Path) -> pd.DataFrame:
    """Clean-row flag rate over the UCI carriers and the ADBench ones together."""
    columns: dict[str, list[float]] = {}
    for classical, deep in (
        (evidence / "typed_injection" / "runs", out / "typed_deep" / "runs"),
        (extra / "REFERENCE_CLASSICAL", extra / "reference_deep"),
    ):
        for path in sorted(classical.glob("*.json")):
            for folder in (classical, deep):
                file = folder / path.name
                if file.is_file():
                    for method, value in json.loads(file.read_text())["fpr_mean"].items():
                        columns.setdefault(method, []).append(value)
    table = pd.DataFrame(
        {m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in columns.items()}
    ).T
    return ordered(table)


def x__merge_fpr__mutmut_17(evidence: Path, out: Path, extra: Path) -> pd.DataFrame:
    """Clean-row flag rate over the UCI carriers and the ADBench ones together."""
    columns: dict[str, list[float]] = {}
    for classical, deep in (
        (evidence / "typed_injection" / "runs", out / "typed_deep" / "runs"),
        (extra / "reference_classical", extra * "reference_deep"),
    ):
        for path in sorted(classical.glob("*.json")):
            for folder in (classical, deep):
                file = folder / path.name
                if file.is_file():
                    for method, value in json.loads(file.read_text())["fpr_mean"].items():
                        columns.setdefault(method, []).append(value)
    table = pd.DataFrame(
        {m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in columns.items()}
    ).T
    return ordered(table)


def x__merge_fpr__mutmut_18(evidence: Path, out: Path, extra: Path) -> pd.DataFrame:
    """Clean-row flag rate over the UCI carriers and the ADBench ones together."""
    columns: dict[str, list[float]] = {}
    for classical, deep in (
        (evidence / "typed_injection" / "runs", out / "typed_deep" / "runs"),
        (extra / "reference_classical", extra / "XXreference_deepXX"),
    ):
        for path in sorted(classical.glob("*.json")):
            for folder in (classical, deep):
                file = folder / path.name
                if file.is_file():
                    for method, value in json.loads(file.read_text())["fpr_mean"].items():
                        columns.setdefault(method, []).append(value)
    table = pd.DataFrame(
        {m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in columns.items()}
    ).T
    return ordered(table)


def x__merge_fpr__mutmut_19(evidence: Path, out: Path, extra: Path) -> pd.DataFrame:
    """Clean-row flag rate over the UCI carriers and the ADBench ones together."""
    columns: dict[str, list[float]] = {}
    for classical, deep in (
        (evidence / "typed_injection" / "runs", out / "typed_deep" / "runs"),
        (extra / "reference_classical", extra / "REFERENCE_DEEP"),
    ):
        for path in sorted(classical.glob("*.json")):
            for folder in (classical, deep):
                file = folder / path.name
                if file.is_file():
                    for method, value in json.loads(file.read_text())["fpr_mean"].items():
                        columns.setdefault(method, []).append(value)
    table = pd.DataFrame(
        {m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in columns.items()}
    ).T
    return ordered(table)


def x__merge_fpr__mutmut_20(evidence: Path, out: Path, extra: Path) -> pd.DataFrame:
    """Clean-row flag rate over the UCI carriers and the ADBench ones together."""
    columns: dict[str, list[float]] = {}
    for classical, deep in (
        (evidence / "typed_injection" / "runs", out / "typed_deep" / "runs"),
        (extra / "reference_classical", extra / "reference_deep"),
    ):
        for path in sorted(None):
            for folder in (classical, deep):
                file = folder / path.name
                if file.is_file():
                    for method, value in json.loads(file.read_text())["fpr_mean"].items():
                        columns.setdefault(method, []).append(value)
    table = pd.DataFrame(
        {m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in columns.items()}
    ).T
    return ordered(table)


def x__merge_fpr__mutmut_21(evidence: Path, out: Path, extra: Path) -> pd.DataFrame:
    """Clean-row flag rate over the UCI carriers and the ADBench ones together."""
    columns: dict[str, list[float]] = {}
    for classical, deep in (
        (evidence / "typed_injection" / "runs", out / "typed_deep" / "runs"),
        (extra / "reference_classical", extra / "reference_deep"),
    ):
        for path in sorted(classical.glob(None)):
            for folder in (classical, deep):
                file = folder / path.name
                if file.is_file():
                    for method, value in json.loads(file.read_text())["fpr_mean"].items():
                        columns.setdefault(method, []).append(value)
    table = pd.DataFrame(
        {m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in columns.items()}
    ).T
    return ordered(table)


def x__merge_fpr__mutmut_22(evidence: Path, out: Path, extra: Path) -> pd.DataFrame:
    """Clean-row flag rate over the UCI carriers and the ADBench ones together."""
    columns: dict[str, list[float]] = {}
    for classical, deep in (
        (evidence / "typed_injection" / "runs", out / "typed_deep" / "runs"),
        (extra / "reference_classical", extra / "reference_deep"),
    ):
        for path in sorted(classical.glob("XX*.jsonXX")):
            for folder in (classical, deep):
                file = folder / path.name
                if file.is_file():
                    for method, value in json.loads(file.read_text())["fpr_mean"].items():
                        columns.setdefault(method, []).append(value)
    table = pd.DataFrame(
        {m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in columns.items()}
    ).T
    return ordered(table)


def x__merge_fpr__mutmut_23(evidence: Path, out: Path, extra: Path) -> pd.DataFrame:
    """Clean-row flag rate over the UCI carriers and the ADBench ones together."""
    columns: dict[str, list[float]] = {}
    for classical, deep in (
        (evidence / "typed_injection" / "runs", out / "typed_deep" / "runs"),
        (extra / "reference_classical", extra / "reference_deep"),
    ):
        for path in sorted(classical.glob("*.JSON")):
            for folder in (classical, deep):
                file = folder / path.name
                if file.is_file():
                    for method, value in json.loads(file.read_text())["fpr_mean"].items():
                        columns.setdefault(method, []).append(value)
    table = pd.DataFrame(
        {m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in columns.items()}
    ).T
    return ordered(table)


def x__merge_fpr__mutmut_24(evidence: Path, out: Path, extra: Path) -> pd.DataFrame:
    """Clean-row flag rate over the UCI carriers and the ADBench ones together."""
    columns: dict[str, list[float]] = {}
    for classical, deep in (
        (evidence / "typed_injection" / "runs", out / "typed_deep" / "runs"),
        (extra / "reference_classical", extra / "reference_deep"),
    ):
        for path in sorted(classical.glob("*.json")):
            for folder in (classical, deep):
                file = None
                if file.is_file():
                    for method, value in json.loads(file.read_text())["fpr_mean"].items():
                        columns.setdefault(method, []).append(value)
    table = pd.DataFrame(
        {m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in columns.items()}
    ).T
    return ordered(table)


def x__merge_fpr__mutmut_25(evidence: Path, out: Path, extra: Path) -> pd.DataFrame:
    """Clean-row flag rate over the UCI carriers and the ADBench ones together."""
    columns: dict[str, list[float]] = {}
    for classical, deep in (
        (evidence / "typed_injection" / "runs", out / "typed_deep" / "runs"),
        (extra / "reference_classical", extra / "reference_deep"),
    ):
        for path in sorted(classical.glob("*.json")):
            for folder in (classical, deep):
                file = folder * path.name
                if file.is_file():
                    for method, value in json.loads(file.read_text())["fpr_mean"].items():
                        columns.setdefault(method, []).append(value)
    table = pd.DataFrame(
        {m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in columns.items()}
    ).T
    return ordered(table)


def x__merge_fpr__mutmut_26(evidence: Path, out: Path, extra: Path) -> pd.DataFrame:
    """Clean-row flag rate over the UCI carriers and the ADBench ones together."""
    columns: dict[str, list[float]] = {}
    for classical, deep in (
        (evidence / "typed_injection" / "runs", out / "typed_deep" / "runs"),
        (extra / "reference_classical", extra / "reference_deep"),
    ):
        for path in sorted(classical.glob("*.json")):
            for folder in (classical, deep):
                file = folder / path.name
                if file.is_file():
                    for method, value in json.loads(None)["fpr_mean"].items():
                        columns.setdefault(method, []).append(value)
    table = pd.DataFrame(
        {m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in columns.items()}
    ).T
    return ordered(table)


def x__merge_fpr__mutmut_27(evidence: Path, out: Path, extra: Path) -> pd.DataFrame:
    """Clean-row flag rate over the UCI carriers and the ADBench ones together."""
    columns: dict[str, list[float]] = {}
    for classical, deep in (
        (evidence / "typed_injection" / "runs", out / "typed_deep" / "runs"),
        (extra / "reference_classical", extra / "reference_deep"),
    ):
        for path in sorted(classical.glob("*.json")):
            for folder in (classical, deep):
                file = folder / path.name
                if file.is_file():
                    for method, value in json.loads(file.read_text())["XXfpr_meanXX"].items():
                        columns.setdefault(method, []).append(value)
    table = pd.DataFrame(
        {m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in columns.items()}
    ).T
    return ordered(table)


def x__merge_fpr__mutmut_28(evidence: Path, out: Path, extra: Path) -> pd.DataFrame:
    """Clean-row flag rate over the UCI carriers and the ADBench ones together."""
    columns: dict[str, list[float]] = {}
    for classical, deep in (
        (evidence / "typed_injection" / "runs", out / "typed_deep" / "runs"),
        (extra / "reference_classical", extra / "reference_deep"),
    ):
        for path in sorted(classical.glob("*.json")):
            for folder in (classical, deep):
                file = folder / path.name
                if file.is_file():
                    for method, value in json.loads(file.read_text())["FPR_MEAN"].items():
                        columns.setdefault(method, []).append(value)
    table = pd.DataFrame(
        {m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in columns.items()}
    ).T
    return ordered(table)


def x__merge_fpr__mutmut_29(evidence: Path, out: Path, extra: Path) -> pd.DataFrame:
    """Clean-row flag rate over the UCI carriers and the ADBench ones together."""
    columns: dict[str, list[float]] = {}
    for classical, deep in (
        (evidence / "typed_injection" / "runs", out / "typed_deep" / "runs"),
        (extra / "reference_classical", extra / "reference_deep"),
    ):
        for path in sorted(classical.glob("*.json")):
            for folder in (classical, deep):
                file = folder / path.name
                if file.is_file():
                    for method, value in json.loads(file.read_text())["fpr_mean"].items():
                        columns.setdefault(method, []).append(None)
    table = pd.DataFrame(
        {m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in columns.items()}
    ).T
    return ordered(table)


def x__merge_fpr__mutmut_30(evidence: Path, out: Path, extra: Path) -> pd.DataFrame:
    """Clean-row flag rate over the UCI carriers and the ADBench ones together."""
    columns: dict[str, list[float]] = {}
    for classical, deep in (
        (evidence / "typed_injection" / "runs", out / "typed_deep" / "runs"),
        (extra / "reference_classical", extra / "reference_deep"),
    ):
        for path in sorted(classical.glob("*.json")):
            for folder in (classical, deep):
                file = folder / path.name
                if file.is_file():
                    for method, value in json.loads(file.read_text())["fpr_mean"].items():
                        columns.setdefault(None, []).append(value)
    table = pd.DataFrame(
        {m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in columns.items()}
    ).T
    return ordered(table)


def x__merge_fpr__mutmut_31(evidence: Path, out: Path, extra: Path) -> pd.DataFrame:
    """Clean-row flag rate over the UCI carriers and the ADBench ones together."""
    columns: dict[str, list[float]] = {}
    for classical, deep in (
        (evidence / "typed_injection" / "runs", out / "typed_deep" / "runs"),
        (extra / "reference_classical", extra / "reference_deep"),
    ):
        for path in sorted(classical.glob("*.json")):
            for folder in (classical, deep):
                file = folder / path.name
                if file.is_file():
                    for method, value in json.loads(file.read_text())["fpr_mean"].items():
                        columns.setdefault(method, None).append(value)
    table = pd.DataFrame(
        {m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in columns.items()}
    ).T
    return ordered(table)


def x__merge_fpr__mutmut_32(evidence: Path, out: Path, extra: Path) -> pd.DataFrame:
    """Clean-row flag rate over the UCI carriers and the ADBench ones together."""
    columns: dict[str, list[float]] = {}
    for classical, deep in (
        (evidence / "typed_injection" / "runs", out / "typed_deep" / "runs"),
        (extra / "reference_classical", extra / "reference_deep"),
    ):
        for path in sorted(classical.glob("*.json")):
            for folder in (classical, deep):
                file = folder / path.name
                if file.is_file():
                    for method, value in json.loads(file.read_text())["fpr_mean"].items():
                        columns.setdefault([]).append(value)
    table = pd.DataFrame(
        {m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in columns.items()}
    ).T
    return ordered(table)


def x__merge_fpr__mutmut_33(evidence: Path, out: Path, extra: Path) -> pd.DataFrame:
    """Clean-row flag rate over the UCI carriers and the ADBench ones together."""
    columns: dict[str, list[float]] = {}
    for classical, deep in (
        (evidence / "typed_injection" / "runs", out / "typed_deep" / "runs"),
        (extra / "reference_classical", extra / "reference_deep"),
    ):
        for path in sorted(classical.glob("*.json")):
            for folder in (classical, deep):
                file = folder / path.name
                if file.is_file():
                    for method, value in json.loads(file.read_text())["fpr_mean"].items():
                        columns.setdefault(method, ).append(value)
    table = pd.DataFrame(
        {m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in columns.items()}
    ).T
    return ordered(table)


def x__merge_fpr__mutmut_34(evidence: Path, out: Path, extra: Path) -> pd.DataFrame:
    """Clean-row flag rate over the UCI carriers and the ADBench ones together."""
    columns: dict[str, list[float]] = {}
    for classical, deep in (
        (evidence / "typed_injection" / "runs", out / "typed_deep" / "runs"),
        (extra / "reference_classical", extra / "reference_deep"),
    ):
        for path in sorted(classical.glob("*.json")):
            for folder in (classical, deep):
                file = folder / path.name
                if file.is_file():
                    for method, value in json.loads(file.read_text())["fpr_mean"].items():
                        columns.setdefault(method, []).append(value)
    table = None
    return ordered(table)


def x__merge_fpr__mutmut_35(evidence: Path, out: Path, extra: Path) -> pd.DataFrame:
    """Clean-row flag rate over the UCI carriers and the ADBench ones together."""
    columns: dict[str, list[float]] = {}
    for classical, deep in (
        (evidence / "typed_injection" / "runs", out / "typed_deep" / "runs"),
        (extra / "reference_classical", extra / "reference_deep"),
    ):
        for path in sorted(classical.glob("*.json")):
            for folder in (classical, deep):
                file = folder / path.name
                if file.is_file():
                    for method, value in json.loads(file.read_text())["fpr_mean"].items():
                        columns.setdefault(method, []).append(value)
    table = pd.DataFrame(
        None
    ).T
    return ordered(table)


def x__merge_fpr__mutmut_36(evidence: Path, out: Path, extra: Path) -> pd.DataFrame:
    """Clean-row flag rate over the UCI carriers and the ADBench ones together."""
    columns: dict[str, list[float]] = {}
    for classical, deep in (
        (evidence / "typed_injection" / "runs", out / "typed_deep" / "runs"),
        (extra / "reference_classical", extra / "reference_deep"),
    ):
        for path in sorted(classical.glob("*.json")):
            for folder in (classical, deep):
                file = folder / path.name
                if file.is_file():
                    for method, value in json.loads(file.read_text())["fpr_mean"].items():
                        columns.setdefault(method, []).append(value)
    table = pd.DataFrame(
        {m: {"XXmedianXX": float(np.median(v)), "max": float(np.max(v))} for m, v in columns.items()}
    ).T
    return ordered(table)


def x__merge_fpr__mutmut_37(evidence: Path, out: Path, extra: Path) -> pd.DataFrame:
    """Clean-row flag rate over the UCI carriers and the ADBench ones together."""
    columns: dict[str, list[float]] = {}
    for classical, deep in (
        (evidence / "typed_injection" / "runs", out / "typed_deep" / "runs"),
        (extra / "reference_classical", extra / "reference_deep"),
    ):
        for path in sorted(classical.glob("*.json")):
            for folder in (classical, deep):
                file = folder / path.name
                if file.is_file():
                    for method, value in json.loads(file.read_text())["fpr_mean"].items():
                        columns.setdefault(method, []).append(value)
    table = pd.DataFrame(
        {m: {"MEDIAN": float(np.median(v)), "max": float(np.max(v))} for m, v in columns.items()}
    ).T
    return ordered(table)


def x__merge_fpr__mutmut_38(evidence: Path, out: Path, extra: Path) -> pd.DataFrame:
    """Clean-row flag rate over the UCI carriers and the ADBench ones together."""
    columns: dict[str, list[float]] = {}
    for classical, deep in (
        (evidence / "typed_injection" / "runs", out / "typed_deep" / "runs"),
        (extra / "reference_classical", extra / "reference_deep"),
    ):
        for path in sorted(classical.glob("*.json")):
            for folder in (classical, deep):
                file = folder / path.name
                if file.is_file():
                    for method, value in json.loads(file.read_text())["fpr_mean"].items():
                        columns.setdefault(method, []).append(value)
    table = pd.DataFrame(
        {m: {"median": float(None), "max": float(np.max(v))} for m, v in columns.items()}
    ).T
    return ordered(table)


def x__merge_fpr__mutmut_39(evidence: Path, out: Path, extra: Path) -> pd.DataFrame:
    """Clean-row flag rate over the UCI carriers and the ADBench ones together."""
    columns: dict[str, list[float]] = {}
    for classical, deep in (
        (evidence / "typed_injection" / "runs", out / "typed_deep" / "runs"),
        (extra / "reference_classical", extra / "reference_deep"),
    ):
        for path in sorted(classical.glob("*.json")):
            for folder in (classical, deep):
                file = folder / path.name
                if file.is_file():
                    for method, value in json.loads(file.read_text())["fpr_mean"].items():
                        columns.setdefault(method, []).append(value)
    table = pd.DataFrame(
        {m: {"median": float(np.median(None)), "max": float(np.max(v))} for m, v in columns.items()}
    ).T
    return ordered(table)


def x__merge_fpr__mutmut_40(evidence: Path, out: Path, extra: Path) -> pd.DataFrame:
    """Clean-row flag rate over the UCI carriers and the ADBench ones together."""
    columns: dict[str, list[float]] = {}
    for classical, deep in (
        (evidence / "typed_injection" / "runs", out / "typed_deep" / "runs"),
        (extra / "reference_classical", extra / "reference_deep"),
    ):
        for path in sorted(classical.glob("*.json")):
            for folder in (classical, deep):
                file = folder / path.name
                if file.is_file():
                    for method, value in json.loads(file.read_text())["fpr_mean"].items():
                        columns.setdefault(method, []).append(value)
    table = pd.DataFrame(
        {m: {"median": float(np.median(v)), "XXmaxXX": float(np.max(v))} for m, v in columns.items()}
    ).T
    return ordered(table)


def x__merge_fpr__mutmut_41(evidence: Path, out: Path, extra: Path) -> pd.DataFrame:
    """Clean-row flag rate over the UCI carriers and the ADBench ones together."""
    columns: dict[str, list[float]] = {}
    for classical, deep in (
        (evidence / "typed_injection" / "runs", out / "typed_deep" / "runs"),
        (extra / "reference_classical", extra / "reference_deep"),
    ):
        for path in sorted(classical.glob("*.json")):
            for folder in (classical, deep):
                file = folder / path.name
                if file.is_file():
                    for method, value in json.loads(file.read_text())["fpr_mean"].items():
                        columns.setdefault(method, []).append(value)
    table = pd.DataFrame(
        {m: {"median": float(np.median(v)), "MAX": float(np.max(v))} for m, v in columns.items()}
    ).T
    return ordered(table)


def x__merge_fpr__mutmut_42(evidence: Path, out: Path, extra: Path) -> pd.DataFrame:
    """Clean-row flag rate over the UCI carriers and the ADBench ones together."""
    columns: dict[str, list[float]] = {}
    for classical, deep in (
        (evidence / "typed_injection" / "runs", out / "typed_deep" / "runs"),
        (extra / "reference_classical", extra / "reference_deep"),
    ):
        for path in sorted(classical.glob("*.json")):
            for folder in (classical, deep):
                file = folder / path.name
                if file.is_file():
                    for method, value in json.loads(file.read_text())["fpr_mean"].items():
                        columns.setdefault(method, []).append(value)
    table = pd.DataFrame(
        {m: {"median": float(np.median(v)), "max": float(None)} for m, v in columns.items()}
    ).T
    return ordered(table)


def x__merge_fpr__mutmut_43(evidence: Path, out: Path, extra: Path) -> pd.DataFrame:
    """Clean-row flag rate over the UCI carriers and the ADBench ones together."""
    columns: dict[str, list[float]] = {}
    for classical, deep in (
        (evidence / "typed_injection" / "runs", out / "typed_deep" / "runs"),
        (extra / "reference_classical", extra / "reference_deep"),
    ):
        for path in sorted(classical.glob("*.json")):
            for folder in (classical, deep):
                file = folder / path.name
                if file.is_file():
                    for method, value in json.loads(file.read_text())["fpr_mean"].items():
                        columns.setdefault(method, []).append(value)
    table = pd.DataFrame(
        {m: {"median": float(np.median(v)), "max": float(np.max(None))} for m, v in columns.items()}
    ).T
    return ordered(table)


def x__merge_fpr__mutmut_44(evidence: Path, out: Path, extra: Path) -> pd.DataFrame:
    """Clean-row flag rate over the UCI carriers and the ADBench ones together."""
    columns: dict[str, list[float]] = {}
    for classical, deep in (
        (evidence / "typed_injection" / "runs", out / "typed_deep" / "runs"),
        (extra / "reference_classical", extra / "reference_deep"),
    ):
        for path in sorted(classical.glob("*.json")):
            for folder in (classical, deep):
                file = folder / path.name
                if file.is_file():
                    for method, value in json.loads(file.read_text())["fpr_mean"].items():
                        columns.setdefault(method, []).append(value)
    table = pd.DataFrame(
        {m: {"median": float(np.median(v)), "max": float(np.max(v))} for m, v in columns.items()}
    ).T
    return ordered(None)

mutants_x__merge_fpr__mutmut['_mutmut_orig'] = x__merge_fpr__mutmut_orig # type: ignore # mutmut generated
mutants_x__merge_fpr__mutmut['x__merge_fpr__mutmut_1'] = x__merge_fpr__mutmut_1 # type: ignore # mutmut generated
mutants_x__merge_fpr__mutmut['x__merge_fpr__mutmut_2'] = x__merge_fpr__mutmut_2 # type: ignore # mutmut generated
mutants_x__merge_fpr__mutmut['x__merge_fpr__mutmut_3'] = x__merge_fpr__mutmut_3 # type: ignore # mutmut generated
mutants_x__merge_fpr__mutmut['x__merge_fpr__mutmut_4'] = x__merge_fpr__mutmut_4 # type: ignore # mutmut generated
mutants_x__merge_fpr__mutmut['x__merge_fpr__mutmut_5'] = x__merge_fpr__mutmut_5 # type: ignore # mutmut generated
mutants_x__merge_fpr__mutmut['x__merge_fpr__mutmut_6'] = x__merge_fpr__mutmut_6 # type: ignore # mutmut generated
mutants_x__merge_fpr__mutmut['x__merge_fpr__mutmut_7'] = x__merge_fpr__mutmut_7 # type: ignore # mutmut generated
mutants_x__merge_fpr__mutmut['x__merge_fpr__mutmut_8'] = x__merge_fpr__mutmut_8 # type: ignore # mutmut generated
mutants_x__merge_fpr__mutmut['x__merge_fpr__mutmut_9'] = x__merge_fpr__mutmut_9 # type: ignore # mutmut generated
mutants_x__merge_fpr__mutmut['x__merge_fpr__mutmut_10'] = x__merge_fpr__mutmut_10 # type: ignore # mutmut generated
mutants_x__merge_fpr__mutmut['x__merge_fpr__mutmut_11'] = x__merge_fpr__mutmut_11 # type: ignore # mutmut generated
mutants_x__merge_fpr__mutmut['x__merge_fpr__mutmut_12'] = x__merge_fpr__mutmut_12 # type: ignore # mutmut generated
mutants_x__merge_fpr__mutmut['x__merge_fpr__mutmut_13'] = x__merge_fpr__mutmut_13 # type: ignore # mutmut generated
mutants_x__merge_fpr__mutmut['x__merge_fpr__mutmut_14'] = x__merge_fpr__mutmut_14 # type: ignore # mutmut generated
mutants_x__merge_fpr__mutmut['x__merge_fpr__mutmut_15'] = x__merge_fpr__mutmut_15 # type: ignore # mutmut generated
mutants_x__merge_fpr__mutmut['x__merge_fpr__mutmut_16'] = x__merge_fpr__mutmut_16 # type: ignore # mutmut generated
mutants_x__merge_fpr__mutmut['x__merge_fpr__mutmut_17'] = x__merge_fpr__mutmut_17 # type: ignore # mutmut generated
mutants_x__merge_fpr__mutmut['x__merge_fpr__mutmut_18'] = x__merge_fpr__mutmut_18 # type: ignore # mutmut generated
mutants_x__merge_fpr__mutmut['x__merge_fpr__mutmut_19'] = x__merge_fpr__mutmut_19 # type: ignore # mutmut generated
mutants_x__merge_fpr__mutmut['x__merge_fpr__mutmut_20'] = x__merge_fpr__mutmut_20 # type: ignore # mutmut generated
mutants_x__merge_fpr__mutmut['x__merge_fpr__mutmut_21'] = x__merge_fpr__mutmut_21 # type: ignore # mutmut generated
mutants_x__merge_fpr__mutmut['x__merge_fpr__mutmut_22'] = x__merge_fpr__mutmut_22 # type: ignore # mutmut generated
mutants_x__merge_fpr__mutmut['x__merge_fpr__mutmut_23'] = x__merge_fpr__mutmut_23 # type: ignore # mutmut generated
mutants_x__merge_fpr__mutmut['x__merge_fpr__mutmut_24'] = x__merge_fpr__mutmut_24 # type: ignore # mutmut generated
mutants_x__merge_fpr__mutmut['x__merge_fpr__mutmut_25'] = x__merge_fpr__mutmut_25 # type: ignore # mutmut generated
mutants_x__merge_fpr__mutmut['x__merge_fpr__mutmut_26'] = x__merge_fpr__mutmut_26 # type: ignore # mutmut generated
mutants_x__merge_fpr__mutmut['x__merge_fpr__mutmut_27'] = x__merge_fpr__mutmut_27 # type: ignore # mutmut generated
mutants_x__merge_fpr__mutmut['x__merge_fpr__mutmut_28'] = x__merge_fpr__mutmut_28 # type: ignore # mutmut generated
mutants_x__merge_fpr__mutmut['x__merge_fpr__mutmut_29'] = x__merge_fpr__mutmut_29 # type: ignore # mutmut generated
mutants_x__merge_fpr__mutmut['x__merge_fpr__mutmut_30'] = x__merge_fpr__mutmut_30 # type: ignore # mutmut generated
mutants_x__merge_fpr__mutmut['x__merge_fpr__mutmut_31'] = x__merge_fpr__mutmut_31 # type: ignore # mutmut generated
mutants_x__merge_fpr__mutmut['x__merge_fpr__mutmut_32'] = x__merge_fpr__mutmut_32 # type: ignore # mutmut generated
mutants_x__merge_fpr__mutmut['x__merge_fpr__mutmut_33'] = x__merge_fpr__mutmut_33 # type: ignore # mutmut generated
mutants_x__merge_fpr__mutmut['x__merge_fpr__mutmut_34'] = x__merge_fpr__mutmut_34 # type: ignore # mutmut generated
mutants_x__merge_fpr__mutmut['x__merge_fpr__mutmut_35'] = x__merge_fpr__mutmut_35 # type: ignore # mutmut generated
mutants_x__merge_fpr__mutmut['x__merge_fpr__mutmut_36'] = x__merge_fpr__mutmut_36 # type: ignore # mutmut generated
mutants_x__merge_fpr__mutmut['x__merge_fpr__mutmut_37'] = x__merge_fpr__mutmut_37 # type: ignore # mutmut generated
mutants_x__merge_fpr__mutmut['x__merge_fpr__mutmut_38'] = x__merge_fpr__mutmut_38 # type: ignore # mutmut generated
mutants_x__merge_fpr__mutmut['x__merge_fpr__mutmut_39'] = x__merge_fpr__mutmut_39 # type: ignore # mutmut generated
mutants_x__merge_fpr__mutmut['x__merge_fpr__mutmut_40'] = x__merge_fpr__mutmut_40 # type: ignore # mutmut generated
mutants_x__merge_fpr__mutmut['x__merge_fpr__mutmut_41'] = x__merge_fpr__mutmut_41 # type: ignore # mutmut generated
mutants_x__merge_fpr__mutmut['x__merge_fpr__mutmut_42'] = x__merge_fpr__mutmut_42 # type: ignore # mutmut generated
mutants_x__merge_fpr__mutmut['x__merge_fpr__mutmut_43'] = x__merge_fpr__mutmut_43 # type: ignore # mutmut generated
mutants_x__merge_fpr__mutmut['x__merge_fpr__mutmut_44'] = x__merge_fpr__mutmut_44 # type: ignore # mutmut generated
mutants_x_table_md__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_table_md__mutmut)
def table_md(
    frame: pd.DataFrame, low: pd.DataFrame | None = None, high=None, digits: int = 2
) -> str:
    lines = [
        "| method | " + " | ".join(frame.columns) + " |",
        "|---|" + "---|" * len(frame.columns),
    ]
    for name in frame.index:
        if low is None:
            cells = [f"{v:.{digits}f}" for v in frame.loc[name]]
        else:
            cells = [
                f"{frame.loc[name, c]:.2f} [{low.loc[name, c]:.2f}, {high.loc[name, c]:.2f}]"
                for c in frame.columns
            ]
        lines.append(f"| {name} | " + " | ".join(cells) + " |")
    return "\n".join(lines) + "\n"


def x_table_md__mutmut_orig(
    frame: pd.DataFrame, low: pd.DataFrame | None = None, high=None, digits: int = 2
) -> str:
    lines = [
        "| method | " + " | ".join(frame.columns) + " |",
        "|---|" + "---|" * len(frame.columns),
    ]
    for name in frame.index:
        if low is None:
            cells = [f"{v:.{digits}f}" for v in frame.loc[name]]
        else:
            cells = [
                f"{frame.loc[name, c]:.2f} [{low.loc[name, c]:.2f}, {high.loc[name, c]:.2f}]"
                for c in frame.columns
            ]
        lines.append(f"| {name} | " + " | ".join(cells) + " |")
    return "\n".join(lines) + "\n"


def x_table_md__mutmut_1(
    frame: pd.DataFrame, low: pd.DataFrame | None = None, high=None, digits: int = 3
) -> str:
    lines = [
        "| method | " + " | ".join(frame.columns) + " |",
        "|---|" + "---|" * len(frame.columns),
    ]
    for name in frame.index:
        if low is None:
            cells = [f"{v:.{digits}f}" for v in frame.loc[name]]
        else:
            cells = [
                f"{frame.loc[name, c]:.2f} [{low.loc[name, c]:.2f}, {high.loc[name, c]:.2f}]"
                for c in frame.columns
            ]
        lines.append(f"| {name} | " + " | ".join(cells) + " |")
    return "\n".join(lines) + "\n"


def x_table_md__mutmut_2(
    frame: pd.DataFrame, low: pd.DataFrame | None = None, high=None, digits: int = 2
) -> str:
    lines = None
    for name in frame.index:
        if low is None:
            cells = [f"{v:.{digits}f}" for v in frame.loc[name]]
        else:
            cells = [
                f"{frame.loc[name, c]:.2f} [{low.loc[name, c]:.2f}, {high.loc[name, c]:.2f}]"
                for c in frame.columns
            ]
        lines.append(f"| {name} | " + " | ".join(cells) + " |")
    return "\n".join(lines) + "\n"


def x_table_md__mutmut_3(
    frame: pd.DataFrame, low: pd.DataFrame | None = None, high=None, digits: int = 2
) -> str:
    lines = [
        "| method | " + " | ".join(frame.columns) - " |",
        "|---|" + "---|" * len(frame.columns),
    ]
    for name in frame.index:
        if low is None:
            cells = [f"{v:.{digits}f}" for v in frame.loc[name]]
        else:
            cells = [
                f"{frame.loc[name, c]:.2f} [{low.loc[name, c]:.2f}, {high.loc[name, c]:.2f}]"
                for c in frame.columns
            ]
        lines.append(f"| {name} | " + " | ".join(cells) + " |")
    return "\n".join(lines) + "\n"


def x_table_md__mutmut_4(
    frame: pd.DataFrame, low: pd.DataFrame | None = None, high=None, digits: int = 2
) -> str:
    lines = [
        "| method | " - " | ".join(frame.columns) + " |",
        "|---|" + "---|" * len(frame.columns),
    ]
    for name in frame.index:
        if low is None:
            cells = [f"{v:.{digits}f}" for v in frame.loc[name]]
        else:
            cells = [
                f"{frame.loc[name, c]:.2f} [{low.loc[name, c]:.2f}, {high.loc[name, c]:.2f}]"
                for c in frame.columns
            ]
        lines.append(f"| {name} | " + " | ".join(cells) + " |")
    return "\n".join(lines) + "\n"


def x_table_md__mutmut_5(
    frame: pd.DataFrame, low: pd.DataFrame | None = None, high=None, digits: int = 2
) -> str:
    lines = [
        "XX| method | XX" + " | ".join(frame.columns) + " |",
        "|---|" + "---|" * len(frame.columns),
    ]
    for name in frame.index:
        if low is None:
            cells = [f"{v:.{digits}f}" for v in frame.loc[name]]
        else:
            cells = [
                f"{frame.loc[name, c]:.2f} [{low.loc[name, c]:.2f}, {high.loc[name, c]:.2f}]"
                for c in frame.columns
            ]
        lines.append(f"| {name} | " + " | ".join(cells) + " |")
    return "\n".join(lines) + "\n"


def x_table_md__mutmut_6(
    frame: pd.DataFrame, low: pd.DataFrame | None = None, high=None, digits: int = 2
) -> str:
    lines = [
        "| METHOD | " + " | ".join(frame.columns) + " |",
        "|---|" + "---|" * len(frame.columns),
    ]
    for name in frame.index:
        if low is None:
            cells = [f"{v:.{digits}f}" for v in frame.loc[name]]
        else:
            cells = [
                f"{frame.loc[name, c]:.2f} [{low.loc[name, c]:.2f}, {high.loc[name, c]:.2f}]"
                for c in frame.columns
            ]
        lines.append(f"| {name} | " + " | ".join(cells) + " |")
    return "\n".join(lines) + "\n"


def x_table_md__mutmut_7(
    frame: pd.DataFrame, low: pd.DataFrame | None = None, high=None, digits: int = 2
) -> str:
    lines = [
        "| method | " + " | ".join(None) + " |",
        "|---|" + "---|" * len(frame.columns),
    ]
    for name in frame.index:
        if low is None:
            cells = [f"{v:.{digits}f}" for v in frame.loc[name]]
        else:
            cells = [
                f"{frame.loc[name, c]:.2f} [{low.loc[name, c]:.2f}, {high.loc[name, c]:.2f}]"
                for c in frame.columns
            ]
        lines.append(f"| {name} | " + " | ".join(cells) + " |")
    return "\n".join(lines) + "\n"


def x_table_md__mutmut_8(
    frame: pd.DataFrame, low: pd.DataFrame | None = None, high=None, digits: int = 2
) -> str:
    lines = [
        "| method | " + "XX | XX".join(frame.columns) + " |",
        "|---|" + "---|" * len(frame.columns),
    ]
    for name in frame.index:
        if low is None:
            cells = [f"{v:.{digits}f}" for v in frame.loc[name]]
        else:
            cells = [
                f"{frame.loc[name, c]:.2f} [{low.loc[name, c]:.2f}, {high.loc[name, c]:.2f}]"
                for c in frame.columns
            ]
        lines.append(f"| {name} | " + " | ".join(cells) + " |")
    return "\n".join(lines) + "\n"


def x_table_md__mutmut_9(
    frame: pd.DataFrame, low: pd.DataFrame | None = None, high=None, digits: int = 2
) -> str:
    lines = [
        "| method | " + " | ".join(frame.columns) + "XX |XX",
        "|---|" + "---|" * len(frame.columns),
    ]
    for name in frame.index:
        if low is None:
            cells = [f"{v:.{digits}f}" for v in frame.loc[name]]
        else:
            cells = [
                f"{frame.loc[name, c]:.2f} [{low.loc[name, c]:.2f}, {high.loc[name, c]:.2f}]"
                for c in frame.columns
            ]
        lines.append(f"| {name} | " + " | ".join(cells) + " |")
    return "\n".join(lines) + "\n"


def x_table_md__mutmut_10(
    frame: pd.DataFrame, low: pd.DataFrame | None = None, high=None, digits: int = 2
) -> str:
    lines = [
        "| method | " + " | ".join(frame.columns) + " |",
        "|---|" - "---|" * len(frame.columns),
    ]
    for name in frame.index:
        if low is None:
            cells = [f"{v:.{digits}f}" for v in frame.loc[name]]
        else:
            cells = [
                f"{frame.loc[name, c]:.2f} [{low.loc[name, c]:.2f}, {high.loc[name, c]:.2f}]"
                for c in frame.columns
            ]
        lines.append(f"| {name} | " + " | ".join(cells) + " |")
    return "\n".join(lines) + "\n"


def x_table_md__mutmut_11(
    frame: pd.DataFrame, low: pd.DataFrame | None = None, high=None, digits: int = 2
) -> str:
    lines = [
        "| method | " + " | ".join(frame.columns) + " |",
        "XX|---|XX" + "---|" * len(frame.columns),
    ]
    for name in frame.index:
        if low is None:
            cells = [f"{v:.{digits}f}" for v in frame.loc[name]]
        else:
            cells = [
                f"{frame.loc[name, c]:.2f} [{low.loc[name, c]:.2f}, {high.loc[name, c]:.2f}]"
                for c in frame.columns
            ]
        lines.append(f"| {name} | " + " | ".join(cells) + " |")
    return "\n".join(lines) + "\n"


def x_table_md__mutmut_12(
    frame: pd.DataFrame, low: pd.DataFrame | None = None, high=None, digits: int = 2
) -> str:
    lines = [
        "| method | " + " | ".join(frame.columns) + " |",
        "|---|" + "---|" / len(frame.columns),
    ]
    for name in frame.index:
        if low is None:
            cells = [f"{v:.{digits}f}" for v in frame.loc[name]]
        else:
            cells = [
                f"{frame.loc[name, c]:.2f} [{low.loc[name, c]:.2f}, {high.loc[name, c]:.2f}]"
                for c in frame.columns
            ]
        lines.append(f"| {name} | " + " | ".join(cells) + " |")
    return "\n".join(lines) + "\n"


def x_table_md__mutmut_13(
    frame: pd.DataFrame, low: pd.DataFrame | None = None, high=None, digits: int = 2
) -> str:
    lines = [
        "| method | " + " | ".join(frame.columns) + " |",
        "|---|" + "XX---|XX" * len(frame.columns),
    ]
    for name in frame.index:
        if low is None:
            cells = [f"{v:.{digits}f}" for v in frame.loc[name]]
        else:
            cells = [
                f"{frame.loc[name, c]:.2f} [{low.loc[name, c]:.2f}, {high.loc[name, c]:.2f}]"
                for c in frame.columns
            ]
        lines.append(f"| {name} | " + " | ".join(cells) + " |")
    return "\n".join(lines) + "\n"


def x_table_md__mutmut_14(
    frame: pd.DataFrame, low: pd.DataFrame | None = None, high=None, digits: int = 2
) -> str:
    lines = [
        "| method | " + " | ".join(frame.columns) + " |",
        "|---|" + "---|" * len(frame.columns),
    ]
    for name in frame.index:
        if low is not None:
            cells = [f"{v:.{digits}f}" for v in frame.loc[name]]
        else:
            cells = [
                f"{frame.loc[name, c]:.2f} [{low.loc[name, c]:.2f}, {high.loc[name, c]:.2f}]"
                for c in frame.columns
            ]
        lines.append(f"| {name} | " + " | ".join(cells) + " |")
    return "\n".join(lines) + "\n"


def x_table_md__mutmut_15(
    frame: pd.DataFrame, low: pd.DataFrame | None = None, high=None, digits: int = 2
) -> str:
    lines = [
        "| method | " + " | ".join(frame.columns) + " |",
        "|---|" + "---|" * len(frame.columns),
    ]
    for name in frame.index:
        if low is None:
            cells = None
        else:
            cells = [
                f"{frame.loc[name, c]:.2f} [{low.loc[name, c]:.2f}, {high.loc[name, c]:.2f}]"
                for c in frame.columns
            ]
        lines.append(f"| {name} | " + " | ".join(cells) + " |")
    return "\n".join(lines) + "\n"


def x_table_md__mutmut_16(
    frame: pd.DataFrame, low: pd.DataFrame | None = None, high=None, digits: int = 2
) -> str:
    lines = [
        "| method | " + " | ".join(frame.columns) + " |",
        "|---|" + "---|" * len(frame.columns),
    ]
    for name in frame.index:
        if low is None:
            cells = [f"{v:.{digits}f}" for v in frame.loc[name]]
        else:
            cells = None
        lines.append(f"| {name} | " + " | ".join(cells) + " |")
    return "\n".join(lines) + "\n"


def x_table_md__mutmut_17(
    frame: pd.DataFrame, low: pd.DataFrame | None = None, high=None, digits: int = 2
) -> str:
    lines = [
        "| method | " + " | ".join(frame.columns) + " |",
        "|---|" + "---|" * len(frame.columns),
    ]
    for name in frame.index:
        if low is None:
            cells = [f"{v:.{digits}f}" for v in frame.loc[name]]
        else:
            cells = [
                f"{frame.loc[name, c]:.2f} [{low.loc[name, c]:.2f}, {high.loc[name, c]:.2f}]"
                for c in frame.columns
            ]
        lines.append(None)
    return "\n".join(lines) + "\n"


def x_table_md__mutmut_18(
    frame: pd.DataFrame, low: pd.DataFrame | None = None, high=None, digits: int = 2
) -> str:
    lines = [
        "| method | " + " | ".join(frame.columns) + " |",
        "|---|" + "---|" * len(frame.columns),
    ]
    for name in frame.index:
        if low is None:
            cells = [f"{v:.{digits}f}" for v in frame.loc[name]]
        else:
            cells = [
                f"{frame.loc[name, c]:.2f} [{low.loc[name, c]:.2f}, {high.loc[name, c]:.2f}]"
                for c in frame.columns
            ]
        lines.append(f"| {name} | " + " | ".join(cells) - " |")
    return "\n".join(lines) + "\n"


def x_table_md__mutmut_19(
    frame: pd.DataFrame, low: pd.DataFrame | None = None, high=None, digits: int = 2
) -> str:
    lines = [
        "| method | " + " | ".join(frame.columns) + " |",
        "|---|" + "---|" * len(frame.columns),
    ]
    for name in frame.index:
        if low is None:
            cells = [f"{v:.{digits}f}" for v in frame.loc[name]]
        else:
            cells = [
                f"{frame.loc[name, c]:.2f} [{low.loc[name, c]:.2f}, {high.loc[name, c]:.2f}]"
                for c in frame.columns
            ]
        lines.append(f"| {name} | " - " | ".join(cells) + " |")
    return "\n".join(lines) + "\n"


def x_table_md__mutmut_20(
    frame: pd.DataFrame, low: pd.DataFrame | None = None, high=None, digits: int = 2
) -> str:
    lines = [
        "| method | " + " | ".join(frame.columns) + " |",
        "|---|" + "---|" * len(frame.columns),
    ]
    for name in frame.index:
        if low is None:
            cells = [f"{v:.{digits}f}" for v in frame.loc[name]]
        else:
            cells = [
                f"{frame.loc[name, c]:.2f} [{low.loc[name, c]:.2f}, {high.loc[name, c]:.2f}]"
                for c in frame.columns
            ]
        lines.append(f"| {name} | " + " | ".join(None) + " |")
    return "\n".join(lines) + "\n"


def x_table_md__mutmut_21(
    frame: pd.DataFrame, low: pd.DataFrame | None = None, high=None, digits: int = 2
) -> str:
    lines = [
        "| method | " + " | ".join(frame.columns) + " |",
        "|---|" + "---|" * len(frame.columns),
    ]
    for name in frame.index:
        if low is None:
            cells = [f"{v:.{digits}f}" for v in frame.loc[name]]
        else:
            cells = [
                f"{frame.loc[name, c]:.2f} [{low.loc[name, c]:.2f}, {high.loc[name, c]:.2f}]"
                for c in frame.columns
            ]
        lines.append(f"| {name} | " + "XX | XX".join(cells) + " |")
    return "\n".join(lines) + "\n"


def x_table_md__mutmut_22(
    frame: pd.DataFrame, low: pd.DataFrame | None = None, high=None, digits: int = 2
) -> str:
    lines = [
        "| method | " + " | ".join(frame.columns) + " |",
        "|---|" + "---|" * len(frame.columns),
    ]
    for name in frame.index:
        if low is None:
            cells = [f"{v:.{digits}f}" for v in frame.loc[name]]
        else:
            cells = [
                f"{frame.loc[name, c]:.2f} [{low.loc[name, c]:.2f}, {high.loc[name, c]:.2f}]"
                for c in frame.columns
            ]
        lines.append(f"| {name} | " + " | ".join(cells) + "XX |XX")
    return "\n".join(lines) + "\n"


def x_table_md__mutmut_23(
    frame: pd.DataFrame, low: pd.DataFrame | None = None, high=None, digits: int = 2
) -> str:
    lines = [
        "| method | " + " | ".join(frame.columns) + " |",
        "|---|" + "---|" * len(frame.columns),
    ]
    for name in frame.index:
        if low is None:
            cells = [f"{v:.{digits}f}" for v in frame.loc[name]]
        else:
            cells = [
                f"{frame.loc[name, c]:.2f} [{low.loc[name, c]:.2f}, {high.loc[name, c]:.2f}]"
                for c in frame.columns
            ]
        lines.append(f"| {name} | " + " | ".join(cells) + " |")
    return "\n".join(lines) - "\n"


def x_table_md__mutmut_24(
    frame: pd.DataFrame, low: pd.DataFrame | None = None, high=None, digits: int = 2
) -> str:
    lines = [
        "| method | " + " | ".join(frame.columns) + " |",
        "|---|" + "---|" * len(frame.columns),
    ]
    for name in frame.index:
        if low is None:
            cells = [f"{v:.{digits}f}" for v in frame.loc[name]]
        else:
            cells = [
                f"{frame.loc[name, c]:.2f} [{low.loc[name, c]:.2f}, {high.loc[name, c]:.2f}]"
                for c in frame.columns
            ]
        lines.append(f"| {name} | " + " | ".join(cells) + " |")
    return "\n".join(None) + "\n"


def x_table_md__mutmut_25(
    frame: pd.DataFrame, low: pd.DataFrame | None = None, high=None, digits: int = 2
) -> str:
    lines = [
        "| method | " + " | ".join(frame.columns) + " |",
        "|---|" + "---|" * len(frame.columns),
    ]
    for name in frame.index:
        if low is None:
            cells = [f"{v:.{digits}f}" for v in frame.loc[name]]
        else:
            cells = [
                f"{frame.loc[name, c]:.2f} [{low.loc[name, c]:.2f}, {high.loc[name, c]:.2f}]"
                for c in frame.columns
            ]
        lines.append(f"| {name} | " + " | ".join(cells) + " |")
    return "XX\nXX".join(lines) + "\n"


def x_table_md__mutmut_26(
    frame: pd.DataFrame, low: pd.DataFrame | None = None, high=None, digits: int = 2
) -> str:
    lines = [
        "| method | " + " | ".join(frame.columns) + " |",
        "|---|" + "---|" * len(frame.columns),
    ]
    for name in frame.index:
        if low is None:
            cells = [f"{v:.{digits}f}" for v in frame.loc[name]]
        else:
            cells = [
                f"{frame.loc[name, c]:.2f} [{low.loc[name, c]:.2f}, {high.loc[name, c]:.2f}]"
                for c in frame.columns
            ]
        lines.append(f"| {name} | " + " | ".join(cells) + " |")
    return "\n".join(lines) + "XX\nXX"

mutants_x_table_md__mutmut['_mutmut_orig'] = x_table_md__mutmut_orig # type: ignore # mutmut generated
mutants_x_table_md__mutmut['x_table_md__mutmut_1'] = x_table_md__mutmut_1 # type: ignore # mutmut generated
mutants_x_table_md__mutmut['x_table_md__mutmut_2'] = x_table_md__mutmut_2 # type: ignore # mutmut generated
mutants_x_table_md__mutmut['x_table_md__mutmut_3'] = x_table_md__mutmut_3 # type: ignore # mutmut generated
mutants_x_table_md__mutmut['x_table_md__mutmut_4'] = x_table_md__mutmut_4 # type: ignore # mutmut generated
mutants_x_table_md__mutmut['x_table_md__mutmut_5'] = x_table_md__mutmut_5 # type: ignore # mutmut generated
mutants_x_table_md__mutmut['x_table_md__mutmut_6'] = x_table_md__mutmut_6 # type: ignore # mutmut generated
mutants_x_table_md__mutmut['x_table_md__mutmut_7'] = x_table_md__mutmut_7 # type: ignore # mutmut generated
mutants_x_table_md__mutmut['x_table_md__mutmut_8'] = x_table_md__mutmut_8 # type: ignore # mutmut generated
mutants_x_table_md__mutmut['x_table_md__mutmut_9'] = x_table_md__mutmut_9 # type: ignore # mutmut generated
mutants_x_table_md__mutmut['x_table_md__mutmut_10'] = x_table_md__mutmut_10 # type: ignore # mutmut generated
mutants_x_table_md__mutmut['x_table_md__mutmut_11'] = x_table_md__mutmut_11 # type: ignore # mutmut generated
mutants_x_table_md__mutmut['x_table_md__mutmut_12'] = x_table_md__mutmut_12 # type: ignore # mutmut generated
mutants_x_table_md__mutmut['x_table_md__mutmut_13'] = x_table_md__mutmut_13 # type: ignore # mutmut generated
mutants_x_table_md__mutmut['x_table_md__mutmut_14'] = x_table_md__mutmut_14 # type: ignore # mutmut generated
mutants_x_table_md__mutmut['x_table_md__mutmut_15'] = x_table_md__mutmut_15 # type: ignore # mutmut generated
mutants_x_table_md__mutmut['x_table_md__mutmut_16'] = x_table_md__mutmut_16 # type: ignore # mutmut generated
mutants_x_table_md__mutmut['x_table_md__mutmut_17'] = x_table_md__mutmut_17 # type: ignore # mutmut generated
mutants_x_table_md__mutmut['x_table_md__mutmut_18'] = x_table_md__mutmut_18 # type: ignore # mutmut generated
mutants_x_table_md__mutmut['x_table_md__mutmut_19'] = x_table_md__mutmut_19 # type: ignore # mutmut generated
mutants_x_table_md__mutmut['x_table_md__mutmut_20'] = x_table_md__mutmut_20 # type: ignore # mutmut generated
mutants_x_table_md__mutmut['x_table_md__mutmut_21'] = x_table_md__mutmut_21 # type: ignore # mutmut generated
mutants_x_table_md__mutmut['x_table_md__mutmut_22'] = x_table_md__mutmut_22 # type: ignore # mutmut generated
mutants_x_table_md__mutmut['x_table_md__mutmut_23'] = x_table_md__mutmut_23 # type: ignore # mutmut generated
mutants_x_table_md__mutmut['x_table_md__mutmut_24'] = x_table_md__mutmut_24 # type: ignore # mutmut generated
mutants_x_table_md__mutmut['x_table_md__mutmut_25'] = x_table_md__mutmut_25 # type: ignore # mutmut generated
mutants_x_table_md__mutmut['x_table_md__mutmut_26'] = x_table_md__mutmut_26 # type: ignore # mutmut generated
mutants_x_figure__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_figure__mutmut)
def figure(frame: pd.DataFrame, title: str, path: Path) -> None:
    fig, ax = plt.subplots(figsize=(7, 0.3 * len(frame) + 1.6))
    tf._draw(ax, frame, title)
    fig.tight_layout()
    fig.savefig(path, dpi=160)
    plt.close(fig)


def x_figure__mutmut_orig(frame: pd.DataFrame, title: str, path: Path) -> None:
    fig, ax = plt.subplots(figsize=(7, 0.3 * len(frame) + 1.6))
    tf._draw(ax, frame, title)
    fig.tight_layout()
    fig.savefig(path, dpi=160)
    plt.close(fig)


def x_figure__mutmut_1(frame: pd.DataFrame, title: str, path: Path) -> None:
    fig, ax = None
    tf._draw(ax, frame, title)
    fig.tight_layout()
    fig.savefig(path, dpi=160)
    plt.close(fig)


def x_figure__mutmut_2(frame: pd.DataFrame, title: str, path: Path) -> None:
    fig, ax = plt.subplots(figsize=None)
    tf._draw(ax, frame, title)
    fig.tight_layout()
    fig.savefig(path, dpi=160)
    plt.close(fig)


def x_figure__mutmut_3(frame: pd.DataFrame, title: str, path: Path) -> None:
    fig, ax = plt.subplots(figsize=(8, 0.3 * len(frame) + 1.6))
    tf._draw(ax, frame, title)
    fig.tight_layout()
    fig.savefig(path, dpi=160)
    plt.close(fig)


def x_figure__mutmut_4(frame: pd.DataFrame, title: str, path: Path) -> None:
    fig, ax = plt.subplots(figsize=(7, 0.3 * len(frame) - 1.6))
    tf._draw(ax, frame, title)
    fig.tight_layout()
    fig.savefig(path, dpi=160)
    plt.close(fig)


def x_figure__mutmut_5(frame: pd.DataFrame, title: str, path: Path) -> None:
    fig, ax = plt.subplots(figsize=(7, 0.3 / len(frame) + 1.6))
    tf._draw(ax, frame, title)
    fig.tight_layout()
    fig.savefig(path, dpi=160)
    plt.close(fig)


def x_figure__mutmut_6(frame: pd.DataFrame, title: str, path: Path) -> None:
    fig, ax = plt.subplots(figsize=(7, 1.3 * len(frame) + 1.6))
    tf._draw(ax, frame, title)
    fig.tight_layout()
    fig.savefig(path, dpi=160)
    plt.close(fig)


def x_figure__mutmut_7(frame: pd.DataFrame, title: str, path: Path) -> None:
    fig, ax = plt.subplots(figsize=(7, 0.3 * len(frame) + 2.6))
    tf._draw(ax, frame, title)
    fig.tight_layout()
    fig.savefig(path, dpi=160)
    plt.close(fig)


def x_figure__mutmut_8(frame: pd.DataFrame, title: str, path: Path) -> None:
    fig, ax = plt.subplots(figsize=(7, 0.3 * len(frame) + 1.6))
    tf._draw(None, frame, title)
    fig.tight_layout()
    fig.savefig(path, dpi=160)
    plt.close(fig)


def x_figure__mutmut_9(frame: pd.DataFrame, title: str, path: Path) -> None:
    fig, ax = plt.subplots(figsize=(7, 0.3 * len(frame) + 1.6))
    tf._draw(ax, None, title)
    fig.tight_layout()
    fig.savefig(path, dpi=160)
    plt.close(fig)


def x_figure__mutmut_10(frame: pd.DataFrame, title: str, path: Path) -> None:
    fig, ax = plt.subplots(figsize=(7, 0.3 * len(frame) + 1.6))
    tf._draw(ax, frame, None)
    fig.tight_layout()
    fig.savefig(path, dpi=160)
    plt.close(fig)


def x_figure__mutmut_11(frame: pd.DataFrame, title: str, path: Path) -> None:
    fig, ax = plt.subplots(figsize=(7, 0.3 * len(frame) + 1.6))
    tf._draw(frame, title)
    fig.tight_layout()
    fig.savefig(path, dpi=160)
    plt.close(fig)


def x_figure__mutmut_12(frame: pd.DataFrame, title: str, path: Path) -> None:
    fig, ax = plt.subplots(figsize=(7, 0.3 * len(frame) + 1.6))
    tf._draw(ax, title)
    fig.tight_layout()
    fig.savefig(path, dpi=160)
    plt.close(fig)


def x_figure__mutmut_13(frame: pd.DataFrame, title: str, path: Path) -> None:
    fig, ax = plt.subplots(figsize=(7, 0.3 * len(frame) + 1.6))
    tf._draw(ax, frame, )
    fig.tight_layout()
    fig.savefig(path, dpi=160)
    plt.close(fig)


def x_figure__mutmut_14(frame: pd.DataFrame, title: str, path: Path) -> None:
    fig, ax = plt.subplots(figsize=(7, 0.3 * len(frame) + 1.6))
    tf._draw(ax, frame, title)
    fig.tight_layout()
    fig.savefig(None, dpi=160)
    plt.close(fig)


def x_figure__mutmut_15(frame: pd.DataFrame, title: str, path: Path) -> None:
    fig, ax = plt.subplots(figsize=(7, 0.3 * len(frame) + 1.6))
    tf._draw(ax, frame, title)
    fig.tight_layout()
    fig.savefig(path, dpi=None)
    plt.close(fig)


def x_figure__mutmut_16(frame: pd.DataFrame, title: str, path: Path) -> None:
    fig, ax = plt.subplots(figsize=(7, 0.3 * len(frame) + 1.6))
    tf._draw(ax, frame, title)
    fig.tight_layout()
    fig.savefig(dpi=160)
    plt.close(fig)


def x_figure__mutmut_17(frame: pd.DataFrame, title: str, path: Path) -> None:
    fig, ax = plt.subplots(figsize=(7, 0.3 * len(frame) + 1.6))
    tf._draw(ax, frame, title)
    fig.tight_layout()
    fig.savefig(path, )
    plt.close(fig)


def x_figure__mutmut_18(frame: pd.DataFrame, title: str, path: Path) -> None:
    fig, ax = plt.subplots(figsize=(7, 0.3 * len(frame) + 1.6))
    tf._draw(ax, frame, title)
    fig.tight_layout()
    fig.savefig(path, dpi=161)
    plt.close(fig)


def x_figure__mutmut_19(frame: pd.DataFrame, title: str, path: Path) -> None:
    fig, ax = plt.subplots(figsize=(7, 0.3 * len(frame) + 1.6))
    tf._draw(ax, frame, title)
    fig.tight_layout()
    fig.savefig(path, dpi=160)
    plt.close(None)

mutants_x_figure__mutmut['_mutmut_orig'] = x_figure__mutmut_orig # type: ignore # mutmut generated
mutants_x_figure__mutmut['x_figure__mutmut_1'] = x_figure__mutmut_1 # type: ignore # mutmut generated
mutants_x_figure__mutmut['x_figure__mutmut_2'] = x_figure__mutmut_2 # type: ignore # mutmut generated
mutants_x_figure__mutmut['x_figure__mutmut_3'] = x_figure__mutmut_3 # type: ignore # mutmut generated
mutants_x_figure__mutmut['x_figure__mutmut_4'] = x_figure__mutmut_4 # type: ignore # mutmut generated
mutants_x_figure__mutmut['x_figure__mutmut_5'] = x_figure__mutmut_5 # type: ignore # mutmut generated
mutants_x_figure__mutmut['x_figure__mutmut_6'] = x_figure__mutmut_6 # type: ignore # mutmut generated
mutants_x_figure__mutmut['x_figure__mutmut_7'] = x_figure__mutmut_7 # type: ignore # mutmut generated
mutants_x_figure__mutmut['x_figure__mutmut_8'] = x_figure__mutmut_8 # type: ignore # mutmut generated
mutants_x_figure__mutmut['x_figure__mutmut_9'] = x_figure__mutmut_9 # type: ignore # mutmut generated
mutants_x_figure__mutmut['x_figure__mutmut_10'] = x_figure__mutmut_10 # type: ignore # mutmut generated
mutants_x_figure__mutmut['x_figure__mutmut_11'] = x_figure__mutmut_11 # type: ignore # mutmut generated
mutants_x_figure__mutmut['x_figure__mutmut_12'] = x_figure__mutmut_12 # type: ignore # mutmut generated
mutants_x_figure__mutmut['x_figure__mutmut_13'] = x_figure__mutmut_13 # type: ignore # mutmut generated
mutants_x_figure__mutmut['x_figure__mutmut_14'] = x_figure__mutmut_14 # type: ignore # mutmut generated
mutants_x_figure__mutmut['x_figure__mutmut_15'] = x_figure__mutmut_15 # type: ignore # mutmut generated
mutants_x_figure__mutmut['x_figure__mutmut_16'] = x_figure__mutmut_16 # type: ignore # mutmut generated
mutants_x_figure__mutmut['x_figure__mutmut_17'] = x_figure__mutmut_17 # type: ignore # mutmut generated
mutants_x_figure__mutmut['x_figure__mutmut_18'] = x_figure__mutmut_18 # type: ignore # mutmut generated
mutants_x_figure__mutmut['x_figure__mutmut_19'] = x_figure__mutmut_19 # type: ignore # mutmut generated
mutants_x_deep_mean__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_deep_mean__mutmut)
def deep_mean(runs: Path, pattern: str) -> pd.DataFrame:
    frames = [_split(json.loads(p.read_text())["recall"]) for p in sorted(runs.glob(pattern))]
    stack = pd.concat(frames, keys=range(len(frames)))
    return stack.groupby(level=1, sort=False).mean()


def x_deep_mean__mutmut_orig(runs: Path, pattern: str) -> pd.DataFrame:
    frames = [_split(json.loads(p.read_text())["recall"]) for p in sorted(runs.glob(pattern))]
    stack = pd.concat(frames, keys=range(len(frames)))
    return stack.groupby(level=1, sort=False).mean()


def x_deep_mean__mutmut_1(runs: Path, pattern: str) -> pd.DataFrame:
    frames = None
    stack = pd.concat(frames, keys=range(len(frames)))
    return stack.groupby(level=1, sort=False).mean()


def x_deep_mean__mutmut_2(runs: Path, pattern: str) -> pd.DataFrame:
    frames = [_split(None) for p in sorted(runs.glob(pattern))]
    stack = pd.concat(frames, keys=range(len(frames)))
    return stack.groupby(level=1, sort=False).mean()


def x_deep_mean__mutmut_3(runs: Path, pattern: str) -> pd.DataFrame:
    frames = [_split(json.loads(None)["recall"]) for p in sorted(runs.glob(pattern))]
    stack = pd.concat(frames, keys=range(len(frames)))
    return stack.groupby(level=1, sort=False).mean()


def x_deep_mean__mutmut_4(runs: Path, pattern: str) -> pd.DataFrame:
    frames = [_split(json.loads(p.read_text())["XXrecallXX"]) for p in sorted(runs.glob(pattern))]
    stack = pd.concat(frames, keys=range(len(frames)))
    return stack.groupby(level=1, sort=False).mean()


def x_deep_mean__mutmut_5(runs: Path, pattern: str) -> pd.DataFrame:
    frames = [_split(json.loads(p.read_text())["RECALL"]) for p in sorted(runs.glob(pattern))]
    stack = pd.concat(frames, keys=range(len(frames)))
    return stack.groupby(level=1, sort=False).mean()


def x_deep_mean__mutmut_6(runs: Path, pattern: str) -> pd.DataFrame:
    frames = [_split(json.loads(p.read_text())["recall"]) for p in sorted(None)]
    stack = pd.concat(frames, keys=range(len(frames)))
    return stack.groupby(level=1, sort=False).mean()


def x_deep_mean__mutmut_7(runs: Path, pattern: str) -> pd.DataFrame:
    frames = [_split(json.loads(p.read_text())["recall"]) for p in sorted(runs.glob(None))]
    stack = pd.concat(frames, keys=range(len(frames)))
    return stack.groupby(level=1, sort=False).mean()


def x_deep_mean__mutmut_8(runs: Path, pattern: str) -> pd.DataFrame:
    frames = [_split(json.loads(p.read_text())["recall"]) for p in sorted(runs.glob(pattern))]
    stack = None
    return stack.groupby(level=1, sort=False).mean()


def x_deep_mean__mutmut_9(runs: Path, pattern: str) -> pd.DataFrame:
    frames = [_split(json.loads(p.read_text())["recall"]) for p in sorted(runs.glob(pattern))]
    stack = pd.concat(None, keys=range(len(frames)))
    return stack.groupby(level=1, sort=False).mean()


def x_deep_mean__mutmut_10(runs: Path, pattern: str) -> pd.DataFrame:
    frames = [_split(json.loads(p.read_text())["recall"]) for p in sorted(runs.glob(pattern))]
    stack = pd.concat(frames, keys=None)
    return stack.groupby(level=1, sort=False).mean()


def x_deep_mean__mutmut_11(runs: Path, pattern: str) -> pd.DataFrame:
    frames = [_split(json.loads(p.read_text())["recall"]) for p in sorted(runs.glob(pattern))]
    stack = pd.concat(keys=range(len(frames)))
    return stack.groupby(level=1, sort=False).mean()


def x_deep_mean__mutmut_12(runs: Path, pattern: str) -> pd.DataFrame:
    frames = [_split(json.loads(p.read_text())["recall"]) for p in sorted(runs.glob(pattern))]
    stack = pd.concat(frames, )
    return stack.groupby(level=1, sort=False).mean()


def x_deep_mean__mutmut_13(runs: Path, pattern: str) -> pd.DataFrame:
    frames = [_split(json.loads(p.read_text())["recall"]) for p in sorted(runs.glob(pattern))]
    stack = pd.concat(frames, keys=range(None))
    return stack.groupby(level=1, sort=False).mean()


def x_deep_mean__mutmut_14(runs: Path, pattern: str) -> pd.DataFrame:
    frames = [_split(json.loads(p.read_text())["recall"]) for p in sorted(runs.glob(pattern))]
    stack = pd.concat(frames, keys=range(len(frames)))
    return stack.groupby(level=None, sort=False).mean()


def x_deep_mean__mutmut_15(runs: Path, pattern: str) -> pd.DataFrame:
    frames = [_split(json.loads(p.read_text())["recall"]) for p in sorted(runs.glob(pattern))]
    stack = pd.concat(frames, keys=range(len(frames)))
    return stack.groupby(level=1, sort=None).mean()


def x_deep_mean__mutmut_16(runs: Path, pattern: str) -> pd.DataFrame:
    frames = [_split(json.loads(p.read_text())["recall"]) for p in sorted(runs.glob(pattern))]
    stack = pd.concat(frames, keys=range(len(frames)))
    return stack.groupby(sort=False).mean()


def x_deep_mean__mutmut_17(runs: Path, pattern: str) -> pd.DataFrame:
    frames = [_split(json.loads(p.read_text())["recall"]) for p in sorted(runs.glob(pattern))]
    stack = pd.concat(frames, keys=range(len(frames)))
    return stack.groupby(level=1, ).mean()


def x_deep_mean__mutmut_18(runs: Path, pattern: str) -> pd.DataFrame:
    frames = [_split(json.loads(p.read_text())["recall"]) for p in sorted(runs.glob(pattern))]
    stack = pd.concat(frames, keys=range(len(frames)))
    return stack.groupby(level=2, sort=False).mean()


def x_deep_mean__mutmut_19(runs: Path, pattern: str) -> pd.DataFrame:
    frames = [_split(json.loads(p.read_text())["recall"]) for p in sorted(runs.glob(pattern))]
    stack = pd.concat(frames, keys=range(len(frames)))
    return stack.groupby(level=1, sort=True).mean()

mutants_x_deep_mean__mutmut['_mutmut_orig'] = x_deep_mean__mutmut_orig # type: ignore # mutmut generated
mutants_x_deep_mean__mutmut['x_deep_mean__mutmut_1'] = x_deep_mean__mutmut_1 # type: ignore # mutmut generated
mutants_x_deep_mean__mutmut['x_deep_mean__mutmut_2'] = x_deep_mean__mutmut_2 # type: ignore # mutmut generated
mutants_x_deep_mean__mutmut['x_deep_mean__mutmut_3'] = x_deep_mean__mutmut_3 # type: ignore # mutmut generated
mutants_x_deep_mean__mutmut['x_deep_mean__mutmut_4'] = x_deep_mean__mutmut_4 # type: ignore # mutmut generated
mutants_x_deep_mean__mutmut['x_deep_mean__mutmut_5'] = x_deep_mean__mutmut_5 # type: ignore # mutmut generated
mutants_x_deep_mean__mutmut['x_deep_mean__mutmut_6'] = x_deep_mean__mutmut_6 # type: ignore # mutmut generated
mutants_x_deep_mean__mutmut['x_deep_mean__mutmut_7'] = x_deep_mean__mutmut_7 # type: ignore # mutmut generated
mutants_x_deep_mean__mutmut['x_deep_mean__mutmut_8'] = x_deep_mean__mutmut_8 # type: ignore # mutmut generated
mutants_x_deep_mean__mutmut['x_deep_mean__mutmut_9'] = x_deep_mean__mutmut_9 # type: ignore # mutmut generated
mutants_x_deep_mean__mutmut['x_deep_mean__mutmut_10'] = x_deep_mean__mutmut_10 # type: ignore # mutmut generated
mutants_x_deep_mean__mutmut['x_deep_mean__mutmut_11'] = x_deep_mean__mutmut_11 # type: ignore # mutmut generated
mutants_x_deep_mean__mutmut['x_deep_mean__mutmut_12'] = x_deep_mean__mutmut_12 # type: ignore # mutmut generated
mutants_x_deep_mean__mutmut['x_deep_mean__mutmut_13'] = x_deep_mean__mutmut_13 # type: ignore # mutmut generated
mutants_x_deep_mean__mutmut['x_deep_mean__mutmut_14'] = x_deep_mean__mutmut_14 # type: ignore # mutmut generated
mutants_x_deep_mean__mutmut['x_deep_mean__mutmut_15'] = x_deep_mean__mutmut_15 # type: ignore # mutmut generated
mutants_x_deep_mean__mutmut['x_deep_mean__mutmut_16'] = x_deep_mean__mutmut_16 # type: ignore # mutmut generated
mutants_x_deep_mean__mutmut['x_deep_mean__mutmut_17'] = x_deep_mean__mutmut_17 # type: ignore # mutmut generated
mutants_x_deep_mean__mutmut['x_deep_mean__mutmut_18'] = x_deep_mean__mutmut_18 # type: ignore # mutmut generated
mutants_x_deep_mean__mutmut['x_deep_mean__mutmut_19'] = x_deep_mean__mutmut_19 # type: ignore # mutmut generated
mutants_x_synthetic_matrix__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_synthetic_matrix__mutmut)
def synthetic_matrix(evidence: Path, deep: Path) -> pd.DataFrame:
    classical = pd.read_csv(evidence / "synthetic_recall.csv", index_col="method")
    classical = classical[[f"{t}_mean" for t in TYPES]].set_axis(TYPES, axis=1)
    rows = [classical, deep_mean(deep, "synthetic_seed_*.json")]
    lstm = [
        json.loads(p.read_text())["recall"]
        for p in sorted((evidence / "deep_typed").glob("seed_*.json"))
    ]
    if lstm:
        frame = pd.concat([_split(r) for r in lstm], keys=range(len(lstm)))
        rows.append(frame.groupby(level=1, sort=False).mean().loc[["lstm_autoencoder"]])
    return ordered(pd.concat(rows)[TYPES])


def x_synthetic_matrix__mutmut_orig(evidence: Path, deep: Path) -> pd.DataFrame:
    classical = pd.read_csv(evidence / "synthetic_recall.csv", index_col="method")
    classical = classical[[f"{t}_mean" for t in TYPES]].set_axis(TYPES, axis=1)
    rows = [classical, deep_mean(deep, "synthetic_seed_*.json")]
    lstm = [
        json.loads(p.read_text())["recall"]
        for p in sorted((evidence / "deep_typed").glob("seed_*.json"))
    ]
    if lstm:
        frame = pd.concat([_split(r) for r in lstm], keys=range(len(lstm)))
        rows.append(frame.groupby(level=1, sort=False).mean().loc[["lstm_autoencoder"]])
    return ordered(pd.concat(rows)[TYPES])


def x_synthetic_matrix__mutmut_1(evidence: Path, deep: Path) -> pd.DataFrame:
    classical = None
    classical = classical[[f"{t}_mean" for t in TYPES]].set_axis(TYPES, axis=1)
    rows = [classical, deep_mean(deep, "synthetic_seed_*.json")]
    lstm = [
        json.loads(p.read_text())["recall"]
        for p in sorted((evidence / "deep_typed").glob("seed_*.json"))
    ]
    if lstm:
        frame = pd.concat([_split(r) for r in lstm], keys=range(len(lstm)))
        rows.append(frame.groupby(level=1, sort=False).mean().loc[["lstm_autoencoder"]])
    return ordered(pd.concat(rows)[TYPES])


def x_synthetic_matrix__mutmut_2(evidence: Path, deep: Path) -> pd.DataFrame:
    classical = pd.read_csv(None, index_col="method")
    classical = classical[[f"{t}_mean" for t in TYPES]].set_axis(TYPES, axis=1)
    rows = [classical, deep_mean(deep, "synthetic_seed_*.json")]
    lstm = [
        json.loads(p.read_text())["recall"]
        for p in sorted((evidence / "deep_typed").glob("seed_*.json"))
    ]
    if lstm:
        frame = pd.concat([_split(r) for r in lstm], keys=range(len(lstm)))
        rows.append(frame.groupby(level=1, sort=False).mean().loc[["lstm_autoencoder"]])
    return ordered(pd.concat(rows)[TYPES])


def x_synthetic_matrix__mutmut_3(evidence: Path, deep: Path) -> pd.DataFrame:
    classical = pd.read_csv(evidence / "synthetic_recall.csv", index_col=None)
    classical = classical[[f"{t}_mean" for t in TYPES]].set_axis(TYPES, axis=1)
    rows = [classical, deep_mean(deep, "synthetic_seed_*.json")]
    lstm = [
        json.loads(p.read_text())["recall"]
        for p in sorted((evidence / "deep_typed").glob("seed_*.json"))
    ]
    if lstm:
        frame = pd.concat([_split(r) for r in lstm], keys=range(len(lstm)))
        rows.append(frame.groupby(level=1, sort=False).mean().loc[["lstm_autoencoder"]])
    return ordered(pd.concat(rows)[TYPES])


def x_synthetic_matrix__mutmut_4(evidence: Path, deep: Path) -> pd.DataFrame:
    classical = pd.read_csv(index_col="method")
    classical = classical[[f"{t}_mean" for t in TYPES]].set_axis(TYPES, axis=1)
    rows = [classical, deep_mean(deep, "synthetic_seed_*.json")]
    lstm = [
        json.loads(p.read_text())["recall"]
        for p in sorted((evidence / "deep_typed").glob("seed_*.json"))
    ]
    if lstm:
        frame = pd.concat([_split(r) for r in lstm], keys=range(len(lstm)))
        rows.append(frame.groupby(level=1, sort=False).mean().loc[["lstm_autoencoder"]])
    return ordered(pd.concat(rows)[TYPES])


def x_synthetic_matrix__mutmut_5(evidence: Path, deep: Path) -> pd.DataFrame:
    classical = pd.read_csv(evidence / "synthetic_recall.csv", )
    classical = classical[[f"{t}_mean" for t in TYPES]].set_axis(TYPES, axis=1)
    rows = [classical, deep_mean(deep, "synthetic_seed_*.json")]
    lstm = [
        json.loads(p.read_text())["recall"]
        for p in sorted((evidence / "deep_typed").glob("seed_*.json"))
    ]
    if lstm:
        frame = pd.concat([_split(r) for r in lstm], keys=range(len(lstm)))
        rows.append(frame.groupby(level=1, sort=False).mean().loc[["lstm_autoencoder"]])
    return ordered(pd.concat(rows)[TYPES])


def x_synthetic_matrix__mutmut_6(evidence: Path, deep: Path) -> pd.DataFrame:
    classical = pd.read_csv(evidence * "synthetic_recall.csv", index_col="method")
    classical = classical[[f"{t}_mean" for t in TYPES]].set_axis(TYPES, axis=1)
    rows = [classical, deep_mean(deep, "synthetic_seed_*.json")]
    lstm = [
        json.loads(p.read_text())["recall"]
        for p in sorted((evidence / "deep_typed").glob("seed_*.json"))
    ]
    if lstm:
        frame = pd.concat([_split(r) for r in lstm], keys=range(len(lstm)))
        rows.append(frame.groupby(level=1, sort=False).mean().loc[["lstm_autoencoder"]])
    return ordered(pd.concat(rows)[TYPES])


def x_synthetic_matrix__mutmut_7(evidence: Path, deep: Path) -> pd.DataFrame:
    classical = pd.read_csv(evidence / "XXsynthetic_recall.csvXX", index_col="method")
    classical = classical[[f"{t}_mean" for t in TYPES]].set_axis(TYPES, axis=1)
    rows = [classical, deep_mean(deep, "synthetic_seed_*.json")]
    lstm = [
        json.loads(p.read_text())["recall"]
        for p in sorted((evidence / "deep_typed").glob("seed_*.json"))
    ]
    if lstm:
        frame = pd.concat([_split(r) for r in lstm], keys=range(len(lstm)))
        rows.append(frame.groupby(level=1, sort=False).mean().loc[["lstm_autoencoder"]])
    return ordered(pd.concat(rows)[TYPES])


def x_synthetic_matrix__mutmut_8(evidence: Path, deep: Path) -> pd.DataFrame:
    classical = pd.read_csv(evidence / "SYNTHETIC_RECALL.CSV", index_col="method")
    classical = classical[[f"{t}_mean" for t in TYPES]].set_axis(TYPES, axis=1)
    rows = [classical, deep_mean(deep, "synthetic_seed_*.json")]
    lstm = [
        json.loads(p.read_text())["recall"]
        for p in sorted((evidence / "deep_typed").glob("seed_*.json"))
    ]
    if lstm:
        frame = pd.concat([_split(r) for r in lstm], keys=range(len(lstm)))
        rows.append(frame.groupby(level=1, sort=False).mean().loc[["lstm_autoencoder"]])
    return ordered(pd.concat(rows)[TYPES])


def x_synthetic_matrix__mutmut_9(evidence: Path, deep: Path) -> pd.DataFrame:
    classical = pd.read_csv(evidence / "synthetic_recall.csv", index_col="XXmethodXX")
    classical = classical[[f"{t}_mean" for t in TYPES]].set_axis(TYPES, axis=1)
    rows = [classical, deep_mean(deep, "synthetic_seed_*.json")]
    lstm = [
        json.loads(p.read_text())["recall"]
        for p in sorted((evidence / "deep_typed").glob("seed_*.json"))
    ]
    if lstm:
        frame = pd.concat([_split(r) for r in lstm], keys=range(len(lstm)))
        rows.append(frame.groupby(level=1, sort=False).mean().loc[["lstm_autoencoder"]])
    return ordered(pd.concat(rows)[TYPES])


def x_synthetic_matrix__mutmut_10(evidence: Path, deep: Path) -> pd.DataFrame:
    classical = pd.read_csv(evidence / "synthetic_recall.csv", index_col="METHOD")
    classical = classical[[f"{t}_mean" for t in TYPES]].set_axis(TYPES, axis=1)
    rows = [classical, deep_mean(deep, "synthetic_seed_*.json")]
    lstm = [
        json.loads(p.read_text())["recall"]
        for p in sorted((evidence / "deep_typed").glob("seed_*.json"))
    ]
    if lstm:
        frame = pd.concat([_split(r) for r in lstm], keys=range(len(lstm)))
        rows.append(frame.groupby(level=1, sort=False).mean().loc[["lstm_autoencoder"]])
    return ordered(pd.concat(rows)[TYPES])


def x_synthetic_matrix__mutmut_11(evidence: Path, deep: Path) -> pd.DataFrame:
    classical = pd.read_csv(evidence / "synthetic_recall.csv", index_col="method")
    classical = None
    rows = [classical, deep_mean(deep, "synthetic_seed_*.json")]
    lstm = [
        json.loads(p.read_text())["recall"]
        for p in sorted((evidence / "deep_typed").glob("seed_*.json"))
    ]
    if lstm:
        frame = pd.concat([_split(r) for r in lstm], keys=range(len(lstm)))
        rows.append(frame.groupby(level=1, sort=False).mean().loc[["lstm_autoencoder"]])
    return ordered(pd.concat(rows)[TYPES])


def x_synthetic_matrix__mutmut_12(evidence: Path, deep: Path) -> pd.DataFrame:
    classical = pd.read_csv(evidence / "synthetic_recall.csv", index_col="method")
    classical = classical[[f"{t}_mean" for t in TYPES]].set_axis(None, axis=1)
    rows = [classical, deep_mean(deep, "synthetic_seed_*.json")]
    lstm = [
        json.loads(p.read_text())["recall"]
        for p in sorted((evidence / "deep_typed").glob("seed_*.json"))
    ]
    if lstm:
        frame = pd.concat([_split(r) for r in lstm], keys=range(len(lstm)))
        rows.append(frame.groupby(level=1, sort=False).mean().loc[["lstm_autoencoder"]])
    return ordered(pd.concat(rows)[TYPES])


def x_synthetic_matrix__mutmut_13(evidence: Path, deep: Path) -> pd.DataFrame:
    classical = pd.read_csv(evidence / "synthetic_recall.csv", index_col="method")
    classical = classical[[f"{t}_mean" for t in TYPES]].set_axis(TYPES, axis=None)
    rows = [classical, deep_mean(deep, "synthetic_seed_*.json")]
    lstm = [
        json.loads(p.read_text())["recall"]
        for p in sorted((evidence / "deep_typed").glob("seed_*.json"))
    ]
    if lstm:
        frame = pd.concat([_split(r) for r in lstm], keys=range(len(lstm)))
        rows.append(frame.groupby(level=1, sort=False).mean().loc[["lstm_autoencoder"]])
    return ordered(pd.concat(rows)[TYPES])


def x_synthetic_matrix__mutmut_14(evidence: Path, deep: Path) -> pd.DataFrame:
    classical = pd.read_csv(evidence / "synthetic_recall.csv", index_col="method")
    classical = classical[[f"{t}_mean" for t in TYPES]].set_axis(axis=1)
    rows = [classical, deep_mean(deep, "synthetic_seed_*.json")]
    lstm = [
        json.loads(p.read_text())["recall"]
        for p in sorted((evidence / "deep_typed").glob("seed_*.json"))
    ]
    if lstm:
        frame = pd.concat([_split(r) for r in lstm], keys=range(len(lstm)))
        rows.append(frame.groupby(level=1, sort=False).mean().loc[["lstm_autoencoder"]])
    return ordered(pd.concat(rows)[TYPES])


def x_synthetic_matrix__mutmut_15(evidence: Path, deep: Path) -> pd.DataFrame:
    classical = pd.read_csv(evidence / "synthetic_recall.csv", index_col="method")
    classical = classical[[f"{t}_mean" for t in TYPES]].set_axis(TYPES, )
    rows = [classical, deep_mean(deep, "synthetic_seed_*.json")]
    lstm = [
        json.loads(p.read_text())["recall"]
        for p in sorted((evidence / "deep_typed").glob("seed_*.json"))
    ]
    if lstm:
        frame = pd.concat([_split(r) for r in lstm], keys=range(len(lstm)))
        rows.append(frame.groupby(level=1, sort=False).mean().loc[["lstm_autoencoder"]])
    return ordered(pd.concat(rows)[TYPES])


def x_synthetic_matrix__mutmut_16(evidence: Path, deep: Path) -> pd.DataFrame:
    classical = pd.read_csv(evidence / "synthetic_recall.csv", index_col="method")
    classical = classical[[f"{t}_mean" for t in TYPES]].set_axis(TYPES, axis=2)
    rows = [classical, deep_mean(deep, "synthetic_seed_*.json")]
    lstm = [
        json.loads(p.read_text())["recall"]
        for p in sorted((evidence / "deep_typed").glob("seed_*.json"))
    ]
    if lstm:
        frame = pd.concat([_split(r) for r in lstm], keys=range(len(lstm)))
        rows.append(frame.groupby(level=1, sort=False).mean().loc[["lstm_autoencoder"]])
    return ordered(pd.concat(rows)[TYPES])


def x_synthetic_matrix__mutmut_17(evidence: Path, deep: Path) -> pd.DataFrame:
    classical = pd.read_csv(evidence / "synthetic_recall.csv", index_col="method")
    classical = classical[[f"{t}_mean" for t in TYPES]].set_axis(TYPES, axis=1)
    rows = None
    lstm = [
        json.loads(p.read_text())["recall"]
        for p in sorted((evidence / "deep_typed").glob("seed_*.json"))
    ]
    if lstm:
        frame = pd.concat([_split(r) for r in lstm], keys=range(len(lstm)))
        rows.append(frame.groupby(level=1, sort=False).mean().loc[["lstm_autoencoder"]])
    return ordered(pd.concat(rows)[TYPES])


def x_synthetic_matrix__mutmut_18(evidence: Path, deep: Path) -> pd.DataFrame:
    classical = pd.read_csv(evidence / "synthetic_recall.csv", index_col="method")
    classical = classical[[f"{t}_mean" for t in TYPES]].set_axis(TYPES, axis=1)
    rows = [classical, deep_mean(None, "synthetic_seed_*.json")]
    lstm = [
        json.loads(p.read_text())["recall"]
        for p in sorted((evidence / "deep_typed").glob("seed_*.json"))
    ]
    if lstm:
        frame = pd.concat([_split(r) for r in lstm], keys=range(len(lstm)))
        rows.append(frame.groupby(level=1, sort=False).mean().loc[["lstm_autoencoder"]])
    return ordered(pd.concat(rows)[TYPES])


def x_synthetic_matrix__mutmut_19(evidence: Path, deep: Path) -> pd.DataFrame:
    classical = pd.read_csv(evidence / "synthetic_recall.csv", index_col="method")
    classical = classical[[f"{t}_mean" for t in TYPES]].set_axis(TYPES, axis=1)
    rows = [classical, deep_mean(deep, None)]
    lstm = [
        json.loads(p.read_text())["recall"]
        for p in sorted((evidence / "deep_typed").glob("seed_*.json"))
    ]
    if lstm:
        frame = pd.concat([_split(r) for r in lstm], keys=range(len(lstm)))
        rows.append(frame.groupby(level=1, sort=False).mean().loc[["lstm_autoencoder"]])
    return ordered(pd.concat(rows)[TYPES])


def x_synthetic_matrix__mutmut_20(evidence: Path, deep: Path) -> pd.DataFrame:
    classical = pd.read_csv(evidence / "synthetic_recall.csv", index_col="method")
    classical = classical[[f"{t}_mean" for t in TYPES]].set_axis(TYPES, axis=1)
    rows = [classical, deep_mean("synthetic_seed_*.json")]
    lstm = [
        json.loads(p.read_text())["recall"]
        for p in sorted((evidence / "deep_typed").glob("seed_*.json"))
    ]
    if lstm:
        frame = pd.concat([_split(r) for r in lstm], keys=range(len(lstm)))
        rows.append(frame.groupby(level=1, sort=False).mean().loc[["lstm_autoencoder"]])
    return ordered(pd.concat(rows)[TYPES])


def x_synthetic_matrix__mutmut_21(evidence: Path, deep: Path) -> pd.DataFrame:
    classical = pd.read_csv(evidence / "synthetic_recall.csv", index_col="method")
    classical = classical[[f"{t}_mean" for t in TYPES]].set_axis(TYPES, axis=1)
    rows = [classical, deep_mean(deep, )]
    lstm = [
        json.loads(p.read_text())["recall"]
        for p in sorted((evidence / "deep_typed").glob("seed_*.json"))
    ]
    if lstm:
        frame = pd.concat([_split(r) for r in lstm], keys=range(len(lstm)))
        rows.append(frame.groupby(level=1, sort=False).mean().loc[["lstm_autoencoder"]])
    return ordered(pd.concat(rows)[TYPES])


def x_synthetic_matrix__mutmut_22(evidence: Path, deep: Path) -> pd.DataFrame:
    classical = pd.read_csv(evidence / "synthetic_recall.csv", index_col="method")
    classical = classical[[f"{t}_mean" for t in TYPES]].set_axis(TYPES, axis=1)
    rows = [classical, deep_mean(deep, "XXsynthetic_seed_*.jsonXX")]
    lstm = [
        json.loads(p.read_text())["recall"]
        for p in sorted((evidence / "deep_typed").glob("seed_*.json"))
    ]
    if lstm:
        frame = pd.concat([_split(r) for r in lstm], keys=range(len(lstm)))
        rows.append(frame.groupby(level=1, sort=False).mean().loc[["lstm_autoencoder"]])
    return ordered(pd.concat(rows)[TYPES])


def x_synthetic_matrix__mutmut_23(evidence: Path, deep: Path) -> pd.DataFrame:
    classical = pd.read_csv(evidence / "synthetic_recall.csv", index_col="method")
    classical = classical[[f"{t}_mean" for t in TYPES]].set_axis(TYPES, axis=1)
    rows = [classical, deep_mean(deep, "SYNTHETIC_SEED_*.JSON")]
    lstm = [
        json.loads(p.read_text())["recall"]
        for p in sorted((evidence / "deep_typed").glob("seed_*.json"))
    ]
    if lstm:
        frame = pd.concat([_split(r) for r in lstm], keys=range(len(lstm)))
        rows.append(frame.groupby(level=1, sort=False).mean().loc[["lstm_autoencoder"]])
    return ordered(pd.concat(rows)[TYPES])


def x_synthetic_matrix__mutmut_24(evidence: Path, deep: Path) -> pd.DataFrame:
    classical = pd.read_csv(evidence / "synthetic_recall.csv", index_col="method")
    classical = classical[[f"{t}_mean" for t in TYPES]].set_axis(TYPES, axis=1)
    rows = [classical, deep_mean(deep, "synthetic_seed_*.json")]
    lstm = None
    if lstm:
        frame = pd.concat([_split(r) for r in lstm], keys=range(len(lstm)))
        rows.append(frame.groupby(level=1, sort=False).mean().loc[["lstm_autoencoder"]])
    return ordered(pd.concat(rows)[TYPES])


def x_synthetic_matrix__mutmut_25(evidence: Path, deep: Path) -> pd.DataFrame:
    classical = pd.read_csv(evidence / "synthetic_recall.csv", index_col="method")
    classical = classical[[f"{t}_mean" for t in TYPES]].set_axis(TYPES, axis=1)
    rows = [classical, deep_mean(deep, "synthetic_seed_*.json")]
    lstm = [
        json.loads(None)["recall"]
        for p in sorted((evidence / "deep_typed").glob("seed_*.json"))
    ]
    if lstm:
        frame = pd.concat([_split(r) for r in lstm], keys=range(len(lstm)))
        rows.append(frame.groupby(level=1, sort=False).mean().loc[["lstm_autoencoder"]])
    return ordered(pd.concat(rows)[TYPES])


def x_synthetic_matrix__mutmut_26(evidence: Path, deep: Path) -> pd.DataFrame:
    classical = pd.read_csv(evidence / "synthetic_recall.csv", index_col="method")
    classical = classical[[f"{t}_mean" for t in TYPES]].set_axis(TYPES, axis=1)
    rows = [classical, deep_mean(deep, "synthetic_seed_*.json")]
    lstm = [
        json.loads(p.read_text())["XXrecallXX"]
        for p in sorted((evidence / "deep_typed").glob("seed_*.json"))
    ]
    if lstm:
        frame = pd.concat([_split(r) for r in lstm], keys=range(len(lstm)))
        rows.append(frame.groupby(level=1, sort=False).mean().loc[["lstm_autoencoder"]])
    return ordered(pd.concat(rows)[TYPES])


def x_synthetic_matrix__mutmut_27(evidence: Path, deep: Path) -> pd.DataFrame:
    classical = pd.read_csv(evidence / "synthetic_recall.csv", index_col="method")
    classical = classical[[f"{t}_mean" for t in TYPES]].set_axis(TYPES, axis=1)
    rows = [classical, deep_mean(deep, "synthetic_seed_*.json")]
    lstm = [
        json.loads(p.read_text())["RECALL"]
        for p in sorted((evidence / "deep_typed").glob("seed_*.json"))
    ]
    if lstm:
        frame = pd.concat([_split(r) for r in lstm], keys=range(len(lstm)))
        rows.append(frame.groupby(level=1, sort=False).mean().loc[["lstm_autoencoder"]])
    return ordered(pd.concat(rows)[TYPES])


def x_synthetic_matrix__mutmut_28(evidence: Path, deep: Path) -> pd.DataFrame:
    classical = pd.read_csv(evidence / "synthetic_recall.csv", index_col="method")
    classical = classical[[f"{t}_mean" for t in TYPES]].set_axis(TYPES, axis=1)
    rows = [classical, deep_mean(deep, "synthetic_seed_*.json")]
    lstm = [
        json.loads(p.read_text())["recall"]
        for p in sorted(None)
    ]
    if lstm:
        frame = pd.concat([_split(r) for r in lstm], keys=range(len(lstm)))
        rows.append(frame.groupby(level=1, sort=False).mean().loc[["lstm_autoencoder"]])
    return ordered(pd.concat(rows)[TYPES])


def x_synthetic_matrix__mutmut_29(evidence: Path, deep: Path) -> pd.DataFrame:
    classical = pd.read_csv(evidence / "synthetic_recall.csv", index_col="method")
    classical = classical[[f"{t}_mean" for t in TYPES]].set_axis(TYPES, axis=1)
    rows = [classical, deep_mean(deep, "synthetic_seed_*.json")]
    lstm = [
        json.loads(p.read_text())["recall"]
        for p in sorted((evidence / "deep_typed").glob(None))
    ]
    if lstm:
        frame = pd.concat([_split(r) for r in lstm], keys=range(len(lstm)))
        rows.append(frame.groupby(level=1, sort=False).mean().loc[["lstm_autoencoder"]])
    return ordered(pd.concat(rows)[TYPES])


def x_synthetic_matrix__mutmut_30(evidence: Path, deep: Path) -> pd.DataFrame:
    classical = pd.read_csv(evidence / "synthetic_recall.csv", index_col="method")
    classical = classical[[f"{t}_mean" for t in TYPES]].set_axis(TYPES, axis=1)
    rows = [classical, deep_mean(deep, "synthetic_seed_*.json")]
    lstm = [
        json.loads(p.read_text())["recall"]
        for p in sorted((evidence * "deep_typed").glob("seed_*.json"))
    ]
    if lstm:
        frame = pd.concat([_split(r) for r in lstm], keys=range(len(lstm)))
        rows.append(frame.groupby(level=1, sort=False).mean().loc[["lstm_autoencoder"]])
    return ordered(pd.concat(rows)[TYPES])


def x_synthetic_matrix__mutmut_31(evidence: Path, deep: Path) -> pd.DataFrame:
    classical = pd.read_csv(evidence / "synthetic_recall.csv", index_col="method")
    classical = classical[[f"{t}_mean" for t in TYPES]].set_axis(TYPES, axis=1)
    rows = [classical, deep_mean(deep, "synthetic_seed_*.json")]
    lstm = [
        json.loads(p.read_text())["recall"]
        for p in sorted((evidence / "XXdeep_typedXX").glob("seed_*.json"))
    ]
    if lstm:
        frame = pd.concat([_split(r) for r in lstm], keys=range(len(lstm)))
        rows.append(frame.groupby(level=1, sort=False).mean().loc[["lstm_autoencoder"]])
    return ordered(pd.concat(rows)[TYPES])


def x_synthetic_matrix__mutmut_32(evidence: Path, deep: Path) -> pd.DataFrame:
    classical = pd.read_csv(evidence / "synthetic_recall.csv", index_col="method")
    classical = classical[[f"{t}_mean" for t in TYPES]].set_axis(TYPES, axis=1)
    rows = [classical, deep_mean(deep, "synthetic_seed_*.json")]
    lstm = [
        json.loads(p.read_text())["recall"]
        for p in sorted((evidence / "DEEP_TYPED").glob("seed_*.json"))
    ]
    if lstm:
        frame = pd.concat([_split(r) for r in lstm], keys=range(len(lstm)))
        rows.append(frame.groupby(level=1, sort=False).mean().loc[["lstm_autoencoder"]])
    return ordered(pd.concat(rows)[TYPES])


def x_synthetic_matrix__mutmut_33(evidence: Path, deep: Path) -> pd.DataFrame:
    classical = pd.read_csv(evidence / "synthetic_recall.csv", index_col="method")
    classical = classical[[f"{t}_mean" for t in TYPES]].set_axis(TYPES, axis=1)
    rows = [classical, deep_mean(deep, "synthetic_seed_*.json")]
    lstm = [
        json.loads(p.read_text())["recall"]
        for p in sorted((evidence / "deep_typed").glob("XXseed_*.jsonXX"))
    ]
    if lstm:
        frame = pd.concat([_split(r) for r in lstm], keys=range(len(lstm)))
        rows.append(frame.groupby(level=1, sort=False).mean().loc[["lstm_autoencoder"]])
    return ordered(pd.concat(rows)[TYPES])


def x_synthetic_matrix__mutmut_34(evidence: Path, deep: Path) -> pd.DataFrame:
    classical = pd.read_csv(evidence / "synthetic_recall.csv", index_col="method")
    classical = classical[[f"{t}_mean" for t in TYPES]].set_axis(TYPES, axis=1)
    rows = [classical, deep_mean(deep, "synthetic_seed_*.json")]
    lstm = [
        json.loads(p.read_text())["recall"]
        for p in sorted((evidence / "deep_typed").glob("SEED_*.JSON"))
    ]
    if lstm:
        frame = pd.concat([_split(r) for r in lstm], keys=range(len(lstm)))
        rows.append(frame.groupby(level=1, sort=False).mean().loc[["lstm_autoencoder"]])
    return ordered(pd.concat(rows)[TYPES])


def x_synthetic_matrix__mutmut_35(evidence: Path, deep: Path) -> pd.DataFrame:
    classical = pd.read_csv(evidence / "synthetic_recall.csv", index_col="method")
    classical = classical[[f"{t}_mean" for t in TYPES]].set_axis(TYPES, axis=1)
    rows = [classical, deep_mean(deep, "synthetic_seed_*.json")]
    lstm = [
        json.loads(p.read_text())["recall"]
        for p in sorted((evidence / "deep_typed").glob("seed_*.json"))
    ]
    if lstm:
        frame = None
        rows.append(frame.groupby(level=1, sort=False).mean().loc[["lstm_autoencoder"]])
    return ordered(pd.concat(rows)[TYPES])


def x_synthetic_matrix__mutmut_36(evidence: Path, deep: Path) -> pd.DataFrame:
    classical = pd.read_csv(evidence / "synthetic_recall.csv", index_col="method")
    classical = classical[[f"{t}_mean" for t in TYPES]].set_axis(TYPES, axis=1)
    rows = [classical, deep_mean(deep, "synthetic_seed_*.json")]
    lstm = [
        json.loads(p.read_text())["recall"]
        for p in sorted((evidence / "deep_typed").glob("seed_*.json"))
    ]
    if lstm:
        frame = pd.concat(None, keys=range(len(lstm)))
        rows.append(frame.groupby(level=1, sort=False).mean().loc[["lstm_autoencoder"]])
    return ordered(pd.concat(rows)[TYPES])


def x_synthetic_matrix__mutmut_37(evidence: Path, deep: Path) -> pd.DataFrame:
    classical = pd.read_csv(evidence / "synthetic_recall.csv", index_col="method")
    classical = classical[[f"{t}_mean" for t in TYPES]].set_axis(TYPES, axis=1)
    rows = [classical, deep_mean(deep, "synthetic_seed_*.json")]
    lstm = [
        json.loads(p.read_text())["recall"]
        for p in sorted((evidence / "deep_typed").glob("seed_*.json"))
    ]
    if lstm:
        frame = pd.concat([_split(r) for r in lstm], keys=None)
        rows.append(frame.groupby(level=1, sort=False).mean().loc[["lstm_autoencoder"]])
    return ordered(pd.concat(rows)[TYPES])


def x_synthetic_matrix__mutmut_38(evidence: Path, deep: Path) -> pd.DataFrame:
    classical = pd.read_csv(evidence / "synthetic_recall.csv", index_col="method")
    classical = classical[[f"{t}_mean" for t in TYPES]].set_axis(TYPES, axis=1)
    rows = [classical, deep_mean(deep, "synthetic_seed_*.json")]
    lstm = [
        json.loads(p.read_text())["recall"]
        for p in sorted((evidence / "deep_typed").glob("seed_*.json"))
    ]
    if lstm:
        frame = pd.concat(keys=range(len(lstm)))
        rows.append(frame.groupby(level=1, sort=False).mean().loc[["lstm_autoencoder"]])
    return ordered(pd.concat(rows)[TYPES])


def x_synthetic_matrix__mutmut_39(evidence: Path, deep: Path) -> pd.DataFrame:
    classical = pd.read_csv(evidence / "synthetic_recall.csv", index_col="method")
    classical = classical[[f"{t}_mean" for t in TYPES]].set_axis(TYPES, axis=1)
    rows = [classical, deep_mean(deep, "synthetic_seed_*.json")]
    lstm = [
        json.loads(p.read_text())["recall"]
        for p in sorted((evidence / "deep_typed").glob("seed_*.json"))
    ]
    if lstm:
        frame = pd.concat([_split(r) for r in lstm], )
        rows.append(frame.groupby(level=1, sort=False).mean().loc[["lstm_autoencoder"]])
    return ordered(pd.concat(rows)[TYPES])


def x_synthetic_matrix__mutmut_40(evidence: Path, deep: Path) -> pd.DataFrame:
    classical = pd.read_csv(evidence / "synthetic_recall.csv", index_col="method")
    classical = classical[[f"{t}_mean" for t in TYPES]].set_axis(TYPES, axis=1)
    rows = [classical, deep_mean(deep, "synthetic_seed_*.json")]
    lstm = [
        json.loads(p.read_text())["recall"]
        for p in sorted((evidence / "deep_typed").glob("seed_*.json"))
    ]
    if lstm:
        frame = pd.concat([_split(None) for r in lstm], keys=range(len(lstm)))
        rows.append(frame.groupby(level=1, sort=False).mean().loc[["lstm_autoencoder"]])
    return ordered(pd.concat(rows)[TYPES])


def x_synthetic_matrix__mutmut_41(evidence: Path, deep: Path) -> pd.DataFrame:
    classical = pd.read_csv(evidence / "synthetic_recall.csv", index_col="method")
    classical = classical[[f"{t}_mean" for t in TYPES]].set_axis(TYPES, axis=1)
    rows = [classical, deep_mean(deep, "synthetic_seed_*.json")]
    lstm = [
        json.loads(p.read_text())["recall"]
        for p in sorted((evidence / "deep_typed").glob("seed_*.json"))
    ]
    if lstm:
        frame = pd.concat([_split(r) for r in lstm], keys=range(None))
        rows.append(frame.groupby(level=1, sort=False).mean().loc[["lstm_autoencoder"]])
    return ordered(pd.concat(rows)[TYPES])


def x_synthetic_matrix__mutmut_42(evidence: Path, deep: Path) -> pd.DataFrame:
    classical = pd.read_csv(evidence / "synthetic_recall.csv", index_col="method")
    classical = classical[[f"{t}_mean" for t in TYPES]].set_axis(TYPES, axis=1)
    rows = [classical, deep_mean(deep, "synthetic_seed_*.json")]
    lstm = [
        json.loads(p.read_text())["recall"]
        for p in sorted((evidence / "deep_typed").glob("seed_*.json"))
    ]
    if lstm:
        frame = pd.concat([_split(r) for r in lstm], keys=range(len(lstm)))
        rows.append(None)
    return ordered(pd.concat(rows)[TYPES])


def x_synthetic_matrix__mutmut_43(evidence: Path, deep: Path) -> pd.DataFrame:
    classical = pd.read_csv(evidence / "synthetic_recall.csv", index_col="method")
    classical = classical[[f"{t}_mean" for t in TYPES]].set_axis(TYPES, axis=1)
    rows = [classical, deep_mean(deep, "synthetic_seed_*.json")]
    lstm = [
        json.loads(p.read_text())["recall"]
        for p in sorted((evidence / "deep_typed").glob("seed_*.json"))
    ]
    if lstm:
        frame = pd.concat([_split(r) for r in lstm], keys=range(len(lstm)))
        rows.append(frame.groupby(level=None, sort=False).mean().loc[["lstm_autoencoder"]])
    return ordered(pd.concat(rows)[TYPES])


def x_synthetic_matrix__mutmut_44(evidence: Path, deep: Path) -> pd.DataFrame:
    classical = pd.read_csv(evidence / "synthetic_recall.csv", index_col="method")
    classical = classical[[f"{t}_mean" for t in TYPES]].set_axis(TYPES, axis=1)
    rows = [classical, deep_mean(deep, "synthetic_seed_*.json")]
    lstm = [
        json.loads(p.read_text())["recall"]
        for p in sorted((evidence / "deep_typed").glob("seed_*.json"))
    ]
    if lstm:
        frame = pd.concat([_split(r) for r in lstm], keys=range(len(lstm)))
        rows.append(frame.groupby(level=1, sort=None).mean().loc[["lstm_autoencoder"]])
    return ordered(pd.concat(rows)[TYPES])


def x_synthetic_matrix__mutmut_45(evidence: Path, deep: Path) -> pd.DataFrame:
    classical = pd.read_csv(evidence / "synthetic_recall.csv", index_col="method")
    classical = classical[[f"{t}_mean" for t in TYPES]].set_axis(TYPES, axis=1)
    rows = [classical, deep_mean(deep, "synthetic_seed_*.json")]
    lstm = [
        json.loads(p.read_text())["recall"]
        for p in sorted((evidence / "deep_typed").glob("seed_*.json"))
    ]
    if lstm:
        frame = pd.concat([_split(r) for r in lstm], keys=range(len(lstm)))
        rows.append(frame.groupby(sort=False).mean().loc[["lstm_autoencoder"]])
    return ordered(pd.concat(rows)[TYPES])


def x_synthetic_matrix__mutmut_46(evidence: Path, deep: Path) -> pd.DataFrame:
    classical = pd.read_csv(evidence / "synthetic_recall.csv", index_col="method")
    classical = classical[[f"{t}_mean" for t in TYPES]].set_axis(TYPES, axis=1)
    rows = [classical, deep_mean(deep, "synthetic_seed_*.json")]
    lstm = [
        json.loads(p.read_text())["recall"]
        for p in sorted((evidence / "deep_typed").glob("seed_*.json"))
    ]
    if lstm:
        frame = pd.concat([_split(r) for r in lstm], keys=range(len(lstm)))
        rows.append(frame.groupby(level=1, ).mean().loc[["lstm_autoencoder"]])
    return ordered(pd.concat(rows)[TYPES])


def x_synthetic_matrix__mutmut_47(evidence: Path, deep: Path) -> pd.DataFrame:
    classical = pd.read_csv(evidence / "synthetic_recall.csv", index_col="method")
    classical = classical[[f"{t}_mean" for t in TYPES]].set_axis(TYPES, axis=1)
    rows = [classical, deep_mean(deep, "synthetic_seed_*.json")]
    lstm = [
        json.loads(p.read_text())["recall"]
        for p in sorted((evidence / "deep_typed").glob("seed_*.json"))
    ]
    if lstm:
        frame = pd.concat([_split(r) for r in lstm], keys=range(len(lstm)))
        rows.append(frame.groupby(level=2, sort=False).mean().loc[["lstm_autoencoder"]])
    return ordered(pd.concat(rows)[TYPES])


def x_synthetic_matrix__mutmut_48(evidence: Path, deep: Path) -> pd.DataFrame:
    classical = pd.read_csv(evidence / "synthetic_recall.csv", index_col="method")
    classical = classical[[f"{t}_mean" for t in TYPES]].set_axis(TYPES, axis=1)
    rows = [classical, deep_mean(deep, "synthetic_seed_*.json")]
    lstm = [
        json.loads(p.read_text())["recall"]
        for p in sorted((evidence / "deep_typed").glob("seed_*.json"))
    ]
    if lstm:
        frame = pd.concat([_split(r) for r in lstm], keys=range(len(lstm)))
        rows.append(frame.groupby(level=1, sort=True).mean().loc[["lstm_autoencoder"]])
    return ordered(pd.concat(rows)[TYPES])


def x_synthetic_matrix__mutmut_49(evidence: Path, deep: Path) -> pd.DataFrame:
    classical = pd.read_csv(evidence / "synthetic_recall.csv", index_col="method")
    classical = classical[[f"{t}_mean" for t in TYPES]].set_axis(TYPES, axis=1)
    rows = [classical, deep_mean(deep, "synthetic_seed_*.json")]
    lstm = [
        json.loads(p.read_text())["recall"]
        for p in sorted((evidence / "deep_typed").glob("seed_*.json"))
    ]
    if lstm:
        frame = pd.concat([_split(r) for r in lstm], keys=range(len(lstm)))
        rows.append(frame.groupby(level=1, sort=False).mean().loc[["XXlstm_autoencoderXX"]])
    return ordered(pd.concat(rows)[TYPES])


def x_synthetic_matrix__mutmut_50(evidence: Path, deep: Path) -> pd.DataFrame:
    classical = pd.read_csv(evidence / "synthetic_recall.csv", index_col="method")
    classical = classical[[f"{t}_mean" for t in TYPES]].set_axis(TYPES, axis=1)
    rows = [classical, deep_mean(deep, "synthetic_seed_*.json")]
    lstm = [
        json.loads(p.read_text())["recall"]
        for p in sorted((evidence / "deep_typed").glob("seed_*.json"))
    ]
    if lstm:
        frame = pd.concat([_split(r) for r in lstm], keys=range(len(lstm)))
        rows.append(frame.groupby(level=1, sort=False).mean().loc[["LSTM_AUTOENCODER"]])
    return ordered(pd.concat(rows)[TYPES])


def x_synthetic_matrix__mutmut_51(evidence: Path, deep: Path) -> pd.DataFrame:
    classical = pd.read_csv(evidence / "synthetic_recall.csv", index_col="method")
    classical = classical[[f"{t}_mean" for t in TYPES]].set_axis(TYPES, axis=1)
    rows = [classical, deep_mean(deep, "synthetic_seed_*.json")]
    lstm = [
        json.loads(p.read_text())["recall"]
        for p in sorted((evidence / "deep_typed").glob("seed_*.json"))
    ]
    if lstm:
        frame = pd.concat([_split(r) for r in lstm], keys=range(len(lstm)))
        rows.append(frame.groupby(level=1, sort=False).mean().loc[["lstm_autoencoder"]])
    return ordered(None)


def x_synthetic_matrix__mutmut_52(evidence: Path, deep: Path) -> pd.DataFrame:
    classical = pd.read_csv(evidence / "synthetic_recall.csv", index_col="method")
    classical = classical[[f"{t}_mean" for t in TYPES]].set_axis(TYPES, axis=1)
    rows = [classical, deep_mean(deep, "synthetic_seed_*.json")]
    lstm = [
        json.loads(p.read_text())["recall"]
        for p in sorted((evidence / "deep_typed").glob("seed_*.json"))
    ]
    if lstm:
        frame = pd.concat([_split(r) for r in lstm], keys=range(len(lstm)))
        rows.append(frame.groupby(level=1, sort=False).mean().loc[["lstm_autoencoder"]])
    return ordered(pd.concat(None)[TYPES])

mutants_x_synthetic_matrix__mutmut['_mutmut_orig'] = x_synthetic_matrix__mutmut_orig # type: ignore # mutmut generated
mutants_x_synthetic_matrix__mutmut['x_synthetic_matrix__mutmut_1'] = x_synthetic_matrix__mutmut_1 # type: ignore # mutmut generated
mutants_x_synthetic_matrix__mutmut['x_synthetic_matrix__mutmut_2'] = x_synthetic_matrix__mutmut_2 # type: ignore # mutmut generated
mutants_x_synthetic_matrix__mutmut['x_synthetic_matrix__mutmut_3'] = x_synthetic_matrix__mutmut_3 # type: ignore # mutmut generated
mutants_x_synthetic_matrix__mutmut['x_synthetic_matrix__mutmut_4'] = x_synthetic_matrix__mutmut_4 # type: ignore # mutmut generated
mutants_x_synthetic_matrix__mutmut['x_synthetic_matrix__mutmut_5'] = x_synthetic_matrix__mutmut_5 # type: ignore # mutmut generated
mutants_x_synthetic_matrix__mutmut['x_synthetic_matrix__mutmut_6'] = x_synthetic_matrix__mutmut_6 # type: ignore # mutmut generated
mutants_x_synthetic_matrix__mutmut['x_synthetic_matrix__mutmut_7'] = x_synthetic_matrix__mutmut_7 # type: ignore # mutmut generated
mutants_x_synthetic_matrix__mutmut['x_synthetic_matrix__mutmut_8'] = x_synthetic_matrix__mutmut_8 # type: ignore # mutmut generated
mutants_x_synthetic_matrix__mutmut['x_synthetic_matrix__mutmut_9'] = x_synthetic_matrix__mutmut_9 # type: ignore # mutmut generated
mutants_x_synthetic_matrix__mutmut['x_synthetic_matrix__mutmut_10'] = x_synthetic_matrix__mutmut_10 # type: ignore # mutmut generated
mutants_x_synthetic_matrix__mutmut['x_synthetic_matrix__mutmut_11'] = x_synthetic_matrix__mutmut_11 # type: ignore # mutmut generated
mutants_x_synthetic_matrix__mutmut['x_synthetic_matrix__mutmut_12'] = x_synthetic_matrix__mutmut_12 # type: ignore # mutmut generated
mutants_x_synthetic_matrix__mutmut['x_synthetic_matrix__mutmut_13'] = x_synthetic_matrix__mutmut_13 # type: ignore # mutmut generated
mutants_x_synthetic_matrix__mutmut['x_synthetic_matrix__mutmut_14'] = x_synthetic_matrix__mutmut_14 # type: ignore # mutmut generated
mutants_x_synthetic_matrix__mutmut['x_synthetic_matrix__mutmut_15'] = x_synthetic_matrix__mutmut_15 # type: ignore # mutmut generated
mutants_x_synthetic_matrix__mutmut['x_synthetic_matrix__mutmut_16'] = x_synthetic_matrix__mutmut_16 # type: ignore # mutmut generated
mutants_x_synthetic_matrix__mutmut['x_synthetic_matrix__mutmut_17'] = x_synthetic_matrix__mutmut_17 # type: ignore # mutmut generated
mutants_x_synthetic_matrix__mutmut['x_synthetic_matrix__mutmut_18'] = x_synthetic_matrix__mutmut_18 # type: ignore # mutmut generated
mutants_x_synthetic_matrix__mutmut['x_synthetic_matrix__mutmut_19'] = x_synthetic_matrix__mutmut_19 # type: ignore # mutmut generated
mutants_x_synthetic_matrix__mutmut['x_synthetic_matrix__mutmut_20'] = x_synthetic_matrix__mutmut_20 # type: ignore # mutmut generated
mutants_x_synthetic_matrix__mutmut['x_synthetic_matrix__mutmut_21'] = x_synthetic_matrix__mutmut_21 # type: ignore # mutmut generated
mutants_x_synthetic_matrix__mutmut['x_synthetic_matrix__mutmut_22'] = x_synthetic_matrix__mutmut_22 # type: ignore # mutmut generated
mutants_x_synthetic_matrix__mutmut['x_synthetic_matrix__mutmut_23'] = x_synthetic_matrix__mutmut_23 # type: ignore # mutmut generated
mutants_x_synthetic_matrix__mutmut['x_synthetic_matrix__mutmut_24'] = x_synthetic_matrix__mutmut_24 # type: ignore # mutmut generated
mutants_x_synthetic_matrix__mutmut['x_synthetic_matrix__mutmut_25'] = x_synthetic_matrix__mutmut_25 # type: ignore # mutmut generated
mutants_x_synthetic_matrix__mutmut['x_synthetic_matrix__mutmut_26'] = x_synthetic_matrix__mutmut_26 # type: ignore # mutmut generated
mutants_x_synthetic_matrix__mutmut['x_synthetic_matrix__mutmut_27'] = x_synthetic_matrix__mutmut_27 # type: ignore # mutmut generated
mutants_x_synthetic_matrix__mutmut['x_synthetic_matrix__mutmut_28'] = x_synthetic_matrix__mutmut_28 # type: ignore # mutmut generated
mutants_x_synthetic_matrix__mutmut['x_synthetic_matrix__mutmut_29'] = x_synthetic_matrix__mutmut_29 # type: ignore # mutmut generated
mutants_x_synthetic_matrix__mutmut['x_synthetic_matrix__mutmut_30'] = x_synthetic_matrix__mutmut_30 # type: ignore # mutmut generated
mutants_x_synthetic_matrix__mutmut['x_synthetic_matrix__mutmut_31'] = x_synthetic_matrix__mutmut_31 # type: ignore # mutmut generated
mutants_x_synthetic_matrix__mutmut['x_synthetic_matrix__mutmut_32'] = x_synthetic_matrix__mutmut_32 # type: ignore # mutmut generated
mutants_x_synthetic_matrix__mutmut['x_synthetic_matrix__mutmut_33'] = x_synthetic_matrix__mutmut_33 # type: ignore # mutmut generated
mutants_x_synthetic_matrix__mutmut['x_synthetic_matrix__mutmut_34'] = x_synthetic_matrix__mutmut_34 # type: ignore # mutmut generated
mutants_x_synthetic_matrix__mutmut['x_synthetic_matrix__mutmut_35'] = x_synthetic_matrix__mutmut_35 # type: ignore # mutmut generated
mutants_x_synthetic_matrix__mutmut['x_synthetic_matrix__mutmut_36'] = x_synthetic_matrix__mutmut_36 # type: ignore # mutmut generated
mutants_x_synthetic_matrix__mutmut['x_synthetic_matrix__mutmut_37'] = x_synthetic_matrix__mutmut_37 # type: ignore # mutmut generated
mutants_x_synthetic_matrix__mutmut['x_synthetic_matrix__mutmut_38'] = x_synthetic_matrix__mutmut_38 # type: ignore # mutmut generated
mutants_x_synthetic_matrix__mutmut['x_synthetic_matrix__mutmut_39'] = x_synthetic_matrix__mutmut_39 # type: ignore # mutmut generated
mutants_x_synthetic_matrix__mutmut['x_synthetic_matrix__mutmut_40'] = x_synthetic_matrix__mutmut_40 # type: ignore # mutmut generated
mutants_x_synthetic_matrix__mutmut['x_synthetic_matrix__mutmut_41'] = x_synthetic_matrix__mutmut_41 # type: ignore # mutmut generated
mutants_x_synthetic_matrix__mutmut['x_synthetic_matrix__mutmut_42'] = x_synthetic_matrix__mutmut_42 # type: ignore # mutmut generated
mutants_x_synthetic_matrix__mutmut['x_synthetic_matrix__mutmut_43'] = x_synthetic_matrix__mutmut_43 # type: ignore # mutmut generated
mutants_x_synthetic_matrix__mutmut['x_synthetic_matrix__mutmut_44'] = x_synthetic_matrix__mutmut_44 # type: ignore # mutmut generated
mutants_x_synthetic_matrix__mutmut['x_synthetic_matrix__mutmut_45'] = x_synthetic_matrix__mutmut_45 # type: ignore # mutmut generated
mutants_x_synthetic_matrix__mutmut['x_synthetic_matrix__mutmut_46'] = x_synthetic_matrix__mutmut_46 # type: ignore # mutmut generated
mutants_x_synthetic_matrix__mutmut['x_synthetic_matrix__mutmut_47'] = x_synthetic_matrix__mutmut_47 # type: ignore # mutmut generated
mutants_x_synthetic_matrix__mutmut['x_synthetic_matrix__mutmut_48'] = x_synthetic_matrix__mutmut_48 # type: ignore # mutmut generated
mutants_x_synthetic_matrix__mutmut['x_synthetic_matrix__mutmut_49'] = x_synthetic_matrix__mutmut_49 # type: ignore # mutmut generated
mutants_x_synthetic_matrix__mutmut['x_synthetic_matrix__mutmut_50'] = x_synthetic_matrix__mutmut_50 # type: ignore # mutmut generated
mutants_x_synthetic_matrix__mutmut['x_synthetic_matrix__mutmut_51'] = x_synthetic_matrix__mutmut_51 # type: ignore # mutmut generated
mutants_x_synthetic_matrix__mutmut['x_synthetic_matrix__mutmut_52'] = x_synthetic_matrix__mutmut_52 # type: ignore # mutmut generated
mutants_x_schema_matrices__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_schema_matrices__mutmut)
def schema_matrices(multi: Path, deep: Path) -> dict[str, pd.DataFrame]:
    classical = json.loads((multi / "multi_schema_results.json").read_text())["mean"]
    out = {}
    for name, payload in classical.items():
        base = _split(payload)
        if name == "customer":
            continue
        extra = deep_mean(deep, f"{name}_seed_*.json")
        out[name] = ordered(pd.concat([base, extra])[TYPES])
    return out


def x_schema_matrices__mutmut_orig(multi: Path, deep: Path) -> dict[str, pd.DataFrame]:
    classical = json.loads((multi / "multi_schema_results.json").read_text())["mean"]
    out = {}
    for name, payload in classical.items():
        base = _split(payload)
        if name == "customer":
            continue
        extra = deep_mean(deep, f"{name}_seed_*.json")
        out[name] = ordered(pd.concat([base, extra])[TYPES])
    return out


def x_schema_matrices__mutmut_1(multi: Path, deep: Path) -> dict[str, pd.DataFrame]:
    classical = None
    out = {}
    for name, payload in classical.items():
        base = _split(payload)
        if name == "customer":
            continue
        extra = deep_mean(deep, f"{name}_seed_*.json")
        out[name] = ordered(pd.concat([base, extra])[TYPES])
    return out


def x_schema_matrices__mutmut_2(multi: Path, deep: Path) -> dict[str, pd.DataFrame]:
    classical = json.loads(None)["mean"]
    out = {}
    for name, payload in classical.items():
        base = _split(payload)
        if name == "customer":
            continue
        extra = deep_mean(deep, f"{name}_seed_*.json")
        out[name] = ordered(pd.concat([base, extra])[TYPES])
    return out


def x_schema_matrices__mutmut_3(multi: Path, deep: Path) -> dict[str, pd.DataFrame]:
    classical = json.loads((multi * "multi_schema_results.json").read_text())["mean"]
    out = {}
    for name, payload in classical.items():
        base = _split(payload)
        if name == "customer":
            continue
        extra = deep_mean(deep, f"{name}_seed_*.json")
        out[name] = ordered(pd.concat([base, extra])[TYPES])
    return out


def x_schema_matrices__mutmut_4(multi: Path, deep: Path) -> dict[str, pd.DataFrame]:
    classical = json.loads((multi / "XXmulti_schema_results.jsonXX").read_text())["mean"]
    out = {}
    for name, payload in classical.items():
        base = _split(payload)
        if name == "customer":
            continue
        extra = deep_mean(deep, f"{name}_seed_*.json")
        out[name] = ordered(pd.concat([base, extra])[TYPES])
    return out


def x_schema_matrices__mutmut_5(multi: Path, deep: Path) -> dict[str, pd.DataFrame]:
    classical = json.loads((multi / "MULTI_SCHEMA_RESULTS.JSON").read_text())["mean"]
    out = {}
    for name, payload in classical.items():
        base = _split(payload)
        if name == "customer":
            continue
        extra = deep_mean(deep, f"{name}_seed_*.json")
        out[name] = ordered(pd.concat([base, extra])[TYPES])
    return out


def x_schema_matrices__mutmut_6(multi: Path, deep: Path) -> dict[str, pd.DataFrame]:
    classical = json.loads((multi / "multi_schema_results.json").read_text())["XXmeanXX"]
    out = {}
    for name, payload in classical.items():
        base = _split(payload)
        if name == "customer":
            continue
        extra = deep_mean(deep, f"{name}_seed_*.json")
        out[name] = ordered(pd.concat([base, extra])[TYPES])
    return out


def x_schema_matrices__mutmut_7(multi: Path, deep: Path) -> dict[str, pd.DataFrame]:
    classical = json.loads((multi / "multi_schema_results.json").read_text())["MEAN"]
    out = {}
    for name, payload in classical.items():
        base = _split(payload)
        if name == "customer":
            continue
        extra = deep_mean(deep, f"{name}_seed_*.json")
        out[name] = ordered(pd.concat([base, extra])[TYPES])
    return out


def x_schema_matrices__mutmut_8(multi: Path, deep: Path) -> dict[str, pd.DataFrame]:
    classical = json.loads((multi / "multi_schema_results.json").read_text())["mean"]
    out = None
    for name, payload in classical.items():
        base = _split(payload)
        if name == "customer":
            continue
        extra = deep_mean(deep, f"{name}_seed_*.json")
        out[name] = ordered(pd.concat([base, extra])[TYPES])
    return out


def x_schema_matrices__mutmut_9(multi: Path, deep: Path) -> dict[str, pd.DataFrame]:
    classical = json.loads((multi / "multi_schema_results.json").read_text())["mean"]
    out = {}
    for name, payload in classical.items():
        base = None
        if name == "customer":
            continue
        extra = deep_mean(deep, f"{name}_seed_*.json")
        out[name] = ordered(pd.concat([base, extra])[TYPES])
    return out


def x_schema_matrices__mutmut_10(multi: Path, deep: Path) -> dict[str, pd.DataFrame]:
    classical = json.loads((multi / "multi_schema_results.json").read_text())["mean"]
    out = {}
    for name, payload in classical.items():
        base = _split(None)
        if name == "customer":
            continue
        extra = deep_mean(deep, f"{name}_seed_*.json")
        out[name] = ordered(pd.concat([base, extra])[TYPES])
    return out


def x_schema_matrices__mutmut_11(multi: Path, deep: Path) -> dict[str, pd.DataFrame]:
    classical = json.loads((multi / "multi_schema_results.json").read_text())["mean"]
    out = {}
    for name, payload in classical.items():
        base = _split(payload)
        if name != "customer":
            continue
        extra = deep_mean(deep, f"{name}_seed_*.json")
        out[name] = ordered(pd.concat([base, extra])[TYPES])
    return out


def x_schema_matrices__mutmut_12(multi: Path, deep: Path) -> dict[str, pd.DataFrame]:
    classical = json.loads((multi / "multi_schema_results.json").read_text())["mean"]
    out = {}
    for name, payload in classical.items():
        base = _split(payload)
        if name == "XXcustomerXX":
            continue
        extra = deep_mean(deep, f"{name}_seed_*.json")
        out[name] = ordered(pd.concat([base, extra])[TYPES])
    return out


def x_schema_matrices__mutmut_13(multi: Path, deep: Path) -> dict[str, pd.DataFrame]:
    classical = json.loads((multi / "multi_schema_results.json").read_text())["mean"]
    out = {}
    for name, payload in classical.items():
        base = _split(payload)
        if name == "CUSTOMER":
            continue
        extra = deep_mean(deep, f"{name}_seed_*.json")
        out[name] = ordered(pd.concat([base, extra])[TYPES])
    return out


def x_schema_matrices__mutmut_14(multi: Path, deep: Path) -> dict[str, pd.DataFrame]:
    classical = json.loads((multi / "multi_schema_results.json").read_text())["mean"]
    out = {}
    for name, payload in classical.items():
        base = _split(payload)
        if name == "customer":
            break
        extra = deep_mean(deep, f"{name}_seed_*.json")
        out[name] = ordered(pd.concat([base, extra])[TYPES])
    return out


def x_schema_matrices__mutmut_15(multi: Path, deep: Path) -> dict[str, pd.DataFrame]:
    classical = json.loads((multi / "multi_schema_results.json").read_text())["mean"]
    out = {}
    for name, payload in classical.items():
        base = _split(payload)
        if name == "customer":
            continue
        extra = None
        out[name] = ordered(pd.concat([base, extra])[TYPES])
    return out


def x_schema_matrices__mutmut_16(multi: Path, deep: Path) -> dict[str, pd.DataFrame]:
    classical = json.loads((multi / "multi_schema_results.json").read_text())["mean"]
    out = {}
    for name, payload in classical.items():
        base = _split(payload)
        if name == "customer":
            continue
        extra = deep_mean(None, f"{name}_seed_*.json")
        out[name] = ordered(pd.concat([base, extra])[TYPES])
    return out


def x_schema_matrices__mutmut_17(multi: Path, deep: Path) -> dict[str, pd.DataFrame]:
    classical = json.loads((multi / "multi_schema_results.json").read_text())["mean"]
    out = {}
    for name, payload in classical.items():
        base = _split(payload)
        if name == "customer":
            continue
        extra = deep_mean(deep, None)
        out[name] = ordered(pd.concat([base, extra])[TYPES])
    return out


def x_schema_matrices__mutmut_18(multi: Path, deep: Path) -> dict[str, pd.DataFrame]:
    classical = json.loads((multi / "multi_schema_results.json").read_text())["mean"]
    out = {}
    for name, payload in classical.items():
        base = _split(payload)
        if name == "customer":
            continue
        extra = deep_mean(f"{name}_seed_*.json")
        out[name] = ordered(pd.concat([base, extra])[TYPES])
    return out


def x_schema_matrices__mutmut_19(multi: Path, deep: Path) -> dict[str, pd.DataFrame]:
    classical = json.loads((multi / "multi_schema_results.json").read_text())["mean"]
    out = {}
    for name, payload in classical.items():
        base = _split(payload)
        if name == "customer":
            continue
        extra = deep_mean(deep, )
        out[name] = ordered(pd.concat([base, extra])[TYPES])
    return out


def x_schema_matrices__mutmut_20(multi: Path, deep: Path) -> dict[str, pd.DataFrame]:
    classical = json.loads((multi / "multi_schema_results.json").read_text())["mean"]
    out = {}
    for name, payload in classical.items():
        base = _split(payload)
        if name == "customer":
            continue
        extra = deep_mean(deep, f"{name}_seed_*.json")
        out[name] = None
    return out


def x_schema_matrices__mutmut_21(multi: Path, deep: Path) -> dict[str, pd.DataFrame]:
    classical = json.loads((multi / "multi_schema_results.json").read_text())["mean"]
    out = {}
    for name, payload in classical.items():
        base = _split(payload)
        if name == "customer":
            continue
        extra = deep_mean(deep, f"{name}_seed_*.json")
        out[name] = ordered(None)
    return out


def x_schema_matrices__mutmut_22(multi: Path, deep: Path) -> dict[str, pd.DataFrame]:
    classical = json.loads((multi / "multi_schema_results.json").read_text())["mean"]
    out = {}
    for name, payload in classical.items():
        base = _split(payload)
        if name == "customer":
            continue
        extra = deep_mean(deep, f"{name}_seed_*.json")
        out[name] = ordered(pd.concat(None)[TYPES])
    return out

mutants_x_schema_matrices__mutmut['_mutmut_orig'] = x_schema_matrices__mutmut_orig # type: ignore # mutmut generated
mutants_x_schema_matrices__mutmut['x_schema_matrices__mutmut_1'] = x_schema_matrices__mutmut_1 # type: ignore # mutmut generated
mutants_x_schema_matrices__mutmut['x_schema_matrices__mutmut_2'] = x_schema_matrices__mutmut_2 # type: ignore # mutmut generated
mutants_x_schema_matrices__mutmut['x_schema_matrices__mutmut_3'] = x_schema_matrices__mutmut_3 # type: ignore # mutmut generated
mutants_x_schema_matrices__mutmut['x_schema_matrices__mutmut_4'] = x_schema_matrices__mutmut_4 # type: ignore # mutmut generated
mutants_x_schema_matrices__mutmut['x_schema_matrices__mutmut_5'] = x_schema_matrices__mutmut_5 # type: ignore # mutmut generated
mutants_x_schema_matrices__mutmut['x_schema_matrices__mutmut_6'] = x_schema_matrices__mutmut_6 # type: ignore # mutmut generated
mutants_x_schema_matrices__mutmut['x_schema_matrices__mutmut_7'] = x_schema_matrices__mutmut_7 # type: ignore # mutmut generated
mutants_x_schema_matrices__mutmut['x_schema_matrices__mutmut_8'] = x_schema_matrices__mutmut_8 # type: ignore # mutmut generated
mutants_x_schema_matrices__mutmut['x_schema_matrices__mutmut_9'] = x_schema_matrices__mutmut_9 # type: ignore # mutmut generated
mutants_x_schema_matrices__mutmut['x_schema_matrices__mutmut_10'] = x_schema_matrices__mutmut_10 # type: ignore # mutmut generated
mutants_x_schema_matrices__mutmut['x_schema_matrices__mutmut_11'] = x_schema_matrices__mutmut_11 # type: ignore # mutmut generated
mutants_x_schema_matrices__mutmut['x_schema_matrices__mutmut_12'] = x_schema_matrices__mutmut_12 # type: ignore # mutmut generated
mutants_x_schema_matrices__mutmut['x_schema_matrices__mutmut_13'] = x_schema_matrices__mutmut_13 # type: ignore # mutmut generated
mutants_x_schema_matrices__mutmut['x_schema_matrices__mutmut_14'] = x_schema_matrices__mutmut_14 # type: ignore # mutmut generated
mutants_x_schema_matrices__mutmut['x_schema_matrices__mutmut_15'] = x_schema_matrices__mutmut_15 # type: ignore # mutmut generated
mutants_x_schema_matrices__mutmut['x_schema_matrices__mutmut_16'] = x_schema_matrices__mutmut_16 # type: ignore # mutmut generated
mutants_x_schema_matrices__mutmut['x_schema_matrices__mutmut_17'] = x_schema_matrices__mutmut_17 # type: ignore # mutmut generated
mutants_x_schema_matrices__mutmut['x_schema_matrices__mutmut_18'] = x_schema_matrices__mutmut_18 # type: ignore # mutmut generated
mutants_x_schema_matrices__mutmut['x_schema_matrices__mutmut_19'] = x_schema_matrices__mutmut_19 # type: ignore # mutmut generated
mutants_x_schema_matrices__mutmut['x_schema_matrices__mutmut_20'] = x_schema_matrices__mutmut_20 # type: ignore # mutmut generated
mutants_x_schema_matrices__mutmut['x_schema_matrices__mutmut_21'] = x_schema_matrices__mutmut_21 # type: ignore # mutmut generated
mutants_x_schema_matrices__mutmut['x_schema_matrices__mutmut_22'] = x_schema_matrices__mutmut_22 # type: ignore # mutmut generated
mutants_x_real_table__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_real_table__mutmut)
def real_table(classical_csv: Path, deep_json: Path) -> pd.DataFrame:
    cols = ["precision", "recall", "f1", "roc_auc", "pr_auc", "flagged_pct"]
    base = pd.read_csv(classical_csv, index_col=0)[[f"{c}_mean" for c in cols]]
    base.columns = cols
    runs = json.loads(deep_json.read_text())["runs"]
    rows = {}
    for name in runs[0]["methods"]:
        ok = [r["methods"][name] for r in runs if "error" not in r["methods"][name]]
        if ok:
            rows[name] = {c: float(np.mean([r[c] for r in ok])) for c in cols}
    return ordered(pd.concat([base, pd.DataFrame(rows).T[cols]]))


def x_real_table__mutmut_orig(classical_csv: Path, deep_json: Path) -> pd.DataFrame:
    cols = ["precision", "recall", "f1", "roc_auc", "pr_auc", "flagged_pct"]
    base = pd.read_csv(classical_csv, index_col=0)[[f"{c}_mean" for c in cols]]
    base.columns = cols
    runs = json.loads(deep_json.read_text())["runs"]
    rows = {}
    for name in runs[0]["methods"]:
        ok = [r["methods"][name] for r in runs if "error" not in r["methods"][name]]
        if ok:
            rows[name] = {c: float(np.mean([r[c] for r in ok])) for c in cols}
    return ordered(pd.concat([base, pd.DataFrame(rows).T[cols]]))


def x_real_table__mutmut_1(classical_csv: Path, deep_json: Path) -> pd.DataFrame:
    cols = None
    base = pd.read_csv(classical_csv, index_col=0)[[f"{c}_mean" for c in cols]]
    base.columns = cols
    runs = json.loads(deep_json.read_text())["runs"]
    rows = {}
    for name in runs[0]["methods"]:
        ok = [r["methods"][name] for r in runs if "error" not in r["methods"][name]]
        if ok:
            rows[name] = {c: float(np.mean([r[c] for r in ok])) for c in cols}
    return ordered(pd.concat([base, pd.DataFrame(rows).T[cols]]))


def x_real_table__mutmut_2(classical_csv: Path, deep_json: Path) -> pd.DataFrame:
    cols = ["XXprecisionXX", "recall", "f1", "roc_auc", "pr_auc", "flagged_pct"]
    base = pd.read_csv(classical_csv, index_col=0)[[f"{c}_mean" for c in cols]]
    base.columns = cols
    runs = json.loads(deep_json.read_text())["runs"]
    rows = {}
    for name in runs[0]["methods"]:
        ok = [r["methods"][name] for r in runs if "error" not in r["methods"][name]]
        if ok:
            rows[name] = {c: float(np.mean([r[c] for r in ok])) for c in cols}
    return ordered(pd.concat([base, pd.DataFrame(rows).T[cols]]))


def x_real_table__mutmut_3(classical_csv: Path, deep_json: Path) -> pd.DataFrame:
    cols = ["PRECISION", "recall", "f1", "roc_auc", "pr_auc", "flagged_pct"]
    base = pd.read_csv(classical_csv, index_col=0)[[f"{c}_mean" for c in cols]]
    base.columns = cols
    runs = json.loads(deep_json.read_text())["runs"]
    rows = {}
    for name in runs[0]["methods"]:
        ok = [r["methods"][name] for r in runs if "error" not in r["methods"][name]]
        if ok:
            rows[name] = {c: float(np.mean([r[c] for r in ok])) for c in cols}
    return ordered(pd.concat([base, pd.DataFrame(rows).T[cols]]))


def x_real_table__mutmut_4(classical_csv: Path, deep_json: Path) -> pd.DataFrame:
    cols = ["precision", "XXrecallXX", "f1", "roc_auc", "pr_auc", "flagged_pct"]
    base = pd.read_csv(classical_csv, index_col=0)[[f"{c}_mean" for c in cols]]
    base.columns = cols
    runs = json.loads(deep_json.read_text())["runs"]
    rows = {}
    for name in runs[0]["methods"]:
        ok = [r["methods"][name] for r in runs if "error" not in r["methods"][name]]
        if ok:
            rows[name] = {c: float(np.mean([r[c] for r in ok])) for c in cols}
    return ordered(pd.concat([base, pd.DataFrame(rows).T[cols]]))


def x_real_table__mutmut_5(classical_csv: Path, deep_json: Path) -> pd.DataFrame:
    cols = ["precision", "RECALL", "f1", "roc_auc", "pr_auc", "flagged_pct"]
    base = pd.read_csv(classical_csv, index_col=0)[[f"{c}_mean" for c in cols]]
    base.columns = cols
    runs = json.loads(deep_json.read_text())["runs"]
    rows = {}
    for name in runs[0]["methods"]:
        ok = [r["methods"][name] for r in runs if "error" not in r["methods"][name]]
        if ok:
            rows[name] = {c: float(np.mean([r[c] for r in ok])) for c in cols}
    return ordered(pd.concat([base, pd.DataFrame(rows).T[cols]]))


def x_real_table__mutmut_6(classical_csv: Path, deep_json: Path) -> pd.DataFrame:
    cols = ["precision", "recall", "XXf1XX", "roc_auc", "pr_auc", "flagged_pct"]
    base = pd.read_csv(classical_csv, index_col=0)[[f"{c}_mean" for c in cols]]
    base.columns = cols
    runs = json.loads(deep_json.read_text())["runs"]
    rows = {}
    for name in runs[0]["methods"]:
        ok = [r["methods"][name] for r in runs if "error" not in r["methods"][name]]
        if ok:
            rows[name] = {c: float(np.mean([r[c] for r in ok])) for c in cols}
    return ordered(pd.concat([base, pd.DataFrame(rows).T[cols]]))


def x_real_table__mutmut_7(classical_csv: Path, deep_json: Path) -> pd.DataFrame:
    cols = ["precision", "recall", "F1", "roc_auc", "pr_auc", "flagged_pct"]
    base = pd.read_csv(classical_csv, index_col=0)[[f"{c}_mean" for c in cols]]
    base.columns = cols
    runs = json.loads(deep_json.read_text())["runs"]
    rows = {}
    for name in runs[0]["methods"]:
        ok = [r["methods"][name] for r in runs if "error" not in r["methods"][name]]
        if ok:
            rows[name] = {c: float(np.mean([r[c] for r in ok])) for c in cols}
    return ordered(pd.concat([base, pd.DataFrame(rows).T[cols]]))


def x_real_table__mutmut_8(classical_csv: Path, deep_json: Path) -> pd.DataFrame:
    cols = ["precision", "recall", "f1", "XXroc_aucXX", "pr_auc", "flagged_pct"]
    base = pd.read_csv(classical_csv, index_col=0)[[f"{c}_mean" for c in cols]]
    base.columns = cols
    runs = json.loads(deep_json.read_text())["runs"]
    rows = {}
    for name in runs[0]["methods"]:
        ok = [r["methods"][name] for r in runs if "error" not in r["methods"][name]]
        if ok:
            rows[name] = {c: float(np.mean([r[c] for r in ok])) for c in cols}
    return ordered(pd.concat([base, pd.DataFrame(rows).T[cols]]))


def x_real_table__mutmut_9(classical_csv: Path, deep_json: Path) -> pd.DataFrame:
    cols = ["precision", "recall", "f1", "ROC_AUC", "pr_auc", "flagged_pct"]
    base = pd.read_csv(classical_csv, index_col=0)[[f"{c}_mean" for c in cols]]
    base.columns = cols
    runs = json.loads(deep_json.read_text())["runs"]
    rows = {}
    for name in runs[0]["methods"]:
        ok = [r["methods"][name] for r in runs if "error" not in r["methods"][name]]
        if ok:
            rows[name] = {c: float(np.mean([r[c] for r in ok])) for c in cols}
    return ordered(pd.concat([base, pd.DataFrame(rows).T[cols]]))


def x_real_table__mutmut_10(classical_csv: Path, deep_json: Path) -> pd.DataFrame:
    cols = ["precision", "recall", "f1", "roc_auc", "XXpr_aucXX", "flagged_pct"]
    base = pd.read_csv(classical_csv, index_col=0)[[f"{c}_mean" for c in cols]]
    base.columns = cols
    runs = json.loads(deep_json.read_text())["runs"]
    rows = {}
    for name in runs[0]["methods"]:
        ok = [r["methods"][name] for r in runs if "error" not in r["methods"][name]]
        if ok:
            rows[name] = {c: float(np.mean([r[c] for r in ok])) for c in cols}
    return ordered(pd.concat([base, pd.DataFrame(rows).T[cols]]))


def x_real_table__mutmut_11(classical_csv: Path, deep_json: Path) -> pd.DataFrame:
    cols = ["precision", "recall", "f1", "roc_auc", "PR_AUC", "flagged_pct"]
    base = pd.read_csv(classical_csv, index_col=0)[[f"{c}_mean" for c in cols]]
    base.columns = cols
    runs = json.loads(deep_json.read_text())["runs"]
    rows = {}
    for name in runs[0]["methods"]:
        ok = [r["methods"][name] for r in runs if "error" not in r["methods"][name]]
        if ok:
            rows[name] = {c: float(np.mean([r[c] for r in ok])) for c in cols}
    return ordered(pd.concat([base, pd.DataFrame(rows).T[cols]]))


def x_real_table__mutmut_12(classical_csv: Path, deep_json: Path) -> pd.DataFrame:
    cols = ["precision", "recall", "f1", "roc_auc", "pr_auc", "XXflagged_pctXX"]
    base = pd.read_csv(classical_csv, index_col=0)[[f"{c}_mean" for c in cols]]
    base.columns = cols
    runs = json.loads(deep_json.read_text())["runs"]
    rows = {}
    for name in runs[0]["methods"]:
        ok = [r["methods"][name] for r in runs if "error" not in r["methods"][name]]
        if ok:
            rows[name] = {c: float(np.mean([r[c] for r in ok])) for c in cols}
    return ordered(pd.concat([base, pd.DataFrame(rows).T[cols]]))


def x_real_table__mutmut_13(classical_csv: Path, deep_json: Path) -> pd.DataFrame:
    cols = ["precision", "recall", "f1", "roc_auc", "pr_auc", "FLAGGED_PCT"]
    base = pd.read_csv(classical_csv, index_col=0)[[f"{c}_mean" for c in cols]]
    base.columns = cols
    runs = json.loads(deep_json.read_text())["runs"]
    rows = {}
    for name in runs[0]["methods"]:
        ok = [r["methods"][name] for r in runs if "error" not in r["methods"][name]]
        if ok:
            rows[name] = {c: float(np.mean([r[c] for r in ok])) for c in cols}
    return ordered(pd.concat([base, pd.DataFrame(rows).T[cols]]))


def x_real_table__mutmut_14(classical_csv: Path, deep_json: Path) -> pd.DataFrame:
    cols = ["precision", "recall", "f1", "roc_auc", "pr_auc", "flagged_pct"]
    base = None
    base.columns = cols
    runs = json.loads(deep_json.read_text())["runs"]
    rows = {}
    for name in runs[0]["methods"]:
        ok = [r["methods"][name] for r in runs if "error" not in r["methods"][name]]
        if ok:
            rows[name] = {c: float(np.mean([r[c] for r in ok])) for c in cols}
    return ordered(pd.concat([base, pd.DataFrame(rows).T[cols]]))


def x_real_table__mutmut_15(classical_csv: Path, deep_json: Path) -> pd.DataFrame:
    cols = ["precision", "recall", "f1", "roc_auc", "pr_auc", "flagged_pct"]
    base = pd.read_csv(None, index_col=0)[[f"{c}_mean" for c in cols]]
    base.columns = cols
    runs = json.loads(deep_json.read_text())["runs"]
    rows = {}
    for name in runs[0]["methods"]:
        ok = [r["methods"][name] for r in runs if "error" not in r["methods"][name]]
        if ok:
            rows[name] = {c: float(np.mean([r[c] for r in ok])) for c in cols}
    return ordered(pd.concat([base, pd.DataFrame(rows).T[cols]]))


def x_real_table__mutmut_16(classical_csv: Path, deep_json: Path) -> pd.DataFrame:
    cols = ["precision", "recall", "f1", "roc_auc", "pr_auc", "flagged_pct"]
    base = pd.read_csv(classical_csv, index_col=None)[[f"{c}_mean" for c in cols]]
    base.columns = cols
    runs = json.loads(deep_json.read_text())["runs"]
    rows = {}
    for name in runs[0]["methods"]:
        ok = [r["methods"][name] for r in runs if "error" not in r["methods"][name]]
        if ok:
            rows[name] = {c: float(np.mean([r[c] for r in ok])) for c in cols}
    return ordered(pd.concat([base, pd.DataFrame(rows).T[cols]]))


def x_real_table__mutmut_17(classical_csv: Path, deep_json: Path) -> pd.DataFrame:
    cols = ["precision", "recall", "f1", "roc_auc", "pr_auc", "flagged_pct"]
    base = pd.read_csv(index_col=0)[[f"{c}_mean" for c in cols]]
    base.columns = cols
    runs = json.loads(deep_json.read_text())["runs"]
    rows = {}
    for name in runs[0]["methods"]:
        ok = [r["methods"][name] for r in runs if "error" not in r["methods"][name]]
        if ok:
            rows[name] = {c: float(np.mean([r[c] for r in ok])) for c in cols}
    return ordered(pd.concat([base, pd.DataFrame(rows).T[cols]]))


def x_real_table__mutmut_18(classical_csv: Path, deep_json: Path) -> pd.DataFrame:
    cols = ["precision", "recall", "f1", "roc_auc", "pr_auc", "flagged_pct"]
    base = pd.read_csv(classical_csv, )[[f"{c}_mean" for c in cols]]
    base.columns = cols
    runs = json.loads(deep_json.read_text())["runs"]
    rows = {}
    for name in runs[0]["methods"]:
        ok = [r["methods"][name] for r in runs if "error" not in r["methods"][name]]
        if ok:
            rows[name] = {c: float(np.mean([r[c] for r in ok])) for c in cols}
    return ordered(pd.concat([base, pd.DataFrame(rows).T[cols]]))


def x_real_table__mutmut_19(classical_csv: Path, deep_json: Path) -> pd.DataFrame:
    cols = ["precision", "recall", "f1", "roc_auc", "pr_auc", "flagged_pct"]
    base = pd.read_csv(classical_csv, index_col=1)[[f"{c}_mean" for c in cols]]
    base.columns = cols
    runs = json.loads(deep_json.read_text())["runs"]
    rows = {}
    for name in runs[0]["methods"]:
        ok = [r["methods"][name] for r in runs if "error" not in r["methods"][name]]
        if ok:
            rows[name] = {c: float(np.mean([r[c] for r in ok])) for c in cols}
    return ordered(pd.concat([base, pd.DataFrame(rows).T[cols]]))


def x_real_table__mutmut_20(classical_csv: Path, deep_json: Path) -> pd.DataFrame:
    cols = ["precision", "recall", "f1", "roc_auc", "pr_auc", "flagged_pct"]
    base = pd.read_csv(classical_csv, index_col=0)[[f"{c}_mean" for c in cols]]
    base.columns = None
    runs = json.loads(deep_json.read_text())["runs"]
    rows = {}
    for name in runs[0]["methods"]:
        ok = [r["methods"][name] for r in runs if "error" not in r["methods"][name]]
        if ok:
            rows[name] = {c: float(np.mean([r[c] for r in ok])) for c in cols}
    return ordered(pd.concat([base, pd.DataFrame(rows).T[cols]]))


def x_real_table__mutmut_21(classical_csv: Path, deep_json: Path) -> pd.DataFrame:
    cols = ["precision", "recall", "f1", "roc_auc", "pr_auc", "flagged_pct"]
    base = pd.read_csv(classical_csv, index_col=0)[[f"{c}_mean" for c in cols]]
    base.columns = cols
    runs = None
    rows = {}
    for name in runs[0]["methods"]:
        ok = [r["methods"][name] for r in runs if "error" not in r["methods"][name]]
        if ok:
            rows[name] = {c: float(np.mean([r[c] for r in ok])) for c in cols}
    return ordered(pd.concat([base, pd.DataFrame(rows).T[cols]]))


def x_real_table__mutmut_22(classical_csv: Path, deep_json: Path) -> pd.DataFrame:
    cols = ["precision", "recall", "f1", "roc_auc", "pr_auc", "flagged_pct"]
    base = pd.read_csv(classical_csv, index_col=0)[[f"{c}_mean" for c in cols]]
    base.columns = cols
    runs = json.loads(None)["runs"]
    rows = {}
    for name in runs[0]["methods"]:
        ok = [r["methods"][name] for r in runs if "error" not in r["methods"][name]]
        if ok:
            rows[name] = {c: float(np.mean([r[c] for r in ok])) for c in cols}
    return ordered(pd.concat([base, pd.DataFrame(rows).T[cols]]))


def x_real_table__mutmut_23(classical_csv: Path, deep_json: Path) -> pd.DataFrame:
    cols = ["precision", "recall", "f1", "roc_auc", "pr_auc", "flagged_pct"]
    base = pd.read_csv(classical_csv, index_col=0)[[f"{c}_mean" for c in cols]]
    base.columns = cols
    runs = json.loads(deep_json.read_text())["XXrunsXX"]
    rows = {}
    for name in runs[0]["methods"]:
        ok = [r["methods"][name] for r in runs if "error" not in r["methods"][name]]
        if ok:
            rows[name] = {c: float(np.mean([r[c] for r in ok])) for c in cols}
    return ordered(pd.concat([base, pd.DataFrame(rows).T[cols]]))


def x_real_table__mutmut_24(classical_csv: Path, deep_json: Path) -> pd.DataFrame:
    cols = ["precision", "recall", "f1", "roc_auc", "pr_auc", "flagged_pct"]
    base = pd.read_csv(classical_csv, index_col=0)[[f"{c}_mean" for c in cols]]
    base.columns = cols
    runs = json.loads(deep_json.read_text())["RUNS"]
    rows = {}
    for name in runs[0]["methods"]:
        ok = [r["methods"][name] for r in runs if "error" not in r["methods"][name]]
        if ok:
            rows[name] = {c: float(np.mean([r[c] for r in ok])) for c in cols}
    return ordered(pd.concat([base, pd.DataFrame(rows).T[cols]]))


def x_real_table__mutmut_25(classical_csv: Path, deep_json: Path) -> pd.DataFrame:
    cols = ["precision", "recall", "f1", "roc_auc", "pr_auc", "flagged_pct"]
    base = pd.read_csv(classical_csv, index_col=0)[[f"{c}_mean" for c in cols]]
    base.columns = cols
    runs = json.loads(deep_json.read_text())["runs"]
    rows = None
    for name in runs[0]["methods"]:
        ok = [r["methods"][name] for r in runs if "error" not in r["methods"][name]]
        if ok:
            rows[name] = {c: float(np.mean([r[c] for r in ok])) for c in cols}
    return ordered(pd.concat([base, pd.DataFrame(rows).T[cols]]))


def x_real_table__mutmut_26(classical_csv: Path, deep_json: Path) -> pd.DataFrame:
    cols = ["precision", "recall", "f1", "roc_auc", "pr_auc", "flagged_pct"]
    base = pd.read_csv(classical_csv, index_col=0)[[f"{c}_mean" for c in cols]]
    base.columns = cols
    runs = json.loads(deep_json.read_text())["runs"]
    rows = {}
    for name in runs[1]["methods"]:
        ok = [r["methods"][name] for r in runs if "error" not in r["methods"][name]]
        if ok:
            rows[name] = {c: float(np.mean([r[c] for r in ok])) for c in cols}
    return ordered(pd.concat([base, pd.DataFrame(rows).T[cols]]))


def x_real_table__mutmut_27(classical_csv: Path, deep_json: Path) -> pd.DataFrame:
    cols = ["precision", "recall", "f1", "roc_auc", "pr_auc", "flagged_pct"]
    base = pd.read_csv(classical_csv, index_col=0)[[f"{c}_mean" for c in cols]]
    base.columns = cols
    runs = json.loads(deep_json.read_text())["runs"]
    rows = {}
    for name in runs[0]["XXmethodsXX"]:
        ok = [r["methods"][name] for r in runs if "error" not in r["methods"][name]]
        if ok:
            rows[name] = {c: float(np.mean([r[c] for r in ok])) for c in cols}
    return ordered(pd.concat([base, pd.DataFrame(rows).T[cols]]))


def x_real_table__mutmut_28(classical_csv: Path, deep_json: Path) -> pd.DataFrame:
    cols = ["precision", "recall", "f1", "roc_auc", "pr_auc", "flagged_pct"]
    base = pd.read_csv(classical_csv, index_col=0)[[f"{c}_mean" for c in cols]]
    base.columns = cols
    runs = json.loads(deep_json.read_text())["runs"]
    rows = {}
    for name in runs[0]["METHODS"]:
        ok = [r["methods"][name] for r in runs if "error" not in r["methods"][name]]
        if ok:
            rows[name] = {c: float(np.mean([r[c] for r in ok])) for c in cols}
    return ordered(pd.concat([base, pd.DataFrame(rows).T[cols]]))


def x_real_table__mutmut_29(classical_csv: Path, deep_json: Path) -> pd.DataFrame:
    cols = ["precision", "recall", "f1", "roc_auc", "pr_auc", "flagged_pct"]
    base = pd.read_csv(classical_csv, index_col=0)[[f"{c}_mean" for c in cols]]
    base.columns = cols
    runs = json.loads(deep_json.read_text())["runs"]
    rows = {}
    for name in runs[0]["methods"]:
        ok = None
        if ok:
            rows[name] = {c: float(np.mean([r[c] for r in ok])) for c in cols}
    return ordered(pd.concat([base, pd.DataFrame(rows).T[cols]]))


def x_real_table__mutmut_30(classical_csv: Path, deep_json: Path) -> pd.DataFrame:
    cols = ["precision", "recall", "f1", "roc_auc", "pr_auc", "flagged_pct"]
    base = pd.read_csv(classical_csv, index_col=0)[[f"{c}_mean" for c in cols]]
    base.columns = cols
    runs = json.loads(deep_json.read_text())["runs"]
    rows = {}
    for name in runs[0]["methods"]:
        ok = [r["XXmethodsXX"][name] for r in runs if "error" not in r["methods"][name]]
        if ok:
            rows[name] = {c: float(np.mean([r[c] for r in ok])) for c in cols}
    return ordered(pd.concat([base, pd.DataFrame(rows).T[cols]]))


def x_real_table__mutmut_31(classical_csv: Path, deep_json: Path) -> pd.DataFrame:
    cols = ["precision", "recall", "f1", "roc_auc", "pr_auc", "flagged_pct"]
    base = pd.read_csv(classical_csv, index_col=0)[[f"{c}_mean" for c in cols]]
    base.columns = cols
    runs = json.loads(deep_json.read_text())["runs"]
    rows = {}
    for name in runs[0]["methods"]:
        ok = [r["METHODS"][name] for r in runs if "error" not in r["methods"][name]]
        if ok:
            rows[name] = {c: float(np.mean([r[c] for r in ok])) for c in cols}
    return ordered(pd.concat([base, pd.DataFrame(rows).T[cols]]))


def x_real_table__mutmut_32(classical_csv: Path, deep_json: Path) -> pd.DataFrame:
    cols = ["precision", "recall", "f1", "roc_auc", "pr_auc", "flagged_pct"]
    base = pd.read_csv(classical_csv, index_col=0)[[f"{c}_mean" for c in cols]]
    base.columns = cols
    runs = json.loads(deep_json.read_text())["runs"]
    rows = {}
    for name in runs[0]["methods"]:
        ok = [r["methods"][name] for r in runs if "XXerrorXX" not in r["methods"][name]]
        if ok:
            rows[name] = {c: float(np.mean([r[c] for r in ok])) for c in cols}
    return ordered(pd.concat([base, pd.DataFrame(rows).T[cols]]))


def x_real_table__mutmut_33(classical_csv: Path, deep_json: Path) -> pd.DataFrame:
    cols = ["precision", "recall", "f1", "roc_auc", "pr_auc", "flagged_pct"]
    base = pd.read_csv(classical_csv, index_col=0)[[f"{c}_mean" for c in cols]]
    base.columns = cols
    runs = json.loads(deep_json.read_text())["runs"]
    rows = {}
    for name in runs[0]["methods"]:
        ok = [r["methods"][name] for r in runs if "ERROR" not in r["methods"][name]]
        if ok:
            rows[name] = {c: float(np.mean([r[c] for r in ok])) for c in cols}
    return ordered(pd.concat([base, pd.DataFrame(rows).T[cols]]))


def x_real_table__mutmut_34(classical_csv: Path, deep_json: Path) -> pd.DataFrame:
    cols = ["precision", "recall", "f1", "roc_auc", "pr_auc", "flagged_pct"]
    base = pd.read_csv(classical_csv, index_col=0)[[f"{c}_mean" for c in cols]]
    base.columns = cols
    runs = json.loads(deep_json.read_text())["runs"]
    rows = {}
    for name in runs[0]["methods"]:
        ok = [r["methods"][name] for r in runs if "error" in r["methods"][name]]
        if ok:
            rows[name] = {c: float(np.mean([r[c] for r in ok])) for c in cols}
    return ordered(pd.concat([base, pd.DataFrame(rows).T[cols]]))


def x_real_table__mutmut_35(classical_csv: Path, deep_json: Path) -> pd.DataFrame:
    cols = ["precision", "recall", "f1", "roc_auc", "pr_auc", "flagged_pct"]
    base = pd.read_csv(classical_csv, index_col=0)[[f"{c}_mean" for c in cols]]
    base.columns = cols
    runs = json.loads(deep_json.read_text())["runs"]
    rows = {}
    for name in runs[0]["methods"]:
        ok = [r["methods"][name] for r in runs if "error" not in r["XXmethodsXX"][name]]
        if ok:
            rows[name] = {c: float(np.mean([r[c] for r in ok])) for c in cols}
    return ordered(pd.concat([base, pd.DataFrame(rows).T[cols]]))


def x_real_table__mutmut_36(classical_csv: Path, deep_json: Path) -> pd.DataFrame:
    cols = ["precision", "recall", "f1", "roc_auc", "pr_auc", "flagged_pct"]
    base = pd.read_csv(classical_csv, index_col=0)[[f"{c}_mean" for c in cols]]
    base.columns = cols
    runs = json.loads(deep_json.read_text())["runs"]
    rows = {}
    for name in runs[0]["methods"]:
        ok = [r["methods"][name] for r in runs if "error" not in r["METHODS"][name]]
        if ok:
            rows[name] = {c: float(np.mean([r[c] for r in ok])) for c in cols}
    return ordered(pd.concat([base, pd.DataFrame(rows).T[cols]]))


def x_real_table__mutmut_37(classical_csv: Path, deep_json: Path) -> pd.DataFrame:
    cols = ["precision", "recall", "f1", "roc_auc", "pr_auc", "flagged_pct"]
    base = pd.read_csv(classical_csv, index_col=0)[[f"{c}_mean" for c in cols]]
    base.columns = cols
    runs = json.loads(deep_json.read_text())["runs"]
    rows = {}
    for name in runs[0]["methods"]:
        ok = [r["methods"][name] for r in runs if "error" not in r["methods"][name]]
        if ok:
            rows[name] = None
    return ordered(pd.concat([base, pd.DataFrame(rows).T[cols]]))


def x_real_table__mutmut_38(classical_csv: Path, deep_json: Path) -> pd.DataFrame:
    cols = ["precision", "recall", "f1", "roc_auc", "pr_auc", "flagged_pct"]
    base = pd.read_csv(classical_csv, index_col=0)[[f"{c}_mean" for c in cols]]
    base.columns = cols
    runs = json.loads(deep_json.read_text())["runs"]
    rows = {}
    for name in runs[0]["methods"]:
        ok = [r["methods"][name] for r in runs if "error" not in r["methods"][name]]
        if ok:
            rows[name] = {c: float(None) for c in cols}
    return ordered(pd.concat([base, pd.DataFrame(rows).T[cols]]))


def x_real_table__mutmut_39(classical_csv: Path, deep_json: Path) -> pd.DataFrame:
    cols = ["precision", "recall", "f1", "roc_auc", "pr_auc", "flagged_pct"]
    base = pd.read_csv(classical_csv, index_col=0)[[f"{c}_mean" for c in cols]]
    base.columns = cols
    runs = json.loads(deep_json.read_text())["runs"]
    rows = {}
    for name in runs[0]["methods"]:
        ok = [r["methods"][name] for r in runs if "error" not in r["methods"][name]]
        if ok:
            rows[name] = {c: float(np.mean(None)) for c in cols}
    return ordered(pd.concat([base, pd.DataFrame(rows).T[cols]]))


def x_real_table__mutmut_40(classical_csv: Path, deep_json: Path) -> pd.DataFrame:
    cols = ["precision", "recall", "f1", "roc_auc", "pr_auc", "flagged_pct"]
    base = pd.read_csv(classical_csv, index_col=0)[[f"{c}_mean" for c in cols]]
    base.columns = cols
    runs = json.loads(deep_json.read_text())["runs"]
    rows = {}
    for name in runs[0]["methods"]:
        ok = [r["methods"][name] for r in runs if "error" not in r["methods"][name]]
        if ok:
            rows[name] = {c: float(np.mean([r[c] for r in ok])) for c in cols}
    return ordered(None)


def x_real_table__mutmut_41(classical_csv: Path, deep_json: Path) -> pd.DataFrame:
    cols = ["precision", "recall", "f1", "roc_auc", "pr_auc", "flagged_pct"]
    base = pd.read_csv(classical_csv, index_col=0)[[f"{c}_mean" for c in cols]]
    base.columns = cols
    runs = json.loads(deep_json.read_text())["runs"]
    rows = {}
    for name in runs[0]["methods"]:
        ok = [r["methods"][name] for r in runs if "error" not in r["methods"][name]]
        if ok:
            rows[name] = {c: float(np.mean([r[c] for r in ok])) for c in cols}
    return ordered(pd.concat(None))


def x_real_table__mutmut_42(classical_csv: Path, deep_json: Path) -> pd.DataFrame:
    cols = ["precision", "recall", "f1", "roc_auc", "pr_auc", "flagged_pct"]
    base = pd.read_csv(classical_csv, index_col=0)[[f"{c}_mean" for c in cols]]
    base.columns = cols
    runs = json.loads(deep_json.read_text())["runs"]
    rows = {}
    for name in runs[0]["methods"]:
        ok = [r["methods"][name] for r in runs if "error" not in r["methods"][name]]
        if ok:
            rows[name] = {c: float(np.mean([r[c] for r in ok])) for c in cols}
    return ordered(pd.concat([base, pd.DataFrame(None).T[cols]]))

mutants_x_real_table__mutmut['_mutmut_orig'] = x_real_table__mutmut_orig # type: ignore # mutmut generated
mutants_x_real_table__mutmut['x_real_table__mutmut_1'] = x_real_table__mutmut_1 # type: ignore # mutmut generated
mutants_x_real_table__mutmut['x_real_table__mutmut_2'] = x_real_table__mutmut_2 # type: ignore # mutmut generated
mutants_x_real_table__mutmut['x_real_table__mutmut_3'] = x_real_table__mutmut_3 # type: ignore # mutmut generated
mutants_x_real_table__mutmut['x_real_table__mutmut_4'] = x_real_table__mutmut_4 # type: ignore # mutmut generated
mutants_x_real_table__mutmut['x_real_table__mutmut_5'] = x_real_table__mutmut_5 # type: ignore # mutmut generated
mutants_x_real_table__mutmut['x_real_table__mutmut_6'] = x_real_table__mutmut_6 # type: ignore # mutmut generated
mutants_x_real_table__mutmut['x_real_table__mutmut_7'] = x_real_table__mutmut_7 # type: ignore # mutmut generated
mutants_x_real_table__mutmut['x_real_table__mutmut_8'] = x_real_table__mutmut_8 # type: ignore # mutmut generated
mutants_x_real_table__mutmut['x_real_table__mutmut_9'] = x_real_table__mutmut_9 # type: ignore # mutmut generated
mutants_x_real_table__mutmut['x_real_table__mutmut_10'] = x_real_table__mutmut_10 # type: ignore # mutmut generated
mutants_x_real_table__mutmut['x_real_table__mutmut_11'] = x_real_table__mutmut_11 # type: ignore # mutmut generated
mutants_x_real_table__mutmut['x_real_table__mutmut_12'] = x_real_table__mutmut_12 # type: ignore # mutmut generated
mutants_x_real_table__mutmut['x_real_table__mutmut_13'] = x_real_table__mutmut_13 # type: ignore # mutmut generated
mutants_x_real_table__mutmut['x_real_table__mutmut_14'] = x_real_table__mutmut_14 # type: ignore # mutmut generated
mutants_x_real_table__mutmut['x_real_table__mutmut_15'] = x_real_table__mutmut_15 # type: ignore # mutmut generated
mutants_x_real_table__mutmut['x_real_table__mutmut_16'] = x_real_table__mutmut_16 # type: ignore # mutmut generated
mutants_x_real_table__mutmut['x_real_table__mutmut_17'] = x_real_table__mutmut_17 # type: ignore # mutmut generated
mutants_x_real_table__mutmut['x_real_table__mutmut_18'] = x_real_table__mutmut_18 # type: ignore # mutmut generated
mutants_x_real_table__mutmut['x_real_table__mutmut_19'] = x_real_table__mutmut_19 # type: ignore # mutmut generated
mutants_x_real_table__mutmut['x_real_table__mutmut_20'] = x_real_table__mutmut_20 # type: ignore # mutmut generated
mutants_x_real_table__mutmut['x_real_table__mutmut_21'] = x_real_table__mutmut_21 # type: ignore # mutmut generated
mutants_x_real_table__mutmut['x_real_table__mutmut_22'] = x_real_table__mutmut_22 # type: ignore # mutmut generated
mutants_x_real_table__mutmut['x_real_table__mutmut_23'] = x_real_table__mutmut_23 # type: ignore # mutmut generated
mutants_x_real_table__mutmut['x_real_table__mutmut_24'] = x_real_table__mutmut_24 # type: ignore # mutmut generated
mutants_x_real_table__mutmut['x_real_table__mutmut_25'] = x_real_table__mutmut_25 # type: ignore # mutmut generated
mutants_x_real_table__mutmut['x_real_table__mutmut_26'] = x_real_table__mutmut_26 # type: ignore # mutmut generated
mutants_x_real_table__mutmut['x_real_table__mutmut_27'] = x_real_table__mutmut_27 # type: ignore # mutmut generated
mutants_x_real_table__mutmut['x_real_table__mutmut_28'] = x_real_table__mutmut_28 # type: ignore # mutmut generated
mutants_x_real_table__mutmut['x_real_table__mutmut_29'] = x_real_table__mutmut_29 # type: ignore # mutmut generated
mutants_x_real_table__mutmut['x_real_table__mutmut_30'] = x_real_table__mutmut_30 # type: ignore # mutmut generated
mutants_x_real_table__mutmut['x_real_table__mutmut_31'] = x_real_table__mutmut_31 # type: ignore # mutmut generated
mutants_x_real_table__mutmut['x_real_table__mutmut_32'] = x_real_table__mutmut_32 # type: ignore # mutmut generated
mutants_x_real_table__mutmut['x_real_table__mutmut_33'] = x_real_table__mutmut_33 # type: ignore # mutmut generated
mutants_x_real_table__mutmut['x_real_table__mutmut_34'] = x_real_table__mutmut_34 # type: ignore # mutmut generated
mutants_x_real_table__mutmut['x_real_table__mutmut_35'] = x_real_table__mutmut_35 # type: ignore # mutmut generated
mutants_x_real_table__mutmut['x_real_table__mutmut_36'] = x_real_table__mutmut_36 # type: ignore # mutmut generated
mutants_x_real_table__mutmut['x_real_table__mutmut_37'] = x_real_table__mutmut_37 # type: ignore # mutmut generated
mutants_x_real_table__mutmut['x_real_table__mutmut_38'] = x_real_table__mutmut_38 # type: ignore # mutmut generated
mutants_x_real_table__mutmut['x_real_table__mutmut_39'] = x_real_table__mutmut_39 # type: ignore # mutmut generated
mutants_x_real_table__mutmut['x_real_table__mutmut_40'] = x_real_table__mutmut_40 # type: ignore # mutmut generated
mutants_x_real_table__mutmut['x_real_table__mutmut_41'] = x_real_table__mutmut_41 # type: ignore # mutmut generated
mutants_x_real_table__mutmut['x_real_table__mutmut_42'] = x_real_table__mutmut_42 # type: ignore # mutmut generated
mutants_x_build__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_build__mutmut)
def build(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_orig(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_1(evidence: Path, figures: Path) -> dict[str, object]:
    out = None
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_2(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence * "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_3(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "XXfull_registryXX"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_4(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "FULL_REGISTRY"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_5(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = None
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_6(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = None
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_7(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" * "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_8(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence * "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_9(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "XXpool_extensionXX" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_10(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "POOL_EXTENSION" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_11(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "XXtypedXX"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_12(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "TYPED"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_13(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = None
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_14(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(None, out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_15(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", None)
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_16(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_17(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", )
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_18(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" * "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_19(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence * "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_20(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "XXtyped_injectionXX" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_21(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "TYPED_INJECTION" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_22(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "XXrunsXX", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_23(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "RUNS", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_24(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" * "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_25(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", out * "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_26(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "XXtyped_deepXX" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_27(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "TYPED_DEEP" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_28(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "XXrunsXX")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_29(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "RUNS")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_30(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra * "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_31(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "XXreference_classicalXX").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_32(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "REFERENCE_CLASSICAL").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_33(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed = merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_34(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed &= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_35(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(None, extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_36(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", None)
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_37(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_38(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", )
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_39(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra * "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_40(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "XXreference_classicalXX", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_41(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "REFERENCE_CLASSICAL", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_42(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra * "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_43(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "XXreference_deepXX")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_44(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "REFERENCE_DEEP")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_45(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = None
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_46(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(None)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_47(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections = [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_48(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections -= [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_49(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "XXXX",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_50(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(None, ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_51(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), None, ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_52(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), None),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_53(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_54(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_55(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_56(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(None), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_57(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["XXmedianXX"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_58(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["MEDIAN"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_59(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(None), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_60(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["XXlowXX"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_61(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["LOW"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_62(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(None)),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_63(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["XXhighXX"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_64(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["HIGH"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_65(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        None,
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_66(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        None,
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_67(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        None,
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_68(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_69(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_70(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_71(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(None),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_72(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["XXmedianXX"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_73(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["MEDIAN"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_74(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures * "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_75(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "XXtyped_pooled.pngXX",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_76(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "TYPED_POOLED.PNG",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_77(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = None
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_78(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(None, out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_79(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", None)
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_80(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_81(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", )
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_82(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" * "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_83(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence * "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_84(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "XXtyped_injectionXX" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_85(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "TYPED_INJECTION" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_86(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "XXrunsXX", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_87(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "RUNS", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_88(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "typed_deep" * "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_89(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out * "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_90(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "XXtyped_deepXX" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_91(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "TYPED_DEEP" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_92(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "typed_deep" / "XXrunsXX")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_93(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "typed_deep" / "RUNS")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_94(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra * "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_95(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "XXreference_classicalXX").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_96(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "REFERENCE_CLASSICAL").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_97(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = None
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_98(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(None, extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_99(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", None)
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_100(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_101(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", )
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_102(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra * "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_103(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "XXreference_classicalXX", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_104(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "REFERENCE_CLASSICAL", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_105(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra * "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_106(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "XXreference_deepXX")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_107(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "REFERENCE_DEEP")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_108(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = None
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_109(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if (len(fpr) == 0) and False else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_110(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if (len(fpr) == 0) or True else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_111(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) != 0 else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_112(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) == 1 else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_113(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(None, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_114(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, None, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_115(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, None)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_116(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_117(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_118(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, )
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_119(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections = ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_120(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections -= ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_121(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["XX### Typed injection, clean rows flaggedXX", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_122(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["### typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_123(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["### TYPED INJECTION, CLEAN ROWS FLAGGED", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_124(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "XXXX", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_125(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(None, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_126(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=None)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_127(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_128(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, )]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_129(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=4)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_130(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = None
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_131(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(None, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_132(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, None)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_133(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_134(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, )
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_135(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections = ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_136(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections -= ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_137(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["XX### Synthetic customer table, mean recallXX", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_138(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_139(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### SYNTHETIC CUSTOMER TABLE, MEAN RECALL", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_140(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "XXXX", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_141(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(None)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_142(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        None,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_143(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        None,
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_144(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        None,
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_145(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_146(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_147(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_148(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "XXMean detection rate by anomaly type (synthetic, 5 seeds)XX",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_149(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_150(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "MEAN DETECTION RATE BY ANOMALY TYPE (SYNTHETIC, 5 SEEDS)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_151(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures * "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_152(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "XXheatmap_full.pngXX",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_153(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "HEATMAP_FULL.PNG",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_154(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(None, out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_155(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", None).items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_156(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_157(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", ).items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_158(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence * "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_159(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "XXmulti_schemaXX", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_160(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "MULTI_SCHEMA", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_161(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out * "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_162(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "XXschemas_deepXX").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_163(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "SCHEMAS_DEEP").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_164(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections = [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_165(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections -= [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_166(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "XXXX", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_167(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(None)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_168(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("XXcredit_cardXX", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_169(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("CREDIT_CARD", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_170(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "XXcardioXX", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_171(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "CARDIO", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_172(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "XXwater_qualityXX"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_173(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "WATER_QUALITY"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_174(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = None
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_175(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(None, out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_176(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", None)
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_177(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_178(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", )
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_179(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence * f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_180(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out * f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_181(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections = [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_182(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections -= [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_183(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "XXXX", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_184(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(None, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_185(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=None)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_186(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_187(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, )]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_188(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=4)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_189(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text(None)
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_190(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out * "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_191(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "XXsummary.mdXX").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_192(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "SUMMARY.MD").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_193(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) - "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_194(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(None) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_195(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("XX\nXX".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_196(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "XX\nXX")
    return {"typed_datasets": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_197(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"XXtyped_datasetsXX": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_198(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"TYPED_DATASETS": len(typed), "synthetic_rows": list(synthetic.index)}


def x_build__mutmut_199(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "XXsynthetic_rowsXX": list(synthetic.index)}


def x_build__mutmut_200(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "SYNTHETIC_ROWS": list(synthetic.index)}


def x_build__mutmut_201(evidence: Path, figures: Path) -> dict[str, object]:
    out = evidence / "full_registry"
    sections = []
    extra = evidence / "pool_extension" / "typed"
    typed = merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():  # the ADBench carriers of the pool extension
        typed |= merged_typed(extra / "reference_classical", extra / "reference_deep")
    pooled = ts.pooled(typed)
    sections += [
        f"### Typed injection, median recall over {len(typed)} real datasets",
        "",
        table_md(ordered(pooled["median"]), ordered(pooled["low"]), ordered(pooled["high"])),
    ]
    figure(
        ordered(pooled["median"]),
        f"Median detection rate over {len(typed)} real datasets (typed injection)",
        figures / "typed_pooled.png",
    )
    fpr = typed_fpr(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    if (extra / "reference_classical").is_dir():
        both = typed_fpr(extra / "reference_classical", extra / "reference_deep")
        fpr = both if len(fpr) == 0 else _merge_fpr(evidence, out, extra)
    sections += ["### Typed injection, clean rows flagged", "", table_md(fpr, digits=3)]
    synthetic = synthetic_matrix(evidence, out)
    sections += ["### Synthetic customer table, mean recall", "", table_md(synthetic)]
    figure(
        synthetic,
        "Mean detection rate by anomaly type (synthetic, 5 seeds)",
        figures / "heatmap_full.png",
    )
    for name, matrix in schema_matrices(evidence / "multi_schema", out / "schemas_deep").items():
        sections += [f"### Schema {name}, mean recall", "", table_md(matrix)]
    for dataset in ("credit_card", "cardio", "water_quality"):
        table = real_table(evidence / f"benchmark_{dataset}.csv", out / f"real_{dataset}.json")
        sections += [f"### {dataset}", "", table_md(table, digits=3)]
    (out / "summary.md").write_text("\n".join(sections) + "\n")
    return {"typed_datasets": len(typed), "synthetic_rows": list(None)}

mutants_x_build__mutmut['_mutmut_orig'] = x_build__mutmut_orig # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_1'] = x_build__mutmut_1 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_2'] = x_build__mutmut_2 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_3'] = x_build__mutmut_3 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_4'] = x_build__mutmut_4 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_5'] = x_build__mutmut_5 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_6'] = x_build__mutmut_6 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_7'] = x_build__mutmut_7 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_8'] = x_build__mutmut_8 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_9'] = x_build__mutmut_9 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_10'] = x_build__mutmut_10 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_11'] = x_build__mutmut_11 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_12'] = x_build__mutmut_12 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_13'] = x_build__mutmut_13 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_14'] = x_build__mutmut_14 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_15'] = x_build__mutmut_15 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_16'] = x_build__mutmut_16 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_17'] = x_build__mutmut_17 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_18'] = x_build__mutmut_18 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_19'] = x_build__mutmut_19 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_20'] = x_build__mutmut_20 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_21'] = x_build__mutmut_21 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_22'] = x_build__mutmut_22 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_23'] = x_build__mutmut_23 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_24'] = x_build__mutmut_24 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_25'] = x_build__mutmut_25 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_26'] = x_build__mutmut_26 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_27'] = x_build__mutmut_27 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_28'] = x_build__mutmut_28 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_29'] = x_build__mutmut_29 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_30'] = x_build__mutmut_30 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_31'] = x_build__mutmut_31 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_32'] = x_build__mutmut_32 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_33'] = x_build__mutmut_33 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_34'] = x_build__mutmut_34 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_35'] = x_build__mutmut_35 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_36'] = x_build__mutmut_36 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_37'] = x_build__mutmut_37 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_38'] = x_build__mutmut_38 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_39'] = x_build__mutmut_39 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_40'] = x_build__mutmut_40 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_41'] = x_build__mutmut_41 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_42'] = x_build__mutmut_42 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_43'] = x_build__mutmut_43 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_44'] = x_build__mutmut_44 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_45'] = x_build__mutmut_45 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_46'] = x_build__mutmut_46 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_47'] = x_build__mutmut_47 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_48'] = x_build__mutmut_48 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_49'] = x_build__mutmut_49 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_50'] = x_build__mutmut_50 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_51'] = x_build__mutmut_51 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_52'] = x_build__mutmut_52 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_53'] = x_build__mutmut_53 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_54'] = x_build__mutmut_54 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_55'] = x_build__mutmut_55 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_56'] = x_build__mutmut_56 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_57'] = x_build__mutmut_57 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_58'] = x_build__mutmut_58 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_59'] = x_build__mutmut_59 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_60'] = x_build__mutmut_60 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_61'] = x_build__mutmut_61 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_62'] = x_build__mutmut_62 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_63'] = x_build__mutmut_63 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_64'] = x_build__mutmut_64 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_65'] = x_build__mutmut_65 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_66'] = x_build__mutmut_66 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_67'] = x_build__mutmut_67 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_68'] = x_build__mutmut_68 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_69'] = x_build__mutmut_69 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_70'] = x_build__mutmut_70 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_71'] = x_build__mutmut_71 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_72'] = x_build__mutmut_72 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_73'] = x_build__mutmut_73 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_74'] = x_build__mutmut_74 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_75'] = x_build__mutmut_75 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_76'] = x_build__mutmut_76 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_77'] = x_build__mutmut_77 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_78'] = x_build__mutmut_78 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_79'] = x_build__mutmut_79 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_80'] = x_build__mutmut_80 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_81'] = x_build__mutmut_81 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_82'] = x_build__mutmut_82 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_83'] = x_build__mutmut_83 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_84'] = x_build__mutmut_84 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_85'] = x_build__mutmut_85 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_86'] = x_build__mutmut_86 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_87'] = x_build__mutmut_87 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_88'] = x_build__mutmut_88 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_89'] = x_build__mutmut_89 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_90'] = x_build__mutmut_90 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_91'] = x_build__mutmut_91 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_92'] = x_build__mutmut_92 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_93'] = x_build__mutmut_93 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_94'] = x_build__mutmut_94 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_95'] = x_build__mutmut_95 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_96'] = x_build__mutmut_96 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_97'] = x_build__mutmut_97 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_98'] = x_build__mutmut_98 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_99'] = x_build__mutmut_99 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_100'] = x_build__mutmut_100 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_101'] = x_build__mutmut_101 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_102'] = x_build__mutmut_102 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_103'] = x_build__mutmut_103 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_104'] = x_build__mutmut_104 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_105'] = x_build__mutmut_105 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_106'] = x_build__mutmut_106 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_107'] = x_build__mutmut_107 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_108'] = x_build__mutmut_108 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_109'] = x_build__mutmut_109 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_110'] = x_build__mutmut_110 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_111'] = x_build__mutmut_111 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_112'] = x_build__mutmut_112 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_113'] = x_build__mutmut_113 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_114'] = x_build__mutmut_114 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_115'] = x_build__mutmut_115 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_116'] = x_build__mutmut_116 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_117'] = x_build__mutmut_117 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_118'] = x_build__mutmut_118 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_119'] = x_build__mutmut_119 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_120'] = x_build__mutmut_120 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_121'] = x_build__mutmut_121 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_122'] = x_build__mutmut_122 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_123'] = x_build__mutmut_123 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_124'] = x_build__mutmut_124 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_125'] = x_build__mutmut_125 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_126'] = x_build__mutmut_126 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_127'] = x_build__mutmut_127 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_128'] = x_build__mutmut_128 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_129'] = x_build__mutmut_129 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_130'] = x_build__mutmut_130 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_131'] = x_build__mutmut_131 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_132'] = x_build__mutmut_132 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_133'] = x_build__mutmut_133 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_134'] = x_build__mutmut_134 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_135'] = x_build__mutmut_135 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_136'] = x_build__mutmut_136 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_137'] = x_build__mutmut_137 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_138'] = x_build__mutmut_138 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_139'] = x_build__mutmut_139 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_140'] = x_build__mutmut_140 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_141'] = x_build__mutmut_141 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_142'] = x_build__mutmut_142 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_143'] = x_build__mutmut_143 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_144'] = x_build__mutmut_144 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_145'] = x_build__mutmut_145 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_146'] = x_build__mutmut_146 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_147'] = x_build__mutmut_147 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_148'] = x_build__mutmut_148 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_149'] = x_build__mutmut_149 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_150'] = x_build__mutmut_150 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_151'] = x_build__mutmut_151 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_152'] = x_build__mutmut_152 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_153'] = x_build__mutmut_153 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_154'] = x_build__mutmut_154 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_155'] = x_build__mutmut_155 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_156'] = x_build__mutmut_156 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_157'] = x_build__mutmut_157 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_158'] = x_build__mutmut_158 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_159'] = x_build__mutmut_159 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_160'] = x_build__mutmut_160 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_161'] = x_build__mutmut_161 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_162'] = x_build__mutmut_162 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_163'] = x_build__mutmut_163 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_164'] = x_build__mutmut_164 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_165'] = x_build__mutmut_165 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_166'] = x_build__mutmut_166 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_167'] = x_build__mutmut_167 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_168'] = x_build__mutmut_168 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_169'] = x_build__mutmut_169 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_170'] = x_build__mutmut_170 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_171'] = x_build__mutmut_171 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_172'] = x_build__mutmut_172 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_173'] = x_build__mutmut_173 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_174'] = x_build__mutmut_174 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_175'] = x_build__mutmut_175 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_176'] = x_build__mutmut_176 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_177'] = x_build__mutmut_177 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_178'] = x_build__mutmut_178 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_179'] = x_build__mutmut_179 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_180'] = x_build__mutmut_180 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_181'] = x_build__mutmut_181 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_182'] = x_build__mutmut_182 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_183'] = x_build__mutmut_183 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_184'] = x_build__mutmut_184 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_185'] = x_build__mutmut_185 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_186'] = x_build__mutmut_186 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_187'] = x_build__mutmut_187 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_188'] = x_build__mutmut_188 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_189'] = x_build__mutmut_189 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_190'] = x_build__mutmut_190 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_191'] = x_build__mutmut_191 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_192'] = x_build__mutmut_192 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_193'] = x_build__mutmut_193 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_194'] = x_build__mutmut_194 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_195'] = x_build__mutmut_195 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_196'] = x_build__mutmut_196 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_197'] = x_build__mutmut_197 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_198'] = x_build__mutmut_198 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_199'] = x_build__mutmut_199 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_200'] = x_build__mutmut_200 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_201'] = x_build__mutmut_201 # type: ignore # mutmut generated
mutants_x_main__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_main__mutmut)
def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--evidence", type=Path, default=EVIDENCE)
    parser.add_argument("--figures", type=Path, default=ROOT / "paper" / "figures")
    args = parser.parse_args(argv)
    print(json.dumps(build(args.evidence, args.figures)))
    return 0


def x_main__mutmut_orig(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--evidence", type=Path, default=EVIDENCE)
    parser.add_argument("--figures", type=Path, default=ROOT / "paper" / "figures")
    args = parser.parse_args(argv)
    print(json.dumps(build(args.evidence, args.figures)))
    return 0


def x_main__mutmut_1(argv: list[str] | None = None) -> int:
    parser = None
    parser.add_argument("--evidence", type=Path, default=EVIDENCE)
    parser.add_argument("--figures", type=Path, default=ROOT / "paper" / "figures")
    args = parser.parse_args(argv)
    print(json.dumps(build(args.evidence, args.figures)))
    return 0


def x_main__mutmut_2(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=None)
    parser.add_argument("--evidence", type=Path, default=EVIDENCE)
    parser.add_argument("--figures", type=Path, default=ROOT / "paper" / "figures")
    args = parser.parse_args(argv)
    print(json.dumps(build(args.evidence, args.figures)))
    return 0


def x_main__mutmut_3(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(None, type=Path, default=EVIDENCE)
    parser.add_argument("--figures", type=Path, default=ROOT / "paper" / "figures")
    args = parser.parse_args(argv)
    print(json.dumps(build(args.evidence, args.figures)))
    return 0


def x_main__mutmut_4(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--evidence", type=None, default=EVIDENCE)
    parser.add_argument("--figures", type=Path, default=ROOT / "paper" / "figures")
    args = parser.parse_args(argv)
    print(json.dumps(build(args.evidence, args.figures)))
    return 0


def x_main__mutmut_5(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--evidence", type=Path, default=None)
    parser.add_argument("--figures", type=Path, default=ROOT / "paper" / "figures")
    args = parser.parse_args(argv)
    print(json.dumps(build(args.evidence, args.figures)))
    return 0


def x_main__mutmut_6(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(type=Path, default=EVIDENCE)
    parser.add_argument("--figures", type=Path, default=ROOT / "paper" / "figures")
    args = parser.parse_args(argv)
    print(json.dumps(build(args.evidence, args.figures)))
    return 0


def x_main__mutmut_7(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--evidence", default=EVIDENCE)
    parser.add_argument("--figures", type=Path, default=ROOT / "paper" / "figures")
    args = parser.parse_args(argv)
    print(json.dumps(build(args.evidence, args.figures)))
    return 0


def x_main__mutmut_8(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--evidence", type=Path, )
    parser.add_argument("--figures", type=Path, default=ROOT / "paper" / "figures")
    args = parser.parse_args(argv)
    print(json.dumps(build(args.evidence, args.figures)))
    return 0


def x_main__mutmut_9(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("XX--evidenceXX", type=Path, default=EVIDENCE)
    parser.add_argument("--figures", type=Path, default=ROOT / "paper" / "figures")
    args = parser.parse_args(argv)
    print(json.dumps(build(args.evidence, args.figures)))
    return 0


def x_main__mutmut_10(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--EVIDENCE", type=Path, default=EVIDENCE)
    parser.add_argument("--figures", type=Path, default=ROOT / "paper" / "figures")
    args = parser.parse_args(argv)
    print(json.dumps(build(args.evidence, args.figures)))
    return 0


def x_main__mutmut_11(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--evidence", type=Path, default=EVIDENCE)
    parser.add_argument(None, type=Path, default=ROOT / "paper" / "figures")
    args = parser.parse_args(argv)
    print(json.dumps(build(args.evidence, args.figures)))
    return 0


def x_main__mutmut_12(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--evidence", type=Path, default=EVIDENCE)
    parser.add_argument("--figures", type=None, default=ROOT / "paper" / "figures")
    args = parser.parse_args(argv)
    print(json.dumps(build(args.evidence, args.figures)))
    return 0


def x_main__mutmut_13(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--evidence", type=Path, default=EVIDENCE)
    parser.add_argument("--figures", type=Path, default=None)
    args = parser.parse_args(argv)
    print(json.dumps(build(args.evidence, args.figures)))
    return 0


def x_main__mutmut_14(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--evidence", type=Path, default=EVIDENCE)
    parser.add_argument(type=Path, default=ROOT / "paper" / "figures")
    args = parser.parse_args(argv)
    print(json.dumps(build(args.evidence, args.figures)))
    return 0


def x_main__mutmut_15(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--evidence", type=Path, default=EVIDENCE)
    parser.add_argument("--figures", default=ROOT / "paper" / "figures")
    args = parser.parse_args(argv)
    print(json.dumps(build(args.evidence, args.figures)))
    return 0


def x_main__mutmut_16(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--evidence", type=Path, default=EVIDENCE)
    parser.add_argument("--figures", type=Path, )
    args = parser.parse_args(argv)
    print(json.dumps(build(args.evidence, args.figures)))
    return 0


def x_main__mutmut_17(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--evidence", type=Path, default=EVIDENCE)
    parser.add_argument("XX--figuresXX", type=Path, default=ROOT / "paper" / "figures")
    args = parser.parse_args(argv)
    print(json.dumps(build(args.evidence, args.figures)))
    return 0


def x_main__mutmut_18(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--evidence", type=Path, default=EVIDENCE)
    parser.add_argument("--FIGURES", type=Path, default=ROOT / "paper" / "figures")
    args = parser.parse_args(argv)
    print(json.dumps(build(args.evidence, args.figures)))
    return 0


def x_main__mutmut_19(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--evidence", type=Path, default=EVIDENCE)
    parser.add_argument("--figures", type=Path, default=ROOT / "paper" * "figures")
    args = parser.parse_args(argv)
    print(json.dumps(build(args.evidence, args.figures)))
    return 0


def x_main__mutmut_20(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--evidence", type=Path, default=EVIDENCE)
    parser.add_argument("--figures", type=Path, default=ROOT * "paper" / "figures")
    args = parser.parse_args(argv)
    print(json.dumps(build(args.evidence, args.figures)))
    return 0


def x_main__mutmut_21(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--evidence", type=Path, default=EVIDENCE)
    parser.add_argument("--figures", type=Path, default=ROOT / "XXpaperXX" / "figures")
    args = parser.parse_args(argv)
    print(json.dumps(build(args.evidence, args.figures)))
    return 0


def x_main__mutmut_22(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--evidence", type=Path, default=EVIDENCE)
    parser.add_argument("--figures", type=Path, default=ROOT / "PAPER" / "figures")
    args = parser.parse_args(argv)
    print(json.dumps(build(args.evidence, args.figures)))
    return 0


def x_main__mutmut_23(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--evidence", type=Path, default=EVIDENCE)
    parser.add_argument("--figures", type=Path, default=ROOT / "paper" / "XXfiguresXX")
    args = parser.parse_args(argv)
    print(json.dumps(build(args.evidence, args.figures)))
    return 0


def x_main__mutmut_24(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--evidence", type=Path, default=EVIDENCE)
    parser.add_argument("--figures", type=Path, default=ROOT / "paper" / "FIGURES")
    args = parser.parse_args(argv)
    print(json.dumps(build(args.evidence, args.figures)))
    return 0


def x_main__mutmut_25(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--evidence", type=Path, default=EVIDENCE)
    parser.add_argument("--figures", type=Path, default=ROOT / "paper" / "figures")
    args = None
    print(json.dumps(build(args.evidence, args.figures)))
    return 0


def x_main__mutmut_26(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--evidence", type=Path, default=EVIDENCE)
    parser.add_argument("--figures", type=Path, default=ROOT / "paper" / "figures")
    args = parser.parse_args(None)
    print(json.dumps(build(args.evidence, args.figures)))
    return 0


def x_main__mutmut_27(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--evidence", type=Path, default=EVIDENCE)
    parser.add_argument("--figures", type=Path, default=ROOT / "paper" / "figures")
    args = parser.parse_args(argv)
    print(None)
    return 0


def x_main__mutmut_28(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--evidence", type=Path, default=EVIDENCE)
    parser.add_argument("--figures", type=Path, default=ROOT / "paper" / "figures")
    args = parser.parse_args(argv)
    print(json.dumps(None))
    return 0


def x_main__mutmut_29(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--evidence", type=Path, default=EVIDENCE)
    parser.add_argument("--figures", type=Path, default=ROOT / "paper" / "figures")
    args = parser.parse_args(argv)
    print(json.dumps(build(None, args.figures)))
    return 0


def x_main__mutmut_30(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--evidence", type=Path, default=EVIDENCE)
    parser.add_argument("--figures", type=Path, default=ROOT / "paper" / "figures")
    args = parser.parse_args(argv)
    print(json.dumps(build(args.evidence, None)))
    return 0


def x_main__mutmut_31(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--evidence", type=Path, default=EVIDENCE)
    parser.add_argument("--figures", type=Path, default=ROOT / "paper" / "figures")
    args = parser.parse_args(argv)
    print(json.dumps(build(args.figures)))
    return 0


def x_main__mutmut_32(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--evidence", type=Path, default=EVIDENCE)
    parser.add_argument("--figures", type=Path, default=ROOT / "paper" / "figures")
    args = parser.parse_args(argv)
    print(json.dumps(build(args.evidence, )))
    return 0


def x_main__mutmut_33(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--evidence", type=Path, default=EVIDENCE)
    parser.add_argument("--figures", type=Path, default=ROOT / "paper" / "figures")
    args = parser.parse_args(argv)
    print(json.dumps(build(args.evidence, args.figures)))
    return 1

mutants_x_main__mutmut['_mutmut_orig'] = x_main__mutmut_orig # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_1'] = x_main__mutmut_1 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_2'] = x_main__mutmut_2 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_3'] = x_main__mutmut_3 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_4'] = x_main__mutmut_4 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_5'] = x_main__mutmut_5 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_6'] = x_main__mutmut_6 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_7'] = x_main__mutmut_7 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_8'] = x_main__mutmut_8 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_9'] = x_main__mutmut_9 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_10'] = x_main__mutmut_10 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_11'] = x_main__mutmut_11 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_12'] = x_main__mutmut_12 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_13'] = x_main__mutmut_13 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_14'] = x_main__mutmut_14 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_15'] = x_main__mutmut_15 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_16'] = x_main__mutmut_16 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_17'] = x_main__mutmut_17 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_18'] = x_main__mutmut_18 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_19'] = x_main__mutmut_19 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_20'] = x_main__mutmut_20 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_21'] = x_main__mutmut_21 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_22'] = x_main__mutmut_22 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_23'] = x_main__mutmut_23 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_24'] = x_main__mutmut_24 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_25'] = x_main__mutmut_25 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_26'] = x_main__mutmut_26 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_27'] = x_main__mutmut_27 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_28'] = x_main__mutmut_28 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_29'] = x_main__mutmut_29 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_30'] = x_main__mutmut_30 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_31'] = x_main__mutmut_31 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_32'] = x_main__mutmut_32 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_33'] = x_main__mutmut_33 # type: ignore # mutmut generated


if __name__ == "__main__":
    raise SystemExit(main())
