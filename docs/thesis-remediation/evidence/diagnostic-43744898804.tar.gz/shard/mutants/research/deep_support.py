"""What the neural detectors need on top of the registry (protocol full_registry.md).

They are fitted on at most ``DEEP_FIT_CAP`` training rows, drawn at random with the seed of
the repetition, and their own seed is the seed of the repetition too. The cap is recorded in
every run that uses it.
"""

from __future__ import annotations

import pandas as pd

from etl_benchmark.registry import DEEP_NAMES, get_detector

DEEP_FIT_CAP = 20_000


from mutmut.mutation.trampoline import wrap_in_trampoline as _mutmut_mutated, MutantDict
mutants_x_capped__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_capped__mutmut)
def capped(train: pd.DataFrame, name: str, seed: int, cap: int = DEEP_FIT_CAP) -> pd.DataFrame:
    """The rows a detector is fitted on: all of them, or a seeded sample for a neural one."""
    if name in DEEP_NAMES and len(train) > cap:
        return train.sample(n=cap, random_state=seed)
    return train


def x_capped__mutmut_orig(train: pd.DataFrame, name: str, seed: int, cap: int = DEEP_FIT_CAP) -> pd.DataFrame:
    """The rows a detector is fitted on: all of them, or a seeded sample for a neural one."""
    if name in DEEP_NAMES and len(train) > cap:
        return train.sample(n=cap, random_state=seed)
    return train


def x_capped__mutmut_1(train: pd.DataFrame, name: str, seed: int, cap: int = DEEP_FIT_CAP) -> pd.DataFrame:
    """The rows a detector is fitted on: all of them, or a seeded sample for a neural one."""
    if name in DEEP_NAMES or len(train) > cap:
        return train.sample(n=cap, random_state=seed)
    return train


def x_capped__mutmut_2(train: pd.DataFrame, name: str, seed: int, cap: int = DEEP_FIT_CAP) -> pd.DataFrame:
    """The rows a detector is fitted on: all of them, or a seeded sample for a neural one."""
    if name not in DEEP_NAMES and len(train) > cap:
        return train.sample(n=cap, random_state=seed)
    return train


def x_capped__mutmut_3(train: pd.DataFrame, name: str, seed: int, cap: int = DEEP_FIT_CAP) -> pd.DataFrame:
    """The rows a detector is fitted on: all of them, or a seeded sample for a neural one."""
    if name in DEEP_NAMES and len(train) >= cap:
        return train.sample(n=cap, random_state=seed)
    return train


def x_capped__mutmut_4(train: pd.DataFrame, name: str, seed: int, cap: int = DEEP_FIT_CAP) -> pd.DataFrame:
    """The rows a detector is fitted on: all of them, or a seeded sample for a neural one."""
    if name in DEEP_NAMES and len(train) > cap:
        return train.sample(n=None, random_state=seed)
    return train


def x_capped__mutmut_5(train: pd.DataFrame, name: str, seed: int, cap: int = DEEP_FIT_CAP) -> pd.DataFrame:
    """The rows a detector is fitted on: all of them, or a seeded sample for a neural one."""
    if name in DEEP_NAMES and len(train) > cap:
        return train.sample(n=cap, random_state=None)
    return train


def x_capped__mutmut_6(train: pd.DataFrame, name: str, seed: int, cap: int = DEEP_FIT_CAP) -> pd.DataFrame:
    """The rows a detector is fitted on: all of them, or a seeded sample for a neural one."""
    if name in DEEP_NAMES and len(train) > cap:
        return train.sample(random_state=seed)
    return train


def x_capped__mutmut_7(train: pd.DataFrame, name: str, seed: int, cap: int = DEEP_FIT_CAP) -> pd.DataFrame:
    """The rows a detector is fitted on: all of them, or a seeded sample for a neural one."""
    if name in DEEP_NAMES and len(train) > cap:
        return train.sample(n=cap, )
    return train

mutants_x_capped__mutmut['_mutmut_orig'] = x_capped__mutmut_orig # type: ignore # mutmut generated
mutants_x_capped__mutmut['x_capped__mutmut_1'] = x_capped__mutmut_1 # type: ignore # mutmut generated
mutants_x_capped__mutmut['x_capped__mutmut_2'] = x_capped__mutmut_2 # type: ignore # mutmut generated
mutants_x_capped__mutmut['x_capped__mutmut_3'] = x_capped__mutmut_3 # type: ignore # mutmut generated
mutants_x_capped__mutmut['x_capped__mutmut_4'] = x_capped__mutmut_4 # type: ignore # mutmut generated
mutants_x_capped__mutmut['x_capped__mutmut_5'] = x_capped__mutmut_5 # type: ignore # mutmut generated
mutants_x_capped__mutmut['x_capped__mutmut_6'] = x_capped__mutmut_6 # type: ignore # mutmut generated
mutants_x_capped__mutmut['x_capped__mutmut_7'] = x_capped__mutmut_7 # type: ignore # mutmut generated
mutants_x_build__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_build__mutmut)
def build(name: str, contamination: float, seed: int):
    """A registry detector; a neural one gets the seed of the repetition."""
    detector = get_detector(name, contamination)
    if name in DEEP_NAMES:
        detector.random_state = seed
    return detector


def x_build__mutmut_orig(name: str, contamination: float, seed: int):
    """A registry detector; a neural one gets the seed of the repetition."""
    detector = get_detector(name, contamination)
    if name in DEEP_NAMES:
        detector.random_state = seed
    return detector


def x_build__mutmut_1(name: str, contamination: float, seed: int):
    """A registry detector; a neural one gets the seed of the repetition."""
    detector = None
    if name in DEEP_NAMES:
        detector.random_state = seed
    return detector


def x_build__mutmut_2(name: str, contamination: float, seed: int):
    """A registry detector; a neural one gets the seed of the repetition."""
    detector = get_detector(None, contamination)
    if name in DEEP_NAMES:
        detector.random_state = seed
    return detector


def x_build__mutmut_3(name: str, contamination: float, seed: int):
    """A registry detector; a neural one gets the seed of the repetition."""
    detector = get_detector(name, None)
    if name in DEEP_NAMES:
        detector.random_state = seed
    return detector


def x_build__mutmut_4(name: str, contamination: float, seed: int):
    """A registry detector; a neural one gets the seed of the repetition."""
    detector = get_detector(contamination)
    if name in DEEP_NAMES:
        detector.random_state = seed
    return detector


def x_build__mutmut_5(name: str, contamination: float, seed: int):
    """A registry detector; a neural one gets the seed of the repetition."""
    detector = get_detector(name, )
    if name in DEEP_NAMES:
        detector.random_state = seed
    return detector


def x_build__mutmut_6(name: str, contamination: float, seed: int):
    """A registry detector; a neural one gets the seed of the repetition."""
    detector = get_detector(name, contamination)
    if name not in DEEP_NAMES:
        detector.random_state = seed
    return detector


def x_build__mutmut_7(name: str, contamination: float, seed: int):
    """A registry detector; a neural one gets the seed of the repetition."""
    detector = get_detector(name, contamination)
    if name in DEEP_NAMES:
        detector.random_state = None
    return detector

mutants_x_build__mutmut['_mutmut_orig'] = x_build__mutmut_orig # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_1'] = x_build__mutmut_1 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_2'] = x_build__mutmut_2 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_3'] = x_build__mutmut_3 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_4'] = x_build__mutmut_4 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_5'] = x_build__mutmut_5 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_6'] = x_build__mutmut_6 # type: ignore # mutmut generated
mutants_x_build__mutmut['x_build__mutmut_7'] = x_build__mutmut_7 # type: ignore # mutmut generated
