"""One normalisation policy for every pooled dataset.

Steps, in this order and for every set: drop constant and mostly-missing columns, encode
categorical columns (one-hot up to a cap, otherwise drop), remove duplicate rows and rows whose
duplicates disagree on the label, split 70/15/15 stratified with a seed, then impute with the
training median and standardise with the training mean and standard deviation. Every decision is
counted in a report so that no set is changed silently.
"""

from __future__ import annotations

from typing import Any

import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split

MAX_MISSING_SHARE = 0.5
CATEGORY_CAP = 20
# A 70/15/15 stratified split needs 6 of the scarcer class: train gets 4 (at most) and the rest
# holds 2, which the second split divides into one validation and one test row. With 3 to 5 the
# scikit-learn split raises a bare ValueError for some sizes (checked over n up to 200, 10 seeds).
MIN_CLASS_COUNT = 6
OCSVM_MAX_TRAIN, LOF_MAX_TRAIN = 20_000, 50_000  # from the cost study exponents, set before use
KNN_MAX_TRAIN = 50_000  # the same limit as LOF: both compare every row with the training rows


from mutmut.mutation.trampoline import wrap_in_trampoline as _mutmut_mutated, MutantDict


class NormaliseError(Exception):
    """The set cannot be split under the protocol."""
mutants_x_clean__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_clean__mutmut)
def clean(
    frame: pd.DataFrame, labels, category_cap: int = CATEGORY_CAP
) -> tuple[np.ndarray, np.ndarray, dict[str, Any]]:
    frame = frame.reset_index(drop=True)
    y = np.asarray(labels).astype(int)
    report: dict[str, Any] = {
        "rows_in": len(frame),
        "dropped_constant": [],
        "dropped_missing": [],
        "dropped_high_cardinality": [],
        "encoded": [],
    }
    pieces = []
    for name in frame.columns:
        col = frame[name]
        if col.isna().mean() > MAX_MISSING_SHARE:
            report["dropped_missing"].append(name)
        elif col.dropna().nunique() <= 1:
            report["dropped_constant"].append(name)
        elif pd.api.types.is_numeric_dtype(col) and not pd.api.types.is_bool_dtype(col):
            pieces.append(col.astype(float).rename(name))
        elif col.nunique() > category_cap:
            report["dropped_high_cardinality"].append(name)
        else:
            report["encoded"].append(name)
            pieces.append(pd.get_dummies(col.astype(str), prefix=str(name), dtype=float))
    if not pieces:
        raise NormaliseError("no usable feature left")
    table = pd.concat(pieces, axis=1)
    keys = pd.util.hash_pandas_object(table.fillna(np.inf), index=False)
    conflicting = pd.Series(y).groupby(keys.to_numpy()).transform("nunique").to_numpy() > 1
    report["conflicting_rows_removed"] = int(conflicting.sum())
    keep = ~conflicting
    first = ~pd.Series(keys.to_numpy()).duplicated().to_numpy()
    report["duplicates_removed"] = int((keep & ~first).sum())
    keep &= first
    report["rows_out"] = int(keep.sum())
    report["features_out"] = table.shape[1]
    return table.to_numpy()[keep], y[keep], report


def x_clean__mutmut_orig(
    frame: pd.DataFrame, labels, category_cap: int = CATEGORY_CAP
) -> tuple[np.ndarray, np.ndarray, dict[str, Any]]:
    frame = frame.reset_index(drop=True)
    y = np.asarray(labels).astype(int)
    report: dict[str, Any] = {
        "rows_in": len(frame),
        "dropped_constant": [],
        "dropped_missing": [],
        "dropped_high_cardinality": [],
        "encoded": [],
    }
    pieces = []
    for name in frame.columns:
        col = frame[name]
        if col.isna().mean() > MAX_MISSING_SHARE:
            report["dropped_missing"].append(name)
        elif col.dropna().nunique() <= 1:
            report["dropped_constant"].append(name)
        elif pd.api.types.is_numeric_dtype(col) and not pd.api.types.is_bool_dtype(col):
            pieces.append(col.astype(float).rename(name))
        elif col.nunique() > category_cap:
            report["dropped_high_cardinality"].append(name)
        else:
            report["encoded"].append(name)
            pieces.append(pd.get_dummies(col.astype(str), prefix=str(name), dtype=float))
    if not pieces:
        raise NormaliseError("no usable feature left")
    table = pd.concat(pieces, axis=1)
    keys = pd.util.hash_pandas_object(table.fillna(np.inf), index=False)
    conflicting = pd.Series(y).groupby(keys.to_numpy()).transform("nunique").to_numpy() > 1
    report["conflicting_rows_removed"] = int(conflicting.sum())
    keep = ~conflicting
    first = ~pd.Series(keys.to_numpy()).duplicated().to_numpy()
    report["duplicates_removed"] = int((keep & ~first).sum())
    keep &= first
    report["rows_out"] = int(keep.sum())
    report["features_out"] = table.shape[1]
    return table.to_numpy()[keep], y[keep], report


def x_clean__mutmut_1(
    frame: pd.DataFrame, labels, category_cap: int = CATEGORY_CAP
) -> tuple[np.ndarray, np.ndarray, dict[str, Any]]:
    frame = None
    y = np.asarray(labels).astype(int)
    report: dict[str, Any] = {
        "rows_in": len(frame),
        "dropped_constant": [],
        "dropped_missing": [],
        "dropped_high_cardinality": [],
        "encoded": [],
    }
    pieces = []
    for name in frame.columns:
        col = frame[name]
        if col.isna().mean() > MAX_MISSING_SHARE:
            report["dropped_missing"].append(name)
        elif col.dropna().nunique() <= 1:
            report["dropped_constant"].append(name)
        elif pd.api.types.is_numeric_dtype(col) and not pd.api.types.is_bool_dtype(col):
            pieces.append(col.astype(float).rename(name))
        elif col.nunique() > category_cap:
            report["dropped_high_cardinality"].append(name)
        else:
            report["encoded"].append(name)
            pieces.append(pd.get_dummies(col.astype(str), prefix=str(name), dtype=float))
    if not pieces:
        raise NormaliseError("no usable feature left")
    table = pd.concat(pieces, axis=1)
    keys = pd.util.hash_pandas_object(table.fillna(np.inf), index=False)
    conflicting = pd.Series(y).groupby(keys.to_numpy()).transform("nunique").to_numpy() > 1
    report["conflicting_rows_removed"] = int(conflicting.sum())
    keep = ~conflicting
    first = ~pd.Series(keys.to_numpy()).duplicated().to_numpy()
    report["duplicates_removed"] = int((keep & ~first).sum())
    keep &= first
    report["rows_out"] = int(keep.sum())
    report["features_out"] = table.shape[1]
    return table.to_numpy()[keep], y[keep], report


def x_clean__mutmut_2(
    frame: pd.DataFrame, labels, category_cap: int = CATEGORY_CAP
) -> tuple[np.ndarray, np.ndarray, dict[str, Any]]:
    frame = frame.reset_index(drop=None)
    y = np.asarray(labels).astype(int)
    report: dict[str, Any] = {
        "rows_in": len(frame),
        "dropped_constant": [],
        "dropped_missing": [],
        "dropped_high_cardinality": [],
        "encoded": [],
    }
    pieces = []
    for name in frame.columns:
        col = frame[name]
        if col.isna().mean() > MAX_MISSING_SHARE:
            report["dropped_missing"].append(name)
        elif col.dropna().nunique() <= 1:
            report["dropped_constant"].append(name)
        elif pd.api.types.is_numeric_dtype(col) and not pd.api.types.is_bool_dtype(col):
            pieces.append(col.astype(float).rename(name))
        elif col.nunique() > category_cap:
            report["dropped_high_cardinality"].append(name)
        else:
            report["encoded"].append(name)
            pieces.append(pd.get_dummies(col.astype(str), prefix=str(name), dtype=float))
    if not pieces:
        raise NormaliseError("no usable feature left")
    table = pd.concat(pieces, axis=1)
    keys = pd.util.hash_pandas_object(table.fillna(np.inf), index=False)
    conflicting = pd.Series(y).groupby(keys.to_numpy()).transform("nunique").to_numpy() > 1
    report["conflicting_rows_removed"] = int(conflicting.sum())
    keep = ~conflicting
    first = ~pd.Series(keys.to_numpy()).duplicated().to_numpy()
    report["duplicates_removed"] = int((keep & ~first).sum())
    keep &= first
    report["rows_out"] = int(keep.sum())
    report["features_out"] = table.shape[1]
    return table.to_numpy()[keep], y[keep], report


def x_clean__mutmut_3(
    frame: pd.DataFrame, labels, category_cap: int = CATEGORY_CAP
) -> tuple[np.ndarray, np.ndarray, dict[str, Any]]:
    frame = frame.reset_index(drop=False)
    y = np.asarray(labels).astype(int)
    report: dict[str, Any] = {
        "rows_in": len(frame),
        "dropped_constant": [],
        "dropped_missing": [],
        "dropped_high_cardinality": [],
        "encoded": [],
    }
    pieces = []
    for name in frame.columns:
        col = frame[name]
        if col.isna().mean() > MAX_MISSING_SHARE:
            report["dropped_missing"].append(name)
        elif col.dropna().nunique() <= 1:
            report["dropped_constant"].append(name)
        elif pd.api.types.is_numeric_dtype(col) and not pd.api.types.is_bool_dtype(col):
            pieces.append(col.astype(float).rename(name))
        elif col.nunique() > category_cap:
            report["dropped_high_cardinality"].append(name)
        else:
            report["encoded"].append(name)
            pieces.append(pd.get_dummies(col.astype(str), prefix=str(name), dtype=float))
    if not pieces:
        raise NormaliseError("no usable feature left")
    table = pd.concat(pieces, axis=1)
    keys = pd.util.hash_pandas_object(table.fillna(np.inf), index=False)
    conflicting = pd.Series(y).groupby(keys.to_numpy()).transform("nunique").to_numpy() > 1
    report["conflicting_rows_removed"] = int(conflicting.sum())
    keep = ~conflicting
    first = ~pd.Series(keys.to_numpy()).duplicated().to_numpy()
    report["duplicates_removed"] = int((keep & ~first).sum())
    keep &= first
    report["rows_out"] = int(keep.sum())
    report["features_out"] = table.shape[1]
    return table.to_numpy()[keep], y[keep], report


def x_clean__mutmut_4(
    frame: pd.DataFrame, labels, category_cap: int = CATEGORY_CAP
) -> tuple[np.ndarray, np.ndarray, dict[str, Any]]:
    frame = frame.reset_index(drop=True)
    y = None
    report: dict[str, Any] = {
        "rows_in": len(frame),
        "dropped_constant": [],
        "dropped_missing": [],
        "dropped_high_cardinality": [],
        "encoded": [],
    }
    pieces = []
    for name in frame.columns:
        col = frame[name]
        if col.isna().mean() > MAX_MISSING_SHARE:
            report["dropped_missing"].append(name)
        elif col.dropna().nunique() <= 1:
            report["dropped_constant"].append(name)
        elif pd.api.types.is_numeric_dtype(col) and not pd.api.types.is_bool_dtype(col):
            pieces.append(col.astype(float).rename(name))
        elif col.nunique() > category_cap:
            report["dropped_high_cardinality"].append(name)
        else:
            report["encoded"].append(name)
            pieces.append(pd.get_dummies(col.astype(str), prefix=str(name), dtype=float))
    if not pieces:
        raise NormaliseError("no usable feature left")
    table = pd.concat(pieces, axis=1)
    keys = pd.util.hash_pandas_object(table.fillna(np.inf), index=False)
    conflicting = pd.Series(y).groupby(keys.to_numpy()).transform("nunique").to_numpy() > 1
    report["conflicting_rows_removed"] = int(conflicting.sum())
    keep = ~conflicting
    first = ~pd.Series(keys.to_numpy()).duplicated().to_numpy()
    report["duplicates_removed"] = int((keep & ~first).sum())
    keep &= first
    report["rows_out"] = int(keep.sum())
    report["features_out"] = table.shape[1]
    return table.to_numpy()[keep], y[keep], report


def x_clean__mutmut_5(
    frame: pd.DataFrame, labels, category_cap: int = CATEGORY_CAP
) -> tuple[np.ndarray, np.ndarray, dict[str, Any]]:
    frame = frame.reset_index(drop=True)
    y = np.asarray(labels).astype(None)
    report: dict[str, Any] = {
        "rows_in": len(frame),
        "dropped_constant": [],
        "dropped_missing": [],
        "dropped_high_cardinality": [],
        "encoded": [],
    }
    pieces = []
    for name in frame.columns:
        col = frame[name]
        if col.isna().mean() > MAX_MISSING_SHARE:
            report["dropped_missing"].append(name)
        elif col.dropna().nunique() <= 1:
            report["dropped_constant"].append(name)
        elif pd.api.types.is_numeric_dtype(col) and not pd.api.types.is_bool_dtype(col):
            pieces.append(col.astype(float).rename(name))
        elif col.nunique() > category_cap:
            report["dropped_high_cardinality"].append(name)
        else:
            report["encoded"].append(name)
            pieces.append(pd.get_dummies(col.astype(str), prefix=str(name), dtype=float))
    if not pieces:
        raise NormaliseError("no usable feature left")
    table = pd.concat(pieces, axis=1)
    keys = pd.util.hash_pandas_object(table.fillna(np.inf), index=False)
    conflicting = pd.Series(y).groupby(keys.to_numpy()).transform("nunique").to_numpy() > 1
    report["conflicting_rows_removed"] = int(conflicting.sum())
    keep = ~conflicting
    first = ~pd.Series(keys.to_numpy()).duplicated().to_numpy()
    report["duplicates_removed"] = int((keep & ~first).sum())
    keep &= first
    report["rows_out"] = int(keep.sum())
    report["features_out"] = table.shape[1]
    return table.to_numpy()[keep], y[keep], report


def x_clean__mutmut_6(
    frame: pd.DataFrame, labels, category_cap: int = CATEGORY_CAP
) -> tuple[np.ndarray, np.ndarray, dict[str, Any]]:
    frame = frame.reset_index(drop=True)
    y = np.asarray(None).astype(int)
    report: dict[str, Any] = {
        "rows_in": len(frame),
        "dropped_constant": [],
        "dropped_missing": [],
        "dropped_high_cardinality": [],
        "encoded": [],
    }
    pieces = []
    for name in frame.columns:
        col = frame[name]
        if col.isna().mean() > MAX_MISSING_SHARE:
            report["dropped_missing"].append(name)
        elif col.dropna().nunique() <= 1:
            report["dropped_constant"].append(name)
        elif pd.api.types.is_numeric_dtype(col) and not pd.api.types.is_bool_dtype(col):
            pieces.append(col.astype(float).rename(name))
        elif col.nunique() > category_cap:
            report["dropped_high_cardinality"].append(name)
        else:
            report["encoded"].append(name)
            pieces.append(pd.get_dummies(col.astype(str), prefix=str(name), dtype=float))
    if not pieces:
        raise NormaliseError("no usable feature left")
    table = pd.concat(pieces, axis=1)
    keys = pd.util.hash_pandas_object(table.fillna(np.inf), index=False)
    conflicting = pd.Series(y).groupby(keys.to_numpy()).transform("nunique").to_numpy() > 1
    report["conflicting_rows_removed"] = int(conflicting.sum())
    keep = ~conflicting
    first = ~pd.Series(keys.to_numpy()).duplicated().to_numpy()
    report["duplicates_removed"] = int((keep & ~first).sum())
    keep &= first
    report["rows_out"] = int(keep.sum())
    report["features_out"] = table.shape[1]
    return table.to_numpy()[keep], y[keep], report


def x_clean__mutmut_7(
    frame: pd.DataFrame, labels, category_cap: int = CATEGORY_CAP
) -> tuple[np.ndarray, np.ndarray, dict[str, Any]]:
    frame = frame.reset_index(drop=True)
    y = np.asarray(labels).astype(int)
    report: dict[str, Any] = None
    pieces = []
    for name in frame.columns:
        col = frame[name]
        if col.isna().mean() > MAX_MISSING_SHARE:
            report["dropped_missing"].append(name)
        elif col.dropna().nunique() <= 1:
            report["dropped_constant"].append(name)
        elif pd.api.types.is_numeric_dtype(col) and not pd.api.types.is_bool_dtype(col):
            pieces.append(col.astype(float).rename(name))
        elif col.nunique() > category_cap:
            report["dropped_high_cardinality"].append(name)
        else:
            report["encoded"].append(name)
            pieces.append(pd.get_dummies(col.astype(str), prefix=str(name), dtype=float))
    if not pieces:
        raise NormaliseError("no usable feature left")
    table = pd.concat(pieces, axis=1)
    keys = pd.util.hash_pandas_object(table.fillna(np.inf), index=False)
    conflicting = pd.Series(y).groupby(keys.to_numpy()).transform("nunique").to_numpy() > 1
    report["conflicting_rows_removed"] = int(conflicting.sum())
    keep = ~conflicting
    first = ~pd.Series(keys.to_numpy()).duplicated().to_numpy()
    report["duplicates_removed"] = int((keep & ~first).sum())
    keep &= first
    report["rows_out"] = int(keep.sum())
    report["features_out"] = table.shape[1]
    return table.to_numpy()[keep], y[keep], report


def x_clean__mutmut_8(
    frame: pd.DataFrame, labels, category_cap: int = CATEGORY_CAP
) -> tuple[np.ndarray, np.ndarray, dict[str, Any]]:
    frame = frame.reset_index(drop=True)
    y = np.asarray(labels).astype(int)
    report: dict[str, Any] = {
        "XXrows_inXX": len(frame),
        "dropped_constant": [],
        "dropped_missing": [],
        "dropped_high_cardinality": [],
        "encoded": [],
    }
    pieces = []
    for name in frame.columns:
        col = frame[name]
        if col.isna().mean() > MAX_MISSING_SHARE:
            report["dropped_missing"].append(name)
        elif col.dropna().nunique() <= 1:
            report["dropped_constant"].append(name)
        elif pd.api.types.is_numeric_dtype(col) and not pd.api.types.is_bool_dtype(col):
            pieces.append(col.astype(float).rename(name))
        elif col.nunique() > category_cap:
            report["dropped_high_cardinality"].append(name)
        else:
            report["encoded"].append(name)
            pieces.append(pd.get_dummies(col.astype(str), prefix=str(name), dtype=float))
    if not pieces:
        raise NormaliseError("no usable feature left")
    table = pd.concat(pieces, axis=1)
    keys = pd.util.hash_pandas_object(table.fillna(np.inf), index=False)
    conflicting = pd.Series(y).groupby(keys.to_numpy()).transform("nunique").to_numpy() > 1
    report["conflicting_rows_removed"] = int(conflicting.sum())
    keep = ~conflicting
    first = ~pd.Series(keys.to_numpy()).duplicated().to_numpy()
    report["duplicates_removed"] = int((keep & ~first).sum())
    keep &= first
    report["rows_out"] = int(keep.sum())
    report["features_out"] = table.shape[1]
    return table.to_numpy()[keep], y[keep], report


def x_clean__mutmut_9(
    frame: pd.DataFrame, labels, category_cap: int = CATEGORY_CAP
) -> tuple[np.ndarray, np.ndarray, dict[str, Any]]:
    frame = frame.reset_index(drop=True)
    y = np.asarray(labels).astype(int)
    report: dict[str, Any] = {
        "ROWS_IN": len(frame),
        "dropped_constant": [],
        "dropped_missing": [],
        "dropped_high_cardinality": [],
        "encoded": [],
    }
    pieces = []
    for name in frame.columns:
        col = frame[name]
        if col.isna().mean() > MAX_MISSING_SHARE:
            report["dropped_missing"].append(name)
        elif col.dropna().nunique() <= 1:
            report["dropped_constant"].append(name)
        elif pd.api.types.is_numeric_dtype(col) and not pd.api.types.is_bool_dtype(col):
            pieces.append(col.astype(float).rename(name))
        elif col.nunique() > category_cap:
            report["dropped_high_cardinality"].append(name)
        else:
            report["encoded"].append(name)
            pieces.append(pd.get_dummies(col.astype(str), prefix=str(name), dtype=float))
    if not pieces:
        raise NormaliseError("no usable feature left")
    table = pd.concat(pieces, axis=1)
    keys = pd.util.hash_pandas_object(table.fillna(np.inf), index=False)
    conflicting = pd.Series(y).groupby(keys.to_numpy()).transform("nunique").to_numpy() > 1
    report["conflicting_rows_removed"] = int(conflicting.sum())
    keep = ~conflicting
    first = ~pd.Series(keys.to_numpy()).duplicated().to_numpy()
    report["duplicates_removed"] = int((keep & ~first).sum())
    keep &= first
    report["rows_out"] = int(keep.sum())
    report["features_out"] = table.shape[1]
    return table.to_numpy()[keep], y[keep], report


def x_clean__mutmut_10(
    frame: pd.DataFrame, labels, category_cap: int = CATEGORY_CAP
) -> tuple[np.ndarray, np.ndarray, dict[str, Any]]:
    frame = frame.reset_index(drop=True)
    y = np.asarray(labels).astype(int)
    report: dict[str, Any] = {
        "rows_in": len(frame),
        "XXdropped_constantXX": [],
        "dropped_missing": [],
        "dropped_high_cardinality": [],
        "encoded": [],
    }
    pieces = []
    for name in frame.columns:
        col = frame[name]
        if col.isna().mean() > MAX_MISSING_SHARE:
            report["dropped_missing"].append(name)
        elif col.dropna().nunique() <= 1:
            report["dropped_constant"].append(name)
        elif pd.api.types.is_numeric_dtype(col) and not pd.api.types.is_bool_dtype(col):
            pieces.append(col.astype(float).rename(name))
        elif col.nunique() > category_cap:
            report["dropped_high_cardinality"].append(name)
        else:
            report["encoded"].append(name)
            pieces.append(pd.get_dummies(col.astype(str), prefix=str(name), dtype=float))
    if not pieces:
        raise NormaliseError("no usable feature left")
    table = pd.concat(pieces, axis=1)
    keys = pd.util.hash_pandas_object(table.fillna(np.inf), index=False)
    conflicting = pd.Series(y).groupby(keys.to_numpy()).transform("nunique").to_numpy() > 1
    report["conflicting_rows_removed"] = int(conflicting.sum())
    keep = ~conflicting
    first = ~pd.Series(keys.to_numpy()).duplicated().to_numpy()
    report["duplicates_removed"] = int((keep & ~first).sum())
    keep &= first
    report["rows_out"] = int(keep.sum())
    report["features_out"] = table.shape[1]
    return table.to_numpy()[keep], y[keep], report


def x_clean__mutmut_11(
    frame: pd.DataFrame, labels, category_cap: int = CATEGORY_CAP
) -> tuple[np.ndarray, np.ndarray, dict[str, Any]]:
    frame = frame.reset_index(drop=True)
    y = np.asarray(labels).astype(int)
    report: dict[str, Any] = {
        "rows_in": len(frame),
        "DROPPED_CONSTANT": [],
        "dropped_missing": [],
        "dropped_high_cardinality": [],
        "encoded": [],
    }
    pieces = []
    for name in frame.columns:
        col = frame[name]
        if col.isna().mean() > MAX_MISSING_SHARE:
            report["dropped_missing"].append(name)
        elif col.dropna().nunique() <= 1:
            report["dropped_constant"].append(name)
        elif pd.api.types.is_numeric_dtype(col) and not pd.api.types.is_bool_dtype(col):
            pieces.append(col.astype(float).rename(name))
        elif col.nunique() > category_cap:
            report["dropped_high_cardinality"].append(name)
        else:
            report["encoded"].append(name)
            pieces.append(pd.get_dummies(col.astype(str), prefix=str(name), dtype=float))
    if not pieces:
        raise NormaliseError("no usable feature left")
    table = pd.concat(pieces, axis=1)
    keys = pd.util.hash_pandas_object(table.fillna(np.inf), index=False)
    conflicting = pd.Series(y).groupby(keys.to_numpy()).transform("nunique").to_numpy() > 1
    report["conflicting_rows_removed"] = int(conflicting.sum())
    keep = ~conflicting
    first = ~pd.Series(keys.to_numpy()).duplicated().to_numpy()
    report["duplicates_removed"] = int((keep & ~first).sum())
    keep &= first
    report["rows_out"] = int(keep.sum())
    report["features_out"] = table.shape[1]
    return table.to_numpy()[keep], y[keep], report


def x_clean__mutmut_12(
    frame: pd.DataFrame, labels, category_cap: int = CATEGORY_CAP
) -> tuple[np.ndarray, np.ndarray, dict[str, Any]]:
    frame = frame.reset_index(drop=True)
    y = np.asarray(labels).astype(int)
    report: dict[str, Any] = {
        "rows_in": len(frame),
        "dropped_constant": [],
        "XXdropped_missingXX": [],
        "dropped_high_cardinality": [],
        "encoded": [],
    }
    pieces = []
    for name in frame.columns:
        col = frame[name]
        if col.isna().mean() > MAX_MISSING_SHARE:
            report["dropped_missing"].append(name)
        elif col.dropna().nunique() <= 1:
            report["dropped_constant"].append(name)
        elif pd.api.types.is_numeric_dtype(col) and not pd.api.types.is_bool_dtype(col):
            pieces.append(col.astype(float).rename(name))
        elif col.nunique() > category_cap:
            report["dropped_high_cardinality"].append(name)
        else:
            report["encoded"].append(name)
            pieces.append(pd.get_dummies(col.astype(str), prefix=str(name), dtype=float))
    if not pieces:
        raise NormaliseError("no usable feature left")
    table = pd.concat(pieces, axis=1)
    keys = pd.util.hash_pandas_object(table.fillna(np.inf), index=False)
    conflicting = pd.Series(y).groupby(keys.to_numpy()).transform("nunique").to_numpy() > 1
    report["conflicting_rows_removed"] = int(conflicting.sum())
    keep = ~conflicting
    first = ~pd.Series(keys.to_numpy()).duplicated().to_numpy()
    report["duplicates_removed"] = int((keep & ~first).sum())
    keep &= first
    report["rows_out"] = int(keep.sum())
    report["features_out"] = table.shape[1]
    return table.to_numpy()[keep], y[keep], report


def x_clean__mutmut_13(
    frame: pd.DataFrame, labels, category_cap: int = CATEGORY_CAP
) -> tuple[np.ndarray, np.ndarray, dict[str, Any]]:
    frame = frame.reset_index(drop=True)
    y = np.asarray(labels).astype(int)
    report: dict[str, Any] = {
        "rows_in": len(frame),
        "dropped_constant": [],
        "DROPPED_MISSING": [],
        "dropped_high_cardinality": [],
        "encoded": [],
    }
    pieces = []
    for name in frame.columns:
        col = frame[name]
        if col.isna().mean() > MAX_MISSING_SHARE:
            report["dropped_missing"].append(name)
        elif col.dropna().nunique() <= 1:
            report["dropped_constant"].append(name)
        elif pd.api.types.is_numeric_dtype(col) and not pd.api.types.is_bool_dtype(col):
            pieces.append(col.astype(float).rename(name))
        elif col.nunique() > category_cap:
            report["dropped_high_cardinality"].append(name)
        else:
            report["encoded"].append(name)
            pieces.append(pd.get_dummies(col.astype(str), prefix=str(name), dtype=float))
    if not pieces:
        raise NormaliseError("no usable feature left")
    table = pd.concat(pieces, axis=1)
    keys = pd.util.hash_pandas_object(table.fillna(np.inf), index=False)
    conflicting = pd.Series(y).groupby(keys.to_numpy()).transform("nunique").to_numpy() > 1
    report["conflicting_rows_removed"] = int(conflicting.sum())
    keep = ~conflicting
    first = ~pd.Series(keys.to_numpy()).duplicated().to_numpy()
    report["duplicates_removed"] = int((keep & ~first).sum())
    keep &= first
    report["rows_out"] = int(keep.sum())
    report["features_out"] = table.shape[1]
    return table.to_numpy()[keep], y[keep], report


def x_clean__mutmut_14(
    frame: pd.DataFrame, labels, category_cap: int = CATEGORY_CAP
) -> tuple[np.ndarray, np.ndarray, dict[str, Any]]:
    frame = frame.reset_index(drop=True)
    y = np.asarray(labels).astype(int)
    report: dict[str, Any] = {
        "rows_in": len(frame),
        "dropped_constant": [],
        "dropped_missing": [],
        "XXdropped_high_cardinalityXX": [],
        "encoded": [],
    }
    pieces = []
    for name in frame.columns:
        col = frame[name]
        if col.isna().mean() > MAX_MISSING_SHARE:
            report["dropped_missing"].append(name)
        elif col.dropna().nunique() <= 1:
            report["dropped_constant"].append(name)
        elif pd.api.types.is_numeric_dtype(col) and not pd.api.types.is_bool_dtype(col):
            pieces.append(col.astype(float).rename(name))
        elif col.nunique() > category_cap:
            report["dropped_high_cardinality"].append(name)
        else:
            report["encoded"].append(name)
            pieces.append(pd.get_dummies(col.astype(str), prefix=str(name), dtype=float))
    if not pieces:
        raise NormaliseError("no usable feature left")
    table = pd.concat(pieces, axis=1)
    keys = pd.util.hash_pandas_object(table.fillna(np.inf), index=False)
    conflicting = pd.Series(y).groupby(keys.to_numpy()).transform("nunique").to_numpy() > 1
    report["conflicting_rows_removed"] = int(conflicting.sum())
    keep = ~conflicting
    first = ~pd.Series(keys.to_numpy()).duplicated().to_numpy()
    report["duplicates_removed"] = int((keep & ~first).sum())
    keep &= first
    report["rows_out"] = int(keep.sum())
    report["features_out"] = table.shape[1]
    return table.to_numpy()[keep], y[keep], report


def x_clean__mutmut_15(
    frame: pd.DataFrame, labels, category_cap: int = CATEGORY_CAP
) -> tuple[np.ndarray, np.ndarray, dict[str, Any]]:
    frame = frame.reset_index(drop=True)
    y = np.asarray(labels).astype(int)
    report: dict[str, Any] = {
        "rows_in": len(frame),
        "dropped_constant": [],
        "dropped_missing": [],
        "DROPPED_HIGH_CARDINALITY": [],
        "encoded": [],
    }
    pieces = []
    for name in frame.columns:
        col = frame[name]
        if col.isna().mean() > MAX_MISSING_SHARE:
            report["dropped_missing"].append(name)
        elif col.dropna().nunique() <= 1:
            report["dropped_constant"].append(name)
        elif pd.api.types.is_numeric_dtype(col) and not pd.api.types.is_bool_dtype(col):
            pieces.append(col.astype(float).rename(name))
        elif col.nunique() > category_cap:
            report["dropped_high_cardinality"].append(name)
        else:
            report["encoded"].append(name)
            pieces.append(pd.get_dummies(col.astype(str), prefix=str(name), dtype=float))
    if not pieces:
        raise NormaliseError("no usable feature left")
    table = pd.concat(pieces, axis=1)
    keys = pd.util.hash_pandas_object(table.fillna(np.inf), index=False)
    conflicting = pd.Series(y).groupby(keys.to_numpy()).transform("nunique").to_numpy() > 1
    report["conflicting_rows_removed"] = int(conflicting.sum())
    keep = ~conflicting
    first = ~pd.Series(keys.to_numpy()).duplicated().to_numpy()
    report["duplicates_removed"] = int((keep & ~first).sum())
    keep &= first
    report["rows_out"] = int(keep.sum())
    report["features_out"] = table.shape[1]
    return table.to_numpy()[keep], y[keep], report


def x_clean__mutmut_16(
    frame: pd.DataFrame, labels, category_cap: int = CATEGORY_CAP
) -> tuple[np.ndarray, np.ndarray, dict[str, Any]]:
    frame = frame.reset_index(drop=True)
    y = np.asarray(labels).astype(int)
    report: dict[str, Any] = {
        "rows_in": len(frame),
        "dropped_constant": [],
        "dropped_missing": [],
        "dropped_high_cardinality": [],
        "XXencodedXX": [],
    }
    pieces = []
    for name in frame.columns:
        col = frame[name]
        if col.isna().mean() > MAX_MISSING_SHARE:
            report["dropped_missing"].append(name)
        elif col.dropna().nunique() <= 1:
            report["dropped_constant"].append(name)
        elif pd.api.types.is_numeric_dtype(col) and not pd.api.types.is_bool_dtype(col):
            pieces.append(col.astype(float).rename(name))
        elif col.nunique() > category_cap:
            report["dropped_high_cardinality"].append(name)
        else:
            report["encoded"].append(name)
            pieces.append(pd.get_dummies(col.astype(str), prefix=str(name), dtype=float))
    if not pieces:
        raise NormaliseError("no usable feature left")
    table = pd.concat(pieces, axis=1)
    keys = pd.util.hash_pandas_object(table.fillna(np.inf), index=False)
    conflicting = pd.Series(y).groupby(keys.to_numpy()).transform("nunique").to_numpy() > 1
    report["conflicting_rows_removed"] = int(conflicting.sum())
    keep = ~conflicting
    first = ~pd.Series(keys.to_numpy()).duplicated().to_numpy()
    report["duplicates_removed"] = int((keep & ~first).sum())
    keep &= first
    report["rows_out"] = int(keep.sum())
    report["features_out"] = table.shape[1]
    return table.to_numpy()[keep], y[keep], report


def x_clean__mutmut_17(
    frame: pd.DataFrame, labels, category_cap: int = CATEGORY_CAP
) -> tuple[np.ndarray, np.ndarray, dict[str, Any]]:
    frame = frame.reset_index(drop=True)
    y = np.asarray(labels).astype(int)
    report: dict[str, Any] = {
        "rows_in": len(frame),
        "dropped_constant": [],
        "dropped_missing": [],
        "dropped_high_cardinality": [],
        "ENCODED": [],
    }
    pieces = []
    for name in frame.columns:
        col = frame[name]
        if col.isna().mean() > MAX_MISSING_SHARE:
            report["dropped_missing"].append(name)
        elif col.dropna().nunique() <= 1:
            report["dropped_constant"].append(name)
        elif pd.api.types.is_numeric_dtype(col) and not pd.api.types.is_bool_dtype(col):
            pieces.append(col.astype(float).rename(name))
        elif col.nunique() > category_cap:
            report["dropped_high_cardinality"].append(name)
        else:
            report["encoded"].append(name)
            pieces.append(pd.get_dummies(col.astype(str), prefix=str(name), dtype=float))
    if not pieces:
        raise NormaliseError("no usable feature left")
    table = pd.concat(pieces, axis=1)
    keys = pd.util.hash_pandas_object(table.fillna(np.inf), index=False)
    conflicting = pd.Series(y).groupby(keys.to_numpy()).transform("nunique").to_numpy() > 1
    report["conflicting_rows_removed"] = int(conflicting.sum())
    keep = ~conflicting
    first = ~pd.Series(keys.to_numpy()).duplicated().to_numpy()
    report["duplicates_removed"] = int((keep & ~first).sum())
    keep &= first
    report["rows_out"] = int(keep.sum())
    report["features_out"] = table.shape[1]
    return table.to_numpy()[keep], y[keep], report


def x_clean__mutmut_18(
    frame: pd.DataFrame, labels, category_cap: int = CATEGORY_CAP
) -> tuple[np.ndarray, np.ndarray, dict[str, Any]]:
    frame = frame.reset_index(drop=True)
    y = np.asarray(labels).astype(int)
    report: dict[str, Any] = {
        "rows_in": len(frame),
        "dropped_constant": [],
        "dropped_missing": [],
        "dropped_high_cardinality": [],
        "encoded": [],
    }
    pieces = None
    for name in frame.columns:
        col = frame[name]
        if col.isna().mean() > MAX_MISSING_SHARE:
            report["dropped_missing"].append(name)
        elif col.dropna().nunique() <= 1:
            report["dropped_constant"].append(name)
        elif pd.api.types.is_numeric_dtype(col) and not pd.api.types.is_bool_dtype(col):
            pieces.append(col.astype(float).rename(name))
        elif col.nunique() > category_cap:
            report["dropped_high_cardinality"].append(name)
        else:
            report["encoded"].append(name)
            pieces.append(pd.get_dummies(col.astype(str), prefix=str(name), dtype=float))
    if not pieces:
        raise NormaliseError("no usable feature left")
    table = pd.concat(pieces, axis=1)
    keys = pd.util.hash_pandas_object(table.fillna(np.inf), index=False)
    conflicting = pd.Series(y).groupby(keys.to_numpy()).transform("nunique").to_numpy() > 1
    report["conflicting_rows_removed"] = int(conflicting.sum())
    keep = ~conflicting
    first = ~pd.Series(keys.to_numpy()).duplicated().to_numpy()
    report["duplicates_removed"] = int((keep & ~first).sum())
    keep &= first
    report["rows_out"] = int(keep.sum())
    report["features_out"] = table.shape[1]
    return table.to_numpy()[keep], y[keep], report


def x_clean__mutmut_19(
    frame: pd.DataFrame, labels, category_cap: int = CATEGORY_CAP
) -> tuple[np.ndarray, np.ndarray, dict[str, Any]]:
    frame = frame.reset_index(drop=True)
    y = np.asarray(labels).astype(int)
    report: dict[str, Any] = {
        "rows_in": len(frame),
        "dropped_constant": [],
        "dropped_missing": [],
        "dropped_high_cardinality": [],
        "encoded": [],
    }
    pieces = []
    for name in frame.columns:
        col = None
        if col.isna().mean() > MAX_MISSING_SHARE:
            report["dropped_missing"].append(name)
        elif col.dropna().nunique() <= 1:
            report["dropped_constant"].append(name)
        elif pd.api.types.is_numeric_dtype(col) and not pd.api.types.is_bool_dtype(col):
            pieces.append(col.astype(float).rename(name))
        elif col.nunique() > category_cap:
            report["dropped_high_cardinality"].append(name)
        else:
            report["encoded"].append(name)
            pieces.append(pd.get_dummies(col.astype(str), prefix=str(name), dtype=float))
    if not pieces:
        raise NormaliseError("no usable feature left")
    table = pd.concat(pieces, axis=1)
    keys = pd.util.hash_pandas_object(table.fillna(np.inf), index=False)
    conflicting = pd.Series(y).groupby(keys.to_numpy()).transform("nunique").to_numpy() > 1
    report["conflicting_rows_removed"] = int(conflicting.sum())
    keep = ~conflicting
    first = ~pd.Series(keys.to_numpy()).duplicated().to_numpy()
    report["duplicates_removed"] = int((keep & ~first).sum())
    keep &= first
    report["rows_out"] = int(keep.sum())
    report["features_out"] = table.shape[1]
    return table.to_numpy()[keep], y[keep], report


def x_clean__mutmut_20(
    frame: pd.DataFrame, labels, category_cap: int = CATEGORY_CAP
) -> tuple[np.ndarray, np.ndarray, dict[str, Any]]:
    frame = frame.reset_index(drop=True)
    y = np.asarray(labels).astype(int)
    report: dict[str, Any] = {
        "rows_in": len(frame),
        "dropped_constant": [],
        "dropped_missing": [],
        "dropped_high_cardinality": [],
        "encoded": [],
    }
    pieces = []
    for name in frame.columns:
        col = frame[name]
        if col.isna().mean() >= MAX_MISSING_SHARE:
            report["dropped_missing"].append(name)
        elif col.dropna().nunique() <= 1:
            report["dropped_constant"].append(name)
        elif pd.api.types.is_numeric_dtype(col) and not pd.api.types.is_bool_dtype(col):
            pieces.append(col.astype(float).rename(name))
        elif col.nunique() > category_cap:
            report["dropped_high_cardinality"].append(name)
        else:
            report["encoded"].append(name)
            pieces.append(pd.get_dummies(col.astype(str), prefix=str(name), dtype=float))
    if not pieces:
        raise NormaliseError("no usable feature left")
    table = pd.concat(pieces, axis=1)
    keys = pd.util.hash_pandas_object(table.fillna(np.inf), index=False)
    conflicting = pd.Series(y).groupby(keys.to_numpy()).transform("nunique").to_numpy() > 1
    report["conflicting_rows_removed"] = int(conflicting.sum())
    keep = ~conflicting
    first = ~pd.Series(keys.to_numpy()).duplicated().to_numpy()
    report["duplicates_removed"] = int((keep & ~first).sum())
    keep &= first
    report["rows_out"] = int(keep.sum())
    report["features_out"] = table.shape[1]
    return table.to_numpy()[keep], y[keep], report


def x_clean__mutmut_21(
    frame: pd.DataFrame, labels, category_cap: int = CATEGORY_CAP
) -> tuple[np.ndarray, np.ndarray, dict[str, Any]]:
    frame = frame.reset_index(drop=True)
    y = np.asarray(labels).astype(int)
    report: dict[str, Any] = {
        "rows_in": len(frame),
        "dropped_constant": [],
        "dropped_missing": [],
        "dropped_high_cardinality": [],
        "encoded": [],
    }
    pieces = []
    for name in frame.columns:
        col = frame[name]
        if col.isna().mean() > MAX_MISSING_SHARE:
            report["dropped_missing"].append(None)
        elif col.dropna().nunique() <= 1:
            report["dropped_constant"].append(name)
        elif pd.api.types.is_numeric_dtype(col) and not pd.api.types.is_bool_dtype(col):
            pieces.append(col.astype(float).rename(name))
        elif col.nunique() > category_cap:
            report["dropped_high_cardinality"].append(name)
        else:
            report["encoded"].append(name)
            pieces.append(pd.get_dummies(col.astype(str), prefix=str(name), dtype=float))
    if not pieces:
        raise NormaliseError("no usable feature left")
    table = pd.concat(pieces, axis=1)
    keys = pd.util.hash_pandas_object(table.fillna(np.inf), index=False)
    conflicting = pd.Series(y).groupby(keys.to_numpy()).transform("nunique").to_numpy() > 1
    report["conflicting_rows_removed"] = int(conflicting.sum())
    keep = ~conflicting
    first = ~pd.Series(keys.to_numpy()).duplicated().to_numpy()
    report["duplicates_removed"] = int((keep & ~first).sum())
    keep &= first
    report["rows_out"] = int(keep.sum())
    report["features_out"] = table.shape[1]
    return table.to_numpy()[keep], y[keep], report


def x_clean__mutmut_22(
    frame: pd.DataFrame, labels, category_cap: int = CATEGORY_CAP
) -> tuple[np.ndarray, np.ndarray, dict[str, Any]]:
    frame = frame.reset_index(drop=True)
    y = np.asarray(labels).astype(int)
    report: dict[str, Any] = {
        "rows_in": len(frame),
        "dropped_constant": [],
        "dropped_missing": [],
        "dropped_high_cardinality": [],
        "encoded": [],
    }
    pieces = []
    for name in frame.columns:
        col = frame[name]
        if col.isna().mean() > MAX_MISSING_SHARE:
            report["XXdropped_missingXX"].append(name)
        elif col.dropna().nunique() <= 1:
            report["dropped_constant"].append(name)
        elif pd.api.types.is_numeric_dtype(col) and not pd.api.types.is_bool_dtype(col):
            pieces.append(col.astype(float).rename(name))
        elif col.nunique() > category_cap:
            report["dropped_high_cardinality"].append(name)
        else:
            report["encoded"].append(name)
            pieces.append(pd.get_dummies(col.astype(str), prefix=str(name), dtype=float))
    if not pieces:
        raise NormaliseError("no usable feature left")
    table = pd.concat(pieces, axis=1)
    keys = pd.util.hash_pandas_object(table.fillna(np.inf), index=False)
    conflicting = pd.Series(y).groupby(keys.to_numpy()).transform("nunique").to_numpy() > 1
    report["conflicting_rows_removed"] = int(conflicting.sum())
    keep = ~conflicting
    first = ~pd.Series(keys.to_numpy()).duplicated().to_numpy()
    report["duplicates_removed"] = int((keep & ~first).sum())
    keep &= first
    report["rows_out"] = int(keep.sum())
    report["features_out"] = table.shape[1]
    return table.to_numpy()[keep], y[keep], report


def x_clean__mutmut_23(
    frame: pd.DataFrame, labels, category_cap: int = CATEGORY_CAP
) -> tuple[np.ndarray, np.ndarray, dict[str, Any]]:
    frame = frame.reset_index(drop=True)
    y = np.asarray(labels).astype(int)
    report: dict[str, Any] = {
        "rows_in": len(frame),
        "dropped_constant": [],
        "dropped_missing": [],
        "dropped_high_cardinality": [],
        "encoded": [],
    }
    pieces = []
    for name in frame.columns:
        col = frame[name]
        if col.isna().mean() > MAX_MISSING_SHARE:
            report["DROPPED_MISSING"].append(name)
        elif col.dropna().nunique() <= 1:
            report["dropped_constant"].append(name)
        elif pd.api.types.is_numeric_dtype(col) and not pd.api.types.is_bool_dtype(col):
            pieces.append(col.astype(float).rename(name))
        elif col.nunique() > category_cap:
            report["dropped_high_cardinality"].append(name)
        else:
            report["encoded"].append(name)
            pieces.append(pd.get_dummies(col.astype(str), prefix=str(name), dtype=float))
    if not pieces:
        raise NormaliseError("no usable feature left")
    table = pd.concat(pieces, axis=1)
    keys = pd.util.hash_pandas_object(table.fillna(np.inf), index=False)
    conflicting = pd.Series(y).groupby(keys.to_numpy()).transform("nunique").to_numpy() > 1
    report["conflicting_rows_removed"] = int(conflicting.sum())
    keep = ~conflicting
    first = ~pd.Series(keys.to_numpy()).duplicated().to_numpy()
    report["duplicates_removed"] = int((keep & ~first).sum())
    keep &= first
    report["rows_out"] = int(keep.sum())
    report["features_out"] = table.shape[1]
    return table.to_numpy()[keep], y[keep], report


def x_clean__mutmut_24(
    frame: pd.DataFrame, labels, category_cap: int = CATEGORY_CAP
) -> tuple[np.ndarray, np.ndarray, dict[str, Any]]:
    frame = frame.reset_index(drop=True)
    y = np.asarray(labels).astype(int)
    report: dict[str, Any] = {
        "rows_in": len(frame),
        "dropped_constant": [],
        "dropped_missing": [],
        "dropped_high_cardinality": [],
        "encoded": [],
    }
    pieces = []
    for name in frame.columns:
        col = frame[name]
        if col.isna().mean() > MAX_MISSING_SHARE:
            report["dropped_missing"].append(name)
        elif col.dropna().nunique() < 1:
            report["dropped_constant"].append(name)
        elif pd.api.types.is_numeric_dtype(col) and not pd.api.types.is_bool_dtype(col):
            pieces.append(col.astype(float).rename(name))
        elif col.nunique() > category_cap:
            report["dropped_high_cardinality"].append(name)
        else:
            report["encoded"].append(name)
            pieces.append(pd.get_dummies(col.astype(str), prefix=str(name), dtype=float))
    if not pieces:
        raise NormaliseError("no usable feature left")
    table = pd.concat(pieces, axis=1)
    keys = pd.util.hash_pandas_object(table.fillna(np.inf), index=False)
    conflicting = pd.Series(y).groupby(keys.to_numpy()).transform("nunique").to_numpy() > 1
    report["conflicting_rows_removed"] = int(conflicting.sum())
    keep = ~conflicting
    first = ~pd.Series(keys.to_numpy()).duplicated().to_numpy()
    report["duplicates_removed"] = int((keep & ~first).sum())
    keep &= first
    report["rows_out"] = int(keep.sum())
    report["features_out"] = table.shape[1]
    return table.to_numpy()[keep], y[keep], report


def x_clean__mutmut_25(
    frame: pd.DataFrame, labels, category_cap: int = CATEGORY_CAP
) -> tuple[np.ndarray, np.ndarray, dict[str, Any]]:
    frame = frame.reset_index(drop=True)
    y = np.asarray(labels).astype(int)
    report: dict[str, Any] = {
        "rows_in": len(frame),
        "dropped_constant": [],
        "dropped_missing": [],
        "dropped_high_cardinality": [],
        "encoded": [],
    }
    pieces = []
    for name in frame.columns:
        col = frame[name]
        if col.isna().mean() > MAX_MISSING_SHARE:
            report["dropped_missing"].append(name)
        elif col.dropna().nunique() <= 2:
            report["dropped_constant"].append(name)
        elif pd.api.types.is_numeric_dtype(col) and not pd.api.types.is_bool_dtype(col):
            pieces.append(col.astype(float).rename(name))
        elif col.nunique() > category_cap:
            report["dropped_high_cardinality"].append(name)
        else:
            report["encoded"].append(name)
            pieces.append(pd.get_dummies(col.astype(str), prefix=str(name), dtype=float))
    if not pieces:
        raise NormaliseError("no usable feature left")
    table = pd.concat(pieces, axis=1)
    keys = pd.util.hash_pandas_object(table.fillna(np.inf), index=False)
    conflicting = pd.Series(y).groupby(keys.to_numpy()).transform("nunique").to_numpy() > 1
    report["conflicting_rows_removed"] = int(conflicting.sum())
    keep = ~conflicting
    first = ~pd.Series(keys.to_numpy()).duplicated().to_numpy()
    report["duplicates_removed"] = int((keep & ~first).sum())
    keep &= first
    report["rows_out"] = int(keep.sum())
    report["features_out"] = table.shape[1]
    return table.to_numpy()[keep], y[keep], report


def x_clean__mutmut_26(
    frame: pd.DataFrame, labels, category_cap: int = CATEGORY_CAP
) -> tuple[np.ndarray, np.ndarray, dict[str, Any]]:
    frame = frame.reset_index(drop=True)
    y = np.asarray(labels).astype(int)
    report: dict[str, Any] = {
        "rows_in": len(frame),
        "dropped_constant": [],
        "dropped_missing": [],
        "dropped_high_cardinality": [],
        "encoded": [],
    }
    pieces = []
    for name in frame.columns:
        col = frame[name]
        if col.isna().mean() > MAX_MISSING_SHARE:
            report["dropped_missing"].append(name)
        elif col.dropna().nunique() <= 1:
            report["dropped_constant"].append(None)
        elif pd.api.types.is_numeric_dtype(col) and not pd.api.types.is_bool_dtype(col):
            pieces.append(col.astype(float).rename(name))
        elif col.nunique() > category_cap:
            report["dropped_high_cardinality"].append(name)
        else:
            report["encoded"].append(name)
            pieces.append(pd.get_dummies(col.astype(str), prefix=str(name), dtype=float))
    if not pieces:
        raise NormaliseError("no usable feature left")
    table = pd.concat(pieces, axis=1)
    keys = pd.util.hash_pandas_object(table.fillna(np.inf), index=False)
    conflicting = pd.Series(y).groupby(keys.to_numpy()).transform("nunique").to_numpy() > 1
    report["conflicting_rows_removed"] = int(conflicting.sum())
    keep = ~conflicting
    first = ~pd.Series(keys.to_numpy()).duplicated().to_numpy()
    report["duplicates_removed"] = int((keep & ~first).sum())
    keep &= first
    report["rows_out"] = int(keep.sum())
    report["features_out"] = table.shape[1]
    return table.to_numpy()[keep], y[keep], report


def x_clean__mutmut_27(
    frame: pd.DataFrame, labels, category_cap: int = CATEGORY_CAP
) -> tuple[np.ndarray, np.ndarray, dict[str, Any]]:
    frame = frame.reset_index(drop=True)
    y = np.asarray(labels).astype(int)
    report: dict[str, Any] = {
        "rows_in": len(frame),
        "dropped_constant": [],
        "dropped_missing": [],
        "dropped_high_cardinality": [],
        "encoded": [],
    }
    pieces = []
    for name in frame.columns:
        col = frame[name]
        if col.isna().mean() > MAX_MISSING_SHARE:
            report["dropped_missing"].append(name)
        elif col.dropna().nunique() <= 1:
            report["XXdropped_constantXX"].append(name)
        elif pd.api.types.is_numeric_dtype(col) and not pd.api.types.is_bool_dtype(col):
            pieces.append(col.astype(float).rename(name))
        elif col.nunique() > category_cap:
            report["dropped_high_cardinality"].append(name)
        else:
            report["encoded"].append(name)
            pieces.append(pd.get_dummies(col.astype(str), prefix=str(name), dtype=float))
    if not pieces:
        raise NormaliseError("no usable feature left")
    table = pd.concat(pieces, axis=1)
    keys = pd.util.hash_pandas_object(table.fillna(np.inf), index=False)
    conflicting = pd.Series(y).groupby(keys.to_numpy()).transform("nunique").to_numpy() > 1
    report["conflicting_rows_removed"] = int(conflicting.sum())
    keep = ~conflicting
    first = ~pd.Series(keys.to_numpy()).duplicated().to_numpy()
    report["duplicates_removed"] = int((keep & ~first).sum())
    keep &= first
    report["rows_out"] = int(keep.sum())
    report["features_out"] = table.shape[1]
    return table.to_numpy()[keep], y[keep], report


def x_clean__mutmut_28(
    frame: pd.DataFrame, labels, category_cap: int = CATEGORY_CAP
) -> tuple[np.ndarray, np.ndarray, dict[str, Any]]:
    frame = frame.reset_index(drop=True)
    y = np.asarray(labels).astype(int)
    report: dict[str, Any] = {
        "rows_in": len(frame),
        "dropped_constant": [],
        "dropped_missing": [],
        "dropped_high_cardinality": [],
        "encoded": [],
    }
    pieces = []
    for name in frame.columns:
        col = frame[name]
        if col.isna().mean() > MAX_MISSING_SHARE:
            report["dropped_missing"].append(name)
        elif col.dropna().nunique() <= 1:
            report["DROPPED_CONSTANT"].append(name)
        elif pd.api.types.is_numeric_dtype(col) and not pd.api.types.is_bool_dtype(col):
            pieces.append(col.astype(float).rename(name))
        elif col.nunique() > category_cap:
            report["dropped_high_cardinality"].append(name)
        else:
            report["encoded"].append(name)
            pieces.append(pd.get_dummies(col.astype(str), prefix=str(name), dtype=float))
    if not pieces:
        raise NormaliseError("no usable feature left")
    table = pd.concat(pieces, axis=1)
    keys = pd.util.hash_pandas_object(table.fillna(np.inf), index=False)
    conflicting = pd.Series(y).groupby(keys.to_numpy()).transform("nunique").to_numpy() > 1
    report["conflicting_rows_removed"] = int(conflicting.sum())
    keep = ~conflicting
    first = ~pd.Series(keys.to_numpy()).duplicated().to_numpy()
    report["duplicates_removed"] = int((keep & ~first).sum())
    keep &= first
    report["rows_out"] = int(keep.sum())
    report["features_out"] = table.shape[1]
    return table.to_numpy()[keep], y[keep], report


def x_clean__mutmut_29(
    frame: pd.DataFrame, labels, category_cap: int = CATEGORY_CAP
) -> tuple[np.ndarray, np.ndarray, dict[str, Any]]:
    frame = frame.reset_index(drop=True)
    y = np.asarray(labels).astype(int)
    report: dict[str, Any] = {
        "rows_in": len(frame),
        "dropped_constant": [],
        "dropped_missing": [],
        "dropped_high_cardinality": [],
        "encoded": [],
    }
    pieces = []
    for name in frame.columns:
        col = frame[name]
        if col.isna().mean() > MAX_MISSING_SHARE:
            report["dropped_missing"].append(name)
        elif col.dropna().nunique() <= 1:
            report["dropped_constant"].append(name)
        elif pd.api.types.is_numeric_dtype(col) or not pd.api.types.is_bool_dtype(col):
            pieces.append(col.astype(float).rename(name))
        elif col.nunique() > category_cap:
            report["dropped_high_cardinality"].append(name)
        else:
            report["encoded"].append(name)
            pieces.append(pd.get_dummies(col.astype(str), prefix=str(name), dtype=float))
    if not pieces:
        raise NormaliseError("no usable feature left")
    table = pd.concat(pieces, axis=1)
    keys = pd.util.hash_pandas_object(table.fillna(np.inf), index=False)
    conflicting = pd.Series(y).groupby(keys.to_numpy()).transform("nunique").to_numpy() > 1
    report["conflicting_rows_removed"] = int(conflicting.sum())
    keep = ~conflicting
    first = ~pd.Series(keys.to_numpy()).duplicated().to_numpy()
    report["duplicates_removed"] = int((keep & ~first).sum())
    keep &= first
    report["rows_out"] = int(keep.sum())
    report["features_out"] = table.shape[1]
    return table.to_numpy()[keep], y[keep], report


def x_clean__mutmut_30(
    frame: pd.DataFrame, labels, category_cap: int = CATEGORY_CAP
) -> tuple[np.ndarray, np.ndarray, dict[str, Any]]:
    frame = frame.reset_index(drop=True)
    y = np.asarray(labels).astype(int)
    report: dict[str, Any] = {
        "rows_in": len(frame),
        "dropped_constant": [],
        "dropped_missing": [],
        "dropped_high_cardinality": [],
        "encoded": [],
    }
    pieces = []
    for name in frame.columns:
        col = frame[name]
        if col.isna().mean() > MAX_MISSING_SHARE:
            report["dropped_missing"].append(name)
        elif col.dropna().nunique() <= 1:
            report["dropped_constant"].append(name)
        elif pd.api.types.is_numeric_dtype(None) and not pd.api.types.is_bool_dtype(col):
            pieces.append(col.astype(float).rename(name))
        elif col.nunique() > category_cap:
            report["dropped_high_cardinality"].append(name)
        else:
            report["encoded"].append(name)
            pieces.append(pd.get_dummies(col.astype(str), prefix=str(name), dtype=float))
    if not pieces:
        raise NormaliseError("no usable feature left")
    table = pd.concat(pieces, axis=1)
    keys = pd.util.hash_pandas_object(table.fillna(np.inf), index=False)
    conflicting = pd.Series(y).groupby(keys.to_numpy()).transform("nunique").to_numpy() > 1
    report["conflicting_rows_removed"] = int(conflicting.sum())
    keep = ~conflicting
    first = ~pd.Series(keys.to_numpy()).duplicated().to_numpy()
    report["duplicates_removed"] = int((keep & ~first).sum())
    keep &= first
    report["rows_out"] = int(keep.sum())
    report["features_out"] = table.shape[1]
    return table.to_numpy()[keep], y[keep], report


def x_clean__mutmut_31(
    frame: pd.DataFrame, labels, category_cap: int = CATEGORY_CAP
) -> tuple[np.ndarray, np.ndarray, dict[str, Any]]:
    frame = frame.reset_index(drop=True)
    y = np.asarray(labels).astype(int)
    report: dict[str, Any] = {
        "rows_in": len(frame),
        "dropped_constant": [],
        "dropped_missing": [],
        "dropped_high_cardinality": [],
        "encoded": [],
    }
    pieces = []
    for name in frame.columns:
        col = frame[name]
        if col.isna().mean() > MAX_MISSING_SHARE:
            report["dropped_missing"].append(name)
        elif col.dropna().nunique() <= 1:
            report["dropped_constant"].append(name)
        elif pd.api.types.is_numeric_dtype(col) and pd.api.types.is_bool_dtype(col):
            pieces.append(col.astype(float).rename(name))
        elif col.nunique() > category_cap:
            report["dropped_high_cardinality"].append(name)
        else:
            report["encoded"].append(name)
            pieces.append(pd.get_dummies(col.astype(str), prefix=str(name), dtype=float))
    if not pieces:
        raise NormaliseError("no usable feature left")
    table = pd.concat(pieces, axis=1)
    keys = pd.util.hash_pandas_object(table.fillna(np.inf), index=False)
    conflicting = pd.Series(y).groupby(keys.to_numpy()).transform("nunique").to_numpy() > 1
    report["conflicting_rows_removed"] = int(conflicting.sum())
    keep = ~conflicting
    first = ~pd.Series(keys.to_numpy()).duplicated().to_numpy()
    report["duplicates_removed"] = int((keep & ~first).sum())
    keep &= first
    report["rows_out"] = int(keep.sum())
    report["features_out"] = table.shape[1]
    return table.to_numpy()[keep], y[keep], report


def x_clean__mutmut_32(
    frame: pd.DataFrame, labels, category_cap: int = CATEGORY_CAP
) -> tuple[np.ndarray, np.ndarray, dict[str, Any]]:
    frame = frame.reset_index(drop=True)
    y = np.asarray(labels).astype(int)
    report: dict[str, Any] = {
        "rows_in": len(frame),
        "dropped_constant": [],
        "dropped_missing": [],
        "dropped_high_cardinality": [],
        "encoded": [],
    }
    pieces = []
    for name in frame.columns:
        col = frame[name]
        if col.isna().mean() > MAX_MISSING_SHARE:
            report["dropped_missing"].append(name)
        elif col.dropna().nunique() <= 1:
            report["dropped_constant"].append(name)
        elif pd.api.types.is_numeric_dtype(col) and not pd.api.types.is_bool_dtype(None):
            pieces.append(col.astype(float).rename(name))
        elif col.nunique() > category_cap:
            report["dropped_high_cardinality"].append(name)
        else:
            report["encoded"].append(name)
            pieces.append(pd.get_dummies(col.astype(str), prefix=str(name), dtype=float))
    if not pieces:
        raise NormaliseError("no usable feature left")
    table = pd.concat(pieces, axis=1)
    keys = pd.util.hash_pandas_object(table.fillna(np.inf), index=False)
    conflicting = pd.Series(y).groupby(keys.to_numpy()).transform("nunique").to_numpy() > 1
    report["conflicting_rows_removed"] = int(conflicting.sum())
    keep = ~conflicting
    first = ~pd.Series(keys.to_numpy()).duplicated().to_numpy()
    report["duplicates_removed"] = int((keep & ~first).sum())
    keep &= first
    report["rows_out"] = int(keep.sum())
    report["features_out"] = table.shape[1]
    return table.to_numpy()[keep], y[keep], report


def x_clean__mutmut_33(
    frame: pd.DataFrame, labels, category_cap: int = CATEGORY_CAP
) -> tuple[np.ndarray, np.ndarray, dict[str, Any]]:
    frame = frame.reset_index(drop=True)
    y = np.asarray(labels).astype(int)
    report: dict[str, Any] = {
        "rows_in": len(frame),
        "dropped_constant": [],
        "dropped_missing": [],
        "dropped_high_cardinality": [],
        "encoded": [],
    }
    pieces = []
    for name in frame.columns:
        col = frame[name]
        if col.isna().mean() > MAX_MISSING_SHARE:
            report["dropped_missing"].append(name)
        elif col.dropna().nunique() <= 1:
            report["dropped_constant"].append(name)
        elif pd.api.types.is_numeric_dtype(col) and not pd.api.types.is_bool_dtype(col):
            pieces.append(None)
        elif col.nunique() > category_cap:
            report["dropped_high_cardinality"].append(name)
        else:
            report["encoded"].append(name)
            pieces.append(pd.get_dummies(col.astype(str), prefix=str(name), dtype=float))
    if not pieces:
        raise NormaliseError("no usable feature left")
    table = pd.concat(pieces, axis=1)
    keys = pd.util.hash_pandas_object(table.fillna(np.inf), index=False)
    conflicting = pd.Series(y).groupby(keys.to_numpy()).transform("nunique").to_numpy() > 1
    report["conflicting_rows_removed"] = int(conflicting.sum())
    keep = ~conflicting
    first = ~pd.Series(keys.to_numpy()).duplicated().to_numpy()
    report["duplicates_removed"] = int((keep & ~first).sum())
    keep &= first
    report["rows_out"] = int(keep.sum())
    report["features_out"] = table.shape[1]
    return table.to_numpy()[keep], y[keep], report


def x_clean__mutmut_34(
    frame: pd.DataFrame, labels, category_cap: int = CATEGORY_CAP
) -> tuple[np.ndarray, np.ndarray, dict[str, Any]]:
    frame = frame.reset_index(drop=True)
    y = np.asarray(labels).astype(int)
    report: dict[str, Any] = {
        "rows_in": len(frame),
        "dropped_constant": [],
        "dropped_missing": [],
        "dropped_high_cardinality": [],
        "encoded": [],
    }
    pieces = []
    for name in frame.columns:
        col = frame[name]
        if col.isna().mean() > MAX_MISSING_SHARE:
            report["dropped_missing"].append(name)
        elif col.dropna().nunique() <= 1:
            report["dropped_constant"].append(name)
        elif pd.api.types.is_numeric_dtype(col) and not pd.api.types.is_bool_dtype(col):
            pieces.append(col.astype(float).rename(None))
        elif col.nunique() > category_cap:
            report["dropped_high_cardinality"].append(name)
        else:
            report["encoded"].append(name)
            pieces.append(pd.get_dummies(col.astype(str), prefix=str(name), dtype=float))
    if not pieces:
        raise NormaliseError("no usable feature left")
    table = pd.concat(pieces, axis=1)
    keys = pd.util.hash_pandas_object(table.fillna(np.inf), index=False)
    conflicting = pd.Series(y).groupby(keys.to_numpy()).transform("nunique").to_numpy() > 1
    report["conflicting_rows_removed"] = int(conflicting.sum())
    keep = ~conflicting
    first = ~pd.Series(keys.to_numpy()).duplicated().to_numpy()
    report["duplicates_removed"] = int((keep & ~first).sum())
    keep &= first
    report["rows_out"] = int(keep.sum())
    report["features_out"] = table.shape[1]
    return table.to_numpy()[keep], y[keep], report


def x_clean__mutmut_35(
    frame: pd.DataFrame, labels, category_cap: int = CATEGORY_CAP
) -> tuple[np.ndarray, np.ndarray, dict[str, Any]]:
    frame = frame.reset_index(drop=True)
    y = np.asarray(labels).astype(int)
    report: dict[str, Any] = {
        "rows_in": len(frame),
        "dropped_constant": [],
        "dropped_missing": [],
        "dropped_high_cardinality": [],
        "encoded": [],
    }
    pieces = []
    for name in frame.columns:
        col = frame[name]
        if col.isna().mean() > MAX_MISSING_SHARE:
            report["dropped_missing"].append(name)
        elif col.dropna().nunique() <= 1:
            report["dropped_constant"].append(name)
        elif pd.api.types.is_numeric_dtype(col) and not pd.api.types.is_bool_dtype(col):
            pieces.append(col.astype(None).rename(name))
        elif col.nunique() > category_cap:
            report["dropped_high_cardinality"].append(name)
        else:
            report["encoded"].append(name)
            pieces.append(pd.get_dummies(col.astype(str), prefix=str(name), dtype=float))
    if not pieces:
        raise NormaliseError("no usable feature left")
    table = pd.concat(pieces, axis=1)
    keys = pd.util.hash_pandas_object(table.fillna(np.inf), index=False)
    conflicting = pd.Series(y).groupby(keys.to_numpy()).transform("nunique").to_numpy() > 1
    report["conflicting_rows_removed"] = int(conflicting.sum())
    keep = ~conflicting
    first = ~pd.Series(keys.to_numpy()).duplicated().to_numpy()
    report["duplicates_removed"] = int((keep & ~first).sum())
    keep &= first
    report["rows_out"] = int(keep.sum())
    report["features_out"] = table.shape[1]
    return table.to_numpy()[keep], y[keep], report


def x_clean__mutmut_36(
    frame: pd.DataFrame, labels, category_cap: int = CATEGORY_CAP
) -> tuple[np.ndarray, np.ndarray, dict[str, Any]]:
    frame = frame.reset_index(drop=True)
    y = np.asarray(labels).astype(int)
    report: dict[str, Any] = {
        "rows_in": len(frame),
        "dropped_constant": [],
        "dropped_missing": [],
        "dropped_high_cardinality": [],
        "encoded": [],
    }
    pieces = []
    for name in frame.columns:
        col = frame[name]
        if col.isna().mean() > MAX_MISSING_SHARE:
            report["dropped_missing"].append(name)
        elif col.dropna().nunique() <= 1:
            report["dropped_constant"].append(name)
        elif pd.api.types.is_numeric_dtype(col) and not pd.api.types.is_bool_dtype(col):
            pieces.append(col.astype(float).rename(name))
        elif col.nunique() >= category_cap:
            report["dropped_high_cardinality"].append(name)
        else:
            report["encoded"].append(name)
            pieces.append(pd.get_dummies(col.astype(str), prefix=str(name), dtype=float))
    if not pieces:
        raise NormaliseError("no usable feature left")
    table = pd.concat(pieces, axis=1)
    keys = pd.util.hash_pandas_object(table.fillna(np.inf), index=False)
    conflicting = pd.Series(y).groupby(keys.to_numpy()).transform("nunique").to_numpy() > 1
    report["conflicting_rows_removed"] = int(conflicting.sum())
    keep = ~conflicting
    first = ~pd.Series(keys.to_numpy()).duplicated().to_numpy()
    report["duplicates_removed"] = int((keep & ~first).sum())
    keep &= first
    report["rows_out"] = int(keep.sum())
    report["features_out"] = table.shape[1]
    return table.to_numpy()[keep], y[keep], report


def x_clean__mutmut_37(
    frame: pd.DataFrame, labels, category_cap: int = CATEGORY_CAP
) -> tuple[np.ndarray, np.ndarray, dict[str, Any]]:
    frame = frame.reset_index(drop=True)
    y = np.asarray(labels).astype(int)
    report: dict[str, Any] = {
        "rows_in": len(frame),
        "dropped_constant": [],
        "dropped_missing": [],
        "dropped_high_cardinality": [],
        "encoded": [],
    }
    pieces = []
    for name in frame.columns:
        col = frame[name]
        if col.isna().mean() > MAX_MISSING_SHARE:
            report["dropped_missing"].append(name)
        elif col.dropna().nunique() <= 1:
            report["dropped_constant"].append(name)
        elif pd.api.types.is_numeric_dtype(col) and not pd.api.types.is_bool_dtype(col):
            pieces.append(col.astype(float).rename(name))
        elif col.nunique() > category_cap:
            report["dropped_high_cardinality"].append(None)
        else:
            report["encoded"].append(name)
            pieces.append(pd.get_dummies(col.astype(str), prefix=str(name), dtype=float))
    if not pieces:
        raise NormaliseError("no usable feature left")
    table = pd.concat(pieces, axis=1)
    keys = pd.util.hash_pandas_object(table.fillna(np.inf), index=False)
    conflicting = pd.Series(y).groupby(keys.to_numpy()).transform("nunique").to_numpy() > 1
    report["conflicting_rows_removed"] = int(conflicting.sum())
    keep = ~conflicting
    first = ~pd.Series(keys.to_numpy()).duplicated().to_numpy()
    report["duplicates_removed"] = int((keep & ~first).sum())
    keep &= first
    report["rows_out"] = int(keep.sum())
    report["features_out"] = table.shape[1]
    return table.to_numpy()[keep], y[keep], report


def x_clean__mutmut_38(
    frame: pd.DataFrame, labels, category_cap: int = CATEGORY_CAP
) -> tuple[np.ndarray, np.ndarray, dict[str, Any]]:
    frame = frame.reset_index(drop=True)
    y = np.asarray(labels).astype(int)
    report: dict[str, Any] = {
        "rows_in": len(frame),
        "dropped_constant": [],
        "dropped_missing": [],
        "dropped_high_cardinality": [],
        "encoded": [],
    }
    pieces = []
    for name in frame.columns:
        col = frame[name]
        if col.isna().mean() > MAX_MISSING_SHARE:
            report["dropped_missing"].append(name)
        elif col.dropna().nunique() <= 1:
            report["dropped_constant"].append(name)
        elif pd.api.types.is_numeric_dtype(col) and not pd.api.types.is_bool_dtype(col):
            pieces.append(col.astype(float).rename(name))
        elif col.nunique() > category_cap:
            report["XXdropped_high_cardinalityXX"].append(name)
        else:
            report["encoded"].append(name)
            pieces.append(pd.get_dummies(col.astype(str), prefix=str(name), dtype=float))
    if not pieces:
        raise NormaliseError("no usable feature left")
    table = pd.concat(pieces, axis=1)
    keys = pd.util.hash_pandas_object(table.fillna(np.inf), index=False)
    conflicting = pd.Series(y).groupby(keys.to_numpy()).transform("nunique").to_numpy() > 1
    report["conflicting_rows_removed"] = int(conflicting.sum())
    keep = ~conflicting
    first = ~pd.Series(keys.to_numpy()).duplicated().to_numpy()
    report["duplicates_removed"] = int((keep & ~first).sum())
    keep &= first
    report["rows_out"] = int(keep.sum())
    report["features_out"] = table.shape[1]
    return table.to_numpy()[keep], y[keep], report


def x_clean__mutmut_39(
    frame: pd.DataFrame, labels, category_cap: int = CATEGORY_CAP
) -> tuple[np.ndarray, np.ndarray, dict[str, Any]]:
    frame = frame.reset_index(drop=True)
    y = np.asarray(labels).astype(int)
    report: dict[str, Any] = {
        "rows_in": len(frame),
        "dropped_constant": [],
        "dropped_missing": [],
        "dropped_high_cardinality": [],
        "encoded": [],
    }
    pieces = []
    for name in frame.columns:
        col = frame[name]
        if col.isna().mean() > MAX_MISSING_SHARE:
            report["dropped_missing"].append(name)
        elif col.dropna().nunique() <= 1:
            report["dropped_constant"].append(name)
        elif pd.api.types.is_numeric_dtype(col) and not pd.api.types.is_bool_dtype(col):
            pieces.append(col.astype(float).rename(name))
        elif col.nunique() > category_cap:
            report["DROPPED_HIGH_CARDINALITY"].append(name)
        else:
            report["encoded"].append(name)
            pieces.append(pd.get_dummies(col.astype(str), prefix=str(name), dtype=float))
    if not pieces:
        raise NormaliseError("no usable feature left")
    table = pd.concat(pieces, axis=1)
    keys = pd.util.hash_pandas_object(table.fillna(np.inf), index=False)
    conflicting = pd.Series(y).groupby(keys.to_numpy()).transform("nunique").to_numpy() > 1
    report["conflicting_rows_removed"] = int(conflicting.sum())
    keep = ~conflicting
    first = ~pd.Series(keys.to_numpy()).duplicated().to_numpy()
    report["duplicates_removed"] = int((keep & ~first).sum())
    keep &= first
    report["rows_out"] = int(keep.sum())
    report["features_out"] = table.shape[1]
    return table.to_numpy()[keep], y[keep], report


def x_clean__mutmut_40(
    frame: pd.DataFrame, labels, category_cap: int = CATEGORY_CAP
) -> tuple[np.ndarray, np.ndarray, dict[str, Any]]:
    frame = frame.reset_index(drop=True)
    y = np.asarray(labels).astype(int)
    report: dict[str, Any] = {
        "rows_in": len(frame),
        "dropped_constant": [],
        "dropped_missing": [],
        "dropped_high_cardinality": [],
        "encoded": [],
    }
    pieces = []
    for name in frame.columns:
        col = frame[name]
        if col.isna().mean() > MAX_MISSING_SHARE:
            report["dropped_missing"].append(name)
        elif col.dropna().nunique() <= 1:
            report["dropped_constant"].append(name)
        elif pd.api.types.is_numeric_dtype(col) and not pd.api.types.is_bool_dtype(col):
            pieces.append(col.astype(float).rename(name))
        elif col.nunique() > category_cap:
            report["dropped_high_cardinality"].append(name)
        else:
            report["encoded"].append(None)
            pieces.append(pd.get_dummies(col.astype(str), prefix=str(name), dtype=float))
    if not pieces:
        raise NormaliseError("no usable feature left")
    table = pd.concat(pieces, axis=1)
    keys = pd.util.hash_pandas_object(table.fillna(np.inf), index=False)
    conflicting = pd.Series(y).groupby(keys.to_numpy()).transform("nunique").to_numpy() > 1
    report["conflicting_rows_removed"] = int(conflicting.sum())
    keep = ~conflicting
    first = ~pd.Series(keys.to_numpy()).duplicated().to_numpy()
    report["duplicates_removed"] = int((keep & ~first).sum())
    keep &= first
    report["rows_out"] = int(keep.sum())
    report["features_out"] = table.shape[1]
    return table.to_numpy()[keep], y[keep], report


def x_clean__mutmut_41(
    frame: pd.DataFrame, labels, category_cap: int = CATEGORY_CAP
) -> tuple[np.ndarray, np.ndarray, dict[str, Any]]:
    frame = frame.reset_index(drop=True)
    y = np.asarray(labels).astype(int)
    report: dict[str, Any] = {
        "rows_in": len(frame),
        "dropped_constant": [],
        "dropped_missing": [],
        "dropped_high_cardinality": [],
        "encoded": [],
    }
    pieces = []
    for name in frame.columns:
        col = frame[name]
        if col.isna().mean() > MAX_MISSING_SHARE:
            report["dropped_missing"].append(name)
        elif col.dropna().nunique() <= 1:
            report["dropped_constant"].append(name)
        elif pd.api.types.is_numeric_dtype(col) and not pd.api.types.is_bool_dtype(col):
            pieces.append(col.astype(float).rename(name))
        elif col.nunique() > category_cap:
            report["dropped_high_cardinality"].append(name)
        else:
            report["XXencodedXX"].append(name)
            pieces.append(pd.get_dummies(col.astype(str), prefix=str(name), dtype=float))
    if not pieces:
        raise NormaliseError("no usable feature left")
    table = pd.concat(pieces, axis=1)
    keys = pd.util.hash_pandas_object(table.fillna(np.inf), index=False)
    conflicting = pd.Series(y).groupby(keys.to_numpy()).transform("nunique").to_numpy() > 1
    report["conflicting_rows_removed"] = int(conflicting.sum())
    keep = ~conflicting
    first = ~pd.Series(keys.to_numpy()).duplicated().to_numpy()
    report["duplicates_removed"] = int((keep & ~first).sum())
    keep &= first
    report["rows_out"] = int(keep.sum())
    report["features_out"] = table.shape[1]
    return table.to_numpy()[keep], y[keep], report


def x_clean__mutmut_42(
    frame: pd.DataFrame, labels, category_cap: int = CATEGORY_CAP
) -> tuple[np.ndarray, np.ndarray, dict[str, Any]]:
    frame = frame.reset_index(drop=True)
    y = np.asarray(labels).astype(int)
    report: dict[str, Any] = {
        "rows_in": len(frame),
        "dropped_constant": [],
        "dropped_missing": [],
        "dropped_high_cardinality": [],
        "encoded": [],
    }
    pieces = []
    for name in frame.columns:
        col = frame[name]
        if col.isna().mean() > MAX_MISSING_SHARE:
            report["dropped_missing"].append(name)
        elif col.dropna().nunique() <= 1:
            report["dropped_constant"].append(name)
        elif pd.api.types.is_numeric_dtype(col) and not pd.api.types.is_bool_dtype(col):
            pieces.append(col.astype(float).rename(name))
        elif col.nunique() > category_cap:
            report["dropped_high_cardinality"].append(name)
        else:
            report["ENCODED"].append(name)
            pieces.append(pd.get_dummies(col.astype(str), prefix=str(name), dtype=float))
    if not pieces:
        raise NormaliseError("no usable feature left")
    table = pd.concat(pieces, axis=1)
    keys = pd.util.hash_pandas_object(table.fillna(np.inf), index=False)
    conflicting = pd.Series(y).groupby(keys.to_numpy()).transform("nunique").to_numpy() > 1
    report["conflicting_rows_removed"] = int(conflicting.sum())
    keep = ~conflicting
    first = ~pd.Series(keys.to_numpy()).duplicated().to_numpy()
    report["duplicates_removed"] = int((keep & ~first).sum())
    keep &= first
    report["rows_out"] = int(keep.sum())
    report["features_out"] = table.shape[1]
    return table.to_numpy()[keep], y[keep], report


def x_clean__mutmut_43(
    frame: pd.DataFrame, labels, category_cap: int = CATEGORY_CAP
) -> tuple[np.ndarray, np.ndarray, dict[str, Any]]:
    frame = frame.reset_index(drop=True)
    y = np.asarray(labels).astype(int)
    report: dict[str, Any] = {
        "rows_in": len(frame),
        "dropped_constant": [],
        "dropped_missing": [],
        "dropped_high_cardinality": [],
        "encoded": [],
    }
    pieces = []
    for name in frame.columns:
        col = frame[name]
        if col.isna().mean() > MAX_MISSING_SHARE:
            report["dropped_missing"].append(name)
        elif col.dropna().nunique() <= 1:
            report["dropped_constant"].append(name)
        elif pd.api.types.is_numeric_dtype(col) and not pd.api.types.is_bool_dtype(col):
            pieces.append(col.astype(float).rename(name))
        elif col.nunique() > category_cap:
            report["dropped_high_cardinality"].append(name)
        else:
            report["encoded"].append(name)
            pieces.append(None)
    if not pieces:
        raise NormaliseError("no usable feature left")
    table = pd.concat(pieces, axis=1)
    keys = pd.util.hash_pandas_object(table.fillna(np.inf), index=False)
    conflicting = pd.Series(y).groupby(keys.to_numpy()).transform("nunique").to_numpy() > 1
    report["conflicting_rows_removed"] = int(conflicting.sum())
    keep = ~conflicting
    first = ~pd.Series(keys.to_numpy()).duplicated().to_numpy()
    report["duplicates_removed"] = int((keep & ~first).sum())
    keep &= first
    report["rows_out"] = int(keep.sum())
    report["features_out"] = table.shape[1]
    return table.to_numpy()[keep], y[keep], report


def x_clean__mutmut_44(
    frame: pd.DataFrame, labels, category_cap: int = CATEGORY_CAP
) -> tuple[np.ndarray, np.ndarray, dict[str, Any]]:
    frame = frame.reset_index(drop=True)
    y = np.asarray(labels).astype(int)
    report: dict[str, Any] = {
        "rows_in": len(frame),
        "dropped_constant": [],
        "dropped_missing": [],
        "dropped_high_cardinality": [],
        "encoded": [],
    }
    pieces = []
    for name in frame.columns:
        col = frame[name]
        if col.isna().mean() > MAX_MISSING_SHARE:
            report["dropped_missing"].append(name)
        elif col.dropna().nunique() <= 1:
            report["dropped_constant"].append(name)
        elif pd.api.types.is_numeric_dtype(col) and not pd.api.types.is_bool_dtype(col):
            pieces.append(col.astype(float).rename(name))
        elif col.nunique() > category_cap:
            report["dropped_high_cardinality"].append(name)
        else:
            report["encoded"].append(name)
            pieces.append(pd.get_dummies(None, prefix=str(name), dtype=float))
    if not pieces:
        raise NormaliseError("no usable feature left")
    table = pd.concat(pieces, axis=1)
    keys = pd.util.hash_pandas_object(table.fillna(np.inf), index=False)
    conflicting = pd.Series(y).groupby(keys.to_numpy()).transform("nunique").to_numpy() > 1
    report["conflicting_rows_removed"] = int(conflicting.sum())
    keep = ~conflicting
    first = ~pd.Series(keys.to_numpy()).duplicated().to_numpy()
    report["duplicates_removed"] = int((keep & ~first).sum())
    keep &= first
    report["rows_out"] = int(keep.sum())
    report["features_out"] = table.shape[1]
    return table.to_numpy()[keep], y[keep], report


def x_clean__mutmut_45(
    frame: pd.DataFrame, labels, category_cap: int = CATEGORY_CAP
) -> tuple[np.ndarray, np.ndarray, dict[str, Any]]:
    frame = frame.reset_index(drop=True)
    y = np.asarray(labels).astype(int)
    report: dict[str, Any] = {
        "rows_in": len(frame),
        "dropped_constant": [],
        "dropped_missing": [],
        "dropped_high_cardinality": [],
        "encoded": [],
    }
    pieces = []
    for name in frame.columns:
        col = frame[name]
        if col.isna().mean() > MAX_MISSING_SHARE:
            report["dropped_missing"].append(name)
        elif col.dropna().nunique() <= 1:
            report["dropped_constant"].append(name)
        elif pd.api.types.is_numeric_dtype(col) and not pd.api.types.is_bool_dtype(col):
            pieces.append(col.astype(float).rename(name))
        elif col.nunique() > category_cap:
            report["dropped_high_cardinality"].append(name)
        else:
            report["encoded"].append(name)
            pieces.append(pd.get_dummies(col.astype(str), prefix=None, dtype=float))
    if not pieces:
        raise NormaliseError("no usable feature left")
    table = pd.concat(pieces, axis=1)
    keys = pd.util.hash_pandas_object(table.fillna(np.inf), index=False)
    conflicting = pd.Series(y).groupby(keys.to_numpy()).transform("nunique").to_numpy() > 1
    report["conflicting_rows_removed"] = int(conflicting.sum())
    keep = ~conflicting
    first = ~pd.Series(keys.to_numpy()).duplicated().to_numpy()
    report["duplicates_removed"] = int((keep & ~first).sum())
    keep &= first
    report["rows_out"] = int(keep.sum())
    report["features_out"] = table.shape[1]
    return table.to_numpy()[keep], y[keep], report


def x_clean__mutmut_46(
    frame: pd.DataFrame, labels, category_cap: int = CATEGORY_CAP
) -> tuple[np.ndarray, np.ndarray, dict[str, Any]]:
    frame = frame.reset_index(drop=True)
    y = np.asarray(labels).astype(int)
    report: dict[str, Any] = {
        "rows_in": len(frame),
        "dropped_constant": [],
        "dropped_missing": [],
        "dropped_high_cardinality": [],
        "encoded": [],
    }
    pieces = []
    for name in frame.columns:
        col = frame[name]
        if col.isna().mean() > MAX_MISSING_SHARE:
            report["dropped_missing"].append(name)
        elif col.dropna().nunique() <= 1:
            report["dropped_constant"].append(name)
        elif pd.api.types.is_numeric_dtype(col) and not pd.api.types.is_bool_dtype(col):
            pieces.append(col.astype(float).rename(name))
        elif col.nunique() > category_cap:
            report["dropped_high_cardinality"].append(name)
        else:
            report["encoded"].append(name)
            pieces.append(pd.get_dummies(col.astype(str), prefix=str(name), dtype=None))
    if not pieces:
        raise NormaliseError("no usable feature left")
    table = pd.concat(pieces, axis=1)
    keys = pd.util.hash_pandas_object(table.fillna(np.inf), index=False)
    conflicting = pd.Series(y).groupby(keys.to_numpy()).transform("nunique").to_numpy() > 1
    report["conflicting_rows_removed"] = int(conflicting.sum())
    keep = ~conflicting
    first = ~pd.Series(keys.to_numpy()).duplicated().to_numpy()
    report["duplicates_removed"] = int((keep & ~first).sum())
    keep &= first
    report["rows_out"] = int(keep.sum())
    report["features_out"] = table.shape[1]
    return table.to_numpy()[keep], y[keep], report


def x_clean__mutmut_47(
    frame: pd.DataFrame, labels, category_cap: int = CATEGORY_CAP
) -> tuple[np.ndarray, np.ndarray, dict[str, Any]]:
    frame = frame.reset_index(drop=True)
    y = np.asarray(labels).astype(int)
    report: dict[str, Any] = {
        "rows_in": len(frame),
        "dropped_constant": [],
        "dropped_missing": [],
        "dropped_high_cardinality": [],
        "encoded": [],
    }
    pieces = []
    for name in frame.columns:
        col = frame[name]
        if col.isna().mean() > MAX_MISSING_SHARE:
            report["dropped_missing"].append(name)
        elif col.dropna().nunique() <= 1:
            report["dropped_constant"].append(name)
        elif pd.api.types.is_numeric_dtype(col) and not pd.api.types.is_bool_dtype(col):
            pieces.append(col.astype(float).rename(name))
        elif col.nunique() > category_cap:
            report["dropped_high_cardinality"].append(name)
        else:
            report["encoded"].append(name)
            pieces.append(pd.get_dummies(prefix=str(name), dtype=float))
    if not pieces:
        raise NormaliseError("no usable feature left")
    table = pd.concat(pieces, axis=1)
    keys = pd.util.hash_pandas_object(table.fillna(np.inf), index=False)
    conflicting = pd.Series(y).groupby(keys.to_numpy()).transform("nunique").to_numpy() > 1
    report["conflicting_rows_removed"] = int(conflicting.sum())
    keep = ~conflicting
    first = ~pd.Series(keys.to_numpy()).duplicated().to_numpy()
    report["duplicates_removed"] = int((keep & ~first).sum())
    keep &= first
    report["rows_out"] = int(keep.sum())
    report["features_out"] = table.shape[1]
    return table.to_numpy()[keep], y[keep], report


def x_clean__mutmut_48(
    frame: pd.DataFrame, labels, category_cap: int = CATEGORY_CAP
) -> tuple[np.ndarray, np.ndarray, dict[str, Any]]:
    frame = frame.reset_index(drop=True)
    y = np.asarray(labels).astype(int)
    report: dict[str, Any] = {
        "rows_in": len(frame),
        "dropped_constant": [],
        "dropped_missing": [],
        "dropped_high_cardinality": [],
        "encoded": [],
    }
    pieces = []
    for name in frame.columns:
        col = frame[name]
        if col.isna().mean() > MAX_MISSING_SHARE:
            report["dropped_missing"].append(name)
        elif col.dropna().nunique() <= 1:
            report["dropped_constant"].append(name)
        elif pd.api.types.is_numeric_dtype(col) and not pd.api.types.is_bool_dtype(col):
            pieces.append(col.astype(float).rename(name))
        elif col.nunique() > category_cap:
            report["dropped_high_cardinality"].append(name)
        else:
            report["encoded"].append(name)
            pieces.append(pd.get_dummies(col.astype(str), dtype=float))
    if not pieces:
        raise NormaliseError("no usable feature left")
    table = pd.concat(pieces, axis=1)
    keys = pd.util.hash_pandas_object(table.fillna(np.inf), index=False)
    conflicting = pd.Series(y).groupby(keys.to_numpy()).transform("nunique").to_numpy() > 1
    report["conflicting_rows_removed"] = int(conflicting.sum())
    keep = ~conflicting
    first = ~pd.Series(keys.to_numpy()).duplicated().to_numpy()
    report["duplicates_removed"] = int((keep & ~first).sum())
    keep &= first
    report["rows_out"] = int(keep.sum())
    report["features_out"] = table.shape[1]
    return table.to_numpy()[keep], y[keep], report


def x_clean__mutmut_49(
    frame: pd.DataFrame, labels, category_cap: int = CATEGORY_CAP
) -> tuple[np.ndarray, np.ndarray, dict[str, Any]]:
    frame = frame.reset_index(drop=True)
    y = np.asarray(labels).astype(int)
    report: dict[str, Any] = {
        "rows_in": len(frame),
        "dropped_constant": [],
        "dropped_missing": [],
        "dropped_high_cardinality": [],
        "encoded": [],
    }
    pieces = []
    for name in frame.columns:
        col = frame[name]
        if col.isna().mean() > MAX_MISSING_SHARE:
            report["dropped_missing"].append(name)
        elif col.dropna().nunique() <= 1:
            report["dropped_constant"].append(name)
        elif pd.api.types.is_numeric_dtype(col) and not pd.api.types.is_bool_dtype(col):
            pieces.append(col.astype(float).rename(name))
        elif col.nunique() > category_cap:
            report["dropped_high_cardinality"].append(name)
        else:
            report["encoded"].append(name)
            pieces.append(pd.get_dummies(col.astype(str), prefix=str(name), ))
    if not pieces:
        raise NormaliseError("no usable feature left")
    table = pd.concat(pieces, axis=1)
    keys = pd.util.hash_pandas_object(table.fillna(np.inf), index=False)
    conflicting = pd.Series(y).groupby(keys.to_numpy()).transform("nunique").to_numpy() > 1
    report["conflicting_rows_removed"] = int(conflicting.sum())
    keep = ~conflicting
    first = ~pd.Series(keys.to_numpy()).duplicated().to_numpy()
    report["duplicates_removed"] = int((keep & ~first).sum())
    keep &= first
    report["rows_out"] = int(keep.sum())
    report["features_out"] = table.shape[1]
    return table.to_numpy()[keep], y[keep], report


def x_clean__mutmut_50(
    frame: pd.DataFrame, labels, category_cap: int = CATEGORY_CAP
) -> tuple[np.ndarray, np.ndarray, dict[str, Any]]:
    frame = frame.reset_index(drop=True)
    y = np.asarray(labels).astype(int)
    report: dict[str, Any] = {
        "rows_in": len(frame),
        "dropped_constant": [],
        "dropped_missing": [],
        "dropped_high_cardinality": [],
        "encoded": [],
    }
    pieces = []
    for name in frame.columns:
        col = frame[name]
        if col.isna().mean() > MAX_MISSING_SHARE:
            report["dropped_missing"].append(name)
        elif col.dropna().nunique() <= 1:
            report["dropped_constant"].append(name)
        elif pd.api.types.is_numeric_dtype(col) and not pd.api.types.is_bool_dtype(col):
            pieces.append(col.astype(float).rename(name))
        elif col.nunique() > category_cap:
            report["dropped_high_cardinality"].append(name)
        else:
            report["encoded"].append(name)
            pieces.append(pd.get_dummies(col.astype(None), prefix=str(name), dtype=float))
    if not pieces:
        raise NormaliseError("no usable feature left")
    table = pd.concat(pieces, axis=1)
    keys = pd.util.hash_pandas_object(table.fillna(np.inf), index=False)
    conflicting = pd.Series(y).groupby(keys.to_numpy()).transform("nunique").to_numpy() > 1
    report["conflicting_rows_removed"] = int(conflicting.sum())
    keep = ~conflicting
    first = ~pd.Series(keys.to_numpy()).duplicated().to_numpy()
    report["duplicates_removed"] = int((keep & ~first).sum())
    keep &= first
    report["rows_out"] = int(keep.sum())
    report["features_out"] = table.shape[1]
    return table.to_numpy()[keep], y[keep], report


def x_clean__mutmut_51(
    frame: pd.DataFrame, labels, category_cap: int = CATEGORY_CAP
) -> tuple[np.ndarray, np.ndarray, dict[str, Any]]:
    frame = frame.reset_index(drop=True)
    y = np.asarray(labels).astype(int)
    report: dict[str, Any] = {
        "rows_in": len(frame),
        "dropped_constant": [],
        "dropped_missing": [],
        "dropped_high_cardinality": [],
        "encoded": [],
    }
    pieces = []
    for name in frame.columns:
        col = frame[name]
        if col.isna().mean() > MAX_MISSING_SHARE:
            report["dropped_missing"].append(name)
        elif col.dropna().nunique() <= 1:
            report["dropped_constant"].append(name)
        elif pd.api.types.is_numeric_dtype(col) and not pd.api.types.is_bool_dtype(col):
            pieces.append(col.astype(float).rename(name))
        elif col.nunique() > category_cap:
            report["dropped_high_cardinality"].append(name)
        else:
            report["encoded"].append(name)
            pieces.append(pd.get_dummies(col.astype(str), prefix=str(None), dtype=float))
    if not pieces:
        raise NormaliseError("no usable feature left")
    table = pd.concat(pieces, axis=1)
    keys = pd.util.hash_pandas_object(table.fillna(np.inf), index=False)
    conflicting = pd.Series(y).groupby(keys.to_numpy()).transform("nunique").to_numpy() > 1
    report["conflicting_rows_removed"] = int(conflicting.sum())
    keep = ~conflicting
    first = ~pd.Series(keys.to_numpy()).duplicated().to_numpy()
    report["duplicates_removed"] = int((keep & ~first).sum())
    keep &= first
    report["rows_out"] = int(keep.sum())
    report["features_out"] = table.shape[1]
    return table.to_numpy()[keep], y[keep], report


def x_clean__mutmut_52(
    frame: pd.DataFrame, labels, category_cap: int = CATEGORY_CAP
) -> tuple[np.ndarray, np.ndarray, dict[str, Any]]:
    frame = frame.reset_index(drop=True)
    y = np.asarray(labels).astype(int)
    report: dict[str, Any] = {
        "rows_in": len(frame),
        "dropped_constant": [],
        "dropped_missing": [],
        "dropped_high_cardinality": [],
        "encoded": [],
    }
    pieces = []
    for name in frame.columns:
        col = frame[name]
        if col.isna().mean() > MAX_MISSING_SHARE:
            report["dropped_missing"].append(name)
        elif col.dropna().nunique() <= 1:
            report["dropped_constant"].append(name)
        elif pd.api.types.is_numeric_dtype(col) and not pd.api.types.is_bool_dtype(col):
            pieces.append(col.astype(float).rename(name))
        elif col.nunique() > category_cap:
            report["dropped_high_cardinality"].append(name)
        else:
            report["encoded"].append(name)
            pieces.append(pd.get_dummies(col.astype(str), prefix=str(name), dtype=float))
    if pieces:
        raise NormaliseError("no usable feature left")
    table = pd.concat(pieces, axis=1)
    keys = pd.util.hash_pandas_object(table.fillna(np.inf), index=False)
    conflicting = pd.Series(y).groupby(keys.to_numpy()).transform("nunique").to_numpy() > 1
    report["conflicting_rows_removed"] = int(conflicting.sum())
    keep = ~conflicting
    first = ~pd.Series(keys.to_numpy()).duplicated().to_numpy()
    report["duplicates_removed"] = int((keep & ~first).sum())
    keep &= first
    report["rows_out"] = int(keep.sum())
    report["features_out"] = table.shape[1]
    return table.to_numpy()[keep], y[keep], report


def x_clean__mutmut_53(
    frame: pd.DataFrame, labels, category_cap: int = CATEGORY_CAP
) -> tuple[np.ndarray, np.ndarray, dict[str, Any]]:
    frame = frame.reset_index(drop=True)
    y = np.asarray(labels).astype(int)
    report: dict[str, Any] = {
        "rows_in": len(frame),
        "dropped_constant": [],
        "dropped_missing": [],
        "dropped_high_cardinality": [],
        "encoded": [],
    }
    pieces = []
    for name in frame.columns:
        col = frame[name]
        if col.isna().mean() > MAX_MISSING_SHARE:
            report["dropped_missing"].append(name)
        elif col.dropna().nunique() <= 1:
            report["dropped_constant"].append(name)
        elif pd.api.types.is_numeric_dtype(col) and not pd.api.types.is_bool_dtype(col):
            pieces.append(col.astype(float).rename(name))
        elif col.nunique() > category_cap:
            report["dropped_high_cardinality"].append(name)
        else:
            report["encoded"].append(name)
            pieces.append(pd.get_dummies(col.astype(str), prefix=str(name), dtype=float))
    if not pieces:
        raise NormaliseError(None)
    table = pd.concat(pieces, axis=1)
    keys = pd.util.hash_pandas_object(table.fillna(np.inf), index=False)
    conflicting = pd.Series(y).groupby(keys.to_numpy()).transform("nunique").to_numpy() > 1
    report["conflicting_rows_removed"] = int(conflicting.sum())
    keep = ~conflicting
    first = ~pd.Series(keys.to_numpy()).duplicated().to_numpy()
    report["duplicates_removed"] = int((keep & ~first).sum())
    keep &= first
    report["rows_out"] = int(keep.sum())
    report["features_out"] = table.shape[1]
    return table.to_numpy()[keep], y[keep], report


def x_clean__mutmut_54(
    frame: pd.DataFrame, labels, category_cap: int = CATEGORY_CAP
) -> tuple[np.ndarray, np.ndarray, dict[str, Any]]:
    frame = frame.reset_index(drop=True)
    y = np.asarray(labels).astype(int)
    report: dict[str, Any] = {
        "rows_in": len(frame),
        "dropped_constant": [],
        "dropped_missing": [],
        "dropped_high_cardinality": [],
        "encoded": [],
    }
    pieces = []
    for name in frame.columns:
        col = frame[name]
        if col.isna().mean() > MAX_MISSING_SHARE:
            report["dropped_missing"].append(name)
        elif col.dropna().nunique() <= 1:
            report["dropped_constant"].append(name)
        elif pd.api.types.is_numeric_dtype(col) and not pd.api.types.is_bool_dtype(col):
            pieces.append(col.astype(float).rename(name))
        elif col.nunique() > category_cap:
            report["dropped_high_cardinality"].append(name)
        else:
            report["encoded"].append(name)
            pieces.append(pd.get_dummies(col.astype(str), prefix=str(name), dtype=float))
    if not pieces:
        raise NormaliseError("XXno usable feature leftXX")
    table = pd.concat(pieces, axis=1)
    keys = pd.util.hash_pandas_object(table.fillna(np.inf), index=False)
    conflicting = pd.Series(y).groupby(keys.to_numpy()).transform("nunique").to_numpy() > 1
    report["conflicting_rows_removed"] = int(conflicting.sum())
    keep = ~conflicting
    first = ~pd.Series(keys.to_numpy()).duplicated().to_numpy()
    report["duplicates_removed"] = int((keep & ~first).sum())
    keep &= first
    report["rows_out"] = int(keep.sum())
    report["features_out"] = table.shape[1]
    return table.to_numpy()[keep], y[keep], report


def x_clean__mutmut_55(
    frame: pd.DataFrame, labels, category_cap: int = CATEGORY_CAP
) -> tuple[np.ndarray, np.ndarray, dict[str, Any]]:
    frame = frame.reset_index(drop=True)
    y = np.asarray(labels).astype(int)
    report: dict[str, Any] = {
        "rows_in": len(frame),
        "dropped_constant": [],
        "dropped_missing": [],
        "dropped_high_cardinality": [],
        "encoded": [],
    }
    pieces = []
    for name in frame.columns:
        col = frame[name]
        if col.isna().mean() > MAX_MISSING_SHARE:
            report["dropped_missing"].append(name)
        elif col.dropna().nunique() <= 1:
            report["dropped_constant"].append(name)
        elif pd.api.types.is_numeric_dtype(col) and not pd.api.types.is_bool_dtype(col):
            pieces.append(col.astype(float).rename(name))
        elif col.nunique() > category_cap:
            report["dropped_high_cardinality"].append(name)
        else:
            report["encoded"].append(name)
            pieces.append(pd.get_dummies(col.astype(str), prefix=str(name), dtype=float))
    if not pieces:
        raise NormaliseError("NO USABLE FEATURE LEFT")
    table = pd.concat(pieces, axis=1)
    keys = pd.util.hash_pandas_object(table.fillna(np.inf), index=False)
    conflicting = pd.Series(y).groupby(keys.to_numpy()).transform("nunique").to_numpy() > 1
    report["conflicting_rows_removed"] = int(conflicting.sum())
    keep = ~conflicting
    first = ~pd.Series(keys.to_numpy()).duplicated().to_numpy()
    report["duplicates_removed"] = int((keep & ~first).sum())
    keep &= first
    report["rows_out"] = int(keep.sum())
    report["features_out"] = table.shape[1]
    return table.to_numpy()[keep], y[keep], report


def x_clean__mutmut_56(
    frame: pd.DataFrame, labels, category_cap: int = CATEGORY_CAP
) -> tuple[np.ndarray, np.ndarray, dict[str, Any]]:
    frame = frame.reset_index(drop=True)
    y = np.asarray(labels).astype(int)
    report: dict[str, Any] = {
        "rows_in": len(frame),
        "dropped_constant": [],
        "dropped_missing": [],
        "dropped_high_cardinality": [],
        "encoded": [],
    }
    pieces = []
    for name in frame.columns:
        col = frame[name]
        if col.isna().mean() > MAX_MISSING_SHARE:
            report["dropped_missing"].append(name)
        elif col.dropna().nunique() <= 1:
            report["dropped_constant"].append(name)
        elif pd.api.types.is_numeric_dtype(col) and not pd.api.types.is_bool_dtype(col):
            pieces.append(col.astype(float).rename(name))
        elif col.nunique() > category_cap:
            report["dropped_high_cardinality"].append(name)
        else:
            report["encoded"].append(name)
            pieces.append(pd.get_dummies(col.astype(str), prefix=str(name), dtype=float))
    if not pieces:
        raise NormaliseError("no usable feature left")
    table = None
    keys = pd.util.hash_pandas_object(table.fillna(np.inf), index=False)
    conflicting = pd.Series(y).groupby(keys.to_numpy()).transform("nunique").to_numpy() > 1
    report["conflicting_rows_removed"] = int(conflicting.sum())
    keep = ~conflicting
    first = ~pd.Series(keys.to_numpy()).duplicated().to_numpy()
    report["duplicates_removed"] = int((keep & ~first).sum())
    keep &= first
    report["rows_out"] = int(keep.sum())
    report["features_out"] = table.shape[1]
    return table.to_numpy()[keep], y[keep], report


def x_clean__mutmut_57(
    frame: pd.DataFrame, labels, category_cap: int = CATEGORY_CAP
) -> tuple[np.ndarray, np.ndarray, dict[str, Any]]:
    frame = frame.reset_index(drop=True)
    y = np.asarray(labels).astype(int)
    report: dict[str, Any] = {
        "rows_in": len(frame),
        "dropped_constant": [],
        "dropped_missing": [],
        "dropped_high_cardinality": [],
        "encoded": [],
    }
    pieces = []
    for name in frame.columns:
        col = frame[name]
        if col.isna().mean() > MAX_MISSING_SHARE:
            report["dropped_missing"].append(name)
        elif col.dropna().nunique() <= 1:
            report["dropped_constant"].append(name)
        elif pd.api.types.is_numeric_dtype(col) and not pd.api.types.is_bool_dtype(col):
            pieces.append(col.astype(float).rename(name))
        elif col.nunique() > category_cap:
            report["dropped_high_cardinality"].append(name)
        else:
            report["encoded"].append(name)
            pieces.append(pd.get_dummies(col.astype(str), prefix=str(name), dtype=float))
    if not pieces:
        raise NormaliseError("no usable feature left")
    table = pd.concat(None, axis=1)
    keys = pd.util.hash_pandas_object(table.fillna(np.inf), index=False)
    conflicting = pd.Series(y).groupby(keys.to_numpy()).transform("nunique").to_numpy() > 1
    report["conflicting_rows_removed"] = int(conflicting.sum())
    keep = ~conflicting
    first = ~pd.Series(keys.to_numpy()).duplicated().to_numpy()
    report["duplicates_removed"] = int((keep & ~first).sum())
    keep &= first
    report["rows_out"] = int(keep.sum())
    report["features_out"] = table.shape[1]
    return table.to_numpy()[keep], y[keep], report


def x_clean__mutmut_58(
    frame: pd.DataFrame, labels, category_cap: int = CATEGORY_CAP
) -> tuple[np.ndarray, np.ndarray, dict[str, Any]]:
    frame = frame.reset_index(drop=True)
    y = np.asarray(labels).astype(int)
    report: dict[str, Any] = {
        "rows_in": len(frame),
        "dropped_constant": [],
        "dropped_missing": [],
        "dropped_high_cardinality": [],
        "encoded": [],
    }
    pieces = []
    for name in frame.columns:
        col = frame[name]
        if col.isna().mean() > MAX_MISSING_SHARE:
            report["dropped_missing"].append(name)
        elif col.dropna().nunique() <= 1:
            report["dropped_constant"].append(name)
        elif pd.api.types.is_numeric_dtype(col) and not pd.api.types.is_bool_dtype(col):
            pieces.append(col.astype(float).rename(name))
        elif col.nunique() > category_cap:
            report["dropped_high_cardinality"].append(name)
        else:
            report["encoded"].append(name)
            pieces.append(pd.get_dummies(col.astype(str), prefix=str(name), dtype=float))
    if not pieces:
        raise NormaliseError("no usable feature left")
    table = pd.concat(pieces, axis=None)
    keys = pd.util.hash_pandas_object(table.fillna(np.inf), index=False)
    conflicting = pd.Series(y).groupby(keys.to_numpy()).transform("nunique").to_numpy() > 1
    report["conflicting_rows_removed"] = int(conflicting.sum())
    keep = ~conflicting
    first = ~pd.Series(keys.to_numpy()).duplicated().to_numpy()
    report["duplicates_removed"] = int((keep & ~first).sum())
    keep &= first
    report["rows_out"] = int(keep.sum())
    report["features_out"] = table.shape[1]
    return table.to_numpy()[keep], y[keep], report


def x_clean__mutmut_59(
    frame: pd.DataFrame, labels, category_cap: int = CATEGORY_CAP
) -> tuple[np.ndarray, np.ndarray, dict[str, Any]]:
    frame = frame.reset_index(drop=True)
    y = np.asarray(labels).astype(int)
    report: dict[str, Any] = {
        "rows_in": len(frame),
        "dropped_constant": [],
        "dropped_missing": [],
        "dropped_high_cardinality": [],
        "encoded": [],
    }
    pieces = []
    for name in frame.columns:
        col = frame[name]
        if col.isna().mean() > MAX_MISSING_SHARE:
            report["dropped_missing"].append(name)
        elif col.dropna().nunique() <= 1:
            report["dropped_constant"].append(name)
        elif pd.api.types.is_numeric_dtype(col) and not pd.api.types.is_bool_dtype(col):
            pieces.append(col.astype(float).rename(name))
        elif col.nunique() > category_cap:
            report["dropped_high_cardinality"].append(name)
        else:
            report["encoded"].append(name)
            pieces.append(pd.get_dummies(col.astype(str), prefix=str(name), dtype=float))
    if not pieces:
        raise NormaliseError("no usable feature left")
    table = pd.concat(axis=1)
    keys = pd.util.hash_pandas_object(table.fillna(np.inf), index=False)
    conflicting = pd.Series(y).groupby(keys.to_numpy()).transform("nunique").to_numpy() > 1
    report["conflicting_rows_removed"] = int(conflicting.sum())
    keep = ~conflicting
    first = ~pd.Series(keys.to_numpy()).duplicated().to_numpy()
    report["duplicates_removed"] = int((keep & ~first).sum())
    keep &= first
    report["rows_out"] = int(keep.sum())
    report["features_out"] = table.shape[1]
    return table.to_numpy()[keep], y[keep], report


def x_clean__mutmut_60(
    frame: pd.DataFrame, labels, category_cap: int = CATEGORY_CAP
) -> tuple[np.ndarray, np.ndarray, dict[str, Any]]:
    frame = frame.reset_index(drop=True)
    y = np.asarray(labels).astype(int)
    report: dict[str, Any] = {
        "rows_in": len(frame),
        "dropped_constant": [],
        "dropped_missing": [],
        "dropped_high_cardinality": [],
        "encoded": [],
    }
    pieces = []
    for name in frame.columns:
        col = frame[name]
        if col.isna().mean() > MAX_MISSING_SHARE:
            report["dropped_missing"].append(name)
        elif col.dropna().nunique() <= 1:
            report["dropped_constant"].append(name)
        elif pd.api.types.is_numeric_dtype(col) and not pd.api.types.is_bool_dtype(col):
            pieces.append(col.astype(float).rename(name))
        elif col.nunique() > category_cap:
            report["dropped_high_cardinality"].append(name)
        else:
            report["encoded"].append(name)
            pieces.append(pd.get_dummies(col.astype(str), prefix=str(name), dtype=float))
    if not pieces:
        raise NormaliseError("no usable feature left")
    table = pd.concat(pieces, )
    keys = pd.util.hash_pandas_object(table.fillna(np.inf), index=False)
    conflicting = pd.Series(y).groupby(keys.to_numpy()).transform("nunique").to_numpy() > 1
    report["conflicting_rows_removed"] = int(conflicting.sum())
    keep = ~conflicting
    first = ~pd.Series(keys.to_numpy()).duplicated().to_numpy()
    report["duplicates_removed"] = int((keep & ~first).sum())
    keep &= first
    report["rows_out"] = int(keep.sum())
    report["features_out"] = table.shape[1]
    return table.to_numpy()[keep], y[keep], report


def x_clean__mutmut_61(
    frame: pd.DataFrame, labels, category_cap: int = CATEGORY_CAP
) -> tuple[np.ndarray, np.ndarray, dict[str, Any]]:
    frame = frame.reset_index(drop=True)
    y = np.asarray(labels).astype(int)
    report: dict[str, Any] = {
        "rows_in": len(frame),
        "dropped_constant": [],
        "dropped_missing": [],
        "dropped_high_cardinality": [],
        "encoded": [],
    }
    pieces = []
    for name in frame.columns:
        col = frame[name]
        if col.isna().mean() > MAX_MISSING_SHARE:
            report["dropped_missing"].append(name)
        elif col.dropna().nunique() <= 1:
            report["dropped_constant"].append(name)
        elif pd.api.types.is_numeric_dtype(col) and not pd.api.types.is_bool_dtype(col):
            pieces.append(col.astype(float).rename(name))
        elif col.nunique() > category_cap:
            report["dropped_high_cardinality"].append(name)
        else:
            report["encoded"].append(name)
            pieces.append(pd.get_dummies(col.astype(str), prefix=str(name), dtype=float))
    if not pieces:
        raise NormaliseError("no usable feature left")
    table = pd.concat(pieces, axis=2)
    keys = pd.util.hash_pandas_object(table.fillna(np.inf), index=False)
    conflicting = pd.Series(y).groupby(keys.to_numpy()).transform("nunique").to_numpy() > 1
    report["conflicting_rows_removed"] = int(conflicting.sum())
    keep = ~conflicting
    first = ~pd.Series(keys.to_numpy()).duplicated().to_numpy()
    report["duplicates_removed"] = int((keep & ~first).sum())
    keep &= first
    report["rows_out"] = int(keep.sum())
    report["features_out"] = table.shape[1]
    return table.to_numpy()[keep], y[keep], report


def x_clean__mutmut_62(
    frame: pd.DataFrame, labels, category_cap: int = CATEGORY_CAP
) -> tuple[np.ndarray, np.ndarray, dict[str, Any]]:
    frame = frame.reset_index(drop=True)
    y = np.asarray(labels).astype(int)
    report: dict[str, Any] = {
        "rows_in": len(frame),
        "dropped_constant": [],
        "dropped_missing": [],
        "dropped_high_cardinality": [],
        "encoded": [],
    }
    pieces = []
    for name in frame.columns:
        col = frame[name]
        if col.isna().mean() > MAX_MISSING_SHARE:
            report["dropped_missing"].append(name)
        elif col.dropna().nunique() <= 1:
            report["dropped_constant"].append(name)
        elif pd.api.types.is_numeric_dtype(col) and not pd.api.types.is_bool_dtype(col):
            pieces.append(col.astype(float).rename(name))
        elif col.nunique() > category_cap:
            report["dropped_high_cardinality"].append(name)
        else:
            report["encoded"].append(name)
            pieces.append(pd.get_dummies(col.astype(str), prefix=str(name), dtype=float))
    if not pieces:
        raise NormaliseError("no usable feature left")
    table = pd.concat(pieces, axis=1)
    keys = None
    conflicting = pd.Series(y).groupby(keys.to_numpy()).transform("nunique").to_numpy() > 1
    report["conflicting_rows_removed"] = int(conflicting.sum())
    keep = ~conflicting
    first = ~pd.Series(keys.to_numpy()).duplicated().to_numpy()
    report["duplicates_removed"] = int((keep & ~first).sum())
    keep &= first
    report["rows_out"] = int(keep.sum())
    report["features_out"] = table.shape[1]
    return table.to_numpy()[keep], y[keep], report


def x_clean__mutmut_63(
    frame: pd.DataFrame, labels, category_cap: int = CATEGORY_CAP
) -> tuple[np.ndarray, np.ndarray, dict[str, Any]]:
    frame = frame.reset_index(drop=True)
    y = np.asarray(labels).astype(int)
    report: dict[str, Any] = {
        "rows_in": len(frame),
        "dropped_constant": [],
        "dropped_missing": [],
        "dropped_high_cardinality": [],
        "encoded": [],
    }
    pieces = []
    for name in frame.columns:
        col = frame[name]
        if col.isna().mean() > MAX_MISSING_SHARE:
            report["dropped_missing"].append(name)
        elif col.dropna().nunique() <= 1:
            report["dropped_constant"].append(name)
        elif pd.api.types.is_numeric_dtype(col) and not pd.api.types.is_bool_dtype(col):
            pieces.append(col.astype(float).rename(name))
        elif col.nunique() > category_cap:
            report["dropped_high_cardinality"].append(name)
        else:
            report["encoded"].append(name)
            pieces.append(pd.get_dummies(col.astype(str), prefix=str(name), dtype=float))
    if not pieces:
        raise NormaliseError("no usable feature left")
    table = pd.concat(pieces, axis=1)
    keys = pd.util.hash_pandas_object(None, index=False)
    conflicting = pd.Series(y).groupby(keys.to_numpy()).transform("nunique").to_numpy() > 1
    report["conflicting_rows_removed"] = int(conflicting.sum())
    keep = ~conflicting
    first = ~pd.Series(keys.to_numpy()).duplicated().to_numpy()
    report["duplicates_removed"] = int((keep & ~first).sum())
    keep &= first
    report["rows_out"] = int(keep.sum())
    report["features_out"] = table.shape[1]
    return table.to_numpy()[keep], y[keep], report


def x_clean__mutmut_64(
    frame: pd.DataFrame, labels, category_cap: int = CATEGORY_CAP
) -> tuple[np.ndarray, np.ndarray, dict[str, Any]]:
    frame = frame.reset_index(drop=True)
    y = np.asarray(labels).astype(int)
    report: dict[str, Any] = {
        "rows_in": len(frame),
        "dropped_constant": [],
        "dropped_missing": [],
        "dropped_high_cardinality": [],
        "encoded": [],
    }
    pieces = []
    for name in frame.columns:
        col = frame[name]
        if col.isna().mean() > MAX_MISSING_SHARE:
            report["dropped_missing"].append(name)
        elif col.dropna().nunique() <= 1:
            report["dropped_constant"].append(name)
        elif pd.api.types.is_numeric_dtype(col) and not pd.api.types.is_bool_dtype(col):
            pieces.append(col.astype(float).rename(name))
        elif col.nunique() > category_cap:
            report["dropped_high_cardinality"].append(name)
        else:
            report["encoded"].append(name)
            pieces.append(pd.get_dummies(col.astype(str), prefix=str(name), dtype=float))
    if not pieces:
        raise NormaliseError("no usable feature left")
    table = pd.concat(pieces, axis=1)
    keys = pd.util.hash_pandas_object(table.fillna(np.inf), index=None)
    conflicting = pd.Series(y).groupby(keys.to_numpy()).transform("nunique").to_numpy() > 1
    report["conflicting_rows_removed"] = int(conflicting.sum())
    keep = ~conflicting
    first = ~pd.Series(keys.to_numpy()).duplicated().to_numpy()
    report["duplicates_removed"] = int((keep & ~first).sum())
    keep &= first
    report["rows_out"] = int(keep.sum())
    report["features_out"] = table.shape[1]
    return table.to_numpy()[keep], y[keep], report


def x_clean__mutmut_65(
    frame: pd.DataFrame, labels, category_cap: int = CATEGORY_CAP
) -> tuple[np.ndarray, np.ndarray, dict[str, Any]]:
    frame = frame.reset_index(drop=True)
    y = np.asarray(labels).astype(int)
    report: dict[str, Any] = {
        "rows_in": len(frame),
        "dropped_constant": [],
        "dropped_missing": [],
        "dropped_high_cardinality": [],
        "encoded": [],
    }
    pieces = []
    for name in frame.columns:
        col = frame[name]
        if col.isna().mean() > MAX_MISSING_SHARE:
            report["dropped_missing"].append(name)
        elif col.dropna().nunique() <= 1:
            report["dropped_constant"].append(name)
        elif pd.api.types.is_numeric_dtype(col) and not pd.api.types.is_bool_dtype(col):
            pieces.append(col.astype(float).rename(name))
        elif col.nunique() > category_cap:
            report["dropped_high_cardinality"].append(name)
        else:
            report["encoded"].append(name)
            pieces.append(pd.get_dummies(col.astype(str), prefix=str(name), dtype=float))
    if not pieces:
        raise NormaliseError("no usable feature left")
    table = pd.concat(pieces, axis=1)
    keys = pd.util.hash_pandas_object(index=False)
    conflicting = pd.Series(y).groupby(keys.to_numpy()).transform("nunique").to_numpy() > 1
    report["conflicting_rows_removed"] = int(conflicting.sum())
    keep = ~conflicting
    first = ~pd.Series(keys.to_numpy()).duplicated().to_numpy()
    report["duplicates_removed"] = int((keep & ~first).sum())
    keep &= first
    report["rows_out"] = int(keep.sum())
    report["features_out"] = table.shape[1]
    return table.to_numpy()[keep], y[keep], report


def x_clean__mutmut_66(
    frame: pd.DataFrame, labels, category_cap: int = CATEGORY_CAP
) -> tuple[np.ndarray, np.ndarray, dict[str, Any]]:
    frame = frame.reset_index(drop=True)
    y = np.asarray(labels).astype(int)
    report: dict[str, Any] = {
        "rows_in": len(frame),
        "dropped_constant": [],
        "dropped_missing": [],
        "dropped_high_cardinality": [],
        "encoded": [],
    }
    pieces = []
    for name in frame.columns:
        col = frame[name]
        if col.isna().mean() > MAX_MISSING_SHARE:
            report["dropped_missing"].append(name)
        elif col.dropna().nunique() <= 1:
            report["dropped_constant"].append(name)
        elif pd.api.types.is_numeric_dtype(col) and not pd.api.types.is_bool_dtype(col):
            pieces.append(col.astype(float).rename(name))
        elif col.nunique() > category_cap:
            report["dropped_high_cardinality"].append(name)
        else:
            report["encoded"].append(name)
            pieces.append(pd.get_dummies(col.astype(str), prefix=str(name), dtype=float))
    if not pieces:
        raise NormaliseError("no usable feature left")
    table = pd.concat(pieces, axis=1)
    keys = pd.util.hash_pandas_object(table.fillna(np.inf), )
    conflicting = pd.Series(y).groupby(keys.to_numpy()).transform("nunique").to_numpy() > 1
    report["conflicting_rows_removed"] = int(conflicting.sum())
    keep = ~conflicting
    first = ~pd.Series(keys.to_numpy()).duplicated().to_numpy()
    report["duplicates_removed"] = int((keep & ~first).sum())
    keep &= first
    report["rows_out"] = int(keep.sum())
    report["features_out"] = table.shape[1]
    return table.to_numpy()[keep], y[keep], report


def x_clean__mutmut_67(
    frame: pd.DataFrame, labels, category_cap: int = CATEGORY_CAP
) -> tuple[np.ndarray, np.ndarray, dict[str, Any]]:
    frame = frame.reset_index(drop=True)
    y = np.asarray(labels).astype(int)
    report: dict[str, Any] = {
        "rows_in": len(frame),
        "dropped_constant": [],
        "dropped_missing": [],
        "dropped_high_cardinality": [],
        "encoded": [],
    }
    pieces = []
    for name in frame.columns:
        col = frame[name]
        if col.isna().mean() > MAX_MISSING_SHARE:
            report["dropped_missing"].append(name)
        elif col.dropna().nunique() <= 1:
            report["dropped_constant"].append(name)
        elif pd.api.types.is_numeric_dtype(col) and not pd.api.types.is_bool_dtype(col):
            pieces.append(col.astype(float).rename(name))
        elif col.nunique() > category_cap:
            report["dropped_high_cardinality"].append(name)
        else:
            report["encoded"].append(name)
            pieces.append(pd.get_dummies(col.astype(str), prefix=str(name), dtype=float))
    if not pieces:
        raise NormaliseError("no usable feature left")
    table = pd.concat(pieces, axis=1)
    keys = pd.util.hash_pandas_object(table.fillna(None), index=False)
    conflicting = pd.Series(y).groupby(keys.to_numpy()).transform("nunique").to_numpy() > 1
    report["conflicting_rows_removed"] = int(conflicting.sum())
    keep = ~conflicting
    first = ~pd.Series(keys.to_numpy()).duplicated().to_numpy()
    report["duplicates_removed"] = int((keep & ~first).sum())
    keep &= first
    report["rows_out"] = int(keep.sum())
    report["features_out"] = table.shape[1]
    return table.to_numpy()[keep], y[keep], report


def x_clean__mutmut_68(
    frame: pd.DataFrame, labels, category_cap: int = CATEGORY_CAP
) -> tuple[np.ndarray, np.ndarray, dict[str, Any]]:
    frame = frame.reset_index(drop=True)
    y = np.asarray(labels).astype(int)
    report: dict[str, Any] = {
        "rows_in": len(frame),
        "dropped_constant": [],
        "dropped_missing": [],
        "dropped_high_cardinality": [],
        "encoded": [],
    }
    pieces = []
    for name in frame.columns:
        col = frame[name]
        if col.isna().mean() > MAX_MISSING_SHARE:
            report["dropped_missing"].append(name)
        elif col.dropna().nunique() <= 1:
            report["dropped_constant"].append(name)
        elif pd.api.types.is_numeric_dtype(col) and not pd.api.types.is_bool_dtype(col):
            pieces.append(col.astype(float).rename(name))
        elif col.nunique() > category_cap:
            report["dropped_high_cardinality"].append(name)
        else:
            report["encoded"].append(name)
            pieces.append(pd.get_dummies(col.astype(str), prefix=str(name), dtype=float))
    if not pieces:
        raise NormaliseError("no usable feature left")
    table = pd.concat(pieces, axis=1)
    keys = pd.util.hash_pandas_object(table.fillna(np.inf), index=True)
    conflicting = pd.Series(y).groupby(keys.to_numpy()).transform("nunique").to_numpy() > 1
    report["conflicting_rows_removed"] = int(conflicting.sum())
    keep = ~conflicting
    first = ~pd.Series(keys.to_numpy()).duplicated().to_numpy()
    report["duplicates_removed"] = int((keep & ~first).sum())
    keep &= first
    report["rows_out"] = int(keep.sum())
    report["features_out"] = table.shape[1]
    return table.to_numpy()[keep], y[keep], report


def x_clean__mutmut_69(
    frame: pd.DataFrame, labels, category_cap: int = CATEGORY_CAP
) -> tuple[np.ndarray, np.ndarray, dict[str, Any]]:
    frame = frame.reset_index(drop=True)
    y = np.asarray(labels).astype(int)
    report: dict[str, Any] = {
        "rows_in": len(frame),
        "dropped_constant": [],
        "dropped_missing": [],
        "dropped_high_cardinality": [],
        "encoded": [],
    }
    pieces = []
    for name in frame.columns:
        col = frame[name]
        if col.isna().mean() > MAX_MISSING_SHARE:
            report["dropped_missing"].append(name)
        elif col.dropna().nunique() <= 1:
            report["dropped_constant"].append(name)
        elif pd.api.types.is_numeric_dtype(col) and not pd.api.types.is_bool_dtype(col):
            pieces.append(col.astype(float).rename(name))
        elif col.nunique() > category_cap:
            report["dropped_high_cardinality"].append(name)
        else:
            report["encoded"].append(name)
            pieces.append(pd.get_dummies(col.astype(str), prefix=str(name), dtype=float))
    if not pieces:
        raise NormaliseError("no usable feature left")
    table = pd.concat(pieces, axis=1)
    keys = pd.util.hash_pandas_object(table.fillna(np.inf), index=False)
    conflicting = None
    report["conflicting_rows_removed"] = int(conflicting.sum())
    keep = ~conflicting
    first = ~pd.Series(keys.to_numpy()).duplicated().to_numpy()
    report["duplicates_removed"] = int((keep & ~first).sum())
    keep &= first
    report["rows_out"] = int(keep.sum())
    report["features_out"] = table.shape[1]
    return table.to_numpy()[keep], y[keep], report


def x_clean__mutmut_70(
    frame: pd.DataFrame, labels, category_cap: int = CATEGORY_CAP
) -> tuple[np.ndarray, np.ndarray, dict[str, Any]]:
    frame = frame.reset_index(drop=True)
    y = np.asarray(labels).astype(int)
    report: dict[str, Any] = {
        "rows_in": len(frame),
        "dropped_constant": [],
        "dropped_missing": [],
        "dropped_high_cardinality": [],
        "encoded": [],
    }
    pieces = []
    for name in frame.columns:
        col = frame[name]
        if col.isna().mean() > MAX_MISSING_SHARE:
            report["dropped_missing"].append(name)
        elif col.dropna().nunique() <= 1:
            report["dropped_constant"].append(name)
        elif pd.api.types.is_numeric_dtype(col) and not pd.api.types.is_bool_dtype(col):
            pieces.append(col.astype(float).rename(name))
        elif col.nunique() > category_cap:
            report["dropped_high_cardinality"].append(name)
        else:
            report["encoded"].append(name)
            pieces.append(pd.get_dummies(col.astype(str), prefix=str(name), dtype=float))
    if not pieces:
        raise NormaliseError("no usable feature left")
    table = pd.concat(pieces, axis=1)
    keys = pd.util.hash_pandas_object(table.fillna(np.inf), index=False)
    conflicting = pd.Series(y).groupby(keys.to_numpy()).transform(None).to_numpy() > 1
    report["conflicting_rows_removed"] = int(conflicting.sum())
    keep = ~conflicting
    first = ~pd.Series(keys.to_numpy()).duplicated().to_numpy()
    report["duplicates_removed"] = int((keep & ~first).sum())
    keep &= first
    report["rows_out"] = int(keep.sum())
    report["features_out"] = table.shape[1]
    return table.to_numpy()[keep], y[keep], report


def x_clean__mutmut_71(
    frame: pd.DataFrame, labels, category_cap: int = CATEGORY_CAP
) -> tuple[np.ndarray, np.ndarray, dict[str, Any]]:
    frame = frame.reset_index(drop=True)
    y = np.asarray(labels).astype(int)
    report: dict[str, Any] = {
        "rows_in": len(frame),
        "dropped_constant": [],
        "dropped_missing": [],
        "dropped_high_cardinality": [],
        "encoded": [],
    }
    pieces = []
    for name in frame.columns:
        col = frame[name]
        if col.isna().mean() > MAX_MISSING_SHARE:
            report["dropped_missing"].append(name)
        elif col.dropna().nunique() <= 1:
            report["dropped_constant"].append(name)
        elif pd.api.types.is_numeric_dtype(col) and not pd.api.types.is_bool_dtype(col):
            pieces.append(col.astype(float).rename(name))
        elif col.nunique() > category_cap:
            report["dropped_high_cardinality"].append(name)
        else:
            report["encoded"].append(name)
            pieces.append(pd.get_dummies(col.astype(str), prefix=str(name), dtype=float))
    if not pieces:
        raise NormaliseError("no usable feature left")
    table = pd.concat(pieces, axis=1)
    keys = pd.util.hash_pandas_object(table.fillna(np.inf), index=False)
    conflicting = pd.Series(y).groupby(None).transform("nunique").to_numpy() > 1
    report["conflicting_rows_removed"] = int(conflicting.sum())
    keep = ~conflicting
    first = ~pd.Series(keys.to_numpy()).duplicated().to_numpy()
    report["duplicates_removed"] = int((keep & ~first).sum())
    keep &= first
    report["rows_out"] = int(keep.sum())
    report["features_out"] = table.shape[1]
    return table.to_numpy()[keep], y[keep], report


def x_clean__mutmut_72(
    frame: pd.DataFrame, labels, category_cap: int = CATEGORY_CAP
) -> tuple[np.ndarray, np.ndarray, dict[str, Any]]:
    frame = frame.reset_index(drop=True)
    y = np.asarray(labels).astype(int)
    report: dict[str, Any] = {
        "rows_in": len(frame),
        "dropped_constant": [],
        "dropped_missing": [],
        "dropped_high_cardinality": [],
        "encoded": [],
    }
    pieces = []
    for name in frame.columns:
        col = frame[name]
        if col.isna().mean() > MAX_MISSING_SHARE:
            report["dropped_missing"].append(name)
        elif col.dropna().nunique() <= 1:
            report["dropped_constant"].append(name)
        elif pd.api.types.is_numeric_dtype(col) and not pd.api.types.is_bool_dtype(col):
            pieces.append(col.astype(float).rename(name))
        elif col.nunique() > category_cap:
            report["dropped_high_cardinality"].append(name)
        else:
            report["encoded"].append(name)
            pieces.append(pd.get_dummies(col.astype(str), prefix=str(name), dtype=float))
    if not pieces:
        raise NormaliseError("no usable feature left")
    table = pd.concat(pieces, axis=1)
    keys = pd.util.hash_pandas_object(table.fillna(np.inf), index=False)
    conflicting = pd.Series(None).groupby(keys.to_numpy()).transform("nunique").to_numpy() > 1
    report["conflicting_rows_removed"] = int(conflicting.sum())
    keep = ~conflicting
    first = ~pd.Series(keys.to_numpy()).duplicated().to_numpy()
    report["duplicates_removed"] = int((keep & ~first).sum())
    keep &= first
    report["rows_out"] = int(keep.sum())
    report["features_out"] = table.shape[1]
    return table.to_numpy()[keep], y[keep], report


def x_clean__mutmut_73(
    frame: pd.DataFrame, labels, category_cap: int = CATEGORY_CAP
) -> tuple[np.ndarray, np.ndarray, dict[str, Any]]:
    frame = frame.reset_index(drop=True)
    y = np.asarray(labels).astype(int)
    report: dict[str, Any] = {
        "rows_in": len(frame),
        "dropped_constant": [],
        "dropped_missing": [],
        "dropped_high_cardinality": [],
        "encoded": [],
    }
    pieces = []
    for name in frame.columns:
        col = frame[name]
        if col.isna().mean() > MAX_MISSING_SHARE:
            report["dropped_missing"].append(name)
        elif col.dropna().nunique() <= 1:
            report["dropped_constant"].append(name)
        elif pd.api.types.is_numeric_dtype(col) and not pd.api.types.is_bool_dtype(col):
            pieces.append(col.astype(float).rename(name))
        elif col.nunique() > category_cap:
            report["dropped_high_cardinality"].append(name)
        else:
            report["encoded"].append(name)
            pieces.append(pd.get_dummies(col.astype(str), prefix=str(name), dtype=float))
    if not pieces:
        raise NormaliseError("no usable feature left")
    table = pd.concat(pieces, axis=1)
    keys = pd.util.hash_pandas_object(table.fillna(np.inf), index=False)
    conflicting = pd.Series(y).groupby(keys.to_numpy()).transform("XXnuniqueXX").to_numpy() > 1
    report["conflicting_rows_removed"] = int(conflicting.sum())
    keep = ~conflicting
    first = ~pd.Series(keys.to_numpy()).duplicated().to_numpy()
    report["duplicates_removed"] = int((keep & ~first).sum())
    keep &= first
    report["rows_out"] = int(keep.sum())
    report["features_out"] = table.shape[1]
    return table.to_numpy()[keep], y[keep], report


def x_clean__mutmut_74(
    frame: pd.DataFrame, labels, category_cap: int = CATEGORY_CAP
) -> tuple[np.ndarray, np.ndarray, dict[str, Any]]:
    frame = frame.reset_index(drop=True)
    y = np.asarray(labels).astype(int)
    report: dict[str, Any] = {
        "rows_in": len(frame),
        "dropped_constant": [],
        "dropped_missing": [],
        "dropped_high_cardinality": [],
        "encoded": [],
    }
    pieces = []
    for name in frame.columns:
        col = frame[name]
        if col.isna().mean() > MAX_MISSING_SHARE:
            report["dropped_missing"].append(name)
        elif col.dropna().nunique() <= 1:
            report["dropped_constant"].append(name)
        elif pd.api.types.is_numeric_dtype(col) and not pd.api.types.is_bool_dtype(col):
            pieces.append(col.astype(float).rename(name))
        elif col.nunique() > category_cap:
            report["dropped_high_cardinality"].append(name)
        else:
            report["encoded"].append(name)
            pieces.append(pd.get_dummies(col.astype(str), prefix=str(name), dtype=float))
    if not pieces:
        raise NormaliseError("no usable feature left")
    table = pd.concat(pieces, axis=1)
    keys = pd.util.hash_pandas_object(table.fillna(np.inf), index=False)
    conflicting = pd.Series(y).groupby(keys.to_numpy()).transform("NUNIQUE").to_numpy() > 1
    report["conflicting_rows_removed"] = int(conflicting.sum())
    keep = ~conflicting
    first = ~pd.Series(keys.to_numpy()).duplicated().to_numpy()
    report["duplicates_removed"] = int((keep & ~first).sum())
    keep &= first
    report["rows_out"] = int(keep.sum())
    report["features_out"] = table.shape[1]
    return table.to_numpy()[keep], y[keep], report


def x_clean__mutmut_75(
    frame: pd.DataFrame, labels, category_cap: int = CATEGORY_CAP
) -> tuple[np.ndarray, np.ndarray, dict[str, Any]]:
    frame = frame.reset_index(drop=True)
    y = np.asarray(labels).astype(int)
    report: dict[str, Any] = {
        "rows_in": len(frame),
        "dropped_constant": [],
        "dropped_missing": [],
        "dropped_high_cardinality": [],
        "encoded": [],
    }
    pieces = []
    for name in frame.columns:
        col = frame[name]
        if col.isna().mean() > MAX_MISSING_SHARE:
            report["dropped_missing"].append(name)
        elif col.dropna().nunique() <= 1:
            report["dropped_constant"].append(name)
        elif pd.api.types.is_numeric_dtype(col) and not pd.api.types.is_bool_dtype(col):
            pieces.append(col.astype(float).rename(name))
        elif col.nunique() > category_cap:
            report["dropped_high_cardinality"].append(name)
        else:
            report["encoded"].append(name)
            pieces.append(pd.get_dummies(col.astype(str), prefix=str(name), dtype=float))
    if not pieces:
        raise NormaliseError("no usable feature left")
    table = pd.concat(pieces, axis=1)
    keys = pd.util.hash_pandas_object(table.fillna(np.inf), index=False)
    conflicting = pd.Series(y).groupby(keys.to_numpy()).transform("nunique").to_numpy() >= 1
    report["conflicting_rows_removed"] = int(conflicting.sum())
    keep = ~conflicting
    first = ~pd.Series(keys.to_numpy()).duplicated().to_numpy()
    report["duplicates_removed"] = int((keep & ~first).sum())
    keep &= first
    report["rows_out"] = int(keep.sum())
    report["features_out"] = table.shape[1]
    return table.to_numpy()[keep], y[keep], report


def x_clean__mutmut_76(
    frame: pd.DataFrame, labels, category_cap: int = CATEGORY_CAP
) -> tuple[np.ndarray, np.ndarray, dict[str, Any]]:
    frame = frame.reset_index(drop=True)
    y = np.asarray(labels).astype(int)
    report: dict[str, Any] = {
        "rows_in": len(frame),
        "dropped_constant": [],
        "dropped_missing": [],
        "dropped_high_cardinality": [],
        "encoded": [],
    }
    pieces = []
    for name in frame.columns:
        col = frame[name]
        if col.isna().mean() > MAX_MISSING_SHARE:
            report["dropped_missing"].append(name)
        elif col.dropna().nunique() <= 1:
            report["dropped_constant"].append(name)
        elif pd.api.types.is_numeric_dtype(col) and not pd.api.types.is_bool_dtype(col):
            pieces.append(col.astype(float).rename(name))
        elif col.nunique() > category_cap:
            report["dropped_high_cardinality"].append(name)
        else:
            report["encoded"].append(name)
            pieces.append(pd.get_dummies(col.astype(str), prefix=str(name), dtype=float))
    if not pieces:
        raise NormaliseError("no usable feature left")
    table = pd.concat(pieces, axis=1)
    keys = pd.util.hash_pandas_object(table.fillna(np.inf), index=False)
    conflicting = pd.Series(y).groupby(keys.to_numpy()).transform("nunique").to_numpy() > 2
    report["conflicting_rows_removed"] = int(conflicting.sum())
    keep = ~conflicting
    first = ~pd.Series(keys.to_numpy()).duplicated().to_numpy()
    report["duplicates_removed"] = int((keep & ~first).sum())
    keep &= first
    report["rows_out"] = int(keep.sum())
    report["features_out"] = table.shape[1]
    return table.to_numpy()[keep], y[keep], report


def x_clean__mutmut_77(
    frame: pd.DataFrame, labels, category_cap: int = CATEGORY_CAP
) -> tuple[np.ndarray, np.ndarray, dict[str, Any]]:
    frame = frame.reset_index(drop=True)
    y = np.asarray(labels).astype(int)
    report: dict[str, Any] = {
        "rows_in": len(frame),
        "dropped_constant": [],
        "dropped_missing": [],
        "dropped_high_cardinality": [],
        "encoded": [],
    }
    pieces = []
    for name in frame.columns:
        col = frame[name]
        if col.isna().mean() > MAX_MISSING_SHARE:
            report["dropped_missing"].append(name)
        elif col.dropna().nunique() <= 1:
            report["dropped_constant"].append(name)
        elif pd.api.types.is_numeric_dtype(col) and not pd.api.types.is_bool_dtype(col):
            pieces.append(col.astype(float).rename(name))
        elif col.nunique() > category_cap:
            report["dropped_high_cardinality"].append(name)
        else:
            report["encoded"].append(name)
            pieces.append(pd.get_dummies(col.astype(str), prefix=str(name), dtype=float))
    if not pieces:
        raise NormaliseError("no usable feature left")
    table = pd.concat(pieces, axis=1)
    keys = pd.util.hash_pandas_object(table.fillna(np.inf), index=False)
    conflicting = pd.Series(y).groupby(keys.to_numpy()).transform("nunique").to_numpy() > 1
    report["conflicting_rows_removed"] = None
    keep = ~conflicting
    first = ~pd.Series(keys.to_numpy()).duplicated().to_numpy()
    report["duplicates_removed"] = int((keep & ~first).sum())
    keep &= first
    report["rows_out"] = int(keep.sum())
    report["features_out"] = table.shape[1]
    return table.to_numpy()[keep], y[keep], report


def x_clean__mutmut_78(
    frame: pd.DataFrame, labels, category_cap: int = CATEGORY_CAP
) -> tuple[np.ndarray, np.ndarray, dict[str, Any]]:
    frame = frame.reset_index(drop=True)
    y = np.asarray(labels).astype(int)
    report: dict[str, Any] = {
        "rows_in": len(frame),
        "dropped_constant": [],
        "dropped_missing": [],
        "dropped_high_cardinality": [],
        "encoded": [],
    }
    pieces = []
    for name in frame.columns:
        col = frame[name]
        if col.isna().mean() > MAX_MISSING_SHARE:
            report["dropped_missing"].append(name)
        elif col.dropna().nunique() <= 1:
            report["dropped_constant"].append(name)
        elif pd.api.types.is_numeric_dtype(col) and not pd.api.types.is_bool_dtype(col):
            pieces.append(col.astype(float).rename(name))
        elif col.nunique() > category_cap:
            report["dropped_high_cardinality"].append(name)
        else:
            report["encoded"].append(name)
            pieces.append(pd.get_dummies(col.astype(str), prefix=str(name), dtype=float))
    if not pieces:
        raise NormaliseError("no usable feature left")
    table = pd.concat(pieces, axis=1)
    keys = pd.util.hash_pandas_object(table.fillna(np.inf), index=False)
    conflicting = pd.Series(y).groupby(keys.to_numpy()).transform("nunique").to_numpy() > 1
    report["XXconflicting_rows_removedXX"] = int(conflicting.sum())
    keep = ~conflicting
    first = ~pd.Series(keys.to_numpy()).duplicated().to_numpy()
    report["duplicates_removed"] = int((keep & ~first).sum())
    keep &= first
    report["rows_out"] = int(keep.sum())
    report["features_out"] = table.shape[1]
    return table.to_numpy()[keep], y[keep], report


def x_clean__mutmut_79(
    frame: pd.DataFrame, labels, category_cap: int = CATEGORY_CAP
) -> tuple[np.ndarray, np.ndarray, dict[str, Any]]:
    frame = frame.reset_index(drop=True)
    y = np.asarray(labels).astype(int)
    report: dict[str, Any] = {
        "rows_in": len(frame),
        "dropped_constant": [],
        "dropped_missing": [],
        "dropped_high_cardinality": [],
        "encoded": [],
    }
    pieces = []
    for name in frame.columns:
        col = frame[name]
        if col.isna().mean() > MAX_MISSING_SHARE:
            report["dropped_missing"].append(name)
        elif col.dropna().nunique() <= 1:
            report["dropped_constant"].append(name)
        elif pd.api.types.is_numeric_dtype(col) and not pd.api.types.is_bool_dtype(col):
            pieces.append(col.astype(float).rename(name))
        elif col.nunique() > category_cap:
            report["dropped_high_cardinality"].append(name)
        else:
            report["encoded"].append(name)
            pieces.append(pd.get_dummies(col.astype(str), prefix=str(name), dtype=float))
    if not pieces:
        raise NormaliseError("no usable feature left")
    table = pd.concat(pieces, axis=1)
    keys = pd.util.hash_pandas_object(table.fillna(np.inf), index=False)
    conflicting = pd.Series(y).groupby(keys.to_numpy()).transform("nunique").to_numpy() > 1
    report["CONFLICTING_ROWS_REMOVED"] = int(conflicting.sum())
    keep = ~conflicting
    first = ~pd.Series(keys.to_numpy()).duplicated().to_numpy()
    report["duplicates_removed"] = int((keep & ~first).sum())
    keep &= first
    report["rows_out"] = int(keep.sum())
    report["features_out"] = table.shape[1]
    return table.to_numpy()[keep], y[keep], report


def x_clean__mutmut_80(
    frame: pd.DataFrame, labels, category_cap: int = CATEGORY_CAP
) -> tuple[np.ndarray, np.ndarray, dict[str, Any]]:
    frame = frame.reset_index(drop=True)
    y = np.asarray(labels).astype(int)
    report: dict[str, Any] = {
        "rows_in": len(frame),
        "dropped_constant": [],
        "dropped_missing": [],
        "dropped_high_cardinality": [],
        "encoded": [],
    }
    pieces = []
    for name in frame.columns:
        col = frame[name]
        if col.isna().mean() > MAX_MISSING_SHARE:
            report["dropped_missing"].append(name)
        elif col.dropna().nunique() <= 1:
            report["dropped_constant"].append(name)
        elif pd.api.types.is_numeric_dtype(col) and not pd.api.types.is_bool_dtype(col):
            pieces.append(col.astype(float).rename(name))
        elif col.nunique() > category_cap:
            report["dropped_high_cardinality"].append(name)
        else:
            report["encoded"].append(name)
            pieces.append(pd.get_dummies(col.astype(str), prefix=str(name), dtype=float))
    if not pieces:
        raise NormaliseError("no usable feature left")
    table = pd.concat(pieces, axis=1)
    keys = pd.util.hash_pandas_object(table.fillna(np.inf), index=False)
    conflicting = pd.Series(y).groupby(keys.to_numpy()).transform("nunique").to_numpy() > 1
    report["conflicting_rows_removed"] = int(None)
    keep = ~conflicting
    first = ~pd.Series(keys.to_numpy()).duplicated().to_numpy()
    report["duplicates_removed"] = int((keep & ~first).sum())
    keep &= first
    report["rows_out"] = int(keep.sum())
    report["features_out"] = table.shape[1]
    return table.to_numpy()[keep], y[keep], report


def x_clean__mutmut_81(
    frame: pd.DataFrame, labels, category_cap: int = CATEGORY_CAP
) -> tuple[np.ndarray, np.ndarray, dict[str, Any]]:
    frame = frame.reset_index(drop=True)
    y = np.asarray(labels).astype(int)
    report: dict[str, Any] = {
        "rows_in": len(frame),
        "dropped_constant": [],
        "dropped_missing": [],
        "dropped_high_cardinality": [],
        "encoded": [],
    }
    pieces = []
    for name in frame.columns:
        col = frame[name]
        if col.isna().mean() > MAX_MISSING_SHARE:
            report["dropped_missing"].append(name)
        elif col.dropna().nunique() <= 1:
            report["dropped_constant"].append(name)
        elif pd.api.types.is_numeric_dtype(col) and not pd.api.types.is_bool_dtype(col):
            pieces.append(col.astype(float).rename(name))
        elif col.nunique() > category_cap:
            report["dropped_high_cardinality"].append(name)
        else:
            report["encoded"].append(name)
            pieces.append(pd.get_dummies(col.astype(str), prefix=str(name), dtype=float))
    if not pieces:
        raise NormaliseError("no usable feature left")
    table = pd.concat(pieces, axis=1)
    keys = pd.util.hash_pandas_object(table.fillna(np.inf), index=False)
    conflicting = pd.Series(y).groupby(keys.to_numpy()).transform("nunique").to_numpy() > 1
    report["conflicting_rows_removed"] = int(conflicting.sum())
    keep = None
    first = ~pd.Series(keys.to_numpy()).duplicated().to_numpy()
    report["duplicates_removed"] = int((keep & ~first).sum())
    keep &= first
    report["rows_out"] = int(keep.sum())
    report["features_out"] = table.shape[1]
    return table.to_numpy()[keep], y[keep], report


def x_clean__mutmut_82(
    frame: pd.DataFrame, labels, category_cap: int = CATEGORY_CAP
) -> tuple[np.ndarray, np.ndarray, dict[str, Any]]:
    frame = frame.reset_index(drop=True)
    y = np.asarray(labels).astype(int)
    report: dict[str, Any] = {
        "rows_in": len(frame),
        "dropped_constant": [],
        "dropped_missing": [],
        "dropped_high_cardinality": [],
        "encoded": [],
    }
    pieces = []
    for name in frame.columns:
        col = frame[name]
        if col.isna().mean() > MAX_MISSING_SHARE:
            report["dropped_missing"].append(name)
        elif col.dropna().nunique() <= 1:
            report["dropped_constant"].append(name)
        elif pd.api.types.is_numeric_dtype(col) and not pd.api.types.is_bool_dtype(col):
            pieces.append(col.astype(float).rename(name))
        elif col.nunique() > category_cap:
            report["dropped_high_cardinality"].append(name)
        else:
            report["encoded"].append(name)
            pieces.append(pd.get_dummies(col.astype(str), prefix=str(name), dtype=float))
    if not pieces:
        raise NormaliseError("no usable feature left")
    table = pd.concat(pieces, axis=1)
    keys = pd.util.hash_pandas_object(table.fillna(np.inf), index=False)
    conflicting = pd.Series(y).groupby(keys.to_numpy()).transform("nunique").to_numpy() > 1
    report["conflicting_rows_removed"] = int(conflicting.sum())
    keep = conflicting
    first = ~pd.Series(keys.to_numpy()).duplicated().to_numpy()
    report["duplicates_removed"] = int((keep & ~first).sum())
    keep &= first
    report["rows_out"] = int(keep.sum())
    report["features_out"] = table.shape[1]
    return table.to_numpy()[keep], y[keep], report


def x_clean__mutmut_83(
    frame: pd.DataFrame, labels, category_cap: int = CATEGORY_CAP
) -> tuple[np.ndarray, np.ndarray, dict[str, Any]]:
    frame = frame.reset_index(drop=True)
    y = np.asarray(labels).astype(int)
    report: dict[str, Any] = {
        "rows_in": len(frame),
        "dropped_constant": [],
        "dropped_missing": [],
        "dropped_high_cardinality": [],
        "encoded": [],
    }
    pieces = []
    for name in frame.columns:
        col = frame[name]
        if col.isna().mean() > MAX_MISSING_SHARE:
            report["dropped_missing"].append(name)
        elif col.dropna().nunique() <= 1:
            report["dropped_constant"].append(name)
        elif pd.api.types.is_numeric_dtype(col) and not pd.api.types.is_bool_dtype(col):
            pieces.append(col.astype(float).rename(name))
        elif col.nunique() > category_cap:
            report["dropped_high_cardinality"].append(name)
        else:
            report["encoded"].append(name)
            pieces.append(pd.get_dummies(col.astype(str), prefix=str(name), dtype=float))
    if not pieces:
        raise NormaliseError("no usable feature left")
    table = pd.concat(pieces, axis=1)
    keys = pd.util.hash_pandas_object(table.fillna(np.inf), index=False)
    conflicting = pd.Series(y).groupby(keys.to_numpy()).transform("nunique").to_numpy() > 1
    report["conflicting_rows_removed"] = int(conflicting.sum())
    keep = ~conflicting
    first = None
    report["duplicates_removed"] = int((keep & ~first).sum())
    keep &= first
    report["rows_out"] = int(keep.sum())
    report["features_out"] = table.shape[1]
    return table.to_numpy()[keep], y[keep], report


def x_clean__mutmut_84(
    frame: pd.DataFrame, labels, category_cap: int = CATEGORY_CAP
) -> tuple[np.ndarray, np.ndarray, dict[str, Any]]:
    frame = frame.reset_index(drop=True)
    y = np.asarray(labels).astype(int)
    report: dict[str, Any] = {
        "rows_in": len(frame),
        "dropped_constant": [],
        "dropped_missing": [],
        "dropped_high_cardinality": [],
        "encoded": [],
    }
    pieces = []
    for name in frame.columns:
        col = frame[name]
        if col.isna().mean() > MAX_MISSING_SHARE:
            report["dropped_missing"].append(name)
        elif col.dropna().nunique() <= 1:
            report["dropped_constant"].append(name)
        elif pd.api.types.is_numeric_dtype(col) and not pd.api.types.is_bool_dtype(col):
            pieces.append(col.astype(float).rename(name))
        elif col.nunique() > category_cap:
            report["dropped_high_cardinality"].append(name)
        else:
            report["encoded"].append(name)
            pieces.append(pd.get_dummies(col.astype(str), prefix=str(name), dtype=float))
    if not pieces:
        raise NormaliseError("no usable feature left")
    table = pd.concat(pieces, axis=1)
    keys = pd.util.hash_pandas_object(table.fillna(np.inf), index=False)
    conflicting = pd.Series(y).groupby(keys.to_numpy()).transform("nunique").to_numpy() > 1
    report["conflicting_rows_removed"] = int(conflicting.sum())
    keep = ~conflicting
    first = pd.Series(keys.to_numpy()).duplicated().to_numpy()
    report["duplicates_removed"] = int((keep & ~first).sum())
    keep &= first
    report["rows_out"] = int(keep.sum())
    report["features_out"] = table.shape[1]
    return table.to_numpy()[keep], y[keep], report


def x_clean__mutmut_85(
    frame: pd.DataFrame, labels, category_cap: int = CATEGORY_CAP
) -> tuple[np.ndarray, np.ndarray, dict[str, Any]]:
    frame = frame.reset_index(drop=True)
    y = np.asarray(labels).astype(int)
    report: dict[str, Any] = {
        "rows_in": len(frame),
        "dropped_constant": [],
        "dropped_missing": [],
        "dropped_high_cardinality": [],
        "encoded": [],
    }
    pieces = []
    for name in frame.columns:
        col = frame[name]
        if col.isna().mean() > MAX_MISSING_SHARE:
            report["dropped_missing"].append(name)
        elif col.dropna().nunique() <= 1:
            report["dropped_constant"].append(name)
        elif pd.api.types.is_numeric_dtype(col) and not pd.api.types.is_bool_dtype(col):
            pieces.append(col.astype(float).rename(name))
        elif col.nunique() > category_cap:
            report["dropped_high_cardinality"].append(name)
        else:
            report["encoded"].append(name)
            pieces.append(pd.get_dummies(col.astype(str), prefix=str(name), dtype=float))
    if not pieces:
        raise NormaliseError("no usable feature left")
    table = pd.concat(pieces, axis=1)
    keys = pd.util.hash_pandas_object(table.fillna(np.inf), index=False)
    conflicting = pd.Series(y).groupby(keys.to_numpy()).transform("nunique").to_numpy() > 1
    report["conflicting_rows_removed"] = int(conflicting.sum())
    keep = ~conflicting
    first = ~pd.Series(None).duplicated().to_numpy()
    report["duplicates_removed"] = int((keep & ~first).sum())
    keep &= first
    report["rows_out"] = int(keep.sum())
    report["features_out"] = table.shape[1]
    return table.to_numpy()[keep], y[keep], report


def x_clean__mutmut_86(
    frame: pd.DataFrame, labels, category_cap: int = CATEGORY_CAP
) -> tuple[np.ndarray, np.ndarray, dict[str, Any]]:
    frame = frame.reset_index(drop=True)
    y = np.asarray(labels).astype(int)
    report: dict[str, Any] = {
        "rows_in": len(frame),
        "dropped_constant": [],
        "dropped_missing": [],
        "dropped_high_cardinality": [],
        "encoded": [],
    }
    pieces = []
    for name in frame.columns:
        col = frame[name]
        if col.isna().mean() > MAX_MISSING_SHARE:
            report["dropped_missing"].append(name)
        elif col.dropna().nunique() <= 1:
            report["dropped_constant"].append(name)
        elif pd.api.types.is_numeric_dtype(col) and not pd.api.types.is_bool_dtype(col):
            pieces.append(col.astype(float).rename(name))
        elif col.nunique() > category_cap:
            report["dropped_high_cardinality"].append(name)
        else:
            report["encoded"].append(name)
            pieces.append(pd.get_dummies(col.astype(str), prefix=str(name), dtype=float))
    if not pieces:
        raise NormaliseError("no usable feature left")
    table = pd.concat(pieces, axis=1)
    keys = pd.util.hash_pandas_object(table.fillna(np.inf), index=False)
    conflicting = pd.Series(y).groupby(keys.to_numpy()).transform("nunique").to_numpy() > 1
    report["conflicting_rows_removed"] = int(conflicting.sum())
    keep = ~conflicting
    first = ~pd.Series(keys.to_numpy()).duplicated().to_numpy()
    report["duplicates_removed"] = None
    keep &= first
    report["rows_out"] = int(keep.sum())
    report["features_out"] = table.shape[1]
    return table.to_numpy()[keep], y[keep], report


def x_clean__mutmut_87(
    frame: pd.DataFrame, labels, category_cap: int = CATEGORY_CAP
) -> tuple[np.ndarray, np.ndarray, dict[str, Any]]:
    frame = frame.reset_index(drop=True)
    y = np.asarray(labels).astype(int)
    report: dict[str, Any] = {
        "rows_in": len(frame),
        "dropped_constant": [],
        "dropped_missing": [],
        "dropped_high_cardinality": [],
        "encoded": [],
    }
    pieces = []
    for name in frame.columns:
        col = frame[name]
        if col.isna().mean() > MAX_MISSING_SHARE:
            report["dropped_missing"].append(name)
        elif col.dropna().nunique() <= 1:
            report["dropped_constant"].append(name)
        elif pd.api.types.is_numeric_dtype(col) and not pd.api.types.is_bool_dtype(col):
            pieces.append(col.astype(float).rename(name))
        elif col.nunique() > category_cap:
            report["dropped_high_cardinality"].append(name)
        else:
            report["encoded"].append(name)
            pieces.append(pd.get_dummies(col.astype(str), prefix=str(name), dtype=float))
    if not pieces:
        raise NormaliseError("no usable feature left")
    table = pd.concat(pieces, axis=1)
    keys = pd.util.hash_pandas_object(table.fillna(np.inf), index=False)
    conflicting = pd.Series(y).groupby(keys.to_numpy()).transform("nunique").to_numpy() > 1
    report["conflicting_rows_removed"] = int(conflicting.sum())
    keep = ~conflicting
    first = ~pd.Series(keys.to_numpy()).duplicated().to_numpy()
    report["XXduplicates_removedXX"] = int((keep & ~first).sum())
    keep &= first
    report["rows_out"] = int(keep.sum())
    report["features_out"] = table.shape[1]
    return table.to_numpy()[keep], y[keep], report


def x_clean__mutmut_88(
    frame: pd.DataFrame, labels, category_cap: int = CATEGORY_CAP
) -> tuple[np.ndarray, np.ndarray, dict[str, Any]]:
    frame = frame.reset_index(drop=True)
    y = np.asarray(labels).astype(int)
    report: dict[str, Any] = {
        "rows_in": len(frame),
        "dropped_constant": [],
        "dropped_missing": [],
        "dropped_high_cardinality": [],
        "encoded": [],
    }
    pieces = []
    for name in frame.columns:
        col = frame[name]
        if col.isna().mean() > MAX_MISSING_SHARE:
            report["dropped_missing"].append(name)
        elif col.dropna().nunique() <= 1:
            report["dropped_constant"].append(name)
        elif pd.api.types.is_numeric_dtype(col) and not pd.api.types.is_bool_dtype(col):
            pieces.append(col.astype(float).rename(name))
        elif col.nunique() > category_cap:
            report["dropped_high_cardinality"].append(name)
        else:
            report["encoded"].append(name)
            pieces.append(pd.get_dummies(col.astype(str), prefix=str(name), dtype=float))
    if not pieces:
        raise NormaliseError("no usable feature left")
    table = pd.concat(pieces, axis=1)
    keys = pd.util.hash_pandas_object(table.fillna(np.inf), index=False)
    conflicting = pd.Series(y).groupby(keys.to_numpy()).transform("nunique").to_numpy() > 1
    report["conflicting_rows_removed"] = int(conflicting.sum())
    keep = ~conflicting
    first = ~pd.Series(keys.to_numpy()).duplicated().to_numpy()
    report["DUPLICATES_REMOVED"] = int((keep & ~first).sum())
    keep &= first
    report["rows_out"] = int(keep.sum())
    report["features_out"] = table.shape[1]
    return table.to_numpy()[keep], y[keep], report


def x_clean__mutmut_89(
    frame: pd.DataFrame, labels, category_cap: int = CATEGORY_CAP
) -> tuple[np.ndarray, np.ndarray, dict[str, Any]]:
    frame = frame.reset_index(drop=True)
    y = np.asarray(labels).astype(int)
    report: dict[str, Any] = {
        "rows_in": len(frame),
        "dropped_constant": [],
        "dropped_missing": [],
        "dropped_high_cardinality": [],
        "encoded": [],
    }
    pieces = []
    for name in frame.columns:
        col = frame[name]
        if col.isna().mean() > MAX_MISSING_SHARE:
            report["dropped_missing"].append(name)
        elif col.dropna().nunique() <= 1:
            report["dropped_constant"].append(name)
        elif pd.api.types.is_numeric_dtype(col) and not pd.api.types.is_bool_dtype(col):
            pieces.append(col.astype(float).rename(name))
        elif col.nunique() > category_cap:
            report["dropped_high_cardinality"].append(name)
        else:
            report["encoded"].append(name)
            pieces.append(pd.get_dummies(col.astype(str), prefix=str(name), dtype=float))
    if not pieces:
        raise NormaliseError("no usable feature left")
    table = pd.concat(pieces, axis=1)
    keys = pd.util.hash_pandas_object(table.fillna(np.inf), index=False)
    conflicting = pd.Series(y).groupby(keys.to_numpy()).transform("nunique").to_numpy() > 1
    report["conflicting_rows_removed"] = int(conflicting.sum())
    keep = ~conflicting
    first = ~pd.Series(keys.to_numpy()).duplicated().to_numpy()
    report["duplicates_removed"] = int(None)
    keep &= first
    report["rows_out"] = int(keep.sum())
    report["features_out"] = table.shape[1]
    return table.to_numpy()[keep], y[keep], report


def x_clean__mutmut_90(
    frame: pd.DataFrame, labels, category_cap: int = CATEGORY_CAP
) -> tuple[np.ndarray, np.ndarray, dict[str, Any]]:
    frame = frame.reset_index(drop=True)
    y = np.asarray(labels).astype(int)
    report: dict[str, Any] = {
        "rows_in": len(frame),
        "dropped_constant": [],
        "dropped_missing": [],
        "dropped_high_cardinality": [],
        "encoded": [],
    }
    pieces = []
    for name in frame.columns:
        col = frame[name]
        if col.isna().mean() > MAX_MISSING_SHARE:
            report["dropped_missing"].append(name)
        elif col.dropna().nunique() <= 1:
            report["dropped_constant"].append(name)
        elif pd.api.types.is_numeric_dtype(col) and not pd.api.types.is_bool_dtype(col):
            pieces.append(col.astype(float).rename(name))
        elif col.nunique() > category_cap:
            report["dropped_high_cardinality"].append(name)
        else:
            report["encoded"].append(name)
            pieces.append(pd.get_dummies(col.astype(str), prefix=str(name), dtype=float))
    if not pieces:
        raise NormaliseError("no usable feature left")
    table = pd.concat(pieces, axis=1)
    keys = pd.util.hash_pandas_object(table.fillna(np.inf), index=False)
    conflicting = pd.Series(y).groupby(keys.to_numpy()).transform("nunique").to_numpy() > 1
    report["conflicting_rows_removed"] = int(conflicting.sum())
    keep = ~conflicting
    first = ~pd.Series(keys.to_numpy()).duplicated().to_numpy()
    report["duplicates_removed"] = int((keep | ~first).sum())
    keep &= first
    report["rows_out"] = int(keep.sum())
    report["features_out"] = table.shape[1]
    return table.to_numpy()[keep], y[keep], report


def x_clean__mutmut_91(
    frame: pd.DataFrame, labels, category_cap: int = CATEGORY_CAP
) -> tuple[np.ndarray, np.ndarray, dict[str, Any]]:
    frame = frame.reset_index(drop=True)
    y = np.asarray(labels).astype(int)
    report: dict[str, Any] = {
        "rows_in": len(frame),
        "dropped_constant": [],
        "dropped_missing": [],
        "dropped_high_cardinality": [],
        "encoded": [],
    }
    pieces = []
    for name in frame.columns:
        col = frame[name]
        if col.isna().mean() > MAX_MISSING_SHARE:
            report["dropped_missing"].append(name)
        elif col.dropna().nunique() <= 1:
            report["dropped_constant"].append(name)
        elif pd.api.types.is_numeric_dtype(col) and not pd.api.types.is_bool_dtype(col):
            pieces.append(col.astype(float).rename(name))
        elif col.nunique() > category_cap:
            report["dropped_high_cardinality"].append(name)
        else:
            report["encoded"].append(name)
            pieces.append(pd.get_dummies(col.astype(str), prefix=str(name), dtype=float))
    if not pieces:
        raise NormaliseError("no usable feature left")
    table = pd.concat(pieces, axis=1)
    keys = pd.util.hash_pandas_object(table.fillna(np.inf), index=False)
    conflicting = pd.Series(y).groupby(keys.to_numpy()).transform("nunique").to_numpy() > 1
    report["conflicting_rows_removed"] = int(conflicting.sum())
    keep = ~conflicting
    first = ~pd.Series(keys.to_numpy()).duplicated().to_numpy()
    report["duplicates_removed"] = int((keep & first).sum())
    keep &= first
    report["rows_out"] = int(keep.sum())
    report["features_out"] = table.shape[1]
    return table.to_numpy()[keep], y[keep], report


def x_clean__mutmut_92(
    frame: pd.DataFrame, labels, category_cap: int = CATEGORY_CAP
) -> tuple[np.ndarray, np.ndarray, dict[str, Any]]:
    frame = frame.reset_index(drop=True)
    y = np.asarray(labels).astype(int)
    report: dict[str, Any] = {
        "rows_in": len(frame),
        "dropped_constant": [],
        "dropped_missing": [],
        "dropped_high_cardinality": [],
        "encoded": [],
    }
    pieces = []
    for name in frame.columns:
        col = frame[name]
        if col.isna().mean() > MAX_MISSING_SHARE:
            report["dropped_missing"].append(name)
        elif col.dropna().nunique() <= 1:
            report["dropped_constant"].append(name)
        elif pd.api.types.is_numeric_dtype(col) and not pd.api.types.is_bool_dtype(col):
            pieces.append(col.astype(float).rename(name))
        elif col.nunique() > category_cap:
            report["dropped_high_cardinality"].append(name)
        else:
            report["encoded"].append(name)
            pieces.append(pd.get_dummies(col.astype(str), prefix=str(name), dtype=float))
    if not pieces:
        raise NormaliseError("no usable feature left")
    table = pd.concat(pieces, axis=1)
    keys = pd.util.hash_pandas_object(table.fillna(np.inf), index=False)
    conflicting = pd.Series(y).groupby(keys.to_numpy()).transform("nunique").to_numpy() > 1
    report["conflicting_rows_removed"] = int(conflicting.sum())
    keep = ~conflicting
    first = ~pd.Series(keys.to_numpy()).duplicated().to_numpy()
    report["duplicates_removed"] = int((keep & ~first).sum())
    keep = first
    report["rows_out"] = int(keep.sum())
    report["features_out"] = table.shape[1]
    return table.to_numpy()[keep], y[keep], report


def x_clean__mutmut_93(
    frame: pd.DataFrame, labels, category_cap: int = CATEGORY_CAP
) -> tuple[np.ndarray, np.ndarray, dict[str, Any]]:
    frame = frame.reset_index(drop=True)
    y = np.asarray(labels).astype(int)
    report: dict[str, Any] = {
        "rows_in": len(frame),
        "dropped_constant": [],
        "dropped_missing": [],
        "dropped_high_cardinality": [],
        "encoded": [],
    }
    pieces = []
    for name in frame.columns:
        col = frame[name]
        if col.isna().mean() > MAX_MISSING_SHARE:
            report["dropped_missing"].append(name)
        elif col.dropna().nunique() <= 1:
            report["dropped_constant"].append(name)
        elif pd.api.types.is_numeric_dtype(col) and not pd.api.types.is_bool_dtype(col):
            pieces.append(col.astype(float).rename(name))
        elif col.nunique() > category_cap:
            report["dropped_high_cardinality"].append(name)
        else:
            report["encoded"].append(name)
            pieces.append(pd.get_dummies(col.astype(str), prefix=str(name), dtype=float))
    if not pieces:
        raise NormaliseError("no usable feature left")
    table = pd.concat(pieces, axis=1)
    keys = pd.util.hash_pandas_object(table.fillna(np.inf), index=False)
    conflicting = pd.Series(y).groupby(keys.to_numpy()).transform("nunique").to_numpy() > 1
    report["conflicting_rows_removed"] = int(conflicting.sum())
    keep = ~conflicting
    first = ~pd.Series(keys.to_numpy()).duplicated().to_numpy()
    report["duplicates_removed"] = int((keep & ~first).sum())
    keep |= first
    report["rows_out"] = int(keep.sum())
    report["features_out"] = table.shape[1]
    return table.to_numpy()[keep], y[keep], report


def x_clean__mutmut_94(
    frame: pd.DataFrame, labels, category_cap: int = CATEGORY_CAP
) -> tuple[np.ndarray, np.ndarray, dict[str, Any]]:
    frame = frame.reset_index(drop=True)
    y = np.asarray(labels).astype(int)
    report: dict[str, Any] = {
        "rows_in": len(frame),
        "dropped_constant": [],
        "dropped_missing": [],
        "dropped_high_cardinality": [],
        "encoded": [],
    }
    pieces = []
    for name in frame.columns:
        col = frame[name]
        if col.isna().mean() > MAX_MISSING_SHARE:
            report["dropped_missing"].append(name)
        elif col.dropna().nunique() <= 1:
            report["dropped_constant"].append(name)
        elif pd.api.types.is_numeric_dtype(col) and not pd.api.types.is_bool_dtype(col):
            pieces.append(col.astype(float).rename(name))
        elif col.nunique() > category_cap:
            report["dropped_high_cardinality"].append(name)
        else:
            report["encoded"].append(name)
            pieces.append(pd.get_dummies(col.astype(str), prefix=str(name), dtype=float))
    if not pieces:
        raise NormaliseError("no usable feature left")
    table = pd.concat(pieces, axis=1)
    keys = pd.util.hash_pandas_object(table.fillna(np.inf), index=False)
    conflicting = pd.Series(y).groupby(keys.to_numpy()).transform("nunique").to_numpy() > 1
    report["conflicting_rows_removed"] = int(conflicting.sum())
    keep = ~conflicting
    first = ~pd.Series(keys.to_numpy()).duplicated().to_numpy()
    report["duplicates_removed"] = int((keep & ~first).sum())
    keep &= first
    report["rows_out"] = None
    report["features_out"] = table.shape[1]
    return table.to_numpy()[keep], y[keep], report


def x_clean__mutmut_95(
    frame: pd.DataFrame, labels, category_cap: int = CATEGORY_CAP
) -> tuple[np.ndarray, np.ndarray, dict[str, Any]]:
    frame = frame.reset_index(drop=True)
    y = np.asarray(labels).astype(int)
    report: dict[str, Any] = {
        "rows_in": len(frame),
        "dropped_constant": [],
        "dropped_missing": [],
        "dropped_high_cardinality": [],
        "encoded": [],
    }
    pieces = []
    for name in frame.columns:
        col = frame[name]
        if col.isna().mean() > MAX_MISSING_SHARE:
            report["dropped_missing"].append(name)
        elif col.dropna().nunique() <= 1:
            report["dropped_constant"].append(name)
        elif pd.api.types.is_numeric_dtype(col) and not pd.api.types.is_bool_dtype(col):
            pieces.append(col.astype(float).rename(name))
        elif col.nunique() > category_cap:
            report["dropped_high_cardinality"].append(name)
        else:
            report["encoded"].append(name)
            pieces.append(pd.get_dummies(col.astype(str), prefix=str(name), dtype=float))
    if not pieces:
        raise NormaliseError("no usable feature left")
    table = pd.concat(pieces, axis=1)
    keys = pd.util.hash_pandas_object(table.fillna(np.inf), index=False)
    conflicting = pd.Series(y).groupby(keys.to_numpy()).transform("nunique").to_numpy() > 1
    report["conflicting_rows_removed"] = int(conflicting.sum())
    keep = ~conflicting
    first = ~pd.Series(keys.to_numpy()).duplicated().to_numpy()
    report["duplicates_removed"] = int((keep & ~first).sum())
    keep &= first
    report["XXrows_outXX"] = int(keep.sum())
    report["features_out"] = table.shape[1]
    return table.to_numpy()[keep], y[keep], report


def x_clean__mutmut_96(
    frame: pd.DataFrame, labels, category_cap: int = CATEGORY_CAP
) -> tuple[np.ndarray, np.ndarray, dict[str, Any]]:
    frame = frame.reset_index(drop=True)
    y = np.asarray(labels).astype(int)
    report: dict[str, Any] = {
        "rows_in": len(frame),
        "dropped_constant": [],
        "dropped_missing": [],
        "dropped_high_cardinality": [],
        "encoded": [],
    }
    pieces = []
    for name in frame.columns:
        col = frame[name]
        if col.isna().mean() > MAX_MISSING_SHARE:
            report["dropped_missing"].append(name)
        elif col.dropna().nunique() <= 1:
            report["dropped_constant"].append(name)
        elif pd.api.types.is_numeric_dtype(col) and not pd.api.types.is_bool_dtype(col):
            pieces.append(col.astype(float).rename(name))
        elif col.nunique() > category_cap:
            report["dropped_high_cardinality"].append(name)
        else:
            report["encoded"].append(name)
            pieces.append(pd.get_dummies(col.astype(str), prefix=str(name), dtype=float))
    if not pieces:
        raise NormaliseError("no usable feature left")
    table = pd.concat(pieces, axis=1)
    keys = pd.util.hash_pandas_object(table.fillna(np.inf), index=False)
    conflicting = pd.Series(y).groupby(keys.to_numpy()).transform("nunique").to_numpy() > 1
    report["conflicting_rows_removed"] = int(conflicting.sum())
    keep = ~conflicting
    first = ~pd.Series(keys.to_numpy()).duplicated().to_numpy()
    report["duplicates_removed"] = int((keep & ~first).sum())
    keep &= first
    report["ROWS_OUT"] = int(keep.sum())
    report["features_out"] = table.shape[1]
    return table.to_numpy()[keep], y[keep], report


def x_clean__mutmut_97(
    frame: pd.DataFrame, labels, category_cap: int = CATEGORY_CAP
) -> tuple[np.ndarray, np.ndarray, dict[str, Any]]:
    frame = frame.reset_index(drop=True)
    y = np.asarray(labels).astype(int)
    report: dict[str, Any] = {
        "rows_in": len(frame),
        "dropped_constant": [],
        "dropped_missing": [],
        "dropped_high_cardinality": [],
        "encoded": [],
    }
    pieces = []
    for name in frame.columns:
        col = frame[name]
        if col.isna().mean() > MAX_MISSING_SHARE:
            report["dropped_missing"].append(name)
        elif col.dropna().nunique() <= 1:
            report["dropped_constant"].append(name)
        elif pd.api.types.is_numeric_dtype(col) and not pd.api.types.is_bool_dtype(col):
            pieces.append(col.astype(float).rename(name))
        elif col.nunique() > category_cap:
            report["dropped_high_cardinality"].append(name)
        else:
            report["encoded"].append(name)
            pieces.append(pd.get_dummies(col.astype(str), prefix=str(name), dtype=float))
    if not pieces:
        raise NormaliseError("no usable feature left")
    table = pd.concat(pieces, axis=1)
    keys = pd.util.hash_pandas_object(table.fillna(np.inf), index=False)
    conflicting = pd.Series(y).groupby(keys.to_numpy()).transform("nunique").to_numpy() > 1
    report["conflicting_rows_removed"] = int(conflicting.sum())
    keep = ~conflicting
    first = ~pd.Series(keys.to_numpy()).duplicated().to_numpy()
    report["duplicates_removed"] = int((keep & ~first).sum())
    keep &= first
    report["rows_out"] = int(None)
    report["features_out"] = table.shape[1]
    return table.to_numpy()[keep], y[keep], report


def x_clean__mutmut_98(
    frame: pd.DataFrame, labels, category_cap: int = CATEGORY_CAP
) -> tuple[np.ndarray, np.ndarray, dict[str, Any]]:
    frame = frame.reset_index(drop=True)
    y = np.asarray(labels).astype(int)
    report: dict[str, Any] = {
        "rows_in": len(frame),
        "dropped_constant": [],
        "dropped_missing": [],
        "dropped_high_cardinality": [],
        "encoded": [],
    }
    pieces = []
    for name in frame.columns:
        col = frame[name]
        if col.isna().mean() > MAX_MISSING_SHARE:
            report["dropped_missing"].append(name)
        elif col.dropna().nunique() <= 1:
            report["dropped_constant"].append(name)
        elif pd.api.types.is_numeric_dtype(col) and not pd.api.types.is_bool_dtype(col):
            pieces.append(col.astype(float).rename(name))
        elif col.nunique() > category_cap:
            report["dropped_high_cardinality"].append(name)
        else:
            report["encoded"].append(name)
            pieces.append(pd.get_dummies(col.astype(str), prefix=str(name), dtype=float))
    if not pieces:
        raise NormaliseError("no usable feature left")
    table = pd.concat(pieces, axis=1)
    keys = pd.util.hash_pandas_object(table.fillna(np.inf), index=False)
    conflicting = pd.Series(y).groupby(keys.to_numpy()).transform("nunique").to_numpy() > 1
    report["conflicting_rows_removed"] = int(conflicting.sum())
    keep = ~conflicting
    first = ~pd.Series(keys.to_numpy()).duplicated().to_numpy()
    report["duplicates_removed"] = int((keep & ~first).sum())
    keep &= first
    report["rows_out"] = int(keep.sum())
    report["features_out"] = None
    return table.to_numpy()[keep], y[keep], report


def x_clean__mutmut_99(
    frame: pd.DataFrame, labels, category_cap: int = CATEGORY_CAP
) -> tuple[np.ndarray, np.ndarray, dict[str, Any]]:
    frame = frame.reset_index(drop=True)
    y = np.asarray(labels).astype(int)
    report: dict[str, Any] = {
        "rows_in": len(frame),
        "dropped_constant": [],
        "dropped_missing": [],
        "dropped_high_cardinality": [],
        "encoded": [],
    }
    pieces = []
    for name in frame.columns:
        col = frame[name]
        if col.isna().mean() > MAX_MISSING_SHARE:
            report["dropped_missing"].append(name)
        elif col.dropna().nunique() <= 1:
            report["dropped_constant"].append(name)
        elif pd.api.types.is_numeric_dtype(col) and not pd.api.types.is_bool_dtype(col):
            pieces.append(col.astype(float).rename(name))
        elif col.nunique() > category_cap:
            report["dropped_high_cardinality"].append(name)
        else:
            report["encoded"].append(name)
            pieces.append(pd.get_dummies(col.astype(str), prefix=str(name), dtype=float))
    if not pieces:
        raise NormaliseError("no usable feature left")
    table = pd.concat(pieces, axis=1)
    keys = pd.util.hash_pandas_object(table.fillna(np.inf), index=False)
    conflicting = pd.Series(y).groupby(keys.to_numpy()).transform("nunique").to_numpy() > 1
    report["conflicting_rows_removed"] = int(conflicting.sum())
    keep = ~conflicting
    first = ~pd.Series(keys.to_numpy()).duplicated().to_numpy()
    report["duplicates_removed"] = int((keep & ~first).sum())
    keep &= first
    report["rows_out"] = int(keep.sum())
    report["XXfeatures_outXX"] = table.shape[1]
    return table.to_numpy()[keep], y[keep], report


def x_clean__mutmut_100(
    frame: pd.DataFrame, labels, category_cap: int = CATEGORY_CAP
) -> tuple[np.ndarray, np.ndarray, dict[str, Any]]:
    frame = frame.reset_index(drop=True)
    y = np.asarray(labels).astype(int)
    report: dict[str, Any] = {
        "rows_in": len(frame),
        "dropped_constant": [],
        "dropped_missing": [],
        "dropped_high_cardinality": [],
        "encoded": [],
    }
    pieces = []
    for name in frame.columns:
        col = frame[name]
        if col.isna().mean() > MAX_MISSING_SHARE:
            report["dropped_missing"].append(name)
        elif col.dropna().nunique() <= 1:
            report["dropped_constant"].append(name)
        elif pd.api.types.is_numeric_dtype(col) and not pd.api.types.is_bool_dtype(col):
            pieces.append(col.astype(float).rename(name))
        elif col.nunique() > category_cap:
            report["dropped_high_cardinality"].append(name)
        else:
            report["encoded"].append(name)
            pieces.append(pd.get_dummies(col.astype(str), prefix=str(name), dtype=float))
    if not pieces:
        raise NormaliseError("no usable feature left")
    table = pd.concat(pieces, axis=1)
    keys = pd.util.hash_pandas_object(table.fillna(np.inf), index=False)
    conflicting = pd.Series(y).groupby(keys.to_numpy()).transform("nunique").to_numpy() > 1
    report["conflicting_rows_removed"] = int(conflicting.sum())
    keep = ~conflicting
    first = ~pd.Series(keys.to_numpy()).duplicated().to_numpy()
    report["duplicates_removed"] = int((keep & ~first).sum())
    keep &= first
    report["rows_out"] = int(keep.sum())
    report["FEATURES_OUT"] = table.shape[1]
    return table.to_numpy()[keep], y[keep], report


def x_clean__mutmut_101(
    frame: pd.DataFrame, labels, category_cap: int = CATEGORY_CAP
) -> tuple[np.ndarray, np.ndarray, dict[str, Any]]:
    frame = frame.reset_index(drop=True)
    y = np.asarray(labels).astype(int)
    report: dict[str, Any] = {
        "rows_in": len(frame),
        "dropped_constant": [],
        "dropped_missing": [],
        "dropped_high_cardinality": [],
        "encoded": [],
    }
    pieces = []
    for name in frame.columns:
        col = frame[name]
        if col.isna().mean() > MAX_MISSING_SHARE:
            report["dropped_missing"].append(name)
        elif col.dropna().nunique() <= 1:
            report["dropped_constant"].append(name)
        elif pd.api.types.is_numeric_dtype(col) and not pd.api.types.is_bool_dtype(col):
            pieces.append(col.astype(float).rename(name))
        elif col.nunique() > category_cap:
            report["dropped_high_cardinality"].append(name)
        else:
            report["encoded"].append(name)
            pieces.append(pd.get_dummies(col.astype(str), prefix=str(name), dtype=float))
    if not pieces:
        raise NormaliseError("no usable feature left")
    table = pd.concat(pieces, axis=1)
    keys = pd.util.hash_pandas_object(table.fillna(np.inf), index=False)
    conflicting = pd.Series(y).groupby(keys.to_numpy()).transform("nunique").to_numpy() > 1
    report["conflicting_rows_removed"] = int(conflicting.sum())
    keep = ~conflicting
    first = ~pd.Series(keys.to_numpy()).duplicated().to_numpy()
    report["duplicates_removed"] = int((keep & ~first).sum())
    keep &= first
    report["rows_out"] = int(keep.sum())
    report["features_out"] = table.shape[2]
    return table.to_numpy()[keep], y[keep], report

mutants_x_clean__mutmut['_mutmut_orig'] = x_clean__mutmut_orig # type: ignore # mutmut generated
mutants_x_clean__mutmut['x_clean__mutmut_1'] = x_clean__mutmut_1 # type: ignore # mutmut generated
mutants_x_clean__mutmut['x_clean__mutmut_2'] = x_clean__mutmut_2 # type: ignore # mutmut generated
mutants_x_clean__mutmut['x_clean__mutmut_3'] = x_clean__mutmut_3 # type: ignore # mutmut generated
mutants_x_clean__mutmut['x_clean__mutmut_4'] = x_clean__mutmut_4 # type: ignore # mutmut generated
mutants_x_clean__mutmut['x_clean__mutmut_5'] = x_clean__mutmut_5 # type: ignore # mutmut generated
mutants_x_clean__mutmut['x_clean__mutmut_6'] = x_clean__mutmut_6 # type: ignore # mutmut generated
mutants_x_clean__mutmut['x_clean__mutmut_7'] = x_clean__mutmut_7 # type: ignore # mutmut generated
mutants_x_clean__mutmut['x_clean__mutmut_8'] = x_clean__mutmut_8 # type: ignore # mutmut generated
mutants_x_clean__mutmut['x_clean__mutmut_9'] = x_clean__mutmut_9 # type: ignore # mutmut generated
mutants_x_clean__mutmut['x_clean__mutmut_10'] = x_clean__mutmut_10 # type: ignore # mutmut generated
mutants_x_clean__mutmut['x_clean__mutmut_11'] = x_clean__mutmut_11 # type: ignore # mutmut generated
mutants_x_clean__mutmut['x_clean__mutmut_12'] = x_clean__mutmut_12 # type: ignore # mutmut generated
mutants_x_clean__mutmut['x_clean__mutmut_13'] = x_clean__mutmut_13 # type: ignore # mutmut generated
mutants_x_clean__mutmut['x_clean__mutmut_14'] = x_clean__mutmut_14 # type: ignore # mutmut generated
mutants_x_clean__mutmut['x_clean__mutmut_15'] = x_clean__mutmut_15 # type: ignore # mutmut generated
mutants_x_clean__mutmut['x_clean__mutmut_16'] = x_clean__mutmut_16 # type: ignore # mutmut generated
mutants_x_clean__mutmut['x_clean__mutmut_17'] = x_clean__mutmut_17 # type: ignore # mutmut generated
mutants_x_clean__mutmut['x_clean__mutmut_18'] = x_clean__mutmut_18 # type: ignore # mutmut generated
mutants_x_clean__mutmut['x_clean__mutmut_19'] = x_clean__mutmut_19 # type: ignore # mutmut generated
mutants_x_clean__mutmut['x_clean__mutmut_20'] = x_clean__mutmut_20 # type: ignore # mutmut generated
mutants_x_clean__mutmut['x_clean__mutmut_21'] = x_clean__mutmut_21 # type: ignore # mutmut generated
mutants_x_clean__mutmut['x_clean__mutmut_22'] = x_clean__mutmut_22 # type: ignore # mutmut generated
mutants_x_clean__mutmut['x_clean__mutmut_23'] = x_clean__mutmut_23 # type: ignore # mutmut generated
mutants_x_clean__mutmut['x_clean__mutmut_24'] = x_clean__mutmut_24 # type: ignore # mutmut generated
mutants_x_clean__mutmut['x_clean__mutmut_25'] = x_clean__mutmut_25 # type: ignore # mutmut generated
mutants_x_clean__mutmut['x_clean__mutmut_26'] = x_clean__mutmut_26 # type: ignore # mutmut generated
mutants_x_clean__mutmut['x_clean__mutmut_27'] = x_clean__mutmut_27 # type: ignore # mutmut generated
mutants_x_clean__mutmut['x_clean__mutmut_28'] = x_clean__mutmut_28 # type: ignore # mutmut generated
mutants_x_clean__mutmut['x_clean__mutmut_29'] = x_clean__mutmut_29 # type: ignore # mutmut generated
mutants_x_clean__mutmut['x_clean__mutmut_30'] = x_clean__mutmut_30 # type: ignore # mutmut generated
mutants_x_clean__mutmut['x_clean__mutmut_31'] = x_clean__mutmut_31 # type: ignore # mutmut generated
mutants_x_clean__mutmut['x_clean__mutmut_32'] = x_clean__mutmut_32 # type: ignore # mutmut generated
mutants_x_clean__mutmut['x_clean__mutmut_33'] = x_clean__mutmut_33 # type: ignore # mutmut generated
mutants_x_clean__mutmut['x_clean__mutmut_34'] = x_clean__mutmut_34 # type: ignore # mutmut generated
mutants_x_clean__mutmut['x_clean__mutmut_35'] = x_clean__mutmut_35 # type: ignore # mutmut generated
mutants_x_clean__mutmut['x_clean__mutmut_36'] = x_clean__mutmut_36 # type: ignore # mutmut generated
mutants_x_clean__mutmut['x_clean__mutmut_37'] = x_clean__mutmut_37 # type: ignore # mutmut generated
mutants_x_clean__mutmut['x_clean__mutmut_38'] = x_clean__mutmut_38 # type: ignore # mutmut generated
mutants_x_clean__mutmut['x_clean__mutmut_39'] = x_clean__mutmut_39 # type: ignore # mutmut generated
mutants_x_clean__mutmut['x_clean__mutmut_40'] = x_clean__mutmut_40 # type: ignore # mutmut generated
mutants_x_clean__mutmut['x_clean__mutmut_41'] = x_clean__mutmut_41 # type: ignore # mutmut generated
mutants_x_clean__mutmut['x_clean__mutmut_42'] = x_clean__mutmut_42 # type: ignore # mutmut generated
mutants_x_clean__mutmut['x_clean__mutmut_43'] = x_clean__mutmut_43 # type: ignore # mutmut generated
mutants_x_clean__mutmut['x_clean__mutmut_44'] = x_clean__mutmut_44 # type: ignore # mutmut generated
mutants_x_clean__mutmut['x_clean__mutmut_45'] = x_clean__mutmut_45 # type: ignore # mutmut generated
mutants_x_clean__mutmut['x_clean__mutmut_46'] = x_clean__mutmut_46 # type: ignore # mutmut generated
mutants_x_clean__mutmut['x_clean__mutmut_47'] = x_clean__mutmut_47 # type: ignore # mutmut generated
mutants_x_clean__mutmut['x_clean__mutmut_48'] = x_clean__mutmut_48 # type: ignore # mutmut generated
mutants_x_clean__mutmut['x_clean__mutmut_49'] = x_clean__mutmut_49 # type: ignore # mutmut generated
mutants_x_clean__mutmut['x_clean__mutmut_50'] = x_clean__mutmut_50 # type: ignore # mutmut generated
mutants_x_clean__mutmut['x_clean__mutmut_51'] = x_clean__mutmut_51 # type: ignore # mutmut generated
mutants_x_clean__mutmut['x_clean__mutmut_52'] = x_clean__mutmut_52 # type: ignore # mutmut generated
mutants_x_clean__mutmut['x_clean__mutmut_53'] = x_clean__mutmut_53 # type: ignore # mutmut generated
mutants_x_clean__mutmut['x_clean__mutmut_54'] = x_clean__mutmut_54 # type: ignore # mutmut generated
mutants_x_clean__mutmut['x_clean__mutmut_55'] = x_clean__mutmut_55 # type: ignore # mutmut generated
mutants_x_clean__mutmut['x_clean__mutmut_56'] = x_clean__mutmut_56 # type: ignore # mutmut generated
mutants_x_clean__mutmut['x_clean__mutmut_57'] = x_clean__mutmut_57 # type: ignore # mutmut generated
mutants_x_clean__mutmut['x_clean__mutmut_58'] = x_clean__mutmut_58 # type: ignore # mutmut generated
mutants_x_clean__mutmut['x_clean__mutmut_59'] = x_clean__mutmut_59 # type: ignore # mutmut generated
mutants_x_clean__mutmut['x_clean__mutmut_60'] = x_clean__mutmut_60 # type: ignore # mutmut generated
mutants_x_clean__mutmut['x_clean__mutmut_61'] = x_clean__mutmut_61 # type: ignore # mutmut generated
mutants_x_clean__mutmut['x_clean__mutmut_62'] = x_clean__mutmut_62 # type: ignore # mutmut generated
mutants_x_clean__mutmut['x_clean__mutmut_63'] = x_clean__mutmut_63 # type: ignore # mutmut generated
mutants_x_clean__mutmut['x_clean__mutmut_64'] = x_clean__mutmut_64 # type: ignore # mutmut generated
mutants_x_clean__mutmut['x_clean__mutmut_65'] = x_clean__mutmut_65 # type: ignore # mutmut generated
mutants_x_clean__mutmut['x_clean__mutmut_66'] = x_clean__mutmut_66 # type: ignore # mutmut generated
mutants_x_clean__mutmut['x_clean__mutmut_67'] = x_clean__mutmut_67 # type: ignore # mutmut generated
mutants_x_clean__mutmut['x_clean__mutmut_68'] = x_clean__mutmut_68 # type: ignore # mutmut generated
mutants_x_clean__mutmut['x_clean__mutmut_69'] = x_clean__mutmut_69 # type: ignore # mutmut generated
mutants_x_clean__mutmut['x_clean__mutmut_70'] = x_clean__mutmut_70 # type: ignore # mutmut generated
mutants_x_clean__mutmut['x_clean__mutmut_71'] = x_clean__mutmut_71 # type: ignore # mutmut generated
mutants_x_clean__mutmut['x_clean__mutmut_72'] = x_clean__mutmut_72 # type: ignore # mutmut generated
mutants_x_clean__mutmut['x_clean__mutmut_73'] = x_clean__mutmut_73 # type: ignore # mutmut generated
mutants_x_clean__mutmut['x_clean__mutmut_74'] = x_clean__mutmut_74 # type: ignore # mutmut generated
mutants_x_clean__mutmut['x_clean__mutmut_75'] = x_clean__mutmut_75 # type: ignore # mutmut generated
mutants_x_clean__mutmut['x_clean__mutmut_76'] = x_clean__mutmut_76 # type: ignore # mutmut generated
mutants_x_clean__mutmut['x_clean__mutmut_77'] = x_clean__mutmut_77 # type: ignore # mutmut generated
mutants_x_clean__mutmut['x_clean__mutmut_78'] = x_clean__mutmut_78 # type: ignore # mutmut generated
mutants_x_clean__mutmut['x_clean__mutmut_79'] = x_clean__mutmut_79 # type: ignore # mutmut generated
mutants_x_clean__mutmut['x_clean__mutmut_80'] = x_clean__mutmut_80 # type: ignore # mutmut generated
mutants_x_clean__mutmut['x_clean__mutmut_81'] = x_clean__mutmut_81 # type: ignore # mutmut generated
mutants_x_clean__mutmut['x_clean__mutmut_82'] = x_clean__mutmut_82 # type: ignore # mutmut generated
mutants_x_clean__mutmut['x_clean__mutmut_83'] = x_clean__mutmut_83 # type: ignore # mutmut generated
mutants_x_clean__mutmut['x_clean__mutmut_84'] = x_clean__mutmut_84 # type: ignore # mutmut generated
mutants_x_clean__mutmut['x_clean__mutmut_85'] = x_clean__mutmut_85 # type: ignore # mutmut generated
mutants_x_clean__mutmut['x_clean__mutmut_86'] = x_clean__mutmut_86 # type: ignore # mutmut generated
mutants_x_clean__mutmut['x_clean__mutmut_87'] = x_clean__mutmut_87 # type: ignore # mutmut generated
mutants_x_clean__mutmut['x_clean__mutmut_88'] = x_clean__mutmut_88 # type: ignore # mutmut generated
mutants_x_clean__mutmut['x_clean__mutmut_89'] = x_clean__mutmut_89 # type: ignore # mutmut generated
mutants_x_clean__mutmut['x_clean__mutmut_90'] = x_clean__mutmut_90 # type: ignore # mutmut generated
mutants_x_clean__mutmut['x_clean__mutmut_91'] = x_clean__mutmut_91 # type: ignore # mutmut generated
mutants_x_clean__mutmut['x_clean__mutmut_92'] = x_clean__mutmut_92 # type: ignore # mutmut generated
mutants_x_clean__mutmut['x_clean__mutmut_93'] = x_clean__mutmut_93 # type: ignore # mutmut generated
mutants_x_clean__mutmut['x_clean__mutmut_94'] = x_clean__mutmut_94 # type: ignore # mutmut generated
mutants_x_clean__mutmut['x_clean__mutmut_95'] = x_clean__mutmut_95 # type: ignore # mutmut generated
mutants_x_clean__mutmut['x_clean__mutmut_96'] = x_clean__mutmut_96 # type: ignore # mutmut generated
mutants_x_clean__mutmut['x_clean__mutmut_97'] = x_clean__mutmut_97 # type: ignore # mutmut generated
mutants_x_clean__mutmut['x_clean__mutmut_98'] = x_clean__mutmut_98 # type: ignore # mutmut generated
mutants_x_clean__mutmut['x_clean__mutmut_99'] = x_clean__mutmut_99 # type: ignore # mutmut generated
mutants_x_clean__mutmut['x_clean__mutmut_100'] = x_clean__mutmut_100 # type: ignore # mutmut generated
mutants_x_clean__mutmut['x_clean__mutmut_101'] = x_clean__mutmut_101 # type: ignore # mutmut generated
mutants_x_split__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_split__mutmut)
def split(x: np.ndarray, y, seed: int) -> dict[str, np.ndarray]:
    x, y = np.asarray(x, dtype=float), np.asarray(y).astype(int)
    if min(y.sum(), len(y) - y.sum()) < MIN_CLASS_COUNT:
        raise NormaliseError(f"too few anomalies to split ({int(y.sum())})")
    idx = np.arange(len(y))
    train, rest = train_test_split(idx, train_size=0.70, stratify=y, random_state=seed)
    val, test = train_test_split(rest, train_size=0.5, stratify=y[rest], random_state=seed)
    median = np.nanmedian(x[train], axis=0)

    def fill(a: np.ndarray) -> np.ndarray:
        return np.where(np.isnan(a), median, a)

    filled = fill(x[train])
    mean, scale = filled.mean(axis=0), filled.std(axis=0)
    scale = np.where(scale == 0, 1.0, scale)
    out: dict[str, np.ndarray] = {
        "mean": mean,
        "scale": scale,
        "idx_train": train,
        "idx_val": val,
        "idx_test": test,
    }
    for name, rows in (("train", train), ("val", val), ("test", test)):
        out[f"x_{name}"] = (fill(x[rows]) - mean) / scale
        out[f"y_{name}"] = y[rows]
    return out


def x_split__mutmut_orig(x: np.ndarray, y, seed: int) -> dict[str, np.ndarray]:
    x, y = np.asarray(x, dtype=float), np.asarray(y).astype(int)
    if min(y.sum(), len(y) - y.sum()) < MIN_CLASS_COUNT:
        raise NormaliseError(f"too few anomalies to split ({int(y.sum())})")
    idx = np.arange(len(y))
    train, rest = train_test_split(idx, train_size=0.70, stratify=y, random_state=seed)
    val, test = train_test_split(rest, train_size=0.5, stratify=y[rest], random_state=seed)
    median = np.nanmedian(x[train], axis=0)

    def fill(a: np.ndarray) -> np.ndarray:
        return np.where(np.isnan(a), median, a)

    filled = fill(x[train])
    mean, scale = filled.mean(axis=0), filled.std(axis=0)
    scale = np.where(scale == 0, 1.0, scale)
    out: dict[str, np.ndarray] = {
        "mean": mean,
        "scale": scale,
        "idx_train": train,
        "idx_val": val,
        "idx_test": test,
    }
    for name, rows in (("train", train), ("val", val), ("test", test)):
        out[f"x_{name}"] = (fill(x[rows]) - mean) / scale
        out[f"y_{name}"] = y[rows]
    return out


def x_split__mutmut_1(x: np.ndarray, y, seed: int) -> dict[str, np.ndarray]:
    x, y = None
    if min(y.sum(), len(y) - y.sum()) < MIN_CLASS_COUNT:
        raise NormaliseError(f"too few anomalies to split ({int(y.sum())})")
    idx = np.arange(len(y))
    train, rest = train_test_split(idx, train_size=0.70, stratify=y, random_state=seed)
    val, test = train_test_split(rest, train_size=0.5, stratify=y[rest], random_state=seed)
    median = np.nanmedian(x[train], axis=0)

    def fill(a: np.ndarray) -> np.ndarray:
        return np.where(np.isnan(a), median, a)

    filled = fill(x[train])
    mean, scale = filled.mean(axis=0), filled.std(axis=0)
    scale = np.where(scale == 0, 1.0, scale)
    out: dict[str, np.ndarray] = {
        "mean": mean,
        "scale": scale,
        "idx_train": train,
        "idx_val": val,
        "idx_test": test,
    }
    for name, rows in (("train", train), ("val", val), ("test", test)):
        out[f"x_{name}"] = (fill(x[rows]) - mean) / scale
        out[f"y_{name}"] = y[rows]
    return out


def x_split__mutmut_2(x: np.ndarray, y, seed: int) -> dict[str, np.ndarray]:
    x, y = np.asarray(None, dtype=float), np.asarray(y).astype(int)
    if min(y.sum(), len(y) - y.sum()) < MIN_CLASS_COUNT:
        raise NormaliseError(f"too few anomalies to split ({int(y.sum())})")
    idx = np.arange(len(y))
    train, rest = train_test_split(idx, train_size=0.70, stratify=y, random_state=seed)
    val, test = train_test_split(rest, train_size=0.5, stratify=y[rest], random_state=seed)
    median = np.nanmedian(x[train], axis=0)

    def fill(a: np.ndarray) -> np.ndarray:
        return np.where(np.isnan(a), median, a)

    filled = fill(x[train])
    mean, scale = filled.mean(axis=0), filled.std(axis=0)
    scale = np.where(scale == 0, 1.0, scale)
    out: dict[str, np.ndarray] = {
        "mean": mean,
        "scale": scale,
        "idx_train": train,
        "idx_val": val,
        "idx_test": test,
    }
    for name, rows in (("train", train), ("val", val), ("test", test)):
        out[f"x_{name}"] = (fill(x[rows]) - mean) / scale
        out[f"y_{name}"] = y[rows]
    return out


def x_split__mutmut_3(x: np.ndarray, y, seed: int) -> dict[str, np.ndarray]:
    x, y = np.asarray(x, dtype=None), np.asarray(y).astype(int)
    if min(y.sum(), len(y) - y.sum()) < MIN_CLASS_COUNT:
        raise NormaliseError(f"too few anomalies to split ({int(y.sum())})")
    idx = np.arange(len(y))
    train, rest = train_test_split(idx, train_size=0.70, stratify=y, random_state=seed)
    val, test = train_test_split(rest, train_size=0.5, stratify=y[rest], random_state=seed)
    median = np.nanmedian(x[train], axis=0)

    def fill(a: np.ndarray) -> np.ndarray:
        return np.where(np.isnan(a), median, a)

    filled = fill(x[train])
    mean, scale = filled.mean(axis=0), filled.std(axis=0)
    scale = np.where(scale == 0, 1.0, scale)
    out: dict[str, np.ndarray] = {
        "mean": mean,
        "scale": scale,
        "idx_train": train,
        "idx_val": val,
        "idx_test": test,
    }
    for name, rows in (("train", train), ("val", val), ("test", test)):
        out[f"x_{name}"] = (fill(x[rows]) - mean) / scale
        out[f"y_{name}"] = y[rows]
    return out


def x_split__mutmut_4(x: np.ndarray, y, seed: int) -> dict[str, np.ndarray]:
    x, y = np.asarray(dtype=float), np.asarray(y).astype(int)
    if min(y.sum(), len(y) - y.sum()) < MIN_CLASS_COUNT:
        raise NormaliseError(f"too few anomalies to split ({int(y.sum())})")
    idx = np.arange(len(y))
    train, rest = train_test_split(idx, train_size=0.70, stratify=y, random_state=seed)
    val, test = train_test_split(rest, train_size=0.5, stratify=y[rest], random_state=seed)
    median = np.nanmedian(x[train], axis=0)

    def fill(a: np.ndarray) -> np.ndarray:
        return np.where(np.isnan(a), median, a)

    filled = fill(x[train])
    mean, scale = filled.mean(axis=0), filled.std(axis=0)
    scale = np.where(scale == 0, 1.0, scale)
    out: dict[str, np.ndarray] = {
        "mean": mean,
        "scale": scale,
        "idx_train": train,
        "idx_val": val,
        "idx_test": test,
    }
    for name, rows in (("train", train), ("val", val), ("test", test)):
        out[f"x_{name}"] = (fill(x[rows]) - mean) / scale
        out[f"y_{name}"] = y[rows]
    return out


def x_split__mutmut_5(x: np.ndarray, y, seed: int) -> dict[str, np.ndarray]:
    x, y = np.asarray(x, ), np.asarray(y).astype(int)
    if min(y.sum(), len(y) - y.sum()) < MIN_CLASS_COUNT:
        raise NormaliseError(f"too few anomalies to split ({int(y.sum())})")
    idx = np.arange(len(y))
    train, rest = train_test_split(idx, train_size=0.70, stratify=y, random_state=seed)
    val, test = train_test_split(rest, train_size=0.5, stratify=y[rest], random_state=seed)
    median = np.nanmedian(x[train], axis=0)

    def fill(a: np.ndarray) -> np.ndarray:
        return np.where(np.isnan(a), median, a)

    filled = fill(x[train])
    mean, scale = filled.mean(axis=0), filled.std(axis=0)
    scale = np.where(scale == 0, 1.0, scale)
    out: dict[str, np.ndarray] = {
        "mean": mean,
        "scale": scale,
        "idx_train": train,
        "idx_val": val,
        "idx_test": test,
    }
    for name, rows in (("train", train), ("val", val), ("test", test)):
        out[f"x_{name}"] = (fill(x[rows]) - mean) / scale
        out[f"y_{name}"] = y[rows]
    return out


def x_split__mutmut_6(x: np.ndarray, y, seed: int) -> dict[str, np.ndarray]:
    x, y = np.asarray(x, dtype=float), np.asarray(y).astype(None)
    if min(y.sum(), len(y) - y.sum()) < MIN_CLASS_COUNT:
        raise NormaliseError(f"too few anomalies to split ({int(y.sum())})")
    idx = np.arange(len(y))
    train, rest = train_test_split(idx, train_size=0.70, stratify=y, random_state=seed)
    val, test = train_test_split(rest, train_size=0.5, stratify=y[rest], random_state=seed)
    median = np.nanmedian(x[train], axis=0)

    def fill(a: np.ndarray) -> np.ndarray:
        return np.where(np.isnan(a), median, a)

    filled = fill(x[train])
    mean, scale = filled.mean(axis=0), filled.std(axis=0)
    scale = np.where(scale == 0, 1.0, scale)
    out: dict[str, np.ndarray] = {
        "mean": mean,
        "scale": scale,
        "idx_train": train,
        "idx_val": val,
        "idx_test": test,
    }
    for name, rows in (("train", train), ("val", val), ("test", test)):
        out[f"x_{name}"] = (fill(x[rows]) - mean) / scale
        out[f"y_{name}"] = y[rows]
    return out


def x_split__mutmut_7(x: np.ndarray, y, seed: int) -> dict[str, np.ndarray]:
    x, y = np.asarray(x, dtype=float), np.asarray(None).astype(int)
    if min(y.sum(), len(y) - y.sum()) < MIN_CLASS_COUNT:
        raise NormaliseError(f"too few anomalies to split ({int(y.sum())})")
    idx = np.arange(len(y))
    train, rest = train_test_split(idx, train_size=0.70, stratify=y, random_state=seed)
    val, test = train_test_split(rest, train_size=0.5, stratify=y[rest], random_state=seed)
    median = np.nanmedian(x[train], axis=0)

    def fill(a: np.ndarray) -> np.ndarray:
        return np.where(np.isnan(a), median, a)

    filled = fill(x[train])
    mean, scale = filled.mean(axis=0), filled.std(axis=0)
    scale = np.where(scale == 0, 1.0, scale)
    out: dict[str, np.ndarray] = {
        "mean": mean,
        "scale": scale,
        "idx_train": train,
        "idx_val": val,
        "idx_test": test,
    }
    for name, rows in (("train", train), ("val", val), ("test", test)):
        out[f"x_{name}"] = (fill(x[rows]) - mean) / scale
        out[f"y_{name}"] = y[rows]
    return out


def x_split__mutmut_8(x: np.ndarray, y, seed: int) -> dict[str, np.ndarray]:
    x, y = np.asarray(x, dtype=float), np.asarray(y).astype(int)
    if min(None, len(y) - y.sum()) < MIN_CLASS_COUNT:
        raise NormaliseError(f"too few anomalies to split ({int(y.sum())})")
    idx = np.arange(len(y))
    train, rest = train_test_split(idx, train_size=0.70, stratify=y, random_state=seed)
    val, test = train_test_split(rest, train_size=0.5, stratify=y[rest], random_state=seed)
    median = np.nanmedian(x[train], axis=0)

    def fill(a: np.ndarray) -> np.ndarray:
        return np.where(np.isnan(a), median, a)

    filled = fill(x[train])
    mean, scale = filled.mean(axis=0), filled.std(axis=0)
    scale = np.where(scale == 0, 1.0, scale)
    out: dict[str, np.ndarray] = {
        "mean": mean,
        "scale": scale,
        "idx_train": train,
        "idx_val": val,
        "idx_test": test,
    }
    for name, rows in (("train", train), ("val", val), ("test", test)):
        out[f"x_{name}"] = (fill(x[rows]) - mean) / scale
        out[f"y_{name}"] = y[rows]
    return out


def x_split__mutmut_9(x: np.ndarray, y, seed: int) -> dict[str, np.ndarray]:
    x, y = np.asarray(x, dtype=float), np.asarray(y).astype(int)
    if min(y.sum(), None) < MIN_CLASS_COUNT:
        raise NormaliseError(f"too few anomalies to split ({int(y.sum())})")
    idx = np.arange(len(y))
    train, rest = train_test_split(idx, train_size=0.70, stratify=y, random_state=seed)
    val, test = train_test_split(rest, train_size=0.5, stratify=y[rest], random_state=seed)
    median = np.nanmedian(x[train], axis=0)

    def fill(a: np.ndarray) -> np.ndarray:
        return np.where(np.isnan(a), median, a)

    filled = fill(x[train])
    mean, scale = filled.mean(axis=0), filled.std(axis=0)
    scale = np.where(scale == 0, 1.0, scale)
    out: dict[str, np.ndarray] = {
        "mean": mean,
        "scale": scale,
        "idx_train": train,
        "idx_val": val,
        "idx_test": test,
    }
    for name, rows in (("train", train), ("val", val), ("test", test)):
        out[f"x_{name}"] = (fill(x[rows]) - mean) / scale
        out[f"y_{name}"] = y[rows]
    return out


def x_split__mutmut_10(x: np.ndarray, y, seed: int) -> dict[str, np.ndarray]:
    x, y = np.asarray(x, dtype=float), np.asarray(y).astype(int)
    if min(len(y) - y.sum()) < MIN_CLASS_COUNT:
        raise NormaliseError(f"too few anomalies to split ({int(y.sum())})")
    idx = np.arange(len(y))
    train, rest = train_test_split(idx, train_size=0.70, stratify=y, random_state=seed)
    val, test = train_test_split(rest, train_size=0.5, stratify=y[rest], random_state=seed)
    median = np.nanmedian(x[train], axis=0)

    def fill(a: np.ndarray) -> np.ndarray:
        return np.where(np.isnan(a), median, a)

    filled = fill(x[train])
    mean, scale = filled.mean(axis=0), filled.std(axis=0)
    scale = np.where(scale == 0, 1.0, scale)
    out: dict[str, np.ndarray] = {
        "mean": mean,
        "scale": scale,
        "idx_train": train,
        "idx_val": val,
        "idx_test": test,
    }
    for name, rows in (("train", train), ("val", val), ("test", test)):
        out[f"x_{name}"] = (fill(x[rows]) - mean) / scale
        out[f"y_{name}"] = y[rows]
    return out


def x_split__mutmut_11(x: np.ndarray, y, seed: int) -> dict[str, np.ndarray]:
    x, y = np.asarray(x, dtype=float), np.asarray(y).astype(int)
    if min(y.sum(), ) < MIN_CLASS_COUNT:
        raise NormaliseError(f"too few anomalies to split ({int(y.sum())})")
    idx = np.arange(len(y))
    train, rest = train_test_split(idx, train_size=0.70, stratify=y, random_state=seed)
    val, test = train_test_split(rest, train_size=0.5, stratify=y[rest], random_state=seed)
    median = np.nanmedian(x[train], axis=0)

    def fill(a: np.ndarray) -> np.ndarray:
        return np.where(np.isnan(a), median, a)

    filled = fill(x[train])
    mean, scale = filled.mean(axis=0), filled.std(axis=0)
    scale = np.where(scale == 0, 1.0, scale)
    out: dict[str, np.ndarray] = {
        "mean": mean,
        "scale": scale,
        "idx_train": train,
        "idx_val": val,
        "idx_test": test,
    }
    for name, rows in (("train", train), ("val", val), ("test", test)):
        out[f"x_{name}"] = (fill(x[rows]) - mean) / scale
        out[f"y_{name}"] = y[rows]
    return out


def x_split__mutmut_12(x: np.ndarray, y, seed: int) -> dict[str, np.ndarray]:
    x, y = np.asarray(x, dtype=float), np.asarray(y).astype(int)
    if min(y.sum(), len(y) + y.sum()) < MIN_CLASS_COUNT:
        raise NormaliseError(f"too few anomalies to split ({int(y.sum())})")
    idx = np.arange(len(y))
    train, rest = train_test_split(idx, train_size=0.70, stratify=y, random_state=seed)
    val, test = train_test_split(rest, train_size=0.5, stratify=y[rest], random_state=seed)
    median = np.nanmedian(x[train], axis=0)

    def fill(a: np.ndarray) -> np.ndarray:
        return np.where(np.isnan(a), median, a)

    filled = fill(x[train])
    mean, scale = filled.mean(axis=0), filled.std(axis=0)
    scale = np.where(scale == 0, 1.0, scale)
    out: dict[str, np.ndarray] = {
        "mean": mean,
        "scale": scale,
        "idx_train": train,
        "idx_val": val,
        "idx_test": test,
    }
    for name, rows in (("train", train), ("val", val), ("test", test)):
        out[f"x_{name}"] = (fill(x[rows]) - mean) / scale
        out[f"y_{name}"] = y[rows]
    return out


def x_split__mutmut_13(x: np.ndarray, y, seed: int) -> dict[str, np.ndarray]:
    x, y = np.asarray(x, dtype=float), np.asarray(y).astype(int)
    if min(y.sum(), len(y) - y.sum()) <= MIN_CLASS_COUNT:
        raise NormaliseError(f"too few anomalies to split ({int(y.sum())})")
    idx = np.arange(len(y))
    train, rest = train_test_split(idx, train_size=0.70, stratify=y, random_state=seed)
    val, test = train_test_split(rest, train_size=0.5, stratify=y[rest], random_state=seed)
    median = np.nanmedian(x[train], axis=0)

    def fill(a: np.ndarray) -> np.ndarray:
        return np.where(np.isnan(a), median, a)

    filled = fill(x[train])
    mean, scale = filled.mean(axis=0), filled.std(axis=0)
    scale = np.where(scale == 0, 1.0, scale)
    out: dict[str, np.ndarray] = {
        "mean": mean,
        "scale": scale,
        "idx_train": train,
        "idx_val": val,
        "idx_test": test,
    }
    for name, rows in (("train", train), ("val", val), ("test", test)):
        out[f"x_{name}"] = (fill(x[rows]) - mean) / scale
        out[f"y_{name}"] = y[rows]
    return out


def x_split__mutmut_14(x: np.ndarray, y, seed: int) -> dict[str, np.ndarray]:
    x, y = np.asarray(x, dtype=float), np.asarray(y).astype(int)
    if min(y.sum(), len(y) - y.sum()) < MIN_CLASS_COUNT:
        raise NormaliseError(None)
    idx = np.arange(len(y))
    train, rest = train_test_split(idx, train_size=0.70, stratify=y, random_state=seed)
    val, test = train_test_split(rest, train_size=0.5, stratify=y[rest], random_state=seed)
    median = np.nanmedian(x[train], axis=0)

    def fill(a: np.ndarray) -> np.ndarray:
        return np.where(np.isnan(a), median, a)

    filled = fill(x[train])
    mean, scale = filled.mean(axis=0), filled.std(axis=0)
    scale = np.where(scale == 0, 1.0, scale)
    out: dict[str, np.ndarray] = {
        "mean": mean,
        "scale": scale,
        "idx_train": train,
        "idx_val": val,
        "idx_test": test,
    }
    for name, rows in (("train", train), ("val", val), ("test", test)):
        out[f"x_{name}"] = (fill(x[rows]) - mean) / scale
        out[f"y_{name}"] = y[rows]
    return out


def x_split__mutmut_15(x: np.ndarray, y, seed: int) -> dict[str, np.ndarray]:
    x, y = np.asarray(x, dtype=float), np.asarray(y).astype(int)
    if min(y.sum(), len(y) - y.sum()) < MIN_CLASS_COUNT:
        raise NormaliseError(f"too few anomalies to split ({int(None)})")
    idx = np.arange(len(y))
    train, rest = train_test_split(idx, train_size=0.70, stratify=y, random_state=seed)
    val, test = train_test_split(rest, train_size=0.5, stratify=y[rest], random_state=seed)
    median = np.nanmedian(x[train], axis=0)

    def fill(a: np.ndarray) -> np.ndarray:
        return np.where(np.isnan(a), median, a)

    filled = fill(x[train])
    mean, scale = filled.mean(axis=0), filled.std(axis=0)
    scale = np.where(scale == 0, 1.0, scale)
    out: dict[str, np.ndarray] = {
        "mean": mean,
        "scale": scale,
        "idx_train": train,
        "idx_val": val,
        "idx_test": test,
    }
    for name, rows in (("train", train), ("val", val), ("test", test)):
        out[f"x_{name}"] = (fill(x[rows]) - mean) / scale
        out[f"y_{name}"] = y[rows]
    return out


def x_split__mutmut_16(x: np.ndarray, y, seed: int) -> dict[str, np.ndarray]:
    x, y = np.asarray(x, dtype=float), np.asarray(y).astype(int)
    if min(y.sum(), len(y) - y.sum()) < MIN_CLASS_COUNT:
        raise NormaliseError(f"too few anomalies to split ({int(y.sum())})")
    idx = None
    train, rest = train_test_split(idx, train_size=0.70, stratify=y, random_state=seed)
    val, test = train_test_split(rest, train_size=0.5, stratify=y[rest], random_state=seed)
    median = np.nanmedian(x[train], axis=0)

    def fill(a: np.ndarray) -> np.ndarray:
        return np.where(np.isnan(a), median, a)

    filled = fill(x[train])
    mean, scale = filled.mean(axis=0), filled.std(axis=0)
    scale = np.where(scale == 0, 1.0, scale)
    out: dict[str, np.ndarray] = {
        "mean": mean,
        "scale": scale,
        "idx_train": train,
        "idx_val": val,
        "idx_test": test,
    }
    for name, rows in (("train", train), ("val", val), ("test", test)):
        out[f"x_{name}"] = (fill(x[rows]) - mean) / scale
        out[f"y_{name}"] = y[rows]
    return out


def x_split__mutmut_17(x: np.ndarray, y, seed: int) -> dict[str, np.ndarray]:
    x, y = np.asarray(x, dtype=float), np.asarray(y).astype(int)
    if min(y.sum(), len(y) - y.sum()) < MIN_CLASS_COUNT:
        raise NormaliseError(f"too few anomalies to split ({int(y.sum())})")
    idx = np.arange(None)
    train, rest = train_test_split(idx, train_size=0.70, stratify=y, random_state=seed)
    val, test = train_test_split(rest, train_size=0.5, stratify=y[rest], random_state=seed)
    median = np.nanmedian(x[train], axis=0)

    def fill(a: np.ndarray) -> np.ndarray:
        return np.where(np.isnan(a), median, a)

    filled = fill(x[train])
    mean, scale = filled.mean(axis=0), filled.std(axis=0)
    scale = np.where(scale == 0, 1.0, scale)
    out: dict[str, np.ndarray] = {
        "mean": mean,
        "scale": scale,
        "idx_train": train,
        "idx_val": val,
        "idx_test": test,
    }
    for name, rows in (("train", train), ("val", val), ("test", test)):
        out[f"x_{name}"] = (fill(x[rows]) - mean) / scale
        out[f"y_{name}"] = y[rows]
    return out


def x_split__mutmut_18(x: np.ndarray, y, seed: int) -> dict[str, np.ndarray]:
    x, y = np.asarray(x, dtype=float), np.asarray(y).astype(int)
    if min(y.sum(), len(y) - y.sum()) < MIN_CLASS_COUNT:
        raise NormaliseError(f"too few anomalies to split ({int(y.sum())})")
    idx = np.arange(len(y))
    train, rest = None
    val, test = train_test_split(rest, train_size=0.5, stratify=y[rest], random_state=seed)
    median = np.nanmedian(x[train], axis=0)

    def fill(a: np.ndarray) -> np.ndarray:
        return np.where(np.isnan(a), median, a)

    filled = fill(x[train])
    mean, scale = filled.mean(axis=0), filled.std(axis=0)
    scale = np.where(scale == 0, 1.0, scale)
    out: dict[str, np.ndarray] = {
        "mean": mean,
        "scale": scale,
        "idx_train": train,
        "idx_val": val,
        "idx_test": test,
    }
    for name, rows in (("train", train), ("val", val), ("test", test)):
        out[f"x_{name}"] = (fill(x[rows]) - mean) / scale
        out[f"y_{name}"] = y[rows]
    return out


def x_split__mutmut_19(x: np.ndarray, y, seed: int) -> dict[str, np.ndarray]:
    x, y = np.asarray(x, dtype=float), np.asarray(y).astype(int)
    if min(y.sum(), len(y) - y.sum()) < MIN_CLASS_COUNT:
        raise NormaliseError(f"too few anomalies to split ({int(y.sum())})")
    idx = np.arange(len(y))
    train, rest = train_test_split(None, train_size=0.70, stratify=y, random_state=seed)
    val, test = train_test_split(rest, train_size=0.5, stratify=y[rest], random_state=seed)
    median = np.nanmedian(x[train], axis=0)

    def fill(a: np.ndarray) -> np.ndarray:
        return np.where(np.isnan(a), median, a)

    filled = fill(x[train])
    mean, scale = filled.mean(axis=0), filled.std(axis=0)
    scale = np.where(scale == 0, 1.0, scale)
    out: dict[str, np.ndarray] = {
        "mean": mean,
        "scale": scale,
        "idx_train": train,
        "idx_val": val,
        "idx_test": test,
    }
    for name, rows in (("train", train), ("val", val), ("test", test)):
        out[f"x_{name}"] = (fill(x[rows]) - mean) / scale
        out[f"y_{name}"] = y[rows]
    return out


def x_split__mutmut_20(x: np.ndarray, y, seed: int) -> dict[str, np.ndarray]:
    x, y = np.asarray(x, dtype=float), np.asarray(y).astype(int)
    if min(y.sum(), len(y) - y.sum()) < MIN_CLASS_COUNT:
        raise NormaliseError(f"too few anomalies to split ({int(y.sum())})")
    idx = np.arange(len(y))
    train, rest = train_test_split(idx, train_size=None, stratify=y, random_state=seed)
    val, test = train_test_split(rest, train_size=0.5, stratify=y[rest], random_state=seed)
    median = np.nanmedian(x[train], axis=0)

    def fill(a: np.ndarray) -> np.ndarray:
        return np.where(np.isnan(a), median, a)

    filled = fill(x[train])
    mean, scale = filled.mean(axis=0), filled.std(axis=0)
    scale = np.where(scale == 0, 1.0, scale)
    out: dict[str, np.ndarray] = {
        "mean": mean,
        "scale": scale,
        "idx_train": train,
        "idx_val": val,
        "idx_test": test,
    }
    for name, rows in (("train", train), ("val", val), ("test", test)):
        out[f"x_{name}"] = (fill(x[rows]) - mean) / scale
        out[f"y_{name}"] = y[rows]
    return out


def x_split__mutmut_21(x: np.ndarray, y, seed: int) -> dict[str, np.ndarray]:
    x, y = np.asarray(x, dtype=float), np.asarray(y).astype(int)
    if min(y.sum(), len(y) - y.sum()) < MIN_CLASS_COUNT:
        raise NormaliseError(f"too few anomalies to split ({int(y.sum())})")
    idx = np.arange(len(y))
    train, rest = train_test_split(idx, train_size=0.70, stratify=None, random_state=seed)
    val, test = train_test_split(rest, train_size=0.5, stratify=y[rest], random_state=seed)
    median = np.nanmedian(x[train], axis=0)

    def fill(a: np.ndarray) -> np.ndarray:
        return np.where(np.isnan(a), median, a)

    filled = fill(x[train])
    mean, scale = filled.mean(axis=0), filled.std(axis=0)
    scale = np.where(scale == 0, 1.0, scale)
    out: dict[str, np.ndarray] = {
        "mean": mean,
        "scale": scale,
        "idx_train": train,
        "idx_val": val,
        "idx_test": test,
    }
    for name, rows in (("train", train), ("val", val), ("test", test)):
        out[f"x_{name}"] = (fill(x[rows]) - mean) / scale
        out[f"y_{name}"] = y[rows]
    return out


def x_split__mutmut_22(x: np.ndarray, y, seed: int) -> dict[str, np.ndarray]:
    x, y = np.asarray(x, dtype=float), np.asarray(y).astype(int)
    if min(y.sum(), len(y) - y.sum()) < MIN_CLASS_COUNT:
        raise NormaliseError(f"too few anomalies to split ({int(y.sum())})")
    idx = np.arange(len(y))
    train, rest = train_test_split(idx, train_size=0.70, stratify=y, random_state=None)
    val, test = train_test_split(rest, train_size=0.5, stratify=y[rest], random_state=seed)
    median = np.nanmedian(x[train], axis=0)

    def fill(a: np.ndarray) -> np.ndarray:
        return np.where(np.isnan(a), median, a)

    filled = fill(x[train])
    mean, scale = filled.mean(axis=0), filled.std(axis=0)
    scale = np.where(scale == 0, 1.0, scale)
    out: dict[str, np.ndarray] = {
        "mean": mean,
        "scale": scale,
        "idx_train": train,
        "idx_val": val,
        "idx_test": test,
    }
    for name, rows in (("train", train), ("val", val), ("test", test)):
        out[f"x_{name}"] = (fill(x[rows]) - mean) / scale
        out[f"y_{name}"] = y[rows]
    return out


def x_split__mutmut_23(x: np.ndarray, y, seed: int) -> dict[str, np.ndarray]:
    x, y = np.asarray(x, dtype=float), np.asarray(y).astype(int)
    if min(y.sum(), len(y) - y.sum()) < MIN_CLASS_COUNT:
        raise NormaliseError(f"too few anomalies to split ({int(y.sum())})")
    idx = np.arange(len(y))
    train, rest = train_test_split(train_size=0.70, stratify=y, random_state=seed)
    val, test = train_test_split(rest, train_size=0.5, stratify=y[rest], random_state=seed)
    median = np.nanmedian(x[train], axis=0)

    def fill(a: np.ndarray) -> np.ndarray:
        return np.where(np.isnan(a), median, a)

    filled = fill(x[train])
    mean, scale = filled.mean(axis=0), filled.std(axis=0)
    scale = np.where(scale == 0, 1.0, scale)
    out: dict[str, np.ndarray] = {
        "mean": mean,
        "scale": scale,
        "idx_train": train,
        "idx_val": val,
        "idx_test": test,
    }
    for name, rows in (("train", train), ("val", val), ("test", test)):
        out[f"x_{name}"] = (fill(x[rows]) - mean) / scale
        out[f"y_{name}"] = y[rows]
    return out


def x_split__mutmut_24(x: np.ndarray, y, seed: int) -> dict[str, np.ndarray]:
    x, y = np.asarray(x, dtype=float), np.asarray(y).astype(int)
    if min(y.sum(), len(y) - y.sum()) < MIN_CLASS_COUNT:
        raise NormaliseError(f"too few anomalies to split ({int(y.sum())})")
    idx = np.arange(len(y))
    train, rest = train_test_split(idx, stratify=y, random_state=seed)
    val, test = train_test_split(rest, train_size=0.5, stratify=y[rest], random_state=seed)
    median = np.nanmedian(x[train], axis=0)

    def fill(a: np.ndarray) -> np.ndarray:
        return np.where(np.isnan(a), median, a)

    filled = fill(x[train])
    mean, scale = filled.mean(axis=0), filled.std(axis=0)
    scale = np.where(scale == 0, 1.0, scale)
    out: dict[str, np.ndarray] = {
        "mean": mean,
        "scale": scale,
        "idx_train": train,
        "idx_val": val,
        "idx_test": test,
    }
    for name, rows in (("train", train), ("val", val), ("test", test)):
        out[f"x_{name}"] = (fill(x[rows]) - mean) / scale
        out[f"y_{name}"] = y[rows]
    return out


def x_split__mutmut_25(x: np.ndarray, y, seed: int) -> dict[str, np.ndarray]:
    x, y = np.asarray(x, dtype=float), np.asarray(y).astype(int)
    if min(y.sum(), len(y) - y.sum()) < MIN_CLASS_COUNT:
        raise NormaliseError(f"too few anomalies to split ({int(y.sum())})")
    idx = np.arange(len(y))
    train, rest = train_test_split(idx, train_size=0.70, random_state=seed)
    val, test = train_test_split(rest, train_size=0.5, stratify=y[rest], random_state=seed)
    median = np.nanmedian(x[train], axis=0)

    def fill(a: np.ndarray) -> np.ndarray:
        return np.where(np.isnan(a), median, a)

    filled = fill(x[train])
    mean, scale = filled.mean(axis=0), filled.std(axis=0)
    scale = np.where(scale == 0, 1.0, scale)
    out: dict[str, np.ndarray] = {
        "mean": mean,
        "scale": scale,
        "idx_train": train,
        "idx_val": val,
        "idx_test": test,
    }
    for name, rows in (("train", train), ("val", val), ("test", test)):
        out[f"x_{name}"] = (fill(x[rows]) - mean) / scale
        out[f"y_{name}"] = y[rows]
    return out


def x_split__mutmut_26(x: np.ndarray, y, seed: int) -> dict[str, np.ndarray]:
    x, y = np.asarray(x, dtype=float), np.asarray(y).astype(int)
    if min(y.sum(), len(y) - y.sum()) < MIN_CLASS_COUNT:
        raise NormaliseError(f"too few anomalies to split ({int(y.sum())})")
    idx = np.arange(len(y))
    train, rest = train_test_split(idx, train_size=0.70, stratify=y, )
    val, test = train_test_split(rest, train_size=0.5, stratify=y[rest], random_state=seed)
    median = np.nanmedian(x[train], axis=0)

    def fill(a: np.ndarray) -> np.ndarray:
        return np.where(np.isnan(a), median, a)

    filled = fill(x[train])
    mean, scale = filled.mean(axis=0), filled.std(axis=0)
    scale = np.where(scale == 0, 1.0, scale)
    out: dict[str, np.ndarray] = {
        "mean": mean,
        "scale": scale,
        "idx_train": train,
        "idx_val": val,
        "idx_test": test,
    }
    for name, rows in (("train", train), ("val", val), ("test", test)):
        out[f"x_{name}"] = (fill(x[rows]) - mean) / scale
        out[f"y_{name}"] = y[rows]
    return out


def x_split__mutmut_27(x: np.ndarray, y, seed: int) -> dict[str, np.ndarray]:
    x, y = np.asarray(x, dtype=float), np.asarray(y).astype(int)
    if min(y.sum(), len(y) - y.sum()) < MIN_CLASS_COUNT:
        raise NormaliseError(f"too few anomalies to split ({int(y.sum())})")
    idx = np.arange(len(y))
    train, rest = train_test_split(idx, train_size=1.7, stratify=y, random_state=seed)
    val, test = train_test_split(rest, train_size=0.5, stratify=y[rest], random_state=seed)
    median = np.nanmedian(x[train], axis=0)

    def fill(a: np.ndarray) -> np.ndarray:
        return np.where(np.isnan(a), median, a)

    filled = fill(x[train])
    mean, scale = filled.mean(axis=0), filled.std(axis=0)
    scale = np.where(scale == 0, 1.0, scale)
    out: dict[str, np.ndarray] = {
        "mean": mean,
        "scale": scale,
        "idx_train": train,
        "idx_val": val,
        "idx_test": test,
    }
    for name, rows in (("train", train), ("val", val), ("test", test)):
        out[f"x_{name}"] = (fill(x[rows]) - mean) / scale
        out[f"y_{name}"] = y[rows]
    return out


def x_split__mutmut_28(x: np.ndarray, y, seed: int) -> dict[str, np.ndarray]:
    x, y = np.asarray(x, dtype=float), np.asarray(y).astype(int)
    if min(y.sum(), len(y) - y.sum()) < MIN_CLASS_COUNT:
        raise NormaliseError(f"too few anomalies to split ({int(y.sum())})")
    idx = np.arange(len(y))
    train, rest = train_test_split(idx, train_size=0.70, stratify=y, random_state=seed)
    val, test = None
    median = np.nanmedian(x[train], axis=0)

    def fill(a: np.ndarray) -> np.ndarray:
        return np.where(np.isnan(a), median, a)

    filled = fill(x[train])
    mean, scale = filled.mean(axis=0), filled.std(axis=0)
    scale = np.where(scale == 0, 1.0, scale)
    out: dict[str, np.ndarray] = {
        "mean": mean,
        "scale": scale,
        "idx_train": train,
        "idx_val": val,
        "idx_test": test,
    }
    for name, rows in (("train", train), ("val", val), ("test", test)):
        out[f"x_{name}"] = (fill(x[rows]) - mean) / scale
        out[f"y_{name}"] = y[rows]
    return out


def x_split__mutmut_29(x: np.ndarray, y, seed: int) -> dict[str, np.ndarray]:
    x, y = np.asarray(x, dtype=float), np.asarray(y).astype(int)
    if min(y.sum(), len(y) - y.sum()) < MIN_CLASS_COUNT:
        raise NormaliseError(f"too few anomalies to split ({int(y.sum())})")
    idx = np.arange(len(y))
    train, rest = train_test_split(idx, train_size=0.70, stratify=y, random_state=seed)
    val, test = train_test_split(None, train_size=0.5, stratify=y[rest], random_state=seed)
    median = np.nanmedian(x[train], axis=0)

    def fill(a: np.ndarray) -> np.ndarray:
        return np.where(np.isnan(a), median, a)

    filled = fill(x[train])
    mean, scale = filled.mean(axis=0), filled.std(axis=0)
    scale = np.where(scale == 0, 1.0, scale)
    out: dict[str, np.ndarray] = {
        "mean": mean,
        "scale": scale,
        "idx_train": train,
        "idx_val": val,
        "idx_test": test,
    }
    for name, rows in (("train", train), ("val", val), ("test", test)):
        out[f"x_{name}"] = (fill(x[rows]) - mean) / scale
        out[f"y_{name}"] = y[rows]
    return out


def x_split__mutmut_30(x: np.ndarray, y, seed: int) -> dict[str, np.ndarray]:
    x, y = np.asarray(x, dtype=float), np.asarray(y).astype(int)
    if min(y.sum(), len(y) - y.sum()) < MIN_CLASS_COUNT:
        raise NormaliseError(f"too few anomalies to split ({int(y.sum())})")
    idx = np.arange(len(y))
    train, rest = train_test_split(idx, train_size=0.70, stratify=y, random_state=seed)
    val, test = train_test_split(rest, train_size=None, stratify=y[rest], random_state=seed)
    median = np.nanmedian(x[train], axis=0)

    def fill(a: np.ndarray) -> np.ndarray:
        return np.where(np.isnan(a), median, a)

    filled = fill(x[train])
    mean, scale = filled.mean(axis=0), filled.std(axis=0)
    scale = np.where(scale == 0, 1.0, scale)
    out: dict[str, np.ndarray] = {
        "mean": mean,
        "scale": scale,
        "idx_train": train,
        "idx_val": val,
        "idx_test": test,
    }
    for name, rows in (("train", train), ("val", val), ("test", test)):
        out[f"x_{name}"] = (fill(x[rows]) - mean) / scale
        out[f"y_{name}"] = y[rows]
    return out


def x_split__mutmut_31(x: np.ndarray, y, seed: int) -> dict[str, np.ndarray]:
    x, y = np.asarray(x, dtype=float), np.asarray(y).astype(int)
    if min(y.sum(), len(y) - y.sum()) < MIN_CLASS_COUNT:
        raise NormaliseError(f"too few anomalies to split ({int(y.sum())})")
    idx = np.arange(len(y))
    train, rest = train_test_split(idx, train_size=0.70, stratify=y, random_state=seed)
    val, test = train_test_split(rest, train_size=0.5, stratify=None, random_state=seed)
    median = np.nanmedian(x[train], axis=0)

    def fill(a: np.ndarray) -> np.ndarray:
        return np.where(np.isnan(a), median, a)

    filled = fill(x[train])
    mean, scale = filled.mean(axis=0), filled.std(axis=0)
    scale = np.where(scale == 0, 1.0, scale)
    out: dict[str, np.ndarray] = {
        "mean": mean,
        "scale": scale,
        "idx_train": train,
        "idx_val": val,
        "idx_test": test,
    }
    for name, rows in (("train", train), ("val", val), ("test", test)):
        out[f"x_{name}"] = (fill(x[rows]) - mean) / scale
        out[f"y_{name}"] = y[rows]
    return out


def x_split__mutmut_32(x: np.ndarray, y, seed: int) -> dict[str, np.ndarray]:
    x, y = np.asarray(x, dtype=float), np.asarray(y).astype(int)
    if min(y.sum(), len(y) - y.sum()) < MIN_CLASS_COUNT:
        raise NormaliseError(f"too few anomalies to split ({int(y.sum())})")
    idx = np.arange(len(y))
    train, rest = train_test_split(idx, train_size=0.70, stratify=y, random_state=seed)
    val, test = train_test_split(rest, train_size=0.5, stratify=y[rest], random_state=None)
    median = np.nanmedian(x[train], axis=0)

    def fill(a: np.ndarray) -> np.ndarray:
        return np.where(np.isnan(a), median, a)

    filled = fill(x[train])
    mean, scale = filled.mean(axis=0), filled.std(axis=0)
    scale = np.where(scale == 0, 1.0, scale)
    out: dict[str, np.ndarray] = {
        "mean": mean,
        "scale": scale,
        "idx_train": train,
        "idx_val": val,
        "idx_test": test,
    }
    for name, rows in (("train", train), ("val", val), ("test", test)):
        out[f"x_{name}"] = (fill(x[rows]) - mean) / scale
        out[f"y_{name}"] = y[rows]
    return out


def x_split__mutmut_33(x: np.ndarray, y, seed: int) -> dict[str, np.ndarray]:
    x, y = np.asarray(x, dtype=float), np.asarray(y).astype(int)
    if min(y.sum(), len(y) - y.sum()) < MIN_CLASS_COUNT:
        raise NormaliseError(f"too few anomalies to split ({int(y.sum())})")
    idx = np.arange(len(y))
    train, rest = train_test_split(idx, train_size=0.70, stratify=y, random_state=seed)
    val, test = train_test_split(train_size=0.5, stratify=y[rest], random_state=seed)
    median = np.nanmedian(x[train], axis=0)

    def fill(a: np.ndarray) -> np.ndarray:
        return np.where(np.isnan(a), median, a)

    filled = fill(x[train])
    mean, scale = filled.mean(axis=0), filled.std(axis=0)
    scale = np.where(scale == 0, 1.0, scale)
    out: dict[str, np.ndarray] = {
        "mean": mean,
        "scale": scale,
        "idx_train": train,
        "idx_val": val,
        "idx_test": test,
    }
    for name, rows in (("train", train), ("val", val), ("test", test)):
        out[f"x_{name}"] = (fill(x[rows]) - mean) / scale
        out[f"y_{name}"] = y[rows]
    return out


def x_split__mutmut_34(x: np.ndarray, y, seed: int) -> dict[str, np.ndarray]:
    x, y = np.asarray(x, dtype=float), np.asarray(y).astype(int)
    if min(y.sum(), len(y) - y.sum()) < MIN_CLASS_COUNT:
        raise NormaliseError(f"too few anomalies to split ({int(y.sum())})")
    idx = np.arange(len(y))
    train, rest = train_test_split(idx, train_size=0.70, stratify=y, random_state=seed)
    val, test = train_test_split(rest, stratify=y[rest], random_state=seed)
    median = np.nanmedian(x[train], axis=0)

    def fill(a: np.ndarray) -> np.ndarray:
        return np.where(np.isnan(a), median, a)

    filled = fill(x[train])
    mean, scale = filled.mean(axis=0), filled.std(axis=0)
    scale = np.where(scale == 0, 1.0, scale)
    out: dict[str, np.ndarray] = {
        "mean": mean,
        "scale": scale,
        "idx_train": train,
        "idx_val": val,
        "idx_test": test,
    }
    for name, rows in (("train", train), ("val", val), ("test", test)):
        out[f"x_{name}"] = (fill(x[rows]) - mean) / scale
        out[f"y_{name}"] = y[rows]
    return out


def x_split__mutmut_35(x: np.ndarray, y, seed: int) -> dict[str, np.ndarray]:
    x, y = np.asarray(x, dtype=float), np.asarray(y).astype(int)
    if min(y.sum(), len(y) - y.sum()) < MIN_CLASS_COUNT:
        raise NormaliseError(f"too few anomalies to split ({int(y.sum())})")
    idx = np.arange(len(y))
    train, rest = train_test_split(idx, train_size=0.70, stratify=y, random_state=seed)
    val, test = train_test_split(rest, train_size=0.5, random_state=seed)
    median = np.nanmedian(x[train], axis=0)

    def fill(a: np.ndarray) -> np.ndarray:
        return np.where(np.isnan(a), median, a)

    filled = fill(x[train])
    mean, scale = filled.mean(axis=0), filled.std(axis=0)
    scale = np.where(scale == 0, 1.0, scale)
    out: dict[str, np.ndarray] = {
        "mean": mean,
        "scale": scale,
        "idx_train": train,
        "idx_val": val,
        "idx_test": test,
    }
    for name, rows in (("train", train), ("val", val), ("test", test)):
        out[f"x_{name}"] = (fill(x[rows]) - mean) / scale
        out[f"y_{name}"] = y[rows]
    return out


def x_split__mutmut_36(x: np.ndarray, y, seed: int) -> dict[str, np.ndarray]:
    x, y = np.asarray(x, dtype=float), np.asarray(y).astype(int)
    if min(y.sum(), len(y) - y.sum()) < MIN_CLASS_COUNT:
        raise NormaliseError(f"too few anomalies to split ({int(y.sum())})")
    idx = np.arange(len(y))
    train, rest = train_test_split(idx, train_size=0.70, stratify=y, random_state=seed)
    val, test = train_test_split(rest, train_size=0.5, stratify=y[rest], )
    median = np.nanmedian(x[train], axis=0)

    def fill(a: np.ndarray) -> np.ndarray:
        return np.where(np.isnan(a), median, a)

    filled = fill(x[train])
    mean, scale = filled.mean(axis=0), filled.std(axis=0)
    scale = np.where(scale == 0, 1.0, scale)
    out: dict[str, np.ndarray] = {
        "mean": mean,
        "scale": scale,
        "idx_train": train,
        "idx_val": val,
        "idx_test": test,
    }
    for name, rows in (("train", train), ("val", val), ("test", test)):
        out[f"x_{name}"] = (fill(x[rows]) - mean) / scale
        out[f"y_{name}"] = y[rows]
    return out


def x_split__mutmut_37(x: np.ndarray, y, seed: int) -> dict[str, np.ndarray]:
    x, y = np.asarray(x, dtype=float), np.asarray(y).astype(int)
    if min(y.sum(), len(y) - y.sum()) < MIN_CLASS_COUNT:
        raise NormaliseError(f"too few anomalies to split ({int(y.sum())})")
    idx = np.arange(len(y))
    train, rest = train_test_split(idx, train_size=0.70, stratify=y, random_state=seed)
    val, test = train_test_split(rest, train_size=1.5, stratify=y[rest], random_state=seed)
    median = np.nanmedian(x[train], axis=0)

    def fill(a: np.ndarray) -> np.ndarray:
        return np.where(np.isnan(a), median, a)

    filled = fill(x[train])
    mean, scale = filled.mean(axis=0), filled.std(axis=0)
    scale = np.where(scale == 0, 1.0, scale)
    out: dict[str, np.ndarray] = {
        "mean": mean,
        "scale": scale,
        "idx_train": train,
        "idx_val": val,
        "idx_test": test,
    }
    for name, rows in (("train", train), ("val", val), ("test", test)):
        out[f"x_{name}"] = (fill(x[rows]) - mean) / scale
        out[f"y_{name}"] = y[rows]
    return out


def x_split__mutmut_38(x: np.ndarray, y, seed: int) -> dict[str, np.ndarray]:
    x, y = np.asarray(x, dtype=float), np.asarray(y).astype(int)
    if min(y.sum(), len(y) - y.sum()) < MIN_CLASS_COUNT:
        raise NormaliseError(f"too few anomalies to split ({int(y.sum())})")
    idx = np.arange(len(y))
    train, rest = train_test_split(idx, train_size=0.70, stratify=y, random_state=seed)
    val, test = train_test_split(rest, train_size=0.5, stratify=y[rest], random_state=seed)
    median = None

    def fill(a: np.ndarray) -> np.ndarray:
        return np.where(np.isnan(a), median, a)

    filled = fill(x[train])
    mean, scale = filled.mean(axis=0), filled.std(axis=0)
    scale = np.where(scale == 0, 1.0, scale)
    out: dict[str, np.ndarray] = {
        "mean": mean,
        "scale": scale,
        "idx_train": train,
        "idx_val": val,
        "idx_test": test,
    }
    for name, rows in (("train", train), ("val", val), ("test", test)):
        out[f"x_{name}"] = (fill(x[rows]) - mean) / scale
        out[f"y_{name}"] = y[rows]
    return out


def x_split__mutmut_39(x: np.ndarray, y, seed: int) -> dict[str, np.ndarray]:
    x, y = np.asarray(x, dtype=float), np.asarray(y).astype(int)
    if min(y.sum(), len(y) - y.sum()) < MIN_CLASS_COUNT:
        raise NormaliseError(f"too few anomalies to split ({int(y.sum())})")
    idx = np.arange(len(y))
    train, rest = train_test_split(idx, train_size=0.70, stratify=y, random_state=seed)
    val, test = train_test_split(rest, train_size=0.5, stratify=y[rest], random_state=seed)
    median = np.nanmedian(None, axis=0)

    def fill(a: np.ndarray) -> np.ndarray:
        return np.where(np.isnan(a), median, a)

    filled = fill(x[train])
    mean, scale = filled.mean(axis=0), filled.std(axis=0)
    scale = np.where(scale == 0, 1.0, scale)
    out: dict[str, np.ndarray] = {
        "mean": mean,
        "scale": scale,
        "idx_train": train,
        "idx_val": val,
        "idx_test": test,
    }
    for name, rows in (("train", train), ("val", val), ("test", test)):
        out[f"x_{name}"] = (fill(x[rows]) - mean) / scale
        out[f"y_{name}"] = y[rows]
    return out


def x_split__mutmut_40(x: np.ndarray, y, seed: int) -> dict[str, np.ndarray]:
    x, y = np.asarray(x, dtype=float), np.asarray(y).astype(int)
    if min(y.sum(), len(y) - y.sum()) < MIN_CLASS_COUNT:
        raise NormaliseError(f"too few anomalies to split ({int(y.sum())})")
    idx = np.arange(len(y))
    train, rest = train_test_split(idx, train_size=0.70, stratify=y, random_state=seed)
    val, test = train_test_split(rest, train_size=0.5, stratify=y[rest], random_state=seed)
    median = np.nanmedian(x[train], axis=None)

    def fill(a: np.ndarray) -> np.ndarray:
        return np.where(np.isnan(a), median, a)

    filled = fill(x[train])
    mean, scale = filled.mean(axis=0), filled.std(axis=0)
    scale = np.where(scale == 0, 1.0, scale)
    out: dict[str, np.ndarray] = {
        "mean": mean,
        "scale": scale,
        "idx_train": train,
        "idx_val": val,
        "idx_test": test,
    }
    for name, rows in (("train", train), ("val", val), ("test", test)):
        out[f"x_{name}"] = (fill(x[rows]) - mean) / scale
        out[f"y_{name}"] = y[rows]
    return out


def x_split__mutmut_41(x: np.ndarray, y, seed: int) -> dict[str, np.ndarray]:
    x, y = np.asarray(x, dtype=float), np.asarray(y).astype(int)
    if min(y.sum(), len(y) - y.sum()) < MIN_CLASS_COUNT:
        raise NormaliseError(f"too few anomalies to split ({int(y.sum())})")
    idx = np.arange(len(y))
    train, rest = train_test_split(idx, train_size=0.70, stratify=y, random_state=seed)
    val, test = train_test_split(rest, train_size=0.5, stratify=y[rest], random_state=seed)
    median = np.nanmedian(axis=0)

    def fill(a: np.ndarray) -> np.ndarray:
        return np.where(np.isnan(a), median, a)

    filled = fill(x[train])
    mean, scale = filled.mean(axis=0), filled.std(axis=0)
    scale = np.where(scale == 0, 1.0, scale)
    out: dict[str, np.ndarray] = {
        "mean": mean,
        "scale": scale,
        "idx_train": train,
        "idx_val": val,
        "idx_test": test,
    }
    for name, rows in (("train", train), ("val", val), ("test", test)):
        out[f"x_{name}"] = (fill(x[rows]) - mean) / scale
        out[f"y_{name}"] = y[rows]
    return out


def x_split__mutmut_42(x: np.ndarray, y, seed: int) -> dict[str, np.ndarray]:
    x, y = np.asarray(x, dtype=float), np.asarray(y).astype(int)
    if min(y.sum(), len(y) - y.sum()) < MIN_CLASS_COUNT:
        raise NormaliseError(f"too few anomalies to split ({int(y.sum())})")
    idx = np.arange(len(y))
    train, rest = train_test_split(idx, train_size=0.70, stratify=y, random_state=seed)
    val, test = train_test_split(rest, train_size=0.5, stratify=y[rest], random_state=seed)
    median = np.nanmedian(x[train], )

    def fill(a: np.ndarray) -> np.ndarray:
        return np.where(np.isnan(a), median, a)

    filled = fill(x[train])
    mean, scale = filled.mean(axis=0), filled.std(axis=0)
    scale = np.where(scale == 0, 1.0, scale)
    out: dict[str, np.ndarray] = {
        "mean": mean,
        "scale": scale,
        "idx_train": train,
        "idx_val": val,
        "idx_test": test,
    }
    for name, rows in (("train", train), ("val", val), ("test", test)):
        out[f"x_{name}"] = (fill(x[rows]) - mean) / scale
        out[f"y_{name}"] = y[rows]
    return out


def x_split__mutmut_43(x: np.ndarray, y, seed: int) -> dict[str, np.ndarray]:
    x, y = np.asarray(x, dtype=float), np.asarray(y).astype(int)
    if min(y.sum(), len(y) - y.sum()) < MIN_CLASS_COUNT:
        raise NormaliseError(f"too few anomalies to split ({int(y.sum())})")
    idx = np.arange(len(y))
    train, rest = train_test_split(idx, train_size=0.70, stratify=y, random_state=seed)
    val, test = train_test_split(rest, train_size=0.5, stratify=y[rest], random_state=seed)
    median = np.nanmedian(x[train], axis=1)

    def fill(a: np.ndarray) -> np.ndarray:
        return np.where(np.isnan(a), median, a)

    filled = fill(x[train])
    mean, scale = filled.mean(axis=0), filled.std(axis=0)
    scale = np.where(scale == 0, 1.0, scale)
    out: dict[str, np.ndarray] = {
        "mean": mean,
        "scale": scale,
        "idx_train": train,
        "idx_val": val,
        "idx_test": test,
    }
    for name, rows in (("train", train), ("val", val), ("test", test)):
        out[f"x_{name}"] = (fill(x[rows]) - mean) / scale
        out[f"y_{name}"] = y[rows]
    return out


def x_split__mutmut_44(x: np.ndarray, y, seed: int) -> dict[str, np.ndarray]:
    x, y = np.asarray(x, dtype=float), np.asarray(y).astype(int)
    if min(y.sum(), len(y) - y.sum()) < MIN_CLASS_COUNT:
        raise NormaliseError(f"too few anomalies to split ({int(y.sum())})")
    idx = np.arange(len(y))
    train, rest = train_test_split(idx, train_size=0.70, stratify=y, random_state=seed)
    val, test = train_test_split(rest, train_size=0.5, stratify=y[rest], random_state=seed)
    median = np.nanmedian(x[train], axis=0)

    def fill(a: np.ndarray) -> np.ndarray:
        return np.where(None, median, a)

    filled = fill(x[train])
    mean, scale = filled.mean(axis=0), filled.std(axis=0)
    scale = np.where(scale == 0, 1.0, scale)
    out: dict[str, np.ndarray] = {
        "mean": mean,
        "scale": scale,
        "idx_train": train,
        "idx_val": val,
        "idx_test": test,
    }
    for name, rows in (("train", train), ("val", val), ("test", test)):
        out[f"x_{name}"] = (fill(x[rows]) - mean) / scale
        out[f"y_{name}"] = y[rows]
    return out


def x_split__mutmut_45(x: np.ndarray, y, seed: int) -> dict[str, np.ndarray]:
    x, y = np.asarray(x, dtype=float), np.asarray(y).astype(int)
    if min(y.sum(), len(y) - y.sum()) < MIN_CLASS_COUNT:
        raise NormaliseError(f"too few anomalies to split ({int(y.sum())})")
    idx = np.arange(len(y))
    train, rest = train_test_split(idx, train_size=0.70, stratify=y, random_state=seed)
    val, test = train_test_split(rest, train_size=0.5, stratify=y[rest], random_state=seed)
    median = np.nanmedian(x[train], axis=0)

    def fill(a: np.ndarray) -> np.ndarray:
        return np.where(np.isnan(a), None, a)

    filled = fill(x[train])
    mean, scale = filled.mean(axis=0), filled.std(axis=0)
    scale = np.where(scale == 0, 1.0, scale)
    out: dict[str, np.ndarray] = {
        "mean": mean,
        "scale": scale,
        "idx_train": train,
        "idx_val": val,
        "idx_test": test,
    }
    for name, rows in (("train", train), ("val", val), ("test", test)):
        out[f"x_{name}"] = (fill(x[rows]) - mean) / scale
        out[f"y_{name}"] = y[rows]
    return out


def x_split__mutmut_46(x: np.ndarray, y, seed: int) -> dict[str, np.ndarray]:
    x, y = np.asarray(x, dtype=float), np.asarray(y).astype(int)
    if min(y.sum(), len(y) - y.sum()) < MIN_CLASS_COUNT:
        raise NormaliseError(f"too few anomalies to split ({int(y.sum())})")
    idx = np.arange(len(y))
    train, rest = train_test_split(idx, train_size=0.70, stratify=y, random_state=seed)
    val, test = train_test_split(rest, train_size=0.5, stratify=y[rest], random_state=seed)
    median = np.nanmedian(x[train], axis=0)

    def fill(a: np.ndarray) -> np.ndarray:
        return np.where(np.isnan(a), median, None)

    filled = fill(x[train])
    mean, scale = filled.mean(axis=0), filled.std(axis=0)
    scale = np.where(scale == 0, 1.0, scale)
    out: dict[str, np.ndarray] = {
        "mean": mean,
        "scale": scale,
        "idx_train": train,
        "idx_val": val,
        "idx_test": test,
    }
    for name, rows in (("train", train), ("val", val), ("test", test)):
        out[f"x_{name}"] = (fill(x[rows]) - mean) / scale
        out[f"y_{name}"] = y[rows]
    return out


def x_split__mutmut_47(x: np.ndarray, y, seed: int) -> dict[str, np.ndarray]:
    x, y = np.asarray(x, dtype=float), np.asarray(y).astype(int)
    if min(y.sum(), len(y) - y.sum()) < MIN_CLASS_COUNT:
        raise NormaliseError(f"too few anomalies to split ({int(y.sum())})")
    idx = np.arange(len(y))
    train, rest = train_test_split(idx, train_size=0.70, stratify=y, random_state=seed)
    val, test = train_test_split(rest, train_size=0.5, stratify=y[rest], random_state=seed)
    median = np.nanmedian(x[train], axis=0)

    def fill(a: np.ndarray) -> np.ndarray:
        return np.where(median, a)

    filled = fill(x[train])
    mean, scale = filled.mean(axis=0), filled.std(axis=0)
    scale = np.where(scale == 0, 1.0, scale)
    out: dict[str, np.ndarray] = {
        "mean": mean,
        "scale": scale,
        "idx_train": train,
        "idx_val": val,
        "idx_test": test,
    }
    for name, rows in (("train", train), ("val", val), ("test", test)):
        out[f"x_{name}"] = (fill(x[rows]) - mean) / scale
        out[f"y_{name}"] = y[rows]
    return out


def x_split__mutmut_48(x: np.ndarray, y, seed: int) -> dict[str, np.ndarray]:
    x, y = np.asarray(x, dtype=float), np.asarray(y).astype(int)
    if min(y.sum(), len(y) - y.sum()) < MIN_CLASS_COUNT:
        raise NormaliseError(f"too few anomalies to split ({int(y.sum())})")
    idx = np.arange(len(y))
    train, rest = train_test_split(idx, train_size=0.70, stratify=y, random_state=seed)
    val, test = train_test_split(rest, train_size=0.5, stratify=y[rest], random_state=seed)
    median = np.nanmedian(x[train], axis=0)

    def fill(a: np.ndarray) -> np.ndarray:
        return np.where(np.isnan(a), a)

    filled = fill(x[train])
    mean, scale = filled.mean(axis=0), filled.std(axis=0)
    scale = np.where(scale == 0, 1.0, scale)
    out: dict[str, np.ndarray] = {
        "mean": mean,
        "scale": scale,
        "idx_train": train,
        "idx_val": val,
        "idx_test": test,
    }
    for name, rows in (("train", train), ("val", val), ("test", test)):
        out[f"x_{name}"] = (fill(x[rows]) - mean) / scale
        out[f"y_{name}"] = y[rows]
    return out


def x_split__mutmut_49(x: np.ndarray, y, seed: int) -> dict[str, np.ndarray]:
    x, y = np.asarray(x, dtype=float), np.asarray(y).astype(int)
    if min(y.sum(), len(y) - y.sum()) < MIN_CLASS_COUNT:
        raise NormaliseError(f"too few anomalies to split ({int(y.sum())})")
    idx = np.arange(len(y))
    train, rest = train_test_split(idx, train_size=0.70, stratify=y, random_state=seed)
    val, test = train_test_split(rest, train_size=0.5, stratify=y[rest], random_state=seed)
    median = np.nanmedian(x[train], axis=0)

    def fill(a: np.ndarray) -> np.ndarray:
        return np.where(np.isnan(a), median, )

    filled = fill(x[train])
    mean, scale = filled.mean(axis=0), filled.std(axis=0)
    scale = np.where(scale == 0, 1.0, scale)
    out: dict[str, np.ndarray] = {
        "mean": mean,
        "scale": scale,
        "idx_train": train,
        "idx_val": val,
        "idx_test": test,
    }
    for name, rows in (("train", train), ("val", val), ("test", test)):
        out[f"x_{name}"] = (fill(x[rows]) - mean) / scale
        out[f"y_{name}"] = y[rows]
    return out


def x_split__mutmut_50(x: np.ndarray, y, seed: int) -> dict[str, np.ndarray]:
    x, y = np.asarray(x, dtype=float), np.asarray(y).astype(int)
    if min(y.sum(), len(y) - y.sum()) < MIN_CLASS_COUNT:
        raise NormaliseError(f"too few anomalies to split ({int(y.sum())})")
    idx = np.arange(len(y))
    train, rest = train_test_split(idx, train_size=0.70, stratify=y, random_state=seed)
    val, test = train_test_split(rest, train_size=0.5, stratify=y[rest], random_state=seed)
    median = np.nanmedian(x[train], axis=0)

    def fill(a: np.ndarray) -> np.ndarray:
        return np.where(np.isnan(None), median, a)

    filled = fill(x[train])
    mean, scale = filled.mean(axis=0), filled.std(axis=0)
    scale = np.where(scale == 0, 1.0, scale)
    out: dict[str, np.ndarray] = {
        "mean": mean,
        "scale": scale,
        "idx_train": train,
        "idx_val": val,
        "idx_test": test,
    }
    for name, rows in (("train", train), ("val", val), ("test", test)):
        out[f"x_{name}"] = (fill(x[rows]) - mean) / scale
        out[f"y_{name}"] = y[rows]
    return out


def x_split__mutmut_51(x: np.ndarray, y, seed: int) -> dict[str, np.ndarray]:
    x, y = np.asarray(x, dtype=float), np.asarray(y).astype(int)
    if min(y.sum(), len(y) - y.sum()) < MIN_CLASS_COUNT:
        raise NormaliseError(f"too few anomalies to split ({int(y.sum())})")
    idx = np.arange(len(y))
    train, rest = train_test_split(idx, train_size=0.70, stratify=y, random_state=seed)
    val, test = train_test_split(rest, train_size=0.5, stratify=y[rest], random_state=seed)
    median = np.nanmedian(x[train], axis=0)

    def fill(a: np.ndarray) -> np.ndarray:
        return np.where(np.isnan(a), median, a)

    filled = None
    mean, scale = filled.mean(axis=0), filled.std(axis=0)
    scale = np.where(scale == 0, 1.0, scale)
    out: dict[str, np.ndarray] = {
        "mean": mean,
        "scale": scale,
        "idx_train": train,
        "idx_val": val,
        "idx_test": test,
    }
    for name, rows in (("train", train), ("val", val), ("test", test)):
        out[f"x_{name}"] = (fill(x[rows]) - mean) / scale
        out[f"y_{name}"] = y[rows]
    return out


def x_split__mutmut_52(x: np.ndarray, y, seed: int) -> dict[str, np.ndarray]:
    x, y = np.asarray(x, dtype=float), np.asarray(y).astype(int)
    if min(y.sum(), len(y) - y.sum()) < MIN_CLASS_COUNT:
        raise NormaliseError(f"too few anomalies to split ({int(y.sum())})")
    idx = np.arange(len(y))
    train, rest = train_test_split(idx, train_size=0.70, stratify=y, random_state=seed)
    val, test = train_test_split(rest, train_size=0.5, stratify=y[rest], random_state=seed)
    median = np.nanmedian(x[train], axis=0)

    def fill(a: np.ndarray) -> np.ndarray:
        return np.where(np.isnan(a), median, a)

    filled = fill(None)
    mean, scale = filled.mean(axis=0), filled.std(axis=0)
    scale = np.where(scale == 0, 1.0, scale)
    out: dict[str, np.ndarray] = {
        "mean": mean,
        "scale": scale,
        "idx_train": train,
        "idx_val": val,
        "idx_test": test,
    }
    for name, rows in (("train", train), ("val", val), ("test", test)):
        out[f"x_{name}"] = (fill(x[rows]) - mean) / scale
        out[f"y_{name}"] = y[rows]
    return out


def x_split__mutmut_53(x: np.ndarray, y, seed: int) -> dict[str, np.ndarray]:
    x, y = np.asarray(x, dtype=float), np.asarray(y).astype(int)
    if min(y.sum(), len(y) - y.sum()) < MIN_CLASS_COUNT:
        raise NormaliseError(f"too few anomalies to split ({int(y.sum())})")
    idx = np.arange(len(y))
    train, rest = train_test_split(idx, train_size=0.70, stratify=y, random_state=seed)
    val, test = train_test_split(rest, train_size=0.5, stratify=y[rest], random_state=seed)
    median = np.nanmedian(x[train], axis=0)

    def fill(a: np.ndarray) -> np.ndarray:
        return np.where(np.isnan(a), median, a)

    filled = fill(x[train])
    mean, scale = None
    scale = np.where(scale == 0, 1.0, scale)
    out: dict[str, np.ndarray] = {
        "mean": mean,
        "scale": scale,
        "idx_train": train,
        "idx_val": val,
        "idx_test": test,
    }
    for name, rows in (("train", train), ("val", val), ("test", test)):
        out[f"x_{name}"] = (fill(x[rows]) - mean) / scale
        out[f"y_{name}"] = y[rows]
    return out


def x_split__mutmut_54(x: np.ndarray, y, seed: int) -> dict[str, np.ndarray]:
    x, y = np.asarray(x, dtype=float), np.asarray(y).astype(int)
    if min(y.sum(), len(y) - y.sum()) < MIN_CLASS_COUNT:
        raise NormaliseError(f"too few anomalies to split ({int(y.sum())})")
    idx = np.arange(len(y))
    train, rest = train_test_split(idx, train_size=0.70, stratify=y, random_state=seed)
    val, test = train_test_split(rest, train_size=0.5, stratify=y[rest], random_state=seed)
    median = np.nanmedian(x[train], axis=0)

    def fill(a: np.ndarray) -> np.ndarray:
        return np.where(np.isnan(a), median, a)

    filled = fill(x[train])
    mean, scale = filled.mean(axis=None), filled.std(axis=0)
    scale = np.where(scale == 0, 1.0, scale)
    out: dict[str, np.ndarray] = {
        "mean": mean,
        "scale": scale,
        "idx_train": train,
        "idx_val": val,
        "idx_test": test,
    }
    for name, rows in (("train", train), ("val", val), ("test", test)):
        out[f"x_{name}"] = (fill(x[rows]) - mean) / scale
        out[f"y_{name}"] = y[rows]
    return out


def x_split__mutmut_55(x: np.ndarray, y, seed: int) -> dict[str, np.ndarray]:
    x, y = np.asarray(x, dtype=float), np.asarray(y).astype(int)
    if min(y.sum(), len(y) - y.sum()) < MIN_CLASS_COUNT:
        raise NormaliseError(f"too few anomalies to split ({int(y.sum())})")
    idx = np.arange(len(y))
    train, rest = train_test_split(idx, train_size=0.70, stratify=y, random_state=seed)
    val, test = train_test_split(rest, train_size=0.5, stratify=y[rest], random_state=seed)
    median = np.nanmedian(x[train], axis=0)

    def fill(a: np.ndarray) -> np.ndarray:
        return np.where(np.isnan(a), median, a)

    filled = fill(x[train])
    mean, scale = filled.mean(axis=1), filled.std(axis=0)
    scale = np.where(scale == 0, 1.0, scale)
    out: dict[str, np.ndarray] = {
        "mean": mean,
        "scale": scale,
        "idx_train": train,
        "idx_val": val,
        "idx_test": test,
    }
    for name, rows in (("train", train), ("val", val), ("test", test)):
        out[f"x_{name}"] = (fill(x[rows]) - mean) / scale
        out[f"y_{name}"] = y[rows]
    return out


def x_split__mutmut_56(x: np.ndarray, y, seed: int) -> dict[str, np.ndarray]:
    x, y = np.asarray(x, dtype=float), np.asarray(y).astype(int)
    if min(y.sum(), len(y) - y.sum()) < MIN_CLASS_COUNT:
        raise NormaliseError(f"too few anomalies to split ({int(y.sum())})")
    idx = np.arange(len(y))
    train, rest = train_test_split(idx, train_size=0.70, stratify=y, random_state=seed)
    val, test = train_test_split(rest, train_size=0.5, stratify=y[rest], random_state=seed)
    median = np.nanmedian(x[train], axis=0)

    def fill(a: np.ndarray) -> np.ndarray:
        return np.where(np.isnan(a), median, a)

    filled = fill(x[train])
    mean, scale = filled.mean(axis=0), filled.std(axis=None)
    scale = np.where(scale == 0, 1.0, scale)
    out: dict[str, np.ndarray] = {
        "mean": mean,
        "scale": scale,
        "idx_train": train,
        "idx_val": val,
        "idx_test": test,
    }
    for name, rows in (("train", train), ("val", val), ("test", test)):
        out[f"x_{name}"] = (fill(x[rows]) - mean) / scale
        out[f"y_{name}"] = y[rows]
    return out


def x_split__mutmut_57(x: np.ndarray, y, seed: int) -> dict[str, np.ndarray]:
    x, y = np.asarray(x, dtype=float), np.asarray(y).astype(int)
    if min(y.sum(), len(y) - y.sum()) < MIN_CLASS_COUNT:
        raise NormaliseError(f"too few anomalies to split ({int(y.sum())})")
    idx = np.arange(len(y))
    train, rest = train_test_split(idx, train_size=0.70, stratify=y, random_state=seed)
    val, test = train_test_split(rest, train_size=0.5, stratify=y[rest], random_state=seed)
    median = np.nanmedian(x[train], axis=0)

    def fill(a: np.ndarray) -> np.ndarray:
        return np.where(np.isnan(a), median, a)

    filled = fill(x[train])
    mean, scale = filled.mean(axis=0), filled.std(axis=1)
    scale = np.where(scale == 0, 1.0, scale)
    out: dict[str, np.ndarray] = {
        "mean": mean,
        "scale": scale,
        "idx_train": train,
        "idx_val": val,
        "idx_test": test,
    }
    for name, rows in (("train", train), ("val", val), ("test", test)):
        out[f"x_{name}"] = (fill(x[rows]) - mean) / scale
        out[f"y_{name}"] = y[rows]
    return out


def x_split__mutmut_58(x: np.ndarray, y, seed: int) -> dict[str, np.ndarray]:
    x, y = np.asarray(x, dtype=float), np.asarray(y).astype(int)
    if min(y.sum(), len(y) - y.sum()) < MIN_CLASS_COUNT:
        raise NormaliseError(f"too few anomalies to split ({int(y.sum())})")
    idx = np.arange(len(y))
    train, rest = train_test_split(idx, train_size=0.70, stratify=y, random_state=seed)
    val, test = train_test_split(rest, train_size=0.5, stratify=y[rest], random_state=seed)
    median = np.nanmedian(x[train], axis=0)

    def fill(a: np.ndarray) -> np.ndarray:
        return np.where(np.isnan(a), median, a)

    filled = fill(x[train])
    mean, scale = filled.mean(axis=0), filled.std(axis=0)
    scale = None
    out: dict[str, np.ndarray] = {
        "mean": mean,
        "scale": scale,
        "idx_train": train,
        "idx_val": val,
        "idx_test": test,
    }
    for name, rows in (("train", train), ("val", val), ("test", test)):
        out[f"x_{name}"] = (fill(x[rows]) - mean) / scale
        out[f"y_{name}"] = y[rows]
    return out


def x_split__mutmut_59(x: np.ndarray, y, seed: int) -> dict[str, np.ndarray]:
    x, y = np.asarray(x, dtype=float), np.asarray(y).astype(int)
    if min(y.sum(), len(y) - y.sum()) < MIN_CLASS_COUNT:
        raise NormaliseError(f"too few anomalies to split ({int(y.sum())})")
    idx = np.arange(len(y))
    train, rest = train_test_split(idx, train_size=0.70, stratify=y, random_state=seed)
    val, test = train_test_split(rest, train_size=0.5, stratify=y[rest], random_state=seed)
    median = np.nanmedian(x[train], axis=0)

    def fill(a: np.ndarray) -> np.ndarray:
        return np.where(np.isnan(a), median, a)

    filled = fill(x[train])
    mean, scale = filled.mean(axis=0), filled.std(axis=0)
    scale = np.where(None, 1.0, scale)
    out: dict[str, np.ndarray] = {
        "mean": mean,
        "scale": scale,
        "idx_train": train,
        "idx_val": val,
        "idx_test": test,
    }
    for name, rows in (("train", train), ("val", val), ("test", test)):
        out[f"x_{name}"] = (fill(x[rows]) - mean) / scale
        out[f"y_{name}"] = y[rows]
    return out


def x_split__mutmut_60(x: np.ndarray, y, seed: int) -> dict[str, np.ndarray]:
    x, y = np.asarray(x, dtype=float), np.asarray(y).astype(int)
    if min(y.sum(), len(y) - y.sum()) < MIN_CLASS_COUNT:
        raise NormaliseError(f"too few anomalies to split ({int(y.sum())})")
    idx = np.arange(len(y))
    train, rest = train_test_split(idx, train_size=0.70, stratify=y, random_state=seed)
    val, test = train_test_split(rest, train_size=0.5, stratify=y[rest], random_state=seed)
    median = np.nanmedian(x[train], axis=0)

    def fill(a: np.ndarray) -> np.ndarray:
        return np.where(np.isnan(a), median, a)

    filled = fill(x[train])
    mean, scale = filled.mean(axis=0), filled.std(axis=0)
    scale = np.where(scale == 0, None, scale)
    out: dict[str, np.ndarray] = {
        "mean": mean,
        "scale": scale,
        "idx_train": train,
        "idx_val": val,
        "idx_test": test,
    }
    for name, rows in (("train", train), ("val", val), ("test", test)):
        out[f"x_{name}"] = (fill(x[rows]) - mean) / scale
        out[f"y_{name}"] = y[rows]
    return out


def x_split__mutmut_61(x: np.ndarray, y, seed: int) -> dict[str, np.ndarray]:
    x, y = np.asarray(x, dtype=float), np.asarray(y).astype(int)
    if min(y.sum(), len(y) - y.sum()) < MIN_CLASS_COUNT:
        raise NormaliseError(f"too few anomalies to split ({int(y.sum())})")
    idx = np.arange(len(y))
    train, rest = train_test_split(idx, train_size=0.70, stratify=y, random_state=seed)
    val, test = train_test_split(rest, train_size=0.5, stratify=y[rest], random_state=seed)
    median = np.nanmedian(x[train], axis=0)

    def fill(a: np.ndarray) -> np.ndarray:
        return np.where(np.isnan(a), median, a)

    filled = fill(x[train])
    mean, scale = filled.mean(axis=0), filled.std(axis=0)
    scale = np.where(scale == 0, 1.0, None)
    out: dict[str, np.ndarray] = {
        "mean": mean,
        "scale": scale,
        "idx_train": train,
        "idx_val": val,
        "idx_test": test,
    }
    for name, rows in (("train", train), ("val", val), ("test", test)):
        out[f"x_{name}"] = (fill(x[rows]) - mean) / scale
        out[f"y_{name}"] = y[rows]
    return out


def x_split__mutmut_62(x: np.ndarray, y, seed: int) -> dict[str, np.ndarray]:
    x, y = np.asarray(x, dtype=float), np.asarray(y).astype(int)
    if min(y.sum(), len(y) - y.sum()) < MIN_CLASS_COUNT:
        raise NormaliseError(f"too few anomalies to split ({int(y.sum())})")
    idx = np.arange(len(y))
    train, rest = train_test_split(idx, train_size=0.70, stratify=y, random_state=seed)
    val, test = train_test_split(rest, train_size=0.5, stratify=y[rest], random_state=seed)
    median = np.nanmedian(x[train], axis=0)

    def fill(a: np.ndarray) -> np.ndarray:
        return np.where(np.isnan(a), median, a)

    filled = fill(x[train])
    mean, scale = filled.mean(axis=0), filled.std(axis=0)
    scale = np.where(1.0, scale)
    out: dict[str, np.ndarray] = {
        "mean": mean,
        "scale": scale,
        "idx_train": train,
        "idx_val": val,
        "idx_test": test,
    }
    for name, rows in (("train", train), ("val", val), ("test", test)):
        out[f"x_{name}"] = (fill(x[rows]) - mean) / scale
        out[f"y_{name}"] = y[rows]
    return out


def x_split__mutmut_63(x: np.ndarray, y, seed: int) -> dict[str, np.ndarray]:
    x, y = np.asarray(x, dtype=float), np.asarray(y).astype(int)
    if min(y.sum(), len(y) - y.sum()) < MIN_CLASS_COUNT:
        raise NormaliseError(f"too few anomalies to split ({int(y.sum())})")
    idx = np.arange(len(y))
    train, rest = train_test_split(idx, train_size=0.70, stratify=y, random_state=seed)
    val, test = train_test_split(rest, train_size=0.5, stratify=y[rest], random_state=seed)
    median = np.nanmedian(x[train], axis=0)

    def fill(a: np.ndarray) -> np.ndarray:
        return np.where(np.isnan(a), median, a)

    filled = fill(x[train])
    mean, scale = filled.mean(axis=0), filled.std(axis=0)
    scale = np.where(scale == 0, scale)
    out: dict[str, np.ndarray] = {
        "mean": mean,
        "scale": scale,
        "idx_train": train,
        "idx_val": val,
        "idx_test": test,
    }
    for name, rows in (("train", train), ("val", val), ("test", test)):
        out[f"x_{name}"] = (fill(x[rows]) - mean) / scale
        out[f"y_{name}"] = y[rows]
    return out


def x_split__mutmut_64(x: np.ndarray, y, seed: int) -> dict[str, np.ndarray]:
    x, y = np.asarray(x, dtype=float), np.asarray(y).astype(int)
    if min(y.sum(), len(y) - y.sum()) < MIN_CLASS_COUNT:
        raise NormaliseError(f"too few anomalies to split ({int(y.sum())})")
    idx = np.arange(len(y))
    train, rest = train_test_split(idx, train_size=0.70, stratify=y, random_state=seed)
    val, test = train_test_split(rest, train_size=0.5, stratify=y[rest], random_state=seed)
    median = np.nanmedian(x[train], axis=0)

    def fill(a: np.ndarray) -> np.ndarray:
        return np.where(np.isnan(a), median, a)

    filled = fill(x[train])
    mean, scale = filled.mean(axis=0), filled.std(axis=0)
    scale = np.where(scale == 0, 1.0, )
    out: dict[str, np.ndarray] = {
        "mean": mean,
        "scale": scale,
        "idx_train": train,
        "idx_val": val,
        "idx_test": test,
    }
    for name, rows in (("train", train), ("val", val), ("test", test)):
        out[f"x_{name}"] = (fill(x[rows]) - mean) / scale
        out[f"y_{name}"] = y[rows]
    return out


def x_split__mutmut_65(x: np.ndarray, y, seed: int) -> dict[str, np.ndarray]:
    x, y = np.asarray(x, dtype=float), np.asarray(y).astype(int)
    if min(y.sum(), len(y) - y.sum()) < MIN_CLASS_COUNT:
        raise NormaliseError(f"too few anomalies to split ({int(y.sum())})")
    idx = np.arange(len(y))
    train, rest = train_test_split(idx, train_size=0.70, stratify=y, random_state=seed)
    val, test = train_test_split(rest, train_size=0.5, stratify=y[rest], random_state=seed)
    median = np.nanmedian(x[train], axis=0)

    def fill(a: np.ndarray) -> np.ndarray:
        return np.where(np.isnan(a), median, a)

    filled = fill(x[train])
    mean, scale = filled.mean(axis=0), filled.std(axis=0)
    scale = np.where(scale != 0, 1.0, scale)
    out: dict[str, np.ndarray] = {
        "mean": mean,
        "scale": scale,
        "idx_train": train,
        "idx_val": val,
        "idx_test": test,
    }
    for name, rows in (("train", train), ("val", val), ("test", test)):
        out[f"x_{name}"] = (fill(x[rows]) - mean) / scale
        out[f"y_{name}"] = y[rows]
    return out


def x_split__mutmut_66(x: np.ndarray, y, seed: int) -> dict[str, np.ndarray]:
    x, y = np.asarray(x, dtype=float), np.asarray(y).astype(int)
    if min(y.sum(), len(y) - y.sum()) < MIN_CLASS_COUNT:
        raise NormaliseError(f"too few anomalies to split ({int(y.sum())})")
    idx = np.arange(len(y))
    train, rest = train_test_split(idx, train_size=0.70, stratify=y, random_state=seed)
    val, test = train_test_split(rest, train_size=0.5, stratify=y[rest], random_state=seed)
    median = np.nanmedian(x[train], axis=0)

    def fill(a: np.ndarray) -> np.ndarray:
        return np.where(np.isnan(a), median, a)

    filled = fill(x[train])
    mean, scale = filled.mean(axis=0), filled.std(axis=0)
    scale = np.where(scale == 1, 1.0, scale)
    out: dict[str, np.ndarray] = {
        "mean": mean,
        "scale": scale,
        "idx_train": train,
        "idx_val": val,
        "idx_test": test,
    }
    for name, rows in (("train", train), ("val", val), ("test", test)):
        out[f"x_{name}"] = (fill(x[rows]) - mean) / scale
        out[f"y_{name}"] = y[rows]
    return out


def x_split__mutmut_67(x: np.ndarray, y, seed: int) -> dict[str, np.ndarray]:
    x, y = np.asarray(x, dtype=float), np.asarray(y).astype(int)
    if min(y.sum(), len(y) - y.sum()) < MIN_CLASS_COUNT:
        raise NormaliseError(f"too few anomalies to split ({int(y.sum())})")
    idx = np.arange(len(y))
    train, rest = train_test_split(idx, train_size=0.70, stratify=y, random_state=seed)
    val, test = train_test_split(rest, train_size=0.5, stratify=y[rest], random_state=seed)
    median = np.nanmedian(x[train], axis=0)

    def fill(a: np.ndarray) -> np.ndarray:
        return np.where(np.isnan(a), median, a)

    filled = fill(x[train])
    mean, scale = filled.mean(axis=0), filled.std(axis=0)
    scale = np.where(scale == 0, 2.0, scale)
    out: dict[str, np.ndarray] = {
        "mean": mean,
        "scale": scale,
        "idx_train": train,
        "idx_val": val,
        "idx_test": test,
    }
    for name, rows in (("train", train), ("val", val), ("test", test)):
        out[f"x_{name}"] = (fill(x[rows]) - mean) / scale
        out[f"y_{name}"] = y[rows]
    return out


def x_split__mutmut_68(x: np.ndarray, y, seed: int) -> dict[str, np.ndarray]:
    x, y = np.asarray(x, dtype=float), np.asarray(y).astype(int)
    if min(y.sum(), len(y) - y.sum()) < MIN_CLASS_COUNT:
        raise NormaliseError(f"too few anomalies to split ({int(y.sum())})")
    idx = np.arange(len(y))
    train, rest = train_test_split(idx, train_size=0.70, stratify=y, random_state=seed)
    val, test = train_test_split(rest, train_size=0.5, stratify=y[rest], random_state=seed)
    median = np.nanmedian(x[train], axis=0)

    def fill(a: np.ndarray) -> np.ndarray:
        return np.where(np.isnan(a), median, a)

    filled = fill(x[train])
    mean, scale = filled.mean(axis=0), filled.std(axis=0)
    scale = np.where(scale == 0, 1.0, scale)
    out: dict[str, np.ndarray] = None
    for name, rows in (("train", train), ("val", val), ("test", test)):
        out[f"x_{name}"] = (fill(x[rows]) - mean) / scale
        out[f"y_{name}"] = y[rows]
    return out


def x_split__mutmut_69(x: np.ndarray, y, seed: int) -> dict[str, np.ndarray]:
    x, y = np.asarray(x, dtype=float), np.asarray(y).astype(int)
    if min(y.sum(), len(y) - y.sum()) < MIN_CLASS_COUNT:
        raise NormaliseError(f"too few anomalies to split ({int(y.sum())})")
    idx = np.arange(len(y))
    train, rest = train_test_split(idx, train_size=0.70, stratify=y, random_state=seed)
    val, test = train_test_split(rest, train_size=0.5, stratify=y[rest], random_state=seed)
    median = np.nanmedian(x[train], axis=0)

    def fill(a: np.ndarray) -> np.ndarray:
        return np.where(np.isnan(a), median, a)

    filled = fill(x[train])
    mean, scale = filled.mean(axis=0), filled.std(axis=0)
    scale = np.where(scale == 0, 1.0, scale)
    out: dict[str, np.ndarray] = {
        "XXmeanXX": mean,
        "scale": scale,
        "idx_train": train,
        "idx_val": val,
        "idx_test": test,
    }
    for name, rows in (("train", train), ("val", val), ("test", test)):
        out[f"x_{name}"] = (fill(x[rows]) - mean) / scale
        out[f"y_{name}"] = y[rows]
    return out


def x_split__mutmut_70(x: np.ndarray, y, seed: int) -> dict[str, np.ndarray]:
    x, y = np.asarray(x, dtype=float), np.asarray(y).astype(int)
    if min(y.sum(), len(y) - y.sum()) < MIN_CLASS_COUNT:
        raise NormaliseError(f"too few anomalies to split ({int(y.sum())})")
    idx = np.arange(len(y))
    train, rest = train_test_split(idx, train_size=0.70, stratify=y, random_state=seed)
    val, test = train_test_split(rest, train_size=0.5, stratify=y[rest], random_state=seed)
    median = np.nanmedian(x[train], axis=0)

    def fill(a: np.ndarray) -> np.ndarray:
        return np.where(np.isnan(a), median, a)

    filled = fill(x[train])
    mean, scale = filled.mean(axis=0), filled.std(axis=0)
    scale = np.where(scale == 0, 1.0, scale)
    out: dict[str, np.ndarray] = {
        "MEAN": mean,
        "scale": scale,
        "idx_train": train,
        "idx_val": val,
        "idx_test": test,
    }
    for name, rows in (("train", train), ("val", val), ("test", test)):
        out[f"x_{name}"] = (fill(x[rows]) - mean) / scale
        out[f"y_{name}"] = y[rows]
    return out


def x_split__mutmut_71(x: np.ndarray, y, seed: int) -> dict[str, np.ndarray]:
    x, y = np.asarray(x, dtype=float), np.asarray(y).astype(int)
    if min(y.sum(), len(y) - y.sum()) < MIN_CLASS_COUNT:
        raise NormaliseError(f"too few anomalies to split ({int(y.sum())})")
    idx = np.arange(len(y))
    train, rest = train_test_split(idx, train_size=0.70, stratify=y, random_state=seed)
    val, test = train_test_split(rest, train_size=0.5, stratify=y[rest], random_state=seed)
    median = np.nanmedian(x[train], axis=0)

    def fill(a: np.ndarray) -> np.ndarray:
        return np.where(np.isnan(a), median, a)

    filled = fill(x[train])
    mean, scale = filled.mean(axis=0), filled.std(axis=0)
    scale = np.where(scale == 0, 1.0, scale)
    out: dict[str, np.ndarray] = {
        "mean": mean,
        "XXscaleXX": scale,
        "idx_train": train,
        "idx_val": val,
        "idx_test": test,
    }
    for name, rows in (("train", train), ("val", val), ("test", test)):
        out[f"x_{name}"] = (fill(x[rows]) - mean) / scale
        out[f"y_{name}"] = y[rows]
    return out


def x_split__mutmut_72(x: np.ndarray, y, seed: int) -> dict[str, np.ndarray]:
    x, y = np.asarray(x, dtype=float), np.asarray(y).astype(int)
    if min(y.sum(), len(y) - y.sum()) < MIN_CLASS_COUNT:
        raise NormaliseError(f"too few anomalies to split ({int(y.sum())})")
    idx = np.arange(len(y))
    train, rest = train_test_split(idx, train_size=0.70, stratify=y, random_state=seed)
    val, test = train_test_split(rest, train_size=0.5, stratify=y[rest], random_state=seed)
    median = np.nanmedian(x[train], axis=0)

    def fill(a: np.ndarray) -> np.ndarray:
        return np.where(np.isnan(a), median, a)

    filled = fill(x[train])
    mean, scale = filled.mean(axis=0), filled.std(axis=0)
    scale = np.where(scale == 0, 1.0, scale)
    out: dict[str, np.ndarray] = {
        "mean": mean,
        "SCALE": scale,
        "idx_train": train,
        "idx_val": val,
        "idx_test": test,
    }
    for name, rows in (("train", train), ("val", val), ("test", test)):
        out[f"x_{name}"] = (fill(x[rows]) - mean) / scale
        out[f"y_{name}"] = y[rows]
    return out


def x_split__mutmut_73(x: np.ndarray, y, seed: int) -> dict[str, np.ndarray]:
    x, y = np.asarray(x, dtype=float), np.asarray(y).astype(int)
    if min(y.sum(), len(y) - y.sum()) < MIN_CLASS_COUNT:
        raise NormaliseError(f"too few anomalies to split ({int(y.sum())})")
    idx = np.arange(len(y))
    train, rest = train_test_split(idx, train_size=0.70, stratify=y, random_state=seed)
    val, test = train_test_split(rest, train_size=0.5, stratify=y[rest], random_state=seed)
    median = np.nanmedian(x[train], axis=0)

    def fill(a: np.ndarray) -> np.ndarray:
        return np.where(np.isnan(a), median, a)

    filled = fill(x[train])
    mean, scale = filled.mean(axis=0), filled.std(axis=0)
    scale = np.where(scale == 0, 1.0, scale)
    out: dict[str, np.ndarray] = {
        "mean": mean,
        "scale": scale,
        "XXidx_trainXX": train,
        "idx_val": val,
        "idx_test": test,
    }
    for name, rows in (("train", train), ("val", val), ("test", test)):
        out[f"x_{name}"] = (fill(x[rows]) - mean) / scale
        out[f"y_{name}"] = y[rows]
    return out


def x_split__mutmut_74(x: np.ndarray, y, seed: int) -> dict[str, np.ndarray]:
    x, y = np.asarray(x, dtype=float), np.asarray(y).astype(int)
    if min(y.sum(), len(y) - y.sum()) < MIN_CLASS_COUNT:
        raise NormaliseError(f"too few anomalies to split ({int(y.sum())})")
    idx = np.arange(len(y))
    train, rest = train_test_split(idx, train_size=0.70, stratify=y, random_state=seed)
    val, test = train_test_split(rest, train_size=0.5, stratify=y[rest], random_state=seed)
    median = np.nanmedian(x[train], axis=0)

    def fill(a: np.ndarray) -> np.ndarray:
        return np.where(np.isnan(a), median, a)

    filled = fill(x[train])
    mean, scale = filled.mean(axis=0), filled.std(axis=0)
    scale = np.where(scale == 0, 1.0, scale)
    out: dict[str, np.ndarray] = {
        "mean": mean,
        "scale": scale,
        "IDX_TRAIN": train,
        "idx_val": val,
        "idx_test": test,
    }
    for name, rows in (("train", train), ("val", val), ("test", test)):
        out[f"x_{name}"] = (fill(x[rows]) - mean) / scale
        out[f"y_{name}"] = y[rows]
    return out


def x_split__mutmut_75(x: np.ndarray, y, seed: int) -> dict[str, np.ndarray]:
    x, y = np.asarray(x, dtype=float), np.asarray(y).astype(int)
    if min(y.sum(), len(y) - y.sum()) < MIN_CLASS_COUNT:
        raise NormaliseError(f"too few anomalies to split ({int(y.sum())})")
    idx = np.arange(len(y))
    train, rest = train_test_split(idx, train_size=0.70, stratify=y, random_state=seed)
    val, test = train_test_split(rest, train_size=0.5, stratify=y[rest], random_state=seed)
    median = np.nanmedian(x[train], axis=0)

    def fill(a: np.ndarray) -> np.ndarray:
        return np.where(np.isnan(a), median, a)

    filled = fill(x[train])
    mean, scale = filled.mean(axis=0), filled.std(axis=0)
    scale = np.where(scale == 0, 1.0, scale)
    out: dict[str, np.ndarray] = {
        "mean": mean,
        "scale": scale,
        "idx_train": train,
        "XXidx_valXX": val,
        "idx_test": test,
    }
    for name, rows in (("train", train), ("val", val), ("test", test)):
        out[f"x_{name}"] = (fill(x[rows]) - mean) / scale
        out[f"y_{name}"] = y[rows]
    return out


def x_split__mutmut_76(x: np.ndarray, y, seed: int) -> dict[str, np.ndarray]:
    x, y = np.asarray(x, dtype=float), np.asarray(y).astype(int)
    if min(y.sum(), len(y) - y.sum()) < MIN_CLASS_COUNT:
        raise NormaliseError(f"too few anomalies to split ({int(y.sum())})")
    idx = np.arange(len(y))
    train, rest = train_test_split(idx, train_size=0.70, stratify=y, random_state=seed)
    val, test = train_test_split(rest, train_size=0.5, stratify=y[rest], random_state=seed)
    median = np.nanmedian(x[train], axis=0)

    def fill(a: np.ndarray) -> np.ndarray:
        return np.where(np.isnan(a), median, a)

    filled = fill(x[train])
    mean, scale = filled.mean(axis=0), filled.std(axis=0)
    scale = np.where(scale == 0, 1.0, scale)
    out: dict[str, np.ndarray] = {
        "mean": mean,
        "scale": scale,
        "idx_train": train,
        "IDX_VAL": val,
        "idx_test": test,
    }
    for name, rows in (("train", train), ("val", val), ("test", test)):
        out[f"x_{name}"] = (fill(x[rows]) - mean) / scale
        out[f"y_{name}"] = y[rows]
    return out


def x_split__mutmut_77(x: np.ndarray, y, seed: int) -> dict[str, np.ndarray]:
    x, y = np.asarray(x, dtype=float), np.asarray(y).astype(int)
    if min(y.sum(), len(y) - y.sum()) < MIN_CLASS_COUNT:
        raise NormaliseError(f"too few anomalies to split ({int(y.sum())})")
    idx = np.arange(len(y))
    train, rest = train_test_split(idx, train_size=0.70, stratify=y, random_state=seed)
    val, test = train_test_split(rest, train_size=0.5, stratify=y[rest], random_state=seed)
    median = np.nanmedian(x[train], axis=0)

    def fill(a: np.ndarray) -> np.ndarray:
        return np.where(np.isnan(a), median, a)

    filled = fill(x[train])
    mean, scale = filled.mean(axis=0), filled.std(axis=0)
    scale = np.where(scale == 0, 1.0, scale)
    out: dict[str, np.ndarray] = {
        "mean": mean,
        "scale": scale,
        "idx_train": train,
        "idx_val": val,
        "XXidx_testXX": test,
    }
    for name, rows in (("train", train), ("val", val), ("test", test)):
        out[f"x_{name}"] = (fill(x[rows]) - mean) / scale
        out[f"y_{name}"] = y[rows]
    return out


def x_split__mutmut_78(x: np.ndarray, y, seed: int) -> dict[str, np.ndarray]:
    x, y = np.asarray(x, dtype=float), np.asarray(y).astype(int)
    if min(y.sum(), len(y) - y.sum()) < MIN_CLASS_COUNT:
        raise NormaliseError(f"too few anomalies to split ({int(y.sum())})")
    idx = np.arange(len(y))
    train, rest = train_test_split(idx, train_size=0.70, stratify=y, random_state=seed)
    val, test = train_test_split(rest, train_size=0.5, stratify=y[rest], random_state=seed)
    median = np.nanmedian(x[train], axis=0)

    def fill(a: np.ndarray) -> np.ndarray:
        return np.where(np.isnan(a), median, a)

    filled = fill(x[train])
    mean, scale = filled.mean(axis=0), filled.std(axis=0)
    scale = np.where(scale == 0, 1.0, scale)
    out: dict[str, np.ndarray] = {
        "mean": mean,
        "scale": scale,
        "idx_train": train,
        "idx_val": val,
        "IDX_TEST": test,
    }
    for name, rows in (("train", train), ("val", val), ("test", test)):
        out[f"x_{name}"] = (fill(x[rows]) - mean) / scale
        out[f"y_{name}"] = y[rows]
    return out


def x_split__mutmut_79(x: np.ndarray, y, seed: int) -> dict[str, np.ndarray]:
    x, y = np.asarray(x, dtype=float), np.asarray(y).astype(int)
    if min(y.sum(), len(y) - y.sum()) < MIN_CLASS_COUNT:
        raise NormaliseError(f"too few anomalies to split ({int(y.sum())})")
    idx = np.arange(len(y))
    train, rest = train_test_split(idx, train_size=0.70, stratify=y, random_state=seed)
    val, test = train_test_split(rest, train_size=0.5, stratify=y[rest], random_state=seed)
    median = np.nanmedian(x[train], axis=0)

    def fill(a: np.ndarray) -> np.ndarray:
        return np.where(np.isnan(a), median, a)

    filled = fill(x[train])
    mean, scale = filled.mean(axis=0), filled.std(axis=0)
    scale = np.where(scale == 0, 1.0, scale)
    out: dict[str, np.ndarray] = {
        "mean": mean,
        "scale": scale,
        "idx_train": train,
        "idx_val": val,
        "idx_test": test,
    }
    for name, rows in (("XXtrainXX", train), ("val", val), ("test", test)):
        out[f"x_{name}"] = (fill(x[rows]) - mean) / scale
        out[f"y_{name}"] = y[rows]
    return out


def x_split__mutmut_80(x: np.ndarray, y, seed: int) -> dict[str, np.ndarray]:
    x, y = np.asarray(x, dtype=float), np.asarray(y).astype(int)
    if min(y.sum(), len(y) - y.sum()) < MIN_CLASS_COUNT:
        raise NormaliseError(f"too few anomalies to split ({int(y.sum())})")
    idx = np.arange(len(y))
    train, rest = train_test_split(idx, train_size=0.70, stratify=y, random_state=seed)
    val, test = train_test_split(rest, train_size=0.5, stratify=y[rest], random_state=seed)
    median = np.nanmedian(x[train], axis=0)

    def fill(a: np.ndarray) -> np.ndarray:
        return np.where(np.isnan(a), median, a)

    filled = fill(x[train])
    mean, scale = filled.mean(axis=0), filled.std(axis=0)
    scale = np.where(scale == 0, 1.0, scale)
    out: dict[str, np.ndarray] = {
        "mean": mean,
        "scale": scale,
        "idx_train": train,
        "idx_val": val,
        "idx_test": test,
    }
    for name, rows in (("TRAIN", train), ("val", val), ("test", test)):
        out[f"x_{name}"] = (fill(x[rows]) - mean) / scale
        out[f"y_{name}"] = y[rows]
    return out


def x_split__mutmut_81(x: np.ndarray, y, seed: int) -> dict[str, np.ndarray]:
    x, y = np.asarray(x, dtype=float), np.asarray(y).astype(int)
    if min(y.sum(), len(y) - y.sum()) < MIN_CLASS_COUNT:
        raise NormaliseError(f"too few anomalies to split ({int(y.sum())})")
    idx = np.arange(len(y))
    train, rest = train_test_split(idx, train_size=0.70, stratify=y, random_state=seed)
    val, test = train_test_split(rest, train_size=0.5, stratify=y[rest], random_state=seed)
    median = np.nanmedian(x[train], axis=0)

    def fill(a: np.ndarray) -> np.ndarray:
        return np.where(np.isnan(a), median, a)

    filled = fill(x[train])
    mean, scale = filled.mean(axis=0), filled.std(axis=0)
    scale = np.where(scale == 0, 1.0, scale)
    out: dict[str, np.ndarray] = {
        "mean": mean,
        "scale": scale,
        "idx_train": train,
        "idx_val": val,
        "idx_test": test,
    }
    for name, rows in (("train", train), ("XXvalXX", val), ("test", test)):
        out[f"x_{name}"] = (fill(x[rows]) - mean) / scale
        out[f"y_{name}"] = y[rows]
    return out


def x_split__mutmut_82(x: np.ndarray, y, seed: int) -> dict[str, np.ndarray]:
    x, y = np.asarray(x, dtype=float), np.asarray(y).astype(int)
    if min(y.sum(), len(y) - y.sum()) < MIN_CLASS_COUNT:
        raise NormaliseError(f"too few anomalies to split ({int(y.sum())})")
    idx = np.arange(len(y))
    train, rest = train_test_split(idx, train_size=0.70, stratify=y, random_state=seed)
    val, test = train_test_split(rest, train_size=0.5, stratify=y[rest], random_state=seed)
    median = np.nanmedian(x[train], axis=0)

    def fill(a: np.ndarray) -> np.ndarray:
        return np.where(np.isnan(a), median, a)

    filled = fill(x[train])
    mean, scale = filled.mean(axis=0), filled.std(axis=0)
    scale = np.where(scale == 0, 1.0, scale)
    out: dict[str, np.ndarray] = {
        "mean": mean,
        "scale": scale,
        "idx_train": train,
        "idx_val": val,
        "idx_test": test,
    }
    for name, rows in (("train", train), ("VAL", val), ("test", test)):
        out[f"x_{name}"] = (fill(x[rows]) - mean) / scale
        out[f"y_{name}"] = y[rows]
    return out


def x_split__mutmut_83(x: np.ndarray, y, seed: int) -> dict[str, np.ndarray]:
    x, y = np.asarray(x, dtype=float), np.asarray(y).astype(int)
    if min(y.sum(), len(y) - y.sum()) < MIN_CLASS_COUNT:
        raise NormaliseError(f"too few anomalies to split ({int(y.sum())})")
    idx = np.arange(len(y))
    train, rest = train_test_split(idx, train_size=0.70, stratify=y, random_state=seed)
    val, test = train_test_split(rest, train_size=0.5, stratify=y[rest], random_state=seed)
    median = np.nanmedian(x[train], axis=0)

    def fill(a: np.ndarray) -> np.ndarray:
        return np.where(np.isnan(a), median, a)

    filled = fill(x[train])
    mean, scale = filled.mean(axis=0), filled.std(axis=0)
    scale = np.where(scale == 0, 1.0, scale)
    out: dict[str, np.ndarray] = {
        "mean": mean,
        "scale": scale,
        "idx_train": train,
        "idx_val": val,
        "idx_test": test,
    }
    for name, rows in (("train", train), ("val", val), ("XXtestXX", test)):
        out[f"x_{name}"] = (fill(x[rows]) - mean) / scale
        out[f"y_{name}"] = y[rows]
    return out


def x_split__mutmut_84(x: np.ndarray, y, seed: int) -> dict[str, np.ndarray]:
    x, y = np.asarray(x, dtype=float), np.asarray(y).astype(int)
    if min(y.sum(), len(y) - y.sum()) < MIN_CLASS_COUNT:
        raise NormaliseError(f"too few anomalies to split ({int(y.sum())})")
    idx = np.arange(len(y))
    train, rest = train_test_split(idx, train_size=0.70, stratify=y, random_state=seed)
    val, test = train_test_split(rest, train_size=0.5, stratify=y[rest], random_state=seed)
    median = np.nanmedian(x[train], axis=0)

    def fill(a: np.ndarray) -> np.ndarray:
        return np.where(np.isnan(a), median, a)

    filled = fill(x[train])
    mean, scale = filled.mean(axis=0), filled.std(axis=0)
    scale = np.where(scale == 0, 1.0, scale)
    out: dict[str, np.ndarray] = {
        "mean": mean,
        "scale": scale,
        "idx_train": train,
        "idx_val": val,
        "idx_test": test,
    }
    for name, rows in (("train", train), ("val", val), ("TEST", test)):
        out[f"x_{name}"] = (fill(x[rows]) - mean) / scale
        out[f"y_{name}"] = y[rows]
    return out


def x_split__mutmut_85(x: np.ndarray, y, seed: int) -> dict[str, np.ndarray]:
    x, y = np.asarray(x, dtype=float), np.asarray(y).astype(int)
    if min(y.sum(), len(y) - y.sum()) < MIN_CLASS_COUNT:
        raise NormaliseError(f"too few anomalies to split ({int(y.sum())})")
    idx = np.arange(len(y))
    train, rest = train_test_split(idx, train_size=0.70, stratify=y, random_state=seed)
    val, test = train_test_split(rest, train_size=0.5, stratify=y[rest], random_state=seed)
    median = np.nanmedian(x[train], axis=0)

    def fill(a: np.ndarray) -> np.ndarray:
        return np.where(np.isnan(a), median, a)

    filled = fill(x[train])
    mean, scale = filled.mean(axis=0), filled.std(axis=0)
    scale = np.where(scale == 0, 1.0, scale)
    out: dict[str, np.ndarray] = {
        "mean": mean,
        "scale": scale,
        "idx_train": train,
        "idx_val": val,
        "idx_test": test,
    }
    for name, rows in (("train", train), ("val", val), ("test", test)):
        out[f"x_{name}"] = None
        out[f"y_{name}"] = y[rows]
    return out


def x_split__mutmut_86(x: np.ndarray, y, seed: int) -> dict[str, np.ndarray]:
    x, y = np.asarray(x, dtype=float), np.asarray(y).astype(int)
    if min(y.sum(), len(y) - y.sum()) < MIN_CLASS_COUNT:
        raise NormaliseError(f"too few anomalies to split ({int(y.sum())})")
    idx = np.arange(len(y))
    train, rest = train_test_split(idx, train_size=0.70, stratify=y, random_state=seed)
    val, test = train_test_split(rest, train_size=0.5, stratify=y[rest], random_state=seed)
    median = np.nanmedian(x[train], axis=0)

    def fill(a: np.ndarray) -> np.ndarray:
        return np.where(np.isnan(a), median, a)

    filled = fill(x[train])
    mean, scale = filled.mean(axis=0), filled.std(axis=0)
    scale = np.where(scale == 0, 1.0, scale)
    out: dict[str, np.ndarray] = {
        "mean": mean,
        "scale": scale,
        "idx_train": train,
        "idx_val": val,
        "idx_test": test,
    }
    for name, rows in (("train", train), ("val", val), ("test", test)):
        out[f"x_{name}"] = (fill(x[rows]) - mean) * scale
        out[f"y_{name}"] = y[rows]
    return out


def x_split__mutmut_87(x: np.ndarray, y, seed: int) -> dict[str, np.ndarray]:
    x, y = np.asarray(x, dtype=float), np.asarray(y).astype(int)
    if min(y.sum(), len(y) - y.sum()) < MIN_CLASS_COUNT:
        raise NormaliseError(f"too few anomalies to split ({int(y.sum())})")
    idx = np.arange(len(y))
    train, rest = train_test_split(idx, train_size=0.70, stratify=y, random_state=seed)
    val, test = train_test_split(rest, train_size=0.5, stratify=y[rest], random_state=seed)
    median = np.nanmedian(x[train], axis=0)

    def fill(a: np.ndarray) -> np.ndarray:
        return np.where(np.isnan(a), median, a)

    filled = fill(x[train])
    mean, scale = filled.mean(axis=0), filled.std(axis=0)
    scale = np.where(scale == 0, 1.0, scale)
    out: dict[str, np.ndarray] = {
        "mean": mean,
        "scale": scale,
        "idx_train": train,
        "idx_val": val,
        "idx_test": test,
    }
    for name, rows in (("train", train), ("val", val), ("test", test)):
        out[f"x_{name}"] = (fill(x[rows]) + mean) / scale
        out[f"y_{name}"] = y[rows]
    return out


def x_split__mutmut_88(x: np.ndarray, y, seed: int) -> dict[str, np.ndarray]:
    x, y = np.asarray(x, dtype=float), np.asarray(y).astype(int)
    if min(y.sum(), len(y) - y.sum()) < MIN_CLASS_COUNT:
        raise NormaliseError(f"too few anomalies to split ({int(y.sum())})")
    idx = np.arange(len(y))
    train, rest = train_test_split(idx, train_size=0.70, stratify=y, random_state=seed)
    val, test = train_test_split(rest, train_size=0.5, stratify=y[rest], random_state=seed)
    median = np.nanmedian(x[train], axis=0)

    def fill(a: np.ndarray) -> np.ndarray:
        return np.where(np.isnan(a), median, a)

    filled = fill(x[train])
    mean, scale = filled.mean(axis=0), filled.std(axis=0)
    scale = np.where(scale == 0, 1.0, scale)
    out: dict[str, np.ndarray] = {
        "mean": mean,
        "scale": scale,
        "idx_train": train,
        "idx_val": val,
        "idx_test": test,
    }
    for name, rows in (("train", train), ("val", val), ("test", test)):
        out[f"x_{name}"] = (fill(None) - mean) / scale
        out[f"y_{name}"] = y[rows]
    return out


def x_split__mutmut_89(x: np.ndarray, y, seed: int) -> dict[str, np.ndarray]:
    x, y = np.asarray(x, dtype=float), np.asarray(y).astype(int)
    if min(y.sum(), len(y) - y.sum()) < MIN_CLASS_COUNT:
        raise NormaliseError(f"too few anomalies to split ({int(y.sum())})")
    idx = np.arange(len(y))
    train, rest = train_test_split(idx, train_size=0.70, stratify=y, random_state=seed)
    val, test = train_test_split(rest, train_size=0.5, stratify=y[rest], random_state=seed)
    median = np.nanmedian(x[train], axis=0)

    def fill(a: np.ndarray) -> np.ndarray:
        return np.where(np.isnan(a), median, a)

    filled = fill(x[train])
    mean, scale = filled.mean(axis=0), filled.std(axis=0)
    scale = np.where(scale == 0, 1.0, scale)
    out: dict[str, np.ndarray] = {
        "mean": mean,
        "scale": scale,
        "idx_train": train,
        "idx_val": val,
        "idx_test": test,
    }
    for name, rows in (("train", train), ("val", val), ("test", test)):
        out[f"x_{name}"] = (fill(x[rows]) - mean) / scale
        out[f"y_{name}"] = None
    return out

mutants_x_split__mutmut['_mutmut_orig'] = x_split__mutmut_orig # type: ignore # mutmut generated
mutants_x_split__mutmut['x_split__mutmut_1'] = x_split__mutmut_1 # type: ignore # mutmut generated
mutants_x_split__mutmut['x_split__mutmut_2'] = x_split__mutmut_2 # type: ignore # mutmut generated
mutants_x_split__mutmut['x_split__mutmut_3'] = x_split__mutmut_3 # type: ignore # mutmut generated
mutants_x_split__mutmut['x_split__mutmut_4'] = x_split__mutmut_4 # type: ignore # mutmut generated
mutants_x_split__mutmut['x_split__mutmut_5'] = x_split__mutmut_5 # type: ignore # mutmut generated
mutants_x_split__mutmut['x_split__mutmut_6'] = x_split__mutmut_6 # type: ignore # mutmut generated
mutants_x_split__mutmut['x_split__mutmut_7'] = x_split__mutmut_7 # type: ignore # mutmut generated
mutants_x_split__mutmut['x_split__mutmut_8'] = x_split__mutmut_8 # type: ignore # mutmut generated
mutants_x_split__mutmut['x_split__mutmut_9'] = x_split__mutmut_9 # type: ignore # mutmut generated
mutants_x_split__mutmut['x_split__mutmut_10'] = x_split__mutmut_10 # type: ignore # mutmut generated
mutants_x_split__mutmut['x_split__mutmut_11'] = x_split__mutmut_11 # type: ignore # mutmut generated
mutants_x_split__mutmut['x_split__mutmut_12'] = x_split__mutmut_12 # type: ignore # mutmut generated
mutants_x_split__mutmut['x_split__mutmut_13'] = x_split__mutmut_13 # type: ignore # mutmut generated
mutants_x_split__mutmut['x_split__mutmut_14'] = x_split__mutmut_14 # type: ignore # mutmut generated
mutants_x_split__mutmut['x_split__mutmut_15'] = x_split__mutmut_15 # type: ignore # mutmut generated
mutants_x_split__mutmut['x_split__mutmut_16'] = x_split__mutmut_16 # type: ignore # mutmut generated
mutants_x_split__mutmut['x_split__mutmut_17'] = x_split__mutmut_17 # type: ignore # mutmut generated
mutants_x_split__mutmut['x_split__mutmut_18'] = x_split__mutmut_18 # type: ignore # mutmut generated
mutants_x_split__mutmut['x_split__mutmut_19'] = x_split__mutmut_19 # type: ignore # mutmut generated
mutants_x_split__mutmut['x_split__mutmut_20'] = x_split__mutmut_20 # type: ignore # mutmut generated
mutants_x_split__mutmut['x_split__mutmut_21'] = x_split__mutmut_21 # type: ignore # mutmut generated
mutants_x_split__mutmut['x_split__mutmut_22'] = x_split__mutmut_22 # type: ignore # mutmut generated
mutants_x_split__mutmut['x_split__mutmut_23'] = x_split__mutmut_23 # type: ignore # mutmut generated
mutants_x_split__mutmut['x_split__mutmut_24'] = x_split__mutmut_24 # type: ignore # mutmut generated
mutants_x_split__mutmut['x_split__mutmut_25'] = x_split__mutmut_25 # type: ignore # mutmut generated
mutants_x_split__mutmut['x_split__mutmut_26'] = x_split__mutmut_26 # type: ignore # mutmut generated
mutants_x_split__mutmut['x_split__mutmut_27'] = x_split__mutmut_27 # type: ignore # mutmut generated
mutants_x_split__mutmut['x_split__mutmut_28'] = x_split__mutmut_28 # type: ignore # mutmut generated
mutants_x_split__mutmut['x_split__mutmut_29'] = x_split__mutmut_29 # type: ignore # mutmut generated
mutants_x_split__mutmut['x_split__mutmut_30'] = x_split__mutmut_30 # type: ignore # mutmut generated
mutants_x_split__mutmut['x_split__mutmut_31'] = x_split__mutmut_31 # type: ignore # mutmut generated
mutants_x_split__mutmut['x_split__mutmut_32'] = x_split__mutmut_32 # type: ignore # mutmut generated
mutants_x_split__mutmut['x_split__mutmut_33'] = x_split__mutmut_33 # type: ignore # mutmut generated
mutants_x_split__mutmut['x_split__mutmut_34'] = x_split__mutmut_34 # type: ignore # mutmut generated
mutants_x_split__mutmut['x_split__mutmut_35'] = x_split__mutmut_35 # type: ignore # mutmut generated
mutants_x_split__mutmut['x_split__mutmut_36'] = x_split__mutmut_36 # type: ignore # mutmut generated
mutants_x_split__mutmut['x_split__mutmut_37'] = x_split__mutmut_37 # type: ignore # mutmut generated
mutants_x_split__mutmut['x_split__mutmut_38'] = x_split__mutmut_38 # type: ignore # mutmut generated
mutants_x_split__mutmut['x_split__mutmut_39'] = x_split__mutmut_39 # type: ignore # mutmut generated
mutants_x_split__mutmut['x_split__mutmut_40'] = x_split__mutmut_40 # type: ignore # mutmut generated
mutants_x_split__mutmut['x_split__mutmut_41'] = x_split__mutmut_41 # type: ignore # mutmut generated
mutants_x_split__mutmut['x_split__mutmut_42'] = x_split__mutmut_42 # type: ignore # mutmut generated
mutants_x_split__mutmut['x_split__mutmut_43'] = x_split__mutmut_43 # type: ignore # mutmut generated
mutants_x_split__mutmut['x_split__mutmut_44'] = x_split__mutmut_44 # type: ignore # mutmut generated
mutants_x_split__mutmut['x_split__mutmut_45'] = x_split__mutmut_45 # type: ignore # mutmut generated
mutants_x_split__mutmut['x_split__mutmut_46'] = x_split__mutmut_46 # type: ignore # mutmut generated
mutants_x_split__mutmut['x_split__mutmut_47'] = x_split__mutmut_47 # type: ignore # mutmut generated
mutants_x_split__mutmut['x_split__mutmut_48'] = x_split__mutmut_48 # type: ignore # mutmut generated
mutants_x_split__mutmut['x_split__mutmut_49'] = x_split__mutmut_49 # type: ignore # mutmut generated
mutants_x_split__mutmut['x_split__mutmut_50'] = x_split__mutmut_50 # type: ignore # mutmut generated
mutants_x_split__mutmut['x_split__mutmut_51'] = x_split__mutmut_51 # type: ignore # mutmut generated
mutants_x_split__mutmut['x_split__mutmut_52'] = x_split__mutmut_52 # type: ignore # mutmut generated
mutants_x_split__mutmut['x_split__mutmut_53'] = x_split__mutmut_53 # type: ignore # mutmut generated
mutants_x_split__mutmut['x_split__mutmut_54'] = x_split__mutmut_54 # type: ignore # mutmut generated
mutants_x_split__mutmut['x_split__mutmut_55'] = x_split__mutmut_55 # type: ignore # mutmut generated
mutants_x_split__mutmut['x_split__mutmut_56'] = x_split__mutmut_56 # type: ignore # mutmut generated
mutants_x_split__mutmut['x_split__mutmut_57'] = x_split__mutmut_57 # type: ignore # mutmut generated
mutants_x_split__mutmut['x_split__mutmut_58'] = x_split__mutmut_58 # type: ignore # mutmut generated
mutants_x_split__mutmut['x_split__mutmut_59'] = x_split__mutmut_59 # type: ignore # mutmut generated
mutants_x_split__mutmut['x_split__mutmut_60'] = x_split__mutmut_60 # type: ignore # mutmut generated
mutants_x_split__mutmut['x_split__mutmut_61'] = x_split__mutmut_61 # type: ignore # mutmut generated
mutants_x_split__mutmut['x_split__mutmut_62'] = x_split__mutmut_62 # type: ignore # mutmut generated
mutants_x_split__mutmut['x_split__mutmut_63'] = x_split__mutmut_63 # type: ignore # mutmut generated
mutants_x_split__mutmut['x_split__mutmut_64'] = x_split__mutmut_64 # type: ignore # mutmut generated
mutants_x_split__mutmut['x_split__mutmut_65'] = x_split__mutmut_65 # type: ignore # mutmut generated
mutants_x_split__mutmut['x_split__mutmut_66'] = x_split__mutmut_66 # type: ignore # mutmut generated
mutants_x_split__mutmut['x_split__mutmut_67'] = x_split__mutmut_67 # type: ignore # mutmut generated
mutants_x_split__mutmut['x_split__mutmut_68'] = x_split__mutmut_68 # type: ignore # mutmut generated
mutants_x_split__mutmut['x_split__mutmut_69'] = x_split__mutmut_69 # type: ignore # mutmut generated
mutants_x_split__mutmut['x_split__mutmut_70'] = x_split__mutmut_70 # type: ignore # mutmut generated
mutants_x_split__mutmut['x_split__mutmut_71'] = x_split__mutmut_71 # type: ignore # mutmut generated
mutants_x_split__mutmut['x_split__mutmut_72'] = x_split__mutmut_72 # type: ignore # mutmut generated
mutants_x_split__mutmut['x_split__mutmut_73'] = x_split__mutmut_73 # type: ignore # mutmut generated
mutants_x_split__mutmut['x_split__mutmut_74'] = x_split__mutmut_74 # type: ignore # mutmut generated
mutants_x_split__mutmut['x_split__mutmut_75'] = x_split__mutmut_75 # type: ignore # mutmut generated
mutants_x_split__mutmut['x_split__mutmut_76'] = x_split__mutmut_76 # type: ignore # mutmut generated
mutants_x_split__mutmut['x_split__mutmut_77'] = x_split__mutmut_77 # type: ignore # mutmut generated
mutants_x_split__mutmut['x_split__mutmut_78'] = x_split__mutmut_78 # type: ignore # mutmut generated
mutants_x_split__mutmut['x_split__mutmut_79'] = x_split__mutmut_79 # type: ignore # mutmut generated
mutants_x_split__mutmut['x_split__mutmut_80'] = x_split__mutmut_80 # type: ignore # mutmut generated
mutants_x_split__mutmut['x_split__mutmut_81'] = x_split__mutmut_81 # type: ignore # mutmut generated
mutants_x_split__mutmut['x_split__mutmut_82'] = x_split__mutmut_82 # type: ignore # mutmut generated
mutants_x_split__mutmut['x_split__mutmut_83'] = x_split__mutmut_83 # type: ignore # mutmut generated
mutants_x_split__mutmut['x_split__mutmut_84'] = x_split__mutmut_84 # type: ignore # mutmut generated
mutants_x_split__mutmut['x_split__mutmut_85'] = x_split__mutmut_85 # type: ignore # mutmut generated
mutants_x_split__mutmut['x_split__mutmut_86'] = x_split__mutmut_86 # type: ignore # mutmut generated
mutants_x_split__mutmut['x_split__mutmut_87'] = x_split__mutmut_87 # type: ignore # mutmut generated
mutants_x_split__mutmut['x_split__mutmut_88'] = x_split__mutmut_88 # type: ignore # mutmut generated
mutants_x_split__mutmut['x_split__mutmut_89'] = x_split__mutmut_89 # type: ignore # mutmut generated
mutants_x_skipped_detectors__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_skipped_detectors__mutmut)
def skipped_detectors(n_train: int) -> list[str]:
    """Quadratic detectors skipped on large training sets; the skip is recorded, never silent."""
    return [
        name
        for name, limit in (
            ("lof", LOF_MAX_TRAIN),
            ("ocsvm", OCSVM_MAX_TRAIN),
            ("knn", KNN_MAX_TRAIN),
        )
        if n_train > limit
    ]


def x_skipped_detectors__mutmut_orig(n_train: int) -> list[str]:
    """Quadratic detectors skipped on large training sets; the skip is recorded, never silent."""
    return [
        name
        for name, limit in (
            ("lof", LOF_MAX_TRAIN),
            ("ocsvm", OCSVM_MAX_TRAIN),
            ("knn", KNN_MAX_TRAIN),
        )
        if n_train > limit
    ]


def x_skipped_detectors__mutmut_1(n_train: int) -> list[str]:
    """Quadratic detectors skipped on large training sets; the skip is recorded, never silent."""
    return [
        name
        for name, limit in (
            ("XXlofXX", LOF_MAX_TRAIN),
            ("ocsvm", OCSVM_MAX_TRAIN),
            ("knn", KNN_MAX_TRAIN),
        )
        if n_train > limit
    ]


def x_skipped_detectors__mutmut_2(n_train: int) -> list[str]:
    """Quadratic detectors skipped on large training sets; the skip is recorded, never silent."""
    return [
        name
        for name, limit in (
            ("LOF", LOF_MAX_TRAIN),
            ("ocsvm", OCSVM_MAX_TRAIN),
            ("knn", KNN_MAX_TRAIN),
        )
        if n_train > limit
    ]


def x_skipped_detectors__mutmut_3(n_train: int) -> list[str]:
    """Quadratic detectors skipped on large training sets; the skip is recorded, never silent."""
    return [
        name
        for name, limit in (
            ("lof", LOF_MAX_TRAIN),
            ("XXocsvmXX", OCSVM_MAX_TRAIN),
            ("knn", KNN_MAX_TRAIN),
        )
        if n_train > limit
    ]


def x_skipped_detectors__mutmut_4(n_train: int) -> list[str]:
    """Quadratic detectors skipped on large training sets; the skip is recorded, never silent."""
    return [
        name
        for name, limit in (
            ("lof", LOF_MAX_TRAIN),
            ("OCSVM", OCSVM_MAX_TRAIN),
            ("knn", KNN_MAX_TRAIN),
        )
        if n_train > limit
    ]


def x_skipped_detectors__mutmut_5(n_train: int) -> list[str]:
    """Quadratic detectors skipped on large training sets; the skip is recorded, never silent."""
    return [
        name
        for name, limit in (
            ("lof", LOF_MAX_TRAIN),
            ("ocsvm", OCSVM_MAX_TRAIN),
            ("XXknnXX", KNN_MAX_TRAIN),
        )
        if n_train > limit
    ]


def x_skipped_detectors__mutmut_6(n_train: int) -> list[str]:
    """Quadratic detectors skipped on large training sets; the skip is recorded, never silent."""
    return [
        name
        for name, limit in (
            ("lof", LOF_MAX_TRAIN),
            ("ocsvm", OCSVM_MAX_TRAIN),
            ("KNN", KNN_MAX_TRAIN),
        )
        if n_train > limit
    ]


def x_skipped_detectors__mutmut_7(n_train: int) -> list[str]:
    """Quadratic detectors skipped on large training sets; the skip is recorded, never silent."""
    return [
        name
        for name, limit in (
            ("lof", LOF_MAX_TRAIN),
            ("ocsvm", OCSVM_MAX_TRAIN),
            ("knn", KNN_MAX_TRAIN),
        )
        if n_train >= limit
    ]

mutants_x_skipped_detectors__mutmut['_mutmut_orig'] = x_skipped_detectors__mutmut_orig # type: ignore # mutmut generated
mutants_x_skipped_detectors__mutmut['x_skipped_detectors__mutmut_1'] = x_skipped_detectors__mutmut_1 # type: ignore # mutmut generated
mutants_x_skipped_detectors__mutmut['x_skipped_detectors__mutmut_2'] = x_skipped_detectors__mutmut_2 # type: ignore # mutmut generated
mutants_x_skipped_detectors__mutmut['x_skipped_detectors__mutmut_3'] = x_skipped_detectors__mutmut_3 # type: ignore # mutmut generated
mutants_x_skipped_detectors__mutmut['x_skipped_detectors__mutmut_4'] = x_skipped_detectors__mutmut_4 # type: ignore # mutmut generated
mutants_x_skipped_detectors__mutmut['x_skipped_detectors__mutmut_5'] = x_skipped_detectors__mutmut_5 # type: ignore # mutmut generated
mutants_x_skipped_detectors__mutmut['x_skipped_detectors__mutmut_6'] = x_skipped_detectors__mutmut_6 # type: ignore # mutmut generated
mutants_x_skipped_detectors__mutmut['x_skipped_detectors__mutmut_7'] = x_skipped_detectors__mutmut_7 # type: ignore # mutmut generated
