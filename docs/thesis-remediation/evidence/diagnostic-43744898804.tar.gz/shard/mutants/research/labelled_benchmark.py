"""Core detectors on the labelled problems of the pool (protocol labelled_pool.md)."""

from __future__ import annotations

import os

os.environ.setdefault("TQDM_DISABLE", "1")

import argparse  # noqa: E402
import json  # noqa: E402
import sys  # noqa: E402
import warnings  # noqa: E402
from concurrent.futures import ProcessPoolExecutor  # noqa: E402
from functools import partial as bind  # noqa: E402
from pathlib import Path  # noqa: E402
from typing import Any  # noqa: E402

import numpy as np  # noqa: E402
import pandas as pd  # noqa: E402

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import dataset_registry as dr  # noqa: E402
import normalise as nm  # noqa: E402
import uci_loader as ul  # noqa: E402
from deep_support import build, capped  # noqa: E402

from etl_benchmark import config  # noqa: E402
from etl_benchmark.metrics import compute_metrics  # noqa: E402
from etl_benchmark.pipeline import detect  # noqa: E402
from etl_benchmark.registry import DEEP_NAMES, DETECTOR_NAMES, clip_contamination  # noqa: E402

METHODS = list(DETECTOR_NAMES)
KNOWN = [*METHODS, *DEEP_NAMES]


from mutmut.mutation.trampoline import wrap_in_trampoline as _mutmut_mutated, MutantDict
mutants_x_load_adbench__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_load_adbench__mutmut)
def load_adbench(name: str, path: Path) -> tuple[np.ndarray, np.ndarray, dict[str, Any]]:
    data = np.load(path)
    x, y, report = nm.clean(pd.DataFrame(data["X"]), data["y"])
    report.update(source="adbench", name=name)
    return x, y, report


def x_load_adbench__mutmut_orig(name: str, path: Path) -> tuple[np.ndarray, np.ndarray, dict[str, Any]]:
    data = np.load(path)
    x, y, report = nm.clean(pd.DataFrame(data["X"]), data["y"])
    report.update(source="adbench", name=name)
    return x, y, report


def x_load_adbench__mutmut_1(name: str, path: Path) -> tuple[np.ndarray, np.ndarray, dict[str, Any]]:
    data = None
    x, y, report = nm.clean(pd.DataFrame(data["X"]), data["y"])
    report.update(source="adbench", name=name)
    return x, y, report


def x_load_adbench__mutmut_2(name: str, path: Path) -> tuple[np.ndarray, np.ndarray, dict[str, Any]]:
    data = np.load(None)
    x, y, report = nm.clean(pd.DataFrame(data["X"]), data["y"])
    report.update(source="adbench", name=name)
    return x, y, report


def x_load_adbench__mutmut_3(name: str, path: Path) -> tuple[np.ndarray, np.ndarray, dict[str, Any]]:
    data = np.load(path)
    x, y, report = None
    report.update(source="adbench", name=name)
    return x, y, report


def x_load_adbench__mutmut_4(name: str, path: Path) -> tuple[np.ndarray, np.ndarray, dict[str, Any]]:
    data = np.load(path)
    x, y, report = nm.clean(None, data["y"])
    report.update(source="adbench", name=name)
    return x, y, report


def x_load_adbench__mutmut_5(name: str, path: Path) -> tuple[np.ndarray, np.ndarray, dict[str, Any]]:
    data = np.load(path)
    x, y, report = nm.clean(pd.DataFrame(data["X"]), None)
    report.update(source="adbench", name=name)
    return x, y, report


def x_load_adbench__mutmut_6(name: str, path: Path) -> tuple[np.ndarray, np.ndarray, dict[str, Any]]:
    data = np.load(path)
    x, y, report = nm.clean(data["y"])
    report.update(source="adbench", name=name)
    return x, y, report


def x_load_adbench__mutmut_7(name: str, path: Path) -> tuple[np.ndarray, np.ndarray, dict[str, Any]]:
    data = np.load(path)
    x, y, report = nm.clean(pd.DataFrame(data["X"]), )
    report.update(source="adbench", name=name)
    return x, y, report


def x_load_adbench__mutmut_8(name: str, path: Path) -> tuple[np.ndarray, np.ndarray, dict[str, Any]]:
    data = np.load(path)
    x, y, report = nm.clean(pd.DataFrame(None), data["y"])
    report.update(source="adbench", name=name)
    return x, y, report


def x_load_adbench__mutmut_9(name: str, path: Path) -> tuple[np.ndarray, np.ndarray, dict[str, Any]]:
    data = np.load(path)
    x, y, report = nm.clean(pd.DataFrame(data["XXXXX"]), data["y"])
    report.update(source="adbench", name=name)
    return x, y, report


def x_load_adbench__mutmut_10(name: str, path: Path) -> tuple[np.ndarray, np.ndarray, dict[str, Any]]:
    data = np.load(path)
    x, y, report = nm.clean(pd.DataFrame(data["x"]), data["y"])
    report.update(source="adbench", name=name)
    return x, y, report


def x_load_adbench__mutmut_11(name: str, path: Path) -> tuple[np.ndarray, np.ndarray, dict[str, Any]]:
    data = np.load(path)
    x, y, report = nm.clean(pd.DataFrame(data["X"]), data["XXyXX"])
    report.update(source="adbench", name=name)
    return x, y, report


def x_load_adbench__mutmut_12(name: str, path: Path) -> tuple[np.ndarray, np.ndarray, dict[str, Any]]:
    data = np.load(path)
    x, y, report = nm.clean(pd.DataFrame(data["X"]), data["Y"])
    report.update(source="adbench", name=name)
    return x, y, report


def x_load_adbench__mutmut_13(name: str, path: Path) -> tuple[np.ndarray, np.ndarray, dict[str, Any]]:
    data = np.load(path)
    x, y, report = nm.clean(pd.DataFrame(data["X"]), data["y"])
    report.update(source=None, name=name)
    return x, y, report


def x_load_adbench__mutmut_14(name: str, path: Path) -> tuple[np.ndarray, np.ndarray, dict[str, Any]]:
    data = np.load(path)
    x, y, report = nm.clean(pd.DataFrame(data["X"]), data["y"])
    report.update(source="adbench", name=None)
    return x, y, report


def x_load_adbench__mutmut_15(name: str, path: Path) -> tuple[np.ndarray, np.ndarray, dict[str, Any]]:
    data = np.load(path)
    x, y, report = nm.clean(pd.DataFrame(data["X"]), data["y"])
    report.update(name=name)
    return x, y, report


def x_load_adbench__mutmut_16(name: str, path: Path) -> tuple[np.ndarray, np.ndarray, dict[str, Any]]:
    data = np.load(path)
    x, y, report = nm.clean(pd.DataFrame(data["X"]), data["y"])
    report.update(source="adbench", )
    return x, y, report


def x_load_adbench__mutmut_17(name: str, path: Path) -> tuple[np.ndarray, np.ndarray, dict[str, Any]]:
    data = np.load(path)
    x, y, report = nm.clean(pd.DataFrame(data["X"]), data["y"])
    report.update(source="XXadbenchXX", name=name)
    return x, y, report


def x_load_adbench__mutmut_18(name: str, path: Path) -> tuple[np.ndarray, np.ndarray, dict[str, Any]]:
    data = np.load(path)
    x, y, report = nm.clean(pd.DataFrame(data["X"]), data["y"])
    report.update(source="ADBENCH", name=name)
    return x, y, report

mutants_x_load_adbench__mutmut['_mutmut_orig'] = x_load_adbench__mutmut_orig # type: ignore # mutmut generated
mutants_x_load_adbench__mutmut['x_load_adbench__mutmut_1'] = x_load_adbench__mutmut_1 # type: ignore # mutmut generated
mutants_x_load_adbench__mutmut['x_load_adbench__mutmut_2'] = x_load_adbench__mutmut_2 # type: ignore # mutmut generated
mutants_x_load_adbench__mutmut['x_load_adbench__mutmut_3'] = x_load_adbench__mutmut_3 # type: ignore # mutmut generated
mutants_x_load_adbench__mutmut['x_load_adbench__mutmut_4'] = x_load_adbench__mutmut_4 # type: ignore # mutmut generated
mutants_x_load_adbench__mutmut['x_load_adbench__mutmut_5'] = x_load_adbench__mutmut_5 # type: ignore # mutmut generated
mutants_x_load_adbench__mutmut['x_load_adbench__mutmut_6'] = x_load_adbench__mutmut_6 # type: ignore # mutmut generated
mutants_x_load_adbench__mutmut['x_load_adbench__mutmut_7'] = x_load_adbench__mutmut_7 # type: ignore # mutmut generated
mutants_x_load_adbench__mutmut['x_load_adbench__mutmut_8'] = x_load_adbench__mutmut_8 # type: ignore # mutmut generated
mutants_x_load_adbench__mutmut['x_load_adbench__mutmut_9'] = x_load_adbench__mutmut_9 # type: ignore # mutmut generated
mutants_x_load_adbench__mutmut['x_load_adbench__mutmut_10'] = x_load_adbench__mutmut_10 # type: ignore # mutmut generated
mutants_x_load_adbench__mutmut['x_load_adbench__mutmut_11'] = x_load_adbench__mutmut_11 # type: ignore # mutmut generated
mutants_x_load_adbench__mutmut['x_load_adbench__mutmut_12'] = x_load_adbench__mutmut_12 # type: ignore # mutmut generated
mutants_x_load_adbench__mutmut['x_load_adbench__mutmut_13'] = x_load_adbench__mutmut_13 # type: ignore # mutmut generated
mutants_x_load_adbench__mutmut['x_load_adbench__mutmut_14'] = x_load_adbench__mutmut_14 # type: ignore # mutmut generated
mutants_x_load_adbench__mutmut['x_load_adbench__mutmut_15'] = x_load_adbench__mutmut_15 # type: ignore # mutmut generated
mutants_x_load_adbench__mutmut['x_load_adbench__mutmut_16'] = x_load_adbench__mutmut_16 # type: ignore # mutmut generated
mutants_x_load_adbench__mutmut['x_load_adbench__mutmut_17'] = x_load_adbench__mutmut_17 # type: ignore # mutmut generated
mutants_x_load_adbench__mutmut['x_load_adbench__mutmut_18'] = x_load_adbench__mutmut_18 # type: ignore # mutmut generated
mutants_x_load_uci__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_load_uci__mutmut)
def load_uci(meta: dict[str, Any], path: Path) -> tuple[np.ndarray, np.ndarray, dict[str, Any]]:
    features, labels, info = ul.derive_labels(ul.read_table(path), meta)
    x, y, report = nm.clean(features, labels)
    report.update(info, source="uci", name=meta["name"], uci_id=meta["uci_id"])
    return x, y, report


def x_load_uci__mutmut_orig(meta: dict[str, Any], path: Path) -> tuple[np.ndarray, np.ndarray, dict[str, Any]]:
    features, labels, info = ul.derive_labels(ul.read_table(path), meta)
    x, y, report = nm.clean(features, labels)
    report.update(info, source="uci", name=meta["name"], uci_id=meta["uci_id"])
    return x, y, report


def x_load_uci__mutmut_1(meta: dict[str, Any], path: Path) -> tuple[np.ndarray, np.ndarray, dict[str, Any]]:
    features, labels, info = None
    x, y, report = nm.clean(features, labels)
    report.update(info, source="uci", name=meta["name"], uci_id=meta["uci_id"])
    return x, y, report


def x_load_uci__mutmut_2(meta: dict[str, Any], path: Path) -> tuple[np.ndarray, np.ndarray, dict[str, Any]]:
    features, labels, info = ul.derive_labels(None, meta)
    x, y, report = nm.clean(features, labels)
    report.update(info, source="uci", name=meta["name"], uci_id=meta["uci_id"])
    return x, y, report


def x_load_uci__mutmut_3(meta: dict[str, Any], path: Path) -> tuple[np.ndarray, np.ndarray, dict[str, Any]]:
    features, labels, info = ul.derive_labels(ul.read_table(path), None)
    x, y, report = nm.clean(features, labels)
    report.update(info, source="uci", name=meta["name"], uci_id=meta["uci_id"])
    return x, y, report


def x_load_uci__mutmut_4(meta: dict[str, Any], path: Path) -> tuple[np.ndarray, np.ndarray, dict[str, Any]]:
    features, labels, info = ul.derive_labels(meta)
    x, y, report = nm.clean(features, labels)
    report.update(info, source="uci", name=meta["name"], uci_id=meta["uci_id"])
    return x, y, report


def x_load_uci__mutmut_5(meta: dict[str, Any], path: Path) -> tuple[np.ndarray, np.ndarray, dict[str, Any]]:
    features, labels, info = ul.derive_labels(ul.read_table(path), )
    x, y, report = nm.clean(features, labels)
    report.update(info, source="uci", name=meta["name"], uci_id=meta["uci_id"])
    return x, y, report


def x_load_uci__mutmut_6(meta: dict[str, Any], path: Path) -> tuple[np.ndarray, np.ndarray, dict[str, Any]]:
    features, labels, info = ul.derive_labels(ul.read_table(None), meta)
    x, y, report = nm.clean(features, labels)
    report.update(info, source="uci", name=meta["name"], uci_id=meta["uci_id"])
    return x, y, report


def x_load_uci__mutmut_7(meta: dict[str, Any], path: Path) -> tuple[np.ndarray, np.ndarray, dict[str, Any]]:
    features, labels, info = ul.derive_labels(ul.read_table(path), meta)
    x, y, report = None
    report.update(info, source="uci", name=meta["name"], uci_id=meta["uci_id"])
    return x, y, report


def x_load_uci__mutmut_8(meta: dict[str, Any], path: Path) -> tuple[np.ndarray, np.ndarray, dict[str, Any]]:
    features, labels, info = ul.derive_labels(ul.read_table(path), meta)
    x, y, report = nm.clean(None, labels)
    report.update(info, source="uci", name=meta["name"], uci_id=meta["uci_id"])
    return x, y, report


def x_load_uci__mutmut_9(meta: dict[str, Any], path: Path) -> tuple[np.ndarray, np.ndarray, dict[str, Any]]:
    features, labels, info = ul.derive_labels(ul.read_table(path), meta)
    x, y, report = nm.clean(features, None)
    report.update(info, source="uci", name=meta["name"], uci_id=meta["uci_id"])
    return x, y, report


def x_load_uci__mutmut_10(meta: dict[str, Any], path: Path) -> tuple[np.ndarray, np.ndarray, dict[str, Any]]:
    features, labels, info = ul.derive_labels(ul.read_table(path), meta)
    x, y, report = nm.clean(labels)
    report.update(info, source="uci", name=meta["name"], uci_id=meta["uci_id"])
    return x, y, report


def x_load_uci__mutmut_11(meta: dict[str, Any], path: Path) -> tuple[np.ndarray, np.ndarray, dict[str, Any]]:
    features, labels, info = ul.derive_labels(ul.read_table(path), meta)
    x, y, report = nm.clean(features, )
    report.update(info, source="uci", name=meta["name"], uci_id=meta["uci_id"])
    return x, y, report


def x_load_uci__mutmut_12(meta: dict[str, Any], path: Path) -> tuple[np.ndarray, np.ndarray, dict[str, Any]]:
    features, labels, info = ul.derive_labels(ul.read_table(path), meta)
    x, y, report = nm.clean(features, labels)
    report.update(None, source="uci", name=meta["name"], uci_id=meta["uci_id"])
    return x, y, report


def x_load_uci__mutmut_13(meta: dict[str, Any], path: Path) -> tuple[np.ndarray, np.ndarray, dict[str, Any]]:
    features, labels, info = ul.derive_labels(ul.read_table(path), meta)
    x, y, report = nm.clean(features, labels)
    report.update(info, source=None, name=meta["name"], uci_id=meta["uci_id"])
    return x, y, report


def x_load_uci__mutmut_14(meta: dict[str, Any], path: Path) -> tuple[np.ndarray, np.ndarray, dict[str, Any]]:
    features, labels, info = ul.derive_labels(ul.read_table(path), meta)
    x, y, report = nm.clean(features, labels)
    report.update(info, source="uci", name=None, uci_id=meta["uci_id"])
    return x, y, report


def x_load_uci__mutmut_15(meta: dict[str, Any], path: Path) -> tuple[np.ndarray, np.ndarray, dict[str, Any]]:
    features, labels, info = ul.derive_labels(ul.read_table(path), meta)
    x, y, report = nm.clean(features, labels)
    report.update(info, source="uci", name=meta["name"], uci_id=None)
    return x, y, report


def x_load_uci__mutmut_16(meta: dict[str, Any], path: Path) -> tuple[np.ndarray, np.ndarray, dict[str, Any]]:
    features, labels, info = ul.derive_labels(ul.read_table(path), meta)
    x, y, report = nm.clean(features, labels)
    report.update(source="uci", name=meta["name"], uci_id=meta["uci_id"])
    return x, y, report


def x_load_uci__mutmut_17(meta: dict[str, Any], path: Path) -> tuple[np.ndarray, np.ndarray, dict[str, Any]]:
    features, labels, info = ul.derive_labels(ul.read_table(path), meta)
    x, y, report = nm.clean(features, labels)
    report.update(info, name=meta["name"], uci_id=meta["uci_id"])
    return x, y, report


def x_load_uci__mutmut_18(meta: dict[str, Any], path: Path) -> tuple[np.ndarray, np.ndarray, dict[str, Any]]:
    features, labels, info = ul.derive_labels(ul.read_table(path), meta)
    x, y, report = nm.clean(features, labels)
    report.update(info, source="uci", uci_id=meta["uci_id"])
    return x, y, report


def x_load_uci__mutmut_19(meta: dict[str, Any], path: Path) -> tuple[np.ndarray, np.ndarray, dict[str, Any]]:
    features, labels, info = ul.derive_labels(ul.read_table(path), meta)
    x, y, report = nm.clean(features, labels)
    report.update(info, source="uci", name=meta["name"], )
    return x, y, report


def x_load_uci__mutmut_20(meta: dict[str, Any], path: Path) -> tuple[np.ndarray, np.ndarray, dict[str, Any]]:
    features, labels, info = ul.derive_labels(ul.read_table(path), meta)
    x, y, report = nm.clean(features, labels)
    report.update(info, source="XXuciXX", name=meta["name"], uci_id=meta["uci_id"])
    return x, y, report


def x_load_uci__mutmut_21(meta: dict[str, Any], path: Path) -> tuple[np.ndarray, np.ndarray, dict[str, Any]]:
    features, labels, info = ul.derive_labels(ul.read_table(path), meta)
    x, y, report = nm.clean(features, labels)
    report.update(info, source="UCI", name=meta["name"], uci_id=meta["uci_id"])
    return x, y, report


def x_load_uci__mutmut_22(meta: dict[str, Any], path: Path) -> tuple[np.ndarray, np.ndarray, dict[str, Any]]:
    features, labels, info = ul.derive_labels(ul.read_table(path), meta)
    x, y, report = nm.clean(features, labels)
    report.update(info, source="uci", name=meta["XXnameXX"], uci_id=meta["uci_id"])
    return x, y, report


def x_load_uci__mutmut_23(meta: dict[str, Any], path: Path) -> tuple[np.ndarray, np.ndarray, dict[str, Any]]:
    features, labels, info = ul.derive_labels(ul.read_table(path), meta)
    x, y, report = nm.clean(features, labels)
    report.update(info, source="uci", name=meta["NAME"], uci_id=meta["uci_id"])
    return x, y, report


def x_load_uci__mutmut_24(meta: dict[str, Any], path: Path) -> tuple[np.ndarray, np.ndarray, dict[str, Any]]:
    features, labels, info = ul.derive_labels(ul.read_table(path), meta)
    x, y, report = nm.clean(features, labels)
    report.update(info, source="uci", name=meta["name"], uci_id=meta["XXuci_idXX"])
    return x, y, report


def x_load_uci__mutmut_25(meta: dict[str, Any], path: Path) -> tuple[np.ndarray, np.ndarray, dict[str, Any]]:
    features, labels, info = ul.derive_labels(ul.read_table(path), meta)
    x, y, report = nm.clean(features, labels)
    report.update(info, source="uci", name=meta["name"], uci_id=meta["UCI_ID"])
    return x, y, report

mutants_x_load_uci__mutmut['_mutmut_orig'] = x_load_uci__mutmut_orig # type: ignore # mutmut generated
mutants_x_load_uci__mutmut['x_load_uci__mutmut_1'] = x_load_uci__mutmut_1 # type: ignore # mutmut generated
mutants_x_load_uci__mutmut['x_load_uci__mutmut_2'] = x_load_uci__mutmut_2 # type: ignore # mutmut generated
mutants_x_load_uci__mutmut['x_load_uci__mutmut_3'] = x_load_uci__mutmut_3 # type: ignore # mutmut generated
mutants_x_load_uci__mutmut['x_load_uci__mutmut_4'] = x_load_uci__mutmut_4 # type: ignore # mutmut generated
mutants_x_load_uci__mutmut['x_load_uci__mutmut_5'] = x_load_uci__mutmut_5 # type: ignore # mutmut generated
mutants_x_load_uci__mutmut['x_load_uci__mutmut_6'] = x_load_uci__mutmut_6 # type: ignore # mutmut generated
mutants_x_load_uci__mutmut['x_load_uci__mutmut_7'] = x_load_uci__mutmut_7 # type: ignore # mutmut generated
mutants_x_load_uci__mutmut['x_load_uci__mutmut_8'] = x_load_uci__mutmut_8 # type: ignore # mutmut generated
mutants_x_load_uci__mutmut['x_load_uci__mutmut_9'] = x_load_uci__mutmut_9 # type: ignore # mutmut generated
mutants_x_load_uci__mutmut['x_load_uci__mutmut_10'] = x_load_uci__mutmut_10 # type: ignore # mutmut generated
mutants_x_load_uci__mutmut['x_load_uci__mutmut_11'] = x_load_uci__mutmut_11 # type: ignore # mutmut generated
mutants_x_load_uci__mutmut['x_load_uci__mutmut_12'] = x_load_uci__mutmut_12 # type: ignore # mutmut generated
mutants_x_load_uci__mutmut['x_load_uci__mutmut_13'] = x_load_uci__mutmut_13 # type: ignore # mutmut generated
mutants_x_load_uci__mutmut['x_load_uci__mutmut_14'] = x_load_uci__mutmut_14 # type: ignore # mutmut generated
mutants_x_load_uci__mutmut['x_load_uci__mutmut_15'] = x_load_uci__mutmut_15 # type: ignore # mutmut generated
mutants_x_load_uci__mutmut['x_load_uci__mutmut_16'] = x_load_uci__mutmut_16 # type: ignore # mutmut generated
mutants_x_load_uci__mutmut['x_load_uci__mutmut_17'] = x_load_uci__mutmut_17 # type: ignore # mutmut generated
mutants_x_load_uci__mutmut['x_load_uci__mutmut_18'] = x_load_uci__mutmut_18 # type: ignore # mutmut generated
mutants_x_load_uci__mutmut['x_load_uci__mutmut_19'] = x_load_uci__mutmut_19 # type: ignore # mutmut generated
mutants_x_load_uci__mutmut['x_load_uci__mutmut_20'] = x_load_uci__mutmut_20 # type: ignore # mutmut generated
mutants_x_load_uci__mutmut['x_load_uci__mutmut_21'] = x_load_uci__mutmut_21 # type: ignore # mutmut generated
mutants_x_load_uci__mutmut['x_load_uci__mutmut_22'] = x_load_uci__mutmut_22 # type: ignore # mutmut generated
mutants_x_load_uci__mutmut['x_load_uci__mutmut_23'] = x_load_uci__mutmut_23 # type: ignore # mutmut generated
mutants_x_load_uci__mutmut['x_load_uci__mutmut_24'] = x_load_uci__mutmut_24 # type: ignore # mutmut generated
mutants_x_load_uci__mutmut['x_load_uci__mutmut_25'] = x_load_uci__mutmut_25 # type: ignore # mutmut generated
mutants_x_run_problem__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_run_problem__mutmut)
def run_problem(
    x: np.ndarray,
    y: np.ndarray,
    seeds: tuple[int, ...] = config.BENCHMARK_SEEDS,
    methods: list[str] | None = None,
) -> dict[str, Any]:
    methods = methods or METHODS
    unknown = [m for m in methods if m not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    metrics: dict[str, list[dict[str, float]]] = {}
    errors: dict[str, list[dict[str, Any]]] = {}
    skipped: list[str] = []
    for seed in seeds:
        part = nm.split(x, y, seed)
        names = [f"f{i}" for i in range(x.shape[1])]
        train = pd.DataFrame(part["x_train"], columns=names)
        test = pd.DataFrame(part["x_test"], columns=names)
        contamination = clip_contamination(float(part["y_train"].mean()))
        skip = nm.skipped_detectors(len(train))
        skipped = [m for m in methods if m in skip]
        for method in methods:
            if method in skip:
                continue
            try:
                result = detect(
                    test, build(method, contamination, seed), fit_df=capped(train, method, seed)
                )
            except Exception as error:  # a failing model is recorded, not hidden
                errors.setdefault(method, []).append({"seed": seed, "error": repr(error)})
                continue
            row = compute_metrics(part["y_test"], result.flags.to_numpy(), result.scores.to_numpy())
            metrics.setdefault(method, []).append(row)
    return {"seeds": list(seeds), "metrics": metrics, "skipped": skipped, "errors": errors}


def x_run_problem__mutmut_orig(
    x: np.ndarray,
    y: np.ndarray,
    seeds: tuple[int, ...] = config.BENCHMARK_SEEDS,
    methods: list[str] | None = None,
) -> dict[str, Any]:
    methods = methods or METHODS
    unknown = [m for m in methods if m not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    metrics: dict[str, list[dict[str, float]]] = {}
    errors: dict[str, list[dict[str, Any]]] = {}
    skipped: list[str] = []
    for seed in seeds:
        part = nm.split(x, y, seed)
        names = [f"f{i}" for i in range(x.shape[1])]
        train = pd.DataFrame(part["x_train"], columns=names)
        test = pd.DataFrame(part["x_test"], columns=names)
        contamination = clip_contamination(float(part["y_train"].mean()))
        skip = nm.skipped_detectors(len(train))
        skipped = [m for m in methods if m in skip]
        for method in methods:
            if method in skip:
                continue
            try:
                result = detect(
                    test, build(method, contamination, seed), fit_df=capped(train, method, seed)
                )
            except Exception as error:  # a failing model is recorded, not hidden
                errors.setdefault(method, []).append({"seed": seed, "error": repr(error)})
                continue
            row = compute_metrics(part["y_test"], result.flags.to_numpy(), result.scores.to_numpy())
            metrics.setdefault(method, []).append(row)
    return {"seeds": list(seeds), "metrics": metrics, "skipped": skipped, "errors": errors}


def x_run_problem__mutmut_1(
    x: np.ndarray,
    y: np.ndarray,
    seeds: tuple[int, ...] = config.BENCHMARK_SEEDS,
    methods: list[str] | None = None,
) -> dict[str, Any]:
    methods = None
    unknown = [m for m in methods if m not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    metrics: dict[str, list[dict[str, float]]] = {}
    errors: dict[str, list[dict[str, Any]]] = {}
    skipped: list[str] = []
    for seed in seeds:
        part = nm.split(x, y, seed)
        names = [f"f{i}" for i in range(x.shape[1])]
        train = pd.DataFrame(part["x_train"], columns=names)
        test = pd.DataFrame(part["x_test"], columns=names)
        contamination = clip_contamination(float(part["y_train"].mean()))
        skip = nm.skipped_detectors(len(train))
        skipped = [m for m in methods if m in skip]
        for method in methods:
            if method in skip:
                continue
            try:
                result = detect(
                    test, build(method, contamination, seed), fit_df=capped(train, method, seed)
                )
            except Exception as error:  # a failing model is recorded, not hidden
                errors.setdefault(method, []).append({"seed": seed, "error": repr(error)})
                continue
            row = compute_metrics(part["y_test"], result.flags.to_numpy(), result.scores.to_numpy())
            metrics.setdefault(method, []).append(row)
    return {"seeds": list(seeds), "metrics": metrics, "skipped": skipped, "errors": errors}


def x_run_problem__mutmut_2(
    x: np.ndarray,
    y: np.ndarray,
    seeds: tuple[int, ...] = config.BENCHMARK_SEEDS,
    methods: list[str] | None = None,
) -> dict[str, Any]:
    methods = methods and METHODS
    unknown = [m for m in methods if m not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    metrics: dict[str, list[dict[str, float]]] = {}
    errors: dict[str, list[dict[str, Any]]] = {}
    skipped: list[str] = []
    for seed in seeds:
        part = nm.split(x, y, seed)
        names = [f"f{i}" for i in range(x.shape[1])]
        train = pd.DataFrame(part["x_train"], columns=names)
        test = pd.DataFrame(part["x_test"], columns=names)
        contamination = clip_contamination(float(part["y_train"].mean()))
        skip = nm.skipped_detectors(len(train))
        skipped = [m for m in methods if m in skip]
        for method in methods:
            if method in skip:
                continue
            try:
                result = detect(
                    test, build(method, contamination, seed), fit_df=capped(train, method, seed)
                )
            except Exception as error:  # a failing model is recorded, not hidden
                errors.setdefault(method, []).append({"seed": seed, "error": repr(error)})
                continue
            row = compute_metrics(part["y_test"], result.flags.to_numpy(), result.scores.to_numpy())
            metrics.setdefault(method, []).append(row)
    return {"seeds": list(seeds), "metrics": metrics, "skipped": skipped, "errors": errors}


def x_run_problem__mutmut_3(
    x: np.ndarray,
    y: np.ndarray,
    seeds: tuple[int, ...] = config.BENCHMARK_SEEDS,
    methods: list[str] | None = None,
) -> dict[str, Any]:
    methods = methods or METHODS
    unknown = None
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    metrics: dict[str, list[dict[str, float]]] = {}
    errors: dict[str, list[dict[str, Any]]] = {}
    skipped: list[str] = []
    for seed in seeds:
        part = nm.split(x, y, seed)
        names = [f"f{i}" for i in range(x.shape[1])]
        train = pd.DataFrame(part["x_train"], columns=names)
        test = pd.DataFrame(part["x_test"], columns=names)
        contamination = clip_contamination(float(part["y_train"].mean()))
        skip = nm.skipped_detectors(len(train))
        skipped = [m for m in methods if m in skip]
        for method in methods:
            if method in skip:
                continue
            try:
                result = detect(
                    test, build(method, contamination, seed), fit_df=capped(train, method, seed)
                )
            except Exception as error:  # a failing model is recorded, not hidden
                errors.setdefault(method, []).append({"seed": seed, "error": repr(error)})
                continue
            row = compute_metrics(part["y_test"], result.flags.to_numpy(), result.scores.to_numpy())
            metrics.setdefault(method, []).append(row)
    return {"seeds": list(seeds), "metrics": metrics, "skipped": skipped, "errors": errors}


def x_run_problem__mutmut_4(
    x: np.ndarray,
    y: np.ndarray,
    seeds: tuple[int, ...] = config.BENCHMARK_SEEDS,
    methods: list[str] | None = None,
) -> dict[str, Any]:
    methods = methods or METHODS
    unknown = [m for m in methods if m in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    metrics: dict[str, list[dict[str, float]]] = {}
    errors: dict[str, list[dict[str, Any]]] = {}
    skipped: list[str] = []
    for seed in seeds:
        part = nm.split(x, y, seed)
        names = [f"f{i}" for i in range(x.shape[1])]
        train = pd.DataFrame(part["x_train"], columns=names)
        test = pd.DataFrame(part["x_test"], columns=names)
        contamination = clip_contamination(float(part["y_train"].mean()))
        skip = nm.skipped_detectors(len(train))
        skipped = [m for m in methods if m in skip]
        for method in methods:
            if method in skip:
                continue
            try:
                result = detect(
                    test, build(method, contamination, seed), fit_df=capped(train, method, seed)
                )
            except Exception as error:  # a failing model is recorded, not hidden
                errors.setdefault(method, []).append({"seed": seed, "error": repr(error)})
                continue
            row = compute_metrics(part["y_test"], result.flags.to_numpy(), result.scores.to_numpy())
            metrics.setdefault(method, []).append(row)
    return {"seeds": list(seeds), "metrics": metrics, "skipped": skipped, "errors": errors}


def x_run_problem__mutmut_5(
    x: np.ndarray,
    y: np.ndarray,
    seeds: tuple[int, ...] = config.BENCHMARK_SEEDS,
    methods: list[str] | None = None,
) -> dict[str, Any]:
    methods = methods or METHODS
    unknown = [m for m in methods if m not in KNOWN]
    if unknown:
        raise ValueError(None)
    metrics: dict[str, list[dict[str, float]]] = {}
    errors: dict[str, list[dict[str, Any]]] = {}
    skipped: list[str] = []
    for seed in seeds:
        part = nm.split(x, y, seed)
        names = [f"f{i}" for i in range(x.shape[1])]
        train = pd.DataFrame(part["x_train"], columns=names)
        test = pd.DataFrame(part["x_test"], columns=names)
        contamination = clip_contamination(float(part["y_train"].mean()))
        skip = nm.skipped_detectors(len(train))
        skipped = [m for m in methods if m in skip]
        for method in methods:
            if method in skip:
                continue
            try:
                result = detect(
                    test, build(method, contamination, seed), fit_df=capped(train, method, seed)
                )
            except Exception as error:  # a failing model is recorded, not hidden
                errors.setdefault(method, []).append({"seed": seed, "error": repr(error)})
                continue
            row = compute_metrics(part["y_test"], result.flags.to_numpy(), result.scores.to_numpy())
            metrics.setdefault(method, []).append(row)
    return {"seeds": list(seeds), "metrics": metrics, "skipped": skipped, "errors": errors}


def x_run_problem__mutmut_6(
    x: np.ndarray,
    y: np.ndarray,
    seeds: tuple[int, ...] = config.BENCHMARK_SEEDS,
    methods: list[str] | None = None,
) -> dict[str, Any]:
    methods = methods or METHODS
    unknown = [m for m in methods if m not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    metrics: dict[str, list[dict[str, float]]] = None
    errors: dict[str, list[dict[str, Any]]] = {}
    skipped: list[str] = []
    for seed in seeds:
        part = nm.split(x, y, seed)
        names = [f"f{i}" for i in range(x.shape[1])]
        train = pd.DataFrame(part["x_train"], columns=names)
        test = pd.DataFrame(part["x_test"], columns=names)
        contamination = clip_contamination(float(part["y_train"].mean()))
        skip = nm.skipped_detectors(len(train))
        skipped = [m for m in methods if m in skip]
        for method in methods:
            if method in skip:
                continue
            try:
                result = detect(
                    test, build(method, contamination, seed), fit_df=capped(train, method, seed)
                )
            except Exception as error:  # a failing model is recorded, not hidden
                errors.setdefault(method, []).append({"seed": seed, "error": repr(error)})
                continue
            row = compute_metrics(part["y_test"], result.flags.to_numpy(), result.scores.to_numpy())
            metrics.setdefault(method, []).append(row)
    return {"seeds": list(seeds), "metrics": metrics, "skipped": skipped, "errors": errors}


def x_run_problem__mutmut_7(
    x: np.ndarray,
    y: np.ndarray,
    seeds: tuple[int, ...] = config.BENCHMARK_SEEDS,
    methods: list[str] | None = None,
) -> dict[str, Any]:
    methods = methods or METHODS
    unknown = [m for m in methods if m not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    metrics: dict[str, list[dict[str, float]]] = {}
    errors: dict[str, list[dict[str, Any]]] = None
    skipped: list[str] = []
    for seed in seeds:
        part = nm.split(x, y, seed)
        names = [f"f{i}" for i in range(x.shape[1])]
        train = pd.DataFrame(part["x_train"], columns=names)
        test = pd.DataFrame(part["x_test"], columns=names)
        contamination = clip_contamination(float(part["y_train"].mean()))
        skip = nm.skipped_detectors(len(train))
        skipped = [m for m in methods if m in skip]
        for method in methods:
            if method in skip:
                continue
            try:
                result = detect(
                    test, build(method, contamination, seed), fit_df=capped(train, method, seed)
                )
            except Exception as error:  # a failing model is recorded, not hidden
                errors.setdefault(method, []).append({"seed": seed, "error": repr(error)})
                continue
            row = compute_metrics(part["y_test"], result.flags.to_numpy(), result.scores.to_numpy())
            metrics.setdefault(method, []).append(row)
    return {"seeds": list(seeds), "metrics": metrics, "skipped": skipped, "errors": errors}


def x_run_problem__mutmut_8(
    x: np.ndarray,
    y: np.ndarray,
    seeds: tuple[int, ...] = config.BENCHMARK_SEEDS,
    methods: list[str] | None = None,
) -> dict[str, Any]:
    methods = methods or METHODS
    unknown = [m for m in methods if m not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    metrics: dict[str, list[dict[str, float]]] = {}
    errors: dict[str, list[dict[str, Any]]] = {}
    skipped: list[str] = None
    for seed in seeds:
        part = nm.split(x, y, seed)
        names = [f"f{i}" for i in range(x.shape[1])]
        train = pd.DataFrame(part["x_train"], columns=names)
        test = pd.DataFrame(part["x_test"], columns=names)
        contamination = clip_contamination(float(part["y_train"].mean()))
        skip = nm.skipped_detectors(len(train))
        skipped = [m for m in methods if m in skip]
        for method in methods:
            if method in skip:
                continue
            try:
                result = detect(
                    test, build(method, contamination, seed), fit_df=capped(train, method, seed)
                )
            except Exception as error:  # a failing model is recorded, not hidden
                errors.setdefault(method, []).append({"seed": seed, "error": repr(error)})
                continue
            row = compute_metrics(part["y_test"], result.flags.to_numpy(), result.scores.to_numpy())
            metrics.setdefault(method, []).append(row)
    return {"seeds": list(seeds), "metrics": metrics, "skipped": skipped, "errors": errors}


def x_run_problem__mutmut_9(
    x: np.ndarray,
    y: np.ndarray,
    seeds: tuple[int, ...] = config.BENCHMARK_SEEDS,
    methods: list[str] | None = None,
) -> dict[str, Any]:
    methods = methods or METHODS
    unknown = [m for m in methods if m not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    metrics: dict[str, list[dict[str, float]]] = {}
    errors: dict[str, list[dict[str, Any]]] = {}
    skipped: list[str] = []
    for seed in seeds:
        part = None
        names = [f"f{i}" for i in range(x.shape[1])]
        train = pd.DataFrame(part["x_train"], columns=names)
        test = pd.DataFrame(part["x_test"], columns=names)
        contamination = clip_contamination(float(part["y_train"].mean()))
        skip = nm.skipped_detectors(len(train))
        skipped = [m for m in methods if m in skip]
        for method in methods:
            if method in skip:
                continue
            try:
                result = detect(
                    test, build(method, contamination, seed), fit_df=capped(train, method, seed)
                )
            except Exception as error:  # a failing model is recorded, not hidden
                errors.setdefault(method, []).append({"seed": seed, "error": repr(error)})
                continue
            row = compute_metrics(part["y_test"], result.flags.to_numpy(), result.scores.to_numpy())
            metrics.setdefault(method, []).append(row)
    return {"seeds": list(seeds), "metrics": metrics, "skipped": skipped, "errors": errors}


def x_run_problem__mutmut_10(
    x: np.ndarray,
    y: np.ndarray,
    seeds: tuple[int, ...] = config.BENCHMARK_SEEDS,
    methods: list[str] | None = None,
) -> dict[str, Any]:
    methods = methods or METHODS
    unknown = [m for m in methods if m not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    metrics: dict[str, list[dict[str, float]]] = {}
    errors: dict[str, list[dict[str, Any]]] = {}
    skipped: list[str] = []
    for seed in seeds:
        part = nm.split(None, y, seed)
        names = [f"f{i}" for i in range(x.shape[1])]
        train = pd.DataFrame(part["x_train"], columns=names)
        test = pd.DataFrame(part["x_test"], columns=names)
        contamination = clip_contamination(float(part["y_train"].mean()))
        skip = nm.skipped_detectors(len(train))
        skipped = [m for m in methods if m in skip]
        for method in methods:
            if method in skip:
                continue
            try:
                result = detect(
                    test, build(method, contamination, seed), fit_df=capped(train, method, seed)
                )
            except Exception as error:  # a failing model is recorded, not hidden
                errors.setdefault(method, []).append({"seed": seed, "error": repr(error)})
                continue
            row = compute_metrics(part["y_test"], result.flags.to_numpy(), result.scores.to_numpy())
            metrics.setdefault(method, []).append(row)
    return {"seeds": list(seeds), "metrics": metrics, "skipped": skipped, "errors": errors}


def x_run_problem__mutmut_11(
    x: np.ndarray,
    y: np.ndarray,
    seeds: tuple[int, ...] = config.BENCHMARK_SEEDS,
    methods: list[str] | None = None,
) -> dict[str, Any]:
    methods = methods or METHODS
    unknown = [m for m in methods if m not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    metrics: dict[str, list[dict[str, float]]] = {}
    errors: dict[str, list[dict[str, Any]]] = {}
    skipped: list[str] = []
    for seed in seeds:
        part = nm.split(x, None, seed)
        names = [f"f{i}" for i in range(x.shape[1])]
        train = pd.DataFrame(part["x_train"], columns=names)
        test = pd.DataFrame(part["x_test"], columns=names)
        contamination = clip_contamination(float(part["y_train"].mean()))
        skip = nm.skipped_detectors(len(train))
        skipped = [m for m in methods if m in skip]
        for method in methods:
            if method in skip:
                continue
            try:
                result = detect(
                    test, build(method, contamination, seed), fit_df=capped(train, method, seed)
                )
            except Exception as error:  # a failing model is recorded, not hidden
                errors.setdefault(method, []).append({"seed": seed, "error": repr(error)})
                continue
            row = compute_metrics(part["y_test"], result.flags.to_numpy(), result.scores.to_numpy())
            metrics.setdefault(method, []).append(row)
    return {"seeds": list(seeds), "metrics": metrics, "skipped": skipped, "errors": errors}


def x_run_problem__mutmut_12(
    x: np.ndarray,
    y: np.ndarray,
    seeds: tuple[int, ...] = config.BENCHMARK_SEEDS,
    methods: list[str] | None = None,
) -> dict[str, Any]:
    methods = methods or METHODS
    unknown = [m for m in methods if m not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    metrics: dict[str, list[dict[str, float]]] = {}
    errors: dict[str, list[dict[str, Any]]] = {}
    skipped: list[str] = []
    for seed in seeds:
        part = nm.split(x, y, None)
        names = [f"f{i}" for i in range(x.shape[1])]
        train = pd.DataFrame(part["x_train"], columns=names)
        test = pd.DataFrame(part["x_test"], columns=names)
        contamination = clip_contamination(float(part["y_train"].mean()))
        skip = nm.skipped_detectors(len(train))
        skipped = [m for m in methods if m in skip]
        for method in methods:
            if method in skip:
                continue
            try:
                result = detect(
                    test, build(method, contamination, seed), fit_df=capped(train, method, seed)
                )
            except Exception as error:  # a failing model is recorded, not hidden
                errors.setdefault(method, []).append({"seed": seed, "error": repr(error)})
                continue
            row = compute_metrics(part["y_test"], result.flags.to_numpy(), result.scores.to_numpy())
            metrics.setdefault(method, []).append(row)
    return {"seeds": list(seeds), "metrics": metrics, "skipped": skipped, "errors": errors}


def x_run_problem__mutmut_13(
    x: np.ndarray,
    y: np.ndarray,
    seeds: tuple[int, ...] = config.BENCHMARK_SEEDS,
    methods: list[str] | None = None,
) -> dict[str, Any]:
    methods = methods or METHODS
    unknown = [m for m in methods if m not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    metrics: dict[str, list[dict[str, float]]] = {}
    errors: dict[str, list[dict[str, Any]]] = {}
    skipped: list[str] = []
    for seed in seeds:
        part = nm.split(y, seed)
        names = [f"f{i}" for i in range(x.shape[1])]
        train = pd.DataFrame(part["x_train"], columns=names)
        test = pd.DataFrame(part["x_test"], columns=names)
        contamination = clip_contamination(float(part["y_train"].mean()))
        skip = nm.skipped_detectors(len(train))
        skipped = [m for m in methods if m in skip]
        for method in methods:
            if method in skip:
                continue
            try:
                result = detect(
                    test, build(method, contamination, seed), fit_df=capped(train, method, seed)
                )
            except Exception as error:  # a failing model is recorded, not hidden
                errors.setdefault(method, []).append({"seed": seed, "error": repr(error)})
                continue
            row = compute_metrics(part["y_test"], result.flags.to_numpy(), result.scores.to_numpy())
            metrics.setdefault(method, []).append(row)
    return {"seeds": list(seeds), "metrics": metrics, "skipped": skipped, "errors": errors}


def x_run_problem__mutmut_14(
    x: np.ndarray,
    y: np.ndarray,
    seeds: tuple[int, ...] = config.BENCHMARK_SEEDS,
    methods: list[str] | None = None,
) -> dict[str, Any]:
    methods = methods or METHODS
    unknown = [m for m in methods if m not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    metrics: dict[str, list[dict[str, float]]] = {}
    errors: dict[str, list[dict[str, Any]]] = {}
    skipped: list[str] = []
    for seed in seeds:
        part = nm.split(x, seed)
        names = [f"f{i}" for i in range(x.shape[1])]
        train = pd.DataFrame(part["x_train"], columns=names)
        test = pd.DataFrame(part["x_test"], columns=names)
        contamination = clip_contamination(float(part["y_train"].mean()))
        skip = nm.skipped_detectors(len(train))
        skipped = [m for m in methods if m in skip]
        for method in methods:
            if method in skip:
                continue
            try:
                result = detect(
                    test, build(method, contamination, seed), fit_df=capped(train, method, seed)
                )
            except Exception as error:  # a failing model is recorded, not hidden
                errors.setdefault(method, []).append({"seed": seed, "error": repr(error)})
                continue
            row = compute_metrics(part["y_test"], result.flags.to_numpy(), result.scores.to_numpy())
            metrics.setdefault(method, []).append(row)
    return {"seeds": list(seeds), "metrics": metrics, "skipped": skipped, "errors": errors}


def x_run_problem__mutmut_15(
    x: np.ndarray,
    y: np.ndarray,
    seeds: tuple[int, ...] = config.BENCHMARK_SEEDS,
    methods: list[str] | None = None,
) -> dict[str, Any]:
    methods = methods or METHODS
    unknown = [m for m in methods if m not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    metrics: dict[str, list[dict[str, float]]] = {}
    errors: dict[str, list[dict[str, Any]]] = {}
    skipped: list[str] = []
    for seed in seeds:
        part = nm.split(x, y, )
        names = [f"f{i}" for i in range(x.shape[1])]
        train = pd.DataFrame(part["x_train"], columns=names)
        test = pd.DataFrame(part["x_test"], columns=names)
        contamination = clip_contamination(float(part["y_train"].mean()))
        skip = nm.skipped_detectors(len(train))
        skipped = [m for m in methods if m in skip]
        for method in methods:
            if method in skip:
                continue
            try:
                result = detect(
                    test, build(method, contamination, seed), fit_df=capped(train, method, seed)
                )
            except Exception as error:  # a failing model is recorded, not hidden
                errors.setdefault(method, []).append({"seed": seed, "error": repr(error)})
                continue
            row = compute_metrics(part["y_test"], result.flags.to_numpy(), result.scores.to_numpy())
            metrics.setdefault(method, []).append(row)
    return {"seeds": list(seeds), "metrics": metrics, "skipped": skipped, "errors": errors}


def x_run_problem__mutmut_16(
    x: np.ndarray,
    y: np.ndarray,
    seeds: tuple[int, ...] = config.BENCHMARK_SEEDS,
    methods: list[str] | None = None,
) -> dict[str, Any]:
    methods = methods or METHODS
    unknown = [m for m in methods if m not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    metrics: dict[str, list[dict[str, float]]] = {}
    errors: dict[str, list[dict[str, Any]]] = {}
    skipped: list[str] = []
    for seed in seeds:
        part = nm.split(x, y, seed)
        names = None
        train = pd.DataFrame(part["x_train"], columns=names)
        test = pd.DataFrame(part["x_test"], columns=names)
        contamination = clip_contamination(float(part["y_train"].mean()))
        skip = nm.skipped_detectors(len(train))
        skipped = [m for m in methods if m in skip]
        for method in methods:
            if method in skip:
                continue
            try:
                result = detect(
                    test, build(method, contamination, seed), fit_df=capped(train, method, seed)
                )
            except Exception as error:  # a failing model is recorded, not hidden
                errors.setdefault(method, []).append({"seed": seed, "error": repr(error)})
                continue
            row = compute_metrics(part["y_test"], result.flags.to_numpy(), result.scores.to_numpy())
            metrics.setdefault(method, []).append(row)
    return {"seeds": list(seeds), "metrics": metrics, "skipped": skipped, "errors": errors}


def x_run_problem__mutmut_17(
    x: np.ndarray,
    y: np.ndarray,
    seeds: tuple[int, ...] = config.BENCHMARK_SEEDS,
    methods: list[str] | None = None,
) -> dict[str, Any]:
    methods = methods or METHODS
    unknown = [m for m in methods if m not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    metrics: dict[str, list[dict[str, float]]] = {}
    errors: dict[str, list[dict[str, Any]]] = {}
    skipped: list[str] = []
    for seed in seeds:
        part = nm.split(x, y, seed)
        names = [f"f{i}" for i in range(None)]
        train = pd.DataFrame(part["x_train"], columns=names)
        test = pd.DataFrame(part["x_test"], columns=names)
        contamination = clip_contamination(float(part["y_train"].mean()))
        skip = nm.skipped_detectors(len(train))
        skipped = [m for m in methods if m in skip]
        for method in methods:
            if method in skip:
                continue
            try:
                result = detect(
                    test, build(method, contamination, seed), fit_df=capped(train, method, seed)
                )
            except Exception as error:  # a failing model is recorded, not hidden
                errors.setdefault(method, []).append({"seed": seed, "error": repr(error)})
                continue
            row = compute_metrics(part["y_test"], result.flags.to_numpy(), result.scores.to_numpy())
            metrics.setdefault(method, []).append(row)
    return {"seeds": list(seeds), "metrics": metrics, "skipped": skipped, "errors": errors}


def x_run_problem__mutmut_18(
    x: np.ndarray,
    y: np.ndarray,
    seeds: tuple[int, ...] = config.BENCHMARK_SEEDS,
    methods: list[str] | None = None,
) -> dict[str, Any]:
    methods = methods or METHODS
    unknown = [m for m in methods if m not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    metrics: dict[str, list[dict[str, float]]] = {}
    errors: dict[str, list[dict[str, Any]]] = {}
    skipped: list[str] = []
    for seed in seeds:
        part = nm.split(x, y, seed)
        names = [f"f{i}" for i in range(x.shape[2])]
        train = pd.DataFrame(part["x_train"], columns=names)
        test = pd.DataFrame(part["x_test"], columns=names)
        contamination = clip_contamination(float(part["y_train"].mean()))
        skip = nm.skipped_detectors(len(train))
        skipped = [m for m in methods if m in skip]
        for method in methods:
            if method in skip:
                continue
            try:
                result = detect(
                    test, build(method, contamination, seed), fit_df=capped(train, method, seed)
                )
            except Exception as error:  # a failing model is recorded, not hidden
                errors.setdefault(method, []).append({"seed": seed, "error": repr(error)})
                continue
            row = compute_metrics(part["y_test"], result.flags.to_numpy(), result.scores.to_numpy())
            metrics.setdefault(method, []).append(row)
    return {"seeds": list(seeds), "metrics": metrics, "skipped": skipped, "errors": errors}


def x_run_problem__mutmut_19(
    x: np.ndarray,
    y: np.ndarray,
    seeds: tuple[int, ...] = config.BENCHMARK_SEEDS,
    methods: list[str] | None = None,
) -> dict[str, Any]:
    methods = methods or METHODS
    unknown = [m for m in methods if m not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    metrics: dict[str, list[dict[str, float]]] = {}
    errors: dict[str, list[dict[str, Any]]] = {}
    skipped: list[str] = []
    for seed in seeds:
        part = nm.split(x, y, seed)
        names = [f"f{i}" for i in range(x.shape[1])]
        train = None
        test = pd.DataFrame(part["x_test"], columns=names)
        contamination = clip_contamination(float(part["y_train"].mean()))
        skip = nm.skipped_detectors(len(train))
        skipped = [m for m in methods if m in skip]
        for method in methods:
            if method in skip:
                continue
            try:
                result = detect(
                    test, build(method, contamination, seed), fit_df=capped(train, method, seed)
                )
            except Exception as error:  # a failing model is recorded, not hidden
                errors.setdefault(method, []).append({"seed": seed, "error": repr(error)})
                continue
            row = compute_metrics(part["y_test"], result.flags.to_numpy(), result.scores.to_numpy())
            metrics.setdefault(method, []).append(row)
    return {"seeds": list(seeds), "metrics": metrics, "skipped": skipped, "errors": errors}


def x_run_problem__mutmut_20(
    x: np.ndarray,
    y: np.ndarray,
    seeds: tuple[int, ...] = config.BENCHMARK_SEEDS,
    methods: list[str] | None = None,
) -> dict[str, Any]:
    methods = methods or METHODS
    unknown = [m for m in methods if m not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    metrics: dict[str, list[dict[str, float]]] = {}
    errors: dict[str, list[dict[str, Any]]] = {}
    skipped: list[str] = []
    for seed in seeds:
        part = nm.split(x, y, seed)
        names = [f"f{i}" for i in range(x.shape[1])]
        train = pd.DataFrame(None, columns=names)
        test = pd.DataFrame(part["x_test"], columns=names)
        contamination = clip_contamination(float(part["y_train"].mean()))
        skip = nm.skipped_detectors(len(train))
        skipped = [m for m in methods if m in skip]
        for method in methods:
            if method in skip:
                continue
            try:
                result = detect(
                    test, build(method, contamination, seed), fit_df=capped(train, method, seed)
                )
            except Exception as error:  # a failing model is recorded, not hidden
                errors.setdefault(method, []).append({"seed": seed, "error": repr(error)})
                continue
            row = compute_metrics(part["y_test"], result.flags.to_numpy(), result.scores.to_numpy())
            metrics.setdefault(method, []).append(row)
    return {"seeds": list(seeds), "metrics": metrics, "skipped": skipped, "errors": errors}


def x_run_problem__mutmut_21(
    x: np.ndarray,
    y: np.ndarray,
    seeds: tuple[int, ...] = config.BENCHMARK_SEEDS,
    methods: list[str] | None = None,
) -> dict[str, Any]:
    methods = methods or METHODS
    unknown = [m for m in methods if m not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    metrics: dict[str, list[dict[str, float]]] = {}
    errors: dict[str, list[dict[str, Any]]] = {}
    skipped: list[str] = []
    for seed in seeds:
        part = nm.split(x, y, seed)
        names = [f"f{i}" for i in range(x.shape[1])]
        train = pd.DataFrame(part["x_train"], columns=None)
        test = pd.DataFrame(part["x_test"], columns=names)
        contamination = clip_contamination(float(part["y_train"].mean()))
        skip = nm.skipped_detectors(len(train))
        skipped = [m for m in methods if m in skip]
        for method in methods:
            if method in skip:
                continue
            try:
                result = detect(
                    test, build(method, contamination, seed), fit_df=capped(train, method, seed)
                )
            except Exception as error:  # a failing model is recorded, not hidden
                errors.setdefault(method, []).append({"seed": seed, "error": repr(error)})
                continue
            row = compute_metrics(part["y_test"], result.flags.to_numpy(), result.scores.to_numpy())
            metrics.setdefault(method, []).append(row)
    return {"seeds": list(seeds), "metrics": metrics, "skipped": skipped, "errors": errors}


def x_run_problem__mutmut_22(
    x: np.ndarray,
    y: np.ndarray,
    seeds: tuple[int, ...] = config.BENCHMARK_SEEDS,
    methods: list[str] | None = None,
) -> dict[str, Any]:
    methods = methods or METHODS
    unknown = [m for m in methods if m not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    metrics: dict[str, list[dict[str, float]]] = {}
    errors: dict[str, list[dict[str, Any]]] = {}
    skipped: list[str] = []
    for seed in seeds:
        part = nm.split(x, y, seed)
        names = [f"f{i}" for i in range(x.shape[1])]
        train = pd.DataFrame(columns=names)
        test = pd.DataFrame(part["x_test"], columns=names)
        contamination = clip_contamination(float(part["y_train"].mean()))
        skip = nm.skipped_detectors(len(train))
        skipped = [m for m in methods if m in skip]
        for method in methods:
            if method in skip:
                continue
            try:
                result = detect(
                    test, build(method, contamination, seed), fit_df=capped(train, method, seed)
                )
            except Exception as error:  # a failing model is recorded, not hidden
                errors.setdefault(method, []).append({"seed": seed, "error": repr(error)})
                continue
            row = compute_metrics(part["y_test"], result.flags.to_numpy(), result.scores.to_numpy())
            metrics.setdefault(method, []).append(row)
    return {"seeds": list(seeds), "metrics": metrics, "skipped": skipped, "errors": errors}


def x_run_problem__mutmut_23(
    x: np.ndarray,
    y: np.ndarray,
    seeds: tuple[int, ...] = config.BENCHMARK_SEEDS,
    methods: list[str] | None = None,
) -> dict[str, Any]:
    methods = methods or METHODS
    unknown = [m for m in methods if m not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    metrics: dict[str, list[dict[str, float]]] = {}
    errors: dict[str, list[dict[str, Any]]] = {}
    skipped: list[str] = []
    for seed in seeds:
        part = nm.split(x, y, seed)
        names = [f"f{i}" for i in range(x.shape[1])]
        train = pd.DataFrame(part["x_train"], )
        test = pd.DataFrame(part["x_test"], columns=names)
        contamination = clip_contamination(float(part["y_train"].mean()))
        skip = nm.skipped_detectors(len(train))
        skipped = [m for m in methods if m in skip]
        for method in methods:
            if method in skip:
                continue
            try:
                result = detect(
                    test, build(method, contamination, seed), fit_df=capped(train, method, seed)
                )
            except Exception as error:  # a failing model is recorded, not hidden
                errors.setdefault(method, []).append({"seed": seed, "error": repr(error)})
                continue
            row = compute_metrics(part["y_test"], result.flags.to_numpy(), result.scores.to_numpy())
            metrics.setdefault(method, []).append(row)
    return {"seeds": list(seeds), "metrics": metrics, "skipped": skipped, "errors": errors}


def x_run_problem__mutmut_24(
    x: np.ndarray,
    y: np.ndarray,
    seeds: tuple[int, ...] = config.BENCHMARK_SEEDS,
    methods: list[str] | None = None,
) -> dict[str, Any]:
    methods = methods or METHODS
    unknown = [m for m in methods if m not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    metrics: dict[str, list[dict[str, float]]] = {}
    errors: dict[str, list[dict[str, Any]]] = {}
    skipped: list[str] = []
    for seed in seeds:
        part = nm.split(x, y, seed)
        names = [f"f{i}" for i in range(x.shape[1])]
        train = pd.DataFrame(part["XXx_trainXX"], columns=names)
        test = pd.DataFrame(part["x_test"], columns=names)
        contamination = clip_contamination(float(part["y_train"].mean()))
        skip = nm.skipped_detectors(len(train))
        skipped = [m for m in methods if m in skip]
        for method in methods:
            if method in skip:
                continue
            try:
                result = detect(
                    test, build(method, contamination, seed), fit_df=capped(train, method, seed)
                )
            except Exception as error:  # a failing model is recorded, not hidden
                errors.setdefault(method, []).append({"seed": seed, "error": repr(error)})
                continue
            row = compute_metrics(part["y_test"], result.flags.to_numpy(), result.scores.to_numpy())
            metrics.setdefault(method, []).append(row)
    return {"seeds": list(seeds), "metrics": metrics, "skipped": skipped, "errors": errors}


def x_run_problem__mutmut_25(
    x: np.ndarray,
    y: np.ndarray,
    seeds: tuple[int, ...] = config.BENCHMARK_SEEDS,
    methods: list[str] | None = None,
) -> dict[str, Any]:
    methods = methods or METHODS
    unknown = [m for m in methods if m not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    metrics: dict[str, list[dict[str, float]]] = {}
    errors: dict[str, list[dict[str, Any]]] = {}
    skipped: list[str] = []
    for seed in seeds:
        part = nm.split(x, y, seed)
        names = [f"f{i}" for i in range(x.shape[1])]
        train = pd.DataFrame(part["X_TRAIN"], columns=names)
        test = pd.DataFrame(part["x_test"], columns=names)
        contamination = clip_contamination(float(part["y_train"].mean()))
        skip = nm.skipped_detectors(len(train))
        skipped = [m for m in methods if m in skip]
        for method in methods:
            if method in skip:
                continue
            try:
                result = detect(
                    test, build(method, contamination, seed), fit_df=capped(train, method, seed)
                )
            except Exception as error:  # a failing model is recorded, not hidden
                errors.setdefault(method, []).append({"seed": seed, "error": repr(error)})
                continue
            row = compute_metrics(part["y_test"], result.flags.to_numpy(), result.scores.to_numpy())
            metrics.setdefault(method, []).append(row)
    return {"seeds": list(seeds), "metrics": metrics, "skipped": skipped, "errors": errors}


def x_run_problem__mutmut_26(
    x: np.ndarray,
    y: np.ndarray,
    seeds: tuple[int, ...] = config.BENCHMARK_SEEDS,
    methods: list[str] | None = None,
) -> dict[str, Any]:
    methods = methods or METHODS
    unknown = [m for m in methods if m not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    metrics: dict[str, list[dict[str, float]]] = {}
    errors: dict[str, list[dict[str, Any]]] = {}
    skipped: list[str] = []
    for seed in seeds:
        part = nm.split(x, y, seed)
        names = [f"f{i}" for i in range(x.shape[1])]
        train = pd.DataFrame(part["x_train"], columns=names)
        test = None
        contamination = clip_contamination(float(part["y_train"].mean()))
        skip = nm.skipped_detectors(len(train))
        skipped = [m for m in methods if m in skip]
        for method in methods:
            if method in skip:
                continue
            try:
                result = detect(
                    test, build(method, contamination, seed), fit_df=capped(train, method, seed)
                )
            except Exception as error:  # a failing model is recorded, not hidden
                errors.setdefault(method, []).append({"seed": seed, "error": repr(error)})
                continue
            row = compute_metrics(part["y_test"], result.flags.to_numpy(), result.scores.to_numpy())
            metrics.setdefault(method, []).append(row)
    return {"seeds": list(seeds), "metrics": metrics, "skipped": skipped, "errors": errors}


def x_run_problem__mutmut_27(
    x: np.ndarray,
    y: np.ndarray,
    seeds: tuple[int, ...] = config.BENCHMARK_SEEDS,
    methods: list[str] | None = None,
) -> dict[str, Any]:
    methods = methods or METHODS
    unknown = [m for m in methods if m not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    metrics: dict[str, list[dict[str, float]]] = {}
    errors: dict[str, list[dict[str, Any]]] = {}
    skipped: list[str] = []
    for seed in seeds:
        part = nm.split(x, y, seed)
        names = [f"f{i}" for i in range(x.shape[1])]
        train = pd.DataFrame(part["x_train"], columns=names)
        test = pd.DataFrame(None, columns=names)
        contamination = clip_contamination(float(part["y_train"].mean()))
        skip = nm.skipped_detectors(len(train))
        skipped = [m for m in methods if m in skip]
        for method in methods:
            if method in skip:
                continue
            try:
                result = detect(
                    test, build(method, contamination, seed), fit_df=capped(train, method, seed)
                )
            except Exception as error:  # a failing model is recorded, not hidden
                errors.setdefault(method, []).append({"seed": seed, "error": repr(error)})
                continue
            row = compute_metrics(part["y_test"], result.flags.to_numpy(), result.scores.to_numpy())
            metrics.setdefault(method, []).append(row)
    return {"seeds": list(seeds), "metrics": metrics, "skipped": skipped, "errors": errors}


def x_run_problem__mutmut_28(
    x: np.ndarray,
    y: np.ndarray,
    seeds: tuple[int, ...] = config.BENCHMARK_SEEDS,
    methods: list[str] | None = None,
) -> dict[str, Any]:
    methods = methods or METHODS
    unknown = [m for m in methods if m not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    metrics: dict[str, list[dict[str, float]]] = {}
    errors: dict[str, list[dict[str, Any]]] = {}
    skipped: list[str] = []
    for seed in seeds:
        part = nm.split(x, y, seed)
        names = [f"f{i}" for i in range(x.shape[1])]
        train = pd.DataFrame(part["x_train"], columns=names)
        test = pd.DataFrame(part["x_test"], columns=None)
        contamination = clip_contamination(float(part["y_train"].mean()))
        skip = nm.skipped_detectors(len(train))
        skipped = [m for m in methods if m in skip]
        for method in methods:
            if method in skip:
                continue
            try:
                result = detect(
                    test, build(method, contamination, seed), fit_df=capped(train, method, seed)
                )
            except Exception as error:  # a failing model is recorded, not hidden
                errors.setdefault(method, []).append({"seed": seed, "error": repr(error)})
                continue
            row = compute_metrics(part["y_test"], result.flags.to_numpy(), result.scores.to_numpy())
            metrics.setdefault(method, []).append(row)
    return {"seeds": list(seeds), "metrics": metrics, "skipped": skipped, "errors": errors}


def x_run_problem__mutmut_29(
    x: np.ndarray,
    y: np.ndarray,
    seeds: tuple[int, ...] = config.BENCHMARK_SEEDS,
    methods: list[str] | None = None,
) -> dict[str, Any]:
    methods = methods or METHODS
    unknown = [m for m in methods if m not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    metrics: dict[str, list[dict[str, float]]] = {}
    errors: dict[str, list[dict[str, Any]]] = {}
    skipped: list[str] = []
    for seed in seeds:
        part = nm.split(x, y, seed)
        names = [f"f{i}" for i in range(x.shape[1])]
        train = pd.DataFrame(part["x_train"], columns=names)
        test = pd.DataFrame(columns=names)
        contamination = clip_contamination(float(part["y_train"].mean()))
        skip = nm.skipped_detectors(len(train))
        skipped = [m for m in methods if m in skip]
        for method in methods:
            if method in skip:
                continue
            try:
                result = detect(
                    test, build(method, contamination, seed), fit_df=capped(train, method, seed)
                )
            except Exception as error:  # a failing model is recorded, not hidden
                errors.setdefault(method, []).append({"seed": seed, "error": repr(error)})
                continue
            row = compute_metrics(part["y_test"], result.flags.to_numpy(), result.scores.to_numpy())
            metrics.setdefault(method, []).append(row)
    return {"seeds": list(seeds), "metrics": metrics, "skipped": skipped, "errors": errors}


def x_run_problem__mutmut_30(
    x: np.ndarray,
    y: np.ndarray,
    seeds: tuple[int, ...] = config.BENCHMARK_SEEDS,
    methods: list[str] | None = None,
) -> dict[str, Any]:
    methods = methods or METHODS
    unknown = [m for m in methods if m not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    metrics: dict[str, list[dict[str, float]]] = {}
    errors: dict[str, list[dict[str, Any]]] = {}
    skipped: list[str] = []
    for seed in seeds:
        part = nm.split(x, y, seed)
        names = [f"f{i}" for i in range(x.shape[1])]
        train = pd.DataFrame(part["x_train"], columns=names)
        test = pd.DataFrame(part["x_test"], )
        contamination = clip_contamination(float(part["y_train"].mean()))
        skip = nm.skipped_detectors(len(train))
        skipped = [m for m in methods if m in skip]
        for method in methods:
            if method in skip:
                continue
            try:
                result = detect(
                    test, build(method, contamination, seed), fit_df=capped(train, method, seed)
                )
            except Exception as error:  # a failing model is recorded, not hidden
                errors.setdefault(method, []).append({"seed": seed, "error": repr(error)})
                continue
            row = compute_metrics(part["y_test"], result.flags.to_numpy(), result.scores.to_numpy())
            metrics.setdefault(method, []).append(row)
    return {"seeds": list(seeds), "metrics": metrics, "skipped": skipped, "errors": errors}


def x_run_problem__mutmut_31(
    x: np.ndarray,
    y: np.ndarray,
    seeds: tuple[int, ...] = config.BENCHMARK_SEEDS,
    methods: list[str] | None = None,
) -> dict[str, Any]:
    methods = methods or METHODS
    unknown = [m for m in methods if m not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    metrics: dict[str, list[dict[str, float]]] = {}
    errors: dict[str, list[dict[str, Any]]] = {}
    skipped: list[str] = []
    for seed in seeds:
        part = nm.split(x, y, seed)
        names = [f"f{i}" for i in range(x.shape[1])]
        train = pd.DataFrame(part["x_train"], columns=names)
        test = pd.DataFrame(part["XXx_testXX"], columns=names)
        contamination = clip_contamination(float(part["y_train"].mean()))
        skip = nm.skipped_detectors(len(train))
        skipped = [m for m in methods if m in skip]
        for method in methods:
            if method in skip:
                continue
            try:
                result = detect(
                    test, build(method, contamination, seed), fit_df=capped(train, method, seed)
                )
            except Exception as error:  # a failing model is recorded, not hidden
                errors.setdefault(method, []).append({"seed": seed, "error": repr(error)})
                continue
            row = compute_metrics(part["y_test"], result.flags.to_numpy(), result.scores.to_numpy())
            metrics.setdefault(method, []).append(row)
    return {"seeds": list(seeds), "metrics": metrics, "skipped": skipped, "errors": errors}


def x_run_problem__mutmut_32(
    x: np.ndarray,
    y: np.ndarray,
    seeds: tuple[int, ...] = config.BENCHMARK_SEEDS,
    methods: list[str] | None = None,
) -> dict[str, Any]:
    methods = methods or METHODS
    unknown = [m for m in methods if m not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    metrics: dict[str, list[dict[str, float]]] = {}
    errors: dict[str, list[dict[str, Any]]] = {}
    skipped: list[str] = []
    for seed in seeds:
        part = nm.split(x, y, seed)
        names = [f"f{i}" for i in range(x.shape[1])]
        train = pd.DataFrame(part["x_train"], columns=names)
        test = pd.DataFrame(part["X_TEST"], columns=names)
        contamination = clip_contamination(float(part["y_train"].mean()))
        skip = nm.skipped_detectors(len(train))
        skipped = [m for m in methods if m in skip]
        for method in methods:
            if method in skip:
                continue
            try:
                result = detect(
                    test, build(method, contamination, seed), fit_df=capped(train, method, seed)
                )
            except Exception as error:  # a failing model is recorded, not hidden
                errors.setdefault(method, []).append({"seed": seed, "error": repr(error)})
                continue
            row = compute_metrics(part["y_test"], result.flags.to_numpy(), result.scores.to_numpy())
            metrics.setdefault(method, []).append(row)
    return {"seeds": list(seeds), "metrics": metrics, "skipped": skipped, "errors": errors}


def x_run_problem__mutmut_33(
    x: np.ndarray,
    y: np.ndarray,
    seeds: tuple[int, ...] = config.BENCHMARK_SEEDS,
    methods: list[str] | None = None,
) -> dict[str, Any]:
    methods = methods or METHODS
    unknown = [m for m in methods if m not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    metrics: dict[str, list[dict[str, float]]] = {}
    errors: dict[str, list[dict[str, Any]]] = {}
    skipped: list[str] = []
    for seed in seeds:
        part = nm.split(x, y, seed)
        names = [f"f{i}" for i in range(x.shape[1])]
        train = pd.DataFrame(part["x_train"], columns=names)
        test = pd.DataFrame(part["x_test"], columns=names)
        contamination = None
        skip = nm.skipped_detectors(len(train))
        skipped = [m for m in methods if m in skip]
        for method in methods:
            if method in skip:
                continue
            try:
                result = detect(
                    test, build(method, contamination, seed), fit_df=capped(train, method, seed)
                )
            except Exception as error:  # a failing model is recorded, not hidden
                errors.setdefault(method, []).append({"seed": seed, "error": repr(error)})
                continue
            row = compute_metrics(part["y_test"], result.flags.to_numpy(), result.scores.to_numpy())
            metrics.setdefault(method, []).append(row)
    return {"seeds": list(seeds), "metrics": metrics, "skipped": skipped, "errors": errors}


def x_run_problem__mutmut_34(
    x: np.ndarray,
    y: np.ndarray,
    seeds: tuple[int, ...] = config.BENCHMARK_SEEDS,
    methods: list[str] | None = None,
) -> dict[str, Any]:
    methods = methods or METHODS
    unknown = [m for m in methods if m not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    metrics: dict[str, list[dict[str, float]]] = {}
    errors: dict[str, list[dict[str, Any]]] = {}
    skipped: list[str] = []
    for seed in seeds:
        part = nm.split(x, y, seed)
        names = [f"f{i}" for i in range(x.shape[1])]
        train = pd.DataFrame(part["x_train"], columns=names)
        test = pd.DataFrame(part["x_test"], columns=names)
        contamination = clip_contamination(None)
        skip = nm.skipped_detectors(len(train))
        skipped = [m for m in methods if m in skip]
        for method in methods:
            if method in skip:
                continue
            try:
                result = detect(
                    test, build(method, contamination, seed), fit_df=capped(train, method, seed)
                )
            except Exception as error:  # a failing model is recorded, not hidden
                errors.setdefault(method, []).append({"seed": seed, "error": repr(error)})
                continue
            row = compute_metrics(part["y_test"], result.flags.to_numpy(), result.scores.to_numpy())
            metrics.setdefault(method, []).append(row)
    return {"seeds": list(seeds), "metrics": metrics, "skipped": skipped, "errors": errors}


def x_run_problem__mutmut_35(
    x: np.ndarray,
    y: np.ndarray,
    seeds: tuple[int, ...] = config.BENCHMARK_SEEDS,
    methods: list[str] | None = None,
) -> dict[str, Any]:
    methods = methods or METHODS
    unknown = [m for m in methods if m not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    metrics: dict[str, list[dict[str, float]]] = {}
    errors: dict[str, list[dict[str, Any]]] = {}
    skipped: list[str] = []
    for seed in seeds:
        part = nm.split(x, y, seed)
        names = [f"f{i}" for i in range(x.shape[1])]
        train = pd.DataFrame(part["x_train"], columns=names)
        test = pd.DataFrame(part["x_test"], columns=names)
        contamination = clip_contamination(float(None))
        skip = nm.skipped_detectors(len(train))
        skipped = [m for m in methods if m in skip]
        for method in methods:
            if method in skip:
                continue
            try:
                result = detect(
                    test, build(method, contamination, seed), fit_df=capped(train, method, seed)
                )
            except Exception as error:  # a failing model is recorded, not hidden
                errors.setdefault(method, []).append({"seed": seed, "error": repr(error)})
                continue
            row = compute_metrics(part["y_test"], result.flags.to_numpy(), result.scores.to_numpy())
            metrics.setdefault(method, []).append(row)
    return {"seeds": list(seeds), "metrics": metrics, "skipped": skipped, "errors": errors}


def x_run_problem__mutmut_36(
    x: np.ndarray,
    y: np.ndarray,
    seeds: tuple[int, ...] = config.BENCHMARK_SEEDS,
    methods: list[str] | None = None,
) -> dict[str, Any]:
    methods = methods or METHODS
    unknown = [m for m in methods if m not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    metrics: dict[str, list[dict[str, float]]] = {}
    errors: dict[str, list[dict[str, Any]]] = {}
    skipped: list[str] = []
    for seed in seeds:
        part = nm.split(x, y, seed)
        names = [f"f{i}" for i in range(x.shape[1])]
        train = pd.DataFrame(part["x_train"], columns=names)
        test = pd.DataFrame(part["x_test"], columns=names)
        contamination = clip_contamination(float(part["XXy_trainXX"].mean()))
        skip = nm.skipped_detectors(len(train))
        skipped = [m for m in methods if m in skip]
        for method in methods:
            if method in skip:
                continue
            try:
                result = detect(
                    test, build(method, contamination, seed), fit_df=capped(train, method, seed)
                )
            except Exception as error:  # a failing model is recorded, not hidden
                errors.setdefault(method, []).append({"seed": seed, "error": repr(error)})
                continue
            row = compute_metrics(part["y_test"], result.flags.to_numpy(), result.scores.to_numpy())
            metrics.setdefault(method, []).append(row)
    return {"seeds": list(seeds), "metrics": metrics, "skipped": skipped, "errors": errors}


def x_run_problem__mutmut_37(
    x: np.ndarray,
    y: np.ndarray,
    seeds: tuple[int, ...] = config.BENCHMARK_SEEDS,
    methods: list[str] | None = None,
) -> dict[str, Any]:
    methods = methods or METHODS
    unknown = [m for m in methods if m not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    metrics: dict[str, list[dict[str, float]]] = {}
    errors: dict[str, list[dict[str, Any]]] = {}
    skipped: list[str] = []
    for seed in seeds:
        part = nm.split(x, y, seed)
        names = [f"f{i}" for i in range(x.shape[1])]
        train = pd.DataFrame(part["x_train"], columns=names)
        test = pd.DataFrame(part["x_test"], columns=names)
        contamination = clip_contamination(float(part["Y_TRAIN"].mean()))
        skip = nm.skipped_detectors(len(train))
        skipped = [m for m in methods if m in skip]
        for method in methods:
            if method in skip:
                continue
            try:
                result = detect(
                    test, build(method, contamination, seed), fit_df=capped(train, method, seed)
                )
            except Exception as error:  # a failing model is recorded, not hidden
                errors.setdefault(method, []).append({"seed": seed, "error": repr(error)})
                continue
            row = compute_metrics(part["y_test"], result.flags.to_numpy(), result.scores.to_numpy())
            metrics.setdefault(method, []).append(row)
    return {"seeds": list(seeds), "metrics": metrics, "skipped": skipped, "errors": errors}


def x_run_problem__mutmut_38(
    x: np.ndarray,
    y: np.ndarray,
    seeds: tuple[int, ...] = config.BENCHMARK_SEEDS,
    methods: list[str] | None = None,
) -> dict[str, Any]:
    methods = methods or METHODS
    unknown = [m for m in methods if m not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    metrics: dict[str, list[dict[str, float]]] = {}
    errors: dict[str, list[dict[str, Any]]] = {}
    skipped: list[str] = []
    for seed in seeds:
        part = nm.split(x, y, seed)
        names = [f"f{i}" for i in range(x.shape[1])]
        train = pd.DataFrame(part["x_train"], columns=names)
        test = pd.DataFrame(part["x_test"], columns=names)
        contamination = clip_contamination(float(part["y_train"].mean()))
        skip = None
        skipped = [m for m in methods if m in skip]
        for method in methods:
            if method in skip:
                continue
            try:
                result = detect(
                    test, build(method, contamination, seed), fit_df=capped(train, method, seed)
                )
            except Exception as error:  # a failing model is recorded, not hidden
                errors.setdefault(method, []).append({"seed": seed, "error": repr(error)})
                continue
            row = compute_metrics(part["y_test"], result.flags.to_numpy(), result.scores.to_numpy())
            metrics.setdefault(method, []).append(row)
    return {"seeds": list(seeds), "metrics": metrics, "skipped": skipped, "errors": errors}


def x_run_problem__mutmut_39(
    x: np.ndarray,
    y: np.ndarray,
    seeds: tuple[int, ...] = config.BENCHMARK_SEEDS,
    methods: list[str] | None = None,
) -> dict[str, Any]:
    methods = methods or METHODS
    unknown = [m for m in methods if m not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    metrics: dict[str, list[dict[str, float]]] = {}
    errors: dict[str, list[dict[str, Any]]] = {}
    skipped: list[str] = []
    for seed in seeds:
        part = nm.split(x, y, seed)
        names = [f"f{i}" for i in range(x.shape[1])]
        train = pd.DataFrame(part["x_train"], columns=names)
        test = pd.DataFrame(part["x_test"], columns=names)
        contamination = clip_contamination(float(part["y_train"].mean()))
        skip = nm.skipped_detectors(None)
        skipped = [m for m in methods if m in skip]
        for method in methods:
            if method in skip:
                continue
            try:
                result = detect(
                    test, build(method, contamination, seed), fit_df=capped(train, method, seed)
                )
            except Exception as error:  # a failing model is recorded, not hidden
                errors.setdefault(method, []).append({"seed": seed, "error": repr(error)})
                continue
            row = compute_metrics(part["y_test"], result.flags.to_numpy(), result.scores.to_numpy())
            metrics.setdefault(method, []).append(row)
    return {"seeds": list(seeds), "metrics": metrics, "skipped": skipped, "errors": errors}


def x_run_problem__mutmut_40(
    x: np.ndarray,
    y: np.ndarray,
    seeds: tuple[int, ...] = config.BENCHMARK_SEEDS,
    methods: list[str] | None = None,
) -> dict[str, Any]:
    methods = methods or METHODS
    unknown = [m for m in methods if m not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    metrics: dict[str, list[dict[str, float]]] = {}
    errors: dict[str, list[dict[str, Any]]] = {}
    skipped: list[str] = []
    for seed in seeds:
        part = nm.split(x, y, seed)
        names = [f"f{i}" for i in range(x.shape[1])]
        train = pd.DataFrame(part["x_train"], columns=names)
        test = pd.DataFrame(part["x_test"], columns=names)
        contamination = clip_contamination(float(part["y_train"].mean()))
        skip = nm.skipped_detectors(len(train))
        skipped = None
        for method in methods:
            if method in skip:
                continue
            try:
                result = detect(
                    test, build(method, contamination, seed), fit_df=capped(train, method, seed)
                )
            except Exception as error:  # a failing model is recorded, not hidden
                errors.setdefault(method, []).append({"seed": seed, "error": repr(error)})
                continue
            row = compute_metrics(part["y_test"], result.flags.to_numpy(), result.scores.to_numpy())
            metrics.setdefault(method, []).append(row)
    return {"seeds": list(seeds), "metrics": metrics, "skipped": skipped, "errors": errors}


def x_run_problem__mutmut_41(
    x: np.ndarray,
    y: np.ndarray,
    seeds: tuple[int, ...] = config.BENCHMARK_SEEDS,
    methods: list[str] | None = None,
) -> dict[str, Any]:
    methods = methods or METHODS
    unknown = [m for m in methods if m not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    metrics: dict[str, list[dict[str, float]]] = {}
    errors: dict[str, list[dict[str, Any]]] = {}
    skipped: list[str] = []
    for seed in seeds:
        part = nm.split(x, y, seed)
        names = [f"f{i}" for i in range(x.shape[1])]
        train = pd.DataFrame(part["x_train"], columns=names)
        test = pd.DataFrame(part["x_test"], columns=names)
        contamination = clip_contamination(float(part["y_train"].mean()))
        skip = nm.skipped_detectors(len(train))
        skipped = [m for m in methods if m not in skip]
        for method in methods:
            if method in skip:
                continue
            try:
                result = detect(
                    test, build(method, contamination, seed), fit_df=capped(train, method, seed)
                )
            except Exception as error:  # a failing model is recorded, not hidden
                errors.setdefault(method, []).append({"seed": seed, "error": repr(error)})
                continue
            row = compute_metrics(part["y_test"], result.flags.to_numpy(), result.scores.to_numpy())
            metrics.setdefault(method, []).append(row)
    return {"seeds": list(seeds), "metrics": metrics, "skipped": skipped, "errors": errors}


def x_run_problem__mutmut_42(
    x: np.ndarray,
    y: np.ndarray,
    seeds: tuple[int, ...] = config.BENCHMARK_SEEDS,
    methods: list[str] | None = None,
) -> dict[str, Any]:
    methods = methods or METHODS
    unknown = [m for m in methods if m not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    metrics: dict[str, list[dict[str, float]]] = {}
    errors: dict[str, list[dict[str, Any]]] = {}
    skipped: list[str] = []
    for seed in seeds:
        part = nm.split(x, y, seed)
        names = [f"f{i}" for i in range(x.shape[1])]
        train = pd.DataFrame(part["x_train"], columns=names)
        test = pd.DataFrame(part["x_test"], columns=names)
        contamination = clip_contamination(float(part["y_train"].mean()))
        skip = nm.skipped_detectors(len(train))
        skipped = [m for m in methods if m in skip]
        for method in methods:
            if method not in skip:
                continue
            try:
                result = detect(
                    test, build(method, contamination, seed), fit_df=capped(train, method, seed)
                )
            except Exception as error:  # a failing model is recorded, not hidden
                errors.setdefault(method, []).append({"seed": seed, "error": repr(error)})
                continue
            row = compute_metrics(part["y_test"], result.flags.to_numpy(), result.scores.to_numpy())
            metrics.setdefault(method, []).append(row)
    return {"seeds": list(seeds), "metrics": metrics, "skipped": skipped, "errors": errors}


def x_run_problem__mutmut_43(
    x: np.ndarray,
    y: np.ndarray,
    seeds: tuple[int, ...] = config.BENCHMARK_SEEDS,
    methods: list[str] | None = None,
) -> dict[str, Any]:
    methods = methods or METHODS
    unknown = [m for m in methods if m not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    metrics: dict[str, list[dict[str, float]]] = {}
    errors: dict[str, list[dict[str, Any]]] = {}
    skipped: list[str] = []
    for seed in seeds:
        part = nm.split(x, y, seed)
        names = [f"f{i}" for i in range(x.shape[1])]
        train = pd.DataFrame(part["x_train"], columns=names)
        test = pd.DataFrame(part["x_test"], columns=names)
        contamination = clip_contamination(float(part["y_train"].mean()))
        skip = nm.skipped_detectors(len(train))
        skipped = [m for m in methods if m in skip]
        for method in methods:
            if method in skip:
                break
            try:
                result = detect(
                    test, build(method, contamination, seed), fit_df=capped(train, method, seed)
                )
            except Exception as error:  # a failing model is recorded, not hidden
                errors.setdefault(method, []).append({"seed": seed, "error": repr(error)})
                continue
            row = compute_metrics(part["y_test"], result.flags.to_numpy(), result.scores.to_numpy())
            metrics.setdefault(method, []).append(row)
    return {"seeds": list(seeds), "metrics": metrics, "skipped": skipped, "errors": errors}


def x_run_problem__mutmut_44(
    x: np.ndarray,
    y: np.ndarray,
    seeds: tuple[int, ...] = config.BENCHMARK_SEEDS,
    methods: list[str] | None = None,
) -> dict[str, Any]:
    methods = methods or METHODS
    unknown = [m for m in methods if m not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    metrics: dict[str, list[dict[str, float]]] = {}
    errors: dict[str, list[dict[str, Any]]] = {}
    skipped: list[str] = []
    for seed in seeds:
        part = nm.split(x, y, seed)
        names = [f"f{i}" for i in range(x.shape[1])]
        train = pd.DataFrame(part["x_train"], columns=names)
        test = pd.DataFrame(part["x_test"], columns=names)
        contamination = clip_contamination(float(part["y_train"].mean()))
        skip = nm.skipped_detectors(len(train))
        skipped = [m for m in methods if m in skip]
        for method in methods:
            if method in skip:
                continue
            try:
                result = None
            except Exception as error:  # a failing model is recorded, not hidden
                errors.setdefault(method, []).append({"seed": seed, "error": repr(error)})
                continue
            row = compute_metrics(part["y_test"], result.flags.to_numpy(), result.scores.to_numpy())
            metrics.setdefault(method, []).append(row)
    return {"seeds": list(seeds), "metrics": metrics, "skipped": skipped, "errors": errors}


def x_run_problem__mutmut_45(
    x: np.ndarray,
    y: np.ndarray,
    seeds: tuple[int, ...] = config.BENCHMARK_SEEDS,
    methods: list[str] | None = None,
) -> dict[str, Any]:
    methods = methods or METHODS
    unknown = [m for m in methods if m not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    metrics: dict[str, list[dict[str, float]]] = {}
    errors: dict[str, list[dict[str, Any]]] = {}
    skipped: list[str] = []
    for seed in seeds:
        part = nm.split(x, y, seed)
        names = [f"f{i}" for i in range(x.shape[1])]
        train = pd.DataFrame(part["x_train"], columns=names)
        test = pd.DataFrame(part["x_test"], columns=names)
        contamination = clip_contamination(float(part["y_train"].mean()))
        skip = nm.skipped_detectors(len(train))
        skipped = [m for m in methods if m in skip]
        for method in methods:
            if method in skip:
                continue
            try:
                result = detect(
                    None, build(method, contamination, seed), fit_df=capped(train, method, seed)
                )
            except Exception as error:  # a failing model is recorded, not hidden
                errors.setdefault(method, []).append({"seed": seed, "error": repr(error)})
                continue
            row = compute_metrics(part["y_test"], result.flags.to_numpy(), result.scores.to_numpy())
            metrics.setdefault(method, []).append(row)
    return {"seeds": list(seeds), "metrics": metrics, "skipped": skipped, "errors": errors}


def x_run_problem__mutmut_46(
    x: np.ndarray,
    y: np.ndarray,
    seeds: tuple[int, ...] = config.BENCHMARK_SEEDS,
    methods: list[str] | None = None,
) -> dict[str, Any]:
    methods = methods or METHODS
    unknown = [m for m in methods if m not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    metrics: dict[str, list[dict[str, float]]] = {}
    errors: dict[str, list[dict[str, Any]]] = {}
    skipped: list[str] = []
    for seed in seeds:
        part = nm.split(x, y, seed)
        names = [f"f{i}" for i in range(x.shape[1])]
        train = pd.DataFrame(part["x_train"], columns=names)
        test = pd.DataFrame(part["x_test"], columns=names)
        contamination = clip_contamination(float(part["y_train"].mean()))
        skip = nm.skipped_detectors(len(train))
        skipped = [m for m in methods if m in skip]
        for method in methods:
            if method in skip:
                continue
            try:
                result = detect(
                    test, None, fit_df=capped(train, method, seed)
                )
            except Exception as error:  # a failing model is recorded, not hidden
                errors.setdefault(method, []).append({"seed": seed, "error": repr(error)})
                continue
            row = compute_metrics(part["y_test"], result.flags.to_numpy(), result.scores.to_numpy())
            metrics.setdefault(method, []).append(row)
    return {"seeds": list(seeds), "metrics": metrics, "skipped": skipped, "errors": errors}


def x_run_problem__mutmut_47(
    x: np.ndarray,
    y: np.ndarray,
    seeds: tuple[int, ...] = config.BENCHMARK_SEEDS,
    methods: list[str] | None = None,
) -> dict[str, Any]:
    methods = methods or METHODS
    unknown = [m for m in methods if m not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    metrics: dict[str, list[dict[str, float]]] = {}
    errors: dict[str, list[dict[str, Any]]] = {}
    skipped: list[str] = []
    for seed in seeds:
        part = nm.split(x, y, seed)
        names = [f"f{i}" for i in range(x.shape[1])]
        train = pd.DataFrame(part["x_train"], columns=names)
        test = pd.DataFrame(part["x_test"], columns=names)
        contamination = clip_contamination(float(part["y_train"].mean()))
        skip = nm.skipped_detectors(len(train))
        skipped = [m for m in methods if m in skip]
        for method in methods:
            if method in skip:
                continue
            try:
                result = detect(
                    test, build(method, contamination, seed), fit_df=None
                )
            except Exception as error:  # a failing model is recorded, not hidden
                errors.setdefault(method, []).append({"seed": seed, "error": repr(error)})
                continue
            row = compute_metrics(part["y_test"], result.flags.to_numpy(), result.scores.to_numpy())
            metrics.setdefault(method, []).append(row)
    return {"seeds": list(seeds), "metrics": metrics, "skipped": skipped, "errors": errors}


def x_run_problem__mutmut_48(
    x: np.ndarray,
    y: np.ndarray,
    seeds: tuple[int, ...] = config.BENCHMARK_SEEDS,
    methods: list[str] | None = None,
) -> dict[str, Any]:
    methods = methods or METHODS
    unknown = [m for m in methods if m not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    metrics: dict[str, list[dict[str, float]]] = {}
    errors: dict[str, list[dict[str, Any]]] = {}
    skipped: list[str] = []
    for seed in seeds:
        part = nm.split(x, y, seed)
        names = [f"f{i}" for i in range(x.shape[1])]
        train = pd.DataFrame(part["x_train"], columns=names)
        test = pd.DataFrame(part["x_test"], columns=names)
        contamination = clip_contamination(float(part["y_train"].mean()))
        skip = nm.skipped_detectors(len(train))
        skipped = [m for m in methods if m in skip]
        for method in methods:
            if method in skip:
                continue
            try:
                result = detect(
                    build(method, contamination, seed), fit_df=capped(train, method, seed)
                )
            except Exception as error:  # a failing model is recorded, not hidden
                errors.setdefault(method, []).append({"seed": seed, "error": repr(error)})
                continue
            row = compute_metrics(part["y_test"], result.flags.to_numpy(), result.scores.to_numpy())
            metrics.setdefault(method, []).append(row)
    return {"seeds": list(seeds), "metrics": metrics, "skipped": skipped, "errors": errors}


def x_run_problem__mutmut_49(
    x: np.ndarray,
    y: np.ndarray,
    seeds: tuple[int, ...] = config.BENCHMARK_SEEDS,
    methods: list[str] | None = None,
) -> dict[str, Any]:
    methods = methods or METHODS
    unknown = [m for m in methods if m not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    metrics: dict[str, list[dict[str, float]]] = {}
    errors: dict[str, list[dict[str, Any]]] = {}
    skipped: list[str] = []
    for seed in seeds:
        part = nm.split(x, y, seed)
        names = [f"f{i}" for i in range(x.shape[1])]
        train = pd.DataFrame(part["x_train"], columns=names)
        test = pd.DataFrame(part["x_test"], columns=names)
        contamination = clip_contamination(float(part["y_train"].mean()))
        skip = nm.skipped_detectors(len(train))
        skipped = [m for m in methods if m in skip]
        for method in methods:
            if method in skip:
                continue
            try:
                result = detect(
                    test, fit_df=capped(train, method, seed)
                )
            except Exception as error:  # a failing model is recorded, not hidden
                errors.setdefault(method, []).append({"seed": seed, "error": repr(error)})
                continue
            row = compute_metrics(part["y_test"], result.flags.to_numpy(), result.scores.to_numpy())
            metrics.setdefault(method, []).append(row)
    return {"seeds": list(seeds), "metrics": metrics, "skipped": skipped, "errors": errors}


def x_run_problem__mutmut_50(
    x: np.ndarray,
    y: np.ndarray,
    seeds: tuple[int, ...] = config.BENCHMARK_SEEDS,
    methods: list[str] | None = None,
) -> dict[str, Any]:
    methods = methods or METHODS
    unknown = [m for m in methods if m not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    metrics: dict[str, list[dict[str, float]]] = {}
    errors: dict[str, list[dict[str, Any]]] = {}
    skipped: list[str] = []
    for seed in seeds:
        part = nm.split(x, y, seed)
        names = [f"f{i}" for i in range(x.shape[1])]
        train = pd.DataFrame(part["x_train"], columns=names)
        test = pd.DataFrame(part["x_test"], columns=names)
        contamination = clip_contamination(float(part["y_train"].mean()))
        skip = nm.skipped_detectors(len(train))
        skipped = [m for m in methods if m in skip]
        for method in methods:
            if method in skip:
                continue
            try:
                result = detect(
                    test, build(method, contamination, seed), )
            except Exception as error:  # a failing model is recorded, not hidden
                errors.setdefault(method, []).append({"seed": seed, "error": repr(error)})
                continue
            row = compute_metrics(part["y_test"], result.flags.to_numpy(), result.scores.to_numpy())
            metrics.setdefault(method, []).append(row)
    return {"seeds": list(seeds), "metrics": metrics, "skipped": skipped, "errors": errors}


def x_run_problem__mutmut_51(
    x: np.ndarray,
    y: np.ndarray,
    seeds: tuple[int, ...] = config.BENCHMARK_SEEDS,
    methods: list[str] | None = None,
) -> dict[str, Any]:
    methods = methods or METHODS
    unknown = [m for m in methods if m not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    metrics: dict[str, list[dict[str, float]]] = {}
    errors: dict[str, list[dict[str, Any]]] = {}
    skipped: list[str] = []
    for seed in seeds:
        part = nm.split(x, y, seed)
        names = [f"f{i}" for i in range(x.shape[1])]
        train = pd.DataFrame(part["x_train"], columns=names)
        test = pd.DataFrame(part["x_test"], columns=names)
        contamination = clip_contamination(float(part["y_train"].mean()))
        skip = nm.skipped_detectors(len(train))
        skipped = [m for m in methods if m in skip]
        for method in methods:
            if method in skip:
                continue
            try:
                result = detect(
                    test, build(None, contamination, seed), fit_df=capped(train, method, seed)
                )
            except Exception as error:  # a failing model is recorded, not hidden
                errors.setdefault(method, []).append({"seed": seed, "error": repr(error)})
                continue
            row = compute_metrics(part["y_test"], result.flags.to_numpy(), result.scores.to_numpy())
            metrics.setdefault(method, []).append(row)
    return {"seeds": list(seeds), "metrics": metrics, "skipped": skipped, "errors": errors}


def x_run_problem__mutmut_52(
    x: np.ndarray,
    y: np.ndarray,
    seeds: tuple[int, ...] = config.BENCHMARK_SEEDS,
    methods: list[str] | None = None,
) -> dict[str, Any]:
    methods = methods or METHODS
    unknown = [m for m in methods if m not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    metrics: dict[str, list[dict[str, float]]] = {}
    errors: dict[str, list[dict[str, Any]]] = {}
    skipped: list[str] = []
    for seed in seeds:
        part = nm.split(x, y, seed)
        names = [f"f{i}" for i in range(x.shape[1])]
        train = pd.DataFrame(part["x_train"], columns=names)
        test = pd.DataFrame(part["x_test"], columns=names)
        contamination = clip_contamination(float(part["y_train"].mean()))
        skip = nm.skipped_detectors(len(train))
        skipped = [m for m in methods if m in skip]
        for method in methods:
            if method in skip:
                continue
            try:
                result = detect(
                    test, build(method, None, seed), fit_df=capped(train, method, seed)
                )
            except Exception as error:  # a failing model is recorded, not hidden
                errors.setdefault(method, []).append({"seed": seed, "error": repr(error)})
                continue
            row = compute_metrics(part["y_test"], result.flags.to_numpy(), result.scores.to_numpy())
            metrics.setdefault(method, []).append(row)
    return {"seeds": list(seeds), "metrics": metrics, "skipped": skipped, "errors": errors}


def x_run_problem__mutmut_53(
    x: np.ndarray,
    y: np.ndarray,
    seeds: tuple[int, ...] = config.BENCHMARK_SEEDS,
    methods: list[str] | None = None,
) -> dict[str, Any]:
    methods = methods or METHODS
    unknown = [m for m in methods if m not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    metrics: dict[str, list[dict[str, float]]] = {}
    errors: dict[str, list[dict[str, Any]]] = {}
    skipped: list[str] = []
    for seed in seeds:
        part = nm.split(x, y, seed)
        names = [f"f{i}" for i in range(x.shape[1])]
        train = pd.DataFrame(part["x_train"], columns=names)
        test = pd.DataFrame(part["x_test"], columns=names)
        contamination = clip_contamination(float(part["y_train"].mean()))
        skip = nm.skipped_detectors(len(train))
        skipped = [m for m in methods if m in skip]
        for method in methods:
            if method in skip:
                continue
            try:
                result = detect(
                    test, build(method, contamination, None), fit_df=capped(train, method, seed)
                )
            except Exception as error:  # a failing model is recorded, not hidden
                errors.setdefault(method, []).append({"seed": seed, "error": repr(error)})
                continue
            row = compute_metrics(part["y_test"], result.flags.to_numpy(), result.scores.to_numpy())
            metrics.setdefault(method, []).append(row)
    return {"seeds": list(seeds), "metrics": metrics, "skipped": skipped, "errors": errors}


def x_run_problem__mutmut_54(
    x: np.ndarray,
    y: np.ndarray,
    seeds: tuple[int, ...] = config.BENCHMARK_SEEDS,
    methods: list[str] | None = None,
) -> dict[str, Any]:
    methods = methods or METHODS
    unknown = [m for m in methods if m not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    metrics: dict[str, list[dict[str, float]]] = {}
    errors: dict[str, list[dict[str, Any]]] = {}
    skipped: list[str] = []
    for seed in seeds:
        part = nm.split(x, y, seed)
        names = [f"f{i}" for i in range(x.shape[1])]
        train = pd.DataFrame(part["x_train"], columns=names)
        test = pd.DataFrame(part["x_test"], columns=names)
        contamination = clip_contamination(float(part["y_train"].mean()))
        skip = nm.skipped_detectors(len(train))
        skipped = [m for m in methods if m in skip]
        for method in methods:
            if method in skip:
                continue
            try:
                result = detect(
                    test, build(contamination, seed), fit_df=capped(train, method, seed)
                )
            except Exception as error:  # a failing model is recorded, not hidden
                errors.setdefault(method, []).append({"seed": seed, "error": repr(error)})
                continue
            row = compute_metrics(part["y_test"], result.flags.to_numpy(), result.scores.to_numpy())
            metrics.setdefault(method, []).append(row)
    return {"seeds": list(seeds), "metrics": metrics, "skipped": skipped, "errors": errors}


def x_run_problem__mutmut_55(
    x: np.ndarray,
    y: np.ndarray,
    seeds: tuple[int, ...] = config.BENCHMARK_SEEDS,
    methods: list[str] | None = None,
) -> dict[str, Any]:
    methods = methods or METHODS
    unknown = [m for m in methods if m not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    metrics: dict[str, list[dict[str, float]]] = {}
    errors: dict[str, list[dict[str, Any]]] = {}
    skipped: list[str] = []
    for seed in seeds:
        part = nm.split(x, y, seed)
        names = [f"f{i}" for i in range(x.shape[1])]
        train = pd.DataFrame(part["x_train"], columns=names)
        test = pd.DataFrame(part["x_test"], columns=names)
        contamination = clip_contamination(float(part["y_train"].mean()))
        skip = nm.skipped_detectors(len(train))
        skipped = [m for m in methods if m in skip]
        for method in methods:
            if method in skip:
                continue
            try:
                result = detect(
                    test, build(method, seed), fit_df=capped(train, method, seed)
                )
            except Exception as error:  # a failing model is recorded, not hidden
                errors.setdefault(method, []).append({"seed": seed, "error": repr(error)})
                continue
            row = compute_metrics(part["y_test"], result.flags.to_numpy(), result.scores.to_numpy())
            metrics.setdefault(method, []).append(row)
    return {"seeds": list(seeds), "metrics": metrics, "skipped": skipped, "errors": errors}


def x_run_problem__mutmut_56(
    x: np.ndarray,
    y: np.ndarray,
    seeds: tuple[int, ...] = config.BENCHMARK_SEEDS,
    methods: list[str] | None = None,
) -> dict[str, Any]:
    methods = methods or METHODS
    unknown = [m for m in methods if m not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    metrics: dict[str, list[dict[str, float]]] = {}
    errors: dict[str, list[dict[str, Any]]] = {}
    skipped: list[str] = []
    for seed in seeds:
        part = nm.split(x, y, seed)
        names = [f"f{i}" for i in range(x.shape[1])]
        train = pd.DataFrame(part["x_train"], columns=names)
        test = pd.DataFrame(part["x_test"], columns=names)
        contamination = clip_contamination(float(part["y_train"].mean()))
        skip = nm.skipped_detectors(len(train))
        skipped = [m for m in methods if m in skip]
        for method in methods:
            if method in skip:
                continue
            try:
                result = detect(
                    test, build(method, contamination, ), fit_df=capped(train, method, seed)
                )
            except Exception as error:  # a failing model is recorded, not hidden
                errors.setdefault(method, []).append({"seed": seed, "error": repr(error)})
                continue
            row = compute_metrics(part["y_test"], result.flags.to_numpy(), result.scores.to_numpy())
            metrics.setdefault(method, []).append(row)
    return {"seeds": list(seeds), "metrics": metrics, "skipped": skipped, "errors": errors}


def x_run_problem__mutmut_57(
    x: np.ndarray,
    y: np.ndarray,
    seeds: tuple[int, ...] = config.BENCHMARK_SEEDS,
    methods: list[str] | None = None,
) -> dict[str, Any]:
    methods = methods or METHODS
    unknown = [m for m in methods if m not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    metrics: dict[str, list[dict[str, float]]] = {}
    errors: dict[str, list[dict[str, Any]]] = {}
    skipped: list[str] = []
    for seed in seeds:
        part = nm.split(x, y, seed)
        names = [f"f{i}" for i in range(x.shape[1])]
        train = pd.DataFrame(part["x_train"], columns=names)
        test = pd.DataFrame(part["x_test"], columns=names)
        contamination = clip_contamination(float(part["y_train"].mean()))
        skip = nm.skipped_detectors(len(train))
        skipped = [m for m in methods if m in skip]
        for method in methods:
            if method in skip:
                continue
            try:
                result = detect(
                    test, build(method, contamination, seed), fit_df=capped(None, method, seed)
                )
            except Exception as error:  # a failing model is recorded, not hidden
                errors.setdefault(method, []).append({"seed": seed, "error": repr(error)})
                continue
            row = compute_metrics(part["y_test"], result.flags.to_numpy(), result.scores.to_numpy())
            metrics.setdefault(method, []).append(row)
    return {"seeds": list(seeds), "metrics": metrics, "skipped": skipped, "errors": errors}


def x_run_problem__mutmut_58(
    x: np.ndarray,
    y: np.ndarray,
    seeds: tuple[int, ...] = config.BENCHMARK_SEEDS,
    methods: list[str] | None = None,
) -> dict[str, Any]:
    methods = methods or METHODS
    unknown = [m for m in methods if m not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    metrics: dict[str, list[dict[str, float]]] = {}
    errors: dict[str, list[dict[str, Any]]] = {}
    skipped: list[str] = []
    for seed in seeds:
        part = nm.split(x, y, seed)
        names = [f"f{i}" for i in range(x.shape[1])]
        train = pd.DataFrame(part["x_train"], columns=names)
        test = pd.DataFrame(part["x_test"], columns=names)
        contamination = clip_contamination(float(part["y_train"].mean()))
        skip = nm.skipped_detectors(len(train))
        skipped = [m for m in methods if m in skip]
        for method in methods:
            if method in skip:
                continue
            try:
                result = detect(
                    test, build(method, contamination, seed), fit_df=capped(train, None, seed)
                )
            except Exception as error:  # a failing model is recorded, not hidden
                errors.setdefault(method, []).append({"seed": seed, "error": repr(error)})
                continue
            row = compute_metrics(part["y_test"], result.flags.to_numpy(), result.scores.to_numpy())
            metrics.setdefault(method, []).append(row)
    return {"seeds": list(seeds), "metrics": metrics, "skipped": skipped, "errors": errors}


def x_run_problem__mutmut_59(
    x: np.ndarray,
    y: np.ndarray,
    seeds: tuple[int, ...] = config.BENCHMARK_SEEDS,
    methods: list[str] | None = None,
) -> dict[str, Any]:
    methods = methods or METHODS
    unknown = [m for m in methods if m not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    metrics: dict[str, list[dict[str, float]]] = {}
    errors: dict[str, list[dict[str, Any]]] = {}
    skipped: list[str] = []
    for seed in seeds:
        part = nm.split(x, y, seed)
        names = [f"f{i}" for i in range(x.shape[1])]
        train = pd.DataFrame(part["x_train"], columns=names)
        test = pd.DataFrame(part["x_test"], columns=names)
        contamination = clip_contamination(float(part["y_train"].mean()))
        skip = nm.skipped_detectors(len(train))
        skipped = [m for m in methods if m in skip]
        for method in methods:
            if method in skip:
                continue
            try:
                result = detect(
                    test, build(method, contamination, seed), fit_df=capped(train, method, None)
                )
            except Exception as error:  # a failing model is recorded, not hidden
                errors.setdefault(method, []).append({"seed": seed, "error": repr(error)})
                continue
            row = compute_metrics(part["y_test"], result.flags.to_numpy(), result.scores.to_numpy())
            metrics.setdefault(method, []).append(row)
    return {"seeds": list(seeds), "metrics": metrics, "skipped": skipped, "errors": errors}


def x_run_problem__mutmut_60(
    x: np.ndarray,
    y: np.ndarray,
    seeds: tuple[int, ...] = config.BENCHMARK_SEEDS,
    methods: list[str] | None = None,
) -> dict[str, Any]:
    methods = methods or METHODS
    unknown = [m for m in methods if m not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    metrics: dict[str, list[dict[str, float]]] = {}
    errors: dict[str, list[dict[str, Any]]] = {}
    skipped: list[str] = []
    for seed in seeds:
        part = nm.split(x, y, seed)
        names = [f"f{i}" for i in range(x.shape[1])]
        train = pd.DataFrame(part["x_train"], columns=names)
        test = pd.DataFrame(part["x_test"], columns=names)
        contamination = clip_contamination(float(part["y_train"].mean()))
        skip = nm.skipped_detectors(len(train))
        skipped = [m for m in methods if m in skip]
        for method in methods:
            if method in skip:
                continue
            try:
                result = detect(
                    test, build(method, contamination, seed), fit_df=capped(method, seed)
                )
            except Exception as error:  # a failing model is recorded, not hidden
                errors.setdefault(method, []).append({"seed": seed, "error": repr(error)})
                continue
            row = compute_metrics(part["y_test"], result.flags.to_numpy(), result.scores.to_numpy())
            metrics.setdefault(method, []).append(row)
    return {"seeds": list(seeds), "metrics": metrics, "skipped": skipped, "errors": errors}


def x_run_problem__mutmut_61(
    x: np.ndarray,
    y: np.ndarray,
    seeds: tuple[int, ...] = config.BENCHMARK_SEEDS,
    methods: list[str] | None = None,
) -> dict[str, Any]:
    methods = methods or METHODS
    unknown = [m for m in methods if m not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    metrics: dict[str, list[dict[str, float]]] = {}
    errors: dict[str, list[dict[str, Any]]] = {}
    skipped: list[str] = []
    for seed in seeds:
        part = nm.split(x, y, seed)
        names = [f"f{i}" for i in range(x.shape[1])]
        train = pd.DataFrame(part["x_train"], columns=names)
        test = pd.DataFrame(part["x_test"], columns=names)
        contamination = clip_contamination(float(part["y_train"].mean()))
        skip = nm.skipped_detectors(len(train))
        skipped = [m for m in methods if m in skip]
        for method in methods:
            if method in skip:
                continue
            try:
                result = detect(
                    test, build(method, contamination, seed), fit_df=capped(train, seed)
                )
            except Exception as error:  # a failing model is recorded, not hidden
                errors.setdefault(method, []).append({"seed": seed, "error": repr(error)})
                continue
            row = compute_metrics(part["y_test"], result.flags.to_numpy(), result.scores.to_numpy())
            metrics.setdefault(method, []).append(row)
    return {"seeds": list(seeds), "metrics": metrics, "skipped": skipped, "errors": errors}


def x_run_problem__mutmut_62(
    x: np.ndarray,
    y: np.ndarray,
    seeds: tuple[int, ...] = config.BENCHMARK_SEEDS,
    methods: list[str] | None = None,
) -> dict[str, Any]:
    methods = methods or METHODS
    unknown = [m for m in methods if m not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    metrics: dict[str, list[dict[str, float]]] = {}
    errors: dict[str, list[dict[str, Any]]] = {}
    skipped: list[str] = []
    for seed in seeds:
        part = nm.split(x, y, seed)
        names = [f"f{i}" for i in range(x.shape[1])]
        train = pd.DataFrame(part["x_train"], columns=names)
        test = pd.DataFrame(part["x_test"], columns=names)
        contamination = clip_contamination(float(part["y_train"].mean()))
        skip = nm.skipped_detectors(len(train))
        skipped = [m for m in methods if m in skip]
        for method in methods:
            if method in skip:
                continue
            try:
                result = detect(
                    test, build(method, contamination, seed), fit_df=capped(train, method, )
                )
            except Exception as error:  # a failing model is recorded, not hidden
                errors.setdefault(method, []).append({"seed": seed, "error": repr(error)})
                continue
            row = compute_metrics(part["y_test"], result.flags.to_numpy(), result.scores.to_numpy())
            metrics.setdefault(method, []).append(row)
    return {"seeds": list(seeds), "metrics": metrics, "skipped": skipped, "errors": errors}


def x_run_problem__mutmut_63(
    x: np.ndarray,
    y: np.ndarray,
    seeds: tuple[int, ...] = config.BENCHMARK_SEEDS,
    methods: list[str] | None = None,
) -> dict[str, Any]:
    methods = methods or METHODS
    unknown = [m for m in methods if m not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    metrics: dict[str, list[dict[str, float]]] = {}
    errors: dict[str, list[dict[str, Any]]] = {}
    skipped: list[str] = []
    for seed in seeds:
        part = nm.split(x, y, seed)
        names = [f"f{i}" for i in range(x.shape[1])]
        train = pd.DataFrame(part["x_train"], columns=names)
        test = pd.DataFrame(part["x_test"], columns=names)
        contamination = clip_contamination(float(part["y_train"].mean()))
        skip = nm.skipped_detectors(len(train))
        skipped = [m for m in methods if m in skip]
        for method in methods:
            if method in skip:
                continue
            try:
                result = detect(
                    test, build(method, contamination, seed), fit_df=capped(train, method, seed)
                )
            except Exception as error:  # a failing model is recorded, not hidden
                errors.setdefault(method, []).append(None)
                continue
            row = compute_metrics(part["y_test"], result.flags.to_numpy(), result.scores.to_numpy())
            metrics.setdefault(method, []).append(row)
    return {"seeds": list(seeds), "metrics": metrics, "skipped": skipped, "errors": errors}


def x_run_problem__mutmut_64(
    x: np.ndarray,
    y: np.ndarray,
    seeds: tuple[int, ...] = config.BENCHMARK_SEEDS,
    methods: list[str] | None = None,
) -> dict[str, Any]:
    methods = methods or METHODS
    unknown = [m for m in methods if m not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    metrics: dict[str, list[dict[str, float]]] = {}
    errors: dict[str, list[dict[str, Any]]] = {}
    skipped: list[str] = []
    for seed in seeds:
        part = nm.split(x, y, seed)
        names = [f"f{i}" for i in range(x.shape[1])]
        train = pd.DataFrame(part["x_train"], columns=names)
        test = pd.DataFrame(part["x_test"], columns=names)
        contamination = clip_contamination(float(part["y_train"].mean()))
        skip = nm.skipped_detectors(len(train))
        skipped = [m for m in methods if m in skip]
        for method in methods:
            if method in skip:
                continue
            try:
                result = detect(
                    test, build(method, contamination, seed), fit_df=capped(train, method, seed)
                )
            except Exception as error:  # a failing model is recorded, not hidden
                errors.setdefault(None, []).append({"seed": seed, "error": repr(error)})
                continue
            row = compute_metrics(part["y_test"], result.flags.to_numpy(), result.scores.to_numpy())
            metrics.setdefault(method, []).append(row)
    return {"seeds": list(seeds), "metrics": metrics, "skipped": skipped, "errors": errors}


def x_run_problem__mutmut_65(
    x: np.ndarray,
    y: np.ndarray,
    seeds: tuple[int, ...] = config.BENCHMARK_SEEDS,
    methods: list[str] | None = None,
) -> dict[str, Any]:
    methods = methods or METHODS
    unknown = [m for m in methods if m not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    metrics: dict[str, list[dict[str, float]]] = {}
    errors: dict[str, list[dict[str, Any]]] = {}
    skipped: list[str] = []
    for seed in seeds:
        part = nm.split(x, y, seed)
        names = [f"f{i}" for i in range(x.shape[1])]
        train = pd.DataFrame(part["x_train"], columns=names)
        test = pd.DataFrame(part["x_test"], columns=names)
        contamination = clip_contamination(float(part["y_train"].mean()))
        skip = nm.skipped_detectors(len(train))
        skipped = [m for m in methods if m in skip]
        for method in methods:
            if method in skip:
                continue
            try:
                result = detect(
                    test, build(method, contamination, seed), fit_df=capped(train, method, seed)
                )
            except Exception as error:  # a failing model is recorded, not hidden
                errors.setdefault(method, None).append({"seed": seed, "error": repr(error)})
                continue
            row = compute_metrics(part["y_test"], result.flags.to_numpy(), result.scores.to_numpy())
            metrics.setdefault(method, []).append(row)
    return {"seeds": list(seeds), "metrics": metrics, "skipped": skipped, "errors": errors}


def x_run_problem__mutmut_66(
    x: np.ndarray,
    y: np.ndarray,
    seeds: tuple[int, ...] = config.BENCHMARK_SEEDS,
    methods: list[str] | None = None,
) -> dict[str, Any]:
    methods = methods or METHODS
    unknown = [m for m in methods if m not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    metrics: dict[str, list[dict[str, float]]] = {}
    errors: dict[str, list[dict[str, Any]]] = {}
    skipped: list[str] = []
    for seed in seeds:
        part = nm.split(x, y, seed)
        names = [f"f{i}" for i in range(x.shape[1])]
        train = pd.DataFrame(part["x_train"], columns=names)
        test = pd.DataFrame(part["x_test"], columns=names)
        contamination = clip_contamination(float(part["y_train"].mean()))
        skip = nm.skipped_detectors(len(train))
        skipped = [m for m in methods if m in skip]
        for method in methods:
            if method in skip:
                continue
            try:
                result = detect(
                    test, build(method, contamination, seed), fit_df=capped(train, method, seed)
                )
            except Exception as error:  # a failing model is recorded, not hidden
                errors.setdefault([]).append({"seed": seed, "error": repr(error)})
                continue
            row = compute_metrics(part["y_test"], result.flags.to_numpy(), result.scores.to_numpy())
            metrics.setdefault(method, []).append(row)
    return {"seeds": list(seeds), "metrics": metrics, "skipped": skipped, "errors": errors}


def x_run_problem__mutmut_67(
    x: np.ndarray,
    y: np.ndarray,
    seeds: tuple[int, ...] = config.BENCHMARK_SEEDS,
    methods: list[str] | None = None,
) -> dict[str, Any]:
    methods = methods or METHODS
    unknown = [m for m in methods if m not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    metrics: dict[str, list[dict[str, float]]] = {}
    errors: dict[str, list[dict[str, Any]]] = {}
    skipped: list[str] = []
    for seed in seeds:
        part = nm.split(x, y, seed)
        names = [f"f{i}" for i in range(x.shape[1])]
        train = pd.DataFrame(part["x_train"], columns=names)
        test = pd.DataFrame(part["x_test"], columns=names)
        contamination = clip_contamination(float(part["y_train"].mean()))
        skip = nm.skipped_detectors(len(train))
        skipped = [m for m in methods if m in skip]
        for method in methods:
            if method in skip:
                continue
            try:
                result = detect(
                    test, build(method, contamination, seed), fit_df=capped(train, method, seed)
                )
            except Exception as error:  # a failing model is recorded, not hidden
                errors.setdefault(method, ).append({"seed": seed, "error": repr(error)})
                continue
            row = compute_metrics(part["y_test"], result.flags.to_numpy(), result.scores.to_numpy())
            metrics.setdefault(method, []).append(row)
    return {"seeds": list(seeds), "metrics": metrics, "skipped": skipped, "errors": errors}


def x_run_problem__mutmut_68(
    x: np.ndarray,
    y: np.ndarray,
    seeds: tuple[int, ...] = config.BENCHMARK_SEEDS,
    methods: list[str] | None = None,
) -> dict[str, Any]:
    methods = methods or METHODS
    unknown = [m for m in methods if m not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    metrics: dict[str, list[dict[str, float]]] = {}
    errors: dict[str, list[dict[str, Any]]] = {}
    skipped: list[str] = []
    for seed in seeds:
        part = nm.split(x, y, seed)
        names = [f"f{i}" for i in range(x.shape[1])]
        train = pd.DataFrame(part["x_train"], columns=names)
        test = pd.DataFrame(part["x_test"], columns=names)
        contamination = clip_contamination(float(part["y_train"].mean()))
        skip = nm.skipped_detectors(len(train))
        skipped = [m for m in methods if m in skip]
        for method in methods:
            if method in skip:
                continue
            try:
                result = detect(
                    test, build(method, contamination, seed), fit_df=capped(train, method, seed)
                )
            except Exception as error:  # a failing model is recorded, not hidden
                errors.setdefault(method, []).append({"XXseedXX": seed, "error": repr(error)})
                continue
            row = compute_metrics(part["y_test"], result.flags.to_numpy(), result.scores.to_numpy())
            metrics.setdefault(method, []).append(row)
    return {"seeds": list(seeds), "metrics": metrics, "skipped": skipped, "errors": errors}


def x_run_problem__mutmut_69(
    x: np.ndarray,
    y: np.ndarray,
    seeds: tuple[int, ...] = config.BENCHMARK_SEEDS,
    methods: list[str] | None = None,
) -> dict[str, Any]:
    methods = methods or METHODS
    unknown = [m for m in methods if m not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    metrics: dict[str, list[dict[str, float]]] = {}
    errors: dict[str, list[dict[str, Any]]] = {}
    skipped: list[str] = []
    for seed in seeds:
        part = nm.split(x, y, seed)
        names = [f"f{i}" for i in range(x.shape[1])]
        train = pd.DataFrame(part["x_train"], columns=names)
        test = pd.DataFrame(part["x_test"], columns=names)
        contamination = clip_contamination(float(part["y_train"].mean()))
        skip = nm.skipped_detectors(len(train))
        skipped = [m for m in methods if m in skip]
        for method in methods:
            if method in skip:
                continue
            try:
                result = detect(
                    test, build(method, contamination, seed), fit_df=capped(train, method, seed)
                )
            except Exception as error:  # a failing model is recorded, not hidden
                errors.setdefault(method, []).append({"SEED": seed, "error": repr(error)})
                continue
            row = compute_metrics(part["y_test"], result.flags.to_numpy(), result.scores.to_numpy())
            metrics.setdefault(method, []).append(row)
    return {"seeds": list(seeds), "metrics": metrics, "skipped": skipped, "errors": errors}


def x_run_problem__mutmut_70(
    x: np.ndarray,
    y: np.ndarray,
    seeds: tuple[int, ...] = config.BENCHMARK_SEEDS,
    methods: list[str] | None = None,
) -> dict[str, Any]:
    methods = methods or METHODS
    unknown = [m for m in methods if m not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    metrics: dict[str, list[dict[str, float]]] = {}
    errors: dict[str, list[dict[str, Any]]] = {}
    skipped: list[str] = []
    for seed in seeds:
        part = nm.split(x, y, seed)
        names = [f"f{i}" for i in range(x.shape[1])]
        train = pd.DataFrame(part["x_train"], columns=names)
        test = pd.DataFrame(part["x_test"], columns=names)
        contamination = clip_contamination(float(part["y_train"].mean()))
        skip = nm.skipped_detectors(len(train))
        skipped = [m for m in methods if m in skip]
        for method in methods:
            if method in skip:
                continue
            try:
                result = detect(
                    test, build(method, contamination, seed), fit_df=capped(train, method, seed)
                )
            except Exception as error:  # a failing model is recorded, not hidden
                errors.setdefault(method, []).append({"seed": seed, "XXerrorXX": repr(error)})
                continue
            row = compute_metrics(part["y_test"], result.flags.to_numpy(), result.scores.to_numpy())
            metrics.setdefault(method, []).append(row)
    return {"seeds": list(seeds), "metrics": metrics, "skipped": skipped, "errors": errors}


def x_run_problem__mutmut_71(
    x: np.ndarray,
    y: np.ndarray,
    seeds: tuple[int, ...] = config.BENCHMARK_SEEDS,
    methods: list[str] | None = None,
) -> dict[str, Any]:
    methods = methods or METHODS
    unknown = [m for m in methods if m not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    metrics: dict[str, list[dict[str, float]]] = {}
    errors: dict[str, list[dict[str, Any]]] = {}
    skipped: list[str] = []
    for seed in seeds:
        part = nm.split(x, y, seed)
        names = [f"f{i}" for i in range(x.shape[1])]
        train = pd.DataFrame(part["x_train"], columns=names)
        test = pd.DataFrame(part["x_test"], columns=names)
        contamination = clip_contamination(float(part["y_train"].mean()))
        skip = nm.skipped_detectors(len(train))
        skipped = [m for m in methods if m in skip]
        for method in methods:
            if method in skip:
                continue
            try:
                result = detect(
                    test, build(method, contamination, seed), fit_df=capped(train, method, seed)
                )
            except Exception as error:  # a failing model is recorded, not hidden
                errors.setdefault(method, []).append({"seed": seed, "ERROR": repr(error)})
                continue
            row = compute_metrics(part["y_test"], result.flags.to_numpy(), result.scores.to_numpy())
            metrics.setdefault(method, []).append(row)
    return {"seeds": list(seeds), "metrics": metrics, "skipped": skipped, "errors": errors}


def x_run_problem__mutmut_72(
    x: np.ndarray,
    y: np.ndarray,
    seeds: tuple[int, ...] = config.BENCHMARK_SEEDS,
    methods: list[str] | None = None,
) -> dict[str, Any]:
    methods = methods or METHODS
    unknown = [m for m in methods if m not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    metrics: dict[str, list[dict[str, float]]] = {}
    errors: dict[str, list[dict[str, Any]]] = {}
    skipped: list[str] = []
    for seed in seeds:
        part = nm.split(x, y, seed)
        names = [f"f{i}" for i in range(x.shape[1])]
        train = pd.DataFrame(part["x_train"], columns=names)
        test = pd.DataFrame(part["x_test"], columns=names)
        contamination = clip_contamination(float(part["y_train"].mean()))
        skip = nm.skipped_detectors(len(train))
        skipped = [m for m in methods if m in skip]
        for method in methods:
            if method in skip:
                continue
            try:
                result = detect(
                    test, build(method, contamination, seed), fit_df=capped(train, method, seed)
                )
            except Exception as error:  # a failing model is recorded, not hidden
                errors.setdefault(method, []).append({"seed": seed, "error": repr(None)})
                continue
            row = compute_metrics(part["y_test"], result.flags.to_numpy(), result.scores.to_numpy())
            metrics.setdefault(method, []).append(row)
    return {"seeds": list(seeds), "metrics": metrics, "skipped": skipped, "errors": errors}


def x_run_problem__mutmut_73(
    x: np.ndarray,
    y: np.ndarray,
    seeds: tuple[int, ...] = config.BENCHMARK_SEEDS,
    methods: list[str] | None = None,
) -> dict[str, Any]:
    methods = methods or METHODS
    unknown = [m for m in methods if m not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    metrics: dict[str, list[dict[str, float]]] = {}
    errors: dict[str, list[dict[str, Any]]] = {}
    skipped: list[str] = []
    for seed in seeds:
        part = nm.split(x, y, seed)
        names = [f"f{i}" for i in range(x.shape[1])]
        train = pd.DataFrame(part["x_train"], columns=names)
        test = pd.DataFrame(part["x_test"], columns=names)
        contamination = clip_contamination(float(part["y_train"].mean()))
        skip = nm.skipped_detectors(len(train))
        skipped = [m for m in methods if m in skip]
        for method in methods:
            if method in skip:
                continue
            try:
                result = detect(
                    test, build(method, contamination, seed), fit_df=capped(train, method, seed)
                )
            except Exception as error:  # a failing model is recorded, not hidden
                errors.setdefault(method, []).append({"seed": seed, "error": repr(error)})
                break
            row = compute_metrics(part["y_test"], result.flags.to_numpy(), result.scores.to_numpy())
            metrics.setdefault(method, []).append(row)
    return {"seeds": list(seeds), "metrics": metrics, "skipped": skipped, "errors": errors}


def x_run_problem__mutmut_74(
    x: np.ndarray,
    y: np.ndarray,
    seeds: tuple[int, ...] = config.BENCHMARK_SEEDS,
    methods: list[str] | None = None,
) -> dict[str, Any]:
    methods = methods or METHODS
    unknown = [m for m in methods if m not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    metrics: dict[str, list[dict[str, float]]] = {}
    errors: dict[str, list[dict[str, Any]]] = {}
    skipped: list[str] = []
    for seed in seeds:
        part = nm.split(x, y, seed)
        names = [f"f{i}" for i in range(x.shape[1])]
        train = pd.DataFrame(part["x_train"], columns=names)
        test = pd.DataFrame(part["x_test"], columns=names)
        contamination = clip_contamination(float(part["y_train"].mean()))
        skip = nm.skipped_detectors(len(train))
        skipped = [m for m in methods if m in skip]
        for method in methods:
            if method in skip:
                continue
            try:
                result = detect(
                    test, build(method, contamination, seed), fit_df=capped(train, method, seed)
                )
            except Exception as error:  # a failing model is recorded, not hidden
                errors.setdefault(method, []).append({"seed": seed, "error": repr(error)})
                continue
            row = None
            metrics.setdefault(method, []).append(row)
    return {"seeds": list(seeds), "metrics": metrics, "skipped": skipped, "errors": errors}


def x_run_problem__mutmut_75(
    x: np.ndarray,
    y: np.ndarray,
    seeds: tuple[int, ...] = config.BENCHMARK_SEEDS,
    methods: list[str] | None = None,
) -> dict[str, Any]:
    methods = methods or METHODS
    unknown = [m for m in methods if m not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    metrics: dict[str, list[dict[str, float]]] = {}
    errors: dict[str, list[dict[str, Any]]] = {}
    skipped: list[str] = []
    for seed in seeds:
        part = nm.split(x, y, seed)
        names = [f"f{i}" for i in range(x.shape[1])]
        train = pd.DataFrame(part["x_train"], columns=names)
        test = pd.DataFrame(part["x_test"], columns=names)
        contamination = clip_contamination(float(part["y_train"].mean()))
        skip = nm.skipped_detectors(len(train))
        skipped = [m for m in methods if m in skip]
        for method in methods:
            if method in skip:
                continue
            try:
                result = detect(
                    test, build(method, contamination, seed), fit_df=capped(train, method, seed)
                )
            except Exception as error:  # a failing model is recorded, not hidden
                errors.setdefault(method, []).append({"seed": seed, "error": repr(error)})
                continue
            row = compute_metrics(None, result.flags.to_numpy(), result.scores.to_numpy())
            metrics.setdefault(method, []).append(row)
    return {"seeds": list(seeds), "metrics": metrics, "skipped": skipped, "errors": errors}


def x_run_problem__mutmut_76(
    x: np.ndarray,
    y: np.ndarray,
    seeds: tuple[int, ...] = config.BENCHMARK_SEEDS,
    methods: list[str] | None = None,
) -> dict[str, Any]:
    methods = methods or METHODS
    unknown = [m for m in methods if m not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    metrics: dict[str, list[dict[str, float]]] = {}
    errors: dict[str, list[dict[str, Any]]] = {}
    skipped: list[str] = []
    for seed in seeds:
        part = nm.split(x, y, seed)
        names = [f"f{i}" for i in range(x.shape[1])]
        train = pd.DataFrame(part["x_train"], columns=names)
        test = pd.DataFrame(part["x_test"], columns=names)
        contamination = clip_contamination(float(part["y_train"].mean()))
        skip = nm.skipped_detectors(len(train))
        skipped = [m for m in methods if m in skip]
        for method in methods:
            if method in skip:
                continue
            try:
                result = detect(
                    test, build(method, contamination, seed), fit_df=capped(train, method, seed)
                )
            except Exception as error:  # a failing model is recorded, not hidden
                errors.setdefault(method, []).append({"seed": seed, "error": repr(error)})
                continue
            row = compute_metrics(part["y_test"], None, result.scores.to_numpy())
            metrics.setdefault(method, []).append(row)
    return {"seeds": list(seeds), "metrics": metrics, "skipped": skipped, "errors": errors}


def x_run_problem__mutmut_77(
    x: np.ndarray,
    y: np.ndarray,
    seeds: tuple[int, ...] = config.BENCHMARK_SEEDS,
    methods: list[str] | None = None,
) -> dict[str, Any]:
    methods = methods or METHODS
    unknown = [m for m in methods if m not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    metrics: dict[str, list[dict[str, float]]] = {}
    errors: dict[str, list[dict[str, Any]]] = {}
    skipped: list[str] = []
    for seed in seeds:
        part = nm.split(x, y, seed)
        names = [f"f{i}" for i in range(x.shape[1])]
        train = pd.DataFrame(part["x_train"], columns=names)
        test = pd.DataFrame(part["x_test"], columns=names)
        contamination = clip_contamination(float(part["y_train"].mean()))
        skip = nm.skipped_detectors(len(train))
        skipped = [m for m in methods if m in skip]
        for method in methods:
            if method in skip:
                continue
            try:
                result = detect(
                    test, build(method, contamination, seed), fit_df=capped(train, method, seed)
                )
            except Exception as error:  # a failing model is recorded, not hidden
                errors.setdefault(method, []).append({"seed": seed, "error": repr(error)})
                continue
            row = compute_metrics(part["y_test"], result.flags.to_numpy(), None)
            metrics.setdefault(method, []).append(row)
    return {"seeds": list(seeds), "metrics": metrics, "skipped": skipped, "errors": errors}


def x_run_problem__mutmut_78(
    x: np.ndarray,
    y: np.ndarray,
    seeds: tuple[int, ...] = config.BENCHMARK_SEEDS,
    methods: list[str] | None = None,
) -> dict[str, Any]:
    methods = methods or METHODS
    unknown = [m for m in methods if m not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    metrics: dict[str, list[dict[str, float]]] = {}
    errors: dict[str, list[dict[str, Any]]] = {}
    skipped: list[str] = []
    for seed in seeds:
        part = nm.split(x, y, seed)
        names = [f"f{i}" for i in range(x.shape[1])]
        train = pd.DataFrame(part["x_train"], columns=names)
        test = pd.DataFrame(part["x_test"], columns=names)
        contamination = clip_contamination(float(part["y_train"].mean()))
        skip = nm.skipped_detectors(len(train))
        skipped = [m for m in methods if m in skip]
        for method in methods:
            if method in skip:
                continue
            try:
                result = detect(
                    test, build(method, contamination, seed), fit_df=capped(train, method, seed)
                )
            except Exception as error:  # a failing model is recorded, not hidden
                errors.setdefault(method, []).append({"seed": seed, "error": repr(error)})
                continue
            row = compute_metrics(result.flags.to_numpy(), result.scores.to_numpy())
            metrics.setdefault(method, []).append(row)
    return {"seeds": list(seeds), "metrics": metrics, "skipped": skipped, "errors": errors}


def x_run_problem__mutmut_79(
    x: np.ndarray,
    y: np.ndarray,
    seeds: tuple[int, ...] = config.BENCHMARK_SEEDS,
    methods: list[str] | None = None,
) -> dict[str, Any]:
    methods = methods or METHODS
    unknown = [m for m in methods if m not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    metrics: dict[str, list[dict[str, float]]] = {}
    errors: dict[str, list[dict[str, Any]]] = {}
    skipped: list[str] = []
    for seed in seeds:
        part = nm.split(x, y, seed)
        names = [f"f{i}" for i in range(x.shape[1])]
        train = pd.DataFrame(part["x_train"], columns=names)
        test = pd.DataFrame(part["x_test"], columns=names)
        contamination = clip_contamination(float(part["y_train"].mean()))
        skip = nm.skipped_detectors(len(train))
        skipped = [m for m in methods if m in skip]
        for method in methods:
            if method in skip:
                continue
            try:
                result = detect(
                    test, build(method, contamination, seed), fit_df=capped(train, method, seed)
                )
            except Exception as error:  # a failing model is recorded, not hidden
                errors.setdefault(method, []).append({"seed": seed, "error": repr(error)})
                continue
            row = compute_metrics(part["y_test"], result.scores.to_numpy())
            metrics.setdefault(method, []).append(row)
    return {"seeds": list(seeds), "metrics": metrics, "skipped": skipped, "errors": errors}


def x_run_problem__mutmut_80(
    x: np.ndarray,
    y: np.ndarray,
    seeds: tuple[int, ...] = config.BENCHMARK_SEEDS,
    methods: list[str] | None = None,
) -> dict[str, Any]:
    methods = methods or METHODS
    unknown = [m for m in methods if m not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    metrics: dict[str, list[dict[str, float]]] = {}
    errors: dict[str, list[dict[str, Any]]] = {}
    skipped: list[str] = []
    for seed in seeds:
        part = nm.split(x, y, seed)
        names = [f"f{i}" for i in range(x.shape[1])]
        train = pd.DataFrame(part["x_train"], columns=names)
        test = pd.DataFrame(part["x_test"], columns=names)
        contamination = clip_contamination(float(part["y_train"].mean()))
        skip = nm.skipped_detectors(len(train))
        skipped = [m for m in methods if m in skip]
        for method in methods:
            if method in skip:
                continue
            try:
                result = detect(
                    test, build(method, contamination, seed), fit_df=capped(train, method, seed)
                )
            except Exception as error:  # a failing model is recorded, not hidden
                errors.setdefault(method, []).append({"seed": seed, "error": repr(error)})
                continue
            row = compute_metrics(part["y_test"], result.flags.to_numpy(), )
            metrics.setdefault(method, []).append(row)
    return {"seeds": list(seeds), "metrics": metrics, "skipped": skipped, "errors": errors}


def x_run_problem__mutmut_81(
    x: np.ndarray,
    y: np.ndarray,
    seeds: tuple[int, ...] = config.BENCHMARK_SEEDS,
    methods: list[str] | None = None,
) -> dict[str, Any]:
    methods = methods or METHODS
    unknown = [m for m in methods if m not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    metrics: dict[str, list[dict[str, float]]] = {}
    errors: dict[str, list[dict[str, Any]]] = {}
    skipped: list[str] = []
    for seed in seeds:
        part = nm.split(x, y, seed)
        names = [f"f{i}" for i in range(x.shape[1])]
        train = pd.DataFrame(part["x_train"], columns=names)
        test = pd.DataFrame(part["x_test"], columns=names)
        contamination = clip_contamination(float(part["y_train"].mean()))
        skip = nm.skipped_detectors(len(train))
        skipped = [m for m in methods if m in skip]
        for method in methods:
            if method in skip:
                continue
            try:
                result = detect(
                    test, build(method, contamination, seed), fit_df=capped(train, method, seed)
                )
            except Exception as error:  # a failing model is recorded, not hidden
                errors.setdefault(method, []).append({"seed": seed, "error": repr(error)})
                continue
            row = compute_metrics(part["XXy_testXX"], result.flags.to_numpy(), result.scores.to_numpy())
            metrics.setdefault(method, []).append(row)
    return {"seeds": list(seeds), "metrics": metrics, "skipped": skipped, "errors": errors}


def x_run_problem__mutmut_82(
    x: np.ndarray,
    y: np.ndarray,
    seeds: tuple[int, ...] = config.BENCHMARK_SEEDS,
    methods: list[str] | None = None,
) -> dict[str, Any]:
    methods = methods or METHODS
    unknown = [m for m in methods if m not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    metrics: dict[str, list[dict[str, float]]] = {}
    errors: dict[str, list[dict[str, Any]]] = {}
    skipped: list[str] = []
    for seed in seeds:
        part = nm.split(x, y, seed)
        names = [f"f{i}" for i in range(x.shape[1])]
        train = pd.DataFrame(part["x_train"], columns=names)
        test = pd.DataFrame(part["x_test"], columns=names)
        contamination = clip_contamination(float(part["y_train"].mean()))
        skip = nm.skipped_detectors(len(train))
        skipped = [m for m in methods if m in skip]
        for method in methods:
            if method in skip:
                continue
            try:
                result = detect(
                    test, build(method, contamination, seed), fit_df=capped(train, method, seed)
                )
            except Exception as error:  # a failing model is recorded, not hidden
                errors.setdefault(method, []).append({"seed": seed, "error": repr(error)})
                continue
            row = compute_metrics(part["Y_TEST"], result.flags.to_numpy(), result.scores.to_numpy())
            metrics.setdefault(method, []).append(row)
    return {"seeds": list(seeds), "metrics": metrics, "skipped": skipped, "errors": errors}


def x_run_problem__mutmut_83(
    x: np.ndarray,
    y: np.ndarray,
    seeds: tuple[int, ...] = config.BENCHMARK_SEEDS,
    methods: list[str] | None = None,
) -> dict[str, Any]:
    methods = methods or METHODS
    unknown = [m for m in methods if m not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    metrics: dict[str, list[dict[str, float]]] = {}
    errors: dict[str, list[dict[str, Any]]] = {}
    skipped: list[str] = []
    for seed in seeds:
        part = nm.split(x, y, seed)
        names = [f"f{i}" for i in range(x.shape[1])]
        train = pd.DataFrame(part["x_train"], columns=names)
        test = pd.DataFrame(part["x_test"], columns=names)
        contamination = clip_contamination(float(part["y_train"].mean()))
        skip = nm.skipped_detectors(len(train))
        skipped = [m for m in methods if m in skip]
        for method in methods:
            if method in skip:
                continue
            try:
                result = detect(
                    test, build(method, contamination, seed), fit_df=capped(train, method, seed)
                )
            except Exception as error:  # a failing model is recorded, not hidden
                errors.setdefault(method, []).append({"seed": seed, "error": repr(error)})
                continue
            row = compute_metrics(part["y_test"], result.flags.to_numpy(), result.scores.to_numpy())
            metrics.setdefault(method, []).append(None)
    return {"seeds": list(seeds), "metrics": metrics, "skipped": skipped, "errors": errors}


def x_run_problem__mutmut_84(
    x: np.ndarray,
    y: np.ndarray,
    seeds: tuple[int, ...] = config.BENCHMARK_SEEDS,
    methods: list[str] | None = None,
) -> dict[str, Any]:
    methods = methods or METHODS
    unknown = [m for m in methods if m not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    metrics: dict[str, list[dict[str, float]]] = {}
    errors: dict[str, list[dict[str, Any]]] = {}
    skipped: list[str] = []
    for seed in seeds:
        part = nm.split(x, y, seed)
        names = [f"f{i}" for i in range(x.shape[1])]
        train = pd.DataFrame(part["x_train"], columns=names)
        test = pd.DataFrame(part["x_test"], columns=names)
        contamination = clip_contamination(float(part["y_train"].mean()))
        skip = nm.skipped_detectors(len(train))
        skipped = [m for m in methods if m in skip]
        for method in methods:
            if method in skip:
                continue
            try:
                result = detect(
                    test, build(method, contamination, seed), fit_df=capped(train, method, seed)
                )
            except Exception as error:  # a failing model is recorded, not hidden
                errors.setdefault(method, []).append({"seed": seed, "error": repr(error)})
                continue
            row = compute_metrics(part["y_test"], result.flags.to_numpy(), result.scores.to_numpy())
            metrics.setdefault(None, []).append(row)
    return {"seeds": list(seeds), "metrics": metrics, "skipped": skipped, "errors": errors}


def x_run_problem__mutmut_85(
    x: np.ndarray,
    y: np.ndarray,
    seeds: tuple[int, ...] = config.BENCHMARK_SEEDS,
    methods: list[str] | None = None,
) -> dict[str, Any]:
    methods = methods or METHODS
    unknown = [m for m in methods if m not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    metrics: dict[str, list[dict[str, float]]] = {}
    errors: dict[str, list[dict[str, Any]]] = {}
    skipped: list[str] = []
    for seed in seeds:
        part = nm.split(x, y, seed)
        names = [f"f{i}" for i in range(x.shape[1])]
        train = pd.DataFrame(part["x_train"], columns=names)
        test = pd.DataFrame(part["x_test"], columns=names)
        contamination = clip_contamination(float(part["y_train"].mean()))
        skip = nm.skipped_detectors(len(train))
        skipped = [m for m in methods if m in skip]
        for method in methods:
            if method in skip:
                continue
            try:
                result = detect(
                    test, build(method, contamination, seed), fit_df=capped(train, method, seed)
                )
            except Exception as error:  # a failing model is recorded, not hidden
                errors.setdefault(method, []).append({"seed": seed, "error": repr(error)})
                continue
            row = compute_metrics(part["y_test"], result.flags.to_numpy(), result.scores.to_numpy())
            metrics.setdefault(method, None).append(row)
    return {"seeds": list(seeds), "metrics": metrics, "skipped": skipped, "errors": errors}


def x_run_problem__mutmut_86(
    x: np.ndarray,
    y: np.ndarray,
    seeds: tuple[int, ...] = config.BENCHMARK_SEEDS,
    methods: list[str] | None = None,
) -> dict[str, Any]:
    methods = methods or METHODS
    unknown = [m for m in methods if m not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    metrics: dict[str, list[dict[str, float]]] = {}
    errors: dict[str, list[dict[str, Any]]] = {}
    skipped: list[str] = []
    for seed in seeds:
        part = nm.split(x, y, seed)
        names = [f"f{i}" for i in range(x.shape[1])]
        train = pd.DataFrame(part["x_train"], columns=names)
        test = pd.DataFrame(part["x_test"], columns=names)
        contamination = clip_contamination(float(part["y_train"].mean()))
        skip = nm.skipped_detectors(len(train))
        skipped = [m for m in methods if m in skip]
        for method in methods:
            if method in skip:
                continue
            try:
                result = detect(
                    test, build(method, contamination, seed), fit_df=capped(train, method, seed)
                )
            except Exception as error:  # a failing model is recorded, not hidden
                errors.setdefault(method, []).append({"seed": seed, "error": repr(error)})
                continue
            row = compute_metrics(part["y_test"], result.flags.to_numpy(), result.scores.to_numpy())
            metrics.setdefault([]).append(row)
    return {"seeds": list(seeds), "metrics": metrics, "skipped": skipped, "errors": errors}


def x_run_problem__mutmut_87(
    x: np.ndarray,
    y: np.ndarray,
    seeds: tuple[int, ...] = config.BENCHMARK_SEEDS,
    methods: list[str] | None = None,
) -> dict[str, Any]:
    methods = methods or METHODS
    unknown = [m for m in methods if m not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    metrics: dict[str, list[dict[str, float]]] = {}
    errors: dict[str, list[dict[str, Any]]] = {}
    skipped: list[str] = []
    for seed in seeds:
        part = nm.split(x, y, seed)
        names = [f"f{i}" for i in range(x.shape[1])]
        train = pd.DataFrame(part["x_train"], columns=names)
        test = pd.DataFrame(part["x_test"], columns=names)
        contamination = clip_contamination(float(part["y_train"].mean()))
        skip = nm.skipped_detectors(len(train))
        skipped = [m for m in methods if m in skip]
        for method in methods:
            if method in skip:
                continue
            try:
                result = detect(
                    test, build(method, contamination, seed), fit_df=capped(train, method, seed)
                )
            except Exception as error:  # a failing model is recorded, not hidden
                errors.setdefault(method, []).append({"seed": seed, "error": repr(error)})
                continue
            row = compute_metrics(part["y_test"], result.flags.to_numpy(), result.scores.to_numpy())
            metrics.setdefault(method, ).append(row)
    return {"seeds": list(seeds), "metrics": metrics, "skipped": skipped, "errors": errors}


def x_run_problem__mutmut_88(
    x: np.ndarray,
    y: np.ndarray,
    seeds: tuple[int, ...] = config.BENCHMARK_SEEDS,
    methods: list[str] | None = None,
) -> dict[str, Any]:
    methods = methods or METHODS
    unknown = [m for m in methods if m not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    metrics: dict[str, list[dict[str, float]]] = {}
    errors: dict[str, list[dict[str, Any]]] = {}
    skipped: list[str] = []
    for seed in seeds:
        part = nm.split(x, y, seed)
        names = [f"f{i}" for i in range(x.shape[1])]
        train = pd.DataFrame(part["x_train"], columns=names)
        test = pd.DataFrame(part["x_test"], columns=names)
        contamination = clip_contamination(float(part["y_train"].mean()))
        skip = nm.skipped_detectors(len(train))
        skipped = [m for m in methods if m in skip]
        for method in methods:
            if method in skip:
                continue
            try:
                result = detect(
                    test, build(method, contamination, seed), fit_df=capped(train, method, seed)
                )
            except Exception as error:  # a failing model is recorded, not hidden
                errors.setdefault(method, []).append({"seed": seed, "error": repr(error)})
                continue
            row = compute_metrics(part["y_test"], result.flags.to_numpy(), result.scores.to_numpy())
            metrics.setdefault(method, []).append(row)
    return {"XXseedsXX": list(seeds), "metrics": metrics, "skipped": skipped, "errors": errors}


def x_run_problem__mutmut_89(
    x: np.ndarray,
    y: np.ndarray,
    seeds: tuple[int, ...] = config.BENCHMARK_SEEDS,
    methods: list[str] | None = None,
) -> dict[str, Any]:
    methods = methods or METHODS
    unknown = [m for m in methods if m not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    metrics: dict[str, list[dict[str, float]]] = {}
    errors: dict[str, list[dict[str, Any]]] = {}
    skipped: list[str] = []
    for seed in seeds:
        part = nm.split(x, y, seed)
        names = [f"f{i}" for i in range(x.shape[1])]
        train = pd.DataFrame(part["x_train"], columns=names)
        test = pd.DataFrame(part["x_test"], columns=names)
        contamination = clip_contamination(float(part["y_train"].mean()))
        skip = nm.skipped_detectors(len(train))
        skipped = [m for m in methods if m in skip]
        for method in methods:
            if method in skip:
                continue
            try:
                result = detect(
                    test, build(method, contamination, seed), fit_df=capped(train, method, seed)
                )
            except Exception as error:  # a failing model is recorded, not hidden
                errors.setdefault(method, []).append({"seed": seed, "error": repr(error)})
                continue
            row = compute_metrics(part["y_test"], result.flags.to_numpy(), result.scores.to_numpy())
            metrics.setdefault(method, []).append(row)
    return {"SEEDS": list(seeds), "metrics": metrics, "skipped": skipped, "errors": errors}


def x_run_problem__mutmut_90(
    x: np.ndarray,
    y: np.ndarray,
    seeds: tuple[int, ...] = config.BENCHMARK_SEEDS,
    methods: list[str] | None = None,
) -> dict[str, Any]:
    methods = methods or METHODS
    unknown = [m for m in methods if m not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    metrics: dict[str, list[dict[str, float]]] = {}
    errors: dict[str, list[dict[str, Any]]] = {}
    skipped: list[str] = []
    for seed in seeds:
        part = nm.split(x, y, seed)
        names = [f"f{i}" for i in range(x.shape[1])]
        train = pd.DataFrame(part["x_train"], columns=names)
        test = pd.DataFrame(part["x_test"], columns=names)
        contamination = clip_contamination(float(part["y_train"].mean()))
        skip = nm.skipped_detectors(len(train))
        skipped = [m for m in methods if m in skip]
        for method in methods:
            if method in skip:
                continue
            try:
                result = detect(
                    test, build(method, contamination, seed), fit_df=capped(train, method, seed)
                )
            except Exception as error:  # a failing model is recorded, not hidden
                errors.setdefault(method, []).append({"seed": seed, "error": repr(error)})
                continue
            row = compute_metrics(part["y_test"], result.flags.to_numpy(), result.scores.to_numpy())
            metrics.setdefault(method, []).append(row)
    return {"seeds": list(None), "metrics": metrics, "skipped": skipped, "errors": errors}


def x_run_problem__mutmut_91(
    x: np.ndarray,
    y: np.ndarray,
    seeds: tuple[int, ...] = config.BENCHMARK_SEEDS,
    methods: list[str] | None = None,
) -> dict[str, Any]:
    methods = methods or METHODS
    unknown = [m for m in methods if m not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    metrics: dict[str, list[dict[str, float]]] = {}
    errors: dict[str, list[dict[str, Any]]] = {}
    skipped: list[str] = []
    for seed in seeds:
        part = nm.split(x, y, seed)
        names = [f"f{i}" for i in range(x.shape[1])]
        train = pd.DataFrame(part["x_train"], columns=names)
        test = pd.DataFrame(part["x_test"], columns=names)
        contamination = clip_contamination(float(part["y_train"].mean()))
        skip = nm.skipped_detectors(len(train))
        skipped = [m for m in methods if m in skip]
        for method in methods:
            if method in skip:
                continue
            try:
                result = detect(
                    test, build(method, contamination, seed), fit_df=capped(train, method, seed)
                )
            except Exception as error:  # a failing model is recorded, not hidden
                errors.setdefault(method, []).append({"seed": seed, "error": repr(error)})
                continue
            row = compute_metrics(part["y_test"], result.flags.to_numpy(), result.scores.to_numpy())
            metrics.setdefault(method, []).append(row)
    return {"seeds": list(seeds), "XXmetricsXX": metrics, "skipped": skipped, "errors": errors}


def x_run_problem__mutmut_92(
    x: np.ndarray,
    y: np.ndarray,
    seeds: tuple[int, ...] = config.BENCHMARK_SEEDS,
    methods: list[str] | None = None,
) -> dict[str, Any]:
    methods = methods or METHODS
    unknown = [m for m in methods if m not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    metrics: dict[str, list[dict[str, float]]] = {}
    errors: dict[str, list[dict[str, Any]]] = {}
    skipped: list[str] = []
    for seed in seeds:
        part = nm.split(x, y, seed)
        names = [f"f{i}" for i in range(x.shape[1])]
        train = pd.DataFrame(part["x_train"], columns=names)
        test = pd.DataFrame(part["x_test"], columns=names)
        contamination = clip_contamination(float(part["y_train"].mean()))
        skip = nm.skipped_detectors(len(train))
        skipped = [m for m in methods if m in skip]
        for method in methods:
            if method in skip:
                continue
            try:
                result = detect(
                    test, build(method, contamination, seed), fit_df=capped(train, method, seed)
                )
            except Exception as error:  # a failing model is recorded, not hidden
                errors.setdefault(method, []).append({"seed": seed, "error": repr(error)})
                continue
            row = compute_metrics(part["y_test"], result.flags.to_numpy(), result.scores.to_numpy())
            metrics.setdefault(method, []).append(row)
    return {"seeds": list(seeds), "METRICS": metrics, "skipped": skipped, "errors": errors}


def x_run_problem__mutmut_93(
    x: np.ndarray,
    y: np.ndarray,
    seeds: tuple[int, ...] = config.BENCHMARK_SEEDS,
    methods: list[str] | None = None,
) -> dict[str, Any]:
    methods = methods or METHODS
    unknown = [m for m in methods if m not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    metrics: dict[str, list[dict[str, float]]] = {}
    errors: dict[str, list[dict[str, Any]]] = {}
    skipped: list[str] = []
    for seed in seeds:
        part = nm.split(x, y, seed)
        names = [f"f{i}" for i in range(x.shape[1])]
        train = pd.DataFrame(part["x_train"], columns=names)
        test = pd.DataFrame(part["x_test"], columns=names)
        contamination = clip_contamination(float(part["y_train"].mean()))
        skip = nm.skipped_detectors(len(train))
        skipped = [m for m in methods if m in skip]
        for method in methods:
            if method in skip:
                continue
            try:
                result = detect(
                    test, build(method, contamination, seed), fit_df=capped(train, method, seed)
                )
            except Exception as error:  # a failing model is recorded, not hidden
                errors.setdefault(method, []).append({"seed": seed, "error": repr(error)})
                continue
            row = compute_metrics(part["y_test"], result.flags.to_numpy(), result.scores.to_numpy())
            metrics.setdefault(method, []).append(row)
    return {"seeds": list(seeds), "metrics": metrics, "XXskippedXX": skipped, "errors": errors}


def x_run_problem__mutmut_94(
    x: np.ndarray,
    y: np.ndarray,
    seeds: tuple[int, ...] = config.BENCHMARK_SEEDS,
    methods: list[str] | None = None,
) -> dict[str, Any]:
    methods = methods or METHODS
    unknown = [m for m in methods if m not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    metrics: dict[str, list[dict[str, float]]] = {}
    errors: dict[str, list[dict[str, Any]]] = {}
    skipped: list[str] = []
    for seed in seeds:
        part = nm.split(x, y, seed)
        names = [f"f{i}" for i in range(x.shape[1])]
        train = pd.DataFrame(part["x_train"], columns=names)
        test = pd.DataFrame(part["x_test"], columns=names)
        contamination = clip_contamination(float(part["y_train"].mean()))
        skip = nm.skipped_detectors(len(train))
        skipped = [m for m in methods if m in skip]
        for method in methods:
            if method in skip:
                continue
            try:
                result = detect(
                    test, build(method, contamination, seed), fit_df=capped(train, method, seed)
                )
            except Exception as error:  # a failing model is recorded, not hidden
                errors.setdefault(method, []).append({"seed": seed, "error": repr(error)})
                continue
            row = compute_metrics(part["y_test"], result.flags.to_numpy(), result.scores.to_numpy())
            metrics.setdefault(method, []).append(row)
    return {"seeds": list(seeds), "metrics": metrics, "SKIPPED": skipped, "errors": errors}


def x_run_problem__mutmut_95(
    x: np.ndarray,
    y: np.ndarray,
    seeds: tuple[int, ...] = config.BENCHMARK_SEEDS,
    methods: list[str] | None = None,
) -> dict[str, Any]:
    methods = methods or METHODS
    unknown = [m for m in methods if m not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    metrics: dict[str, list[dict[str, float]]] = {}
    errors: dict[str, list[dict[str, Any]]] = {}
    skipped: list[str] = []
    for seed in seeds:
        part = nm.split(x, y, seed)
        names = [f"f{i}" for i in range(x.shape[1])]
        train = pd.DataFrame(part["x_train"], columns=names)
        test = pd.DataFrame(part["x_test"], columns=names)
        contamination = clip_contamination(float(part["y_train"].mean()))
        skip = nm.skipped_detectors(len(train))
        skipped = [m for m in methods if m in skip]
        for method in methods:
            if method in skip:
                continue
            try:
                result = detect(
                    test, build(method, contamination, seed), fit_df=capped(train, method, seed)
                )
            except Exception as error:  # a failing model is recorded, not hidden
                errors.setdefault(method, []).append({"seed": seed, "error": repr(error)})
                continue
            row = compute_metrics(part["y_test"], result.flags.to_numpy(), result.scores.to_numpy())
            metrics.setdefault(method, []).append(row)
    return {"seeds": list(seeds), "metrics": metrics, "skipped": skipped, "XXerrorsXX": errors}


def x_run_problem__mutmut_96(
    x: np.ndarray,
    y: np.ndarray,
    seeds: tuple[int, ...] = config.BENCHMARK_SEEDS,
    methods: list[str] | None = None,
) -> dict[str, Any]:
    methods = methods or METHODS
    unknown = [m for m in methods if m not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    metrics: dict[str, list[dict[str, float]]] = {}
    errors: dict[str, list[dict[str, Any]]] = {}
    skipped: list[str] = []
    for seed in seeds:
        part = nm.split(x, y, seed)
        names = [f"f{i}" for i in range(x.shape[1])]
        train = pd.DataFrame(part["x_train"], columns=names)
        test = pd.DataFrame(part["x_test"], columns=names)
        contamination = clip_contamination(float(part["y_train"].mean()))
        skip = nm.skipped_detectors(len(train))
        skipped = [m for m in methods if m in skip]
        for method in methods:
            if method in skip:
                continue
            try:
                result = detect(
                    test, build(method, contamination, seed), fit_df=capped(train, method, seed)
                )
            except Exception as error:  # a failing model is recorded, not hidden
                errors.setdefault(method, []).append({"seed": seed, "error": repr(error)})
                continue
            row = compute_metrics(part["y_test"], result.flags.to_numpy(), result.scores.to_numpy())
            metrics.setdefault(method, []).append(row)
    return {"seeds": list(seeds), "metrics": metrics, "skipped": skipped, "ERRORS": errors}

mutants_x_run_problem__mutmut['_mutmut_orig'] = x_run_problem__mutmut_orig # type: ignore # mutmut generated
mutants_x_run_problem__mutmut['x_run_problem__mutmut_1'] = x_run_problem__mutmut_1 # type: ignore # mutmut generated
mutants_x_run_problem__mutmut['x_run_problem__mutmut_2'] = x_run_problem__mutmut_2 # type: ignore # mutmut generated
mutants_x_run_problem__mutmut['x_run_problem__mutmut_3'] = x_run_problem__mutmut_3 # type: ignore # mutmut generated
mutants_x_run_problem__mutmut['x_run_problem__mutmut_4'] = x_run_problem__mutmut_4 # type: ignore # mutmut generated
mutants_x_run_problem__mutmut['x_run_problem__mutmut_5'] = x_run_problem__mutmut_5 # type: ignore # mutmut generated
mutants_x_run_problem__mutmut['x_run_problem__mutmut_6'] = x_run_problem__mutmut_6 # type: ignore # mutmut generated
mutants_x_run_problem__mutmut['x_run_problem__mutmut_7'] = x_run_problem__mutmut_7 # type: ignore # mutmut generated
mutants_x_run_problem__mutmut['x_run_problem__mutmut_8'] = x_run_problem__mutmut_8 # type: ignore # mutmut generated
mutants_x_run_problem__mutmut['x_run_problem__mutmut_9'] = x_run_problem__mutmut_9 # type: ignore # mutmut generated
mutants_x_run_problem__mutmut['x_run_problem__mutmut_10'] = x_run_problem__mutmut_10 # type: ignore # mutmut generated
mutants_x_run_problem__mutmut['x_run_problem__mutmut_11'] = x_run_problem__mutmut_11 # type: ignore # mutmut generated
mutants_x_run_problem__mutmut['x_run_problem__mutmut_12'] = x_run_problem__mutmut_12 # type: ignore # mutmut generated
mutants_x_run_problem__mutmut['x_run_problem__mutmut_13'] = x_run_problem__mutmut_13 # type: ignore # mutmut generated
mutants_x_run_problem__mutmut['x_run_problem__mutmut_14'] = x_run_problem__mutmut_14 # type: ignore # mutmut generated
mutants_x_run_problem__mutmut['x_run_problem__mutmut_15'] = x_run_problem__mutmut_15 # type: ignore # mutmut generated
mutants_x_run_problem__mutmut['x_run_problem__mutmut_16'] = x_run_problem__mutmut_16 # type: ignore # mutmut generated
mutants_x_run_problem__mutmut['x_run_problem__mutmut_17'] = x_run_problem__mutmut_17 # type: ignore # mutmut generated
mutants_x_run_problem__mutmut['x_run_problem__mutmut_18'] = x_run_problem__mutmut_18 # type: ignore # mutmut generated
mutants_x_run_problem__mutmut['x_run_problem__mutmut_19'] = x_run_problem__mutmut_19 # type: ignore # mutmut generated
mutants_x_run_problem__mutmut['x_run_problem__mutmut_20'] = x_run_problem__mutmut_20 # type: ignore # mutmut generated
mutants_x_run_problem__mutmut['x_run_problem__mutmut_21'] = x_run_problem__mutmut_21 # type: ignore # mutmut generated
mutants_x_run_problem__mutmut['x_run_problem__mutmut_22'] = x_run_problem__mutmut_22 # type: ignore # mutmut generated
mutants_x_run_problem__mutmut['x_run_problem__mutmut_23'] = x_run_problem__mutmut_23 # type: ignore # mutmut generated
mutants_x_run_problem__mutmut['x_run_problem__mutmut_24'] = x_run_problem__mutmut_24 # type: ignore # mutmut generated
mutants_x_run_problem__mutmut['x_run_problem__mutmut_25'] = x_run_problem__mutmut_25 # type: ignore # mutmut generated
mutants_x_run_problem__mutmut['x_run_problem__mutmut_26'] = x_run_problem__mutmut_26 # type: ignore # mutmut generated
mutants_x_run_problem__mutmut['x_run_problem__mutmut_27'] = x_run_problem__mutmut_27 # type: ignore # mutmut generated
mutants_x_run_problem__mutmut['x_run_problem__mutmut_28'] = x_run_problem__mutmut_28 # type: ignore # mutmut generated
mutants_x_run_problem__mutmut['x_run_problem__mutmut_29'] = x_run_problem__mutmut_29 # type: ignore # mutmut generated
mutants_x_run_problem__mutmut['x_run_problem__mutmut_30'] = x_run_problem__mutmut_30 # type: ignore # mutmut generated
mutants_x_run_problem__mutmut['x_run_problem__mutmut_31'] = x_run_problem__mutmut_31 # type: ignore # mutmut generated
mutants_x_run_problem__mutmut['x_run_problem__mutmut_32'] = x_run_problem__mutmut_32 # type: ignore # mutmut generated
mutants_x_run_problem__mutmut['x_run_problem__mutmut_33'] = x_run_problem__mutmut_33 # type: ignore # mutmut generated
mutants_x_run_problem__mutmut['x_run_problem__mutmut_34'] = x_run_problem__mutmut_34 # type: ignore # mutmut generated
mutants_x_run_problem__mutmut['x_run_problem__mutmut_35'] = x_run_problem__mutmut_35 # type: ignore # mutmut generated
mutants_x_run_problem__mutmut['x_run_problem__mutmut_36'] = x_run_problem__mutmut_36 # type: ignore # mutmut generated
mutants_x_run_problem__mutmut['x_run_problem__mutmut_37'] = x_run_problem__mutmut_37 # type: ignore # mutmut generated
mutants_x_run_problem__mutmut['x_run_problem__mutmut_38'] = x_run_problem__mutmut_38 # type: ignore # mutmut generated
mutants_x_run_problem__mutmut['x_run_problem__mutmut_39'] = x_run_problem__mutmut_39 # type: ignore # mutmut generated
mutants_x_run_problem__mutmut['x_run_problem__mutmut_40'] = x_run_problem__mutmut_40 # type: ignore # mutmut generated
mutants_x_run_problem__mutmut['x_run_problem__mutmut_41'] = x_run_problem__mutmut_41 # type: ignore # mutmut generated
mutants_x_run_problem__mutmut['x_run_problem__mutmut_42'] = x_run_problem__mutmut_42 # type: ignore # mutmut generated
mutants_x_run_problem__mutmut['x_run_problem__mutmut_43'] = x_run_problem__mutmut_43 # type: ignore # mutmut generated
mutants_x_run_problem__mutmut['x_run_problem__mutmut_44'] = x_run_problem__mutmut_44 # type: ignore # mutmut generated
mutants_x_run_problem__mutmut['x_run_problem__mutmut_45'] = x_run_problem__mutmut_45 # type: ignore # mutmut generated
mutants_x_run_problem__mutmut['x_run_problem__mutmut_46'] = x_run_problem__mutmut_46 # type: ignore # mutmut generated
mutants_x_run_problem__mutmut['x_run_problem__mutmut_47'] = x_run_problem__mutmut_47 # type: ignore # mutmut generated
mutants_x_run_problem__mutmut['x_run_problem__mutmut_48'] = x_run_problem__mutmut_48 # type: ignore # mutmut generated
mutants_x_run_problem__mutmut['x_run_problem__mutmut_49'] = x_run_problem__mutmut_49 # type: ignore # mutmut generated
mutants_x_run_problem__mutmut['x_run_problem__mutmut_50'] = x_run_problem__mutmut_50 # type: ignore # mutmut generated
mutants_x_run_problem__mutmut['x_run_problem__mutmut_51'] = x_run_problem__mutmut_51 # type: ignore # mutmut generated
mutants_x_run_problem__mutmut['x_run_problem__mutmut_52'] = x_run_problem__mutmut_52 # type: ignore # mutmut generated
mutants_x_run_problem__mutmut['x_run_problem__mutmut_53'] = x_run_problem__mutmut_53 # type: ignore # mutmut generated
mutants_x_run_problem__mutmut['x_run_problem__mutmut_54'] = x_run_problem__mutmut_54 # type: ignore # mutmut generated
mutants_x_run_problem__mutmut['x_run_problem__mutmut_55'] = x_run_problem__mutmut_55 # type: ignore # mutmut generated
mutants_x_run_problem__mutmut['x_run_problem__mutmut_56'] = x_run_problem__mutmut_56 # type: ignore # mutmut generated
mutants_x_run_problem__mutmut['x_run_problem__mutmut_57'] = x_run_problem__mutmut_57 # type: ignore # mutmut generated
mutants_x_run_problem__mutmut['x_run_problem__mutmut_58'] = x_run_problem__mutmut_58 # type: ignore # mutmut generated
mutants_x_run_problem__mutmut['x_run_problem__mutmut_59'] = x_run_problem__mutmut_59 # type: ignore # mutmut generated
mutants_x_run_problem__mutmut['x_run_problem__mutmut_60'] = x_run_problem__mutmut_60 # type: ignore # mutmut generated
mutants_x_run_problem__mutmut['x_run_problem__mutmut_61'] = x_run_problem__mutmut_61 # type: ignore # mutmut generated
mutants_x_run_problem__mutmut['x_run_problem__mutmut_62'] = x_run_problem__mutmut_62 # type: ignore # mutmut generated
mutants_x_run_problem__mutmut['x_run_problem__mutmut_63'] = x_run_problem__mutmut_63 # type: ignore # mutmut generated
mutants_x_run_problem__mutmut['x_run_problem__mutmut_64'] = x_run_problem__mutmut_64 # type: ignore # mutmut generated
mutants_x_run_problem__mutmut['x_run_problem__mutmut_65'] = x_run_problem__mutmut_65 # type: ignore # mutmut generated
mutants_x_run_problem__mutmut['x_run_problem__mutmut_66'] = x_run_problem__mutmut_66 # type: ignore # mutmut generated
mutants_x_run_problem__mutmut['x_run_problem__mutmut_67'] = x_run_problem__mutmut_67 # type: ignore # mutmut generated
mutants_x_run_problem__mutmut['x_run_problem__mutmut_68'] = x_run_problem__mutmut_68 # type: ignore # mutmut generated
mutants_x_run_problem__mutmut['x_run_problem__mutmut_69'] = x_run_problem__mutmut_69 # type: ignore # mutmut generated
mutants_x_run_problem__mutmut['x_run_problem__mutmut_70'] = x_run_problem__mutmut_70 # type: ignore # mutmut generated
mutants_x_run_problem__mutmut['x_run_problem__mutmut_71'] = x_run_problem__mutmut_71 # type: ignore # mutmut generated
mutants_x_run_problem__mutmut['x_run_problem__mutmut_72'] = x_run_problem__mutmut_72 # type: ignore # mutmut generated
mutants_x_run_problem__mutmut['x_run_problem__mutmut_73'] = x_run_problem__mutmut_73 # type: ignore # mutmut generated
mutants_x_run_problem__mutmut['x_run_problem__mutmut_74'] = x_run_problem__mutmut_74 # type: ignore # mutmut generated
mutants_x_run_problem__mutmut['x_run_problem__mutmut_75'] = x_run_problem__mutmut_75 # type: ignore # mutmut generated
mutants_x_run_problem__mutmut['x_run_problem__mutmut_76'] = x_run_problem__mutmut_76 # type: ignore # mutmut generated
mutants_x_run_problem__mutmut['x_run_problem__mutmut_77'] = x_run_problem__mutmut_77 # type: ignore # mutmut generated
mutants_x_run_problem__mutmut['x_run_problem__mutmut_78'] = x_run_problem__mutmut_78 # type: ignore # mutmut generated
mutants_x_run_problem__mutmut['x_run_problem__mutmut_79'] = x_run_problem__mutmut_79 # type: ignore # mutmut generated
mutants_x_run_problem__mutmut['x_run_problem__mutmut_80'] = x_run_problem__mutmut_80 # type: ignore # mutmut generated
mutants_x_run_problem__mutmut['x_run_problem__mutmut_81'] = x_run_problem__mutmut_81 # type: ignore # mutmut generated
mutants_x_run_problem__mutmut['x_run_problem__mutmut_82'] = x_run_problem__mutmut_82 # type: ignore # mutmut generated
mutants_x_run_problem__mutmut['x_run_problem__mutmut_83'] = x_run_problem__mutmut_83 # type: ignore # mutmut generated
mutants_x_run_problem__mutmut['x_run_problem__mutmut_84'] = x_run_problem__mutmut_84 # type: ignore # mutmut generated
mutants_x_run_problem__mutmut['x_run_problem__mutmut_85'] = x_run_problem__mutmut_85 # type: ignore # mutmut generated
mutants_x_run_problem__mutmut['x_run_problem__mutmut_86'] = x_run_problem__mutmut_86 # type: ignore # mutmut generated
mutants_x_run_problem__mutmut['x_run_problem__mutmut_87'] = x_run_problem__mutmut_87 # type: ignore # mutmut generated
mutants_x_run_problem__mutmut['x_run_problem__mutmut_88'] = x_run_problem__mutmut_88 # type: ignore # mutmut generated
mutants_x_run_problem__mutmut['x_run_problem__mutmut_89'] = x_run_problem__mutmut_89 # type: ignore # mutmut generated
mutants_x_run_problem__mutmut['x_run_problem__mutmut_90'] = x_run_problem__mutmut_90 # type: ignore # mutmut generated
mutants_x_run_problem__mutmut['x_run_problem__mutmut_91'] = x_run_problem__mutmut_91 # type: ignore # mutmut generated
mutants_x_run_problem__mutmut['x_run_problem__mutmut_92'] = x_run_problem__mutmut_92 # type: ignore # mutmut generated
mutants_x_run_problem__mutmut['x_run_problem__mutmut_93'] = x_run_problem__mutmut_93 # type: ignore # mutmut generated
mutants_x_run_problem__mutmut['x_run_problem__mutmut_94'] = x_run_problem__mutmut_94 # type: ignore # mutmut generated
mutants_x_run_problem__mutmut['x_run_problem__mutmut_95'] = x_run_problem__mutmut_95 # type: ignore # mutmut generated
mutants_x_run_problem__mutmut['x_run_problem__mutmut_96'] = x_run_problem__mutmut_96 # type: ignore # mutmut generated
mutants_x_run_job__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_run_job__mutmut)
def run_job(job: dict[str, Any], methods: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    try:
        if job["source"] == "adbench":
            x, y, report = load_adbench(job["name"], Path(job["path"]))
        else:
            x, y, report = load_uci(job["meta"], Path(job["path"]))
        result = run_problem(x, y, methods=methods)
    except Exception as error:  # recorded, never dropped silently
        return {"problem": job["problem"], "source": job["source"], "failed": repr(error)}
    return {
        "problem": job["problem"],
        "source": job["source"],
        "name": report["name"],
        "prevalence": float(y.mean()),
        "rows": int(len(y)),
        "features": int(x.shape[1]),
        "report": report,
        **result,
    }


def x_run_job__mutmut_orig(job: dict[str, Any], methods: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    try:
        if job["source"] == "adbench":
            x, y, report = load_adbench(job["name"], Path(job["path"]))
        else:
            x, y, report = load_uci(job["meta"], Path(job["path"]))
        result = run_problem(x, y, methods=methods)
    except Exception as error:  # recorded, never dropped silently
        return {"problem": job["problem"], "source": job["source"], "failed": repr(error)}
    return {
        "problem": job["problem"],
        "source": job["source"],
        "name": report["name"],
        "prevalence": float(y.mean()),
        "rows": int(len(y)),
        "features": int(x.shape[1]),
        "report": report,
        **result,
    }


def x_run_job__mutmut_1(job: dict[str, Any], methods: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings(None)
    try:
        if job["source"] == "adbench":
            x, y, report = load_adbench(job["name"], Path(job["path"]))
        else:
            x, y, report = load_uci(job["meta"], Path(job["path"]))
        result = run_problem(x, y, methods=methods)
    except Exception as error:  # recorded, never dropped silently
        return {"problem": job["problem"], "source": job["source"], "failed": repr(error)}
    return {
        "problem": job["problem"],
        "source": job["source"],
        "name": report["name"],
        "prevalence": float(y.mean()),
        "rows": int(len(y)),
        "features": int(x.shape[1]),
        "report": report,
        **result,
    }


def x_run_job__mutmut_2(job: dict[str, Any], methods: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("XXignoreXX")
    try:
        if job["source"] == "adbench":
            x, y, report = load_adbench(job["name"], Path(job["path"]))
        else:
            x, y, report = load_uci(job["meta"], Path(job["path"]))
        result = run_problem(x, y, methods=methods)
    except Exception as error:  # recorded, never dropped silently
        return {"problem": job["problem"], "source": job["source"], "failed": repr(error)}
    return {
        "problem": job["problem"],
        "source": job["source"],
        "name": report["name"],
        "prevalence": float(y.mean()),
        "rows": int(len(y)),
        "features": int(x.shape[1]),
        "report": report,
        **result,
    }


def x_run_job__mutmut_3(job: dict[str, Any], methods: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("IGNORE")
    try:
        if job["source"] == "adbench":
            x, y, report = load_adbench(job["name"], Path(job["path"]))
        else:
            x, y, report = load_uci(job["meta"], Path(job["path"]))
        result = run_problem(x, y, methods=methods)
    except Exception as error:  # recorded, never dropped silently
        return {"problem": job["problem"], "source": job["source"], "failed": repr(error)}
    return {
        "problem": job["problem"],
        "source": job["source"],
        "name": report["name"],
        "prevalence": float(y.mean()),
        "rows": int(len(y)),
        "features": int(x.shape[1]),
        "report": report,
        **result,
    }


def x_run_job__mutmut_4(job: dict[str, Any], methods: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    try:
        if job["XXsourceXX"] == "adbench":
            x, y, report = load_adbench(job["name"], Path(job["path"]))
        else:
            x, y, report = load_uci(job["meta"], Path(job["path"]))
        result = run_problem(x, y, methods=methods)
    except Exception as error:  # recorded, never dropped silently
        return {"problem": job["problem"], "source": job["source"], "failed": repr(error)}
    return {
        "problem": job["problem"],
        "source": job["source"],
        "name": report["name"],
        "prevalence": float(y.mean()),
        "rows": int(len(y)),
        "features": int(x.shape[1]),
        "report": report,
        **result,
    }


def x_run_job__mutmut_5(job: dict[str, Any], methods: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    try:
        if job["SOURCE"] == "adbench":
            x, y, report = load_adbench(job["name"], Path(job["path"]))
        else:
            x, y, report = load_uci(job["meta"], Path(job["path"]))
        result = run_problem(x, y, methods=methods)
    except Exception as error:  # recorded, never dropped silently
        return {"problem": job["problem"], "source": job["source"], "failed": repr(error)}
    return {
        "problem": job["problem"],
        "source": job["source"],
        "name": report["name"],
        "prevalence": float(y.mean()),
        "rows": int(len(y)),
        "features": int(x.shape[1]),
        "report": report,
        **result,
    }


def x_run_job__mutmut_6(job: dict[str, Any], methods: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    try:
        if job["source"] != "adbench":
            x, y, report = load_adbench(job["name"], Path(job["path"]))
        else:
            x, y, report = load_uci(job["meta"], Path(job["path"]))
        result = run_problem(x, y, methods=methods)
    except Exception as error:  # recorded, never dropped silently
        return {"problem": job["problem"], "source": job["source"], "failed": repr(error)}
    return {
        "problem": job["problem"],
        "source": job["source"],
        "name": report["name"],
        "prevalence": float(y.mean()),
        "rows": int(len(y)),
        "features": int(x.shape[1]),
        "report": report,
        **result,
    }


def x_run_job__mutmut_7(job: dict[str, Any], methods: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    try:
        if job["source"] == "XXadbenchXX":
            x, y, report = load_adbench(job["name"], Path(job["path"]))
        else:
            x, y, report = load_uci(job["meta"], Path(job["path"]))
        result = run_problem(x, y, methods=methods)
    except Exception as error:  # recorded, never dropped silently
        return {"problem": job["problem"], "source": job["source"], "failed": repr(error)}
    return {
        "problem": job["problem"],
        "source": job["source"],
        "name": report["name"],
        "prevalence": float(y.mean()),
        "rows": int(len(y)),
        "features": int(x.shape[1]),
        "report": report,
        **result,
    }


def x_run_job__mutmut_8(job: dict[str, Any], methods: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    try:
        if job["source"] == "ADBENCH":
            x, y, report = load_adbench(job["name"], Path(job["path"]))
        else:
            x, y, report = load_uci(job["meta"], Path(job["path"]))
        result = run_problem(x, y, methods=methods)
    except Exception as error:  # recorded, never dropped silently
        return {"problem": job["problem"], "source": job["source"], "failed": repr(error)}
    return {
        "problem": job["problem"],
        "source": job["source"],
        "name": report["name"],
        "prevalence": float(y.mean()),
        "rows": int(len(y)),
        "features": int(x.shape[1]),
        "report": report,
        **result,
    }


def x_run_job__mutmut_9(job: dict[str, Any], methods: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    try:
        if job["source"] == "adbench":
            x, y, report = None
        else:
            x, y, report = load_uci(job["meta"], Path(job["path"]))
        result = run_problem(x, y, methods=methods)
    except Exception as error:  # recorded, never dropped silently
        return {"problem": job["problem"], "source": job["source"], "failed": repr(error)}
    return {
        "problem": job["problem"],
        "source": job["source"],
        "name": report["name"],
        "prevalence": float(y.mean()),
        "rows": int(len(y)),
        "features": int(x.shape[1]),
        "report": report,
        **result,
    }


def x_run_job__mutmut_10(job: dict[str, Any], methods: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    try:
        if job["source"] == "adbench":
            x, y, report = load_adbench(None, Path(job["path"]))
        else:
            x, y, report = load_uci(job["meta"], Path(job["path"]))
        result = run_problem(x, y, methods=methods)
    except Exception as error:  # recorded, never dropped silently
        return {"problem": job["problem"], "source": job["source"], "failed": repr(error)}
    return {
        "problem": job["problem"],
        "source": job["source"],
        "name": report["name"],
        "prevalence": float(y.mean()),
        "rows": int(len(y)),
        "features": int(x.shape[1]),
        "report": report,
        **result,
    }


def x_run_job__mutmut_11(job: dict[str, Any], methods: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    try:
        if job["source"] == "adbench":
            x, y, report = load_adbench(job["name"], None)
        else:
            x, y, report = load_uci(job["meta"], Path(job["path"]))
        result = run_problem(x, y, methods=methods)
    except Exception as error:  # recorded, never dropped silently
        return {"problem": job["problem"], "source": job["source"], "failed": repr(error)}
    return {
        "problem": job["problem"],
        "source": job["source"],
        "name": report["name"],
        "prevalence": float(y.mean()),
        "rows": int(len(y)),
        "features": int(x.shape[1]),
        "report": report,
        **result,
    }


def x_run_job__mutmut_12(job: dict[str, Any], methods: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    try:
        if job["source"] == "adbench":
            x, y, report = load_adbench(Path(job["path"]))
        else:
            x, y, report = load_uci(job["meta"], Path(job["path"]))
        result = run_problem(x, y, methods=methods)
    except Exception as error:  # recorded, never dropped silently
        return {"problem": job["problem"], "source": job["source"], "failed": repr(error)}
    return {
        "problem": job["problem"],
        "source": job["source"],
        "name": report["name"],
        "prevalence": float(y.mean()),
        "rows": int(len(y)),
        "features": int(x.shape[1]),
        "report": report,
        **result,
    }


def x_run_job__mutmut_13(job: dict[str, Any], methods: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    try:
        if job["source"] == "adbench":
            x, y, report = load_adbench(job["name"], )
        else:
            x, y, report = load_uci(job["meta"], Path(job["path"]))
        result = run_problem(x, y, methods=methods)
    except Exception as error:  # recorded, never dropped silently
        return {"problem": job["problem"], "source": job["source"], "failed": repr(error)}
    return {
        "problem": job["problem"],
        "source": job["source"],
        "name": report["name"],
        "prevalence": float(y.mean()),
        "rows": int(len(y)),
        "features": int(x.shape[1]),
        "report": report,
        **result,
    }


def x_run_job__mutmut_14(job: dict[str, Any], methods: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    try:
        if job["source"] == "adbench":
            x, y, report = load_adbench(job["XXnameXX"], Path(job["path"]))
        else:
            x, y, report = load_uci(job["meta"], Path(job["path"]))
        result = run_problem(x, y, methods=methods)
    except Exception as error:  # recorded, never dropped silently
        return {"problem": job["problem"], "source": job["source"], "failed": repr(error)}
    return {
        "problem": job["problem"],
        "source": job["source"],
        "name": report["name"],
        "prevalence": float(y.mean()),
        "rows": int(len(y)),
        "features": int(x.shape[1]),
        "report": report,
        **result,
    }


def x_run_job__mutmut_15(job: dict[str, Any], methods: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    try:
        if job["source"] == "adbench":
            x, y, report = load_adbench(job["NAME"], Path(job["path"]))
        else:
            x, y, report = load_uci(job["meta"], Path(job["path"]))
        result = run_problem(x, y, methods=methods)
    except Exception as error:  # recorded, never dropped silently
        return {"problem": job["problem"], "source": job["source"], "failed": repr(error)}
    return {
        "problem": job["problem"],
        "source": job["source"],
        "name": report["name"],
        "prevalence": float(y.mean()),
        "rows": int(len(y)),
        "features": int(x.shape[1]),
        "report": report,
        **result,
    }


def x_run_job__mutmut_16(job: dict[str, Any], methods: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    try:
        if job["source"] == "adbench":
            x, y, report = load_adbench(job["name"], Path(None))
        else:
            x, y, report = load_uci(job["meta"], Path(job["path"]))
        result = run_problem(x, y, methods=methods)
    except Exception as error:  # recorded, never dropped silently
        return {"problem": job["problem"], "source": job["source"], "failed": repr(error)}
    return {
        "problem": job["problem"],
        "source": job["source"],
        "name": report["name"],
        "prevalence": float(y.mean()),
        "rows": int(len(y)),
        "features": int(x.shape[1]),
        "report": report,
        **result,
    }


def x_run_job__mutmut_17(job: dict[str, Any], methods: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    try:
        if job["source"] == "adbench":
            x, y, report = load_adbench(job["name"], Path(job["XXpathXX"]))
        else:
            x, y, report = load_uci(job["meta"], Path(job["path"]))
        result = run_problem(x, y, methods=methods)
    except Exception as error:  # recorded, never dropped silently
        return {"problem": job["problem"], "source": job["source"], "failed": repr(error)}
    return {
        "problem": job["problem"],
        "source": job["source"],
        "name": report["name"],
        "prevalence": float(y.mean()),
        "rows": int(len(y)),
        "features": int(x.shape[1]),
        "report": report,
        **result,
    }


def x_run_job__mutmut_18(job: dict[str, Any], methods: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    try:
        if job["source"] == "adbench":
            x, y, report = load_adbench(job["name"], Path(job["PATH"]))
        else:
            x, y, report = load_uci(job["meta"], Path(job["path"]))
        result = run_problem(x, y, methods=methods)
    except Exception as error:  # recorded, never dropped silently
        return {"problem": job["problem"], "source": job["source"], "failed": repr(error)}
    return {
        "problem": job["problem"],
        "source": job["source"],
        "name": report["name"],
        "prevalence": float(y.mean()),
        "rows": int(len(y)),
        "features": int(x.shape[1]),
        "report": report,
        **result,
    }


def x_run_job__mutmut_19(job: dict[str, Any], methods: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    try:
        if job["source"] == "adbench":
            x, y, report = load_adbench(job["name"], Path(job["path"]))
        else:
            x, y, report = None
        result = run_problem(x, y, methods=methods)
    except Exception as error:  # recorded, never dropped silently
        return {"problem": job["problem"], "source": job["source"], "failed": repr(error)}
    return {
        "problem": job["problem"],
        "source": job["source"],
        "name": report["name"],
        "prevalence": float(y.mean()),
        "rows": int(len(y)),
        "features": int(x.shape[1]),
        "report": report,
        **result,
    }


def x_run_job__mutmut_20(job: dict[str, Any], methods: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    try:
        if job["source"] == "adbench":
            x, y, report = load_adbench(job["name"], Path(job["path"]))
        else:
            x, y, report = load_uci(None, Path(job["path"]))
        result = run_problem(x, y, methods=methods)
    except Exception as error:  # recorded, never dropped silently
        return {"problem": job["problem"], "source": job["source"], "failed": repr(error)}
    return {
        "problem": job["problem"],
        "source": job["source"],
        "name": report["name"],
        "prevalence": float(y.mean()),
        "rows": int(len(y)),
        "features": int(x.shape[1]),
        "report": report,
        **result,
    }


def x_run_job__mutmut_21(job: dict[str, Any], methods: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    try:
        if job["source"] == "adbench":
            x, y, report = load_adbench(job["name"], Path(job["path"]))
        else:
            x, y, report = load_uci(job["meta"], None)
        result = run_problem(x, y, methods=methods)
    except Exception as error:  # recorded, never dropped silently
        return {"problem": job["problem"], "source": job["source"], "failed": repr(error)}
    return {
        "problem": job["problem"],
        "source": job["source"],
        "name": report["name"],
        "prevalence": float(y.mean()),
        "rows": int(len(y)),
        "features": int(x.shape[1]),
        "report": report,
        **result,
    }


def x_run_job__mutmut_22(job: dict[str, Any], methods: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    try:
        if job["source"] == "adbench":
            x, y, report = load_adbench(job["name"], Path(job["path"]))
        else:
            x, y, report = load_uci(Path(job["path"]))
        result = run_problem(x, y, methods=methods)
    except Exception as error:  # recorded, never dropped silently
        return {"problem": job["problem"], "source": job["source"], "failed": repr(error)}
    return {
        "problem": job["problem"],
        "source": job["source"],
        "name": report["name"],
        "prevalence": float(y.mean()),
        "rows": int(len(y)),
        "features": int(x.shape[1]),
        "report": report,
        **result,
    }


def x_run_job__mutmut_23(job: dict[str, Any], methods: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    try:
        if job["source"] == "adbench":
            x, y, report = load_adbench(job["name"], Path(job["path"]))
        else:
            x, y, report = load_uci(job["meta"], )
        result = run_problem(x, y, methods=methods)
    except Exception as error:  # recorded, never dropped silently
        return {"problem": job["problem"], "source": job["source"], "failed": repr(error)}
    return {
        "problem": job["problem"],
        "source": job["source"],
        "name": report["name"],
        "prevalence": float(y.mean()),
        "rows": int(len(y)),
        "features": int(x.shape[1]),
        "report": report,
        **result,
    }


def x_run_job__mutmut_24(job: dict[str, Any], methods: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    try:
        if job["source"] == "adbench":
            x, y, report = load_adbench(job["name"], Path(job["path"]))
        else:
            x, y, report = load_uci(job["XXmetaXX"], Path(job["path"]))
        result = run_problem(x, y, methods=methods)
    except Exception as error:  # recorded, never dropped silently
        return {"problem": job["problem"], "source": job["source"], "failed": repr(error)}
    return {
        "problem": job["problem"],
        "source": job["source"],
        "name": report["name"],
        "prevalence": float(y.mean()),
        "rows": int(len(y)),
        "features": int(x.shape[1]),
        "report": report,
        **result,
    }


def x_run_job__mutmut_25(job: dict[str, Any], methods: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    try:
        if job["source"] == "adbench":
            x, y, report = load_adbench(job["name"], Path(job["path"]))
        else:
            x, y, report = load_uci(job["META"], Path(job["path"]))
        result = run_problem(x, y, methods=methods)
    except Exception as error:  # recorded, never dropped silently
        return {"problem": job["problem"], "source": job["source"], "failed": repr(error)}
    return {
        "problem": job["problem"],
        "source": job["source"],
        "name": report["name"],
        "prevalence": float(y.mean()),
        "rows": int(len(y)),
        "features": int(x.shape[1]),
        "report": report,
        **result,
    }


def x_run_job__mutmut_26(job: dict[str, Any], methods: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    try:
        if job["source"] == "adbench":
            x, y, report = load_adbench(job["name"], Path(job["path"]))
        else:
            x, y, report = load_uci(job["meta"], Path(None))
        result = run_problem(x, y, methods=methods)
    except Exception as error:  # recorded, never dropped silently
        return {"problem": job["problem"], "source": job["source"], "failed": repr(error)}
    return {
        "problem": job["problem"],
        "source": job["source"],
        "name": report["name"],
        "prevalence": float(y.mean()),
        "rows": int(len(y)),
        "features": int(x.shape[1]),
        "report": report,
        **result,
    }


def x_run_job__mutmut_27(job: dict[str, Any], methods: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    try:
        if job["source"] == "adbench":
            x, y, report = load_adbench(job["name"], Path(job["path"]))
        else:
            x, y, report = load_uci(job["meta"], Path(job["XXpathXX"]))
        result = run_problem(x, y, methods=methods)
    except Exception as error:  # recorded, never dropped silently
        return {"problem": job["problem"], "source": job["source"], "failed": repr(error)}
    return {
        "problem": job["problem"],
        "source": job["source"],
        "name": report["name"],
        "prevalence": float(y.mean()),
        "rows": int(len(y)),
        "features": int(x.shape[1]),
        "report": report,
        **result,
    }


def x_run_job__mutmut_28(job: dict[str, Any], methods: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    try:
        if job["source"] == "adbench":
            x, y, report = load_adbench(job["name"], Path(job["path"]))
        else:
            x, y, report = load_uci(job["meta"], Path(job["PATH"]))
        result = run_problem(x, y, methods=methods)
    except Exception as error:  # recorded, never dropped silently
        return {"problem": job["problem"], "source": job["source"], "failed": repr(error)}
    return {
        "problem": job["problem"],
        "source": job["source"],
        "name": report["name"],
        "prevalence": float(y.mean()),
        "rows": int(len(y)),
        "features": int(x.shape[1]),
        "report": report,
        **result,
    }


def x_run_job__mutmut_29(job: dict[str, Any], methods: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    try:
        if job["source"] == "adbench":
            x, y, report = load_adbench(job["name"], Path(job["path"]))
        else:
            x, y, report = load_uci(job["meta"], Path(job["path"]))
        result = None
    except Exception as error:  # recorded, never dropped silently
        return {"problem": job["problem"], "source": job["source"], "failed": repr(error)}
    return {
        "problem": job["problem"],
        "source": job["source"],
        "name": report["name"],
        "prevalence": float(y.mean()),
        "rows": int(len(y)),
        "features": int(x.shape[1]),
        "report": report,
        **result,
    }


def x_run_job__mutmut_30(job: dict[str, Any], methods: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    try:
        if job["source"] == "adbench":
            x, y, report = load_adbench(job["name"], Path(job["path"]))
        else:
            x, y, report = load_uci(job["meta"], Path(job["path"]))
        result = run_problem(None, y, methods=methods)
    except Exception as error:  # recorded, never dropped silently
        return {"problem": job["problem"], "source": job["source"], "failed": repr(error)}
    return {
        "problem": job["problem"],
        "source": job["source"],
        "name": report["name"],
        "prevalence": float(y.mean()),
        "rows": int(len(y)),
        "features": int(x.shape[1]),
        "report": report,
        **result,
    }


def x_run_job__mutmut_31(job: dict[str, Any], methods: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    try:
        if job["source"] == "adbench":
            x, y, report = load_adbench(job["name"], Path(job["path"]))
        else:
            x, y, report = load_uci(job["meta"], Path(job["path"]))
        result = run_problem(x, None, methods=methods)
    except Exception as error:  # recorded, never dropped silently
        return {"problem": job["problem"], "source": job["source"], "failed": repr(error)}
    return {
        "problem": job["problem"],
        "source": job["source"],
        "name": report["name"],
        "prevalence": float(y.mean()),
        "rows": int(len(y)),
        "features": int(x.shape[1]),
        "report": report,
        **result,
    }


def x_run_job__mutmut_32(job: dict[str, Any], methods: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    try:
        if job["source"] == "adbench":
            x, y, report = load_adbench(job["name"], Path(job["path"]))
        else:
            x, y, report = load_uci(job["meta"], Path(job["path"]))
        result = run_problem(x, y, methods=None)
    except Exception as error:  # recorded, never dropped silently
        return {"problem": job["problem"], "source": job["source"], "failed": repr(error)}
    return {
        "problem": job["problem"],
        "source": job["source"],
        "name": report["name"],
        "prevalence": float(y.mean()),
        "rows": int(len(y)),
        "features": int(x.shape[1]),
        "report": report,
        **result,
    }


def x_run_job__mutmut_33(job: dict[str, Any], methods: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    try:
        if job["source"] == "adbench":
            x, y, report = load_adbench(job["name"], Path(job["path"]))
        else:
            x, y, report = load_uci(job["meta"], Path(job["path"]))
        result = run_problem(y, methods=methods)
    except Exception as error:  # recorded, never dropped silently
        return {"problem": job["problem"], "source": job["source"], "failed": repr(error)}
    return {
        "problem": job["problem"],
        "source": job["source"],
        "name": report["name"],
        "prevalence": float(y.mean()),
        "rows": int(len(y)),
        "features": int(x.shape[1]),
        "report": report,
        **result,
    }


def x_run_job__mutmut_34(job: dict[str, Any], methods: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    try:
        if job["source"] == "adbench":
            x, y, report = load_adbench(job["name"], Path(job["path"]))
        else:
            x, y, report = load_uci(job["meta"], Path(job["path"]))
        result = run_problem(x, methods=methods)
    except Exception as error:  # recorded, never dropped silently
        return {"problem": job["problem"], "source": job["source"], "failed": repr(error)}
    return {
        "problem": job["problem"],
        "source": job["source"],
        "name": report["name"],
        "prevalence": float(y.mean()),
        "rows": int(len(y)),
        "features": int(x.shape[1]),
        "report": report,
        **result,
    }


def x_run_job__mutmut_35(job: dict[str, Any], methods: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    try:
        if job["source"] == "adbench":
            x, y, report = load_adbench(job["name"], Path(job["path"]))
        else:
            x, y, report = load_uci(job["meta"], Path(job["path"]))
        result = run_problem(x, y, )
    except Exception as error:  # recorded, never dropped silently
        return {"problem": job["problem"], "source": job["source"], "failed": repr(error)}
    return {
        "problem": job["problem"],
        "source": job["source"],
        "name": report["name"],
        "prevalence": float(y.mean()),
        "rows": int(len(y)),
        "features": int(x.shape[1]),
        "report": report,
        **result,
    }


def x_run_job__mutmut_36(job: dict[str, Any], methods: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    try:
        if job["source"] == "adbench":
            x, y, report = load_adbench(job["name"], Path(job["path"]))
        else:
            x, y, report = load_uci(job["meta"], Path(job["path"]))
        result = run_problem(x, y, methods=methods)
    except Exception as error:  # recorded, never dropped silently
        return {"XXproblemXX": job["problem"], "source": job["source"], "failed": repr(error)}
    return {
        "problem": job["problem"],
        "source": job["source"],
        "name": report["name"],
        "prevalence": float(y.mean()),
        "rows": int(len(y)),
        "features": int(x.shape[1]),
        "report": report,
        **result,
    }


def x_run_job__mutmut_37(job: dict[str, Any], methods: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    try:
        if job["source"] == "adbench":
            x, y, report = load_adbench(job["name"], Path(job["path"]))
        else:
            x, y, report = load_uci(job["meta"], Path(job["path"]))
        result = run_problem(x, y, methods=methods)
    except Exception as error:  # recorded, never dropped silently
        return {"PROBLEM": job["problem"], "source": job["source"], "failed": repr(error)}
    return {
        "problem": job["problem"],
        "source": job["source"],
        "name": report["name"],
        "prevalence": float(y.mean()),
        "rows": int(len(y)),
        "features": int(x.shape[1]),
        "report": report,
        **result,
    }


def x_run_job__mutmut_38(job: dict[str, Any], methods: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    try:
        if job["source"] == "adbench":
            x, y, report = load_adbench(job["name"], Path(job["path"]))
        else:
            x, y, report = load_uci(job["meta"], Path(job["path"]))
        result = run_problem(x, y, methods=methods)
    except Exception as error:  # recorded, never dropped silently
        return {"problem": job["XXproblemXX"], "source": job["source"], "failed": repr(error)}
    return {
        "problem": job["problem"],
        "source": job["source"],
        "name": report["name"],
        "prevalence": float(y.mean()),
        "rows": int(len(y)),
        "features": int(x.shape[1]),
        "report": report,
        **result,
    }


def x_run_job__mutmut_39(job: dict[str, Any], methods: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    try:
        if job["source"] == "adbench":
            x, y, report = load_adbench(job["name"], Path(job["path"]))
        else:
            x, y, report = load_uci(job["meta"], Path(job["path"]))
        result = run_problem(x, y, methods=methods)
    except Exception as error:  # recorded, never dropped silently
        return {"problem": job["PROBLEM"], "source": job["source"], "failed": repr(error)}
    return {
        "problem": job["problem"],
        "source": job["source"],
        "name": report["name"],
        "prevalence": float(y.mean()),
        "rows": int(len(y)),
        "features": int(x.shape[1]),
        "report": report,
        **result,
    }


def x_run_job__mutmut_40(job: dict[str, Any], methods: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    try:
        if job["source"] == "adbench":
            x, y, report = load_adbench(job["name"], Path(job["path"]))
        else:
            x, y, report = load_uci(job["meta"], Path(job["path"]))
        result = run_problem(x, y, methods=methods)
    except Exception as error:  # recorded, never dropped silently
        return {"problem": job["problem"], "XXsourceXX": job["source"], "failed": repr(error)}
    return {
        "problem": job["problem"],
        "source": job["source"],
        "name": report["name"],
        "prevalence": float(y.mean()),
        "rows": int(len(y)),
        "features": int(x.shape[1]),
        "report": report,
        **result,
    }


def x_run_job__mutmut_41(job: dict[str, Any], methods: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    try:
        if job["source"] == "adbench":
            x, y, report = load_adbench(job["name"], Path(job["path"]))
        else:
            x, y, report = load_uci(job["meta"], Path(job["path"]))
        result = run_problem(x, y, methods=methods)
    except Exception as error:  # recorded, never dropped silently
        return {"problem": job["problem"], "SOURCE": job["source"], "failed": repr(error)}
    return {
        "problem": job["problem"],
        "source": job["source"],
        "name": report["name"],
        "prevalence": float(y.mean()),
        "rows": int(len(y)),
        "features": int(x.shape[1]),
        "report": report,
        **result,
    }


def x_run_job__mutmut_42(job: dict[str, Any], methods: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    try:
        if job["source"] == "adbench":
            x, y, report = load_adbench(job["name"], Path(job["path"]))
        else:
            x, y, report = load_uci(job["meta"], Path(job["path"]))
        result = run_problem(x, y, methods=methods)
    except Exception as error:  # recorded, never dropped silently
        return {"problem": job["problem"], "source": job["XXsourceXX"], "failed": repr(error)}
    return {
        "problem": job["problem"],
        "source": job["source"],
        "name": report["name"],
        "prevalence": float(y.mean()),
        "rows": int(len(y)),
        "features": int(x.shape[1]),
        "report": report,
        **result,
    }


def x_run_job__mutmut_43(job: dict[str, Any], methods: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    try:
        if job["source"] == "adbench":
            x, y, report = load_adbench(job["name"], Path(job["path"]))
        else:
            x, y, report = load_uci(job["meta"], Path(job["path"]))
        result = run_problem(x, y, methods=methods)
    except Exception as error:  # recorded, never dropped silently
        return {"problem": job["problem"], "source": job["SOURCE"], "failed": repr(error)}
    return {
        "problem": job["problem"],
        "source": job["source"],
        "name": report["name"],
        "prevalence": float(y.mean()),
        "rows": int(len(y)),
        "features": int(x.shape[1]),
        "report": report,
        **result,
    }


def x_run_job__mutmut_44(job: dict[str, Any], methods: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    try:
        if job["source"] == "adbench":
            x, y, report = load_adbench(job["name"], Path(job["path"]))
        else:
            x, y, report = load_uci(job["meta"], Path(job["path"]))
        result = run_problem(x, y, methods=methods)
    except Exception as error:  # recorded, never dropped silently
        return {"problem": job["problem"], "source": job["source"], "XXfailedXX": repr(error)}
    return {
        "problem": job["problem"],
        "source": job["source"],
        "name": report["name"],
        "prevalence": float(y.mean()),
        "rows": int(len(y)),
        "features": int(x.shape[1]),
        "report": report,
        **result,
    }


def x_run_job__mutmut_45(job: dict[str, Any], methods: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    try:
        if job["source"] == "adbench":
            x, y, report = load_adbench(job["name"], Path(job["path"]))
        else:
            x, y, report = load_uci(job["meta"], Path(job["path"]))
        result = run_problem(x, y, methods=methods)
    except Exception as error:  # recorded, never dropped silently
        return {"problem": job["problem"], "source": job["source"], "FAILED": repr(error)}
    return {
        "problem": job["problem"],
        "source": job["source"],
        "name": report["name"],
        "prevalence": float(y.mean()),
        "rows": int(len(y)),
        "features": int(x.shape[1]),
        "report": report,
        **result,
    }


def x_run_job__mutmut_46(job: dict[str, Any], methods: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    try:
        if job["source"] == "adbench":
            x, y, report = load_adbench(job["name"], Path(job["path"]))
        else:
            x, y, report = load_uci(job["meta"], Path(job["path"]))
        result = run_problem(x, y, methods=methods)
    except Exception as error:  # recorded, never dropped silently
        return {"problem": job["problem"], "source": job["source"], "failed": repr(None)}
    return {
        "problem": job["problem"],
        "source": job["source"],
        "name": report["name"],
        "prevalence": float(y.mean()),
        "rows": int(len(y)),
        "features": int(x.shape[1]),
        "report": report,
        **result,
    }


def x_run_job__mutmut_47(job: dict[str, Any], methods: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    try:
        if job["source"] == "adbench":
            x, y, report = load_adbench(job["name"], Path(job["path"]))
        else:
            x, y, report = load_uci(job["meta"], Path(job["path"]))
        result = run_problem(x, y, methods=methods)
    except Exception as error:  # recorded, never dropped silently
        return {"problem": job["problem"], "source": job["source"], "failed": repr(error)}
    return {
        "XXproblemXX": job["problem"],
        "source": job["source"],
        "name": report["name"],
        "prevalence": float(y.mean()),
        "rows": int(len(y)),
        "features": int(x.shape[1]),
        "report": report,
        **result,
    }


def x_run_job__mutmut_48(job: dict[str, Any], methods: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    try:
        if job["source"] == "adbench":
            x, y, report = load_adbench(job["name"], Path(job["path"]))
        else:
            x, y, report = load_uci(job["meta"], Path(job["path"]))
        result = run_problem(x, y, methods=methods)
    except Exception as error:  # recorded, never dropped silently
        return {"problem": job["problem"], "source": job["source"], "failed": repr(error)}
    return {
        "PROBLEM": job["problem"],
        "source": job["source"],
        "name": report["name"],
        "prevalence": float(y.mean()),
        "rows": int(len(y)),
        "features": int(x.shape[1]),
        "report": report,
        **result,
    }


def x_run_job__mutmut_49(job: dict[str, Any], methods: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    try:
        if job["source"] == "adbench":
            x, y, report = load_adbench(job["name"], Path(job["path"]))
        else:
            x, y, report = load_uci(job["meta"], Path(job["path"]))
        result = run_problem(x, y, methods=methods)
    except Exception as error:  # recorded, never dropped silently
        return {"problem": job["problem"], "source": job["source"], "failed": repr(error)}
    return {
        "problem": job["XXproblemXX"],
        "source": job["source"],
        "name": report["name"],
        "prevalence": float(y.mean()),
        "rows": int(len(y)),
        "features": int(x.shape[1]),
        "report": report,
        **result,
    }


def x_run_job__mutmut_50(job: dict[str, Any], methods: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    try:
        if job["source"] == "adbench":
            x, y, report = load_adbench(job["name"], Path(job["path"]))
        else:
            x, y, report = load_uci(job["meta"], Path(job["path"]))
        result = run_problem(x, y, methods=methods)
    except Exception as error:  # recorded, never dropped silently
        return {"problem": job["problem"], "source": job["source"], "failed": repr(error)}
    return {
        "problem": job["PROBLEM"],
        "source": job["source"],
        "name": report["name"],
        "prevalence": float(y.mean()),
        "rows": int(len(y)),
        "features": int(x.shape[1]),
        "report": report,
        **result,
    }


def x_run_job__mutmut_51(job: dict[str, Any], methods: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    try:
        if job["source"] == "adbench":
            x, y, report = load_adbench(job["name"], Path(job["path"]))
        else:
            x, y, report = load_uci(job["meta"], Path(job["path"]))
        result = run_problem(x, y, methods=methods)
    except Exception as error:  # recorded, never dropped silently
        return {"problem": job["problem"], "source": job["source"], "failed": repr(error)}
    return {
        "problem": job["problem"],
        "XXsourceXX": job["source"],
        "name": report["name"],
        "prevalence": float(y.mean()),
        "rows": int(len(y)),
        "features": int(x.shape[1]),
        "report": report,
        **result,
    }


def x_run_job__mutmut_52(job: dict[str, Any], methods: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    try:
        if job["source"] == "adbench":
            x, y, report = load_adbench(job["name"], Path(job["path"]))
        else:
            x, y, report = load_uci(job["meta"], Path(job["path"]))
        result = run_problem(x, y, methods=methods)
    except Exception as error:  # recorded, never dropped silently
        return {"problem": job["problem"], "source": job["source"], "failed": repr(error)}
    return {
        "problem": job["problem"],
        "SOURCE": job["source"],
        "name": report["name"],
        "prevalence": float(y.mean()),
        "rows": int(len(y)),
        "features": int(x.shape[1]),
        "report": report,
        **result,
    }


def x_run_job__mutmut_53(job: dict[str, Any], methods: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    try:
        if job["source"] == "adbench":
            x, y, report = load_adbench(job["name"], Path(job["path"]))
        else:
            x, y, report = load_uci(job["meta"], Path(job["path"]))
        result = run_problem(x, y, methods=methods)
    except Exception as error:  # recorded, never dropped silently
        return {"problem": job["problem"], "source": job["source"], "failed": repr(error)}
    return {
        "problem": job["problem"],
        "source": job["XXsourceXX"],
        "name": report["name"],
        "prevalence": float(y.mean()),
        "rows": int(len(y)),
        "features": int(x.shape[1]),
        "report": report,
        **result,
    }


def x_run_job__mutmut_54(job: dict[str, Any], methods: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    try:
        if job["source"] == "adbench":
            x, y, report = load_adbench(job["name"], Path(job["path"]))
        else:
            x, y, report = load_uci(job["meta"], Path(job["path"]))
        result = run_problem(x, y, methods=methods)
    except Exception as error:  # recorded, never dropped silently
        return {"problem": job["problem"], "source": job["source"], "failed": repr(error)}
    return {
        "problem": job["problem"],
        "source": job["SOURCE"],
        "name": report["name"],
        "prevalence": float(y.mean()),
        "rows": int(len(y)),
        "features": int(x.shape[1]),
        "report": report,
        **result,
    }


def x_run_job__mutmut_55(job: dict[str, Any], methods: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    try:
        if job["source"] == "adbench":
            x, y, report = load_adbench(job["name"], Path(job["path"]))
        else:
            x, y, report = load_uci(job["meta"], Path(job["path"]))
        result = run_problem(x, y, methods=methods)
    except Exception as error:  # recorded, never dropped silently
        return {"problem": job["problem"], "source": job["source"], "failed": repr(error)}
    return {
        "problem": job["problem"],
        "source": job["source"],
        "XXnameXX": report["name"],
        "prevalence": float(y.mean()),
        "rows": int(len(y)),
        "features": int(x.shape[1]),
        "report": report,
        **result,
    }


def x_run_job__mutmut_56(job: dict[str, Any], methods: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    try:
        if job["source"] == "adbench":
            x, y, report = load_adbench(job["name"], Path(job["path"]))
        else:
            x, y, report = load_uci(job["meta"], Path(job["path"]))
        result = run_problem(x, y, methods=methods)
    except Exception as error:  # recorded, never dropped silently
        return {"problem": job["problem"], "source": job["source"], "failed": repr(error)}
    return {
        "problem": job["problem"],
        "source": job["source"],
        "NAME": report["name"],
        "prevalence": float(y.mean()),
        "rows": int(len(y)),
        "features": int(x.shape[1]),
        "report": report,
        **result,
    }


def x_run_job__mutmut_57(job: dict[str, Any], methods: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    try:
        if job["source"] == "adbench":
            x, y, report = load_adbench(job["name"], Path(job["path"]))
        else:
            x, y, report = load_uci(job["meta"], Path(job["path"]))
        result = run_problem(x, y, methods=methods)
    except Exception as error:  # recorded, never dropped silently
        return {"problem": job["problem"], "source": job["source"], "failed": repr(error)}
    return {
        "problem": job["problem"],
        "source": job["source"],
        "name": report["XXnameXX"],
        "prevalence": float(y.mean()),
        "rows": int(len(y)),
        "features": int(x.shape[1]),
        "report": report,
        **result,
    }


def x_run_job__mutmut_58(job: dict[str, Any], methods: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    try:
        if job["source"] == "adbench":
            x, y, report = load_adbench(job["name"], Path(job["path"]))
        else:
            x, y, report = load_uci(job["meta"], Path(job["path"]))
        result = run_problem(x, y, methods=methods)
    except Exception as error:  # recorded, never dropped silently
        return {"problem": job["problem"], "source": job["source"], "failed": repr(error)}
    return {
        "problem": job["problem"],
        "source": job["source"],
        "name": report["NAME"],
        "prevalence": float(y.mean()),
        "rows": int(len(y)),
        "features": int(x.shape[1]),
        "report": report,
        **result,
    }


def x_run_job__mutmut_59(job: dict[str, Any], methods: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    try:
        if job["source"] == "adbench":
            x, y, report = load_adbench(job["name"], Path(job["path"]))
        else:
            x, y, report = load_uci(job["meta"], Path(job["path"]))
        result = run_problem(x, y, methods=methods)
    except Exception as error:  # recorded, never dropped silently
        return {"problem": job["problem"], "source": job["source"], "failed": repr(error)}
    return {
        "problem": job["problem"],
        "source": job["source"],
        "name": report["name"],
        "XXprevalenceXX": float(y.mean()),
        "rows": int(len(y)),
        "features": int(x.shape[1]),
        "report": report,
        **result,
    }


def x_run_job__mutmut_60(job: dict[str, Any], methods: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    try:
        if job["source"] == "adbench":
            x, y, report = load_adbench(job["name"], Path(job["path"]))
        else:
            x, y, report = load_uci(job["meta"], Path(job["path"]))
        result = run_problem(x, y, methods=methods)
    except Exception as error:  # recorded, never dropped silently
        return {"problem": job["problem"], "source": job["source"], "failed": repr(error)}
    return {
        "problem": job["problem"],
        "source": job["source"],
        "name": report["name"],
        "PREVALENCE": float(y.mean()),
        "rows": int(len(y)),
        "features": int(x.shape[1]),
        "report": report,
        **result,
    }


def x_run_job__mutmut_61(job: dict[str, Any], methods: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    try:
        if job["source"] == "adbench":
            x, y, report = load_adbench(job["name"], Path(job["path"]))
        else:
            x, y, report = load_uci(job["meta"], Path(job["path"]))
        result = run_problem(x, y, methods=methods)
    except Exception as error:  # recorded, never dropped silently
        return {"problem": job["problem"], "source": job["source"], "failed": repr(error)}
    return {
        "problem": job["problem"],
        "source": job["source"],
        "name": report["name"],
        "prevalence": float(None),
        "rows": int(len(y)),
        "features": int(x.shape[1]),
        "report": report,
        **result,
    }


def x_run_job__mutmut_62(job: dict[str, Any], methods: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    try:
        if job["source"] == "adbench":
            x, y, report = load_adbench(job["name"], Path(job["path"]))
        else:
            x, y, report = load_uci(job["meta"], Path(job["path"]))
        result = run_problem(x, y, methods=methods)
    except Exception as error:  # recorded, never dropped silently
        return {"problem": job["problem"], "source": job["source"], "failed": repr(error)}
    return {
        "problem": job["problem"],
        "source": job["source"],
        "name": report["name"],
        "prevalence": float(y.mean()),
        "XXrowsXX": int(len(y)),
        "features": int(x.shape[1]),
        "report": report,
        **result,
    }


def x_run_job__mutmut_63(job: dict[str, Any], methods: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    try:
        if job["source"] == "adbench":
            x, y, report = load_adbench(job["name"], Path(job["path"]))
        else:
            x, y, report = load_uci(job["meta"], Path(job["path"]))
        result = run_problem(x, y, methods=methods)
    except Exception as error:  # recorded, never dropped silently
        return {"problem": job["problem"], "source": job["source"], "failed": repr(error)}
    return {
        "problem": job["problem"],
        "source": job["source"],
        "name": report["name"],
        "prevalence": float(y.mean()),
        "ROWS": int(len(y)),
        "features": int(x.shape[1]),
        "report": report,
        **result,
    }


def x_run_job__mutmut_64(job: dict[str, Any], methods: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    try:
        if job["source"] == "adbench":
            x, y, report = load_adbench(job["name"], Path(job["path"]))
        else:
            x, y, report = load_uci(job["meta"], Path(job["path"]))
        result = run_problem(x, y, methods=methods)
    except Exception as error:  # recorded, never dropped silently
        return {"problem": job["problem"], "source": job["source"], "failed": repr(error)}
    return {
        "problem": job["problem"],
        "source": job["source"],
        "name": report["name"],
        "prevalence": float(y.mean()),
        "rows": int(None),
        "features": int(x.shape[1]),
        "report": report,
        **result,
    }


def x_run_job__mutmut_65(job: dict[str, Any], methods: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    try:
        if job["source"] == "adbench":
            x, y, report = load_adbench(job["name"], Path(job["path"]))
        else:
            x, y, report = load_uci(job["meta"], Path(job["path"]))
        result = run_problem(x, y, methods=methods)
    except Exception as error:  # recorded, never dropped silently
        return {"problem": job["problem"], "source": job["source"], "failed": repr(error)}
    return {
        "problem": job["problem"],
        "source": job["source"],
        "name": report["name"],
        "prevalence": float(y.mean()),
        "rows": int(len(y)),
        "XXfeaturesXX": int(x.shape[1]),
        "report": report,
        **result,
    }


def x_run_job__mutmut_66(job: dict[str, Any], methods: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    try:
        if job["source"] == "adbench":
            x, y, report = load_adbench(job["name"], Path(job["path"]))
        else:
            x, y, report = load_uci(job["meta"], Path(job["path"]))
        result = run_problem(x, y, methods=methods)
    except Exception as error:  # recorded, never dropped silently
        return {"problem": job["problem"], "source": job["source"], "failed": repr(error)}
    return {
        "problem": job["problem"],
        "source": job["source"],
        "name": report["name"],
        "prevalence": float(y.mean()),
        "rows": int(len(y)),
        "FEATURES": int(x.shape[1]),
        "report": report,
        **result,
    }


def x_run_job__mutmut_67(job: dict[str, Any], methods: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    try:
        if job["source"] == "adbench":
            x, y, report = load_adbench(job["name"], Path(job["path"]))
        else:
            x, y, report = load_uci(job["meta"], Path(job["path"]))
        result = run_problem(x, y, methods=methods)
    except Exception as error:  # recorded, never dropped silently
        return {"problem": job["problem"], "source": job["source"], "failed": repr(error)}
    return {
        "problem": job["problem"],
        "source": job["source"],
        "name": report["name"],
        "prevalence": float(y.mean()),
        "rows": int(len(y)),
        "features": int(None),
        "report": report,
        **result,
    }


def x_run_job__mutmut_68(job: dict[str, Any], methods: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    try:
        if job["source"] == "adbench":
            x, y, report = load_adbench(job["name"], Path(job["path"]))
        else:
            x, y, report = load_uci(job["meta"], Path(job["path"]))
        result = run_problem(x, y, methods=methods)
    except Exception as error:  # recorded, never dropped silently
        return {"problem": job["problem"], "source": job["source"], "failed": repr(error)}
    return {
        "problem": job["problem"],
        "source": job["source"],
        "name": report["name"],
        "prevalence": float(y.mean()),
        "rows": int(len(y)),
        "features": int(x.shape[2]),
        "report": report,
        **result,
    }


def x_run_job__mutmut_69(job: dict[str, Any], methods: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    try:
        if job["source"] == "adbench":
            x, y, report = load_adbench(job["name"], Path(job["path"]))
        else:
            x, y, report = load_uci(job["meta"], Path(job["path"]))
        result = run_problem(x, y, methods=methods)
    except Exception as error:  # recorded, never dropped silently
        return {"problem": job["problem"], "source": job["source"], "failed": repr(error)}
    return {
        "problem": job["problem"],
        "source": job["source"],
        "name": report["name"],
        "prevalence": float(y.mean()),
        "rows": int(len(y)),
        "features": int(x.shape[1]),
        "XXreportXX": report,
        **result,
    }


def x_run_job__mutmut_70(job: dict[str, Any], methods: list[str] | None = None) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    try:
        if job["source"] == "adbench":
            x, y, report = load_adbench(job["name"], Path(job["path"]))
        else:
            x, y, report = load_uci(job["meta"], Path(job["path"]))
        result = run_problem(x, y, methods=methods)
    except Exception as error:  # recorded, never dropped silently
        return {"problem": job["problem"], "source": job["source"], "failed": repr(error)}
    return {
        "problem": job["problem"],
        "source": job["source"],
        "name": report["name"],
        "prevalence": float(y.mean()),
        "rows": int(len(y)),
        "features": int(x.shape[1]),
        "REPORT": report,
        **result,
    }

mutants_x_run_job__mutmut['_mutmut_orig'] = x_run_job__mutmut_orig # type: ignore # mutmut generated
mutants_x_run_job__mutmut['x_run_job__mutmut_1'] = x_run_job__mutmut_1 # type: ignore # mutmut generated
mutants_x_run_job__mutmut['x_run_job__mutmut_2'] = x_run_job__mutmut_2 # type: ignore # mutmut generated
mutants_x_run_job__mutmut['x_run_job__mutmut_3'] = x_run_job__mutmut_3 # type: ignore # mutmut generated
mutants_x_run_job__mutmut['x_run_job__mutmut_4'] = x_run_job__mutmut_4 # type: ignore # mutmut generated
mutants_x_run_job__mutmut['x_run_job__mutmut_5'] = x_run_job__mutmut_5 # type: ignore # mutmut generated
mutants_x_run_job__mutmut['x_run_job__mutmut_6'] = x_run_job__mutmut_6 # type: ignore # mutmut generated
mutants_x_run_job__mutmut['x_run_job__mutmut_7'] = x_run_job__mutmut_7 # type: ignore # mutmut generated
mutants_x_run_job__mutmut['x_run_job__mutmut_8'] = x_run_job__mutmut_8 # type: ignore # mutmut generated
mutants_x_run_job__mutmut['x_run_job__mutmut_9'] = x_run_job__mutmut_9 # type: ignore # mutmut generated
mutants_x_run_job__mutmut['x_run_job__mutmut_10'] = x_run_job__mutmut_10 # type: ignore # mutmut generated
mutants_x_run_job__mutmut['x_run_job__mutmut_11'] = x_run_job__mutmut_11 # type: ignore # mutmut generated
mutants_x_run_job__mutmut['x_run_job__mutmut_12'] = x_run_job__mutmut_12 # type: ignore # mutmut generated
mutants_x_run_job__mutmut['x_run_job__mutmut_13'] = x_run_job__mutmut_13 # type: ignore # mutmut generated
mutants_x_run_job__mutmut['x_run_job__mutmut_14'] = x_run_job__mutmut_14 # type: ignore # mutmut generated
mutants_x_run_job__mutmut['x_run_job__mutmut_15'] = x_run_job__mutmut_15 # type: ignore # mutmut generated
mutants_x_run_job__mutmut['x_run_job__mutmut_16'] = x_run_job__mutmut_16 # type: ignore # mutmut generated
mutants_x_run_job__mutmut['x_run_job__mutmut_17'] = x_run_job__mutmut_17 # type: ignore # mutmut generated
mutants_x_run_job__mutmut['x_run_job__mutmut_18'] = x_run_job__mutmut_18 # type: ignore # mutmut generated
mutants_x_run_job__mutmut['x_run_job__mutmut_19'] = x_run_job__mutmut_19 # type: ignore # mutmut generated
mutants_x_run_job__mutmut['x_run_job__mutmut_20'] = x_run_job__mutmut_20 # type: ignore # mutmut generated
mutants_x_run_job__mutmut['x_run_job__mutmut_21'] = x_run_job__mutmut_21 # type: ignore # mutmut generated
mutants_x_run_job__mutmut['x_run_job__mutmut_22'] = x_run_job__mutmut_22 # type: ignore # mutmut generated
mutants_x_run_job__mutmut['x_run_job__mutmut_23'] = x_run_job__mutmut_23 # type: ignore # mutmut generated
mutants_x_run_job__mutmut['x_run_job__mutmut_24'] = x_run_job__mutmut_24 # type: ignore # mutmut generated
mutants_x_run_job__mutmut['x_run_job__mutmut_25'] = x_run_job__mutmut_25 # type: ignore # mutmut generated
mutants_x_run_job__mutmut['x_run_job__mutmut_26'] = x_run_job__mutmut_26 # type: ignore # mutmut generated
mutants_x_run_job__mutmut['x_run_job__mutmut_27'] = x_run_job__mutmut_27 # type: ignore # mutmut generated
mutants_x_run_job__mutmut['x_run_job__mutmut_28'] = x_run_job__mutmut_28 # type: ignore # mutmut generated
mutants_x_run_job__mutmut['x_run_job__mutmut_29'] = x_run_job__mutmut_29 # type: ignore # mutmut generated
mutants_x_run_job__mutmut['x_run_job__mutmut_30'] = x_run_job__mutmut_30 # type: ignore # mutmut generated
mutants_x_run_job__mutmut['x_run_job__mutmut_31'] = x_run_job__mutmut_31 # type: ignore # mutmut generated
mutants_x_run_job__mutmut['x_run_job__mutmut_32'] = x_run_job__mutmut_32 # type: ignore # mutmut generated
mutants_x_run_job__mutmut['x_run_job__mutmut_33'] = x_run_job__mutmut_33 # type: ignore # mutmut generated
mutants_x_run_job__mutmut['x_run_job__mutmut_34'] = x_run_job__mutmut_34 # type: ignore # mutmut generated
mutants_x_run_job__mutmut['x_run_job__mutmut_35'] = x_run_job__mutmut_35 # type: ignore # mutmut generated
mutants_x_run_job__mutmut['x_run_job__mutmut_36'] = x_run_job__mutmut_36 # type: ignore # mutmut generated
mutants_x_run_job__mutmut['x_run_job__mutmut_37'] = x_run_job__mutmut_37 # type: ignore # mutmut generated
mutants_x_run_job__mutmut['x_run_job__mutmut_38'] = x_run_job__mutmut_38 # type: ignore # mutmut generated
mutants_x_run_job__mutmut['x_run_job__mutmut_39'] = x_run_job__mutmut_39 # type: ignore # mutmut generated
mutants_x_run_job__mutmut['x_run_job__mutmut_40'] = x_run_job__mutmut_40 # type: ignore # mutmut generated
mutants_x_run_job__mutmut['x_run_job__mutmut_41'] = x_run_job__mutmut_41 # type: ignore # mutmut generated
mutants_x_run_job__mutmut['x_run_job__mutmut_42'] = x_run_job__mutmut_42 # type: ignore # mutmut generated
mutants_x_run_job__mutmut['x_run_job__mutmut_43'] = x_run_job__mutmut_43 # type: ignore # mutmut generated
mutants_x_run_job__mutmut['x_run_job__mutmut_44'] = x_run_job__mutmut_44 # type: ignore # mutmut generated
mutants_x_run_job__mutmut['x_run_job__mutmut_45'] = x_run_job__mutmut_45 # type: ignore # mutmut generated
mutants_x_run_job__mutmut['x_run_job__mutmut_46'] = x_run_job__mutmut_46 # type: ignore # mutmut generated
mutants_x_run_job__mutmut['x_run_job__mutmut_47'] = x_run_job__mutmut_47 # type: ignore # mutmut generated
mutants_x_run_job__mutmut['x_run_job__mutmut_48'] = x_run_job__mutmut_48 # type: ignore # mutmut generated
mutants_x_run_job__mutmut['x_run_job__mutmut_49'] = x_run_job__mutmut_49 # type: ignore # mutmut generated
mutants_x_run_job__mutmut['x_run_job__mutmut_50'] = x_run_job__mutmut_50 # type: ignore # mutmut generated
mutants_x_run_job__mutmut['x_run_job__mutmut_51'] = x_run_job__mutmut_51 # type: ignore # mutmut generated
mutants_x_run_job__mutmut['x_run_job__mutmut_52'] = x_run_job__mutmut_52 # type: ignore # mutmut generated
mutants_x_run_job__mutmut['x_run_job__mutmut_53'] = x_run_job__mutmut_53 # type: ignore # mutmut generated
mutants_x_run_job__mutmut['x_run_job__mutmut_54'] = x_run_job__mutmut_54 # type: ignore # mutmut generated
mutants_x_run_job__mutmut['x_run_job__mutmut_55'] = x_run_job__mutmut_55 # type: ignore # mutmut generated
mutants_x_run_job__mutmut['x_run_job__mutmut_56'] = x_run_job__mutmut_56 # type: ignore # mutmut generated
mutants_x_run_job__mutmut['x_run_job__mutmut_57'] = x_run_job__mutmut_57 # type: ignore # mutmut generated
mutants_x_run_job__mutmut['x_run_job__mutmut_58'] = x_run_job__mutmut_58 # type: ignore # mutmut generated
mutants_x_run_job__mutmut['x_run_job__mutmut_59'] = x_run_job__mutmut_59 # type: ignore # mutmut generated
mutants_x_run_job__mutmut['x_run_job__mutmut_60'] = x_run_job__mutmut_60 # type: ignore # mutmut generated
mutants_x_run_job__mutmut['x_run_job__mutmut_61'] = x_run_job__mutmut_61 # type: ignore # mutmut generated
mutants_x_run_job__mutmut['x_run_job__mutmut_62'] = x_run_job__mutmut_62 # type: ignore # mutmut generated
mutants_x_run_job__mutmut['x_run_job__mutmut_63'] = x_run_job__mutmut_63 # type: ignore # mutmut generated
mutants_x_run_job__mutmut['x_run_job__mutmut_64'] = x_run_job__mutmut_64 # type: ignore # mutmut generated
mutants_x_run_job__mutmut['x_run_job__mutmut_65'] = x_run_job__mutmut_65 # type: ignore # mutmut generated
mutants_x_run_job__mutmut['x_run_job__mutmut_66'] = x_run_job__mutmut_66 # type: ignore # mutmut generated
mutants_x_run_job__mutmut['x_run_job__mutmut_67'] = x_run_job__mutmut_67 # type: ignore # mutmut generated
mutants_x_run_job__mutmut['x_run_job__mutmut_68'] = x_run_job__mutmut_68 # type: ignore # mutmut generated
mutants_x_run_job__mutmut['x_run_job__mutmut_69'] = x_run_job__mutmut_69 # type: ignore # mutmut generated
mutants_x_run_job__mutmut['x_run_job__mutmut_70'] = x_run_job__mutmut_70 # type: ignore # mutmut generated
mutants_x_jobs__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_jobs__mutmut)
def jobs(registry: Path, adbench: Path, pool: Path) -> list[dict[str, Any]]:
    files = {t["name"]: t["file"] for t in dr.ADBENCH_TABULAR}
    out = [
        {
            "problem": f"adbench:{name}",
            "source": "adbench",
            "name": name,
            "path": str(adbench / files[name]),
        }
        for name in sorted(json.loads((registry / "adbench_normalisation_report.json").read_text()))
    ]
    curated = {
        m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]
    }
    for row in json.loads((registry / "uci_pool.json").read_text())["rows"]:
        if "labelled" in row["roles"]:
            out.append(
                {
                    "problem": f"uci:{row['uci_id']}",
                    "source": "uci",
                    "meta": curated[row["uci_id"]],
                    "path": str(pool / f"{row['uci_id']}.csv"),
                }
            )
    return out


def x_jobs__mutmut_orig(registry: Path, adbench: Path, pool: Path) -> list[dict[str, Any]]:
    files = {t["name"]: t["file"] for t in dr.ADBENCH_TABULAR}
    out = [
        {
            "problem": f"adbench:{name}",
            "source": "adbench",
            "name": name,
            "path": str(adbench / files[name]),
        }
        for name in sorted(json.loads((registry / "adbench_normalisation_report.json").read_text()))
    ]
    curated = {
        m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]
    }
    for row in json.loads((registry / "uci_pool.json").read_text())["rows"]:
        if "labelled" in row["roles"]:
            out.append(
                {
                    "problem": f"uci:{row['uci_id']}",
                    "source": "uci",
                    "meta": curated[row["uci_id"]],
                    "path": str(pool / f"{row['uci_id']}.csv"),
                }
            )
    return out


def x_jobs__mutmut_1(registry: Path, adbench: Path, pool: Path) -> list[dict[str, Any]]:
    files = None
    out = [
        {
            "problem": f"adbench:{name}",
            "source": "adbench",
            "name": name,
            "path": str(adbench / files[name]),
        }
        for name in sorted(json.loads((registry / "adbench_normalisation_report.json").read_text()))
    ]
    curated = {
        m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]
    }
    for row in json.loads((registry / "uci_pool.json").read_text())["rows"]:
        if "labelled" in row["roles"]:
            out.append(
                {
                    "problem": f"uci:{row['uci_id']}",
                    "source": "uci",
                    "meta": curated[row["uci_id"]],
                    "path": str(pool / f"{row['uci_id']}.csv"),
                }
            )
    return out


def x_jobs__mutmut_2(registry: Path, adbench: Path, pool: Path) -> list[dict[str, Any]]:
    files = {t["XXnameXX"]: t["file"] for t in dr.ADBENCH_TABULAR}
    out = [
        {
            "problem": f"adbench:{name}",
            "source": "adbench",
            "name": name,
            "path": str(adbench / files[name]),
        }
        for name in sorted(json.loads((registry / "adbench_normalisation_report.json").read_text()))
    ]
    curated = {
        m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]
    }
    for row in json.loads((registry / "uci_pool.json").read_text())["rows"]:
        if "labelled" in row["roles"]:
            out.append(
                {
                    "problem": f"uci:{row['uci_id']}",
                    "source": "uci",
                    "meta": curated[row["uci_id"]],
                    "path": str(pool / f"{row['uci_id']}.csv"),
                }
            )
    return out


def x_jobs__mutmut_3(registry: Path, adbench: Path, pool: Path) -> list[dict[str, Any]]:
    files = {t["NAME"]: t["file"] for t in dr.ADBENCH_TABULAR}
    out = [
        {
            "problem": f"adbench:{name}",
            "source": "adbench",
            "name": name,
            "path": str(adbench / files[name]),
        }
        for name in sorted(json.loads((registry / "adbench_normalisation_report.json").read_text()))
    ]
    curated = {
        m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]
    }
    for row in json.loads((registry / "uci_pool.json").read_text())["rows"]:
        if "labelled" in row["roles"]:
            out.append(
                {
                    "problem": f"uci:{row['uci_id']}",
                    "source": "uci",
                    "meta": curated[row["uci_id"]],
                    "path": str(pool / f"{row['uci_id']}.csv"),
                }
            )
    return out


def x_jobs__mutmut_4(registry: Path, adbench: Path, pool: Path) -> list[dict[str, Any]]:
    files = {t["name"]: t["XXfileXX"] for t in dr.ADBENCH_TABULAR}
    out = [
        {
            "problem": f"adbench:{name}",
            "source": "adbench",
            "name": name,
            "path": str(adbench / files[name]),
        }
        for name in sorted(json.loads((registry / "adbench_normalisation_report.json").read_text()))
    ]
    curated = {
        m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]
    }
    for row in json.loads((registry / "uci_pool.json").read_text())["rows"]:
        if "labelled" in row["roles"]:
            out.append(
                {
                    "problem": f"uci:{row['uci_id']}",
                    "source": "uci",
                    "meta": curated[row["uci_id"]],
                    "path": str(pool / f"{row['uci_id']}.csv"),
                }
            )
    return out


def x_jobs__mutmut_5(registry: Path, adbench: Path, pool: Path) -> list[dict[str, Any]]:
    files = {t["name"]: t["FILE"] for t in dr.ADBENCH_TABULAR}
    out = [
        {
            "problem": f"adbench:{name}",
            "source": "adbench",
            "name": name,
            "path": str(adbench / files[name]),
        }
        for name in sorted(json.loads((registry / "adbench_normalisation_report.json").read_text()))
    ]
    curated = {
        m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]
    }
    for row in json.loads((registry / "uci_pool.json").read_text())["rows"]:
        if "labelled" in row["roles"]:
            out.append(
                {
                    "problem": f"uci:{row['uci_id']}",
                    "source": "uci",
                    "meta": curated[row["uci_id"]],
                    "path": str(pool / f"{row['uci_id']}.csv"),
                }
            )
    return out


def x_jobs__mutmut_6(registry: Path, adbench: Path, pool: Path) -> list[dict[str, Any]]:
    files = {t["name"]: t["file"] for t in dr.ADBENCH_TABULAR}
    out = None
    curated = {
        m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]
    }
    for row in json.loads((registry / "uci_pool.json").read_text())["rows"]:
        if "labelled" in row["roles"]:
            out.append(
                {
                    "problem": f"uci:{row['uci_id']}",
                    "source": "uci",
                    "meta": curated[row["uci_id"]],
                    "path": str(pool / f"{row['uci_id']}.csv"),
                }
            )
    return out


def x_jobs__mutmut_7(registry: Path, adbench: Path, pool: Path) -> list[dict[str, Any]]:
    files = {t["name"]: t["file"] for t in dr.ADBENCH_TABULAR}
    out = [
        {
            "XXproblemXX": f"adbench:{name}",
            "source": "adbench",
            "name": name,
            "path": str(adbench / files[name]),
        }
        for name in sorted(json.loads((registry / "adbench_normalisation_report.json").read_text()))
    ]
    curated = {
        m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]
    }
    for row in json.loads((registry / "uci_pool.json").read_text())["rows"]:
        if "labelled" in row["roles"]:
            out.append(
                {
                    "problem": f"uci:{row['uci_id']}",
                    "source": "uci",
                    "meta": curated[row["uci_id"]],
                    "path": str(pool / f"{row['uci_id']}.csv"),
                }
            )
    return out


def x_jobs__mutmut_8(registry: Path, adbench: Path, pool: Path) -> list[dict[str, Any]]:
    files = {t["name"]: t["file"] for t in dr.ADBENCH_TABULAR}
    out = [
        {
            "PROBLEM": f"adbench:{name}",
            "source": "adbench",
            "name": name,
            "path": str(adbench / files[name]),
        }
        for name in sorted(json.loads((registry / "adbench_normalisation_report.json").read_text()))
    ]
    curated = {
        m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]
    }
    for row in json.loads((registry / "uci_pool.json").read_text())["rows"]:
        if "labelled" in row["roles"]:
            out.append(
                {
                    "problem": f"uci:{row['uci_id']}",
                    "source": "uci",
                    "meta": curated[row["uci_id"]],
                    "path": str(pool / f"{row['uci_id']}.csv"),
                }
            )
    return out


def x_jobs__mutmut_9(registry: Path, adbench: Path, pool: Path) -> list[dict[str, Any]]:
    files = {t["name"]: t["file"] for t in dr.ADBENCH_TABULAR}
    out = [
        {
            "problem": f"adbench:{name}",
            "XXsourceXX": "adbench",
            "name": name,
            "path": str(adbench / files[name]),
        }
        for name in sorted(json.loads((registry / "adbench_normalisation_report.json").read_text()))
    ]
    curated = {
        m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]
    }
    for row in json.loads((registry / "uci_pool.json").read_text())["rows"]:
        if "labelled" in row["roles"]:
            out.append(
                {
                    "problem": f"uci:{row['uci_id']}",
                    "source": "uci",
                    "meta": curated[row["uci_id"]],
                    "path": str(pool / f"{row['uci_id']}.csv"),
                }
            )
    return out


def x_jobs__mutmut_10(registry: Path, adbench: Path, pool: Path) -> list[dict[str, Any]]:
    files = {t["name"]: t["file"] for t in dr.ADBENCH_TABULAR}
    out = [
        {
            "problem": f"adbench:{name}",
            "SOURCE": "adbench",
            "name": name,
            "path": str(adbench / files[name]),
        }
        for name in sorted(json.loads((registry / "adbench_normalisation_report.json").read_text()))
    ]
    curated = {
        m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]
    }
    for row in json.loads((registry / "uci_pool.json").read_text())["rows"]:
        if "labelled" in row["roles"]:
            out.append(
                {
                    "problem": f"uci:{row['uci_id']}",
                    "source": "uci",
                    "meta": curated[row["uci_id"]],
                    "path": str(pool / f"{row['uci_id']}.csv"),
                }
            )
    return out


def x_jobs__mutmut_11(registry: Path, adbench: Path, pool: Path) -> list[dict[str, Any]]:
    files = {t["name"]: t["file"] for t in dr.ADBENCH_TABULAR}
    out = [
        {
            "problem": f"adbench:{name}",
            "source": "XXadbenchXX",
            "name": name,
            "path": str(adbench / files[name]),
        }
        for name in sorted(json.loads((registry / "adbench_normalisation_report.json").read_text()))
    ]
    curated = {
        m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]
    }
    for row in json.loads((registry / "uci_pool.json").read_text())["rows"]:
        if "labelled" in row["roles"]:
            out.append(
                {
                    "problem": f"uci:{row['uci_id']}",
                    "source": "uci",
                    "meta": curated[row["uci_id"]],
                    "path": str(pool / f"{row['uci_id']}.csv"),
                }
            )
    return out


def x_jobs__mutmut_12(registry: Path, adbench: Path, pool: Path) -> list[dict[str, Any]]:
    files = {t["name"]: t["file"] for t in dr.ADBENCH_TABULAR}
    out = [
        {
            "problem": f"adbench:{name}",
            "source": "ADBENCH",
            "name": name,
            "path": str(adbench / files[name]),
        }
        for name in sorted(json.loads((registry / "adbench_normalisation_report.json").read_text()))
    ]
    curated = {
        m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]
    }
    for row in json.loads((registry / "uci_pool.json").read_text())["rows"]:
        if "labelled" in row["roles"]:
            out.append(
                {
                    "problem": f"uci:{row['uci_id']}",
                    "source": "uci",
                    "meta": curated[row["uci_id"]],
                    "path": str(pool / f"{row['uci_id']}.csv"),
                }
            )
    return out


def x_jobs__mutmut_13(registry: Path, adbench: Path, pool: Path) -> list[dict[str, Any]]:
    files = {t["name"]: t["file"] for t in dr.ADBENCH_TABULAR}
    out = [
        {
            "problem": f"adbench:{name}",
            "source": "adbench",
            "XXnameXX": name,
            "path": str(adbench / files[name]),
        }
        for name in sorted(json.loads((registry / "adbench_normalisation_report.json").read_text()))
    ]
    curated = {
        m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]
    }
    for row in json.loads((registry / "uci_pool.json").read_text())["rows"]:
        if "labelled" in row["roles"]:
            out.append(
                {
                    "problem": f"uci:{row['uci_id']}",
                    "source": "uci",
                    "meta": curated[row["uci_id"]],
                    "path": str(pool / f"{row['uci_id']}.csv"),
                }
            )
    return out


def x_jobs__mutmut_14(registry: Path, adbench: Path, pool: Path) -> list[dict[str, Any]]:
    files = {t["name"]: t["file"] for t in dr.ADBENCH_TABULAR}
    out = [
        {
            "problem": f"adbench:{name}",
            "source": "adbench",
            "NAME": name,
            "path": str(adbench / files[name]),
        }
        for name in sorted(json.loads((registry / "adbench_normalisation_report.json").read_text()))
    ]
    curated = {
        m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]
    }
    for row in json.loads((registry / "uci_pool.json").read_text())["rows"]:
        if "labelled" in row["roles"]:
            out.append(
                {
                    "problem": f"uci:{row['uci_id']}",
                    "source": "uci",
                    "meta": curated[row["uci_id"]],
                    "path": str(pool / f"{row['uci_id']}.csv"),
                }
            )
    return out


def x_jobs__mutmut_15(registry: Path, adbench: Path, pool: Path) -> list[dict[str, Any]]:
    files = {t["name"]: t["file"] for t in dr.ADBENCH_TABULAR}
    out = [
        {
            "problem": f"adbench:{name}",
            "source": "adbench",
            "name": name,
            "XXpathXX": str(adbench / files[name]),
        }
        for name in sorted(json.loads((registry / "adbench_normalisation_report.json").read_text()))
    ]
    curated = {
        m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]
    }
    for row in json.loads((registry / "uci_pool.json").read_text())["rows"]:
        if "labelled" in row["roles"]:
            out.append(
                {
                    "problem": f"uci:{row['uci_id']}",
                    "source": "uci",
                    "meta": curated[row["uci_id"]],
                    "path": str(pool / f"{row['uci_id']}.csv"),
                }
            )
    return out


def x_jobs__mutmut_16(registry: Path, adbench: Path, pool: Path) -> list[dict[str, Any]]:
    files = {t["name"]: t["file"] for t in dr.ADBENCH_TABULAR}
    out = [
        {
            "problem": f"adbench:{name}",
            "source": "adbench",
            "name": name,
            "PATH": str(adbench / files[name]),
        }
        for name in sorted(json.loads((registry / "adbench_normalisation_report.json").read_text()))
    ]
    curated = {
        m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]
    }
    for row in json.loads((registry / "uci_pool.json").read_text())["rows"]:
        if "labelled" in row["roles"]:
            out.append(
                {
                    "problem": f"uci:{row['uci_id']}",
                    "source": "uci",
                    "meta": curated[row["uci_id"]],
                    "path": str(pool / f"{row['uci_id']}.csv"),
                }
            )
    return out


def x_jobs__mutmut_17(registry: Path, adbench: Path, pool: Path) -> list[dict[str, Any]]:
    files = {t["name"]: t["file"] for t in dr.ADBENCH_TABULAR}
    out = [
        {
            "problem": f"adbench:{name}",
            "source": "adbench",
            "name": name,
            "path": str(None),
        }
        for name in sorted(json.loads((registry / "adbench_normalisation_report.json").read_text()))
    ]
    curated = {
        m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]
    }
    for row in json.loads((registry / "uci_pool.json").read_text())["rows"]:
        if "labelled" in row["roles"]:
            out.append(
                {
                    "problem": f"uci:{row['uci_id']}",
                    "source": "uci",
                    "meta": curated[row["uci_id"]],
                    "path": str(pool / f"{row['uci_id']}.csv"),
                }
            )
    return out


def x_jobs__mutmut_18(registry: Path, adbench: Path, pool: Path) -> list[dict[str, Any]]:
    files = {t["name"]: t["file"] for t in dr.ADBENCH_TABULAR}
    out = [
        {
            "problem": f"adbench:{name}",
            "source": "adbench",
            "name": name,
            "path": str(adbench * files[name]),
        }
        for name in sorted(json.loads((registry / "adbench_normalisation_report.json").read_text()))
    ]
    curated = {
        m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]
    }
    for row in json.loads((registry / "uci_pool.json").read_text())["rows"]:
        if "labelled" in row["roles"]:
            out.append(
                {
                    "problem": f"uci:{row['uci_id']}",
                    "source": "uci",
                    "meta": curated[row["uci_id"]],
                    "path": str(pool / f"{row['uci_id']}.csv"),
                }
            )
    return out


def x_jobs__mutmut_19(registry: Path, adbench: Path, pool: Path) -> list[dict[str, Any]]:
    files = {t["name"]: t["file"] for t in dr.ADBENCH_TABULAR}
    out = [
        {
            "problem": f"adbench:{name}",
            "source": "adbench",
            "name": name,
            "path": str(adbench / files[name]),
        }
        for name in sorted(None)
    ]
    curated = {
        m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]
    }
    for row in json.loads((registry / "uci_pool.json").read_text())["rows"]:
        if "labelled" in row["roles"]:
            out.append(
                {
                    "problem": f"uci:{row['uci_id']}",
                    "source": "uci",
                    "meta": curated[row["uci_id"]],
                    "path": str(pool / f"{row['uci_id']}.csv"),
                }
            )
    return out


def x_jobs__mutmut_20(registry: Path, adbench: Path, pool: Path) -> list[dict[str, Any]]:
    files = {t["name"]: t["file"] for t in dr.ADBENCH_TABULAR}
    out = [
        {
            "problem": f"adbench:{name}",
            "source": "adbench",
            "name": name,
            "path": str(adbench / files[name]),
        }
        for name in sorted(json.loads(None))
    ]
    curated = {
        m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]
    }
    for row in json.loads((registry / "uci_pool.json").read_text())["rows"]:
        if "labelled" in row["roles"]:
            out.append(
                {
                    "problem": f"uci:{row['uci_id']}",
                    "source": "uci",
                    "meta": curated[row["uci_id"]],
                    "path": str(pool / f"{row['uci_id']}.csv"),
                }
            )
    return out


def x_jobs__mutmut_21(registry: Path, adbench: Path, pool: Path) -> list[dict[str, Any]]:
    files = {t["name"]: t["file"] for t in dr.ADBENCH_TABULAR}
    out = [
        {
            "problem": f"adbench:{name}",
            "source": "adbench",
            "name": name,
            "path": str(adbench / files[name]),
        }
        for name in sorted(json.loads((registry * "adbench_normalisation_report.json").read_text()))
    ]
    curated = {
        m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]
    }
    for row in json.loads((registry / "uci_pool.json").read_text())["rows"]:
        if "labelled" in row["roles"]:
            out.append(
                {
                    "problem": f"uci:{row['uci_id']}",
                    "source": "uci",
                    "meta": curated[row["uci_id"]],
                    "path": str(pool / f"{row['uci_id']}.csv"),
                }
            )
    return out


def x_jobs__mutmut_22(registry: Path, adbench: Path, pool: Path) -> list[dict[str, Any]]:
    files = {t["name"]: t["file"] for t in dr.ADBENCH_TABULAR}
    out = [
        {
            "problem": f"adbench:{name}",
            "source": "adbench",
            "name": name,
            "path": str(adbench / files[name]),
        }
        for name in sorted(json.loads((registry / "XXadbench_normalisation_report.jsonXX").read_text()))
    ]
    curated = {
        m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]
    }
    for row in json.loads((registry / "uci_pool.json").read_text())["rows"]:
        if "labelled" in row["roles"]:
            out.append(
                {
                    "problem": f"uci:{row['uci_id']}",
                    "source": "uci",
                    "meta": curated[row["uci_id"]],
                    "path": str(pool / f"{row['uci_id']}.csv"),
                }
            )
    return out


def x_jobs__mutmut_23(registry: Path, adbench: Path, pool: Path) -> list[dict[str, Any]]:
    files = {t["name"]: t["file"] for t in dr.ADBENCH_TABULAR}
    out = [
        {
            "problem": f"adbench:{name}",
            "source": "adbench",
            "name": name,
            "path": str(adbench / files[name]),
        }
        for name in sorted(json.loads((registry / "ADBENCH_NORMALISATION_REPORT.JSON").read_text()))
    ]
    curated = {
        m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]
    }
    for row in json.loads((registry / "uci_pool.json").read_text())["rows"]:
        if "labelled" in row["roles"]:
            out.append(
                {
                    "problem": f"uci:{row['uci_id']}",
                    "source": "uci",
                    "meta": curated[row["uci_id"]],
                    "path": str(pool / f"{row['uci_id']}.csv"),
                }
            )
    return out


def x_jobs__mutmut_24(registry: Path, adbench: Path, pool: Path) -> list[dict[str, Any]]:
    files = {t["name"]: t["file"] for t in dr.ADBENCH_TABULAR}
    out = [
        {
            "problem": f"adbench:{name}",
            "source": "adbench",
            "name": name,
            "path": str(adbench / files[name]),
        }
        for name in sorted(json.loads((registry / "adbench_normalisation_report.json").read_text()))
    ]
    curated = None
    for row in json.loads((registry / "uci_pool.json").read_text())["rows"]:
        if "labelled" in row["roles"]:
            out.append(
                {
                    "problem": f"uci:{row['uci_id']}",
                    "source": "uci",
                    "meta": curated[row["uci_id"]],
                    "path": str(pool / f"{row['uci_id']}.csv"),
                }
            )
    return out


def x_jobs__mutmut_25(registry: Path, adbench: Path, pool: Path) -> list[dict[str, Any]]:
    files = {t["name"]: t["file"] for t in dr.ADBENCH_TABULAR}
    out = [
        {
            "problem": f"adbench:{name}",
            "source": "adbench",
            "name": name,
            "path": str(adbench / files[name]),
        }
        for name in sorted(json.loads((registry / "adbench_normalisation_report.json").read_text()))
    ]
    curated = {
        m["XXuci_idXX"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]
    }
    for row in json.loads((registry / "uci_pool.json").read_text())["rows"]:
        if "labelled" in row["roles"]:
            out.append(
                {
                    "problem": f"uci:{row['uci_id']}",
                    "source": "uci",
                    "meta": curated[row["uci_id"]],
                    "path": str(pool / f"{row['uci_id']}.csv"),
                }
            )
    return out


def x_jobs__mutmut_26(registry: Path, adbench: Path, pool: Path) -> list[dict[str, Any]]:
    files = {t["name"]: t["file"] for t in dr.ADBENCH_TABULAR}
    out = [
        {
            "problem": f"adbench:{name}",
            "source": "adbench",
            "name": name,
            "path": str(adbench / files[name]),
        }
        for name in sorted(json.loads((registry / "adbench_normalisation_report.json").read_text()))
    ]
    curated = {
        m["UCI_ID"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]
    }
    for row in json.loads((registry / "uci_pool.json").read_text())["rows"]:
        if "labelled" in row["roles"]:
            out.append(
                {
                    "problem": f"uci:{row['uci_id']}",
                    "source": "uci",
                    "meta": curated[row["uci_id"]],
                    "path": str(pool / f"{row['uci_id']}.csv"),
                }
            )
    return out


def x_jobs__mutmut_27(registry: Path, adbench: Path, pool: Path) -> list[dict[str, Any]]:
    files = {t["name"]: t["file"] for t in dr.ADBENCH_TABULAR}
    out = [
        {
            "problem": f"adbench:{name}",
            "source": "adbench",
            "name": name,
            "path": str(adbench / files[name]),
        }
        for name in sorted(json.loads((registry / "adbench_normalisation_report.json").read_text()))
    ]
    curated = {
        m["uci_id"]: m for m in json.loads(None)["kept"]
    }
    for row in json.loads((registry / "uci_pool.json").read_text())["rows"]:
        if "labelled" in row["roles"]:
            out.append(
                {
                    "problem": f"uci:{row['uci_id']}",
                    "source": "uci",
                    "meta": curated[row["uci_id"]],
                    "path": str(pool / f"{row['uci_id']}.csv"),
                }
            )
    return out


def x_jobs__mutmut_28(registry: Path, adbench: Path, pool: Path) -> list[dict[str, Any]]:
    files = {t["name"]: t["file"] for t in dr.ADBENCH_TABULAR}
    out = [
        {
            "problem": f"adbench:{name}",
            "source": "adbench",
            "name": name,
            "path": str(adbench / files[name]),
        }
        for name in sorted(json.loads((registry / "adbench_normalisation_report.json").read_text()))
    ]
    curated = {
        m["uci_id"]: m for m in json.loads((registry * "uci_curated.json").read_text())["kept"]
    }
    for row in json.loads((registry / "uci_pool.json").read_text())["rows"]:
        if "labelled" in row["roles"]:
            out.append(
                {
                    "problem": f"uci:{row['uci_id']}",
                    "source": "uci",
                    "meta": curated[row["uci_id"]],
                    "path": str(pool / f"{row['uci_id']}.csv"),
                }
            )
    return out


def x_jobs__mutmut_29(registry: Path, adbench: Path, pool: Path) -> list[dict[str, Any]]:
    files = {t["name"]: t["file"] for t in dr.ADBENCH_TABULAR}
    out = [
        {
            "problem": f"adbench:{name}",
            "source": "adbench",
            "name": name,
            "path": str(adbench / files[name]),
        }
        for name in sorted(json.loads((registry / "adbench_normalisation_report.json").read_text()))
    ]
    curated = {
        m["uci_id"]: m for m in json.loads((registry / "XXuci_curated.jsonXX").read_text())["kept"]
    }
    for row in json.loads((registry / "uci_pool.json").read_text())["rows"]:
        if "labelled" in row["roles"]:
            out.append(
                {
                    "problem": f"uci:{row['uci_id']}",
                    "source": "uci",
                    "meta": curated[row["uci_id"]],
                    "path": str(pool / f"{row['uci_id']}.csv"),
                }
            )
    return out


def x_jobs__mutmut_30(registry: Path, adbench: Path, pool: Path) -> list[dict[str, Any]]:
    files = {t["name"]: t["file"] for t in dr.ADBENCH_TABULAR}
    out = [
        {
            "problem": f"adbench:{name}",
            "source": "adbench",
            "name": name,
            "path": str(adbench / files[name]),
        }
        for name in sorted(json.loads((registry / "adbench_normalisation_report.json").read_text()))
    ]
    curated = {
        m["uci_id"]: m for m in json.loads((registry / "UCI_CURATED.JSON").read_text())["kept"]
    }
    for row in json.loads((registry / "uci_pool.json").read_text())["rows"]:
        if "labelled" in row["roles"]:
            out.append(
                {
                    "problem": f"uci:{row['uci_id']}",
                    "source": "uci",
                    "meta": curated[row["uci_id"]],
                    "path": str(pool / f"{row['uci_id']}.csv"),
                }
            )
    return out


def x_jobs__mutmut_31(registry: Path, adbench: Path, pool: Path) -> list[dict[str, Any]]:
    files = {t["name"]: t["file"] for t in dr.ADBENCH_TABULAR}
    out = [
        {
            "problem": f"adbench:{name}",
            "source": "adbench",
            "name": name,
            "path": str(adbench / files[name]),
        }
        for name in sorted(json.loads((registry / "adbench_normalisation_report.json").read_text()))
    ]
    curated = {
        m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["XXkeptXX"]
    }
    for row in json.loads((registry / "uci_pool.json").read_text())["rows"]:
        if "labelled" in row["roles"]:
            out.append(
                {
                    "problem": f"uci:{row['uci_id']}",
                    "source": "uci",
                    "meta": curated[row["uci_id"]],
                    "path": str(pool / f"{row['uci_id']}.csv"),
                }
            )
    return out


def x_jobs__mutmut_32(registry: Path, adbench: Path, pool: Path) -> list[dict[str, Any]]:
    files = {t["name"]: t["file"] for t in dr.ADBENCH_TABULAR}
    out = [
        {
            "problem": f"adbench:{name}",
            "source": "adbench",
            "name": name,
            "path": str(adbench / files[name]),
        }
        for name in sorted(json.loads((registry / "adbench_normalisation_report.json").read_text()))
    ]
    curated = {
        m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["KEPT"]
    }
    for row in json.loads((registry / "uci_pool.json").read_text())["rows"]:
        if "labelled" in row["roles"]:
            out.append(
                {
                    "problem": f"uci:{row['uci_id']}",
                    "source": "uci",
                    "meta": curated[row["uci_id"]],
                    "path": str(pool / f"{row['uci_id']}.csv"),
                }
            )
    return out


def x_jobs__mutmut_33(registry: Path, adbench: Path, pool: Path) -> list[dict[str, Any]]:
    files = {t["name"]: t["file"] for t in dr.ADBENCH_TABULAR}
    out = [
        {
            "problem": f"adbench:{name}",
            "source": "adbench",
            "name": name,
            "path": str(adbench / files[name]),
        }
        for name in sorted(json.loads((registry / "adbench_normalisation_report.json").read_text()))
    ]
    curated = {
        m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]
    }
    for row in json.loads(None)["rows"]:
        if "labelled" in row["roles"]:
            out.append(
                {
                    "problem": f"uci:{row['uci_id']}",
                    "source": "uci",
                    "meta": curated[row["uci_id"]],
                    "path": str(pool / f"{row['uci_id']}.csv"),
                }
            )
    return out


def x_jobs__mutmut_34(registry: Path, adbench: Path, pool: Path) -> list[dict[str, Any]]:
    files = {t["name"]: t["file"] for t in dr.ADBENCH_TABULAR}
    out = [
        {
            "problem": f"adbench:{name}",
            "source": "adbench",
            "name": name,
            "path": str(adbench / files[name]),
        }
        for name in sorted(json.loads((registry / "adbench_normalisation_report.json").read_text()))
    ]
    curated = {
        m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]
    }
    for row in json.loads((registry * "uci_pool.json").read_text())["rows"]:
        if "labelled" in row["roles"]:
            out.append(
                {
                    "problem": f"uci:{row['uci_id']}",
                    "source": "uci",
                    "meta": curated[row["uci_id"]],
                    "path": str(pool / f"{row['uci_id']}.csv"),
                }
            )
    return out


def x_jobs__mutmut_35(registry: Path, adbench: Path, pool: Path) -> list[dict[str, Any]]:
    files = {t["name"]: t["file"] for t in dr.ADBENCH_TABULAR}
    out = [
        {
            "problem": f"adbench:{name}",
            "source": "adbench",
            "name": name,
            "path": str(adbench / files[name]),
        }
        for name in sorted(json.loads((registry / "adbench_normalisation_report.json").read_text()))
    ]
    curated = {
        m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]
    }
    for row in json.loads((registry / "XXuci_pool.jsonXX").read_text())["rows"]:
        if "labelled" in row["roles"]:
            out.append(
                {
                    "problem": f"uci:{row['uci_id']}",
                    "source": "uci",
                    "meta": curated[row["uci_id"]],
                    "path": str(pool / f"{row['uci_id']}.csv"),
                }
            )
    return out


def x_jobs__mutmut_36(registry: Path, adbench: Path, pool: Path) -> list[dict[str, Any]]:
    files = {t["name"]: t["file"] for t in dr.ADBENCH_TABULAR}
    out = [
        {
            "problem": f"adbench:{name}",
            "source": "adbench",
            "name": name,
            "path": str(adbench / files[name]),
        }
        for name in sorted(json.loads((registry / "adbench_normalisation_report.json").read_text()))
    ]
    curated = {
        m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]
    }
    for row in json.loads((registry / "UCI_POOL.JSON").read_text())["rows"]:
        if "labelled" in row["roles"]:
            out.append(
                {
                    "problem": f"uci:{row['uci_id']}",
                    "source": "uci",
                    "meta": curated[row["uci_id"]],
                    "path": str(pool / f"{row['uci_id']}.csv"),
                }
            )
    return out


def x_jobs__mutmut_37(registry: Path, adbench: Path, pool: Path) -> list[dict[str, Any]]:
    files = {t["name"]: t["file"] for t in dr.ADBENCH_TABULAR}
    out = [
        {
            "problem": f"adbench:{name}",
            "source": "adbench",
            "name": name,
            "path": str(adbench / files[name]),
        }
        for name in sorted(json.loads((registry / "adbench_normalisation_report.json").read_text()))
    ]
    curated = {
        m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]
    }
    for row in json.loads((registry / "uci_pool.json").read_text())["XXrowsXX"]:
        if "labelled" in row["roles"]:
            out.append(
                {
                    "problem": f"uci:{row['uci_id']}",
                    "source": "uci",
                    "meta": curated[row["uci_id"]],
                    "path": str(pool / f"{row['uci_id']}.csv"),
                }
            )
    return out


def x_jobs__mutmut_38(registry: Path, adbench: Path, pool: Path) -> list[dict[str, Any]]:
    files = {t["name"]: t["file"] for t in dr.ADBENCH_TABULAR}
    out = [
        {
            "problem": f"adbench:{name}",
            "source": "adbench",
            "name": name,
            "path": str(adbench / files[name]),
        }
        for name in sorted(json.loads((registry / "adbench_normalisation_report.json").read_text()))
    ]
    curated = {
        m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]
    }
    for row in json.loads((registry / "uci_pool.json").read_text())["ROWS"]:
        if "labelled" in row["roles"]:
            out.append(
                {
                    "problem": f"uci:{row['uci_id']}",
                    "source": "uci",
                    "meta": curated[row["uci_id"]],
                    "path": str(pool / f"{row['uci_id']}.csv"),
                }
            )
    return out


def x_jobs__mutmut_39(registry: Path, adbench: Path, pool: Path) -> list[dict[str, Any]]:
    files = {t["name"]: t["file"] for t in dr.ADBENCH_TABULAR}
    out = [
        {
            "problem": f"adbench:{name}",
            "source": "adbench",
            "name": name,
            "path": str(adbench / files[name]),
        }
        for name in sorted(json.loads((registry / "adbench_normalisation_report.json").read_text()))
    ]
    curated = {
        m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]
    }
    for row in json.loads((registry / "uci_pool.json").read_text())["rows"]:
        if "XXlabelledXX" in row["roles"]:
            out.append(
                {
                    "problem": f"uci:{row['uci_id']}",
                    "source": "uci",
                    "meta": curated[row["uci_id"]],
                    "path": str(pool / f"{row['uci_id']}.csv"),
                }
            )
    return out


def x_jobs__mutmut_40(registry: Path, adbench: Path, pool: Path) -> list[dict[str, Any]]:
    files = {t["name"]: t["file"] for t in dr.ADBENCH_TABULAR}
    out = [
        {
            "problem": f"adbench:{name}",
            "source": "adbench",
            "name": name,
            "path": str(adbench / files[name]),
        }
        for name in sorted(json.loads((registry / "adbench_normalisation_report.json").read_text()))
    ]
    curated = {
        m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]
    }
    for row in json.loads((registry / "uci_pool.json").read_text())["rows"]:
        if "LABELLED" in row["roles"]:
            out.append(
                {
                    "problem": f"uci:{row['uci_id']}",
                    "source": "uci",
                    "meta": curated[row["uci_id"]],
                    "path": str(pool / f"{row['uci_id']}.csv"),
                }
            )
    return out


def x_jobs__mutmut_41(registry: Path, adbench: Path, pool: Path) -> list[dict[str, Any]]:
    files = {t["name"]: t["file"] for t in dr.ADBENCH_TABULAR}
    out = [
        {
            "problem": f"adbench:{name}",
            "source": "adbench",
            "name": name,
            "path": str(adbench / files[name]),
        }
        for name in sorted(json.loads((registry / "adbench_normalisation_report.json").read_text()))
    ]
    curated = {
        m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]
    }
    for row in json.loads((registry / "uci_pool.json").read_text())["rows"]:
        if "labelled" not in row["roles"]:
            out.append(
                {
                    "problem": f"uci:{row['uci_id']}",
                    "source": "uci",
                    "meta": curated[row["uci_id"]],
                    "path": str(pool / f"{row['uci_id']}.csv"),
                }
            )
    return out


def x_jobs__mutmut_42(registry: Path, adbench: Path, pool: Path) -> list[dict[str, Any]]:
    files = {t["name"]: t["file"] for t in dr.ADBENCH_TABULAR}
    out = [
        {
            "problem": f"adbench:{name}",
            "source": "adbench",
            "name": name,
            "path": str(adbench / files[name]),
        }
        for name in sorted(json.loads((registry / "adbench_normalisation_report.json").read_text()))
    ]
    curated = {
        m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]
    }
    for row in json.loads((registry / "uci_pool.json").read_text())["rows"]:
        if "labelled" in row["XXrolesXX"]:
            out.append(
                {
                    "problem": f"uci:{row['uci_id']}",
                    "source": "uci",
                    "meta": curated[row["uci_id"]],
                    "path": str(pool / f"{row['uci_id']}.csv"),
                }
            )
    return out


def x_jobs__mutmut_43(registry: Path, adbench: Path, pool: Path) -> list[dict[str, Any]]:
    files = {t["name"]: t["file"] for t in dr.ADBENCH_TABULAR}
    out = [
        {
            "problem": f"adbench:{name}",
            "source": "adbench",
            "name": name,
            "path": str(adbench / files[name]),
        }
        for name in sorted(json.loads((registry / "adbench_normalisation_report.json").read_text()))
    ]
    curated = {
        m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]
    }
    for row in json.loads((registry / "uci_pool.json").read_text())["rows"]:
        if "labelled" in row["ROLES"]:
            out.append(
                {
                    "problem": f"uci:{row['uci_id']}",
                    "source": "uci",
                    "meta": curated[row["uci_id"]],
                    "path": str(pool / f"{row['uci_id']}.csv"),
                }
            )
    return out


def x_jobs__mutmut_44(registry: Path, adbench: Path, pool: Path) -> list[dict[str, Any]]:
    files = {t["name"]: t["file"] for t in dr.ADBENCH_TABULAR}
    out = [
        {
            "problem": f"adbench:{name}",
            "source": "adbench",
            "name": name,
            "path": str(adbench / files[name]),
        }
        for name in sorted(json.loads((registry / "adbench_normalisation_report.json").read_text()))
    ]
    curated = {
        m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]
    }
    for row in json.loads((registry / "uci_pool.json").read_text())["rows"]:
        if "labelled" in row["roles"]:
            out.append(
                None
            )
    return out


def x_jobs__mutmut_45(registry: Path, adbench: Path, pool: Path) -> list[dict[str, Any]]:
    files = {t["name"]: t["file"] for t in dr.ADBENCH_TABULAR}
    out = [
        {
            "problem": f"adbench:{name}",
            "source": "adbench",
            "name": name,
            "path": str(adbench / files[name]),
        }
        for name in sorted(json.loads((registry / "adbench_normalisation_report.json").read_text()))
    ]
    curated = {
        m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]
    }
    for row in json.loads((registry / "uci_pool.json").read_text())["rows"]:
        if "labelled" in row["roles"]:
            out.append(
                {
                    "XXproblemXX": f"uci:{row['uci_id']}",
                    "source": "uci",
                    "meta": curated[row["uci_id"]],
                    "path": str(pool / f"{row['uci_id']}.csv"),
                }
            )
    return out


def x_jobs__mutmut_46(registry: Path, adbench: Path, pool: Path) -> list[dict[str, Any]]:
    files = {t["name"]: t["file"] for t in dr.ADBENCH_TABULAR}
    out = [
        {
            "problem": f"adbench:{name}",
            "source": "adbench",
            "name": name,
            "path": str(adbench / files[name]),
        }
        for name in sorted(json.loads((registry / "adbench_normalisation_report.json").read_text()))
    ]
    curated = {
        m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]
    }
    for row in json.loads((registry / "uci_pool.json").read_text())["rows"]:
        if "labelled" in row["roles"]:
            out.append(
                {
                    "PROBLEM": f"uci:{row['uci_id']}",
                    "source": "uci",
                    "meta": curated[row["uci_id"]],
                    "path": str(pool / f"{row['uci_id']}.csv"),
                }
            )
    return out


def x_jobs__mutmut_47(registry: Path, adbench: Path, pool: Path) -> list[dict[str, Any]]:
    files = {t["name"]: t["file"] for t in dr.ADBENCH_TABULAR}
    out = [
        {
            "problem": f"adbench:{name}",
            "source": "adbench",
            "name": name,
            "path": str(adbench / files[name]),
        }
        for name in sorted(json.loads((registry / "adbench_normalisation_report.json").read_text()))
    ]
    curated = {
        m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]
    }
    for row in json.loads((registry / "uci_pool.json").read_text())["rows"]:
        if "labelled" in row["roles"]:
            out.append(
                {
                    "problem": f"uci:{row['XXuci_idXX']}",
                    "source": "uci",
                    "meta": curated[row["uci_id"]],
                    "path": str(pool / f"{row['uci_id']}.csv"),
                }
            )
    return out


def x_jobs__mutmut_48(registry: Path, adbench: Path, pool: Path) -> list[dict[str, Any]]:
    files = {t["name"]: t["file"] for t in dr.ADBENCH_TABULAR}
    out = [
        {
            "problem": f"adbench:{name}",
            "source": "adbench",
            "name": name,
            "path": str(adbench / files[name]),
        }
        for name in sorted(json.loads((registry / "adbench_normalisation_report.json").read_text()))
    ]
    curated = {
        m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]
    }
    for row in json.loads((registry / "uci_pool.json").read_text())["rows"]:
        if "labelled" in row["roles"]:
            out.append(
                {
                    "problem": f"uci:{row['UCI_ID']}",
                    "source": "uci",
                    "meta": curated[row["uci_id"]],
                    "path": str(pool / f"{row['uci_id']}.csv"),
                }
            )
    return out


def x_jobs__mutmut_49(registry: Path, adbench: Path, pool: Path) -> list[dict[str, Any]]:
    files = {t["name"]: t["file"] for t in dr.ADBENCH_TABULAR}
    out = [
        {
            "problem": f"adbench:{name}",
            "source": "adbench",
            "name": name,
            "path": str(adbench / files[name]),
        }
        for name in sorted(json.loads((registry / "adbench_normalisation_report.json").read_text()))
    ]
    curated = {
        m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]
    }
    for row in json.loads((registry / "uci_pool.json").read_text())["rows"]:
        if "labelled" in row["roles"]:
            out.append(
                {
                    "problem": f"uci:{row['uci_id']}",
                    "XXsourceXX": "uci",
                    "meta": curated[row["uci_id"]],
                    "path": str(pool / f"{row['uci_id']}.csv"),
                }
            )
    return out


def x_jobs__mutmut_50(registry: Path, adbench: Path, pool: Path) -> list[dict[str, Any]]:
    files = {t["name"]: t["file"] for t in dr.ADBENCH_TABULAR}
    out = [
        {
            "problem": f"adbench:{name}",
            "source": "adbench",
            "name": name,
            "path": str(adbench / files[name]),
        }
        for name in sorted(json.loads((registry / "adbench_normalisation_report.json").read_text()))
    ]
    curated = {
        m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]
    }
    for row in json.loads((registry / "uci_pool.json").read_text())["rows"]:
        if "labelled" in row["roles"]:
            out.append(
                {
                    "problem": f"uci:{row['uci_id']}",
                    "SOURCE": "uci",
                    "meta": curated[row["uci_id"]],
                    "path": str(pool / f"{row['uci_id']}.csv"),
                }
            )
    return out


def x_jobs__mutmut_51(registry: Path, adbench: Path, pool: Path) -> list[dict[str, Any]]:
    files = {t["name"]: t["file"] for t in dr.ADBENCH_TABULAR}
    out = [
        {
            "problem": f"adbench:{name}",
            "source": "adbench",
            "name": name,
            "path": str(adbench / files[name]),
        }
        for name in sorted(json.loads((registry / "adbench_normalisation_report.json").read_text()))
    ]
    curated = {
        m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]
    }
    for row in json.loads((registry / "uci_pool.json").read_text())["rows"]:
        if "labelled" in row["roles"]:
            out.append(
                {
                    "problem": f"uci:{row['uci_id']}",
                    "source": "XXuciXX",
                    "meta": curated[row["uci_id"]],
                    "path": str(pool / f"{row['uci_id']}.csv"),
                }
            )
    return out


def x_jobs__mutmut_52(registry: Path, adbench: Path, pool: Path) -> list[dict[str, Any]]:
    files = {t["name"]: t["file"] for t in dr.ADBENCH_TABULAR}
    out = [
        {
            "problem": f"adbench:{name}",
            "source": "adbench",
            "name": name,
            "path": str(adbench / files[name]),
        }
        for name in sorted(json.loads((registry / "adbench_normalisation_report.json").read_text()))
    ]
    curated = {
        m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]
    }
    for row in json.loads((registry / "uci_pool.json").read_text())["rows"]:
        if "labelled" in row["roles"]:
            out.append(
                {
                    "problem": f"uci:{row['uci_id']}",
                    "source": "UCI",
                    "meta": curated[row["uci_id"]],
                    "path": str(pool / f"{row['uci_id']}.csv"),
                }
            )
    return out


def x_jobs__mutmut_53(registry: Path, adbench: Path, pool: Path) -> list[dict[str, Any]]:
    files = {t["name"]: t["file"] for t in dr.ADBENCH_TABULAR}
    out = [
        {
            "problem": f"adbench:{name}",
            "source": "adbench",
            "name": name,
            "path": str(adbench / files[name]),
        }
        for name in sorted(json.loads((registry / "adbench_normalisation_report.json").read_text()))
    ]
    curated = {
        m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]
    }
    for row in json.loads((registry / "uci_pool.json").read_text())["rows"]:
        if "labelled" in row["roles"]:
            out.append(
                {
                    "problem": f"uci:{row['uci_id']}",
                    "source": "uci",
                    "XXmetaXX": curated[row["uci_id"]],
                    "path": str(pool / f"{row['uci_id']}.csv"),
                }
            )
    return out


def x_jobs__mutmut_54(registry: Path, adbench: Path, pool: Path) -> list[dict[str, Any]]:
    files = {t["name"]: t["file"] for t in dr.ADBENCH_TABULAR}
    out = [
        {
            "problem": f"adbench:{name}",
            "source": "adbench",
            "name": name,
            "path": str(adbench / files[name]),
        }
        for name in sorted(json.loads((registry / "adbench_normalisation_report.json").read_text()))
    ]
    curated = {
        m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]
    }
    for row in json.loads((registry / "uci_pool.json").read_text())["rows"]:
        if "labelled" in row["roles"]:
            out.append(
                {
                    "problem": f"uci:{row['uci_id']}",
                    "source": "uci",
                    "META": curated[row["uci_id"]],
                    "path": str(pool / f"{row['uci_id']}.csv"),
                }
            )
    return out


def x_jobs__mutmut_55(registry: Path, adbench: Path, pool: Path) -> list[dict[str, Any]]:
    files = {t["name"]: t["file"] for t in dr.ADBENCH_TABULAR}
    out = [
        {
            "problem": f"adbench:{name}",
            "source": "adbench",
            "name": name,
            "path": str(adbench / files[name]),
        }
        for name in sorted(json.loads((registry / "adbench_normalisation_report.json").read_text()))
    ]
    curated = {
        m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]
    }
    for row in json.loads((registry / "uci_pool.json").read_text())["rows"]:
        if "labelled" in row["roles"]:
            out.append(
                {
                    "problem": f"uci:{row['uci_id']}",
                    "source": "uci",
                    "meta": curated[row["XXuci_idXX"]],
                    "path": str(pool / f"{row['uci_id']}.csv"),
                }
            )
    return out


def x_jobs__mutmut_56(registry: Path, adbench: Path, pool: Path) -> list[dict[str, Any]]:
    files = {t["name"]: t["file"] for t in dr.ADBENCH_TABULAR}
    out = [
        {
            "problem": f"adbench:{name}",
            "source": "adbench",
            "name": name,
            "path": str(adbench / files[name]),
        }
        for name in sorted(json.loads((registry / "adbench_normalisation_report.json").read_text()))
    ]
    curated = {
        m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]
    }
    for row in json.loads((registry / "uci_pool.json").read_text())["rows"]:
        if "labelled" in row["roles"]:
            out.append(
                {
                    "problem": f"uci:{row['uci_id']}",
                    "source": "uci",
                    "meta": curated[row["UCI_ID"]],
                    "path": str(pool / f"{row['uci_id']}.csv"),
                }
            )
    return out


def x_jobs__mutmut_57(registry: Path, adbench: Path, pool: Path) -> list[dict[str, Any]]:
    files = {t["name"]: t["file"] for t in dr.ADBENCH_TABULAR}
    out = [
        {
            "problem": f"adbench:{name}",
            "source": "adbench",
            "name": name,
            "path": str(adbench / files[name]),
        }
        for name in sorted(json.loads((registry / "adbench_normalisation_report.json").read_text()))
    ]
    curated = {
        m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]
    }
    for row in json.loads((registry / "uci_pool.json").read_text())["rows"]:
        if "labelled" in row["roles"]:
            out.append(
                {
                    "problem": f"uci:{row['uci_id']}",
                    "source": "uci",
                    "meta": curated[row["uci_id"]],
                    "XXpathXX": str(pool / f"{row['uci_id']}.csv"),
                }
            )
    return out


def x_jobs__mutmut_58(registry: Path, adbench: Path, pool: Path) -> list[dict[str, Any]]:
    files = {t["name"]: t["file"] for t in dr.ADBENCH_TABULAR}
    out = [
        {
            "problem": f"adbench:{name}",
            "source": "adbench",
            "name": name,
            "path": str(adbench / files[name]),
        }
        for name in sorted(json.loads((registry / "adbench_normalisation_report.json").read_text()))
    ]
    curated = {
        m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]
    }
    for row in json.loads((registry / "uci_pool.json").read_text())["rows"]:
        if "labelled" in row["roles"]:
            out.append(
                {
                    "problem": f"uci:{row['uci_id']}",
                    "source": "uci",
                    "meta": curated[row["uci_id"]],
                    "PATH": str(pool / f"{row['uci_id']}.csv"),
                }
            )
    return out


def x_jobs__mutmut_59(registry: Path, adbench: Path, pool: Path) -> list[dict[str, Any]]:
    files = {t["name"]: t["file"] for t in dr.ADBENCH_TABULAR}
    out = [
        {
            "problem": f"adbench:{name}",
            "source": "adbench",
            "name": name,
            "path": str(adbench / files[name]),
        }
        for name in sorted(json.loads((registry / "adbench_normalisation_report.json").read_text()))
    ]
    curated = {
        m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]
    }
    for row in json.loads((registry / "uci_pool.json").read_text())["rows"]:
        if "labelled" in row["roles"]:
            out.append(
                {
                    "problem": f"uci:{row['uci_id']}",
                    "source": "uci",
                    "meta": curated[row["uci_id"]],
                    "path": str(None),
                }
            )
    return out


def x_jobs__mutmut_60(registry: Path, adbench: Path, pool: Path) -> list[dict[str, Any]]:
    files = {t["name"]: t["file"] for t in dr.ADBENCH_TABULAR}
    out = [
        {
            "problem": f"adbench:{name}",
            "source": "adbench",
            "name": name,
            "path": str(adbench / files[name]),
        }
        for name in sorted(json.loads((registry / "adbench_normalisation_report.json").read_text()))
    ]
    curated = {
        m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]
    }
    for row in json.loads((registry / "uci_pool.json").read_text())["rows"]:
        if "labelled" in row["roles"]:
            out.append(
                {
                    "problem": f"uci:{row['uci_id']}",
                    "source": "uci",
                    "meta": curated[row["uci_id"]],
                    "path": str(pool * f"{row['uci_id']}.csv"),
                }
            )
    return out


def x_jobs__mutmut_61(registry: Path, adbench: Path, pool: Path) -> list[dict[str, Any]]:
    files = {t["name"]: t["file"] for t in dr.ADBENCH_TABULAR}
    out = [
        {
            "problem": f"adbench:{name}",
            "source": "adbench",
            "name": name,
            "path": str(adbench / files[name]),
        }
        for name in sorted(json.loads((registry / "adbench_normalisation_report.json").read_text()))
    ]
    curated = {
        m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]
    }
    for row in json.loads((registry / "uci_pool.json").read_text())["rows"]:
        if "labelled" in row["roles"]:
            out.append(
                {
                    "problem": f"uci:{row['uci_id']}",
                    "source": "uci",
                    "meta": curated[row["uci_id"]],
                    "path": str(pool / f"{row['XXuci_idXX']}.csv"),
                }
            )
    return out


def x_jobs__mutmut_62(registry: Path, adbench: Path, pool: Path) -> list[dict[str, Any]]:
    files = {t["name"]: t["file"] for t in dr.ADBENCH_TABULAR}
    out = [
        {
            "problem": f"adbench:{name}",
            "source": "adbench",
            "name": name,
            "path": str(adbench / files[name]),
        }
        for name in sorted(json.loads((registry / "adbench_normalisation_report.json").read_text()))
    ]
    curated = {
        m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]
    }
    for row in json.loads((registry / "uci_pool.json").read_text())["rows"]:
        if "labelled" in row["roles"]:
            out.append(
                {
                    "problem": f"uci:{row['uci_id']}",
                    "source": "uci",
                    "meta": curated[row["uci_id"]],
                    "path": str(pool / f"{row['UCI_ID']}.csv"),
                }
            )
    return out

mutants_x_jobs__mutmut['_mutmut_orig'] = x_jobs__mutmut_orig # type: ignore # mutmut generated
mutants_x_jobs__mutmut['x_jobs__mutmut_1'] = x_jobs__mutmut_1 # type: ignore # mutmut generated
mutants_x_jobs__mutmut['x_jobs__mutmut_2'] = x_jobs__mutmut_2 # type: ignore # mutmut generated
mutants_x_jobs__mutmut['x_jobs__mutmut_3'] = x_jobs__mutmut_3 # type: ignore # mutmut generated
mutants_x_jobs__mutmut['x_jobs__mutmut_4'] = x_jobs__mutmut_4 # type: ignore # mutmut generated
mutants_x_jobs__mutmut['x_jobs__mutmut_5'] = x_jobs__mutmut_5 # type: ignore # mutmut generated
mutants_x_jobs__mutmut['x_jobs__mutmut_6'] = x_jobs__mutmut_6 # type: ignore # mutmut generated
mutants_x_jobs__mutmut['x_jobs__mutmut_7'] = x_jobs__mutmut_7 # type: ignore # mutmut generated
mutants_x_jobs__mutmut['x_jobs__mutmut_8'] = x_jobs__mutmut_8 # type: ignore # mutmut generated
mutants_x_jobs__mutmut['x_jobs__mutmut_9'] = x_jobs__mutmut_9 # type: ignore # mutmut generated
mutants_x_jobs__mutmut['x_jobs__mutmut_10'] = x_jobs__mutmut_10 # type: ignore # mutmut generated
mutants_x_jobs__mutmut['x_jobs__mutmut_11'] = x_jobs__mutmut_11 # type: ignore # mutmut generated
mutants_x_jobs__mutmut['x_jobs__mutmut_12'] = x_jobs__mutmut_12 # type: ignore # mutmut generated
mutants_x_jobs__mutmut['x_jobs__mutmut_13'] = x_jobs__mutmut_13 # type: ignore # mutmut generated
mutants_x_jobs__mutmut['x_jobs__mutmut_14'] = x_jobs__mutmut_14 # type: ignore # mutmut generated
mutants_x_jobs__mutmut['x_jobs__mutmut_15'] = x_jobs__mutmut_15 # type: ignore # mutmut generated
mutants_x_jobs__mutmut['x_jobs__mutmut_16'] = x_jobs__mutmut_16 # type: ignore # mutmut generated
mutants_x_jobs__mutmut['x_jobs__mutmut_17'] = x_jobs__mutmut_17 # type: ignore # mutmut generated
mutants_x_jobs__mutmut['x_jobs__mutmut_18'] = x_jobs__mutmut_18 # type: ignore # mutmut generated
mutants_x_jobs__mutmut['x_jobs__mutmut_19'] = x_jobs__mutmut_19 # type: ignore # mutmut generated
mutants_x_jobs__mutmut['x_jobs__mutmut_20'] = x_jobs__mutmut_20 # type: ignore # mutmut generated
mutants_x_jobs__mutmut['x_jobs__mutmut_21'] = x_jobs__mutmut_21 # type: ignore # mutmut generated
mutants_x_jobs__mutmut['x_jobs__mutmut_22'] = x_jobs__mutmut_22 # type: ignore # mutmut generated
mutants_x_jobs__mutmut['x_jobs__mutmut_23'] = x_jobs__mutmut_23 # type: ignore # mutmut generated
mutants_x_jobs__mutmut['x_jobs__mutmut_24'] = x_jobs__mutmut_24 # type: ignore # mutmut generated
mutants_x_jobs__mutmut['x_jobs__mutmut_25'] = x_jobs__mutmut_25 # type: ignore # mutmut generated
mutants_x_jobs__mutmut['x_jobs__mutmut_26'] = x_jobs__mutmut_26 # type: ignore # mutmut generated
mutants_x_jobs__mutmut['x_jobs__mutmut_27'] = x_jobs__mutmut_27 # type: ignore # mutmut generated
mutants_x_jobs__mutmut['x_jobs__mutmut_28'] = x_jobs__mutmut_28 # type: ignore # mutmut generated
mutants_x_jobs__mutmut['x_jobs__mutmut_29'] = x_jobs__mutmut_29 # type: ignore # mutmut generated
mutants_x_jobs__mutmut['x_jobs__mutmut_30'] = x_jobs__mutmut_30 # type: ignore # mutmut generated
mutants_x_jobs__mutmut['x_jobs__mutmut_31'] = x_jobs__mutmut_31 # type: ignore # mutmut generated
mutants_x_jobs__mutmut['x_jobs__mutmut_32'] = x_jobs__mutmut_32 # type: ignore # mutmut generated
mutants_x_jobs__mutmut['x_jobs__mutmut_33'] = x_jobs__mutmut_33 # type: ignore # mutmut generated
mutants_x_jobs__mutmut['x_jobs__mutmut_34'] = x_jobs__mutmut_34 # type: ignore # mutmut generated
mutants_x_jobs__mutmut['x_jobs__mutmut_35'] = x_jobs__mutmut_35 # type: ignore # mutmut generated
mutants_x_jobs__mutmut['x_jobs__mutmut_36'] = x_jobs__mutmut_36 # type: ignore # mutmut generated
mutants_x_jobs__mutmut['x_jobs__mutmut_37'] = x_jobs__mutmut_37 # type: ignore # mutmut generated
mutants_x_jobs__mutmut['x_jobs__mutmut_38'] = x_jobs__mutmut_38 # type: ignore # mutmut generated
mutants_x_jobs__mutmut['x_jobs__mutmut_39'] = x_jobs__mutmut_39 # type: ignore # mutmut generated
mutants_x_jobs__mutmut['x_jobs__mutmut_40'] = x_jobs__mutmut_40 # type: ignore # mutmut generated
mutants_x_jobs__mutmut['x_jobs__mutmut_41'] = x_jobs__mutmut_41 # type: ignore # mutmut generated
mutants_x_jobs__mutmut['x_jobs__mutmut_42'] = x_jobs__mutmut_42 # type: ignore # mutmut generated
mutants_x_jobs__mutmut['x_jobs__mutmut_43'] = x_jobs__mutmut_43 # type: ignore # mutmut generated
mutants_x_jobs__mutmut['x_jobs__mutmut_44'] = x_jobs__mutmut_44 # type: ignore # mutmut generated
mutants_x_jobs__mutmut['x_jobs__mutmut_45'] = x_jobs__mutmut_45 # type: ignore # mutmut generated
mutants_x_jobs__mutmut['x_jobs__mutmut_46'] = x_jobs__mutmut_46 # type: ignore # mutmut generated
mutants_x_jobs__mutmut['x_jobs__mutmut_47'] = x_jobs__mutmut_47 # type: ignore # mutmut generated
mutants_x_jobs__mutmut['x_jobs__mutmut_48'] = x_jobs__mutmut_48 # type: ignore # mutmut generated
mutants_x_jobs__mutmut['x_jobs__mutmut_49'] = x_jobs__mutmut_49 # type: ignore # mutmut generated
mutants_x_jobs__mutmut['x_jobs__mutmut_50'] = x_jobs__mutmut_50 # type: ignore # mutmut generated
mutants_x_jobs__mutmut['x_jobs__mutmut_51'] = x_jobs__mutmut_51 # type: ignore # mutmut generated
mutants_x_jobs__mutmut['x_jobs__mutmut_52'] = x_jobs__mutmut_52 # type: ignore # mutmut generated
mutants_x_jobs__mutmut['x_jobs__mutmut_53'] = x_jobs__mutmut_53 # type: ignore # mutmut generated
mutants_x_jobs__mutmut['x_jobs__mutmut_54'] = x_jobs__mutmut_54 # type: ignore # mutmut generated
mutants_x_jobs__mutmut['x_jobs__mutmut_55'] = x_jobs__mutmut_55 # type: ignore # mutmut generated
mutants_x_jobs__mutmut['x_jobs__mutmut_56'] = x_jobs__mutmut_56 # type: ignore # mutmut generated
mutants_x_jobs__mutmut['x_jobs__mutmut_57'] = x_jobs__mutmut_57 # type: ignore # mutmut generated
mutants_x_jobs__mutmut['x_jobs__mutmut_58'] = x_jobs__mutmut_58 # type: ignore # mutmut generated
mutants_x_jobs__mutmut['x_jobs__mutmut_59'] = x_jobs__mutmut_59 # type: ignore # mutmut generated
mutants_x_jobs__mutmut['x_jobs__mutmut_60'] = x_jobs__mutmut_60 # type: ignore # mutmut generated
mutants_x_jobs__mutmut['x_jobs__mutmut_61'] = x_jobs__mutmut_61 # type: ignore # mutmut generated
mutants_x_jobs__mutmut['x_jobs__mutmut_62'] = x_jobs__mutmut_62 # type: ignore # mutmut generated
mutants_x_main__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_main__mutmut)
def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_orig(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_1(argv: list[str] | None = None) -> int:
    parser = None
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_2(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=None)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_3(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = None
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_4(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = None
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_5(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" * "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_6(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" * "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_7(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root * "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_8(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "XXverificationXX" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_9(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "VERIFICATION" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_10(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "XXevidenceXX" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_11(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "EVIDENCE" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_12(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "XXdataset_registryXX"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_13(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "DATASET_REGISTRY"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_14(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument(None, type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_15(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=None, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_16(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=None)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_17(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument(type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_18(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_19(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, )
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_20(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("XX--registryXX", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_21(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--REGISTRY", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_22(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument(None, type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_23(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=None, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_24(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=None)
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_25(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument(type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_26(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_27(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, )
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_28(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("XX--adbenchXX", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_29(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--ADBENCH", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_30(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" * "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_31(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root * "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_32(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "XXdataXX" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_33(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "DATA" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_34(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "XXadbenchXX")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_35(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "ADBENCH")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_36(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument(None, type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_37(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=None, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_38(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=None)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_39(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument(type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_40(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_41(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, )
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_42(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("XX--poolXX", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_43(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--POOL", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_44(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" * "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_45(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root * "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_46(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "XXdataXX" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_47(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "DATA" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_48(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "XXpoolXX")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_49(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "POOL")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_50(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument(None, type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_51(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=None, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_52(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=None)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_53(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument(type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_54(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_55(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, )
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_56(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("XX--outputXX", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_57(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--OUTPUT", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_58(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=False)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_59(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument(None, type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_60(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=None, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_61(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=None)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_62(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument(type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_63(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_64(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, )
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_65(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("XX--workersXX", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_66(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--WORKERS", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_67(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=5)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_68(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument(None, nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_69(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs=None, help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_70(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help=None)
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_71(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument(nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_72(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_73(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", )
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_74(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("XX--onlyXX", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_75(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--ONLY", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_76(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="XX*XX", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_77(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="XXproblem ids, for a quick checkXX")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_78(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="PROBLEM IDS, FOR A QUICK CHECK")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_79(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        None, action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_80(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action=None, help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_81(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help=None
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_82(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_83(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_84(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_85(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "XX--resumeXX", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_86(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--RESUME", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_87(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="XXstore_trueXX", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_88(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="STORE_TRUE", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_89(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="XXskip the problems whose result is already writtenXX"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_90(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="SKIP THE PROBLEMS WHOSE RESULT IS ALREADY WRITTEN"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_91(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        None,
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_92(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=None,
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_93(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default=None,
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_94(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help=None,
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_95(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_96(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_97(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_98(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_99(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "XX--methodsXX",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_100(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--METHODS",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_101(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("XXclassicalXX", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_102(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("CLASSICAL", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_103(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "XXdeepXX"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_104(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "DEEP"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_105(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="XXclassicalXX",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_106(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="CLASSICAL",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_107(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="XXthe detectors of the registry sweep, or the neural ones (fit rows capped)XX",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_108(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="THE DETECTORS OF THE REGISTRY SWEEP, OR THE NEURAL ONES (FIT ROWS CAPPED)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_109(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = None
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_110(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(None)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_111(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = None
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_112(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(None, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_113(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, None, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_114(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, None)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_115(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_116(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_117(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, )
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_118(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only and j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_119(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_120(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["XXproblemXX"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_121(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["PROBLEM"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_122(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] not in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_123(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=None, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_124(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=None)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_125(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_126(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, )
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_127(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=False, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_128(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=False)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_129(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = None
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_130(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_131(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output * f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_132(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(None, '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_133(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', None)}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_134(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace('_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_135(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', )}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_136(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['XXproblemXX'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_137(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['PROBLEM'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_138(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace('XX:XX', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_139(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', 'XX_XX')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_140(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = None
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_141(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 1
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_142(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = None
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_143(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if (args.methods == "deep") and False else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_144(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if (args.methods == "deep") or True else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_145(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(None) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_146(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods != "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_147(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "XXdeepXX" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_148(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "DEEP" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_149(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(None)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_150(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=None) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_151(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(None, todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_152(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), None):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_153(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_154(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), ):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_155(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(None, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_156(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=None), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_157(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_158(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, ), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_159(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed = "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_160(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed -= "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_161(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "XXfailedXX" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_162(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "FAILED" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_163(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" not in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_164(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = None
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_165(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(None, "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_166(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", None)
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_167(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace("_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_168(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", )
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_169(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["XXproblemXX"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_170(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["PROBLEM"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_171(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace("XX:XX", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_172(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "XX_XX")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_173(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(None) as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_174(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output * f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_175(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(None)
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_176(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) - "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_177(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(None, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_178(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=None, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_179(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=None) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_180(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_181(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_182(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, ) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_183(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_184(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=False) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_185(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "XX\nXX")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_186(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(None, result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_187(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], None, flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_188(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=None)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_189(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_190(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_191(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), )
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_192(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["XXproblemXX"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_193(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["PROBLEM"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_194(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get(None, "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_195(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", None), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_196(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_197(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", ), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_198(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("XXfailedXX", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_199(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("FAILED", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_200(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "XXokXX"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_201(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "OK"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_202(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=False)
    print(f"{len(todo)} problems, {failed} failed")
    return 0


def x_main__mutmut_203(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(None)
    return 0


def x_main__mutmut_204(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent
    registry = root / "verification" / "evidence" / "dataset_registry"
    parser.add_argument("--registry", type=Path, default=registry)
    parser.add_argument("--adbench", type=Path, default=root / "data" / "adbench")
    parser.add_argument("--pool", type=Path, default=root / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--only", nargs="*", help="problem ids, for a quick check")
    parser.add_argument(
        "--resume", action="store_true", help="skip the problems whose result is already written"
    )
    parser.add_argument(
        "--methods",
        choices=("classical", "deep"),
        default="classical",
        help="the detectors of the registry sweep, or the neural ones (fit rows capped)",
    )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    todo = [
        j
        for j in jobs(args.registry, args.adbench, args.pool)
        if not args.only or j["problem"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.resume:
        todo = [
            j for j in todo if not (args.output / f"{j['problem'].replace(':', '_')}.json").exists()
        ]
    failed = 0
    methods = list(DEEP_NAMES) if args.methods == "deep" else list(METHODS)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(bind(run_job, methods=methods), todo):
            failed += "failed" in result
            stem = result["problem"].replace(":", "_")
            with atomic_path(args.output / f"{stem}.json") as partial:
                partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
            print(result["problem"], result.get("failed", "ok"), flush=True)
    print(f"{len(todo)} problems, {failed} failed")
    return 1

mutants_x_main__mutmut['_mutmut_orig'] = x_main__mutmut_orig # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_1'] = x_main__mutmut_1 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_2'] = x_main__mutmut_2 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_3'] = x_main__mutmut_3 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_4'] = x_main__mutmut_4 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_5'] = x_main__mutmut_5 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_6'] = x_main__mutmut_6 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_7'] = x_main__mutmut_7 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_8'] = x_main__mutmut_8 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_9'] = x_main__mutmut_9 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_10'] = x_main__mutmut_10 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_11'] = x_main__mutmut_11 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_12'] = x_main__mutmut_12 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_13'] = x_main__mutmut_13 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_14'] = x_main__mutmut_14 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_15'] = x_main__mutmut_15 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_16'] = x_main__mutmut_16 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_17'] = x_main__mutmut_17 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_18'] = x_main__mutmut_18 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_19'] = x_main__mutmut_19 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_20'] = x_main__mutmut_20 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_21'] = x_main__mutmut_21 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_22'] = x_main__mutmut_22 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_23'] = x_main__mutmut_23 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_24'] = x_main__mutmut_24 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_25'] = x_main__mutmut_25 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_26'] = x_main__mutmut_26 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_27'] = x_main__mutmut_27 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_28'] = x_main__mutmut_28 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_29'] = x_main__mutmut_29 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_30'] = x_main__mutmut_30 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_31'] = x_main__mutmut_31 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_32'] = x_main__mutmut_32 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_33'] = x_main__mutmut_33 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_34'] = x_main__mutmut_34 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_35'] = x_main__mutmut_35 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_36'] = x_main__mutmut_36 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_37'] = x_main__mutmut_37 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_38'] = x_main__mutmut_38 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_39'] = x_main__mutmut_39 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_40'] = x_main__mutmut_40 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_41'] = x_main__mutmut_41 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_42'] = x_main__mutmut_42 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_43'] = x_main__mutmut_43 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_44'] = x_main__mutmut_44 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_45'] = x_main__mutmut_45 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_46'] = x_main__mutmut_46 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_47'] = x_main__mutmut_47 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_48'] = x_main__mutmut_48 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_49'] = x_main__mutmut_49 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_50'] = x_main__mutmut_50 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_51'] = x_main__mutmut_51 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_52'] = x_main__mutmut_52 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_53'] = x_main__mutmut_53 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_54'] = x_main__mutmut_54 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_55'] = x_main__mutmut_55 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_56'] = x_main__mutmut_56 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_57'] = x_main__mutmut_57 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_58'] = x_main__mutmut_58 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_59'] = x_main__mutmut_59 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_60'] = x_main__mutmut_60 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_61'] = x_main__mutmut_61 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_62'] = x_main__mutmut_62 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_63'] = x_main__mutmut_63 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_64'] = x_main__mutmut_64 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_65'] = x_main__mutmut_65 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_66'] = x_main__mutmut_66 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_67'] = x_main__mutmut_67 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_68'] = x_main__mutmut_68 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_69'] = x_main__mutmut_69 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_70'] = x_main__mutmut_70 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_71'] = x_main__mutmut_71 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_72'] = x_main__mutmut_72 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_73'] = x_main__mutmut_73 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_74'] = x_main__mutmut_74 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_75'] = x_main__mutmut_75 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_76'] = x_main__mutmut_76 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_77'] = x_main__mutmut_77 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_78'] = x_main__mutmut_78 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_79'] = x_main__mutmut_79 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_80'] = x_main__mutmut_80 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_81'] = x_main__mutmut_81 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_82'] = x_main__mutmut_82 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_83'] = x_main__mutmut_83 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_84'] = x_main__mutmut_84 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_85'] = x_main__mutmut_85 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_86'] = x_main__mutmut_86 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_87'] = x_main__mutmut_87 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_88'] = x_main__mutmut_88 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_89'] = x_main__mutmut_89 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_90'] = x_main__mutmut_90 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_91'] = x_main__mutmut_91 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_92'] = x_main__mutmut_92 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_93'] = x_main__mutmut_93 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_94'] = x_main__mutmut_94 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_95'] = x_main__mutmut_95 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_96'] = x_main__mutmut_96 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_97'] = x_main__mutmut_97 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_98'] = x_main__mutmut_98 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_99'] = x_main__mutmut_99 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_100'] = x_main__mutmut_100 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_101'] = x_main__mutmut_101 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_102'] = x_main__mutmut_102 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_103'] = x_main__mutmut_103 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_104'] = x_main__mutmut_104 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_105'] = x_main__mutmut_105 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_106'] = x_main__mutmut_106 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_107'] = x_main__mutmut_107 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_108'] = x_main__mutmut_108 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_109'] = x_main__mutmut_109 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_110'] = x_main__mutmut_110 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_111'] = x_main__mutmut_111 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_112'] = x_main__mutmut_112 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_113'] = x_main__mutmut_113 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_114'] = x_main__mutmut_114 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_115'] = x_main__mutmut_115 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_116'] = x_main__mutmut_116 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_117'] = x_main__mutmut_117 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_118'] = x_main__mutmut_118 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_119'] = x_main__mutmut_119 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_120'] = x_main__mutmut_120 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_121'] = x_main__mutmut_121 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_122'] = x_main__mutmut_122 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_123'] = x_main__mutmut_123 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_124'] = x_main__mutmut_124 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_125'] = x_main__mutmut_125 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_126'] = x_main__mutmut_126 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_127'] = x_main__mutmut_127 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_128'] = x_main__mutmut_128 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_129'] = x_main__mutmut_129 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_130'] = x_main__mutmut_130 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_131'] = x_main__mutmut_131 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_132'] = x_main__mutmut_132 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_133'] = x_main__mutmut_133 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_134'] = x_main__mutmut_134 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_135'] = x_main__mutmut_135 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_136'] = x_main__mutmut_136 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_137'] = x_main__mutmut_137 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_138'] = x_main__mutmut_138 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_139'] = x_main__mutmut_139 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_140'] = x_main__mutmut_140 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_141'] = x_main__mutmut_141 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_142'] = x_main__mutmut_142 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_143'] = x_main__mutmut_143 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_144'] = x_main__mutmut_144 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_145'] = x_main__mutmut_145 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_146'] = x_main__mutmut_146 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_147'] = x_main__mutmut_147 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_148'] = x_main__mutmut_148 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_149'] = x_main__mutmut_149 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_150'] = x_main__mutmut_150 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_151'] = x_main__mutmut_151 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_152'] = x_main__mutmut_152 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_153'] = x_main__mutmut_153 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_154'] = x_main__mutmut_154 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_155'] = x_main__mutmut_155 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_156'] = x_main__mutmut_156 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_157'] = x_main__mutmut_157 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_158'] = x_main__mutmut_158 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_159'] = x_main__mutmut_159 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_160'] = x_main__mutmut_160 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_161'] = x_main__mutmut_161 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_162'] = x_main__mutmut_162 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_163'] = x_main__mutmut_163 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_164'] = x_main__mutmut_164 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_165'] = x_main__mutmut_165 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_166'] = x_main__mutmut_166 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_167'] = x_main__mutmut_167 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_168'] = x_main__mutmut_168 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_169'] = x_main__mutmut_169 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_170'] = x_main__mutmut_170 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_171'] = x_main__mutmut_171 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_172'] = x_main__mutmut_172 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_173'] = x_main__mutmut_173 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_174'] = x_main__mutmut_174 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_175'] = x_main__mutmut_175 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_176'] = x_main__mutmut_176 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_177'] = x_main__mutmut_177 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_178'] = x_main__mutmut_178 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_179'] = x_main__mutmut_179 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_180'] = x_main__mutmut_180 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_181'] = x_main__mutmut_181 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_182'] = x_main__mutmut_182 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_183'] = x_main__mutmut_183 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_184'] = x_main__mutmut_184 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_185'] = x_main__mutmut_185 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_186'] = x_main__mutmut_186 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_187'] = x_main__mutmut_187 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_188'] = x_main__mutmut_188 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_189'] = x_main__mutmut_189 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_190'] = x_main__mutmut_190 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_191'] = x_main__mutmut_191 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_192'] = x_main__mutmut_192 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_193'] = x_main__mutmut_193 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_194'] = x_main__mutmut_194 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_195'] = x_main__mutmut_195 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_196'] = x_main__mutmut_196 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_197'] = x_main__mutmut_197 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_198'] = x_main__mutmut_198 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_199'] = x_main__mutmut_199 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_200'] = x_main__mutmut_200 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_201'] = x_main__mutmut_201 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_202'] = x_main__mutmut_202 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_203'] = x_main__mutmut_203 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_204'] = x_main__mutmut_204 # type: ignore # mutmut generated


if __name__ == "__main__":
    raise SystemExit(main())
