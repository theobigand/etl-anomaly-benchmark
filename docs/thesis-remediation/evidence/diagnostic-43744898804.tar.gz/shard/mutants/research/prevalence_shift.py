"""Fixed deployment thresholds under a change of anomaly prevalence (T169; exploratory).

The model and its training-score threshold are kept as they are; no threshold is recalibrated. From
the held-out confusion counts of an alert-budget cell, the true-positive rate and the false-positive
rate of that fixed threshold are read. Under pure prior (label) shift, where the score distributions
of the normal rows and of the anomalies do not change and only their mixing proportion does, a test
set resampled to prevalence ``pi`` has, in expectation:

    alert rate = pi * TPR + (1 - pi) * FPR,   recall = TPR,   FPR = FPR,
    precision  = pi * TPR / alert rate

Test labels are therefore used to build the simulated population, never to set the threshold. This
isolates the prevalence effect: a change of the conditional score distributions (T170) is excluded
by construction, and the results say nothing about real deployment drift. The rates carry the
sampling error of the counts they come from, so the number of held-out positives and negatives is
reported.
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any

import numpy as np

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from source_clustered import bootstrap, holm, source_id  # noqa: E402

PREVALENCES = (0.005, 0.01, 0.02, 0.05, 0.10, 0.20)
METRICS = ("alert_rate", "precision", "recall", "f1", "fpr", "alert_over_budget")
DRAWS = 10_000


from mutmut.mutation.trampoline import wrap_in_trampoline as _mutmut_mutated, MutantDict
mutants_x_shifted__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_shifted__mutmut)
def shifted(cell: dict[str, Any], prevalence: float) -> dict[str, float]:
    """Expected metrics of the fixed threshold of ``cell`` at a population with this prevalence."""
    if not 0.0 < prevalence < 1.0:
        raise ValueError("prevalence must be in (0, 1)")
    positives, negatives = cell["tp"] + cell["fn"], cell["fp"] + cell["tn"]
    if positives <= 0 or negatives <= 0:
        raise ValueError("a cell needs held-out positives and negatives")
    tpr, fpr = cell["tp"] / positives, cell["fp"] / negatives
    alert = prevalence * tpr + (1 - prevalence) * fpr
    precision = prevalence * tpr / alert if alert > 0 else 0.0
    f1 = 2 * precision * tpr / (precision + tpr) if precision + tpr > 0 else 0.0
    return {
        "alert_rate": alert, "precision": precision, "recall": tpr, "f1": f1, "fpr": fpr,
        "alert_over_budget": alert / cell["nominal"],
    }  # fmt: skip


def x_shifted__mutmut_orig(cell: dict[str, Any], prevalence: float) -> dict[str, float]:
    """Expected metrics of the fixed threshold of ``cell`` at a population with this prevalence."""
    if not 0.0 < prevalence < 1.0:
        raise ValueError("prevalence must be in (0, 1)")
    positives, negatives = cell["tp"] + cell["fn"], cell["fp"] + cell["tn"]
    if positives <= 0 or negatives <= 0:
        raise ValueError("a cell needs held-out positives and negatives")
    tpr, fpr = cell["tp"] / positives, cell["fp"] / negatives
    alert = prevalence * tpr + (1 - prevalence) * fpr
    precision = prevalence * tpr / alert if alert > 0 else 0.0
    f1 = 2 * precision * tpr / (precision + tpr) if precision + tpr > 0 else 0.0
    return {
        "alert_rate": alert, "precision": precision, "recall": tpr, "f1": f1, "fpr": fpr,
        "alert_over_budget": alert / cell["nominal"],
    }  # fmt: skip


def x_shifted__mutmut_1(cell: dict[str, Any], prevalence: float) -> dict[str, float]:
    """Expected metrics of the fixed threshold of ``cell`` at a population with this prevalence."""
    if 0.0 < prevalence < 1.0:
        raise ValueError("prevalence must be in (0, 1)")
    positives, negatives = cell["tp"] + cell["fn"], cell["fp"] + cell["tn"]
    if positives <= 0 or negatives <= 0:
        raise ValueError("a cell needs held-out positives and negatives")
    tpr, fpr = cell["tp"] / positives, cell["fp"] / negatives
    alert = prevalence * tpr + (1 - prevalence) * fpr
    precision = prevalence * tpr / alert if alert > 0 else 0.0
    f1 = 2 * precision * tpr / (precision + tpr) if precision + tpr > 0 else 0.0
    return {
        "alert_rate": alert, "precision": precision, "recall": tpr, "f1": f1, "fpr": fpr,
        "alert_over_budget": alert / cell["nominal"],
    }  # fmt: skip


def x_shifted__mutmut_2(cell: dict[str, Any], prevalence: float) -> dict[str, float]:
    """Expected metrics of the fixed threshold of ``cell`` at a population with this prevalence."""
    if not 1.0 < prevalence < 1.0:
        raise ValueError("prevalence must be in (0, 1)")
    positives, negatives = cell["tp"] + cell["fn"], cell["fp"] + cell["tn"]
    if positives <= 0 or negatives <= 0:
        raise ValueError("a cell needs held-out positives and negatives")
    tpr, fpr = cell["tp"] / positives, cell["fp"] / negatives
    alert = prevalence * tpr + (1 - prevalence) * fpr
    precision = prevalence * tpr / alert if alert > 0 else 0.0
    f1 = 2 * precision * tpr / (precision + tpr) if precision + tpr > 0 else 0.0
    return {
        "alert_rate": alert, "precision": precision, "recall": tpr, "f1": f1, "fpr": fpr,
        "alert_over_budget": alert / cell["nominal"],
    }  # fmt: skip


def x_shifted__mutmut_3(cell: dict[str, Any], prevalence: float) -> dict[str, float]:
    """Expected metrics of the fixed threshold of ``cell`` at a population with this prevalence."""
    if not 0.0 <= prevalence < 1.0:
        raise ValueError("prevalence must be in (0, 1)")
    positives, negatives = cell["tp"] + cell["fn"], cell["fp"] + cell["tn"]
    if positives <= 0 or negatives <= 0:
        raise ValueError("a cell needs held-out positives and negatives")
    tpr, fpr = cell["tp"] / positives, cell["fp"] / negatives
    alert = prevalence * tpr + (1 - prevalence) * fpr
    precision = prevalence * tpr / alert if alert > 0 else 0.0
    f1 = 2 * precision * tpr / (precision + tpr) if precision + tpr > 0 else 0.0
    return {
        "alert_rate": alert, "precision": precision, "recall": tpr, "f1": f1, "fpr": fpr,
        "alert_over_budget": alert / cell["nominal"],
    }  # fmt: skip


def x_shifted__mutmut_4(cell: dict[str, Any], prevalence: float) -> dict[str, float]:
    """Expected metrics of the fixed threshold of ``cell`` at a population with this prevalence."""
    if not 0.0 < prevalence <= 1.0:
        raise ValueError("prevalence must be in (0, 1)")
    positives, negatives = cell["tp"] + cell["fn"], cell["fp"] + cell["tn"]
    if positives <= 0 or negatives <= 0:
        raise ValueError("a cell needs held-out positives and negatives")
    tpr, fpr = cell["tp"] / positives, cell["fp"] / negatives
    alert = prevalence * tpr + (1 - prevalence) * fpr
    precision = prevalence * tpr / alert if alert > 0 else 0.0
    f1 = 2 * precision * tpr / (precision + tpr) if precision + tpr > 0 else 0.0
    return {
        "alert_rate": alert, "precision": precision, "recall": tpr, "f1": f1, "fpr": fpr,
        "alert_over_budget": alert / cell["nominal"],
    }  # fmt: skip


def x_shifted__mutmut_5(cell: dict[str, Any], prevalence: float) -> dict[str, float]:
    """Expected metrics of the fixed threshold of ``cell`` at a population with this prevalence."""
    if not 0.0 < prevalence < 2.0:
        raise ValueError("prevalence must be in (0, 1)")
    positives, negatives = cell["tp"] + cell["fn"], cell["fp"] + cell["tn"]
    if positives <= 0 or negatives <= 0:
        raise ValueError("a cell needs held-out positives and negatives")
    tpr, fpr = cell["tp"] / positives, cell["fp"] / negatives
    alert = prevalence * tpr + (1 - prevalence) * fpr
    precision = prevalence * tpr / alert if alert > 0 else 0.0
    f1 = 2 * precision * tpr / (precision + tpr) if precision + tpr > 0 else 0.0
    return {
        "alert_rate": alert, "precision": precision, "recall": tpr, "f1": f1, "fpr": fpr,
        "alert_over_budget": alert / cell["nominal"],
    }  # fmt: skip


def x_shifted__mutmut_6(cell: dict[str, Any], prevalence: float) -> dict[str, float]:
    """Expected metrics of the fixed threshold of ``cell`` at a population with this prevalence."""
    if not 0.0 < prevalence < 1.0:
        raise ValueError(None)
    positives, negatives = cell["tp"] + cell["fn"], cell["fp"] + cell["tn"]
    if positives <= 0 or negatives <= 0:
        raise ValueError("a cell needs held-out positives and negatives")
    tpr, fpr = cell["tp"] / positives, cell["fp"] / negatives
    alert = prevalence * tpr + (1 - prevalence) * fpr
    precision = prevalence * tpr / alert if alert > 0 else 0.0
    f1 = 2 * precision * tpr / (precision + tpr) if precision + tpr > 0 else 0.0
    return {
        "alert_rate": alert, "precision": precision, "recall": tpr, "f1": f1, "fpr": fpr,
        "alert_over_budget": alert / cell["nominal"],
    }  # fmt: skip


def x_shifted__mutmut_7(cell: dict[str, Any], prevalence: float) -> dict[str, float]:
    """Expected metrics of the fixed threshold of ``cell`` at a population with this prevalence."""
    if not 0.0 < prevalence < 1.0:
        raise ValueError("XXprevalence must be in (0, 1)XX")
    positives, negatives = cell["tp"] + cell["fn"], cell["fp"] + cell["tn"]
    if positives <= 0 or negatives <= 0:
        raise ValueError("a cell needs held-out positives and negatives")
    tpr, fpr = cell["tp"] / positives, cell["fp"] / negatives
    alert = prevalence * tpr + (1 - prevalence) * fpr
    precision = prevalence * tpr / alert if alert > 0 else 0.0
    f1 = 2 * precision * tpr / (precision + tpr) if precision + tpr > 0 else 0.0
    return {
        "alert_rate": alert, "precision": precision, "recall": tpr, "f1": f1, "fpr": fpr,
        "alert_over_budget": alert / cell["nominal"],
    }  # fmt: skip


def x_shifted__mutmut_8(cell: dict[str, Any], prevalence: float) -> dict[str, float]:
    """Expected metrics of the fixed threshold of ``cell`` at a population with this prevalence."""
    if not 0.0 < prevalence < 1.0:
        raise ValueError("PREVALENCE MUST BE IN (0, 1)")
    positives, negatives = cell["tp"] + cell["fn"], cell["fp"] + cell["tn"]
    if positives <= 0 or negatives <= 0:
        raise ValueError("a cell needs held-out positives and negatives")
    tpr, fpr = cell["tp"] / positives, cell["fp"] / negatives
    alert = prevalence * tpr + (1 - prevalence) * fpr
    precision = prevalence * tpr / alert if alert > 0 else 0.0
    f1 = 2 * precision * tpr / (precision + tpr) if precision + tpr > 0 else 0.0
    return {
        "alert_rate": alert, "precision": precision, "recall": tpr, "f1": f1, "fpr": fpr,
        "alert_over_budget": alert / cell["nominal"],
    }  # fmt: skip


def x_shifted__mutmut_9(cell: dict[str, Any], prevalence: float) -> dict[str, float]:
    """Expected metrics of the fixed threshold of ``cell`` at a population with this prevalence."""
    if not 0.0 < prevalence < 1.0:
        raise ValueError("prevalence must be in (0, 1)")
    positives, negatives = None
    if positives <= 0 or negatives <= 0:
        raise ValueError("a cell needs held-out positives and negatives")
    tpr, fpr = cell["tp"] / positives, cell["fp"] / negatives
    alert = prevalence * tpr + (1 - prevalence) * fpr
    precision = prevalence * tpr / alert if alert > 0 else 0.0
    f1 = 2 * precision * tpr / (precision + tpr) if precision + tpr > 0 else 0.0
    return {
        "alert_rate": alert, "precision": precision, "recall": tpr, "f1": f1, "fpr": fpr,
        "alert_over_budget": alert / cell["nominal"],
    }  # fmt: skip


def x_shifted__mutmut_10(cell: dict[str, Any], prevalence: float) -> dict[str, float]:
    """Expected metrics of the fixed threshold of ``cell`` at a population with this prevalence."""
    if not 0.0 < prevalence < 1.0:
        raise ValueError("prevalence must be in (0, 1)")
    positives, negatives = cell["tp"] - cell["fn"], cell["fp"] + cell["tn"]
    if positives <= 0 or negatives <= 0:
        raise ValueError("a cell needs held-out positives and negatives")
    tpr, fpr = cell["tp"] / positives, cell["fp"] / negatives
    alert = prevalence * tpr + (1 - prevalence) * fpr
    precision = prevalence * tpr / alert if alert > 0 else 0.0
    f1 = 2 * precision * tpr / (precision + tpr) if precision + tpr > 0 else 0.0
    return {
        "alert_rate": alert, "precision": precision, "recall": tpr, "f1": f1, "fpr": fpr,
        "alert_over_budget": alert / cell["nominal"],
    }  # fmt: skip


def x_shifted__mutmut_11(cell: dict[str, Any], prevalence: float) -> dict[str, float]:
    """Expected metrics of the fixed threshold of ``cell`` at a population with this prevalence."""
    if not 0.0 < prevalence < 1.0:
        raise ValueError("prevalence must be in (0, 1)")
    positives, negatives = cell["XXtpXX"] + cell["fn"], cell["fp"] + cell["tn"]
    if positives <= 0 or negatives <= 0:
        raise ValueError("a cell needs held-out positives and negatives")
    tpr, fpr = cell["tp"] / positives, cell["fp"] / negatives
    alert = prevalence * tpr + (1 - prevalence) * fpr
    precision = prevalence * tpr / alert if alert > 0 else 0.0
    f1 = 2 * precision * tpr / (precision + tpr) if precision + tpr > 0 else 0.0
    return {
        "alert_rate": alert, "precision": precision, "recall": tpr, "f1": f1, "fpr": fpr,
        "alert_over_budget": alert / cell["nominal"],
    }  # fmt: skip


def x_shifted__mutmut_12(cell: dict[str, Any], prevalence: float) -> dict[str, float]:
    """Expected metrics of the fixed threshold of ``cell`` at a population with this prevalence."""
    if not 0.0 < prevalence < 1.0:
        raise ValueError("prevalence must be in (0, 1)")
    positives, negatives = cell["TP"] + cell["fn"], cell["fp"] + cell["tn"]
    if positives <= 0 or negatives <= 0:
        raise ValueError("a cell needs held-out positives and negatives")
    tpr, fpr = cell["tp"] / positives, cell["fp"] / negatives
    alert = prevalence * tpr + (1 - prevalence) * fpr
    precision = prevalence * tpr / alert if alert > 0 else 0.0
    f1 = 2 * precision * tpr / (precision + tpr) if precision + tpr > 0 else 0.0
    return {
        "alert_rate": alert, "precision": precision, "recall": tpr, "f1": f1, "fpr": fpr,
        "alert_over_budget": alert / cell["nominal"],
    }  # fmt: skip


def x_shifted__mutmut_13(cell: dict[str, Any], prevalence: float) -> dict[str, float]:
    """Expected metrics of the fixed threshold of ``cell`` at a population with this prevalence."""
    if not 0.0 < prevalence < 1.0:
        raise ValueError("prevalence must be in (0, 1)")
    positives, negatives = cell["tp"] + cell["XXfnXX"], cell["fp"] + cell["tn"]
    if positives <= 0 or negatives <= 0:
        raise ValueError("a cell needs held-out positives and negatives")
    tpr, fpr = cell["tp"] / positives, cell["fp"] / negatives
    alert = prevalence * tpr + (1 - prevalence) * fpr
    precision = prevalence * tpr / alert if alert > 0 else 0.0
    f1 = 2 * precision * tpr / (precision + tpr) if precision + tpr > 0 else 0.0
    return {
        "alert_rate": alert, "precision": precision, "recall": tpr, "f1": f1, "fpr": fpr,
        "alert_over_budget": alert / cell["nominal"],
    }  # fmt: skip


def x_shifted__mutmut_14(cell: dict[str, Any], prevalence: float) -> dict[str, float]:
    """Expected metrics of the fixed threshold of ``cell`` at a population with this prevalence."""
    if not 0.0 < prevalence < 1.0:
        raise ValueError("prevalence must be in (0, 1)")
    positives, negatives = cell["tp"] + cell["FN"], cell["fp"] + cell["tn"]
    if positives <= 0 or negatives <= 0:
        raise ValueError("a cell needs held-out positives and negatives")
    tpr, fpr = cell["tp"] / positives, cell["fp"] / negatives
    alert = prevalence * tpr + (1 - prevalence) * fpr
    precision = prevalence * tpr / alert if alert > 0 else 0.0
    f1 = 2 * precision * tpr / (precision + tpr) if precision + tpr > 0 else 0.0
    return {
        "alert_rate": alert, "precision": precision, "recall": tpr, "f1": f1, "fpr": fpr,
        "alert_over_budget": alert / cell["nominal"],
    }  # fmt: skip


def x_shifted__mutmut_15(cell: dict[str, Any], prevalence: float) -> dict[str, float]:
    """Expected metrics of the fixed threshold of ``cell`` at a population with this prevalence."""
    if not 0.0 < prevalence < 1.0:
        raise ValueError("prevalence must be in (0, 1)")
    positives, negatives = cell["tp"] + cell["fn"], cell["fp"] - cell["tn"]
    if positives <= 0 or negatives <= 0:
        raise ValueError("a cell needs held-out positives and negatives")
    tpr, fpr = cell["tp"] / positives, cell["fp"] / negatives
    alert = prevalence * tpr + (1 - prevalence) * fpr
    precision = prevalence * tpr / alert if alert > 0 else 0.0
    f1 = 2 * precision * tpr / (precision + tpr) if precision + tpr > 0 else 0.0
    return {
        "alert_rate": alert, "precision": precision, "recall": tpr, "f1": f1, "fpr": fpr,
        "alert_over_budget": alert / cell["nominal"],
    }  # fmt: skip


def x_shifted__mutmut_16(cell: dict[str, Any], prevalence: float) -> dict[str, float]:
    """Expected metrics of the fixed threshold of ``cell`` at a population with this prevalence."""
    if not 0.0 < prevalence < 1.0:
        raise ValueError("prevalence must be in (0, 1)")
    positives, negatives = cell["tp"] + cell["fn"], cell["XXfpXX"] + cell["tn"]
    if positives <= 0 or negatives <= 0:
        raise ValueError("a cell needs held-out positives and negatives")
    tpr, fpr = cell["tp"] / positives, cell["fp"] / negatives
    alert = prevalence * tpr + (1 - prevalence) * fpr
    precision = prevalence * tpr / alert if alert > 0 else 0.0
    f1 = 2 * precision * tpr / (precision + tpr) if precision + tpr > 0 else 0.0
    return {
        "alert_rate": alert, "precision": precision, "recall": tpr, "f1": f1, "fpr": fpr,
        "alert_over_budget": alert / cell["nominal"],
    }  # fmt: skip


def x_shifted__mutmut_17(cell: dict[str, Any], prevalence: float) -> dict[str, float]:
    """Expected metrics of the fixed threshold of ``cell`` at a population with this prevalence."""
    if not 0.0 < prevalence < 1.0:
        raise ValueError("prevalence must be in (0, 1)")
    positives, negatives = cell["tp"] + cell["fn"], cell["FP"] + cell["tn"]
    if positives <= 0 or negatives <= 0:
        raise ValueError("a cell needs held-out positives and negatives")
    tpr, fpr = cell["tp"] / positives, cell["fp"] / negatives
    alert = prevalence * tpr + (1 - prevalence) * fpr
    precision = prevalence * tpr / alert if alert > 0 else 0.0
    f1 = 2 * precision * tpr / (precision + tpr) if precision + tpr > 0 else 0.0
    return {
        "alert_rate": alert, "precision": precision, "recall": tpr, "f1": f1, "fpr": fpr,
        "alert_over_budget": alert / cell["nominal"],
    }  # fmt: skip


def x_shifted__mutmut_18(cell: dict[str, Any], prevalence: float) -> dict[str, float]:
    """Expected metrics of the fixed threshold of ``cell`` at a population with this prevalence."""
    if not 0.0 < prevalence < 1.0:
        raise ValueError("prevalence must be in (0, 1)")
    positives, negatives = cell["tp"] + cell["fn"], cell["fp"] + cell["XXtnXX"]
    if positives <= 0 or negatives <= 0:
        raise ValueError("a cell needs held-out positives and negatives")
    tpr, fpr = cell["tp"] / positives, cell["fp"] / negatives
    alert = prevalence * tpr + (1 - prevalence) * fpr
    precision = prevalence * tpr / alert if alert > 0 else 0.0
    f1 = 2 * precision * tpr / (precision + tpr) if precision + tpr > 0 else 0.0
    return {
        "alert_rate": alert, "precision": precision, "recall": tpr, "f1": f1, "fpr": fpr,
        "alert_over_budget": alert / cell["nominal"],
    }  # fmt: skip


def x_shifted__mutmut_19(cell: dict[str, Any], prevalence: float) -> dict[str, float]:
    """Expected metrics of the fixed threshold of ``cell`` at a population with this prevalence."""
    if not 0.0 < prevalence < 1.0:
        raise ValueError("prevalence must be in (0, 1)")
    positives, negatives = cell["tp"] + cell["fn"], cell["fp"] + cell["TN"]
    if positives <= 0 or negatives <= 0:
        raise ValueError("a cell needs held-out positives and negatives")
    tpr, fpr = cell["tp"] / positives, cell["fp"] / negatives
    alert = prevalence * tpr + (1 - prevalence) * fpr
    precision = prevalence * tpr / alert if alert > 0 else 0.0
    f1 = 2 * precision * tpr / (precision + tpr) if precision + tpr > 0 else 0.0
    return {
        "alert_rate": alert, "precision": precision, "recall": tpr, "f1": f1, "fpr": fpr,
        "alert_over_budget": alert / cell["nominal"],
    }  # fmt: skip


def x_shifted__mutmut_20(cell: dict[str, Any], prevalence: float) -> dict[str, float]:
    """Expected metrics of the fixed threshold of ``cell`` at a population with this prevalence."""
    if not 0.0 < prevalence < 1.0:
        raise ValueError("prevalence must be in (0, 1)")
    positives, negatives = cell["tp"] + cell["fn"], cell["fp"] + cell["tn"]
    if positives <= 0 and negatives <= 0:
        raise ValueError("a cell needs held-out positives and negatives")
    tpr, fpr = cell["tp"] / positives, cell["fp"] / negatives
    alert = prevalence * tpr + (1 - prevalence) * fpr
    precision = prevalence * tpr / alert if alert > 0 else 0.0
    f1 = 2 * precision * tpr / (precision + tpr) if precision + tpr > 0 else 0.0
    return {
        "alert_rate": alert, "precision": precision, "recall": tpr, "f1": f1, "fpr": fpr,
        "alert_over_budget": alert / cell["nominal"],
    }  # fmt: skip


def x_shifted__mutmut_21(cell: dict[str, Any], prevalence: float) -> dict[str, float]:
    """Expected metrics of the fixed threshold of ``cell`` at a population with this prevalence."""
    if not 0.0 < prevalence < 1.0:
        raise ValueError("prevalence must be in (0, 1)")
    positives, negatives = cell["tp"] + cell["fn"], cell["fp"] + cell["tn"]
    if positives < 0 or negatives <= 0:
        raise ValueError("a cell needs held-out positives and negatives")
    tpr, fpr = cell["tp"] / positives, cell["fp"] / negatives
    alert = prevalence * tpr + (1 - prevalence) * fpr
    precision = prevalence * tpr / alert if alert > 0 else 0.0
    f1 = 2 * precision * tpr / (precision + tpr) if precision + tpr > 0 else 0.0
    return {
        "alert_rate": alert, "precision": precision, "recall": tpr, "f1": f1, "fpr": fpr,
        "alert_over_budget": alert / cell["nominal"],
    }  # fmt: skip


def x_shifted__mutmut_22(cell: dict[str, Any], prevalence: float) -> dict[str, float]:
    """Expected metrics of the fixed threshold of ``cell`` at a population with this prevalence."""
    if not 0.0 < prevalence < 1.0:
        raise ValueError("prevalence must be in (0, 1)")
    positives, negatives = cell["tp"] + cell["fn"], cell["fp"] + cell["tn"]
    if positives <= 1 or negatives <= 0:
        raise ValueError("a cell needs held-out positives and negatives")
    tpr, fpr = cell["tp"] / positives, cell["fp"] / negatives
    alert = prevalence * tpr + (1 - prevalence) * fpr
    precision = prevalence * tpr / alert if alert > 0 else 0.0
    f1 = 2 * precision * tpr / (precision + tpr) if precision + tpr > 0 else 0.0
    return {
        "alert_rate": alert, "precision": precision, "recall": tpr, "f1": f1, "fpr": fpr,
        "alert_over_budget": alert / cell["nominal"],
    }  # fmt: skip


def x_shifted__mutmut_23(cell: dict[str, Any], prevalence: float) -> dict[str, float]:
    """Expected metrics of the fixed threshold of ``cell`` at a population with this prevalence."""
    if not 0.0 < prevalence < 1.0:
        raise ValueError("prevalence must be in (0, 1)")
    positives, negatives = cell["tp"] + cell["fn"], cell["fp"] + cell["tn"]
    if positives <= 0 or negatives < 0:
        raise ValueError("a cell needs held-out positives and negatives")
    tpr, fpr = cell["tp"] / positives, cell["fp"] / negatives
    alert = prevalence * tpr + (1 - prevalence) * fpr
    precision = prevalence * tpr / alert if alert > 0 else 0.0
    f1 = 2 * precision * tpr / (precision + tpr) if precision + tpr > 0 else 0.0
    return {
        "alert_rate": alert, "precision": precision, "recall": tpr, "f1": f1, "fpr": fpr,
        "alert_over_budget": alert / cell["nominal"],
    }  # fmt: skip


def x_shifted__mutmut_24(cell: dict[str, Any], prevalence: float) -> dict[str, float]:
    """Expected metrics of the fixed threshold of ``cell`` at a population with this prevalence."""
    if not 0.0 < prevalence < 1.0:
        raise ValueError("prevalence must be in (0, 1)")
    positives, negatives = cell["tp"] + cell["fn"], cell["fp"] + cell["tn"]
    if positives <= 0 or negatives <= 1:
        raise ValueError("a cell needs held-out positives and negatives")
    tpr, fpr = cell["tp"] / positives, cell["fp"] / negatives
    alert = prevalence * tpr + (1 - prevalence) * fpr
    precision = prevalence * tpr / alert if alert > 0 else 0.0
    f1 = 2 * precision * tpr / (precision + tpr) if precision + tpr > 0 else 0.0
    return {
        "alert_rate": alert, "precision": precision, "recall": tpr, "f1": f1, "fpr": fpr,
        "alert_over_budget": alert / cell["nominal"],
    }  # fmt: skip


def x_shifted__mutmut_25(cell: dict[str, Any], prevalence: float) -> dict[str, float]:
    """Expected metrics of the fixed threshold of ``cell`` at a population with this prevalence."""
    if not 0.0 < prevalence < 1.0:
        raise ValueError("prevalence must be in (0, 1)")
    positives, negatives = cell["tp"] + cell["fn"], cell["fp"] + cell["tn"]
    if positives <= 0 or negatives <= 0:
        raise ValueError(None)
    tpr, fpr = cell["tp"] / positives, cell["fp"] / negatives
    alert = prevalence * tpr + (1 - prevalence) * fpr
    precision = prevalence * tpr / alert if alert > 0 else 0.0
    f1 = 2 * precision * tpr / (precision + tpr) if precision + tpr > 0 else 0.0
    return {
        "alert_rate": alert, "precision": precision, "recall": tpr, "f1": f1, "fpr": fpr,
        "alert_over_budget": alert / cell["nominal"],
    }  # fmt: skip


def x_shifted__mutmut_26(cell: dict[str, Any], prevalence: float) -> dict[str, float]:
    """Expected metrics of the fixed threshold of ``cell`` at a population with this prevalence."""
    if not 0.0 < prevalence < 1.0:
        raise ValueError("prevalence must be in (0, 1)")
    positives, negatives = cell["tp"] + cell["fn"], cell["fp"] + cell["tn"]
    if positives <= 0 or negatives <= 0:
        raise ValueError("XXa cell needs held-out positives and negativesXX")
    tpr, fpr = cell["tp"] / positives, cell["fp"] / negatives
    alert = prevalence * tpr + (1 - prevalence) * fpr
    precision = prevalence * tpr / alert if alert > 0 else 0.0
    f1 = 2 * precision * tpr / (precision + tpr) if precision + tpr > 0 else 0.0
    return {
        "alert_rate": alert, "precision": precision, "recall": tpr, "f1": f1, "fpr": fpr,
        "alert_over_budget": alert / cell["nominal"],
    }  # fmt: skip


def x_shifted__mutmut_27(cell: dict[str, Any], prevalence: float) -> dict[str, float]:
    """Expected metrics of the fixed threshold of ``cell`` at a population with this prevalence."""
    if not 0.0 < prevalence < 1.0:
        raise ValueError("prevalence must be in (0, 1)")
    positives, negatives = cell["tp"] + cell["fn"], cell["fp"] + cell["tn"]
    if positives <= 0 or negatives <= 0:
        raise ValueError("A CELL NEEDS HELD-OUT POSITIVES AND NEGATIVES")
    tpr, fpr = cell["tp"] / positives, cell["fp"] / negatives
    alert = prevalence * tpr + (1 - prevalence) * fpr
    precision = prevalence * tpr / alert if alert > 0 else 0.0
    f1 = 2 * precision * tpr / (precision + tpr) if precision + tpr > 0 else 0.0
    return {
        "alert_rate": alert, "precision": precision, "recall": tpr, "f1": f1, "fpr": fpr,
        "alert_over_budget": alert / cell["nominal"],
    }  # fmt: skip


def x_shifted__mutmut_28(cell: dict[str, Any], prevalence: float) -> dict[str, float]:
    """Expected metrics of the fixed threshold of ``cell`` at a population with this prevalence."""
    if not 0.0 < prevalence < 1.0:
        raise ValueError("prevalence must be in (0, 1)")
    positives, negatives = cell["tp"] + cell["fn"], cell["fp"] + cell["tn"]
    if positives <= 0 or negatives <= 0:
        raise ValueError("a cell needs held-out positives and negatives")
    tpr, fpr = None
    alert = prevalence * tpr + (1 - prevalence) * fpr
    precision = prevalence * tpr / alert if alert > 0 else 0.0
    f1 = 2 * precision * tpr / (precision + tpr) if precision + tpr > 0 else 0.0
    return {
        "alert_rate": alert, "precision": precision, "recall": tpr, "f1": f1, "fpr": fpr,
        "alert_over_budget": alert / cell["nominal"],
    }  # fmt: skip


def x_shifted__mutmut_29(cell: dict[str, Any], prevalence: float) -> dict[str, float]:
    """Expected metrics of the fixed threshold of ``cell`` at a population with this prevalence."""
    if not 0.0 < prevalence < 1.0:
        raise ValueError("prevalence must be in (0, 1)")
    positives, negatives = cell["tp"] + cell["fn"], cell["fp"] + cell["tn"]
    if positives <= 0 or negatives <= 0:
        raise ValueError("a cell needs held-out positives and negatives")
    tpr, fpr = cell["tp"] * positives, cell["fp"] / negatives
    alert = prevalence * tpr + (1 - prevalence) * fpr
    precision = prevalence * tpr / alert if alert > 0 else 0.0
    f1 = 2 * precision * tpr / (precision + tpr) if precision + tpr > 0 else 0.0
    return {
        "alert_rate": alert, "precision": precision, "recall": tpr, "f1": f1, "fpr": fpr,
        "alert_over_budget": alert / cell["nominal"],
    }  # fmt: skip


def x_shifted__mutmut_30(cell: dict[str, Any], prevalence: float) -> dict[str, float]:
    """Expected metrics of the fixed threshold of ``cell`` at a population with this prevalence."""
    if not 0.0 < prevalence < 1.0:
        raise ValueError("prevalence must be in (0, 1)")
    positives, negatives = cell["tp"] + cell["fn"], cell["fp"] + cell["tn"]
    if positives <= 0 or negatives <= 0:
        raise ValueError("a cell needs held-out positives and negatives")
    tpr, fpr = cell["XXtpXX"] / positives, cell["fp"] / negatives
    alert = prevalence * tpr + (1 - prevalence) * fpr
    precision = prevalence * tpr / alert if alert > 0 else 0.0
    f1 = 2 * precision * tpr / (precision + tpr) if precision + tpr > 0 else 0.0
    return {
        "alert_rate": alert, "precision": precision, "recall": tpr, "f1": f1, "fpr": fpr,
        "alert_over_budget": alert / cell["nominal"],
    }  # fmt: skip


def x_shifted__mutmut_31(cell: dict[str, Any], prevalence: float) -> dict[str, float]:
    """Expected metrics of the fixed threshold of ``cell`` at a population with this prevalence."""
    if not 0.0 < prevalence < 1.0:
        raise ValueError("prevalence must be in (0, 1)")
    positives, negatives = cell["tp"] + cell["fn"], cell["fp"] + cell["tn"]
    if positives <= 0 or negatives <= 0:
        raise ValueError("a cell needs held-out positives and negatives")
    tpr, fpr = cell["TP"] / positives, cell["fp"] / negatives
    alert = prevalence * tpr + (1 - prevalence) * fpr
    precision = prevalence * tpr / alert if alert > 0 else 0.0
    f1 = 2 * precision * tpr / (precision + tpr) if precision + tpr > 0 else 0.0
    return {
        "alert_rate": alert, "precision": precision, "recall": tpr, "f1": f1, "fpr": fpr,
        "alert_over_budget": alert / cell["nominal"],
    }  # fmt: skip


def x_shifted__mutmut_32(cell: dict[str, Any], prevalence: float) -> dict[str, float]:
    """Expected metrics of the fixed threshold of ``cell`` at a population with this prevalence."""
    if not 0.0 < prevalence < 1.0:
        raise ValueError("prevalence must be in (0, 1)")
    positives, negatives = cell["tp"] + cell["fn"], cell["fp"] + cell["tn"]
    if positives <= 0 or negatives <= 0:
        raise ValueError("a cell needs held-out positives and negatives")
    tpr, fpr = cell["tp"] / positives, cell["fp"] * negatives
    alert = prevalence * tpr + (1 - prevalence) * fpr
    precision = prevalence * tpr / alert if alert > 0 else 0.0
    f1 = 2 * precision * tpr / (precision + tpr) if precision + tpr > 0 else 0.0
    return {
        "alert_rate": alert, "precision": precision, "recall": tpr, "f1": f1, "fpr": fpr,
        "alert_over_budget": alert / cell["nominal"],
    }  # fmt: skip


def x_shifted__mutmut_33(cell: dict[str, Any], prevalence: float) -> dict[str, float]:
    """Expected metrics of the fixed threshold of ``cell`` at a population with this prevalence."""
    if not 0.0 < prevalence < 1.0:
        raise ValueError("prevalence must be in (0, 1)")
    positives, negatives = cell["tp"] + cell["fn"], cell["fp"] + cell["tn"]
    if positives <= 0 or negatives <= 0:
        raise ValueError("a cell needs held-out positives and negatives")
    tpr, fpr = cell["tp"] / positives, cell["XXfpXX"] / negatives
    alert = prevalence * tpr + (1 - prevalence) * fpr
    precision = prevalence * tpr / alert if alert > 0 else 0.0
    f1 = 2 * precision * tpr / (precision + tpr) if precision + tpr > 0 else 0.0
    return {
        "alert_rate": alert, "precision": precision, "recall": tpr, "f1": f1, "fpr": fpr,
        "alert_over_budget": alert / cell["nominal"],
    }  # fmt: skip


def x_shifted__mutmut_34(cell: dict[str, Any], prevalence: float) -> dict[str, float]:
    """Expected metrics of the fixed threshold of ``cell`` at a population with this prevalence."""
    if not 0.0 < prevalence < 1.0:
        raise ValueError("prevalence must be in (0, 1)")
    positives, negatives = cell["tp"] + cell["fn"], cell["fp"] + cell["tn"]
    if positives <= 0 or negatives <= 0:
        raise ValueError("a cell needs held-out positives and negatives")
    tpr, fpr = cell["tp"] / positives, cell["FP"] / negatives
    alert = prevalence * tpr + (1 - prevalence) * fpr
    precision = prevalence * tpr / alert if alert > 0 else 0.0
    f1 = 2 * precision * tpr / (precision + tpr) if precision + tpr > 0 else 0.0
    return {
        "alert_rate": alert, "precision": precision, "recall": tpr, "f1": f1, "fpr": fpr,
        "alert_over_budget": alert / cell["nominal"],
    }  # fmt: skip


def x_shifted__mutmut_35(cell: dict[str, Any], prevalence: float) -> dict[str, float]:
    """Expected metrics of the fixed threshold of ``cell`` at a population with this prevalence."""
    if not 0.0 < prevalence < 1.0:
        raise ValueError("prevalence must be in (0, 1)")
    positives, negatives = cell["tp"] + cell["fn"], cell["fp"] + cell["tn"]
    if positives <= 0 or negatives <= 0:
        raise ValueError("a cell needs held-out positives and negatives")
    tpr, fpr = cell["tp"] / positives, cell["fp"] / negatives
    alert = None
    precision = prevalence * tpr / alert if alert > 0 else 0.0
    f1 = 2 * precision * tpr / (precision + tpr) if precision + tpr > 0 else 0.0
    return {
        "alert_rate": alert, "precision": precision, "recall": tpr, "f1": f1, "fpr": fpr,
        "alert_over_budget": alert / cell["nominal"],
    }  # fmt: skip


def x_shifted__mutmut_36(cell: dict[str, Any], prevalence: float) -> dict[str, float]:
    """Expected metrics of the fixed threshold of ``cell`` at a population with this prevalence."""
    if not 0.0 < prevalence < 1.0:
        raise ValueError("prevalence must be in (0, 1)")
    positives, negatives = cell["tp"] + cell["fn"], cell["fp"] + cell["tn"]
    if positives <= 0 or negatives <= 0:
        raise ValueError("a cell needs held-out positives and negatives")
    tpr, fpr = cell["tp"] / positives, cell["fp"] / negatives
    alert = prevalence * tpr - (1 - prevalence) * fpr
    precision = prevalence * tpr / alert if alert > 0 else 0.0
    f1 = 2 * precision * tpr / (precision + tpr) if precision + tpr > 0 else 0.0
    return {
        "alert_rate": alert, "precision": precision, "recall": tpr, "f1": f1, "fpr": fpr,
        "alert_over_budget": alert / cell["nominal"],
    }  # fmt: skip


def x_shifted__mutmut_37(cell: dict[str, Any], prevalence: float) -> dict[str, float]:
    """Expected metrics of the fixed threshold of ``cell`` at a population with this prevalence."""
    if not 0.0 < prevalence < 1.0:
        raise ValueError("prevalence must be in (0, 1)")
    positives, negatives = cell["tp"] + cell["fn"], cell["fp"] + cell["tn"]
    if positives <= 0 or negatives <= 0:
        raise ValueError("a cell needs held-out positives and negatives")
    tpr, fpr = cell["tp"] / positives, cell["fp"] / negatives
    alert = prevalence / tpr + (1 - prevalence) * fpr
    precision = prevalence * tpr / alert if alert > 0 else 0.0
    f1 = 2 * precision * tpr / (precision + tpr) if precision + tpr > 0 else 0.0
    return {
        "alert_rate": alert, "precision": precision, "recall": tpr, "f1": f1, "fpr": fpr,
        "alert_over_budget": alert / cell["nominal"],
    }  # fmt: skip


def x_shifted__mutmut_38(cell: dict[str, Any], prevalence: float) -> dict[str, float]:
    """Expected metrics of the fixed threshold of ``cell`` at a population with this prevalence."""
    if not 0.0 < prevalence < 1.0:
        raise ValueError("prevalence must be in (0, 1)")
    positives, negatives = cell["tp"] + cell["fn"], cell["fp"] + cell["tn"]
    if positives <= 0 or negatives <= 0:
        raise ValueError("a cell needs held-out positives and negatives")
    tpr, fpr = cell["tp"] / positives, cell["fp"] / negatives
    alert = prevalence * tpr + (1 - prevalence) / fpr
    precision = prevalence * tpr / alert if alert > 0 else 0.0
    f1 = 2 * precision * tpr / (precision + tpr) if precision + tpr > 0 else 0.0
    return {
        "alert_rate": alert, "precision": precision, "recall": tpr, "f1": f1, "fpr": fpr,
        "alert_over_budget": alert / cell["nominal"],
    }  # fmt: skip


def x_shifted__mutmut_39(cell: dict[str, Any], prevalence: float) -> dict[str, float]:
    """Expected metrics of the fixed threshold of ``cell`` at a population with this prevalence."""
    if not 0.0 < prevalence < 1.0:
        raise ValueError("prevalence must be in (0, 1)")
    positives, negatives = cell["tp"] + cell["fn"], cell["fp"] + cell["tn"]
    if positives <= 0 or negatives <= 0:
        raise ValueError("a cell needs held-out positives and negatives")
    tpr, fpr = cell["tp"] / positives, cell["fp"] / negatives
    alert = prevalence * tpr + (1 + prevalence) * fpr
    precision = prevalence * tpr / alert if alert > 0 else 0.0
    f1 = 2 * precision * tpr / (precision + tpr) if precision + tpr > 0 else 0.0
    return {
        "alert_rate": alert, "precision": precision, "recall": tpr, "f1": f1, "fpr": fpr,
        "alert_over_budget": alert / cell["nominal"],
    }  # fmt: skip


def x_shifted__mutmut_40(cell: dict[str, Any], prevalence: float) -> dict[str, float]:
    """Expected metrics of the fixed threshold of ``cell`` at a population with this prevalence."""
    if not 0.0 < prevalence < 1.0:
        raise ValueError("prevalence must be in (0, 1)")
    positives, negatives = cell["tp"] + cell["fn"], cell["fp"] + cell["tn"]
    if positives <= 0 or negatives <= 0:
        raise ValueError("a cell needs held-out positives and negatives")
    tpr, fpr = cell["tp"] / positives, cell["fp"] / negatives
    alert = prevalence * tpr + (2 - prevalence) * fpr
    precision = prevalence * tpr / alert if alert > 0 else 0.0
    f1 = 2 * precision * tpr / (precision + tpr) if precision + tpr > 0 else 0.0
    return {
        "alert_rate": alert, "precision": precision, "recall": tpr, "f1": f1, "fpr": fpr,
        "alert_over_budget": alert / cell["nominal"],
    }  # fmt: skip


def x_shifted__mutmut_41(cell: dict[str, Any], prevalence: float) -> dict[str, float]:
    """Expected metrics of the fixed threshold of ``cell`` at a population with this prevalence."""
    if not 0.0 < prevalence < 1.0:
        raise ValueError("prevalence must be in (0, 1)")
    positives, negatives = cell["tp"] + cell["fn"], cell["fp"] + cell["tn"]
    if positives <= 0 or negatives <= 0:
        raise ValueError("a cell needs held-out positives and negatives")
    tpr, fpr = cell["tp"] / positives, cell["fp"] / negatives
    alert = prevalence * tpr + (1 - prevalence) * fpr
    precision = None
    f1 = 2 * precision * tpr / (precision + tpr) if precision + tpr > 0 else 0.0
    return {
        "alert_rate": alert, "precision": precision, "recall": tpr, "f1": f1, "fpr": fpr,
        "alert_over_budget": alert / cell["nominal"],
    }  # fmt: skip


def x_shifted__mutmut_42(cell: dict[str, Any], prevalence: float) -> dict[str, float]:
    """Expected metrics of the fixed threshold of ``cell`` at a population with this prevalence."""
    if not 0.0 < prevalence < 1.0:
        raise ValueError("prevalence must be in (0, 1)")
    positives, negatives = cell["tp"] + cell["fn"], cell["fp"] + cell["tn"]
    if positives <= 0 or negatives <= 0:
        raise ValueError("a cell needs held-out positives and negatives")
    tpr, fpr = cell["tp"] / positives, cell["fp"] / negatives
    alert = prevalence * tpr + (1 - prevalence) * fpr
    precision = prevalence * tpr / alert if (alert > 0) and False else 0.0
    f1 = 2 * precision * tpr / (precision + tpr) if precision + tpr > 0 else 0.0
    return {
        "alert_rate": alert, "precision": precision, "recall": tpr, "f1": f1, "fpr": fpr,
        "alert_over_budget": alert / cell["nominal"],
    }  # fmt: skip


def x_shifted__mutmut_43(cell: dict[str, Any], prevalence: float) -> dict[str, float]:
    """Expected metrics of the fixed threshold of ``cell`` at a population with this prevalence."""
    if not 0.0 < prevalence < 1.0:
        raise ValueError("prevalence must be in (0, 1)")
    positives, negatives = cell["tp"] + cell["fn"], cell["fp"] + cell["tn"]
    if positives <= 0 or negatives <= 0:
        raise ValueError("a cell needs held-out positives and negatives")
    tpr, fpr = cell["tp"] / positives, cell["fp"] / negatives
    alert = prevalence * tpr + (1 - prevalence) * fpr
    precision = prevalence * tpr / alert if (alert > 0) or True else 0.0
    f1 = 2 * precision * tpr / (precision + tpr) if precision + tpr > 0 else 0.0
    return {
        "alert_rate": alert, "precision": precision, "recall": tpr, "f1": f1, "fpr": fpr,
        "alert_over_budget": alert / cell["nominal"],
    }  # fmt: skip


def x_shifted__mutmut_44(cell: dict[str, Any], prevalence: float) -> dict[str, float]:
    """Expected metrics of the fixed threshold of ``cell`` at a population with this prevalence."""
    if not 0.0 < prevalence < 1.0:
        raise ValueError("prevalence must be in (0, 1)")
    positives, negatives = cell["tp"] + cell["fn"], cell["fp"] + cell["tn"]
    if positives <= 0 or negatives <= 0:
        raise ValueError("a cell needs held-out positives and negatives")
    tpr, fpr = cell["tp"] / positives, cell["fp"] / negatives
    alert = prevalence * tpr + (1 - prevalence) * fpr
    precision = prevalence * tpr * alert if alert > 0 else 0.0
    f1 = 2 * precision * tpr / (precision + tpr) if precision + tpr > 0 else 0.0
    return {
        "alert_rate": alert, "precision": precision, "recall": tpr, "f1": f1, "fpr": fpr,
        "alert_over_budget": alert / cell["nominal"],
    }  # fmt: skip


def x_shifted__mutmut_45(cell: dict[str, Any], prevalence: float) -> dict[str, float]:
    """Expected metrics of the fixed threshold of ``cell`` at a population with this prevalence."""
    if not 0.0 < prevalence < 1.0:
        raise ValueError("prevalence must be in (0, 1)")
    positives, negatives = cell["tp"] + cell["fn"], cell["fp"] + cell["tn"]
    if positives <= 0 or negatives <= 0:
        raise ValueError("a cell needs held-out positives and negatives")
    tpr, fpr = cell["tp"] / positives, cell["fp"] / negatives
    alert = prevalence * tpr + (1 - prevalence) * fpr
    precision = prevalence / tpr / alert if alert > 0 else 0.0
    f1 = 2 * precision * tpr / (precision + tpr) if precision + tpr > 0 else 0.0
    return {
        "alert_rate": alert, "precision": precision, "recall": tpr, "f1": f1, "fpr": fpr,
        "alert_over_budget": alert / cell["nominal"],
    }  # fmt: skip


def x_shifted__mutmut_46(cell: dict[str, Any], prevalence: float) -> dict[str, float]:
    """Expected metrics of the fixed threshold of ``cell`` at a population with this prevalence."""
    if not 0.0 < prevalence < 1.0:
        raise ValueError("prevalence must be in (0, 1)")
    positives, negatives = cell["tp"] + cell["fn"], cell["fp"] + cell["tn"]
    if positives <= 0 or negatives <= 0:
        raise ValueError("a cell needs held-out positives and negatives")
    tpr, fpr = cell["tp"] / positives, cell["fp"] / negatives
    alert = prevalence * tpr + (1 - prevalence) * fpr
    precision = prevalence * tpr / alert if alert >= 0 else 0.0
    f1 = 2 * precision * tpr / (precision + tpr) if precision + tpr > 0 else 0.0
    return {
        "alert_rate": alert, "precision": precision, "recall": tpr, "f1": f1, "fpr": fpr,
        "alert_over_budget": alert / cell["nominal"],
    }  # fmt: skip


def x_shifted__mutmut_47(cell: dict[str, Any], prevalence: float) -> dict[str, float]:
    """Expected metrics of the fixed threshold of ``cell`` at a population with this prevalence."""
    if not 0.0 < prevalence < 1.0:
        raise ValueError("prevalence must be in (0, 1)")
    positives, negatives = cell["tp"] + cell["fn"], cell["fp"] + cell["tn"]
    if positives <= 0 or negatives <= 0:
        raise ValueError("a cell needs held-out positives and negatives")
    tpr, fpr = cell["tp"] / positives, cell["fp"] / negatives
    alert = prevalence * tpr + (1 - prevalence) * fpr
    precision = prevalence * tpr / alert if alert > 1 else 0.0
    f1 = 2 * precision * tpr / (precision + tpr) if precision + tpr > 0 else 0.0
    return {
        "alert_rate": alert, "precision": precision, "recall": tpr, "f1": f1, "fpr": fpr,
        "alert_over_budget": alert / cell["nominal"],
    }  # fmt: skip


def x_shifted__mutmut_48(cell: dict[str, Any], prevalence: float) -> dict[str, float]:
    """Expected metrics of the fixed threshold of ``cell`` at a population with this prevalence."""
    if not 0.0 < prevalence < 1.0:
        raise ValueError("prevalence must be in (0, 1)")
    positives, negatives = cell["tp"] + cell["fn"], cell["fp"] + cell["tn"]
    if positives <= 0 or negatives <= 0:
        raise ValueError("a cell needs held-out positives and negatives")
    tpr, fpr = cell["tp"] / positives, cell["fp"] / negatives
    alert = prevalence * tpr + (1 - prevalence) * fpr
    precision = prevalence * tpr / alert if alert > 0 else 1.0
    f1 = 2 * precision * tpr / (precision + tpr) if precision + tpr > 0 else 0.0
    return {
        "alert_rate": alert, "precision": precision, "recall": tpr, "f1": f1, "fpr": fpr,
        "alert_over_budget": alert / cell["nominal"],
    }  # fmt: skip


def x_shifted__mutmut_49(cell: dict[str, Any], prevalence: float) -> dict[str, float]:
    """Expected metrics of the fixed threshold of ``cell`` at a population with this prevalence."""
    if not 0.0 < prevalence < 1.0:
        raise ValueError("prevalence must be in (0, 1)")
    positives, negatives = cell["tp"] + cell["fn"], cell["fp"] + cell["tn"]
    if positives <= 0 or negatives <= 0:
        raise ValueError("a cell needs held-out positives and negatives")
    tpr, fpr = cell["tp"] / positives, cell["fp"] / negatives
    alert = prevalence * tpr + (1 - prevalence) * fpr
    precision = prevalence * tpr / alert if alert > 0 else 0.0
    f1 = None
    return {
        "alert_rate": alert, "precision": precision, "recall": tpr, "f1": f1, "fpr": fpr,
        "alert_over_budget": alert / cell["nominal"],
    }  # fmt: skip


def x_shifted__mutmut_50(cell: dict[str, Any], prevalence: float) -> dict[str, float]:
    """Expected metrics of the fixed threshold of ``cell`` at a population with this prevalence."""
    if not 0.0 < prevalence < 1.0:
        raise ValueError("prevalence must be in (0, 1)")
    positives, negatives = cell["tp"] + cell["fn"], cell["fp"] + cell["tn"]
    if positives <= 0 or negatives <= 0:
        raise ValueError("a cell needs held-out positives and negatives")
    tpr, fpr = cell["tp"] / positives, cell["fp"] / negatives
    alert = prevalence * tpr + (1 - prevalence) * fpr
    precision = prevalence * tpr / alert if alert > 0 else 0.0
    f1 = 2 * precision * tpr / (precision + tpr) if (precision + tpr > 0) and False else 0.0
    return {
        "alert_rate": alert, "precision": precision, "recall": tpr, "f1": f1, "fpr": fpr,
        "alert_over_budget": alert / cell["nominal"],
    }  # fmt: skip


def x_shifted__mutmut_51(cell: dict[str, Any], prevalence: float) -> dict[str, float]:
    """Expected metrics of the fixed threshold of ``cell`` at a population with this prevalence."""
    if not 0.0 < prevalence < 1.0:
        raise ValueError("prevalence must be in (0, 1)")
    positives, negatives = cell["tp"] + cell["fn"], cell["fp"] + cell["tn"]
    if positives <= 0 or negatives <= 0:
        raise ValueError("a cell needs held-out positives and negatives")
    tpr, fpr = cell["tp"] / positives, cell["fp"] / negatives
    alert = prevalence * tpr + (1 - prevalence) * fpr
    precision = prevalence * tpr / alert if alert > 0 else 0.0
    f1 = 2 * precision * tpr / (precision + tpr) if (precision + tpr > 0) or True else 0.0
    return {
        "alert_rate": alert, "precision": precision, "recall": tpr, "f1": f1, "fpr": fpr,
        "alert_over_budget": alert / cell["nominal"],
    }  # fmt: skip


def x_shifted__mutmut_52(cell: dict[str, Any], prevalence: float) -> dict[str, float]:
    """Expected metrics of the fixed threshold of ``cell`` at a population with this prevalence."""
    if not 0.0 < prevalence < 1.0:
        raise ValueError("prevalence must be in (0, 1)")
    positives, negatives = cell["tp"] + cell["fn"], cell["fp"] + cell["tn"]
    if positives <= 0 or negatives <= 0:
        raise ValueError("a cell needs held-out positives and negatives")
    tpr, fpr = cell["tp"] / positives, cell["fp"] / negatives
    alert = prevalence * tpr + (1 - prevalence) * fpr
    precision = prevalence * tpr / alert if alert > 0 else 0.0
    f1 = 2 * precision * tpr * (precision + tpr) if precision + tpr > 0 else 0.0
    return {
        "alert_rate": alert, "precision": precision, "recall": tpr, "f1": f1, "fpr": fpr,
        "alert_over_budget": alert / cell["nominal"],
    }  # fmt: skip


def x_shifted__mutmut_53(cell: dict[str, Any], prevalence: float) -> dict[str, float]:
    """Expected metrics of the fixed threshold of ``cell`` at a population with this prevalence."""
    if not 0.0 < prevalence < 1.0:
        raise ValueError("prevalence must be in (0, 1)")
    positives, negatives = cell["tp"] + cell["fn"], cell["fp"] + cell["tn"]
    if positives <= 0 or negatives <= 0:
        raise ValueError("a cell needs held-out positives and negatives")
    tpr, fpr = cell["tp"] / positives, cell["fp"] / negatives
    alert = prevalence * tpr + (1 - prevalence) * fpr
    precision = prevalence * tpr / alert if alert > 0 else 0.0
    f1 = 2 * precision / tpr / (precision + tpr) if precision + tpr > 0 else 0.0
    return {
        "alert_rate": alert, "precision": precision, "recall": tpr, "f1": f1, "fpr": fpr,
        "alert_over_budget": alert / cell["nominal"],
    }  # fmt: skip


def x_shifted__mutmut_54(cell: dict[str, Any], prevalence: float) -> dict[str, float]:
    """Expected metrics of the fixed threshold of ``cell`` at a population with this prevalence."""
    if not 0.0 < prevalence < 1.0:
        raise ValueError("prevalence must be in (0, 1)")
    positives, negatives = cell["tp"] + cell["fn"], cell["fp"] + cell["tn"]
    if positives <= 0 or negatives <= 0:
        raise ValueError("a cell needs held-out positives and negatives")
    tpr, fpr = cell["tp"] / positives, cell["fp"] / negatives
    alert = prevalence * tpr + (1 - prevalence) * fpr
    precision = prevalence * tpr / alert if alert > 0 else 0.0
    f1 = 2 / precision * tpr / (precision + tpr) if precision + tpr > 0 else 0.0
    return {
        "alert_rate": alert, "precision": precision, "recall": tpr, "f1": f1, "fpr": fpr,
        "alert_over_budget": alert / cell["nominal"],
    }  # fmt: skip


def x_shifted__mutmut_55(cell: dict[str, Any], prevalence: float) -> dict[str, float]:
    """Expected metrics of the fixed threshold of ``cell`` at a population with this prevalence."""
    if not 0.0 < prevalence < 1.0:
        raise ValueError("prevalence must be in (0, 1)")
    positives, negatives = cell["tp"] + cell["fn"], cell["fp"] + cell["tn"]
    if positives <= 0 or negatives <= 0:
        raise ValueError("a cell needs held-out positives and negatives")
    tpr, fpr = cell["tp"] / positives, cell["fp"] / negatives
    alert = prevalence * tpr + (1 - prevalence) * fpr
    precision = prevalence * tpr / alert if alert > 0 else 0.0
    f1 = 3 * precision * tpr / (precision + tpr) if precision + tpr > 0 else 0.0
    return {
        "alert_rate": alert, "precision": precision, "recall": tpr, "f1": f1, "fpr": fpr,
        "alert_over_budget": alert / cell["nominal"],
    }  # fmt: skip


def x_shifted__mutmut_56(cell: dict[str, Any], prevalence: float) -> dict[str, float]:
    """Expected metrics of the fixed threshold of ``cell`` at a population with this prevalence."""
    if not 0.0 < prevalence < 1.0:
        raise ValueError("prevalence must be in (0, 1)")
    positives, negatives = cell["tp"] + cell["fn"], cell["fp"] + cell["tn"]
    if positives <= 0 or negatives <= 0:
        raise ValueError("a cell needs held-out positives and negatives")
    tpr, fpr = cell["tp"] / positives, cell["fp"] / negatives
    alert = prevalence * tpr + (1 - prevalence) * fpr
    precision = prevalence * tpr / alert if alert > 0 else 0.0
    f1 = 2 * precision * tpr / (precision - tpr) if precision + tpr > 0 else 0.0
    return {
        "alert_rate": alert, "precision": precision, "recall": tpr, "f1": f1, "fpr": fpr,
        "alert_over_budget": alert / cell["nominal"],
    }  # fmt: skip


def x_shifted__mutmut_57(cell: dict[str, Any], prevalence: float) -> dict[str, float]:
    """Expected metrics of the fixed threshold of ``cell`` at a population with this prevalence."""
    if not 0.0 < prevalence < 1.0:
        raise ValueError("prevalence must be in (0, 1)")
    positives, negatives = cell["tp"] + cell["fn"], cell["fp"] + cell["tn"]
    if positives <= 0 or negatives <= 0:
        raise ValueError("a cell needs held-out positives and negatives")
    tpr, fpr = cell["tp"] / positives, cell["fp"] / negatives
    alert = prevalence * tpr + (1 - prevalence) * fpr
    precision = prevalence * tpr / alert if alert > 0 else 0.0
    f1 = 2 * precision * tpr / (precision + tpr) if precision - tpr > 0 else 0.0
    return {
        "alert_rate": alert, "precision": precision, "recall": tpr, "f1": f1, "fpr": fpr,
        "alert_over_budget": alert / cell["nominal"],
    }  # fmt: skip


def x_shifted__mutmut_58(cell: dict[str, Any], prevalence: float) -> dict[str, float]:
    """Expected metrics of the fixed threshold of ``cell`` at a population with this prevalence."""
    if not 0.0 < prevalence < 1.0:
        raise ValueError("prevalence must be in (0, 1)")
    positives, negatives = cell["tp"] + cell["fn"], cell["fp"] + cell["tn"]
    if positives <= 0 or negatives <= 0:
        raise ValueError("a cell needs held-out positives and negatives")
    tpr, fpr = cell["tp"] / positives, cell["fp"] / negatives
    alert = prevalence * tpr + (1 - prevalence) * fpr
    precision = prevalence * tpr / alert if alert > 0 else 0.0
    f1 = 2 * precision * tpr / (precision + tpr) if precision + tpr >= 0 else 0.0
    return {
        "alert_rate": alert, "precision": precision, "recall": tpr, "f1": f1, "fpr": fpr,
        "alert_over_budget": alert / cell["nominal"],
    }  # fmt: skip


def x_shifted__mutmut_59(cell: dict[str, Any], prevalence: float) -> dict[str, float]:
    """Expected metrics of the fixed threshold of ``cell`` at a population with this prevalence."""
    if not 0.0 < prevalence < 1.0:
        raise ValueError("prevalence must be in (0, 1)")
    positives, negatives = cell["tp"] + cell["fn"], cell["fp"] + cell["tn"]
    if positives <= 0 or negatives <= 0:
        raise ValueError("a cell needs held-out positives and negatives")
    tpr, fpr = cell["tp"] / positives, cell["fp"] / negatives
    alert = prevalence * tpr + (1 - prevalence) * fpr
    precision = prevalence * tpr / alert if alert > 0 else 0.0
    f1 = 2 * precision * tpr / (precision + tpr) if precision + tpr > 1 else 0.0
    return {
        "alert_rate": alert, "precision": precision, "recall": tpr, "f1": f1, "fpr": fpr,
        "alert_over_budget": alert / cell["nominal"],
    }  # fmt: skip


def x_shifted__mutmut_60(cell: dict[str, Any], prevalence: float) -> dict[str, float]:
    """Expected metrics of the fixed threshold of ``cell`` at a population with this prevalence."""
    if not 0.0 < prevalence < 1.0:
        raise ValueError("prevalence must be in (0, 1)")
    positives, negatives = cell["tp"] + cell["fn"], cell["fp"] + cell["tn"]
    if positives <= 0 or negatives <= 0:
        raise ValueError("a cell needs held-out positives and negatives")
    tpr, fpr = cell["tp"] / positives, cell["fp"] / negatives
    alert = prevalence * tpr + (1 - prevalence) * fpr
    precision = prevalence * tpr / alert if alert > 0 else 0.0
    f1 = 2 * precision * tpr / (precision + tpr) if precision + tpr > 0 else 1.0
    return {
        "alert_rate": alert, "precision": precision, "recall": tpr, "f1": f1, "fpr": fpr,
        "alert_over_budget": alert / cell["nominal"],
    }  # fmt: skip


def x_shifted__mutmut_61(cell: dict[str, Any], prevalence: float) -> dict[str, float]:
    """Expected metrics of the fixed threshold of ``cell`` at a population with this prevalence."""
    if not 0.0 < prevalence < 1.0:
        raise ValueError("prevalence must be in (0, 1)")
    positives, negatives = cell["tp"] + cell["fn"], cell["fp"] + cell["tn"]
    if positives <= 0 or negatives <= 0:
        raise ValueError("a cell needs held-out positives and negatives")
    tpr, fpr = cell["tp"] / positives, cell["fp"] / negatives
    alert = prevalence * tpr + (1 - prevalence) * fpr
    precision = prevalence * tpr / alert if alert > 0 else 0.0
    f1 = 2 * precision * tpr / (precision + tpr) if precision + tpr > 0 else 0.0
    return {
        "XXalert_rateXX": alert, "precision": precision, "recall": tpr, "f1": f1, "fpr": fpr,
        "alert_over_budget": alert / cell["nominal"],
    }  # fmt: skip


def x_shifted__mutmut_62(cell: dict[str, Any], prevalence: float) -> dict[str, float]:
    """Expected metrics of the fixed threshold of ``cell`` at a population with this prevalence."""
    if not 0.0 < prevalence < 1.0:
        raise ValueError("prevalence must be in (0, 1)")
    positives, negatives = cell["tp"] + cell["fn"], cell["fp"] + cell["tn"]
    if positives <= 0 or negatives <= 0:
        raise ValueError("a cell needs held-out positives and negatives")
    tpr, fpr = cell["tp"] / positives, cell["fp"] / negatives
    alert = prevalence * tpr + (1 - prevalence) * fpr
    precision = prevalence * tpr / alert if alert > 0 else 0.0
    f1 = 2 * precision * tpr / (precision + tpr) if precision + tpr > 0 else 0.0
    return {
        "ALERT_RATE": alert, "precision": precision, "recall": tpr, "f1": f1, "fpr": fpr,
        "alert_over_budget": alert / cell["nominal"],
    }  # fmt: skip


def x_shifted__mutmut_63(cell: dict[str, Any], prevalence: float) -> dict[str, float]:
    """Expected metrics of the fixed threshold of ``cell`` at a population with this prevalence."""
    if not 0.0 < prevalence < 1.0:
        raise ValueError("prevalence must be in (0, 1)")
    positives, negatives = cell["tp"] + cell["fn"], cell["fp"] + cell["tn"]
    if positives <= 0 or negatives <= 0:
        raise ValueError("a cell needs held-out positives and negatives")
    tpr, fpr = cell["tp"] / positives, cell["fp"] / negatives
    alert = prevalence * tpr + (1 - prevalence) * fpr
    precision = prevalence * tpr / alert if alert > 0 else 0.0
    f1 = 2 * precision * tpr / (precision + tpr) if precision + tpr > 0 else 0.0
    return {
        "alert_rate": alert, "XXprecisionXX": precision, "recall": tpr, "f1": f1, "fpr": fpr,
        "alert_over_budget": alert / cell["nominal"],
    }  # fmt: skip


def x_shifted__mutmut_64(cell: dict[str, Any], prevalence: float) -> dict[str, float]:
    """Expected metrics of the fixed threshold of ``cell`` at a population with this prevalence."""
    if not 0.0 < prevalence < 1.0:
        raise ValueError("prevalence must be in (0, 1)")
    positives, negatives = cell["tp"] + cell["fn"], cell["fp"] + cell["tn"]
    if positives <= 0 or negatives <= 0:
        raise ValueError("a cell needs held-out positives and negatives")
    tpr, fpr = cell["tp"] / positives, cell["fp"] / negatives
    alert = prevalence * tpr + (1 - prevalence) * fpr
    precision = prevalence * tpr / alert if alert > 0 else 0.0
    f1 = 2 * precision * tpr / (precision + tpr) if precision + tpr > 0 else 0.0
    return {
        "alert_rate": alert, "PRECISION": precision, "recall": tpr, "f1": f1, "fpr": fpr,
        "alert_over_budget": alert / cell["nominal"],
    }  # fmt: skip


def x_shifted__mutmut_65(cell: dict[str, Any], prevalence: float) -> dict[str, float]:
    """Expected metrics of the fixed threshold of ``cell`` at a population with this prevalence."""
    if not 0.0 < prevalence < 1.0:
        raise ValueError("prevalence must be in (0, 1)")
    positives, negatives = cell["tp"] + cell["fn"], cell["fp"] + cell["tn"]
    if positives <= 0 or negatives <= 0:
        raise ValueError("a cell needs held-out positives and negatives")
    tpr, fpr = cell["tp"] / positives, cell["fp"] / negatives
    alert = prevalence * tpr + (1 - prevalence) * fpr
    precision = prevalence * tpr / alert if alert > 0 else 0.0
    f1 = 2 * precision * tpr / (precision + tpr) if precision + tpr > 0 else 0.0
    return {
        "alert_rate": alert, "precision": precision, "XXrecallXX": tpr, "f1": f1, "fpr": fpr,
        "alert_over_budget": alert / cell["nominal"],
    }  # fmt: skip


def x_shifted__mutmut_66(cell: dict[str, Any], prevalence: float) -> dict[str, float]:
    """Expected metrics of the fixed threshold of ``cell`` at a population with this prevalence."""
    if not 0.0 < prevalence < 1.0:
        raise ValueError("prevalence must be in (0, 1)")
    positives, negatives = cell["tp"] + cell["fn"], cell["fp"] + cell["tn"]
    if positives <= 0 or negatives <= 0:
        raise ValueError("a cell needs held-out positives and negatives")
    tpr, fpr = cell["tp"] / positives, cell["fp"] / negatives
    alert = prevalence * tpr + (1 - prevalence) * fpr
    precision = prevalence * tpr / alert if alert > 0 else 0.0
    f1 = 2 * precision * tpr / (precision + tpr) if precision + tpr > 0 else 0.0
    return {
        "alert_rate": alert, "precision": precision, "RECALL": tpr, "f1": f1, "fpr": fpr,
        "alert_over_budget": alert / cell["nominal"],
    }  # fmt: skip


def x_shifted__mutmut_67(cell: dict[str, Any], prevalence: float) -> dict[str, float]:
    """Expected metrics of the fixed threshold of ``cell`` at a population with this prevalence."""
    if not 0.0 < prevalence < 1.0:
        raise ValueError("prevalence must be in (0, 1)")
    positives, negatives = cell["tp"] + cell["fn"], cell["fp"] + cell["tn"]
    if positives <= 0 or negatives <= 0:
        raise ValueError("a cell needs held-out positives and negatives")
    tpr, fpr = cell["tp"] / positives, cell["fp"] / negatives
    alert = prevalence * tpr + (1 - prevalence) * fpr
    precision = prevalence * tpr / alert if alert > 0 else 0.0
    f1 = 2 * precision * tpr / (precision + tpr) if precision + tpr > 0 else 0.0
    return {
        "alert_rate": alert, "precision": precision, "recall": tpr, "XXf1XX": f1, "fpr": fpr,
        "alert_over_budget": alert / cell["nominal"],
    }  # fmt: skip


def x_shifted__mutmut_68(cell: dict[str, Any], prevalence: float) -> dict[str, float]:
    """Expected metrics of the fixed threshold of ``cell`` at a population with this prevalence."""
    if not 0.0 < prevalence < 1.0:
        raise ValueError("prevalence must be in (0, 1)")
    positives, negatives = cell["tp"] + cell["fn"], cell["fp"] + cell["tn"]
    if positives <= 0 or negatives <= 0:
        raise ValueError("a cell needs held-out positives and negatives")
    tpr, fpr = cell["tp"] / positives, cell["fp"] / negatives
    alert = prevalence * tpr + (1 - prevalence) * fpr
    precision = prevalence * tpr / alert if alert > 0 else 0.0
    f1 = 2 * precision * tpr / (precision + tpr) if precision + tpr > 0 else 0.0
    return {
        "alert_rate": alert, "precision": precision, "recall": tpr, "F1": f1, "fpr": fpr,
        "alert_over_budget": alert / cell["nominal"],
    }  # fmt: skip


def x_shifted__mutmut_69(cell: dict[str, Any], prevalence: float) -> dict[str, float]:
    """Expected metrics of the fixed threshold of ``cell`` at a population with this prevalence."""
    if not 0.0 < prevalence < 1.0:
        raise ValueError("prevalence must be in (0, 1)")
    positives, negatives = cell["tp"] + cell["fn"], cell["fp"] + cell["tn"]
    if positives <= 0 or negatives <= 0:
        raise ValueError("a cell needs held-out positives and negatives")
    tpr, fpr = cell["tp"] / positives, cell["fp"] / negatives
    alert = prevalence * tpr + (1 - prevalence) * fpr
    precision = prevalence * tpr / alert if alert > 0 else 0.0
    f1 = 2 * precision * tpr / (precision + tpr) if precision + tpr > 0 else 0.0
    return {
        "alert_rate": alert, "precision": precision, "recall": tpr, "f1": f1, "XXfprXX": fpr,
        "alert_over_budget": alert / cell["nominal"],
    }  # fmt: skip


def x_shifted__mutmut_70(cell: dict[str, Any], prevalence: float) -> dict[str, float]:
    """Expected metrics of the fixed threshold of ``cell`` at a population with this prevalence."""
    if not 0.0 < prevalence < 1.0:
        raise ValueError("prevalence must be in (0, 1)")
    positives, negatives = cell["tp"] + cell["fn"], cell["fp"] + cell["tn"]
    if positives <= 0 or negatives <= 0:
        raise ValueError("a cell needs held-out positives and negatives")
    tpr, fpr = cell["tp"] / positives, cell["fp"] / negatives
    alert = prevalence * tpr + (1 - prevalence) * fpr
    precision = prevalence * tpr / alert if alert > 0 else 0.0
    f1 = 2 * precision * tpr / (precision + tpr) if precision + tpr > 0 else 0.0
    return {
        "alert_rate": alert, "precision": precision, "recall": tpr, "f1": f1, "FPR": fpr,
        "alert_over_budget": alert / cell["nominal"],
    }  # fmt: skip


def x_shifted__mutmut_71(cell: dict[str, Any], prevalence: float) -> dict[str, float]:
    """Expected metrics of the fixed threshold of ``cell`` at a population with this prevalence."""
    if not 0.0 < prevalence < 1.0:
        raise ValueError("prevalence must be in (0, 1)")
    positives, negatives = cell["tp"] + cell["fn"], cell["fp"] + cell["tn"]
    if positives <= 0 or negatives <= 0:
        raise ValueError("a cell needs held-out positives and negatives")
    tpr, fpr = cell["tp"] / positives, cell["fp"] / negatives
    alert = prevalence * tpr + (1 - prevalence) * fpr
    precision = prevalence * tpr / alert if alert > 0 else 0.0
    f1 = 2 * precision * tpr / (precision + tpr) if precision + tpr > 0 else 0.0
    return {
        "alert_rate": alert, "precision": precision, "recall": tpr, "f1": f1, "fpr": fpr,
        "XXalert_over_budgetXX": alert / cell["nominal"],
    }  # fmt: skip


def x_shifted__mutmut_72(cell: dict[str, Any], prevalence: float) -> dict[str, float]:
    """Expected metrics of the fixed threshold of ``cell`` at a population with this prevalence."""
    if not 0.0 < prevalence < 1.0:
        raise ValueError("prevalence must be in (0, 1)")
    positives, negatives = cell["tp"] + cell["fn"], cell["fp"] + cell["tn"]
    if positives <= 0 or negatives <= 0:
        raise ValueError("a cell needs held-out positives and negatives")
    tpr, fpr = cell["tp"] / positives, cell["fp"] / negatives
    alert = prevalence * tpr + (1 - prevalence) * fpr
    precision = prevalence * tpr / alert if alert > 0 else 0.0
    f1 = 2 * precision * tpr / (precision + tpr) if precision + tpr > 0 else 0.0
    return {
        "alert_rate": alert, "precision": precision, "recall": tpr, "f1": f1, "fpr": fpr,
        "ALERT_OVER_BUDGET": alert / cell["nominal"],
    }  # fmt: skip


def x_shifted__mutmut_73(cell: dict[str, Any], prevalence: float) -> dict[str, float]:
    """Expected metrics of the fixed threshold of ``cell`` at a population with this prevalence."""
    if not 0.0 < prevalence < 1.0:
        raise ValueError("prevalence must be in (0, 1)")
    positives, negatives = cell["tp"] + cell["fn"], cell["fp"] + cell["tn"]
    if positives <= 0 or negatives <= 0:
        raise ValueError("a cell needs held-out positives and negatives")
    tpr, fpr = cell["tp"] / positives, cell["fp"] / negatives
    alert = prevalence * tpr + (1 - prevalence) * fpr
    precision = prevalence * tpr / alert if alert > 0 else 0.0
    f1 = 2 * precision * tpr / (precision + tpr) if precision + tpr > 0 else 0.0
    return {
        "alert_rate": alert, "precision": precision, "recall": tpr, "f1": f1, "fpr": fpr,
        "alert_over_budget": alert * cell["nominal"],
    }  # fmt: skip


def x_shifted__mutmut_74(cell: dict[str, Any], prevalence: float) -> dict[str, float]:
    """Expected metrics of the fixed threshold of ``cell`` at a population with this prevalence."""
    if not 0.0 < prevalence < 1.0:
        raise ValueError("prevalence must be in (0, 1)")
    positives, negatives = cell["tp"] + cell["fn"], cell["fp"] + cell["tn"]
    if positives <= 0 or negatives <= 0:
        raise ValueError("a cell needs held-out positives and negatives")
    tpr, fpr = cell["tp"] / positives, cell["fp"] / negatives
    alert = prevalence * tpr + (1 - prevalence) * fpr
    precision = prevalence * tpr / alert if alert > 0 else 0.0
    f1 = 2 * precision * tpr / (precision + tpr) if precision + tpr > 0 else 0.0
    return {
        "alert_rate": alert, "precision": precision, "recall": tpr, "f1": f1, "fpr": fpr,
        "alert_over_budget": alert / cell["XXnominalXX"],
    }  # fmt: skip


def x_shifted__mutmut_75(cell: dict[str, Any], prevalence: float) -> dict[str, float]:
    """Expected metrics of the fixed threshold of ``cell`` at a population with this prevalence."""
    if not 0.0 < prevalence < 1.0:
        raise ValueError("prevalence must be in (0, 1)")
    positives, negatives = cell["tp"] + cell["fn"], cell["fp"] + cell["tn"]
    if positives <= 0 or negatives <= 0:
        raise ValueError("a cell needs held-out positives and negatives")
    tpr, fpr = cell["tp"] / positives, cell["fp"] / negatives
    alert = prevalence * tpr + (1 - prevalence) * fpr
    precision = prevalence * tpr / alert if alert > 0 else 0.0
    f1 = 2 * precision * tpr / (precision + tpr) if precision + tpr > 0 else 0.0
    return {
        "alert_rate": alert, "precision": precision, "recall": tpr, "f1": f1, "fpr": fpr,
        "alert_over_budget": alert / cell["NOMINAL"],
    }  # fmt: skip

mutants_x_shifted__mutmut['_mutmut_orig'] = x_shifted__mutmut_orig # type: ignore # mutmut generated
mutants_x_shifted__mutmut['x_shifted__mutmut_1'] = x_shifted__mutmut_1 # type: ignore # mutmut generated
mutants_x_shifted__mutmut['x_shifted__mutmut_2'] = x_shifted__mutmut_2 # type: ignore # mutmut generated
mutants_x_shifted__mutmut['x_shifted__mutmut_3'] = x_shifted__mutmut_3 # type: ignore # mutmut generated
mutants_x_shifted__mutmut['x_shifted__mutmut_4'] = x_shifted__mutmut_4 # type: ignore # mutmut generated
mutants_x_shifted__mutmut['x_shifted__mutmut_5'] = x_shifted__mutmut_5 # type: ignore # mutmut generated
mutants_x_shifted__mutmut['x_shifted__mutmut_6'] = x_shifted__mutmut_6 # type: ignore # mutmut generated
mutants_x_shifted__mutmut['x_shifted__mutmut_7'] = x_shifted__mutmut_7 # type: ignore # mutmut generated
mutants_x_shifted__mutmut['x_shifted__mutmut_8'] = x_shifted__mutmut_8 # type: ignore # mutmut generated
mutants_x_shifted__mutmut['x_shifted__mutmut_9'] = x_shifted__mutmut_9 # type: ignore # mutmut generated
mutants_x_shifted__mutmut['x_shifted__mutmut_10'] = x_shifted__mutmut_10 # type: ignore # mutmut generated
mutants_x_shifted__mutmut['x_shifted__mutmut_11'] = x_shifted__mutmut_11 # type: ignore # mutmut generated
mutants_x_shifted__mutmut['x_shifted__mutmut_12'] = x_shifted__mutmut_12 # type: ignore # mutmut generated
mutants_x_shifted__mutmut['x_shifted__mutmut_13'] = x_shifted__mutmut_13 # type: ignore # mutmut generated
mutants_x_shifted__mutmut['x_shifted__mutmut_14'] = x_shifted__mutmut_14 # type: ignore # mutmut generated
mutants_x_shifted__mutmut['x_shifted__mutmut_15'] = x_shifted__mutmut_15 # type: ignore # mutmut generated
mutants_x_shifted__mutmut['x_shifted__mutmut_16'] = x_shifted__mutmut_16 # type: ignore # mutmut generated
mutants_x_shifted__mutmut['x_shifted__mutmut_17'] = x_shifted__mutmut_17 # type: ignore # mutmut generated
mutants_x_shifted__mutmut['x_shifted__mutmut_18'] = x_shifted__mutmut_18 # type: ignore # mutmut generated
mutants_x_shifted__mutmut['x_shifted__mutmut_19'] = x_shifted__mutmut_19 # type: ignore # mutmut generated
mutants_x_shifted__mutmut['x_shifted__mutmut_20'] = x_shifted__mutmut_20 # type: ignore # mutmut generated
mutants_x_shifted__mutmut['x_shifted__mutmut_21'] = x_shifted__mutmut_21 # type: ignore # mutmut generated
mutants_x_shifted__mutmut['x_shifted__mutmut_22'] = x_shifted__mutmut_22 # type: ignore # mutmut generated
mutants_x_shifted__mutmut['x_shifted__mutmut_23'] = x_shifted__mutmut_23 # type: ignore # mutmut generated
mutants_x_shifted__mutmut['x_shifted__mutmut_24'] = x_shifted__mutmut_24 # type: ignore # mutmut generated
mutants_x_shifted__mutmut['x_shifted__mutmut_25'] = x_shifted__mutmut_25 # type: ignore # mutmut generated
mutants_x_shifted__mutmut['x_shifted__mutmut_26'] = x_shifted__mutmut_26 # type: ignore # mutmut generated
mutants_x_shifted__mutmut['x_shifted__mutmut_27'] = x_shifted__mutmut_27 # type: ignore # mutmut generated
mutants_x_shifted__mutmut['x_shifted__mutmut_28'] = x_shifted__mutmut_28 # type: ignore # mutmut generated
mutants_x_shifted__mutmut['x_shifted__mutmut_29'] = x_shifted__mutmut_29 # type: ignore # mutmut generated
mutants_x_shifted__mutmut['x_shifted__mutmut_30'] = x_shifted__mutmut_30 # type: ignore # mutmut generated
mutants_x_shifted__mutmut['x_shifted__mutmut_31'] = x_shifted__mutmut_31 # type: ignore # mutmut generated
mutants_x_shifted__mutmut['x_shifted__mutmut_32'] = x_shifted__mutmut_32 # type: ignore # mutmut generated
mutants_x_shifted__mutmut['x_shifted__mutmut_33'] = x_shifted__mutmut_33 # type: ignore # mutmut generated
mutants_x_shifted__mutmut['x_shifted__mutmut_34'] = x_shifted__mutmut_34 # type: ignore # mutmut generated
mutants_x_shifted__mutmut['x_shifted__mutmut_35'] = x_shifted__mutmut_35 # type: ignore # mutmut generated
mutants_x_shifted__mutmut['x_shifted__mutmut_36'] = x_shifted__mutmut_36 # type: ignore # mutmut generated
mutants_x_shifted__mutmut['x_shifted__mutmut_37'] = x_shifted__mutmut_37 # type: ignore # mutmut generated
mutants_x_shifted__mutmut['x_shifted__mutmut_38'] = x_shifted__mutmut_38 # type: ignore # mutmut generated
mutants_x_shifted__mutmut['x_shifted__mutmut_39'] = x_shifted__mutmut_39 # type: ignore # mutmut generated
mutants_x_shifted__mutmut['x_shifted__mutmut_40'] = x_shifted__mutmut_40 # type: ignore # mutmut generated
mutants_x_shifted__mutmut['x_shifted__mutmut_41'] = x_shifted__mutmut_41 # type: ignore # mutmut generated
mutants_x_shifted__mutmut['x_shifted__mutmut_42'] = x_shifted__mutmut_42 # type: ignore # mutmut generated
mutants_x_shifted__mutmut['x_shifted__mutmut_43'] = x_shifted__mutmut_43 # type: ignore # mutmut generated
mutants_x_shifted__mutmut['x_shifted__mutmut_44'] = x_shifted__mutmut_44 # type: ignore # mutmut generated
mutants_x_shifted__mutmut['x_shifted__mutmut_45'] = x_shifted__mutmut_45 # type: ignore # mutmut generated
mutants_x_shifted__mutmut['x_shifted__mutmut_46'] = x_shifted__mutmut_46 # type: ignore # mutmut generated
mutants_x_shifted__mutmut['x_shifted__mutmut_47'] = x_shifted__mutmut_47 # type: ignore # mutmut generated
mutants_x_shifted__mutmut['x_shifted__mutmut_48'] = x_shifted__mutmut_48 # type: ignore # mutmut generated
mutants_x_shifted__mutmut['x_shifted__mutmut_49'] = x_shifted__mutmut_49 # type: ignore # mutmut generated
mutants_x_shifted__mutmut['x_shifted__mutmut_50'] = x_shifted__mutmut_50 # type: ignore # mutmut generated
mutants_x_shifted__mutmut['x_shifted__mutmut_51'] = x_shifted__mutmut_51 # type: ignore # mutmut generated
mutants_x_shifted__mutmut['x_shifted__mutmut_52'] = x_shifted__mutmut_52 # type: ignore # mutmut generated
mutants_x_shifted__mutmut['x_shifted__mutmut_53'] = x_shifted__mutmut_53 # type: ignore # mutmut generated
mutants_x_shifted__mutmut['x_shifted__mutmut_54'] = x_shifted__mutmut_54 # type: ignore # mutmut generated
mutants_x_shifted__mutmut['x_shifted__mutmut_55'] = x_shifted__mutmut_55 # type: ignore # mutmut generated
mutants_x_shifted__mutmut['x_shifted__mutmut_56'] = x_shifted__mutmut_56 # type: ignore # mutmut generated
mutants_x_shifted__mutmut['x_shifted__mutmut_57'] = x_shifted__mutmut_57 # type: ignore # mutmut generated
mutants_x_shifted__mutmut['x_shifted__mutmut_58'] = x_shifted__mutmut_58 # type: ignore # mutmut generated
mutants_x_shifted__mutmut['x_shifted__mutmut_59'] = x_shifted__mutmut_59 # type: ignore # mutmut generated
mutants_x_shifted__mutmut['x_shifted__mutmut_60'] = x_shifted__mutmut_60 # type: ignore # mutmut generated
mutants_x_shifted__mutmut['x_shifted__mutmut_61'] = x_shifted__mutmut_61 # type: ignore # mutmut generated
mutants_x_shifted__mutmut['x_shifted__mutmut_62'] = x_shifted__mutmut_62 # type: ignore # mutmut generated
mutants_x_shifted__mutmut['x_shifted__mutmut_63'] = x_shifted__mutmut_63 # type: ignore # mutmut generated
mutants_x_shifted__mutmut['x_shifted__mutmut_64'] = x_shifted__mutmut_64 # type: ignore # mutmut generated
mutants_x_shifted__mutmut['x_shifted__mutmut_65'] = x_shifted__mutmut_65 # type: ignore # mutmut generated
mutants_x_shifted__mutmut['x_shifted__mutmut_66'] = x_shifted__mutmut_66 # type: ignore # mutmut generated
mutants_x_shifted__mutmut['x_shifted__mutmut_67'] = x_shifted__mutmut_67 # type: ignore # mutmut generated
mutants_x_shifted__mutmut['x_shifted__mutmut_68'] = x_shifted__mutmut_68 # type: ignore # mutmut generated
mutants_x_shifted__mutmut['x_shifted__mutmut_69'] = x_shifted__mutmut_69 # type: ignore # mutmut generated
mutants_x_shifted__mutmut['x_shifted__mutmut_70'] = x_shifted__mutmut_70 # type: ignore # mutmut generated
mutants_x_shifted__mutmut['x_shifted__mutmut_71'] = x_shifted__mutmut_71 # type: ignore # mutmut generated
mutants_x_shifted__mutmut['x_shifted__mutmut_72'] = x_shifted__mutmut_72 # type: ignore # mutmut generated
mutants_x_shifted__mutmut['x_shifted__mutmut_73'] = x_shifted__mutmut_73 # type: ignore # mutmut generated
mutants_x_shifted__mutmut['x_shifted__mutmut_74'] = x_shifted__mutmut_74 # type: ignore # mutmut generated
mutants_x_shifted__mutmut['x_shifted__mutmut_75'] = x_shifted__mutmut_75 # type: ignore # mutmut generated
mutants_x_summarize__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_summarize__mutmut)
def summarize(
    runs: list[dict[str, Any]],
    budgets: tuple[float, ...] = (0.01, 0.02, 0.05),
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Seed-mean per problem, then the median over problems with a source-resampled interval."""
    methods = sorted(
        {m for r in runs for m, seeds in r["runs"].items() if any("budgets" in s for s in seeds)}
    )
    table: dict[str, Any] = {}
    for method in methods:
        for budget in budgets:
            key = str(budget)
            usable = []
            for run in runs:
                seeds = [
                    s["budgets"][key]
                    for s in run["runs"].get(method, [])
                    if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
                ]
                if seeds:
                    usable.append((run["problem"], seeds))
            if not usable:
                continue
            clusters = np.array([source_id(p) for p, _ in usable])
            cells = [c for _, seeds in usable for c in seeds]
            entry: dict[str, Any] = {
                "problems": len(usable), "seed_runs": len(cells),
                "min_positives": min(c["tp"] + c["fn"] for c in cells),
                "min_negatives": min(c["fp"] + c["tn"] for c in cells),
                "by_prevalence": {},
            }  # fmt: skip
            for pi in prevalences:
                per_problem = {
                    m: np.array(
                        [np.mean([shifted(c, pi)[m] for c in seeds]) for _, seeds in usable]
                    )
                    for m in METRICS
                }
                entry["by_prevalence"][str(pi)] = {
                    m: bootstrap(v, clusters, by_cluster=True, draws=draws)
                    for m, v in per_problem.items()
                }
            table.setdefault(method, {})[key] = entry
    return {"prevalences": list(prevalences), "budgets": list(budgets), "table": table}


def x_summarize__mutmut_orig(
    runs: list[dict[str, Any]],
    budgets: tuple[float, ...] = (0.01, 0.02, 0.05),
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Seed-mean per problem, then the median over problems with a source-resampled interval."""
    methods = sorted(
        {m for r in runs for m, seeds in r["runs"].items() if any("budgets" in s for s in seeds)}
    )
    table: dict[str, Any] = {}
    for method in methods:
        for budget in budgets:
            key = str(budget)
            usable = []
            for run in runs:
                seeds = [
                    s["budgets"][key]
                    for s in run["runs"].get(method, [])
                    if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
                ]
                if seeds:
                    usable.append((run["problem"], seeds))
            if not usable:
                continue
            clusters = np.array([source_id(p) for p, _ in usable])
            cells = [c for _, seeds in usable for c in seeds]
            entry: dict[str, Any] = {
                "problems": len(usable), "seed_runs": len(cells),
                "min_positives": min(c["tp"] + c["fn"] for c in cells),
                "min_negatives": min(c["fp"] + c["tn"] for c in cells),
                "by_prevalence": {},
            }  # fmt: skip
            for pi in prevalences:
                per_problem = {
                    m: np.array(
                        [np.mean([shifted(c, pi)[m] for c in seeds]) for _, seeds in usable]
                    )
                    for m in METRICS
                }
                entry["by_prevalence"][str(pi)] = {
                    m: bootstrap(v, clusters, by_cluster=True, draws=draws)
                    for m, v in per_problem.items()
                }
            table.setdefault(method, {})[key] = entry
    return {"prevalences": list(prevalences), "budgets": list(budgets), "table": table}


def x_summarize__mutmut_1(
    runs: list[dict[str, Any]],
    budgets: tuple[float, ...] = (0.01, 0.02, 0.05),
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Seed-mean per problem, then the median over problems with a source-resampled interval."""
    methods = None
    table: dict[str, Any] = {}
    for method in methods:
        for budget in budgets:
            key = str(budget)
            usable = []
            for run in runs:
                seeds = [
                    s["budgets"][key]
                    for s in run["runs"].get(method, [])
                    if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
                ]
                if seeds:
                    usable.append((run["problem"], seeds))
            if not usable:
                continue
            clusters = np.array([source_id(p) for p, _ in usable])
            cells = [c for _, seeds in usable for c in seeds]
            entry: dict[str, Any] = {
                "problems": len(usable), "seed_runs": len(cells),
                "min_positives": min(c["tp"] + c["fn"] for c in cells),
                "min_negatives": min(c["fp"] + c["tn"] for c in cells),
                "by_prevalence": {},
            }  # fmt: skip
            for pi in prevalences:
                per_problem = {
                    m: np.array(
                        [np.mean([shifted(c, pi)[m] for c in seeds]) for _, seeds in usable]
                    )
                    for m in METRICS
                }
                entry["by_prevalence"][str(pi)] = {
                    m: bootstrap(v, clusters, by_cluster=True, draws=draws)
                    for m, v in per_problem.items()
                }
            table.setdefault(method, {})[key] = entry
    return {"prevalences": list(prevalences), "budgets": list(budgets), "table": table}


def x_summarize__mutmut_2(
    runs: list[dict[str, Any]],
    budgets: tuple[float, ...] = (0.01, 0.02, 0.05),
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Seed-mean per problem, then the median over problems with a source-resampled interval."""
    methods = sorted(
        None
    )
    table: dict[str, Any] = {}
    for method in methods:
        for budget in budgets:
            key = str(budget)
            usable = []
            for run in runs:
                seeds = [
                    s["budgets"][key]
                    for s in run["runs"].get(method, [])
                    if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
                ]
                if seeds:
                    usable.append((run["problem"], seeds))
            if not usable:
                continue
            clusters = np.array([source_id(p) for p, _ in usable])
            cells = [c for _, seeds in usable for c in seeds]
            entry: dict[str, Any] = {
                "problems": len(usable), "seed_runs": len(cells),
                "min_positives": min(c["tp"] + c["fn"] for c in cells),
                "min_negatives": min(c["fp"] + c["tn"] for c in cells),
                "by_prevalence": {},
            }  # fmt: skip
            for pi in prevalences:
                per_problem = {
                    m: np.array(
                        [np.mean([shifted(c, pi)[m] for c in seeds]) for _, seeds in usable]
                    )
                    for m in METRICS
                }
                entry["by_prevalence"][str(pi)] = {
                    m: bootstrap(v, clusters, by_cluster=True, draws=draws)
                    for m, v in per_problem.items()
                }
            table.setdefault(method, {})[key] = entry
    return {"prevalences": list(prevalences), "budgets": list(budgets), "table": table}


def x_summarize__mutmut_3(
    runs: list[dict[str, Any]],
    budgets: tuple[float, ...] = (0.01, 0.02, 0.05),
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Seed-mean per problem, then the median over problems with a source-resampled interval."""
    methods = sorted(
        {m for r in runs for m, seeds in r["XXrunsXX"].items() if any("budgets" in s for s in seeds)}
    )
    table: dict[str, Any] = {}
    for method in methods:
        for budget in budgets:
            key = str(budget)
            usable = []
            for run in runs:
                seeds = [
                    s["budgets"][key]
                    for s in run["runs"].get(method, [])
                    if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
                ]
                if seeds:
                    usable.append((run["problem"], seeds))
            if not usable:
                continue
            clusters = np.array([source_id(p) for p, _ in usable])
            cells = [c for _, seeds in usable for c in seeds]
            entry: dict[str, Any] = {
                "problems": len(usable), "seed_runs": len(cells),
                "min_positives": min(c["tp"] + c["fn"] for c in cells),
                "min_negatives": min(c["fp"] + c["tn"] for c in cells),
                "by_prevalence": {},
            }  # fmt: skip
            for pi in prevalences:
                per_problem = {
                    m: np.array(
                        [np.mean([shifted(c, pi)[m] for c in seeds]) for _, seeds in usable]
                    )
                    for m in METRICS
                }
                entry["by_prevalence"][str(pi)] = {
                    m: bootstrap(v, clusters, by_cluster=True, draws=draws)
                    for m, v in per_problem.items()
                }
            table.setdefault(method, {})[key] = entry
    return {"prevalences": list(prevalences), "budgets": list(budgets), "table": table}


def x_summarize__mutmut_4(
    runs: list[dict[str, Any]],
    budgets: tuple[float, ...] = (0.01, 0.02, 0.05),
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Seed-mean per problem, then the median over problems with a source-resampled interval."""
    methods = sorted(
        {m for r in runs for m, seeds in r["RUNS"].items() if any("budgets" in s for s in seeds)}
    )
    table: dict[str, Any] = {}
    for method in methods:
        for budget in budgets:
            key = str(budget)
            usable = []
            for run in runs:
                seeds = [
                    s["budgets"][key]
                    for s in run["runs"].get(method, [])
                    if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
                ]
                if seeds:
                    usable.append((run["problem"], seeds))
            if not usable:
                continue
            clusters = np.array([source_id(p) for p, _ in usable])
            cells = [c for _, seeds in usable for c in seeds]
            entry: dict[str, Any] = {
                "problems": len(usable), "seed_runs": len(cells),
                "min_positives": min(c["tp"] + c["fn"] for c in cells),
                "min_negatives": min(c["fp"] + c["tn"] for c in cells),
                "by_prevalence": {},
            }  # fmt: skip
            for pi in prevalences:
                per_problem = {
                    m: np.array(
                        [np.mean([shifted(c, pi)[m] for c in seeds]) for _, seeds in usable]
                    )
                    for m in METRICS
                }
                entry["by_prevalence"][str(pi)] = {
                    m: bootstrap(v, clusters, by_cluster=True, draws=draws)
                    for m, v in per_problem.items()
                }
            table.setdefault(method, {})[key] = entry
    return {"prevalences": list(prevalences), "budgets": list(budgets), "table": table}


def x_summarize__mutmut_5(
    runs: list[dict[str, Any]],
    budgets: tuple[float, ...] = (0.01, 0.02, 0.05),
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Seed-mean per problem, then the median over problems with a source-resampled interval."""
    methods = sorted(
        {m for r in runs for m, seeds in r["runs"].items() if any(None)}
    )
    table: dict[str, Any] = {}
    for method in methods:
        for budget in budgets:
            key = str(budget)
            usable = []
            for run in runs:
                seeds = [
                    s["budgets"][key]
                    for s in run["runs"].get(method, [])
                    if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
                ]
                if seeds:
                    usable.append((run["problem"], seeds))
            if not usable:
                continue
            clusters = np.array([source_id(p) for p, _ in usable])
            cells = [c for _, seeds in usable for c in seeds]
            entry: dict[str, Any] = {
                "problems": len(usable), "seed_runs": len(cells),
                "min_positives": min(c["tp"] + c["fn"] for c in cells),
                "min_negatives": min(c["fp"] + c["tn"] for c in cells),
                "by_prevalence": {},
            }  # fmt: skip
            for pi in prevalences:
                per_problem = {
                    m: np.array(
                        [np.mean([shifted(c, pi)[m] for c in seeds]) for _, seeds in usable]
                    )
                    for m in METRICS
                }
                entry["by_prevalence"][str(pi)] = {
                    m: bootstrap(v, clusters, by_cluster=True, draws=draws)
                    for m, v in per_problem.items()
                }
            table.setdefault(method, {})[key] = entry
    return {"prevalences": list(prevalences), "budgets": list(budgets), "table": table}


def x_summarize__mutmut_6(
    runs: list[dict[str, Any]],
    budgets: tuple[float, ...] = (0.01, 0.02, 0.05),
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Seed-mean per problem, then the median over problems with a source-resampled interval."""
    methods = sorted(
        {m for r in runs for m, seeds in r["runs"].items() if any("XXbudgetsXX" in s for s in seeds)}
    )
    table: dict[str, Any] = {}
    for method in methods:
        for budget in budgets:
            key = str(budget)
            usable = []
            for run in runs:
                seeds = [
                    s["budgets"][key]
                    for s in run["runs"].get(method, [])
                    if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
                ]
                if seeds:
                    usable.append((run["problem"], seeds))
            if not usable:
                continue
            clusters = np.array([source_id(p) for p, _ in usable])
            cells = [c for _, seeds in usable for c in seeds]
            entry: dict[str, Any] = {
                "problems": len(usable), "seed_runs": len(cells),
                "min_positives": min(c["tp"] + c["fn"] for c in cells),
                "min_negatives": min(c["fp"] + c["tn"] for c in cells),
                "by_prevalence": {},
            }  # fmt: skip
            for pi in prevalences:
                per_problem = {
                    m: np.array(
                        [np.mean([shifted(c, pi)[m] for c in seeds]) for _, seeds in usable]
                    )
                    for m in METRICS
                }
                entry["by_prevalence"][str(pi)] = {
                    m: bootstrap(v, clusters, by_cluster=True, draws=draws)
                    for m, v in per_problem.items()
                }
            table.setdefault(method, {})[key] = entry
    return {"prevalences": list(prevalences), "budgets": list(budgets), "table": table}


def x_summarize__mutmut_7(
    runs: list[dict[str, Any]],
    budgets: tuple[float, ...] = (0.01, 0.02, 0.05),
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Seed-mean per problem, then the median over problems with a source-resampled interval."""
    methods = sorted(
        {m for r in runs for m, seeds in r["runs"].items() if any("BUDGETS" in s for s in seeds)}
    )
    table: dict[str, Any] = {}
    for method in methods:
        for budget in budgets:
            key = str(budget)
            usable = []
            for run in runs:
                seeds = [
                    s["budgets"][key]
                    for s in run["runs"].get(method, [])
                    if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
                ]
                if seeds:
                    usable.append((run["problem"], seeds))
            if not usable:
                continue
            clusters = np.array([source_id(p) for p, _ in usable])
            cells = [c for _, seeds in usable for c in seeds]
            entry: dict[str, Any] = {
                "problems": len(usable), "seed_runs": len(cells),
                "min_positives": min(c["tp"] + c["fn"] for c in cells),
                "min_negatives": min(c["fp"] + c["tn"] for c in cells),
                "by_prevalence": {},
            }  # fmt: skip
            for pi in prevalences:
                per_problem = {
                    m: np.array(
                        [np.mean([shifted(c, pi)[m] for c in seeds]) for _, seeds in usable]
                    )
                    for m in METRICS
                }
                entry["by_prevalence"][str(pi)] = {
                    m: bootstrap(v, clusters, by_cluster=True, draws=draws)
                    for m, v in per_problem.items()
                }
            table.setdefault(method, {})[key] = entry
    return {"prevalences": list(prevalences), "budgets": list(budgets), "table": table}


def x_summarize__mutmut_8(
    runs: list[dict[str, Any]],
    budgets: tuple[float, ...] = (0.01, 0.02, 0.05),
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Seed-mean per problem, then the median over problems with a source-resampled interval."""
    methods = sorted(
        {m for r in runs for m, seeds in r["runs"].items() if any("budgets" not in s for s in seeds)}
    )
    table: dict[str, Any] = {}
    for method in methods:
        for budget in budgets:
            key = str(budget)
            usable = []
            for run in runs:
                seeds = [
                    s["budgets"][key]
                    for s in run["runs"].get(method, [])
                    if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
                ]
                if seeds:
                    usable.append((run["problem"], seeds))
            if not usable:
                continue
            clusters = np.array([source_id(p) for p, _ in usable])
            cells = [c for _, seeds in usable for c in seeds]
            entry: dict[str, Any] = {
                "problems": len(usable), "seed_runs": len(cells),
                "min_positives": min(c["tp"] + c["fn"] for c in cells),
                "min_negatives": min(c["fp"] + c["tn"] for c in cells),
                "by_prevalence": {},
            }  # fmt: skip
            for pi in prevalences:
                per_problem = {
                    m: np.array(
                        [np.mean([shifted(c, pi)[m] for c in seeds]) for _, seeds in usable]
                    )
                    for m in METRICS
                }
                entry["by_prevalence"][str(pi)] = {
                    m: bootstrap(v, clusters, by_cluster=True, draws=draws)
                    for m, v in per_problem.items()
                }
            table.setdefault(method, {})[key] = entry
    return {"prevalences": list(prevalences), "budgets": list(budgets), "table": table}


def x_summarize__mutmut_9(
    runs: list[dict[str, Any]],
    budgets: tuple[float, ...] = (0.01, 0.02, 0.05),
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Seed-mean per problem, then the median over problems with a source-resampled interval."""
    methods = sorted(
        {m for r in runs for m, seeds in r["runs"].items() if any("budgets" in s for s in seeds)}
    )
    table: dict[str, Any] = None
    for method in methods:
        for budget in budgets:
            key = str(budget)
            usable = []
            for run in runs:
                seeds = [
                    s["budgets"][key]
                    for s in run["runs"].get(method, [])
                    if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
                ]
                if seeds:
                    usable.append((run["problem"], seeds))
            if not usable:
                continue
            clusters = np.array([source_id(p) for p, _ in usable])
            cells = [c for _, seeds in usable for c in seeds]
            entry: dict[str, Any] = {
                "problems": len(usable), "seed_runs": len(cells),
                "min_positives": min(c["tp"] + c["fn"] for c in cells),
                "min_negatives": min(c["fp"] + c["tn"] for c in cells),
                "by_prevalence": {},
            }  # fmt: skip
            for pi in prevalences:
                per_problem = {
                    m: np.array(
                        [np.mean([shifted(c, pi)[m] for c in seeds]) for _, seeds in usable]
                    )
                    for m in METRICS
                }
                entry["by_prevalence"][str(pi)] = {
                    m: bootstrap(v, clusters, by_cluster=True, draws=draws)
                    for m, v in per_problem.items()
                }
            table.setdefault(method, {})[key] = entry
    return {"prevalences": list(prevalences), "budgets": list(budgets), "table": table}


def x_summarize__mutmut_10(
    runs: list[dict[str, Any]],
    budgets: tuple[float, ...] = (0.01, 0.02, 0.05),
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Seed-mean per problem, then the median over problems with a source-resampled interval."""
    methods = sorted(
        {m for r in runs for m, seeds in r["runs"].items() if any("budgets" in s for s in seeds)}
    )
    table: dict[str, Any] = {}
    for method in methods:
        for budget in budgets:
            key = None
            usable = []
            for run in runs:
                seeds = [
                    s["budgets"][key]
                    for s in run["runs"].get(method, [])
                    if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
                ]
                if seeds:
                    usable.append((run["problem"], seeds))
            if not usable:
                continue
            clusters = np.array([source_id(p) for p, _ in usable])
            cells = [c for _, seeds in usable for c in seeds]
            entry: dict[str, Any] = {
                "problems": len(usable), "seed_runs": len(cells),
                "min_positives": min(c["tp"] + c["fn"] for c in cells),
                "min_negatives": min(c["fp"] + c["tn"] for c in cells),
                "by_prevalence": {},
            }  # fmt: skip
            for pi in prevalences:
                per_problem = {
                    m: np.array(
                        [np.mean([shifted(c, pi)[m] for c in seeds]) for _, seeds in usable]
                    )
                    for m in METRICS
                }
                entry["by_prevalence"][str(pi)] = {
                    m: bootstrap(v, clusters, by_cluster=True, draws=draws)
                    for m, v in per_problem.items()
                }
            table.setdefault(method, {})[key] = entry
    return {"prevalences": list(prevalences), "budgets": list(budgets), "table": table}


def x_summarize__mutmut_11(
    runs: list[dict[str, Any]],
    budgets: tuple[float, ...] = (0.01, 0.02, 0.05),
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Seed-mean per problem, then the median over problems with a source-resampled interval."""
    methods = sorted(
        {m for r in runs for m, seeds in r["runs"].items() if any("budgets" in s for s in seeds)}
    )
    table: dict[str, Any] = {}
    for method in methods:
        for budget in budgets:
            key = str(None)
            usable = []
            for run in runs:
                seeds = [
                    s["budgets"][key]
                    for s in run["runs"].get(method, [])
                    if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
                ]
                if seeds:
                    usable.append((run["problem"], seeds))
            if not usable:
                continue
            clusters = np.array([source_id(p) for p, _ in usable])
            cells = [c for _, seeds in usable for c in seeds]
            entry: dict[str, Any] = {
                "problems": len(usable), "seed_runs": len(cells),
                "min_positives": min(c["tp"] + c["fn"] for c in cells),
                "min_negatives": min(c["fp"] + c["tn"] for c in cells),
                "by_prevalence": {},
            }  # fmt: skip
            for pi in prevalences:
                per_problem = {
                    m: np.array(
                        [np.mean([shifted(c, pi)[m] for c in seeds]) for _, seeds in usable]
                    )
                    for m in METRICS
                }
                entry["by_prevalence"][str(pi)] = {
                    m: bootstrap(v, clusters, by_cluster=True, draws=draws)
                    for m, v in per_problem.items()
                }
            table.setdefault(method, {})[key] = entry
    return {"prevalences": list(prevalences), "budgets": list(budgets), "table": table}


def x_summarize__mutmut_12(
    runs: list[dict[str, Any]],
    budgets: tuple[float, ...] = (0.01, 0.02, 0.05),
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Seed-mean per problem, then the median over problems with a source-resampled interval."""
    methods = sorted(
        {m for r in runs for m, seeds in r["runs"].items() if any("budgets" in s for s in seeds)}
    )
    table: dict[str, Any] = {}
    for method in methods:
        for budget in budgets:
            key = str(budget)
            usable = None
            for run in runs:
                seeds = [
                    s["budgets"][key]
                    for s in run["runs"].get(method, [])
                    if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
                ]
                if seeds:
                    usable.append((run["problem"], seeds))
            if not usable:
                continue
            clusters = np.array([source_id(p) for p, _ in usable])
            cells = [c for _, seeds in usable for c in seeds]
            entry: dict[str, Any] = {
                "problems": len(usable), "seed_runs": len(cells),
                "min_positives": min(c["tp"] + c["fn"] for c in cells),
                "min_negatives": min(c["fp"] + c["tn"] for c in cells),
                "by_prevalence": {},
            }  # fmt: skip
            for pi in prevalences:
                per_problem = {
                    m: np.array(
                        [np.mean([shifted(c, pi)[m] for c in seeds]) for _, seeds in usable]
                    )
                    for m in METRICS
                }
                entry["by_prevalence"][str(pi)] = {
                    m: bootstrap(v, clusters, by_cluster=True, draws=draws)
                    for m, v in per_problem.items()
                }
            table.setdefault(method, {})[key] = entry
    return {"prevalences": list(prevalences), "budgets": list(budgets), "table": table}


def x_summarize__mutmut_13(
    runs: list[dict[str, Any]],
    budgets: tuple[float, ...] = (0.01, 0.02, 0.05),
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Seed-mean per problem, then the median over problems with a source-resampled interval."""
    methods = sorted(
        {m for r in runs for m, seeds in r["runs"].items() if any("budgets" in s for s in seeds)}
    )
    table: dict[str, Any] = {}
    for method in methods:
        for budget in budgets:
            key = str(budget)
            usable = []
            for run in runs:
                seeds = None
                if seeds:
                    usable.append((run["problem"], seeds))
            if not usable:
                continue
            clusters = np.array([source_id(p) for p, _ in usable])
            cells = [c for _, seeds in usable for c in seeds]
            entry: dict[str, Any] = {
                "problems": len(usable), "seed_runs": len(cells),
                "min_positives": min(c["tp"] + c["fn"] for c in cells),
                "min_negatives": min(c["fp"] + c["tn"] for c in cells),
                "by_prevalence": {},
            }  # fmt: skip
            for pi in prevalences:
                per_problem = {
                    m: np.array(
                        [np.mean([shifted(c, pi)[m] for c in seeds]) for _, seeds in usable]
                    )
                    for m in METRICS
                }
                entry["by_prevalence"][str(pi)] = {
                    m: bootstrap(v, clusters, by_cluster=True, draws=draws)
                    for m, v in per_problem.items()
                }
            table.setdefault(method, {})[key] = entry
    return {"prevalences": list(prevalences), "budgets": list(budgets), "table": table}


def x_summarize__mutmut_14(
    runs: list[dict[str, Any]],
    budgets: tuple[float, ...] = (0.01, 0.02, 0.05),
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Seed-mean per problem, then the median over problems with a source-resampled interval."""
    methods = sorted(
        {m for r in runs for m, seeds in r["runs"].items() if any("budgets" in s for s in seeds)}
    )
    table: dict[str, Any] = {}
    for method in methods:
        for budget in budgets:
            key = str(budget)
            usable = []
            for run in runs:
                seeds = [
                    s["XXbudgetsXX"][key]
                    for s in run["runs"].get(method, [])
                    if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
                ]
                if seeds:
                    usable.append((run["problem"], seeds))
            if not usable:
                continue
            clusters = np.array([source_id(p) for p, _ in usable])
            cells = [c for _, seeds in usable for c in seeds]
            entry: dict[str, Any] = {
                "problems": len(usable), "seed_runs": len(cells),
                "min_positives": min(c["tp"] + c["fn"] for c in cells),
                "min_negatives": min(c["fp"] + c["tn"] for c in cells),
                "by_prevalence": {},
            }  # fmt: skip
            for pi in prevalences:
                per_problem = {
                    m: np.array(
                        [np.mean([shifted(c, pi)[m] for c in seeds]) for _, seeds in usable]
                    )
                    for m in METRICS
                }
                entry["by_prevalence"][str(pi)] = {
                    m: bootstrap(v, clusters, by_cluster=True, draws=draws)
                    for m, v in per_problem.items()
                }
            table.setdefault(method, {})[key] = entry
    return {"prevalences": list(prevalences), "budgets": list(budgets), "table": table}


def x_summarize__mutmut_15(
    runs: list[dict[str, Any]],
    budgets: tuple[float, ...] = (0.01, 0.02, 0.05),
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Seed-mean per problem, then the median over problems with a source-resampled interval."""
    methods = sorted(
        {m for r in runs for m, seeds in r["runs"].items() if any("budgets" in s for s in seeds)}
    )
    table: dict[str, Any] = {}
    for method in methods:
        for budget in budgets:
            key = str(budget)
            usable = []
            for run in runs:
                seeds = [
                    s["BUDGETS"][key]
                    for s in run["runs"].get(method, [])
                    if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
                ]
                if seeds:
                    usable.append((run["problem"], seeds))
            if not usable:
                continue
            clusters = np.array([source_id(p) for p, _ in usable])
            cells = [c for _, seeds in usable for c in seeds]
            entry: dict[str, Any] = {
                "problems": len(usable), "seed_runs": len(cells),
                "min_positives": min(c["tp"] + c["fn"] for c in cells),
                "min_negatives": min(c["fp"] + c["tn"] for c in cells),
                "by_prevalence": {},
            }  # fmt: skip
            for pi in prevalences:
                per_problem = {
                    m: np.array(
                        [np.mean([shifted(c, pi)[m] for c in seeds]) for _, seeds in usable]
                    )
                    for m in METRICS
                }
                entry["by_prevalence"][str(pi)] = {
                    m: bootstrap(v, clusters, by_cluster=True, draws=draws)
                    for m, v in per_problem.items()
                }
            table.setdefault(method, {})[key] = entry
    return {"prevalences": list(prevalences), "budgets": list(budgets), "table": table}


def x_summarize__mutmut_16(
    runs: list[dict[str, Any]],
    budgets: tuple[float, ...] = (0.01, 0.02, 0.05),
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Seed-mean per problem, then the median over problems with a source-resampled interval."""
    methods = sorted(
        {m for r in runs for m, seeds in r["runs"].items() if any("budgets" in s for s in seeds)}
    )
    table: dict[str, Any] = {}
    for method in methods:
        for budget in budgets:
            key = str(budget)
            usable = []
            for run in runs:
                seeds = [
                    s["budgets"][key]
                    for s in run["runs"].get(None, [])
                    if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
                ]
                if seeds:
                    usable.append((run["problem"], seeds))
            if not usable:
                continue
            clusters = np.array([source_id(p) for p, _ in usable])
            cells = [c for _, seeds in usable for c in seeds]
            entry: dict[str, Any] = {
                "problems": len(usable), "seed_runs": len(cells),
                "min_positives": min(c["tp"] + c["fn"] for c in cells),
                "min_negatives": min(c["fp"] + c["tn"] for c in cells),
                "by_prevalence": {},
            }  # fmt: skip
            for pi in prevalences:
                per_problem = {
                    m: np.array(
                        [np.mean([shifted(c, pi)[m] for c in seeds]) for _, seeds in usable]
                    )
                    for m in METRICS
                }
                entry["by_prevalence"][str(pi)] = {
                    m: bootstrap(v, clusters, by_cluster=True, draws=draws)
                    for m, v in per_problem.items()
                }
            table.setdefault(method, {})[key] = entry
    return {"prevalences": list(prevalences), "budgets": list(budgets), "table": table}


def x_summarize__mutmut_17(
    runs: list[dict[str, Any]],
    budgets: tuple[float, ...] = (0.01, 0.02, 0.05),
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Seed-mean per problem, then the median over problems with a source-resampled interval."""
    methods = sorted(
        {m for r in runs for m, seeds in r["runs"].items() if any("budgets" in s for s in seeds)}
    )
    table: dict[str, Any] = {}
    for method in methods:
        for budget in budgets:
            key = str(budget)
            usable = []
            for run in runs:
                seeds = [
                    s["budgets"][key]
                    for s in run["runs"].get(method, None)
                    if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
                ]
                if seeds:
                    usable.append((run["problem"], seeds))
            if not usable:
                continue
            clusters = np.array([source_id(p) for p, _ in usable])
            cells = [c for _, seeds in usable for c in seeds]
            entry: dict[str, Any] = {
                "problems": len(usable), "seed_runs": len(cells),
                "min_positives": min(c["tp"] + c["fn"] for c in cells),
                "min_negatives": min(c["fp"] + c["tn"] for c in cells),
                "by_prevalence": {},
            }  # fmt: skip
            for pi in prevalences:
                per_problem = {
                    m: np.array(
                        [np.mean([shifted(c, pi)[m] for c in seeds]) for _, seeds in usable]
                    )
                    for m in METRICS
                }
                entry["by_prevalence"][str(pi)] = {
                    m: bootstrap(v, clusters, by_cluster=True, draws=draws)
                    for m, v in per_problem.items()
                }
            table.setdefault(method, {})[key] = entry
    return {"prevalences": list(prevalences), "budgets": list(budgets), "table": table}


def x_summarize__mutmut_18(
    runs: list[dict[str, Any]],
    budgets: tuple[float, ...] = (0.01, 0.02, 0.05),
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Seed-mean per problem, then the median over problems with a source-resampled interval."""
    methods = sorted(
        {m for r in runs for m, seeds in r["runs"].items() if any("budgets" in s for s in seeds)}
    )
    table: dict[str, Any] = {}
    for method in methods:
        for budget in budgets:
            key = str(budget)
            usable = []
            for run in runs:
                seeds = [
                    s["budgets"][key]
                    for s in run["runs"].get([])
                    if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
                ]
                if seeds:
                    usable.append((run["problem"], seeds))
            if not usable:
                continue
            clusters = np.array([source_id(p) for p, _ in usable])
            cells = [c for _, seeds in usable for c in seeds]
            entry: dict[str, Any] = {
                "problems": len(usable), "seed_runs": len(cells),
                "min_positives": min(c["tp"] + c["fn"] for c in cells),
                "min_negatives": min(c["fp"] + c["tn"] for c in cells),
                "by_prevalence": {},
            }  # fmt: skip
            for pi in prevalences:
                per_problem = {
                    m: np.array(
                        [np.mean([shifted(c, pi)[m] for c in seeds]) for _, seeds in usable]
                    )
                    for m in METRICS
                }
                entry["by_prevalence"][str(pi)] = {
                    m: bootstrap(v, clusters, by_cluster=True, draws=draws)
                    for m, v in per_problem.items()
                }
            table.setdefault(method, {})[key] = entry
    return {"prevalences": list(prevalences), "budgets": list(budgets), "table": table}


def x_summarize__mutmut_19(
    runs: list[dict[str, Any]],
    budgets: tuple[float, ...] = (0.01, 0.02, 0.05),
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Seed-mean per problem, then the median over problems with a source-resampled interval."""
    methods = sorted(
        {m for r in runs for m, seeds in r["runs"].items() if any("budgets" in s for s in seeds)}
    )
    table: dict[str, Any] = {}
    for method in methods:
        for budget in budgets:
            key = str(budget)
            usable = []
            for run in runs:
                seeds = [
                    s["budgets"][key]
                    for s in run["runs"].get(method, )
                    if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
                ]
                if seeds:
                    usable.append((run["problem"], seeds))
            if not usable:
                continue
            clusters = np.array([source_id(p) for p, _ in usable])
            cells = [c for _, seeds in usable for c in seeds]
            entry: dict[str, Any] = {
                "problems": len(usable), "seed_runs": len(cells),
                "min_positives": min(c["tp"] + c["fn"] for c in cells),
                "min_negatives": min(c["fp"] + c["tn"] for c in cells),
                "by_prevalence": {},
            }  # fmt: skip
            for pi in prevalences:
                per_problem = {
                    m: np.array(
                        [np.mean([shifted(c, pi)[m] for c in seeds]) for _, seeds in usable]
                    )
                    for m in METRICS
                }
                entry["by_prevalence"][str(pi)] = {
                    m: bootstrap(v, clusters, by_cluster=True, draws=draws)
                    for m, v in per_problem.items()
                }
            table.setdefault(method, {})[key] = entry
    return {"prevalences": list(prevalences), "budgets": list(budgets), "table": table}


def x_summarize__mutmut_20(
    runs: list[dict[str, Any]],
    budgets: tuple[float, ...] = (0.01, 0.02, 0.05),
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Seed-mean per problem, then the median over problems with a source-resampled interval."""
    methods = sorted(
        {m for r in runs for m, seeds in r["runs"].items() if any("budgets" in s for s in seeds)}
    )
    table: dict[str, Any] = {}
    for method in methods:
        for budget in budgets:
            key = str(budget)
            usable = []
            for run in runs:
                seeds = [
                    s["budgets"][key]
                    for s in run["XXrunsXX"].get(method, [])
                    if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
                ]
                if seeds:
                    usable.append((run["problem"], seeds))
            if not usable:
                continue
            clusters = np.array([source_id(p) for p, _ in usable])
            cells = [c for _, seeds in usable for c in seeds]
            entry: dict[str, Any] = {
                "problems": len(usable), "seed_runs": len(cells),
                "min_positives": min(c["tp"] + c["fn"] for c in cells),
                "min_negatives": min(c["fp"] + c["tn"] for c in cells),
                "by_prevalence": {},
            }  # fmt: skip
            for pi in prevalences:
                per_problem = {
                    m: np.array(
                        [np.mean([shifted(c, pi)[m] for c in seeds]) for _, seeds in usable]
                    )
                    for m in METRICS
                }
                entry["by_prevalence"][str(pi)] = {
                    m: bootstrap(v, clusters, by_cluster=True, draws=draws)
                    for m, v in per_problem.items()
                }
            table.setdefault(method, {})[key] = entry
    return {"prevalences": list(prevalences), "budgets": list(budgets), "table": table}


def x_summarize__mutmut_21(
    runs: list[dict[str, Any]],
    budgets: tuple[float, ...] = (0.01, 0.02, 0.05),
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Seed-mean per problem, then the median over problems with a source-resampled interval."""
    methods = sorted(
        {m for r in runs for m, seeds in r["runs"].items() if any("budgets" in s for s in seeds)}
    )
    table: dict[str, Any] = {}
    for method in methods:
        for budget in budgets:
            key = str(budget)
            usable = []
            for run in runs:
                seeds = [
                    s["budgets"][key]
                    for s in run["RUNS"].get(method, [])
                    if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
                ]
                if seeds:
                    usable.append((run["problem"], seeds))
            if not usable:
                continue
            clusters = np.array([source_id(p) for p, _ in usable])
            cells = [c for _, seeds in usable for c in seeds]
            entry: dict[str, Any] = {
                "problems": len(usable), "seed_runs": len(cells),
                "min_positives": min(c["tp"] + c["fn"] for c in cells),
                "min_negatives": min(c["fp"] + c["tn"] for c in cells),
                "by_prevalence": {},
            }  # fmt: skip
            for pi in prevalences:
                per_problem = {
                    m: np.array(
                        [np.mean([shifted(c, pi)[m] for c in seeds]) for _, seeds in usable]
                    )
                    for m in METRICS
                }
                entry["by_prevalence"][str(pi)] = {
                    m: bootstrap(v, clusters, by_cluster=True, draws=draws)
                    for m, v in per_problem.items()
                }
            table.setdefault(method, {})[key] = entry
    return {"prevalences": list(prevalences), "budgets": list(budgets), "table": table}


def x_summarize__mutmut_22(
    runs: list[dict[str, Any]],
    budgets: tuple[float, ...] = (0.01, 0.02, 0.05),
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Seed-mean per problem, then the median over problems with a source-resampled interval."""
    methods = sorted(
        {m for r in runs for m, seeds in r["runs"].items() if any("budgets" in s for s in seeds)}
    )
    table: dict[str, Any] = {}
    for method in methods:
        for budget in budgets:
            key = str(budget)
            usable = []
            for run in runs:
                seeds = [
                    s["budgets"][key]
                    for s in run["runs"].get(method, [])
                    if key in s.get("budgets", {}) or "infeasible" not in s["budgets"][key]
                ]
                if seeds:
                    usable.append((run["problem"], seeds))
            if not usable:
                continue
            clusters = np.array([source_id(p) for p, _ in usable])
            cells = [c for _, seeds in usable for c in seeds]
            entry: dict[str, Any] = {
                "problems": len(usable), "seed_runs": len(cells),
                "min_positives": min(c["tp"] + c["fn"] for c in cells),
                "min_negatives": min(c["fp"] + c["tn"] for c in cells),
                "by_prevalence": {},
            }  # fmt: skip
            for pi in prevalences:
                per_problem = {
                    m: np.array(
                        [np.mean([shifted(c, pi)[m] for c in seeds]) for _, seeds in usable]
                    )
                    for m in METRICS
                }
                entry["by_prevalence"][str(pi)] = {
                    m: bootstrap(v, clusters, by_cluster=True, draws=draws)
                    for m, v in per_problem.items()
                }
            table.setdefault(method, {})[key] = entry
    return {"prevalences": list(prevalences), "budgets": list(budgets), "table": table}


def x_summarize__mutmut_23(
    runs: list[dict[str, Any]],
    budgets: tuple[float, ...] = (0.01, 0.02, 0.05),
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Seed-mean per problem, then the median over problems with a source-resampled interval."""
    methods = sorted(
        {m for r in runs for m, seeds in r["runs"].items() if any("budgets" in s for s in seeds)}
    )
    table: dict[str, Any] = {}
    for method in methods:
        for budget in budgets:
            key = str(budget)
            usable = []
            for run in runs:
                seeds = [
                    s["budgets"][key]
                    for s in run["runs"].get(method, [])
                    if key not in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
                ]
                if seeds:
                    usable.append((run["problem"], seeds))
            if not usable:
                continue
            clusters = np.array([source_id(p) for p, _ in usable])
            cells = [c for _, seeds in usable for c in seeds]
            entry: dict[str, Any] = {
                "problems": len(usable), "seed_runs": len(cells),
                "min_positives": min(c["tp"] + c["fn"] for c in cells),
                "min_negatives": min(c["fp"] + c["tn"] for c in cells),
                "by_prevalence": {},
            }  # fmt: skip
            for pi in prevalences:
                per_problem = {
                    m: np.array(
                        [np.mean([shifted(c, pi)[m] for c in seeds]) for _, seeds in usable]
                    )
                    for m in METRICS
                }
                entry["by_prevalence"][str(pi)] = {
                    m: bootstrap(v, clusters, by_cluster=True, draws=draws)
                    for m, v in per_problem.items()
                }
            table.setdefault(method, {})[key] = entry
    return {"prevalences": list(prevalences), "budgets": list(budgets), "table": table}


def x_summarize__mutmut_24(
    runs: list[dict[str, Any]],
    budgets: tuple[float, ...] = (0.01, 0.02, 0.05),
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Seed-mean per problem, then the median over problems with a source-resampled interval."""
    methods = sorted(
        {m for r in runs for m, seeds in r["runs"].items() if any("budgets" in s for s in seeds)}
    )
    table: dict[str, Any] = {}
    for method in methods:
        for budget in budgets:
            key = str(budget)
            usable = []
            for run in runs:
                seeds = [
                    s["budgets"][key]
                    for s in run["runs"].get(method, [])
                    if key in s.get(None, {}) and "infeasible" not in s["budgets"][key]
                ]
                if seeds:
                    usable.append((run["problem"], seeds))
            if not usable:
                continue
            clusters = np.array([source_id(p) for p, _ in usable])
            cells = [c for _, seeds in usable for c in seeds]
            entry: dict[str, Any] = {
                "problems": len(usable), "seed_runs": len(cells),
                "min_positives": min(c["tp"] + c["fn"] for c in cells),
                "min_negatives": min(c["fp"] + c["tn"] for c in cells),
                "by_prevalence": {},
            }  # fmt: skip
            for pi in prevalences:
                per_problem = {
                    m: np.array(
                        [np.mean([shifted(c, pi)[m] for c in seeds]) for _, seeds in usable]
                    )
                    for m in METRICS
                }
                entry["by_prevalence"][str(pi)] = {
                    m: bootstrap(v, clusters, by_cluster=True, draws=draws)
                    for m, v in per_problem.items()
                }
            table.setdefault(method, {})[key] = entry
    return {"prevalences": list(prevalences), "budgets": list(budgets), "table": table}


def x_summarize__mutmut_25(
    runs: list[dict[str, Any]],
    budgets: tuple[float, ...] = (0.01, 0.02, 0.05),
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Seed-mean per problem, then the median over problems with a source-resampled interval."""
    methods = sorted(
        {m for r in runs for m, seeds in r["runs"].items() if any("budgets" in s for s in seeds)}
    )
    table: dict[str, Any] = {}
    for method in methods:
        for budget in budgets:
            key = str(budget)
            usable = []
            for run in runs:
                seeds = [
                    s["budgets"][key]
                    for s in run["runs"].get(method, [])
                    if key in s.get("budgets", None) and "infeasible" not in s["budgets"][key]
                ]
                if seeds:
                    usable.append((run["problem"], seeds))
            if not usable:
                continue
            clusters = np.array([source_id(p) for p, _ in usable])
            cells = [c for _, seeds in usable for c in seeds]
            entry: dict[str, Any] = {
                "problems": len(usable), "seed_runs": len(cells),
                "min_positives": min(c["tp"] + c["fn"] for c in cells),
                "min_negatives": min(c["fp"] + c["tn"] for c in cells),
                "by_prevalence": {},
            }  # fmt: skip
            for pi in prevalences:
                per_problem = {
                    m: np.array(
                        [np.mean([shifted(c, pi)[m] for c in seeds]) for _, seeds in usable]
                    )
                    for m in METRICS
                }
                entry["by_prevalence"][str(pi)] = {
                    m: bootstrap(v, clusters, by_cluster=True, draws=draws)
                    for m, v in per_problem.items()
                }
            table.setdefault(method, {})[key] = entry
    return {"prevalences": list(prevalences), "budgets": list(budgets), "table": table}


def x_summarize__mutmut_26(
    runs: list[dict[str, Any]],
    budgets: tuple[float, ...] = (0.01, 0.02, 0.05),
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Seed-mean per problem, then the median over problems with a source-resampled interval."""
    methods = sorted(
        {m for r in runs for m, seeds in r["runs"].items() if any("budgets" in s for s in seeds)}
    )
    table: dict[str, Any] = {}
    for method in methods:
        for budget in budgets:
            key = str(budget)
            usable = []
            for run in runs:
                seeds = [
                    s["budgets"][key]
                    for s in run["runs"].get(method, [])
                    if key in s.get({}) and "infeasible" not in s["budgets"][key]
                ]
                if seeds:
                    usable.append((run["problem"], seeds))
            if not usable:
                continue
            clusters = np.array([source_id(p) for p, _ in usable])
            cells = [c for _, seeds in usable for c in seeds]
            entry: dict[str, Any] = {
                "problems": len(usable), "seed_runs": len(cells),
                "min_positives": min(c["tp"] + c["fn"] for c in cells),
                "min_negatives": min(c["fp"] + c["tn"] for c in cells),
                "by_prevalence": {},
            }  # fmt: skip
            for pi in prevalences:
                per_problem = {
                    m: np.array(
                        [np.mean([shifted(c, pi)[m] for c in seeds]) for _, seeds in usable]
                    )
                    for m in METRICS
                }
                entry["by_prevalence"][str(pi)] = {
                    m: bootstrap(v, clusters, by_cluster=True, draws=draws)
                    for m, v in per_problem.items()
                }
            table.setdefault(method, {})[key] = entry
    return {"prevalences": list(prevalences), "budgets": list(budgets), "table": table}


def x_summarize__mutmut_27(
    runs: list[dict[str, Any]],
    budgets: tuple[float, ...] = (0.01, 0.02, 0.05),
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Seed-mean per problem, then the median over problems with a source-resampled interval."""
    methods = sorted(
        {m for r in runs for m, seeds in r["runs"].items() if any("budgets" in s for s in seeds)}
    )
    table: dict[str, Any] = {}
    for method in methods:
        for budget in budgets:
            key = str(budget)
            usable = []
            for run in runs:
                seeds = [
                    s["budgets"][key]
                    for s in run["runs"].get(method, [])
                    if key in s.get("budgets", ) and "infeasible" not in s["budgets"][key]
                ]
                if seeds:
                    usable.append((run["problem"], seeds))
            if not usable:
                continue
            clusters = np.array([source_id(p) for p, _ in usable])
            cells = [c for _, seeds in usable for c in seeds]
            entry: dict[str, Any] = {
                "problems": len(usable), "seed_runs": len(cells),
                "min_positives": min(c["tp"] + c["fn"] for c in cells),
                "min_negatives": min(c["fp"] + c["tn"] for c in cells),
                "by_prevalence": {},
            }  # fmt: skip
            for pi in prevalences:
                per_problem = {
                    m: np.array(
                        [np.mean([shifted(c, pi)[m] for c in seeds]) for _, seeds in usable]
                    )
                    for m in METRICS
                }
                entry["by_prevalence"][str(pi)] = {
                    m: bootstrap(v, clusters, by_cluster=True, draws=draws)
                    for m, v in per_problem.items()
                }
            table.setdefault(method, {})[key] = entry
    return {"prevalences": list(prevalences), "budgets": list(budgets), "table": table}


def x_summarize__mutmut_28(
    runs: list[dict[str, Any]],
    budgets: tuple[float, ...] = (0.01, 0.02, 0.05),
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Seed-mean per problem, then the median over problems with a source-resampled interval."""
    methods = sorted(
        {m for r in runs for m, seeds in r["runs"].items() if any("budgets" in s for s in seeds)}
    )
    table: dict[str, Any] = {}
    for method in methods:
        for budget in budgets:
            key = str(budget)
            usable = []
            for run in runs:
                seeds = [
                    s["budgets"][key]
                    for s in run["runs"].get(method, [])
                    if key in s.get("XXbudgetsXX", {}) and "infeasible" not in s["budgets"][key]
                ]
                if seeds:
                    usable.append((run["problem"], seeds))
            if not usable:
                continue
            clusters = np.array([source_id(p) for p, _ in usable])
            cells = [c for _, seeds in usable for c in seeds]
            entry: dict[str, Any] = {
                "problems": len(usable), "seed_runs": len(cells),
                "min_positives": min(c["tp"] + c["fn"] for c in cells),
                "min_negatives": min(c["fp"] + c["tn"] for c in cells),
                "by_prevalence": {},
            }  # fmt: skip
            for pi in prevalences:
                per_problem = {
                    m: np.array(
                        [np.mean([shifted(c, pi)[m] for c in seeds]) for _, seeds in usable]
                    )
                    for m in METRICS
                }
                entry["by_prevalence"][str(pi)] = {
                    m: bootstrap(v, clusters, by_cluster=True, draws=draws)
                    for m, v in per_problem.items()
                }
            table.setdefault(method, {})[key] = entry
    return {"prevalences": list(prevalences), "budgets": list(budgets), "table": table}


def x_summarize__mutmut_29(
    runs: list[dict[str, Any]],
    budgets: tuple[float, ...] = (0.01, 0.02, 0.05),
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Seed-mean per problem, then the median over problems with a source-resampled interval."""
    methods = sorted(
        {m for r in runs for m, seeds in r["runs"].items() if any("budgets" in s for s in seeds)}
    )
    table: dict[str, Any] = {}
    for method in methods:
        for budget in budgets:
            key = str(budget)
            usable = []
            for run in runs:
                seeds = [
                    s["budgets"][key]
                    for s in run["runs"].get(method, [])
                    if key in s.get("BUDGETS", {}) and "infeasible" not in s["budgets"][key]
                ]
                if seeds:
                    usable.append((run["problem"], seeds))
            if not usable:
                continue
            clusters = np.array([source_id(p) for p, _ in usable])
            cells = [c for _, seeds in usable for c in seeds]
            entry: dict[str, Any] = {
                "problems": len(usable), "seed_runs": len(cells),
                "min_positives": min(c["tp"] + c["fn"] for c in cells),
                "min_negatives": min(c["fp"] + c["tn"] for c in cells),
                "by_prevalence": {},
            }  # fmt: skip
            for pi in prevalences:
                per_problem = {
                    m: np.array(
                        [np.mean([shifted(c, pi)[m] for c in seeds]) for _, seeds in usable]
                    )
                    for m in METRICS
                }
                entry["by_prevalence"][str(pi)] = {
                    m: bootstrap(v, clusters, by_cluster=True, draws=draws)
                    for m, v in per_problem.items()
                }
            table.setdefault(method, {})[key] = entry
    return {"prevalences": list(prevalences), "budgets": list(budgets), "table": table}


def x_summarize__mutmut_30(
    runs: list[dict[str, Any]],
    budgets: tuple[float, ...] = (0.01, 0.02, 0.05),
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Seed-mean per problem, then the median over problems with a source-resampled interval."""
    methods = sorted(
        {m for r in runs for m, seeds in r["runs"].items() if any("budgets" in s for s in seeds)}
    )
    table: dict[str, Any] = {}
    for method in methods:
        for budget in budgets:
            key = str(budget)
            usable = []
            for run in runs:
                seeds = [
                    s["budgets"][key]
                    for s in run["runs"].get(method, [])
                    if key in s.get("budgets", {}) and "XXinfeasibleXX" not in s["budgets"][key]
                ]
                if seeds:
                    usable.append((run["problem"], seeds))
            if not usable:
                continue
            clusters = np.array([source_id(p) for p, _ in usable])
            cells = [c for _, seeds in usable for c in seeds]
            entry: dict[str, Any] = {
                "problems": len(usable), "seed_runs": len(cells),
                "min_positives": min(c["tp"] + c["fn"] for c in cells),
                "min_negatives": min(c["fp"] + c["tn"] for c in cells),
                "by_prevalence": {},
            }  # fmt: skip
            for pi in prevalences:
                per_problem = {
                    m: np.array(
                        [np.mean([shifted(c, pi)[m] for c in seeds]) for _, seeds in usable]
                    )
                    for m in METRICS
                }
                entry["by_prevalence"][str(pi)] = {
                    m: bootstrap(v, clusters, by_cluster=True, draws=draws)
                    for m, v in per_problem.items()
                }
            table.setdefault(method, {})[key] = entry
    return {"prevalences": list(prevalences), "budgets": list(budgets), "table": table}


def x_summarize__mutmut_31(
    runs: list[dict[str, Any]],
    budgets: tuple[float, ...] = (0.01, 0.02, 0.05),
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Seed-mean per problem, then the median over problems with a source-resampled interval."""
    methods = sorted(
        {m for r in runs for m, seeds in r["runs"].items() if any("budgets" in s for s in seeds)}
    )
    table: dict[str, Any] = {}
    for method in methods:
        for budget in budgets:
            key = str(budget)
            usable = []
            for run in runs:
                seeds = [
                    s["budgets"][key]
                    for s in run["runs"].get(method, [])
                    if key in s.get("budgets", {}) and "INFEASIBLE" not in s["budgets"][key]
                ]
                if seeds:
                    usable.append((run["problem"], seeds))
            if not usable:
                continue
            clusters = np.array([source_id(p) for p, _ in usable])
            cells = [c for _, seeds in usable for c in seeds]
            entry: dict[str, Any] = {
                "problems": len(usable), "seed_runs": len(cells),
                "min_positives": min(c["tp"] + c["fn"] for c in cells),
                "min_negatives": min(c["fp"] + c["tn"] for c in cells),
                "by_prevalence": {},
            }  # fmt: skip
            for pi in prevalences:
                per_problem = {
                    m: np.array(
                        [np.mean([shifted(c, pi)[m] for c in seeds]) for _, seeds in usable]
                    )
                    for m in METRICS
                }
                entry["by_prevalence"][str(pi)] = {
                    m: bootstrap(v, clusters, by_cluster=True, draws=draws)
                    for m, v in per_problem.items()
                }
            table.setdefault(method, {})[key] = entry
    return {"prevalences": list(prevalences), "budgets": list(budgets), "table": table}


def x_summarize__mutmut_32(
    runs: list[dict[str, Any]],
    budgets: tuple[float, ...] = (0.01, 0.02, 0.05),
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Seed-mean per problem, then the median over problems with a source-resampled interval."""
    methods = sorted(
        {m for r in runs for m, seeds in r["runs"].items() if any("budgets" in s for s in seeds)}
    )
    table: dict[str, Any] = {}
    for method in methods:
        for budget in budgets:
            key = str(budget)
            usable = []
            for run in runs:
                seeds = [
                    s["budgets"][key]
                    for s in run["runs"].get(method, [])
                    if key in s.get("budgets", {}) and "infeasible" in s["budgets"][key]
                ]
                if seeds:
                    usable.append((run["problem"], seeds))
            if not usable:
                continue
            clusters = np.array([source_id(p) for p, _ in usable])
            cells = [c for _, seeds in usable for c in seeds]
            entry: dict[str, Any] = {
                "problems": len(usable), "seed_runs": len(cells),
                "min_positives": min(c["tp"] + c["fn"] for c in cells),
                "min_negatives": min(c["fp"] + c["tn"] for c in cells),
                "by_prevalence": {},
            }  # fmt: skip
            for pi in prevalences:
                per_problem = {
                    m: np.array(
                        [np.mean([shifted(c, pi)[m] for c in seeds]) for _, seeds in usable]
                    )
                    for m in METRICS
                }
                entry["by_prevalence"][str(pi)] = {
                    m: bootstrap(v, clusters, by_cluster=True, draws=draws)
                    for m, v in per_problem.items()
                }
            table.setdefault(method, {})[key] = entry
    return {"prevalences": list(prevalences), "budgets": list(budgets), "table": table}


def x_summarize__mutmut_33(
    runs: list[dict[str, Any]],
    budgets: tuple[float, ...] = (0.01, 0.02, 0.05),
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Seed-mean per problem, then the median over problems with a source-resampled interval."""
    methods = sorted(
        {m for r in runs for m, seeds in r["runs"].items() if any("budgets" in s for s in seeds)}
    )
    table: dict[str, Any] = {}
    for method in methods:
        for budget in budgets:
            key = str(budget)
            usable = []
            for run in runs:
                seeds = [
                    s["budgets"][key]
                    for s in run["runs"].get(method, [])
                    if key in s.get("budgets", {}) and "infeasible" not in s["XXbudgetsXX"][key]
                ]
                if seeds:
                    usable.append((run["problem"], seeds))
            if not usable:
                continue
            clusters = np.array([source_id(p) for p, _ in usable])
            cells = [c for _, seeds in usable for c in seeds]
            entry: dict[str, Any] = {
                "problems": len(usable), "seed_runs": len(cells),
                "min_positives": min(c["tp"] + c["fn"] for c in cells),
                "min_negatives": min(c["fp"] + c["tn"] for c in cells),
                "by_prevalence": {},
            }  # fmt: skip
            for pi in prevalences:
                per_problem = {
                    m: np.array(
                        [np.mean([shifted(c, pi)[m] for c in seeds]) for _, seeds in usable]
                    )
                    for m in METRICS
                }
                entry["by_prevalence"][str(pi)] = {
                    m: bootstrap(v, clusters, by_cluster=True, draws=draws)
                    for m, v in per_problem.items()
                }
            table.setdefault(method, {})[key] = entry
    return {"prevalences": list(prevalences), "budgets": list(budgets), "table": table}


def x_summarize__mutmut_34(
    runs: list[dict[str, Any]],
    budgets: tuple[float, ...] = (0.01, 0.02, 0.05),
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Seed-mean per problem, then the median over problems with a source-resampled interval."""
    methods = sorted(
        {m for r in runs for m, seeds in r["runs"].items() if any("budgets" in s for s in seeds)}
    )
    table: dict[str, Any] = {}
    for method in methods:
        for budget in budgets:
            key = str(budget)
            usable = []
            for run in runs:
                seeds = [
                    s["budgets"][key]
                    for s in run["runs"].get(method, [])
                    if key in s.get("budgets", {}) and "infeasible" not in s["BUDGETS"][key]
                ]
                if seeds:
                    usable.append((run["problem"], seeds))
            if not usable:
                continue
            clusters = np.array([source_id(p) for p, _ in usable])
            cells = [c for _, seeds in usable for c in seeds]
            entry: dict[str, Any] = {
                "problems": len(usable), "seed_runs": len(cells),
                "min_positives": min(c["tp"] + c["fn"] for c in cells),
                "min_negatives": min(c["fp"] + c["tn"] for c in cells),
                "by_prevalence": {},
            }  # fmt: skip
            for pi in prevalences:
                per_problem = {
                    m: np.array(
                        [np.mean([shifted(c, pi)[m] for c in seeds]) for _, seeds in usable]
                    )
                    for m in METRICS
                }
                entry["by_prevalence"][str(pi)] = {
                    m: bootstrap(v, clusters, by_cluster=True, draws=draws)
                    for m, v in per_problem.items()
                }
            table.setdefault(method, {})[key] = entry
    return {"prevalences": list(prevalences), "budgets": list(budgets), "table": table}


def x_summarize__mutmut_35(
    runs: list[dict[str, Any]],
    budgets: tuple[float, ...] = (0.01, 0.02, 0.05),
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Seed-mean per problem, then the median over problems with a source-resampled interval."""
    methods = sorted(
        {m for r in runs for m, seeds in r["runs"].items() if any("budgets" in s for s in seeds)}
    )
    table: dict[str, Any] = {}
    for method in methods:
        for budget in budgets:
            key = str(budget)
            usable = []
            for run in runs:
                seeds = [
                    s["budgets"][key]
                    for s in run["runs"].get(method, [])
                    if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
                ]
                if seeds:
                    usable.append(None)
            if not usable:
                continue
            clusters = np.array([source_id(p) for p, _ in usable])
            cells = [c for _, seeds in usable for c in seeds]
            entry: dict[str, Any] = {
                "problems": len(usable), "seed_runs": len(cells),
                "min_positives": min(c["tp"] + c["fn"] for c in cells),
                "min_negatives": min(c["fp"] + c["tn"] for c in cells),
                "by_prevalence": {},
            }  # fmt: skip
            for pi in prevalences:
                per_problem = {
                    m: np.array(
                        [np.mean([shifted(c, pi)[m] for c in seeds]) for _, seeds in usable]
                    )
                    for m in METRICS
                }
                entry["by_prevalence"][str(pi)] = {
                    m: bootstrap(v, clusters, by_cluster=True, draws=draws)
                    for m, v in per_problem.items()
                }
            table.setdefault(method, {})[key] = entry
    return {"prevalences": list(prevalences), "budgets": list(budgets), "table": table}


def x_summarize__mutmut_36(
    runs: list[dict[str, Any]],
    budgets: tuple[float, ...] = (0.01, 0.02, 0.05),
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Seed-mean per problem, then the median over problems with a source-resampled interval."""
    methods = sorted(
        {m for r in runs for m, seeds in r["runs"].items() if any("budgets" in s for s in seeds)}
    )
    table: dict[str, Any] = {}
    for method in methods:
        for budget in budgets:
            key = str(budget)
            usable = []
            for run in runs:
                seeds = [
                    s["budgets"][key]
                    for s in run["runs"].get(method, [])
                    if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
                ]
                if seeds:
                    usable.append((run["XXproblemXX"], seeds))
            if not usable:
                continue
            clusters = np.array([source_id(p) for p, _ in usable])
            cells = [c for _, seeds in usable for c in seeds]
            entry: dict[str, Any] = {
                "problems": len(usable), "seed_runs": len(cells),
                "min_positives": min(c["tp"] + c["fn"] for c in cells),
                "min_negatives": min(c["fp"] + c["tn"] for c in cells),
                "by_prevalence": {},
            }  # fmt: skip
            for pi in prevalences:
                per_problem = {
                    m: np.array(
                        [np.mean([shifted(c, pi)[m] for c in seeds]) for _, seeds in usable]
                    )
                    for m in METRICS
                }
                entry["by_prevalence"][str(pi)] = {
                    m: bootstrap(v, clusters, by_cluster=True, draws=draws)
                    for m, v in per_problem.items()
                }
            table.setdefault(method, {})[key] = entry
    return {"prevalences": list(prevalences), "budgets": list(budgets), "table": table}


def x_summarize__mutmut_37(
    runs: list[dict[str, Any]],
    budgets: tuple[float, ...] = (0.01, 0.02, 0.05),
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Seed-mean per problem, then the median over problems with a source-resampled interval."""
    methods = sorted(
        {m for r in runs for m, seeds in r["runs"].items() if any("budgets" in s for s in seeds)}
    )
    table: dict[str, Any] = {}
    for method in methods:
        for budget in budgets:
            key = str(budget)
            usable = []
            for run in runs:
                seeds = [
                    s["budgets"][key]
                    for s in run["runs"].get(method, [])
                    if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
                ]
                if seeds:
                    usable.append((run["PROBLEM"], seeds))
            if not usable:
                continue
            clusters = np.array([source_id(p) for p, _ in usable])
            cells = [c for _, seeds in usable for c in seeds]
            entry: dict[str, Any] = {
                "problems": len(usable), "seed_runs": len(cells),
                "min_positives": min(c["tp"] + c["fn"] for c in cells),
                "min_negatives": min(c["fp"] + c["tn"] for c in cells),
                "by_prevalence": {},
            }  # fmt: skip
            for pi in prevalences:
                per_problem = {
                    m: np.array(
                        [np.mean([shifted(c, pi)[m] for c in seeds]) for _, seeds in usable]
                    )
                    for m in METRICS
                }
                entry["by_prevalence"][str(pi)] = {
                    m: bootstrap(v, clusters, by_cluster=True, draws=draws)
                    for m, v in per_problem.items()
                }
            table.setdefault(method, {})[key] = entry
    return {"prevalences": list(prevalences), "budgets": list(budgets), "table": table}


def x_summarize__mutmut_38(
    runs: list[dict[str, Any]],
    budgets: tuple[float, ...] = (0.01, 0.02, 0.05),
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Seed-mean per problem, then the median over problems with a source-resampled interval."""
    methods = sorted(
        {m for r in runs for m, seeds in r["runs"].items() if any("budgets" in s for s in seeds)}
    )
    table: dict[str, Any] = {}
    for method in methods:
        for budget in budgets:
            key = str(budget)
            usable = []
            for run in runs:
                seeds = [
                    s["budgets"][key]
                    for s in run["runs"].get(method, [])
                    if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
                ]
                if seeds:
                    usable.append((run["problem"], seeds))
            if usable:
                continue
            clusters = np.array([source_id(p) for p, _ in usable])
            cells = [c for _, seeds in usable for c in seeds]
            entry: dict[str, Any] = {
                "problems": len(usable), "seed_runs": len(cells),
                "min_positives": min(c["tp"] + c["fn"] for c in cells),
                "min_negatives": min(c["fp"] + c["tn"] for c in cells),
                "by_prevalence": {},
            }  # fmt: skip
            for pi in prevalences:
                per_problem = {
                    m: np.array(
                        [np.mean([shifted(c, pi)[m] for c in seeds]) for _, seeds in usable]
                    )
                    for m in METRICS
                }
                entry["by_prevalence"][str(pi)] = {
                    m: bootstrap(v, clusters, by_cluster=True, draws=draws)
                    for m, v in per_problem.items()
                }
            table.setdefault(method, {})[key] = entry
    return {"prevalences": list(prevalences), "budgets": list(budgets), "table": table}


def x_summarize__mutmut_39(
    runs: list[dict[str, Any]],
    budgets: tuple[float, ...] = (0.01, 0.02, 0.05),
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Seed-mean per problem, then the median over problems with a source-resampled interval."""
    methods = sorted(
        {m for r in runs for m, seeds in r["runs"].items() if any("budgets" in s for s in seeds)}
    )
    table: dict[str, Any] = {}
    for method in methods:
        for budget in budgets:
            key = str(budget)
            usable = []
            for run in runs:
                seeds = [
                    s["budgets"][key]
                    for s in run["runs"].get(method, [])
                    if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
                ]
                if seeds:
                    usable.append((run["problem"], seeds))
            if not usable:
                break
            clusters = np.array([source_id(p) for p, _ in usable])
            cells = [c for _, seeds in usable for c in seeds]
            entry: dict[str, Any] = {
                "problems": len(usable), "seed_runs": len(cells),
                "min_positives": min(c["tp"] + c["fn"] for c in cells),
                "min_negatives": min(c["fp"] + c["tn"] for c in cells),
                "by_prevalence": {},
            }  # fmt: skip
            for pi in prevalences:
                per_problem = {
                    m: np.array(
                        [np.mean([shifted(c, pi)[m] for c in seeds]) for _, seeds in usable]
                    )
                    for m in METRICS
                }
                entry["by_prevalence"][str(pi)] = {
                    m: bootstrap(v, clusters, by_cluster=True, draws=draws)
                    for m, v in per_problem.items()
                }
            table.setdefault(method, {})[key] = entry
    return {"prevalences": list(prevalences), "budgets": list(budgets), "table": table}


def x_summarize__mutmut_40(
    runs: list[dict[str, Any]],
    budgets: tuple[float, ...] = (0.01, 0.02, 0.05),
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Seed-mean per problem, then the median over problems with a source-resampled interval."""
    methods = sorted(
        {m for r in runs for m, seeds in r["runs"].items() if any("budgets" in s for s in seeds)}
    )
    table: dict[str, Any] = {}
    for method in methods:
        for budget in budgets:
            key = str(budget)
            usable = []
            for run in runs:
                seeds = [
                    s["budgets"][key]
                    for s in run["runs"].get(method, [])
                    if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
                ]
                if seeds:
                    usable.append((run["problem"], seeds))
            if not usable:
                continue
            clusters = None
            cells = [c for _, seeds in usable for c in seeds]
            entry: dict[str, Any] = {
                "problems": len(usable), "seed_runs": len(cells),
                "min_positives": min(c["tp"] + c["fn"] for c in cells),
                "min_negatives": min(c["fp"] + c["tn"] for c in cells),
                "by_prevalence": {},
            }  # fmt: skip
            for pi in prevalences:
                per_problem = {
                    m: np.array(
                        [np.mean([shifted(c, pi)[m] for c in seeds]) for _, seeds in usable]
                    )
                    for m in METRICS
                }
                entry["by_prevalence"][str(pi)] = {
                    m: bootstrap(v, clusters, by_cluster=True, draws=draws)
                    for m, v in per_problem.items()
                }
            table.setdefault(method, {})[key] = entry
    return {"prevalences": list(prevalences), "budgets": list(budgets), "table": table}


def x_summarize__mutmut_41(
    runs: list[dict[str, Any]],
    budgets: tuple[float, ...] = (0.01, 0.02, 0.05),
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Seed-mean per problem, then the median over problems with a source-resampled interval."""
    methods = sorted(
        {m for r in runs for m, seeds in r["runs"].items() if any("budgets" in s for s in seeds)}
    )
    table: dict[str, Any] = {}
    for method in methods:
        for budget in budgets:
            key = str(budget)
            usable = []
            for run in runs:
                seeds = [
                    s["budgets"][key]
                    for s in run["runs"].get(method, [])
                    if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
                ]
                if seeds:
                    usable.append((run["problem"], seeds))
            if not usable:
                continue
            clusters = np.array(None)
            cells = [c for _, seeds in usable for c in seeds]
            entry: dict[str, Any] = {
                "problems": len(usable), "seed_runs": len(cells),
                "min_positives": min(c["tp"] + c["fn"] for c in cells),
                "min_negatives": min(c["fp"] + c["tn"] for c in cells),
                "by_prevalence": {},
            }  # fmt: skip
            for pi in prevalences:
                per_problem = {
                    m: np.array(
                        [np.mean([shifted(c, pi)[m] for c in seeds]) for _, seeds in usable]
                    )
                    for m in METRICS
                }
                entry["by_prevalence"][str(pi)] = {
                    m: bootstrap(v, clusters, by_cluster=True, draws=draws)
                    for m, v in per_problem.items()
                }
            table.setdefault(method, {})[key] = entry
    return {"prevalences": list(prevalences), "budgets": list(budgets), "table": table}


def x_summarize__mutmut_42(
    runs: list[dict[str, Any]],
    budgets: tuple[float, ...] = (0.01, 0.02, 0.05),
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Seed-mean per problem, then the median over problems with a source-resampled interval."""
    methods = sorted(
        {m for r in runs for m, seeds in r["runs"].items() if any("budgets" in s for s in seeds)}
    )
    table: dict[str, Any] = {}
    for method in methods:
        for budget in budgets:
            key = str(budget)
            usable = []
            for run in runs:
                seeds = [
                    s["budgets"][key]
                    for s in run["runs"].get(method, [])
                    if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
                ]
                if seeds:
                    usable.append((run["problem"], seeds))
            if not usable:
                continue
            clusters = np.array([source_id(None) for p, _ in usable])
            cells = [c for _, seeds in usable for c in seeds]
            entry: dict[str, Any] = {
                "problems": len(usable), "seed_runs": len(cells),
                "min_positives": min(c["tp"] + c["fn"] for c in cells),
                "min_negatives": min(c["fp"] + c["tn"] for c in cells),
                "by_prevalence": {},
            }  # fmt: skip
            for pi in prevalences:
                per_problem = {
                    m: np.array(
                        [np.mean([shifted(c, pi)[m] for c in seeds]) for _, seeds in usable]
                    )
                    for m in METRICS
                }
                entry["by_prevalence"][str(pi)] = {
                    m: bootstrap(v, clusters, by_cluster=True, draws=draws)
                    for m, v in per_problem.items()
                }
            table.setdefault(method, {})[key] = entry
    return {"prevalences": list(prevalences), "budgets": list(budgets), "table": table}


def x_summarize__mutmut_43(
    runs: list[dict[str, Any]],
    budgets: tuple[float, ...] = (0.01, 0.02, 0.05),
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Seed-mean per problem, then the median over problems with a source-resampled interval."""
    methods = sorted(
        {m for r in runs for m, seeds in r["runs"].items() if any("budgets" in s for s in seeds)}
    )
    table: dict[str, Any] = {}
    for method in methods:
        for budget in budgets:
            key = str(budget)
            usable = []
            for run in runs:
                seeds = [
                    s["budgets"][key]
                    for s in run["runs"].get(method, [])
                    if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
                ]
                if seeds:
                    usable.append((run["problem"], seeds))
            if not usable:
                continue
            clusters = np.array([source_id(p) for p, _ in usable])
            cells = None
            entry: dict[str, Any] = {
                "problems": len(usable), "seed_runs": len(cells),
                "min_positives": min(c["tp"] + c["fn"] for c in cells),
                "min_negatives": min(c["fp"] + c["tn"] for c in cells),
                "by_prevalence": {},
            }  # fmt: skip
            for pi in prevalences:
                per_problem = {
                    m: np.array(
                        [np.mean([shifted(c, pi)[m] for c in seeds]) for _, seeds in usable]
                    )
                    for m in METRICS
                }
                entry["by_prevalence"][str(pi)] = {
                    m: bootstrap(v, clusters, by_cluster=True, draws=draws)
                    for m, v in per_problem.items()
                }
            table.setdefault(method, {})[key] = entry
    return {"prevalences": list(prevalences), "budgets": list(budgets), "table": table}


def x_summarize__mutmut_44(
    runs: list[dict[str, Any]],
    budgets: tuple[float, ...] = (0.01, 0.02, 0.05),
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Seed-mean per problem, then the median over problems with a source-resampled interval."""
    methods = sorted(
        {m for r in runs for m, seeds in r["runs"].items() if any("budgets" in s for s in seeds)}
    )
    table: dict[str, Any] = {}
    for method in methods:
        for budget in budgets:
            key = str(budget)
            usable = []
            for run in runs:
                seeds = [
                    s["budgets"][key]
                    for s in run["runs"].get(method, [])
                    if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
                ]
                if seeds:
                    usable.append((run["problem"], seeds))
            if not usable:
                continue
            clusters = np.array([source_id(p) for p, _ in usable])
            cells = [c for _, seeds in usable for c in seeds]
            entry: dict[str, Any] = None  # fmt: skip
            for pi in prevalences:
                per_problem = {
                    m: np.array(
                        [np.mean([shifted(c, pi)[m] for c in seeds]) for _, seeds in usable]
                    )
                    for m in METRICS
                }
                entry["by_prevalence"][str(pi)] = {
                    m: bootstrap(v, clusters, by_cluster=True, draws=draws)
                    for m, v in per_problem.items()
                }
            table.setdefault(method, {})[key] = entry
    return {"prevalences": list(prevalences), "budgets": list(budgets), "table": table}


def x_summarize__mutmut_45(
    runs: list[dict[str, Any]],
    budgets: tuple[float, ...] = (0.01, 0.02, 0.05),
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Seed-mean per problem, then the median over problems with a source-resampled interval."""
    methods = sorted(
        {m for r in runs for m, seeds in r["runs"].items() if any("budgets" in s for s in seeds)}
    )
    table: dict[str, Any] = {}
    for method in methods:
        for budget in budgets:
            key = str(budget)
            usable = []
            for run in runs:
                seeds = [
                    s["budgets"][key]
                    for s in run["runs"].get(method, [])
                    if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
                ]
                if seeds:
                    usable.append((run["problem"], seeds))
            if not usable:
                continue
            clusters = np.array([source_id(p) for p, _ in usable])
            cells = [c for _, seeds in usable for c in seeds]
            entry: dict[str, Any] = {
                "XXproblemsXX": len(usable), "seed_runs": len(cells),
                "min_positives": min(c["tp"] + c["fn"] for c in cells),
                "min_negatives": min(c["fp"] + c["tn"] for c in cells),
                "by_prevalence": {},
            }  # fmt: skip
            for pi in prevalences:
                per_problem = {
                    m: np.array(
                        [np.mean([shifted(c, pi)[m] for c in seeds]) for _, seeds in usable]
                    )
                    for m in METRICS
                }
                entry["by_prevalence"][str(pi)] = {
                    m: bootstrap(v, clusters, by_cluster=True, draws=draws)
                    for m, v in per_problem.items()
                }
            table.setdefault(method, {})[key] = entry
    return {"prevalences": list(prevalences), "budgets": list(budgets), "table": table}


def x_summarize__mutmut_46(
    runs: list[dict[str, Any]],
    budgets: tuple[float, ...] = (0.01, 0.02, 0.05),
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Seed-mean per problem, then the median over problems with a source-resampled interval."""
    methods = sorted(
        {m for r in runs for m, seeds in r["runs"].items() if any("budgets" in s for s in seeds)}
    )
    table: dict[str, Any] = {}
    for method in methods:
        for budget in budgets:
            key = str(budget)
            usable = []
            for run in runs:
                seeds = [
                    s["budgets"][key]
                    for s in run["runs"].get(method, [])
                    if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
                ]
                if seeds:
                    usable.append((run["problem"], seeds))
            if not usable:
                continue
            clusters = np.array([source_id(p) for p, _ in usable])
            cells = [c for _, seeds in usable for c in seeds]
            entry: dict[str, Any] = {
                "PROBLEMS": len(usable), "seed_runs": len(cells),
                "min_positives": min(c["tp"] + c["fn"] for c in cells),
                "min_negatives": min(c["fp"] + c["tn"] for c in cells),
                "by_prevalence": {},
            }  # fmt: skip
            for pi in prevalences:
                per_problem = {
                    m: np.array(
                        [np.mean([shifted(c, pi)[m] for c in seeds]) for _, seeds in usable]
                    )
                    for m in METRICS
                }
                entry["by_prevalence"][str(pi)] = {
                    m: bootstrap(v, clusters, by_cluster=True, draws=draws)
                    for m, v in per_problem.items()
                }
            table.setdefault(method, {})[key] = entry
    return {"prevalences": list(prevalences), "budgets": list(budgets), "table": table}


def x_summarize__mutmut_47(
    runs: list[dict[str, Any]],
    budgets: tuple[float, ...] = (0.01, 0.02, 0.05),
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Seed-mean per problem, then the median over problems with a source-resampled interval."""
    methods = sorted(
        {m for r in runs for m, seeds in r["runs"].items() if any("budgets" in s for s in seeds)}
    )
    table: dict[str, Any] = {}
    for method in methods:
        for budget in budgets:
            key = str(budget)
            usable = []
            for run in runs:
                seeds = [
                    s["budgets"][key]
                    for s in run["runs"].get(method, [])
                    if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
                ]
                if seeds:
                    usable.append((run["problem"], seeds))
            if not usable:
                continue
            clusters = np.array([source_id(p) for p, _ in usable])
            cells = [c for _, seeds in usable for c in seeds]
            entry: dict[str, Any] = {
                "problems": len(usable), "XXseed_runsXX": len(cells),
                "min_positives": min(c["tp"] + c["fn"] for c in cells),
                "min_negatives": min(c["fp"] + c["tn"] for c in cells),
                "by_prevalence": {},
            }  # fmt: skip
            for pi in prevalences:
                per_problem = {
                    m: np.array(
                        [np.mean([shifted(c, pi)[m] for c in seeds]) for _, seeds in usable]
                    )
                    for m in METRICS
                }
                entry["by_prevalence"][str(pi)] = {
                    m: bootstrap(v, clusters, by_cluster=True, draws=draws)
                    for m, v in per_problem.items()
                }
            table.setdefault(method, {})[key] = entry
    return {"prevalences": list(prevalences), "budgets": list(budgets), "table": table}


def x_summarize__mutmut_48(
    runs: list[dict[str, Any]],
    budgets: tuple[float, ...] = (0.01, 0.02, 0.05),
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Seed-mean per problem, then the median over problems with a source-resampled interval."""
    methods = sorted(
        {m for r in runs for m, seeds in r["runs"].items() if any("budgets" in s for s in seeds)}
    )
    table: dict[str, Any] = {}
    for method in methods:
        for budget in budgets:
            key = str(budget)
            usable = []
            for run in runs:
                seeds = [
                    s["budgets"][key]
                    for s in run["runs"].get(method, [])
                    if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
                ]
                if seeds:
                    usable.append((run["problem"], seeds))
            if not usable:
                continue
            clusters = np.array([source_id(p) for p, _ in usable])
            cells = [c for _, seeds in usable for c in seeds]
            entry: dict[str, Any] = {
                "problems": len(usable), "SEED_RUNS": len(cells),
                "min_positives": min(c["tp"] + c["fn"] for c in cells),
                "min_negatives": min(c["fp"] + c["tn"] for c in cells),
                "by_prevalence": {},
            }  # fmt: skip
            for pi in prevalences:
                per_problem = {
                    m: np.array(
                        [np.mean([shifted(c, pi)[m] for c in seeds]) for _, seeds in usable]
                    )
                    for m in METRICS
                }
                entry["by_prevalence"][str(pi)] = {
                    m: bootstrap(v, clusters, by_cluster=True, draws=draws)
                    for m, v in per_problem.items()
                }
            table.setdefault(method, {})[key] = entry
    return {"prevalences": list(prevalences), "budgets": list(budgets), "table": table}


def x_summarize__mutmut_49(
    runs: list[dict[str, Any]],
    budgets: tuple[float, ...] = (0.01, 0.02, 0.05),
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Seed-mean per problem, then the median over problems with a source-resampled interval."""
    methods = sorted(
        {m for r in runs for m, seeds in r["runs"].items() if any("budgets" in s for s in seeds)}
    )
    table: dict[str, Any] = {}
    for method in methods:
        for budget in budgets:
            key = str(budget)
            usable = []
            for run in runs:
                seeds = [
                    s["budgets"][key]
                    for s in run["runs"].get(method, [])
                    if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
                ]
                if seeds:
                    usable.append((run["problem"], seeds))
            if not usable:
                continue
            clusters = np.array([source_id(p) for p, _ in usable])
            cells = [c for _, seeds in usable for c in seeds]
            entry: dict[str, Any] = {
                "problems": len(usable), "seed_runs": len(cells),
                "XXmin_positivesXX": min(c["tp"] + c["fn"] for c in cells),
                "min_negatives": min(c["fp"] + c["tn"] for c in cells),
                "by_prevalence": {},
            }  # fmt: skip
            for pi in prevalences:
                per_problem = {
                    m: np.array(
                        [np.mean([shifted(c, pi)[m] for c in seeds]) for _, seeds in usable]
                    )
                    for m in METRICS
                }
                entry["by_prevalence"][str(pi)] = {
                    m: bootstrap(v, clusters, by_cluster=True, draws=draws)
                    for m, v in per_problem.items()
                }
            table.setdefault(method, {})[key] = entry
    return {"prevalences": list(prevalences), "budgets": list(budgets), "table": table}


def x_summarize__mutmut_50(
    runs: list[dict[str, Any]],
    budgets: tuple[float, ...] = (0.01, 0.02, 0.05),
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Seed-mean per problem, then the median over problems with a source-resampled interval."""
    methods = sorted(
        {m for r in runs for m, seeds in r["runs"].items() if any("budgets" in s for s in seeds)}
    )
    table: dict[str, Any] = {}
    for method in methods:
        for budget in budgets:
            key = str(budget)
            usable = []
            for run in runs:
                seeds = [
                    s["budgets"][key]
                    for s in run["runs"].get(method, [])
                    if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
                ]
                if seeds:
                    usable.append((run["problem"], seeds))
            if not usable:
                continue
            clusters = np.array([source_id(p) for p, _ in usable])
            cells = [c for _, seeds in usable for c in seeds]
            entry: dict[str, Any] = {
                "problems": len(usable), "seed_runs": len(cells),
                "MIN_POSITIVES": min(c["tp"] + c["fn"] for c in cells),
                "min_negatives": min(c["fp"] + c["tn"] for c in cells),
                "by_prevalence": {},
            }  # fmt: skip
            for pi in prevalences:
                per_problem = {
                    m: np.array(
                        [np.mean([shifted(c, pi)[m] for c in seeds]) for _, seeds in usable]
                    )
                    for m in METRICS
                }
                entry["by_prevalence"][str(pi)] = {
                    m: bootstrap(v, clusters, by_cluster=True, draws=draws)
                    for m, v in per_problem.items()
                }
            table.setdefault(method, {})[key] = entry
    return {"prevalences": list(prevalences), "budgets": list(budgets), "table": table}


def x_summarize__mutmut_51(
    runs: list[dict[str, Any]],
    budgets: tuple[float, ...] = (0.01, 0.02, 0.05),
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Seed-mean per problem, then the median over problems with a source-resampled interval."""
    methods = sorted(
        {m for r in runs for m, seeds in r["runs"].items() if any("budgets" in s for s in seeds)}
    )
    table: dict[str, Any] = {}
    for method in methods:
        for budget in budgets:
            key = str(budget)
            usable = []
            for run in runs:
                seeds = [
                    s["budgets"][key]
                    for s in run["runs"].get(method, [])
                    if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
                ]
                if seeds:
                    usable.append((run["problem"], seeds))
            if not usable:
                continue
            clusters = np.array([source_id(p) for p, _ in usable])
            cells = [c for _, seeds in usable for c in seeds]
            entry: dict[str, Any] = {
                "problems": len(usable), "seed_runs": len(cells),
                "min_positives": min(None),
                "min_negatives": min(c["fp"] + c["tn"] for c in cells),
                "by_prevalence": {},
            }  # fmt: skip
            for pi in prevalences:
                per_problem = {
                    m: np.array(
                        [np.mean([shifted(c, pi)[m] for c in seeds]) for _, seeds in usable]
                    )
                    for m in METRICS
                }
                entry["by_prevalence"][str(pi)] = {
                    m: bootstrap(v, clusters, by_cluster=True, draws=draws)
                    for m, v in per_problem.items()
                }
            table.setdefault(method, {})[key] = entry
    return {"prevalences": list(prevalences), "budgets": list(budgets), "table": table}


def x_summarize__mutmut_52(
    runs: list[dict[str, Any]],
    budgets: tuple[float, ...] = (0.01, 0.02, 0.05),
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Seed-mean per problem, then the median over problems with a source-resampled interval."""
    methods = sorted(
        {m for r in runs for m, seeds in r["runs"].items() if any("budgets" in s for s in seeds)}
    )
    table: dict[str, Any] = {}
    for method in methods:
        for budget in budgets:
            key = str(budget)
            usable = []
            for run in runs:
                seeds = [
                    s["budgets"][key]
                    for s in run["runs"].get(method, [])
                    if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
                ]
                if seeds:
                    usable.append((run["problem"], seeds))
            if not usable:
                continue
            clusters = np.array([source_id(p) for p, _ in usable])
            cells = [c for _, seeds in usable for c in seeds]
            entry: dict[str, Any] = {
                "problems": len(usable), "seed_runs": len(cells),
                "min_positives": min(c["tp"] - c["fn"] for c in cells),
                "min_negatives": min(c["fp"] + c["tn"] for c in cells),
                "by_prevalence": {},
            }  # fmt: skip
            for pi in prevalences:
                per_problem = {
                    m: np.array(
                        [np.mean([shifted(c, pi)[m] for c in seeds]) for _, seeds in usable]
                    )
                    for m in METRICS
                }
                entry["by_prevalence"][str(pi)] = {
                    m: bootstrap(v, clusters, by_cluster=True, draws=draws)
                    for m, v in per_problem.items()
                }
            table.setdefault(method, {})[key] = entry
    return {"prevalences": list(prevalences), "budgets": list(budgets), "table": table}


def x_summarize__mutmut_53(
    runs: list[dict[str, Any]],
    budgets: tuple[float, ...] = (0.01, 0.02, 0.05),
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Seed-mean per problem, then the median over problems with a source-resampled interval."""
    methods = sorted(
        {m for r in runs for m, seeds in r["runs"].items() if any("budgets" in s for s in seeds)}
    )
    table: dict[str, Any] = {}
    for method in methods:
        for budget in budgets:
            key = str(budget)
            usable = []
            for run in runs:
                seeds = [
                    s["budgets"][key]
                    for s in run["runs"].get(method, [])
                    if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
                ]
                if seeds:
                    usable.append((run["problem"], seeds))
            if not usable:
                continue
            clusters = np.array([source_id(p) for p, _ in usable])
            cells = [c for _, seeds in usable for c in seeds]
            entry: dict[str, Any] = {
                "problems": len(usable), "seed_runs": len(cells),
                "min_positives": min(c["XXtpXX"] + c["fn"] for c in cells),
                "min_negatives": min(c["fp"] + c["tn"] for c in cells),
                "by_prevalence": {},
            }  # fmt: skip
            for pi in prevalences:
                per_problem = {
                    m: np.array(
                        [np.mean([shifted(c, pi)[m] for c in seeds]) for _, seeds in usable]
                    )
                    for m in METRICS
                }
                entry["by_prevalence"][str(pi)] = {
                    m: bootstrap(v, clusters, by_cluster=True, draws=draws)
                    for m, v in per_problem.items()
                }
            table.setdefault(method, {})[key] = entry
    return {"prevalences": list(prevalences), "budgets": list(budgets), "table": table}


def x_summarize__mutmut_54(
    runs: list[dict[str, Any]],
    budgets: tuple[float, ...] = (0.01, 0.02, 0.05),
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Seed-mean per problem, then the median over problems with a source-resampled interval."""
    methods = sorted(
        {m for r in runs for m, seeds in r["runs"].items() if any("budgets" in s for s in seeds)}
    )
    table: dict[str, Any] = {}
    for method in methods:
        for budget in budgets:
            key = str(budget)
            usable = []
            for run in runs:
                seeds = [
                    s["budgets"][key]
                    for s in run["runs"].get(method, [])
                    if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
                ]
                if seeds:
                    usable.append((run["problem"], seeds))
            if not usable:
                continue
            clusters = np.array([source_id(p) for p, _ in usable])
            cells = [c for _, seeds in usable for c in seeds]
            entry: dict[str, Any] = {
                "problems": len(usable), "seed_runs": len(cells),
                "min_positives": min(c["TP"] + c["fn"] for c in cells),
                "min_negatives": min(c["fp"] + c["tn"] for c in cells),
                "by_prevalence": {},
            }  # fmt: skip
            for pi in prevalences:
                per_problem = {
                    m: np.array(
                        [np.mean([shifted(c, pi)[m] for c in seeds]) for _, seeds in usable]
                    )
                    for m in METRICS
                }
                entry["by_prevalence"][str(pi)] = {
                    m: bootstrap(v, clusters, by_cluster=True, draws=draws)
                    for m, v in per_problem.items()
                }
            table.setdefault(method, {})[key] = entry
    return {"prevalences": list(prevalences), "budgets": list(budgets), "table": table}


def x_summarize__mutmut_55(
    runs: list[dict[str, Any]],
    budgets: tuple[float, ...] = (0.01, 0.02, 0.05),
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Seed-mean per problem, then the median over problems with a source-resampled interval."""
    methods = sorted(
        {m for r in runs for m, seeds in r["runs"].items() if any("budgets" in s for s in seeds)}
    )
    table: dict[str, Any] = {}
    for method in methods:
        for budget in budgets:
            key = str(budget)
            usable = []
            for run in runs:
                seeds = [
                    s["budgets"][key]
                    for s in run["runs"].get(method, [])
                    if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
                ]
                if seeds:
                    usable.append((run["problem"], seeds))
            if not usable:
                continue
            clusters = np.array([source_id(p) for p, _ in usable])
            cells = [c for _, seeds in usable for c in seeds]
            entry: dict[str, Any] = {
                "problems": len(usable), "seed_runs": len(cells),
                "min_positives": min(c["tp"] + c["XXfnXX"] for c in cells),
                "min_negatives": min(c["fp"] + c["tn"] for c in cells),
                "by_prevalence": {},
            }  # fmt: skip
            for pi in prevalences:
                per_problem = {
                    m: np.array(
                        [np.mean([shifted(c, pi)[m] for c in seeds]) for _, seeds in usable]
                    )
                    for m in METRICS
                }
                entry["by_prevalence"][str(pi)] = {
                    m: bootstrap(v, clusters, by_cluster=True, draws=draws)
                    for m, v in per_problem.items()
                }
            table.setdefault(method, {})[key] = entry
    return {"prevalences": list(prevalences), "budgets": list(budgets), "table": table}


def x_summarize__mutmut_56(
    runs: list[dict[str, Any]],
    budgets: tuple[float, ...] = (0.01, 0.02, 0.05),
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Seed-mean per problem, then the median over problems with a source-resampled interval."""
    methods = sorted(
        {m for r in runs for m, seeds in r["runs"].items() if any("budgets" in s for s in seeds)}
    )
    table: dict[str, Any] = {}
    for method in methods:
        for budget in budgets:
            key = str(budget)
            usable = []
            for run in runs:
                seeds = [
                    s["budgets"][key]
                    for s in run["runs"].get(method, [])
                    if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
                ]
                if seeds:
                    usable.append((run["problem"], seeds))
            if not usable:
                continue
            clusters = np.array([source_id(p) for p, _ in usable])
            cells = [c for _, seeds in usable for c in seeds]
            entry: dict[str, Any] = {
                "problems": len(usable), "seed_runs": len(cells),
                "min_positives": min(c["tp"] + c["FN"] for c in cells),
                "min_negatives": min(c["fp"] + c["tn"] for c in cells),
                "by_prevalence": {},
            }  # fmt: skip
            for pi in prevalences:
                per_problem = {
                    m: np.array(
                        [np.mean([shifted(c, pi)[m] for c in seeds]) for _, seeds in usable]
                    )
                    for m in METRICS
                }
                entry["by_prevalence"][str(pi)] = {
                    m: bootstrap(v, clusters, by_cluster=True, draws=draws)
                    for m, v in per_problem.items()
                }
            table.setdefault(method, {})[key] = entry
    return {"prevalences": list(prevalences), "budgets": list(budgets), "table": table}


def x_summarize__mutmut_57(
    runs: list[dict[str, Any]],
    budgets: tuple[float, ...] = (0.01, 0.02, 0.05),
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Seed-mean per problem, then the median over problems with a source-resampled interval."""
    methods = sorted(
        {m for r in runs for m, seeds in r["runs"].items() if any("budgets" in s for s in seeds)}
    )
    table: dict[str, Any] = {}
    for method in methods:
        for budget in budgets:
            key = str(budget)
            usable = []
            for run in runs:
                seeds = [
                    s["budgets"][key]
                    for s in run["runs"].get(method, [])
                    if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
                ]
                if seeds:
                    usable.append((run["problem"], seeds))
            if not usable:
                continue
            clusters = np.array([source_id(p) for p, _ in usable])
            cells = [c for _, seeds in usable for c in seeds]
            entry: dict[str, Any] = {
                "problems": len(usable), "seed_runs": len(cells),
                "min_positives": min(c["tp"] + c["fn"] for c in cells),
                "XXmin_negativesXX": min(c["fp"] + c["tn"] for c in cells),
                "by_prevalence": {},
            }  # fmt: skip
            for pi in prevalences:
                per_problem = {
                    m: np.array(
                        [np.mean([shifted(c, pi)[m] for c in seeds]) for _, seeds in usable]
                    )
                    for m in METRICS
                }
                entry["by_prevalence"][str(pi)] = {
                    m: bootstrap(v, clusters, by_cluster=True, draws=draws)
                    for m, v in per_problem.items()
                }
            table.setdefault(method, {})[key] = entry
    return {"prevalences": list(prevalences), "budgets": list(budgets), "table": table}


def x_summarize__mutmut_58(
    runs: list[dict[str, Any]],
    budgets: tuple[float, ...] = (0.01, 0.02, 0.05),
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Seed-mean per problem, then the median over problems with a source-resampled interval."""
    methods = sorted(
        {m for r in runs for m, seeds in r["runs"].items() if any("budgets" in s for s in seeds)}
    )
    table: dict[str, Any] = {}
    for method in methods:
        for budget in budgets:
            key = str(budget)
            usable = []
            for run in runs:
                seeds = [
                    s["budgets"][key]
                    for s in run["runs"].get(method, [])
                    if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
                ]
                if seeds:
                    usable.append((run["problem"], seeds))
            if not usable:
                continue
            clusters = np.array([source_id(p) for p, _ in usable])
            cells = [c for _, seeds in usable for c in seeds]
            entry: dict[str, Any] = {
                "problems": len(usable), "seed_runs": len(cells),
                "min_positives": min(c["tp"] + c["fn"] for c in cells),
                "MIN_NEGATIVES": min(c["fp"] + c["tn"] for c in cells),
                "by_prevalence": {},
            }  # fmt: skip
            for pi in prevalences:
                per_problem = {
                    m: np.array(
                        [np.mean([shifted(c, pi)[m] for c in seeds]) for _, seeds in usable]
                    )
                    for m in METRICS
                }
                entry["by_prevalence"][str(pi)] = {
                    m: bootstrap(v, clusters, by_cluster=True, draws=draws)
                    for m, v in per_problem.items()
                }
            table.setdefault(method, {})[key] = entry
    return {"prevalences": list(prevalences), "budgets": list(budgets), "table": table}


def x_summarize__mutmut_59(
    runs: list[dict[str, Any]],
    budgets: tuple[float, ...] = (0.01, 0.02, 0.05),
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Seed-mean per problem, then the median over problems with a source-resampled interval."""
    methods = sorted(
        {m for r in runs for m, seeds in r["runs"].items() if any("budgets" in s for s in seeds)}
    )
    table: dict[str, Any] = {}
    for method in methods:
        for budget in budgets:
            key = str(budget)
            usable = []
            for run in runs:
                seeds = [
                    s["budgets"][key]
                    for s in run["runs"].get(method, [])
                    if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
                ]
                if seeds:
                    usable.append((run["problem"], seeds))
            if not usable:
                continue
            clusters = np.array([source_id(p) for p, _ in usable])
            cells = [c for _, seeds in usable for c in seeds]
            entry: dict[str, Any] = {
                "problems": len(usable), "seed_runs": len(cells),
                "min_positives": min(c["tp"] + c["fn"] for c in cells),
                "min_negatives": min(None),
                "by_prevalence": {},
            }  # fmt: skip
            for pi in prevalences:
                per_problem = {
                    m: np.array(
                        [np.mean([shifted(c, pi)[m] for c in seeds]) for _, seeds in usable]
                    )
                    for m in METRICS
                }
                entry["by_prevalence"][str(pi)] = {
                    m: bootstrap(v, clusters, by_cluster=True, draws=draws)
                    for m, v in per_problem.items()
                }
            table.setdefault(method, {})[key] = entry
    return {"prevalences": list(prevalences), "budgets": list(budgets), "table": table}


def x_summarize__mutmut_60(
    runs: list[dict[str, Any]],
    budgets: tuple[float, ...] = (0.01, 0.02, 0.05),
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Seed-mean per problem, then the median over problems with a source-resampled interval."""
    methods = sorted(
        {m for r in runs for m, seeds in r["runs"].items() if any("budgets" in s for s in seeds)}
    )
    table: dict[str, Any] = {}
    for method in methods:
        for budget in budgets:
            key = str(budget)
            usable = []
            for run in runs:
                seeds = [
                    s["budgets"][key]
                    for s in run["runs"].get(method, [])
                    if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
                ]
                if seeds:
                    usable.append((run["problem"], seeds))
            if not usable:
                continue
            clusters = np.array([source_id(p) for p, _ in usable])
            cells = [c for _, seeds in usable for c in seeds]
            entry: dict[str, Any] = {
                "problems": len(usable), "seed_runs": len(cells),
                "min_positives": min(c["tp"] + c["fn"] for c in cells),
                "min_negatives": min(c["fp"] - c["tn"] for c in cells),
                "by_prevalence": {},
            }  # fmt: skip
            for pi in prevalences:
                per_problem = {
                    m: np.array(
                        [np.mean([shifted(c, pi)[m] for c in seeds]) for _, seeds in usable]
                    )
                    for m in METRICS
                }
                entry["by_prevalence"][str(pi)] = {
                    m: bootstrap(v, clusters, by_cluster=True, draws=draws)
                    for m, v in per_problem.items()
                }
            table.setdefault(method, {})[key] = entry
    return {"prevalences": list(prevalences), "budgets": list(budgets), "table": table}


def x_summarize__mutmut_61(
    runs: list[dict[str, Any]],
    budgets: tuple[float, ...] = (0.01, 0.02, 0.05),
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Seed-mean per problem, then the median over problems with a source-resampled interval."""
    methods = sorted(
        {m for r in runs for m, seeds in r["runs"].items() if any("budgets" in s for s in seeds)}
    )
    table: dict[str, Any] = {}
    for method in methods:
        for budget in budgets:
            key = str(budget)
            usable = []
            for run in runs:
                seeds = [
                    s["budgets"][key]
                    for s in run["runs"].get(method, [])
                    if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
                ]
                if seeds:
                    usable.append((run["problem"], seeds))
            if not usable:
                continue
            clusters = np.array([source_id(p) for p, _ in usable])
            cells = [c for _, seeds in usable for c in seeds]
            entry: dict[str, Any] = {
                "problems": len(usable), "seed_runs": len(cells),
                "min_positives": min(c["tp"] + c["fn"] for c in cells),
                "min_negatives": min(c["XXfpXX"] + c["tn"] for c in cells),
                "by_prevalence": {},
            }  # fmt: skip
            for pi in prevalences:
                per_problem = {
                    m: np.array(
                        [np.mean([shifted(c, pi)[m] for c in seeds]) for _, seeds in usable]
                    )
                    for m in METRICS
                }
                entry["by_prevalence"][str(pi)] = {
                    m: bootstrap(v, clusters, by_cluster=True, draws=draws)
                    for m, v in per_problem.items()
                }
            table.setdefault(method, {})[key] = entry
    return {"prevalences": list(prevalences), "budgets": list(budgets), "table": table}


def x_summarize__mutmut_62(
    runs: list[dict[str, Any]],
    budgets: tuple[float, ...] = (0.01, 0.02, 0.05),
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Seed-mean per problem, then the median over problems with a source-resampled interval."""
    methods = sorted(
        {m for r in runs for m, seeds in r["runs"].items() if any("budgets" in s for s in seeds)}
    )
    table: dict[str, Any] = {}
    for method in methods:
        for budget in budgets:
            key = str(budget)
            usable = []
            for run in runs:
                seeds = [
                    s["budgets"][key]
                    for s in run["runs"].get(method, [])
                    if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
                ]
                if seeds:
                    usable.append((run["problem"], seeds))
            if not usable:
                continue
            clusters = np.array([source_id(p) for p, _ in usable])
            cells = [c for _, seeds in usable for c in seeds]
            entry: dict[str, Any] = {
                "problems": len(usable), "seed_runs": len(cells),
                "min_positives": min(c["tp"] + c["fn"] for c in cells),
                "min_negatives": min(c["FP"] + c["tn"] for c in cells),
                "by_prevalence": {},
            }  # fmt: skip
            for pi in prevalences:
                per_problem = {
                    m: np.array(
                        [np.mean([shifted(c, pi)[m] for c in seeds]) for _, seeds in usable]
                    )
                    for m in METRICS
                }
                entry["by_prevalence"][str(pi)] = {
                    m: bootstrap(v, clusters, by_cluster=True, draws=draws)
                    for m, v in per_problem.items()
                }
            table.setdefault(method, {})[key] = entry
    return {"prevalences": list(prevalences), "budgets": list(budgets), "table": table}


def x_summarize__mutmut_63(
    runs: list[dict[str, Any]],
    budgets: tuple[float, ...] = (0.01, 0.02, 0.05),
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Seed-mean per problem, then the median over problems with a source-resampled interval."""
    methods = sorted(
        {m for r in runs for m, seeds in r["runs"].items() if any("budgets" in s for s in seeds)}
    )
    table: dict[str, Any] = {}
    for method in methods:
        for budget in budgets:
            key = str(budget)
            usable = []
            for run in runs:
                seeds = [
                    s["budgets"][key]
                    for s in run["runs"].get(method, [])
                    if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
                ]
                if seeds:
                    usable.append((run["problem"], seeds))
            if not usable:
                continue
            clusters = np.array([source_id(p) for p, _ in usable])
            cells = [c for _, seeds in usable for c in seeds]
            entry: dict[str, Any] = {
                "problems": len(usable), "seed_runs": len(cells),
                "min_positives": min(c["tp"] + c["fn"] for c in cells),
                "min_negatives": min(c["fp"] + c["XXtnXX"] for c in cells),
                "by_prevalence": {},
            }  # fmt: skip
            for pi in prevalences:
                per_problem = {
                    m: np.array(
                        [np.mean([shifted(c, pi)[m] for c in seeds]) for _, seeds in usable]
                    )
                    for m in METRICS
                }
                entry["by_prevalence"][str(pi)] = {
                    m: bootstrap(v, clusters, by_cluster=True, draws=draws)
                    for m, v in per_problem.items()
                }
            table.setdefault(method, {})[key] = entry
    return {"prevalences": list(prevalences), "budgets": list(budgets), "table": table}


def x_summarize__mutmut_64(
    runs: list[dict[str, Any]],
    budgets: tuple[float, ...] = (0.01, 0.02, 0.05),
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Seed-mean per problem, then the median over problems with a source-resampled interval."""
    methods = sorted(
        {m for r in runs for m, seeds in r["runs"].items() if any("budgets" in s for s in seeds)}
    )
    table: dict[str, Any] = {}
    for method in methods:
        for budget in budgets:
            key = str(budget)
            usable = []
            for run in runs:
                seeds = [
                    s["budgets"][key]
                    for s in run["runs"].get(method, [])
                    if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
                ]
                if seeds:
                    usable.append((run["problem"], seeds))
            if not usable:
                continue
            clusters = np.array([source_id(p) for p, _ in usable])
            cells = [c for _, seeds in usable for c in seeds]
            entry: dict[str, Any] = {
                "problems": len(usable), "seed_runs": len(cells),
                "min_positives": min(c["tp"] + c["fn"] for c in cells),
                "min_negatives": min(c["fp"] + c["TN"] for c in cells),
                "by_prevalence": {},
            }  # fmt: skip
            for pi in prevalences:
                per_problem = {
                    m: np.array(
                        [np.mean([shifted(c, pi)[m] for c in seeds]) for _, seeds in usable]
                    )
                    for m in METRICS
                }
                entry["by_prevalence"][str(pi)] = {
                    m: bootstrap(v, clusters, by_cluster=True, draws=draws)
                    for m, v in per_problem.items()
                }
            table.setdefault(method, {})[key] = entry
    return {"prevalences": list(prevalences), "budgets": list(budgets), "table": table}


def x_summarize__mutmut_65(
    runs: list[dict[str, Any]],
    budgets: tuple[float, ...] = (0.01, 0.02, 0.05),
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Seed-mean per problem, then the median over problems with a source-resampled interval."""
    methods = sorted(
        {m for r in runs for m, seeds in r["runs"].items() if any("budgets" in s for s in seeds)}
    )
    table: dict[str, Any] = {}
    for method in methods:
        for budget in budgets:
            key = str(budget)
            usable = []
            for run in runs:
                seeds = [
                    s["budgets"][key]
                    for s in run["runs"].get(method, [])
                    if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
                ]
                if seeds:
                    usable.append((run["problem"], seeds))
            if not usable:
                continue
            clusters = np.array([source_id(p) for p, _ in usable])
            cells = [c for _, seeds in usable for c in seeds]
            entry: dict[str, Any] = {
                "problems": len(usable), "seed_runs": len(cells),
                "min_positives": min(c["tp"] + c["fn"] for c in cells),
                "min_negatives": min(c["fp"] + c["tn"] for c in cells),
                "XXby_prevalenceXX": {},
            }  # fmt: skip
            for pi in prevalences:
                per_problem = {
                    m: np.array(
                        [np.mean([shifted(c, pi)[m] for c in seeds]) for _, seeds in usable]
                    )
                    for m in METRICS
                }
                entry["by_prevalence"][str(pi)] = {
                    m: bootstrap(v, clusters, by_cluster=True, draws=draws)
                    for m, v in per_problem.items()
                }
            table.setdefault(method, {})[key] = entry
    return {"prevalences": list(prevalences), "budgets": list(budgets), "table": table}


def x_summarize__mutmut_66(
    runs: list[dict[str, Any]],
    budgets: tuple[float, ...] = (0.01, 0.02, 0.05),
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Seed-mean per problem, then the median over problems with a source-resampled interval."""
    methods = sorted(
        {m for r in runs for m, seeds in r["runs"].items() if any("budgets" in s for s in seeds)}
    )
    table: dict[str, Any] = {}
    for method in methods:
        for budget in budgets:
            key = str(budget)
            usable = []
            for run in runs:
                seeds = [
                    s["budgets"][key]
                    for s in run["runs"].get(method, [])
                    if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
                ]
                if seeds:
                    usable.append((run["problem"], seeds))
            if not usable:
                continue
            clusters = np.array([source_id(p) for p, _ in usable])
            cells = [c for _, seeds in usable for c in seeds]
            entry: dict[str, Any] = {
                "problems": len(usable), "seed_runs": len(cells),
                "min_positives": min(c["tp"] + c["fn"] for c in cells),
                "min_negatives": min(c["fp"] + c["tn"] for c in cells),
                "BY_PREVALENCE": {},
            }  # fmt: skip
            for pi in prevalences:
                per_problem = {
                    m: np.array(
                        [np.mean([shifted(c, pi)[m] for c in seeds]) for _, seeds in usable]
                    )
                    for m in METRICS
                }
                entry["by_prevalence"][str(pi)] = {
                    m: bootstrap(v, clusters, by_cluster=True, draws=draws)
                    for m, v in per_problem.items()
                }
            table.setdefault(method, {})[key] = entry
    return {"prevalences": list(prevalences), "budgets": list(budgets), "table": table}


def x_summarize__mutmut_67(
    runs: list[dict[str, Any]],
    budgets: tuple[float, ...] = (0.01, 0.02, 0.05),
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Seed-mean per problem, then the median over problems with a source-resampled interval."""
    methods = sorted(
        {m for r in runs for m, seeds in r["runs"].items() if any("budgets" in s for s in seeds)}
    )
    table: dict[str, Any] = {}
    for method in methods:
        for budget in budgets:
            key = str(budget)
            usable = []
            for run in runs:
                seeds = [
                    s["budgets"][key]
                    for s in run["runs"].get(method, [])
                    if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
                ]
                if seeds:
                    usable.append((run["problem"], seeds))
            if not usable:
                continue
            clusters = np.array([source_id(p) for p, _ in usable])
            cells = [c for _, seeds in usable for c in seeds]
            entry: dict[str, Any] = {
                "problems": len(usable), "seed_runs": len(cells),
                "min_positives": min(c["tp"] + c["fn"] for c in cells),
                "min_negatives": min(c["fp"] + c["tn"] for c in cells),
                "by_prevalence": {},
            }  # fmt: skip
            for pi in prevalences:
                per_problem = None
                entry["by_prevalence"][str(pi)] = {
                    m: bootstrap(v, clusters, by_cluster=True, draws=draws)
                    for m, v in per_problem.items()
                }
            table.setdefault(method, {})[key] = entry
    return {"prevalences": list(prevalences), "budgets": list(budgets), "table": table}


def x_summarize__mutmut_68(
    runs: list[dict[str, Any]],
    budgets: tuple[float, ...] = (0.01, 0.02, 0.05),
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Seed-mean per problem, then the median over problems with a source-resampled interval."""
    methods = sorted(
        {m for r in runs for m, seeds in r["runs"].items() if any("budgets" in s for s in seeds)}
    )
    table: dict[str, Any] = {}
    for method in methods:
        for budget in budgets:
            key = str(budget)
            usable = []
            for run in runs:
                seeds = [
                    s["budgets"][key]
                    for s in run["runs"].get(method, [])
                    if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
                ]
                if seeds:
                    usable.append((run["problem"], seeds))
            if not usable:
                continue
            clusters = np.array([source_id(p) for p, _ in usable])
            cells = [c for _, seeds in usable for c in seeds]
            entry: dict[str, Any] = {
                "problems": len(usable), "seed_runs": len(cells),
                "min_positives": min(c["tp"] + c["fn"] for c in cells),
                "min_negatives": min(c["fp"] + c["tn"] for c in cells),
                "by_prevalence": {},
            }  # fmt: skip
            for pi in prevalences:
                per_problem = {
                    m: np.array(
                        None
                    )
                    for m in METRICS
                }
                entry["by_prevalence"][str(pi)] = {
                    m: bootstrap(v, clusters, by_cluster=True, draws=draws)
                    for m, v in per_problem.items()
                }
            table.setdefault(method, {})[key] = entry
    return {"prevalences": list(prevalences), "budgets": list(budgets), "table": table}


def x_summarize__mutmut_69(
    runs: list[dict[str, Any]],
    budgets: tuple[float, ...] = (0.01, 0.02, 0.05),
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Seed-mean per problem, then the median over problems with a source-resampled interval."""
    methods = sorted(
        {m for r in runs for m, seeds in r["runs"].items() if any("budgets" in s for s in seeds)}
    )
    table: dict[str, Any] = {}
    for method in methods:
        for budget in budgets:
            key = str(budget)
            usable = []
            for run in runs:
                seeds = [
                    s["budgets"][key]
                    for s in run["runs"].get(method, [])
                    if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
                ]
                if seeds:
                    usable.append((run["problem"], seeds))
            if not usable:
                continue
            clusters = np.array([source_id(p) for p, _ in usable])
            cells = [c for _, seeds in usable for c in seeds]
            entry: dict[str, Any] = {
                "problems": len(usable), "seed_runs": len(cells),
                "min_positives": min(c["tp"] + c["fn"] for c in cells),
                "min_negatives": min(c["fp"] + c["tn"] for c in cells),
                "by_prevalence": {},
            }  # fmt: skip
            for pi in prevalences:
                per_problem = {
                    m: np.array(
                        [np.mean(None) for _, seeds in usable]
                    )
                    for m in METRICS
                }
                entry["by_prevalence"][str(pi)] = {
                    m: bootstrap(v, clusters, by_cluster=True, draws=draws)
                    for m, v in per_problem.items()
                }
            table.setdefault(method, {})[key] = entry
    return {"prevalences": list(prevalences), "budgets": list(budgets), "table": table}


def x_summarize__mutmut_70(
    runs: list[dict[str, Any]],
    budgets: tuple[float, ...] = (0.01, 0.02, 0.05),
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Seed-mean per problem, then the median over problems with a source-resampled interval."""
    methods = sorted(
        {m for r in runs for m, seeds in r["runs"].items() if any("budgets" in s for s in seeds)}
    )
    table: dict[str, Any] = {}
    for method in methods:
        for budget in budgets:
            key = str(budget)
            usable = []
            for run in runs:
                seeds = [
                    s["budgets"][key]
                    for s in run["runs"].get(method, [])
                    if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
                ]
                if seeds:
                    usable.append((run["problem"], seeds))
            if not usable:
                continue
            clusters = np.array([source_id(p) for p, _ in usable])
            cells = [c for _, seeds in usable for c in seeds]
            entry: dict[str, Any] = {
                "problems": len(usable), "seed_runs": len(cells),
                "min_positives": min(c["tp"] + c["fn"] for c in cells),
                "min_negatives": min(c["fp"] + c["tn"] for c in cells),
                "by_prevalence": {},
            }  # fmt: skip
            for pi in prevalences:
                per_problem = {
                    m: np.array(
                        [np.mean([shifted(None, pi)[m] for c in seeds]) for _, seeds in usable]
                    )
                    for m in METRICS
                }
                entry["by_prevalence"][str(pi)] = {
                    m: bootstrap(v, clusters, by_cluster=True, draws=draws)
                    for m, v in per_problem.items()
                }
            table.setdefault(method, {})[key] = entry
    return {"prevalences": list(prevalences), "budgets": list(budgets), "table": table}


def x_summarize__mutmut_71(
    runs: list[dict[str, Any]],
    budgets: tuple[float, ...] = (0.01, 0.02, 0.05),
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Seed-mean per problem, then the median over problems with a source-resampled interval."""
    methods = sorted(
        {m for r in runs for m, seeds in r["runs"].items() if any("budgets" in s for s in seeds)}
    )
    table: dict[str, Any] = {}
    for method in methods:
        for budget in budgets:
            key = str(budget)
            usable = []
            for run in runs:
                seeds = [
                    s["budgets"][key]
                    for s in run["runs"].get(method, [])
                    if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
                ]
                if seeds:
                    usable.append((run["problem"], seeds))
            if not usable:
                continue
            clusters = np.array([source_id(p) for p, _ in usable])
            cells = [c for _, seeds in usable for c in seeds]
            entry: dict[str, Any] = {
                "problems": len(usable), "seed_runs": len(cells),
                "min_positives": min(c["tp"] + c["fn"] for c in cells),
                "min_negatives": min(c["fp"] + c["tn"] for c in cells),
                "by_prevalence": {},
            }  # fmt: skip
            for pi in prevalences:
                per_problem = {
                    m: np.array(
                        [np.mean([shifted(c, None)[m] for c in seeds]) for _, seeds in usable]
                    )
                    for m in METRICS
                }
                entry["by_prevalence"][str(pi)] = {
                    m: bootstrap(v, clusters, by_cluster=True, draws=draws)
                    for m, v in per_problem.items()
                }
            table.setdefault(method, {})[key] = entry
    return {"prevalences": list(prevalences), "budgets": list(budgets), "table": table}


def x_summarize__mutmut_72(
    runs: list[dict[str, Any]],
    budgets: tuple[float, ...] = (0.01, 0.02, 0.05),
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Seed-mean per problem, then the median over problems with a source-resampled interval."""
    methods = sorted(
        {m for r in runs for m, seeds in r["runs"].items() if any("budgets" in s for s in seeds)}
    )
    table: dict[str, Any] = {}
    for method in methods:
        for budget in budgets:
            key = str(budget)
            usable = []
            for run in runs:
                seeds = [
                    s["budgets"][key]
                    for s in run["runs"].get(method, [])
                    if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
                ]
                if seeds:
                    usable.append((run["problem"], seeds))
            if not usable:
                continue
            clusters = np.array([source_id(p) for p, _ in usable])
            cells = [c for _, seeds in usable for c in seeds]
            entry: dict[str, Any] = {
                "problems": len(usable), "seed_runs": len(cells),
                "min_positives": min(c["tp"] + c["fn"] for c in cells),
                "min_negatives": min(c["fp"] + c["tn"] for c in cells),
                "by_prevalence": {},
            }  # fmt: skip
            for pi in prevalences:
                per_problem = {
                    m: np.array(
                        [np.mean([shifted(pi)[m] for c in seeds]) for _, seeds in usable]
                    )
                    for m in METRICS
                }
                entry["by_prevalence"][str(pi)] = {
                    m: bootstrap(v, clusters, by_cluster=True, draws=draws)
                    for m, v in per_problem.items()
                }
            table.setdefault(method, {})[key] = entry
    return {"prevalences": list(prevalences), "budgets": list(budgets), "table": table}


def x_summarize__mutmut_73(
    runs: list[dict[str, Any]],
    budgets: tuple[float, ...] = (0.01, 0.02, 0.05),
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Seed-mean per problem, then the median over problems with a source-resampled interval."""
    methods = sorted(
        {m for r in runs for m, seeds in r["runs"].items() if any("budgets" in s for s in seeds)}
    )
    table: dict[str, Any] = {}
    for method in methods:
        for budget in budgets:
            key = str(budget)
            usable = []
            for run in runs:
                seeds = [
                    s["budgets"][key]
                    for s in run["runs"].get(method, [])
                    if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
                ]
                if seeds:
                    usable.append((run["problem"], seeds))
            if not usable:
                continue
            clusters = np.array([source_id(p) for p, _ in usable])
            cells = [c for _, seeds in usable for c in seeds]
            entry: dict[str, Any] = {
                "problems": len(usable), "seed_runs": len(cells),
                "min_positives": min(c["tp"] + c["fn"] for c in cells),
                "min_negatives": min(c["fp"] + c["tn"] for c in cells),
                "by_prevalence": {},
            }  # fmt: skip
            for pi in prevalences:
                per_problem = {
                    m: np.array(
                        [np.mean([shifted(c, )[m] for c in seeds]) for _, seeds in usable]
                    )
                    for m in METRICS
                }
                entry["by_prevalence"][str(pi)] = {
                    m: bootstrap(v, clusters, by_cluster=True, draws=draws)
                    for m, v in per_problem.items()
                }
            table.setdefault(method, {})[key] = entry
    return {"prevalences": list(prevalences), "budgets": list(budgets), "table": table}


def x_summarize__mutmut_74(
    runs: list[dict[str, Any]],
    budgets: tuple[float, ...] = (0.01, 0.02, 0.05),
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Seed-mean per problem, then the median over problems with a source-resampled interval."""
    methods = sorted(
        {m for r in runs for m, seeds in r["runs"].items() if any("budgets" in s for s in seeds)}
    )
    table: dict[str, Any] = {}
    for method in methods:
        for budget in budgets:
            key = str(budget)
            usable = []
            for run in runs:
                seeds = [
                    s["budgets"][key]
                    for s in run["runs"].get(method, [])
                    if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
                ]
                if seeds:
                    usable.append((run["problem"], seeds))
            if not usable:
                continue
            clusters = np.array([source_id(p) for p, _ in usable])
            cells = [c for _, seeds in usable for c in seeds]
            entry: dict[str, Any] = {
                "problems": len(usable), "seed_runs": len(cells),
                "min_positives": min(c["tp"] + c["fn"] for c in cells),
                "min_negatives": min(c["fp"] + c["tn"] for c in cells),
                "by_prevalence": {},
            }  # fmt: skip
            for pi in prevalences:
                per_problem = {
                    m: np.array(
                        [np.mean([shifted(c, pi)[m] for c in seeds]) for _, seeds in usable]
                    )
                    for m in METRICS
                }
                entry["by_prevalence"][str(pi)] = None
            table.setdefault(method, {})[key] = entry
    return {"prevalences": list(prevalences), "budgets": list(budgets), "table": table}


def x_summarize__mutmut_75(
    runs: list[dict[str, Any]],
    budgets: tuple[float, ...] = (0.01, 0.02, 0.05),
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Seed-mean per problem, then the median over problems with a source-resampled interval."""
    methods = sorted(
        {m for r in runs for m, seeds in r["runs"].items() if any("budgets" in s for s in seeds)}
    )
    table: dict[str, Any] = {}
    for method in methods:
        for budget in budgets:
            key = str(budget)
            usable = []
            for run in runs:
                seeds = [
                    s["budgets"][key]
                    for s in run["runs"].get(method, [])
                    if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
                ]
                if seeds:
                    usable.append((run["problem"], seeds))
            if not usable:
                continue
            clusters = np.array([source_id(p) for p, _ in usable])
            cells = [c for _, seeds in usable for c in seeds]
            entry: dict[str, Any] = {
                "problems": len(usable), "seed_runs": len(cells),
                "min_positives": min(c["tp"] + c["fn"] for c in cells),
                "min_negatives": min(c["fp"] + c["tn"] for c in cells),
                "by_prevalence": {},
            }  # fmt: skip
            for pi in prevalences:
                per_problem = {
                    m: np.array(
                        [np.mean([shifted(c, pi)[m] for c in seeds]) for _, seeds in usable]
                    )
                    for m in METRICS
                }
                entry["XXby_prevalenceXX"][str(pi)] = {
                    m: bootstrap(v, clusters, by_cluster=True, draws=draws)
                    for m, v in per_problem.items()
                }
            table.setdefault(method, {})[key] = entry
    return {"prevalences": list(prevalences), "budgets": list(budgets), "table": table}


def x_summarize__mutmut_76(
    runs: list[dict[str, Any]],
    budgets: tuple[float, ...] = (0.01, 0.02, 0.05),
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Seed-mean per problem, then the median over problems with a source-resampled interval."""
    methods = sorted(
        {m for r in runs for m, seeds in r["runs"].items() if any("budgets" in s for s in seeds)}
    )
    table: dict[str, Any] = {}
    for method in methods:
        for budget in budgets:
            key = str(budget)
            usable = []
            for run in runs:
                seeds = [
                    s["budgets"][key]
                    for s in run["runs"].get(method, [])
                    if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
                ]
                if seeds:
                    usable.append((run["problem"], seeds))
            if not usable:
                continue
            clusters = np.array([source_id(p) for p, _ in usable])
            cells = [c for _, seeds in usable for c in seeds]
            entry: dict[str, Any] = {
                "problems": len(usable), "seed_runs": len(cells),
                "min_positives": min(c["tp"] + c["fn"] for c in cells),
                "min_negatives": min(c["fp"] + c["tn"] for c in cells),
                "by_prevalence": {},
            }  # fmt: skip
            for pi in prevalences:
                per_problem = {
                    m: np.array(
                        [np.mean([shifted(c, pi)[m] for c in seeds]) for _, seeds in usable]
                    )
                    for m in METRICS
                }
                entry["BY_PREVALENCE"][str(pi)] = {
                    m: bootstrap(v, clusters, by_cluster=True, draws=draws)
                    for m, v in per_problem.items()
                }
            table.setdefault(method, {})[key] = entry
    return {"prevalences": list(prevalences), "budgets": list(budgets), "table": table}


def x_summarize__mutmut_77(
    runs: list[dict[str, Any]],
    budgets: tuple[float, ...] = (0.01, 0.02, 0.05),
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Seed-mean per problem, then the median over problems with a source-resampled interval."""
    methods = sorted(
        {m for r in runs for m, seeds in r["runs"].items() if any("budgets" in s for s in seeds)}
    )
    table: dict[str, Any] = {}
    for method in methods:
        for budget in budgets:
            key = str(budget)
            usable = []
            for run in runs:
                seeds = [
                    s["budgets"][key]
                    for s in run["runs"].get(method, [])
                    if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
                ]
                if seeds:
                    usable.append((run["problem"], seeds))
            if not usable:
                continue
            clusters = np.array([source_id(p) for p, _ in usable])
            cells = [c for _, seeds in usable for c in seeds]
            entry: dict[str, Any] = {
                "problems": len(usable), "seed_runs": len(cells),
                "min_positives": min(c["tp"] + c["fn"] for c in cells),
                "min_negatives": min(c["fp"] + c["tn"] for c in cells),
                "by_prevalence": {},
            }  # fmt: skip
            for pi in prevalences:
                per_problem = {
                    m: np.array(
                        [np.mean([shifted(c, pi)[m] for c in seeds]) for _, seeds in usable]
                    )
                    for m in METRICS
                }
                entry["by_prevalence"][str(None)] = {
                    m: bootstrap(v, clusters, by_cluster=True, draws=draws)
                    for m, v in per_problem.items()
                }
            table.setdefault(method, {})[key] = entry
    return {"prevalences": list(prevalences), "budgets": list(budgets), "table": table}


def x_summarize__mutmut_78(
    runs: list[dict[str, Any]],
    budgets: tuple[float, ...] = (0.01, 0.02, 0.05),
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Seed-mean per problem, then the median over problems with a source-resampled interval."""
    methods = sorted(
        {m for r in runs for m, seeds in r["runs"].items() if any("budgets" in s for s in seeds)}
    )
    table: dict[str, Any] = {}
    for method in methods:
        for budget in budgets:
            key = str(budget)
            usable = []
            for run in runs:
                seeds = [
                    s["budgets"][key]
                    for s in run["runs"].get(method, [])
                    if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
                ]
                if seeds:
                    usable.append((run["problem"], seeds))
            if not usable:
                continue
            clusters = np.array([source_id(p) for p, _ in usable])
            cells = [c for _, seeds in usable for c in seeds]
            entry: dict[str, Any] = {
                "problems": len(usable), "seed_runs": len(cells),
                "min_positives": min(c["tp"] + c["fn"] for c in cells),
                "min_negatives": min(c["fp"] + c["tn"] for c in cells),
                "by_prevalence": {},
            }  # fmt: skip
            for pi in prevalences:
                per_problem = {
                    m: np.array(
                        [np.mean([shifted(c, pi)[m] for c in seeds]) for _, seeds in usable]
                    )
                    for m in METRICS
                }
                entry["by_prevalence"][str(pi)] = {
                    m: bootstrap(None, clusters, by_cluster=True, draws=draws)
                    for m, v in per_problem.items()
                }
            table.setdefault(method, {})[key] = entry
    return {"prevalences": list(prevalences), "budgets": list(budgets), "table": table}


def x_summarize__mutmut_79(
    runs: list[dict[str, Any]],
    budgets: tuple[float, ...] = (0.01, 0.02, 0.05),
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Seed-mean per problem, then the median over problems with a source-resampled interval."""
    methods = sorted(
        {m for r in runs for m, seeds in r["runs"].items() if any("budgets" in s for s in seeds)}
    )
    table: dict[str, Any] = {}
    for method in methods:
        for budget in budgets:
            key = str(budget)
            usable = []
            for run in runs:
                seeds = [
                    s["budgets"][key]
                    for s in run["runs"].get(method, [])
                    if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
                ]
                if seeds:
                    usable.append((run["problem"], seeds))
            if not usable:
                continue
            clusters = np.array([source_id(p) for p, _ in usable])
            cells = [c for _, seeds in usable for c in seeds]
            entry: dict[str, Any] = {
                "problems": len(usable), "seed_runs": len(cells),
                "min_positives": min(c["tp"] + c["fn"] for c in cells),
                "min_negatives": min(c["fp"] + c["tn"] for c in cells),
                "by_prevalence": {},
            }  # fmt: skip
            for pi in prevalences:
                per_problem = {
                    m: np.array(
                        [np.mean([shifted(c, pi)[m] for c in seeds]) for _, seeds in usable]
                    )
                    for m in METRICS
                }
                entry["by_prevalence"][str(pi)] = {
                    m: bootstrap(v, None, by_cluster=True, draws=draws)
                    for m, v in per_problem.items()
                }
            table.setdefault(method, {})[key] = entry
    return {"prevalences": list(prevalences), "budgets": list(budgets), "table": table}


def x_summarize__mutmut_80(
    runs: list[dict[str, Any]],
    budgets: tuple[float, ...] = (0.01, 0.02, 0.05),
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Seed-mean per problem, then the median over problems with a source-resampled interval."""
    methods = sorted(
        {m for r in runs for m, seeds in r["runs"].items() if any("budgets" in s for s in seeds)}
    )
    table: dict[str, Any] = {}
    for method in methods:
        for budget in budgets:
            key = str(budget)
            usable = []
            for run in runs:
                seeds = [
                    s["budgets"][key]
                    for s in run["runs"].get(method, [])
                    if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
                ]
                if seeds:
                    usable.append((run["problem"], seeds))
            if not usable:
                continue
            clusters = np.array([source_id(p) for p, _ in usable])
            cells = [c for _, seeds in usable for c in seeds]
            entry: dict[str, Any] = {
                "problems": len(usable), "seed_runs": len(cells),
                "min_positives": min(c["tp"] + c["fn"] for c in cells),
                "min_negatives": min(c["fp"] + c["tn"] for c in cells),
                "by_prevalence": {},
            }  # fmt: skip
            for pi in prevalences:
                per_problem = {
                    m: np.array(
                        [np.mean([shifted(c, pi)[m] for c in seeds]) for _, seeds in usable]
                    )
                    for m in METRICS
                }
                entry["by_prevalence"][str(pi)] = {
                    m: bootstrap(v, clusters, by_cluster=None, draws=draws)
                    for m, v in per_problem.items()
                }
            table.setdefault(method, {})[key] = entry
    return {"prevalences": list(prevalences), "budgets": list(budgets), "table": table}


def x_summarize__mutmut_81(
    runs: list[dict[str, Any]],
    budgets: tuple[float, ...] = (0.01, 0.02, 0.05),
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Seed-mean per problem, then the median over problems with a source-resampled interval."""
    methods = sorted(
        {m for r in runs for m, seeds in r["runs"].items() if any("budgets" in s for s in seeds)}
    )
    table: dict[str, Any] = {}
    for method in methods:
        for budget in budgets:
            key = str(budget)
            usable = []
            for run in runs:
                seeds = [
                    s["budgets"][key]
                    for s in run["runs"].get(method, [])
                    if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
                ]
                if seeds:
                    usable.append((run["problem"], seeds))
            if not usable:
                continue
            clusters = np.array([source_id(p) for p, _ in usable])
            cells = [c for _, seeds in usable for c in seeds]
            entry: dict[str, Any] = {
                "problems": len(usable), "seed_runs": len(cells),
                "min_positives": min(c["tp"] + c["fn"] for c in cells),
                "min_negatives": min(c["fp"] + c["tn"] for c in cells),
                "by_prevalence": {},
            }  # fmt: skip
            for pi in prevalences:
                per_problem = {
                    m: np.array(
                        [np.mean([shifted(c, pi)[m] for c in seeds]) for _, seeds in usable]
                    )
                    for m in METRICS
                }
                entry["by_prevalence"][str(pi)] = {
                    m: bootstrap(v, clusters, by_cluster=True, draws=None)
                    for m, v in per_problem.items()
                }
            table.setdefault(method, {})[key] = entry
    return {"prevalences": list(prevalences), "budgets": list(budgets), "table": table}


def x_summarize__mutmut_82(
    runs: list[dict[str, Any]],
    budgets: tuple[float, ...] = (0.01, 0.02, 0.05),
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Seed-mean per problem, then the median over problems with a source-resampled interval."""
    methods = sorted(
        {m for r in runs for m, seeds in r["runs"].items() if any("budgets" in s for s in seeds)}
    )
    table: dict[str, Any] = {}
    for method in methods:
        for budget in budgets:
            key = str(budget)
            usable = []
            for run in runs:
                seeds = [
                    s["budgets"][key]
                    for s in run["runs"].get(method, [])
                    if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
                ]
                if seeds:
                    usable.append((run["problem"], seeds))
            if not usable:
                continue
            clusters = np.array([source_id(p) for p, _ in usable])
            cells = [c for _, seeds in usable for c in seeds]
            entry: dict[str, Any] = {
                "problems": len(usable), "seed_runs": len(cells),
                "min_positives": min(c["tp"] + c["fn"] for c in cells),
                "min_negatives": min(c["fp"] + c["tn"] for c in cells),
                "by_prevalence": {},
            }  # fmt: skip
            for pi in prevalences:
                per_problem = {
                    m: np.array(
                        [np.mean([shifted(c, pi)[m] for c in seeds]) for _, seeds in usable]
                    )
                    for m in METRICS
                }
                entry["by_prevalence"][str(pi)] = {
                    m: bootstrap(clusters, by_cluster=True, draws=draws)
                    for m, v in per_problem.items()
                }
            table.setdefault(method, {})[key] = entry
    return {"prevalences": list(prevalences), "budgets": list(budgets), "table": table}


def x_summarize__mutmut_83(
    runs: list[dict[str, Any]],
    budgets: tuple[float, ...] = (0.01, 0.02, 0.05),
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Seed-mean per problem, then the median over problems with a source-resampled interval."""
    methods = sorted(
        {m for r in runs for m, seeds in r["runs"].items() if any("budgets" in s for s in seeds)}
    )
    table: dict[str, Any] = {}
    for method in methods:
        for budget in budgets:
            key = str(budget)
            usable = []
            for run in runs:
                seeds = [
                    s["budgets"][key]
                    for s in run["runs"].get(method, [])
                    if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
                ]
                if seeds:
                    usable.append((run["problem"], seeds))
            if not usable:
                continue
            clusters = np.array([source_id(p) for p, _ in usable])
            cells = [c for _, seeds in usable for c in seeds]
            entry: dict[str, Any] = {
                "problems": len(usable), "seed_runs": len(cells),
                "min_positives": min(c["tp"] + c["fn"] for c in cells),
                "min_negatives": min(c["fp"] + c["tn"] for c in cells),
                "by_prevalence": {},
            }  # fmt: skip
            for pi in prevalences:
                per_problem = {
                    m: np.array(
                        [np.mean([shifted(c, pi)[m] for c in seeds]) for _, seeds in usable]
                    )
                    for m in METRICS
                }
                entry["by_prevalence"][str(pi)] = {
                    m: bootstrap(v, by_cluster=True, draws=draws)
                    for m, v in per_problem.items()
                }
            table.setdefault(method, {})[key] = entry
    return {"prevalences": list(prevalences), "budgets": list(budgets), "table": table}


def x_summarize__mutmut_84(
    runs: list[dict[str, Any]],
    budgets: tuple[float, ...] = (0.01, 0.02, 0.05),
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Seed-mean per problem, then the median over problems with a source-resampled interval."""
    methods = sorted(
        {m for r in runs for m, seeds in r["runs"].items() if any("budgets" in s for s in seeds)}
    )
    table: dict[str, Any] = {}
    for method in methods:
        for budget in budgets:
            key = str(budget)
            usable = []
            for run in runs:
                seeds = [
                    s["budgets"][key]
                    for s in run["runs"].get(method, [])
                    if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
                ]
                if seeds:
                    usable.append((run["problem"], seeds))
            if not usable:
                continue
            clusters = np.array([source_id(p) for p, _ in usable])
            cells = [c for _, seeds in usable for c in seeds]
            entry: dict[str, Any] = {
                "problems": len(usable), "seed_runs": len(cells),
                "min_positives": min(c["tp"] + c["fn"] for c in cells),
                "min_negatives": min(c["fp"] + c["tn"] for c in cells),
                "by_prevalence": {},
            }  # fmt: skip
            for pi in prevalences:
                per_problem = {
                    m: np.array(
                        [np.mean([shifted(c, pi)[m] for c in seeds]) for _, seeds in usable]
                    )
                    for m in METRICS
                }
                entry["by_prevalence"][str(pi)] = {
                    m: bootstrap(v, clusters, draws=draws)
                    for m, v in per_problem.items()
                }
            table.setdefault(method, {})[key] = entry
    return {"prevalences": list(prevalences), "budgets": list(budgets), "table": table}


def x_summarize__mutmut_85(
    runs: list[dict[str, Any]],
    budgets: tuple[float, ...] = (0.01, 0.02, 0.05),
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Seed-mean per problem, then the median over problems with a source-resampled interval."""
    methods = sorted(
        {m for r in runs for m, seeds in r["runs"].items() if any("budgets" in s for s in seeds)}
    )
    table: dict[str, Any] = {}
    for method in methods:
        for budget in budgets:
            key = str(budget)
            usable = []
            for run in runs:
                seeds = [
                    s["budgets"][key]
                    for s in run["runs"].get(method, [])
                    if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
                ]
                if seeds:
                    usable.append((run["problem"], seeds))
            if not usable:
                continue
            clusters = np.array([source_id(p) for p, _ in usable])
            cells = [c for _, seeds in usable for c in seeds]
            entry: dict[str, Any] = {
                "problems": len(usable), "seed_runs": len(cells),
                "min_positives": min(c["tp"] + c["fn"] for c in cells),
                "min_negatives": min(c["fp"] + c["tn"] for c in cells),
                "by_prevalence": {},
            }  # fmt: skip
            for pi in prevalences:
                per_problem = {
                    m: np.array(
                        [np.mean([shifted(c, pi)[m] for c in seeds]) for _, seeds in usable]
                    )
                    for m in METRICS
                }
                entry["by_prevalence"][str(pi)] = {
                    m: bootstrap(v, clusters, by_cluster=True, )
                    for m, v in per_problem.items()
                }
            table.setdefault(method, {})[key] = entry
    return {"prevalences": list(prevalences), "budgets": list(budgets), "table": table}


def x_summarize__mutmut_86(
    runs: list[dict[str, Any]],
    budgets: tuple[float, ...] = (0.01, 0.02, 0.05),
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Seed-mean per problem, then the median over problems with a source-resampled interval."""
    methods = sorted(
        {m for r in runs for m, seeds in r["runs"].items() if any("budgets" in s for s in seeds)}
    )
    table: dict[str, Any] = {}
    for method in methods:
        for budget in budgets:
            key = str(budget)
            usable = []
            for run in runs:
                seeds = [
                    s["budgets"][key]
                    for s in run["runs"].get(method, [])
                    if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
                ]
                if seeds:
                    usable.append((run["problem"], seeds))
            if not usable:
                continue
            clusters = np.array([source_id(p) for p, _ in usable])
            cells = [c for _, seeds in usable for c in seeds]
            entry: dict[str, Any] = {
                "problems": len(usable), "seed_runs": len(cells),
                "min_positives": min(c["tp"] + c["fn"] for c in cells),
                "min_negatives": min(c["fp"] + c["tn"] for c in cells),
                "by_prevalence": {},
            }  # fmt: skip
            for pi in prevalences:
                per_problem = {
                    m: np.array(
                        [np.mean([shifted(c, pi)[m] for c in seeds]) for _, seeds in usable]
                    )
                    for m in METRICS
                }
                entry["by_prevalence"][str(pi)] = {
                    m: bootstrap(v, clusters, by_cluster=False, draws=draws)
                    for m, v in per_problem.items()
                }
            table.setdefault(method, {})[key] = entry
    return {"prevalences": list(prevalences), "budgets": list(budgets), "table": table}


def x_summarize__mutmut_87(
    runs: list[dict[str, Any]],
    budgets: tuple[float, ...] = (0.01, 0.02, 0.05),
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Seed-mean per problem, then the median over problems with a source-resampled interval."""
    methods = sorted(
        {m for r in runs for m, seeds in r["runs"].items() if any("budgets" in s for s in seeds)}
    )
    table: dict[str, Any] = {}
    for method in methods:
        for budget in budgets:
            key = str(budget)
            usable = []
            for run in runs:
                seeds = [
                    s["budgets"][key]
                    for s in run["runs"].get(method, [])
                    if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
                ]
                if seeds:
                    usable.append((run["problem"], seeds))
            if not usable:
                continue
            clusters = np.array([source_id(p) for p, _ in usable])
            cells = [c for _, seeds in usable for c in seeds]
            entry: dict[str, Any] = {
                "problems": len(usable), "seed_runs": len(cells),
                "min_positives": min(c["tp"] + c["fn"] for c in cells),
                "min_negatives": min(c["fp"] + c["tn"] for c in cells),
                "by_prevalence": {},
            }  # fmt: skip
            for pi in prevalences:
                per_problem = {
                    m: np.array(
                        [np.mean([shifted(c, pi)[m] for c in seeds]) for _, seeds in usable]
                    )
                    for m in METRICS
                }
                entry["by_prevalence"][str(pi)] = {
                    m: bootstrap(v, clusters, by_cluster=True, draws=draws)
                    for m, v in per_problem.items()
                }
            table.setdefault(method, {})[key] = None
    return {"prevalences": list(prevalences), "budgets": list(budgets), "table": table}


def x_summarize__mutmut_88(
    runs: list[dict[str, Any]],
    budgets: tuple[float, ...] = (0.01, 0.02, 0.05),
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Seed-mean per problem, then the median over problems with a source-resampled interval."""
    methods = sorted(
        {m for r in runs for m, seeds in r["runs"].items() if any("budgets" in s for s in seeds)}
    )
    table: dict[str, Any] = {}
    for method in methods:
        for budget in budgets:
            key = str(budget)
            usable = []
            for run in runs:
                seeds = [
                    s["budgets"][key]
                    for s in run["runs"].get(method, [])
                    if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
                ]
                if seeds:
                    usable.append((run["problem"], seeds))
            if not usable:
                continue
            clusters = np.array([source_id(p) for p, _ in usable])
            cells = [c for _, seeds in usable for c in seeds]
            entry: dict[str, Any] = {
                "problems": len(usable), "seed_runs": len(cells),
                "min_positives": min(c["tp"] + c["fn"] for c in cells),
                "min_negatives": min(c["fp"] + c["tn"] for c in cells),
                "by_prevalence": {},
            }  # fmt: skip
            for pi in prevalences:
                per_problem = {
                    m: np.array(
                        [np.mean([shifted(c, pi)[m] for c in seeds]) for _, seeds in usable]
                    )
                    for m in METRICS
                }
                entry["by_prevalence"][str(pi)] = {
                    m: bootstrap(v, clusters, by_cluster=True, draws=draws)
                    for m, v in per_problem.items()
                }
            table.setdefault(None, {})[key] = entry
    return {"prevalences": list(prevalences), "budgets": list(budgets), "table": table}


def x_summarize__mutmut_89(
    runs: list[dict[str, Any]],
    budgets: tuple[float, ...] = (0.01, 0.02, 0.05),
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Seed-mean per problem, then the median over problems with a source-resampled interval."""
    methods = sorted(
        {m for r in runs for m, seeds in r["runs"].items() if any("budgets" in s for s in seeds)}
    )
    table: dict[str, Any] = {}
    for method in methods:
        for budget in budgets:
            key = str(budget)
            usable = []
            for run in runs:
                seeds = [
                    s["budgets"][key]
                    for s in run["runs"].get(method, [])
                    if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
                ]
                if seeds:
                    usable.append((run["problem"], seeds))
            if not usable:
                continue
            clusters = np.array([source_id(p) for p, _ in usable])
            cells = [c for _, seeds in usable for c in seeds]
            entry: dict[str, Any] = {
                "problems": len(usable), "seed_runs": len(cells),
                "min_positives": min(c["tp"] + c["fn"] for c in cells),
                "min_negatives": min(c["fp"] + c["tn"] for c in cells),
                "by_prevalence": {},
            }  # fmt: skip
            for pi in prevalences:
                per_problem = {
                    m: np.array(
                        [np.mean([shifted(c, pi)[m] for c in seeds]) for _, seeds in usable]
                    )
                    for m in METRICS
                }
                entry["by_prevalence"][str(pi)] = {
                    m: bootstrap(v, clusters, by_cluster=True, draws=draws)
                    for m, v in per_problem.items()
                }
            table.setdefault(method, None)[key] = entry
    return {"prevalences": list(prevalences), "budgets": list(budgets), "table": table}


def x_summarize__mutmut_90(
    runs: list[dict[str, Any]],
    budgets: tuple[float, ...] = (0.01, 0.02, 0.05),
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Seed-mean per problem, then the median over problems with a source-resampled interval."""
    methods = sorted(
        {m for r in runs for m, seeds in r["runs"].items() if any("budgets" in s for s in seeds)}
    )
    table: dict[str, Any] = {}
    for method in methods:
        for budget in budgets:
            key = str(budget)
            usable = []
            for run in runs:
                seeds = [
                    s["budgets"][key]
                    for s in run["runs"].get(method, [])
                    if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
                ]
                if seeds:
                    usable.append((run["problem"], seeds))
            if not usable:
                continue
            clusters = np.array([source_id(p) for p, _ in usable])
            cells = [c for _, seeds in usable for c in seeds]
            entry: dict[str, Any] = {
                "problems": len(usable), "seed_runs": len(cells),
                "min_positives": min(c["tp"] + c["fn"] for c in cells),
                "min_negatives": min(c["fp"] + c["tn"] for c in cells),
                "by_prevalence": {},
            }  # fmt: skip
            for pi in prevalences:
                per_problem = {
                    m: np.array(
                        [np.mean([shifted(c, pi)[m] for c in seeds]) for _, seeds in usable]
                    )
                    for m in METRICS
                }
                entry["by_prevalence"][str(pi)] = {
                    m: bootstrap(v, clusters, by_cluster=True, draws=draws)
                    for m, v in per_problem.items()
                }
            table.setdefault({})[key] = entry
    return {"prevalences": list(prevalences), "budgets": list(budgets), "table": table}


def x_summarize__mutmut_91(
    runs: list[dict[str, Any]],
    budgets: tuple[float, ...] = (0.01, 0.02, 0.05),
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Seed-mean per problem, then the median over problems with a source-resampled interval."""
    methods = sorted(
        {m for r in runs for m, seeds in r["runs"].items() if any("budgets" in s for s in seeds)}
    )
    table: dict[str, Any] = {}
    for method in methods:
        for budget in budgets:
            key = str(budget)
            usable = []
            for run in runs:
                seeds = [
                    s["budgets"][key]
                    for s in run["runs"].get(method, [])
                    if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
                ]
                if seeds:
                    usable.append((run["problem"], seeds))
            if not usable:
                continue
            clusters = np.array([source_id(p) for p, _ in usable])
            cells = [c for _, seeds in usable for c in seeds]
            entry: dict[str, Any] = {
                "problems": len(usable), "seed_runs": len(cells),
                "min_positives": min(c["tp"] + c["fn"] for c in cells),
                "min_negatives": min(c["fp"] + c["tn"] for c in cells),
                "by_prevalence": {},
            }  # fmt: skip
            for pi in prevalences:
                per_problem = {
                    m: np.array(
                        [np.mean([shifted(c, pi)[m] for c in seeds]) for _, seeds in usable]
                    )
                    for m in METRICS
                }
                entry["by_prevalence"][str(pi)] = {
                    m: bootstrap(v, clusters, by_cluster=True, draws=draws)
                    for m, v in per_problem.items()
                }
            table.setdefault(method, )[key] = entry
    return {"prevalences": list(prevalences), "budgets": list(budgets), "table": table}


def x_summarize__mutmut_92(
    runs: list[dict[str, Any]],
    budgets: tuple[float, ...] = (0.01, 0.02, 0.05),
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Seed-mean per problem, then the median over problems with a source-resampled interval."""
    methods = sorted(
        {m for r in runs for m, seeds in r["runs"].items() if any("budgets" in s for s in seeds)}
    )
    table: dict[str, Any] = {}
    for method in methods:
        for budget in budgets:
            key = str(budget)
            usable = []
            for run in runs:
                seeds = [
                    s["budgets"][key]
                    for s in run["runs"].get(method, [])
                    if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
                ]
                if seeds:
                    usable.append((run["problem"], seeds))
            if not usable:
                continue
            clusters = np.array([source_id(p) for p, _ in usable])
            cells = [c for _, seeds in usable for c in seeds]
            entry: dict[str, Any] = {
                "problems": len(usable), "seed_runs": len(cells),
                "min_positives": min(c["tp"] + c["fn"] for c in cells),
                "min_negatives": min(c["fp"] + c["tn"] for c in cells),
                "by_prevalence": {},
            }  # fmt: skip
            for pi in prevalences:
                per_problem = {
                    m: np.array(
                        [np.mean([shifted(c, pi)[m] for c in seeds]) for _, seeds in usable]
                    )
                    for m in METRICS
                }
                entry["by_prevalence"][str(pi)] = {
                    m: bootstrap(v, clusters, by_cluster=True, draws=draws)
                    for m, v in per_problem.items()
                }
            table.setdefault(method, {})[key] = entry
    return {"XXprevalencesXX": list(prevalences), "budgets": list(budgets), "table": table}


def x_summarize__mutmut_93(
    runs: list[dict[str, Any]],
    budgets: tuple[float, ...] = (0.01, 0.02, 0.05),
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Seed-mean per problem, then the median over problems with a source-resampled interval."""
    methods = sorted(
        {m for r in runs for m, seeds in r["runs"].items() if any("budgets" in s for s in seeds)}
    )
    table: dict[str, Any] = {}
    for method in methods:
        for budget in budgets:
            key = str(budget)
            usable = []
            for run in runs:
                seeds = [
                    s["budgets"][key]
                    for s in run["runs"].get(method, [])
                    if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
                ]
                if seeds:
                    usable.append((run["problem"], seeds))
            if not usable:
                continue
            clusters = np.array([source_id(p) for p, _ in usable])
            cells = [c for _, seeds in usable for c in seeds]
            entry: dict[str, Any] = {
                "problems": len(usable), "seed_runs": len(cells),
                "min_positives": min(c["tp"] + c["fn"] for c in cells),
                "min_negatives": min(c["fp"] + c["tn"] for c in cells),
                "by_prevalence": {},
            }  # fmt: skip
            for pi in prevalences:
                per_problem = {
                    m: np.array(
                        [np.mean([shifted(c, pi)[m] for c in seeds]) for _, seeds in usable]
                    )
                    for m in METRICS
                }
                entry["by_prevalence"][str(pi)] = {
                    m: bootstrap(v, clusters, by_cluster=True, draws=draws)
                    for m, v in per_problem.items()
                }
            table.setdefault(method, {})[key] = entry
    return {"PREVALENCES": list(prevalences), "budgets": list(budgets), "table": table}


def x_summarize__mutmut_94(
    runs: list[dict[str, Any]],
    budgets: tuple[float, ...] = (0.01, 0.02, 0.05),
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Seed-mean per problem, then the median over problems with a source-resampled interval."""
    methods = sorted(
        {m for r in runs for m, seeds in r["runs"].items() if any("budgets" in s for s in seeds)}
    )
    table: dict[str, Any] = {}
    for method in methods:
        for budget in budgets:
            key = str(budget)
            usable = []
            for run in runs:
                seeds = [
                    s["budgets"][key]
                    for s in run["runs"].get(method, [])
                    if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
                ]
                if seeds:
                    usable.append((run["problem"], seeds))
            if not usable:
                continue
            clusters = np.array([source_id(p) for p, _ in usable])
            cells = [c for _, seeds in usable for c in seeds]
            entry: dict[str, Any] = {
                "problems": len(usable), "seed_runs": len(cells),
                "min_positives": min(c["tp"] + c["fn"] for c in cells),
                "min_negatives": min(c["fp"] + c["tn"] for c in cells),
                "by_prevalence": {},
            }  # fmt: skip
            for pi in prevalences:
                per_problem = {
                    m: np.array(
                        [np.mean([shifted(c, pi)[m] for c in seeds]) for _, seeds in usable]
                    )
                    for m in METRICS
                }
                entry["by_prevalence"][str(pi)] = {
                    m: bootstrap(v, clusters, by_cluster=True, draws=draws)
                    for m, v in per_problem.items()
                }
            table.setdefault(method, {})[key] = entry
    return {"prevalences": list(None), "budgets": list(budgets), "table": table}


def x_summarize__mutmut_95(
    runs: list[dict[str, Any]],
    budgets: tuple[float, ...] = (0.01, 0.02, 0.05),
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Seed-mean per problem, then the median over problems with a source-resampled interval."""
    methods = sorted(
        {m for r in runs for m, seeds in r["runs"].items() if any("budgets" in s for s in seeds)}
    )
    table: dict[str, Any] = {}
    for method in methods:
        for budget in budgets:
            key = str(budget)
            usable = []
            for run in runs:
                seeds = [
                    s["budgets"][key]
                    for s in run["runs"].get(method, [])
                    if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
                ]
                if seeds:
                    usable.append((run["problem"], seeds))
            if not usable:
                continue
            clusters = np.array([source_id(p) for p, _ in usable])
            cells = [c for _, seeds in usable for c in seeds]
            entry: dict[str, Any] = {
                "problems": len(usable), "seed_runs": len(cells),
                "min_positives": min(c["tp"] + c["fn"] for c in cells),
                "min_negatives": min(c["fp"] + c["tn"] for c in cells),
                "by_prevalence": {},
            }  # fmt: skip
            for pi in prevalences:
                per_problem = {
                    m: np.array(
                        [np.mean([shifted(c, pi)[m] for c in seeds]) for _, seeds in usable]
                    )
                    for m in METRICS
                }
                entry["by_prevalence"][str(pi)] = {
                    m: bootstrap(v, clusters, by_cluster=True, draws=draws)
                    for m, v in per_problem.items()
                }
            table.setdefault(method, {})[key] = entry
    return {"prevalences": list(prevalences), "XXbudgetsXX": list(budgets), "table": table}


def x_summarize__mutmut_96(
    runs: list[dict[str, Any]],
    budgets: tuple[float, ...] = (0.01, 0.02, 0.05),
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Seed-mean per problem, then the median over problems with a source-resampled interval."""
    methods = sorted(
        {m for r in runs for m, seeds in r["runs"].items() if any("budgets" in s for s in seeds)}
    )
    table: dict[str, Any] = {}
    for method in methods:
        for budget in budgets:
            key = str(budget)
            usable = []
            for run in runs:
                seeds = [
                    s["budgets"][key]
                    for s in run["runs"].get(method, [])
                    if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
                ]
                if seeds:
                    usable.append((run["problem"], seeds))
            if not usable:
                continue
            clusters = np.array([source_id(p) for p, _ in usable])
            cells = [c for _, seeds in usable for c in seeds]
            entry: dict[str, Any] = {
                "problems": len(usable), "seed_runs": len(cells),
                "min_positives": min(c["tp"] + c["fn"] for c in cells),
                "min_negatives": min(c["fp"] + c["tn"] for c in cells),
                "by_prevalence": {},
            }  # fmt: skip
            for pi in prevalences:
                per_problem = {
                    m: np.array(
                        [np.mean([shifted(c, pi)[m] for c in seeds]) for _, seeds in usable]
                    )
                    for m in METRICS
                }
                entry["by_prevalence"][str(pi)] = {
                    m: bootstrap(v, clusters, by_cluster=True, draws=draws)
                    for m, v in per_problem.items()
                }
            table.setdefault(method, {})[key] = entry
    return {"prevalences": list(prevalences), "BUDGETS": list(budgets), "table": table}


def x_summarize__mutmut_97(
    runs: list[dict[str, Any]],
    budgets: tuple[float, ...] = (0.01, 0.02, 0.05),
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Seed-mean per problem, then the median over problems with a source-resampled interval."""
    methods = sorted(
        {m for r in runs for m, seeds in r["runs"].items() if any("budgets" in s for s in seeds)}
    )
    table: dict[str, Any] = {}
    for method in methods:
        for budget in budgets:
            key = str(budget)
            usable = []
            for run in runs:
                seeds = [
                    s["budgets"][key]
                    for s in run["runs"].get(method, [])
                    if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
                ]
                if seeds:
                    usable.append((run["problem"], seeds))
            if not usable:
                continue
            clusters = np.array([source_id(p) for p, _ in usable])
            cells = [c for _, seeds in usable for c in seeds]
            entry: dict[str, Any] = {
                "problems": len(usable), "seed_runs": len(cells),
                "min_positives": min(c["tp"] + c["fn"] for c in cells),
                "min_negatives": min(c["fp"] + c["tn"] for c in cells),
                "by_prevalence": {},
            }  # fmt: skip
            for pi in prevalences:
                per_problem = {
                    m: np.array(
                        [np.mean([shifted(c, pi)[m] for c in seeds]) for _, seeds in usable]
                    )
                    for m in METRICS
                }
                entry["by_prevalence"][str(pi)] = {
                    m: bootstrap(v, clusters, by_cluster=True, draws=draws)
                    for m, v in per_problem.items()
                }
            table.setdefault(method, {})[key] = entry
    return {"prevalences": list(prevalences), "budgets": list(None), "table": table}


def x_summarize__mutmut_98(
    runs: list[dict[str, Any]],
    budgets: tuple[float, ...] = (0.01, 0.02, 0.05),
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Seed-mean per problem, then the median over problems with a source-resampled interval."""
    methods = sorted(
        {m for r in runs for m, seeds in r["runs"].items() if any("budgets" in s for s in seeds)}
    )
    table: dict[str, Any] = {}
    for method in methods:
        for budget in budgets:
            key = str(budget)
            usable = []
            for run in runs:
                seeds = [
                    s["budgets"][key]
                    for s in run["runs"].get(method, [])
                    if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
                ]
                if seeds:
                    usable.append((run["problem"], seeds))
            if not usable:
                continue
            clusters = np.array([source_id(p) for p, _ in usable])
            cells = [c for _, seeds in usable for c in seeds]
            entry: dict[str, Any] = {
                "problems": len(usable), "seed_runs": len(cells),
                "min_positives": min(c["tp"] + c["fn"] for c in cells),
                "min_negatives": min(c["fp"] + c["tn"] for c in cells),
                "by_prevalence": {},
            }  # fmt: skip
            for pi in prevalences:
                per_problem = {
                    m: np.array(
                        [np.mean([shifted(c, pi)[m] for c in seeds]) for _, seeds in usable]
                    )
                    for m in METRICS
                }
                entry["by_prevalence"][str(pi)] = {
                    m: bootstrap(v, clusters, by_cluster=True, draws=draws)
                    for m, v in per_problem.items()
                }
            table.setdefault(method, {})[key] = entry
    return {"prevalences": list(prevalences), "budgets": list(budgets), "XXtableXX": table}


def x_summarize__mutmut_99(
    runs: list[dict[str, Any]],
    budgets: tuple[float, ...] = (0.01, 0.02, 0.05),
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Seed-mean per problem, then the median over problems with a source-resampled interval."""
    methods = sorted(
        {m for r in runs for m, seeds in r["runs"].items() if any("budgets" in s for s in seeds)}
    )
    table: dict[str, Any] = {}
    for method in methods:
        for budget in budgets:
            key = str(budget)
            usable = []
            for run in runs:
                seeds = [
                    s["budgets"][key]
                    for s in run["runs"].get(method, [])
                    if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
                ]
                if seeds:
                    usable.append((run["problem"], seeds))
            if not usable:
                continue
            clusters = np.array([source_id(p) for p, _ in usable])
            cells = [c for _, seeds in usable for c in seeds]
            entry: dict[str, Any] = {
                "problems": len(usable), "seed_runs": len(cells),
                "min_positives": min(c["tp"] + c["fn"] for c in cells),
                "min_negatives": min(c["fp"] + c["tn"] for c in cells),
                "by_prevalence": {},
            }  # fmt: skip
            for pi in prevalences:
                per_problem = {
                    m: np.array(
                        [np.mean([shifted(c, pi)[m] for c in seeds]) for _, seeds in usable]
                    )
                    for m in METRICS
                }
                entry["by_prevalence"][str(pi)] = {
                    m: bootstrap(v, clusters, by_cluster=True, draws=draws)
                    for m, v in per_problem.items()
                }
            table.setdefault(method, {})[key] = entry
    return {"prevalences": list(prevalences), "budgets": list(budgets), "TABLE": table}

mutants_x_summarize__mutmut['_mutmut_orig'] = x_summarize__mutmut_orig # type: ignore # mutmut generated
mutants_x_summarize__mutmut['x_summarize__mutmut_1'] = x_summarize__mutmut_1 # type: ignore # mutmut generated
mutants_x_summarize__mutmut['x_summarize__mutmut_2'] = x_summarize__mutmut_2 # type: ignore # mutmut generated
mutants_x_summarize__mutmut['x_summarize__mutmut_3'] = x_summarize__mutmut_3 # type: ignore # mutmut generated
mutants_x_summarize__mutmut['x_summarize__mutmut_4'] = x_summarize__mutmut_4 # type: ignore # mutmut generated
mutants_x_summarize__mutmut['x_summarize__mutmut_5'] = x_summarize__mutmut_5 # type: ignore # mutmut generated
mutants_x_summarize__mutmut['x_summarize__mutmut_6'] = x_summarize__mutmut_6 # type: ignore # mutmut generated
mutants_x_summarize__mutmut['x_summarize__mutmut_7'] = x_summarize__mutmut_7 # type: ignore # mutmut generated
mutants_x_summarize__mutmut['x_summarize__mutmut_8'] = x_summarize__mutmut_8 # type: ignore # mutmut generated
mutants_x_summarize__mutmut['x_summarize__mutmut_9'] = x_summarize__mutmut_9 # type: ignore # mutmut generated
mutants_x_summarize__mutmut['x_summarize__mutmut_10'] = x_summarize__mutmut_10 # type: ignore # mutmut generated
mutants_x_summarize__mutmut['x_summarize__mutmut_11'] = x_summarize__mutmut_11 # type: ignore # mutmut generated
mutants_x_summarize__mutmut['x_summarize__mutmut_12'] = x_summarize__mutmut_12 # type: ignore # mutmut generated
mutants_x_summarize__mutmut['x_summarize__mutmut_13'] = x_summarize__mutmut_13 # type: ignore # mutmut generated
mutants_x_summarize__mutmut['x_summarize__mutmut_14'] = x_summarize__mutmut_14 # type: ignore # mutmut generated
mutants_x_summarize__mutmut['x_summarize__mutmut_15'] = x_summarize__mutmut_15 # type: ignore # mutmut generated
mutants_x_summarize__mutmut['x_summarize__mutmut_16'] = x_summarize__mutmut_16 # type: ignore # mutmut generated
mutants_x_summarize__mutmut['x_summarize__mutmut_17'] = x_summarize__mutmut_17 # type: ignore # mutmut generated
mutants_x_summarize__mutmut['x_summarize__mutmut_18'] = x_summarize__mutmut_18 # type: ignore # mutmut generated
mutants_x_summarize__mutmut['x_summarize__mutmut_19'] = x_summarize__mutmut_19 # type: ignore # mutmut generated
mutants_x_summarize__mutmut['x_summarize__mutmut_20'] = x_summarize__mutmut_20 # type: ignore # mutmut generated
mutants_x_summarize__mutmut['x_summarize__mutmut_21'] = x_summarize__mutmut_21 # type: ignore # mutmut generated
mutants_x_summarize__mutmut['x_summarize__mutmut_22'] = x_summarize__mutmut_22 # type: ignore # mutmut generated
mutants_x_summarize__mutmut['x_summarize__mutmut_23'] = x_summarize__mutmut_23 # type: ignore # mutmut generated
mutants_x_summarize__mutmut['x_summarize__mutmut_24'] = x_summarize__mutmut_24 # type: ignore # mutmut generated
mutants_x_summarize__mutmut['x_summarize__mutmut_25'] = x_summarize__mutmut_25 # type: ignore # mutmut generated
mutants_x_summarize__mutmut['x_summarize__mutmut_26'] = x_summarize__mutmut_26 # type: ignore # mutmut generated
mutants_x_summarize__mutmut['x_summarize__mutmut_27'] = x_summarize__mutmut_27 # type: ignore # mutmut generated
mutants_x_summarize__mutmut['x_summarize__mutmut_28'] = x_summarize__mutmut_28 # type: ignore # mutmut generated
mutants_x_summarize__mutmut['x_summarize__mutmut_29'] = x_summarize__mutmut_29 # type: ignore # mutmut generated
mutants_x_summarize__mutmut['x_summarize__mutmut_30'] = x_summarize__mutmut_30 # type: ignore # mutmut generated
mutants_x_summarize__mutmut['x_summarize__mutmut_31'] = x_summarize__mutmut_31 # type: ignore # mutmut generated
mutants_x_summarize__mutmut['x_summarize__mutmut_32'] = x_summarize__mutmut_32 # type: ignore # mutmut generated
mutants_x_summarize__mutmut['x_summarize__mutmut_33'] = x_summarize__mutmut_33 # type: ignore # mutmut generated
mutants_x_summarize__mutmut['x_summarize__mutmut_34'] = x_summarize__mutmut_34 # type: ignore # mutmut generated
mutants_x_summarize__mutmut['x_summarize__mutmut_35'] = x_summarize__mutmut_35 # type: ignore # mutmut generated
mutants_x_summarize__mutmut['x_summarize__mutmut_36'] = x_summarize__mutmut_36 # type: ignore # mutmut generated
mutants_x_summarize__mutmut['x_summarize__mutmut_37'] = x_summarize__mutmut_37 # type: ignore # mutmut generated
mutants_x_summarize__mutmut['x_summarize__mutmut_38'] = x_summarize__mutmut_38 # type: ignore # mutmut generated
mutants_x_summarize__mutmut['x_summarize__mutmut_39'] = x_summarize__mutmut_39 # type: ignore # mutmut generated
mutants_x_summarize__mutmut['x_summarize__mutmut_40'] = x_summarize__mutmut_40 # type: ignore # mutmut generated
mutants_x_summarize__mutmut['x_summarize__mutmut_41'] = x_summarize__mutmut_41 # type: ignore # mutmut generated
mutants_x_summarize__mutmut['x_summarize__mutmut_42'] = x_summarize__mutmut_42 # type: ignore # mutmut generated
mutants_x_summarize__mutmut['x_summarize__mutmut_43'] = x_summarize__mutmut_43 # type: ignore # mutmut generated
mutants_x_summarize__mutmut['x_summarize__mutmut_44'] = x_summarize__mutmut_44 # type: ignore # mutmut generated
mutants_x_summarize__mutmut['x_summarize__mutmut_45'] = x_summarize__mutmut_45 # type: ignore # mutmut generated
mutants_x_summarize__mutmut['x_summarize__mutmut_46'] = x_summarize__mutmut_46 # type: ignore # mutmut generated
mutants_x_summarize__mutmut['x_summarize__mutmut_47'] = x_summarize__mutmut_47 # type: ignore # mutmut generated
mutants_x_summarize__mutmut['x_summarize__mutmut_48'] = x_summarize__mutmut_48 # type: ignore # mutmut generated
mutants_x_summarize__mutmut['x_summarize__mutmut_49'] = x_summarize__mutmut_49 # type: ignore # mutmut generated
mutants_x_summarize__mutmut['x_summarize__mutmut_50'] = x_summarize__mutmut_50 # type: ignore # mutmut generated
mutants_x_summarize__mutmut['x_summarize__mutmut_51'] = x_summarize__mutmut_51 # type: ignore # mutmut generated
mutants_x_summarize__mutmut['x_summarize__mutmut_52'] = x_summarize__mutmut_52 # type: ignore # mutmut generated
mutants_x_summarize__mutmut['x_summarize__mutmut_53'] = x_summarize__mutmut_53 # type: ignore # mutmut generated
mutants_x_summarize__mutmut['x_summarize__mutmut_54'] = x_summarize__mutmut_54 # type: ignore # mutmut generated
mutants_x_summarize__mutmut['x_summarize__mutmut_55'] = x_summarize__mutmut_55 # type: ignore # mutmut generated
mutants_x_summarize__mutmut['x_summarize__mutmut_56'] = x_summarize__mutmut_56 # type: ignore # mutmut generated
mutants_x_summarize__mutmut['x_summarize__mutmut_57'] = x_summarize__mutmut_57 # type: ignore # mutmut generated
mutants_x_summarize__mutmut['x_summarize__mutmut_58'] = x_summarize__mutmut_58 # type: ignore # mutmut generated
mutants_x_summarize__mutmut['x_summarize__mutmut_59'] = x_summarize__mutmut_59 # type: ignore # mutmut generated
mutants_x_summarize__mutmut['x_summarize__mutmut_60'] = x_summarize__mutmut_60 # type: ignore # mutmut generated
mutants_x_summarize__mutmut['x_summarize__mutmut_61'] = x_summarize__mutmut_61 # type: ignore # mutmut generated
mutants_x_summarize__mutmut['x_summarize__mutmut_62'] = x_summarize__mutmut_62 # type: ignore # mutmut generated
mutants_x_summarize__mutmut['x_summarize__mutmut_63'] = x_summarize__mutmut_63 # type: ignore # mutmut generated
mutants_x_summarize__mutmut['x_summarize__mutmut_64'] = x_summarize__mutmut_64 # type: ignore # mutmut generated
mutants_x_summarize__mutmut['x_summarize__mutmut_65'] = x_summarize__mutmut_65 # type: ignore # mutmut generated
mutants_x_summarize__mutmut['x_summarize__mutmut_66'] = x_summarize__mutmut_66 # type: ignore # mutmut generated
mutants_x_summarize__mutmut['x_summarize__mutmut_67'] = x_summarize__mutmut_67 # type: ignore # mutmut generated
mutants_x_summarize__mutmut['x_summarize__mutmut_68'] = x_summarize__mutmut_68 # type: ignore # mutmut generated
mutants_x_summarize__mutmut['x_summarize__mutmut_69'] = x_summarize__mutmut_69 # type: ignore # mutmut generated
mutants_x_summarize__mutmut['x_summarize__mutmut_70'] = x_summarize__mutmut_70 # type: ignore # mutmut generated
mutants_x_summarize__mutmut['x_summarize__mutmut_71'] = x_summarize__mutmut_71 # type: ignore # mutmut generated
mutants_x_summarize__mutmut['x_summarize__mutmut_72'] = x_summarize__mutmut_72 # type: ignore # mutmut generated
mutants_x_summarize__mutmut['x_summarize__mutmut_73'] = x_summarize__mutmut_73 # type: ignore # mutmut generated
mutants_x_summarize__mutmut['x_summarize__mutmut_74'] = x_summarize__mutmut_74 # type: ignore # mutmut generated
mutants_x_summarize__mutmut['x_summarize__mutmut_75'] = x_summarize__mutmut_75 # type: ignore # mutmut generated
mutants_x_summarize__mutmut['x_summarize__mutmut_76'] = x_summarize__mutmut_76 # type: ignore # mutmut generated
mutants_x_summarize__mutmut['x_summarize__mutmut_77'] = x_summarize__mutmut_77 # type: ignore # mutmut generated
mutants_x_summarize__mutmut['x_summarize__mutmut_78'] = x_summarize__mutmut_78 # type: ignore # mutmut generated
mutants_x_summarize__mutmut['x_summarize__mutmut_79'] = x_summarize__mutmut_79 # type: ignore # mutmut generated
mutants_x_summarize__mutmut['x_summarize__mutmut_80'] = x_summarize__mutmut_80 # type: ignore # mutmut generated
mutants_x_summarize__mutmut['x_summarize__mutmut_81'] = x_summarize__mutmut_81 # type: ignore # mutmut generated
mutants_x_summarize__mutmut['x_summarize__mutmut_82'] = x_summarize__mutmut_82 # type: ignore # mutmut generated
mutants_x_summarize__mutmut['x_summarize__mutmut_83'] = x_summarize__mutmut_83 # type: ignore # mutmut generated
mutants_x_summarize__mutmut['x_summarize__mutmut_84'] = x_summarize__mutmut_84 # type: ignore # mutmut generated
mutants_x_summarize__mutmut['x_summarize__mutmut_85'] = x_summarize__mutmut_85 # type: ignore # mutmut generated
mutants_x_summarize__mutmut['x_summarize__mutmut_86'] = x_summarize__mutmut_86 # type: ignore # mutmut generated
mutants_x_summarize__mutmut['x_summarize__mutmut_87'] = x_summarize__mutmut_87 # type: ignore # mutmut generated
mutants_x_summarize__mutmut['x_summarize__mutmut_88'] = x_summarize__mutmut_88 # type: ignore # mutmut generated
mutants_x_summarize__mutmut['x_summarize__mutmut_89'] = x_summarize__mutmut_89 # type: ignore # mutmut generated
mutants_x_summarize__mutmut['x_summarize__mutmut_90'] = x_summarize__mutmut_90 # type: ignore # mutmut generated
mutants_x_summarize__mutmut['x_summarize__mutmut_91'] = x_summarize__mutmut_91 # type: ignore # mutmut generated
mutants_x_summarize__mutmut['x_summarize__mutmut_92'] = x_summarize__mutmut_92 # type: ignore # mutmut generated
mutants_x_summarize__mutmut['x_summarize__mutmut_93'] = x_summarize__mutmut_93 # type: ignore # mutmut generated
mutants_x_summarize__mutmut['x_summarize__mutmut_94'] = x_summarize__mutmut_94 # type: ignore # mutmut generated
mutants_x_summarize__mutmut['x_summarize__mutmut_95'] = x_summarize__mutmut_95 # type: ignore # mutmut generated
mutants_x_summarize__mutmut['x_summarize__mutmut_96'] = x_summarize__mutmut_96 # type: ignore # mutmut generated
mutants_x_summarize__mutmut['x_summarize__mutmut_97'] = x_summarize__mutmut_97 # type: ignore # mutmut generated
mutants_x_summarize__mutmut['x_summarize__mutmut_98'] = x_summarize__mutmut_98 # type: ignore # mutmut generated
mutants_x_summarize__mutmut['x_summarize__mutmut_99'] = x_summarize__mutmut_99 # type: ignore # mutmut generated


MIN_SOURCES = 10  # fewer independent sources than this give no interval
CONTRAST_METRICS = ("alert_over_budget", "precision")
mutants_x_contrasts__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_contrasts__mutmut)
def contrasts(
    runs: list[dict[str, Any]],
    budget: float = 0.02,
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Change of the fixed threshold's behaviour from the observed prevalence to ``pi``.

    Per problem, the metrics of the threshold at ``pi`` minus its metrics at the problem's own
    held-out prevalence (the observed cell), averaged over the fits of all detectors and seeds
    that share the data. The independent unit is the original source, resampled as a whole; a
    contrast needs at least ``MIN_SOURCES`` sources. Holm adjusts over prevalence-metric pairs.
    """
    key = str(budget)
    problems, per_problem = [], []
    for run in runs:
        cells = [
            c
            for seeds in run["runs"].values()
            for s in seeds
            if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
            for c in [s["budgets"][key]]
        ]
        if not cells:
            continue
        rows = {}
        for pi in prevalences:
            observed = [
                shifted(c, (c["tp"] + c["fn"]) / (c["tp"] + c["fn"] + c["fp"] + c["tn"]))
                for c in cells
            ]
            moved = [shifted(c, pi) for c in cells]
            rows[pi] = {
                m: float(np.mean([a[m] - b[m] for a, b in zip(moved, observed, strict=True)]))
                for m in CONTRAST_METRICS
            }
        problems.append(run["problem"])
        per_problem.append(rows)
    clusters = np.array([source_id(p) for p in problems])
    sources, counts = np.unique(clusters, return_counts=True)
    out: dict[str, Any] = {
        "budget": budget, "problems": len(problems), "sources": int(len(sources)),
        "singleton_sources": int((counts == 1).sum()), "draws": draws, "contrasts": [],
    }  # fmt: skip
    if len(sources) < MIN_SOURCES:
        out["insufficient"] = f"fewer than {MIN_SOURCES} independent sources"
        return out
    for pi in prevalences:
        for metric in CONTRAST_METRICS:
            values = np.array([row[pi][metric] for row in per_problem])
            out["contrasts"].append(
                {"prevalence": pi, "metric": metric}
                | bootstrap(values, clusters, by_cluster=True, draws=draws)
            )
    adjusted = holm([c["p_two_sided"] for c in out["contrasts"]])
    for item, value in zip(out["contrasts"], adjusted, strict=True):
        item["holm_p"] = value
    return out


def x_contrasts__mutmut_orig(
    runs: list[dict[str, Any]],
    budget: float = 0.02,
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Change of the fixed threshold's behaviour from the observed prevalence to ``pi``.

    Per problem, the metrics of the threshold at ``pi`` minus its metrics at the problem's own
    held-out prevalence (the observed cell), averaged over the fits of all detectors and seeds
    that share the data. The independent unit is the original source, resampled as a whole; a
    contrast needs at least ``MIN_SOURCES`` sources. Holm adjusts over prevalence-metric pairs.
    """
    key = str(budget)
    problems, per_problem = [], []
    for run in runs:
        cells = [
            c
            for seeds in run["runs"].values()
            for s in seeds
            if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
            for c in [s["budgets"][key]]
        ]
        if not cells:
            continue
        rows = {}
        for pi in prevalences:
            observed = [
                shifted(c, (c["tp"] + c["fn"]) / (c["tp"] + c["fn"] + c["fp"] + c["tn"]))
                for c in cells
            ]
            moved = [shifted(c, pi) for c in cells]
            rows[pi] = {
                m: float(np.mean([a[m] - b[m] for a, b in zip(moved, observed, strict=True)]))
                for m in CONTRAST_METRICS
            }
        problems.append(run["problem"])
        per_problem.append(rows)
    clusters = np.array([source_id(p) for p in problems])
    sources, counts = np.unique(clusters, return_counts=True)
    out: dict[str, Any] = {
        "budget": budget, "problems": len(problems), "sources": int(len(sources)),
        "singleton_sources": int((counts == 1).sum()), "draws": draws, "contrasts": [],
    }  # fmt: skip
    if len(sources) < MIN_SOURCES:
        out["insufficient"] = f"fewer than {MIN_SOURCES} independent sources"
        return out
    for pi in prevalences:
        for metric in CONTRAST_METRICS:
            values = np.array([row[pi][metric] for row in per_problem])
            out["contrasts"].append(
                {"prevalence": pi, "metric": metric}
                | bootstrap(values, clusters, by_cluster=True, draws=draws)
            )
    adjusted = holm([c["p_two_sided"] for c in out["contrasts"]])
    for item, value in zip(out["contrasts"], adjusted, strict=True):
        item["holm_p"] = value
    return out


def x_contrasts__mutmut_1(
    runs: list[dict[str, Any]],
    budget: float = 1.02,
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Change of the fixed threshold's behaviour from the observed prevalence to ``pi``.

    Per problem, the metrics of the threshold at ``pi`` minus its metrics at the problem's own
    held-out prevalence (the observed cell), averaged over the fits of all detectors and seeds
    that share the data. The independent unit is the original source, resampled as a whole; a
    contrast needs at least ``MIN_SOURCES`` sources. Holm adjusts over prevalence-metric pairs.
    """
    key = str(budget)
    problems, per_problem = [], []
    for run in runs:
        cells = [
            c
            for seeds in run["runs"].values()
            for s in seeds
            if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
            for c in [s["budgets"][key]]
        ]
        if not cells:
            continue
        rows = {}
        for pi in prevalences:
            observed = [
                shifted(c, (c["tp"] + c["fn"]) / (c["tp"] + c["fn"] + c["fp"] + c["tn"]))
                for c in cells
            ]
            moved = [shifted(c, pi) for c in cells]
            rows[pi] = {
                m: float(np.mean([a[m] - b[m] for a, b in zip(moved, observed, strict=True)]))
                for m in CONTRAST_METRICS
            }
        problems.append(run["problem"])
        per_problem.append(rows)
    clusters = np.array([source_id(p) for p in problems])
    sources, counts = np.unique(clusters, return_counts=True)
    out: dict[str, Any] = {
        "budget": budget, "problems": len(problems), "sources": int(len(sources)),
        "singleton_sources": int((counts == 1).sum()), "draws": draws, "contrasts": [],
    }  # fmt: skip
    if len(sources) < MIN_SOURCES:
        out["insufficient"] = f"fewer than {MIN_SOURCES} independent sources"
        return out
    for pi in prevalences:
        for metric in CONTRAST_METRICS:
            values = np.array([row[pi][metric] for row in per_problem])
            out["contrasts"].append(
                {"prevalence": pi, "metric": metric}
                | bootstrap(values, clusters, by_cluster=True, draws=draws)
            )
    adjusted = holm([c["p_two_sided"] for c in out["contrasts"]])
    for item, value in zip(out["contrasts"], adjusted, strict=True):
        item["holm_p"] = value
    return out


def x_contrasts__mutmut_2(
    runs: list[dict[str, Any]],
    budget: float = 0.02,
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Change of the fixed threshold's behaviour from the observed prevalence to ``pi``.

    Per problem, the metrics of the threshold at ``pi`` minus its metrics at the problem's own
    held-out prevalence (the observed cell), averaged over the fits of all detectors and seeds
    that share the data. The independent unit is the original source, resampled as a whole; a
    contrast needs at least ``MIN_SOURCES`` sources. Holm adjusts over prevalence-metric pairs.
    """
    key = None
    problems, per_problem = [], []
    for run in runs:
        cells = [
            c
            for seeds in run["runs"].values()
            for s in seeds
            if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
            for c in [s["budgets"][key]]
        ]
        if not cells:
            continue
        rows = {}
        for pi in prevalences:
            observed = [
                shifted(c, (c["tp"] + c["fn"]) / (c["tp"] + c["fn"] + c["fp"] + c["tn"]))
                for c in cells
            ]
            moved = [shifted(c, pi) for c in cells]
            rows[pi] = {
                m: float(np.mean([a[m] - b[m] for a, b in zip(moved, observed, strict=True)]))
                for m in CONTRAST_METRICS
            }
        problems.append(run["problem"])
        per_problem.append(rows)
    clusters = np.array([source_id(p) for p in problems])
    sources, counts = np.unique(clusters, return_counts=True)
    out: dict[str, Any] = {
        "budget": budget, "problems": len(problems), "sources": int(len(sources)),
        "singleton_sources": int((counts == 1).sum()), "draws": draws, "contrasts": [],
    }  # fmt: skip
    if len(sources) < MIN_SOURCES:
        out["insufficient"] = f"fewer than {MIN_SOURCES} independent sources"
        return out
    for pi in prevalences:
        for metric in CONTRAST_METRICS:
            values = np.array([row[pi][metric] for row in per_problem])
            out["contrasts"].append(
                {"prevalence": pi, "metric": metric}
                | bootstrap(values, clusters, by_cluster=True, draws=draws)
            )
    adjusted = holm([c["p_two_sided"] for c in out["contrasts"]])
    for item, value in zip(out["contrasts"], adjusted, strict=True):
        item["holm_p"] = value
    return out


def x_contrasts__mutmut_3(
    runs: list[dict[str, Any]],
    budget: float = 0.02,
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Change of the fixed threshold's behaviour from the observed prevalence to ``pi``.

    Per problem, the metrics of the threshold at ``pi`` minus its metrics at the problem's own
    held-out prevalence (the observed cell), averaged over the fits of all detectors and seeds
    that share the data. The independent unit is the original source, resampled as a whole; a
    contrast needs at least ``MIN_SOURCES`` sources. Holm adjusts over prevalence-metric pairs.
    """
    key = str(None)
    problems, per_problem = [], []
    for run in runs:
        cells = [
            c
            for seeds in run["runs"].values()
            for s in seeds
            if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
            for c in [s["budgets"][key]]
        ]
        if not cells:
            continue
        rows = {}
        for pi in prevalences:
            observed = [
                shifted(c, (c["tp"] + c["fn"]) / (c["tp"] + c["fn"] + c["fp"] + c["tn"]))
                for c in cells
            ]
            moved = [shifted(c, pi) for c in cells]
            rows[pi] = {
                m: float(np.mean([a[m] - b[m] for a, b in zip(moved, observed, strict=True)]))
                for m in CONTRAST_METRICS
            }
        problems.append(run["problem"])
        per_problem.append(rows)
    clusters = np.array([source_id(p) for p in problems])
    sources, counts = np.unique(clusters, return_counts=True)
    out: dict[str, Any] = {
        "budget": budget, "problems": len(problems), "sources": int(len(sources)),
        "singleton_sources": int((counts == 1).sum()), "draws": draws, "contrasts": [],
    }  # fmt: skip
    if len(sources) < MIN_SOURCES:
        out["insufficient"] = f"fewer than {MIN_SOURCES} independent sources"
        return out
    for pi in prevalences:
        for metric in CONTRAST_METRICS:
            values = np.array([row[pi][metric] for row in per_problem])
            out["contrasts"].append(
                {"prevalence": pi, "metric": metric}
                | bootstrap(values, clusters, by_cluster=True, draws=draws)
            )
    adjusted = holm([c["p_two_sided"] for c in out["contrasts"]])
    for item, value in zip(out["contrasts"], adjusted, strict=True):
        item["holm_p"] = value
    return out


def x_contrasts__mutmut_4(
    runs: list[dict[str, Any]],
    budget: float = 0.02,
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Change of the fixed threshold's behaviour from the observed prevalence to ``pi``.

    Per problem, the metrics of the threshold at ``pi`` minus its metrics at the problem's own
    held-out prevalence (the observed cell), averaged over the fits of all detectors and seeds
    that share the data. The independent unit is the original source, resampled as a whole; a
    contrast needs at least ``MIN_SOURCES`` sources. Holm adjusts over prevalence-metric pairs.
    """
    key = str(budget)
    problems, per_problem = None
    for run in runs:
        cells = [
            c
            for seeds in run["runs"].values()
            for s in seeds
            if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
            for c in [s["budgets"][key]]
        ]
        if not cells:
            continue
        rows = {}
        for pi in prevalences:
            observed = [
                shifted(c, (c["tp"] + c["fn"]) / (c["tp"] + c["fn"] + c["fp"] + c["tn"]))
                for c in cells
            ]
            moved = [shifted(c, pi) for c in cells]
            rows[pi] = {
                m: float(np.mean([a[m] - b[m] for a, b in zip(moved, observed, strict=True)]))
                for m in CONTRAST_METRICS
            }
        problems.append(run["problem"])
        per_problem.append(rows)
    clusters = np.array([source_id(p) for p in problems])
    sources, counts = np.unique(clusters, return_counts=True)
    out: dict[str, Any] = {
        "budget": budget, "problems": len(problems), "sources": int(len(sources)),
        "singleton_sources": int((counts == 1).sum()), "draws": draws, "contrasts": [],
    }  # fmt: skip
    if len(sources) < MIN_SOURCES:
        out["insufficient"] = f"fewer than {MIN_SOURCES} independent sources"
        return out
    for pi in prevalences:
        for metric in CONTRAST_METRICS:
            values = np.array([row[pi][metric] for row in per_problem])
            out["contrasts"].append(
                {"prevalence": pi, "metric": metric}
                | bootstrap(values, clusters, by_cluster=True, draws=draws)
            )
    adjusted = holm([c["p_two_sided"] for c in out["contrasts"]])
    for item, value in zip(out["contrasts"], adjusted, strict=True):
        item["holm_p"] = value
    return out


def x_contrasts__mutmut_5(
    runs: list[dict[str, Any]],
    budget: float = 0.02,
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Change of the fixed threshold's behaviour from the observed prevalence to ``pi``.

    Per problem, the metrics of the threshold at ``pi`` minus its metrics at the problem's own
    held-out prevalence (the observed cell), averaged over the fits of all detectors and seeds
    that share the data. The independent unit is the original source, resampled as a whole; a
    contrast needs at least ``MIN_SOURCES`` sources. Holm adjusts over prevalence-metric pairs.
    """
    key = str(budget)
    problems, per_problem = [], []
    for run in runs:
        cells = None
        if not cells:
            continue
        rows = {}
        for pi in prevalences:
            observed = [
                shifted(c, (c["tp"] + c["fn"]) / (c["tp"] + c["fn"] + c["fp"] + c["tn"]))
                for c in cells
            ]
            moved = [shifted(c, pi) for c in cells]
            rows[pi] = {
                m: float(np.mean([a[m] - b[m] for a, b in zip(moved, observed, strict=True)]))
                for m in CONTRAST_METRICS
            }
        problems.append(run["problem"])
        per_problem.append(rows)
    clusters = np.array([source_id(p) for p in problems])
    sources, counts = np.unique(clusters, return_counts=True)
    out: dict[str, Any] = {
        "budget": budget, "problems": len(problems), "sources": int(len(sources)),
        "singleton_sources": int((counts == 1).sum()), "draws": draws, "contrasts": [],
    }  # fmt: skip
    if len(sources) < MIN_SOURCES:
        out["insufficient"] = f"fewer than {MIN_SOURCES} independent sources"
        return out
    for pi in prevalences:
        for metric in CONTRAST_METRICS:
            values = np.array([row[pi][metric] for row in per_problem])
            out["contrasts"].append(
                {"prevalence": pi, "metric": metric}
                | bootstrap(values, clusters, by_cluster=True, draws=draws)
            )
    adjusted = holm([c["p_two_sided"] for c in out["contrasts"]])
    for item, value in zip(out["contrasts"], adjusted, strict=True):
        item["holm_p"] = value
    return out


def x_contrasts__mutmut_6(
    runs: list[dict[str, Any]],
    budget: float = 0.02,
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Change of the fixed threshold's behaviour from the observed prevalence to ``pi``.

    Per problem, the metrics of the threshold at ``pi`` minus its metrics at the problem's own
    held-out prevalence (the observed cell), averaged over the fits of all detectors and seeds
    that share the data. The independent unit is the original source, resampled as a whole; a
    contrast needs at least ``MIN_SOURCES`` sources. Holm adjusts over prevalence-metric pairs.
    """
    key = str(budget)
    problems, per_problem = [], []
    for run in runs:
        cells = [
            c
            for seeds in run["XXrunsXX"].values()
            for s in seeds
            if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
            for c in [s["budgets"][key]]
        ]
        if not cells:
            continue
        rows = {}
        for pi in prevalences:
            observed = [
                shifted(c, (c["tp"] + c["fn"]) / (c["tp"] + c["fn"] + c["fp"] + c["tn"]))
                for c in cells
            ]
            moved = [shifted(c, pi) for c in cells]
            rows[pi] = {
                m: float(np.mean([a[m] - b[m] for a, b in zip(moved, observed, strict=True)]))
                for m in CONTRAST_METRICS
            }
        problems.append(run["problem"])
        per_problem.append(rows)
    clusters = np.array([source_id(p) for p in problems])
    sources, counts = np.unique(clusters, return_counts=True)
    out: dict[str, Any] = {
        "budget": budget, "problems": len(problems), "sources": int(len(sources)),
        "singleton_sources": int((counts == 1).sum()), "draws": draws, "contrasts": [],
    }  # fmt: skip
    if len(sources) < MIN_SOURCES:
        out["insufficient"] = f"fewer than {MIN_SOURCES} independent sources"
        return out
    for pi in prevalences:
        for metric in CONTRAST_METRICS:
            values = np.array([row[pi][metric] for row in per_problem])
            out["contrasts"].append(
                {"prevalence": pi, "metric": metric}
                | bootstrap(values, clusters, by_cluster=True, draws=draws)
            )
    adjusted = holm([c["p_two_sided"] for c in out["contrasts"]])
    for item, value in zip(out["contrasts"], adjusted, strict=True):
        item["holm_p"] = value
    return out


def x_contrasts__mutmut_7(
    runs: list[dict[str, Any]],
    budget: float = 0.02,
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Change of the fixed threshold's behaviour from the observed prevalence to ``pi``.

    Per problem, the metrics of the threshold at ``pi`` minus its metrics at the problem's own
    held-out prevalence (the observed cell), averaged over the fits of all detectors and seeds
    that share the data. The independent unit is the original source, resampled as a whole; a
    contrast needs at least ``MIN_SOURCES`` sources. Holm adjusts over prevalence-metric pairs.
    """
    key = str(budget)
    problems, per_problem = [], []
    for run in runs:
        cells = [
            c
            for seeds in run["RUNS"].values()
            for s in seeds
            if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
            for c in [s["budgets"][key]]
        ]
        if not cells:
            continue
        rows = {}
        for pi in prevalences:
            observed = [
                shifted(c, (c["tp"] + c["fn"]) / (c["tp"] + c["fn"] + c["fp"] + c["tn"]))
                for c in cells
            ]
            moved = [shifted(c, pi) for c in cells]
            rows[pi] = {
                m: float(np.mean([a[m] - b[m] for a, b in zip(moved, observed, strict=True)]))
                for m in CONTRAST_METRICS
            }
        problems.append(run["problem"])
        per_problem.append(rows)
    clusters = np.array([source_id(p) for p in problems])
    sources, counts = np.unique(clusters, return_counts=True)
    out: dict[str, Any] = {
        "budget": budget, "problems": len(problems), "sources": int(len(sources)),
        "singleton_sources": int((counts == 1).sum()), "draws": draws, "contrasts": [],
    }  # fmt: skip
    if len(sources) < MIN_SOURCES:
        out["insufficient"] = f"fewer than {MIN_SOURCES} independent sources"
        return out
    for pi in prevalences:
        for metric in CONTRAST_METRICS:
            values = np.array([row[pi][metric] for row in per_problem])
            out["contrasts"].append(
                {"prevalence": pi, "metric": metric}
                | bootstrap(values, clusters, by_cluster=True, draws=draws)
            )
    adjusted = holm([c["p_two_sided"] for c in out["contrasts"]])
    for item, value in zip(out["contrasts"], adjusted, strict=True):
        item["holm_p"] = value
    return out


def x_contrasts__mutmut_8(
    runs: list[dict[str, Any]],
    budget: float = 0.02,
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Change of the fixed threshold's behaviour from the observed prevalence to ``pi``.

    Per problem, the metrics of the threshold at ``pi`` minus its metrics at the problem's own
    held-out prevalence (the observed cell), averaged over the fits of all detectors and seeds
    that share the data. The independent unit is the original source, resampled as a whole; a
    contrast needs at least ``MIN_SOURCES`` sources. Holm adjusts over prevalence-metric pairs.
    """
    key = str(budget)
    problems, per_problem = [], []
    for run in runs:
        cells = [
            c
            for seeds in run["runs"].values()
            for s in seeds
            if key in s.get("budgets", {}) or "infeasible" not in s["budgets"][key]
            for c in [s["budgets"][key]]
        ]
        if not cells:
            continue
        rows = {}
        for pi in prevalences:
            observed = [
                shifted(c, (c["tp"] + c["fn"]) / (c["tp"] + c["fn"] + c["fp"] + c["tn"]))
                for c in cells
            ]
            moved = [shifted(c, pi) for c in cells]
            rows[pi] = {
                m: float(np.mean([a[m] - b[m] for a, b in zip(moved, observed, strict=True)]))
                for m in CONTRAST_METRICS
            }
        problems.append(run["problem"])
        per_problem.append(rows)
    clusters = np.array([source_id(p) for p in problems])
    sources, counts = np.unique(clusters, return_counts=True)
    out: dict[str, Any] = {
        "budget": budget, "problems": len(problems), "sources": int(len(sources)),
        "singleton_sources": int((counts == 1).sum()), "draws": draws, "contrasts": [],
    }  # fmt: skip
    if len(sources) < MIN_SOURCES:
        out["insufficient"] = f"fewer than {MIN_SOURCES} independent sources"
        return out
    for pi in prevalences:
        for metric in CONTRAST_METRICS:
            values = np.array([row[pi][metric] for row in per_problem])
            out["contrasts"].append(
                {"prevalence": pi, "metric": metric}
                | bootstrap(values, clusters, by_cluster=True, draws=draws)
            )
    adjusted = holm([c["p_two_sided"] for c in out["contrasts"]])
    for item, value in zip(out["contrasts"], adjusted, strict=True):
        item["holm_p"] = value
    return out


def x_contrasts__mutmut_9(
    runs: list[dict[str, Any]],
    budget: float = 0.02,
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Change of the fixed threshold's behaviour from the observed prevalence to ``pi``.

    Per problem, the metrics of the threshold at ``pi`` minus its metrics at the problem's own
    held-out prevalence (the observed cell), averaged over the fits of all detectors and seeds
    that share the data. The independent unit is the original source, resampled as a whole; a
    contrast needs at least ``MIN_SOURCES`` sources. Holm adjusts over prevalence-metric pairs.
    """
    key = str(budget)
    problems, per_problem = [], []
    for run in runs:
        cells = [
            c
            for seeds in run["runs"].values()
            for s in seeds
            if key not in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
            for c in [s["budgets"][key]]
        ]
        if not cells:
            continue
        rows = {}
        for pi in prevalences:
            observed = [
                shifted(c, (c["tp"] + c["fn"]) / (c["tp"] + c["fn"] + c["fp"] + c["tn"]))
                for c in cells
            ]
            moved = [shifted(c, pi) for c in cells]
            rows[pi] = {
                m: float(np.mean([a[m] - b[m] for a, b in zip(moved, observed, strict=True)]))
                for m in CONTRAST_METRICS
            }
        problems.append(run["problem"])
        per_problem.append(rows)
    clusters = np.array([source_id(p) for p in problems])
    sources, counts = np.unique(clusters, return_counts=True)
    out: dict[str, Any] = {
        "budget": budget, "problems": len(problems), "sources": int(len(sources)),
        "singleton_sources": int((counts == 1).sum()), "draws": draws, "contrasts": [],
    }  # fmt: skip
    if len(sources) < MIN_SOURCES:
        out["insufficient"] = f"fewer than {MIN_SOURCES} independent sources"
        return out
    for pi in prevalences:
        for metric in CONTRAST_METRICS:
            values = np.array([row[pi][metric] for row in per_problem])
            out["contrasts"].append(
                {"prevalence": pi, "metric": metric}
                | bootstrap(values, clusters, by_cluster=True, draws=draws)
            )
    adjusted = holm([c["p_two_sided"] for c in out["contrasts"]])
    for item, value in zip(out["contrasts"], adjusted, strict=True):
        item["holm_p"] = value
    return out


def x_contrasts__mutmut_10(
    runs: list[dict[str, Any]],
    budget: float = 0.02,
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Change of the fixed threshold's behaviour from the observed prevalence to ``pi``.

    Per problem, the metrics of the threshold at ``pi`` minus its metrics at the problem's own
    held-out prevalence (the observed cell), averaged over the fits of all detectors and seeds
    that share the data. The independent unit is the original source, resampled as a whole; a
    contrast needs at least ``MIN_SOURCES`` sources. Holm adjusts over prevalence-metric pairs.
    """
    key = str(budget)
    problems, per_problem = [], []
    for run in runs:
        cells = [
            c
            for seeds in run["runs"].values()
            for s in seeds
            if key in s.get(None, {}) and "infeasible" not in s["budgets"][key]
            for c in [s["budgets"][key]]
        ]
        if not cells:
            continue
        rows = {}
        for pi in prevalences:
            observed = [
                shifted(c, (c["tp"] + c["fn"]) / (c["tp"] + c["fn"] + c["fp"] + c["tn"]))
                for c in cells
            ]
            moved = [shifted(c, pi) for c in cells]
            rows[pi] = {
                m: float(np.mean([a[m] - b[m] for a, b in zip(moved, observed, strict=True)]))
                for m in CONTRAST_METRICS
            }
        problems.append(run["problem"])
        per_problem.append(rows)
    clusters = np.array([source_id(p) for p in problems])
    sources, counts = np.unique(clusters, return_counts=True)
    out: dict[str, Any] = {
        "budget": budget, "problems": len(problems), "sources": int(len(sources)),
        "singleton_sources": int((counts == 1).sum()), "draws": draws, "contrasts": [],
    }  # fmt: skip
    if len(sources) < MIN_SOURCES:
        out["insufficient"] = f"fewer than {MIN_SOURCES} independent sources"
        return out
    for pi in prevalences:
        for metric in CONTRAST_METRICS:
            values = np.array([row[pi][metric] for row in per_problem])
            out["contrasts"].append(
                {"prevalence": pi, "metric": metric}
                | bootstrap(values, clusters, by_cluster=True, draws=draws)
            )
    adjusted = holm([c["p_two_sided"] for c in out["contrasts"]])
    for item, value in zip(out["contrasts"], adjusted, strict=True):
        item["holm_p"] = value
    return out


def x_contrasts__mutmut_11(
    runs: list[dict[str, Any]],
    budget: float = 0.02,
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Change of the fixed threshold's behaviour from the observed prevalence to ``pi``.

    Per problem, the metrics of the threshold at ``pi`` minus its metrics at the problem's own
    held-out prevalence (the observed cell), averaged over the fits of all detectors and seeds
    that share the data. The independent unit is the original source, resampled as a whole; a
    contrast needs at least ``MIN_SOURCES`` sources. Holm adjusts over prevalence-metric pairs.
    """
    key = str(budget)
    problems, per_problem = [], []
    for run in runs:
        cells = [
            c
            for seeds in run["runs"].values()
            for s in seeds
            if key in s.get("budgets", None) and "infeasible" not in s["budgets"][key]
            for c in [s["budgets"][key]]
        ]
        if not cells:
            continue
        rows = {}
        for pi in prevalences:
            observed = [
                shifted(c, (c["tp"] + c["fn"]) / (c["tp"] + c["fn"] + c["fp"] + c["tn"]))
                for c in cells
            ]
            moved = [shifted(c, pi) for c in cells]
            rows[pi] = {
                m: float(np.mean([a[m] - b[m] for a, b in zip(moved, observed, strict=True)]))
                for m in CONTRAST_METRICS
            }
        problems.append(run["problem"])
        per_problem.append(rows)
    clusters = np.array([source_id(p) for p in problems])
    sources, counts = np.unique(clusters, return_counts=True)
    out: dict[str, Any] = {
        "budget": budget, "problems": len(problems), "sources": int(len(sources)),
        "singleton_sources": int((counts == 1).sum()), "draws": draws, "contrasts": [],
    }  # fmt: skip
    if len(sources) < MIN_SOURCES:
        out["insufficient"] = f"fewer than {MIN_SOURCES} independent sources"
        return out
    for pi in prevalences:
        for metric in CONTRAST_METRICS:
            values = np.array([row[pi][metric] for row in per_problem])
            out["contrasts"].append(
                {"prevalence": pi, "metric": metric}
                | bootstrap(values, clusters, by_cluster=True, draws=draws)
            )
    adjusted = holm([c["p_two_sided"] for c in out["contrasts"]])
    for item, value in zip(out["contrasts"], adjusted, strict=True):
        item["holm_p"] = value
    return out


def x_contrasts__mutmut_12(
    runs: list[dict[str, Any]],
    budget: float = 0.02,
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Change of the fixed threshold's behaviour from the observed prevalence to ``pi``.

    Per problem, the metrics of the threshold at ``pi`` minus its metrics at the problem's own
    held-out prevalence (the observed cell), averaged over the fits of all detectors and seeds
    that share the data. The independent unit is the original source, resampled as a whole; a
    contrast needs at least ``MIN_SOURCES`` sources. Holm adjusts over prevalence-metric pairs.
    """
    key = str(budget)
    problems, per_problem = [], []
    for run in runs:
        cells = [
            c
            for seeds in run["runs"].values()
            for s in seeds
            if key in s.get({}) and "infeasible" not in s["budgets"][key]
            for c in [s["budgets"][key]]
        ]
        if not cells:
            continue
        rows = {}
        for pi in prevalences:
            observed = [
                shifted(c, (c["tp"] + c["fn"]) / (c["tp"] + c["fn"] + c["fp"] + c["tn"]))
                for c in cells
            ]
            moved = [shifted(c, pi) for c in cells]
            rows[pi] = {
                m: float(np.mean([a[m] - b[m] for a, b in zip(moved, observed, strict=True)]))
                for m in CONTRAST_METRICS
            }
        problems.append(run["problem"])
        per_problem.append(rows)
    clusters = np.array([source_id(p) for p in problems])
    sources, counts = np.unique(clusters, return_counts=True)
    out: dict[str, Any] = {
        "budget": budget, "problems": len(problems), "sources": int(len(sources)),
        "singleton_sources": int((counts == 1).sum()), "draws": draws, "contrasts": [],
    }  # fmt: skip
    if len(sources) < MIN_SOURCES:
        out["insufficient"] = f"fewer than {MIN_SOURCES} independent sources"
        return out
    for pi in prevalences:
        for metric in CONTRAST_METRICS:
            values = np.array([row[pi][metric] for row in per_problem])
            out["contrasts"].append(
                {"prevalence": pi, "metric": metric}
                | bootstrap(values, clusters, by_cluster=True, draws=draws)
            )
    adjusted = holm([c["p_two_sided"] for c in out["contrasts"]])
    for item, value in zip(out["contrasts"], adjusted, strict=True):
        item["holm_p"] = value
    return out


def x_contrasts__mutmut_13(
    runs: list[dict[str, Any]],
    budget: float = 0.02,
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Change of the fixed threshold's behaviour from the observed prevalence to ``pi``.

    Per problem, the metrics of the threshold at ``pi`` minus its metrics at the problem's own
    held-out prevalence (the observed cell), averaged over the fits of all detectors and seeds
    that share the data. The independent unit is the original source, resampled as a whole; a
    contrast needs at least ``MIN_SOURCES`` sources. Holm adjusts over prevalence-metric pairs.
    """
    key = str(budget)
    problems, per_problem = [], []
    for run in runs:
        cells = [
            c
            for seeds in run["runs"].values()
            for s in seeds
            if key in s.get("budgets", ) and "infeasible" not in s["budgets"][key]
            for c in [s["budgets"][key]]
        ]
        if not cells:
            continue
        rows = {}
        for pi in prevalences:
            observed = [
                shifted(c, (c["tp"] + c["fn"]) / (c["tp"] + c["fn"] + c["fp"] + c["tn"]))
                for c in cells
            ]
            moved = [shifted(c, pi) for c in cells]
            rows[pi] = {
                m: float(np.mean([a[m] - b[m] for a, b in zip(moved, observed, strict=True)]))
                for m in CONTRAST_METRICS
            }
        problems.append(run["problem"])
        per_problem.append(rows)
    clusters = np.array([source_id(p) for p in problems])
    sources, counts = np.unique(clusters, return_counts=True)
    out: dict[str, Any] = {
        "budget": budget, "problems": len(problems), "sources": int(len(sources)),
        "singleton_sources": int((counts == 1).sum()), "draws": draws, "contrasts": [],
    }  # fmt: skip
    if len(sources) < MIN_SOURCES:
        out["insufficient"] = f"fewer than {MIN_SOURCES} independent sources"
        return out
    for pi in prevalences:
        for metric in CONTRAST_METRICS:
            values = np.array([row[pi][metric] for row in per_problem])
            out["contrasts"].append(
                {"prevalence": pi, "metric": metric}
                | bootstrap(values, clusters, by_cluster=True, draws=draws)
            )
    adjusted = holm([c["p_two_sided"] for c in out["contrasts"]])
    for item, value in zip(out["contrasts"], adjusted, strict=True):
        item["holm_p"] = value
    return out


def x_contrasts__mutmut_14(
    runs: list[dict[str, Any]],
    budget: float = 0.02,
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Change of the fixed threshold's behaviour from the observed prevalence to ``pi``.

    Per problem, the metrics of the threshold at ``pi`` minus its metrics at the problem's own
    held-out prevalence (the observed cell), averaged over the fits of all detectors and seeds
    that share the data. The independent unit is the original source, resampled as a whole; a
    contrast needs at least ``MIN_SOURCES`` sources. Holm adjusts over prevalence-metric pairs.
    """
    key = str(budget)
    problems, per_problem = [], []
    for run in runs:
        cells = [
            c
            for seeds in run["runs"].values()
            for s in seeds
            if key in s.get("XXbudgetsXX", {}) and "infeasible" not in s["budgets"][key]
            for c in [s["budgets"][key]]
        ]
        if not cells:
            continue
        rows = {}
        for pi in prevalences:
            observed = [
                shifted(c, (c["tp"] + c["fn"]) / (c["tp"] + c["fn"] + c["fp"] + c["tn"]))
                for c in cells
            ]
            moved = [shifted(c, pi) for c in cells]
            rows[pi] = {
                m: float(np.mean([a[m] - b[m] for a, b in zip(moved, observed, strict=True)]))
                for m in CONTRAST_METRICS
            }
        problems.append(run["problem"])
        per_problem.append(rows)
    clusters = np.array([source_id(p) for p in problems])
    sources, counts = np.unique(clusters, return_counts=True)
    out: dict[str, Any] = {
        "budget": budget, "problems": len(problems), "sources": int(len(sources)),
        "singleton_sources": int((counts == 1).sum()), "draws": draws, "contrasts": [],
    }  # fmt: skip
    if len(sources) < MIN_SOURCES:
        out["insufficient"] = f"fewer than {MIN_SOURCES} independent sources"
        return out
    for pi in prevalences:
        for metric in CONTRAST_METRICS:
            values = np.array([row[pi][metric] for row in per_problem])
            out["contrasts"].append(
                {"prevalence": pi, "metric": metric}
                | bootstrap(values, clusters, by_cluster=True, draws=draws)
            )
    adjusted = holm([c["p_two_sided"] for c in out["contrasts"]])
    for item, value in zip(out["contrasts"], adjusted, strict=True):
        item["holm_p"] = value
    return out


def x_contrasts__mutmut_15(
    runs: list[dict[str, Any]],
    budget: float = 0.02,
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Change of the fixed threshold's behaviour from the observed prevalence to ``pi``.

    Per problem, the metrics of the threshold at ``pi`` minus its metrics at the problem's own
    held-out prevalence (the observed cell), averaged over the fits of all detectors and seeds
    that share the data. The independent unit is the original source, resampled as a whole; a
    contrast needs at least ``MIN_SOURCES`` sources. Holm adjusts over prevalence-metric pairs.
    """
    key = str(budget)
    problems, per_problem = [], []
    for run in runs:
        cells = [
            c
            for seeds in run["runs"].values()
            for s in seeds
            if key in s.get("BUDGETS", {}) and "infeasible" not in s["budgets"][key]
            for c in [s["budgets"][key]]
        ]
        if not cells:
            continue
        rows = {}
        for pi in prevalences:
            observed = [
                shifted(c, (c["tp"] + c["fn"]) / (c["tp"] + c["fn"] + c["fp"] + c["tn"]))
                for c in cells
            ]
            moved = [shifted(c, pi) for c in cells]
            rows[pi] = {
                m: float(np.mean([a[m] - b[m] for a, b in zip(moved, observed, strict=True)]))
                for m in CONTRAST_METRICS
            }
        problems.append(run["problem"])
        per_problem.append(rows)
    clusters = np.array([source_id(p) for p in problems])
    sources, counts = np.unique(clusters, return_counts=True)
    out: dict[str, Any] = {
        "budget": budget, "problems": len(problems), "sources": int(len(sources)),
        "singleton_sources": int((counts == 1).sum()), "draws": draws, "contrasts": [],
    }  # fmt: skip
    if len(sources) < MIN_SOURCES:
        out["insufficient"] = f"fewer than {MIN_SOURCES} independent sources"
        return out
    for pi in prevalences:
        for metric in CONTRAST_METRICS:
            values = np.array([row[pi][metric] for row in per_problem])
            out["contrasts"].append(
                {"prevalence": pi, "metric": metric}
                | bootstrap(values, clusters, by_cluster=True, draws=draws)
            )
    adjusted = holm([c["p_two_sided"] for c in out["contrasts"]])
    for item, value in zip(out["contrasts"], adjusted, strict=True):
        item["holm_p"] = value
    return out


def x_contrasts__mutmut_16(
    runs: list[dict[str, Any]],
    budget: float = 0.02,
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Change of the fixed threshold's behaviour from the observed prevalence to ``pi``.

    Per problem, the metrics of the threshold at ``pi`` minus its metrics at the problem's own
    held-out prevalence (the observed cell), averaged over the fits of all detectors and seeds
    that share the data. The independent unit is the original source, resampled as a whole; a
    contrast needs at least ``MIN_SOURCES`` sources. Holm adjusts over prevalence-metric pairs.
    """
    key = str(budget)
    problems, per_problem = [], []
    for run in runs:
        cells = [
            c
            for seeds in run["runs"].values()
            for s in seeds
            if key in s.get("budgets", {}) and "XXinfeasibleXX" not in s["budgets"][key]
            for c in [s["budgets"][key]]
        ]
        if not cells:
            continue
        rows = {}
        for pi in prevalences:
            observed = [
                shifted(c, (c["tp"] + c["fn"]) / (c["tp"] + c["fn"] + c["fp"] + c["tn"]))
                for c in cells
            ]
            moved = [shifted(c, pi) for c in cells]
            rows[pi] = {
                m: float(np.mean([a[m] - b[m] for a, b in zip(moved, observed, strict=True)]))
                for m in CONTRAST_METRICS
            }
        problems.append(run["problem"])
        per_problem.append(rows)
    clusters = np.array([source_id(p) for p in problems])
    sources, counts = np.unique(clusters, return_counts=True)
    out: dict[str, Any] = {
        "budget": budget, "problems": len(problems), "sources": int(len(sources)),
        "singleton_sources": int((counts == 1).sum()), "draws": draws, "contrasts": [],
    }  # fmt: skip
    if len(sources) < MIN_SOURCES:
        out["insufficient"] = f"fewer than {MIN_SOURCES} independent sources"
        return out
    for pi in prevalences:
        for metric in CONTRAST_METRICS:
            values = np.array([row[pi][metric] for row in per_problem])
            out["contrasts"].append(
                {"prevalence": pi, "metric": metric}
                | bootstrap(values, clusters, by_cluster=True, draws=draws)
            )
    adjusted = holm([c["p_two_sided"] for c in out["contrasts"]])
    for item, value in zip(out["contrasts"], adjusted, strict=True):
        item["holm_p"] = value
    return out


def x_contrasts__mutmut_17(
    runs: list[dict[str, Any]],
    budget: float = 0.02,
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Change of the fixed threshold's behaviour from the observed prevalence to ``pi``.

    Per problem, the metrics of the threshold at ``pi`` minus its metrics at the problem's own
    held-out prevalence (the observed cell), averaged over the fits of all detectors and seeds
    that share the data. The independent unit is the original source, resampled as a whole; a
    contrast needs at least ``MIN_SOURCES`` sources. Holm adjusts over prevalence-metric pairs.
    """
    key = str(budget)
    problems, per_problem = [], []
    for run in runs:
        cells = [
            c
            for seeds in run["runs"].values()
            for s in seeds
            if key in s.get("budgets", {}) and "INFEASIBLE" not in s["budgets"][key]
            for c in [s["budgets"][key]]
        ]
        if not cells:
            continue
        rows = {}
        for pi in prevalences:
            observed = [
                shifted(c, (c["tp"] + c["fn"]) / (c["tp"] + c["fn"] + c["fp"] + c["tn"]))
                for c in cells
            ]
            moved = [shifted(c, pi) for c in cells]
            rows[pi] = {
                m: float(np.mean([a[m] - b[m] for a, b in zip(moved, observed, strict=True)]))
                for m in CONTRAST_METRICS
            }
        problems.append(run["problem"])
        per_problem.append(rows)
    clusters = np.array([source_id(p) for p in problems])
    sources, counts = np.unique(clusters, return_counts=True)
    out: dict[str, Any] = {
        "budget": budget, "problems": len(problems), "sources": int(len(sources)),
        "singleton_sources": int((counts == 1).sum()), "draws": draws, "contrasts": [],
    }  # fmt: skip
    if len(sources) < MIN_SOURCES:
        out["insufficient"] = f"fewer than {MIN_SOURCES} independent sources"
        return out
    for pi in prevalences:
        for metric in CONTRAST_METRICS:
            values = np.array([row[pi][metric] for row in per_problem])
            out["contrasts"].append(
                {"prevalence": pi, "metric": metric}
                | bootstrap(values, clusters, by_cluster=True, draws=draws)
            )
    adjusted = holm([c["p_two_sided"] for c in out["contrasts"]])
    for item, value in zip(out["contrasts"], adjusted, strict=True):
        item["holm_p"] = value
    return out


def x_contrasts__mutmut_18(
    runs: list[dict[str, Any]],
    budget: float = 0.02,
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Change of the fixed threshold's behaviour from the observed prevalence to ``pi``.

    Per problem, the metrics of the threshold at ``pi`` minus its metrics at the problem's own
    held-out prevalence (the observed cell), averaged over the fits of all detectors and seeds
    that share the data. The independent unit is the original source, resampled as a whole; a
    contrast needs at least ``MIN_SOURCES`` sources. Holm adjusts over prevalence-metric pairs.
    """
    key = str(budget)
    problems, per_problem = [], []
    for run in runs:
        cells = [
            c
            for seeds in run["runs"].values()
            for s in seeds
            if key in s.get("budgets", {}) and "infeasible" in s["budgets"][key]
            for c in [s["budgets"][key]]
        ]
        if not cells:
            continue
        rows = {}
        for pi in prevalences:
            observed = [
                shifted(c, (c["tp"] + c["fn"]) / (c["tp"] + c["fn"] + c["fp"] + c["tn"]))
                for c in cells
            ]
            moved = [shifted(c, pi) for c in cells]
            rows[pi] = {
                m: float(np.mean([a[m] - b[m] for a, b in zip(moved, observed, strict=True)]))
                for m in CONTRAST_METRICS
            }
        problems.append(run["problem"])
        per_problem.append(rows)
    clusters = np.array([source_id(p) for p in problems])
    sources, counts = np.unique(clusters, return_counts=True)
    out: dict[str, Any] = {
        "budget": budget, "problems": len(problems), "sources": int(len(sources)),
        "singleton_sources": int((counts == 1).sum()), "draws": draws, "contrasts": [],
    }  # fmt: skip
    if len(sources) < MIN_SOURCES:
        out["insufficient"] = f"fewer than {MIN_SOURCES} independent sources"
        return out
    for pi in prevalences:
        for metric in CONTRAST_METRICS:
            values = np.array([row[pi][metric] for row in per_problem])
            out["contrasts"].append(
                {"prevalence": pi, "metric": metric}
                | bootstrap(values, clusters, by_cluster=True, draws=draws)
            )
    adjusted = holm([c["p_two_sided"] for c in out["contrasts"]])
    for item, value in zip(out["contrasts"], adjusted, strict=True):
        item["holm_p"] = value
    return out


def x_contrasts__mutmut_19(
    runs: list[dict[str, Any]],
    budget: float = 0.02,
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Change of the fixed threshold's behaviour from the observed prevalence to ``pi``.

    Per problem, the metrics of the threshold at ``pi`` minus its metrics at the problem's own
    held-out prevalence (the observed cell), averaged over the fits of all detectors and seeds
    that share the data. The independent unit is the original source, resampled as a whole; a
    contrast needs at least ``MIN_SOURCES`` sources. Holm adjusts over prevalence-metric pairs.
    """
    key = str(budget)
    problems, per_problem = [], []
    for run in runs:
        cells = [
            c
            for seeds in run["runs"].values()
            for s in seeds
            if key in s.get("budgets", {}) and "infeasible" not in s["XXbudgetsXX"][key]
            for c in [s["budgets"][key]]
        ]
        if not cells:
            continue
        rows = {}
        for pi in prevalences:
            observed = [
                shifted(c, (c["tp"] + c["fn"]) / (c["tp"] + c["fn"] + c["fp"] + c["tn"]))
                for c in cells
            ]
            moved = [shifted(c, pi) for c in cells]
            rows[pi] = {
                m: float(np.mean([a[m] - b[m] for a, b in zip(moved, observed, strict=True)]))
                for m in CONTRAST_METRICS
            }
        problems.append(run["problem"])
        per_problem.append(rows)
    clusters = np.array([source_id(p) for p in problems])
    sources, counts = np.unique(clusters, return_counts=True)
    out: dict[str, Any] = {
        "budget": budget, "problems": len(problems), "sources": int(len(sources)),
        "singleton_sources": int((counts == 1).sum()), "draws": draws, "contrasts": [],
    }  # fmt: skip
    if len(sources) < MIN_SOURCES:
        out["insufficient"] = f"fewer than {MIN_SOURCES} independent sources"
        return out
    for pi in prevalences:
        for metric in CONTRAST_METRICS:
            values = np.array([row[pi][metric] for row in per_problem])
            out["contrasts"].append(
                {"prevalence": pi, "metric": metric}
                | bootstrap(values, clusters, by_cluster=True, draws=draws)
            )
    adjusted = holm([c["p_two_sided"] for c in out["contrasts"]])
    for item, value in zip(out["contrasts"], adjusted, strict=True):
        item["holm_p"] = value
    return out


def x_contrasts__mutmut_20(
    runs: list[dict[str, Any]],
    budget: float = 0.02,
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Change of the fixed threshold's behaviour from the observed prevalence to ``pi``.

    Per problem, the metrics of the threshold at ``pi`` minus its metrics at the problem's own
    held-out prevalence (the observed cell), averaged over the fits of all detectors and seeds
    that share the data. The independent unit is the original source, resampled as a whole; a
    contrast needs at least ``MIN_SOURCES`` sources. Holm adjusts over prevalence-metric pairs.
    """
    key = str(budget)
    problems, per_problem = [], []
    for run in runs:
        cells = [
            c
            for seeds in run["runs"].values()
            for s in seeds
            if key in s.get("budgets", {}) and "infeasible" not in s["BUDGETS"][key]
            for c in [s["budgets"][key]]
        ]
        if not cells:
            continue
        rows = {}
        for pi in prevalences:
            observed = [
                shifted(c, (c["tp"] + c["fn"]) / (c["tp"] + c["fn"] + c["fp"] + c["tn"]))
                for c in cells
            ]
            moved = [shifted(c, pi) for c in cells]
            rows[pi] = {
                m: float(np.mean([a[m] - b[m] for a, b in zip(moved, observed, strict=True)]))
                for m in CONTRAST_METRICS
            }
        problems.append(run["problem"])
        per_problem.append(rows)
    clusters = np.array([source_id(p) for p in problems])
    sources, counts = np.unique(clusters, return_counts=True)
    out: dict[str, Any] = {
        "budget": budget, "problems": len(problems), "sources": int(len(sources)),
        "singleton_sources": int((counts == 1).sum()), "draws": draws, "contrasts": [],
    }  # fmt: skip
    if len(sources) < MIN_SOURCES:
        out["insufficient"] = f"fewer than {MIN_SOURCES} independent sources"
        return out
    for pi in prevalences:
        for metric in CONTRAST_METRICS:
            values = np.array([row[pi][metric] for row in per_problem])
            out["contrasts"].append(
                {"prevalence": pi, "metric": metric}
                | bootstrap(values, clusters, by_cluster=True, draws=draws)
            )
    adjusted = holm([c["p_two_sided"] for c in out["contrasts"]])
    for item, value in zip(out["contrasts"], adjusted, strict=True):
        item["holm_p"] = value
    return out


def x_contrasts__mutmut_21(
    runs: list[dict[str, Any]],
    budget: float = 0.02,
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Change of the fixed threshold's behaviour from the observed prevalence to ``pi``.

    Per problem, the metrics of the threshold at ``pi`` minus its metrics at the problem's own
    held-out prevalence (the observed cell), averaged over the fits of all detectors and seeds
    that share the data. The independent unit is the original source, resampled as a whole; a
    contrast needs at least ``MIN_SOURCES`` sources. Holm adjusts over prevalence-metric pairs.
    """
    key = str(budget)
    problems, per_problem = [], []
    for run in runs:
        cells = [
            c
            for seeds in run["runs"].values()
            for s in seeds
            if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
            for c in [s["XXbudgetsXX"][key]]
        ]
        if not cells:
            continue
        rows = {}
        for pi in prevalences:
            observed = [
                shifted(c, (c["tp"] + c["fn"]) / (c["tp"] + c["fn"] + c["fp"] + c["tn"]))
                for c in cells
            ]
            moved = [shifted(c, pi) for c in cells]
            rows[pi] = {
                m: float(np.mean([a[m] - b[m] for a, b in zip(moved, observed, strict=True)]))
                for m in CONTRAST_METRICS
            }
        problems.append(run["problem"])
        per_problem.append(rows)
    clusters = np.array([source_id(p) for p in problems])
    sources, counts = np.unique(clusters, return_counts=True)
    out: dict[str, Any] = {
        "budget": budget, "problems": len(problems), "sources": int(len(sources)),
        "singleton_sources": int((counts == 1).sum()), "draws": draws, "contrasts": [],
    }  # fmt: skip
    if len(sources) < MIN_SOURCES:
        out["insufficient"] = f"fewer than {MIN_SOURCES} independent sources"
        return out
    for pi in prevalences:
        for metric in CONTRAST_METRICS:
            values = np.array([row[pi][metric] for row in per_problem])
            out["contrasts"].append(
                {"prevalence": pi, "metric": metric}
                | bootstrap(values, clusters, by_cluster=True, draws=draws)
            )
    adjusted = holm([c["p_two_sided"] for c in out["contrasts"]])
    for item, value in zip(out["contrasts"], adjusted, strict=True):
        item["holm_p"] = value
    return out


def x_contrasts__mutmut_22(
    runs: list[dict[str, Any]],
    budget: float = 0.02,
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Change of the fixed threshold's behaviour from the observed prevalence to ``pi``.

    Per problem, the metrics of the threshold at ``pi`` minus its metrics at the problem's own
    held-out prevalence (the observed cell), averaged over the fits of all detectors and seeds
    that share the data. The independent unit is the original source, resampled as a whole; a
    contrast needs at least ``MIN_SOURCES`` sources. Holm adjusts over prevalence-metric pairs.
    """
    key = str(budget)
    problems, per_problem = [], []
    for run in runs:
        cells = [
            c
            for seeds in run["runs"].values()
            for s in seeds
            if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
            for c in [s["BUDGETS"][key]]
        ]
        if not cells:
            continue
        rows = {}
        for pi in prevalences:
            observed = [
                shifted(c, (c["tp"] + c["fn"]) / (c["tp"] + c["fn"] + c["fp"] + c["tn"]))
                for c in cells
            ]
            moved = [shifted(c, pi) for c in cells]
            rows[pi] = {
                m: float(np.mean([a[m] - b[m] for a, b in zip(moved, observed, strict=True)]))
                for m in CONTRAST_METRICS
            }
        problems.append(run["problem"])
        per_problem.append(rows)
    clusters = np.array([source_id(p) for p in problems])
    sources, counts = np.unique(clusters, return_counts=True)
    out: dict[str, Any] = {
        "budget": budget, "problems": len(problems), "sources": int(len(sources)),
        "singleton_sources": int((counts == 1).sum()), "draws": draws, "contrasts": [],
    }  # fmt: skip
    if len(sources) < MIN_SOURCES:
        out["insufficient"] = f"fewer than {MIN_SOURCES} independent sources"
        return out
    for pi in prevalences:
        for metric in CONTRAST_METRICS:
            values = np.array([row[pi][metric] for row in per_problem])
            out["contrasts"].append(
                {"prevalence": pi, "metric": metric}
                | bootstrap(values, clusters, by_cluster=True, draws=draws)
            )
    adjusted = holm([c["p_two_sided"] for c in out["contrasts"]])
    for item, value in zip(out["contrasts"], adjusted, strict=True):
        item["holm_p"] = value
    return out


def x_contrasts__mutmut_23(
    runs: list[dict[str, Any]],
    budget: float = 0.02,
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Change of the fixed threshold's behaviour from the observed prevalence to ``pi``.

    Per problem, the metrics of the threshold at ``pi`` minus its metrics at the problem's own
    held-out prevalence (the observed cell), averaged over the fits of all detectors and seeds
    that share the data. The independent unit is the original source, resampled as a whole; a
    contrast needs at least ``MIN_SOURCES`` sources. Holm adjusts over prevalence-metric pairs.
    """
    key = str(budget)
    problems, per_problem = [], []
    for run in runs:
        cells = [
            c
            for seeds in run["runs"].values()
            for s in seeds
            if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
            for c in [s["budgets"][key]]
        ]
        if cells:
            continue
        rows = {}
        for pi in prevalences:
            observed = [
                shifted(c, (c["tp"] + c["fn"]) / (c["tp"] + c["fn"] + c["fp"] + c["tn"]))
                for c in cells
            ]
            moved = [shifted(c, pi) for c in cells]
            rows[pi] = {
                m: float(np.mean([a[m] - b[m] for a, b in zip(moved, observed, strict=True)]))
                for m in CONTRAST_METRICS
            }
        problems.append(run["problem"])
        per_problem.append(rows)
    clusters = np.array([source_id(p) for p in problems])
    sources, counts = np.unique(clusters, return_counts=True)
    out: dict[str, Any] = {
        "budget": budget, "problems": len(problems), "sources": int(len(sources)),
        "singleton_sources": int((counts == 1).sum()), "draws": draws, "contrasts": [],
    }  # fmt: skip
    if len(sources) < MIN_SOURCES:
        out["insufficient"] = f"fewer than {MIN_SOURCES} independent sources"
        return out
    for pi in prevalences:
        for metric in CONTRAST_METRICS:
            values = np.array([row[pi][metric] for row in per_problem])
            out["contrasts"].append(
                {"prevalence": pi, "metric": metric}
                | bootstrap(values, clusters, by_cluster=True, draws=draws)
            )
    adjusted = holm([c["p_two_sided"] for c in out["contrasts"]])
    for item, value in zip(out["contrasts"], adjusted, strict=True):
        item["holm_p"] = value
    return out


def x_contrasts__mutmut_24(
    runs: list[dict[str, Any]],
    budget: float = 0.02,
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Change of the fixed threshold's behaviour from the observed prevalence to ``pi``.

    Per problem, the metrics of the threshold at ``pi`` minus its metrics at the problem's own
    held-out prevalence (the observed cell), averaged over the fits of all detectors and seeds
    that share the data. The independent unit is the original source, resampled as a whole; a
    contrast needs at least ``MIN_SOURCES`` sources. Holm adjusts over prevalence-metric pairs.
    """
    key = str(budget)
    problems, per_problem = [], []
    for run in runs:
        cells = [
            c
            for seeds in run["runs"].values()
            for s in seeds
            if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
            for c in [s["budgets"][key]]
        ]
        if not cells:
            break
        rows = {}
        for pi in prevalences:
            observed = [
                shifted(c, (c["tp"] + c["fn"]) / (c["tp"] + c["fn"] + c["fp"] + c["tn"]))
                for c in cells
            ]
            moved = [shifted(c, pi) for c in cells]
            rows[pi] = {
                m: float(np.mean([a[m] - b[m] for a, b in zip(moved, observed, strict=True)]))
                for m in CONTRAST_METRICS
            }
        problems.append(run["problem"])
        per_problem.append(rows)
    clusters = np.array([source_id(p) for p in problems])
    sources, counts = np.unique(clusters, return_counts=True)
    out: dict[str, Any] = {
        "budget": budget, "problems": len(problems), "sources": int(len(sources)),
        "singleton_sources": int((counts == 1).sum()), "draws": draws, "contrasts": [],
    }  # fmt: skip
    if len(sources) < MIN_SOURCES:
        out["insufficient"] = f"fewer than {MIN_SOURCES} independent sources"
        return out
    for pi in prevalences:
        for metric in CONTRAST_METRICS:
            values = np.array([row[pi][metric] for row in per_problem])
            out["contrasts"].append(
                {"prevalence": pi, "metric": metric}
                | bootstrap(values, clusters, by_cluster=True, draws=draws)
            )
    adjusted = holm([c["p_two_sided"] for c in out["contrasts"]])
    for item, value in zip(out["contrasts"], adjusted, strict=True):
        item["holm_p"] = value
    return out


def x_contrasts__mutmut_25(
    runs: list[dict[str, Any]],
    budget: float = 0.02,
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Change of the fixed threshold's behaviour from the observed prevalence to ``pi``.

    Per problem, the metrics of the threshold at ``pi`` minus its metrics at the problem's own
    held-out prevalence (the observed cell), averaged over the fits of all detectors and seeds
    that share the data. The independent unit is the original source, resampled as a whole; a
    contrast needs at least ``MIN_SOURCES`` sources. Holm adjusts over prevalence-metric pairs.
    """
    key = str(budget)
    problems, per_problem = [], []
    for run in runs:
        cells = [
            c
            for seeds in run["runs"].values()
            for s in seeds
            if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
            for c in [s["budgets"][key]]
        ]
        if not cells:
            continue
        rows = None
        for pi in prevalences:
            observed = [
                shifted(c, (c["tp"] + c["fn"]) / (c["tp"] + c["fn"] + c["fp"] + c["tn"]))
                for c in cells
            ]
            moved = [shifted(c, pi) for c in cells]
            rows[pi] = {
                m: float(np.mean([a[m] - b[m] for a, b in zip(moved, observed, strict=True)]))
                for m in CONTRAST_METRICS
            }
        problems.append(run["problem"])
        per_problem.append(rows)
    clusters = np.array([source_id(p) for p in problems])
    sources, counts = np.unique(clusters, return_counts=True)
    out: dict[str, Any] = {
        "budget": budget, "problems": len(problems), "sources": int(len(sources)),
        "singleton_sources": int((counts == 1).sum()), "draws": draws, "contrasts": [],
    }  # fmt: skip
    if len(sources) < MIN_SOURCES:
        out["insufficient"] = f"fewer than {MIN_SOURCES} independent sources"
        return out
    for pi in prevalences:
        for metric in CONTRAST_METRICS:
            values = np.array([row[pi][metric] for row in per_problem])
            out["contrasts"].append(
                {"prevalence": pi, "metric": metric}
                | bootstrap(values, clusters, by_cluster=True, draws=draws)
            )
    adjusted = holm([c["p_two_sided"] for c in out["contrasts"]])
    for item, value in zip(out["contrasts"], adjusted, strict=True):
        item["holm_p"] = value
    return out


def x_contrasts__mutmut_26(
    runs: list[dict[str, Any]],
    budget: float = 0.02,
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Change of the fixed threshold's behaviour from the observed prevalence to ``pi``.

    Per problem, the metrics of the threshold at ``pi`` minus its metrics at the problem's own
    held-out prevalence (the observed cell), averaged over the fits of all detectors and seeds
    that share the data. The independent unit is the original source, resampled as a whole; a
    contrast needs at least ``MIN_SOURCES`` sources. Holm adjusts over prevalence-metric pairs.
    """
    key = str(budget)
    problems, per_problem = [], []
    for run in runs:
        cells = [
            c
            for seeds in run["runs"].values()
            for s in seeds
            if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
            for c in [s["budgets"][key]]
        ]
        if not cells:
            continue
        rows = {}
        for pi in prevalences:
            observed = None
            moved = [shifted(c, pi) for c in cells]
            rows[pi] = {
                m: float(np.mean([a[m] - b[m] for a, b in zip(moved, observed, strict=True)]))
                for m in CONTRAST_METRICS
            }
        problems.append(run["problem"])
        per_problem.append(rows)
    clusters = np.array([source_id(p) for p in problems])
    sources, counts = np.unique(clusters, return_counts=True)
    out: dict[str, Any] = {
        "budget": budget, "problems": len(problems), "sources": int(len(sources)),
        "singleton_sources": int((counts == 1).sum()), "draws": draws, "contrasts": [],
    }  # fmt: skip
    if len(sources) < MIN_SOURCES:
        out["insufficient"] = f"fewer than {MIN_SOURCES} independent sources"
        return out
    for pi in prevalences:
        for metric in CONTRAST_METRICS:
            values = np.array([row[pi][metric] for row in per_problem])
            out["contrasts"].append(
                {"prevalence": pi, "metric": metric}
                | bootstrap(values, clusters, by_cluster=True, draws=draws)
            )
    adjusted = holm([c["p_two_sided"] for c in out["contrasts"]])
    for item, value in zip(out["contrasts"], adjusted, strict=True):
        item["holm_p"] = value
    return out


def x_contrasts__mutmut_27(
    runs: list[dict[str, Any]],
    budget: float = 0.02,
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Change of the fixed threshold's behaviour from the observed prevalence to ``pi``.

    Per problem, the metrics of the threshold at ``pi`` minus its metrics at the problem's own
    held-out prevalence (the observed cell), averaged over the fits of all detectors and seeds
    that share the data. The independent unit is the original source, resampled as a whole; a
    contrast needs at least ``MIN_SOURCES`` sources. Holm adjusts over prevalence-metric pairs.
    """
    key = str(budget)
    problems, per_problem = [], []
    for run in runs:
        cells = [
            c
            for seeds in run["runs"].values()
            for s in seeds
            if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
            for c in [s["budgets"][key]]
        ]
        if not cells:
            continue
        rows = {}
        for pi in prevalences:
            observed = [
                shifted(None, (c["tp"] + c["fn"]) / (c["tp"] + c["fn"] + c["fp"] + c["tn"]))
                for c in cells
            ]
            moved = [shifted(c, pi) for c in cells]
            rows[pi] = {
                m: float(np.mean([a[m] - b[m] for a, b in zip(moved, observed, strict=True)]))
                for m in CONTRAST_METRICS
            }
        problems.append(run["problem"])
        per_problem.append(rows)
    clusters = np.array([source_id(p) for p in problems])
    sources, counts = np.unique(clusters, return_counts=True)
    out: dict[str, Any] = {
        "budget": budget, "problems": len(problems), "sources": int(len(sources)),
        "singleton_sources": int((counts == 1).sum()), "draws": draws, "contrasts": [],
    }  # fmt: skip
    if len(sources) < MIN_SOURCES:
        out["insufficient"] = f"fewer than {MIN_SOURCES} independent sources"
        return out
    for pi in prevalences:
        for metric in CONTRAST_METRICS:
            values = np.array([row[pi][metric] for row in per_problem])
            out["contrasts"].append(
                {"prevalence": pi, "metric": metric}
                | bootstrap(values, clusters, by_cluster=True, draws=draws)
            )
    adjusted = holm([c["p_two_sided"] for c in out["contrasts"]])
    for item, value in zip(out["contrasts"], adjusted, strict=True):
        item["holm_p"] = value
    return out


def x_contrasts__mutmut_28(
    runs: list[dict[str, Any]],
    budget: float = 0.02,
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Change of the fixed threshold's behaviour from the observed prevalence to ``pi``.

    Per problem, the metrics of the threshold at ``pi`` minus its metrics at the problem's own
    held-out prevalence (the observed cell), averaged over the fits of all detectors and seeds
    that share the data. The independent unit is the original source, resampled as a whole; a
    contrast needs at least ``MIN_SOURCES`` sources. Holm adjusts over prevalence-metric pairs.
    """
    key = str(budget)
    problems, per_problem = [], []
    for run in runs:
        cells = [
            c
            for seeds in run["runs"].values()
            for s in seeds
            if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
            for c in [s["budgets"][key]]
        ]
        if not cells:
            continue
        rows = {}
        for pi in prevalences:
            observed = [
                shifted(c, None)
                for c in cells
            ]
            moved = [shifted(c, pi) for c in cells]
            rows[pi] = {
                m: float(np.mean([a[m] - b[m] for a, b in zip(moved, observed, strict=True)]))
                for m in CONTRAST_METRICS
            }
        problems.append(run["problem"])
        per_problem.append(rows)
    clusters = np.array([source_id(p) for p in problems])
    sources, counts = np.unique(clusters, return_counts=True)
    out: dict[str, Any] = {
        "budget": budget, "problems": len(problems), "sources": int(len(sources)),
        "singleton_sources": int((counts == 1).sum()), "draws": draws, "contrasts": [],
    }  # fmt: skip
    if len(sources) < MIN_SOURCES:
        out["insufficient"] = f"fewer than {MIN_SOURCES} independent sources"
        return out
    for pi in prevalences:
        for metric in CONTRAST_METRICS:
            values = np.array([row[pi][metric] for row in per_problem])
            out["contrasts"].append(
                {"prevalence": pi, "metric": metric}
                | bootstrap(values, clusters, by_cluster=True, draws=draws)
            )
    adjusted = holm([c["p_two_sided"] for c in out["contrasts"]])
    for item, value in zip(out["contrasts"], adjusted, strict=True):
        item["holm_p"] = value
    return out


def x_contrasts__mutmut_29(
    runs: list[dict[str, Any]],
    budget: float = 0.02,
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Change of the fixed threshold's behaviour from the observed prevalence to ``pi``.

    Per problem, the metrics of the threshold at ``pi`` minus its metrics at the problem's own
    held-out prevalence (the observed cell), averaged over the fits of all detectors and seeds
    that share the data. The independent unit is the original source, resampled as a whole; a
    contrast needs at least ``MIN_SOURCES`` sources. Holm adjusts over prevalence-metric pairs.
    """
    key = str(budget)
    problems, per_problem = [], []
    for run in runs:
        cells = [
            c
            for seeds in run["runs"].values()
            for s in seeds
            if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
            for c in [s["budgets"][key]]
        ]
        if not cells:
            continue
        rows = {}
        for pi in prevalences:
            observed = [
                shifted((c["tp"] + c["fn"]) / (c["tp"] + c["fn"] + c["fp"] + c["tn"]))
                for c in cells
            ]
            moved = [shifted(c, pi) for c in cells]
            rows[pi] = {
                m: float(np.mean([a[m] - b[m] for a, b in zip(moved, observed, strict=True)]))
                for m in CONTRAST_METRICS
            }
        problems.append(run["problem"])
        per_problem.append(rows)
    clusters = np.array([source_id(p) for p in problems])
    sources, counts = np.unique(clusters, return_counts=True)
    out: dict[str, Any] = {
        "budget": budget, "problems": len(problems), "sources": int(len(sources)),
        "singleton_sources": int((counts == 1).sum()), "draws": draws, "contrasts": [],
    }  # fmt: skip
    if len(sources) < MIN_SOURCES:
        out["insufficient"] = f"fewer than {MIN_SOURCES} independent sources"
        return out
    for pi in prevalences:
        for metric in CONTRAST_METRICS:
            values = np.array([row[pi][metric] for row in per_problem])
            out["contrasts"].append(
                {"prevalence": pi, "metric": metric}
                | bootstrap(values, clusters, by_cluster=True, draws=draws)
            )
    adjusted = holm([c["p_two_sided"] for c in out["contrasts"]])
    for item, value in zip(out["contrasts"], adjusted, strict=True):
        item["holm_p"] = value
    return out


def x_contrasts__mutmut_30(
    runs: list[dict[str, Any]],
    budget: float = 0.02,
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Change of the fixed threshold's behaviour from the observed prevalence to ``pi``.

    Per problem, the metrics of the threshold at ``pi`` minus its metrics at the problem's own
    held-out prevalence (the observed cell), averaged over the fits of all detectors and seeds
    that share the data. The independent unit is the original source, resampled as a whole; a
    contrast needs at least ``MIN_SOURCES`` sources. Holm adjusts over prevalence-metric pairs.
    """
    key = str(budget)
    problems, per_problem = [], []
    for run in runs:
        cells = [
            c
            for seeds in run["runs"].values()
            for s in seeds
            if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
            for c in [s["budgets"][key]]
        ]
        if not cells:
            continue
        rows = {}
        for pi in prevalences:
            observed = [
                shifted(c, )
                for c in cells
            ]
            moved = [shifted(c, pi) for c in cells]
            rows[pi] = {
                m: float(np.mean([a[m] - b[m] for a, b in zip(moved, observed, strict=True)]))
                for m in CONTRAST_METRICS
            }
        problems.append(run["problem"])
        per_problem.append(rows)
    clusters = np.array([source_id(p) for p in problems])
    sources, counts = np.unique(clusters, return_counts=True)
    out: dict[str, Any] = {
        "budget": budget, "problems": len(problems), "sources": int(len(sources)),
        "singleton_sources": int((counts == 1).sum()), "draws": draws, "contrasts": [],
    }  # fmt: skip
    if len(sources) < MIN_SOURCES:
        out["insufficient"] = f"fewer than {MIN_SOURCES} independent sources"
        return out
    for pi in prevalences:
        for metric in CONTRAST_METRICS:
            values = np.array([row[pi][metric] for row in per_problem])
            out["contrasts"].append(
                {"prevalence": pi, "metric": metric}
                | bootstrap(values, clusters, by_cluster=True, draws=draws)
            )
    adjusted = holm([c["p_two_sided"] for c in out["contrasts"]])
    for item, value in zip(out["contrasts"], adjusted, strict=True):
        item["holm_p"] = value
    return out


def x_contrasts__mutmut_31(
    runs: list[dict[str, Any]],
    budget: float = 0.02,
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Change of the fixed threshold's behaviour from the observed prevalence to ``pi``.

    Per problem, the metrics of the threshold at ``pi`` minus its metrics at the problem's own
    held-out prevalence (the observed cell), averaged over the fits of all detectors and seeds
    that share the data. The independent unit is the original source, resampled as a whole; a
    contrast needs at least ``MIN_SOURCES`` sources. Holm adjusts over prevalence-metric pairs.
    """
    key = str(budget)
    problems, per_problem = [], []
    for run in runs:
        cells = [
            c
            for seeds in run["runs"].values()
            for s in seeds
            if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
            for c in [s["budgets"][key]]
        ]
        if not cells:
            continue
        rows = {}
        for pi in prevalences:
            observed = [
                shifted(c, (c["tp"] + c["fn"]) * (c["tp"] + c["fn"] + c["fp"] + c["tn"]))
                for c in cells
            ]
            moved = [shifted(c, pi) for c in cells]
            rows[pi] = {
                m: float(np.mean([a[m] - b[m] for a, b in zip(moved, observed, strict=True)]))
                for m in CONTRAST_METRICS
            }
        problems.append(run["problem"])
        per_problem.append(rows)
    clusters = np.array([source_id(p) for p in problems])
    sources, counts = np.unique(clusters, return_counts=True)
    out: dict[str, Any] = {
        "budget": budget, "problems": len(problems), "sources": int(len(sources)),
        "singleton_sources": int((counts == 1).sum()), "draws": draws, "contrasts": [],
    }  # fmt: skip
    if len(sources) < MIN_SOURCES:
        out["insufficient"] = f"fewer than {MIN_SOURCES} independent sources"
        return out
    for pi in prevalences:
        for metric in CONTRAST_METRICS:
            values = np.array([row[pi][metric] for row in per_problem])
            out["contrasts"].append(
                {"prevalence": pi, "metric": metric}
                | bootstrap(values, clusters, by_cluster=True, draws=draws)
            )
    adjusted = holm([c["p_two_sided"] for c in out["contrasts"]])
    for item, value in zip(out["contrasts"], adjusted, strict=True):
        item["holm_p"] = value
    return out


def x_contrasts__mutmut_32(
    runs: list[dict[str, Any]],
    budget: float = 0.02,
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Change of the fixed threshold's behaviour from the observed prevalence to ``pi``.

    Per problem, the metrics of the threshold at ``pi`` minus its metrics at the problem's own
    held-out prevalence (the observed cell), averaged over the fits of all detectors and seeds
    that share the data. The independent unit is the original source, resampled as a whole; a
    contrast needs at least ``MIN_SOURCES`` sources. Holm adjusts over prevalence-metric pairs.
    """
    key = str(budget)
    problems, per_problem = [], []
    for run in runs:
        cells = [
            c
            for seeds in run["runs"].values()
            for s in seeds
            if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
            for c in [s["budgets"][key]]
        ]
        if not cells:
            continue
        rows = {}
        for pi in prevalences:
            observed = [
                shifted(c, (c["tp"] - c["fn"]) / (c["tp"] + c["fn"] + c["fp"] + c["tn"]))
                for c in cells
            ]
            moved = [shifted(c, pi) for c in cells]
            rows[pi] = {
                m: float(np.mean([a[m] - b[m] for a, b in zip(moved, observed, strict=True)]))
                for m in CONTRAST_METRICS
            }
        problems.append(run["problem"])
        per_problem.append(rows)
    clusters = np.array([source_id(p) for p in problems])
    sources, counts = np.unique(clusters, return_counts=True)
    out: dict[str, Any] = {
        "budget": budget, "problems": len(problems), "sources": int(len(sources)),
        "singleton_sources": int((counts == 1).sum()), "draws": draws, "contrasts": [],
    }  # fmt: skip
    if len(sources) < MIN_SOURCES:
        out["insufficient"] = f"fewer than {MIN_SOURCES} independent sources"
        return out
    for pi in prevalences:
        for metric in CONTRAST_METRICS:
            values = np.array([row[pi][metric] for row in per_problem])
            out["contrasts"].append(
                {"prevalence": pi, "metric": metric}
                | bootstrap(values, clusters, by_cluster=True, draws=draws)
            )
    adjusted = holm([c["p_two_sided"] for c in out["contrasts"]])
    for item, value in zip(out["contrasts"], adjusted, strict=True):
        item["holm_p"] = value
    return out


def x_contrasts__mutmut_33(
    runs: list[dict[str, Any]],
    budget: float = 0.02,
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Change of the fixed threshold's behaviour from the observed prevalence to ``pi``.

    Per problem, the metrics of the threshold at ``pi`` minus its metrics at the problem's own
    held-out prevalence (the observed cell), averaged over the fits of all detectors and seeds
    that share the data. The independent unit is the original source, resampled as a whole; a
    contrast needs at least ``MIN_SOURCES`` sources. Holm adjusts over prevalence-metric pairs.
    """
    key = str(budget)
    problems, per_problem = [], []
    for run in runs:
        cells = [
            c
            for seeds in run["runs"].values()
            for s in seeds
            if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
            for c in [s["budgets"][key]]
        ]
        if not cells:
            continue
        rows = {}
        for pi in prevalences:
            observed = [
                shifted(c, (c["XXtpXX"] + c["fn"]) / (c["tp"] + c["fn"] + c["fp"] + c["tn"]))
                for c in cells
            ]
            moved = [shifted(c, pi) for c in cells]
            rows[pi] = {
                m: float(np.mean([a[m] - b[m] for a, b in zip(moved, observed, strict=True)]))
                for m in CONTRAST_METRICS
            }
        problems.append(run["problem"])
        per_problem.append(rows)
    clusters = np.array([source_id(p) for p in problems])
    sources, counts = np.unique(clusters, return_counts=True)
    out: dict[str, Any] = {
        "budget": budget, "problems": len(problems), "sources": int(len(sources)),
        "singleton_sources": int((counts == 1).sum()), "draws": draws, "contrasts": [],
    }  # fmt: skip
    if len(sources) < MIN_SOURCES:
        out["insufficient"] = f"fewer than {MIN_SOURCES} independent sources"
        return out
    for pi in prevalences:
        for metric in CONTRAST_METRICS:
            values = np.array([row[pi][metric] for row in per_problem])
            out["contrasts"].append(
                {"prevalence": pi, "metric": metric}
                | bootstrap(values, clusters, by_cluster=True, draws=draws)
            )
    adjusted = holm([c["p_two_sided"] for c in out["contrasts"]])
    for item, value in zip(out["contrasts"], adjusted, strict=True):
        item["holm_p"] = value
    return out


def x_contrasts__mutmut_34(
    runs: list[dict[str, Any]],
    budget: float = 0.02,
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Change of the fixed threshold's behaviour from the observed prevalence to ``pi``.

    Per problem, the metrics of the threshold at ``pi`` minus its metrics at the problem's own
    held-out prevalence (the observed cell), averaged over the fits of all detectors and seeds
    that share the data. The independent unit is the original source, resampled as a whole; a
    contrast needs at least ``MIN_SOURCES`` sources. Holm adjusts over prevalence-metric pairs.
    """
    key = str(budget)
    problems, per_problem = [], []
    for run in runs:
        cells = [
            c
            for seeds in run["runs"].values()
            for s in seeds
            if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
            for c in [s["budgets"][key]]
        ]
        if not cells:
            continue
        rows = {}
        for pi in prevalences:
            observed = [
                shifted(c, (c["TP"] + c["fn"]) / (c["tp"] + c["fn"] + c["fp"] + c["tn"]))
                for c in cells
            ]
            moved = [shifted(c, pi) for c in cells]
            rows[pi] = {
                m: float(np.mean([a[m] - b[m] for a, b in zip(moved, observed, strict=True)]))
                for m in CONTRAST_METRICS
            }
        problems.append(run["problem"])
        per_problem.append(rows)
    clusters = np.array([source_id(p) for p in problems])
    sources, counts = np.unique(clusters, return_counts=True)
    out: dict[str, Any] = {
        "budget": budget, "problems": len(problems), "sources": int(len(sources)),
        "singleton_sources": int((counts == 1).sum()), "draws": draws, "contrasts": [],
    }  # fmt: skip
    if len(sources) < MIN_SOURCES:
        out["insufficient"] = f"fewer than {MIN_SOURCES} independent sources"
        return out
    for pi in prevalences:
        for metric in CONTRAST_METRICS:
            values = np.array([row[pi][metric] for row in per_problem])
            out["contrasts"].append(
                {"prevalence": pi, "metric": metric}
                | bootstrap(values, clusters, by_cluster=True, draws=draws)
            )
    adjusted = holm([c["p_two_sided"] for c in out["contrasts"]])
    for item, value in zip(out["contrasts"], adjusted, strict=True):
        item["holm_p"] = value
    return out


def x_contrasts__mutmut_35(
    runs: list[dict[str, Any]],
    budget: float = 0.02,
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Change of the fixed threshold's behaviour from the observed prevalence to ``pi``.

    Per problem, the metrics of the threshold at ``pi`` minus its metrics at the problem's own
    held-out prevalence (the observed cell), averaged over the fits of all detectors and seeds
    that share the data. The independent unit is the original source, resampled as a whole; a
    contrast needs at least ``MIN_SOURCES`` sources. Holm adjusts over prevalence-metric pairs.
    """
    key = str(budget)
    problems, per_problem = [], []
    for run in runs:
        cells = [
            c
            for seeds in run["runs"].values()
            for s in seeds
            if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
            for c in [s["budgets"][key]]
        ]
        if not cells:
            continue
        rows = {}
        for pi in prevalences:
            observed = [
                shifted(c, (c["tp"] + c["XXfnXX"]) / (c["tp"] + c["fn"] + c["fp"] + c["tn"]))
                for c in cells
            ]
            moved = [shifted(c, pi) for c in cells]
            rows[pi] = {
                m: float(np.mean([a[m] - b[m] for a, b in zip(moved, observed, strict=True)]))
                for m in CONTRAST_METRICS
            }
        problems.append(run["problem"])
        per_problem.append(rows)
    clusters = np.array([source_id(p) for p in problems])
    sources, counts = np.unique(clusters, return_counts=True)
    out: dict[str, Any] = {
        "budget": budget, "problems": len(problems), "sources": int(len(sources)),
        "singleton_sources": int((counts == 1).sum()), "draws": draws, "contrasts": [],
    }  # fmt: skip
    if len(sources) < MIN_SOURCES:
        out["insufficient"] = f"fewer than {MIN_SOURCES} independent sources"
        return out
    for pi in prevalences:
        for metric in CONTRAST_METRICS:
            values = np.array([row[pi][metric] for row in per_problem])
            out["contrasts"].append(
                {"prevalence": pi, "metric": metric}
                | bootstrap(values, clusters, by_cluster=True, draws=draws)
            )
    adjusted = holm([c["p_two_sided"] for c in out["contrasts"]])
    for item, value in zip(out["contrasts"], adjusted, strict=True):
        item["holm_p"] = value
    return out


def x_contrasts__mutmut_36(
    runs: list[dict[str, Any]],
    budget: float = 0.02,
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Change of the fixed threshold's behaviour from the observed prevalence to ``pi``.

    Per problem, the metrics of the threshold at ``pi`` minus its metrics at the problem's own
    held-out prevalence (the observed cell), averaged over the fits of all detectors and seeds
    that share the data. The independent unit is the original source, resampled as a whole; a
    contrast needs at least ``MIN_SOURCES`` sources. Holm adjusts over prevalence-metric pairs.
    """
    key = str(budget)
    problems, per_problem = [], []
    for run in runs:
        cells = [
            c
            for seeds in run["runs"].values()
            for s in seeds
            if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
            for c in [s["budgets"][key]]
        ]
        if not cells:
            continue
        rows = {}
        for pi in prevalences:
            observed = [
                shifted(c, (c["tp"] + c["FN"]) / (c["tp"] + c["fn"] + c["fp"] + c["tn"]))
                for c in cells
            ]
            moved = [shifted(c, pi) for c in cells]
            rows[pi] = {
                m: float(np.mean([a[m] - b[m] for a, b in zip(moved, observed, strict=True)]))
                for m in CONTRAST_METRICS
            }
        problems.append(run["problem"])
        per_problem.append(rows)
    clusters = np.array([source_id(p) for p in problems])
    sources, counts = np.unique(clusters, return_counts=True)
    out: dict[str, Any] = {
        "budget": budget, "problems": len(problems), "sources": int(len(sources)),
        "singleton_sources": int((counts == 1).sum()), "draws": draws, "contrasts": [],
    }  # fmt: skip
    if len(sources) < MIN_SOURCES:
        out["insufficient"] = f"fewer than {MIN_SOURCES} independent sources"
        return out
    for pi in prevalences:
        for metric in CONTRAST_METRICS:
            values = np.array([row[pi][metric] for row in per_problem])
            out["contrasts"].append(
                {"prevalence": pi, "metric": metric}
                | bootstrap(values, clusters, by_cluster=True, draws=draws)
            )
    adjusted = holm([c["p_two_sided"] for c in out["contrasts"]])
    for item, value in zip(out["contrasts"], adjusted, strict=True):
        item["holm_p"] = value
    return out


def x_contrasts__mutmut_37(
    runs: list[dict[str, Any]],
    budget: float = 0.02,
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Change of the fixed threshold's behaviour from the observed prevalence to ``pi``.

    Per problem, the metrics of the threshold at ``pi`` minus its metrics at the problem's own
    held-out prevalence (the observed cell), averaged over the fits of all detectors and seeds
    that share the data. The independent unit is the original source, resampled as a whole; a
    contrast needs at least ``MIN_SOURCES`` sources. Holm adjusts over prevalence-metric pairs.
    """
    key = str(budget)
    problems, per_problem = [], []
    for run in runs:
        cells = [
            c
            for seeds in run["runs"].values()
            for s in seeds
            if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
            for c in [s["budgets"][key]]
        ]
        if not cells:
            continue
        rows = {}
        for pi in prevalences:
            observed = [
                shifted(c, (c["tp"] + c["fn"]) / (c["tp"] + c["fn"] + c["fp"] - c["tn"]))
                for c in cells
            ]
            moved = [shifted(c, pi) for c in cells]
            rows[pi] = {
                m: float(np.mean([a[m] - b[m] for a, b in zip(moved, observed, strict=True)]))
                for m in CONTRAST_METRICS
            }
        problems.append(run["problem"])
        per_problem.append(rows)
    clusters = np.array([source_id(p) for p in problems])
    sources, counts = np.unique(clusters, return_counts=True)
    out: dict[str, Any] = {
        "budget": budget, "problems": len(problems), "sources": int(len(sources)),
        "singleton_sources": int((counts == 1).sum()), "draws": draws, "contrasts": [],
    }  # fmt: skip
    if len(sources) < MIN_SOURCES:
        out["insufficient"] = f"fewer than {MIN_SOURCES} independent sources"
        return out
    for pi in prevalences:
        for metric in CONTRAST_METRICS:
            values = np.array([row[pi][metric] for row in per_problem])
            out["contrasts"].append(
                {"prevalence": pi, "metric": metric}
                | bootstrap(values, clusters, by_cluster=True, draws=draws)
            )
    adjusted = holm([c["p_two_sided"] for c in out["contrasts"]])
    for item, value in zip(out["contrasts"], adjusted, strict=True):
        item["holm_p"] = value
    return out


def x_contrasts__mutmut_38(
    runs: list[dict[str, Any]],
    budget: float = 0.02,
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Change of the fixed threshold's behaviour from the observed prevalence to ``pi``.

    Per problem, the metrics of the threshold at ``pi`` minus its metrics at the problem's own
    held-out prevalence (the observed cell), averaged over the fits of all detectors and seeds
    that share the data. The independent unit is the original source, resampled as a whole; a
    contrast needs at least ``MIN_SOURCES`` sources. Holm adjusts over prevalence-metric pairs.
    """
    key = str(budget)
    problems, per_problem = [], []
    for run in runs:
        cells = [
            c
            for seeds in run["runs"].values()
            for s in seeds
            if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
            for c in [s["budgets"][key]]
        ]
        if not cells:
            continue
        rows = {}
        for pi in prevalences:
            observed = [
                shifted(c, (c["tp"] + c["fn"]) / (c["tp"] + c["fn"] - c["fp"] + c["tn"]))
                for c in cells
            ]
            moved = [shifted(c, pi) for c in cells]
            rows[pi] = {
                m: float(np.mean([a[m] - b[m] for a, b in zip(moved, observed, strict=True)]))
                for m in CONTRAST_METRICS
            }
        problems.append(run["problem"])
        per_problem.append(rows)
    clusters = np.array([source_id(p) for p in problems])
    sources, counts = np.unique(clusters, return_counts=True)
    out: dict[str, Any] = {
        "budget": budget, "problems": len(problems), "sources": int(len(sources)),
        "singleton_sources": int((counts == 1).sum()), "draws": draws, "contrasts": [],
    }  # fmt: skip
    if len(sources) < MIN_SOURCES:
        out["insufficient"] = f"fewer than {MIN_SOURCES} independent sources"
        return out
    for pi in prevalences:
        for metric in CONTRAST_METRICS:
            values = np.array([row[pi][metric] for row in per_problem])
            out["contrasts"].append(
                {"prevalence": pi, "metric": metric}
                | bootstrap(values, clusters, by_cluster=True, draws=draws)
            )
    adjusted = holm([c["p_two_sided"] for c in out["contrasts"]])
    for item, value in zip(out["contrasts"], adjusted, strict=True):
        item["holm_p"] = value
    return out


def x_contrasts__mutmut_39(
    runs: list[dict[str, Any]],
    budget: float = 0.02,
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Change of the fixed threshold's behaviour from the observed prevalence to ``pi``.

    Per problem, the metrics of the threshold at ``pi`` minus its metrics at the problem's own
    held-out prevalence (the observed cell), averaged over the fits of all detectors and seeds
    that share the data. The independent unit is the original source, resampled as a whole; a
    contrast needs at least ``MIN_SOURCES`` sources. Holm adjusts over prevalence-metric pairs.
    """
    key = str(budget)
    problems, per_problem = [], []
    for run in runs:
        cells = [
            c
            for seeds in run["runs"].values()
            for s in seeds
            if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
            for c in [s["budgets"][key]]
        ]
        if not cells:
            continue
        rows = {}
        for pi in prevalences:
            observed = [
                shifted(c, (c["tp"] + c["fn"]) / (c["tp"] - c["fn"] + c["fp"] + c["tn"]))
                for c in cells
            ]
            moved = [shifted(c, pi) for c in cells]
            rows[pi] = {
                m: float(np.mean([a[m] - b[m] for a, b in zip(moved, observed, strict=True)]))
                for m in CONTRAST_METRICS
            }
        problems.append(run["problem"])
        per_problem.append(rows)
    clusters = np.array([source_id(p) for p in problems])
    sources, counts = np.unique(clusters, return_counts=True)
    out: dict[str, Any] = {
        "budget": budget, "problems": len(problems), "sources": int(len(sources)),
        "singleton_sources": int((counts == 1).sum()), "draws": draws, "contrasts": [],
    }  # fmt: skip
    if len(sources) < MIN_SOURCES:
        out["insufficient"] = f"fewer than {MIN_SOURCES} independent sources"
        return out
    for pi in prevalences:
        for metric in CONTRAST_METRICS:
            values = np.array([row[pi][metric] for row in per_problem])
            out["contrasts"].append(
                {"prevalence": pi, "metric": metric}
                | bootstrap(values, clusters, by_cluster=True, draws=draws)
            )
    adjusted = holm([c["p_two_sided"] for c in out["contrasts"]])
    for item, value in zip(out["contrasts"], adjusted, strict=True):
        item["holm_p"] = value
    return out


def x_contrasts__mutmut_40(
    runs: list[dict[str, Any]],
    budget: float = 0.02,
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Change of the fixed threshold's behaviour from the observed prevalence to ``pi``.

    Per problem, the metrics of the threshold at ``pi`` minus its metrics at the problem's own
    held-out prevalence (the observed cell), averaged over the fits of all detectors and seeds
    that share the data. The independent unit is the original source, resampled as a whole; a
    contrast needs at least ``MIN_SOURCES`` sources. Holm adjusts over prevalence-metric pairs.
    """
    key = str(budget)
    problems, per_problem = [], []
    for run in runs:
        cells = [
            c
            for seeds in run["runs"].values()
            for s in seeds
            if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
            for c in [s["budgets"][key]]
        ]
        if not cells:
            continue
        rows = {}
        for pi in prevalences:
            observed = [
                shifted(c, (c["tp"] + c["fn"]) / (c["XXtpXX"] + c["fn"] + c["fp"] + c["tn"]))
                for c in cells
            ]
            moved = [shifted(c, pi) for c in cells]
            rows[pi] = {
                m: float(np.mean([a[m] - b[m] for a, b in zip(moved, observed, strict=True)]))
                for m in CONTRAST_METRICS
            }
        problems.append(run["problem"])
        per_problem.append(rows)
    clusters = np.array([source_id(p) for p in problems])
    sources, counts = np.unique(clusters, return_counts=True)
    out: dict[str, Any] = {
        "budget": budget, "problems": len(problems), "sources": int(len(sources)),
        "singleton_sources": int((counts == 1).sum()), "draws": draws, "contrasts": [],
    }  # fmt: skip
    if len(sources) < MIN_SOURCES:
        out["insufficient"] = f"fewer than {MIN_SOURCES} independent sources"
        return out
    for pi in prevalences:
        for metric in CONTRAST_METRICS:
            values = np.array([row[pi][metric] for row in per_problem])
            out["contrasts"].append(
                {"prevalence": pi, "metric": metric}
                | bootstrap(values, clusters, by_cluster=True, draws=draws)
            )
    adjusted = holm([c["p_two_sided"] for c in out["contrasts"]])
    for item, value in zip(out["contrasts"], adjusted, strict=True):
        item["holm_p"] = value
    return out


def x_contrasts__mutmut_41(
    runs: list[dict[str, Any]],
    budget: float = 0.02,
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Change of the fixed threshold's behaviour from the observed prevalence to ``pi``.

    Per problem, the metrics of the threshold at ``pi`` minus its metrics at the problem's own
    held-out prevalence (the observed cell), averaged over the fits of all detectors and seeds
    that share the data. The independent unit is the original source, resampled as a whole; a
    contrast needs at least ``MIN_SOURCES`` sources. Holm adjusts over prevalence-metric pairs.
    """
    key = str(budget)
    problems, per_problem = [], []
    for run in runs:
        cells = [
            c
            for seeds in run["runs"].values()
            for s in seeds
            if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
            for c in [s["budgets"][key]]
        ]
        if not cells:
            continue
        rows = {}
        for pi in prevalences:
            observed = [
                shifted(c, (c["tp"] + c["fn"]) / (c["TP"] + c["fn"] + c["fp"] + c["tn"]))
                for c in cells
            ]
            moved = [shifted(c, pi) for c in cells]
            rows[pi] = {
                m: float(np.mean([a[m] - b[m] for a, b in zip(moved, observed, strict=True)]))
                for m in CONTRAST_METRICS
            }
        problems.append(run["problem"])
        per_problem.append(rows)
    clusters = np.array([source_id(p) for p in problems])
    sources, counts = np.unique(clusters, return_counts=True)
    out: dict[str, Any] = {
        "budget": budget, "problems": len(problems), "sources": int(len(sources)),
        "singleton_sources": int((counts == 1).sum()), "draws": draws, "contrasts": [],
    }  # fmt: skip
    if len(sources) < MIN_SOURCES:
        out["insufficient"] = f"fewer than {MIN_SOURCES} independent sources"
        return out
    for pi in prevalences:
        for metric in CONTRAST_METRICS:
            values = np.array([row[pi][metric] for row in per_problem])
            out["contrasts"].append(
                {"prevalence": pi, "metric": metric}
                | bootstrap(values, clusters, by_cluster=True, draws=draws)
            )
    adjusted = holm([c["p_two_sided"] for c in out["contrasts"]])
    for item, value in zip(out["contrasts"], adjusted, strict=True):
        item["holm_p"] = value
    return out


def x_contrasts__mutmut_42(
    runs: list[dict[str, Any]],
    budget: float = 0.02,
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Change of the fixed threshold's behaviour from the observed prevalence to ``pi``.

    Per problem, the metrics of the threshold at ``pi`` minus its metrics at the problem's own
    held-out prevalence (the observed cell), averaged over the fits of all detectors and seeds
    that share the data. The independent unit is the original source, resampled as a whole; a
    contrast needs at least ``MIN_SOURCES`` sources. Holm adjusts over prevalence-metric pairs.
    """
    key = str(budget)
    problems, per_problem = [], []
    for run in runs:
        cells = [
            c
            for seeds in run["runs"].values()
            for s in seeds
            if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
            for c in [s["budgets"][key]]
        ]
        if not cells:
            continue
        rows = {}
        for pi in prevalences:
            observed = [
                shifted(c, (c["tp"] + c["fn"]) / (c["tp"] + c["XXfnXX"] + c["fp"] + c["tn"]))
                for c in cells
            ]
            moved = [shifted(c, pi) for c in cells]
            rows[pi] = {
                m: float(np.mean([a[m] - b[m] for a, b in zip(moved, observed, strict=True)]))
                for m in CONTRAST_METRICS
            }
        problems.append(run["problem"])
        per_problem.append(rows)
    clusters = np.array([source_id(p) for p in problems])
    sources, counts = np.unique(clusters, return_counts=True)
    out: dict[str, Any] = {
        "budget": budget, "problems": len(problems), "sources": int(len(sources)),
        "singleton_sources": int((counts == 1).sum()), "draws": draws, "contrasts": [],
    }  # fmt: skip
    if len(sources) < MIN_SOURCES:
        out["insufficient"] = f"fewer than {MIN_SOURCES} independent sources"
        return out
    for pi in prevalences:
        for metric in CONTRAST_METRICS:
            values = np.array([row[pi][metric] for row in per_problem])
            out["contrasts"].append(
                {"prevalence": pi, "metric": metric}
                | bootstrap(values, clusters, by_cluster=True, draws=draws)
            )
    adjusted = holm([c["p_two_sided"] for c in out["contrasts"]])
    for item, value in zip(out["contrasts"], adjusted, strict=True):
        item["holm_p"] = value
    return out


def x_contrasts__mutmut_43(
    runs: list[dict[str, Any]],
    budget: float = 0.02,
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Change of the fixed threshold's behaviour from the observed prevalence to ``pi``.

    Per problem, the metrics of the threshold at ``pi`` minus its metrics at the problem's own
    held-out prevalence (the observed cell), averaged over the fits of all detectors and seeds
    that share the data. The independent unit is the original source, resampled as a whole; a
    contrast needs at least ``MIN_SOURCES`` sources. Holm adjusts over prevalence-metric pairs.
    """
    key = str(budget)
    problems, per_problem = [], []
    for run in runs:
        cells = [
            c
            for seeds in run["runs"].values()
            for s in seeds
            if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
            for c in [s["budgets"][key]]
        ]
        if not cells:
            continue
        rows = {}
        for pi in prevalences:
            observed = [
                shifted(c, (c["tp"] + c["fn"]) / (c["tp"] + c["FN"] + c["fp"] + c["tn"]))
                for c in cells
            ]
            moved = [shifted(c, pi) for c in cells]
            rows[pi] = {
                m: float(np.mean([a[m] - b[m] for a, b in zip(moved, observed, strict=True)]))
                for m in CONTRAST_METRICS
            }
        problems.append(run["problem"])
        per_problem.append(rows)
    clusters = np.array([source_id(p) for p in problems])
    sources, counts = np.unique(clusters, return_counts=True)
    out: dict[str, Any] = {
        "budget": budget, "problems": len(problems), "sources": int(len(sources)),
        "singleton_sources": int((counts == 1).sum()), "draws": draws, "contrasts": [],
    }  # fmt: skip
    if len(sources) < MIN_SOURCES:
        out["insufficient"] = f"fewer than {MIN_SOURCES} independent sources"
        return out
    for pi in prevalences:
        for metric in CONTRAST_METRICS:
            values = np.array([row[pi][metric] for row in per_problem])
            out["contrasts"].append(
                {"prevalence": pi, "metric": metric}
                | bootstrap(values, clusters, by_cluster=True, draws=draws)
            )
    adjusted = holm([c["p_two_sided"] for c in out["contrasts"]])
    for item, value in zip(out["contrasts"], adjusted, strict=True):
        item["holm_p"] = value
    return out


def x_contrasts__mutmut_44(
    runs: list[dict[str, Any]],
    budget: float = 0.02,
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Change of the fixed threshold's behaviour from the observed prevalence to ``pi``.

    Per problem, the metrics of the threshold at ``pi`` minus its metrics at the problem's own
    held-out prevalence (the observed cell), averaged over the fits of all detectors and seeds
    that share the data. The independent unit is the original source, resampled as a whole; a
    contrast needs at least ``MIN_SOURCES`` sources. Holm adjusts over prevalence-metric pairs.
    """
    key = str(budget)
    problems, per_problem = [], []
    for run in runs:
        cells = [
            c
            for seeds in run["runs"].values()
            for s in seeds
            if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
            for c in [s["budgets"][key]]
        ]
        if not cells:
            continue
        rows = {}
        for pi in prevalences:
            observed = [
                shifted(c, (c["tp"] + c["fn"]) / (c["tp"] + c["fn"] + c["XXfpXX"] + c["tn"]))
                for c in cells
            ]
            moved = [shifted(c, pi) for c in cells]
            rows[pi] = {
                m: float(np.mean([a[m] - b[m] for a, b in zip(moved, observed, strict=True)]))
                for m in CONTRAST_METRICS
            }
        problems.append(run["problem"])
        per_problem.append(rows)
    clusters = np.array([source_id(p) for p in problems])
    sources, counts = np.unique(clusters, return_counts=True)
    out: dict[str, Any] = {
        "budget": budget, "problems": len(problems), "sources": int(len(sources)),
        "singleton_sources": int((counts == 1).sum()), "draws": draws, "contrasts": [],
    }  # fmt: skip
    if len(sources) < MIN_SOURCES:
        out["insufficient"] = f"fewer than {MIN_SOURCES} independent sources"
        return out
    for pi in prevalences:
        for metric in CONTRAST_METRICS:
            values = np.array([row[pi][metric] for row in per_problem])
            out["contrasts"].append(
                {"prevalence": pi, "metric": metric}
                | bootstrap(values, clusters, by_cluster=True, draws=draws)
            )
    adjusted = holm([c["p_two_sided"] for c in out["contrasts"]])
    for item, value in zip(out["contrasts"], adjusted, strict=True):
        item["holm_p"] = value
    return out


def x_contrasts__mutmut_45(
    runs: list[dict[str, Any]],
    budget: float = 0.02,
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Change of the fixed threshold's behaviour from the observed prevalence to ``pi``.

    Per problem, the metrics of the threshold at ``pi`` minus its metrics at the problem's own
    held-out prevalence (the observed cell), averaged over the fits of all detectors and seeds
    that share the data. The independent unit is the original source, resampled as a whole; a
    contrast needs at least ``MIN_SOURCES`` sources. Holm adjusts over prevalence-metric pairs.
    """
    key = str(budget)
    problems, per_problem = [], []
    for run in runs:
        cells = [
            c
            for seeds in run["runs"].values()
            for s in seeds
            if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
            for c in [s["budgets"][key]]
        ]
        if not cells:
            continue
        rows = {}
        for pi in prevalences:
            observed = [
                shifted(c, (c["tp"] + c["fn"]) / (c["tp"] + c["fn"] + c["FP"] + c["tn"]))
                for c in cells
            ]
            moved = [shifted(c, pi) for c in cells]
            rows[pi] = {
                m: float(np.mean([a[m] - b[m] for a, b in zip(moved, observed, strict=True)]))
                for m in CONTRAST_METRICS
            }
        problems.append(run["problem"])
        per_problem.append(rows)
    clusters = np.array([source_id(p) for p in problems])
    sources, counts = np.unique(clusters, return_counts=True)
    out: dict[str, Any] = {
        "budget": budget, "problems": len(problems), "sources": int(len(sources)),
        "singleton_sources": int((counts == 1).sum()), "draws": draws, "contrasts": [],
    }  # fmt: skip
    if len(sources) < MIN_SOURCES:
        out["insufficient"] = f"fewer than {MIN_SOURCES} independent sources"
        return out
    for pi in prevalences:
        for metric in CONTRAST_METRICS:
            values = np.array([row[pi][metric] for row in per_problem])
            out["contrasts"].append(
                {"prevalence": pi, "metric": metric}
                | bootstrap(values, clusters, by_cluster=True, draws=draws)
            )
    adjusted = holm([c["p_two_sided"] for c in out["contrasts"]])
    for item, value in zip(out["contrasts"], adjusted, strict=True):
        item["holm_p"] = value
    return out


def x_contrasts__mutmut_46(
    runs: list[dict[str, Any]],
    budget: float = 0.02,
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Change of the fixed threshold's behaviour from the observed prevalence to ``pi``.

    Per problem, the metrics of the threshold at ``pi`` minus its metrics at the problem's own
    held-out prevalence (the observed cell), averaged over the fits of all detectors and seeds
    that share the data. The independent unit is the original source, resampled as a whole; a
    contrast needs at least ``MIN_SOURCES`` sources. Holm adjusts over prevalence-metric pairs.
    """
    key = str(budget)
    problems, per_problem = [], []
    for run in runs:
        cells = [
            c
            for seeds in run["runs"].values()
            for s in seeds
            if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
            for c in [s["budgets"][key]]
        ]
        if not cells:
            continue
        rows = {}
        for pi in prevalences:
            observed = [
                shifted(c, (c["tp"] + c["fn"]) / (c["tp"] + c["fn"] + c["fp"] + c["XXtnXX"]))
                for c in cells
            ]
            moved = [shifted(c, pi) for c in cells]
            rows[pi] = {
                m: float(np.mean([a[m] - b[m] for a, b in zip(moved, observed, strict=True)]))
                for m in CONTRAST_METRICS
            }
        problems.append(run["problem"])
        per_problem.append(rows)
    clusters = np.array([source_id(p) for p in problems])
    sources, counts = np.unique(clusters, return_counts=True)
    out: dict[str, Any] = {
        "budget": budget, "problems": len(problems), "sources": int(len(sources)),
        "singleton_sources": int((counts == 1).sum()), "draws": draws, "contrasts": [],
    }  # fmt: skip
    if len(sources) < MIN_SOURCES:
        out["insufficient"] = f"fewer than {MIN_SOURCES} independent sources"
        return out
    for pi in prevalences:
        for metric in CONTRAST_METRICS:
            values = np.array([row[pi][metric] for row in per_problem])
            out["contrasts"].append(
                {"prevalence": pi, "metric": metric}
                | bootstrap(values, clusters, by_cluster=True, draws=draws)
            )
    adjusted = holm([c["p_two_sided"] for c in out["contrasts"]])
    for item, value in zip(out["contrasts"], adjusted, strict=True):
        item["holm_p"] = value
    return out


def x_contrasts__mutmut_47(
    runs: list[dict[str, Any]],
    budget: float = 0.02,
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Change of the fixed threshold's behaviour from the observed prevalence to ``pi``.

    Per problem, the metrics of the threshold at ``pi`` minus its metrics at the problem's own
    held-out prevalence (the observed cell), averaged over the fits of all detectors and seeds
    that share the data. The independent unit is the original source, resampled as a whole; a
    contrast needs at least ``MIN_SOURCES`` sources. Holm adjusts over prevalence-metric pairs.
    """
    key = str(budget)
    problems, per_problem = [], []
    for run in runs:
        cells = [
            c
            for seeds in run["runs"].values()
            for s in seeds
            if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
            for c in [s["budgets"][key]]
        ]
        if not cells:
            continue
        rows = {}
        for pi in prevalences:
            observed = [
                shifted(c, (c["tp"] + c["fn"]) / (c["tp"] + c["fn"] + c["fp"] + c["TN"]))
                for c in cells
            ]
            moved = [shifted(c, pi) for c in cells]
            rows[pi] = {
                m: float(np.mean([a[m] - b[m] for a, b in zip(moved, observed, strict=True)]))
                for m in CONTRAST_METRICS
            }
        problems.append(run["problem"])
        per_problem.append(rows)
    clusters = np.array([source_id(p) for p in problems])
    sources, counts = np.unique(clusters, return_counts=True)
    out: dict[str, Any] = {
        "budget": budget, "problems": len(problems), "sources": int(len(sources)),
        "singleton_sources": int((counts == 1).sum()), "draws": draws, "contrasts": [],
    }  # fmt: skip
    if len(sources) < MIN_SOURCES:
        out["insufficient"] = f"fewer than {MIN_SOURCES} independent sources"
        return out
    for pi in prevalences:
        for metric in CONTRAST_METRICS:
            values = np.array([row[pi][metric] for row in per_problem])
            out["contrasts"].append(
                {"prevalence": pi, "metric": metric}
                | bootstrap(values, clusters, by_cluster=True, draws=draws)
            )
    adjusted = holm([c["p_two_sided"] for c in out["contrasts"]])
    for item, value in zip(out["contrasts"], adjusted, strict=True):
        item["holm_p"] = value
    return out


def x_contrasts__mutmut_48(
    runs: list[dict[str, Any]],
    budget: float = 0.02,
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Change of the fixed threshold's behaviour from the observed prevalence to ``pi``.

    Per problem, the metrics of the threshold at ``pi`` minus its metrics at the problem's own
    held-out prevalence (the observed cell), averaged over the fits of all detectors and seeds
    that share the data. The independent unit is the original source, resampled as a whole; a
    contrast needs at least ``MIN_SOURCES`` sources. Holm adjusts over prevalence-metric pairs.
    """
    key = str(budget)
    problems, per_problem = [], []
    for run in runs:
        cells = [
            c
            for seeds in run["runs"].values()
            for s in seeds
            if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
            for c in [s["budgets"][key]]
        ]
        if not cells:
            continue
        rows = {}
        for pi in prevalences:
            observed = [
                shifted(c, (c["tp"] + c["fn"]) / (c["tp"] + c["fn"] + c["fp"] + c["tn"]))
                for c in cells
            ]
            moved = None
            rows[pi] = {
                m: float(np.mean([a[m] - b[m] for a, b in zip(moved, observed, strict=True)]))
                for m in CONTRAST_METRICS
            }
        problems.append(run["problem"])
        per_problem.append(rows)
    clusters = np.array([source_id(p) for p in problems])
    sources, counts = np.unique(clusters, return_counts=True)
    out: dict[str, Any] = {
        "budget": budget, "problems": len(problems), "sources": int(len(sources)),
        "singleton_sources": int((counts == 1).sum()), "draws": draws, "contrasts": [],
    }  # fmt: skip
    if len(sources) < MIN_SOURCES:
        out["insufficient"] = f"fewer than {MIN_SOURCES} independent sources"
        return out
    for pi in prevalences:
        for metric in CONTRAST_METRICS:
            values = np.array([row[pi][metric] for row in per_problem])
            out["contrasts"].append(
                {"prevalence": pi, "metric": metric}
                | bootstrap(values, clusters, by_cluster=True, draws=draws)
            )
    adjusted = holm([c["p_two_sided"] for c in out["contrasts"]])
    for item, value in zip(out["contrasts"], adjusted, strict=True):
        item["holm_p"] = value
    return out


def x_contrasts__mutmut_49(
    runs: list[dict[str, Any]],
    budget: float = 0.02,
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Change of the fixed threshold's behaviour from the observed prevalence to ``pi``.

    Per problem, the metrics of the threshold at ``pi`` minus its metrics at the problem's own
    held-out prevalence (the observed cell), averaged over the fits of all detectors and seeds
    that share the data. The independent unit is the original source, resampled as a whole; a
    contrast needs at least ``MIN_SOURCES`` sources. Holm adjusts over prevalence-metric pairs.
    """
    key = str(budget)
    problems, per_problem = [], []
    for run in runs:
        cells = [
            c
            for seeds in run["runs"].values()
            for s in seeds
            if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
            for c in [s["budgets"][key]]
        ]
        if not cells:
            continue
        rows = {}
        for pi in prevalences:
            observed = [
                shifted(c, (c["tp"] + c["fn"]) / (c["tp"] + c["fn"] + c["fp"] + c["tn"]))
                for c in cells
            ]
            moved = [shifted(None, pi) for c in cells]
            rows[pi] = {
                m: float(np.mean([a[m] - b[m] for a, b in zip(moved, observed, strict=True)]))
                for m in CONTRAST_METRICS
            }
        problems.append(run["problem"])
        per_problem.append(rows)
    clusters = np.array([source_id(p) for p in problems])
    sources, counts = np.unique(clusters, return_counts=True)
    out: dict[str, Any] = {
        "budget": budget, "problems": len(problems), "sources": int(len(sources)),
        "singleton_sources": int((counts == 1).sum()), "draws": draws, "contrasts": [],
    }  # fmt: skip
    if len(sources) < MIN_SOURCES:
        out["insufficient"] = f"fewer than {MIN_SOURCES} independent sources"
        return out
    for pi in prevalences:
        for metric in CONTRAST_METRICS:
            values = np.array([row[pi][metric] for row in per_problem])
            out["contrasts"].append(
                {"prevalence": pi, "metric": metric}
                | bootstrap(values, clusters, by_cluster=True, draws=draws)
            )
    adjusted = holm([c["p_two_sided"] for c in out["contrasts"]])
    for item, value in zip(out["contrasts"], adjusted, strict=True):
        item["holm_p"] = value
    return out


def x_contrasts__mutmut_50(
    runs: list[dict[str, Any]],
    budget: float = 0.02,
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Change of the fixed threshold's behaviour from the observed prevalence to ``pi``.

    Per problem, the metrics of the threshold at ``pi`` minus its metrics at the problem's own
    held-out prevalence (the observed cell), averaged over the fits of all detectors and seeds
    that share the data. The independent unit is the original source, resampled as a whole; a
    contrast needs at least ``MIN_SOURCES`` sources. Holm adjusts over prevalence-metric pairs.
    """
    key = str(budget)
    problems, per_problem = [], []
    for run in runs:
        cells = [
            c
            for seeds in run["runs"].values()
            for s in seeds
            if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
            for c in [s["budgets"][key]]
        ]
        if not cells:
            continue
        rows = {}
        for pi in prevalences:
            observed = [
                shifted(c, (c["tp"] + c["fn"]) / (c["tp"] + c["fn"] + c["fp"] + c["tn"]))
                for c in cells
            ]
            moved = [shifted(c, None) for c in cells]
            rows[pi] = {
                m: float(np.mean([a[m] - b[m] for a, b in zip(moved, observed, strict=True)]))
                for m in CONTRAST_METRICS
            }
        problems.append(run["problem"])
        per_problem.append(rows)
    clusters = np.array([source_id(p) for p in problems])
    sources, counts = np.unique(clusters, return_counts=True)
    out: dict[str, Any] = {
        "budget": budget, "problems": len(problems), "sources": int(len(sources)),
        "singleton_sources": int((counts == 1).sum()), "draws": draws, "contrasts": [],
    }  # fmt: skip
    if len(sources) < MIN_SOURCES:
        out["insufficient"] = f"fewer than {MIN_SOURCES} independent sources"
        return out
    for pi in prevalences:
        for metric in CONTRAST_METRICS:
            values = np.array([row[pi][metric] for row in per_problem])
            out["contrasts"].append(
                {"prevalence": pi, "metric": metric}
                | bootstrap(values, clusters, by_cluster=True, draws=draws)
            )
    adjusted = holm([c["p_two_sided"] for c in out["contrasts"]])
    for item, value in zip(out["contrasts"], adjusted, strict=True):
        item["holm_p"] = value
    return out


def x_contrasts__mutmut_51(
    runs: list[dict[str, Any]],
    budget: float = 0.02,
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Change of the fixed threshold's behaviour from the observed prevalence to ``pi``.

    Per problem, the metrics of the threshold at ``pi`` minus its metrics at the problem's own
    held-out prevalence (the observed cell), averaged over the fits of all detectors and seeds
    that share the data. The independent unit is the original source, resampled as a whole; a
    contrast needs at least ``MIN_SOURCES`` sources. Holm adjusts over prevalence-metric pairs.
    """
    key = str(budget)
    problems, per_problem = [], []
    for run in runs:
        cells = [
            c
            for seeds in run["runs"].values()
            for s in seeds
            if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
            for c in [s["budgets"][key]]
        ]
        if not cells:
            continue
        rows = {}
        for pi in prevalences:
            observed = [
                shifted(c, (c["tp"] + c["fn"]) / (c["tp"] + c["fn"] + c["fp"] + c["tn"]))
                for c in cells
            ]
            moved = [shifted(pi) for c in cells]
            rows[pi] = {
                m: float(np.mean([a[m] - b[m] for a, b in zip(moved, observed, strict=True)]))
                for m in CONTRAST_METRICS
            }
        problems.append(run["problem"])
        per_problem.append(rows)
    clusters = np.array([source_id(p) for p in problems])
    sources, counts = np.unique(clusters, return_counts=True)
    out: dict[str, Any] = {
        "budget": budget, "problems": len(problems), "sources": int(len(sources)),
        "singleton_sources": int((counts == 1).sum()), "draws": draws, "contrasts": [],
    }  # fmt: skip
    if len(sources) < MIN_SOURCES:
        out["insufficient"] = f"fewer than {MIN_SOURCES} independent sources"
        return out
    for pi in prevalences:
        for metric in CONTRAST_METRICS:
            values = np.array([row[pi][metric] for row in per_problem])
            out["contrasts"].append(
                {"prevalence": pi, "metric": metric}
                | bootstrap(values, clusters, by_cluster=True, draws=draws)
            )
    adjusted = holm([c["p_two_sided"] for c in out["contrasts"]])
    for item, value in zip(out["contrasts"], adjusted, strict=True):
        item["holm_p"] = value
    return out


def x_contrasts__mutmut_52(
    runs: list[dict[str, Any]],
    budget: float = 0.02,
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Change of the fixed threshold's behaviour from the observed prevalence to ``pi``.

    Per problem, the metrics of the threshold at ``pi`` minus its metrics at the problem's own
    held-out prevalence (the observed cell), averaged over the fits of all detectors and seeds
    that share the data. The independent unit is the original source, resampled as a whole; a
    contrast needs at least ``MIN_SOURCES`` sources. Holm adjusts over prevalence-metric pairs.
    """
    key = str(budget)
    problems, per_problem = [], []
    for run in runs:
        cells = [
            c
            for seeds in run["runs"].values()
            for s in seeds
            if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
            for c in [s["budgets"][key]]
        ]
        if not cells:
            continue
        rows = {}
        for pi in prevalences:
            observed = [
                shifted(c, (c["tp"] + c["fn"]) / (c["tp"] + c["fn"] + c["fp"] + c["tn"]))
                for c in cells
            ]
            moved = [shifted(c, ) for c in cells]
            rows[pi] = {
                m: float(np.mean([a[m] - b[m] for a, b in zip(moved, observed, strict=True)]))
                for m in CONTRAST_METRICS
            }
        problems.append(run["problem"])
        per_problem.append(rows)
    clusters = np.array([source_id(p) for p in problems])
    sources, counts = np.unique(clusters, return_counts=True)
    out: dict[str, Any] = {
        "budget": budget, "problems": len(problems), "sources": int(len(sources)),
        "singleton_sources": int((counts == 1).sum()), "draws": draws, "contrasts": [],
    }  # fmt: skip
    if len(sources) < MIN_SOURCES:
        out["insufficient"] = f"fewer than {MIN_SOURCES} independent sources"
        return out
    for pi in prevalences:
        for metric in CONTRAST_METRICS:
            values = np.array([row[pi][metric] for row in per_problem])
            out["contrasts"].append(
                {"prevalence": pi, "metric": metric}
                | bootstrap(values, clusters, by_cluster=True, draws=draws)
            )
    adjusted = holm([c["p_two_sided"] for c in out["contrasts"]])
    for item, value in zip(out["contrasts"], adjusted, strict=True):
        item["holm_p"] = value
    return out


def x_contrasts__mutmut_53(
    runs: list[dict[str, Any]],
    budget: float = 0.02,
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Change of the fixed threshold's behaviour from the observed prevalence to ``pi``.

    Per problem, the metrics of the threshold at ``pi`` minus its metrics at the problem's own
    held-out prevalence (the observed cell), averaged over the fits of all detectors and seeds
    that share the data. The independent unit is the original source, resampled as a whole; a
    contrast needs at least ``MIN_SOURCES`` sources. Holm adjusts over prevalence-metric pairs.
    """
    key = str(budget)
    problems, per_problem = [], []
    for run in runs:
        cells = [
            c
            for seeds in run["runs"].values()
            for s in seeds
            if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
            for c in [s["budgets"][key]]
        ]
        if not cells:
            continue
        rows = {}
        for pi in prevalences:
            observed = [
                shifted(c, (c["tp"] + c["fn"]) / (c["tp"] + c["fn"] + c["fp"] + c["tn"]))
                for c in cells
            ]
            moved = [shifted(c, pi) for c in cells]
            rows[pi] = None
        problems.append(run["problem"])
        per_problem.append(rows)
    clusters = np.array([source_id(p) for p in problems])
    sources, counts = np.unique(clusters, return_counts=True)
    out: dict[str, Any] = {
        "budget": budget, "problems": len(problems), "sources": int(len(sources)),
        "singleton_sources": int((counts == 1).sum()), "draws": draws, "contrasts": [],
    }  # fmt: skip
    if len(sources) < MIN_SOURCES:
        out["insufficient"] = f"fewer than {MIN_SOURCES} independent sources"
        return out
    for pi in prevalences:
        for metric in CONTRAST_METRICS:
            values = np.array([row[pi][metric] for row in per_problem])
            out["contrasts"].append(
                {"prevalence": pi, "metric": metric}
                | bootstrap(values, clusters, by_cluster=True, draws=draws)
            )
    adjusted = holm([c["p_two_sided"] for c in out["contrasts"]])
    for item, value in zip(out["contrasts"], adjusted, strict=True):
        item["holm_p"] = value
    return out


def x_contrasts__mutmut_54(
    runs: list[dict[str, Any]],
    budget: float = 0.02,
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Change of the fixed threshold's behaviour from the observed prevalence to ``pi``.

    Per problem, the metrics of the threshold at ``pi`` minus its metrics at the problem's own
    held-out prevalence (the observed cell), averaged over the fits of all detectors and seeds
    that share the data. The independent unit is the original source, resampled as a whole; a
    contrast needs at least ``MIN_SOURCES`` sources. Holm adjusts over prevalence-metric pairs.
    """
    key = str(budget)
    problems, per_problem = [], []
    for run in runs:
        cells = [
            c
            for seeds in run["runs"].values()
            for s in seeds
            if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
            for c in [s["budgets"][key]]
        ]
        if not cells:
            continue
        rows = {}
        for pi in prevalences:
            observed = [
                shifted(c, (c["tp"] + c["fn"]) / (c["tp"] + c["fn"] + c["fp"] + c["tn"]))
                for c in cells
            ]
            moved = [shifted(c, pi) for c in cells]
            rows[pi] = {
                m: float(None)
                for m in CONTRAST_METRICS
            }
        problems.append(run["problem"])
        per_problem.append(rows)
    clusters = np.array([source_id(p) for p in problems])
    sources, counts = np.unique(clusters, return_counts=True)
    out: dict[str, Any] = {
        "budget": budget, "problems": len(problems), "sources": int(len(sources)),
        "singleton_sources": int((counts == 1).sum()), "draws": draws, "contrasts": [],
    }  # fmt: skip
    if len(sources) < MIN_SOURCES:
        out["insufficient"] = f"fewer than {MIN_SOURCES} independent sources"
        return out
    for pi in prevalences:
        for metric in CONTRAST_METRICS:
            values = np.array([row[pi][metric] for row in per_problem])
            out["contrasts"].append(
                {"prevalence": pi, "metric": metric}
                | bootstrap(values, clusters, by_cluster=True, draws=draws)
            )
    adjusted = holm([c["p_two_sided"] for c in out["contrasts"]])
    for item, value in zip(out["contrasts"], adjusted, strict=True):
        item["holm_p"] = value
    return out


def x_contrasts__mutmut_55(
    runs: list[dict[str, Any]],
    budget: float = 0.02,
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Change of the fixed threshold's behaviour from the observed prevalence to ``pi``.

    Per problem, the metrics of the threshold at ``pi`` minus its metrics at the problem's own
    held-out prevalence (the observed cell), averaged over the fits of all detectors and seeds
    that share the data. The independent unit is the original source, resampled as a whole; a
    contrast needs at least ``MIN_SOURCES`` sources. Holm adjusts over prevalence-metric pairs.
    """
    key = str(budget)
    problems, per_problem = [], []
    for run in runs:
        cells = [
            c
            for seeds in run["runs"].values()
            for s in seeds
            if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
            for c in [s["budgets"][key]]
        ]
        if not cells:
            continue
        rows = {}
        for pi in prevalences:
            observed = [
                shifted(c, (c["tp"] + c["fn"]) / (c["tp"] + c["fn"] + c["fp"] + c["tn"]))
                for c in cells
            ]
            moved = [shifted(c, pi) for c in cells]
            rows[pi] = {
                m: float(np.mean(None))
                for m in CONTRAST_METRICS
            }
        problems.append(run["problem"])
        per_problem.append(rows)
    clusters = np.array([source_id(p) for p in problems])
    sources, counts = np.unique(clusters, return_counts=True)
    out: dict[str, Any] = {
        "budget": budget, "problems": len(problems), "sources": int(len(sources)),
        "singleton_sources": int((counts == 1).sum()), "draws": draws, "contrasts": [],
    }  # fmt: skip
    if len(sources) < MIN_SOURCES:
        out["insufficient"] = f"fewer than {MIN_SOURCES} independent sources"
        return out
    for pi in prevalences:
        for metric in CONTRAST_METRICS:
            values = np.array([row[pi][metric] for row in per_problem])
            out["contrasts"].append(
                {"prevalence": pi, "metric": metric}
                | bootstrap(values, clusters, by_cluster=True, draws=draws)
            )
    adjusted = holm([c["p_two_sided"] for c in out["contrasts"]])
    for item, value in zip(out["contrasts"], adjusted, strict=True):
        item["holm_p"] = value
    return out


def x_contrasts__mutmut_56(
    runs: list[dict[str, Any]],
    budget: float = 0.02,
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Change of the fixed threshold's behaviour from the observed prevalence to ``pi``.

    Per problem, the metrics of the threshold at ``pi`` minus its metrics at the problem's own
    held-out prevalence (the observed cell), averaged over the fits of all detectors and seeds
    that share the data. The independent unit is the original source, resampled as a whole; a
    contrast needs at least ``MIN_SOURCES`` sources. Holm adjusts over prevalence-metric pairs.
    """
    key = str(budget)
    problems, per_problem = [], []
    for run in runs:
        cells = [
            c
            for seeds in run["runs"].values()
            for s in seeds
            if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
            for c in [s["budgets"][key]]
        ]
        if not cells:
            continue
        rows = {}
        for pi in prevalences:
            observed = [
                shifted(c, (c["tp"] + c["fn"]) / (c["tp"] + c["fn"] + c["fp"] + c["tn"]))
                for c in cells
            ]
            moved = [shifted(c, pi) for c in cells]
            rows[pi] = {
                m: float(np.mean([a[m] + b[m] for a, b in zip(moved, observed, strict=True)]))
                for m in CONTRAST_METRICS
            }
        problems.append(run["problem"])
        per_problem.append(rows)
    clusters = np.array([source_id(p) for p in problems])
    sources, counts = np.unique(clusters, return_counts=True)
    out: dict[str, Any] = {
        "budget": budget, "problems": len(problems), "sources": int(len(sources)),
        "singleton_sources": int((counts == 1).sum()), "draws": draws, "contrasts": [],
    }  # fmt: skip
    if len(sources) < MIN_SOURCES:
        out["insufficient"] = f"fewer than {MIN_SOURCES} independent sources"
        return out
    for pi in prevalences:
        for metric in CONTRAST_METRICS:
            values = np.array([row[pi][metric] for row in per_problem])
            out["contrasts"].append(
                {"prevalence": pi, "metric": metric}
                | bootstrap(values, clusters, by_cluster=True, draws=draws)
            )
    adjusted = holm([c["p_two_sided"] for c in out["contrasts"]])
    for item, value in zip(out["contrasts"], adjusted, strict=True):
        item["holm_p"] = value
    return out


def x_contrasts__mutmut_57(
    runs: list[dict[str, Any]],
    budget: float = 0.02,
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Change of the fixed threshold's behaviour from the observed prevalence to ``pi``.

    Per problem, the metrics of the threshold at ``pi`` minus its metrics at the problem's own
    held-out prevalence (the observed cell), averaged over the fits of all detectors and seeds
    that share the data. The independent unit is the original source, resampled as a whole; a
    contrast needs at least ``MIN_SOURCES`` sources. Holm adjusts over prevalence-metric pairs.
    """
    key = str(budget)
    problems, per_problem = [], []
    for run in runs:
        cells = [
            c
            for seeds in run["runs"].values()
            for s in seeds
            if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
            for c in [s["budgets"][key]]
        ]
        if not cells:
            continue
        rows = {}
        for pi in prevalences:
            observed = [
                shifted(c, (c["tp"] + c["fn"]) / (c["tp"] + c["fn"] + c["fp"] + c["tn"]))
                for c in cells
            ]
            moved = [shifted(c, pi) for c in cells]
            rows[pi] = {
                m: float(np.mean([a[m] - b[m] for a, b in zip(None, observed, strict=True)]))
                for m in CONTRAST_METRICS
            }
        problems.append(run["problem"])
        per_problem.append(rows)
    clusters = np.array([source_id(p) for p in problems])
    sources, counts = np.unique(clusters, return_counts=True)
    out: dict[str, Any] = {
        "budget": budget, "problems": len(problems), "sources": int(len(sources)),
        "singleton_sources": int((counts == 1).sum()), "draws": draws, "contrasts": [],
    }  # fmt: skip
    if len(sources) < MIN_SOURCES:
        out["insufficient"] = f"fewer than {MIN_SOURCES} independent sources"
        return out
    for pi in prevalences:
        for metric in CONTRAST_METRICS:
            values = np.array([row[pi][metric] for row in per_problem])
            out["contrasts"].append(
                {"prevalence": pi, "metric": metric}
                | bootstrap(values, clusters, by_cluster=True, draws=draws)
            )
    adjusted = holm([c["p_two_sided"] for c in out["contrasts"]])
    for item, value in zip(out["contrasts"], adjusted, strict=True):
        item["holm_p"] = value
    return out


def x_contrasts__mutmut_58(
    runs: list[dict[str, Any]],
    budget: float = 0.02,
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Change of the fixed threshold's behaviour from the observed prevalence to ``pi``.

    Per problem, the metrics of the threshold at ``pi`` minus its metrics at the problem's own
    held-out prevalence (the observed cell), averaged over the fits of all detectors and seeds
    that share the data. The independent unit is the original source, resampled as a whole; a
    contrast needs at least ``MIN_SOURCES`` sources. Holm adjusts over prevalence-metric pairs.
    """
    key = str(budget)
    problems, per_problem = [], []
    for run in runs:
        cells = [
            c
            for seeds in run["runs"].values()
            for s in seeds
            if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
            for c in [s["budgets"][key]]
        ]
        if not cells:
            continue
        rows = {}
        for pi in prevalences:
            observed = [
                shifted(c, (c["tp"] + c["fn"]) / (c["tp"] + c["fn"] + c["fp"] + c["tn"]))
                for c in cells
            ]
            moved = [shifted(c, pi) for c in cells]
            rows[pi] = {
                m: float(np.mean([a[m] - b[m] for a, b in zip(moved, None, strict=True)]))
                for m in CONTRAST_METRICS
            }
        problems.append(run["problem"])
        per_problem.append(rows)
    clusters = np.array([source_id(p) for p in problems])
    sources, counts = np.unique(clusters, return_counts=True)
    out: dict[str, Any] = {
        "budget": budget, "problems": len(problems), "sources": int(len(sources)),
        "singleton_sources": int((counts == 1).sum()), "draws": draws, "contrasts": [],
    }  # fmt: skip
    if len(sources) < MIN_SOURCES:
        out["insufficient"] = f"fewer than {MIN_SOURCES} independent sources"
        return out
    for pi in prevalences:
        for metric in CONTRAST_METRICS:
            values = np.array([row[pi][metric] for row in per_problem])
            out["contrasts"].append(
                {"prevalence": pi, "metric": metric}
                | bootstrap(values, clusters, by_cluster=True, draws=draws)
            )
    adjusted = holm([c["p_two_sided"] for c in out["contrasts"]])
    for item, value in zip(out["contrasts"], adjusted, strict=True):
        item["holm_p"] = value
    return out


def x_contrasts__mutmut_59(
    runs: list[dict[str, Any]],
    budget: float = 0.02,
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Change of the fixed threshold's behaviour from the observed prevalence to ``pi``.

    Per problem, the metrics of the threshold at ``pi`` minus its metrics at the problem's own
    held-out prevalence (the observed cell), averaged over the fits of all detectors and seeds
    that share the data. The independent unit is the original source, resampled as a whole; a
    contrast needs at least ``MIN_SOURCES`` sources. Holm adjusts over prevalence-metric pairs.
    """
    key = str(budget)
    problems, per_problem = [], []
    for run in runs:
        cells = [
            c
            for seeds in run["runs"].values()
            for s in seeds
            if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
            for c in [s["budgets"][key]]
        ]
        if not cells:
            continue
        rows = {}
        for pi in prevalences:
            observed = [
                shifted(c, (c["tp"] + c["fn"]) / (c["tp"] + c["fn"] + c["fp"] + c["tn"]))
                for c in cells
            ]
            moved = [shifted(c, pi) for c in cells]
            rows[pi] = {
                m: float(np.mean([a[m] - b[m] for a, b in zip(moved, observed, strict=None)]))
                for m in CONTRAST_METRICS
            }
        problems.append(run["problem"])
        per_problem.append(rows)
    clusters = np.array([source_id(p) for p in problems])
    sources, counts = np.unique(clusters, return_counts=True)
    out: dict[str, Any] = {
        "budget": budget, "problems": len(problems), "sources": int(len(sources)),
        "singleton_sources": int((counts == 1).sum()), "draws": draws, "contrasts": [],
    }  # fmt: skip
    if len(sources) < MIN_SOURCES:
        out["insufficient"] = f"fewer than {MIN_SOURCES} independent sources"
        return out
    for pi in prevalences:
        for metric in CONTRAST_METRICS:
            values = np.array([row[pi][metric] for row in per_problem])
            out["contrasts"].append(
                {"prevalence": pi, "metric": metric}
                | bootstrap(values, clusters, by_cluster=True, draws=draws)
            )
    adjusted = holm([c["p_two_sided"] for c in out["contrasts"]])
    for item, value in zip(out["contrasts"], adjusted, strict=True):
        item["holm_p"] = value
    return out


def x_contrasts__mutmut_60(
    runs: list[dict[str, Any]],
    budget: float = 0.02,
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Change of the fixed threshold's behaviour from the observed prevalence to ``pi``.

    Per problem, the metrics of the threshold at ``pi`` minus its metrics at the problem's own
    held-out prevalence (the observed cell), averaged over the fits of all detectors and seeds
    that share the data. The independent unit is the original source, resampled as a whole; a
    contrast needs at least ``MIN_SOURCES`` sources. Holm adjusts over prevalence-metric pairs.
    """
    key = str(budget)
    problems, per_problem = [], []
    for run in runs:
        cells = [
            c
            for seeds in run["runs"].values()
            for s in seeds
            if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
            for c in [s["budgets"][key]]
        ]
        if not cells:
            continue
        rows = {}
        for pi in prevalences:
            observed = [
                shifted(c, (c["tp"] + c["fn"]) / (c["tp"] + c["fn"] + c["fp"] + c["tn"]))
                for c in cells
            ]
            moved = [shifted(c, pi) for c in cells]
            rows[pi] = {
                m: float(np.mean([a[m] - b[m] for a, b in zip(observed, strict=True)]))
                for m in CONTRAST_METRICS
            }
        problems.append(run["problem"])
        per_problem.append(rows)
    clusters = np.array([source_id(p) for p in problems])
    sources, counts = np.unique(clusters, return_counts=True)
    out: dict[str, Any] = {
        "budget": budget, "problems": len(problems), "sources": int(len(sources)),
        "singleton_sources": int((counts == 1).sum()), "draws": draws, "contrasts": [],
    }  # fmt: skip
    if len(sources) < MIN_SOURCES:
        out["insufficient"] = f"fewer than {MIN_SOURCES} independent sources"
        return out
    for pi in prevalences:
        for metric in CONTRAST_METRICS:
            values = np.array([row[pi][metric] for row in per_problem])
            out["contrasts"].append(
                {"prevalence": pi, "metric": metric}
                | bootstrap(values, clusters, by_cluster=True, draws=draws)
            )
    adjusted = holm([c["p_two_sided"] for c in out["contrasts"]])
    for item, value in zip(out["contrasts"], adjusted, strict=True):
        item["holm_p"] = value
    return out


def x_contrasts__mutmut_61(
    runs: list[dict[str, Any]],
    budget: float = 0.02,
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Change of the fixed threshold's behaviour from the observed prevalence to ``pi``.

    Per problem, the metrics of the threshold at ``pi`` minus its metrics at the problem's own
    held-out prevalence (the observed cell), averaged over the fits of all detectors and seeds
    that share the data. The independent unit is the original source, resampled as a whole; a
    contrast needs at least ``MIN_SOURCES`` sources. Holm adjusts over prevalence-metric pairs.
    """
    key = str(budget)
    problems, per_problem = [], []
    for run in runs:
        cells = [
            c
            for seeds in run["runs"].values()
            for s in seeds
            if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
            for c in [s["budgets"][key]]
        ]
        if not cells:
            continue
        rows = {}
        for pi in prevalences:
            observed = [
                shifted(c, (c["tp"] + c["fn"]) / (c["tp"] + c["fn"] + c["fp"] + c["tn"]))
                for c in cells
            ]
            moved = [shifted(c, pi) for c in cells]
            rows[pi] = {
                m: float(np.mean([a[m] - b[m] for a, b in zip(moved, strict=True)]))
                for m in CONTRAST_METRICS
            }
        problems.append(run["problem"])
        per_problem.append(rows)
    clusters = np.array([source_id(p) for p in problems])
    sources, counts = np.unique(clusters, return_counts=True)
    out: dict[str, Any] = {
        "budget": budget, "problems": len(problems), "sources": int(len(sources)),
        "singleton_sources": int((counts == 1).sum()), "draws": draws, "contrasts": [],
    }  # fmt: skip
    if len(sources) < MIN_SOURCES:
        out["insufficient"] = f"fewer than {MIN_SOURCES} independent sources"
        return out
    for pi in prevalences:
        for metric in CONTRAST_METRICS:
            values = np.array([row[pi][metric] for row in per_problem])
            out["contrasts"].append(
                {"prevalence": pi, "metric": metric}
                | bootstrap(values, clusters, by_cluster=True, draws=draws)
            )
    adjusted = holm([c["p_two_sided"] for c in out["contrasts"]])
    for item, value in zip(out["contrasts"], adjusted, strict=True):
        item["holm_p"] = value
    return out


def x_contrasts__mutmut_62(
    runs: list[dict[str, Any]],
    budget: float = 0.02,
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Change of the fixed threshold's behaviour from the observed prevalence to ``pi``.

    Per problem, the metrics of the threshold at ``pi`` minus its metrics at the problem's own
    held-out prevalence (the observed cell), averaged over the fits of all detectors and seeds
    that share the data. The independent unit is the original source, resampled as a whole; a
    contrast needs at least ``MIN_SOURCES`` sources. Holm adjusts over prevalence-metric pairs.
    """
    key = str(budget)
    problems, per_problem = [], []
    for run in runs:
        cells = [
            c
            for seeds in run["runs"].values()
            for s in seeds
            if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
            for c in [s["budgets"][key]]
        ]
        if not cells:
            continue
        rows = {}
        for pi in prevalences:
            observed = [
                shifted(c, (c["tp"] + c["fn"]) / (c["tp"] + c["fn"] + c["fp"] + c["tn"]))
                for c in cells
            ]
            moved = [shifted(c, pi) for c in cells]
            rows[pi] = {
                m: float(np.mean([a[m] - b[m] for a, b in zip(moved, observed, )]))
                for m in CONTRAST_METRICS
            }
        problems.append(run["problem"])
        per_problem.append(rows)
    clusters = np.array([source_id(p) for p in problems])
    sources, counts = np.unique(clusters, return_counts=True)
    out: dict[str, Any] = {
        "budget": budget, "problems": len(problems), "sources": int(len(sources)),
        "singleton_sources": int((counts == 1).sum()), "draws": draws, "contrasts": [],
    }  # fmt: skip
    if len(sources) < MIN_SOURCES:
        out["insufficient"] = f"fewer than {MIN_SOURCES} independent sources"
        return out
    for pi in prevalences:
        for metric in CONTRAST_METRICS:
            values = np.array([row[pi][metric] for row in per_problem])
            out["contrasts"].append(
                {"prevalence": pi, "metric": metric}
                | bootstrap(values, clusters, by_cluster=True, draws=draws)
            )
    adjusted = holm([c["p_two_sided"] for c in out["contrasts"]])
    for item, value in zip(out["contrasts"], adjusted, strict=True):
        item["holm_p"] = value
    return out


def x_contrasts__mutmut_63(
    runs: list[dict[str, Any]],
    budget: float = 0.02,
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Change of the fixed threshold's behaviour from the observed prevalence to ``pi``.

    Per problem, the metrics of the threshold at ``pi`` minus its metrics at the problem's own
    held-out prevalence (the observed cell), averaged over the fits of all detectors and seeds
    that share the data. The independent unit is the original source, resampled as a whole; a
    contrast needs at least ``MIN_SOURCES`` sources. Holm adjusts over prevalence-metric pairs.
    """
    key = str(budget)
    problems, per_problem = [], []
    for run in runs:
        cells = [
            c
            for seeds in run["runs"].values()
            for s in seeds
            if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
            for c in [s["budgets"][key]]
        ]
        if not cells:
            continue
        rows = {}
        for pi in prevalences:
            observed = [
                shifted(c, (c["tp"] + c["fn"]) / (c["tp"] + c["fn"] + c["fp"] + c["tn"]))
                for c in cells
            ]
            moved = [shifted(c, pi) for c in cells]
            rows[pi] = {
                m: float(np.mean([a[m] - b[m] for a, b in zip(moved, observed, strict=False)]))
                for m in CONTRAST_METRICS
            }
        problems.append(run["problem"])
        per_problem.append(rows)
    clusters = np.array([source_id(p) for p in problems])
    sources, counts = np.unique(clusters, return_counts=True)
    out: dict[str, Any] = {
        "budget": budget, "problems": len(problems), "sources": int(len(sources)),
        "singleton_sources": int((counts == 1).sum()), "draws": draws, "contrasts": [],
    }  # fmt: skip
    if len(sources) < MIN_SOURCES:
        out["insufficient"] = f"fewer than {MIN_SOURCES} independent sources"
        return out
    for pi in prevalences:
        for metric in CONTRAST_METRICS:
            values = np.array([row[pi][metric] for row in per_problem])
            out["contrasts"].append(
                {"prevalence": pi, "metric": metric}
                | bootstrap(values, clusters, by_cluster=True, draws=draws)
            )
    adjusted = holm([c["p_two_sided"] for c in out["contrasts"]])
    for item, value in zip(out["contrasts"], adjusted, strict=True):
        item["holm_p"] = value
    return out


def x_contrasts__mutmut_64(
    runs: list[dict[str, Any]],
    budget: float = 0.02,
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Change of the fixed threshold's behaviour from the observed prevalence to ``pi``.

    Per problem, the metrics of the threshold at ``pi`` minus its metrics at the problem's own
    held-out prevalence (the observed cell), averaged over the fits of all detectors and seeds
    that share the data. The independent unit is the original source, resampled as a whole; a
    contrast needs at least ``MIN_SOURCES`` sources. Holm adjusts over prevalence-metric pairs.
    """
    key = str(budget)
    problems, per_problem = [], []
    for run in runs:
        cells = [
            c
            for seeds in run["runs"].values()
            for s in seeds
            if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
            for c in [s["budgets"][key]]
        ]
        if not cells:
            continue
        rows = {}
        for pi in prevalences:
            observed = [
                shifted(c, (c["tp"] + c["fn"]) / (c["tp"] + c["fn"] + c["fp"] + c["tn"]))
                for c in cells
            ]
            moved = [shifted(c, pi) for c in cells]
            rows[pi] = {
                m: float(np.mean([a[m] - b[m] for a, b in zip(moved, observed, strict=True)]))
                for m in CONTRAST_METRICS
            }
        problems.append(None)
        per_problem.append(rows)
    clusters = np.array([source_id(p) for p in problems])
    sources, counts = np.unique(clusters, return_counts=True)
    out: dict[str, Any] = {
        "budget": budget, "problems": len(problems), "sources": int(len(sources)),
        "singleton_sources": int((counts == 1).sum()), "draws": draws, "contrasts": [],
    }  # fmt: skip
    if len(sources) < MIN_SOURCES:
        out["insufficient"] = f"fewer than {MIN_SOURCES} independent sources"
        return out
    for pi in prevalences:
        for metric in CONTRAST_METRICS:
            values = np.array([row[pi][metric] for row in per_problem])
            out["contrasts"].append(
                {"prevalence": pi, "metric": metric}
                | bootstrap(values, clusters, by_cluster=True, draws=draws)
            )
    adjusted = holm([c["p_two_sided"] for c in out["contrasts"]])
    for item, value in zip(out["contrasts"], adjusted, strict=True):
        item["holm_p"] = value
    return out


def x_contrasts__mutmut_65(
    runs: list[dict[str, Any]],
    budget: float = 0.02,
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Change of the fixed threshold's behaviour from the observed prevalence to ``pi``.

    Per problem, the metrics of the threshold at ``pi`` minus its metrics at the problem's own
    held-out prevalence (the observed cell), averaged over the fits of all detectors and seeds
    that share the data. The independent unit is the original source, resampled as a whole; a
    contrast needs at least ``MIN_SOURCES`` sources. Holm adjusts over prevalence-metric pairs.
    """
    key = str(budget)
    problems, per_problem = [], []
    for run in runs:
        cells = [
            c
            for seeds in run["runs"].values()
            for s in seeds
            if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
            for c in [s["budgets"][key]]
        ]
        if not cells:
            continue
        rows = {}
        for pi in prevalences:
            observed = [
                shifted(c, (c["tp"] + c["fn"]) / (c["tp"] + c["fn"] + c["fp"] + c["tn"]))
                for c in cells
            ]
            moved = [shifted(c, pi) for c in cells]
            rows[pi] = {
                m: float(np.mean([a[m] - b[m] for a, b in zip(moved, observed, strict=True)]))
                for m in CONTRAST_METRICS
            }
        problems.append(run["XXproblemXX"])
        per_problem.append(rows)
    clusters = np.array([source_id(p) for p in problems])
    sources, counts = np.unique(clusters, return_counts=True)
    out: dict[str, Any] = {
        "budget": budget, "problems": len(problems), "sources": int(len(sources)),
        "singleton_sources": int((counts == 1).sum()), "draws": draws, "contrasts": [],
    }  # fmt: skip
    if len(sources) < MIN_SOURCES:
        out["insufficient"] = f"fewer than {MIN_SOURCES} independent sources"
        return out
    for pi in prevalences:
        for metric in CONTRAST_METRICS:
            values = np.array([row[pi][metric] for row in per_problem])
            out["contrasts"].append(
                {"prevalence": pi, "metric": metric}
                | bootstrap(values, clusters, by_cluster=True, draws=draws)
            )
    adjusted = holm([c["p_two_sided"] for c in out["contrasts"]])
    for item, value in zip(out["contrasts"], adjusted, strict=True):
        item["holm_p"] = value
    return out


def x_contrasts__mutmut_66(
    runs: list[dict[str, Any]],
    budget: float = 0.02,
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Change of the fixed threshold's behaviour from the observed prevalence to ``pi``.

    Per problem, the metrics of the threshold at ``pi`` minus its metrics at the problem's own
    held-out prevalence (the observed cell), averaged over the fits of all detectors and seeds
    that share the data. The independent unit is the original source, resampled as a whole; a
    contrast needs at least ``MIN_SOURCES`` sources. Holm adjusts over prevalence-metric pairs.
    """
    key = str(budget)
    problems, per_problem = [], []
    for run in runs:
        cells = [
            c
            for seeds in run["runs"].values()
            for s in seeds
            if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
            for c in [s["budgets"][key]]
        ]
        if not cells:
            continue
        rows = {}
        for pi in prevalences:
            observed = [
                shifted(c, (c["tp"] + c["fn"]) / (c["tp"] + c["fn"] + c["fp"] + c["tn"]))
                for c in cells
            ]
            moved = [shifted(c, pi) for c in cells]
            rows[pi] = {
                m: float(np.mean([a[m] - b[m] for a, b in zip(moved, observed, strict=True)]))
                for m in CONTRAST_METRICS
            }
        problems.append(run["PROBLEM"])
        per_problem.append(rows)
    clusters = np.array([source_id(p) for p in problems])
    sources, counts = np.unique(clusters, return_counts=True)
    out: dict[str, Any] = {
        "budget": budget, "problems": len(problems), "sources": int(len(sources)),
        "singleton_sources": int((counts == 1).sum()), "draws": draws, "contrasts": [],
    }  # fmt: skip
    if len(sources) < MIN_SOURCES:
        out["insufficient"] = f"fewer than {MIN_SOURCES} independent sources"
        return out
    for pi in prevalences:
        for metric in CONTRAST_METRICS:
            values = np.array([row[pi][metric] for row in per_problem])
            out["contrasts"].append(
                {"prevalence": pi, "metric": metric}
                | bootstrap(values, clusters, by_cluster=True, draws=draws)
            )
    adjusted = holm([c["p_two_sided"] for c in out["contrasts"]])
    for item, value in zip(out["contrasts"], adjusted, strict=True):
        item["holm_p"] = value
    return out


def x_contrasts__mutmut_67(
    runs: list[dict[str, Any]],
    budget: float = 0.02,
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Change of the fixed threshold's behaviour from the observed prevalence to ``pi``.

    Per problem, the metrics of the threshold at ``pi`` minus its metrics at the problem's own
    held-out prevalence (the observed cell), averaged over the fits of all detectors and seeds
    that share the data. The independent unit is the original source, resampled as a whole; a
    contrast needs at least ``MIN_SOURCES`` sources. Holm adjusts over prevalence-metric pairs.
    """
    key = str(budget)
    problems, per_problem = [], []
    for run in runs:
        cells = [
            c
            for seeds in run["runs"].values()
            for s in seeds
            if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
            for c in [s["budgets"][key]]
        ]
        if not cells:
            continue
        rows = {}
        for pi in prevalences:
            observed = [
                shifted(c, (c["tp"] + c["fn"]) / (c["tp"] + c["fn"] + c["fp"] + c["tn"]))
                for c in cells
            ]
            moved = [shifted(c, pi) for c in cells]
            rows[pi] = {
                m: float(np.mean([a[m] - b[m] for a, b in zip(moved, observed, strict=True)]))
                for m in CONTRAST_METRICS
            }
        problems.append(run["problem"])
        per_problem.append(None)
    clusters = np.array([source_id(p) for p in problems])
    sources, counts = np.unique(clusters, return_counts=True)
    out: dict[str, Any] = {
        "budget": budget, "problems": len(problems), "sources": int(len(sources)),
        "singleton_sources": int((counts == 1).sum()), "draws": draws, "contrasts": [],
    }  # fmt: skip
    if len(sources) < MIN_SOURCES:
        out["insufficient"] = f"fewer than {MIN_SOURCES} independent sources"
        return out
    for pi in prevalences:
        for metric in CONTRAST_METRICS:
            values = np.array([row[pi][metric] for row in per_problem])
            out["contrasts"].append(
                {"prevalence": pi, "metric": metric}
                | bootstrap(values, clusters, by_cluster=True, draws=draws)
            )
    adjusted = holm([c["p_two_sided"] for c in out["contrasts"]])
    for item, value in zip(out["contrasts"], adjusted, strict=True):
        item["holm_p"] = value
    return out


def x_contrasts__mutmut_68(
    runs: list[dict[str, Any]],
    budget: float = 0.02,
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Change of the fixed threshold's behaviour from the observed prevalence to ``pi``.

    Per problem, the metrics of the threshold at ``pi`` minus its metrics at the problem's own
    held-out prevalence (the observed cell), averaged over the fits of all detectors and seeds
    that share the data. The independent unit is the original source, resampled as a whole; a
    contrast needs at least ``MIN_SOURCES`` sources. Holm adjusts over prevalence-metric pairs.
    """
    key = str(budget)
    problems, per_problem = [], []
    for run in runs:
        cells = [
            c
            for seeds in run["runs"].values()
            for s in seeds
            if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
            for c in [s["budgets"][key]]
        ]
        if not cells:
            continue
        rows = {}
        for pi in prevalences:
            observed = [
                shifted(c, (c["tp"] + c["fn"]) / (c["tp"] + c["fn"] + c["fp"] + c["tn"]))
                for c in cells
            ]
            moved = [shifted(c, pi) for c in cells]
            rows[pi] = {
                m: float(np.mean([a[m] - b[m] for a, b in zip(moved, observed, strict=True)]))
                for m in CONTRAST_METRICS
            }
        problems.append(run["problem"])
        per_problem.append(rows)
    clusters = None
    sources, counts = np.unique(clusters, return_counts=True)
    out: dict[str, Any] = {
        "budget": budget, "problems": len(problems), "sources": int(len(sources)),
        "singleton_sources": int((counts == 1).sum()), "draws": draws, "contrasts": [],
    }  # fmt: skip
    if len(sources) < MIN_SOURCES:
        out["insufficient"] = f"fewer than {MIN_SOURCES} independent sources"
        return out
    for pi in prevalences:
        for metric in CONTRAST_METRICS:
            values = np.array([row[pi][metric] for row in per_problem])
            out["contrasts"].append(
                {"prevalence": pi, "metric": metric}
                | bootstrap(values, clusters, by_cluster=True, draws=draws)
            )
    adjusted = holm([c["p_two_sided"] for c in out["contrasts"]])
    for item, value in zip(out["contrasts"], adjusted, strict=True):
        item["holm_p"] = value
    return out


def x_contrasts__mutmut_69(
    runs: list[dict[str, Any]],
    budget: float = 0.02,
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Change of the fixed threshold's behaviour from the observed prevalence to ``pi``.

    Per problem, the metrics of the threshold at ``pi`` minus its metrics at the problem's own
    held-out prevalence (the observed cell), averaged over the fits of all detectors and seeds
    that share the data. The independent unit is the original source, resampled as a whole; a
    contrast needs at least ``MIN_SOURCES`` sources. Holm adjusts over prevalence-metric pairs.
    """
    key = str(budget)
    problems, per_problem = [], []
    for run in runs:
        cells = [
            c
            for seeds in run["runs"].values()
            for s in seeds
            if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
            for c in [s["budgets"][key]]
        ]
        if not cells:
            continue
        rows = {}
        for pi in prevalences:
            observed = [
                shifted(c, (c["tp"] + c["fn"]) / (c["tp"] + c["fn"] + c["fp"] + c["tn"]))
                for c in cells
            ]
            moved = [shifted(c, pi) for c in cells]
            rows[pi] = {
                m: float(np.mean([a[m] - b[m] for a, b in zip(moved, observed, strict=True)]))
                for m in CONTRAST_METRICS
            }
        problems.append(run["problem"])
        per_problem.append(rows)
    clusters = np.array(None)
    sources, counts = np.unique(clusters, return_counts=True)
    out: dict[str, Any] = {
        "budget": budget, "problems": len(problems), "sources": int(len(sources)),
        "singleton_sources": int((counts == 1).sum()), "draws": draws, "contrasts": [],
    }  # fmt: skip
    if len(sources) < MIN_SOURCES:
        out["insufficient"] = f"fewer than {MIN_SOURCES} independent sources"
        return out
    for pi in prevalences:
        for metric in CONTRAST_METRICS:
            values = np.array([row[pi][metric] for row in per_problem])
            out["contrasts"].append(
                {"prevalence": pi, "metric": metric}
                | bootstrap(values, clusters, by_cluster=True, draws=draws)
            )
    adjusted = holm([c["p_two_sided"] for c in out["contrasts"]])
    for item, value in zip(out["contrasts"], adjusted, strict=True):
        item["holm_p"] = value
    return out


def x_contrasts__mutmut_70(
    runs: list[dict[str, Any]],
    budget: float = 0.02,
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Change of the fixed threshold's behaviour from the observed prevalence to ``pi``.

    Per problem, the metrics of the threshold at ``pi`` minus its metrics at the problem's own
    held-out prevalence (the observed cell), averaged over the fits of all detectors and seeds
    that share the data. The independent unit is the original source, resampled as a whole; a
    contrast needs at least ``MIN_SOURCES`` sources. Holm adjusts over prevalence-metric pairs.
    """
    key = str(budget)
    problems, per_problem = [], []
    for run in runs:
        cells = [
            c
            for seeds in run["runs"].values()
            for s in seeds
            if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
            for c in [s["budgets"][key]]
        ]
        if not cells:
            continue
        rows = {}
        for pi in prevalences:
            observed = [
                shifted(c, (c["tp"] + c["fn"]) / (c["tp"] + c["fn"] + c["fp"] + c["tn"]))
                for c in cells
            ]
            moved = [shifted(c, pi) for c in cells]
            rows[pi] = {
                m: float(np.mean([a[m] - b[m] for a, b in zip(moved, observed, strict=True)]))
                for m in CONTRAST_METRICS
            }
        problems.append(run["problem"])
        per_problem.append(rows)
    clusters = np.array([source_id(None) for p in problems])
    sources, counts = np.unique(clusters, return_counts=True)
    out: dict[str, Any] = {
        "budget": budget, "problems": len(problems), "sources": int(len(sources)),
        "singleton_sources": int((counts == 1).sum()), "draws": draws, "contrasts": [],
    }  # fmt: skip
    if len(sources) < MIN_SOURCES:
        out["insufficient"] = f"fewer than {MIN_SOURCES} independent sources"
        return out
    for pi in prevalences:
        for metric in CONTRAST_METRICS:
            values = np.array([row[pi][metric] for row in per_problem])
            out["contrasts"].append(
                {"prevalence": pi, "metric": metric}
                | bootstrap(values, clusters, by_cluster=True, draws=draws)
            )
    adjusted = holm([c["p_two_sided"] for c in out["contrasts"]])
    for item, value in zip(out["contrasts"], adjusted, strict=True):
        item["holm_p"] = value
    return out


def x_contrasts__mutmut_71(
    runs: list[dict[str, Any]],
    budget: float = 0.02,
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Change of the fixed threshold's behaviour from the observed prevalence to ``pi``.

    Per problem, the metrics of the threshold at ``pi`` minus its metrics at the problem's own
    held-out prevalence (the observed cell), averaged over the fits of all detectors and seeds
    that share the data. The independent unit is the original source, resampled as a whole; a
    contrast needs at least ``MIN_SOURCES`` sources. Holm adjusts over prevalence-metric pairs.
    """
    key = str(budget)
    problems, per_problem = [], []
    for run in runs:
        cells = [
            c
            for seeds in run["runs"].values()
            for s in seeds
            if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
            for c in [s["budgets"][key]]
        ]
        if not cells:
            continue
        rows = {}
        for pi in prevalences:
            observed = [
                shifted(c, (c["tp"] + c["fn"]) / (c["tp"] + c["fn"] + c["fp"] + c["tn"]))
                for c in cells
            ]
            moved = [shifted(c, pi) for c in cells]
            rows[pi] = {
                m: float(np.mean([a[m] - b[m] for a, b in zip(moved, observed, strict=True)]))
                for m in CONTRAST_METRICS
            }
        problems.append(run["problem"])
        per_problem.append(rows)
    clusters = np.array([source_id(p) for p in problems])
    sources, counts = None
    out: dict[str, Any] = {
        "budget": budget, "problems": len(problems), "sources": int(len(sources)),
        "singleton_sources": int((counts == 1).sum()), "draws": draws, "contrasts": [],
    }  # fmt: skip
    if len(sources) < MIN_SOURCES:
        out["insufficient"] = f"fewer than {MIN_SOURCES} independent sources"
        return out
    for pi in prevalences:
        for metric in CONTRAST_METRICS:
            values = np.array([row[pi][metric] for row in per_problem])
            out["contrasts"].append(
                {"prevalence": pi, "metric": metric}
                | bootstrap(values, clusters, by_cluster=True, draws=draws)
            )
    adjusted = holm([c["p_two_sided"] for c in out["contrasts"]])
    for item, value in zip(out["contrasts"], adjusted, strict=True):
        item["holm_p"] = value
    return out


def x_contrasts__mutmut_72(
    runs: list[dict[str, Any]],
    budget: float = 0.02,
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Change of the fixed threshold's behaviour from the observed prevalence to ``pi``.

    Per problem, the metrics of the threshold at ``pi`` minus its metrics at the problem's own
    held-out prevalence (the observed cell), averaged over the fits of all detectors and seeds
    that share the data. The independent unit is the original source, resampled as a whole; a
    contrast needs at least ``MIN_SOURCES`` sources. Holm adjusts over prevalence-metric pairs.
    """
    key = str(budget)
    problems, per_problem = [], []
    for run in runs:
        cells = [
            c
            for seeds in run["runs"].values()
            for s in seeds
            if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
            for c in [s["budgets"][key]]
        ]
        if not cells:
            continue
        rows = {}
        for pi in prevalences:
            observed = [
                shifted(c, (c["tp"] + c["fn"]) / (c["tp"] + c["fn"] + c["fp"] + c["tn"]))
                for c in cells
            ]
            moved = [shifted(c, pi) for c in cells]
            rows[pi] = {
                m: float(np.mean([a[m] - b[m] for a, b in zip(moved, observed, strict=True)]))
                for m in CONTRAST_METRICS
            }
        problems.append(run["problem"])
        per_problem.append(rows)
    clusters = np.array([source_id(p) for p in problems])
    sources, counts = np.unique(None, return_counts=True)
    out: dict[str, Any] = {
        "budget": budget, "problems": len(problems), "sources": int(len(sources)),
        "singleton_sources": int((counts == 1).sum()), "draws": draws, "contrasts": [],
    }  # fmt: skip
    if len(sources) < MIN_SOURCES:
        out["insufficient"] = f"fewer than {MIN_SOURCES} independent sources"
        return out
    for pi in prevalences:
        for metric in CONTRAST_METRICS:
            values = np.array([row[pi][metric] for row in per_problem])
            out["contrasts"].append(
                {"prevalence": pi, "metric": metric}
                | bootstrap(values, clusters, by_cluster=True, draws=draws)
            )
    adjusted = holm([c["p_two_sided"] for c in out["contrasts"]])
    for item, value in zip(out["contrasts"], adjusted, strict=True):
        item["holm_p"] = value
    return out


def x_contrasts__mutmut_73(
    runs: list[dict[str, Any]],
    budget: float = 0.02,
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Change of the fixed threshold's behaviour from the observed prevalence to ``pi``.

    Per problem, the metrics of the threshold at ``pi`` minus its metrics at the problem's own
    held-out prevalence (the observed cell), averaged over the fits of all detectors and seeds
    that share the data. The independent unit is the original source, resampled as a whole; a
    contrast needs at least ``MIN_SOURCES`` sources. Holm adjusts over prevalence-metric pairs.
    """
    key = str(budget)
    problems, per_problem = [], []
    for run in runs:
        cells = [
            c
            for seeds in run["runs"].values()
            for s in seeds
            if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
            for c in [s["budgets"][key]]
        ]
        if not cells:
            continue
        rows = {}
        for pi in prevalences:
            observed = [
                shifted(c, (c["tp"] + c["fn"]) / (c["tp"] + c["fn"] + c["fp"] + c["tn"]))
                for c in cells
            ]
            moved = [shifted(c, pi) for c in cells]
            rows[pi] = {
                m: float(np.mean([a[m] - b[m] for a, b in zip(moved, observed, strict=True)]))
                for m in CONTRAST_METRICS
            }
        problems.append(run["problem"])
        per_problem.append(rows)
    clusters = np.array([source_id(p) for p in problems])
    sources, counts = np.unique(clusters, return_counts=None)
    out: dict[str, Any] = {
        "budget": budget, "problems": len(problems), "sources": int(len(sources)),
        "singleton_sources": int((counts == 1).sum()), "draws": draws, "contrasts": [],
    }  # fmt: skip
    if len(sources) < MIN_SOURCES:
        out["insufficient"] = f"fewer than {MIN_SOURCES} independent sources"
        return out
    for pi in prevalences:
        for metric in CONTRAST_METRICS:
            values = np.array([row[pi][metric] for row in per_problem])
            out["contrasts"].append(
                {"prevalence": pi, "metric": metric}
                | bootstrap(values, clusters, by_cluster=True, draws=draws)
            )
    adjusted = holm([c["p_two_sided"] for c in out["contrasts"]])
    for item, value in zip(out["contrasts"], adjusted, strict=True):
        item["holm_p"] = value
    return out


def x_contrasts__mutmut_74(
    runs: list[dict[str, Any]],
    budget: float = 0.02,
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Change of the fixed threshold's behaviour from the observed prevalence to ``pi``.

    Per problem, the metrics of the threshold at ``pi`` minus its metrics at the problem's own
    held-out prevalence (the observed cell), averaged over the fits of all detectors and seeds
    that share the data. The independent unit is the original source, resampled as a whole; a
    contrast needs at least ``MIN_SOURCES`` sources. Holm adjusts over prevalence-metric pairs.
    """
    key = str(budget)
    problems, per_problem = [], []
    for run in runs:
        cells = [
            c
            for seeds in run["runs"].values()
            for s in seeds
            if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
            for c in [s["budgets"][key]]
        ]
        if not cells:
            continue
        rows = {}
        for pi in prevalences:
            observed = [
                shifted(c, (c["tp"] + c["fn"]) / (c["tp"] + c["fn"] + c["fp"] + c["tn"]))
                for c in cells
            ]
            moved = [shifted(c, pi) for c in cells]
            rows[pi] = {
                m: float(np.mean([a[m] - b[m] for a, b in zip(moved, observed, strict=True)]))
                for m in CONTRAST_METRICS
            }
        problems.append(run["problem"])
        per_problem.append(rows)
    clusters = np.array([source_id(p) for p in problems])
    sources, counts = np.unique(return_counts=True)
    out: dict[str, Any] = {
        "budget": budget, "problems": len(problems), "sources": int(len(sources)),
        "singleton_sources": int((counts == 1).sum()), "draws": draws, "contrasts": [],
    }  # fmt: skip
    if len(sources) < MIN_SOURCES:
        out["insufficient"] = f"fewer than {MIN_SOURCES} independent sources"
        return out
    for pi in prevalences:
        for metric in CONTRAST_METRICS:
            values = np.array([row[pi][metric] for row in per_problem])
            out["contrasts"].append(
                {"prevalence": pi, "metric": metric}
                | bootstrap(values, clusters, by_cluster=True, draws=draws)
            )
    adjusted = holm([c["p_two_sided"] for c in out["contrasts"]])
    for item, value in zip(out["contrasts"], adjusted, strict=True):
        item["holm_p"] = value
    return out


def x_contrasts__mutmut_75(
    runs: list[dict[str, Any]],
    budget: float = 0.02,
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Change of the fixed threshold's behaviour from the observed prevalence to ``pi``.

    Per problem, the metrics of the threshold at ``pi`` minus its metrics at the problem's own
    held-out prevalence (the observed cell), averaged over the fits of all detectors and seeds
    that share the data. The independent unit is the original source, resampled as a whole; a
    contrast needs at least ``MIN_SOURCES`` sources. Holm adjusts over prevalence-metric pairs.
    """
    key = str(budget)
    problems, per_problem = [], []
    for run in runs:
        cells = [
            c
            for seeds in run["runs"].values()
            for s in seeds
            if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
            for c in [s["budgets"][key]]
        ]
        if not cells:
            continue
        rows = {}
        for pi in prevalences:
            observed = [
                shifted(c, (c["tp"] + c["fn"]) / (c["tp"] + c["fn"] + c["fp"] + c["tn"]))
                for c in cells
            ]
            moved = [shifted(c, pi) for c in cells]
            rows[pi] = {
                m: float(np.mean([a[m] - b[m] for a, b in zip(moved, observed, strict=True)]))
                for m in CONTRAST_METRICS
            }
        problems.append(run["problem"])
        per_problem.append(rows)
    clusters = np.array([source_id(p) for p in problems])
    sources, counts = np.unique(clusters, )
    out: dict[str, Any] = {
        "budget": budget, "problems": len(problems), "sources": int(len(sources)),
        "singleton_sources": int((counts == 1).sum()), "draws": draws, "contrasts": [],
    }  # fmt: skip
    if len(sources) < MIN_SOURCES:
        out["insufficient"] = f"fewer than {MIN_SOURCES} independent sources"
        return out
    for pi in prevalences:
        for metric in CONTRAST_METRICS:
            values = np.array([row[pi][metric] for row in per_problem])
            out["contrasts"].append(
                {"prevalence": pi, "metric": metric}
                | bootstrap(values, clusters, by_cluster=True, draws=draws)
            )
    adjusted = holm([c["p_two_sided"] for c in out["contrasts"]])
    for item, value in zip(out["contrasts"], adjusted, strict=True):
        item["holm_p"] = value
    return out


def x_contrasts__mutmut_76(
    runs: list[dict[str, Any]],
    budget: float = 0.02,
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Change of the fixed threshold's behaviour from the observed prevalence to ``pi``.

    Per problem, the metrics of the threshold at ``pi`` minus its metrics at the problem's own
    held-out prevalence (the observed cell), averaged over the fits of all detectors and seeds
    that share the data. The independent unit is the original source, resampled as a whole; a
    contrast needs at least ``MIN_SOURCES`` sources. Holm adjusts over prevalence-metric pairs.
    """
    key = str(budget)
    problems, per_problem = [], []
    for run in runs:
        cells = [
            c
            for seeds in run["runs"].values()
            for s in seeds
            if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
            for c in [s["budgets"][key]]
        ]
        if not cells:
            continue
        rows = {}
        for pi in prevalences:
            observed = [
                shifted(c, (c["tp"] + c["fn"]) / (c["tp"] + c["fn"] + c["fp"] + c["tn"]))
                for c in cells
            ]
            moved = [shifted(c, pi) for c in cells]
            rows[pi] = {
                m: float(np.mean([a[m] - b[m] for a, b in zip(moved, observed, strict=True)]))
                for m in CONTRAST_METRICS
            }
        problems.append(run["problem"])
        per_problem.append(rows)
    clusters = np.array([source_id(p) for p in problems])
    sources, counts = np.unique(clusters, return_counts=False)
    out: dict[str, Any] = {
        "budget": budget, "problems": len(problems), "sources": int(len(sources)),
        "singleton_sources": int((counts == 1).sum()), "draws": draws, "contrasts": [],
    }  # fmt: skip
    if len(sources) < MIN_SOURCES:
        out["insufficient"] = f"fewer than {MIN_SOURCES} independent sources"
        return out
    for pi in prevalences:
        for metric in CONTRAST_METRICS:
            values = np.array([row[pi][metric] for row in per_problem])
            out["contrasts"].append(
                {"prevalence": pi, "metric": metric}
                | bootstrap(values, clusters, by_cluster=True, draws=draws)
            )
    adjusted = holm([c["p_two_sided"] for c in out["contrasts"]])
    for item, value in zip(out["contrasts"], adjusted, strict=True):
        item["holm_p"] = value
    return out


def x_contrasts__mutmut_77(
    runs: list[dict[str, Any]],
    budget: float = 0.02,
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Change of the fixed threshold's behaviour from the observed prevalence to ``pi``.

    Per problem, the metrics of the threshold at ``pi`` minus its metrics at the problem's own
    held-out prevalence (the observed cell), averaged over the fits of all detectors and seeds
    that share the data. The independent unit is the original source, resampled as a whole; a
    contrast needs at least ``MIN_SOURCES`` sources. Holm adjusts over prevalence-metric pairs.
    """
    key = str(budget)
    problems, per_problem = [], []
    for run in runs:
        cells = [
            c
            for seeds in run["runs"].values()
            for s in seeds
            if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
            for c in [s["budgets"][key]]
        ]
        if not cells:
            continue
        rows = {}
        for pi in prevalences:
            observed = [
                shifted(c, (c["tp"] + c["fn"]) / (c["tp"] + c["fn"] + c["fp"] + c["tn"]))
                for c in cells
            ]
            moved = [shifted(c, pi) for c in cells]
            rows[pi] = {
                m: float(np.mean([a[m] - b[m] for a, b in zip(moved, observed, strict=True)]))
                for m in CONTRAST_METRICS
            }
        problems.append(run["problem"])
        per_problem.append(rows)
    clusters = np.array([source_id(p) for p in problems])
    sources, counts = np.unique(clusters, return_counts=True)
    out: dict[str, Any] = None  # fmt: skip
    if len(sources) < MIN_SOURCES:
        out["insufficient"] = f"fewer than {MIN_SOURCES} independent sources"
        return out
    for pi in prevalences:
        for metric in CONTRAST_METRICS:
            values = np.array([row[pi][metric] for row in per_problem])
            out["contrasts"].append(
                {"prevalence": pi, "metric": metric}
                | bootstrap(values, clusters, by_cluster=True, draws=draws)
            )
    adjusted = holm([c["p_two_sided"] for c in out["contrasts"]])
    for item, value in zip(out["contrasts"], adjusted, strict=True):
        item["holm_p"] = value
    return out


def x_contrasts__mutmut_78(
    runs: list[dict[str, Any]],
    budget: float = 0.02,
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Change of the fixed threshold's behaviour from the observed prevalence to ``pi``.

    Per problem, the metrics of the threshold at ``pi`` minus its metrics at the problem's own
    held-out prevalence (the observed cell), averaged over the fits of all detectors and seeds
    that share the data. The independent unit is the original source, resampled as a whole; a
    contrast needs at least ``MIN_SOURCES`` sources. Holm adjusts over prevalence-metric pairs.
    """
    key = str(budget)
    problems, per_problem = [], []
    for run in runs:
        cells = [
            c
            for seeds in run["runs"].values()
            for s in seeds
            if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
            for c in [s["budgets"][key]]
        ]
        if not cells:
            continue
        rows = {}
        for pi in prevalences:
            observed = [
                shifted(c, (c["tp"] + c["fn"]) / (c["tp"] + c["fn"] + c["fp"] + c["tn"]))
                for c in cells
            ]
            moved = [shifted(c, pi) for c in cells]
            rows[pi] = {
                m: float(np.mean([a[m] - b[m] for a, b in zip(moved, observed, strict=True)]))
                for m in CONTRAST_METRICS
            }
        problems.append(run["problem"])
        per_problem.append(rows)
    clusters = np.array([source_id(p) for p in problems])
    sources, counts = np.unique(clusters, return_counts=True)
    out: dict[str, Any] = {
        "XXbudgetXX": budget, "problems": len(problems), "sources": int(len(sources)),
        "singleton_sources": int((counts == 1).sum()), "draws": draws, "contrasts": [],
    }  # fmt: skip
    if len(sources) < MIN_SOURCES:
        out["insufficient"] = f"fewer than {MIN_SOURCES} independent sources"
        return out
    for pi in prevalences:
        for metric in CONTRAST_METRICS:
            values = np.array([row[pi][metric] for row in per_problem])
            out["contrasts"].append(
                {"prevalence": pi, "metric": metric}
                | bootstrap(values, clusters, by_cluster=True, draws=draws)
            )
    adjusted = holm([c["p_two_sided"] for c in out["contrasts"]])
    for item, value in zip(out["contrasts"], adjusted, strict=True):
        item["holm_p"] = value
    return out


def x_contrasts__mutmut_79(
    runs: list[dict[str, Any]],
    budget: float = 0.02,
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Change of the fixed threshold's behaviour from the observed prevalence to ``pi``.

    Per problem, the metrics of the threshold at ``pi`` minus its metrics at the problem's own
    held-out prevalence (the observed cell), averaged over the fits of all detectors and seeds
    that share the data. The independent unit is the original source, resampled as a whole; a
    contrast needs at least ``MIN_SOURCES`` sources. Holm adjusts over prevalence-metric pairs.
    """
    key = str(budget)
    problems, per_problem = [], []
    for run in runs:
        cells = [
            c
            for seeds in run["runs"].values()
            for s in seeds
            if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
            for c in [s["budgets"][key]]
        ]
        if not cells:
            continue
        rows = {}
        for pi in prevalences:
            observed = [
                shifted(c, (c["tp"] + c["fn"]) / (c["tp"] + c["fn"] + c["fp"] + c["tn"]))
                for c in cells
            ]
            moved = [shifted(c, pi) for c in cells]
            rows[pi] = {
                m: float(np.mean([a[m] - b[m] for a, b in zip(moved, observed, strict=True)]))
                for m in CONTRAST_METRICS
            }
        problems.append(run["problem"])
        per_problem.append(rows)
    clusters = np.array([source_id(p) for p in problems])
    sources, counts = np.unique(clusters, return_counts=True)
    out: dict[str, Any] = {
        "BUDGET": budget, "problems": len(problems), "sources": int(len(sources)),
        "singleton_sources": int((counts == 1).sum()), "draws": draws, "contrasts": [],
    }  # fmt: skip
    if len(sources) < MIN_SOURCES:
        out["insufficient"] = f"fewer than {MIN_SOURCES} independent sources"
        return out
    for pi in prevalences:
        for metric in CONTRAST_METRICS:
            values = np.array([row[pi][metric] for row in per_problem])
            out["contrasts"].append(
                {"prevalence": pi, "metric": metric}
                | bootstrap(values, clusters, by_cluster=True, draws=draws)
            )
    adjusted = holm([c["p_two_sided"] for c in out["contrasts"]])
    for item, value in zip(out["contrasts"], adjusted, strict=True):
        item["holm_p"] = value
    return out


def x_contrasts__mutmut_80(
    runs: list[dict[str, Any]],
    budget: float = 0.02,
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Change of the fixed threshold's behaviour from the observed prevalence to ``pi``.

    Per problem, the metrics of the threshold at ``pi`` minus its metrics at the problem's own
    held-out prevalence (the observed cell), averaged over the fits of all detectors and seeds
    that share the data. The independent unit is the original source, resampled as a whole; a
    contrast needs at least ``MIN_SOURCES`` sources. Holm adjusts over prevalence-metric pairs.
    """
    key = str(budget)
    problems, per_problem = [], []
    for run in runs:
        cells = [
            c
            for seeds in run["runs"].values()
            for s in seeds
            if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
            for c in [s["budgets"][key]]
        ]
        if not cells:
            continue
        rows = {}
        for pi in prevalences:
            observed = [
                shifted(c, (c["tp"] + c["fn"]) / (c["tp"] + c["fn"] + c["fp"] + c["tn"]))
                for c in cells
            ]
            moved = [shifted(c, pi) for c in cells]
            rows[pi] = {
                m: float(np.mean([a[m] - b[m] for a, b in zip(moved, observed, strict=True)]))
                for m in CONTRAST_METRICS
            }
        problems.append(run["problem"])
        per_problem.append(rows)
    clusters = np.array([source_id(p) for p in problems])
    sources, counts = np.unique(clusters, return_counts=True)
    out: dict[str, Any] = {
        "budget": budget, "XXproblemsXX": len(problems), "sources": int(len(sources)),
        "singleton_sources": int((counts == 1).sum()), "draws": draws, "contrasts": [],
    }  # fmt: skip
    if len(sources) < MIN_SOURCES:
        out["insufficient"] = f"fewer than {MIN_SOURCES} independent sources"
        return out
    for pi in prevalences:
        for metric in CONTRAST_METRICS:
            values = np.array([row[pi][metric] for row in per_problem])
            out["contrasts"].append(
                {"prevalence": pi, "metric": metric}
                | bootstrap(values, clusters, by_cluster=True, draws=draws)
            )
    adjusted = holm([c["p_two_sided"] for c in out["contrasts"]])
    for item, value in zip(out["contrasts"], adjusted, strict=True):
        item["holm_p"] = value
    return out


def x_contrasts__mutmut_81(
    runs: list[dict[str, Any]],
    budget: float = 0.02,
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Change of the fixed threshold's behaviour from the observed prevalence to ``pi``.

    Per problem, the metrics of the threshold at ``pi`` minus its metrics at the problem's own
    held-out prevalence (the observed cell), averaged over the fits of all detectors and seeds
    that share the data. The independent unit is the original source, resampled as a whole; a
    contrast needs at least ``MIN_SOURCES`` sources. Holm adjusts over prevalence-metric pairs.
    """
    key = str(budget)
    problems, per_problem = [], []
    for run in runs:
        cells = [
            c
            for seeds in run["runs"].values()
            for s in seeds
            if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
            for c in [s["budgets"][key]]
        ]
        if not cells:
            continue
        rows = {}
        for pi in prevalences:
            observed = [
                shifted(c, (c["tp"] + c["fn"]) / (c["tp"] + c["fn"] + c["fp"] + c["tn"]))
                for c in cells
            ]
            moved = [shifted(c, pi) for c in cells]
            rows[pi] = {
                m: float(np.mean([a[m] - b[m] for a, b in zip(moved, observed, strict=True)]))
                for m in CONTRAST_METRICS
            }
        problems.append(run["problem"])
        per_problem.append(rows)
    clusters = np.array([source_id(p) for p in problems])
    sources, counts = np.unique(clusters, return_counts=True)
    out: dict[str, Any] = {
        "budget": budget, "PROBLEMS": len(problems), "sources": int(len(sources)),
        "singleton_sources": int((counts == 1).sum()), "draws": draws, "contrasts": [],
    }  # fmt: skip
    if len(sources) < MIN_SOURCES:
        out["insufficient"] = f"fewer than {MIN_SOURCES} independent sources"
        return out
    for pi in prevalences:
        for metric in CONTRAST_METRICS:
            values = np.array([row[pi][metric] for row in per_problem])
            out["contrasts"].append(
                {"prevalence": pi, "metric": metric}
                | bootstrap(values, clusters, by_cluster=True, draws=draws)
            )
    adjusted = holm([c["p_two_sided"] for c in out["contrasts"]])
    for item, value in zip(out["contrasts"], adjusted, strict=True):
        item["holm_p"] = value
    return out


def x_contrasts__mutmut_82(
    runs: list[dict[str, Any]],
    budget: float = 0.02,
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Change of the fixed threshold's behaviour from the observed prevalence to ``pi``.

    Per problem, the metrics of the threshold at ``pi`` minus its metrics at the problem's own
    held-out prevalence (the observed cell), averaged over the fits of all detectors and seeds
    that share the data. The independent unit is the original source, resampled as a whole; a
    contrast needs at least ``MIN_SOURCES`` sources. Holm adjusts over prevalence-metric pairs.
    """
    key = str(budget)
    problems, per_problem = [], []
    for run in runs:
        cells = [
            c
            for seeds in run["runs"].values()
            for s in seeds
            if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
            for c in [s["budgets"][key]]
        ]
        if not cells:
            continue
        rows = {}
        for pi in prevalences:
            observed = [
                shifted(c, (c["tp"] + c["fn"]) / (c["tp"] + c["fn"] + c["fp"] + c["tn"]))
                for c in cells
            ]
            moved = [shifted(c, pi) for c in cells]
            rows[pi] = {
                m: float(np.mean([a[m] - b[m] for a, b in zip(moved, observed, strict=True)]))
                for m in CONTRAST_METRICS
            }
        problems.append(run["problem"])
        per_problem.append(rows)
    clusters = np.array([source_id(p) for p in problems])
    sources, counts = np.unique(clusters, return_counts=True)
    out: dict[str, Any] = {
        "budget": budget, "problems": len(problems), "XXsourcesXX": int(len(sources)),
        "singleton_sources": int((counts == 1).sum()), "draws": draws, "contrasts": [],
    }  # fmt: skip
    if len(sources) < MIN_SOURCES:
        out["insufficient"] = f"fewer than {MIN_SOURCES} independent sources"
        return out
    for pi in prevalences:
        for metric in CONTRAST_METRICS:
            values = np.array([row[pi][metric] for row in per_problem])
            out["contrasts"].append(
                {"prevalence": pi, "metric": metric}
                | bootstrap(values, clusters, by_cluster=True, draws=draws)
            )
    adjusted = holm([c["p_two_sided"] for c in out["contrasts"]])
    for item, value in zip(out["contrasts"], adjusted, strict=True):
        item["holm_p"] = value
    return out


def x_contrasts__mutmut_83(
    runs: list[dict[str, Any]],
    budget: float = 0.02,
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Change of the fixed threshold's behaviour from the observed prevalence to ``pi``.

    Per problem, the metrics of the threshold at ``pi`` minus its metrics at the problem's own
    held-out prevalence (the observed cell), averaged over the fits of all detectors and seeds
    that share the data. The independent unit is the original source, resampled as a whole; a
    contrast needs at least ``MIN_SOURCES`` sources. Holm adjusts over prevalence-metric pairs.
    """
    key = str(budget)
    problems, per_problem = [], []
    for run in runs:
        cells = [
            c
            for seeds in run["runs"].values()
            for s in seeds
            if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
            for c in [s["budgets"][key]]
        ]
        if not cells:
            continue
        rows = {}
        for pi in prevalences:
            observed = [
                shifted(c, (c["tp"] + c["fn"]) / (c["tp"] + c["fn"] + c["fp"] + c["tn"]))
                for c in cells
            ]
            moved = [shifted(c, pi) for c in cells]
            rows[pi] = {
                m: float(np.mean([a[m] - b[m] for a, b in zip(moved, observed, strict=True)]))
                for m in CONTRAST_METRICS
            }
        problems.append(run["problem"])
        per_problem.append(rows)
    clusters = np.array([source_id(p) for p in problems])
    sources, counts = np.unique(clusters, return_counts=True)
    out: dict[str, Any] = {
        "budget": budget, "problems": len(problems), "SOURCES": int(len(sources)),
        "singleton_sources": int((counts == 1).sum()), "draws": draws, "contrasts": [],
    }  # fmt: skip
    if len(sources) < MIN_SOURCES:
        out["insufficient"] = f"fewer than {MIN_SOURCES} independent sources"
        return out
    for pi in prevalences:
        for metric in CONTRAST_METRICS:
            values = np.array([row[pi][metric] for row in per_problem])
            out["contrasts"].append(
                {"prevalence": pi, "metric": metric}
                | bootstrap(values, clusters, by_cluster=True, draws=draws)
            )
    adjusted = holm([c["p_two_sided"] for c in out["contrasts"]])
    for item, value in zip(out["contrasts"], adjusted, strict=True):
        item["holm_p"] = value
    return out


def x_contrasts__mutmut_84(
    runs: list[dict[str, Any]],
    budget: float = 0.02,
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Change of the fixed threshold's behaviour from the observed prevalence to ``pi``.

    Per problem, the metrics of the threshold at ``pi`` minus its metrics at the problem's own
    held-out prevalence (the observed cell), averaged over the fits of all detectors and seeds
    that share the data. The independent unit is the original source, resampled as a whole; a
    contrast needs at least ``MIN_SOURCES`` sources. Holm adjusts over prevalence-metric pairs.
    """
    key = str(budget)
    problems, per_problem = [], []
    for run in runs:
        cells = [
            c
            for seeds in run["runs"].values()
            for s in seeds
            if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
            for c in [s["budgets"][key]]
        ]
        if not cells:
            continue
        rows = {}
        for pi in prevalences:
            observed = [
                shifted(c, (c["tp"] + c["fn"]) / (c["tp"] + c["fn"] + c["fp"] + c["tn"]))
                for c in cells
            ]
            moved = [shifted(c, pi) for c in cells]
            rows[pi] = {
                m: float(np.mean([a[m] - b[m] for a, b in zip(moved, observed, strict=True)]))
                for m in CONTRAST_METRICS
            }
        problems.append(run["problem"])
        per_problem.append(rows)
    clusters = np.array([source_id(p) for p in problems])
    sources, counts = np.unique(clusters, return_counts=True)
    out: dict[str, Any] = {
        "budget": budget, "problems": len(problems), "sources": int(None),
        "singleton_sources": int((counts == 1).sum()), "draws": draws, "contrasts": [],
    }  # fmt: skip
    if len(sources) < MIN_SOURCES:
        out["insufficient"] = f"fewer than {MIN_SOURCES} independent sources"
        return out
    for pi in prevalences:
        for metric in CONTRAST_METRICS:
            values = np.array([row[pi][metric] for row in per_problem])
            out["contrasts"].append(
                {"prevalence": pi, "metric": metric}
                | bootstrap(values, clusters, by_cluster=True, draws=draws)
            )
    adjusted = holm([c["p_two_sided"] for c in out["contrasts"]])
    for item, value in zip(out["contrasts"], adjusted, strict=True):
        item["holm_p"] = value
    return out


def x_contrasts__mutmut_85(
    runs: list[dict[str, Any]],
    budget: float = 0.02,
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Change of the fixed threshold's behaviour from the observed prevalence to ``pi``.

    Per problem, the metrics of the threshold at ``pi`` minus its metrics at the problem's own
    held-out prevalence (the observed cell), averaged over the fits of all detectors and seeds
    that share the data. The independent unit is the original source, resampled as a whole; a
    contrast needs at least ``MIN_SOURCES`` sources. Holm adjusts over prevalence-metric pairs.
    """
    key = str(budget)
    problems, per_problem = [], []
    for run in runs:
        cells = [
            c
            for seeds in run["runs"].values()
            for s in seeds
            if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
            for c in [s["budgets"][key]]
        ]
        if not cells:
            continue
        rows = {}
        for pi in prevalences:
            observed = [
                shifted(c, (c["tp"] + c["fn"]) / (c["tp"] + c["fn"] + c["fp"] + c["tn"]))
                for c in cells
            ]
            moved = [shifted(c, pi) for c in cells]
            rows[pi] = {
                m: float(np.mean([a[m] - b[m] for a, b in zip(moved, observed, strict=True)]))
                for m in CONTRAST_METRICS
            }
        problems.append(run["problem"])
        per_problem.append(rows)
    clusters = np.array([source_id(p) for p in problems])
    sources, counts = np.unique(clusters, return_counts=True)
    out: dict[str, Any] = {
        "budget": budget, "problems": len(problems), "sources": int(len(sources)),
        "XXsingleton_sourcesXX": int((counts == 1).sum()), "draws": draws, "contrasts": [],
    }  # fmt: skip
    if len(sources) < MIN_SOURCES:
        out["insufficient"] = f"fewer than {MIN_SOURCES} independent sources"
        return out
    for pi in prevalences:
        for metric in CONTRAST_METRICS:
            values = np.array([row[pi][metric] for row in per_problem])
            out["contrasts"].append(
                {"prevalence": pi, "metric": metric}
                | bootstrap(values, clusters, by_cluster=True, draws=draws)
            )
    adjusted = holm([c["p_two_sided"] for c in out["contrasts"]])
    for item, value in zip(out["contrasts"], adjusted, strict=True):
        item["holm_p"] = value
    return out


def x_contrasts__mutmut_86(
    runs: list[dict[str, Any]],
    budget: float = 0.02,
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Change of the fixed threshold's behaviour from the observed prevalence to ``pi``.

    Per problem, the metrics of the threshold at ``pi`` minus its metrics at the problem's own
    held-out prevalence (the observed cell), averaged over the fits of all detectors and seeds
    that share the data. The independent unit is the original source, resampled as a whole; a
    contrast needs at least ``MIN_SOURCES`` sources. Holm adjusts over prevalence-metric pairs.
    """
    key = str(budget)
    problems, per_problem = [], []
    for run in runs:
        cells = [
            c
            for seeds in run["runs"].values()
            for s in seeds
            if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
            for c in [s["budgets"][key]]
        ]
        if not cells:
            continue
        rows = {}
        for pi in prevalences:
            observed = [
                shifted(c, (c["tp"] + c["fn"]) / (c["tp"] + c["fn"] + c["fp"] + c["tn"]))
                for c in cells
            ]
            moved = [shifted(c, pi) for c in cells]
            rows[pi] = {
                m: float(np.mean([a[m] - b[m] for a, b in zip(moved, observed, strict=True)]))
                for m in CONTRAST_METRICS
            }
        problems.append(run["problem"])
        per_problem.append(rows)
    clusters = np.array([source_id(p) for p in problems])
    sources, counts = np.unique(clusters, return_counts=True)
    out: dict[str, Any] = {
        "budget": budget, "problems": len(problems), "sources": int(len(sources)),
        "SINGLETON_SOURCES": int((counts == 1).sum()), "draws": draws, "contrasts": [],
    }  # fmt: skip
    if len(sources) < MIN_SOURCES:
        out["insufficient"] = f"fewer than {MIN_SOURCES} independent sources"
        return out
    for pi in prevalences:
        for metric in CONTRAST_METRICS:
            values = np.array([row[pi][metric] for row in per_problem])
            out["contrasts"].append(
                {"prevalence": pi, "metric": metric}
                | bootstrap(values, clusters, by_cluster=True, draws=draws)
            )
    adjusted = holm([c["p_two_sided"] for c in out["contrasts"]])
    for item, value in zip(out["contrasts"], adjusted, strict=True):
        item["holm_p"] = value
    return out


def x_contrasts__mutmut_87(
    runs: list[dict[str, Any]],
    budget: float = 0.02,
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Change of the fixed threshold's behaviour from the observed prevalence to ``pi``.

    Per problem, the metrics of the threshold at ``pi`` minus its metrics at the problem's own
    held-out prevalence (the observed cell), averaged over the fits of all detectors and seeds
    that share the data. The independent unit is the original source, resampled as a whole; a
    contrast needs at least ``MIN_SOURCES`` sources. Holm adjusts over prevalence-metric pairs.
    """
    key = str(budget)
    problems, per_problem = [], []
    for run in runs:
        cells = [
            c
            for seeds in run["runs"].values()
            for s in seeds
            if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
            for c in [s["budgets"][key]]
        ]
        if not cells:
            continue
        rows = {}
        for pi in prevalences:
            observed = [
                shifted(c, (c["tp"] + c["fn"]) / (c["tp"] + c["fn"] + c["fp"] + c["tn"]))
                for c in cells
            ]
            moved = [shifted(c, pi) for c in cells]
            rows[pi] = {
                m: float(np.mean([a[m] - b[m] for a, b in zip(moved, observed, strict=True)]))
                for m in CONTRAST_METRICS
            }
        problems.append(run["problem"])
        per_problem.append(rows)
    clusters = np.array([source_id(p) for p in problems])
    sources, counts = np.unique(clusters, return_counts=True)
    out: dict[str, Any] = {
        "budget": budget, "problems": len(problems), "sources": int(len(sources)),
        "singleton_sources": int(None), "draws": draws, "contrasts": [],
    }  # fmt: skip
    if len(sources) < MIN_SOURCES:
        out["insufficient"] = f"fewer than {MIN_SOURCES} independent sources"
        return out
    for pi in prevalences:
        for metric in CONTRAST_METRICS:
            values = np.array([row[pi][metric] for row in per_problem])
            out["contrasts"].append(
                {"prevalence": pi, "metric": metric}
                | bootstrap(values, clusters, by_cluster=True, draws=draws)
            )
    adjusted = holm([c["p_two_sided"] for c in out["contrasts"]])
    for item, value in zip(out["contrasts"], adjusted, strict=True):
        item["holm_p"] = value
    return out


def x_contrasts__mutmut_88(
    runs: list[dict[str, Any]],
    budget: float = 0.02,
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Change of the fixed threshold's behaviour from the observed prevalence to ``pi``.

    Per problem, the metrics of the threshold at ``pi`` minus its metrics at the problem's own
    held-out prevalence (the observed cell), averaged over the fits of all detectors and seeds
    that share the data. The independent unit is the original source, resampled as a whole; a
    contrast needs at least ``MIN_SOURCES`` sources. Holm adjusts over prevalence-metric pairs.
    """
    key = str(budget)
    problems, per_problem = [], []
    for run in runs:
        cells = [
            c
            for seeds in run["runs"].values()
            for s in seeds
            if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
            for c in [s["budgets"][key]]
        ]
        if not cells:
            continue
        rows = {}
        for pi in prevalences:
            observed = [
                shifted(c, (c["tp"] + c["fn"]) / (c["tp"] + c["fn"] + c["fp"] + c["tn"]))
                for c in cells
            ]
            moved = [shifted(c, pi) for c in cells]
            rows[pi] = {
                m: float(np.mean([a[m] - b[m] for a, b in zip(moved, observed, strict=True)]))
                for m in CONTRAST_METRICS
            }
        problems.append(run["problem"])
        per_problem.append(rows)
    clusters = np.array([source_id(p) for p in problems])
    sources, counts = np.unique(clusters, return_counts=True)
    out: dict[str, Any] = {
        "budget": budget, "problems": len(problems), "sources": int(len(sources)),
        "singleton_sources": int((counts != 1).sum()), "draws": draws, "contrasts": [],
    }  # fmt: skip
    if len(sources) < MIN_SOURCES:
        out["insufficient"] = f"fewer than {MIN_SOURCES} independent sources"
        return out
    for pi in prevalences:
        for metric in CONTRAST_METRICS:
            values = np.array([row[pi][metric] for row in per_problem])
            out["contrasts"].append(
                {"prevalence": pi, "metric": metric}
                | bootstrap(values, clusters, by_cluster=True, draws=draws)
            )
    adjusted = holm([c["p_two_sided"] for c in out["contrasts"]])
    for item, value in zip(out["contrasts"], adjusted, strict=True):
        item["holm_p"] = value
    return out


def x_contrasts__mutmut_89(
    runs: list[dict[str, Any]],
    budget: float = 0.02,
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Change of the fixed threshold's behaviour from the observed prevalence to ``pi``.

    Per problem, the metrics of the threshold at ``pi`` minus its metrics at the problem's own
    held-out prevalence (the observed cell), averaged over the fits of all detectors and seeds
    that share the data. The independent unit is the original source, resampled as a whole; a
    contrast needs at least ``MIN_SOURCES`` sources. Holm adjusts over prevalence-metric pairs.
    """
    key = str(budget)
    problems, per_problem = [], []
    for run in runs:
        cells = [
            c
            for seeds in run["runs"].values()
            for s in seeds
            if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
            for c in [s["budgets"][key]]
        ]
        if not cells:
            continue
        rows = {}
        for pi in prevalences:
            observed = [
                shifted(c, (c["tp"] + c["fn"]) / (c["tp"] + c["fn"] + c["fp"] + c["tn"]))
                for c in cells
            ]
            moved = [shifted(c, pi) for c in cells]
            rows[pi] = {
                m: float(np.mean([a[m] - b[m] for a, b in zip(moved, observed, strict=True)]))
                for m in CONTRAST_METRICS
            }
        problems.append(run["problem"])
        per_problem.append(rows)
    clusters = np.array([source_id(p) for p in problems])
    sources, counts = np.unique(clusters, return_counts=True)
    out: dict[str, Any] = {
        "budget": budget, "problems": len(problems), "sources": int(len(sources)),
        "singleton_sources": int((counts == 2).sum()), "draws": draws, "contrasts": [],
    }  # fmt: skip
    if len(sources) < MIN_SOURCES:
        out["insufficient"] = f"fewer than {MIN_SOURCES} independent sources"
        return out
    for pi in prevalences:
        for metric in CONTRAST_METRICS:
            values = np.array([row[pi][metric] for row in per_problem])
            out["contrasts"].append(
                {"prevalence": pi, "metric": metric}
                | bootstrap(values, clusters, by_cluster=True, draws=draws)
            )
    adjusted = holm([c["p_two_sided"] for c in out["contrasts"]])
    for item, value in zip(out["contrasts"], adjusted, strict=True):
        item["holm_p"] = value
    return out


def x_contrasts__mutmut_90(
    runs: list[dict[str, Any]],
    budget: float = 0.02,
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Change of the fixed threshold's behaviour from the observed prevalence to ``pi``.

    Per problem, the metrics of the threshold at ``pi`` minus its metrics at the problem's own
    held-out prevalence (the observed cell), averaged over the fits of all detectors and seeds
    that share the data. The independent unit is the original source, resampled as a whole; a
    contrast needs at least ``MIN_SOURCES`` sources. Holm adjusts over prevalence-metric pairs.
    """
    key = str(budget)
    problems, per_problem = [], []
    for run in runs:
        cells = [
            c
            for seeds in run["runs"].values()
            for s in seeds
            if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
            for c in [s["budgets"][key]]
        ]
        if not cells:
            continue
        rows = {}
        for pi in prevalences:
            observed = [
                shifted(c, (c["tp"] + c["fn"]) / (c["tp"] + c["fn"] + c["fp"] + c["tn"]))
                for c in cells
            ]
            moved = [shifted(c, pi) for c in cells]
            rows[pi] = {
                m: float(np.mean([a[m] - b[m] for a, b in zip(moved, observed, strict=True)]))
                for m in CONTRAST_METRICS
            }
        problems.append(run["problem"])
        per_problem.append(rows)
    clusters = np.array([source_id(p) for p in problems])
    sources, counts = np.unique(clusters, return_counts=True)
    out: dict[str, Any] = {
        "budget": budget, "problems": len(problems), "sources": int(len(sources)),
        "singleton_sources": int((counts == 1).sum()), "XXdrawsXX": draws, "contrasts": [],
    }  # fmt: skip
    if len(sources) < MIN_SOURCES:
        out["insufficient"] = f"fewer than {MIN_SOURCES} independent sources"
        return out
    for pi in prevalences:
        for metric in CONTRAST_METRICS:
            values = np.array([row[pi][metric] for row in per_problem])
            out["contrasts"].append(
                {"prevalence": pi, "metric": metric}
                | bootstrap(values, clusters, by_cluster=True, draws=draws)
            )
    adjusted = holm([c["p_two_sided"] for c in out["contrasts"]])
    for item, value in zip(out["contrasts"], adjusted, strict=True):
        item["holm_p"] = value
    return out


def x_contrasts__mutmut_91(
    runs: list[dict[str, Any]],
    budget: float = 0.02,
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Change of the fixed threshold's behaviour from the observed prevalence to ``pi``.

    Per problem, the metrics of the threshold at ``pi`` minus its metrics at the problem's own
    held-out prevalence (the observed cell), averaged over the fits of all detectors and seeds
    that share the data. The independent unit is the original source, resampled as a whole; a
    contrast needs at least ``MIN_SOURCES`` sources. Holm adjusts over prevalence-metric pairs.
    """
    key = str(budget)
    problems, per_problem = [], []
    for run in runs:
        cells = [
            c
            for seeds in run["runs"].values()
            for s in seeds
            if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
            for c in [s["budgets"][key]]
        ]
        if not cells:
            continue
        rows = {}
        for pi in prevalences:
            observed = [
                shifted(c, (c["tp"] + c["fn"]) / (c["tp"] + c["fn"] + c["fp"] + c["tn"]))
                for c in cells
            ]
            moved = [shifted(c, pi) for c in cells]
            rows[pi] = {
                m: float(np.mean([a[m] - b[m] for a, b in zip(moved, observed, strict=True)]))
                for m in CONTRAST_METRICS
            }
        problems.append(run["problem"])
        per_problem.append(rows)
    clusters = np.array([source_id(p) for p in problems])
    sources, counts = np.unique(clusters, return_counts=True)
    out: dict[str, Any] = {
        "budget": budget, "problems": len(problems), "sources": int(len(sources)),
        "singleton_sources": int((counts == 1).sum()), "DRAWS": draws, "contrasts": [],
    }  # fmt: skip
    if len(sources) < MIN_SOURCES:
        out["insufficient"] = f"fewer than {MIN_SOURCES} independent sources"
        return out
    for pi in prevalences:
        for metric in CONTRAST_METRICS:
            values = np.array([row[pi][metric] for row in per_problem])
            out["contrasts"].append(
                {"prevalence": pi, "metric": metric}
                | bootstrap(values, clusters, by_cluster=True, draws=draws)
            )
    adjusted = holm([c["p_two_sided"] for c in out["contrasts"]])
    for item, value in zip(out["contrasts"], adjusted, strict=True):
        item["holm_p"] = value
    return out


def x_contrasts__mutmut_92(
    runs: list[dict[str, Any]],
    budget: float = 0.02,
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Change of the fixed threshold's behaviour from the observed prevalence to ``pi``.

    Per problem, the metrics of the threshold at ``pi`` minus its metrics at the problem's own
    held-out prevalence (the observed cell), averaged over the fits of all detectors and seeds
    that share the data. The independent unit is the original source, resampled as a whole; a
    contrast needs at least ``MIN_SOURCES`` sources. Holm adjusts over prevalence-metric pairs.
    """
    key = str(budget)
    problems, per_problem = [], []
    for run in runs:
        cells = [
            c
            for seeds in run["runs"].values()
            for s in seeds
            if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
            for c in [s["budgets"][key]]
        ]
        if not cells:
            continue
        rows = {}
        for pi in prevalences:
            observed = [
                shifted(c, (c["tp"] + c["fn"]) / (c["tp"] + c["fn"] + c["fp"] + c["tn"]))
                for c in cells
            ]
            moved = [shifted(c, pi) for c in cells]
            rows[pi] = {
                m: float(np.mean([a[m] - b[m] for a, b in zip(moved, observed, strict=True)]))
                for m in CONTRAST_METRICS
            }
        problems.append(run["problem"])
        per_problem.append(rows)
    clusters = np.array([source_id(p) for p in problems])
    sources, counts = np.unique(clusters, return_counts=True)
    out: dict[str, Any] = {
        "budget": budget, "problems": len(problems), "sources": int(len(sources)),
        "singleton_sources": int((counts == 1).sum()), "draws": draws, "XXcontrastsXX": [],
    }  # fmt: skip
    if len(sources) < MIN_SOURCES:
        out["insufficient"] = f"fewer than {MIN_SOURCES} independent sources"
        return out
    for pi in prevalences:
        for metric in CONTRAST_METRICS:
            values = np.array([row[pi][metric] for row in per_problem])
            out["contrasts"].append(
                {"prevalence": pi, "metric": metric}
                | bootstrap(values, clusters, by_cluster=True, draws=draws)
            )
    adjusted = holm([c["p_two_sided"] for c in out["contrasts"]])
    for item, value in zip(out["contrasts"], adjusted, strict=True):
        item["holm_p"] = value
    return out


def x_contrasts__mutmut_93(
    runs: list[dict[str, Any]],
    budget: float = 0.02,
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Change of the fixed threshold's behaviour from the observed prevalence to ``pi``.

    Per problem, the metrics of the threshold at ``pi`` minus its metrics at the problem's own
    held-out prevalence (the observed cell), averaged over the fits of all detectors and seeds
    that share the data. The independent unit is the original source, resampled as a whole; a
    contrast needs at least ``MIN_SOURCES`` sources. Holm adjusts over prevalence-metric pairs.
    """
    key = str(budget)
    problems, per_problem = [], []
    for run in runs:
        cells = [
            c
            for seeds in run["runs"].values()
            for s in seeds
            if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
            for c in [s["budgets"][key]]
        ]
        if not cells:
            continue
        rows = {}
        for pi in prevalences:
            observed = [
                shifted(c, (c["tp"] + c["fn"]) / (c["tp"] + c["fn"] + c["fp"] + c["tn"]))
                for c in cells
            ]
            moved = [shifted(c, pi) for c in cells]
            rows[pi] = {
                m: float(np.mean([a[m] - b[m] for a, b in zip(moved, observed, strict=True)]))
                for m in CONTRAST_METRICS
            }
        problems.append(run["problem"])
        per_problem.append(rows)
    clusters = np.array([source_id(p) for p in problems])
    sources, counts = np.unique(clusters, return_counts=True)
    out: dict[str, Any] = {
        "budget": budget, "problems": len(problems), "sources": int(len(sources)),
        "singleton_sources": int((counts == 1).sum()), "draws": draws, "CONTRASTS": [],
    }  # fmt: skip
    if len(sources) < MIN_SOURCES:
        out["insufficient"] = f"fewer than {MIN_SOURCES} independent sources"
        return out
    for pi in prevalences:
        for metric in CONTRAST_METRICS:
            values = np.array([row[pi][metric] for row in per_problem])
            out["contrasts"].append(
                {"prevalence": pi, "metric": metric}
                | bootstrap(values, clusters, by_cluster=True, draws=draws)
            )
    adjusted = holm([c["p_two_sided"] for c in out["contrasts"]])
    for item, value in zip(out["contrasts"], adjusted, strict=True):
        item["holm_p"] = value
    return out


def x_contrasts__mutmut_94(
    runs: list[dict[str, Any]],
    budget: float = 0.02,
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Change of the fixed threshold's behaviour from the observed prevalence to ``pi``.

    Per problem, the metrics of the threshold at ``pi`` minus its metrics at the problem's own
    held-out prevalence (the observed cell), averaged over the fits of all detectors and seeds
    that share the data. The independent unit is the original source, resampled as a whole; a
    contrast needs at least ``MIN_SOURCES`` sources. Holm adjusts over prevalence-metric pairs.
    """
    key = str(budget)
    problems, per_problem = [], []
    for run in runs:
        cells = [
            c
            for seeds in run["runs"].values()
            for s in seeds
            if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
            for c in [s["budgets"][key]]
        ]
        if not cells:
            continue
        rows = {}
        for pi in prevalences:
            observed = [
                shifted(c, (c["tp"] + c["fn"]) / (c["tp"] + c["fn"] + c["fp"] + c["tn"]))
                for c in cells
            ]
            moved = [shifted(c, pi) for c in cells]
            rows[pi] = {
                m: float(np.mean([a[m] - b[m] for a, b in zip(moved, observed, strict=True)]))
                for m in CONTRAST_METRICS
            }
        problems.append(run["problem"])
        per_problem.append(rows)
    clusters = np.array([source_id(p) for p in problems])
    sources, counts = np.unique(clusters, return_counts=True)
    out: dict[str, Any] = {
        "budget": budget, "problems": len(problems), "sources": int(len(sources)),
        "singleton_sources": int((counts == 1).sum()), "draws": draws, "contrasts": [],
    }  # fmt: skip
    if len(sources) <= MIN_SOURCES:
        out["insufficient"] = f"fewer than {MIN_SOURCES} independent sources"
        return out
    for pi in prevalences:
        for metric in CONTRAST_METRICS:
            values = np.array([row[pi][metric] for row in per_problem])
            out["contrasts"].append(
                {"prevalence": pi, "metric": metric}
                | bootstrap(values, clusters, by_cluster=True, draws=draws)
            )
    adjusted = holm([c["p_two_sided"] for c in out["contrasts"]])
    for item, value in zip(out["contrasts"], adjusted, strict=True):
        item["holm_p"] = value
    return out


def x_contrasts__mutmut_95(
    runs: list[dict[str, Any]],
    budget: float = 0.02,
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Change of the fixed threshold's behaviour from the observed prevalence to ``pi``.

    Per problem, the metrics of the threshold at ``pi`` minus its metrics at the problem's own
    held-out prevalence (the observed cell), averaged over the fits of all detectors and seeds
    that share the data. The independent unit is the original source, resampled as a whole; a
    contrast needs at least ``MIN_SOURCES`` sources. Holm adjusts over prevalence-metric pairs.
    """
    key = str(budget)
    problems, per_problem = [], []
    for run in runs:
        cells = [
            c
            for seeds in run["runs"].values()
            for s in seeds
            if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
            for c in [s["budgets"][key]]
        ]
        if not cells:
            continue
        rows = {}
        for pi in prevalences:
            observed = [
                shifted(c, (c["tp"] + c["fn"]) / (c["tp"] + c["fn"] + c["fp"] + c["tn"]))
                for c in cells
            ]
            moved = [shifted(c, pi) for c in cells]
            rows[pi] = {
                m: float(np.mean([a[m] - b[m] for a, b in zip(moved, observed, strict=True)]))
                for m in CONTRAST_METRICS
            }
        problems.append(run["problem"])
        per_problem.append(rows)
    clusters = np.array([source_id(p) for p in problems])
    sources, counts = np.unique(clusters, return_counts=True)
    out: dict[str, Any] = {
        "budget": budget, "problems": len(problems), "sources": int(len(sources)),
        "singleton_sources": int((counts == 1).sum()), "draws": draws, "contrasts": [],
    }  # fmt: skip
    if len(sources) < MIN_SOURCES:
        out["insufficient"] = None
        return out
    for pi in prevalences:
        for metric in CONTRAST_METRICS:
            values = np.array([row[pi][metric] for row in per_problem])
            out["contrasts"].append(
                {"prevalence": pi, "metric": metric}
                | bootstrap(values, clusters, by_cluster=True, draws=draws)
            )
    adjusted = holm([c["p_two_sided"] for c in out["contrasts"]])
    for item, value in zip(out["contrasts"], adjusted, strict=True):
        item["holm_p"] = value
    return out


def x_contrasts__mutmut_96(
    runs: list[dict[str, Any]],
    budget: float = 0.02,
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Change of the fixed threshold's behaviour from the observed prevalence to ``pi``.

    Per problem, the metrics of the threshold at ``pi`` minus its metrics at the problem's own
    held-out prevalence (the observed cell), averaged over the fits of all detectors and seeds
    that share the data. The independent unit is the original source, resampled as a whole; a
    contrast needs at least ``MIN_SOURCES`` sources. Holm adjusts over prevalence-metric pairs.
    """
    key = str(budget)
    problems, per_problem = [], []
    for run in runs:
        cells = [
            c
            for seeds in run["runs"].values()
            for s in seeds
            if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
            for c in [s["budgets"][key]]
        ]
        if not cells:
            continue
        rows = {}
        for pi in prevalences:
            observed = [
                shifted(c, (c["tp"] + c["fn"]) / (c["tp"] + c["fn"] + c["fp"] + c["tn"]))
                for c in cells
            ]
            moved = [shifted(c, pi) for c in cells]
            rows[pi] = {
                m: float(np.mean([a[m] - b[m] for a, b in zip(moved, observed, strict=True)]))
                for m in CONTRAST_METRICS
            }
        problems.append(run["problem"])
        per_problem.append(rows)
    clusters = np.array([source_id(p) for p in problems])
    sources, counts = np.unique(clusters, return_counts=True)
    out: dict[str, Any] = {
        "budget": budget, "problems": len(problems), "sources": int(len(sources)),
        "singleton_sources": int((counts == 1).sum()), "draws": draws, "contrasts": [],
    }  # fmt: skip
    if len(sources) < MIN_SOURCES:
        out["XXinsufficientXX"] = f"fewer than {MIN_SOURCES} independent sources"
        return out
    for pi in prevalences:
        for metric in CONTRAST_METRICS:
            values = np.array([row[pi][metric] for row in per_problem])
            out["contrasts"].append(
                {"prevalence": pi, "metric": metric}
                | bootstrap(values, clusters, by_cluster=True, draws=draws)
            )
    adjusted = holm([c["p_two_sided"] for c in out["contrasts"]])
    for item, value in zip(out["contrasts"], adjusted, strict=True):
        item["holm_p"] = value
    return out


def x_contrasts__mutmut_97(
    runs: list[dict[str, Any]],
    budget: float = 0.02,
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Change of the fixed threshold's behaviour from the observed prevalence to ``pi``.

    Per problem, the metrics of the threshold at ``pi`` minus its metrics at the problem's own
    held-out prevalence (the observed cell), averaged over the fits of all detectors and seeds
    that share the data. The independent unit is the original source, resampled as a whole; a
    contrast needs at least ``MIN_SOURCES`` sources. Holm adjusts over prevalence-metric pairs.
    """
    key = str(budget)
    problems, per_problem = [], []
    for run in runs:
        cells = [
            c
            for seeds in run["runs"].values()
            for s in seeds
            if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
            for c in [s["budgets"][key]]
        ]
        if not cells:
            continue
        rows = {}
        for pi in prevalences:
            observed = [
                shifted(c, (c["tp"] + c["fn"]) / (c["tp"] + c["fn"] + c["fp"] + c["tn"]))
                for c in cells
            ]
            moved = [shifted(c, pi) for c in cells]
            rows[pi] = {
                m: float(np.mean([a[m] - b[m] for a, b in zip(moved, observed, strict=True)]))
                for m in CONTRAST_METRICS
            }
        problems.append(run["problem"])
        per_problem.append(rows)
    clusters = np.array([source_id(p) for p in problems])
    sources, counts = np.unique(clusters, return_counts=True)
    out: dict[str, Any] = {
        "budget": budget, "problems": len(problems), "sources": int(len(sources)),
        "singleton_sources": int((counts == 1).sum()), "draws": draws, "contrasts": [],
    }  # fmt: skip
    if len(sources) < MIN_SOURCES:
        out["INSUFFICIENT"] = f"fewer than {MIN_SOURCES} independent sources"
        return out
    for pi in prevalences:
        for metric in CONTRAST_METRICS:
            values = np.array([row[pi][metric] for row in per_problem])
            out["contrasts"].append(
                {"prevalence": pi, "metric": metric}
                | bootstrap(values, clusters, by_cluster=True, draws=draws)
            )
    adjusted = holm([c["p_two_sided"] for c in out["contrasts"]])
    for item, value in zip(out["contrasts"], adjusted, strict=True):
        item["holm_p"] = value
    return out


def x_contrasts__mutmut_98(
    runs: list[dict[str, Any]],
    budget: float = 0.02,
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Change of the fixed threshold's behaviour from the observed prevalence to ``pi``.

    Per problem, the metrics of the threshold at ``pi`` minus its metrics at the problem's own
    held-out prevalence (the observed cell), averaged over the fits of all detectors and seeds
    that share the data. The independent unit is the original source, resampled as a whole; a
    contrast needs at least ``MIN_SOURCES`` sources. Holm adjusts over prevalence-metric pairs.
    """
    key = str(budget)
    problems, per_problem = [], []
    for run in runs:
        cells = [
            c
            for seeds in run["runs"].values()
            for s in seeds
            if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
            for c in [s["budgets"][key]]
        ]
        if not cells:
            continue
        rows = {}
        for pi in prevalences:
            observed = [
                shifted(c, (c["tp"] + c["fn"]) / (c["tp"] + c["fn"] + c["fp"] + c["tn"]))
                for c in cells
            ]
            moved = [shifted(c, pi) for c in cells]
            rows[pi] = {
                m: float(np.mean([a[m] - b[m] for a, b in zip(moved, observed, strict=True)]))
                for m in CONTRAST_METRICS
            }
        problems.append(run["problem"])
        per_problem.append(rows)
    clusters = np.array([source_id(p) for p in problems])
    sources, counts = np.unique(clusters, return_counts=True)
    out: dict[str, Any] = {
        "budget": budget, "problems": len(problems), "sources": int(len(sources)),
        "singleton_sources": int((counts == 1).sum()), "draws": draws, "contrasts": [],
    }  # fmt: skip
    if len(sources) < MIN_SOURCES:
        out["insufficient"] = f"fewer than {MIN_SOURCES} independent sources"
        return out
    for pi in prevalences:
        for metric in CONTRAST_METRICS:
            values = None
            out["contrasts"].append(
                {"prevalence": pi, "metric": metric}
                | bootstrap(values, clusters, by_cluster=True, draws=draws)
            )
    adjusted = holm([c["p_two_sided"] for c in out["contrasts"]])
    for item, value in zip(out["contrasts"], adjusted, strict=True):
        item["holm_p"] = value
    return out


def x_contrasts__mutmut_99(
    runs: list[dict[str, Any]],
    budget: float = 0.02,
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Change of the fixed threshold's behaviour from the observed prevalence to ``pi``.

    Per problem, the metrics of the threshold at ``pi`` minus its metrics at the problem's own
    held-out prevalence (the observed cell), averaged over the fits of all detectors and seeds
    that share the data. The independent unit is the original source, resampled as a whole; a
    contrast needs at least ``MIN_SOURCES`` sources. Holm adjusts over prevalence-metric pairs.
    """
    key = str(budget)
    problems, per_problem = [], []
    for run in runs:
        cells = [
            c
            for seeds in run["runs"].values()
            for s in seeds
            if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
            for c in [s["budgets"][key]]
        ]
        if not cells:
            continue
        rows = {}
        for pi in prevalences:
            observed = [
                shifted(c, (c["tp"] + c["fn"]) / (c["tp"] + c["fn"] + c["fp"] + c["tn"]))
                for c in cells
            ]
            moved = [shifted(c, pi) for c in cells]
            rows[pi] = {
                m: float(np.mean([a[m] - b[m] for a, b in zip(moved, observed, strict=True)]))
                for m in CONTRAST_METRICS
            }
        problems.append(run["problem"])
        per_problem.append(rows)
    clusters = np.array([source_id(p) for p in problems])
    sources, counts = np.unique(clusters, return_counts=True)
    out: dict[str, Any] = {
        "budget": budget, "problems": len(problems), "sources": int(len(sources)),
        "singleton_sources": int((counts == 1).sum()), "draws": draws, "contrasts": [],
    }  # fmt: skip
    if len(sources) < MIN_SOURCES:
        out["insufficient"] = f"fewer than {MIN_SOURCES} independent sources"
        return out
    for pi in prevalences:
        for metric in CONTRAST_METRICS:
            values = np.array(None)
            out["contrasts"].append(
                {"prevalence": pi, "metric": metric}
                | bootstrap(values, clusters, by_cluster=True, draws=draws)
            )
    adjusted = holm([c["p_two_sided"] for c in out["contrasts"]])
    for item, value in zip(out["contrasts"], adjusted, strict=True):
        item["holm_p"] = value
    return out


def x_contrasts__mutmut_100(
    runs: list[dict[str, Any]],
    budget: float = 0.02,
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Change of the fixed threshold's behaviour from the observed prevalence to ``pi``.

    Per problem, the metrics of the threshold at ``pi`` minus its metrics at the problem's own
    held-out prevalence (the observed cell), averaged over the fits of all detectors and seeds
    that share the data. The independent unit is the original source, resampled as a whole; a
    contrast needs at least ``MIN_SOURCES`` sources. Holm adjusts over prevalence-metric pairs.
    """
    key = str(budget)
    problems, per_problem = [], []
    for run in runs:
        cells = [
            c
            for seeds in run["runs"].values()
            for s in seeds
            if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
            for c in [s["budgets"][key]]
        ]
        if not cells:
            continue
        rows = {}
        for pi in prevalences:
            observed = [
                shifted(c, (c["tp"] + c["fn"]) / (c["tp"] + c["fn"] + c["fp"] + c["tn"]))
                for c in cells
            ]
            moved = [shifted(c, pi) for c in cells]
            rows[pi] = {
                m: float(np.mean([a[m] - b[m] for a, b in zip(moved, observed, strict=True)]))
                for m in CONTRAST_METRICS
            }
        problems.append(run["problem"])
        per_problem.append(rows)
    clusters = np.array([source_id(p) for p in problems])
    sources, counts = np.unique(clusters, return_counts=True)
    out: dict[str, Any] = {
        "budget": budget, "problems": len(problems), "sources": int(len(sources)),
        "singleton_sources": int((counts == 1).sum()), "draws": draws, "contrasts": [],
    }  # fmt: skip
    if len(sources) < MIN_SOURCES:
        out["insufficient"] = f"fewer than {MIN_SOURCES} independent sources"
        return out
    for pi in prevalences:
        for metric in CONTRAST_METRICS:
            values = np.array([row[pi][metric] for row in per_problem])
            out["contrasts"].append(
                None
            )
    adjusted = holm([c["p_two_sided"] for c in out["contrasts"]])
    for item, value in zip(out["contrasts"], adjusted, strict=True):
        item["holm_p"] = value
    return out


def x_contrasts__mutmut_101(
    runs: list[dict[str, Any]],
    budget: float = 0.02,
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Change of the fixed threshold's behaviour from the observed prevalence to ``pi``.

    Per problem, the metrics of the threshold at ``pi`` minus its metrics at the problem's own
    held-out prevalence (the observed cell), averaged over the fits of all detectors and seeds
    that share the data. The independent unit is the original source, resampled as a whole; a
    contrast needs at least ``MIN_SOURCES`` sources. Holm adjusts over prevalence-metric pairs.
    """
    key = str(budget)
    problems, per_problem = [], []
    for run in runs:
        cells = [
            c
            for seeds in run["runs"].values()
            for s in seeds
            if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
            for c in [s["budgets"][key]]
        ]
        if not cells:
            continue
        rows = {}
        for pi in prevalences:
            observed = [
                shifted(c, (c["tp"] + c["fn"]) / (c["tp"] + c["fn"] + c["fp"] + c["tn"]))
                for c in cells
            ]
            moved = [shifted(c, pi) for c in cells]
            rows[pi] = {
                m: float(np.mean([a[m] - b[m] for a, b in zip(moved, observed, strict=True)]))
                for m in CONTRAST_METRICS
            }
        problems.append(run["problem"])
        per_problem.append(rows)
    clusters = np.array([source_id(p) for p in problems])
    sources, counts = np.unique(clusters, return_counts=True)
    out: dict[str, Any] = {
        "budget": budget, "problems": len(problems), "sources": int(len(sources)),
        "singleton_sources": int((counts == 1).sum()), "draws": draws, "contrasts": [],
    }  # fmt: skip
    if len(sources) < MIN_SOURCES:
        out["insufficient"] = f"fewer than {MIN_SOURCES} independent sources"
        return out
    for pi in prevalences:
        for metric in CONTRAST_METRICS:
            values = np.array([row[pi][metric] for row in per_problem])
            out["XXcontrastsXX"].append(
                {"prevalence": pi, "metric": metric}
                | bootstrap(values, clusters, by_cluster=True, draws=draws)
            )
    adjusted = holm([c["p_two_sided"] for c in out["contrasts"]])
    for item, value in zip(out["contrasts"], adjusted, strict=True):
        item["holm_p"] = value
    return out


def x_contrasts__mutmut_102(
    runs: list[dict[str, Any]],
    budget: float = 0.02,
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Change of the fixed threshold's behaviour from the observed prevalence to ``pi``.

    Per problem, the metrics of the threshold at ``pi`` minus its metrics at the problem's own
    held-out prevalence (the observed cell), averaged over the fits of all detectors and seeds
    that share the data. The independent unit is the original source, resampled as a whole; a
    contrast needs at least ``MIN_SOURCES`` sources. Holm adjusts over prevalence-metric pairs.
    """
    key = str(budget)
    problems, per_problem = [], []
    for run in runs:
        cells = [
            c
            for seeds in run["runs"].values()
            for s in seeds
            if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
            for c in [s["budgets"][key]]
        ]
        if not cells:
            continue
        rows = {}
        for pi in prevalences:
            observed = [
                shifted(c, (c["tp"] + c["fn"]) / (c["tp"] + c["fn"] + c["fp"] + c["tn"]))
                for c in cells
            ]
            moved = [shifted(c, pi) for c in cells]
            rows[pi] = {
                m: float(np.mean([a[m] - b[m] for a, b in zip(moved, observed, strict=True)]))
                for m in CONTRAST_METRICS
            }
        problems.append(run["problem"])
        per_problem.append(rows)
    clusters = np.array([source_id(p) for p in problems])
    sources, counts = np.unique(clusters, return_counts=True)
    out: dict[str, Any] = {
        "budget": budget, "problems": len(problems), "sources": int(len(sources)),
        "singleton_sources": int((counts == 1).sum()), "draws": draws, "contrasts": [],
    }  # fmt: skip
    if len(sources) < MIN_SOURCES:
        out["insufficient"] = f"fewer than {MIN_SOURCES} independent sources"
        return out
    for pi in prevalences:
        for metric in CONTRAST_METRICS:
            values = np.array([row[pi][metric] for row in per_problem])
            out["CONTRASTS"].append(
                {"prevalence": pi, "metric": metric}
                | bootstrap(values, clusters, by_cluster=True, draws=draws)
            )
    adjusted = holm([c["p_two_sided"] for c in out["contrasts"]])
    for item, value in zip(out["contrasts"], adjusted, strict=True):
        item["holm_p"] = value
    return out


def x_contrasts__mutmut_103(
    runs: list[dict[str, Any]],
    budget: float = 0.02,
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Change of the fixed threshold's behaviour from the observed prevalence to ``pi``.

    Per problem, the metrics of the threshold at ``pi`` minus its metrics at the problem's own
    held-out prevalence (the observed cell), averaged over the fits of all detectors and seeds
    that share the data. The independent unit is the original source, resampled as a whole; a
    contrast needs at least ``MIN_SOURCES`` sources. Holm adjusts over prevalence-metric pairs.
    """
    key = str(budget)
    problems, per_problem = [], []
    for run in runs:
        cells = [
            c
            for seeds in run["runs"].values()
            for s in seeds
            if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
            for c in [s["budgets"][key]]
        ]
        if not cells:
            continue
        rows = {}
        for pi in prevalences:
            observed = [
                shifted(c, (c["tp"] + c["fn"]) / (c["tp"] + c["fn"] + c["fp"] + c["tn"]))
                for c in cells
            ]
            moved = [shifted(c, pi) for c in cells]
            rows[pi] = {
                m: float(np.mean([a[m] - b[m] for a, b in zip(moved, observed, strict=True)]))
                for m in CONTRAST_METRICS
            }
        problems.append(run["problem"])
        per_problem.append(rows)
    clusters = np.array([source_id(p) for p in problems])
    sources, counts = np.unique(clusters, return_counts=True)
    out: dict[str, Any] = {
        "budget": budget, "problems": len(problems), "sources": int(len(sources)),
        "singleton_sources": int((counts == 1).sum()), "draws": draws, "contrasts": [],
    }  # fmt: skip
    if len(sources) < MIN_SOURCES:
        out["insufficient"] = f"fewer than {MIN_SOURCES} independent sources"
        return out
    for pi in prevalences:
        for metric in CONTRAST_METRICS:
            values = np.array([row[pi][metric] for row in per_problem])
            out["contrasts"].append(
                {"prevalence": pi, "metric": metric} & bootstrap(values, clusters, by_cluster=True, draws=draws)
            )
    adjusted = holm([c["p_two_sided"] for c in out["contrasts"]])
    for item, value in zip(out["contrasts"], adjusted, strict=True):
        item["holm_p"] = value
    return out


def x_contrasts__mutmut_104(
    runs: list[dict[str, Any]],
    budget: float = 0.02,
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Change of the fixed threshold's behaviour from the observed prevalence to ``pi``.

    Per problem, the metrics of the threshold at ``pi`` minus its metrics at the problem's own
    held-out prevalence (the observed cell), averaged over the fits of all detectors and seeds
    that share the data. The independent unit is the original source, resampled as a whole; a
    contrast needs at least ``MIN_SOURCES`` sources. Holm adjusts over prevalence-metric pairs.
    """
    key = str(budget)
    problems, per_problem = [], []
    for run in runs:
        cells = [
            c
            for seeds in run["runs"].values()
            for s in seeds
            if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
            for c in [s["budgets"][key]]
        ]
        if not cells:
            continue
        rows = {}
        for pi in prevalences:
            observed = [
                shifted(c, (c["tp"] + c["fn"]) / (c["tp"] + c["fn"] + c["fp"] + c["tn"]))
                for c in cells
            ]
            moved = [shifted(c, pi) for c in cells]
            rows[pi] = {
                m: float(np.mean([a[m] - b[m] for a, b in zip(moved, observed, strict=True)]))
                for m in CONTRAST_METRICS
            }
        problems.append(run["problem"])
        per_problem.append(rows)
    clusters = np.array([source_id(p) for p in problems])
    sources, counts = np.unique(clusters, return_counts=True)
    out: dict[str, Any] = {
        "budget": budget, "problems": len(problems), "sources": int(len(sources)),
        "singleton_sources": int((counts == 1).sum()), "draws": draws, "contrasts": [],
    }  # fmt: skip
    if len(sources) < MIN_SOURCES:
        out["insufficient"] = f"fewer than {MIN_SOURCES} independent sources"
        return out
    for pi in prevalences:
        for metric in CONTRAST_METRICS:
            values = np.array([row[pi][metric] for row in per_problem])
            out["contrasts"].append(
                {"XXprevalenceXX": pi, "metric": metric}
                | bootstrap(values, clusters, by_cluster=True, draws=draws)
            )
    adjusted = holm([c["p_two_sided"] for c in out["contrasts"]])
    for item, value in zip(out["contrasts"], adjusted, strict=True):
        item["holm_p"] = value
    return out


def x_contrasts__mutmut_105(
    runs: list[dict[str, Any]],
    budget: float = 0.02,
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Change of the fixed threshold's behaviour from the observed prevalence to ``pi``.

    Per problem, the metrics of the threshold at ``pi`` minus its metrics at the problem's own
    held-out prevalence (the observed cell), averaged over the fits of all detectors and seeds
    that share the data. The independent unit is the original source, resampled as a whole; a
    contrast needs at least ``MIN_SOURCES`` sources. Holm adjusts over prevalence-metric pairs.
    """
    key = str(budget)
    problems, per_problem = [], []
    for run in runs:
        cells = [
            c
            for seeds in run["runs"].values()
            for s in seeds
            if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
            for c in [s["budgets"][key]]
        ]
        if not cells:
            continue
        rows = {}
        for pi in prevalences:
            observed = [
                shifted(c, (c["tp"] + c["fn"]) / (c["tp"] + c["fn"] + c["fp"] + c["tn"]))
                for c in cells
            ]
            moved = [shifted(c, pi) for c in cells]
            rows[pi] = {
                m: float(np.mean([a[m] - b[m] for a, b in zip(moved, observed, strict=True)]))
                for m in CONTRAST_METRICS
            }
        problems.append(run["problem"])
        per_problem.append(rows)
    clusters = np.array([source_id(p) for p in problems])
    sources, counts = np.unique(clusters, return_counts=True)
    out: dict[str, Any] = {
        "budget": budget, "problems": len(problems), "sources": int(len(sources)),
        "singleton_sources": int((counts == 1).sum()), "draws": draws, "contrasts": [],
    }  # fmt: skip
    if len(sources) < MIN_SOURCES:
        out["insufficient"] = f"fewer than {MIN_SOURCES} independent sources"
        return out
    for pi in prevalences:
        for metric in CONTRAST_METRICS:
            values = np.array([row[pi][metric] for row in per_problem])
            out["contrasts"].append(
                {"PREVALENCE": pi, "metric": metric}
                | bootstrap(values, clusters, by_cluster=True, draws=draws)
            )
    adjusted = holm([c["p_two_sided"] for c in out["contrasts"]])
    for item, value in zip(out["contrasts"], adjusted, strict=True):
        item["holm_p"] = value
    return out


def x_contrasts__mutmut_106(
    runs: list[dict[str, Any]],
    budget: float = 0.02,
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Change of the fixed threshold's behaviour from the observed prevalence to ``pi``.

    Per problem, the metrics of the threshold at ``pi`` minus its metrics at the problem's own
    held-out prevalence (the observed cell), averaged over the fits of all detectors and seeds
    that share the data. The independent unit is the original source, resampled as a whole; a
    contrast needs at least ``MIN_SOURCES`` sources. Holm adjusts over prevalence-metric pairs.
    """
    key = str(budget)
    problems, per_problem = [], []
    for run in runs:
        cells = [
            c
            for seeds in run["runs"].values()
            for s in seeds
            if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
            for c in [s["budgets"][key]]
        ]
        if not cells:
            continue
        rows = {}
        for pi in prevalences:
            observed = [
                shifted(c, (c["tp"] + c["fn"]) / (c["tp"] + c["fn"] + c["fp"] + c["tn"]))
                for c in cells
            ]
            moved = [shifted(c, pi) for c in cells]
            rows[pi] = {
                m: float(np.mean([a[m] - b[m] for a, b in zip(moved, observed, strict=True)]))
                for m in CONTRAST_METRICS
            }
        problems.append(run["problem"])
        per_problem.append(rows)
    clusters = np.array([source_id(p) for p in problems])
    sources, counts = np.unique(clusters, return_counts=True)
    out: dict[str, Any] = {
        "budget": budget, "problems": len(problems), "sources": int(len(sources)),
        "singleton_sources": int((counts == 1).sum()), "draws": draws, "contrasts": [],
    }  # fmt: skip
    if len(sources) < MIN_SOURCES:
        out["insufficient"] = f"fewer than {MIN_SOURCES} independent sources"
        return out
    for pi in prevalences:
        for metric in CONTRAST_METRICS:
            values = np.array([row[pi][metric] for row in per_problem])
            out["contrasts"].append(
                {"prevalence": pi, "XXmetricXX": metric}
                | bootstrap(values, clusters, by_cluster=True, draws=draws)
            )
    adjusted = holm([c["p_two_sided"] for c in out["contrasts"]])
    for item, value in zip(out["contrasts"], adjusted, strict=True):
        item["holm_p"] = value
    return out


def x_contrasts__mutmut_107(
    runs: list[dict[str, Any]],
    budget: float = 0.02,
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Change of the fixed threshold's behaviour from the observed prevalence to ``pi``.

    Per problem, the metrics of the threshold at ``pi`` minus its metrics at the problem's own
    held-out prevalence (the observed cell), averaged over the fits of all detectors and seeds
    that share the data. The independent unit is the original source, resampled as a whole; a
    contrast needs at least ``MIN_SOURCES`` sources. Holm adjusts over prevalence-metric pairs.
    """
    key = str(budget)
    problems, per_problem = [], []
    for run in runs:
        cells = [
            c
            for seeds in run["runs"].values()
            for s in seeds
            if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
            for c in [s["budgets"][key]]
        ]
        if not cells:
            continue
        rows = {}
        for pi in prevalences:
            observed = [
                shifted(c, (c["tp"] + c["fn"]) / (c["tp"] + c["fn"] + c["fp"] + c["tn"]))
                for c in cells
            ]
            moved = [shifted(c, pi) for c in cells]
            rows[pi] = {
                m: float(np.mean([a[m] - b[m] for a, b in zip(moved, observed, strict=True)]))
                for m in CONTRAST_METRICS
            }
        problems.append(run["problem"])
        per_problem.append(rows)
    clusters = np.array([source_id(p) for p in problems])
    sources, counts = np.unique(clusters, return_counts=True)
    out: dict[str, Any] = {
        "budget": budget, "problems": len(problems), "sources": int(len(sources)),
        "singleton_sources": int((counts == 1).sum()), "draws": draws, "contrasts": [],
    }  # fmt: skip
    if len(sources) < MIN_SOURCES:
        out["insufficient"] = f"fewer than {MIN_SOURCES} independent sources"
        return out
    for pi in prevalences:
        for metric in CONTRAST_METRICS:
            values = np.array([row[pi][metric] for row in per_problem])
            out["contrasts"].append(
                {"prevalence": pi, "METRIC": metric}
                | bootstrap(values, clusters, by_cluster=True, draws=draws)
            )
    adjusted = holm([c["p_two_sided"] for c in out["contrasts"]])
    for item, value in zip(out["contrasts"], adjusted, strict=True):
        item["holm_p"] = value
    return out


def x_contrasts__mutmut_108(
    runs: list[dict[str, Any]],
    budget: float = 0.02,
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Change of the fixed threshold's behaviour from the observed prevalence to ``pi``.

    Per problem, the metrics of the threshold at ``pi`` minus its metrics at the problem's own
    held-out prevalence (the observed cell), averaged over the fits of all detectors and seeds
    that share the data. The independent unit is the original source, resampled as a whole; a
    contrast needs at least ``MIN_SOURCES`` sources. Holm adjusts over prevalence-metric pairs.
    """
    key = str(budget)
    problems, per_problem = [], []
    for run in runs:
        cells = [
            c
            for seeds in run["runs"].values()
            for s in seeds
            if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
            for c in [s["budgets"][key]]
        ]
        if not cells:
            continue
        rows = {}
        for pi in prevalences:
            observed = [
                shifted(c, (c["tp"] + c["fn"]) / (c["tp"] + c["fn"] + c["fp"] + c["tn"]))
                for c in cells
            ]
            moved = [shifted(c, pi) for c in cells]
            rows[pi] = {
                m: float(np.mean([a[m] - b[m] for a, b in zip(moved, observed, strict=True)]))
                for m in CONTRAST_METRICS
            }
        problems.append(run["problem"])
        per_problem.append(rows)
    clusters = np.array([source_id(p) for p in problems])
    sources, counts = np.unique(clusters, return_counts=True)
    out: dict[str, Any] = {
        "budget": budget, "problems": len(problems), "sources": int(len(sources)),
        "singleton_sources": int((counts == 1).sum()), "draws": draws, "contrasts": [],
    }  # fmt: skip
    if len(sources) < MIN_SOURCES:
        out["insufficient"] = f"fewer than {MIN_SOURCES} independent sources"
        return out
    for pi in prevalences:
        for metric in CONTRAST_METRICS:
            values = np.array([row[pi][metric] for row in per_problem])
            out["contrasts"].append(
                {"prevalence": pi, "metric": metric}
                | bootstrap(None, clusters, by_cluster=True, draws=draws)
            )
    adjusted = holm([c["p_two_sided"] for c in out["contrasts"]])
    for item, value in zip(out["contrasts"], adjusted, strict=True):
        item["holm_p"] = value
    return out


def x_contrasts__mutmut_109(
    runs: list[dict[str, Any]],
    budget: float = 0.02,
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Change of the fixed threshold's behaviour from the observed prevalence to ``pi``.

    Per problem, the metrics of the threshold at ``pi`` minus its metrics at the problem's own
    held-out prevalence (the observed cell), averaged over the fits of all detectors and seeds
    that share the data. The independent unit is the original source, resampled as a whole; a
    contrast needs at least ``MIN_SOURCES`` sources. Holm adjusts over prevalence-metric pairs.
    """
    key = str(budget)
    problems, per_problem = [], []
    for run in runs:
        cells = [
            c
            for seeds in run["runs"].values()
            for s in seeds
            if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
            for c in [s["budgets"][key]]
        ]
        if not cells:
            continue
        rows = {}
        for pi in prevalences:
            observed = [
                shifted(c, (c["tp"] + c["fn"]) / (c["tp"] + c["fn"] + c["fp"] + c["tn"]))
                for c in cells
            ]
            moved = [shifted(c, pi) for c in cells]
            rows[pi] = {
                m: float(np.mean([a[m] - b[m] for a, b in zip(moved, observed, strict=True)]))
                for m in CONTRAST_METRICS
            }
        problems.append(run["problem"])
        per_problem.append(rows)
    clusters = np.array([source_id(p) for p in problems])
    sources, counts = np.unique(clusters, return_counts=True)
    out: dict[str, Any] = {
        "budget": budget, "problems": len(problems), "sources": int(len(sources)),
        "singleton_sources": int((counts == 1).sum()), "draws": draws, "contrasts": [],
    }  # fmt: skip
    if len(sources) < MIN_SOURCES:
        out["insufficient"] = f"fewer than {MIN_SOURCES} independent sources"
        return out
    for pi in prevalences:
        for metric in CONTRAST_METRICS:
            values = np.array([row[pi][metric] for row in per_problem])
            out["contrasts"].append(
                {"prevalence": pi, "metric": metric}
                | bootstrap(values, None, by_cluster=True, draws=draws)
            )
    adjusted = holm([c["p_two_sided"] for c in out["contrasts"]])
    for item, value in zip(out["contrasts"], adjusted, strict=True):
        item["holm_p"] = value
    return out


def x_contrasts__mutmut_110(
    runs: list[dict[str, Any]],
    budget: float = 0.02,
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Change of the fixed threshold's behaviour from the observed prevalence to ``pi``.

    Per problem, the metrics of the threshold at ``pi`` minus its metrics at the problem's own
    held-out prevalence (the observed cell), averaged over the fits of all detectors and seeds
    that share the data. The independent unit is the original source, resampled as a whole; a
    contrast needs at least ``MIN_SOURCES`` sources. Holm adjusts over prevalence-metric pairs.
    """
    key = str(budget)
    problems, per_problem = [], []
    for run in runs:
        cells = [
            c
            for seeds in run["runs"].values()
            for s in seeds
            if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
            for c in [s["budgets"][key]]
        ]
        if not cells:
            continue
        rows = {}
        for pi in prevalences:
            observed = [
                shifted(c, (c["tp"] + c["fn"]) / (c["tp"] + c["fn"] + c["fp"] + c["tn"]))
                for c in cells
            ]
            moved = [shifted(c, pi) for c in cells]
            rows[pi] = {
                m: float(np.mean([a[m] - b[m] for a, b in zip(moved, observed, strict=True)]))
                for m in CONTRAST_METRICS
            }
        problems.append(run["problem"])
        per_problem.append(rows)
    clusters = np.array([source_id(p) for p in problems])
    sources, counts = np.unique(clusters, return_counts=True)
    out: dict[str, Any] = {
        "budget": budget, "problems": len(problems), "sources": int(len(sources)),
        "singleton_sources": int((counts == 1).sum()), "draws": draws, "contrasts": [],
    }  # fmt: skip
    if len(sources) < MIN_SOURCES:
        out["insufficient"] = f"fewer than {MIN_SOURCES} independent sources"
        return out
    for pi in prevalences:
        for metric in CONTRAST_METRICS:
            values = np.array([row[pi][metric] for row in per_problem])
            out["contrasts"].append(
                {"prevalence": pi, "metric": metric}
                | bootstrap(values, clusters, by_cluster=None, draws=draws)
            )
    adjusted = holm([c["p_two_sided"] for c in out["contrasts"]])
    for item, value in zip(out["contrasts"], adjusted, strict=True):
        item["holm_p"] = value
    return out


def x_contrasts__mutmut_111(
    runs: list[dict[str, Any]],
    budget: float = 0.02,
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Change of the fixed threshold's behaviour from the observed prevalence to ``pi``.

    Per problem, the metrics of the threshold at ``pi`` minus its metrics at the problem's own
    held-out prevalence (the observed cell), averaged over the fits of all detectors and seeds
    that share the data. The independent unit is the original source, resampled as a whole; a
    contrast needs at least ``MIN_SOURCES`` sources. Holm adjusts over prevalence-metric pairs.
    """
    key = str(budget)
    problems, per_problem = [], []
    for run in runs:
        cells = [
            c
            for seeds in run["runs"].values()
            for s in seeds
            if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
            for c in [s["budgets"][key]]
        ]
        if not cells:
            continue
        rows = {}
        for pi in prevalences:
            observed = [
                shifted(c, (c["tp"] + c["fn"]) / (c["tp"] + c["fn"] + c["fp"] + c["tn"]))
                for c in cells
            ]
            moved = [shifted(c, pi) for c in cells]
            rows[pi] = {
                m: float(np.mean([a[m] - b[m] for a, b in zip(moved, observed, strict=True)]))
                for m in CONTRAST_METRICS
            }
        problems.append(run["problem"])
        per_problem.append(rows)
    clusters = np.array([source_id(p) for p in problems])
    sources, counts = np.unique(clusters, return_counts=True)
    out: dict[str, Any] = {
        "budget": budget, "problems": len(problems), "sources": int(len(sources)),
        "singleton_sources": int((counts == 1).sum()), "draws": draws, "contrasts": [],
    }  # fmt: skip
    if len(sources) < MIN_SOURCES:
        out["insufficient"] = f"fewer than {MIN_SOURCES} independent sources"
        return out
    for pi in prevalences:
        for metric in CONTRAST_METRICS:
            values = np.array([row[pi][metric] for row in per_problem])
            out["contrasts"].append(
                {"prevalence": pi, "metric": metric}
                | bootstrap(values, clusters, by_cluster=True, draws=None)
            )
    adjusted = holm([c["p_two_sided"] for c in out["contrasts"]])
    for item, value in zip(out["contrasts"], adjusted, strict=True):
        item["holm_p"] = value
    return out


def x_contrasts__mutmut_112(
    runs: list[dict[str, Any]],
    budget: float = 0.02,
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Change of the fixed threshold's behaviour from the observed prevalence to ``pi``.

    Per problem, the metrics of the threshold at ``pi`` minus its metrics at the problem's own
    held-out prevalence (the observed cell), averaged over the fits of all detectors and seeds
    that share the data. The independent unit is the original source, resampled as a whole; a
    contrast needs at least ``MIN_SOURCES`` sources. Holm adjusts over prevalence-metric pairs.
    """
    key = str(budget)
    problems, per_problem = [], []
    for run in runs:
        cells = [
            c
            for seeds in run["runs"].values()
            for s in seeds
            if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
            for c in [s["budgets"][key]]
        ]
        if not cells:
            continue
        rows = {}
        for pi in prevalences:
            observed = [
                shifted(c, (c["tp"] + c["fn"]) / (c["tp"] + c["fn"] + c["fp"] + c["tn"]))
                for c in cells
            ]
            moved = [shifted(c, pi) for c in cells]
            rows[pi] = {
                m: float(np.mean([a[m] - b[m] for a, b in zip(moved, observed, strict=True)]))
                for m in CONTRAST_METRICS
            }
        problems.append(run["problem"])
        per_problem.append(rows)
    clusters = np.array([source_id(p) for p in problems])
    sources, counts = np.unique(clusters, return_counts=True)
    out: dict[str, Any] = {
        "budget": budget, "problems": len(problems), "sources": int(len(sources)),
        "singleton_sources": int((counts == 1).sum()), "draws": draws, "contrasts": [],
    }  # fmt: skip
    if len(sources) < MIN_SOURCES:
        out["insufficient"] = f"fewer than {MIN_SOURCES} independent sources"
        return out
    for pi in prevalences:
        for metric in CONTRAST_METRICS:
            values = np.array([row[pi][metric] for row in per_problem])
            out["contrasts"].append(
                {"prevalence": pi, "metric": metric}
                | bootstrap(clusters, by_cluster=True, draws=draws)
            )
    adjusted = holm([c["p_two_sided"] for c in out["contrasts"]])
    for item, value in zip(out["contrasts"], adjusted, strict=True):
        item["holm_p"] = value
    return out


def x_contrasts__mutmut_113(
    runs: list[dict[str, Any]],
    budget: float = 0.02,
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Change of the fixed threshold's behaviour from the observed prevalence to ``pi``.

    Per problem, the metrics of the threshold at ``pi`` minus its metrics at the problem's own
    held-out prevalence (the observed cell), averaged over the fits of all detectors and seeds
    that share the data. The independent unit is the original source, resampled as a whole; a
    contrast needs at least ``MIN_SOURCES`` sources. Holm adjusts over prevalence-metric pairs.
    """
    key = str(budget)
    problems, per_problem = [], []
    for run in runs:
        cells = [
            c
            for seeds in run["runs"].values()
            for s in seeds
            if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
            for c in [s["budgets"][key]]
        ]
        if not cells:
            continue
        rows = {}
        for pi in prevalences:
            observed = [
                shifted(c, (c["tp"] + c["fn"]) / (c["tp"] + c["fn"] + c["fp"] + c["tn"]))
                for c in cells
            ]
            moved = [shifted(c, pi) for c in cells]
            rows[pi] = {
                m: float(np.mean([a[m] - b[m] for a, b in zip(moved, observed, strict=True)]))
                for m in CONTRAST_METRICS
            }
        problems.append(run["problem"])
        per_problem.append(rows)
    clusters = np.array([source_id(p) for p in problems])
    sources, counts = np.unique(clusters, return_counts=True)
    out: dict[str, Any] = {
        "budget": budget, "problems": len(problems), "sources": int(len(sources)),
        "singleton_sources": int((counts == 1).sum()), "draws": draws, "contrasts": [],
    }  # fmt: skip
    if len(sources) < MIN_SOURCES:
        out["insufficient"] = f"fewer than {MIN_SOURCES} independent sources"
        return out
    for pi in prevalences:
        for metric in CONTRAST_METRICS:
            values = np.array([row[pi][metric] for row in per_problem])
            out["contrasts"].append(
                {"prevalence": pi, "metric": metric}
                | bootstrap(values, by_cluster=True, draws=draws)
            )
    adjusted = holm([c["p_two_sided"] for c in out["contrasts"]])
    for item, value in zip(out["contrasts"], adjusted, strict=True):
        item["holm_p"] = value
    return out


def x_contrasts__mutmut_114(
    runs: list[dict[str, Any]],
    budget: float = 0.02,
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Change of the fixed threshold's behaviour from the observed prevalence to ``pi``.

    Per problem, the metrics of the threshold at ``pi`` minus its metrics at the problem's own
    held-out prevalence (the observed cell), averaged over the fits of all detectors and seeds
    that share the data. The independent unit is the original source, resampled as a whole; a
    contrast needs at least ``MIN_SOURCES`` sources. Holm adjusts over prevalence-metric pairs.
    """
    key = str(budget)
    problems, per_problem = [], []
    for run in runs:
        cells = [
            c
            for seeds in run["runs"].values()
            for s in seeds
            if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
            for c in [s["budgets"][key]]
        ]
        if not cells:
            continue
        rows = {}
        for pi in prevalences:
            observed = [
                shifted(c, (c["tp"] + c["fn"]) / (c["tp"] + c["fn"] + c["fp"] + c["tn"]))
                for c in cells
            ]
            moved = [shifted(c, pi) for c in cells]
            rows[pi] = {
                m: float(np.mean([a[m] - b[m] for a, b in zip(moved, observed, strict=True)]))
                for m in CONTRAST_METRICS
            }
        problems.append(run["problem"])
        per_problem.append(rows)
    clusters = np.array([source_id(p) for p in problems])
    sources, counts = np.unique(clusters, return_counts=True)
    out: dict[str, Any] = {
        "budget": budget, "problems": len(problems), "sources": int(len(sources)),
        "singleton_sources": int((counts == 1).sum()), "draws": draws, "contrasts": [],
    }  # fmt: skip
    if len(sources) < MIN_SOURCES:
        out["insufficient"] = f"fewer than {MIN_SOURCES} independent sources"
        return out
    for pi in prevalences:
        for metric in CONTRAST_METRICS:
            values = np.array([row[pi][metric] for row in per_problem])
            out["contrasts"].append(
                {"prevalence": pi, "metric": metric}
                | bootstrap(values, clusters, draws=draws)
            )
    adjusted = holm([c["p_two_sided"] for c in out["contrasts"]])
    for item, value in zip(out["contrasts"], adjusted, strict=True):
        item["holm_p"] = value
    return out


def x_contrasts__mutmut_115(
    runs: list[dict[str, Any]],
    budget: float = 0.02,
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Change of the fixed threshold's behaviour from the observed prevalence to ``pi``.

    Per problem, the metrics of the threshold at ``pi`` minus its metrics at the problem's own
    held-out prevalence (the observed cell), averaged over the fits of all detectors and seeds
    that share the data. The independent unit is the original source, resampled as a whole; a
    contrast needs at least ``MIN_SOURCES`` sources. Holm adjusts over prevalence-metric pairs.
    """
    key = str(budget)
    problems, per_problem = [], []
    for run in runs:
        cells = [
            c
            for seeds in run["runs"].values()
            for s in seeds
            if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
            for c in [s["budgets"][key]]
        ]
        if not cells:
            continue
        rows = {}
        for pi in prevalences:
            observed = [
                shifted(c, (c["tp"] + c["fn"]) / (c["tp"] + c["fn"] + c["fp"] + c["tn"]))
                for c in cells
            ]
            moved = [shifted(c, pi) for c in cells]
            rows[pi] = {
                m: float(np.mean([a[m] - b[m] for a, b in zip(moved, observed, strict=True)]))
                for m in CONTRAST_METRICS
            }
        problems.append(run["problem"])
        per_problem.append(rows)
    clusters = np.array([source_id(p) for p in problems])
    sources, counts = np.unique(clusters, return_counts=True)
    out: dict[str, Any] = {
        "budget": budget, "problems": len(problems), "sources": int(len(sources)),
        "singleton_sources": int((counts == 1).sum()), "draws": draws, "contrasts": [],
    }  # fmt: skip
    if len(sources) < MIN_SOURCES:
        out["insufficient"] = f"fewer than {MIN_SOURCES} independent sources"
        return out
    for pi in prevalences:
        for metric in CONTRAST_METRICS:
            values = np.array([row[pi][metric] for row in per_problem])
            out["contrasts"].append(
                {"prevalence": pi, "metric": metric}
                | bootstrap(values, clusters, by_cluster=True, )
            )
    adjusted = holm([c["p_two_sided"] for c in out["contrasts"]])
    for item, value in zip(out["contrasts"], adjusted, strict=True):
        item["holm_p"] = value
    return out


def x_contrasts__mutmut_116(
    runs: list[dict[str, Any]],
    budget: float = 0.02,
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Change of the fixed threshold's behaviour from the observed prevalence to ``pi``.

    Per problem, the metrics of the threshold at ``pi`` minus its metrics at the problem's own
    held-out prevalence (the observed cell), averaged over the fits of all detectors and seeds
    that share the data. The independent unit is the original source, resampled as a whole; a
    contrast needs at least ``MIN_SOURCES`` sources. Holm adjusts over prevalence-metric pairs.
    """
    key = str(budget)
    problems, per_problem = [], []
    for run in runs:
        cells = [
            c
            for seeds in run["runs"].values()
            for s in seeds
            if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
            for c in [s["budgets"][key]]
        ]
        if not cells:
            continue
        rows = {}
        for pi in prevalences:
            observed = [
                shifted(c, (c["tp"] + c["fn"]) / (c["tp"] + c["fn"] + c["fp"] + c["tn"]))
                for c in cells
            ]
            moved = [shifted(c, pi) for c in cells]
            rows[pi] = {
                m: float(np.mean([a[m] - b[m] for a, b in zip(moved, observed, strict=True)]))
                for m in CONTRAST_METRICS
            }
        problems.append(run["problem"])
        per_problem.append(rows)
    clusters = np.array([source_id(p) for p in problems])
    sources, counts = np.unique(clusters, return_counts=True)
    out: dict[str, Any] = {
        "budget": budget, "problems": len(problems), "sources": int(len(sources)),
        "singleton_sources": int((counts == 1).sum()), "draws": draws, "contrasts": [],
    }  # fmt: skip
    if len(sources) < MIN_SOURCES:
        out["insufficient"] = f"fewer than {MIN_SOURCES} independent sources"
        return out
    for pi in prevalences:
        for metric in CONTRAST_METRICS:
            values = np.array([row[pi][metric] for row in per_problem])
            out["contrasts"].append(
                {"prevalence": pi, "metric": metric}
                | bootstrap(values, clusters, by_cluster=False, draws=draws)
            )
    adjusted = holm([c["p_two_sided"] for c in out["contrasts"]])
    for item, value in zip(out["contrasts"], adjusted, strict=True):
        item["holm_p"] = value
    return out


def x_contrasts__mutmut_117(
    runs: list[dict[str, Any]],
    budget: float = 0.02,
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Change of the fixed threshold's behaviour from the observed prevalence to ``pi``.

    Per problem, the metrics of the threshold at ``pi`` minus its metrics at the problem's own
    held-out prevalence (the observed cell), averaged over the fits of all detectors and seeds
    that share the data. The independent unit is the original source, resampled as a whole; a
    contrast needs at least ``MIN_SOURCES`` sources. Holm adjusts over prevalence-metric pairs.
    """
    key = str(budget)
    problems, per_problem = [], []
    for run in runs:
        cells = [
            c
            for seeds in run["runs"].values()
            for s in seeds
            if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
            for c in [s["budgets"][key]]
        ]
        if not cells:
            continue
        rows = {}
        for pi in prevalences:
            observed = [
                shifted(c, (c["tp"] + c["fn"]) / (c["tp"] + c["fn"] + c["fp"] + c["tn"]))
                for c in cells
            ]
            moved = [shifted(c, pi) for c in cells]
            rows[pi] = {
                m: float(np.mean([a[m] - b[m] for a, b in zip(moved, observed, strict=True)]))
                for m in CONTRAST_METRICS
            }
        problems.append(run["problem"])
        per_problem.append(rows)
    clusters = np.array([source_id(p) for p in problems])
    sources, counts = np.unique(clusters, return_counts=True)
    out: dict[str, Any] = {
        "budget": budget, "problems": len(problems), "sources": int(len(sources)),
        "singleton_sources": int((counts == 1).sum()), "draws": draws, "contrasts": [],
    }  # fmt: skip
    if len(sources) < MIN_SOURCES:
        out["insufficient"] = f"fewer than {MIN_SOURCES} independent sources"
        return out
    for pi in prevalences:
        for metric in CONTRAST_METRICS:
            values = np.array([row[pi][metric] for row in per_problem])
            out["contrasts"].append(
                {"prevalence": pi, "metric": metric}
                | bootstrap(values, clusters, by_cluster=True, draws=draws)
            )
    adjusted = None
    for item, value in zip(out["contrasts"], adjusted, strict=True):
        item["holm_p"] = value
    return out


def x_contrasts__mutmut_118(
    runs: list[dict[str, Any]],
    budget: float = 0.02,
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Change of the fixed threshold's behaviour from the observed prevalence to ``pi``.

    Per problem, the metrics of the threshold at ``pi`` minus its metrics at the problem's own
    held-out prevalence (the observed cell), averaged over the fits of all detectors and seeds
    that share the data. The independent unit is the original source, resampled as a whole; a
    contrast needs at least ``MIN_SOURCES`` sources. Holm adjusts over prevalence-metric pairs.
    """
    key = str(budget)
    problems, per_problem = [], []
    for run in runs:
        cells = [
            c
            for seeds in run["runs"].values()
            for s in seeds
            if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
            for c in [s["budgets"][key]]
        ]
        if not cells:
            continue
        rows = {}
        for pi in prevalences:
            observed = [
                shifted(c, (c["tp"] + c["fn"]) / (c["tp"] + c["fn"] + c["fp"] + c["tn"]))
                for c in cells
            ]
            moved = [shifted(c, pi) for c in cells]
            rows[pi] = {
                m: float(np.mean([a[m] - b[m] for a, b in zip(moved, observed, strict=True)]))
                for m in CONTRAST_METRICS
            }
        problems.append(run["problem"])
        per_problem.append(rows)
    clusters = np.array([source_id(p) for p in problems])
    sources, counts = np.unique(clusters, return_counts=True)
    out: dict[str, Any] = {
        "budget": budget, "problems": len(problems), "sources": int(len(sources)),
        "singleton_sources": int((counts == 1).sum()), "draws": draws, "contrasts": [],
    }  # fmt: skip
    if len(sources) < MIN_SOURCES:
        out["insufficient"] = f"fewer than {MIN_SOURCES} independent sources"
        return out
    for pi in prevalences:
        for metric in CONTRAST_METRICS:
            values = np.array([row[pi][metric] for row in per_problem])
            out["contrasts"].append(
                {"prevalence": pi, "metric": metric}
                | bootstrap(values, clusters, by_cluster=True, draws=draws)
            )
    adjusted = holm(None)
    for item, value in zip(out["contrasts"], adjusted, strict=True):
        item["holm_p"] = value
    return out


def x_contrasts__mutmut_119(
    runs: list[dict[str, Any]],
    budget: float = 0.02,
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Change of the fixed threshold's behaviour from the observed prevalence to ``pi``.

    Per problem, the metrics of the threshold at ``pi`` minus its metrics at the problem's own
    held-out prevalence (the observed cell), averaged over the fits of all detectors and seeds
    that share the data. The independent unit is the original source, resampled as a whole; a
    contrast needs at least ``MIN_SOURCES`` sources. Holm adjusts over prevalence-metric pairs.
    """
    key = str(budget)
    problems, per_problem = [], []
    for run in runs:
        cells = [
            c
            for seeds in run["runs"].values()
            for s in seeds
            if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
            for c in [s["budgets"][key]]
        ]
        if not cells:
            continue
        rows = {}
        for pi in prevalences:
            observed = [
                shifted(c, (c["tp"] + c["fn"]) / (c["tp"] + c["fn"] + c["fp"] + c["tn"]))
                for c in cells
            ]
            moved = [shifted(c, pi) for c in cells]
            rows[pi] = {
                m: float(np.mean([a[m] - b[m] for a, b in zip(moved, observed, strict=True)]))
                for m in CONTRAST_METRICS
            }
        problems.append(run["problem"])
        per_problem.append(rows)
    clusters = np.array([source_id(p) for p in problems])
    sources, counts = np.unique(clusters, return_counts=True)
    out: dict[str, Any] = {
        "budget": budget, "problems": len(problems), "sources": int(len(sources)),
        "singleton_sources": int((counts == 1).sum()), "draws": draws, "contrasts": [],
    }  # fmt: skip
    if len(sources) < MIN_SOURCES:
        out["insufficient"] = f"fewer than {MIN_SOURCES} independent sources"
        return out
    for pi in prevalences:
        for metric in CONTRAST_METRICS:
            values = np.array([row[pi][metric] for row in per_problem])
            out["contrasts"].append(
                {"prevalence": pi, "metric": metric}
                | bootstrap(values, clusters, by_cluster=True, draws=draws)
            )
    adjusted = holm([c["XXp_two_sidedXX"] for c in out["contrasts"]])
    for item, value in zip(out["contrasts"], adjusted, strict=True):
        item["holm_p"] = value
    return out


def x_contrasts__mutmut_120(
    runs: list[dict[str, Any]],
    budget: float = 0.02,
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Change of the fixed threshold's behaviour from the observed prevalence to ``pi``.

    Per problem, the metrics of the threshold at ``pi`` minus its metrics at the problem's own
    held-out prevalence (the observed cell), averaged over the fits of all detectors and seeds
    that share the data. The independent unit is the original source, resampled as a whole; a
    contrast needs at least ``MIN_SOURCES`` sources. Holm adjusts over prevalence-metric pairs.
    """
    key = str(budget)
    problems, per_problem = [], []
    for run in runs:
        cells = [
            c
            for seeds in run["runs"].values()
            for s in seeds
            if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
            for c in [s["budgets"][key]]
        ]
        if not cells:
            continue
        rows = {}
        for pi in prevalences:
            observed = [
                shifted(c, (c["tp"] + c["fn"]) / (c["tp"] + c["fn"] + c["fp"] + c["tn"]))
                for c in cells
            ]
            moved = [shifted(c, pi) for c in cells]
            rows[pi] = {
                m: float(np.mean([a[m] - b[m] for a, b in zip(moved, observed, strict=True)]))
                for m in CONTRAST_METRICS
            }
        problems.append(run["problem"])
        per_problem.append(rows)
    clusters = np.array([source_id(p) for p in problems])
    sources, counts = np.unique(clusters, return_counts=True)
    out: dict[str, Any] = {
        "budget": budget, "problems": len(problems), "sources": int(len(sources)),
        "singleton_sources": int((counts == 1).sum()), "draws": draws, "contrasts": [],
    }  # fmt: skip
    if len(sources) < MIN_SOURCES:
        out["insufficient"] = f"fewer than {MIN_SOURCES} independent sources"
        return out
    for pi in prevalences:
        for metric in CONTRAST_METRICS:
            values = np.array([row[pi][metric] for row in per_problem])
            out["contrasts"].append(
                {"prevalence": pi, "metric": metric}
                | bootstrap(values, clusters, by_cluster=True, draws=draws)
            )
    adjusted = holm([c["P_TWO_SIDED"] for c in out["contrasts"]])
    for item, value in zip(out["contrasts"], adjusted, strict=True):
        item["holm_p"] = value
    return out


def x_contrasts__mutmut_121(
    runs: list[dict[str, Any]],
    budget: float = 0.02,
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Change of the fixed threshold's behaviour from the observed prevalence to ``pi``.

    Per problem, the metrics of the threshold at ``pi`` minus its metrics at the problem's own
    held-out prevalence (the observed cell), averaged over the fits of all detectors and seeds
    that share the data. The independent unit is the original source, resampled as a whole; a
    contrast needs at least ``MIN_SOURCES`` sources. Holm adjusts over prevalence-metric pairs.
    """
    key = str(budget)
    problems, per_problem = [], []
    for run in runs:
        cells = [
            c
            for seeds in run["runs"].values()
            for s in seeds
            if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
            for c in [s["budgets"][key]]
        ]
        if not cells:
            continue
        rows = {}
        for pi in prevalences:
            observed = [
                shifted(c, (c["tp"] + c["fn"]) / (c["tp"] + c["fn"] + c["fp"] + c["tn"]))
                for c in cells
            ]
            moved = [shifted(c, pi) for c in cells]
            rows[pi] = {
                m: float(np.mean([a[m] - b[m] for a, b in zip(moved, observed, strict=True)]))
                for m in CONTRAST_METRICS
            }
        problems.append(run["problem"])
        per_problem.append(rows)
    clusters = np.array([source_id(p) for p in problems])
    sources, counts = np.unique(clusters, return_counts=True)
    out: dict[str, Any] = {
        "budget": budget, "problems": len(problems), "sources": int(len(sources)),
        "singleton_sources": int((counts == 1).sum()), "draws": draws, "contrasts": [],
    }  # fmt: skip
    if len(sources) < MIN_SOURCES:
        out["insufficient"] = f"fewer than {MIN_SOURCES} independent sources"
        return out
    for pi in prevalences:
        for metric in CONTRAST_METRICS:
            values = np.array([row[pi][metric] for row in per_problem])
            out["contrasts"].append(
                {"prevalence": pi, "metric": metric}
                | bootstrap(values, clusters, by_cluster=True, draws=draws)
            )
    adjusted = holm([c["p_two_sided"] for c in out["XXcontrastsXX"]])
    for item, value in zip(out["contrasts"], adjusted, strict=True):
        item["holm_p"] = value
    return out


def x_contrasts__mutmut_122(
    runs: list[dict[str, Any]],
    budget: float = 0.02,
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Change of the fixed threshold's behaviour from the observed prevalence to ``pi``.

    Per problem, the metrics of the threshold at ``pi`` minus its metrics at the problem's own
    held-out prevalence (the observed cell), averaged over the fits of all detectors and seeds
    that share the data. The independent unit is the original source, resampled as a whole; a
    contrast needs at least ``MIN_SOURCES`` sources. Holm adjusts over prevalence-metric pairs.
    """
    key = str(budget)
    problems, per_problem = [], []
    for run in runs:
        cells = [
            c
            for seeds in run["runs"].values()
            for s in seeds
            if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
            for c in [s["budgets"][key]]
        ]
        if not cells:
            continue
        rows = {}
        for pi in prevalences:
            observed = [
                shifted(c, (c["tp"] + c["fn"]) / (c["tp"] + c["fn"] + c["fp"] + c["tn"]))
                for c in cells
            ]
            moved = [shifted(c, pi) for c in cells]
            rows[pi] = {
                m: float(np.mean([a[m] - b[m] for a, b in zip(moved, observed, strict=True)]))
                for m in CONTRAST_METRICS
            }
        problems.append(run["problem"])
        per_problem.append(rows)
    clusters = np.array([source_id(p) for p in problems])
    sources, counts = np.unique(clusters, return_counts=True)
    out: dict[str, Any] = {
        "budget": budget, "problems": len(problems), "sources": int(len(sources)),
        "singleton_sources": int((counts == 1).sum()), "draws": draws, "contrasts": [],
    }  # fmt: skip
    if len(sources) < MIN_SOURCES:
        out["insufficient"] = f"fewer than {MIN_SOURCES} independent sources"
        return out
    for pi in prevalences:
        for metric in CONTRAST_METRICS:
            values = np.array([row[pi][metric] for row in per_problem])
            out["contrasts"].append(
                {"prevalence": pi, "metric": metric}
                | bootstrap(values, clusters, by_cluster=True, draws=draws)
            )
    adjusted = holm([c["p_two_sided"] for c in out["CONTRASTS"]])
    for item, value in zip(out["contrasts"], adjusted, strict=True):
        item["holm_p"] = value
    return out


def x_contrasts__mutmut_123(
    runs: list[dict[str, Any]],
    budget: float = 0.02,
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Change of the fixed threshold's behaviour from the observed prevalence to ``pi``.

    Per problem, the metrics of the threshold at ``pi`` minus its metrics at the problem's own
    held-out prevalence (the observed cell), averaged over the fits of all detectors and seeds
    that share the data. The independent unit is the original source, resampled as a whole; a
    contrast needs at least ``MIN_SOURCES`` sources. Holm adjusts over prevalence-metric pairs.
    """
    key = str(budget)
    problems, per_problem = [], []
    for run in runs:
        cells = [
            c
            for seeds in run["runs"].values()
            for s in seeds
            if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
            for c in [s["budgets"][key]]
        ]
        if not cells:
            continue
        rows = {}
        for pi in prevalences:
            observed = [
                shifted(c, (c["tp"] + c["fn"]) / (c["tp"] + c["fn"] + c["fp"] + c["tn"]))
                for c in cells
            ]
            moved = [shifted(c, pi) for c in cells]
            rows[pi] = {
                m: float(np.mean([a[m] - b[m] for a, b in zip(moved, observed, strict=True)]))
                for m in CONTRAST_METRICS
            }
        problems.append(run["problem"])
        per_problem.append(rows)
    clusters = np.array([source_id(p) for p in problems])
    sources, counts = np.unique(clusters, return_counts=True)
    out: dict[str, Any] = {
        "budget": budget, "problems": len(problems), "sources": int(len(sources)),
        "singleton_sources": int((counts == 1).sum()), "draws": draws, "contrasts": [],
    }  # fmt: skip
    if len(sources) < MIN_SOURCES:
        out["insufficient"] = f"fewer than {MIN_SOURCES} independent sources"
        return out
    for pi in prevalences:
        for metric in CONTRAST_METRICS:
            values = np.array([row[pi][metric] for row in per_problem])
            out["contrasts"].append(
                {"prevalence": pi, "metric": metric}
                | bootstrap(values, clusters, by_cluster=True, draws=draws)
            )
    adjusted = holm([c["p_two_sided"] for c in out["contrasts"]])
    for item, value in zip(None, adjusted, strict=True):
        item["holm_p"] = value
    return out


def x_contrasts__mutmut_124(
    runs: list[dict[str, Any]],
    budget: float = 0.02,
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Change of the fixed threshold's behaviour from the observed prevalence to ``pi``.

    Per problem, the metrics of the threshold at ``pi`` minus its metrics at the problem's own
    held-out prevalence (the observed cell), averaged over the fits of all detectors and seeds
    that share the data. The independent unit is the original source, resampled as a whole; a
    contrast needs at least ``MIN_SOURCES`` sources. Holm adjusts over prevalence-metric pairs.
    """
    key = str(budget)
    problems, per_problem = [], []
    for run in runs:
        cells = [
            c
            for seeds in run["runs"].values()
            for s in seeds
            if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
            for c in [s["budgets"][key]]
        ]
        if not cells:
            continue
        rows = {}
        for pi in prevalences:
            observed = [
                shifted(c, (c["tp"] + c["fn"]) / (c["tp"] + c["fn"] + c["fp"] + c["tn"]))
                for c in cells
            ]
            moved = [shifted(c, pi) for c in cells]
            rows[pi] = {
                m: float(np.mean([a[m] - b[m] for a, b in zip(moved, observed, strict=True)]))
                for m in CONTRAST_METRICS
            }
        problems.append(run["problem"])
        per_problem.append(rows)
    clusters = np.array([source_id(p) for p in problems])
    sources, counts = np.unique(clusters, return_counts=True)
    out: dict[str, Any] = {
        "budget": budget, "problems": len(problems), "sources": int(len(sources)),
        "singleton_sources": int((counts == 1).sum()), "draws": draws, "contrasts": [],
    }  # fmt: skip
    if len(sources) < MIN_SOURCES:
        out["insufficient"] = f"fewer than {MIN_SOURCES} independent sources"
        return out
    for pi in prevalences:
        for metric in CONTRAST_METRICS:
            values = np.array([row[pi][metric] for row in per_problem])
            out["contrasts"].append(
                {"prevalence": pi, "metric": metric}
                | bootstrap(values, clusters, by_cluster=True, draws=draws)
            )
    adjusted = holm([c["p_two_sided"] for c in out["contrasts"]])
    for item, value in zip(out["contrasts"], None, strict=True):
        item["holm_p"] = value
    return out


def x_contrasts__mutmut_125(
    runs: list[dict[str, Any]],
    budget: float = 0.02,
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Change of the fixed threshold's behaviour from the observed prevalence to ``pi``.

    Per problem, the metrics of the threshold at ``pi`` minus its metrics at the problem's own
    held-out prevalence (the observed cell), averaged over the fits of all detectors and seeds
    that share the data. The independent unit is the original source, resampled as a whole; a
    contrast needs at least ``MIN_SOURCES`` sources. Holm adjusts over prevalence-metric pairs.
    """
    key = str(budget)
    problems, per_problem = [], []
    for run in runs:
        cells = [
            c
            for seeds in run["runs"].values()
            for s in seeds
            if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
            for c in [s["budgets"][key]]
        ]
        if not cells:
            continue
        rows = {}
        for pi in prevalences:
            observed = [
                shifted(c, (c["tp"] + c["fn"]) / (c["tp"] + c["fn"] + c["fp"] + c["tn"]))
                for c in cells
            ]
            moved = [shifted(c, pi) for c in cells]
            rows[pi] = {
                m: float(np.mean([a[m] - b[m] for a, b in zip(moved, observed, strict=True)]))
                for m in CONTRAST_METRICS
            }
        problems.append(run["problem"])
        per_problem.append(rows)
    clusters = np.array([source_id(p) for p in problems])
    sources, counts = np.unique(clusters, return_counts=True)
    out: dict[str, Any] = {
        "budget": budget, "problems": len(problems), "sources": int(len(sources)),
        "singleton_sources": int((counts == 1).sum()), "draws": draws, "contrasts": [],
    }  # fmt: skip
    if len(sources) < MIN_SOURCES:
        out["insufficient"] = f"fewer than {MIN_SOURCES} independent sources"
        return out
    for pi in prevalences:
        for metric in CONTRAST_METRICS:
            values = np.array([row[pi][metric] for row in per_problem])
            out["contrasts"].append(
                {"prevalence": pi, "metric": metric}
                | bootstrap(values, clusters, by_cluster=True, draws=draws)
            )
    adjusted = holm([c["p_two_sided"] for c in out["contrasts"]])
    for item, value in zip(out["contrasts"], adjusted, strict=None):
        item["holm_p"] = value
    return out


def x_contrasts__mutmut_126(
    runs: list[dict[str, Any]],
    budget: float = 0.02,
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Change of the fixed threshold's behaviour from the observed prevalence to ``pi``.

    Per problem, the metrics of the threshold at ``pi`` minus its metrics at the problem's own
    held-out prevalence (the observed cell), averaged over the fits of all detectors and seeds
    that share the data. The independent unit is the original source, resampled as a whole; a
    contrast needs at least ``MIN_SOURCES`` sources. Holm adjusts over prevalence-metric pairs.
    """
    key = str(budget)
    problems, per_problem = [], []
    for run in runs:
        cells = [
            c
            for seeds in run["runs"].values()
            for s in seeds
            if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
            for c in [s["budgets"][key]]
        ]
        if not cells:
            continue
        rows = {}
        for pi in prevalences:
            observed = [
                shifted(c, (c["tp"] + c["fn"]) / (c["tp"] + c["fn"] + c["fp"] + c["tn"]))
                for c in cells
            ]
            moved = [shifted(c, pi) for c in cells]
            rows[pi] = {
                m: float(np.mean([a[m] - b[m] for a, b in zip(moved, observed, strict=True)]))
                for m in CONTRAST_METRICS
            }
        problems.append(run["problem"])
        per_problem.append(rows)
    clusters = np.array([source_id(p) for p in problems])
    sources, counts = np.unique(clusters, return_counts=True)
    out: dict[str, Any] = {
        "budget": budget, "problems": len(problems), "sources": int(len(sources)),
        "singleton_sources": int((counts == 1).sum()), "draws": draws, "contrasts": [],
    }  # fmt: skip
    if len(sources) < MIN_SOURCES:
        out["insufficient"] = f"fewer than {MIN_SOURCES} independent sources"
        return out
    for pi in prevalences:
        for metric in CONTRAST_METRICS:
            values = np.array([row[pi][metric] for row in per_problem])
            out["contrasts"].append(
                {"prevalence": pi, "metric": metric}
                | bootstrap(values, clusters, by_cluster=True, draws=draws)
            )
    adjusted = holm([c["p_two_sided"] for c in out["contrasts"]])
    for item, value in zip(adjusted, strict=True):
        item["holm_p"] = value
    return out


def x_contrasts__mutmut_127(
    runs: list[dict[str, Any]],
    budget: float = 0.02,
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Change of the fixed threshold's behaviour from the observed prevalence to ``pi``.

    Per problem, the metrics of the threshold at ``pi`` minus its metrics at the problem's own
    held-out prevalence (the observed cell), averaged over the fits of all detectors and seeds
    that share the data. The independent unit is the original source, resampled as a whole; a
    contrast needs at least ``MIN_SOURCES`` sources. Holm adjusts over prevalence-metric pairs.
    """
    key = str(budget)
    problems, per_problem = [], []
    for run in runs:
        cells = [
            c
            for seeds in run["runs"].values()
            for s in seeds
            if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
            for c in [s["budgets"][key]]
        ]
        if not cells:
            continue
        rows = {}
        for pi in prevalences:
            observed = [
                shifted(c, (c["tp"] + c["fn"]) / (c["tp"] + c["fn"] + c["fp"] + c["tn"]))
                for c in cells
            ]
            moved = [shifted(c, pi) for c in cells]
            rows[pi] = {
                m: float(np.mean([a[m] - b[m] for a, b in zip(moved, observed, strict=True)]))
                for m in CONTRAST_METRICS
            }
        problems.append(run["problem"])
        per_problem.append(rows)
    clusters = np.array([source_id(p) for p in problems])
    sources, counts = np.unique(clusters, return_counts=True)
    out: dict[str, Any] = {
        "budget": budget, "problems": len(problems), "sources": int(len(sources)),
        "singleton_sources": int((counts == 1).sum()), "draws": draws, "contrasts": [],
    }  # fmt: skip
    if len(sources) < MIN_SOURCES:
        out["insufficient"] = f"fewer than {MIN_SOURCES} independent sources"
        return out
    for pi in prevalences:
        for metric in CONTRAST_METRICS:
            values = np.array([row[pi][metric] for row in per_problem])
            out["contrasts"].append(
                {"prevalence": pi, "metric": metric}
                | bootstrap(values, clusters, by_cluster=True, draws=draws)
            )
    adjusted = holm([c["p_two_sided"] for c in out["contrasts"]])
    for item, value in zip(out["contrasts"], strict=True):
        item["holm_p"] = value
    return out


def x_contrasts__mutmut_128(
    runs: list[dict[str, Any]],
    budget: float = 0.02,
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Change of the fixed threshold's behaviour from the observed prevalence to ``pi``.

    Per problem, the metrics of the threshold at ``pi`` minus its metrics at the problem's own
    held-out prevalence (the observed cell), averaged over the fits of all detectors and seeds
    that share the data. The independent unit is the original source, resampled as a whole; a
    contrast needs at least ``MIN_SOURCES`` sources. Holm adjusts over prevalence-metric pairs.
    """
    key = str(budget)
    problems, per_problem = [], []
    for run in runs:
        cells = [
            c
            for seeds in run["runs"].values()
            for s in seeds
            if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
            for c in [s["budgets"][key]]
        ]
        if not cells:
            continue
        rows = {}
        for pi in prevalences:
            observed = [
                shifted(c, (c["tp"] + c["fn"]) / (c["tp"] + c["fn"] + c["fp"] + c["tn"]))
                for c in cells
            ]
            moved = [shifted(c, pi) for c in cells]
            rows[pi] = {
                m: float(np.mean([a[m] - b[m] for a, b in zip(moved, observed, strict=True)]))
                for m in CONTRAST_METRICS
            }
        problems.append(run["problem"])
        per_problem.append(rows)
    clusters = np.array([source_id(p) for p in problems])
    sources, counts = np.unique(clusters, return_counts=True)
    out: dict[str, Any] = {
        "budget": budget, "problems": len(problems), "sources": int(len(sources)),
        "singleton_sources": int((counts == 1).sum()), "draws": draws, "contrasts": [],
    }  # fmt: skip
    if len(sources) < MIN_SOURCES:
        out["insufficient"] = f"fewer than {MIN_SOURCES} independent sources"
        return out
    for pi in prevalences:
        for metric in CONTRAST_METRICS:
            values = np.array([row[pi][metric] for row in per_problem])
            out["contrasts"].append(
                {"prevalence": pi, "metric": metric}
                | bootstrap(values, clusters, by_cluster=True, draws=draws)
            )
    adjusted = holm([c["p_two_sided"] for c in out["contrasts"]])
    for item, value in zip(out["contrasts"], adjusted, ):
        item["holm_p"] = value
    return out


def x_contrasts__mutmut_129(
    runs: list[dict[str, Any]],
    budget: float = 0.02,
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Change of the fixed threshold's behaviour from the observed prevalence to ``pi``.

    Per problem, the metrics of the threshold at ``pi`` minus its metrics at the problem's own
    held-out prevalence (the observed cell), averaged over the fits of all detectors and seeds
    that share the data. The independent unit is the original source, resampled as a whole; a
    contrast needs at least ``MIN_SOURCES`` sources. Holm adjusts over prevalence-metric pairs.
    """
    key = str(budget)
    problems, per_problem = [], []
    for run in runs:
        cells = [
            c
            for seeds in run["runs"].values()
            for s in seeds
            if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
            for c in [s["budgets"][key]]
        ]
        if not cells:
            continue
        rows = {}
        for pi in prevalences:
            observed = [
                shifted(c, (c["tp"] + c["fn"]) / (c["tp"] + c["fn"] + c["fp"] + c["tn"]))
                for c in cells
            ]
            moved = [shifted(c, pi) for c in cells]
            rows[pi] = {
                m: float(np.mean([a[m] - b[m] for a, b in zip(moved, observed, strict=True)]))
                for m in CONTRAST_METRICS
            }
        problems.append(run["problem"])
        per_problem.append(rows)
    clusters = np.array([source_id(p) for p in problems])
    sources, counts = np.unique(clusters, return_counts=True)
    out: dict[str, Any] = {
        "budget": budget, "problems": len(problems), "sources": int(len(sources)),
        "singleton_sources": int((counts == 1).sum()), "draws": draws, "contrasts": [],
    }  # fmt: skip
    if len(sources) < MIN_SOURCES:
        out["insufficient"] = f"fewer than {MIN_SOURCES} independent sources"
        return out
    for pi in prevalences:
        for metric in CONTRAST_METRICS:
            values = np.array([row[pi][metric] for row in per_problem])
            out["contrasts"].append(
                {"prevalence": pi, "metric": metric}
                | bootstrap(values, clusters, by_cluster=True, draws=draws)
            )
    adjusted = holm([c["p_two_sided"] for c in out["contrasts"]])
    for item, value in zip(out["XXcontrastsXX"], adjusted, strict=True):
        item["holm_p"] = value
    return out


def x_contrasts__mutmut_130(
    runs: list[dict[str, Any]],
    budget: float = 0.02,
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Change of the fixed threshold's behaviour from the observed prevalence to ``pi``.

    Per problem, the metrics of the threshold at ``pi`` minus its metrics at the problem's own
    held-out prevalence (the observed cell), averaged over the fits of all detectors and seeds
    that share the data. The independent unit is the original source, resampled as a whole; a
    contrast needs at least ``MIN_SOURCES`` sources. Holm adjusts over prevalence-metric pairs.
    """
    key = str(budget)
    problems, per_problem = [], []
    for run in runs:
        cells = [
            c
            for seeds in run["runs"].values()
            for s in seeds
            if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
            for c in [s["budgets"][key]]
        ]
        if not cells:
            continue
        rows = {}
        for pi in prevalences:
            observed = [
                shifted(c, (c["tp"] + c["fn"]) / (c["tp"] + c["fn"] + c["fp"] + c["tn"]))
                for c in cells
            ]
            moved = [shifted(c, pi) for c in cells]
            rows[pi] = {
                m: float(np.mean([a[m] - b[m] for a, b in zip(moved, observed, strict=True)]))
                for m in CONTRAST_METRICS
            }
        problems.append(run["problem"])
        per_problem.append(rows)
    clusters = np.array([source_id(p) for p in problems])
    sources, counts = np.unique(clusters, return_counts=True)
    out: dict[str, Any] = {
        "budget": budget, "problems": len(problems), "sources": int(len(sources)),
        "singleton_sources": int((counts == 1).sum()), "draws": draws, "contrasts": [],
    }  # fmt: skip
    if len(sources) < MIN_SOURCES:
        out["insufficient"] = f"fewer than {MIN_SOURCES} independent sources"
        return out
    for pi in prevalences:
        for metric in CONTRAST_METRICS:
            values = np.array([row[pi][metric] for row in per_problem])
            out["contrasts"].append(
                {"prevalence": pi, "metric": metric}
                | bootstrap(values, clusters, by_cluster=True, draws=draws)
            )
    adjusted = holm([c["p_two_sided"] for c in out["contrasts"]])
    for item, value in zip(out["CONTRASTS"], adjusted, strict=True):
        item["holm_p"] = value
    return out


def x_contrasts__mutmut_131(
    runs: list[dict[str, Any]],
    budget: float = 0.02,
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Change of the fixed threshold's behaviour from the observed prevalence to ``pi``.

    Per problem, the metrics of the threshold at ``pi`` minus its metrics at the problem's own
    held-out prevalence (the observed cell), averaged over the fits of all detectors and seeds
    that share the data. The independent unit is the original source, resampled as a whole; a
    contrast needs at least ``MIN_SOURCES`` sources. Holm adjusts over prevalence-metric pairs.
    """
    key = str(budget)
    problems, per_problem = [], []
    for run in runs:
        cells = [
            c
            for seeds in run["runs"].values()
            for s in seeds
            if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
            for c in [s["budgets"][key]]
        ]
        if not cells:
            continue
        rows = {}
        for pi in prevalences:
            observed = [
                shifted(c, (c["tp"] + c["fn"]) / (c["tp"] + c["fn"] + c["fp"] + c["tn"]))
                for c in cells
            ]
            moved = [shifted(c, pi) for c in cells]
            rows[pi] = {
                m: float(np.mean([a[m] - b[m] for a, b in zip(moved, observed, strict=True)]))
                for m in CONTRAST_METRICS
            }
        problems.append(run["problem"])
        per_problem.append(rows)
    clusters = np.array([source_id(p) for p in problems])
    sources, counts = np.unique(clusters, return_counts=True)
    out: dict[str, Any] = {
        "budget": budget, "problems": len(problems), "sources": int(len(sources)),
        "singleton_sources": int((counts == 1).sum()), "draws": draws, "contrasts": [],
    }  # fmt: skip
    if len(sources) < MIN_SOURCES:
        out["insufficient"] = f"fewer than {MIN_SOURCES} independent sources"
        return out
    for pi in prevalences:
        for metric in CONTRAST_METRICS:
            values = np.array([row[pi][metric] for row in per_problem])
            out["contrasts"].append(
                {"prevalence": pi, "metric": metric}
                | bootstrap(values, clusters, by_cluster=True, draws=draws)
            )
    adjusted = holm([c["p_two_sided"] for c in out["contrasts"]])
    for item, value in zip(out["contrasts"], adjusted, strict=False):
        item["holm_p"] = value
    return out


def x_contrasts__mutmut_132(
    runs: list[dict[str, Any]],
    budget: float = 0.02,
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Change of the fixed threshold's behaviour from the observed prevalence to ``pi``.

    Per problem, the metrics of the threshold at ``pi`` minus its metrics at the problem's own
    held-out prevalence (the observed cell), averaged over the fits of all detectors and seeds
    that share the data. The independent unit is the original source, resampled as a whole; a
    contrast needs at least ``MIN_SOURCES`` sources. Holm adjusts over prevalence-metric pairs.
    """
    key = str(budget)
    problems, per_problem = [], []
    for run in runs:
        cells = [
            c
            for seeds in run["runs"].values()
            for s in seeds
            if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
            for c in [s["budgets"][key]]
        ]
        if not cells:
            continue
        rows = {}
        for pi in prevalences:
            observed = [
                shifted(c, (c["tp"] + c["fn"]) / (c["tp"] + c["fn"] + c["fp"] + c["tn"]))
                for c in cells
            ]
            moved = [shifted(c, pi) for c in cells]
            rows[pi] = {
                m: float(np.mean([a[m] - b[m] for a, b in zip(moved, observed, strict=True)]))
                for m in CONTRAST_METRICS
            }
        problems.append(run["problem"])
        per_problem.append(rows)
    clusters = np.array([source_id(p) for p in problems])
    sources, counts = np.unique(clusters, return_counts=True)
    out: dict[str, Any] = {
        "budget": budget, "problems": len(problems), "sources": int(len(sources)),
        "singleton_sources": int((counts == 1).sum()), "draws": draws, "contrasts": [],
    }  # fmt: skip
    if len(sources) < MIN_SOURCES:
        out["insufficient"] = f"fewer than {MIN_SOURCES} independent sources"
        return out
    for pi in prevalences:
        for metric in CONTRAST_METRICS:
            values = np.array([row[pi][metric] for row in per_problem])
            out["contrasts"].append(
                {"prevalence": pi, "metric": metric}
                | bootstrap(values, clusters, by_cluster=True, draws=draws)
            )
    adjusted = holm([c["p_two_sided"] for c in out["contrasts"]])
    for item, value in zip(out["contrasts"], adjusted, strict=True):
        item["holm_p"] = None
    return out


def x_contrasts__mutmut_133(
    runs: list[dict[str, Any]],
    budget: float = 0.02,
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Change of the fixed threshold's behaviour from the observed prevalence to ``pi``.

    Per problem, the metrics of the threshold at ``pi`` minus its metrics at the problem's own
    held-out prevalence (the observed cell), averaged over the fits of all detectors and seeds
    that share the data. The independent unit is the original source, resampled as a whole; a
    contrast needs at least ``MIN_SOURCES`` sources. Holm adjusts over prevalence-metric pairs.
    """
    key = str(budget)
    problems, per_problem = [], []
    for run in runs:
        cells = [
            c
            for seeds in run["runs"].values()
            for s in seeds
            if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
            for c in [s["budgets"][key]]
        ]
        if not cells:
            continue
        rows = {}
        for pi in prevalences:
            observed = [
                shifted(c, (c["tp"] + c["fn"]) / (c["tp"] + c["fn"] + c["fp"] + c["tn"]))
                for c in cells
            ]
            moved = [shifted(c, pi) for c in cells]
            rows[pi] = {
                m: float(np.mean([a[m] - b[m] for a, b in zip(moved, observed, strict=True)]))
                for m in CONTRAST_METRICS
            }
        problems.append(run["problem"])
        per_problem.append(rows)
    clusters = np.array([source_id(p) for p in problems])
    sources, counts = np.unique(clusters, return_counts=True)
    out: dict[str, Any] = {
        "budget": budget, "problems": len(problems), "sources": int(len(sources)),
        "singleton_sources": int((counts == 1).sum()), "draws": draws, "contrasts": [],
    }  # fmt: skip
    if len(sources) < MIN_SOURCES:
        out["insufficient"] = f"fewer than {MIN_SOURCES} independent sources"
        return out
    for pi in prevalences:
        for metric in CONTRAST_METRICS:
            values = np.array([row[pi][metric] for row in per_problem])
            out["contrasts"].append(
                {"prevalence": pi, "metric": metric}
                | bootstrap(values, clusters, by_cluster=True, draws=draws)
            )
    adjusted = holm([c["p_two_sided"] for c in out["contrasts"]])
    for item, value in zip(out["contrasts"], adjusted, strict=True):
        item["XXholm_pXX"] = value
    return out


def x_contrasts__mutmut_134(
    runs: list[dict[str, Any]],
    budget: float = 0.02,
    prevalences: tuple[float, ...] = PREVALENCES,
    draws: int = DRAWS,
) -> dict[str, Any]:
    """Change of the fixed threshold's behaviour from the observed prevalence to ``pi``.

    Per problem, the metrics of the threshold at ``pi`` minus its metrics at the problem's own
    held-out prevalence (the observed cell), averaged over the fits of all detectors and seeds
    that share the data. The independent unit is the original source, resampled as a whole; a
    contrast needs at least ``MIN_SOURCES`` sources. Holm adjusts over prevalence-metric pairs.
    """
    key = str(budget)
    problems, per_problem = [], []
    for run in runs:
        cells = [
            c
            for seeds in run["runs"].values()
            for s in seeds
            if key in s.get("budgets", {}) and "infeasible" not in s["budgets"][key]
            for c in [s["budgets"][key]]
        ]
        if not cells:
            continue
        rows = {}
        for pi in prevalences:
            observed = [
                shifted(c, (c["tp"] + c["fn"]) / (c["tp"] + c["fn"] + c["fp"] + c["tn"]))
                for c in cells
            ]
            moved = [shifted(c, pi) for c in cells]
            rows[pi] = {
                m: float(np.mean([a[m] - b[m] for a, b in zip(moved, observed, strict=True)]))
                for m in CONTRAST_METRICS
            }
        problems.append(run["problem"])
        per_problem.append(rows)
    clusters = np.array([source_id(p) for p in problems])
    sources, counts = np.unique(clusters, return_counts=True)
    out: dict[str, Any] = {
        "budget": budget, "problems": len(problems), "sources": int(len(sources)),
        "singleton_sources": int((counts == 1).sum()), "draws": draws, "contrasts": [],
    }  # fmt: skip
    if len(sources) < MIN_SOURCES:
        out["insufficient"] = f"fewer than {MIN_SOURCES} independent sources"
        return out
    for pi in prevalences:
        for metric in CONTRAST_METRICS:
            values = np.array([row[pi][metric] for row in per_problem])
            out["contrasts"].append(
                {"prevalence": pi, "metric": metric}
                | bootstrap(values, clusters, by_cluster=True, draws=draws)
            )
    adjusted = holm([c["p_two_sided"] for c in out["contrasts"]])
    for item, value in zip(out["contrasts"], adjusted, strict=True):
        item["HOLM_P"] = value
    return out

mutants_x_contrasts__mutmut['_mutmut_orig'] = x_contrasts__mutmut_orig # type: ignore # mutmut generated
mutants_x_contrasts__mutmut['x_contrasts__mutmut_1'] = x_contrasts__mutmut_1 # type: ignore # mutmut generated
mutants_x_contrasts__mutmut['x_contrasts__mutmut_2'] = x_contrasts__mutmut_2 # type: ignore # mutmut generated
mutants_x_contrasts__mutmut['x_contrasts__mutmut_3'] = x_contrasts__mutmut_3 # type: ignore # mutmut generated
mutants_x_contrasts__mutmut['x_contrasts__mutmut_4'] = x_contrasts__mutmut_4 # type: ignore # mutmut generated
mutants_x_contrasts__mutmut['x_contrasts__mutmut_5'] = x_contrasts__mutmut_5 # type: ignore # mutmut generated
mutants_x_contrasts__mutmut['x_contrasts__mutmut_6'] = x_contrasts__mutmut_6 # type: ignore # mutmut generated
mutants_x_contrasts__mutmut['x_contrasts__mutmut_7'] = x_contrasts__mutmut_7 # type: ignore # mutmut generated
mutants_x_contrasts__mutmut['x_contrasts__mutmut_8'] = x_contrasts__mutmut_8 # type: ignore # mutmut generated
mutants_x_contrasts__mutmut['x_contrasts__mutmut_9'] = x_contrasts__mutmut_9 # type: ignore # mutmut generated
mutants_x_contrasts__mutmut['x_contrasts__mutmut_10'] = x_contrasts__mutmut_10 # type: ignore # mutmut generated
mutants_x_contrasts__mutmut['x_contrasts__mutmut_11'] = x_contrasts__mutmut_11 # type: ignore # mutmut generated
mutants_x_contrasts__mutmut['x_contrasts__mutmut_12'] = x_contrasts__mutmut_12 # type: ignore # mutmut generated
mutants_x_contrasts__mutmut['x_contrasts__mutmut_13'] = x_contrasts__mutmut_13 # type: ignore # mutmut generated
mutants_x_contrasts__mutmut['x_contrasts__mutmut_14'] = x_contrasts__mutmut_14 # type: ignore # mutmut generated
mutants_x_contrasts__mutmut['x_contrasts__mutmut_15'] = x_contrasts__mutmut_15 # type: ignore # mutmut generated
mutants_x_contrasts__mutmut['x_contrasts__mutmut_16'] = x_contrasts__mutmut_16 # type: ignore # mutmut generated
mutants_x_contrasts__mutmut['x_contrasts__mutmut_17'] = x_contrasts__mutmut_17 # type: ignore # mutmut generated
mutants_x_contrasts__mutmut['x_contrasts__mutmut_18'] = x_contrasts__mutmut_18 # type: ignore # mutmut generated
mutants_x_contrasts__mutmut['x_contrasts__mutmut_19'] = x_contrasts__mutmut_19 # type: ignore # mutmut generated
mutants_x_contrasts__mutmut['x_contrasts__mutmut_20'] = x_contrasts__mutmut_20 # type: ignore # mutmut generated
mutants_x_contrasts__mutmut['x_contrasts__mutmut_21'] = x_contrasts__mutmut_21 # type: ignore # mutmut generated
mutants_x_contrasts__mutmut['x_contrasts__mutmut_22'] = x_contrasts__mutmut_22 # type: ignore # mutmut generated
mutants_x_contrasts__mutmut['x_contrasts__mutmut_23'] = x_contrasts__mutmut_23 # type: ignore # mutmut generated
mutants_x_contrasts__mutmut['x_contrasts__mutmut_24'] = x_contrasts__mutmut_24 # type: ignore # mutmut generated
mutants_x_contrasts__mutmut['x_contrasts__mutmut_25'] = x_contrasts__mutmut_25 # type: ignore # mutmut generated
mutants_x_contrasts__mutmut['x_contrasts__mutmut_26'] = x_contrasts__mutmut_26 # type: ignore # mutmut generated
mutants_x_contrasts__mutmut['x_contrasts__mutmut_27'] = x_contrasts__mutmut_27 # type: ignore # mutmut generated
mutants_x_contrasts__mutmut['x_contrasts__mutmut_28'] = x_contrasts__mutmut_28 # type: ignore # mutmut generated
mutants_x_contrasts__mutmut['x_contrasts__mutmut_29'] = x_contrasts__mutmut_29 # type: ignore # mutmut generated
mutants_x_contrasts__mutmut['x_contrasts__mutmut_30'] = x_contrasts__mutmut_30 # type: ignore # mutmut generated
mutants_x_contrasts__mutmut['x_contrasts__mutmut_31'] = x_contrasts__mutmut_31 # type: ignore # mutmut generated
mutants_x_contrasts__mutmut['x_contrasts__mutmut_32'] = x_contrasts__mutmut_32 # type: ignore # mutmut generated
mutants_x_contrasts__mutmut['x_contrasts__mutmut_33'] = x_contrasts__mutmut_33 # type: ignore # mutmut generated
mutants_x_contrasts__mutmut['x_contrasts__mutmut_34'] = x_contrasts__mutmut_34 # type: ignore # mutmut generated
mutants_x_contrasts__mutmut['x_contrasts__mutmut_35'] = x_contrasts__mutmut_35 # type: ignore # mutmut generated
mutants_x_contrasts__mutmut['x_contrasts__mutmut_36'] = x_contrasts__mutmut_36 # type: ignore # mutmut generated
mutants_x_contrasts__mutmut['x_contrasts__mutmut_37'] = x_contrasts__mutmut_37 # type: ignore # mutmut generated
mutants_x_contrasts__mutmut['x_contrasts__mutmut_38'] = x_contrasts__mutmut_38 # type: ignore # mutmut generated
mutants_x_contrasts__mutmut['x_contrasts__mutmut_39'] = x_contrasts__mutmut_39 # type: ignore # mutmut generated
mutants_x_contrasts__mutmut['x_contrasts__mutmut_40'] = x_contrasts__mutmut_40 # type: ignore # mutmut generated
mutants_x_contrasts__mutmut['x_contrasts__mutmut_41'] = x_contrasts__mutmut_41 # type: ignore # mutmut generated
mutants_x_contrasts__mutmut['x_contrasts__mutmut_42'] = x_contrasts__mutmut_42 # type: ignore # mutmut generated
mutants_x_contrasts__mutmut['x_contrasts__mutmut_43'] = x_contrasts__mutmut_43 # type: ignore # mutmut generated
mutants_x_contrasts__mutmut['x_contrasts__mutmut_44'] = x_contrasts__mutmut_44 # type: ignore # mutmut generated
mutants_x_contrasts__mutmut['x_contrasts__mutmut_45'] = x_contrasts__mutmut_45 # type: ignore # mutmut generated
mutants_x_contrasts__mutmut['x_contrasts__mutmut_46'] = x_contrasts__mutmut_46 # type: ignore # mutmut generated
mutants_x_contrasts__mutmut['x_contrasts__mutmut_47'] = x_contrasts__mutmut_47 # type: ignore # mutmut generated
mutants_x_contrasts__mutmut['x_contrasts__mutmut_48'] = x_contrasts__mutmut_48 # type: ignore # mutmut generated
mutants_x_contrasts__mutmut['x_contrasts__mutmut_49'] = x_contrasts__mutmut_49 # type: ignore # mutmut generated
mutants_x_contrasts__mutmut['x_contrasts__mutmut_50'] = x_contrasts__mutmut_50 # type: ignore # mutmut generated
mutants_x_contrasts__mutmut['x_contrasts__mutmut_51'] = x_contrasts__mutmut_51 # type: ignore # mutmut generated
mutants_x_contrasts__mutmut['x_contrasts__mutmut_52'] = x_contrasts__mutmut_52 # type: ignore # mutmut generated
mutants_x_contrasts__mutmut['x_contrasts__mutmut_53'] = x_contrasts__mutmut_53 # type: ignore # mutmut generated
mutants_x_contrasts__mutmut['x_contrasts__mutmut_54'] = x_contrasts__mutmut_54 # type: ignore # mutmut generated
mutants_x_contrasts__mutmut['x_contrasts__mutmut_55'] = x_contrasts__mutmut_55 # type: ignore # mutmut generated
mutants_x_contrasts__mutmut['x_contrasts__mutmut_56'] = x_contrasts__mutmut_56 # type: ignore # mutmut generated
mutants_x_contrasts__mutmut['x_contrasts__mutmut_57'] = x_contrasts__mutmut_57 # type: ignore # mutmut generated
mutants_x_contrasts__mutmut['x_contrasts__mutmut_58'] = x_contrasts__mutmut_58 # type: ignore # mutmut generated
mutants_x_contrasts__mutmut['x_contrasts__mutmut_59'] = x_contrasts__mutmut_59 # type: ignore # mutmut generated
mutants_x_contrasts__mutmut['x_contrasts__mutmut_60'] = x_contrasts__mutmut_60 # type: ignore # mutmut generated
mutants_x_contrasts__mutmut['x_contrasts__mutmut_61'] = x_contrasts__mutmut_61 # type: ignore # mutmut generated
mutants_x_contrasts__mutmut['x_contrasts__mutmut_62'] = x_contrasts__mutmut_62 # type: ignore # mutmut generated
mutants_x_contrasts__mutmut['x_contrasts__mutmut_63'] = x_contrasts__mutmut_63 # type: ignore # mutmut generated
mutants_x_contrasts__mutmut['x_contrasts__mutmut_64'] = x_contrasts__mutmut_64 # type: ignore # mutmut generated
mutants_x_contrasts__mutmut['x_contrasts__mutmut_65'] = x_contrasts__mutmut_65 # type: ignore # mutmut generated
mutants_x_contrasts__mutmut['x_contrasts__mutmut_66'] = x_contrasts__mutmut_66 # type: ignore # mutmut generated
mutants_x_contrasts__mutmut['x_contrasts__mutmut_67'] = x_contrasts__mutmut_67 # type: ignore # mutmut generated
mutants_x_contrasts__mutmut['x_contrasts__mutmut_68'] = x_contrasts__mutmut_68 # type: ignore # mutmut generated
mutants_x_contrasts__mutmut['x_contrasts__mutmut_69'] = x_contrasts__mutmut_69 # type: ignore # mutmut generated
mutants_x_contrasts__mutmut['x_contrasts__mutmut_70'] = x_contrasts__mutmut_70 # type: ignore # mutmut generated
mutants_x_contrasts__mutmut['x_contrasts__mutmut_71'] = x_contrasts__mutmut_71 # type: ignore # mutmut generated
mutants_x_contrasts__mutmut['x_contrasts__mutmut_72'] = x_contrasts__mutmut_72 # type: ignore # mutmut generated
mutants_x_contrasts__mutmut['x_contrasts__mutmut_73'] = x_contrasts__mutmut_73 # type: ignore # mutmut generated
mutants_x_contrasts__mutmut['x_contrasts__mutmut_74'] = x_contrasts__mutmut_74 # type: ignore # mutmut generated
mutants_x_contrasts__mutmut['x_contrasts__mutmut_75'] = x_contrasts__mutmut_75 # type: ignore # mutmut generated
mutants_x_contrasts__mutmut['x_contrasts__mutmut_76'] = x_contrasts__mutmut_76 # type: ignore # mutmut generated
mutants_x_contrasts__mutmut['x_contrasts__mutmut_77'] = x_contrasts__mutmut_77 # type: ignore # mutmut generated
mutants_x_contrasts__mutmut['x_contrasts__mutmut_78'] = x_contrasts__mutmut_78 # type: ignore # mutmut generated
mutants_x_contrasts__mutmut['x_contrasts__mutmut_79'] = x_contrasts__mutmut_79 # type: ignore # mutmut generated
mutants_x_contrasts__mutmut['x_contrasts__mutmut_80'] = x_contrasts__mutmut_80 # type: ignore # mutmut generated
mutants_x_contrasts__mutmut['x_contrasts__mutmut_81'] = x_contrasts__mutmut_81 # type: ignore # mutmut generated
mutants_x_contrasts__mutmut['x_contrasts__mutmut_82'] = x_contrasts__mutmut_82 # type: ignore # mutmut generated
mutants_x_contrasts__mutmut['x_contrasts__mutmut_83'] = x_contrasts__mutmut_83 # type: ignore # mutmut generated
mutants_x_contrasts__mutmut['x_contrasts__mutmut_84'] = x_contrasts__mutmut_84 # type: ignore # mutmut generated
mutants_x_contrasts__mutmut['x_contrasts__mutmut_85'] = x_contrasts__mutmut_85 # type: ignore # mutmut generated
mutants_x_contrasts__mutmut['x_contrasts__mutmut_86'] = x_contrasts__mutmut_86 # type: ignore # mutmut generated
mutants_x_contrasts__mutmut['x_contrasts__mutmut_87'] = x_contrasts__mutmut_87 # type: ignore # mutmut generated
mutants_x_contrasts__mutmut['x_contrasts__mutmut_88'] = x_contrasts__mutmut_88 # type: ignore # mutmut generated
mutants_x_contrasts__mutmut['x_contrasts__mutmut_89'] = x_contrasts__mutmut_89 # type: ignore # mutmut generated
mutants_x_contrasts__mutmut['x_contrasts__mutmut_90'] = x_contrasts__mutmut_90 # type: ignore # mutmut generated
mutants_x_contrasts__mutmut['x_contrasts__mutmut_91'] = x_contrasts__mutmut_91 # type: ignore # mutmut generated
mutants_x_contrasts__mutmut['x_contrasts__mutmut_92'] = x_contrasts__mutmut_92 # type: ignore # mutmut generated
mutants_x_contrasts__mutmut['x_contrasts__mutmut_93'] = x_contrasts__mutmut_93 # type: ignore # mutmut generated
mutants_x_contrasts__mutmut['x_contrasts__mutmut_94'] = x_contrasts__mutmut_94 # type: ignore # mutmut generated
mutants_x_contrasts__mutmut['x_contrasts__mutmut_95'] = x_contrasts__mutmut_95 # type: ignore # mutmut generated
mutants_x_contrasts__mutmut['x_contrasts__mutmut_96'] = x_contrasts__mutmut_96 # type: ignore # mutmut generated
mutants_x_contrasts__mutmut['x_contrasts__mutmut_97'] = x_contrasts__mutmut_97 # type: ignore # mutmut generated
mutants_x_contrasts__mutmut['x_contrasts__mutmut_98'] = x_contrasts__mutmut_98 # type: ignore # mutmut generated
mutants_x_contrasts__mutmut['x_contrasts__mutmut_99'] = x_contrasts__mutmut_99 # type: ignore # mutmut generated
mutants_x_contrasts__mutmut['x_contrasts__mutmut_100'] = x_contrasts__mutmut_100 # type: ignore # mutmut generated
mutants_x_contrasts__mutmut['x_contrasts__mutmut_101'] = x_contrasts__mutmut_101 # type: ignore # mutmut generated
mutants_x_contrasts__mutmut['x_contrasts__mutmut_102'] = x_contrasts__mutmut_102 # type: ignore # mutmut generated
mutants_x_contrasts__mutmut['x_contrasts__mutmut_103'] = x_contrasts__mutmut_103 # type: ignore # mutmut generated
mutants_x_contrasts__mutmut['x_contrasts__mutmut_104'] = x_contrasts__mutmut_104 # type: ignore # mutmut generated
mutants_x_contrasts__mutmut['x_contrasts__mutmut_105'] = x_contrasts__mutmut_105 # type: ignore # mutmut generated
mutants_x_contrasts__mutmut['x_contrasts__mutmut_106'] = x_contrasts__mutmut_106 # type: ignore # mutmut generated
mutants_x_contrasts__mutmut['x_contrasts__mutmut_107'] = x_contrasts__mutmut_107 # type: ignore # mutmut generated
mutants_x_contrasts__mutmut['x_contrasts__mutmut_108'] = x_contrasts__mutmut_108 # type: ignore # mutmut generated
mutants_x_contrasts__mutmut['x_contrasts__mutmut_109'] = x_contrasts__mutmut_109 # type: ignore # mutmut generated
mutants_x_contrasts__mutmut['x_contrasts__mutmut_110'] = x_contrasts__mutmut_110 # type: ignore # mutmut generated
mutants_x_contrasts__mutmut['x_contrasts__mutmut_111'] = x_contrasts__mutmut_111 # type: ignore # mutmut generated
mutants_x_contrasts__mutmut['x_contrasts__mutmut_112'] = x_contrasts__mutmut_112 # type: ignore # mutmut generated
mutants_x_contrasts__mutmut['x_contrasts__mutmut_113'] = x_contrasts__mutmut_113 # type: ignore # mutmut generated
mutants_x_contrasts__mutmut['x_contrasts__mutmut_114'] = x_contrasts__mutmut_114 # type: ignore # mutmut generated
mutants_x_contrasts__mutmut['x_contrasts__mutmut_115'] = x_contrasts__mutmut_115 # type: ignore # mutmut generated
mutants_x_contrasts__mutmut['x_contrasts__mutmut_116'] = x_contrasts__mutmut_116 # type: ignore # mutmut generated
mutants_x_contrasts__mutmut['x_contrasts__mutmut_117'] = x_contrasts__mutmut_117 # type: ignore # mutmut generated
mutants_x_contrasts__mutmut['x_contrasts__mutmut_118'] = x_contrasts__mutmut_118 # type: ignore # mutmut generated
mutants_x_contrasts__mutmut['x_contrasts__mutmut_119'] = x_contrasts__mutmut_119 # type: ignore # mutmut generated
mutants_x_contrasts__mutmut['x_contrasts__mutmut_120'] = x_contrasts__mutmut_120 # type: ignore # mutmut generated
mutants_x_contrasts__mutmut['x_contrasts__mutmut_121'] = x_contrasts__mutmut_121 # type: ignore # mutmut generated
mutants_x_contrasts__mutmut['x_contrasts__mutmut_122'] = x_contrasts__mutmut_122 # type: ignore # mutmut generated
mutants_x_contrasts__mutmut['x_contrasts__mutmut_123'] = x_contrasts__mutmut_123 # type: ignore # mutmut generated
mutants_x_contrasts__mutmut['x_contrasts__mutmut_124'] = x_contrasts__mutmut_124 # type: ignore # mutmut generated
mutants_x_contrasts__mutmut['x_contrasts__mutmut_125'] = x_contrasts__mutmut_125 # type: ignore # mutmut generated
mutants_x_contrasts__mutmut['x_contrasts__mutmut_126'] = x_contrasts__mutmut_126 # type: ignore # mutmut generated
mutants_x_contrasts__mutmut['x_contrasts__mutmut_127'] = x_contrasts__mutmut_127 # type: ignore # mutmut generated
mutants_x_contrasts__mutmut['x_contrasts__mutmut_128'] = x_contrasts__mutmut_128 # type: ignore # mutmut generated
mutants_x_contrasts__mutmut['x_contrasts__mutmut_129'] = x_contrasts__mutmut_129 # type: ignore # mutmut generated
mutants_x_contrasts__mutmut['x_contrasts__mutmut_130'] = x_contrasts__mutmut_130 # type: ignore # mutmut generated
mutants_x_contrasts__mutmut['x_contrasts__mutmut_131'] = x_contrasts__mutmut_131 # type: ignore # mutmut generated
mutants_x_contrasts__mutmut['x_contrasts__mutmut_132'] = x_contrasts__mutmut_132 # type: ignore # mutmut generated
mutants_x_contrasts__mutmut['x_contrasts__mutmut_133'] = x_contrasts__mutmut_133 # type: ignore # mutmut generated
mutants_x_contrasts__mutmut['x_contrasts__mutmut_134'] = x_contrasts__mutmut_134 # type: ignore # mutmut generated
mutants_x_main__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_main__mutmut)
def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("folders", nargs="+", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--draws", type=int, default=DRAWS)
    args = parser.parse_args(argv)
    from matched_alert import load

    runs = load(*args.folders)
    summary = summarize(runs, draws=args.draws)
    summary["contrasts"] = {
        str(b): contrasts(runs, b, draws=args.draws) for b in (0.01, 0.02, 0.05)
    }
    args.output.write_text(json.dumps(summary, indent=1, sort_keys=True) + "\n")
    return 0


def x_main__mutmut_orig(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("folders", nargs="+", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--draws", type=int, default=DRAWS)
    args = parser.parse_args(argv)
    from matched_alert import load

    runs = load(*args.folders)
    summary = summarize(runs, draws=args.draws)
    summary["contrasts"] = {
        str(b): contrasts(runs, b, draws=args.draws) for b in (0.01, 0.02, 0.05)
    }
    args.output.write_text(json.dumps(summary, indent=1, sort_keys=True) + "\n")
    return 0


def x_main__mutmut_1(argv: list[str] | None = None) -> int:
    parser = None
    parser.add_argument("folders", nargs="+", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--draws", type=int, default=DRAWS)
    args = parser.parse_args(argv)
    from matched_alert import load

    runs = load(*args.folders)
    summary = summarize(runs, draws=args.draws)
    summary["contrasts"] = {
        str(b): contrasts(runs, b, draws=args.draws) for b in (0.01, 0.02, 0.05)
    }
    args.output.write_text(json.dumps(summary, indent=1, sort_keys=True) + "\n")
    return 0


def x_main__mutmut_2(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=None)
    parser.add_argument("folders", nargs="+", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--draws", type=int, default=DRAWS)
    args = parser.parse_args(argv)
    from matched_alert import load

    runs = load(*args.folders)
    summary = summarize(runs, draws=args.draws)
    summary["contrasts"] = {
        str(b): contrasts(runs, b, draws=args.draws) for b in (0.01, 0.02, 0.05)
    }
    args.output.write_text(json.dumps(summary, indent=1, sort_keys=True) + "\n")
    return 0


def x_main__mutmut_3(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(None, nargs="+", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--draws", type=int, default=DRAWS)
    args = parser.parse_args(argv)
    from matched_alert import load

    runs = load(*args.folders)
    summary = summarize(runs, draws=args.draws)
    summary["contrasts"] = {
        str(b): contrasts(runs, b, draws=args.draws) for b in (0.01, 0.02, 0.05)
    }
    args.output.write_text(json.dumps(summary, indent=1, sort_keys=True) + "\n")
    return 0


def x_main__mutmut_4(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("folders", nargs=None, type=Path)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--draws", type=int, default=DRAWS)
    args = parser.parse_args(argv)
    from matched_alert import load

    runs = load(*args.folders)
    summary = summarize(runs, draws=args.draws)
    summary["contrasts"] = {
        str(b): contrasts(runs, b, draws=args.draws) for b in (0.01, 0.02, 0.05)
    }
    args.output.write_text(json.dumps(summary, indent=1, sort_keys=True) + "\n")
    return 0


def x_main__mutmut_5(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("folders", nargs="+", type=None)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--draws", type=int, default=DRAWS)
    args = parser.parse_args(argv)
    from matched_alert import load

    runs = load(*args.folders)
    summary = summarize(runs, draws=args.draws)
    summary["contrasts"] = {
        str(b): contrasts(runs, b, draws=args.draws) for b in (0.01, 0.02, 0.05)
    }
    args.output.write_text(json.dumps(summary, indent=1, sort_keys=True) + "\n")
    return 0


def x_main__mutmut_6(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(nargs="+", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--draws", type=int, default=DRAWS)
    args = parser.parse_args(argv)
    from matched_alert import load

    runs = load(*args.folders)
    summary = summarize(runs, draws=args.draws)
    summary["contrasts"] = {
        str(b): contrasts(runs, b, draws=args.draws) for b in (0.01, 0.02, 0.05)
    }
    args.output.write_text(json.dumps(summary, indent=1, sort_keys=True) + "\n")
    return 0


def x_main__mutmut_7(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("folders", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--draws", type=int, default=DRAWS)
    args = parser.parse_args(argv)
    from matched_alert import load

    runs = load(*args.folders)
    summary = summarize(runs, draws=args.draws)
    summary["contrasts"] = {
        str(b): contrasts(runs, b, draws=args.draws) for b in (0.01, 0.02, 0.05)
    }
    args.output.write_text(json.dumps(summary, indent=1, sort_keys=True) + "\n")
    return 0


def x_main__mutmut_8(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("folders", nargs="+", )
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--draws", type=int, default=DRAWS)
    args = parser.parse_args(argv)
    from matched_alert import load

    runs = load(*args.folders)
    summary = summarize(runs, draws=args.draws)
    summary["contrasts"] = {
        str(b): contrasts(runs, b, draws=args.draws) for b in (0.01, 0.02, 0.05)
    }
    args.output.write_text(json.dumps(summary, indent=1, sort_keys=True) + "\n")
    return 0


def x_main__mutmut_9(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("XXfoldersXX", nargs="+", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--draws", type=int, default=DRAWS)
    args = parser.parse_args(argv)
    from matched_alert import load

    runs = load(*args.folders)
    summary = summarize(runs, draws=args.draws)
    summary["contrasts"] = {
        str(b): contrasts(runs, b, draws=args.draws) for b in (0.01, 0.02, 0.05)
    }
    args.output.write_text(json.dumps(summary, indent=1, sort_keys=True) + "\n")
    return 0


def x_main__mutmut_10(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("FOLDERS", nargs="+", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--draws", type=int, default=DRAWS)
    args = parser.parse_args(argv)
    from matched_alert import load

    runs = load(*args.folders)
    summary = summarize(runs, draws=args.draws)
    summary["contrasts"] = {
        str(b): contrasts(runs, b, draws=args.draws) for b in (0.01, 0.02, 0.05)
    }
    args.output.write_text(json.dumps(summary, indent=1, sort_keys=True) + "\n")
    return 0


def x_main__mutmut_11(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("folders", nargs="XX+XX", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--draws", type=int, default=DRAWS)
    args = parser.parse_args(argv)
    from matched_alert import load

    runs = load(*args.folders)
    summary = summarize(runs, draws=args.draws)
    summary["contrasts"] = {
        str(b): contrasts(runs, b, draws=args.draws) for b in (0.01, 0.02, 0.05)
    }
    args.output.write_text(json.dumps(summary, indent=1, sort_keys=True) + "\n")
    return 0


def x_main__mutmut_12(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("folders", nargs="+", type=Path)
    parser.add_argument(None, type=Path, required=True)
    parser.add_argument("--draws", type=int, default=DRAWS)
    args = parser.parse_args(argv)
    from matched_alert import load

    runs = load(*args.folders)
    summary = summarize(runs, draws=args.draws)
    summary["contrasts"] = {
        str(b): contrasts(runs, b, draws=args.draws) for b in (0.01, 0.02, 0.05)
    }
    args.output.write_text(json.dumps(summary, indent=1, sort_keys=True) + "\n")
    return 0


def x_main__mutmut_13(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("folders", nargs="+", type=Path)
    parser.add_argument("--output", type=None, required=True)
    parser.add_argument("--draws", type=int, default=DRAWS)
    args = parser.parse_args(argv)
    from matched_alert import load

    runs = load(*args.folders)
    summary = summarize(runs, draws=args.draws)
    summary["contrasts"] = {
        str(b): contrasts(runs, b, draws=args.draws) for b in (0.01, 0.02, 0.05)
    }
    args.output.write_text(json.dumps(summary, indent=1, sort_keys=True) + "\n")
    return 0


def x_main__mutmut_14(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("folders", nargs="+", type=Path)
    parser.add_argument("--output", type=Path, required=None)
    parser.add_argument("--draws", type=int, default=DRAWS)
    args = parser.parse_args(argv)
    from matched_alert import load

    runs = load(*args.folders)
    summary = summarize(runs, draws=args.draws)
    summary["contrasts"] = {
        str(b): contrasts(runs, b, draws=args.draws) for b in (0.01, 0.02, 0.05)
    }
    args.output.write_text(json.dumps(summary, indent=1, sort_keys=True) + "\n")
    return 0


def x_main__mutmut_15(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("folders", nargs="+", type=Path)
    parser.add_argument(type=Path, required=True)
    parser.add_argument("--draws", type=int, default=DRAWS)
    args = parser.parse_args(argv)
    from matched_alert import load

    runs = load(*args.folders)
    summary = summarize(runs, draws=args.draws)
    summary["contrasts"] = {
        str(b): contrasts(runs, b, draws=args.draws) for b in (0.01, 0.02, 0.05)
    }
    args.output.write_text(json.dumps(summary, indent=1, sort_keys=True) + "\n")
    return 0


def x_main__mutmut_16(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("folders", nargs="+", type=Path)
    parser.add_argument("--output", required=True)
    parser.add_argument("--draws", type=int, default=DRAWS)
    args = parser.parse_args(argv)
    from matched_alert import load

    runs = load(*args.folders)
    summary = summarize(runs, draws=args.draws)
    summary["contrasts"] = {
        str(b): contrasts(runs, b, draws=args.draws) for b in (0.01, 0.02, 0.05)
    }
    args.output.write_text(json.dumps(summary, indent=1, sort_keys=True) + "\n")
    return 0


def x_main__mutmut_17(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("folders", nargs="+", type=Path)
    parser.add_argument("--output", type=Path, )
    parser.add_argument("--draws", type=int, default=DRAWS)
    args = parser.parse_args(argv)
    from matched_alert import load

    runs = load(*args.folders)
    summary = summarize(runs, draws=args.draws)
    summary["contrasts"] = {
        str(b): contrasts(runs, b, draws=args.draws) for b in (0.01, 0.02, 0.05)
    }
    args.output.write_text(json.dumps(summary, indent=1, sort_keys=True) + "\n")
    return 0


def x_main__mutmut_18(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("folders", nargs="+", type=Path)
    parser.add_argument("XX--outputXX", type=Path, required=True)
    parser.add_argument("--draws", type=int, default=DRAWS)
    args = parser.parse_args(argv)
    from matched_alert import load

    runs = load(*args.folders)
    summary = summarize(runs, draws=args.draws)
    summary["contrasts"] = {
        str(b): contrasts(runs, b, draws=args.draws) for b in (0.01, 0.02, 0.05)
    }
    args.output.write_text(json.dumps(summary, indent=1, sort_keys=True) + "\n")
    return 0


def x_main__mutmut_19(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("folders", nargs="+", type=Path)
    parser.add_argument("--OUTPUT", type=Path, required=True)
    parser.add_argument("--draws", type=int, default=DRAWS)
    args = parser.parse_args(argv)
    from matched_alert import load

    runs = load(*args.folders)
    summary = summarize(runs, draws=args.draws)
    summary["contrasts"] = {
        str(b): contrasts(runs, b, draws=args.draws) for b in (0.01, 0.02, 0.05)
    }
    args.output.write_text(json.dumps(summary, indent=1, sort_keys=True) + "\n")
    return 0


def x_main__mutmut_20(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("folders", nargs="+", type=Path)
    parser.add_argument("--output", type=Path, required=False)
    parser.add_argument("--draws", type=int, default=DRAWS)
    args = parser.parse_args(argv)
    from matched_alert import load

    runs = load(*args.folders)
    summary = summarize(runs, draws=args.draws)
    summary["contrasts"] = {
        str(b): contrasts(runs, b, draws=args.draws) for b in (0.01, 0.02, 0.05)
    }
    args.output.write_text(json.dumps(summary, indent=1, sort_keys=True) + "\n")
    return 0


def x_main__mutmut_21(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("folders", nargs="+", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument(None, type=int, default=DRAWS)
    args = parser.parse_args(argv)
    from matched_alert import load

    runs = load(*args.folders)
    summary = summarize(runs, draws=args.draws)
    summary["contrasts"] = {
        str(b): contrasts(runs, b, draws=args.draws) for b in (0.01, 0.02, 0.05)
    }
    args.output.write_text(json.dumps(summary, indent=1, sort_keys=True) + "\n")
    return 0


def x_main__mutmut_22(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("folders", nargs="+", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--draws", type=None, default=DRAWS)
    args = parser.parse_args(argv)
    from matched_alert import load

    runs = load(*args.folders)
    summary = summarize(runs, draws=args.draws)
    summary["contrasts"] = {
        str(b): contrasts(runs, b, draws=args.draws) for b in (0.01, 0.02, 0.05)
    }
    args.output.write_text(json.dumps(summary, indent=1, sort_keys=True) + "\n")
    return 0


def x_main__mutmut_23(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("folders", nargs="+", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--draws", type=int, default=None)
    args = parser.parse_args(argv)
    from matched_alert import load

    runs = load(*args.folders)
    summary = summarize(runs, draws=args.draws)
    summary["contrasts"] = {
        str(b): contrasts(runs, b, draws=args.draws) for b in (0.01, 0.02, 0.05)
    }
    args.output.write_text(json.dumps(summary, indent=1, sort_keys=True) + "\n")
    return 0


def x_main__mutmut_24(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("folders", nargs="+", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument(type=int, default=DRAWS)
    args = parser.parse_args(argv)
    from matched_alert import load

    runs = load(*args.folders)
    summary = summarize(runs, draws=args.draws)
    summary["contrasts"] = {
        str(b): contrasts(runs, b, draws=args.draws) for b in (0.01, 0.02, 0.05)
    }
    args.output.write_text(json.dumps(summary, indent=1, sort_keys=True) + "\n")
    return 0


def x_main__mutmut_25(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("folders", nargs="+", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--draws", default=DRAWS)
    args = parser.parse_args(argv)
    from matched_alert import load

    runs = load(*args.folders)
    summary = summarize(runs, draws=args.draws)
    summary["contrasts"] = {
        str(b): contrasts(runs, b, draws=args.draws) for b in (0.01, 0.02, 0.05)
    }
    args.output.write_text(json.dumps(summary, indent=1, sort_keys=True) + "\n")
    return 0


def x_main__mutmut_26(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("folders", nargs="+", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--draws", type=int, )
    args = parser.parse_args(argv)
    from matched_alert import load

    runs = load(*args.folders)
    summary = summarize(runs, draws=args.draws)
    summary["contrasts"] = {
        str(b): contrasts(runs, b, draws=args.draws) for b in (0.01, 0.02, 0.05)
    }
    args.output.write_text(json.dumps(summary, indent=1, sort_keys=True) + "\n")
    return 0


def x_main__mutmut_27(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("folders", nargs="+", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("XX--drawsXX", type=int, default=DRAWS)
    args = parser.parse_args(argv)
    from matched_alert import load

    runs = load(*args.folders)
    summary = summarize(runs, draws=args.draws)
    summary["contrasts"] = {
        str(b): contrasts(runs, b, draws=args.draws) for b in (0.01, 0.02, 0.05)
    }
    args.output.write_text(json.dumps(summary, indent=1, sort_keys=True) + "\n")
    return 0


def x_main__mutmut_28(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("folders", nargs="+", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--DRAWS", type=int, default=DRAWS)
    args = parser.parse_args(argv)
    from matched_alert import load

    runs = load(*args.folders)
    summary = summarize(runs, draws=args.draws)
    summary["contrasts"] = {
        str(b): contrasts(runs, b, draws=args.draws) for b in (0.01, 0.02, 0.05)
    }
    args.output.write_text(json.dumps(summary, indent=1, sort_keys=True) + "\n")
    return 0


def x_main__mutmut_29(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("folders", nargs="+", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--draws", type=int, default=DRAWS)
    args = None
    from matched_alert import load

    runs = load(*args.folders)
    summary = summarize(runs, draws=args.draws)
    summary["contrasts"] = {
        str(b): contrasts(runs, b, draws=args.draws) for b in (0.01, 0.02, 0.05)
    }
    args.output.write_text(json.dumps(summary, indent=1, sort_keys=True) + "\n")
    return 0


def x_main__mutmut_30(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("folders", nargs="+", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--draws", type=int, default=DRAWS)
    args = parser.parse_args(None)
    from matched_alert import load

    runs = load(*args.folders)
    summary = summarize(runs, draws=args.draws)
    summary["contrasts"] = {
        str(b): contrasts(runs, b, draws=args.draws) for b in (0.01, 0.02, 0.05)
    }
    args.output.write_text(json.dumps(summary, indent=1, sort_keys=True) + "\n")
    return 0


def x_main__mutmut_31(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("folders", nargs="+", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--draws", type=int, default=DRAWS)
    args = parser.parse_args(argv)
    from matched_alert import load

    runs = None
    summary = summarize(runs, draws=args.draws)
    summary["contrasts"] = {
        str(b): contrasts(runs, b, draws=args.draws) for b in (0.01, 0.02, 0.05)
    }
    args.output.write_text(json.dumps(summary, indent=1, sort_keys=True) + "\n")
    return 0


def x_main__mutmut_32(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("folders", nargs="+", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--draws", type=int, default=DRAWS)
    args = parser.parse_args(argv)
    from matched_alert import load

    runs = load(*args.folders)
    summary = None
    summary["contrasts"] = {
        str(b): contrasts(runs, b, draws=args.draws) for b in (0.01, 0.02, 0.05)
    }
    args.output.write_text(json.dumps(summary, indent=1, sort_keys=True) + "\n")
    return 0


def x_main__mutmut_33(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("folders", nargs="+", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--draws", type=int, default=DRAWS)
    args = parser.parse_args(argv)
    from matched_alert import load

    runs = load(*args.folders)
    summary = summarize(None, draws=args.draws)
    summary["contrasts"] = {
        str(b): contrasts(runs, b, draws=args.draws) for b in (0.01, 0.02, 0.05)
    }
    args.output.write_text(json.dumps(summary, indent=1, sort_keys=True) + "\n")
    return 0


def x_main__mutmut_34(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("folders", nargs="+", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--draws", type=int, default=DRAWS)
    args = parser.parse_args(argv)
    from matched_alert import load

    runs = load(*args.folders)
    summary = summarize(runs, draws=None)
    summary["contrasts"] = {
        str(b): contrasts(runs, b, draws=args.draws) for b in (0.01, 0.02, 0.05)
    }
    args.output.write_text(json.dumps(summary, indent=1, sort_keys=True) + "\n")
    return 0


def x_main__mutmut_35(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("folders", nargs="+", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--draws", type=int, default=DRAWS)
    args = parser.parse_args(argv)
    from matched_alert import load

    runs = load(*args.folders)
    summary = summarize(draws=args.draws)
    summary["contrasts"] = {
        str(b): contrasts(runs, b, draws=args.draws) for b in (0.01, 0.02, 0.05)
    }
    args.output.write_text(json.dumps(summary, indent=1, sort_keys=True) + "\n")
    return 0


def x_main__mutmut_36(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("folders", nargs="+", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--draws", type=int, default=DRAWS)
    args = parser.parse_args(argv)
    from matched_alert import load

    runs = load(*args.folders)
    summary = summarize(runs, )
    summary["contrasts"] = {
        str(b): contrasts(runs, b, draws=args.draws) for b in (0.01, 0.02, 0.05)
    }
    args.output.write_text(json.dumps(summary, indent=1, sort_keys=True) + "\n")
    return 0


def x_main__mutmut_37(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("folders", nargs="+", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--draws", type=int, default=DRAWS)
    args = parser.parse_args(argv)
    from matched_alert import load

    runs = load(*args.folders)
    summary = summarize(runs, draws=args.draws)
    summary["contrasts"] = None
    args.output.write_text(json.dumps(summary, indent=1, sort_keys=True) + "\n")
    return 0


def x_main__mutmut_38(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("folders", nargs="+", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--draws", type=int, default=DRAWS)
    args = parser.parse_args(argv)
    from matched_alert import load

    runs = load(*args.folders)
    summary = summarize(runs, draws=args.draws)
    summary["XXcontrastsXX"] = {
        str(b): contrasts(runs, b, draws=args.draws) for b in (0.01, 0.02, 0.05)
    }
    args.output.write_text(json.dumps(summary, indent=1, sort_keys=True) + "\n")
    return 0


def x_main__mutmut_39(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("folders", nargs="+", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--draws", type=int, default=DRAWS)
    args = parser.parse_args(argv)
    from matched_alert import load

    runs = load(*args.folders)
    summary = summarize(runs, draws=args.draws)
    summary["CONTRASTS"] = {
        str(b): contrasts(runs, b, draws=args.draws) for b in (0.01, 0.02, 0.05)
    }
    args.output.write_text(json.dumps(summary, indent=1, sort_keys=True) + "\n")
    return 0


def x_main__mutmut_40(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("folders", nargs="+", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--draws", type=int, default=DRAWS)
    args = parser.parse_args(argv)
    from matched_alert import load

    runs = load(*args.folders)
    summary = summarize(runs, draws=args.draws)
    summary["contrasts"] = {
        str(None): contrasts(runs, b, draws=args.draws) for b in (0.01, 0.02, 0.05)
    }
    args.output.write_text(json.dumps(summary, indent=1, sort_keys=True) + "\n")
    return 0


def x_main__mutmut_41(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("folders", nargs="+", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--draws", type=int, default=DRAWS)
    args = parser.parse_args(argv)
    from matched_alert import load

    runs = load(*args.folders)
    summary = summarize(runs, draws=args.draws)
    summary["contrasts"] = {
        str(b): contrasts(None, b, draws=args.draws) for b in (0.01, 0.02, 0.05)
    }
    args.output.write_text(json.dumps(summary, indent=1, sort_keys=True) + "\n")
    return 0


def x_main__mutmut_42(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("folders", nargs="+", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--draws", type=int, default=DRAWS)
    args = parser.parse_args(argv)
    from matched_alert import load

    runs = load(*args.folders)
    summary = summarize(runs, draws=args.draws)
    summary["contrasts"] = {
        str(b): contrasts(runs, None, draws=args.draws) for b in (0.01, 0.02, 0.05)
    }
    args.output.write_text(json.dumps(summary, indent=1, sort_keys=True) + "\n")
    return 0


def x_main__mutmut_43(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("folders", nargs="+", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--draws", type=int, default=DRAWS)
    args = parser.parse_args(argv)
    from matched_alert import load

    runs = load(*args.folders)
    summary = summarize(runs, draws=args.draws)
    summary["contrasts"] = {
        str(b): contrasts(runs, b, draws=None) for b in (0.01, 0.02, 0.05)
    }
    args.output.write_text(json.dumps(summary, indent=1, sort_keys=True) + "\n")
    return 0


def x_main__mutmut_44(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("folders", nargs="+", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--draws", type=int, default=DRAWS)
    args = parser.parse_args(argv)
    from matched_alert import load

    runs = load(*args.folders)
    summary = summarize(runs, draws=args.draws)
    summary["contrasts"] = {
        str(b): contrasts(b, draws=args.draws) for b in (0.01, 0.02, 0.05)
    }
    args.output.write_text(json.dumps(summary, indent=1, sort_keys=True) + "\n")
    return 0


def x_main__mutmut_45(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("folders", nargs="+", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--draws", type=int, default=DRAWS)
    args = parser.parse_args(argv)
    from matched_alert import load

    runs = load(*args.folders)
    summary = summarize(runs, draws=args.draws)
    summary["contrasts"] = {
        str(b): contrasts(runs, draws=args.draws) for b in (0.01, 0.02, 0.05)
    }
    args.output.write_text(json.dumps(summary, indent=1, sort_keys=True) + "\n")
    return 0


def x_main__mutmut_46(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("folders", nargs="+", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--draws", type=int, default=DRAWS)
    args = parser.parse_args(argv)
    from matched_alert import load

    runs = load(*args.folders)
    summary = summarize(runs, draws=args.draws)
    summary["contrasts"] = {
        str(b): contrasts(runs, b, ) for b in (0.01, 0.02, 0.05)
    }
    args.output.write_text(json.dumps(summary, indent=1, sort_keys=True) + "\n")
    return 0


def x_main__mutmut_47(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("folders", nargs="+", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--draws", type=int, default=DRAWS)
    args = parser.parse_args(argv)
    from matched_alert import load

    runs = load(*args.folders)
    summary = summarize(runs, draws=args.draws)
    summary["contrasts"] = {
        str(b): contrasts(runs, b, draws=args.draws) for b in (1.01, 0.02, 0.05)
    }
    args.output.write_text(json.dumps(summary, indent=1, sort_keys=True) + "\n")
    return 0


def x_main__mutmut_48(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("folders", nargs="+", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--draws", type=int, default=DRAWS)
    args = parser.parse_args(argv)
    from matched_alert import load

    runs = load(*args.folders)
    summary = summarize(runs, draws=args.draws)
    summary["contrasts"] = {
        str(b): contrasts(runs, b, draws=args.draws) for b in (0.01, 1.02, 0.05)
    }
    args.output.write_text(json.dumps(summary, indent=1, sort_keys=True) + "\n")
    return 0


def x_main__mutmut_49(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("folders", nargs="+", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--draws", type=int, default=DRAWS)
    args = parser.parse_args(argv)
    from matched_alert import load

    runs = load(*args.folders)
    summary = summarize(runs, draws=args.draws)
    summary["contrasts"] = {
        str(b): contrasts(runs, b, draws=args.draws) for b in (0.01, 0.02, 1.05)
    }
    args.output.write_text(json.dumps(summary, indent=1, sort_keys=True) + "\n")
    return 0


def x_main__mutmut_50(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("folders", nargs="+", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--draws", type=int, default=DRAWS)
    args = parser.parse_args(argv)
    from matched_alert import load

    runs = load(*args.folders)
    summary = summarize(runs, draws=args.draws)
    summary["contrasts"] = {
        str(b): contrasts(runs, b, draws=args.draws) for b in (0.01, 0.02, 0.05)
    }
    args.output.write_text(None)
    return 0


def x_main__mutmut_51(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("folders", nargs="+", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--draws", type=int, default=DRAWS)
    args = parser.parse_args(argv)
    from matched_alert import load

    runs = load(*args.folders)
    summary = summarize(runs, draws=args.draws)
    summary["contrasts"] = {
        str(b): contrasts(runs, b, draws=args.draws) for b in (0.01, 0.02, 0.05)
    }
    args.output.write_text(json.dumps(summary, indent=1, sort_keys=True) - "\n")
    return 0


def x_main__mutmut_52(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("folders", nargs="+", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--draws", type=int, default=DRAWS)
    args = parser.parse_args(argv)
    from matched_alert import load

    runs = load(*args.folders)
    summary = summarize(runs, draws=args.draws)
    summary["contrasts"] = {
        str(b): contrasts(runs, b, draws=args.draws) for b in (0.01, 0.02, 0.05)
    }
    args.output.write_text(json.dumps(None, indent=1, sort_keys=True) + "\n")
    return 0


def x_main__mutmut_53(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("folders", nargs="+", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--draws", type=int, default=DRAWS)
    args = parser.parse_args(argv)
    from matched_alert import load

    runs = load(*args.folders)
    summary = summarize(runs, draws=args.draws)
    summary["contrasts"] = {
        str(b): contrasts(runs, b, draws=args.draws) for b in (0.01, 0.02, 0.05)
    }
    args.output.write_text(json.dumps(summary, indent=None, sort_keys=True) + "\n")
    return 0


def x_main__mutmut_54(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("folders", nargs="+", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--draws", type=int, default=DRAWS)
    args = parser.parse_args(argv)
    from matched_alert import load

    runs = load(*args.folders)
    summary = summarize(runs, draws=args.draws)
    summary["contrasts"] = {
        str(b): contrasts(runs, b, draws=args.draws) for b in (0.01, 0.02, 0.05)
    }
    args.output.write_text(json.dumps(summary, indent=1, sort_keys=None) + "\n")
    return 0


def x_main__mutmut_55(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("folders", nargs="+", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--draws", type=int, default=DRAWS)
    args = parser.parse_args(argv)
    from matched_alert import load

    runs = load(*args.folders)
    summary = summarize(runs, draws=args.draws)
    summary["contrasts"] = {
        str(b): contrasts(runs, b, draws=args.draws) for b in (0.01, 0.02, 0.05)
    }
    args.output.write_text(json.dumps(indent=1, sort_keys=True) + "\n")
    return 0


def x_main__mutmut_56(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("folders", nargs="+", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--draws", type=int, default=DRAWS)
    args = parser.parse_args(argv)
    from matched_alert import load

    runs = load(*args.folders)
    summary = summarize(runs, draws=args.draws)
    summary["contrasts"] = {
        str(b): contrasts(runs, b, draws=args.draws) for b in (0.01, 0.02, 0.05)
    }
    args.output.write_text(json.dumps(summary, sort_keys=True) + "\n")
    return 0


def x_main__mutmut_57(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("folders", nargs="+", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--draws", type=int, default=DRAWS)
    args = parser.parse_args(argv)
    from matched_alert import load

    runs = load(*args.folders)
    summary = summarize(runs, draws=args.draws)
    summary["contrasts"] = {
        str(b): contrasts(runs, b, draws=args.draws) for b in (0.01, 0.02, 0.05)
    }
    args.output.write_text(json.dumps(summary, indent=1, ) + "\n")
    return 0


def x_main__mutmut_58(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("folders", nargs="+", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--draws", type=int, default=DRAWS)
    args = parser.parse_args(argv)
    from matched_alert import load

    runs = load(*args.folders)
    summary = summarize(runs, draws=args.draws)
    summary["contrasts"] = {
        str(b): contrasts(runs, b, draws=args.draws) for b in (0.01, 0.02, 0.05)
    }
    args.output.write_text(json.dumps(summary, indent=2, sort_keys=True) + "\n")
    return 0


def x_main__mutmut_59(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("folders", nargs="+", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--draws", type=int, default=DRAWS)
    args = parser.parse_args(argv)
    from matched_alert import load

    runs = load(*args.folders)
    summary = summarize(runs, draws=args.draws)
    summary["contrasts"] = {
        str(b): contrasts(runs, b, draws=args.draws) for b in (0.01, 0.02, 0.05)
    }
    args.output.write_text(json.dumps(summary, indent=1, sort_keys=False) + "\n")
    return 0


def x_main__mutmut_60(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("folders", nargs="+", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--draws", type=int, default=DRAWS)
    args = parser.parse_args(argv)
    from matched_alert import load

    runs = load(*args.folders)
    summary = summarize(runs, draws=args.draws)
    summary["contrasts"] = {
        str(b): contrasts(runs, b, draws=args.draws) for b in (0.01, 0.02, 0.05)
    }
    args.output.write_text(json.dumps(summary, indent=1, sort_keys=True) + "XX\nXX")
    return 0


def x_main__mutmut_61(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("folders", nargs="+", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--draws", type=int, default=DRAWS)
    args = parser.parse_args(argv)
    from matched_alert import load

    runs = load(*args.folders)
    summary = summarize(runs, draws=args.draws)
    summary["contrasts"] = {
        str(b): contrasts(runs, b, draws=args.draws) for b in (0.01, 0.02, 0.05)
    }
    args.output.write_text(json.dumps(summary, indent=1, sort_keys=True) + "\n")
    return 1

mutants_x_main__mutmut['_mutmut_orig'] = x_main__mutmut_orig # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_1'] = x_main__mutmut_1 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_2'] = x_main__mutmut_2 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_3'] = x_main__mutmut_3 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_4'] = x_main__mutmut_4 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_5'] = x_main__mutmut_5 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_6'] = x_main__mutmut_6 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_7'] = x_main__mutmut_7 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_8'] = x_main__mutmut_8 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_9'] = x_main__mutmut_9 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_10'] = x_main__mutmut_10 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_11'] = x_main__mutmut_11 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_12'] = x_main__mutmut_12 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_13'] = x_main__mutmut_13 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_14'] = x_main__mutmut_14 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_15'] = x_main__mutmut_15 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_16'] = x_main__mutmut_16 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_17'] = x_main__mutmut_17 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_18'] = x_main__mutmut_18 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_19'] = x_main__mutmut_19 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_20'] = x_main__mutmut_20 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_21'] = x_main__mutmut_21 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_22'] = x_main__mutmut_22 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_23'] = x_main__mutmut_23 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_24'] = x_main__mutmut_24 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_25'] = x_main__mutmut_25 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_26'] = x_main__mutmut_26 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_27'] = x_main__mutmut_27 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_28'] = x_main__mutmut_28 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_29'] = x_main__mutmut_29 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_30'] = x_main__mutmut_30 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_31'] = x_main__mutmut_31 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_32'] = x_main__mutmut_32 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_33'] = x_main__mutmut_33 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_34'] = x_main__mutmut_34 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_35'] = x_main__mutmut_35 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_36'] = x_main__mutmut_36 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_37'] = x_main__mutmut_37 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_38'] = x_main__mutmut_38 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_39'] = x_main__mutmut_39 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_40'] = x_main__mutmut_40 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_41'] = x_main__mutmut_41 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_42'] = x_main__mutmut_42 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_43'] = x_main__mutmut_43 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_44'] = x_main__mutmut_44 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_45'] = x_main__mutmut_45 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_46'] = x_main__mutmut_46 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_47'] = x_main__mutmut_47 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_48'] = x_main__mutmut_48 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_49'] = x_main__mutmut_49 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_50'] = x_main__mutmut_50 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_51'] = x_main__mutmut_51 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_52'] = x_main__mutmut_52 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_53'] = x_main__mutmut_53 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_54'] = x_main__mutmut_54 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_55'] = x_main__mutmut_55 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_56'] = x_main__mutmut_56 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_57'] = x_main__mutmut_57 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_58'] = x_main__mutmut_58 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_59'] = x_main__mutmut_59 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_60'] = x_main__mutmut_60 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_61'] = x_main__mutmut_61 # type: ignore # mutmut generated


if __name__ == "__main__":
    raise SystemExit(main())
