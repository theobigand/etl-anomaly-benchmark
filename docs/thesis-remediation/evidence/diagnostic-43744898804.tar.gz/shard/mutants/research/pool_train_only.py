"""Explicit exploratory consumer of source-bound, frozen pool partitions."""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
from importlib.metadata import PackageNotFoundError, version
from pathlib import Path

import numpy as np
import pandas as pd

from etl_benchmark.atomic import atomic_path
from etl_benchmark.metrics import compute_metrics
from etl_benchmark.pipeline import detect
from etl_benchmark.registry import DEEP_NAMES, DETECTOR_NAMES, clip_contamination
from experiments.provenance import write_record
from research.deep_support import build, capped
from research.normalise import skipped_detectors
from research.pool_preprocessing import PARTITIONS, prepare_frozen

ROOT = Path(__file__).resolve().parents[1]
PROTOCOL = "pool-train-only-v1"
RESEARCH_SOURCES = (
    "research/pool_preprocessing.py",
    "research/pool_train_only.py",
    "research/deep_support.py",
    "research/normalise.py",
)


from mutmut.mutation.trampoline import wrap_in_trampoline as _mutmut_mutated, MutantDict
mutants_x_evaluate_frozen__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_evaluate_frozen__mutmut)
def evaluate_frozen(
    frame: pd.DataFrame, labels, partitions: dict, *, seed: int, methods: list[str]
) -> dict:
    """Run named detectors on unchanged positions with training-only preparation."""
    if (
        not methods
        or len(set(methods)) != len(methods)
        or set(methods) - set([*DETECTOR_NAMES, *DEEP_NAMES])
    ):
        raise ValueError("detectors must be explicit, unique row-level registry names")
    if type(seed) is not int or not 0 <= seed < 2**32:
        raise ValueError("seed must be a nonnegative 32-bit integer")
    prepared = prepare_frozen(frame, partitions)
    y = np.asarray(labels)
    if y.ndim != 1 or len(y) != len(frame) or set(np.unique(y)) - {0, 1}:
        raise ValueError("labels must be an aligned binary vector")
    for name in PARTITIONS:
        if set(np.unique(y[partitions[name]])) != {0, 1}:
            raise ValueError("both classes are required in every frozen partition")
    train, test = prepared["train"], prepared["test"]
    contamination = clip_contamination(float(y[partitions["train"]].mean()))
    result = {
        "protocol": PROTOCOL,
        "exploratory": True,
        "seed": seed,
        "partitions": {name: list(partitions[name]) for name in PARTITIONS},
        "preprocessing": prepared["fit"],
        "calibration": {"policy": "train_prevalence", "value": contamination},
        "prevalence": {name: float(y[partitions[name]].mean()) for name in PARTITIONS},
        "runs": {},
        "errors": [],
        "skipped": [],
    }
    skipped = skipped_detectors(len(train))
    for method in methods:
        if method in skipped:
            result["skipped"].append(method)
            continue
        fit = capped(train, method, seed)
        try:
            detector = build(method, contamination, seed)
            found = detect(test, detector, fit_df=fit)
            result["runs"][method] = {
                "metrics": compute_metrics(y[partitions["test"]], found.flags, found.scores),
                "scores": found.scores.tolist(),
                "flags": found.flags.tolist(),
                "fit_rows": len(fit),
            }
        except Exception as error:
            result["errors"].append({"detector": method, "error": repr(error)})
    return result


def x_evaluate_frozen__mutmut_orig(
    frame: pd.DataFrame, labels, partitions: dict, *, seed: int, methods: list[str]
) -> dict:
    """Run named detectors on unchanged positions with training-only preparation."""
    if (
        not methods
        or len(set(methods)) != len(methods)
        or set(methods) - set([*DETECTOR_NAMES, *DEEP_NAMES])
    ):
        raise ValueError("detectors must be explicit, unique row-level registry names")
    if type(seed) is not int or not 0 <= seed < 2**32:
        raise ValueError("seed must be a nonnegative 32-bit integer")
    prepared = prepare_frozen(frame, partitions)
    y = np.asarray(labels)
    if y.ndim != 1 or len(y) != len(frame) or set(np.unique(y)) - {0, 1}:
        raise ValueError("labels must be an aligned binary vector")
    for name in PARTITIONS:
        if set(np.unique(y[partitions[name]])) != {0, 1}:
            raise ValueError("both classes are required in every frozen partition")
    train, test = prepared["train"], prepared["test"]
    contamination = clip_contamination(float(y[partitions["train"]].mean()))
    result = {
        "protocol": PROTOCOL,
        "exploratory": True,
        "seed": seed,
        "partitions": {name: list(partitions[name]) for name in PARTITIONS},
        "preprocessing": prepared["fit"],
        "calibration": {"policy": "train_prevalence", "value": contamination},
        "prevalence": {name: float(y[partitions[name]].mean()) for name in PARTITIONS},
        "runs": {},
        "errors": [],
        "skipped": [],
    }
    skipped = skipped_detectors(len(train))
    for method in methods:
        if method in skipped:
            result["skipped"].append(method)
            continue
        fit = capped(train, method, seed)
        try:
            detector = build(method, contamination, seed)
            found = detect(test, detector, fit_df=fit)
            result["runs"][method] = {
                "metrics": compute_metrics(y[partitions["test"]], found.flags, found.scores),
                "scores": found.scores.tolist(),
                "flags": found.flags.tolist(),
                "fit_rows": len(fit),
            }
        except Exception as error:
            result["errors"].append({"detector": method, "error": repr(error)})
    return result


def x_evaluate_frozen__mutmut_1(
    frame: pd.DataFrame, labels, partitions: dict, *, seed: int, methods: list[str]
) -> dict:
    """Run named detectors on unchanged positions with training-only preparation."""
    if (
        not methods
        or len(set(methods)) != len(methods) and set(methods) - set([*DETECTOR_NAMES, *DEEP_NAMES])
    ):
        raise ValueError("detectors must be explicit, unique row-level registry names")
    if type(seed) is not int or not 0 <= seed < 2**32:
        raise ValueError("seed must be a nonnegative 32-bit integer")
    prepared = prepare_frozen(frame, partitions)
    y = np.asarray(labels)
    if y.ndim != 1 or len(y) != len(frame) or set(np.unique(y)) - {0, 1}:
        raise ValueError("labels must be an aligned binary vector")
    for name in PARTITIONS:
        if set(np.unique(y[partitions[name]])) != {0, 1}:
            raise ValueError("both classes are required in every frozen partition")
    train, test = prepared["train"], prepared["test"]
    contamination = clip_contamination(float(y[partitions["train"]].mean()))
    result = {
        "protocol": PROTOCOL,
        "exploratory": True,
        "seed": seed,
        "partitions": {name: list(partitions[name]) for name in PARTITIONS},
        "preprocessing": prepared["fit"],
        "calibration": {"policy": "train_prevalence", "value": contamination},
        "prevalence": {name: float(y[partitions[name]].mean()) for name in PARTITIONS},
        "runs": {},
        "errors": [],
        "skipped": [],
    }
    skipped = skipped_detectors(len(train))
    for method in methods:
        if method in skipped:
            result["skipped"].append(method)
            continue
        fit = capped(train, method, seed)
        try:
            detector = build(method, contamination, seed)
            found = detect(test, detector, fit_df=fit)
            result["runs"][method] = {
                "metrics": compute_metrics(y[partitions["test"]], found.flags, found.scores),
                "scores": found.scores.tolist(),
                "flags": found.flags.tolist(),
                "fit_rows": len(fit),
            }
        except Exception as error:
            result["errors"].append({"detector": method, "error": repr(error)})
    return result


def x_evaluate_frozen__mutmut_2(
    frame: pd.DataFrame, labels, partitions: dict, *, seed: int, methods: list[str]
) -> dict:
    """Run named detectors on unchanged positions with training-only preparation."""
    if (
        not methods and len(set(methods)) != len(methods)
        or set(methods) - set([*DETECTOR_NAMES, *DEEP_NAMES])
    ):
        raise ValueError("detectors must be explicit, unique row-level registry names")
    if type(seed) is not int or not 0 <= seed < 2**32:
        raise ValueError("seed must be a nonnegative 32-bit integer")
    prepared = prepare_frozen(frame, partitions)
    y = np.asarray(labels)
    if y.ndim != 1 or len(y) != len(frame) or set(np.unique(y)) - {0, 1}:
        raise ValueError("labels must be an aligned binary vector")
    for name in PARTITIONS:
        if set(np.unique(y[partitions[name]])) != {0, 1}:
            raise ValueError("both classes are required in every frozen partition")
    train, test = prepared["train"], prepared["test"]
    contamination = clip_contamination(float(y[partitions["train"]].mean()))
    result = {
        "protocol": PROTOCOL,
        "exploratory": True,
        "seed": seed,
        "partitions": {name: list(partitions[name]) for name in PARTITIONS},
        "preprocessing": prepared["fit"],
        "calibration": {"policy": "train_prevalence", "value": contamination},
        "prevalence": {name: float(y[partitions[name]].mean()) for name in PARTITIONS},
        "runs": {},
        "errors": [],
        "skipped": [],
    }
    skipped = skipped_detectors(len(train))
    for method in methods:
        if method in skipped:
            result["skipped"].append(method)
            continue
        fit = capped(train, method, seed)
        try:
            detector = build(method, contamination, seed)
            found = detect(test, detector, fit_df=fit)
            result["runs"][method] = {
                "metrics": compute_metrics(y[partitions["test"]], found.flags, found.scores),
                "scores": found.scores.tolist(),
                "flags": found.flags.tolist(),
                "fit_rows": len(fit),
            }
        except Exception as error:
            result["errors"].append({"detector": method, "error": repr(error)})
    return result


def x_evaluate_frozen__mutmut_3(
    frame: pd.DataFrame, labels, partitions: dict, *, seed: int, methods: list[str]
) -> dict:
    """Run named detectors on unchanged positions with training-only preparation."""
    if (
        methods
        or len(set(methods)) != len(methods)
        or set(methods) - set([*DETECTOR_NAMES, *DEEP_NAMES])
    ):
        raise ValueError("detectors must be explicit, unique row-level registry names")
    if type(seed) is not int or not 0 <= seed < 2**32:
        raise ValueError("seed must be a nonnegative 32-bit integer")
    prepared = prepare_frozen(frame, partitions)
    y = np.asarray(labels)
    if y.ndim != 1 or len(y) != len(frame) or set(np.unique(y)) - {0, 1}:
        raise ValueError("labels must be an aligned binary vector")
    for name in PARTITIONS:
        if set(np.unique(y[partitions[name]])) != {0, 1}:
            raise ValueError("both classes are required in every frozen partition")
    train, test = prepared["train"], prepared["test"]
    contamination = clip_contamination(float(y[partitions["train"]].mean()))
    result = {
        "protocol": PROTOCOL,
        "exploratory": True,
        "seed": seed,
        "partitions": {name: list(partitions[name]) for name in PARTITIONS},
        "preprocessing": prepared["fit"],
        "calibration": {"policy": "train_prevalence", "value": contamination},
        "prevalence": {name: float(y[partitions[name]].mean()) for name in PARTITIONS},
        "runs": {},
        "errors": [],
        "skipped": [],
    }
    skipped = skipped_detectors(len(train))
    for method in methods:
        if method in skipped:
            result["skipped"].append(method)
            continue
        fit = capped(train, method, seed)
        try:
            detector = build(method, contamination, seed)
            found = detect(test, detector, fit_df=fit)
            result["runs"][method] = {
                "metrics": compute_metrics(y[partitions["test"]], found.flags, found.scores),
                "scores": found.scores.tolist(),
                "flags": found.flags.tolist(),
                "fit_rows": len(fit),
            }
        except Exception as error:
            result["errors"].append({"detector": method, "error": repr(error)})
    return result


def x_evaluate_frozen__mutmut_4(
    frame: pd.DataFrame, labels, partitions: dict, *, seed: int, methods: list[str]
) -> dict:
    """Run named detectors on unchanged positions with training-only preparation."""
    if (
        not methods
        or len(set(methods)) == len(methods)
        or set(methods) - set([*DETECTOR_NAMES, *DEEP_NAMES])
    ):
        raise ValueError("detectors must be explicit, unique row-level registry names")
    if type(seed) is not int or not 0 <= seed < 2**32:
        raise ValueError("seed must be a nonnegative 32-bit integer")
    prepared = prepare_frozen(frame, partitions)
    y = np.asarray(labels)
    if y.ndim != 1 or len(y) != len(frame) or set(np.unique(y)) - {0, 1}:
        raise ValueError("labels must be an aligned binary vector")
    for name in PARTITIONS:
        if set(np.unique(y[partitions[name]])) != {0, 1}:
            raise ValueError("both classes are required in every frozen partition")
    train, test = prepared["train"], prepared["test"]
    contamination = clip_contamination(float(y[partitions["train"]].mean()))
    result = {
        "protocol": PROTOCOL,
        "exploratory": True,
        "seed": seed,
        "partitions": {name: list(partitions[name]) for name in PARTITIONS},
        "preprocessing": prepared["fit"],
        "calibration": {"policy": "train_prevalence", "value": contamination},
        "prevalence": {name: float(y[partitions[name]].mean()) for name in PARTITIONS},
        "runs": {},
        "errors": [],
        "skipped": [],
    }
    skipped = skipped_detectors(len(train))
    for method in methods:
        if method in skipped:
            result["skipped"].append(method)
            continue
        fit = capped(train, method, seed)
        try:
            detector = build(method, contamination, seed)
            found = detect(test, detector, fit_df=fit)
            result["runs"][method] = {
                "metrics": compute_metrics(y[partitions["test"]], found.flags, found.scores),
                "scores": found.scores.tolist(),
                "flags": found.flags.tolist(),
                "fit_rows": len(fit),
            }
        except Exception as error:
            result["errors"].append({"detector": method, "error": repr(error)})
    return result


def x_evaluate_frozen__mutmut_5(
    frame: pd.DataFrame, labels, partitions: dict, *, seed: int, methods: list[str]
) -> dict:
    """Run named detectors on unchanged positions with training-only preparation."""
    if (
        not methods
        or len(set(methods)) != len(methods)
        or set(methods) + set([*DETECTOR_NAMES, *DEEP_NAMES])
    ):
        raise ValueError("detectors must be explicit, unique row-level registry names")
    if type(seed) is not int or not 0 <= seed < 2**32:
        raise ValueError("seed must be a nonnegative 32-bit integer")
    prepared = prepare_frozen(frame, partitions)
    y = np.asarray(labels)
    if y.ndim != 1 or len(y) != len(frame) or set(np.unique(y)) - {0, 1}:
        raise ValueError("labels must be an aligned binary vector")
    for name in PARTITIONS:
        if set(np.unique(y[partitions[name]])) != {0, 1}:
            raise ValueError("both classes are required in every frozen partition")
    train, test = prepared["train"], prepared["test"]
    contamination = clip_contamination(float(y[partitions["train"]].mean()))
    result = {
        "protocol": PROTOCOL,
        "exploratory": True,
        "seed": seed,
        "partitions": {name: list(partitions[name]) for name in PARTITIONS},
        "preprocessing": prepared["fit"],
        "calibration": {"policy": "train_prevalence", "value": contamination},
        "prevalence": {name: float(y[partitions[name]].mean()) for name in PARTITIONS},
        "runs": {},
        "errors": [],
        "skipped": [],
    }
    skipped = skipped_detectors(len(train))
    for method in methods:
        if method in skipped:
            result["skipped"].append(method)
            continue
        fit = capped(train, method, seed)
        try:
            detector = build(method, contamination, seed)
            found = detect(test, detector, fit_df=fit)
            result["runs"][method] = {
                "metrics": compute_metrics(y[partitions["test"]], found.flags, found.scores),
                "scores": found.scores.tolist(),
                "flags": found.flags.tolist(),
                "fit_rows": len(fit),
            }
        except Exception as error:
            result["errors"].append({"detector": method, "error": repr(error)})
    return result


def x_evaluate_frozen__mutmut_6(
    frame: pd.DataFrame, labels, partitions: dict, *, seed: int, methods: list[str]
) -> dict:
    """Run named detectors on unchanged positions with training-only preparation."""
    if (
        not methods
        or len(set(methods)) != len(methods)
        or set(None) - set([*DETECTOR_NAMES, *DEEP_NAMES])
    ):
        raise ValueError("detectors must be explicit, unique row-level registry names")
    if type(seed) is not int or not 0 <= seed < 2**32:
        raise ValueError("seed must be a nonnegative 32-bit integer")
    prepared = prepare_frozen(frame, partitions)
    y = np.asarray(labels)
    if y.ndim != 1 or len(y) != len(frame) or set(np.unique(y)) - {0, 1}:
        raise ValueError("labels must be an aligned binary vector")
    for name in PARTITIONS:
        if set(np.unique(y[partitions[name]])) != {0, 1}:
            raise ValueError("both classes are required in every frozen partition")
    train, test = prepared["train"], prepared["test"]
    contamination = clip_contamination(float(y[partitions["train"]].mean()))
    result = {
        "protocol": PROTOCOL,
        "exploratory": True,
        "seed": seed,
        "partitions": {name: list(partitions[name]) for name in PARTITIONS},
        "preprocessing": prepared["fit"],
        "calibration": {"policy": "train_prevalence", "value": contamination},
        "prevalence": {name: float(y[partitions[name]].mean()) for name in PARTITIONS},
        "runs": {},
        "errors": [],
        "skipped": [],
    }
    skipped = skipped_detectors(len(train))
    for method in methods:
        if method in skipped:
            result["skipped"].append(method)
            continue
        fit = capped(train, method, seed)
        try:
            detector = build(method, contamination, seed)
            found = detect(test, detector, fit_df=fit)
            result["runs"][method] = {
                "metrics": compute_metrics(y[partitions["test"]], found.flags, found.scores),
                "scores": found.scores.tolist(),
                "flags": found.flags.tolist(),
                "fit_rows": len(fit),
            }
        except Exception as error:
            result["errors"].append({"detector": method, "error": repr(error)})
    return result


def x_evaluate_frozen__mutmut_7(
    frame: pd.DataFrame, labels, partitions: dict, *, seed: int, methods: list[str]
) -> dict:
    """Run named detectors on unchanged positions with training-only preparation."""
    if (
        not methods
        or len(set(methods)) != len(methods)
        or set(methods) - set(None)
    ):
        raise ValueError("detectors must be explicit, unique row-level registry names")
    if type(seed) is not int or not 0 <= seed < 2**32:
        raise ValueError("seed must be a nonnegative 32-bit integer")
    prepared = prepare_frozen(frame, partitions)
    y = np.asarray(labels)
    if y.ndim != 1 or len(y) != len(frame) or set(np.unique(y)) - {0, 1}:
        raise ValueError("labels must be an aligned binary vector")
    for name in PARTITIONS:
        if set(np.unique(y[partitions[name]])) != {0, 1}:
            raise ValueError("both classes are required in every frozen partition")
    train, test = prepared["train"], prepared["test"]
    contamination = clip_contamination(float(y[partitions["train"]].mean()))
    result = {
        "protocol": PROTOCOL,
        "exploratory": True,
        "seed": seed,
        "partitions": {name: list(partitions[name]) for name in PARTITIONS},
        "preprocessing": prepared["fit"],
        "calibration": {"policy": "train_prevalence", "value": contamination},
        "prevalence": {name: float(y[partitions[name]].mean()) for name in PARTITIONS},
        "runs": {},
        "errors": [],
        "skipped": [],
    }
    skipped = skipped_detectors(len(train))
    for method in methods:
        if method in skipped:
            result["skipped"].append(method)
            continue
        fit = capped(train, method, seed)
        try:
            detector = build(method, contamination, seed)
            found = detect(test, detector, fit_df=fit)
            result["runs"][method] = {
                "metrics": compute_metrics(y[partitions["test"]], found.flags, found.scores),
                "scores": found.scores.tolist(),
                "flags": found.flags.tolist(),
                "fit_rows": len(fit),
            }
        except Exception as error:
            result["errors"].append({"detector": method, "error": repr(error)})
    return result


def x_evaluate_frozen__mutmut_8(
    frame: pd.DataFrame, labels, partitions: dict, *, seed: int, methods: list[str]
) -> dict:
    """Run named detectors on unchanged positions with training-only preparation."""
    if (
        not methods
        or len(set(methods)) != len(methods)
        or set(methods) - set([*DETECTOR_NAMES, *DEEP_NAMES])
    ):
        raise ValueError(None)
    if type(seed) is not int or not 0 <= seed < 2**32:
        raise ValueError("seed must be a nonnegative 32-bit integer")
    prepared = prepare_frozen(frame, partitions)
    y = np.asarray(labels)
    if y.ndim != 1 or len(y) != len(frame) or set(np.unique(y)) - {0, 1}:
        raise ValueError("labels must be an aligned binary vector")
    for name in PARTITIONS:
        if set(np.unique(y[partitions[name]])) != {0, 1}:
            raise ValueError("both classes are required in every frozen partition")
    train, test = prepared["train"], prepared["test"]
    contamination = clip_contamination(float(y[partitions["train"]].mean()))
    result = {
        "protocol": PROTOCOL,
        "exploratory": True,
        "seed": seed,
        "partitions": {name: list(partitions[name]) for name in PARTITIONS},
        "preprocessing": prepared["fit"],
        "calibration": {"policy": "train_prevalence", "value": contamination},
        "prevalence": {name: float(y[partitions[name]].mean()) for name in PARTITIONS},
        "runs": {},
        "errors": [],
        "skipped": [],
    }
    skipped = skipped_detectors(len(train))
    for method in methods:
        if method in skipped:
            result["skipped"].append(method)
            continue
        fit = capped(train, method, seed)
        try:
            detector = build(method, contamination, seed)
            found = detect(test, detector, fit_df=fit)
            result["runs"][method] = {
                "metrics": compute_metrics(y[partitions["test"]], found.flags, found.scores),
                "scores": found.scores.tolist(),
                "flags": found.flags.tolist(),
                "fit_rows": len(fit),
            }
        except Exception as error:
            result["errors"].append({"detector": method, "error": repr(error)})
    return result


def x_evaluate_frozen__mutmut_9(
    frame: pd.DataFrame, labels, partitions: dict, *, seed: int, methods: list[str]
) -> dict:
    """Run named detectors on unchanged positions with training-only preparation."""
    if (
        not methods
        or len(set(methods)) != len(methods)
        or set(methods) - set([*DETECTOR_NAMES, *DEEP_NAMES])
    ):
        raise ValueError("XXdetectors must be explicit, unique row-level registry namesXX")
    if type(seed) is not int or not 0 <= seed < 2**32:
        raise ValueError("seed must be a nonnegative 32-bit integer")
    prepared = prepare_frozen(frame, partitions)
    y = np.asarray(labels)
    if y.ndim != 1 or len(y) != len(frame) or set(np.unique(y)) - {0, 1}:
        raise ValueError("labels must be an aligned binary vector")
    for name in PARTITIONS:
        if set(np.unique(y[partitions[name]])) != {0, 1}:
            raise ValueError("both classes are required in every frozen partition")
    train, test = prepared["train"], prepared["test"]
    contamination = clip_contamination(float(y[partitions["train"]].mean()))
    result = {
        "protocol": PROTOCOL,
        "exploratory": True,
        "seed": seed,
        "partitions": {name: list(partitions[name]) for name in PARTITIONS},
        "preprocessing": prepared["fit"],
        "calibration": {"policy": "train_prevalence", "value": contamination},
        "prevalence": {name: float(y[partitions[name]].mean()) for name in PARTITIONS},
        "runs": {},
        "errors": [],
        "skipped": [],
    }
    skipped = skipped_detectors(len(train))
    for method in methods:
        if method in skipped:
            result["skipped"].append(method)
            continue
        fit = capped(train, method, seed)
        try:
            detector = build(method, contamination, seed)
            found = detect(test, detector, fit_df=fit)
            result["runs"][method] = {
                "metrics": compute_metrics(y[partitions["test"]], found.flags, found.scores),
                "scores": found.scores.tolist(),
                "flags": found.flags.tolist(),
                "fit_rows": len(fit),
            }
        except Exception as error:
            result["errors"].append({"detector": method, "error": repr(error)})
    return result


def x_evaluate_frozen__mutmut_10(
    frame: pd.DataFrame, labels, partitions: dict, *, seed: int, methods: list[str]
) -> dict:
    """Run named detectors on unchanged positions with training-only preparation."""
    if (
        not methods
        or len(set(methods)) != len(methods)
        or set(methods) - set([*DETECTOR_NAMES, *DEEP_NAMES])
    ):
        raise ValueError("DETECTORS MUST BE EXPLICIT, UNIQUE ROW-LEVEL REGISTRY NAMES")
    if type(seed) is not int or not 0 <= seed < 2**32:
        raise ValueError("seed must be a nonnegative 32-bit integer")
    prepared = prepare_frozen(frame, partitions)
    y = np.asarray(labels)
    if y.ndim != 1 or len(y) != len(frame) or set(np.unique(y)) - {0, 1}:
        raise ValueError("labels must be an aligned binary vector")
    for name in PARTITIONS:
        if set(np.unique(y[partitions[name]])) != {0, 1}:
            raise ValueError("both classes are required in every frozen partition")
    train, test = prepared["train"], prepared["test"]
    contamination = clip_contamination(float(y[partitions["train"]].mean()))
    result = {
        "protocol": PROTOCOL,
        "exploratory": True,
        "seed": seed,
        "partitions": {name: list(partitions[name]) for name in PARTITIONS},
        "preprocessing": prepared["fit"],
        "calibration": {"policy": "train_prevalence", "value": contamination},
        "prevalence": {name: float(y[partitions[name]].mean()) for name in PARTITIONS},
        "runs": {},
        "errors": [],
        "skipped": [],
    }
    skipped = skipped_detectors(len(train))
    for method in methods:
        if method in skipped:
            result["skipped"].append(method)
            continue
        fit = capped(train, method, seed)
        try:
            detector = build(method, contamination, seed)
            found = detect(test, detector, fit_df=fit)
            result["runs"][method] = {
                "metrics": compute_metrics(y[partitions["test"]], found.flags, found.scores),
                "scores": found.scores.tolist(),
                "flags": found.flags.tolist(),
                "fit_rows": len(fit),
            }
        except Exception as error:
            result["errors"].append({"detector": method, "error": repr(error)})
    return result


def x_evaluate_frozen__mutmut_11(
    frame: pd.DataFrame, labels, partitions: dict, *, seed: int, methods: list[str]
) -> dict:
    """Run named detectors on unchanged positions with training-only preparation."""
    if (
        not methods
        or len(set(methods)) != len(methods)
        or set(methods) - set([*DETECTOR_NAMES, *DEEP_NAMES])
    ):
        raise ValueError("detectors must be explicit, unique row-level registry names")
    if type(seed) is not int and not 0 <= seed < 2**32:
        raise ValueError("seed must be a nonnegative 32-bit integer")
    prepared = prepare_frozen(frame, partitions)
    y = np.asarray(labels)
    if y.ndim != 1 or len(y) != len(frame) or set(np.unique(y)) - {0, 1}:
        raise ValueError("labels must be an aligned binary vector")
    for name in PARTITIONS:
        if set(np.unique(y[partitions[name]])) != {0, 1}:
            raise ValueError("both classes are required in every frozen partition")
    train, test = prepared["train"], prepared["test"]
    contamination = clip_contamination(float(y[partitions["train"]].mean()))
    result = {
        "protocol": PROTOCOL,
        "exploratory": True,
        "seed": seed,
        "partitions": {name: list(partitions[name]) for name in PARTITIONS},
        "preprocessing": prepared["fit"],
        "calibration": {"policy": "train_prevalence", "value": contamination},
        "prevalence": {name: float(y[partitions[name]].mean()) for name in PARTITIONS},
        "runs": {},
        "errors": [],
        "skipped": [],
    }
    skipped = skipped_detectors(len(train))
    for method in methods:
        if method in skipped:
            result["skipped"].append(method)
            continue
        fit = capped(train, method, seed)
        try:
            detector = build(method, contamination, seed)
            found = detect(test, detector, fit_df=fit)
            result["runs"][method] = {
                "metrics": compute_metrics(y[partitions["test"]], found.flags, found.scores),
                "scores": found.scores.tolist(),
                "flags": found.flags.tolist(),
                "fit_rows": len(fit),
            }
        except Exception as error:
            result["errors"].append({"detector": method, "error": repr(error)})
    return result


def x_evaluate_frozen__mutmut_12(
    frame: pd.DataFrame, labels, partitions: dict, *, seed: int, methods: list[str]
) -> dict:
    """Run named detectors on unchanged positions with training-only preparation."""
    if (
        not methods
        or len(set(methods)) != len(methods)
        or set(methods) - set([*DETECTOR_NAMES, *DEEP_NAMES])
    ):
        raise ValueError("detectors must be explicit, unique row-level registry names")
    if type(None) is not int or not 0 <= seed < 2**32:
        raise ValueError("seed must be a nonnegative 32-bit integer")
    prepared = prepare_frozen(frame, partitions)
    y = np.asarray(labels)
    if y.ndim != 1 or len(y) != len(frame) or set(np.unique(y)) - {0, 1}:
        raise ValueError("labels must be an aligned binary vector")
    for name in PARTITIONS:
        if set(np.unique(y[partitions[name]])) != {0, 1}:
            raise ValueError("both classes are required in every frozen partition")
    train, test = prepared["train"], prepared["test"]
    contamination = clip_contamination(float(y[partitions["train"]].mean()))
    result = {
        "protocol": PROTOCOL,
        "exploratory": True,
        "seed": seed,
        "partitions": {name: list(partitions[name]) for name in PARTITIONS},
        "preprocessing": prepared["fit"],
        "calibration": {"policy": "train_prevalence", "value": contamination},
        "prevalence": {name: float(y[partitions[name]].mean()) for name in PARTITIONS},
        "runs": {},
        "errors": [],
        "skipped": [],
    }
    skipped = skipped_detectors(len(train))
    for method in methods:
        if method in skipped:
            result["skipped"].append(method)
            continue
        fit = capped(train, method, seed)
        try:
            detector = build(method, contamination, seed)
            found = detect(test, detector, fit_df=fit)
            result["runs"][method] = {
                "metrics": compute_metrics(y[partitions["test"]], found.flags, found.scores),
                "scores": found.scores.tolist(),
                "flags": found.flags.tolist(),
                "fit_rows": len(fit),
            }
        except Exception as error:
            result["errors"].append({"detector": method, "error": repr(error)})
    return result


def x_evaluate_frozen__mutmut_13(
    frame: pd.DataFrame, labels, partitions: dict, *, seed: int, methods: list[str]
) -> dict:
    """Run named detectors on unchanged positions with training-only preparation."""
    if (
        not methods
        or len(set(methods)) != len(methods)
        or set(methods) - set([*DETECTOR_NAMES, *DEEP_NAMES])
    ):
        raise ValueError("detectors must be explicit, unique row-level registry names")
    if type(seed) is int or not 0 <= seed < 2**32:
        raise ValueError("seed must be a nonnegative 32-bit integer")
    prepared = prepare_frozen(frame, partitions)
    y = np.asarray(labels)
    if y.ndim != 1 or len(y) != len(frame) or set(np.unique(y)) - {0, 1}:
        raise ValueError("labels must be an aligned binary vector")
    for name in PARTITIONS:
        if set(np.unique(y[partitions[name]])) != {0, 1}:
            raise ValueError("both classes are required in every frozen partition")
    train, test = prepared["train"], prepared["test"]
    contamination = clip_contamination(float(y[partitions["train"]].mean()))
    result = {
        "protocol": PROTOCOL,
        "exploratory": True,
        "seed": seed,
        "partitions": {name: list(partitions[name]) for name in PARTITIONS},
        "preprocessing": prepared["fit"],
        "calibration": {"policy": "train_prevalence", "value": contamination},
        "prevalence": {name: float(y[partitions[name]].mean()) for name in PARTITIONS},
        "runs": {},
        "errors": [],
        "skipped": [],
    }
    skipped = skipped_detectors(len(train))
    for method in methods:
        if method in skipped:
            result["skipped"].append(method)
            continue
        fit = capped(train, method, seed)
        try:
            detector = build(method, contamination, seed)
            found = detect(test, detector, fit_df=fit)
            result["runs"][method] = {
                "metrics": compute_metrics(y[partitions["test"]], found.flags, found.scores),
                "scores": found.scores.tolist(),
                "flags": found.flags.tolist(),
                "fit_rows": len(fit),
            }
        except Exception as error:
            result["errors"].append({"detector": method, "error": repr(error)})
    return result


def x_evaluate_frozen__mutmut_14(
    frame: pd.DataFrame, labels, partitions: dict, *, seed: int, methods: list[str]
) -> dict:
    """Run named detectors on unchanged positions with training-only preparation."""
    if (
        not methods
        or len(set(methods)) != len(methods)
        or set(methods) - set([*DETECTOR_NAMES, *DEEP_NAMES])
    ):
        raise ValueError("detectors must be explicit, unique row-level registry names")
    if type(seed) is not int or 0 <= seed < 2**32:
        raise ValueError("seed must be a nonnegative 32-bit integer")
    prepared = prepare_frozen(frame, partitions)
    y = np.asarray(labels)
    if y.ndim != 1 or len(y) != len(frame) or set(np.unique(y)) - {0, 1}:
        raise ValueError("labels must be an aligned binary vector")
    for name in PARTITIONS:
        if set(np.unique(y[partitions[name]])) != {0, 1}:
            raise ValueError("both classes are required in every frozen partition")
    train, test = prepared["train"], prepared["test"]
    contamination = clip_contamination(float(y[partitions["train"]].mean()))
    result = {
        "protocol": PROTOCOL,
        "exploratory": True,
        "seed": seed,
        "partitions": {name: list(partitions[name]) for name in PARTITIONS},
        "preprocessing": prepared["fit"],
        "calibration": {"policy": "train_prevalence", "value": contamination},
        "prevalence": {name: float(y[partitions[name]].mean()) for name in PARTITIONS},
        "runs": {},
        "errors": [],
        "skipped": [],
    }
    skipped = skipped_detectors(len(train))
    for method in methods:
        if method in skipped:
            result["skipped"].append(method)
            continue
        fit = capped(train, method, seed)
        try:
            detector = build(method, contamination, seed)
            found = detect(test, detector, fit_df=fit)
            result["runs"][method] = {
                "metrics": compute_metrics(y[partitions["test"]], found.flags, found.scores),
                "scores": found.scores.tolist(),
                "flags": found.flags.tolist(),
                "fit_rows": len(fit),
            }
        except Exception as error:
            result["errors"].append({"detector": method, "error": repr(error)})
    return result


def x_evaluate_frozen__mutmut_15(
    frame: pd.DataFrame, labels, partitions: dict, *, seed: int, methods: list[str]
) -> dict:
    """Run named detectors on unchanged positions with training-only preparation."""
    if (
        not methods
        or len(set(methods)) != len(methods)
        or set(methods) - set([*DETECTOR_NAMES, *DEEP_NAMES])
    ):
        raise ValueError("detectors must be explicit, unique row-level registry names")
    if type(seed) is not int or not 1 <= seed < 2**32:
        raise ValueError("seed must be a nonnegative 32-bit integer")
    prepared = prepare_frozen(frame, partitions)
    y = np.asarray(labels)
    if y.ndim != 1 or len(y) != len(frame) or set(np.unique(y)) - {0, 1}:
        raise ValueError("labels must be an aligned binary vector")
    for name in PARTITIONS:
        if set(np.unique(y[partitions[name]])) != {0, 1}:
            raise ValueError("both classes are required in every frozen partition")
    train, test = prepared["train"], prepared["test"]
    contamination = clip_contamination(float(y[partitions["train"]].mean()))
    result = {
        "protocol": PROTOCOL,
        "exploratory": True,
        "seed": seed,
        "partitions": {name: list(partitions[name]) for name in PARTITIONS},
        "preprocessing": prepared["fit"],
        "calibration": {"policy": "train_prevalence", "value": contamination},
        "prevalence": {name: float(y[partitions[name]].mean()) for name in PARTITIONS},
        "runs": {},
        "errors": [],
        "skipped": [],
    }
    skipped = skipped_detectors(len(train))
    for method in methods:
        if method in skipped:
            result["skipped"].append(method)
            continue
        fit = capped(train, method, seed)
        try:
            detector = build(method, contamination, seed)
            found = detect(test, detector, fit_df=fit)
            result["runs"][method] = {
                "metrics": compute_metrics(y[partitions["test"]], found.flags, found.scores),
                "scores": found.scores.tolist(),
                "flags": found.flags.tolist(),
                "fit_rows": len(fit),
            }
        except Exception as error:
            result["errors"].append({"detector": method, "error": repr(error)})
    return result


def x_evaluate_frozen__mutmut_16(
    frame: pd.DataFrame, labels, partitions: dict, *, seed: int, methods: list[str]
) -> dict:
    """Run named detectors on unchanged positions with training-only preparation."""
    if (
        not methods
        or len(set(methods)) != len(methods)
        or set(methods) - set([*DETECTOR_NAMES, *DEEP_NAMES])
    ):
        raise ValueError("detectors must be explicit, unique row-level registry names")
    if type(seed) is not int or not 0 < seed < 2**32:
        raise ValueError("seed must be a nonnegative 32-bit integer")
    prepared = prepare_frozen(frame, partitions)
    y = np.asarray(labels)
    if y.ndim != 1 or len(y) != len(frame) or set(np.unique(y)) - {0, 1}:
        raise ValueError("labels must be an aligned binary vector")
    for name in PARTITIONS:
        if set(np.unique(y[partitions[name]])) != {0, 1}:
            raise ValueError("both classes are required in every frozen partition")
    train, test = prepared["train"], prepared["test"]
    contamination = clip_contamination(float(y[partitions["train"]].mean()))
    result = {
        "protocol": PROTOCOL,
        "exploratory": True,
        "seed": seed,
        "partitions": {name: list(partitions[name]) for name in PARTITIONS},
        "preprocessing": prepared["fit"],
        "calibration": {"policy": "train_prevalence", "value": contamination},
        "prevalence": {name: float(y[partitions[name]].mean()) for name in PARTITIONS},
        "runs": {},
        "errors": [],
        "skipped": [],
    }
    skipped = skipped_detectors(len(train))
    for method in methods:
        if method in skipped:
            result["skipped"].append(method)
            continue
        fit = capped(train, method, seed)
        try:
            detector = build(method, contamination, seed)
            found = detect(test, detector, fit_df=fit)
            result["runs"][method] = {
                "metrics": compute_metrics(y[partitions["test"]], found.flags, found.scores),
                "scores": found.scores.tolist(),
                "flags": found.flags.tolist(),
                "fit_rows": len(fit),
            }
        except Exception as error:
            result["errors"].append({"detector": method, "error": repr(error)})
    return result


def x_evaluate_frozen__mutmut_17(
    frame: pd.DataFrame, labels, partitions: dict, *, seed: int, methods: list[str]
) -> dict:
    """Run named detectors on unchanged positions with training-only preparation."""
    if (
        not methods
        or len(set(methods)) != len(methods)
        or set(methods) - set([*DETECTOR_NAMES, *DEEP_NAMES])
    ):
        raise ValueError("detectors must be explicit, unique row-level registry names")
    if type(seed) is not int or not 0 <= seed <= 2**32:
        raise ValueError("seed must be a nonnegative 32-bit integer")
    prepared = prepare_frozen(frame, partitions)
    y = np.asarray(labels)
    if y.ndim != 1 or len(y) != len(frame) or set(np.unique(y)) - {0, 1}:
        raise ValueError("labels must be an aligned binary vector")
    for name in PARTITIONS:
        if set(np.unique(y[partitions[name]])) != {0, 1}:
            raise ValueError("both classes are required in every frozen partition")
    train, test = prepared["train"], prepared["test"]
    contamination = clip_contamination(float(y[partitions["train"]].mean()))
    result = {
        "protocol": PROTOCOL,
        "exploratory": True,
        "seed": seed,
        "partitions": {name: list(partitions[name]) for name in PARTITIONS},
        "preprocessing": prepared["fit"],
        "calibration": {"policy": "train_prevalence", "value": contamination},
        "prevalence": {name: float(y[partitions[name]].mean()) for name in PARTITIONS},
        "runs": {},
        "errors": [],
        "skipped": [],
    }
    skipped = skipped_detectors(len(train))
    for method in methods:
        if method in skipped:
            result["skipped"].append(method)
            continue
        fit = capped(train, method, seed)
        try:
            detector = build(method, contamination, seed)
            found = detect(test, detector, fit_df=fit)
            result["runs"][method] = {
                "metrics": compute_metrics(y[partitions["test"]], found.flags, found.scores),
                "scores": found.scores.tolist(),
                "flags": found.flags.tolist(),
                "fit_rows": len(fit),
            }
        except Exception as error:
            result["errors"].append({"detector": method, "error": repr(error)})
    return result


def x_evaluate_frozen__mutmut_18(
    frame: pd.DataFrame, labels, partitions: dict, *, seed: int, methods: list[str]
) -> dict:
    """Run named detectors on unchanged positions with training-only preparation."""
    if (
        not methods
        or len(set(methods)) != len(methods)
        or set(methods) - set([*DETECTOR_NAMES, *DEEP_NAMES])
    ):
        raise ValueError("detectors must be explicit, unique row-level registry names")
    if type(seed) is not int or not 0 <= seed < 2 * 32:
        raise ValueError("seed must be a nonnegative 32-bit integer")
    prepared = prepare_frozen(frame, partitions)
    y = np.asarray(labels)
    if y.ndim != 1 or len(y) != len(frame) or set(np.unique(y)) - {0, 1}:
        raise ValueError("labels must be an aligned binary vector")
    for name in PARTITIONS:
        if set(np.unique(y[partitions[name]])) != {0, 1}:
            raise ValueError("both classes are required in every frozen partition")
    train, test = prepared["train"], prepared["test"]
    contamination = clip_contamination(float(y[partitions["train"]].mean()))
    result = {
        "protocol": PROTOCOL,
        "exploratory": True,
        "seed": seed,
        "partitions": {name: list(partitions[name]) for name in PARTITIONS},
        "preprocessing": prepared["fit"],
        "calibration": {"policy": "train_prevalence", "value": contamination},
        "prevalence": {name: float(y[partitions[name]].mean()) for name in PARTITIONS},
        "runs": {},
        "errors": [],
        "skipped": [],
    }
    skipped = skipped_detectors(len(train))
    for method in methods:
        if method in skipped:
            result["skipped"].append(method)
            continue
        fit = capped(train, method, seed)
        try:
            detector = build(method, contamination, seed)
            found = detect(test, detector, fit_df=fit)
            result["runs"][method] = {
                "metrics": compute_metrics(y[partitions["test"]], found.flags, found.scores),
                "scores": found.scores.tolist(),
                "flags": found.flags.tolist(),
                "fit_rows": len(fit),
            }
        except Exception as error:
            result["errors"].append({"detector": method, "error": repr(error)})
    return result


def x_evaluate_frozen__mutmut_19(
    frame: pd.DataFrame, labels, partitions: dict, *, seed: int, methods: list[str]
) -> dict:
    """Run named detectors on unchanged positions with training-only preparation."""
    if (
        not methods
        or len(set(methods)) != len(methods)
        or set(methods) - set([*DETECTOR_NAMES, *DEEP_NAMES])
    ):
        raise ValueError("detectors must be explicit, unique row-level registry names")
    if type(seed) is not int or not 0 <= seed < 3**32:
        raise ValueError("seed must be a nonnegative 32-bit integer")
    prepared = prepare_frozen(frame, partitions)
    y = np.asarray(labels)
    if y.ndim != 1 or len(y) != len(frame) or set(np.unique(y)) - {0, 1}:
        raise ValueError("labels must be an aligned binary vector")
    for name in PARTITIONS:
        if set(np.unique(y[partitions[name]])) != {0, 1}:
            raise ValueError("both classes are required in every frozen partition")
    train, test = prepared["train"], prepared["test"]
    contamination = clip_contamination(float(y[partitions["train"]].mean()))
    result = {
        "protocol": PROTOCOL,
        "exploratory": True,
        "seed": seed,
        "partitions": {name: list(partitions[name]) for name in PARTITIONS},
        "preprocessing": prepared["fit"],
        "calibration": {"policy": "train_prevalence", "value": contamination},
        "prevalence": {name: float(y[partitions[name]].mean()) for name in PARTITIONS},
        "runs": {},
        "errors": [],
        "skipped": [],
    }
    skipped = skipped_detectors(len(train))
    for method in methods:
        if method in skipped:
            result["skipped"].append(method)
            continue
        fit = capped(train, method, seed)
        try:
            detector = build(method, contamination, seed)
            found = detect(test, detector, fit_df=fit)
            result["runs"][method] = {
                "metrics": compute_metrics(y[partitions["test"]], found.flags, found.scores),
                "scores": found.scores.tolist(),
                "flags": found.flags.tolist(),
                "fit_rows": len(fit),
            }
        except Exception as error:
            result["errors"].append({"detector": method, "error": repr(error)})
    return result


def x_evaluate_frozen__mutmut_20(
    frame: pd.DataFrame, labels, partitions: dict, *, seed: int, methods: list[str]
) -> dict:
    """Run named detectors on unchanged positions with training-only preparation."""
    if (
        not methods
        or len(set(methods)) != len(methods)
        or set(methods) - set([*DETECTOR_NAMES, *DEEP_NAMES])
    ):
        raise ValueError("detectors must be explicit, unique row-level registry names")
    if type(seed) is not int or not 0 <= seed < 2**33:
        raise ValueError("seed must be a nonnegative 32-bit integer")
    prepared = prepare_frozen(frame, partitions)
    y = np.asarray(labels)
    if y.ndim != 1 or len(y) != len(frame) or set(np.unique(y)) - {0, 1}:
        raise ValueError("labels must be an aligned binary vector")
    for name in PARTITIONS:
        if set(np.unique(y[partitions[name]])) != {0, 1}:
            raise ValueError("both classes are required in every frozen partition")
    train, test = prepared["train"], prepared["test"]
    contamination = clip_contamination(float(y[partitions["train"]].mean()))
    result = {
        "protocol": PROTOCOL,
        "exploratory": True,
        "seed": seed,
        "partitions": {name: list(partitions[name]) for name in PARTITIONS},
        "preprocessing": prepared["fit"],
        "calibration": {"policy": "train_prevalence", "value": contamination},
        "prevalence": {name: float(y[partitions[name]].mean()) for name in PARTITIONS},
        "runs": {},
        "errors": [],
        "skipped": [],
    }
    skipped = skipped_detectors(len(train))
    for method in methods:
        if method in skipped:
            result["skipped"].append(method)
            continue
        fit = capped(train, method, seed)
        try:
            detector = build(method, contamination, seed)
            found = detect(test, detector, fit_df=fit)
            result["runs"][method] = {
                "metrics": compute_metrics(y[partitions["test"]], found.flags, found.scores),
                "scores": found.scores.tolist(),
                "flags": found.flags.tolist(),
                "fit_rows": len(fit),
            }
        except Exception as error:
            result["errors"].append({"detector": method, "error": repr(error)})
    return result


def x_evaluate_frozen__mutmut_21(
    frame: pd.DataFrame, labels, partitions: dict, *, seed: int, methods: list[str]
) -> dict:
    """Run named detectors on unchanged positions with training-only preparation."""
    if (
        not methods
        or len(set(methods)) != len(methods)
        or set(methods) - set([*DETECTOR_NAMES, *DEEP_NAMES])
    ):
        raise ValueError("detectors must be explicit, unique row-level registry names")
    if type(seed) is not int or not 0 <= seed < 2**32:
        raise ValueError(None)
    prepared = prepare_frozen(frame, partitions)
    y = np.asarray(labels)
    if y.ndim != 1 or len(y) != len(frame) or set(np.unique(y)) - {0, 1}:
        raise ValueError("labels must be an aligned binary vector")
    for name in PARTITIONS:
        if set(np.unique(y[partitions[name]])) != {0, 1}:
            raise ValueError("both classes are required in every frozen partition")
    train, test = prepared["train"], prepared["test"]
    contamination = clip_contamination(float(y[partitions["train"]].mean()))
    result = {
        "protocol": PROTOCOL,
        "exploratory": True,
        "seed": seed,
        "partitions": {name: list(partitions[name]) for name in PARTITIONS},
        "preprocessing": prepared["fit"],
        "calibration": {"policy": "train_prevalence", "value": contamination},
        "prevalence": {name: float(y[partitions[name]].mean()) for name in PARTITIONS},
        "runs": {},
        "errors": [],
        "skipped": [],
    }
    skipped = skipped_detectors(len(train))
    for method in methods:
        if method in skipped:
            result["skipped"].append(method)
            continue
        fit = capped(train, method, seed)
        try:
            detector = build(method, contamination, seed)
            found = detect(test, detector, fit_df=fit)
            result["runs"][method] = {
                "metrics": compute_metrics(y[partitions["test"]], found.flags, found.scores),
                "scores": found.scores.tolist(),
                "flags": found.flags.tolist(),
                "fit_rows": len(fit),
            }
        except Exception as error:
            result["errors"].append({"detector": method, "error": repr(error)})
    return result


def x_evaluate_frozen__mutmut_22(
    frame: pd.DataFrame, labels, partitions: dict, *, seed: int, methods: list[str]
) -> dict:
    """Run named detectors on unchanged positions with training-only preparation."""
    if (
        not methods
        or len(set(methods)) != len(methods)
        or set(methods) - set([*DETECTOR_NAMES, *DEEP_NAMES])
    ):
        raise ValueError("detectors must be explicit, unique row-level registry names")
    if type(seed) is not int or not 0 <= seed < 2**32:
        raise ValueError("XXseed must be a nonnegative 32-bit integerXX")
    prepared = prepare_frozen(frame, partitions)
    y = np.asarray(labels)
    if y.ndim != 1 or len(y) != len(frame) or set(np.unique(y)) - {0, 1}:
        raise ValueError("labels must be an aligned binary vector")
    for name in PARTITIONS:
        if set(np.unique(y[partitions[name]])) != {0, 1}:
            raise ValueError("both classes are required in every frozen partition")
    train, test = prepared["train"], prepared["test"]
    contamination = clip_contamination(float(y[partitions["train"]].mean()))
    result = {
        "protocol": PROTOCOL,
        "exploratory": True,
        "seed": seed,
        "partitions": {name: list(partitions[name]) for name in PARTITIONS},
        "preprocessing": prepared["fit"],
        "calibration": {"policy": "train_prevalence", "value": contamination},
        "prevalence": {name: float(y[partitions[name]].mean()) for name in PARTITIONS},
        "runs": {},
        "errors": [],
        "skipped": [],
    }
    skipped = skipped_detectors(len(train))
    for method in methods:
        if method in skipped:
            result["skipped"].append(method)
            continue
        fit = capped(train, method, seed)
        try:
            detector = build(method, contamination, seed)
            found = detect(test, detector, fit_df=fit)
            result["runs"][method] = {
                "metrics": compute_metrics(y[partitions["test"]], found.flags, found.scores),
                "scores": found.scores.tolist(),
                "flags": found.flags.tolist(),
                "fit_rows": len(fit),
            }
        except Exception as error:
            result["errors"].append({"detector": method, "error": repr(error)})
    return result


def x_evaluate_frozen__mutmut_23(
    frame: pd.DataFrame, labels, partitions: dict, *, seed: int, methods: list[str]
) -> dict:
    """Run named detectors on unchanged positions with training-only preparation."""
    if (
        not methods
        or len(set(methods)) != len(methods)
        or set(methods) - set([*DETECTOR_NAMES, *DEEP_NAMES])
    ):
        raise ValueError("detectors must be explicit, unique row-level registry names")
    if type(seed) is not int or not 0 <= seed < 2**32:
        raise ValueError("SEED MUST BE A NONNEGATIVE 32-BIT INTEGER")
    prepared = prepare_frozen(frame, partitions)
    y = np.asarray(labels)
    if y.ndim != 1 or len(y) != len(frame) or set(np.unique(y)) - {0, 1}:
        raise ValueError("labels must be an aligned binary vector")
    for name in PARTITIONS:
        if set(np.unique(y[partitions[name]])) != {0, 1}:
            raise ValueError("both classes are required in every frozen partition")
    train, test = prepared["train"], prepared["test"]
    contamination = clip_contamination(float(y[partitions["train"]].mean()))
    result = {
        "protocol": PROTOCOL,
        "exploratory": True,
        "seed": seed,
        "partitions": {name: list(partitions[name]) for name in PARTITIONS},
        "preprocessing": prepared["fit"],
        "calibration": {"policy": "train_prevalence", "value": contamination},
        "prevalence": {name: float(y[partitions[name]].mean()) for name in PARTITIONS},
        "runs": {},
        "errors": [],
        "skipped": [],
    }
    skipped = skipped_detectors(len(train))
    for method in methods:
        if method in skipped:
            result["skipped"].append(method)
            continue
        fit = capped(train, method, seed)
        try:
            detector = build(method, contamination, seed)
            found = detect(test, detector, fit_df=fit)
            result["runs"][method] = {
                "metrics": compute_metrics(y[partitions["test"]], found.flags, found.scores),
                "scores": found.scores.tolist(),
                "flags": found.flags.tolist(),
                "fit_rows": len(fit),
            }
        except Exception as error:
            result["errors"].append({"detector": method, "error": repr(error)})
    return result


def x_evaluate_frozen__mutmut_24(
    frame: pd.DataFrame, labels, partitions: dict, *, seed: int, methods: list[str]
) -> dict:
    """Run named detectors on unchanged positions with training-only preparation."""
    if (
        not methods
        or len(set(methods)) != len(methods)
        or set(methods) - set([*DETECTOR_NAMES, *DEEP_NAMES])
    ):
        raise ValueError("detectors must be explicit, unique row-level registry names")
    if type(seed) is not int or not 0 <= seed < 2**32:
        raise ValueError("seed must be a nonnegative 32-bit integer")
    prepared = None
    y = np.asarray(labels)
    if y.ndim != 1 or len(y) != len(frame) or set(np.unique(y)) - {0, 1}:
        raise ValueError("labels must be an aligned binary vector")
    for name in PARTITIONS:
        if set(np.unique(y[partitions[name]])) != {0, 1}:
            raise ValueError("both classes are required in every frozen partition")
    train, test = prepared["train"], prepared["test"]
    contamination = clip_contamination(float(y[partitions["train"]].mean()))
    result = {
        "protocol": PROTOCOL,
        "exploratory": True,
        "seed": seed,
        "partitions": {name: list(partitions[name]) for name in PARTITIONS},
        "preprocessing": prepared["fit"],
        "calibration": {"policy": "train_prevalence", "value": contamination},
        "prevalence": {name: float(y[partitions[name]].mean()) for name in PARTITIONS},
        "runs": {},
        "errors": [],
        "skipped": [],
    }
    skipped = skipped_detectors(len(train))
    for method in methods:
        if method in skipped:
            result["skipped"].append(method)
            continue
        fit = capped(train, method, seed)
        try:
            detector = build(method, contamination, seed)
            found = detect(test, detector, fit_df=fit)
            result["runs"][method] = {
                "metrics": compute_metrics(y[partitions["test"]], found.flags, found.scores),
                "scores": found.scores.tolist(),
                "flags": found.flags.tolist(),
                "fit_rows": len(fit),
            }
        except Exception as error:
            result["errors"].append({"detector": method, "error": repr(error)})
    return result


def x_evaluate_frozen__mutmut_25(
    frame: pd.DataFrame, labels, partitions: dict, *, seed: int, methods: list[str]
) -> dict:
    """Run named detectors on unchanged positions with training-only preparation."""
    if (
        not methods
        or len(set(methods)) != len(methods)
        or set(methods) - set([*DETECTOR_NAMES, *DEEP_NAMES])
    ):
        raise ValueError("detectors must be explicit, unique row-level registry names")
    if type(seed) is not int or not 0 <= seed < 2**32:
        raise ValueError("seed must be a nonnegative 32-bit integer")
    prepared = prepare_frozen(None, partitions)
    y = np.asarray(labels)
    if y.ndim != 1 or len(y) != len(frame) or set(np.unique(y)) - {0, 1}:
        raise ValueError("labels must be an aligned binary vector")
    for name in PARTITIONS:
        if set(np.unique(y[partitions[name]])) != {0, 1}:
            raise ValueError("both classes are required in every frozen partition")
    train, test = prepared["train"], prepared["test"]
    contamination = clip_contamination(float(y[partitions["train"]].mean()))
    result = {
        "protocol": PROTOCOL,
        "exploratory": True,
        "seed": seed,
        "partitions": {name: list(partitions[name]) for name in PARTITIONS},
        "preprocessing": prepared["fit"],
        "calibration": {"policy": "train_prevalence", "value": contamination},
        "prevalence": {name: float(y[partitions[name]].mean()) for name in PARTITIONS},
        "runs": {},
        "errors": [],
        "skipped": [],
    }
    skipped = skipped_detectors(len(train))
    for method in methods:
        if method in skipped:
            result["skipped"].append(method)
            continue
        fit = capped(train, method, seed)
        try:
            detector = build(method, contamination, seed)
            found = detect(test, detector, fit_df=fit)
            result["runs"][method] = {
                "metrics": compute_metrics(y[partitions["test"]], found.flags, found.scores),
                "scores": found.scores.tolist(),
                "flags": found.flags.tolist(),
                "fit_rows": len(fit),
            }
        except Exception as error:
            result["errors"].append({"detector": method, "error": repr(error)})
    return result


def x_evaluate_frozen__mutmut_26(
    frame: pd.DataFrame, labels, partitions: dict, *, seed: int, methods: list[str]
) -> dict:
    """Run named detectors on unchanged positions with training-only preparation."""
    if (
        not methods
        or len(set(methods)) != len(methods)
        or set(methods) - set([*DETECTOR_NAMES, *DEEP_NAMES])
    ):
        raise ValueError("detectors must be explicit, unique row-level registry names")
    if type(seed) is not int or not 0 <= seed < 2**32:
        raise ValueError("seed must be a nonnegative 32-bit integer")
    prepared = prepare_frozen(frame, None)
    y = np.asarray(labels)
    if y.ndim != 1 or len(y) != len(frame) or set(np.unique(y)) - {0, 1}:
        raise ValueError("labels must be an aligned binary vector")
    for name in PARTITIONS:
        if set(np.unique(y[partitions[name]])) != {0, 1}:
            raise ValueError("both classes are required in every frozen partition")
    train, test = prepared["train"], prepared["test"]
    contamination = clip_contamination(float(y[partitions["train"]].mean()))
    result = {
        "protocol": PROTOCOL,
        "exploratory": True,
        "seed": seed,
        "partitions": {name: list(partitions[name]) for name in PARTITIONS},
        "preprocessing": prepared["fit"],
        "calibration": {"policy": "train_prevalence", "value": contamination},
        "prevalence": {name: float(y[partitions[name]].mean()) for name in PARTITIONS},
        "runs": {},
        "errors": [],
        "skipped": [],
    }
    skipped = skipped_detectors(len(train))
    for method in methods:
        if method in skipped:
            result["skipped"].append(method)
            continue
        fit = capped(train, method, seed)
        try:
            detector = build(method, contamination, seed)
            found = detect(test, detector, fit_df=fit)
            result["runs"][method] = {
                "metrics": compute_metrics(y[partitions["test"]], found.flags, found.scores),
                "scores": found.scores.tolist(),
                "flags": found.flags.tolist(),
                "fit_rows": len(fit),
            }
        except Exception as error:
            result["errors"].append({"detector": method, "error": repr(error)})
    return result


def x_evaluate_frozen__mutmut_27(
    frame: pd.DataFrame, labels, partitions: dict, *, seed: int, methods: list[str]
) -> dict:
    """Run named detectors on unchanged positions with training-only preparation."""
    if (
        not methods
        or len(set(methods)) != len(methods)
        or set(methods) - set([*DETECTOR_NAMES, *DEEP_NAMES])
    ):
        raise ValueError("detectors must be explicit, unique row-level registry names")
    if type(seed) is not int or not 0 <= seed < 2**32:
        raise ValueError("seed must be a nonnegative 32-bit integer")
    prepared = prepare_frozen(partitions)
    y = np.asarray(labels)
    if y.ndim != 1 or len(y) != len(frame) or set(np.unique(y)) - {0, 1}:
        raise ValueError("labels must be an aligned binary vector")
    for name in PARTITIONS:
        if set(np.unique(y[partitions[name]])) != {0, 1}:
            raise ValueError("both classes are required in every frozen partition")
    train, test = prepared["train"], prepared["test"]
    contamination = clip_contamination(float(y[partitions["train"]].mean()))
    result = {
        "protocol": PROTOCOL,
        "exploratory": True,
        "seed": seed,
        "partitions": {name: list(partitions[name]) for name in PARTITIONS},
        "preprocessing": prepared["fit"],
        "calibration": {"policy": "train_prevalence", "value": contamination},
        "prevalence": {name: float(y[partitions[name]].mean()) for name in PARTITIONS},
        "runs": {},
        "errors": [],
        "skipped": [],
    }
    skipped = skipped_detectors(len(train))
    for method in methods:
        if method in skipped:
            result["skipped"].append(method)
            continue
        fit = capped(train, method, seed)
        try:
            detector = build(method, contamination, seed)
            found = detect(test, detector, fit_df=fit)
            result["runs"][method] = {
                "metrics": compute_metrics(y[partitions["test"]], found.flags, found.scores),
                "scores": found.scores.tolist(),
                "flags": found.flags.tolist(),
                "fit_rows": len(fit),
            }
        except Exception as error:
            result["errors"].append({"detector": method, "error": repr(error)})
    return result


def x_evaluate_frozen__mutmut_28(
    frame: pd.DataFrame, labels, partitions: dict, *, seed: int, methods: list[str]
) -> dict:
    """Run named detectors on unchanged positions with training-only preparation."""
    if (
        not methods
        or len(set(methods)) != len(methods)
        or set(methods) - set([*DETECTOR_NAMES, *DEEP_NAMES])
    ):
        raise ValueError("detectors must be explicit, unique row-level registry names")
    if type(seed) is not int or not 0 <= seed < 2**32:
        raise ValueError("seed must be a nonnegative 32-bit integer")
    prepared = prepare_frozen(frame, )
    y = np.asarray(labels)
    if y.ndim != 1 or len(y) != len(frame) or set(np.unique(y)) - {0, 1}:
        raise ValueError("labels must be an aligned binary vector")
    for name in PARTITIONS:
        if set(np.unique(y[partitions[name]])) != {0, 1}:
            raise ValueError("both classes are required in every frozen partition")
    train, test = prepared["train"], prepared["test"]
    contamination = clip_contamination(float(y[partitions["train"]].mean()))
    result = {
        "protocol": PROTOCOL,
        "exploratory": True,
        "seed": seed,
        "partitions": {name: list(partitions[name]) for name in PARTITIONS},
        "preprocessing": prepared["fit"],
        "calibration": {"policy": "train_prevalence", "value": contamination},
        "prevalence": {name: float(y[partitions[name]].mean()) for name in PARTITIONS},
        "runs": {},
        "errors": [],
        "skipped": [],
    }
    skipped = skipped_detectors(len(train))
    for method in methods:
        if method in skipped:
            result["skipped"].append(method)
            continue
        fit = capped(train, method, seed)
        try:
            detector = build(method, contamination, seed)
            found = detect(test, detector, fit_df=fit)
            result["runs"][method] = {
                "metrics": compute_metrics(y[partitions["test"]], found.flags, found.scores),
                "scores": found.scores.tolist(),
                "flags": found.flags.tolist(),
                "fit_rows": len(fit),
            }
        except Exception as error:
            result["errors"].append({"detector": method, "error": repr(error)})
    return result


def x_evaluate_frozen__mutmut_29(
    frame: pd.DataFrame, labels, partitions: dict, *, seed: int, methods: list[str]
) -> dict:
    """Run named detectors on unchanged positions with training-only preparation."""
    if (
        not methods
        or len(set(methods)) != len(methods)
        or set(methods) - set([*DETECTOR_NAMES, *DEEP_NAMES])
    ):
        raise ValueError("detectors must be explicit, unique row-level registry names")
    if type(seed) is not int or not 0 <= seed < 2**32:
        raise ValueError("seed must be a nonnegative 32-bit integer")
    prepared = prepare_frozen(frame, partitions)
    y = None
    if y.ndim != 1 or len(y) != len(frame) or set(np.unique(y)) - {0, 1}:
        raise ValueError("labels must be an aligned binary vector")
    for name in PARTITIONS:
        if set(np.unique(y[partitions[name]])) != {0, 1}:
            raise ValueError("both classes are required in every frozen partition")
    train, test = prepared["train"], prepared["test"]
    contamination = clip_contamination(float(y[partitions["train"]].mean()))
    result = {
        "protocol": PROTOCOL,
        "exploratory": True,
        "seed": seed,
        "partitions": {name: list(partitions[name]) for name in PARTITIONS},
        "preprocessing": prepared["fit"],
        "calibration": {"policy": "train_prevalence", "value": contamination},
        "prevalence": {name: float(y[partitions[name]].mean()) for name in PARTITIONS},
        "runs": {},
        "errors": [],
        "skipped": [],
    }
    skipped = skipped_detectors(len(train))
    for method in methods:
        if method in skipped:
            result["skipped"].append(method)
            continue
        fit = capped(train, method, seed)
        try:
            detector = build(method, contamination, seed)
            found = detect(test, detector, fit_df=fit)
            result["runs"][method] = {
                "metrics": compute_metrics(y[partitions["test"]], found.flags, found.scores),
                "scores": found.scores.tolist(),
                "flags": found.flags.tolist(),
                "fit_rows": len(fit),
            }
        except Exception as error:
            result["errors"].append({"detector": method, "error": repr(error)})
    return result


def x_evaluate_frozen__mutmut_30(
    frame: pd.DataFrame, labels, partitions: dict, *, seed: int, methods: list[str]
) -> dict:
    """Run named detectors on unchanged positions with training-only preparation."""
    if (
        not methods
        or len(set(methods)) != len(methods)
        or set(methods) - set([*DETECTOR_NAMES, *DEEP_NAMES])
    ):
        raise ValueError("detectors must be explicit, unique row-level registry names")
    if type(seed) is not int or not 0 <= seed < 2**32:
        raise ValueError("seed must be a nonnegative 32-bit integer")
    prepared = prepare_frozen(frame, partitions)
    y = np.asarray(None)
    if y.ndim != 1 or len(y) != len(frame) or set(np.unique(y)) - {0, 1}:
        raise ValueError("labels must be an aligned binary vector")
    for name in PARTITIONS:
        if set(np.unique(y[partitions[name]])) != {0, 1}:
            raise ValueError("both classes are required in every frozen partition")
    train, test = prepared["train"], prepared["test"]
    contamination = clip_contamination(float(y[partitions["train"]].mean()))
    result = {
        "protocol": PROTOCOL,
        "exploratory": True,
        "seed": seed,
        "partitions": {name: list(partitions[name]) for name in PARTITIONS},
        "preprocessing": prepared["fit"],
        "calibration": {"policy": "train_prevalence", "value": contamination},
        "prevalence": {name: float(y[partitions[name]].mean()) for name in PARTITIONS},
        "runs": {},
        "errors": [],
        "skipped": [],
    }
    skipped = skipped_detectors(len(train))
    for method in methods:
        if method in skipped:
            result["skipped"].append(method)
            continue
        fit = capped(train, method, seed)
        try:
            detector = build(method, contamination, seed)
            found = detect(test, detector, fit_df=fit)
            result["runs"][method] = {
                "metrics": compute_metrics(y[partitions["test"]], found.flags, found.scores),
                "scores": found.scores.tolist(),
                "flags": found.flags.tolist(),
                "fit_rows": len(fit),
            }
        except Exception as error:
            result["errors"].append({"detector": method, "error": repr(error)})
    return result


def x_evaluate_frozen__mutmut_31(
    frame: pd.DataFrame, labels, partitions: dict, *, seed: int, methods: list[str]
) -> dict:
    """Run named detectors on unchanged positions with training-only preparation."""
    if (
        not methods
        or len(set(methods)) != len(methods)
        or set(methods) - set([*DETECTOR_NAMES, *DEEP_NAMES])
    ):
        raise ValueError("detectors must be explicit, unique row-level registry names")
    if type(seed) is not int or not 0 <= seed < 2**32:
        raise ValueError("seed must be a nonnegative 32-bit integer")
    prepared = prepare_frozen(frame, partitions)
    y = np.asarray(labels)
    if y.ndim != 1 or len(y) != len(frame) and set(np.unique(y)) - {0, 1}:
        raise ValueError("labels must be an aligned binary vector")
    for name in PARTITIONS:
        if set(np.unique(y[partitions[name]])) != {0, 1}:
            raise ValueError("both classes are required in every frozen partition")
    train, test = prepared["train"], prepared["test"]
    contamination = clip_contamination(float(y[partitions["train"]].mean()))
    result = {
        "protocol": PROTOCOL,
        "exploratory": True,
        "seed": seed,
        "partitions": {name: list(partitions[name]) for name in PARTITIONS},
        "preprocessing": prepared["fit"],
        "calibration": {"policy": "train_prevalence", "value": contamination},
        "prevalence": {name: float(y[partitions[name]].mean()) for name in PARTITIONS},
        "runs": {},
        "errors": [],
        "skipped": [],
    }
    skipped = skipped_detectors(len(train))
    for method in methods:
        if method in skipped:
            result["skipped"].append(method)
            continue
        fit = capped(train, method, seed)
        try:
            detector = build(method, contamination, seed)
            found = detect(test, detector, fit_df=fit)
            result["runs"][method] = {
                "metrics": compute_metrics(y[partitions["test"]], found.flags, found.scores),
                "scores": found.scores.tolist(),
                "flags": found.flags.tolist(),
                "fit_rows": len(fit),
            }
        except Exception as error:
            result["errors"].append({"detector": method, "error": repr(error)})
    return result


def x_evaluate_frozen__mutmut_32(
    frame: pd.DataFrame, labels, partitions: dict, *, seed: int, methods: list[str]
) -> dict:
    """Run named detectors on unchanged positions with training-only preparation."""
    if (
        not methods
        or len(set(methods)) != len(methods)
        or set(methods) - set([*DETECTOR_NAMES, *DEEP_NAMES])
    ):
        raise ValueError("detectors must be explicit, unique row-level registry names")
    if type(seed) is not int or not 0 <= seed < 2**32:
        raise ValueError("seed must be a nonnegative 32-bit integer")
    prepared = prepare_frozen(frame, partitions)
    y = np.asarray(labels)
    if y.ndim != 1 and len(y) != len(frame) or set(np.unique(y)) - {0, 1}:
        raise ValueError("labels must be an aligned binary vector")
    for name in PARTITIONS:
        if set(np.unique(y[partitions[name]])) != {0, 1}:
            raise ValueError("both classes are required in every frozen partition")
    train, test = prepared["train"], prepared["test"]
    contamination = clip_contamination(float(y[partitions["train"]].mean()))
    result = {
        "protocol": PROTOCOL,
        "exploratory": True,
        "seed": seed,
        "partitions": {name: list(partitions[name]) for name in PARTITIONS},
        "preprocessing": prepared["fit"],
        "calibration": {"policy": "train_prevalence", "value": contamination},
        "prevalence": {name: float(y[partitions[name]].mean()) for name in PARTITIONS},
        "runs": {},
        "errors": [],
        "skipped": [],
    }
    skipped = skipped_detectors(len(train))
    for method in methods:
        if method in skipped:
            result["skipped"].append(method)
            continue
        fit = capped(train, method, seed)
        try:
            detector = build(method, contamination, seed)
            found = detect(test, detector, fit_df=fit)
            result["runs"][method] = {
                "metrics": compute_metrics(y[partitions["test"]], found.flags, found.scores),
                "scores": found.scores.tolist(),
                "flags": found.flags.tolist(),
                "fit_rows": len(fit),
            }
        except Exception as error:
            result["errors"].append({"detector": method, "error": repr(error)})
    return result


def x_evaluate_frozen__mutmut_33(
    frame: pd.DataFrame, labels, partitions: dict, *, seed: int, methods: list[str]
) -> dict:
    """Run named detectors on unchanged positions with training-only preparation."""
    if (
        not methods
        or len(set(methods)) != len(methods)
        or set(methods) - set([*DETECTOR_NAMES, *DEEP_NAMES])
    ):
        raise ValueError("detectors must be explicit, unique row-level registry names")
    if type(seed) is not int or not 0 <= seed < 2**32:
        raise ValueError("seed must be a nonnegative 32-bit integer")
    prepared = prepare_frozen(frame, partitions)
    y = np.asarray(labels)
    if y.ndim == 1 or len(y) != len(frame) or set(np.unique(y)) - {0, 1}:
        raise ValueError("labels must be an aligned binary vector")
    for name in PARTITIONS:
        if set(np.unique(y[partitions[name]])) != {0, 1}:
            raise ValueError("both classes are required in every frozen partition")
    train, test = prepared["train"], prepared["test"]
    contamination = clip_contamination(float(y[partitions["train"]].mean()))
    result = {
        "protocol": PROTOCOL,
        "exploratory": True,
        "seed": seed,
        "partitions": {name: list(partitions[name]) for name in PARTITIONS},
        "preprocessing": prepared["fit"],
        "calibration": {"policy": "train_prevalence", "value": contamination},
        "prevalence": {name: float(y[partitions[name]].mean()) for name in PARTITIONS},
        "runs": {},
        "errors": [],
        "skipped": [],
    }
    skipped = skipped_detectors(len(train))
    for method in methods:
        if method in skipped:
            result["skipped"].append(method)
            continue
        fit = capped(train, method, seed)
        try:
            detector = build(method, contamination, seed)
            found = detect(test, detector, fit_df=fit)
            result["runs"][method] = {
                "metrics": compute_metrics(y[partitions["test"]], found.flags, found.scores),
                "scores": found.scores.tolist(),
                "flags": found.flags.tolist(),
                "fit_rows": len(fit),
            }
        except Exception as error:
            result["errors"].append({"detector": method, "error": repr(error)})
    return result


def x_evaluate_frozen__mutmut_34(
    frame: pd.DataFrame, labels, partitions: dict, *, seed: int, methods: list[str]
) -> dict:
    """Run named detectors on unchanged positions with training-only preparation."""
    if (
        not methods
        or len(set(methods)) != len(methods)
        or set(methods) - set([*DETECTOR_NAMES, *DEEP_NAMES])
    ):
        raise ValueError("detectors must be explicit, unique row-level registry names")
    if type(seed) is not int or not 0 <= seed < 2**32:
        raise ValueError("seed must be a nonnegative 32-bit integer")
    prepared = prepare_frozen(frame, partitions)
    y = np.asarray(labels)
    if y.ndim != 2 or len(y) != len(frame) or set(np.unique(y)) - {0, 1}:
        raise ValueError("labels must be an aligned binary vector")
    for name in PARTITIONS:
        if set(np.unique(y[partitions[name]])) != {0, 1}:
            raise ValueError("both classes are required in every frozen partition")
    train, test = prepared["train"], prepared["test"]
    contamination = clip_contamination(float(y[partitions["train"]].mean()))
    result = {
        "protocol": PROTOCOL,
        "exploratory": True,
        "seed": seed,
        "partitions": {name: list(partitions[name]) for name in PARTITIONS},
        "preprocessing": prepared["fit"],
        "calibration": {"policy": "train_prevalence", "value": contamination},
        "prevalence": {name: float(y[partitions[name]].mean()) for name in PARTITIONS},
        "runs": {},
        "errors": [],
        "skipped": [],
    }
    skipped = skipped_detectors(len(train))
    for method in methods:
        if method in skipped:
            result["skipped"].append(method)
            continue
        fit = capped(train, method, seed)
        try:
            detector = build(method, contamination, seed)
            found = detect(test, detector, fit_df=fit)
            result["runs"][method] = {
                "metrics": compute_metrics(y[partitions["test"]], found.flags, found.scores),
                "scores": found.scores.tolist(),
                "flags": found.flags.tolist(),
                "fit_rows": len(fit),
            }
        except Exception as error:
            result["errors"].append({"detector": method, "error": repr(error)})
    return result


def x_evaluate_frozen__mutmut_35(
    frame: pd.DataFrame, labels, partitions: dict, *, seed: int, methods: list[str]
) -> dict:
    """Run named detectors on unchanged positions with training-only preparation."""
    if (
        not methods
        or len(set(methods)) != len(methods)
        or set(methods) - set([*DETECTOR_NAMES, *DEEP_NAMES])
    ):
        raise ValueError("detectors must be explicit, unique row-level registry names")
    if type(seed) is not int or not 0 <= seed < 2**32:
        raise ValueError("seed must be a nonnegative 32-bit integer")
    prepared = prepare_frozen(frame, partitions)
    y = np.asarray(labels)
    if y.ndim != 1 or len(y) == len(frame) or set(np.unique(y)) - {0, 1}:
        raise ValueError("labels must be an aligned binary vector")
    for name in PARTITIONS:
        if set(np.unique(y[partitions[name]])) != {0, 1}:
            raise ValueError("both classes are required in every frozen partition")
    train, test = prepared["train"], prepared["test"]
    contamination = clip_contamination(float(y[partitions["train"]].mean()))
    result = {
        "protocol": PROTOCOL,
        "exploratory": True,
        "seed": seed,
        "partitions": {name: list(partitions[name]) for name in PARTITIONS},
        "preprocessing": prepared["fit"],
        "calibration": {"policy": "train_prevalence", "value": contamination},
        "prevalence": {name: float(y[partitions[name]].mean()) for name in PARTITIONS},
        "runs": {},
        "errors": [],
        "skipped": [],
    }
    skipped = skipped_detectors(len(train))
    for method in methods:
        if method in skipped:
            result["skipped"].append(method)
            continue
        fit = capped(train, method, seed)
        try:
            detector = build(method, contamination, seed)
            found = detect(test, detector, fit_df=fit)
            result["runs"][method] = {
                "metrics": compute_metrics(y[partitions["test"]], found.flags, found.scores),
                "scores": found.scores.tolist(),
                "flags": found.flags.tolist(),
                "fit_rows": len(fit),
            }
        except Exception as error:
            result["errors"].append({"detector": method, "error": repr(error)})
    return result


def x_evaluate_frozen__mutmut_36(
    frame: pd.DataFrame, labels, partitions: dict, *, seed: int, methods: list[str]
) -> dict:
    """Run named detectors on unchanged positions with training-only preparation."""
    if (
        not methods
        or len(set(methods)) != len(methods)
        or set(methods) - set([*DETECTOR_NAMES, *DEEP_NAMES])
    ):
        raise ValueError("detectors must be explicit, unique row-level registry names")
    if type(seed) is not int or not 0 <= seed < 2**32:
        raise ValueError("seed must be a nonnegative 32-bit integer")
    prepared = prepare_frozen(frame, partitions)
    y = np.asarray(labels)
    if y.ndim != 1 or len(y) != len(frame) or set(np.unique(y)) + {0, 1}:
        raise ValueError("labels must be an aligned binary vector")
    for name in PARTITIONS:
        if set(np.unique(y[partitions[name]])) != {0, 1}:
            raise ValueError("both classes are required in every frozen partition")
    train, test = prepared["train"], prepared["test"]
    contamination = clip_contamination(float(y[partitions["train"]].mean()))
    result = {
        "protocol": PROTOCOL,
        "exploratory": True,
        "seed": seed,
        "partitions": {name: list(partitions[name]) for name in PARTITIONS},
        "preprocessing": prepared["fit"],
        "calibration": {"policy": "train_prevalence", "value": contamination},
        "prevalence": {name: float(y[partitions[name]].mean()) for name in PARTITIONS},
        "runs": {},
        "errors": [],
        "skipped": [],
    }
    skipped = skipped_detectors(len(train))
    for method in methods:
        if method in skipped:
            result["skipped"].append(method)
            continue
        fit = capped(train, method, seed)
        try:
            detector = build(method, contamination, seed)
            found = detect(test, detector, fit_df=fit)
            result["runs"][method] = {
                "metrics": compute_metrics(y[partitions["test"]], found.flags, found.scores),
                "scores": found.scores.tolist(),
                "flags": found.flags.tolist(),
                "fit_rows": len(fit),
            }
        except Exception as error:
            result["errors"].append({"detector": method, "error": repr(error)})
    return result


def x_evaluate_frozen__mutmut_37(
    frame: pd.DataFrame, labels, partitions: dict, *, seed: int, methods: list[str]
) -> dict:
    """Run named detectors on unchanged positions with training-only preparation."""
    if (
        not methods
        or len(set(methods)) != len(methods)
        or set(methods) - set([*DETECTOR_NAMES, *DEEP_NAMES])
    ):
        raise ValueError("detectors must be explicit, unique row-level registry names")
    if type(seed) is not int or not 0 <= seed < 2**32:
        raise ValueError("seed must be a nonnegative 32-bit integer")
    prepared = prepare_frozen(frame, partitions)
    y = np.asarray(labels)
    if y.ndim != 1 or len(y) != len(frame) or set(None) - {0, 1}:
        raise ValueError("labels must be an aligned binary vector")
    for name in PARTITIONS:
        if set(np.unique(y[partitions[name]])) != {0, 1}:
            raise ValueError("both classes are required in every frozen partition")
    train, test = prepared["train"], prepared["test"]
    contamination = clip_contamination(float(y[partitions["train"]].mean()))
    result = {
        "protocol": PROTOCOL,
        "exploratory": True,
        "seed": seed,
        "partitions": {name: list(partitions[name]) for name in PARTITIONS},
        "preprocessing": prepared["fit"],
        "calibration": {"policy": "train_prevalence", "value": contamination},
        "prevalence": {name: float(y[partitions[name]].mean()) for name in PARTITIONS},
        "runs": {},
        "errors": [],
        "skipped": [],
    }
    skipped = skipped_detectors(len(train))
    for method in methods:
        if method in skipped:
            result["skipped"].append(method)
            continue
        fit = capped(train, method, seed)
        try:
            detector = build(method, contamination, seed)
            found = detect(test, detector, fit_df=fit)
            result["runs"][method] = {
                "metrics": compute_metrics(y[partitions["test"]], found.flags, found.scores),
                "scores": found.scores.tolist(),
                "flags": found.flags.tolist(),
                "fit_rows": len(fit),
            }
        except Exception as error:
            result["errors"].append({"detector": method, "error": repr(error)})
    return result


def x_evaluate_frozen__mutmut_38(
    frame: pd.DataFrame, labels, partitions: dict, *, seed: int, methods: list[str]
) -> dict:
    """Run named detectors on unchanged positions with training-only preparation."""
    if (
        not methods
        or len(set(methods)) != len(methods)
        or set(methods) - set([*DETECTOR_NAMES, *DEEP_NAMES])
    ):
        raise ValueError("detectors must be explicit, unique row-level registry names")
    if type(seed) is not int or not 0 <= seed < 2**32:
        raise ValueError("seed must be a nonnegative 32-bit integer")
    prepared = prepare_frozen(frame, partitions)
    y = np.asarray(labels)
    if y.ndim != 1 or len(y) != len(frame) or set(np.unique(None)) - {0, 1}:
        raise ValueError("labels must be an aligned binary vector")
    for name in PARTITIONS:
        if set(np.unique(y[partitions[name]])) != {0, 1}:
            raise ValueError("both classes are required in every frozen partition")
    train, test = prepared["train"], prepared["test"]
    contamination = clip_contamination(float(y[partitions["train"]].mean()))
    result = {
        "protocol": PROTOCOL,
        "exploratory": True,
        "seed": seed,
        "partitions": {name: list(partitions[name]) for name in PARTITIONS},
        "preprocessing": prepared["fit"],
        "calibration": {"policy": "train_prevalence", "value": contamination},
        "prevalence": {name: float(y[partitions[name]].mean()) for name in PARTITIONS},
        "runs": {},
        "errors": [],
        "skipped": [],
    }
    skipped = skipped_detectors(len(train))
    for method in methods:
        if method in skipped:
            result["skipped"].append(method)
            continue
        fit = capped(train, method, seed)
        try:
            detector = build(method, contamination, seed)
            found = detect(test, detector, fit_df=fit)
            result["runs"][method] = {
                "metrics": compute_metrics(y[partitions["test"]], found.flags, found.scores),
                "scores": found.scores.tolist(),
                "flags": found.flags.tolist(),
                "fit_rows": len(fit),
            }
        except Exception as error:
            result["errors"].append({"detector": method, "error": repr(error)})
    return result


def x_evaluate_frozen__mutmut_39(
    frame: pd.DataFrame, labels, partitions: dict, *, seed: int, methods: list[str]
) -> dict:
    """Run named detectors on unchanged positions with training-only preparation."""
    if (
        not methods
        or len(set(methods)) != len(methods)
        or set(methods) - set([*DETECTOR_NAMES, *DEEP_NAMES])
    ):
        raise ValueError("detectors must be explicit, unique row-level registry names")
    if type(seed) is not int or not 0 <= seed < 2**32:
        raise ValueError("seed must be a nonnegative 32-bit integer")
    prepared = prepare_frozen(frame, partitions)
    y = np.asarray(labels)
    if y.ndim != 1 or len(y) != len(frame) or set(np.unique(y)) - {1, 1}:
        raise ValueError("labels must be an aligned binary vector")
    for name in PARTITIONS:
        if set(np.unique(y[partitions[name]])) != {0, 1}:
            raise ValueError("both classes are required in every frozen partition")
    train, test = prepared["train"], prepared["test"]
    contamination = clip_contamination(float(y[partitions["train"]].mean()))
    result = {
        "protocol": PROTOCOL,
        "exploratory": True,
        "seed": seed,
        "partitions": {name: list(partitions[name]) for name in PARTITIONS},
        "preprocessing": prepared["fit"],
        "calibration": {"policy": "train_prevalence", "value": contamination},
        "prevalence": {name: float(y[partitions[name]].mean()) for name in PARTITIONS},
        "runs": {},
        "errors": [],
        "skipped": [],
    }
    skipped = skipped_detectors(len(train))
    for method in methods:
        if method in skipped:
            result["skipped"].append(method)
            continue
        fit = capped(train, method, seed)
        try:
            detector = build(method, contamination, seed)
            found = detect(test, detector, fit_df=fit)
            result["runs"][method] = {
                "metrics": compute_metrics(y[partitions["test"]], found.flags, found.scores),
                "scores": found.scores.tolist(),
                "flags": found.flags.tolist(),
                "fit_rows": len(fit),
            }
        except Exception as error:
            result["errors"].append({"detector": method, "error": repr(error)})
    return result


def x_evaluate_frozen__mutmut_40(
    frame: pd.DataFrame, labels, partitions: dict, *, seed: int, methods: list[str]
) -> dict:
    """Run named detectors on unchanged positions with training-only preparation."""
    if (
        not methods
        or len(set(methods)) != len(methods)
        or set(methods) - set([*DETECTOR_NAMES, *DEEP_NAMES])
    ):
        raise ValueError("detectors must be explicit, unique row-level registry names")
    if type(seed) is not int or not 0 <= seed < 2**32:
        raise ValueError("seed must be a nonnegative 32-bit integer")
    prepared = prepare_frozen(frame, partitions)
    y = np.asarray(labels)
    if y.ndim != 1 or len(y) != len(frame) or set(np.unique(y)) - {0, 2}:
        raise ValueError("labels must be an aligned binary vector")
    for name in PARTITIONS:
        if set(np.unique(y[partitions[name]])) != {0, 1}:
            raise ValueError("both classes are required in every frozen partition")
    train, test = prepared["train"], prepared["test"]
    contamination = clip_contamination(float(y[partitions["train"]].mean()))
    result = {
        "protocol": PROTOCOL,
        "exploratory": True,
        "seed": seed,
        "partitions": {name: list(partitions[name]) for name in PARTITIONS},
        "preprocessing": prepared["fit"],
        "calibration": {"policy": "train_prevalence", "value": contamination},
        "prevalence": {name: float(y[partitions[name]].mean()) for name in PARTITIONS},
        "runs": {},
        "errors": [],
        "skipped": [],
    }
    skipped = skipped_detectors(len(train))
    for method in methods:
        if method in skipped:
            result["skipped"].append(method)
            continue
        fit = capped(train, method, seed)
        try:
            detector = build(method, contamination, seed)
            found = detect(test, detector, fit_df=fit)
            result["runs"][method] = {
                "metrics": compute_metrics(y[partitions["test"]], found.flags, found.scores),
                "scores": found.scores.tolist(),
                "flags": found.flags.tolist(),
                "fit_rows": len(fit),
            }
        except Exception as error:
            result["errors"].append({"detector": method, "error": repr(error)})
    return result


def x_evaluate_frozen__mutmut_41(
    frame: pd.DataFrame, labels, partitions: dict, *, seed: int, methods: list[str]
) -> dict:
    """Run named detectors on unchanged positions with training-only preparation."""
    if (
        not methods
        or len(set(methods)) != len(methods)
        or set(methods) - set([*DETECTOR_NAMES, *DEEP_NAMES])
    ):
        raise ValueError("detectors must be explicit, unique row-level registry names")
    if type(seed) is not int or not 0 <= seed < 2**32:
        raise ValueError("seed must be a nonnegative 32-bit integer")
    prepared = prepare_frozen(frame, partitions)
    y = np.asarray(labels)
    if y.ndim != 1 or len(y) != len(frame) or set(np.unique(y)) - {0, 1}:
        raise ValueError(None)
    for name in PARTITIONS:
        if set(np.unique(y[partitions[name]])) != {0, 1}:
            raise ValueError("both classes are required in every frozen partition")
    train, test = prepared["train"], prepared["test"]
    contamination = clip_contamination(float(y[partitions["train"]].mean()))
    result = {
        "protocol": PROTOCOL,
        "exploratory": True,
        "seed": seed,
        "partitions": {name: list(partitions[name]) for name in PARTITIONS},
        "preprocessing": prepared["fit"],
        "calibration": {"policy": "train_prevalence", "value": contamination},
        "prevalence": {name: float(y[partitions[name]].mean()) for name in PARTITIONS},
        "runs": {},
        "errors": [],
        "skipped": [],
    }
    skipped = skipped_detectors(len(train))
    for method in methods:
        if method in skipped:
            result["skipped"].append(method)
            continue
        fit = capped(train, method, seed)
        try:
            detector = build(method, contamination, seed)
            found = detect(test, detector, fit_df=fit)
            result["runs"][method] = {
                "metrics": compute_metrics(y[partitions["test"]], found.flags, found.scores),
                "scores": found.scores.tolist(),
                "flags": found.flags.tolist(),
                "fit_rows": len(fit),
            }
        except Exception as error:
            result["errors"].append({"detector": method, "error": repr(error)})
    return result


def x_evaluate_frozen__mutmut_42(
    frame: pd.DataFrame, labels, partitions: dict, *, seed: int, methods: list[str]
) -> dict:
    """Run named detectors on unchanged positions with training-only preparation."""
    if (
        not methods
        or len(set(methods)) != len(methods)
        or set(methods) - set([*DETECTOR_NAMES, *DEEP_NAMES])
    ):
        raise ValueError("detectors must be explicit, unique row-level registry names")
    if type(seed) is not int or not 0 <= seed < 2**32:
        raise ValueError("seed must be a nonnegative 32-bit integer")
    prepared = prepare_frozen(frame, partitions)
    y = np.asarray(labels)
    if y.ndim != 1 or len(y) != len(frame) or set(np.unique(y)) - {0, 1}:
        raise ValueError("XXlabels must be an aligned binary vectorXX")
    for name in PARTITIONS:
        if set(np.unique(y[partitions[name]])) != {0, 1}:
            raise ValueError("both classes are required in every frozen partition")
    train, test = prepared["train"], prepared["test"]
    contamination = clip_contamination(float(y[partitions["train"]].mean()))
    result = {
        "protocol": PROTOCOL,
        "exploratory": True,
        "seed": seed,
        "partitions": {name: list(partitions[name]) for name in PARTITIONS},
        "preprocessing": prepared["fit"],
        "calibration": {"policy": "train_prevalence", "value": contamination},
        "prevalence": {name: float(y[partitions[name]].mean()) for name in PARTITIONS},
        "runs": {},
        "errors": [],
        "skipped": [],
    }
    skipped = skipped_detectors(len(train))
    for method in methods:
        if method in skipped:
            result["skipped"].append(method)
            continue
        fit = capped(train, method, seed)
        try:
            detector = build(method, contamination, seed)
            found = detect(test, detector, fit_df=fit)
            result["runs"][method] = {
                "metrics": compute_metrics(y[partitions["test"]], found.flags, found.scores),
                "scores": found.scores.tolist(),
                "flags": found.flags.tolist(),
                "fit_rows": len(fit),
            }
        except Exception as error:
            result["errors"].append({"detector": method, "error": repr(error)})
    return result


def x_evaluate_frozen__mutmut_43(
    frame: pd.DataFrame, labels, partitions: dict, *, seed: int, methods: list[str]
) -> dict:
    """Run named detectors on unchanged positions with training-only preparation."""
    if (
        not methods
        or len(set(methods)) != len(methods)
        or set(methods) - set([*DETECTOR_NAMES, *DEEP_NAMES])
    ):
        raise ValueError("detectors must be explicit, unique row-level registry names")
    if type(seed) is not int or not 0 <= seed < 2**32:
        raise ValueError("seed must be a nonnegative 32-bit integer")
    prepared = prepare_frozen(frame, partitions)
    y = np.asarray(labels)
    if y.ndim != 1 or len(y) != len(frame) or set(np.unique(y)) - {0, 1}:
        raise ValueError("LABELS MUST BE AN ALIGNED BINARY VECTOR")
    for name in PARTITIONS:
        if set(np.unique(y[partitions[name]])) != {0, 1}:
            raise ValueError("both classes are required in every frozen partition")
    train, test = prepared["train"], prepared["test"]
    contamination = clip_contamination(float(y[partitions["train"]].mean()))
    result = {
        "protocol": PROTOCOL,
        "exploratory": True,
        "seed": seed,
        "partitions": {name: list(partitions[name]) for name in PARTITIONS},
        "preprocessing": prepared["fit"],
        "calibration": {"policy": "train_prevalence", "value": contamination},
        "prevalence": {name: float(y[partitions[name]].mean()) for name in PARTITIONS},
        "runs": {},
        "errors": [],
        "skipped": [],
    }
    skipped = skipped_detectors(len(train))
    for method in methods:
        if method in skipped:
            result["skipped"].append(method)
            continue
        fit = capped(train, method, seed)
        try:
            detector = build(method, contamination, seed)
            found = detect(test, detector, fit_df=fit)
            result["runs"][method] = {
                "metrics": compute_metrics(y[partitions["test"]], found.flags, found.scores),
                "scores": found.scores.tolist(),
                "flags": found.flags.tolist(),
                "fit_rows": len(fit),
            }
        except Exception as error:
            result["errors"].append({"detector": method, "error": repr(error)})
    return result


def x_evaluate_frozen__mutmut_44(
    frame: pd.DataFrame, labels, partitions: dict, *, seed: int, methods: list[str]
) -> dict:
    """Run named detectors on unchanged positions with training-only preparation."""
    if (
        not methods
        or len(set(methods)) != len(methods)
        or set(methods) - set([*DETECTOR_NAMES, *DEEP_NAMES])
    ):
        raise ValueError("detectors must be explicit, unique row-level registry names")
    if type(seed) is not int or not 0 <= seed < 2**32:
        raise ValueError("seed must be a nonnegative 32-bit integer")
    prepared = prepare_frozen(frame, partitions)
    y = np.asarray(labels)
    if y.ndim != 1 or len(y) != len(frame) or set(np.unique(y)) - {0, 1}:
        raise ValueError("labels must be an aligned binary vector")
    for name in PARTITIONS:
        if set(None) != {0, 1}:
            raise ValueError("both classes are required in every frozen partition")
    train, test = prepared["train"], prepared["test"]
    contamination = clip_contamination(float(y[partitions["train"]].mean()))
    result = {
        "protocol": PROTOCOL,
        "exploratory": True,
        "seed": seed,
        "partitions": {name: list(partitions[name]) for name in PARTITIONS},
        "preprocessing": prepared["fit"],
        "calibration": {"policy": "train_prevalence", "value": contamination},
        "prevalence": {name: float(y[partitions[name]].mean()) for name in PARTITIONS},
        "runs": {},
        "errors": [],
        "skipped": [],
    }
    skipped = skipped_detectors(len(train))
    for method in methods:
        if method in skipped:
            result["skipped"].append(method)
            continue
        fit = capped(train, method, seed)
        try:
            detector = build(method, contamination, seed)
            found = detect(test, detector, fit_df=fit)
            result["runs"][method] = {
                "metrics": compute_metrics(y[partitions["test"]], found.flags, found.scores),
                "scores": found.scores.tolist(),
                "flags": found.flags.tolist(),
                "fit_rows": len(fit),
            }
        except Exception as error:
            result["errors"].append({"detector": method, "error": repr(error)})
    return result


def x_evaluate_frozen__mutmut_45(
    frame: pd.DataFrame, labels, partitions: dict, *, seed: int, methods: list[str]
) -> dict:
    """Run named detectors on unchanged positions with training-only preparation."""
    if (
        not methods
        or len(set(methods)) != len(methods)
        or set(methods) - set([*DETECTOR_NAMES, *DEEP_NAMES])
    ):
        raise ValueError("detectors must be explicit, unique row-level registry names")
    if type(seed) is not int or not 0 <= seed < 2**32:
        raise ValueError("seed must be a nonnegative 32-bit integer")
    prepared = prepare_frozen(frame, partitions)
    y = np.asarray(labels)
    if y.ndim != 1 or len(y) != len(frame) or set(np.unique(y)) - {0, 1}:
        raise ValueError("labels must be an aligned binary vector")
    for name in PARTITIONS:
        if set(np.unique(None)) != {0, 1}:
            raise ValueError("both classes are required in every frozen partition")
    train, test = prepared["train"], prepared["test"]
    contamination = clip_contamination(float(y[partitions["train"]].mean()))
    result = {
        "protocol": PROTOCOL,
        "exploratory": True,
        "seed": seed,
        "partitions": {name: list(partitions[name]) for name in PARTITIONS},
        "preprocessing": prepared["fit"],
        "calibration": {"policy": "train_prevalence", "value": contamination},
        "prevalence": {name: float(y[partitions[name]].mean()) for name in PARTITIONS},
        "runs": {},
        "errors": [],
        "skipped": [],
    }
    skipped = skipped_detectors(len(train))
    for method in methods:
        if method in skipped:
            result["skipped"].append(method)
            continue
        fit = capped(train, method, seed)
        try:
            detector = build(method, contamination, seed)
            found = detect(test, detector, fit_df=fit)
            result["runs"][method] = {
                "metrics": compute_metrics(y[partitions["test"]], found.flags, found.scores),
                "scores": found.scores.tolist(),
                "flags": found.flags.tolist(),
                "fit_rows": len(fit),
            }
        except Exception as error:
            result["errors"].append({"detector": method, "error": repr(error)})
    return result


def x_evaluate_frozen__mutmut_46(
    frame: pd.DataFrame, labels, partitions: dict, *, seed: int, methods: list[str]
) -> dict:
    """Run named detectors on unchanged positions with training-only preparation."""
    if (
        not methods
        or len(set(methods)) != len(methods)
        or set(methods) - set([*DETECTOR_NAMES, *DEEP_NAMES])
    ):
        raise ValueError("detectors must be explicit, unique row-level registry names")
    if type(seed) is not int or not 0 <= seed < 2**32:
        raise ValueError("seed must be a nonnegative 32-bit integer")
    prepared = prepare_frozen(frame, partitions)
    y = np.asarray(labels)
    if y.ndim != 1 or len(y) != len(frame) or set(np.unique(y)) - {0, 1}:
        raise ValueError("labels must be an aligned binary vector")
    for name in PARTITIONS:
        if set(np.unique(y[partitions[name]])) == {0, 1}:
            raise ValueError("both classes are required in every frozen partition")
    train, test = prepared["train"], prepared["test"]
    contamination = clip_contamination(float(y[partitions["train"]].mean()))
    result = {
        "protocol": PROTOCOL,
        "exploratory": True,
        "seed": seed,
        "partitions": {name: list(partitions[name]) for name in PARTITIONS},
        "preprocessing": prepared["fit"],
        "calibration": {"policy": "train_prevalence", "value": contamination},
        "prevalence": {name: float(y[partitions[name]].mean()) for name in PARTITIONS},
        "runs": {},
        "errors": [],
        "skipped": [],
    }
    skipped = skipped_detectors(len(train))
    for method in methods:
        if method in skipped:
            result["skipped"].append(method)
            continue
        fit = capped(train, method, seed)
        try:
            detector = build(method, contamination, seed)
            found = detect(test, detector, fit_df=fit)
            result["runs"][method] = {
                "metrics": compute_metrics(y[partitions["test"]], found.flags, found.scores),
                "scores": found.scores.tolist(),
                "flags": found.flags.tolist(),
                "fit_rows": len(fit),
            }
        except Exception as error:
            result["errors"].append({"detector": method, "error": repr(error)})
    return result


def x_evaluate_frozen__mutmut_47(
    frame: pd.DataFrame, labels, partitions: dict, *, seed: int, methods: list[str]
) -> dict:
    """Run named detectors on unchanged positions with training-only preparation."""
    if (
        not methods
        or len(set(methods)) != len(methods)
        or set(methods) - set([*DETECTOR_NAMES, *DEEP_NAMES])
    ):
        raise ValueError("detectors must be explicit, unique row-level registry names")
    if type(seed) is not int or not 0 <= seed < 2**32:
        raise ValueError("seed must be a nonnegative 32-bit integer")
    prepared = prepare_frozen(frame, partitions)
    y = np.asarray(labels)
    if y.ndim != 1 or len(y) != len(frame) or set(np.unique(y)) - {0, 1}:
        raise ValueError("labels must be an aligned binary vector")
    for name in PARTITIONS:
        if set(np.unique(y[partitions[name]])) != {1, 1}:
            raise ValueError("both classes are required in every frozen partition")
    train, test = prepared["train"], prepared["test"]
    contamination = clip_contamination(float(y[partitions["train"]].mean()))
    result = {
        "protocol": PROTOCOL,
        "exploratory": True,
        "seed": seed,
        "partitions": {name: list(partitions[name]) for name in PARTITIONS},
        "preprocessing": prepared["fit"],
        "calibration": {"policy": "train_prevalence", "value": contamination},
        "prevalence": {name: float(y[partitions[name]].mean()) for name in PARTITIONS},
        "runs": {},
        "errors": [],
        "skipped": [],
    }
    skipped = skipped_detectors(len(train))
    for method in methods:
        if method in skipped:
            result["skipped"].append(method)
            continue
        fit = capped(train, method, seed)
        try:
            detector = build(method, contamination, seed)
            found = detect(test, detector, fit_df=fit)
            result["runs"][method] = {
                "metrics": compute_metrics(y[partitions["test"]], found.flags, found.scores),
                "scores": found.scores.tolist(),
                "flags": found.flags.tolist(),
                "fit_rows": len(fit),
            }
        except Exception as error:
            result["errors"].append({"detector": method, "error": repr(error)})
    return result


def x_evaluate_frozen__mutmut_48(
    frame: pd.DataFrame, labels, partitions: dict, *, seed: int, methods: list[str]
) -> dict:
    """Run named detectors on unchanged positions with training-only preparation."""
    if (
        not methods
        or len(set(methods)) != len(methods)
        or set(methods) - set([*DETECTOR_NAMES, *DEEP_NAMES])
    ):
        raise ValueError("detectors must be explicit, unique row-level registry names")
    if type(seed) is not int or not 0 <= seed < 2**32:
        raise ValueError("seed must be a nonnegative 32-bit integer")
    prepared = prepare_frozen(frame, partitions)
    y = np.asarray(labels)
    if y.ndim != 1 or len(y) != len(frame) or set(np.unique(y)) - {0, 1}:
        raise ValueError("labels must be an aligned binary vector")
    for name in PARTITIONS:
        if set(np.unique(y[partitions[name]])) != {0, 2}:
            raise ValueError("both classes are required in every frozen partition")
    train, test = prepared["train"], prepared["test"]
    contamination = clip_contamination(float(y[partitions["train"]].mean()))
    result = {
        "protocol": PROTOCOL,
        "exploratory": True,
        "seed": seed,
        "partitions": {name: list(partitions[name]) for name in PARTITIONS},
        "preprocessing": prepared["fit"],
        "calibration": {"policy": "train_prevalence", "value": contamination},
        "prevalence": {name: float(y[partitions[name]].mean()) for name in PARTITIONS},
        "runs": {},
        "errors": [],
        "skipped": [],
    }
    skipped = skipped_detectors(len(train))
    for method in methods:
        if method in skipped:
            result["skipped"].append(method)
            continue
        fit = capped(train, method, seed)
        try:
            detector = build(method, contamination, seed)
            found = detect(test, detector, fit_df=fit)
            result["runs"][method] = {
                "metrics": compute_metrics(y[partitions["test"]], found.flags, found.scores),
                "scores": found.scores.tolist(),
                "flags": found.flags.tolist(),
                "fit_rows": len(fit),
            }
        except Exception as error:
            result["errors"].append({"detector": method, "error": repr(error)})
    return result


def x_evaluate_frozen__mutmut_49(
    frame: pd.DataFrame, labels, partitions: dict, *, seed: int, methods: list[str]
) -> dict:
    """Run named detectors on unchanged positions with training-only preparation."""
    if (
        not methods
        or len(set(methods)) != len(methods)
        or set(methods) - set([*DETECTOR_NAMES, *DEEP_NAMES])
    ):
        raise ValueError("detectors must be explicit, unique row-level registry names")
    if type(seed) is not int or not 0 <= seed < 2**32:
        raise ValueError("seed must be a nonnegative 32-bit integer")
    prepared = prepare_frozen(frame, partitions)
    y = np.asarray(labels)
    if y.ndim != 1 or len(y) != len(frame) or set(np.unique(y)) - {0, 1}:
        raise ValueError("labels must be an aligned binary vector")
    for name in PARTITIONS:
        if set(np.unique(y[partitions[name]])) != {0, 1}:
            raise ValueError(None)
    train, test = prepared["train"], prepared["test"]
    contamination = clip_contamination(float(y[partitions["train"]].mean()))
    result = {
        "protocol": PROTOCOL,
        "exploratory": True,
        "seed": seed,
        "partitions": {name: list(partitions[name]) for name in PARTITIONS},
        "preprocessing": prepared["fit"],
        "calibration": {"policy": "train_prevalence", "value": contamination},
        "prevalence": {name: float(y[partitions[name]].mean()) for name in PARTITIONS},
        "runs": {},
        "errors": [],
        "skipped": [],
    }
    skipped = skipped_detectors(len(train))
    for method in methods:
        if method in skipped:
            result["skipped"].append(method)
            continue
        fit = capped(train, method, seed)
        try:
            detector = build(method, contamination, seed)
            found = detect(test, detector, fit_df=fit)
            result["runs"][method] = {
                "metrics": compute_metrics(y[partitions["test"]], found.flags, found.scores),
                "scores": found.scores.tolist(),
                "flags": found.flags.tolist(),
                "fit_rows": len(fit),
            }
        except Exception as error:
            result["errors"].append({"detector": method, "error": repr(error)})
    return result


def x_evaluate_frozen__mutmut_50(
    frame: pd.DataFrame, labels, partitions: dict, *, seed: int, methods: list[str]
) -> dict:
    """Run named detectors on unchanged positions with training-only preparation."""
    if (
        not methods
        or len(set(methods)) != len(methods)
        or set(methods) - set([*DETECTOR_NAMES, *DEEP_NAMES])
    ):
        raise ValueError("detectors must be explicit, unique row-level registry names")
    if type(seed) is not int or not 0 <= seed < 2**32:
        raise ValueError("seed must be a nonnegative 32-bit integer")
    prepared = prepare_frozen(frame, partitions)
    y = np.asarray(labels)
    if y.ndim != 1 or len(y) != len(frame) or set(np.unique(y)) - {0, 1}:
        raise ValueError("labels must be an aligned binary vector")
    for name in PARTITIONS:
        if set(np.unique(y[partitions[name]])) != {0, 1}:
            raise ValueError("XXboth classes are required in every frozen partitionXX")
    train, test = prepared["train"], prepared["test"]
    contamination = clip_contamination(float(y[partitions["train"]].mean()))
    result = {
        "protocol": PROTOCOL,
        "exploratory": True,
        "seed": seed,
        "partitions": {name: list(partitions[name]) for name in PARTITIONS},
        "preprocessing": prepared["fit"],
        "calibration": {"policy": "train_prevalence", "value": contamination},
        "prevalence": {name: float(y[partitions[name]].mean()) for name in PARTITIONS},
        "runs": {},
        "errors": [],
        "skipped": [],
    }
    skipped = skipped_detectors(len(train))
    for method in methods:
        if method in skipped:
            result["skipped"].append(method)
            continue
        fit = capped(train, method, seed)
        try:
            detector = build(method, contamination, seed)
            found = detect(test, detector, fit_df=fit)
            result["runs"][method] = {
                "metrics": compute_metrics(y[partitions["test"]], found.flags, found.scores),
                "scores": found.scores.tolist(),
                "flags": found.flags.tolist(),
                "fit_rows": len(fit),
            }
        except Exception as error:
            result["errors"].append({"detector": method, "error": repr(error)})
    return result


def x_evaluate_frozen__mutmut_51(
    frame: pd.DataFrame, labels, partitions: dict, *, seed: int, methods: list[str]
) -> dict:
    """Run named detectors on unchanged positions with training-only preparation."""
    if (
        not methods
        or len(set(methods)) != len(methods)
        or set(methods) - set([*DETECTOR_NAMES, *DEEP_NAMES])
    ):
        raise ValueError("detectors must be explicit, unique row-level registry names")
    if type(seed) is not int or not 0 <= seed < 2**32:
        raise ValueError("seed must be a nonnegative 32-bit integer")
    prepared = prepare_frozen(frame, partitions)
    y = np.asarray(labels)
    if y.ndim != 1 or len(y) != len(frame) or set(np.unique(y)) - {0, 1}:
        raise ValueError("labels must be an aligned binary vector")
    for name in PARTITIONS:
        if set(np.unique(y[partitions[name]])) != {0, 1}:
            raise ValueError("BOTH CLASSES ARE REQUIRED IN EVERY FROZEN PARTITION")
    train, test = prepared["train"], prepared["test"]
    contamination = clip_contamination(float(y[partitions["train"]].mean()))
    result = {
        "protocol": PROTOCOL,
        "exploratory": True,
        "seed": seed,
        "partitions": {name: list(partitions[name]) for name in PARTITIONS},
        "preprocessing": prepared["fit"],
        "calibration": {"policy": "train_prevalence", "value": contamination},
        "prevalence": {name: float(y[partitions[name]].mean()) for name in PARTITIONS},
        "runs": {},
        "errors": [],
        "skipped": [],
    }
    skipped = skipped_detectors(len(train))
    for method in methods:
        if method in skipped:
            result["skipped"].append(method)
            continue
        fit = capped(train, method, seed)
        try:
            detector = build(method, contamination, seed)
            found = detect(test, detector, fit_df=fit)
            result["runs"][method] = {
                "metrics": compute_metrics(y[partitions["test"]], found.flags, found.scores),
                "scores": found.scores.tolist(),
                "flags": found.flags.tolist(),
                "fit_rows": len(fit),
            }
        except Exception as error:
            result["errors"].append({"detector": method, "error": repr(error)})
    return result


def x_evaluate_frozen__mutmut_52(
    frame: pd.DataFrame, labels, partitions: dict, *, seed: int, methods: list[str]
) -> dict:
    """Run named detectors on unchanged positions with training-only preparation."""
    if (
        not methods
        or len(set(methods)) != len(methods)
        or set(methods) - set([*DETECTOR_NAMES, *DEEP_NAMES])
    ):
        raise ValueError("detectors must be explicit, unique row-level registry names")
    if type(seed) is not int or not 0 <= seed < 2**32:
        raise ValueError("seed must be a nonnegative 32-bit integer")
    prepared = prepare_frozen(frame, partitions)
    y = np.asarray(labels)
    if y.ndim != 1 or len(y) != len(frame) or set(np.unique(y)) - {0, 1}:
        raise ValueError("labels must be an aligned binary vector")
    for name in PARTITIONS:
        if set(np.unique(y[partitions[name]])) != {0, 1}:
            raise ValueError("both classes are required in every frozen partition")
    train, test = None
    contamination = clip_contamination(float(y[partitions["train"]].mean()))
    result = {
        "protocol": PROTOCOL,
        "exploratory": True,
        "seed": seed,
        "partitions": {name: list(partitions[name]) for name in PARTITIONS},
        "preprocessing": prepared["fit"],
        "calibration": {"policy": "train_prevalence", "value": contamination},
        "prevalence": {name: float(y[partitions[name]].mean()) for name in PARTITIONS},
        "runs": {},
        "errors": [],
        "skipped": [],
    }
    skipped = skipped_detectors(len(train))
    for method in methods:
        if method in skipped:
            result["skipped"].append(method)
            continue
        fit = capped(train, method, seed)
        try:
            detector = build(method, contamination, seed)
            found = detect(test, detector, fit_df=fit)
            result["runs"][method] = {
                "metrics": compute_metrics(y[partitions["test"]], found.flags, found.scores),
                "scores": found.scores.tolist(),
                "flags": found.flags.tolist(),
                "fit_rows": len(fit),
            }
        except Exception as error:
            result["errors"].append({"detector": method, "error": repr(error)})
    return result


def x_evaluate_frozen__mutmut_53(
    frame: pd.DataFrame, labels, partitions: dict, *, seed: int, methods: list[str]
) -> dict:
    """Run named detectors on unchanged positions with training-only preparation."""
    if (
        not methods
        or len(set(methods)) != len(methods)
        or set(methods) - set([*DETECTOR_NAMES, *DEEP_NAMES])
    ):
        raise ValueError("detectors must be explicit, unique row-level registry names")
    if type(seed) is not int or not 0 <= seed < 2**32:
        raise ValueError("seed must be a nonnegative 32-bit integer")
    prepared = prepare_frozen(frame, partitions)
    y = np.asarray(labels)
    if y.ndim != 1 or len(y) != len(frame) or set(np.unique(y)) - {0, 1}:
        raise ValueError("labels must be an aligned binary vector")
    for name in PARTITIONS:
        if set(np.unique(y[partitions[name]])) != {0, 1}:
            raise ValueError("both classes are required in every frozen partition")
    train, test = prepared["XXtrainXX"], prepared["test"]
    contamination = clip_contamination(float(y[partitions["train"]].mean()))
    result = {
        "protocol": PROTOCOL,
        "exploratory": True,
        "seed": seed,
        "partitions": {name: list(partitions[name]) for name in PARTITIONS},
        "preprocessing": prepared["fit"],
        "calibration": {"policy": "train_prevalence", "value": contamination},
        "prevalence": {name: float(y[partitions[name]].mean()) for name in PARTITIONS},
        "runs": {},
        "errors": [],
        "skipped": [],
    }
    skipped = skipped_detectors(len(train))
    for method in methods:
        if method in skipped:
            result["skipped"].append(method)
            continue
        fit = capped(train, method, seed)
        try:
            detector = build(method, contamination, seed)
            found = detect(test, detector, fit_df=fit)
            result["runs"][method] = {
                "metrics": compute_metrics(y[partitions["test"]], found.flags, found.scores),
                "scores": found.scores.tolist(),
                "flags": found.flags.tolist(),
                "fit_rows": len(fit),
            }
        except Exception as error:
            result["errors"].append({"detector": method, "error": repr(error)})
    return result


def x_evaluate_frozen__mutmut_54(
    frame: pd.DataFrame, labels, partitions: dict, *, seed: int, methods: list[str]
) -> dict:
    """Run named detectors on unchanged positions with training-only preparation."""
    if (
        not methods
        or len(set(methods)) != len(methods)
        or set(methods) - set([*DETECTOR_NAMES, *DEEP_NAMES])
    ):
        raise ValueError("detectors must be explicit, unique row-level registry names")
    if type(seed) is not int or not 0 <= seed < 2**32:
        raise ValueError("seed must be a nonnegative 32-bit integer")
    prepared = prepare_frozen(frame, partitions)
    y = np.asarray(labels)
    if y.ndim != 1 or len(y) != len(frame) or set(np.unique(y)) - {0, 1}:
        raise ValueError("labels must be an aligned binary vector")
    for name in PARTITIONS:
        if set(np.unique(y[partitions[name]])) != {0, 1}:
            raise ValueError("both classes are required in every frozen partition")
    train, test = prepared["TRAIN"], prepared["test"]
    contamination = clip_contamination(float(y[partitions["train"]].mean()))
    result = {
        "protocol": PROTOCOL,
        "exploratory": True,
        "seed": seed,
        "partitions": {name: list(partitions[name]) for name in PARTITIONS},
        "preprocessing": prepared["fit"],
        "calibration": {"policy": "train_prevalence", "value": contamination},
        "prevalence": {name: float(y[partitions[name]].mean()) for name in PARTITIONS},
        "runs": {},
        "errors": [],
        "skipped": [],
    }
    skipped = skipped_detectors(len(train))
    for method in methods:
        if method in skipped:
            result["skipped"].append(method)
            continue
        fit = capped(train, method, seed)
        try:
            detector = build(method, contamination, seed)
            found = detect(test, detector, fit_df=fit)
            result["runs"][method] = {
                "metrics": compute_metrics(y[partitions["test"]], found.flags, found.scores),
                "scores": found.scores.tolist(),
                "flags": found.flags.tolist(),
                "fit_rows": len(fit),
            }
        except Exception as error:
            result["errors"].append({"detector": method, "error": repr(error)})
    return result


def x_evaluate_frozen__mutmut_55(
    frame: pd.DataFrame, labels, partitions: dict, *, seed: int, methods: list[str]
) -> dict:
    """Run named detectors on unchanged positions with training-only preparation."""
    if (
        not methods
        or len(set(methods)) != len(methods)
        or set(methods) - set([*DETECTOR_NAMES, *DEEP_NAMES])
    ):
        raise ValueError("detectors must be explicit, unique row-level registry names")
    if type(seed) is not int or not 0 <= seed < 2**32:
        raise ValueError("seed must be a nonnegative 32-bit integer")
    prepared = prepare_frozen(frame, partitions)
    y = np.asarray(labels)
    if y.ndim != 1 or len(y) != len(frame) or set(np.unique(y)) - {0, 1}:
        raise ValueError("labels must be an aligned binary vector")
    for name in PARTITIONS:
        if set(np.unique(y[partitions[name]])) != {0, 1}:
            raise ValueError("both classes are required in every frozen partition")
    train, test = prepared["train"], prepared["XXtestXX"]
    contamination = clip_contamination(float(y[partitions["train"]].mean()))
    result = {
        "protocol": PROTOCOL,
        "exploratory": True,
        "seed": seed,
        "partitions": {name: list(partitions[name]) for name in PARTITIONS},
        "preprocessing": prepared["fit"],
        "calibration": {"policy": "train_prevalence", "value": contamination},
        "prevalence": {name: float(y[partitions[name]].mean()) for name in PARTITIONS},
        "runs": {},
        "errors": [],
        "skipped": [],
    }
    skipped = skipped_detectors(len(train))
    for method in methods:
        if method in skipped:
            result["skipped"].append(method)
            continue
        fit = capped(train, method, seed)
        try:
            detector = build(method, contamination, seed)
            found = detect(test, detector, fit_df=fit)
            result["runs"][method] = {
                "metrics": compute_metrics(y[partitions["test"]], found.flags, found.scores),
                "scores": found.scores.tolist(),
                "flags": found.flags.tolist(),
                "fit_rows": len(fit),
            }
        except Exception as error:
            result["errors"].append({"detector": method, "error": repr(error)})
    return result


def x_evaluate_frozen__mutmut_56(
    frame: pd.DataFrame, labels, partitions: dict, *, seed: int, methods: list[str]
) -> dict:
    """Run named detectors on unchanged positions with training-only preparation."""
    if (
        not methods
        or len(set(methods)) != len(methods)
        or set(methods) - set([*DETECTOR_NAMES, *DEEP_NAMES])
    ):
        raise ValueError("detectors must be explicit, unique row-level registry names")
    if type(seed) is not int or not 0 <= seed < 2**32:
        raise ValueError("seed must be a nonnegative 32-bit integer")
    prepared = prepare_frozen(frame, partitions)
    y = np.asarray(labels)
    if y.ndim != 1 or len(y) != len(frame) or set(np.unique(y)) - {0, 1}:
        raise ValueError("labels must be an aligned binary vector")
    for name in PARTITIONS:
        if set(np.unique(y[partitions[name]])) != {0, 1}:
            raise ValueError("both classes are required in every frozen partition")
    train, test = prepared["train"], prepared["TEST"]
    contamination = clip_contamination(float(y[partitions["train"]].mean()))
    result = {
        "protocol": PROTOCOL,
        "exploratory": True,
        "seed": seed,
        "partitions": {name: list(partitions[name]) for name in PARTITIONS},
        "preprocessing": prepared["fit"],
        "calibration": {"policy": "train_prevalence", "value": contamination},
        "prevalence": {name: float(y[partitions[name]].mean()) for name in PARTITIONS},
        "runs": {},
        "errors": [],
        "skipped": [],
    }
    skipped = skipped_detectors(len(train))
    for method in methods:
        if method in skipped:
            result["skipped"].append(method)
            continue
        fit = capped(train, method, seed)
        try:
            detector = build(method, contamination, seed)
            found = detect(test, detector, fit_df=fit)
            result["runs"][method] = {
                "metrics": compute_metrics(y[partitions["test"]], found.flags, found.scores),
                "scores": found.scores.tolist(),
                "flags": found.flags.tolist(),
                "fit_rows": len(fit),
            }
        except Exception as error:
            result["errors"].append({"detector": method, "error": repr(error)})
    return result


def x_evaluate_frozen__mutmut_57(
    frame: pd.DataFrame, labels, partitions: dict, *, seed: int, methods: list[str]
) -> dict:
    """Run named detectors on unchanged positions with training-only preparation."""
    if (
        not methods
        or len(set(methods)) != len(methods)
        or set(methods) - set([*DETECTOR_NAMES, *DEEP_NAMES])
    ):
        raise ValueError("detectors must be explicit, unique row-level registry names")
    if type(seed) is not int or not 0 <= seed < 2**32:
        raise ValueError("seed must be a nonnegative 32-bit integer")
    prepared = prepare_frozen(frame, partitions)
    y = np.asarray(labels)
    if y.ndim != 1 or len(y) != len(frame) or set(np.unique(y)) - {0, 1}:
        raise ValueError("labels must be an aligned binary vector")
    for name in PARTITIONS:
        if set(np.unique(y[partitions[name]])) != {0, 1}:
            raise ValueError("both classes are required in every frozen partition")
    train, test = prepared["train"], prepared["test"]
    contamination = None
    result = {
        "protocol": PROTOCOL,
        "exploratory": True,
        "seed": seed,
        "partitions": {name: list(partitions[name]) for name in PARTITIONS},
        "preprocessing": prepared["fit"],
        "calibration": {"policy": "train_prevalence", "value": contamination},
        "prevalence": {name: float(y[partitions[name]].mean()) for name in PARTITIONS},
        "runs": {},
        "errors": [],
        "skipped": [],
    }
    skipped = skipped_detectors(len(train))
    for method in methods:
        if method in skipped:
            result["skipped"].append(method)
            continue
        fit = capped(train, method, seed)
        try:
            detector = build(method, contamination, seed)
            found = detect(test, detector, fit_df=fit)
            result["runs"][method] = {
                "metrics": compute_metrics(y[partitions["test"]], found.flags, found.scores),
                "scores": found.scores.tolist(),
                "flags": found.flags.tolist(),
                "fit_rows": len(fit),
            }
        except Exception as error:
            result["errors"].append({"detector": method, "error": repr(error)})
    return result


def x_evaluate_frozen__mutmut_58(
    frame: pd.DataFrame, labels, partitions: dict, *, seed: int, methods: list[str]
) -> dict:
    """Run named detectors on unchanged positions with training-only preparation."""
    if (
        not methods
        or len(set(methods)) != len(methods)
        or set(methods) - set([*DETECTOR_NAMES, *DEEP_NAMES])
    ):
        raise ValueError("detectors must be explicit, unique row-level registry names")
    if type(seed) is not int or not 0 <= seed < 2**32:
        raise ValueError("seed must be a nonnegative 32-bit integer")
    prepared = prepare_frozen(frame, partitions)
    y = np.asarray(labels)
    if y.ndim != 1 or len(y) != len(frame) or set(np.unique(y)) - {0, 1}:
        raise ValueError("labels must be an aligned binary vector")
    for name in PARTITIONS:
        if set(np.unique(y[partitions[name]])) != {0, 1}:
            raise ValueError("both classes are required in every frozen partition")
    train, test = prepared["train"], prepared["test"]
    contamination = clip_contamination(None)
    result = {
        "protocol": PROTOCOL,
        "exploratory": True,
        "seed": seed,
        "partitions": {name: list(partitions[name]) for name in PARTITIONS},
        "preprocessing": prepared["fit"],
        "calibration": {"policy": "train_prevalence", "value": contamination},
        "prevalence": {name: float(y[partitions[name]].mean()) for name in PARTITIONS},
        "runs": {},
        "errors": [],
        "skipped": [],
    }
    skipped = skipped_detectors(len(train))
    for method in methods:
        if method in skipped:
            result["skipped"].append(method)
            continue
        fit = capped(train, method, seed)
        try:
            detector = build(method, contamination, seed)
            found = detect(test, detector, fit_df=fit)
            result["runs"][method] = {
                "metrics": compute_metrics(y[partitions["test"]], found.flags, found.scores),
                "scores": found.scores.tolist(),
                "flags": found.flags.tolist(),
                "fit_rows": len(fit),
            }
        except Exception as error:
            result["errors"].append({"detector": method, "error": repr(error)})
    return result


def x_evaluate_frozen__mutmut_59(
    frame: pd.DataFrame, labels, partitions: dict, *, seed: int, methods: list[str]
) -> dict:
    """Run named detectors on unchanged positions with training-only preparation."""
    if (
        not methods
        or len(set(methods)) != len(methods)
        or set(methods) - set([*DETECTOR_NAMES, *DEEP_NAMES])
    ):
        raise ValueError("detectors must be explicit, unique row-level registry names")
    if type(seed) is not int or not 0 <= seed < 2**32:
        raise ValueError("seed must be a nonnegative 32-bit integer")
    prepared = prepare_frozen(frame, partitions)
    y = np.asarray(labels)
    if y.ndim != 1 or len(y) != len(frame) or set(np.unique(y)) - {0, 1}:
        raise ValueError("labels must be an aligned binary vector")
    for name in PARTITIONS:
        if set(np.unique(y[partitions[name]])) != {0, 1}:
            raise ValueError("both classes are required in every frozen partition")
    train, test = prepared["train"], prepared["test"]
    contamination = clip_contamination(float(None))
    result = {
        "protocol": PROTOCOL,
        "exploratory": True,
        "seed": seed,
        "partitions": {name: list(partitions[name]) for name in PARTITIONS},
        "preprocessing": prepared["fit"],
        "calibration": {"policy": "train_prevalence", "value": contamination},
        "prevalence": {name: float(y[partitions[name]].mean()) for name in PARTITIONS},
        "runs": {},
        "errors": [],
        "skipped": [],
    }
    skipped = skipped_detectors(len(train))
    for method in methods:
        if method in skipped:
            result["skipped"].append(method)
            continue
        fit = capped(train, method, seed)
        try:
            detector = build(method, contamination, seed)
            found = detect(test, detector, fit_df=fit)
            result["runs"][method] = {
                "metrics": compute_metrics(y[partitions["test"]], found.flags, found.scores),
                "scores": found.scores.tolist(),
                "flags": found.flags.tolist(),
                "fit_rows": len(fit),
            }
        except Exception as error:
            result["errors"].append({"detector": method, "error": repr(error)})
    return result


def x_evaluate_frozen__mutmut_60(
    frame: pd.DataFrame, labels, partitions: dict, *, seed: int, methods: list[str]
) -> dict:
    """Run named detectors on unchanged positions with training-only preparation."""
    if (
        not methods
        or len(set(methods)) != len(methods)
        or set(methods) - set([*DETECTOR_NAMES, *DEEP_NAMES])
    ):
        raise ValueError("detectors must be explicit, unique row-level registry names")
    if type(seed) is not int or not 0 <= seed < 2**32:
        raise ValueError("seed must be a nonnegative 32-bit integer")
    prepared = prepare_frozen(frame, partitions)
    y = np.asarray(labels)
    if y.ndim != 1 or len(y) != len(frame) or set(np.unique(y)) - {0, 1}:
        raise ValueError("labels must be an aligned binary vector")
    for name in PARTITIONS:
        if set(np.unique(y[partitions[name]])) != {0, 1}:
            raise ValueError("both classes are required in every frozen partition")
    train, test = prepared["train"], prepared["test"]
    contamination = clip_contamination(float(y[partitions["XXtrainXX"]].mean()))
    result = {
        "protocol": PROTOCOL,
        "exploratory": True,
        "seed": seed,
        "partitions": {name: list(partitions[name]) for name in PARTITIONS},
        "preprocessing": prepared["fit"],
        "calibration": {"policy": "train_prevalence", "value": contamination},
        "prevalence": {name: float(y[partitions[name]].mean()) for name in PARTITIONS},
        "runs": {},
        "errors": [],
        "skipped": [],
    }
    skipped = skipped_detectors(len(train))
    for method in methods:
        if method in skipped:
            result["skipped"].append(method)
            continue
        fit = capped(train, method, seed)
        try:
            detector = build(method, contamination, seed)
            found = detect(test, detector, fit_df=fit)
            result["runs"][method] = {
                "metrics": compute_metrics(y[partitions["test"]], found.flags, found.scores),
                "scores": found.scores.tolist(),
                "flags": found.flags.tolist(),
                "fit_rows": len(fit),
            }
        except Exception as error:
            result["errors"].append({"detector": method, "error": repr(error)})
    return result


def x_evaluate_frozen__mutmut_61(
    frame: pd.DataFrame, labels, partitions: dict, *, seed: int, methods: list[str]
) -> dict:
    """Run named detectors on unchanged positions with training-only preparation."""
    if (
        not methods
        or len(set(methods)) != len(methods)
        or set(methods) - set([*DETECTOR_NAMES, *DEEP_NAMES])
    ):
        raise ValueError("detectors must be explicit, unique row-level registry names")
    if type(seed) is not int or not 0 <= seed < 2**32:
        raise ValueError("seed must be a nonnegative 32-bit integer")
    prepared = prepare_frozen(frame, partitions)
    y = np.asarray(labels)
    if y.ndim != 1 or len(y) != len(frame) or set(np.unique(y)) - {0, 1}:
        raise ValueError("labels must be an aligned binary vector")
    for name in PARTITIONS:
        if set(np.unique(y[partitions[name]])) != {0, 1}:
            raise ValueError("both classes are required in every frozen partition")
    train, test = prepared["train"], prepared["test"]
    contamination = clip_contamination(float(y[partitions["TRAIN"]].mean()))
    result = {
        "protocol": PROTOCOL,
        "exploratory": True,
        "seed": seed,
        "partitions": {name: list(partitions[name]) for name in PARTITIONS},
        "preprocessing": prepared["fit"],
        "calibration": {"policy": "train_prevalence", "value": contamination},
        "prevalence": {name: float(y[partitions[name]].mean()) for name in PARTITIONS},
        "runs": {},
        "errors": [],
        "skipped": [],
    }
    skipped = skipped_detectors(len(train))
    for method in methods:
        if method in skipped:
            result["skipped"].append(method)
            continue
        fit = capped(train, method, seed)
        try:
            detector = build(method, contamination, seed)
            found = detect(test, detector, fit_df=fit)
            result["runs"][method] = {
                "metrics": compute_metrics(y[partitions["test"]], found.flags, found.scores),
                "scores": found.scores.tolist(),
                "flags": found.flags.tolist(),
                "fit_rows": len(fit),
            }
        except Exception as error:
            result["errors"].append({"detector": method, "error": repr(error)})
    return result


def x_evaluate_frozen__mutmut_62(
    frame: pd.DataFrame, labels, partitions: dict, *, seed: int, methods: list[str]
) -> dict:
    """Run named detectors on unchanged positions with training-only preparation."""
    if (
        not methods
        or len(set(methods)) != len(methods)
        or set(methods) - set([*DETECTOR_NAMES, *DEEP_NAMES])
    ):
        raise ValueError("detectors must be explicit, unique row-level registry names")
    if type(seed) is not int or not 0 <= seed < 2**32:
        raise ValueError("seed must be a nonnegative 32-bit integer")
    prepared = prepare_frozen(frame, partitions)
    y = np.asarray(labels)
    if y.ndim != 1 or len(y) != len(frame) or set(np.unique(y)) - {0, 1}:
        raise ValueError("labels must be an aligned binary vector")
    for name in PARTITIONS:
        if set(np.unique(y[partitions[name]])) != {0, 1}:
            raise ValueError("both classes are required in every frozen partition")
    train, test = prepared["train"], prepared["test"]
    contamination = clip_contamination(float(y[partitions["train"]].mean()))
    result = None
    skipped = skipped_detectors(len(train))
    for method in methods:
        if method in skipped:
            result["skipped"].append(method)
            continue
        fit = capped(train, method, seed)
        try:
            detector = build(method, contamination, seed)
            found = detect(test, detector, fit_df=fit)
            result["runs"][method] = {
                "metrics": compute_metrics(y[partitions["test"]], found.flags, found.scores),
                "scores": found.scores.tolist(),
                "flags": found.flags.tolist(),
                "fit_rows": len(fit),
            }
        except Exception as error:
            result["errors"].append({"detector": method, "error": repr(error)})
    return result


def x_evaluate_frozen__mutmut_63(
    frame: pd.DataFrame, labels, partitions: dict, *, seed: int, methods: list[str]
) -> dict:
    """Run named detectors on unchanged positions with training-only preparation."""
    if (
        not methods
        or len(set(methods)) != len(methods)
        or set(methods) - set([*DETECTOR_NAMES, *DEEP_NAMES])
    ):
        raise ValueError("detectors must be explicit, unique row-level registry names")
    if type(seed) is not int or not 0 <= seed < 2**32:
        raise ValueError("seed must be a nonnegative 32-bit integer")
    prepared = prepare_frozen(frame, partitions)
    y = np.asarray(labels)
    if y.ndim != 1 or len(y) != len(frame) or set(np.unique(y)) - {0, 1}:
        raise ValueError("labels must be an aligned binary vector")
    for name in PARTITIONS:
        if set(np.unique(y[partitions[name]])) != {0, 1}:
            raise ValueError("both classes are required in every frozen partition")
    train, test = prepared["train"], prepared["test"]
    contamination = clip_contamination(float(y[partitions["train"]].mean()))
    result = {
        "XXprotocolXX": PROTOCOL,
        "exploratory": True,
        "seed": seed,
        "partitions": {name: list(partitions[name]) for name in PARTITIONS},
        "preprocessing": prepared["fit"],
        "calibration": {"policy": "train_prevalence", "value": contamination},
        "prevalence": {name: float(y[partitions[name]].mean()) for name in PARTITIONS},
        "runs": {},
        "errors": [],
        "skipped": [],
    }
    skipped = skipped_detectors(len(train))
    for method in methods:
        if method in skipped:
            result["skipped"].append(method)
            continue
        fit = capped(train, method, seed)
        try:
            detector = build(method, contamination, seed)
            found = detect(test, detector, fit_df=fit)
            result["runs"][method] = {
                "metrics": compute_metrics(y[partitions["test"]], found.flags, found.scores),
                "scores": found.scores.tolist(),
                "flags": found.flags.tolist(),
                "fit_rows": len(fit),
            }
        except Exception as error:
            result["errors"].append({"detector": method, "error": repr(error)})
    return result


def x_evaluate_frozen__mutmut_64(
    frame: pd.DataFrame, labels, partitions: dict, *, seed: int, methods: list[str]
) -> dict:
    """Run named detectors on unchanged positions with training-only preparation."""
    if (
        not methods
        or len(set(methods)) != len(methods)
        or set(methods) - set([*DETECTOR_NAMES, *DEEP_NAMES])
    ):
        raise ValueError("detectors must be explicit, unique row-level registry names")
    if type(seed) is not int or not 0 <= seed < 2**32:
        raise ValueError("seed must be a nonnegative 32-bit integer")
    prepared = prepare_frozen(frame, partitions)
    y = np.asarray(labels)
    if y.ndim != 1 or len(y) != len(frame) or set(np.unique(y)) - {0, 1}:
        raise ValueError("labels must be an aligned binary vector")
    for name in PARTITIONS:
        if set(np.unique(y[partitions[name]])) != {0, 1}:
            raise ValueError("both classes are required in every frozen partition")
    train, test = prepared["train"], prepared["test"]
    contamination = clip_contamination(float(y[partitions["train"]].mean()))
    result = {
        "PROTOCOL": PROTOCOL,
        "exploratory": True,
        "seed": seed,
        "partitions": {name: list(partitions[name]) for name in PARTITIONS},
        "preprocessing": prepared["fit"],
        "calibration": {"policy": "train_prevalence", "value": contamination},
        "prevalence": {name: float(y[partitions[name]].mean()) for name in PARTITIONS},
        "runs": {},
        "errors": [],
        "skipped": [],
    }
    skipped = skipped_detectors(len(train))
    for method in methods:
        if method in skipped:
            result["skipped"].append(method)
            continue
        fit = capped(train, method, seed)
        try:
            detector = build(method, contamination, seed)
            found = detect(test, detector, fit_df=fit)
            result["runs"][method] = {
                "metrics": compute_metrics(y[partitions["test"]], found.flags, found.scores),
                "scores": found.scores.tolist(),
                "flags": found.flags.tolist(),
                "fit_rows": len(fit),
            }
        except Exception as error:
            result["errors"].append({"detector": method, "error": repr(error)})
    return result


def x_evaluate_frozen__mutmut_65(
    frame: pd.DataFrame, labels, partitions: dict, *, seed: int, methods: list[str]
) -> dict:
    """Run named detectors on unchanged positions with training-only preparation."""
    if (
        not methods
        or len(set(methods)) != len(methods)
        or set(methods) - set([*DETECTOR_NAMES, *DEEP_NAMES])
    ):
        raise ValueError("detectors must be explicit, unique row-level registry names")
    if type(seed) is not int or not 0 <= seed < 2**32:
        raise ValueError("seed must be a nonnegative 32-bit integer")
    prepared = prepare_frozen(frame, partitions)
    y = np.asarray(labels)
    if y.ndim != 1 or len(y) != len(frame) or set(np.unique(y)) - {0, 1}:
        raise ValueError("labels must be an aligned binary vector")
    for name in PARTITIONS:
        if set(np.unique(y[partitions[name]])) != {0, 1}:
            raise ValueError("both classes are required in every frozen partition")
    train, test = prepared["train"], prepared["test"]
    contamination = clip_contamination(float(y[partitions["train"]].mean()))
    result = {
        "protocol": PROTOCOL,
        "XXexploratoryXX": True,
        "seed": seed,
        "partitions": {name: list(partitions[name]) for name in PARTITIONS},
        "preprocessing": prepared["fit"],
        "calibration": {"policy": "train_prevalence", "value": contamination},
        "prevalence": {name: float(y[partitions[name]].mean()) for name in PARTITIONS},
        "runs": {},
        "errors": [],
        "skipped": [],
    }
    skipped = skipped_detectors(len(train))
    for method in methods:
        if method in skipped:
            result["skipped"].append(method)
            continue
        fit = capped(train, method, seed)
        try:
            detector = build(method, contamination, seed)
            found = detect(test, detector, fit_df=fit)
            result["runs"][method] = {
                "metrics": compute_metrics(y[partitions["test"]], found.flags, found.scores),
                "scores": found.scores.tolist(),
                "flags": found.flags.tolist(),
                "fit_rows": len(fit),
            }
        except Exception as error:
            result["errors"].append({"detector": method, "error": repr(error)})
    return result


def x_evaluate_frozen__mutmut_66(
    frame: pd.DataFrame, labels, partitions: dict, *, seed: int, methods: list[str]
) -> dict:
    """Run named detectors on unchanged positions with training-only preparation."""
    if (
        not methods
        or len(set(methods)) != len(methods)
        or set(methods) - set([*DETECTOR_NAMES, *DEEP_NAMES])
    ):
        raise ValueError("detectors must be explicit, unique row-level registry names")
    if type(seed) is not int or not 0 <= seed < 2**32:
        raise ValueError("seed must be a nonnegative 32-bit integer")
    prepared = prepare_frozen(frame, partitions)
    y = np.asarray(labels)
    if y.ndim != 1 or len(y) != len(frame) or set(np.unique(y)) - {0, 1}:
        raise ValueError("labels must be an aligned binary vector")
    for name in PARTITIONS:
        if set(np.unique(y[partitions[name]])) != {0, 1}:
            raise ValueError("both classes are required in every frozen partition")
    train, test = prepared["train"], prepared["test"]
    contamination = clip_contamination(float(y[partitions["train"]].mean()))
    result = {
        "protocol": PROTOCOL,
        "EXPLORATORY": True,
        "seed": seed,
        "partitions": {name: list(partitions[name]) for name in PARTITIONS},
        "preprocessing": prepared["fit"],
        "calibration": {"policy": "train_prevalence", "value": contamination},
        "prevalence": {name: float(y[partitions[name]].mean()) for name in PARTITIONS},
        "runs": {},
        "errors": [],
        "skipped": [],
    }
    skipped = skipped_detectors(len(train))
    for method in methods:
        if method in skipped:
            result["skipped"].append(method)
            continue
        fit = capped(train, method, seed)
        try:
            detector = build(method, contamination, seed)
            found = detect(test, detector, fit_df=fit)
            result["runs"][method] = {
                "metrics": compute_metrics(y[partitions["test"]], found.flags, found.scores),
                "scores": found.scores.tolist(),
                "flags": found.flags.tolist(),
                "fit_rows": len(fit),
            }
        except Exception as error:
            result["errors"].append({"detector": method, "error": repr(error)})
    return result


def x_evaluate_frozen__mutmut_67(
    frame: pd.DataFrame, labels, partitions: dict, *, seed: int, methods: list[str]
) -> dict:
    """Run named detectors on unchanged positions with training-only preparation."""
    if (
        not methods
        or len(set(methods)) != len(methods)
        or set(methods) - set([*DETECTOR_NAMES, *DEEP_NAMES])
    ):
        raise ValueError("detectors must be explicit, unique row-level registry names")
    if type(seed) is not int or not 0 <= seed < 2**32:
        raise ValueError("seed must be a nonnegative 32-bit integer")
    prepared = prepare_frozen(frame, partitions)
    y = np.asarray(labels)
    if y.ndim != 1 or len(y) != len(frame) or set(np.unique(y)) - {0, 1}:
        raise ValueError("labels must be an aligned binary vector")
    for name in PARTITIONS:
        if set(np.unique(y[partitions[name]])) != {0, 1}:
            raise ValueError("both classes are required in every frozen partition")
    train, test = prepared["train"], prepared["test"]
    contamination = clip_contamination(float(y[partitions["train"]].mean()))
    result = {
        "protocol": PROTOCOL,
        "exploratory": False,
        "seed": seed,
        "partitions": {name: list(partitions[name]) for name in PARTITIONS},
        "preprocessing": prepared["fit"],
        "calibration": {"policy": "train_prevalence", "value": contamination},
        "prevalence": {name: float(y[partitions[name]].mean()) for name in PARTITIONS},
        "runs": {},
        "errors": [],
        "skipped": [],
    }
    skipped = skipped_detectors(len(train))
    for method in methods:
        if method in skipped:
            result["skipped"].append(method)
            continue
        fit = capped(train, method, seed)
        try:
            detector = build(method, contamination, seed)
            found = detect(test, detector, fit_df=fit)
            result["runs"][method] = {
                "metrics": compute_metrics(y[partitions["test"]], found.flags, found.scores),
                "scores": found.scores.tolist(),
                "flags": found.flags.tolist(),
                "fit_rows": len(fit),
            }
        except Exception as error:
            result["errors"].append({"detector": method, "error": repr(error)})
    return result


def x_evaluate_frozen__mutmut_68(
    frame: pd.DataFrame, labels, partitions: dict, *, seed: int, methods: list[str]
) -> dict:
    """Run named detectors on unchanged positions with training-only preparation."""
    if (
        not methods
        or len(set(methods)) != len(methods)
        or set(methods) - set([*DETECTOR_NAMES, *DEEP_NAMES])
    ):
        raise ValueError("detectors must be explicit, unique row-level registry names")
    if type(seed) is not int or not 0 <= seed < 2**32:
        raise ValueError("seed must be a nonnegative 32-bit integer")
    prepared = prepare_frozen(frame, partitions)
    y = np.asarray(labels)
    if y.ndim != 1 or len(y) != len(frame) or set(np.unique(y)) - {0, 1}:
        raise ValueError("labels must be an aligned binary vector")
    for name in PARTITIONS:
        if set(np.unique(y[partitions[name]])) != {0, 1}:
            raise ValueError("both classes are required in every frozen partition")
    train, test = prepared["train"], prepared["test"]
    contamination = clip_contamination(float(y[partitions["train"]].mean()))
    result = {
        "protocol": PROTOCOL,
        "exploratory": True,
        "XXseedXX": seed,
        "partitions": {name: list(partitions[name]) for name in PARTITIONS},
        "preprocessing": prepared["fit"],
        "calibration": {"policy": "train_prevalence", "value": contamination},
        "prevalence": {name: float(y[partitions[name]].mean()) for name in PARTITIONS},
        "runs": {},
        "errors": [],
        "skipped": [],
    }
    skipped = skipped_detectors(len(train))
    for method in methods:
        if method in skipped:
            result["skipped"].append(method)
            continue
        fit = capped(train, method, seed)
        try:
            detector = build(method, contamination, seed)
            found = detect(test, detector, fit_df=fit)
            result["runs"][method] = {
                "metrics": compute_metrics(y[partitions["test"]], found.flags, found.scores),
                "scores": found.scores.tolist(),
                "flags": found.flags.tolist(),
                "fit_rows": len(fit),
            }
        except Exception as error:
            result["errors"].append({"detector": method, "error": repr(error)})
    return result


def x_evaluate_frozen__mutmut_69(
    frame: pd.DataFrame, labels, partitions: dict, *, seed: int, methods: list[str]
) -> dict:
    """Run named detectors on unchanged positions with training-only preparation."""
    if (
        not methods
        or len(set(methods)) != len(methods)
        or set(methods) - set([*DETECTOR_NAMES, *DEEP_NAMES])
    ):
        raise ValueError("detectors must be explicit, unique row-level registry names")
    if type(seed) is not int or not 0 <= seed < 2**32:
        raise ValueError("seed must be a nonnegative 32-bit integer")
    prepared = prepare_frozen(frame, partitions)
    y = np.asarray(labels)
    if y.ndim != 1 or len(y) != len(frame) or set(np.unique(y)) - {0, 1}:
        raise ValueError("labels must be an aligned binary vector")
    for name in PARTITIONS:
        if set(np.unique(y[partitions[name]])) != {0, 1}:
            raise ValueError("both classes are required in every frozen partition")
    train, test = prepared["train"], prepared["test"]
    contamination = clip_contamination(float(y[partitions["train"]].mean()))
    result = {
        "protocol": PROTOCOL,
        "exploratory": True,
        "SEED": seed,
        "partitions": {name: list(partitions[name]) for name in PARTITIONS},
        "preprocessing": prepared["fit"],
        "calibration": {"policy": "train_prevalence", "value": contamination},
        "prevalence": {name: float(y[partitions[name]].mean()) for name in PARTITIONS},
        "runs": {},
        "errors": [],
        "skipped": [],
    }
    skipped = skipped_detectors(len(train))
    for method in methods:
        if method in skipped:
            result["skipped"].append(method)
            continue
        fit = capped(train, method, seed)
        try:
            detector = build(method, contamination, seed)
            found = detect(test, detector, fit_df=fit)
            result["runs"][method] = {
                "metrics": compute_metrics(y[partitions["test"]], found.flags, found.scores),
                "scores": found.scores.tolist(),
                "flags": found.flags.tolist(),
                "fit_rows": len(fit),
            }
        except Exception as error:
            result["errors"].append({"detector": method, "error": repr(error)})
    return result


def x_evaluate_frozen__mutmut_70(
    frame: pd.DataFrame, labels, partitions: dict, *, seed: int, methods: list[str]
) -> dict:
    """Run named detectors on unchanged positions with training-only preparation."""
    if (
        not methods
        or len(set(methods)) != len(methods)
        or set(methods) - set([*DETECTOR_NAMES, *DEEP_NAMES])
    ):
        raise ValueError("detectors must be explicit, unique row-level registry names")
    if type(seed) is not int or not 0 <= seed < 2**32:
        raise ValueError("seed must be a nonnegative 32-bit integer")
    prepared = prepare_frozen(frame, partitions)
    y = np.asarray(labels)
    if y.ndim != 1 or len(y) != len(frame) or set(np.unique(y)) - {0, 1}:
        raise ValueError("labels must be an aligned binary vector")
    for name in PARTITIONS:
        if set(np.unique(y[partitions[name]])) != {0, 1}:
            raise ValueError("both classes are required in every frozen partition")
    train, test = prepared["train"], prepared["test"]
    contamination = clip_contamination(float(y[partitions["train"]].mean()))
    result = {
        "protocol": PROTOCOL,
        "exploratory": True,
        "seed": seed,
        "XXpartitionsXX": {name: list(partitions[name]) for name in PARTITIONS},
        "preprocessing": prepared["fit"],
        "calibration": {"policy": "train_prevalence", "value": contamination},
        "prevalence": {name: float(y[partitions[name]].mean()) for name in PARTITIONS},
        "runs": {},
        "errors": [],
        "skipped": [],
    }
    skipped = skipped_detectors(len(train))
    for method in methods:
        if method in skipped:
            result["skipped"].append(method)
            continue
        fit = capped(train, method, seed)
        try:
            detector = build(method, contamination, seed)
            found = detect(test, detector, fit_df=fit)
            result["runs"][method] = {
                "metrics": compute_metrics(y[partitions["test"]], found.flags, found.scores),
                "scores": found.scores.tolist(),
                "flags": found.flags.tolist(),
                "fit_rows": len(fit),
            }
        except Exception as error:
            result["errors"].append({"detector": method, "error": repr(error)})
    return result


def x_evaluate_frozen__mutmut_71(
    frame: pd.DataFrame, labels, partitions: dict, *, seed: int, methods: list[str]
) -> dict:
    """Run named detectors on unchanged positions with training-only preparation."""
    if (
        not methods
        or len(set(methods)) != len(methods)
        or set(methods) - set([*DETECTOR_NAMES, *DEEP_NAMES])
    ):
        raise ValueError("detectors must be explicit, unique row-level registry names")
    if type(seed) is not int or not 0 <= seed < 2**32:
        raise ValueError("seed must be a nonnegative 32-bit integer")
    prepared = prepare_frozen(frame, partitions)
    y = np.asarray(labels)
    if y.ndim != 1 or len(y) != len(frame) or set(np.unique(y)) - {0, 1}:
        raise ValueError("labels must be an aligned binary vector")
    for name in PARTITIONS:
        if set(np.unique(y[partitions[name]])) != {0, 1}:
            raise ValueError("both classes are required in every frozen partition")
    train, test = prepared["train"], prepared["test"]
    contamination = clip_contamination(float(y[partitions["train"]].mean()))
    result = {
        "protocol": PROTOCOL,
        "exploratory": True,
        "seed": seed,
        "PARTITIONS": {name: list(partitions[name]) for name in PARTITIONS},
        "preprocessing": prepared["fit"],
        "calibration": {"policy": "train_prevalence", "value": contamination},
        "prevalence": {name: float(y[partitions[name]].mean()) for name in PARTITIONS},
        "runs": {},
        "errors": [],
        "skipped": [],
    }
    skipped = skipped_detectors(len(train))
    for method in methods:
        if method in skipped:
            result["skipped"].append(method)
            continue
        fit = capped(train, method, seed)
        try:
            detector = build(method, contamination, seed)
            found = detect(test, detector, fit_df=fit)
            result["runs"][method] = {
                "metrics": compute_metrics(y[partitions["test"]], found.flags, found.scores),
                "scores": found.scores.tolist(),
                "flags": found.flags.tolist(),
                "fit_rows": len(fit),
            }
        except Exception as error:
            result["errors"].append({"detector": method, "error": repr(error)})
    return result


def x_evaluate_frozen__mutmut_72(
    frame: pd.DataFrame, labels, partitions: dict, *, seed: int, methods: list[str]
) -> dict:
    """Run named detectors on unchanged positions with training-only preparation."""
    if (
        not methods
        or len(set(methods)) != len(methods)
        or set(methods) - set([*DETECTOR_NAMES, *DEEP_NAMES])
    ):
        raise ValueError("detectors must be explicit, unique row-level registry names")
    if type(seed) is not int or not 0 <= seed < 2**32:
        raise ValueError("seed must be a nonnegative 32-bit integer")
    prepared = prepare_frozen(frame, partitions)
    y = np.asarray(labels)
    if y.ndim != 1 or len(y) != len(frame) or set(np.unique(y)) - {0, 1}:
        raise ValueError("labels must be an aligned binary vector")
    for name in PARTITIONS:
        if set(np.unique(y[partitions[name]])) != {0, 1}:
            raise ValueError("both classes are required in every frozen partition")
    train, test = prepared["train"], prepared["test"]
    contamination = clip_contamination(float(y[partitions["train"]].mean()))
    result = {
        "protocol": PROTOCOL,
        "exploratory": True,
        "seed": seed,
        "partitions": {name: list(None) for name in PARTITIONS},
        "preprocessing": prepared["fit"],
        "calibration": {"policy": "train_prevalence", "value": contamination},
        "prevalence": {name: float(y[partitions[name]].mean()) for name in PARTITIONS},
        "runs": {},
        "errors": [],
        "skipped": [],
    }
    skipped = skipped_detectors(len(train))
    for method in methods:
        if method in skipped:
            result["skipped"].append(method)
            continue
        fit = capped(train, method, seed)
        try:
            detector = build(method, contamination, seed)
            found = detect(test, detector, fit_df=fit)
            result["runs"][method] = {
                "metrics": compute_metrics(y[partitions["test"]], found.flags, found.scores),
                "scores": found.scores.tolist(),
                "flags": found.flags.tolist(),
                "fit_rows": len(fit),
            }
        except Exception as error:
            result["errors"].append({"detector": method, "error": repr(error)})
    return result


def x_evaluate_frozen__mutmut_73(
    frame: pd.DataFrame, labels, partitions: dict, *, seed: int, methods: list[str]
) -> dict:
    """Run named detectors on unchanged positions with training-only preparation."""
    if (
        not methods
        or len(set(methods)) != len(methods)
        or set(methods) - set([*DETECTOR_NAMES, *DEEP_NAMES])
    ):
        raise ValueError("detectors must be explicit, unique row-level registry names")
    if type(seed) is not int or not 0 <= seed < 2**32:
        raise ValueError("seed must be a nonnegative 32-bit integer")
    prepared = prepare_frozen(frame, partitions)
    y = np.asarray(labels)
    if y.ndim != 1 or len(y) != len(frame) or set(np.unique(y)) - {0, 1}:
        raise ValueError("labels must be an aligned binary vector")
    for name in PARTITIONS:
        if set(np.unique(y[partitions[name]])) != {0, 1}:
            raise ValueError("both classes are required in every frozen partition")
    train, test = prepared["train"], prepared["test"]
    contamination = clip_contamination(float(y[partitions["train"]].mean()))
    result = {
        "protocol": PROTOCOL,
        "exploratory": True,
        "seed": seed,
        "partitions": {name: list(partitions[name]) for name in PARTITIONS},
        "XXpreprocessingXX": prepared["fit"],
        "calibration": {"policy": "train_prevalence", "value": contamination},
        "prevalence": {name: float(y[partitions[name]].mean()) for name in PARTITIONS},
        "runs": {},
        "errors": [],
        "skipped": [],
    }
    skipped = skipped_detectors(len(train))
    for method in methods:
        if method in skipped:
            result["skipped"].append(method)
            continue
        fit = capped(train, method, seed)
        try:
            detector = build(method, contamination, seed)
            found = detect(test, detector, fit_df=fit)
            result["runs"][method] = {
                "metrics": compute_metrics(y[partitions["test"]], found.flags, found.scores),
                "scores": found.scores.tolist(),
                "flags": found.flags.tolist(),
                "fit_rows": len(fit),
            }
        except Exception as error:
            result["errors"].append({"detector": method, "error": repr(error)})
    return result


def x_evaluate_frozen__mutmut_74(
    frame: pd.DataFrame, labels, partitions: dict, *, seed: int, methods: list[str]
) -> dict:
    """Run named detectors on unchanged positions with training-only preparation."""
    if (
        not methods
        or len(set(methods)) != len(methods)
        or set(methods) - set([*DETECTOR_NAMES, *DEEP_NAMES])
    ):
        raise ValueError("detectors must be explicit, unique row-level registry names")
    if type(seed) is not int or not 0 <= seed < 2**32:
        raise ValueError("seed must be a nonnegative 32-bit integer")
    prepared = prepare_frozen(frame, partitions)
    y = np.asarray(labels)
    if y.ndim != 1 or len(y) != len(frame) or set(np.unique(y)) - {0, 1}:
        raise ValueError("labels must be an aligned binary vector")
    for name in PARTITIONS:
        if set(np.unique(y[partitions[name]])) != {0, 1}:
            raise ValueError("both classes are required in every frozen partition")
    train, test = prepared["train"], prepared["test"]
    contamination = clip_contamination(float(y[partitions["train"]].mean()))
    result = {
        "protocol": PROTOCOL,
        "exploratory": True,
        "seed": seed,
        "partitions": {name: list(partitions[name]) for name in PARTITIONS},
        "PREPROCESSING": prepared["fit"],
        "calibration": {"policy": "train_prevalence", "value": contamination},
        "prevalence": {name: float(y[partitions[name]].mean()) for name in PARTITIONS},
        "runs": {},
        "errors": [],
        "skipped": [],
    }
    skipped = skipped_detectors(len(train))
    for method in methods:
        if method in skipped:
            result["skipped"].append(method)
            continue
        fit = capped(train, method, seed)
        try:
            detector = build(method, contamination, seed)
            found = detect(test, detector, fit_df=fit)
            result["runs"][method] = {
                "metrics": compute_metrics(y[partitions["test"]], found.flags, found.scores),
                "scores": found.scores.tolist(),
                "flags": found.flags.tolist(),
                "fit_rows": len(fit),
            }
        except Exception as error:
            result["errors"].append({"detector": method, "error": repr(error)})
    return result


def x_evaluate_frozen__mutmut_75(
    frame: pd.DataFrame, labels, partitions: dict, *, seed: int, methods: list[str]
) -> dict:
    """Run named detectors on unchanged positions with training-only preparation."""
    if (
        not methods
        or len(set(methods)) != len(methods)
        or set(methods) - set([*DETECTOR_NAMES, *DEEP_NAMES])
    ):
        raise ValueError("detectors must be explicit, unique row-level registry names")
    if type(seed) is not int or not 0 <= seed < 2**32:
        raise ValueError("seed must be a nonnegative 32-bit integer")
    prepared = prepare_frozen(frame, partitions)
    y = np.asarray(labels)
    if y.ndim != 1 or len(y) != len(frame) or set(np.unique(y)) - {0, 1}:
        raise ValueError("labels must be an aligned binary vector")
    for name in PARTITIONS:
        if set(np.unique(y[partitions[name]])) != {0, 1}:
            raise ValueError("both classes are required in every frozen partition")
    train, test = prepared["train"], prepared["test"]
    contamination = clip_contamination(float(y[partitions["train"]].mean()))
    result = {
        "protocol": PROTOCOL,
        "exploratory": True,
        "seed": seed,
        "partitions": {name: list(partitions[name]) for name in PARTITIONS},
        "preprocessing": prepared["XXfitXX"],
        "calibration": {"policy": "train_prevalence", "value": contamination},
        "prevalence": {name: float(y[partitions[name]].mean()) for name in PARTITIONS},
        "runs": {},
        "errors": [],
        "skipped": [],
    }
    skipped = skipped_detectors(len(train))
    for method in methods:
        if method in skipped:
            result["skipped"].append(method)
            continue
        fit = capped(train, method, seed)
        try:
            detector = build(method, contamination, seed)
            found = detect(test, detector, fit_df=fit)
            result["runs"][method] = {
                "metrics": compute_metrics(y[partitions["test"]], found.flags, found.scores),
                "scores": found.scores.tolist(),
                "flags": found.flags.tolist(),
                "fit_rows": len(fit),
            }
        except Exception as error:
            result["errors"].append({"detector": method, "error": repr(error)})
    return result


def x_evaluate_frozen__mutmut_76(
    frame: pd.DataFrame, labels, partitions: dict, *, seed: int, methods: list[str]
) -> dict:
    """Run named detectors on unchanged positions with training-only preparation."""
    if (
        not methods
        or len(set(methods)) != len(methods)
        or set(methods) - set([*DETECTOR_NAMES, *DEEP_NAMES])
    ):
        raise ValueError("detectors must be explicit, unique row-level registry names")
    if type(seed) is not int or not 0 <= seed < 2**32:
        raise ValueError("seed must be a nonnegative 32-bit integer")
    prepared = prepare_frozen(frame, partitions)
    y = np.asarray(labels)
    if y.ndim != 1 or len(y) != len(frame) or set(np.unique(y)) - {0, 1}:
        raise ValueError("labels must be an aligned binary vector")
    for name in PARTITIONS:
        if set(np.unique(y[partitions[name]])) != {0, 1}:
            raise ValueError("both classes are required in every frozen partition")
    train, test = prepared["train"], prepared["test"]
    contamination = clip_contamination(float(y[partitions["train"]].mean()))
    result = {
        "protocol": PROTOCOL,
        "exploratory": True,
        "seed": seed,
        "partitions": {name: list(partitions[name]) for name in PARTITIONS},
        "preprocessing": prepared["FIT"],
        "calibration": {"policy": "train_prevalence", "value": contamination},
        "prevalence": {name: float(y[partitions[name]].mean()) for name in PARTITIONS},
        "runs": {},
        "errors": [],
        "skipped": [],
    }
    skipped = skipped_detectors(len(train))
    for method in methods:
        if method in skipped:
            result["skipped"].append(method)
            continue
        fit = capped(train, method, seed)
        try:
            detector = build(method, contamination, seed)
            found = detect(test, detector, fit_df=fit)
            result["runs"][method] = {
                "metrics": compute_metrics(y[partitions["test"]], found.flags, found.scores),
                "scores": found.scores.tolist(),
                "flags": found.flags.tolist(),
                "fit_rows": len(fit),
            }
        except Exception as error:
            result["errors"].append({"detector": method, "error": repr(error)})
    return result


def x_evaluate_frozen__mutmut_77(
    frame: pd.DataFrame, labels, partitions: dict, *, seed: int, methods: list[str]
) -> dict:
    """Run named detectors on unchanged positions with training-only preparation."""
    if (
        not methods
        or len(set(methods)) != len(methods)
        or set(methods) - set([*DETECTOR_NAMES, *DEEP_NAMES])
    ):
        raise ValueError("detectors must be explicit, unique row-level registry names")
    if type(seed) is not int or not 0 <= seed < 2**32:
        raise ValueError("seed must be a nonnegative 32-bit integer")
    prepared = prepare_frozen(frame, partitions)
    y = np.asarray(labels)
    if y.ndim != 1 or len(y) != len(frame) or set(np.unique(y)) - {0, 1}:
        raise ValueError("labels must be an aligned binary vector")
    for name in PARTITIONS:
        if set(np.unique(y[partitions[name]])) != {0, 1}:
            raise ValueError("both classes are required in every frozen partition")
    train, test = prepared["train"], prepared["test"]
    contamination = clip_contamination(float(y[partitions["train"]].mean()))
    result = {
        "protocol": PROTOCOL,
        "exploratory": True,
        "seed": seed,
        "partitions": {name: list(partitions[name]) for name in PARTITIONS},
        "preprocessing": prepared["fit"],
        "XXcalibrationXX": {"policy": "train_prevalence", "value": contamination},
        "prevalence": {name: float(y[partitions[name]].mean()) for name in PARTITIONS},
        "runs": {},
        "errors": [],
        "skipped": [],
    }
    skipped = skipped_detectors(len(train))
    for method in methods:
        if method in skipped:
            result["skipped"].append(method)
            continue
        fit = capped(train, method, seed)
        try:
            detector = build(method, contamination, seed)
            found = detect(test, detector, fit_df=fit)
            result["runs"][method] = {
                "metrics": compute_metrics(y[partitions["test"]], found.flags, found.scores),
                "scores": found.scores.tolist(),
                "flags": found.flags.tolist(),
                "fit_rows": len(fit),
            }
        except Exception as error:
            result["errors"].append({"detector": method, "error": repr(error)})
    return result


def x_evaluate_frozen__mutmut_78(
    frame: pd.DataFrame, labels, partitions: dict, *, seed: int, methods: list[str]
) -> dict:
    """Run named detectors on unchanged positions with training-only preparation."""
    if (
        not methods
        or len(set(methods)) != len(methods)
        or set(methods) - set([*DETECTOR_NAMES, *DEEP_NAMES])
    ):
        raise ValueError("detectors must be explicit, unique row-level registry names")
    if type(seed) is not int or not 0 <= seed < 2**32:
        raise ValueError("seed must be a nonnegative 32-bit integer")
    prepared = prepare_frozen(frame, partitions)
    y = np.asarray(labels)
    if y.ndim != 1 or len(y) != len(frame) or set(np.unique(y)) - {0, 1}:
        raise ValueError("labels must be an aligned binary vector")
    for name in PARTITIONS:
        if set(np.unique(y[partitions[name]])) != {0, 1}:
            raise ValueError("both classes are required in every frozen partition")
    train, test = prepared["train"], prepared["test"]
    contamination = clip_contamination(float(y[partitions["train"]].mean()))
    result = {
        "protocol": PROTOCOL,
        "exploratory": True,
        "seed": seed,
        "partitions": {name: list(partitions[name]) for name in PARTITIONS},
        "preprocessing": prepared["fit"],
        "CALIBRATION": {"policy": "train_prevalence", "value": contamination},
        "prevalence": {name: float(y[partitions[name]].mean()) for name in PARTITIONS},
        "runs": {},
        "errors": [],
        "skipped": [],
    }
    skipped = skipped_detectors(len(train))
    for method in methods:
        if method in skipped:
            result["skipped"].append(method)
            continue
        fit = capped(train, method, seed)
        try:
            detector = build(method, contamination, seed)
            found = detect(test, detector, fit_df=fit)
            result["runs"][method] = {
                "metrics": compute_metrics(y[partitions["test"]], found.flags, found.scores),
                "scores": found.scores.tolist(),
                "flags": found.flags.tolist(),
                "fit_rows": len(fit),
            }
        except Exception as error:
            result["errors"].append({"detector": method, "error": repr(error)})
    return result


def x_evaluate_frozen__mutmut_79(
    frame: pd.DataFrame, labels, partitions: dict, *, seed: int, methods: list[str]
) -> dict:
    """Run named detectors on unchanged positions with training-only preparation."""
    if (
        not methods
        or len(set(methods)) != len(methods)
        or set(methods) - set([*DETECTOR_NAMES, *DEEP_NAMES])
    ):
        raise ValueError("detectors must be explicit, unique row-level registry names")
    if type(seed) is not int or not 0 <= seed < 2**32:
        raise ValueError("seed must be a nonnegative 32-bit integer")
    prepared = prepare_frozen(frame, partitions)
    y = np.asarray(labels)
    if y.ndim != 1 or len(y) != len(frame) or set(np.unique(y)) - {0, 1}:
        raise ValueError("labels must be an aligned binary vector")
    for name in PARTITIONS:
        if set(np.unique(y[partitions[name]])) != {0, 1}:
            raise ValueError("both classes are required in every frozen partition")
    train, test = prepared["train"], prepared["test"]
    contamination = clip_contamination(float(y[partitions["train"]].mean()))
    result = {
        "protocol": PROTOCOL,
        "exploratory": True,
        "seed": seed,
        "partitions": {name: list(partitions[name]) for name in PARTITIONS},
        "preprocessing": prepared["fit"],
        "calibration": {"XXpolicyXX": "train_prevalence", "value": contamination},
        "prevalence": {name: float(y[partitions[name]].mean()) for name in PARTITIONS},
        "runs": {},
        "errors": [],
        "skipped": [],
    }
    skipped = skipped_detectors(len(train))
    for method in methods:
        if method in skipped:
            result["skipped"].append(method)
            continue
        fit = capped(train, method, seed)
        try:
            detector = build(method, contamination, seed)
            found = detect(test, detector, fit_df=fit)
            result["runs"][method] = {
                "metrics": compute_metrics(y[partitions["test"]], found.flags, found.scores),
                "scores": found.scores.tolist(),
                "flags": found.flags.tolist(),
                "fit_rows": len(fit),
            }
        except Exception as error:
            result["errors"].append({"detector": method, "error": repr(error)})
    return result


def x_evaluate_frozen__mutmut_80(
    frame: pd.DataFrame, labels, partitions: dict, *, seed: int, methods: list[str]
) -> dict:
    """Run named detectors on unchanged positions with training-only preparation."""
    if (
        not methods
        or len(set(methods)) != len(methods)
        or set(methods) - set([*DETECTOR_NAMES, *DEEP_NAMES])
    ):
        raise ValueError("detectors must be explicit, unique row-level registry names")
    if type(seed) is not int or not 0 <= seed < 2**32:
        raise ValueError("seed must be a nonnegative 32-bit integer")
    prepared = prepare_frozen(frame, partitions)
    y = np.asarray(labels)
    if y.ndim != 1 or len(y) != len(frame) or set(np.unique(y)) - {0, 1}:
        raise ValueError("labels must be an aligned binary vector")
    for name in PARTITIONS:
        if set(np.unique(y[partitions[name]])) != {0, 1}:
            raise ValueError("both classes are required in every frozen partition")
    train, test = prepared["train"], prepared["test"]
    contamination = clip_contamination(float(y[partitions["train"]].mean()))
    result = {
        "protocol": PROTOCOL,
        "exploratory": True,
        "seed": seed,
        "partitions": {name: list(partitions[name]) for name in PARTITIONS},
        "preprocessing": prepared["fit"],
        "calibration": {"POLICY": "train_prevalence", "value": contamination},
        "prevalence": {name: float(y[partitions[name]].mean()) for name in PARTITIONS},
        "runs": {},
        "errors": [],
        "skipped": [],
    }
    skipped = skipped_detectors(len(train))
    for method in methods:
        if method in skipped:
            result["skipped"].append(method)
            continue
        fit = capped(train, method, seed)
        try:
            detector = build(method, contamination, seed)
            found = detect(test, detector, fit_df=fit)
            result["runs"][method] = {
                "metrics": compute_metrics(y[partitions["test"]], found.flags, found.scores),
                "scores": found.scores.tolist(),
                "flags": found.flags.tolist(),
                "fit_rows": len(fit),
            }
        except Exception as error:
            result["errors"].append({"detector": method, "error": repr(error)})
    return result


def x_evaluate_frozen__mutmut_81(
    frame: pd.DataFrame, labels, partitions: dict, *, seed: int, methods: list[str]
) -> dict:
    """Run named detectors on unchanged positions with training-only preparation."""
    if (
        not methods
        or len(set(methods)) != len(methods)
        or set(methods) - set([*DETECTOR_NAMES, *DEEP_NAMES])
    ):
        raise ValueError("detectors must be explicit, unique row-level registry names")
    if type(seed) is not int or not 0 <= seed < 2**32:
        raise ValueError("seed must be a nonnegative 32-bit integer")
    prepared = prepare_frozen(frame, partitions)
    y = np.asarray(labels)
    if y.ndim != 1 or len(y) != len(frame) or set(np.unique(y)) - {0, 1}:
        raise ValueError("labels must be an aligned binary vector")
    for name in PARTITIONS:
        if set(np.unique(y[partitions[name]])) != {0, 1}:
            raise ValueError("both classes are required in every frozen partition")
    train, test = prepared["train"], prepared["test"]
    contamination = clip_contamination(float(y[partitions["train"]].mean()))
    result = {
        "protocol": PROTOCOL,
        "exploratory": True,
        "seed": seed,
        "partitions": {name: list(partitions[name]) for name in PARTITIONS},
        "preprocessing": prepared["fit"],
        "calibration": {"policy": "XXtrain_prevalenceXX", "value": contamination},
        "prevalence": {name: float(y[partitions[name]].mean()) for name in PARTITIONS},
        "runs": {},
        "errors": [],
        "skipped": [],
    }
    skipped = skipped_detectors(len(train))
    for method in methods:
        if method in skipped:
            result["skipped"].append(method)
            continue
        fit = capped(train, method, seed)
        try:
            detector = build(method, contamination, seed)
            found = detect(test, detector, fit_df=fit)
            result["runs"][method] = {
                "metrics": compute_metrics(y[partitions["test"]], found.flags, found.scores),
                "scores": found.scores.tolist(),
                "flags": found.flags.tolist(),
                "fit_rows": len(fit),
            }
        except Exception as error:
            result["errors"].append({"detector": method, "error": repr(error)})
    return result


def x_evaluate_frozen__mutmut_82(
    frame: pd.DataFrame, labels, partitions: dict, *, seed: int, methods: list[str]
) -> dict:
    """Run named detectors on unchanged positions with training-only preparation."""
    if (
        not methods
        or len(set(methods)) != len(methods)
        or set(methods) - set([*DETECTOR_NAMES, *DEEP_NAMES])
    ):
        raise ValueError("detectors must be explicit, unique row-level registry names")
    if type(seed) is not int or not 0 <= seed < 2**32:
        raise ValueError("seed must be a nonnegative 32-bit integer")
    prepared = prepare_frozen(frame, partitions)
    y = np.asarray(labels)
    if y.ndim != 1 or len(y) != len(frame) or set(np.unique(y)) - {0, 1}:
        raise ValueError("labels must be an aligned binary vector")
    for name in PARTITIONS:
        if set(np.unique(y[partitions[name]])) != {0, 1}:
            raise ValueError("both classes are required in every frozen partition")
    train, test = prepared["train"], prepared["test"]
    contamination = clip_contamination(float(y[partitions["train"]].mean()))
    result = {
        "protocol": PROTOCOL,
        "exploratory": True,
        "seed": seed,
        "partitions": {name: list(partitions[name]) for name in PARTITIONS},
        "preprocessing": prepared["fit"],
        "calibration": {"policy": "TRAIN_PREVALENCE", "value": contamination},
        "prevalence": {name: float(y[partitions[name]].mean()) for name in PARTITIONS},
        "runs": {},
        "errors": [],
        "skipped": [],
    }
    skipped = skipped_detectors(len(train))
    for method in methods:
        if method in skipped:
            result["skipped"].append(method)
            continue
        fit = capped(train, method, seed)
        try:
            detector = build(method, contamination, seed)
            found = detect(test, detector, fit_df=fit)
            result["runs"][method] = {
                "metrics": compute_metrics(y[partitions["test"]], found.flags, found.scores),
                "scores": found.scores.tolist(),
                "flags": found.flags.tolist(),
                "fit_rows": len(fit),
            }
        except Exception as error:
            result["errors"].append({"detector": method, "error": repr(error)})
    return result


def x_evaluate_frozen__mutmut_83(
    frame: pd.DataFrame, labels, partitions: dict, *, seed: int, methods: list[str]
) -> dict:
    """Run named detectors on unchanged positions with training-only preparation."""
    if (
        not methods
        or len(set(methods)) != len(methods)
        or set(methods) - set([*DETECTOR_NAMES, *DEEP_NAMES])
    ):
        raise ValueError("detectors must be explicit, unique row-level registry names")
    if type(seed) is not int or not 0 <= seed < 2**32:
        raise ValueError("seed must be a nonnegative 32-bit integer")
    prepared = prepare_frozen(frame, partitions)
    y = np.asarray(labels)
    if y.ndim != 1 or len(y) != len(frame) or set(np.unique(y)) - {0, 1}:
        raise ValueError("labels must be an aligned binary vector")
    for name in PARTITIONS:
        if set(np.unique(y[partitions[name]])) != {0, 1}:
            raise ValueError("both classes are required in every frozen partition")
    train, test = prepared["train"], prepared["test"]
    contamination = clip_contamination(float(y[partitions["train"]].mean()))
    result = {
        "protocol": PROTOCOL,
        "exploratory": True,
        "seed": seed,
        "partitions": {name: list(partitions[name]) for name in PARTITIONS},
        "preprocessing": prepared["fit"],
        "calibration": {"policy": "train_prevalence", "XXvalueXX": contamination},
        "prevalence": {name: float(y[partitions[name]].mean()) for name in PARTITIONS},
        "runs": {},
        "errors": [],
        "skipped": [],
    }
    skipped = skipped_detectors(len(train))
    for method in methods:
        if method in skipped:
            result["skipped"].append(method)
            continue
        fit = capped(train, method, seed)
        try:
            detector = build(method, contamination, seed)
            found = detect(test, detector, fit_df=fit)
            result["runs"][method] = {
                "metrics": compute_metrics(y[partitions["test"]], found.flags, found.scores),
                "scores": found.scores.tolist(),
                "flags": found.flags.tolist(),
                "fit_rows": len(fit),
            }
        except Exception as error:
            result["errors"].append({"detector": method, "error": repr(error)})
    return result


def x_evaluate_frozen__mutmut_84(
    frame: pd.DataFrame, labels, partitions: dict, *, seed: int, methods: list[str]
) -> dict:
    """Run named detectors on unchanged positions with training-only preparation."""
    if (
        not methods
        or len(set(methods)) != len(methods)
        or set(methods) - set([*DETECTOR_NAMES, *DEEP_NAMES])
    ):
        raise ValueError("detectors must be explicit, unique row-level registry names")
    if type(seed) is not int or not 0 <= seed < 2**32:
        raise ValueError("seed must be a nonnegative 32-bit integer")
    prepared = prepare_frozen(frame, partitions)
    y = np.asarray(labels)
    if y.ndim != 1 or len(y) != len(frame) or set(np.unique(y)) - {0, 1}:
        raise ValueError("labels must be an aligned binary vector")
    for name in PARTITIONS:
        if set(np.unique(y[partitions[name]])) != {0, 1}:
            raise ValueError("both classes are required in every frozen partition")
    train, test = prepared["train"], prepared["test"]
    contamination = clip_contamination(float(y[partitions["train"]].mean()))
    result = {
        "protocol": PROTOCOL,
        "exploratory": True,
        "seed": seed,
        "partitions": {name: list(partitions[name]) for name in PARTITIONS},
        "preprocessing": prepared["fit"],
        "calibration": {"policy": "train_prevalence", "VALUE": contamination},
        "prevalence": {name: float(y[partitions[name]].mean()) for name in PARTITIONS},
        "runs": {},
        "errors": [],
        "skipped": [],
    }
    skipped = skipped_detectors(len(train))
    for method in methods:
        if method in skipped:
            result["skipped"].append(method)
            continue
        fit = capped(train, method, seed)
        try:
            detector = build(method, contamination, seed)
            found = detect(test, detector, fit_df=fit)
            result["runs"][method] = {
                "metrics": compute_metrics(y[partitions["test"]], found.flags, found.scores),
                "scores": found.scores.tolist(),
                "flags": found.flags.tolist(),
                "fit_rows": len(fit),
            }
        except Exception as error:
            result["errors"].append({"detector": method, "error": repr(error)})
    return result


def x_evaluate_frozen__mutmut_85(
    frame: pd.DataFrame, labels, partitions: dict, *, seed: int, methods: list[str]
) -> dict:
    """Run named detectors on unchanged positions with training-only preparation."""
    if (
        not methods
        or len(set(methods)) != len(methods)
        or set(methods) - set([*DETECTOR_NAMES, *DEEP_NAMES])
    ):
        raise ValueError("detectors must be explicit, unique row-level registry names")
    if type(seed) is not int or not 0 <= seed < 2**32:
        raise ValueError("seed must be a nonnegative 32-bit integer")
    prepared = prepare_frozen(frame, partitions)
    y = np.asarray(labels)
    if y.ndim != 1 or len(y) != len(frame) or set(np.unique(y)) - {0, 1}:
        raise ValueError("labels must be an aligned binary vector")
    for name in PARTITIONS:
        if set(np.unique(y[partitions[name]])) != {0, 1}:
            raise ValueError("both classes are required in every frozen partition")
    train, test = prepared["train"], prepared["test"]
    contamination = clip_contamination(float(y[partitions["train"]].mean()))
    result = {
        "protocol": PROTOCOL,
        "exploratory": True,
        "seed": seed,
        "partitions": {name: list(partitions[name]) for name in PARTITIONS},
        "preprocessing": prepared["fit"],
        "calibration": {"policy": "train_prevalence", "value": contamination},
        "XXprevalenceXX": {name: float(y[partitions[name]].mean()) for name in PARTITIONS},
        "runs": {},
        "errors": [],
        "skipped": [],
    }
    skipped = skipped_detectors(len(train))
    for method in methods:
        if method in skipped:
            result["skipped"].append(method)
            continue
        fit = capped(train, method, seed)
        try:
            detector = build(method, contamination, seed)
            found = detect(test, detector, fit_df=fit)
            result["runs"][method] = {
                "metrics": compute_metrics(y[partitions["test"]], found.flags, found.scores),
                "scores": found.scores.tolist(),
                "flags": found.flags.tolist(),
                "fit_rows": len(fit),
            }
        except Exception as error:
            result["errors"].append({"detector": method, "error": repr(error)})
    return result


def x_evaluate_frozen__mutmut_86(
    frame: pd.DataFrame, labels, partitions: dict, *, seed: int, methods: list[str]
) -> dict:
    """Run named detectors on unchanged positions with training-only preparation."""
    if (
        not methods
        or len(set(methods)) != len(methods)
        or set(methods) - set([*DETECTOR_NAMES, *DEEP_NAMES])
    ):
        raise ValueError("detectors must be explicit, unique row-level registry names")
    if type(seed) is not int or not 0 <= seed < 2**32:
        raise ValueError("seed must be a nonnegative 32-bit integer")
    prepared = prepare_frozen(frame, partitions)
    y = np.asarray(labels)
    if y.ndim != 1 or len(y) != len(frame) or set(np.unique(y)) - {0, 1}:
        raise ValueError("labels must be an aligned binary vector")
    for name in PARTITIONS:
        if set(np.unique(y[partitions[name]])) != {0, 1}:
            raise ValueError("both classes are required in every frozen partition")
    train, test = prepared["train"], prepared["test"]
    contamination = clip_contamination(float(y[partitions["train"]].mean()))
    result = {
        "protocol": PROTOCOL,
        "exploratory": True,
        "seed": seed,
        "partitions": {name: list(partitions[name]) for name in PARTITIONS},
        "preprocessing": prepared["fit"],
        "calibration": {"policy": "train_prevalence", "value": contamination},
        "PREVALENCE": {name: float(y[partitions[name]].mean()) for name in PARTITIONS},
        "runs": {},
        "errors": [],
        "skipped": [],
    }
    skipped = skipped_detectors(len(train))
    for method in methods:
        if method in skipped:
            result["skipped"].append(method)
            continue
        fit = capped(train, method, seed)
        try:
            detector = build(method, contamination, seed)
            found = detect(test, detector, fit_df=fit)
            result["runs"][method] = {
                "metrics": compute_metrics(y[partitions["test"]], found.flags, found.scores),
                "scores": found.scores.tolist(),
                "flags": found.flags.tolist(),
                "fit_rows": len(fit),
            }
        except Exception as error:
            result["errors"].append({"detector": method, "error": repr(error)})
    return result


def x_evaluate_frozen__mutmut_87(
    frame: pd.DataFrame, labels, partitions: dict, *, seed: int, methods: list[str]
) -> dict:
    """Run named detectors on unchanged positions with training-only preparation."""
    if (
        not methods
        or len(set(methods)) != len(methods)
        or set(methods) - set([*DETECTOR_NAMES, *DEEP_NAMES])
    ):
        raise ValueError("detectors must be explicit, unique row-level registry names")
    if type(seed) is not int or not 0 <= seed < 2**32:
        raise ValueError("seed must be a nonnegative 32-bit integer")
    prepared = prepare_frozen(frame, partitions)
    y = np.asarray(labels)
    if y.ndim != 1 or len(y) != len(frame) or set(np.unique(y)) - {0, 1}:
        raise ValueError("labels must be an aligned binary vector")
    for name in PARTITIONS:
        if set(np.unique(y[partitions[name]])) != {0, 1}:
            raise ValueError("both classes are required in every frozen partition")
    train, test = prepared["train"], prepared["test"]
    contamination = clip_contamination(float(y[partitions["train"]].mean()))
    result = {
        "protocol": PROTOCOL,
        "exploratory": True,
        "seed": seed,
        "partitions": {name: list(partitions[name]) for name in PARTITIONS},
        "preprocessing": prepared["fit"],
        "calibration": {"policy": "train_prevalence", "value": contamination},
        "prevalence": {name: float(None) for name in PARTITIONS},
        "runs": {},
        "errors": [],
        "skipped": [],
    }
    skipped = skipped_detectors(len(train))
    for method in methods:
        if method in skipped:
            result["skipped"].append(method)
            continue
        fit = capped(train, method, seed)
        try:
            detector = build(method, contamination, seed)
            found = detect(test, detector, fit_df=fit)
            result["runs"][method] = {
                "metrics": compute_metrics(y[partitions["test"]], found.flags, found.scores),
                "scores": found.scores.tolist(),
                "flags": found.flags.tolist(),
                "fit_rows": len(fit),
            }
        except Exception as error:
            result["errors"].append({"detector": method, "error": repr(error)})
    return result


def x_evaluate_frozen__mutmut_88(
    frame: pd.DataFrame, labels, partitions: dict, *, seed: int, methods: list[str]
) -> dict:
    """Run named detectors on unchanged positions with training-only preparation."""
    if (
        not methods
        or len(set(methods)) != len(methods)
        or set(methods) - set([*DETECTOR_NAMES, *DEEP_NAMES])
    ):
        raise ValueError("detectors must be explicit, unique row-level registry names")
    if type(seed) is not int or not 0 <= seed < 2**32:
        raise ValueError("seed must be a nonnegative 32-bit integer")
    prepared = prepare_frozen(frame, partitions)
    y = np.asarray(labels)
    if y.ndim != 1 or len(y) != len(frame) or set(np.unique(y)) - {0, 1}:
        raise ValueError("labels must be an aligned binary vector")
    for name in PARTITIONS:
        if set(np.unique(y[partitions[name]])) != {0, 1}:
            raise ValueError("both classes are required in every frozen partition")
    train, test = prepared["train"], prepared["test"]
    contamination = clip_contamination(float(y[partitions["train"]].mean()))
    result = {
        "protocol": PROTOCOL,
        "exploratory": True,
        "seed": seed,
        "partitions": {name: list(partitions[name]) for name in PARTITIONS},
        "preprocessing": prepared["fit"],
        "calibration": {"policy": "train_prevalence", "value": contamination},
        "prevalence": {name: float(y[partitions[name]].mean()) for name in PARTITIONS},
        "XXrunsXX": {},
        "errors": [],
        "skipped": [],
    }
    skipped = skipped_detectors(len(train))
    for method in methods:
        if method in skipped:
            result["skipped"].append(method)
            continue
        fit = capped(train, method, seed)
        try:
            detector = build(method, contamination, seed)
            found = detect(test, detector, fit_df=fit)
            result["runs"][method] = {
                "metrics": compute_metrics(y[partitions["test"]], found.flags, found.scores),
                "scores": found.scores.tolist(),
                "flags": found.flags.tolist(),
                "fit_rows": len(fit),
            }
        except Exception as error:
            result["errors"].append({"detector": method, "error": repr(error)})
    return result


def x_evaluate_frozen__mutmut_89(
    frame: pd.DataFrame, labels, partitions: dict, *, seed: int, methods: list[str]
) -> dict:
    """Run named detectors on unchanged positions with training-only preparation."""
    if (
        not methods
        or len(set(methods)) != len(methods)
        or set(methods) - set([*DETECTOR_NAMES, *DEEP_NAMES])
    ):
        raise ValueError("detectors must be explicit, unique row-level registry names")
    if type(seed) is not int or not 0 <= seed < 2**32:
        raise ValueError("seed must be a nonnegative 32-bit integer")
    prepared = prepare_frozen(frame, partitions)
    y = np.asarray(labels)
    if y.ndim != 1 or len(y) != len(frame) or set(np.unique(y)) - {0, 1}:
        raise ValueError("labels must be an aligned binary vector")
    for name in PARTITIONS:
        if set(np.unique(y[partitions[name]])) != {0, 1}:
            raise ValueError("both classes are required in every frozen partition")
    train, test = prepared["train"], prepared["test"]
    contamination = clip_contamination(float(y[partitions["train"]].mean()))
    result = {
        "protocol": PROTOCOL,
        "exploratory": True,
        "seed": seed,
        "partitions": {name: list(partitions[name]) for name in PARTITIONS},
        "preprocessing": prepared["fit"],
        "calibration": {"policy": "train_prevalence", "value": contamination},
        "prevalence": {name: float(y[partitions[name]].mean()) for name in PARTITIONS},
        "RUNS": {},
        "errors": [],
        "skipped": [],
    }
    skipped = skipped_detectors(len(train))
    for method in methods:
        if method in skipped:
            result["skipped"].append(method)
            continue
        fit = capped(train, method, seed)
        try:
            detector = build(method, contamination, seed)
            found = detect(test, detector, fit_df=fit)
            result["runs"][method] = {
                "metrics": compute_metrics(y[partitions["test"]], found.flags, found.scores),
                "scores": found.scores.tolist(),
                "flags": found.flags.tolist(),
                "fit_rows": len(fit),
            }
        except Exception as error:
            result["errors"].append({"detector": method, "error": repr(error)})
    return result


def x_evaluate_frozen__mutmut_90(
    frame: pd.DataFrame, labels, partitions: dict, *, seed: int, methods: list[str]
) -> dict:
    """Run named detectors on unchanged positions with training-only preparation."""
    if (
        not methods
        or len(set(methods)) != len(methods)
        or set(methods) - set([*DETECTOR_NAMES, *DEEP_NAMES])
    ):
        raise ValueError("detectors must be explicit, unique row-level registry names")
    if type(seed) is not int or not 0 <= seed < 2**32:
        raise ValueError("seed must be a nonnegative 32-bit integer")
    prepared = prepare_frozen(frame, partitions)
    y = np.asarray(labels)
    if y.ndim != 1 or len(y) != len(frame) or set(np.unique(y)) - {0, 1}:
        raise ValueError("labels must be an aligned binary vector")
    for name in PARTITIONS:
        if set(np.unique(y[partitions[name]])) != {0, 1}:
            raise ValueError("both classes are required in every frozen partition")
    train, test = prepared["train"], prepared["test"]
    contamination = clip_contamination(float(y[partitions["train"]].mean()))
    result = {
        "protocol": PROTOCOL,
        "exploratory": True,
        "seed": seed,
        "partitions": {name: list(partitions[name]) for name in PARTITIONS},
        "preprocessing": prepared["fit"],
        "calibration": {"policy": "train_prevalence", "value": contamination},
        "prevalence": {name: float(y[partitions[name]].mean()) for name in PARTITIONS},
        "runs": {},
        "XXerrorsXX": [],
        "skipped": [],
    }
    skipped = skipped_detectors(len(train))
    for method in methods:
        if method in skipped:
            result["skipped"].append(method)
            continue
        fit = capped(train, method, seed)
        try:
            detector = build(method, contamination, seed)
            found = detect(test, detector, fit_df=fit)
            result["runs"][method] = {
                "metrics": compute_metrics(y[partitions["test"]], found.flags, found.scores),
                "scores": found.scores.tolist(),
                "flags": found.flags.tolist(),
                "fit_rows": len(fit),
            }
        except Exception as error:
            result["errors"].append({"detector": method, "error": repr(error)})
    return result


def x_evaluate_frozen__mutmut_91(
    frame: pd.DataFrame, labels, partitions: dict, *, seed: int, methods: list[str]
) -> dict:
    """Run named detectors on unchanged positions with training-only preparation."""
    if (
        not methods
        or len(set(methods)) != len(methods)
        or set(methods) - set([*DETECTOR_NAMES, *DEEP_NAMES])
    ):
        raise ValueError("detectors must be explicit, unique row-level registry names")
    if type(seed) is not int or not 0 <= seed < 2**32:
        raise ValueError("seed must be a nonnegative 32-bit integer")
    prepared = prepare_frozen(frame, partitions)
    y = np.asarray(labels)
    if y.ndim != 1 or len(y) != len(frame) or set(np.unique(y)) - {0, 1}:
        raise ValueError("labels must be an aligned binary vector")
    for name in PARTITIONS:
        if set(np.unique(y[partitions[name]])) != {0, 1}:
            raise ValueError("both classes are required in every frozen partition")
    train, test = prepared["train"], prepared["test"]
    contamination = clip_contamination(float(y[partitions["train"]].mean()))
    result = {
        "protocol": PROTOCOL,
        "exploratory": True,
        "seed": seed,
        "partitions": {name: list(partitions[name]) for name in PARTITIONS},
        "preprocessing": prepared["fit"],
        "calibration": {"policy": "train_prevalence", "value": contamination},
        "prevalence": {name: float(y[partitions[name]].mean()) for name in PARTITIONS},
        "runs": {},
        "ERRORS": [],
        "skipped": [],
    }
    skipped = skipped_detectors(len(train))
    for method in methods:
        if method in skipped:
            result["skipped"].append(method)
            continue
        fit = capped(train, method, seed)
        try:
            detector = build(method, contamination, seed)
            found = detect(test, detector, fit_df=fit)
            result["runs"][method] = {
                "metrics": compute_metrics(y[partitions["test"]], found.flags, found.scores),
                "scores": found.scores.tolist(),
                "flags": found.flags.tolist(),
                "fit_rows": len(fit),
            }
        except Exception as error:
            result["errors"].append({"detector": method, "error": repr(error)})
    return result


def x_evaluate_frozen__mutmut_92(
    frame: pd.DataFrame, labels, partitions: dict, *, seed: int, methods: list[str]
) -> dict:
    """Run named detectors on unchanged positions with training-only preparation."""
    if (
        not methods
        or len(set(methods)) != len(methods)
        or set(methods) - set([*DETECTOR_NAMES, *DEEP_NAMES])
    ):
        raise ValueError("detectors must be explicit, unique row-level registry names")
    if type(seed) is not int or not 0 <= seed < 2**32:
        raise ValueError("seed must be a nonnegative 32-bit integer")
    prepared = prepare_frozen(frame, partitions)
    y = np.asarray(labels)
    if y.ndim != 1 or len(y) != len(frame) or set(np.unique(y)) - {0, 1}:
        raise ValueError("labels must be an aligned binary vector")
    for name in PARTITIONS:
        if set(np.unique(y[partitions[name]])) != {0, 1}:
            raise ValueError("both classes are required in every frozen partition")
    train, test = prepared["train"], prepared["test"]
    contamination = clip_contamination(float(y[partitions["train"]].mean()))
    result = {
        "protocol": PROTOCOL,
        "exploratory": True,
        "seed": seed,
        "partitions": {name: list(partitions[name]) for name in PARTITIONS},
        "preprocessing": prepared["fit"],
        "calibration": {"policy": "train_prevalence", "value": contamination},
        "prevalence": {name: float(y[partitions[name]].mean()) for name in PARTITIONS},
        "runs": {},
        "errors": [],
        "XXskippedXX": [],
    }
    skipped = skipped_detectors(len(train))
    for method in methods:
        if method in skipped:
            result["skipped"].append(method)
            continue
        fit = capped(train, method, seed)
        try:
            detector = build(method, contamination, seed)
            found = detect(test, detector, fit_df=fit)
            result["runs"][method] = {
                "metrics": compute_metrics(y[partitions["test"]], found.flags, found.scores),
                "scores": found.scores.tolist(),
                "flags": found.flags.tolist(),
                "fit_rows": len(fit),
            }
        except Exception as error:
            result["errors"].append({"detector": method, "error": repr(error)})
    return result


def x_evaluate_frozen__mutmut_93(
    frame: pd.DataFrame, labels, partitions: dict, *, seed: int, methods: list[str]
) -> dict:
    """Run named detectors on unchanged positions with training-only preparation."""
    if (
        not methods
        or len(set(methods)) != len(methods)
        or set(methods) - set([*DETECTOR_NAMES, *DEEP_NAMES])
    ):
        raise ValueError("detectors must be explicit, unique row-level registry names")
    if type(seed) is not int or not 0 <= seed < 2**32:
        raise ValueError("seed must be a nonnegative 32-bit integer")
    prepared = prepare_frozen(frame, partitions)
    y = np.asarray(labels)
    if y.ndim != 1 or len(y) != len(frame) or set(np.unique(y)) - {0, 1}:
        raise ValueError("labels must be an aligned binary vector")
    for name in PARTITIONS:
        if set(np.unique(y[partitions[name]])) != {0, 1}:
            raise ValueError("both classes are required in every frozen partition")
    train, test = prepared["train"], prepared["test"]
    contamination = clip_contamination(float(y[partitions["train"]].mean()))
    result = {
        "protocol": PROTOCOL,
        "exploratory": True,
        "seed": seed,
        "partitions": {name: list(partitions[name]) for name in PARTITIONS},
        "preprocessing": prepared["fit"],
        "calibration": {"policy": "train_prevalence", "value": contamination},
        "prevalence": {name: float(y[partitions[name]].mean()) for name in PARTITIONS},
        "runs": {},
        "errors": [],
        "SKIPPED": [],
    }
    skipped = skipped_detectors(len(train))
    for method in methods:
        if method in skipped:
            result["skipped"].append(method)
            continue
        fit = capped(train, method, seed)
        try:
            detector = build(method, contamination, seed)
            found = detect(test, detector, fit_df=fit)
            result["runs"][method] = {
                "metrics": compute_metrics(y[partitions["test"]], found.flags, found.scores),
                "scores": found.scores.tolist(),
                "flags": found.flags.tolist(),
                "fit_rows": len(fit),
            }
        except Exception as error:
            result["errors"].append({"detector": method, "error": repr(error)})
    return result


def x_evaluate_frozen__mutmut_94(
    frame: pd.DataFrame, labels, partitions: dict, *, seed: int, methods: list[str]
) -> dict:
    """Run named detectors on unchanged positions with training-only preparation."""
    if (
        not methods
        or len(set(methods)) != len(methods)
        or set(methods) - set([*DETECTOR_NAMES, *DEEP_NAMES])
    ):
        raise ValueError("detectors must be explicit, unique row-level registry names")
    if type(seed) is not int or not 0 <= seed < 2**32:
        raise ValueError("seed must be a nonnegative 32-bit integer")
    prepared = prepare_frozen(frame, partitions)
    y = np.asarray(labels)
    if y.ndim != 1 or len(y) != len(frame) or set(np.unique(y)) - {0, 1}:
        raise ValueError("labels must be an aligned binary vector")
    for name in PARTITIONS:
        if set(np.unique(y[partitions[name]])) != {0, 1}:
            raise ValueError("both classes are required in every frozen partition")
    train, test = prepared["train"], prepared["test"]
    contamination = clip_contamination(float(y[partitions["train"]].mean()))
    result = {
        "protocol": PROTOCOL,
        "exploratory": True,
        "seed": seed,
        "partitions": {name: list(partitions[name]) for name in PARTITIONS},
        "preprocessing": prepared["fit"],
        "calibration": {"policy": "train_prevalence", "value": contamination},
        "prevalence": {name: float(y[partitions[name]].mean()) for name in PARTITIONS},
        "runs": {},
        "errors": [],
        "skipped": [],
    }
    skipped = None
    for method in methods:
        if method in skipped:
            result["skipped"].append(method)
            continue
        fit = capped(train, method, seed)
        try:
            detector = build(method, contamination, seed)
            found = detect(test, detector, fit_df=fit)
            result["runs"][method] = {
                "metrics": compute_metrics(y[partitions["test"]], found.flags, found.scores),
                "scores": found.scores.tolist(),
                "flags": found.flags.tolist(),
                "fit_rows": len(fit),
            }
        except Exception as error:
            result["errors"].append({"detector": method, "error": repr(error)})
    return result


def x_evaluate_frozen__mutmut_95(
    frame: pd.DataFrame, labels, partitions: dict, *, seed: int, methods: list[str]
) -> dict:
    """Run named detectors on unchanged positions with training-only preparation."""
    if (
        not methods
        or len(set(methods)) != len(methods)
        or set(methods) - set([*DETECTOR_NAMES, *DEEP_NAMES])
    ):
        raise ValueError("detectors must be explicit, unique row-level registry names")
    if type(seed) is not int or not 0 <= seed < 2**32:
        raise ValueError("seed must be a nonnegative 32-bit integer")
    prepared = prepare_frozen(frame, partitions)
    y = np.asarray(labels)
    if y.ndim != 1 or len(y) != len(frame) or set(np.unique(y)) - {0, 1}:
        raise ValueError("labels must be an aligned binary vector")
    for name in PARTITIONS:
        if set(np.unique(y[partitions[name]])) != {0, 1}:
            raise ValueError("both classes are required in every frozen partition")
    train, test = prepared["train"], prepared["test"]
    contamination = clip_contamination(float(y[partitions["train"]].mean()))
    result = {
        "protocol": PROTOCOL,
        "exploratory": True,
        "seed": seed,
        "partitions": {name: list(partitions[name]) for name in PARTITIONS},
        "preprocessing": prepared["fit"],
        "calibration": {"policy": "train_prevalence", "value": contamination},
        "prevalence": {name: float(y[partitions[name]].mean()) for name in PARTITIONS},
        "runs": {},
        "errors": [],
        "skipped": [],
    }
    skipped = skipped_detectors(None)
    for method in methods:
        if method in skipped:
            result["skipped"].append(method)
            continue
        fit = capped(train, method, seed)
        try:
            detector = build(method, contamination, seed)
            found = detect(test, detector, fit_df=fit)
            result["runs"][method] = {
                "metrics": compute_metrics(y[partitions["test"]], found.flags, found.scores),
                "scores": found.scores.tolist(),
                "flags": found.flags.tolist(),
                "fit_rows": len(fit),
            }
        except Exception as error:
            result["errors"].append({"detector": method, "error": repr(error)})
    return result


def x_evaluate_frozen__mutmut_96(
    frame: pd.DataFrame, labels, partitions: dict, *, seed: int, methods: list[str]
) -> dict:
    """Run named detectors on unchanged positions with training-only preparation."""
    if (
        not methods
        or len(set(methods)) != len(methods)
        or set(methods) - set([*DETECTOR_NAMES, *DEEP_NAMES])
    ):
        raise ValueError("detectors must be explicit, unique row-level registry names")
    if type(seed) is not int or not 0 <= seed < 2**32:
        raise ValueError("seed must be a nonnegative 32-bit integer")
    prepared = prepare_frozen(frame, partitions)
    y = np.asarray(labels)
    if y.ndim != 1 or len(y) != len(frame) or set(np.unique(y)) - {0, 1}:
        raise ValueError("labels must be an aligned binary vector")
    for name in PARTITIONS:
        if set(np.unique(y[partitions[name]])) != {0, 1}:
            raise ValueError("both classes are required in every frozen partition")
    train, test = prepared["train"], prepared["test"]
    contamination = clip_contamination(float(y[partitions["train"]].mean()))
    result = {
        "protocol": PROTOCOL,
        "exploratory": True,
        "seed": seed,
        "partitions": {name: list(partitions[name]) for name in PARTITIONS},
        "preprocessing": prepared["fit"],
        "calibration": {"policy": "train_prevalence", "value": contamination},
        "prevalence": {name: float(y[partitions[name]].mean()) for name in PARTITIONS},
        "runs": {},
        "errors": [],
        "skipped": [],
    }
    skipped = skipped_detectors(len(train))
    for method in methods:
        if method not in skipped:
            result["skipped"].append(method)
            continue
        fit = capped(train, method, seed)
        try:
            detector = build(method, contamination, seed)
            found = detect(test, detector, fit_df=fit)
            result["runs"][method] = {
                "metrics": compute_metrics(y[partitions["test"]], found.flags, found.scores),
                "scores": found.scores.tolist(),
                "flags": found.flags.tolist(),
                "fit_rows": len(fit),
            }
        except Exception as error:
            result["errors"].append({"detector": method, "error": repr(error)})
    return result


def x_evaluate_frozen__mutmut_97(
    frame: pd.DataFrame, labels, partitions: dict, *, seed: int, methods: list[str]
) -> dict:
    """Run named detectors on unchanged positions with training-only preparation."""
    if (
        not methods
        or len(set(methods)) != len(methods)
        or set(methods) - set([*DETECTOR_NAMES, *DEEP_NAMES])
    ):
        raise ValueError("detectors must be explicit, unique row-level registry names")
    if type(seed) is not int or not 0 <= seed < 2**32:
        raise ValueError("seed must be a nonnegative 32-bit integer")
    prepared = prepare_frozen(frame, partitions)
    y = np.asarray(labels)
    if y.ndim != 1 or len(y) != len(frame) or set(np.unique(y)) - {0, 1}:
        raise ValueError("labels must be an aligned binary vector")
    for name in PARTITIONS:
        if set(np.unique(y[partitions[name]])) != {0, 1}:
            raise ValueError("both classes are required in every frozen partition")
    train, test = prepared["train"], prepared["test"]
    contamination = clip_contamination(float(y[partitions["train"]].mean()))
    result = {
        "protocol": PROTOCOL,
        "exploratory": True,
        "seed": seed,
        "partitions": {name: list(partitions[name]) for name in PARTITIONS},
        "preprocessing": prepared["fit"],
        "calibration": {"policy": "train_prevalence", "value": contamination},
        "prevalence": {name: float(y[partitions[name]].mean()) for name in PARTITIONS},
        "runs": {},
        "errors": [],
        "skipped": [],
    }
    skipped = skipped_detectors(len(train))
    for method in methods:
        if method in skipped:
            result["skipped"].append(None)
            continue
        fit = capped(train, method, seed)
        try:
            detector = build(method, contamination, seed)
            found = detect(test, detector, fit_df=fit)
            result["runs"][method] = {
                "metrics": compute_metrics(y[partitions["test"]], found.flags, found.scores),
                "scores": found.scores.tolist(),
                "flags": found.flags.tolist(),
                "fit_rows": len(fit),
            }
        except Exception as error:
            result["errors"].append({"detector": method, "error": repr(error)})
    return result


def x_evaluate_frozen__mutmut_98(
    frame: pd.DataFrame, labels, partitions: dict, *, seed: int, methods: list[str]
) -> dict:
    """Run named detectors on unchanged positions with training-only preparation."""
    if (
        not methods
        or len(set(methods)) != len(methods)
        or set(methods) - set([*DETECTOR_NAMES, *DEEP_NAMES])
    ):
        raise ValueError("detectors must be explicit, unique row-level registry names")
    if type(seed) is not int or not 0 <= seed < 2**32:
        raise ValueError("seed must be a nonnegative 32-bit integer")
    prepared = prepare_frozen(frame, partitions)
    y = np.asarray(labels)
    if y.ndim != 1 or len(y) != len(frame) or set(np.unique(y)) - {0, 1}:
        raise ValueError("labels must be an aligned binary vector")
    for name in PARTITIONS:
        if set(np.unique(y[partitions[name]])) != {0, 1}:
            raise ValueError("both classes are required in every frozen partition")
    train, test = prepared["train"], prepared["test"]
    contamination = clip_contamination(float(y[partitions["train"]].mean()))
    result = {
        "protocol": PROTOCOL,
        "exploratory": True,
        "seed": seed,
        "partitions": {name: list(partitions[name]) for name in PARTITIONS},
        "preprocessing": prepared["fit"],
        "calibration": {"policy": "train_prevalence", "value": contamination},
        "prevalence": {name: float(y[partitions[name]].mean()) for name in PARTITIONS},
        "runs": {},
        "errors": [],
        "skipped": [],
    }
    skipped = skipped_detectors(len(train))
    for method in methods:
        if method in skipped:
            result["XXskippedXX"].append(method)
            continue
        fit = capped(train, method, seed)
        try:
            detector = build(method, contamination, seed)
            found = detect(test, detector, fit_df=fit)
            result["runs"][method] = {
                "metrics": compute_metrics(y[partitions["test"]], found.flags, found.scores),
                "scores": found.scores.tolist(),
                "flags": found.flags.tolist(),
                "fit_rows": len(fit),
            }
        except Exception as error:
            result["errors"].append({"detector": method, "error": repr(error)})
    return result


def x_evaluate_frozen__mutmut_99(
    frame: pd.DataFrame, labels, partitions: dict, *, seed: int, methods: list[str]
) -> dict:
    """Run named detectors on unchanged positions with training-only preparation."""
    if (
        not methods
        or len(set(methods)) != len(methods)
        or set(methods) - set([*DETECTOR_NAMES, *DEEP_NAMES])
    ):
        raise ValueError("detectors must be explicit, unique row-level registry names")
    if type(seed) is not int or not 0 <= seed < 2**32:
        raise ValueError("seed must be a nonnegative 32-bit integer")
    prepared = prepare_frozen(frame, partitions)
    y = np.asarray(labels)
    if y.ndim != 1 or len(y) != len(frame) or set(np.unique(y)) - {0, 1}:
        raise ValueError("labels must be an aligned binary vector")
    for name in PARTITIONS:
        if set(np.unique(y[partitions[name]])) != {0, 1}:
            raise ValueError("both classes are required in every frozen partition")
    train, test = prepared["train"], prepared["test"]
    contamination = clip_contamination(float(y[partitions["train"]].mean()))
    result = {
        "protocol": PROTOCOL,
        "exploratory": True,
        "seed": seed,
        "partitions": {name: list(partitions[name]) for name in PARTITIONS},
        "preprocessing": prepared["fit"],
        "calibration": {"policy": "train_prevalence", "value": contamination},
        "prevalence": {name: float(y[partitions[name]].mean()) for name in PARTITIONS},
        "runs": {},
        "errors": [],
        "skipped": [],
    }
    skipped = skipped_detectors(len(train))
    for method in methods:
        if method in skipped:
            result["SKIPPED"].append(method)
            continue
        fit = capped(train, method, seed)
        try:
            detector = build(method, contamination, seed)
            found = detect(test, detector, fit_df=fit)
            result["runs"][method] = {
                "metrics": compute_metrics(y[partitions["test"]], found.flags, found.scores),
                "scores": found.scores.tolist(),
                "flags": found.flags.tolist(),
                "fit_rows": len(fit),
            }
        except Exception as error:
            result["errors"].append({"detector": method, "error": repr(error)})
    return result


def x_evaluate_frozen__mutmut_100(
    frame: pd.DataFrame, labels, partitions: dict, *, seed: int, methods: list[str]
) -> dict:
    """Run named detectors on unchanged positions with training-only preparation."""
    if (
        not methods
        or len(set(methods)) != len(methods)
        or set(methods) - set([*DETECTOR_NAMES, *DEEP_NAMES])
    ):
        raise ValueError("detectors must be explicit, unique row-level registry names")
    if type(seed) is not int or not 0 <= seed < 2**32:
        raise ValueError("seed must be a nonnegative 32-bit integer")
    prepared = prepare_frozen(frame, partitions)
    y = np.asarray(labels)
    if y.ndim != 1 or len(y) != len(frame) or set(np.unique(y)) - {0, 1}:
        raise ValueError("labels must be an aligned binary vector")
    for name in PARTITIONS:
        if set(np.unique(y[partitions[name]])) != {0, 1}:
            raise ValueError("both classes are required in every frozen partition")
    train, test = prepared["train"], prepared["test"]
    contamination = clip_contamination(float(y[partitions["train"]].mean()))
    result = {
        "protocol": PROTOCOL,
        "exploratory": True,
        "seed": seed,
        "partitions": {name: list(partitions[name]) for name in PARTITIONS},
        "preprocessing": prepared["fit"],
        "calibration": {"policy": "train_prevalence", "value": contamination},
        "prevalence": {name: float(y[partitions[name]].mean()) for name in PARTITIONS},
        "runs": {},
        "errors": [],
        "skipped": [],
    }
    skipped = skipped_detectors(len(train))
    for method in methods:
        if method in skipped:
            result["skipped"].append(method)
            break
        fit = capped(train, method, seed)
        try:
            detector = build(method, contamination, seed)
            found = detect(test, detector, fit_df=fit)
            result["runs"][method] = {
                "metrics": compute_metrics(y[partitions["test"]], found.flags, found.scores),
                "scores": found.scores.tolist(),
                "flags": found.flags.tolist(),
                "fit_rows": len(fit),
            }
        except Exception as error:
            result["errors"].append({"detector": method, "error": repr(error)})
    return result


def x_evaluate_frozen__mutmut_101(
    frame: pd.DataFrame, labels, partitions: dict, *, seed: int, methods: list[str]
) -> dict:
    """Run named detectors on unchanged positions with training-only preparation."""
    if (
        not methods
        or len(set(methods)) != len(methods)
        or set(methods) - set([*DETECTOR_NAMES, *DEEP_NAMES])
    ):
        raise ValueError("detectors must be explicit, unique row-level registry names")
    if type(seed) is not int or not 0 <= seed < 2**32:
        raise ValueError("seed must be a nonnegative 32-bit integer")
    prepared = prepare_frozen(frame, partitions)
    y = np.asarray(labels)
    if y.ndim != 1 or len(y) != len(frame) or set(np.unique(y)) - {0, 1}:
        raise ValueError("labels must be an aligned binary vector")
    for name in PARTITIONS:
        if set(np.unique(y[partitions[name]])) != {0, 1}:
            raise ValueError("both classes are required in every frozen partition")
    train, test = prepared["train"], prepared["test"]
    contamination = clip_contamination(float(y[partitions["train"]].mean()))
    result = {
        "protocol": PROTOCOL,
        "exploratory": True,
        "seed": seed,
        "partitions": {name: list(partitions[name]) for name in PARTITIONS},
        "preprocessing": prepared["fit"],
        "calibration": {"policy": "train_prevalence", "value": contamination},
        "prevalence": {name: float(y[partitions[name]].mean()) for name in PARTITIONS},
        "runs": {},
        "errors": [],
        "skipped": [],
    }
    skipped = skipped_detectors(len(train))
    for method in methods:
        if method in skipped:
            result["skipped"].append(method)
            continue
        fit = None
        try:
            detector = build(method, contamination, seed)
            found = detect(test, detector, fit_df=fit)
            result["runs"][method] = {
                "metrics": compute_metrics(y[partitions["test"]], found.flags, found.scores),
                "scores": found.scores.tolist(),
                "flags": found.flags.tolist(),
                "fit_rows": len(fit),
            }
        except Exception as error:
            result["errors"].append({"detector": method, "error": repr(error)})
    return result


def x_evaluate_frozen__mutmut_102(
    frame: pd.DataFrame, labels, partitions: dict, *, seed: int, methods: list[str]
) -> dict:
    """Run named detectors on unchanged positions with training-only preparation."""
    if (
        not methods
        or len(set(methods)) != len(methods)
        or set(methods) - set([*DETECTOR_NAMES, *DEEP_NAMES])
    ):
        raise ValueError("detectors must be explicit, unique row-level registry names")
    if type(seed) is not int or not 0 <= seed < 2**32:
        raise ValueError("seed must be a nonnegative 32-bit integer")
    prepared = prepare_frozen(frame, partitions)
    y = np.asarray(labels)
    if y.ndim != 1 or len(y) != len(frame) or set(np.unique(y)) - {0, 1}:
        raise ValueError("labels must be an aligned binary vector")
    for name in PARTITIONS:
        if set(np.unique(y[partitions[name]])) != {0, 1}:
            raise ValueError("both classes are required in every frozen partition")
    train, test = prepared["train"], prepared["test"]
    contamination = clip_contamination(float(y[partitions["train"]].mean()))
    result = {
        "protocol": PROTOCOL,
        "exploratory": True,
        "seed": seed,
        "partitions": {name: list(partitions[name]) for name in PARTITIONS},
        "preprocessing": prepared["fit"],
        "calibration": {"policy": "train_prevalence", "value": contamination},
        "prevalence": {name: float(y[partitions[name]].mean()) for name in PARTITIONS},
        "runs": {},
        "errors": [],
        "skipped": [],
    }
    skipped = skipped_detectors(len(train))
    for method in methods:
        if method in skipped:
            result["skipped"].append(method)
            continue
        fit = capped(None, method, seed)
        try:
            detector = build(method, contamination, seed)
            found = detect(test, detector, fit_df=fit)
            result["runs"][method] = {
                "metrics": compute_metrics(y[partitions["test"]], found.flags, found.scores),
                "scores": found.scores.tolist(),
                "flags": found.flags.tolist(),
                "fit_rows": len(fit),
            }
        except Exception as error:
            result["errors"].append({"detector": method, "error": repr(error)})
    return result


def x_evaluate_frozen__mutmut_103(
    frame: pd.DataFrame, labels, partitions: dict, *, seed: int, methods: list[str]
) -> dict:
    """Run named detectors on unchanged positions with training-only preparation."""
    if (
        not methods
        or len(set(methods)) != len(methods)
        or set(methods) - set([*DETECTOR_NAMES, *DEEP_NAMES])
    ):
        raise ValueError("detectors must be explicit, unique row-level registry names")
    if type(seed) is not int or not 0 <= seed < 2**32:
        raise ValueError("seed must be a nonnegative 32-bit integer")
    prepared = prepare_frozen(frame, partitions)
    y = np.asarray(labels)
    if y.ndim != 1 or len(y) != len(frame) or set(np.unique(y)) - {0, 1}:
        raise ValueError("labels must be an aligned binary vector")
    for name in PARTITIONS:
        if set(np.unique(y[partitions[name]])) != {0, 1}:
            raise ValueError("both classes are required in every frozen partition")
    train, test = prepared["train"], prepared["test"]
    contamination = clip_contamination(float(y[partitions["train"]].mean()))
    result = {
        "protocol": PROTOCOL,
        "exploratory": True,
        "seed": seed,
        "partitions": {name: list(partitions[name]) for name in PARTITIONS},
        "preprocessing": prepared["fit"],
        "calibration": {"policy": "train_prevalence", "value": contamination},
        "prevalence": {name: float(y[partitions[name]].mean()) for name in PARTITIONS},
        "runs": {},
        "errors": [],
        "skipped": [],
    }
    skipped = skipped_detectors(len(train))
    for method in methods:
        if method in skipped:
            result["skipped"].append(method)
            continue
        fit = capped(train, None, seed)
        try:
            detector = build(method, contamination, seed)
            found = detect(test, detector, fit_df=fit)
            result["runs"][method] = {
                "metrics": compute_metrics(y[partitions["test"]], found.flags, found.scores),
                "scores": found.scores.tolist(),
                "flags": found.flags.tolist(),
                "fit_rows": len(fit),
            }
        except Exception as error:
            result["errors"].append({"detector": method, "error": repr(error)})
    return result


def x_evaluate_frozen__mutmut_104(
    frame: pd.DataFrame, labels, partitions: dict, *, seed: int, methods: list[str]
) -> dict:
    """Run named detectors on unchanged positions with training-only preparation."""
    if (
        not methods
        or len(set(methods)) != len(methods)
        or set(methods) - set([*DETECTOR_NAMES, *DEEP_NAMES])
    ):
        raise ValueError("detectors must be explicit, unique row-level registry names")
    if type(seed) is not int or not 0 <= seed < 2**32:
        raise ValueError("seed must be a nonnegative 32-bit integer")
    prepared = prepare_frozen(frame, partitions)
    y = np.asarray(labels)
    if y.ndim != 1 or len(y) != len(frame) or set(np.unique(y)) - {0, 1}:
        raise ValueError("labels must be an aligned binary vector")
    for name in PARTITIONS:
        if set(np.unique(y[partitions[name]])) != {0, 1}:
            raise ValueError("both classes are required in every frozen partition")
    train, test = prepared["train"], prepared["test"]
    contamination = clip_contamination(float(y[partitions["train"]].mean()))
    result = {
        "protocol": PROTOCOL,
        "exploratory": True,
        "seed": seed,
        "partitions": {name: list(partitions[name]) for name in PARTITIONS},
        "preprocessing": prepared["fit"],
        "calibration": {"policy": "train_prevalence", "value": contamination},
        "prevalence": {name: float(y[partitions[name]].mean()) for name in PARTITIONS},
        "runs": {},
        "errors": [],
        "skipped": [],
    }
    skipped = skipped_detectors(len(train))
    for method in methods:
        if method in skipped:
            result["skipped"].append(method)
            continue
        fit = capped(train, method, None)
        try:
            detector = build(method, contamination, seed)
            found = detect(test, detector, fit_df=fit)
            result["runs"][method] = {
                "metrics": compute_metrics(y[partitions["test"]], found.flags, found.scores),
                "scores": found.scores.tolist(),
                "flags": found.flags.tolist(),
                "fit_rows": len(fit),
            }
        except Exception as error:
            result["errors"].append({"detector": method, "error": repr(error)})
    return result


def x_evaluate_frozen__mutmut_105(
    frame: pd.DataFrame, labels, partitions: dict, *, seed: int, methods: list[str]
) -> dict:
    """Run named detectors on unchanged positions with training-only preparation."""
    if (
        not methods
        or len(set(methods)) != len(methods)
        or set(methods) - set([*DETECTOR_NAMES, *DEEP_NAMES])
    ):
        raise ValueError("detectors must be explicit, unique row-level registry names")
    if type(seed) is not int or not 0 <= seed < 2**32:
        raise ValueError("seed must be a nonnegative 32-bit integer")
    prepared = prepare_frozen(frame, partitions)
    y = np.asarray(labels)
    if y.ndim != 1 or len(y) != len(frame) or set(np.unique(y)) - {0, 1}:
        raise ValueError("labels must be an aligned binary vector")
    for name in PARTITIONS:
        if set(np.unique(y[partitions[name]])) != {0, 1}:
            raise ValueError("both classes are required in every frozen partition")
    train, test = prepared["train"], prepared["test"]
    contamination = clip_contamination(float(y[partitions["train"]].mean()))
    result = {
        "protocol": PROTOCOL,
        "exploratory": True,
        "seed": seed,
        "partitions": {name: list(partitions[name]) for name in PARTITIONS},
        "preprocessing": prepared["fit"],
        "calibration": {"policy": "train_prevalence", "value": contamination},
        "prevalence": {name: float(y[partitions[name]].mean()) for name in PARTITIONS},
        "runs": {},
        "errors": [],
        "skipped": [],
    }
    skipped = skipped_detectors(len(train))
    for method in methods:
        if method in skipped:
            result["skipped"].append(method)
            continue
        fit = capped(method, seed)
        try:
            detector = build(method, contamination, seed)
            found = detect(test, detector, fit_df=fit)
            result["runs"][method] = {
                "metrics": compute_metrics(y[partitions["test"]], found.flags, found.scores),
                "scores": found.scores.tolist(),
                "flags": found.flags.tolist(),
                "fit_rows": len(fit),
            }
        except Exception as error:
            result["errors"].append({"detector": method, "error": repr(error)})
    return result


def x_evaluate_frozen__mutmut_106(
    frame: pd.DataFrame, labels, partitions: dict, *, seed: int, methods: list[str]
) -> dict:
    """Run named detectors on unchanged positions with training-only preparation."""
    if (
        not methods
        or len(set(methods)) != len(methods)
        or set(methods) - set([*DETECTOR_NAMES, *DEEP_NAMES])
    ):
        raise ValueError("detectors must be explicit, unique row-level registry names")
    if type(seed) is not int or not 0 <= seed < 2**32:
        raise ValueError("seed must be a nonnegative 32-bit integer")
    prepared = prepare_frozen(frame, partitions)
    y = np.asarray(labels)
    if y.ndim != 1 or len(y) != len(frame) or set(np.unique(y)) - {0, 1}:
        raise ValueError("labels must be an aligned binary vector")
    for name in PARTITIONS:
        if set(np.unique(y[partitions[name]])) != {0, 1}:
            raise ValueError("both classes are required in every frozen partition")
    train, test = prepared["train"], prepared["test"]
    contamination = clip_contamination(float(y[partitions["train"]].mean()))
    result = {
        "protocol": PROTOCOL,
        "exploratory": True,
        "seed": seed,
        "partitions": {name: list(partitions[name]) for name in PARTITIONS},
        "preprocessing": prepared["fit"],
        "calibration": {"policy": "train_prevalence", "value": contamination},
        "prevalence": {name: float(y[partitions[name]].mean()) for name in PARTITIONS},
        "runs": {},
        "errors": [],
        "skipped": [],
    }
    skipped = skipped_detectors(len(train))
    for method in methods:
        if method in skipped:
            result["skipped"].append(method)
            continue
        fit = capped(train, seed)
        try:
            detector = build(method, contamination, seed)
            found = detect(test, detector, fit_df=fit)
            result["runs"][method] = {
                "metrics": compute_metrics(y[partitions["test"]], found.flags, found.scores),
                "scores": found.scores.tolist(),
                "flags": found.flags.tolist(),
                "fit_rows": len(fit),
            }
        except Exception as error:
            result["errors"].append({"detector": method, "error": repr(error)})
    return result


def x_evaluate_frozen__mutmut_107(
    frame: pd.DataFrame, labels, partitions: dict, *, seed: int, methods: list[str]
) -> dict:
    """Run named detectors on unchanged positions with training-only preparation."""
    if (
        not methods
        or len(set(methods)) != len(methods)
        or set(methods) - set([*DETECTOR_NAMES, *DEEP_NAMES])
    ):
        raise ValueError("detectors must be explicit, unique row-level registry names")
    if type(seed) is not int or not 0 <= seed < 2**32:
        raise ValueError("seed must be a nonnegative 32-bit integer")
    prepared = prepare_frozen(frame, partitions)
    y = np.asarray(labels)
    if y.ndim != 1 or len(y) != len(frame) or set(np.unique(y)) - {0, 1}:
        raise ValueError("labels must be an aligned binary vector")
    for name in PARTITIONS:
        if set(np.unique(y[partitions[name]])) != {0, 1}:
            raise ValueError("both classes are required in every frozen partition")
    train, test = prepared["train"], prepared["test"]
    contamination = clip_contamination(float(y[partitions["train"]].mean()))
    result = {
        "protocol": PROTOCOL,
        "exploratory": True,
        "seed": seed,
        "partitions": {name: list(partitions[name]) for name in PARTITIONS},
        "preprocessing": prepared["fit"],
        "calibration": {"policy": "train_prevalence", "value": contamination},
        "prevalence": {name: float(y[partitions[name]].mean()) for name in PARTITIONS},
        "runs": {},
        "errors": [],
        "skipped": [],
    }
    skipped = skipped_detectors(len(train))
    for method in methods:
        if method in skipped:
            result["skipped"].append(method)
            continue
        fit = capped(train, method, )
        try:
            detector = build(method, contamination, seed)
            found = detect(test, detector, fit_df=fit)
            result["runs"][method] = {
                "metrics": compute_metrics(y[partitions["test"]], found.flags, found.scores),
                "scores": found.scores.tolist(),
                "flags": found.flags.tolist(),
                "fit_rows": len(fit),
            }
        except Exception as error:
            result["errors"].append({"detector": method, "error": repr(error)})
    return result


def x_evaluate_frozen__mutmut_108(
    frame: pd.DataFrame, labels, partitions: dict, *, seed: int, methods: list[str]
) -> dict:
    """Run named detectors on unchanged positions with training-only preparation."""
    if (
        not methods
        or len(set(methods)) != len(methods)
        or set(methods) - set([*DETECTOR_NAMES, *DEEP_NAMES])
    ):
        raise ValueError("detectors must be explicit, unique row-level registry names")
    if type(seed) is not int or not 0 <= seed < 2**32:
        raise ValueError("seed must be a nonnegative 32-bit integer")
    prepared = prepare_frozen(frame, partitions)
    y = np.asarray(labels)
    if y.ndim != 1 or len(y) != len(frame) or set(np.unique(y)) - {0, 1}:
        raise ValueError("labels must be an aligned binary vector")
    for name in PARTITIONS:
        if set(np.unique(y[partitions[name]])) != {0, 1}:
            raise ValueError("both classes are required in every frozen partition")
    train, test = prepared["train"], prepared["test"]
    contamination = clip_contamination(float(y[partitions["train"]].mean()))
    result = {
        "protocol": PROTOCOL,
        "exploratory": True,
        "seed": seed,
        "partitions": {name: list(partitions[name]) for name in PARTITIONS},
        "preprocessing": prepared["fit"],
        "calibration": {"policy": "train_prevalence", "value": contamination},
        "prevalence": {name: float(y[partitions[name]].mean()) for name in PARTITIONS},
        "runs": {},
        "errors": [],
        "skipped": [],
    }
    skipped = skipped_detectors(len(train))
    for method in methods:
        if method in skipped:
            result["skipped"].append(method)
            continue
        fit = capped(train, method, seed)
        try:
            detector = None
            found = detect(test, detector, fit_df=fit)
            result["runs"][method] = {
                "metrics": compute_metrics(y[partitions["test"]], found.flags, found.scores),
                "scores": found.scores.tolist(),
                "flags": found.flags.tolist(),
                "fit_rows": len(fit),
            }
        except Exception as error:
            result["errors"].append({"detector": method, "error": repr(error)})
    return result


def x_evaluate_frozen__mutmut_109(
    frame: pd.DataFrame, labels, partitions: dict, *, seed: int, methods: list[str]
) -> dict:
    """Run named detectors on unchanged positions with training-only preparation."""
    if (
        not methods
        or len(set(methods)) != len(methods)
        or set(methods) - set([*DETECTOR_NAMES, *DEEP_NAMES])
    ):
        raise ValueError("detectors must be explicit, unique row-level registry names")
    if type(seed) is not int or not 0 <= seed < 2**32:
        raise ValueError("seed must be a nonnegative 32-bit integer")
    prepared = prepare_frozen(frame, partitions)
    y = np.asarray(labels)
    if y.ndim != 1 or len(y) != len(frame) or set(np.unique(y)) - {0, 1}:
        raise ValueError("labels must be an aligned binary vector")
    for name in PARTITIONS:
        if set(np.unique(y[partitions[name]])) != {0, 1}:
            raise ValueError("both classes are required in every frozen partition")
    train, test = prepared["train"], prepared["test"]
    contamination = clip_contamination(float(y[partitions["train"]].mean()))
    result = {
        "protocol": PROTOCOL,
        "exploratory": True,
        "seed": seed,
        "partitions": {name: list(partitions[name]) for name in PARTITIONS},
        "preprocessing": prepared["fit"],
        "calibration": {"policy": "train_prevalence", "value": contamination},
        "prevalence": {name: float(y[partitions[name]].mean()) for name in PARTITIONS},
        "runs": {},
        "errors": [],
        "skipped": [],
    }
    skipped = skipped_detectors(len(train))
    for method in methods:
        if method in skipped:
            result["skipped"].append(method)
            continue
        fit = capped(train, method, seed)
        try:
            detector = build(None, contamination, seed)
            found = detect(test, detector, fit_df=fit)
            result["runs"][method] = {
                "metrics": compute_metrics(y[partitions["test"]], found.flags, found.scores),
                "scores": found.scores.tolist(),
                "flags": found.flags.tolist(),
                "fit_rows": len(fit),
            }
        except Exception as error:
            result["errors"].append({"detector": method, "error": repr(error)})
    return result


def x_evaluate_frozen__mutmut_110(
    frame: pd.DataFrame, labels, partitions: dict, *, seed: int, methods: list[str]
) -> dict:
    """Run named detectors on unchanged positions with training-only preparation."""
    if (
        not methods
        or len(set(methods)) != len(methods)
        or set(methods) - set([*DETECTOR_NAMES, *DEEP_NAMES])
    ):
        raise ValueError("detectors must be explicit, unique row-level registry names")
    if type(seed) is not int or not 0 <= seed < 2**32:
        raise ValueError("seed must be a nonnegative 32-bit integer")
    prepared = prepare_frozen(frame, partitions)
    y = np.asarray(labels)
    if y.ndim != 1 or len(y) != len(frame) or set(np.unique(y)) - {0, 1}:
        raise ValueError("labels must be an aligned binary vector")
    for name in PARTITIONS:
        if set(np.unique(y[partitions[name]])) != {0, 1}:
            raise ValueError("both classes are required in every frozen partition")
    train, test = prepared["train"], prepared["test"]
    contamination = clip_contamination(float(y[partitions["train"]].mean()))
    result = {
        "protocol": PROTOCOL,
        "exploratory": True,
        "seed": seed,
        "partitions": {name: list(partitions[name]) for name in PARTITIONS},
        "preprocessing": prepared["fit"],
        "calibration": {"policy": "train_prevalence", "value": contamination},
        "prevalence": {name: float(y[partitions[name]].mean()) for name in PARTITIONS},
        "runs": {},
        "errors": [],
        "skipped": [],
    }
    skipped = skipped_detectors(len(train))
    for method in methods:
        if method in skipped:
            result["skipped"].append(method)
            continue
        fit = capped(train, method, seed)
        try:
            detector = build(method, None, seed)
            found = detect(test, detector, fit_df=fit)
            result["runs"][method] = {
                "metrics": compute_metrics(y[partitions["test"]], found.flags, found.scores),
                "scores": found.scores.tolist(),
                "flags": found.flags.tolist(),
                "fit_rows": len(fit),
            }
        except Exception as error:
            result["errors"].append({"detector": method, "error": repr(error)})
    return result


def x_evaluate_frozen__mutmut_111(
    frame: pd.DataFrame, labels, partitions: dict, *, seed: int, methods: list[str]
) -> dict:
    """Run named detectors on unchanged positions with training-only preparation."""
    if (
        not methods
        or len(set(methods)) != len(methods)
        or set(methods) - set([*DETECTOR_NAMES, *DEEP_NAMES])
    ):
        raise ValueError("detectors must be explicit, unique row-level registry names")
    if type(seed) is not int or not 0 <= seed < 2**32:
        raise ValueError("seed must be a nonnegative 32-bit integer")
    prepared = prepare_frozen(frame, partitions)
    y = np.asarray(labels)
    if y.ndim != 1 or len(y) != len(frame) or set(np.unique(y)) - {0, 1}:
        raise ValueError("labels must be an aligned binary vector")
    for name in PARTITIONS:
        if set(np.unique(y[partitions[name]])) != {0, 1}:
            raise ValueError("both classes are required in every frozen partition")
    train, test = prepared["train"], prepared["test"]
    contamination = clip_contamination(float(y[partitions["train"]].mean()))
    result = {
        "protocol": PROTOCOL,
        "exploratory": True,
        "seed": seed,
        "partitions": {name: list(partitions[name]) for name in PARTITIONS},
        "preprocessing": prepared["fit"],
        "calibration": {"policy": "train_prevalence", "value": contamination},
        "prevalence": {name: float(y[partitions[name]].mean()) for name in PARTITIONS},
        "runs": {},
        "errors": [],
        "skipped": [],
    }
    skipped = skipped_detectors(len(train))
    for method in methods:
        if method in skipped:
            result["skipped"].append(method)
            continue
        fit = capped(train, method, seed)
        try:
            detector = build(method, contamination, None)
            found = detect(test, detector, fit_df=fit)
            result["runs"][method] = {
                "metrics": compute_metrics(y[partitions["test"]], found.flags, found.scores),
                "scores": found.scores.tolist(),
                "flags": found.flags.tolist(),
                "fit_rows": len(fit),
            }
        except Exception as error:
            result["errors"].append({"detector": method, "error": repr(error)})
    return result


def x_evaluate_frozen__mutmut_112(
    frame: pd.DataFrame, labels, partitions: dict, *, seed: int, methods: list[str]
) -> dict:
    """Run named detectors on unchanged positions with training-only preparation."""
    if (
        not methods
        or len(set(methods)) != len(methods)
        or set(methods) - set([*DETECTOR_NAMES, *DEEP_NAMES])
    ):
        raise ValueError("detectors must be explicit, unique row-level registry names")
    if type(seed) is not int or not 0 <= seed < 2**32:
        raise ValueError("seed must be a nonnegative 32-bit integer")
    prepared = prepare_frozen(frame, partitions)
    y = np.asarray(labels)
    if y.ndim != 1 or len(y) != len(frame) or set(np.unique(y)) - {0, 1}:
        raise ValueError("labels must be an aligned binary vector")
    for name in PARTITIONS:
        if set(np.unique(y[partitions[name]])) != {0, 1}:
            raise ValueError("both classes are required in every frozen partition")
    train, test = prepared["train"], prepared["test"]
    contamination = clip_contamination(float(y[partitions["train"]].mean()))
    result = {
        "protocol": PROTOCOL,
        "exploratory": True,
        "seed": seed,
        "partitions": {name: list(partitions[name]) for name in PARTITIONS},
        "preprocessing": prepared["fit"],
        "calibration": {"policy": "train_prevalence", "value": contamination},
        "prevalence": {name: float(y[partitions[name]].mean()) for name in PARTITIONS},
        "runs": {},
        "errors": [],
        "skipped": [],
    }
    skipped = skipped_detectors(len(train))
    for method in methods:
        if method in skipped:
            result["skipped"].append(method)
            continue
        fit = capped(train, method, seed)
        try:
            detector = build(contamination, seed)
            found = detect(test, detector, fit_df=fit)
            result["runs"][method] = {
                "metrics": compute_metrics(y[partitions["test"]], found.flags, found.scores),
                "scores": found.scores.tolist(),
                "flags": found.flags.tolist(),
                "fit_rows": len(fit),
            }
        except Exception as error:
            result["errors"].append({"detector": method, "error": repr(error)})
    return result


def x_evaluate_frozen__mutmut_113(
    frame: pd.DataFrame, labels, partitions: dict, *, seed: int, methods: list[str]
) -> dict:
    """Run named detectors on unchanged positions with training-only preparation."""
    if (
        not methods
        or len(set(methods)) != len(methods)
        or set(methods) - set([*DETECTOR_NAMES, *DEEP_NAMES])
    ):
        raise ValueError("detectors must be explicit, unique row-level registry names")
    if type(seed) is not int or not 0 <= seed < 2**32:
        raise ValueError("seed must be a nonnegative 32-bit integer")
    prepared = prepare_frozen(frame, partitions)
    y = np.asarray(labels)
    if y.ndim != 1 or len(y) != len(frame) or set(np.unique(y)) - {0, 1}:
        raise ValueError("labels must be an aligned binary vector")
    for name in PARTITIONS:
        if set(np.unique(y[partitions[name]])) != {0, 1}:
            raise ValueError("both classes are required in every frozen partition")
    train, test = prepared["train"], prepared["test"]
    contamination = clip_contamination(float(y[partitions["train"]].mean()))
    result = {
        "protocol": PROTOCOL,
        "exploratory": True,
        "seed": seed,
        "partitions": {name: list(partitions[name]) for name in PARTITIONS},
        "preprocessing": prepared["fit"],
        "calibration": {"policy": "train_prevalence", "value": contamination},
        "prevalence": {name: float(y[partitions[name]].mean()) for name in PARTITIONS},
        "runs": {},
        "errors": [],
        "skipped": [],
    }
    skipped = skipped_detectors(len(train))
    for method in methods:
        if method in skipped:
            result["skipped"].append(method)
            continue
        fit = capped(train, method, seed)
        try:
            detector = build(method, seed)
            found = detect(test, detector, fit_df=fit)
            result["runs"][method] = {
                "metrics": compute_metrics(y[partitions["test"]], found.flags, found.scores),
                "scores": found.scores.tolist(),
                "flags": found.flags.tolist(),
                "fit_rows": len(fit),
            }
        except Exception as error:
            result["errors"].append({"detector": method, "error": repr(error)})
    return result


def x_evaluate_frozen__mutmut_114(
    frame: pd.DataFrame, labels, partitions: dict, *, seed: int, methods: list[str]
) -> dict:
    """Run named detectors on unchanged positions with training-only preparation."""
    if (
        not methods
        or len(set(methods)) != len(methods)
        or set(methods) - set([*DETECTOR_NAMES, *DEEP_NAMES])
    ):
        raise ValueError("detectors must be explicit, unique row-level registry names")
    if type(seed) is not int or not 0 <= seed < 2**32:
        raise ValueError("seed must be a nonnegative 32-bit integer")
    prepared = prepare_frozen(frame, partitions)
    y = np.asarray(labels)
    if y.ndim != 1 or len(y) != len(frame) or set(np.unique(y)) - {0, 1}:
        raise ValueError("labels must be an aligned binary vector")
    for name in PARTITIONS:
        if set(np.unique(y[partitions[name]])) != {0, 1}:
            raise ValueError("both classes are required in every frozen partition")
    train, test = prepared["train"], prepared["test"]
    contamination = clip_contamination(float(y[partitions["train"]].mean()))
    result = {
        "protocol": PROTOCOL,
        "exploratory": True,
        "seed": seed,
        "partitions": {name: list(partitions[name]) for name in PARTITIONS},
        "preprocessing": prepared["fit"],
        "calibration": {"policy": "train_prevalence", "value": contamination},
        "prevalence": {name: float(y[partitions[name]].mean()) for name in PARTITIONS},
        "runs": {},
        "errors": [],
        "skipped": [],
    }
    skipped = skipped_detectors(len(train))
    for method in methods:
        if method in skipped:
            result["skipped"].append(method)
            continue
        fit = capped(train, method, seed)
        try:
            detector = build(method, contamination, )
            found = detect(test, detector, fit_df=fit)
            result["runs"][method] = {
                "metrics": compute_metrics(y[partitions["test"]], found.flags, found.scores),
                "scores": found.scores.tolist(),
                "flags": found.flags.tolist(),
                "fit_rows": len(fit),
            }
        except Exception as error:
            result["errors"].append({"detector": method, "error": repr(error)})
    return result


def x_evaluate_frozen__mutmut_115(
    frame: pd.DataFrame, labels, partitions: dict, *, seed: int, methods: list[str]
) -> dict:
    """Run named detectors on unchanged positions with training-only preparation."""
    if (
        not methods
        or len(set(methods)) != len(methods)
        or set(methods) - set([*DETECTOR_NAMES, *DEEP_NAMES])
    ):
        raise ValueError("detectors must be explicit, unique row-level registry names")
    if type(seed) is not int or not 0 <= seed < 2**32:
        raise ValueError("seed must be a nonnegative 32-bit integer")
    prepared = prepare_frozen(frame, partitions)
    y = np.asarray(labels)
    if y.ndim != 1 or len(y) != len(frame) or set(np.unique(y)) - {0, 1}:
        raise ValueError("labels must be an aligned binary vector")
    for name in PARTITIONS:
        if set(np.unique(y[partitions[name]])) != {0, 1}:
            raise ValueError("both classes are required in every frozen partition")
    train, test = prepared["train"], prepared["test"]
    contamination = clip_contamination(float(y[partitions["train"]].mean()))
    result = {
        "protocol": PROTOCOL,
        "exploratory": True,
        "seed": seed,
        "partitions": {name: list(partitions[name]) for name in PARTITIONS},
        "preprocessing": prepared["fit"],
        "calibration": {"policy": "train_prevalence", "value": contamination},
        "prevalence": {name: float(y[partitions[name]].mean()) for name in PARTITIONS},
        "runs": {},
        "errors": [],
        "skipped": [],
    }
    skipped = skipped_detectors(len(train))
    for method in methods:
        if method in skipped:
            result["skipped"].append(method)
            continue
        fit = capped(train, method, seed)
        try:
            detector = build(method, contamination, seed)
            found = None
            result["runs"][method] = {
                "metrics": compute_metrics(y[partitions["test"]], found.flags, found.scores),
                "scores": found.scores.tolist(),
                "flags": found.flags.tolist(),
                "fit_rows": len(fit),
            }
        except Exception as error:
            result["errors"].append({"detector": method, "error": repr(error)})
    return result


def x_evaluate_frozen__mutmut_116(
    frame: pd.DataFrame, labels, partitions: dict, *, seed: int, methods: list[str]
) -> dict:
    """Run named detectors on unchanged positions with training-only preparation."""
    if (
        not methods
        or len(set(methods)) != len(methods)
        or set(methods) - set([*DETECTOR_NAMES, *DEEP_NAMES])
    ):
        raise ValueError("detectors must be explicit, unique row-level registry names")
    if type(seed) is not int or not 0 <= seed < 2**32:
        raise ValueError("seed must be a nonnegative 32-bit integer")
    prepared = prepare_frozen(frame, partitions)
    y = np.asarray(labels)
    if y.ndim != 1 or len(y) != len(frame) or set(np.unique(y)) - {0, 1}:
        raise ValueError("labels must be an aligned binary vector")
    for name in PARTITIONS:
        if set(np.unique(y[partitions[name]])) != {0, 1}:
            raise ValueError("both classes are required in every frozen partition")
    train, test = prepared["train"], prepared["test"]
    contamination = clip_contamination(float(y[partitions["train"]].mean()))
    result = {
        "protocol": PROTOCOL,
        "exploratory": True,
        "seed": seed,
        "partitions": {name: list(partitions[name]) for name in PARTITIONS},
        "preprocessing": prepared["fit"],
        "calibration": {"policy": "train_prevalence", "value": contamination},
        "prevalence": {name: float(y[partitions[name]].mean()) for name in PARTITIONS},
        "runs": {},
        "errors": [],
        "skipped": [],
    }
    skipped = skipped_detectors(len(train))
    for method in methods:
        if method in skipped:
            result["skipped"].append(method)
            continue
        fit = capped(train, method, seed)
        try:
            detector = build(method, contamination, seed)
            found = detect(None, detector, fit_df=fit)
            result["runs"][method] = {
                "metrics": compute_metrics(y[partitions["test"]], found.flags, found.scores),
                "scores": found.scores.tolist(),
                "flags": found.flags.tolist(),
                "fit_rows": len(fit),
            }
        except Exception as error:
            result["errors"].append({"detector": method, "error": repr(error)})
    return result


def x_evaluate_frozen__mutmut_117(
    frame: pd.DataFrame, labels, partitions: dict, *, seed: int, methods: list[str]
) -> dict:
    """Run named detectors on unchanged positions with training-only preparation."""
    if (
        not methods
        or len(set(methods)) != len(methods)
        or set(methods) - set([*DETECTOR_NAMES, *DEEP_NAMES])
    ):
        raise ValueError("detectors must be explicit, unique row-level registry names")
    if type(seed) is not int or not 0 <= seed < 2**32:
        raise ValueError("seed must be a nonnegative 32-bit integer")
    prepared = prepare_frozen(frame, partitions)
    y = np.asarray(labels)
    if y.ndim != 1 or len(y) != len(frame) or set(np.unique(y)) - {0, 1}:
        raise ValueError("labels must be an aligned binary vector")
    for name in PARTITIONS:
        if set(np.unique(y[partitions[name]])) != {0, 1}:
            raise ValueError("both classes are required in every frozen partition")
    train, test = prepared["train"], prepared["test"]
    contamination = clip_contamination(float(y[partitions["train"]].mean()))
    result = {
        "protocol": PROTOCOL,
        "exploratory": True,
        "seed": seed,
        "partitions": {name: list(partitions[name]) for name in PARTITIONS},
        "preprocessing": prepared["fit"],
        "calibration": {"policy": "train_prevalence", "value": contamination},
        "prevalence": {name: float(y[partitions[name]].mean()) for name in PARTITIONS},
        "runs": {},
        "errors": [],
        "skipped": [],
    }
    skipped = skipped_detectors(len(train))
    for method in methods:
        if method in skipped:
            result["skipped"].append(method)
            continue
        fit = capped(train, method, seed)
        try:
            detector = build(method, contamination, seed)
            found = detect(test, None, fit_df=fit)
            result["runs"][method] = {
                "metrics": compute_metrics(y[partitions["test"]], found.flags, found.scores),
                "scores": found.scores.tolist(),
                "flags": found.flags.tolist(),
                "fit_rows": len(fit),
            }
        except Exception as error:
            result["errors"].append({"detector": method, "error": repr(error)})
    return result


def x_evaluate_frozen__mutmut_118(
    frame: pd.DataFrame, labels, partitions: dict, *, seed: int, methods: list[str]
) -> dict:
    """Run named detectors on unchanged positions with training-only preparation."""
    if (
        not methods
        or len(set(methods)) != len(methods)
        or set(methods) - set([*DETECTOR_NAMES, *DEEP_NAMES])
    ):
        raise ValueError("detectors must be explicit, unique row-level registry names")
    if type(seed) is not int or not 0 <= seed < 2**32:
        raise ValueError("seed must be a nonnegative 32-bit integer")
    prepared = prepare_frozen(frame, partitions)
    y = np.asarray(labels)
    if y.ndim != 1 or len(y) != len(frame) or set(np.unique(y)) - {0, 1}:
        raise ValueError("labels must be an aligned binary vector")
    for name in PARTITIONS:
        if set(np.unique(y[partitions[name]])) != {0, 1}:
            raise ValueError("both classes are required in every frozen partition")
    train, test = prepared["train"], prepared["test"]
    contamination = clip_contamination(float(y[partitions["train"]].mean()))
    result = {
        "protocol": PROTOCOL,
        "exploratory": True,
        "seed": seed,
        "partitions": {name: list(partitions[name]) for name in PARTITIONS},
        "preprocessing": prepared["fit"],
        "calibration": {"policy": "train_prevalence", "value": contamination},
        "prevalence": {name: float(y[partitions[name]].mean()) for name in PARTITIONS},
        "runs": {},
        "errors": [],
        "skipped": [],
    }
    skipped = skipped_detectors(len(train))
    for method in methods:
        if method in skipped:
            result["skipped"].append(method)
            continue
        fit = capped(train, method, seed)
        try:
            detector = build(method, contamination, seed)
            found = detect(test, detector, fit_df=None)
            result["runs"][method] = {
                "metrics": compute_metrics(y[partitions["test"]], found.flags, found.scores),
                "scores": found.scores.tolist(),
                "flags": found.flags.tolist(),
                "fit_rows": len(fit),
            }
        except Exception as error:
            result["errors"].append({"detector": method, "error": repr(error)})
    return result


def x_evaluate_frozen__mutmut_119(
    frame: pd.DataFrame, labels, partitions: dict, *, seed: int, methods: list[str]
) -> dict:
    """Run named detectors on unchanged positions with training-only preparation."""
    if (
        not methods
        or len(set(methods)) != len(methods)
        or set(methods) - set([*DETECTOR_NAMES, *DEEP_NAMES])
    ):
        raise ValueError("detectors must be explicit, unique row-level registry names")
    if type(seed) is not int or not 0 <= seed < 2**32:
        raise ValueError("seed must be a nonnegative 32-bit integer")
    prepared = prepare_frozen(frame, partitions)
    y = np.asarray(labels)
    if y.ndim != 1 or len(y) != len(frame) or set(np.unique(y)) - {0, 1}:
        raise ValueError("labels must be an aligned binary vector")
    for name in PARTITIONS:
        if set(np.unique(y[partitions[name]])) != {0, 1}:
            raise ValueError("both classes are required in every frozen partition")
    train, test = prepared["train"], prepared["test"]
    contamination = clip_contamination(float(y[partitions["train"]].mean()))
    result = {
        "protocol": PROTOCOL,
        "exploratory": True,
        "seed": seed,
        "partitions": {name: list(partitions[name]) for name in PARTITIONS},
        "preprocessing": prepared["fit"],
        "calibration": {"policy": "train_prevalence", "value": contamination},
        "prevalence": {name: float(y[partitions[name]].mean()) for name in PARTITIONS},
        "runs": {},
        "errors": [],
        "skipped": [],
    }
    skipped = skipped_detectors(len(train))
    for method in methods:
        if method in skipped:
            result["skipped"].append(method)
            continue
        fit = capped(train, method, seed)
        try:
            detector = build(method, contamination, seed)
            found = detect(detector, fit_df=fit)
            result["runs"][method] = {
                "metrics": compute_metrics(y[partitions["test"]], found.flags, found.scores),
                "scores": found.scores.tolist(),
                "flags": found.flags.tolist(),
                "fit_rows": len(fit),
            }
        except Exception as error:
            result["errors"].append({"detector": method, "error": repr(error)})
    return result


def x_evaluate_frozen__mutmut_120(
    frame: pd.DataFrame, labels, partitions: dict, *, seed: int, methods: list[str]
) -> dict:
    """Run named detectors on unchanged positions with training-only preparation."""
    if (
        not methods
        or len(set(methods)) != len(methods)
        or set(methods) - set([*DETECTOR_NAMES, *DEEP_NAMES])
    ):
        raise ValueError("detectors must be explicit, unique row-level registry names")
    if type(seed) is not int or not 0 <= seed < 2**32:
        raise ValueError("seed must be a nonnegative 32-bit integer")
    prepared = prepare_frozen(frame, partitions)
    y = np.asarray(labels)
    if y.ndim != 1 or len(y) != len(frame) or set(np.unique(y)) - {0, 1}:
        raise ValueError("labels must be an aligned binary vector")
    for name in PARTITIONS:
        if set(np.unique(y[partitions[name]])) != {0, 1}:
            raise ValueError("both classes are required in every frozen partition")
    train, test = prepared["train"], prepared["test"]
    contamination = clip_contamination(float(y[partitions["train"]].mean()))
    result = {
        "protocol": PROTOCOL,
        "exploratory": True,
        "seed": seed,
        "partitions": {name: list(partitions[name]) for name in PARTITIONS},
        "preprocessing": prepared["fit"],
        "calibration": {"policy": "train_prevalence", "value": contamination},
        "prevalence": {name: float(y[partitions[name]].mean()) for name in PARTITIONS},
        "runs": {},
        "errors": [],
        "skipped": [],
    }
    skipped = skipped_detectors(len(train))
    for method in methods:
        if method in skipped:
            result["skipped"].append(method)
            continue
        fit = capped(train, method, seed)
        try:
            detector = build(method, contamination, seed)
            found = detect(test, fit_df=fit)
            result["runs"][method] = {
                "metrics": compute_metrics(y[partitions["test"]], found.flags, found.scores),
                "scores": found.scores.tolist(),
                "flags": found.flags.tolist(),
                "fit_rows": len(fit),
            }
        except Exception as error:
            result["errors"].append({"detector": method, "error": repr(error)})
    return result


def x_evaluate_frozen__mutmut_121(
    frame: pd.DataFrame, labels, partitions: dict, *, seed: int, methods: list[str]
) -> dict:
    """Run named detectors on unchanged positions with training-only preparation."""
    if (
        not methods
        or len(set(methods)) != len(methods)
        or set(methods) - set([*DETECTOR_NAMES, *DEEP_NAMES])
    ):
        raise ValueError("detectors must be explicit, unique row-level registry names")
    if type(seed) is not int or not 0 <= seed < 2**32:
        raise ValueError("seed must be a nonnegative 32-bit integer")
    prepared = prepare_frozen(frame, partitions)
    y = np.asarray(labels)
    if y.ndim != 1 or len(y) != len(frame) or set(np.unique(y)) - {0, 1}:
        raise ValueError("labels must be an aligned binary vector")
    for name in PARTITIONS:
        if set(np.unique(y[partitions[name]])) != {0, 1}:
            raise ValueError("both classes are required in every frozen partition")
    train, test = prepared["train"], prepared["test"]
    contamination = clip_contamination(float(y[partitions["train"]].mean()))
    result = {
        "protocol": PROTOCOL,
        "exploratory": True,
        "seed": seed,
        "partitions": {name: list(partitions[name]) for name in PARTITIONS},
        "preprocessing": prepared["fit"],
        "calibration": {"policy": "train_prevalence", "value": contamination},
        "prevalence": {name: float(y[partitions[name]].mean()) for name in PARTITIONS},
        "runs": {},
        "errors": [],
        "skipped": [],
    }
    skipped = skipped_detectors(len(train))
    for method in methods:
        if method in skipped:
            result["skipped"].append(method)
            continue
        fit = capped(train, method, seed)
        try:
            detector = build(method, contamination, seed)
            found = detect(test, detector, )
            result["runs"][method] = {
                "metrics": compute_metrics(y[partitions["test"]], found.flags, found.scores),
                "scores": found.scores.tolist(),
                "flags": found.flags.tolist(),
                "fit_rows": len(fit),
            }
        except Exception as error:
            result["errors"].append({"detector": method, "error": repr(error)})
    return result


def x_evaluate_frozen__mutmut_122(
    frame: pd.DataFrame, labels, partitions: dict, *, seed: int, methods: list[str]
) -> dict:
    """Run named detectors on unchanged positions with training-only preparation."""
    if (
        not methods
        or len(set(methods)) != len(methods)
        or set(methods) - set([*DETECTOR_NAMES, *DEEP_NAMES])
    ):
        raise ValueError("detectors must be explicit, unique row-level registry names")
    if type(seed) is not int or not 0 <= seed < 2**32:
        raise ValueError("seed must be a nonnegative 32-bit integer")
    prepared = prepare_frozen(frame, partitions)
    y = np.asarray(labels)
    if y.ndim != 1 or len(y) != len(frame) or set(np.unique(y)) - {0, 1}:
        raise ValueError("labels must be an aligned binary vector")
    for name in PARTITIONS:
        if set(np.unique(y[partitions[name]])) != {0, 1}:
            raise ValueError("both classes are required in every frozen partition")
    train, test = prepared["train"], prepared["test"]
    contamination = clip_contamination(float(y[partitions["train"]].mean()))
    result = {
        "protocol": PROTOCOL,
        "exploratory": True,
        "seed": seed,
        "partitions": {name: list(partitions[name]) for name in PARTITIONS},
        "preprocessing": prepared["fit"],
        "calibration": {"policy": "train_prevalence", "value": contamination},
        "prevalence": {name: float(y[partitions[name]].mean()) for name in PARTITIONS},
        "runs": {},
        "errors": [],
        "skipped": [],
    }
    skipped = skipped_detectors(len(train))
    for method in methods:
        if method in skipped:
            result["skipped"].append(method)
            continue
        fit = capped(train, method, seed)
        try:
            detector = build(method, contamination, seed)
            found = detect(test, detector, fit_df=fit)
            result["runs"][method] = None
        except Exception as error:
            result["errors"].append({"detector": method, "error": repr(error)})
    return result


def x_evaluate_frozen__mutmut_123(
    frame: pd.DataFrame, labels, partitions: dict, *, seed: int, methods: list[str]
) -> dict:
    """Run named detectors on unchanged positions with training-only preparation."""
    if (
        not methods
        or len(set(methods)) != len(methods)
        or set(methods) - set([*DETECTOR_NAMES, *DEEP_NAMES])
    ):
        raise ValueError("detectors must be explicit, unique row-level registry names")
    if type(seed) is not int or not 0 <= seed < 2**32:
        raise ValueError("seed must be a nonnegative 32-bit integer")
    prepared = prepare_frozen(frame, partitions)
    y = np.asarray(labels)
    if y.ndim != 1 or len(y) != len(frame) or set(np.unique(y)) - {0, 1}:
        raise ValueError("labels must be an aligned binary vector")
    for name in PARTITIONS:
        if set(np.unique(y[partitions[name]])) != {0, 1}:
            raise ValueError("both classes are required in every frozen partition")
    train, test = prepared["train"], prepared["test"]
    contamination = clip_contamination(float(y[partitions["train"]].mean()))
    result = {
        "protocol": PROTOCOL,
        "exploratory": True,
        "seed": seed,
        "partitions": {name: list(partitions[name]) for name in PARTITIONS},
        "preprocessing": prepared["fit"],
        "calibration": {"policy": "train_prevalence", "value": contamination},
        "prevalence": {name: float(y[partitions[name]].mean()) for name in PARTITIONS},
        "runs": {},
        "errors": [],
        "skipped": [],
    }
    skipped = skipped_detectors(len(train))
    for method in methods:
        if method in skipped:
            result["skipped"].append(method)
            continue
        fit = capped(train, method, seed)
        try:
            detector = build(method, contamination, seed)
            found = detect(test, detector, fit_df=fit)
            result["XXrunsXX"][method] = {
                "metrics": compute_metrics(y[partitions["test"]], found.flags, found.scores),
                "scores": found.scores.tolist(),
                "flags": found.flags.tolist(),
                "fit_rows": len(fit),
            }
        except Exception as error:
            result["errors"].append({"detector": method, "error": repr(error)})
    return result


def x_evaluate_frozen__mutmut_124(
    frame: pd.DataFrame, labels, partitions: dict, *, seed: int, methods: list[str]
) -> dict:
    """Run named detectors on unchanged positions with training-only preparation."""
    if (
        not methods
        or len(set(methods)) != len(methods)
        or set(methods) - set([*DETECTOR_NAMES, *DEEP_NAMES])
    ):
        raise ValueError("detectors must be explicit, unique row-level registry names")
    if type(seed) is not int or not 0 <= seed < 2**32:
        raise ValueError("seed must be a nonnegative 32-bit integer")
    prepared = prepare_frozen(frame, partitions)
    y = np.asarray(labels)
    if y.ndim != 1 or len(y) != len(frame) or set(np.unique(y)) - {0, 1}:
        raise ValueError("labels must be an aligned binary vector")
    for name in PARTITIONS:
        if set(np.unique(y[partitions[name]])) != {0, 1}:
            raise ValueError("both classes are required in every frozen partition")
    train, test = prepared["train"], prepared["test"]
    contamination = clip_contamination(float(y[partitions["train"]].mean()))
    result = {
        "protocol": PROTOCOL,
        "exploratory": True,
        "seed": seed,
        "partitions": {name: list(partitions[name]) for name in PARTITIONS},
        "preprocessing": prepared["fit"],
        "calibration": {"policy": "train_prevalence", "value": contamination},
        "prevalence": {name: float(y[partitions[name]].mean()) for name in PARTITIONS},
        "runs": {},
        "errors": [],
        "skipped": [],
    }
    skipped = skipped_detectors(len(train))
    for method in methods:
        if method in skipped:
            result["skipped"].append(method)
            continue
        fit = capped(train, method, seed)
        try:
            detector = build(method, contamination, seed)
            found = detect(test, detector, fit_df=fit)
            result["RUNS"][method] = {
                "metrics": compute_metrics(y[partitions["test"]], found.flags, found.scores),
                "scores": found.scores.tolist(),
                "flags": found.flags.tolist(),
                "fit_rows": len(fit),
            }
        except Exception as error:
            result["errors"].append({"detector": method, "error": repr(error)})
    return result


def x_evaluate_frozen__mutmut_125(
    frame: pd.DataFrame, labels, partitions: dict, *, seed: int, methods: list[str]
) -> dict:
    """Run named detectors on unchanged positions with training-only preparation."""
    if (
        not methods
        or len(set(methods)) != len(methods)
        or set(methods) - set([*DETECTOR_NAMES, *DEEP_NAMES])
    ):
        raise ValueError("detectors must be explicit, unique row-level registry names")
    if type(seed) is not int or not 0 <= seed < 2**32:
        raise ValueError("seed must be a nonnegative 32-bit integer")
    prepared = prepare_frozen(frame, partitions)
    y = np.asarray(labels)
    if y.ndim != 1 or len(y) != len(frame) or set(np.unique(y)) - {0, 1}:
        raise ValueError("labels must be an aligned binary vector")
    for name in PARTITIONS:
        if set(np.unique(y[partitions[name]])) != {0, 1}:
            raise ValueError("both classes are required in every frozen partition")
    train, test = prepared["train"], prepared["test"]
    contamination = clip_contamination(float(y[partitions["train"]].mean()))
    result = {
        "protocol": PROTOCOL,
        "exploratory": True,
        "seed": seed,
        "partitions": {name: list(partitions[name]) for name in PARTITIONS},
        "preprocessing": prepared["fit"],
        "calibration": {"policy": "train_prevalence", "value": contamination},
        "prevalence": {name: float(y[partitions[name]].mean()) for name in PARTITIONS},
        "runs": {},
        "errors": [],
        "skipped": [],
    }
    skipped = skipped_detectors(len(train))
    for method in methods:
        if method in skipped:
            result["skipped"].append(method)
            continue
        fit = capped(train, method, seed)
        try:
            detector = build(method, contamination, seed)
            found = detect(test, detector, fit_df=fit)
            result["runs"][method] = {
                "XXmetricsXX": compute_metrics(y[partitions["test"]], found.flags, found.scores),
                "scores": found.scores.tolist(),
                "flags": found.flags.tolist(),
                "fit_rows": len(fit),
            }
        except Exception as error:
            result["errors"].append({"detector": method, "error": repr(error)})
    return result


def x_evaluate_frozen__mutmut_126(
    frame: pd.DataFrame, labels, partitions: dict, *, seed: int, methods: list[str]
) -> dict:
    """Run named detectors on unchanged positions with training-only preparation."""
    if (
        not methods
        or len(set(methods)) != len(methods)
        or set(methods) - set([*DETECTOR_NAMES, *DEEP_NAMES])
    ):
        raise ValueError("detectors must be explicit, unique row-level registry names")
    if type(seed) is not int or not 0 <= seed < 2**32:
        raise ValueError("seed must be a nonnegative 32-bit integer")
    prepared = prepare_frozen(frame, partitions)
    y = np.asarray(labels)
    if y.ndim != 1 or len(y) != len(frame) or set(np.unique(y)) - {0, 1}:
        raise ValueError("labels must be an aligned binary vector")
    for name in PARTITIONS:
        if set(np.unique(y[partitions[name]])) != {0, 1}:
            raise ValueError("both classes are required in every frozen partition")
    train, test = prepared["train"], prepared["test"]
    contamination = clip_contamination(float(y[partitions["train"]].mean()))
    result = {
        "protocol": PROTOCOL,
        "exploratory": True,
        "seed": seed,
        "partitions": {name: list(partitions[name]) for name in PARTITIONS},
        "preprocessing": prepared["fit"],
        "calibration": {"policy": "train_prevalence", "value": contamination},
        "prevalence": {name: float(y[partitions[name]].mean()) for name in PARTITIONS},
        "runs": {},
        "errors": [],
        "skipped": [],
    }
    skipped = skipped_detectors(len(train))
    for method in methods:
        if method in skipped:
            result["skipped"].append(method)
            continue
        fit = capped(train, method, seed)
        try:
            detector = build(method, contamination, seed)
            found = detect(test, detector, fit_df=fit)
            result["runs"][method] = {
                "METRICS": compute_metrics(y[partitions["test"]], found.flags, found.scores),
                "scores": found.scores.tolist(),
                "flags": found.flags.tolist(),
                "fit_rows": len(fit),
            }
        except Exception as error:
            result["errors"].append({"detector": method, "error": repr(error)})
    return result


def x_evaluate_frozen__mutmut_127(
    frame: pd.DataFrame, labels, partitions: dict, *, seed: int, methods: list[str]
) -> dict:
    """Run named detectors on unchanged positions with training-only preparation."""
    if (
        not methods
        or len(set(methods)) != len(methods)
        or set(methods) - set([*DETECTOR_NAMES, *DEEP_NAMES])
    ):
        raise ValueError("detectors must be explicit, unique row-level registry names")
    if type(seed) is not int or not 0 <= seed < 2**32:
        raise ValueError("seed must be a nonnegative 32-bit integer")
    prepared = prepare_frozen(frame, partitions)
    y = np.asarray(labels)
    if y.ndim != 1 or len(y) != len(frame) or set(np.unique(y)) - {0, 1}:
        raise ValueError("labels must be an aligned binary vector")
    for name in PARTITIONS:
        if set(np.unique(y[partitions[name]])) != {0, 1}:
            raise ValueError("both classes are required in every frozen partition")
    train, test = prepared["train"], prepared["test"]
    contamination = clip_contamination(float(y[partitions["train"]].mean()))
    result = {
        "protocol": PROTOCOL,
        "exploratory": True,
        "seed": seed,
        "partitions": {name: list(partitions[name]) for name in PARTITIONS},
        "preprocessing": prepared["fit"],
        "calibration": {"policy": "train_prevalence", "value": contamination},
        "prevalence": {name: float(y[partitions[name]].mean()) for name in PARTITIONS},
        "runs": {},
        "errors": [],
        "skipped": [],
    }
    skipped = skipped_detectors(len(train))
    for method in methods:
        if method in skipped:
            result["skipped"].append(method)
            continue
        fit = capped(train, method, seed)
        try:
            detector = build(method, contamination, seed)
            found = detect(test, detector, fit_df=fit)
            result["runs"][method] = {
                "metrics": compute_metrics(None, found.flags, found.scores),
                "scores": found.scores.tolist(),
                "flags": found.flags.tolist(),
                "fit_rows": len(fit),
            }
        except Exception as error:
            result["errors"].append({"detector": method, "error": repr(error)})
    return result


def x_evaluate_frozen__mutmut_128(
    frame: pd.DataFrame, labels, partitions: dict, *, seed: int, methods: list[str]
) -> dict:
    """Run named detectors on unchanged positions with training-only preparation."""
    if (
        not methods
        or len(set(methods)) != len(methods)
        or set(methods) - set([*DETECTOR_NAMES, *DEEP_NAMES])
    ):
        raise ValueError("detectors must be explicit, unique row-level registry names")
    if type(seed) is not int or not 0 <= seed < 2**32:
        raise ValueError("seed must be a nonnegative 32-bit integer")
    prepared = prepare_frozen(frame, partitions)
    y = np.asarray(labels)
    if y.ndim != 1 or len(y) != len(frame) or set(np.unique(y)) - {0, 1}:
        raise ValueError("labels must be an aligned binary vector")
    for name in PARTITIONS:
        if set(np.unique(y[partitions[name]])) != {0, 1}:
            raise ValueError("both classes are required in every frozen partition")
    train, test = prepared["train"], prepared["test"]
    contamination = clip_contamination(float(y[partitions["train"]].mean()))
    result = {
        "protocol": PROTOCOL,
        "exploratory": True,
        "seed": seed,
        "partitions": {name: list(partitions[name]) for name in PARTITIONS},
        "preprocessing": prepared["fit"],
        "calibration": {"policy": "train_prevalence", "value": contamination},
        "prevalence": {name: float(y[partitions[name]].mean()) for name in PARTITIONS},
        "runs": {},
        "errors": [],
        "skipped": [],
    }
    skipped = skipped_detectors(len(train))
    for method in methods:
        if method in skipped:
            result["skipped"].append(method)
            continue
        fit = capped(train, method, seed)
        try:
            detector = build(method, contamination, seed)
            found = detect(test, detector, fit_df=fit)
            result["runs"][method] = {
                "metrics": compute_metrics(y[partitions["test"]], None, found.scores),
                "scores": found.scores.tolist(),
                "flags": found.flags.tolist(),
                "fit_rows": len(fit),
            }
        except Exception as error:
            result["errors"].append({"detector": method, "error": repr(error)})
    return result


def x_evaluate_frozen__mutmut_129(
    frame: pd.DataFrame, labels, partitions: dict, *, seed: int, methods: list[str]
) -> dict:
    """Run named detectors on unchanged positions with training-only preparation."""
    if (
        not methods
        or len(set(methods)) != len(methods)
        or set(methods) - set([*DETECTOR_NAMES, *DEEP_NAMES])
    ):
        raise ValueError("detectors must be explicit, unique row-level registry names")
    if type(seed) is not int or not 0 <= seed < 2**32:
        raise ValueError("seed must be a nonnegative 32-bit integer")
    prepared = prepare_frozen(frame, partitions)
    y = np.asarray(labels)
    if y.ndim != 1 or len(y) != len(frame) or set(np.unique(y)) - {0, 1}:
        raise ValueError("labels must be an aligned binary vector")
    for name in PARTITIONS:
        if set(np.unique(y[partitions[name]])) != {0, 1}:
            raise ValueError("both classes are required in every frozen partition")
    train, test = prepared["train"], prepared["test"]
    contamination = clip_contamination(float(y[partitions["train"]].mean()))
    result = {
        "protocol": PROTOCOL,
        "exploratory": True,
        "seed": seed,
        "partitions": {name: list(partitions[name]) for name in PARTITIONS},
        "preprocessing": prepared["fit"],
        "calibration": {"policy": "train_prevalence", "value": contamination},
        "prevalence": {name: float(y[partitions[name]].mean()) for name in PARTITIONS},
        "runs": {},
        "errors": [],
        "skipped": [],
    }
    skipped = skipped_detectors(len(train))
    for method in methods:
        if method in skipped:
            result["skipped"].append(method)
            continue
        fit = capped(train, method, seed)
        try:
            detector = build(method, contamination, seed)
            found = detect(test, detector, fit_df=fit)
            result["runs"][method] = {
                "metrics": compute_metrics(y[partitions["test"]], found.flags, None),
                "scores": found.scores.tolist(),
                "flags": found.flags.tolist(),
                "fit_rows": len(fit),
            }
        except Exception as error:
            result["errors"].append({"detector": method, "error": repr(error)})
    return result


def x_evaluate_frozen__mutmut_130(
    frame: pd.DataFrame, labels, partitions: dict, *, seed: int, methods: list[str]
) -> dict:
    """Run named detectors on unchanged positions with training-only preparation."""
    if (
        not methods
        or len(set(methods)) != len(methods)
        or set(methods) - set([*DETECTOR_NAMES, *DEEP_NAMES])
    ):
        raise ValueError("detectors must be explicit, unique row-level registry names")
    if type(seed) is not int or not 0 <= seed < 2**32:
        raise ValueError("seed must be a nonnegative 32-bit integer")
    prepared = prepare_frozen(frame, partitions)
    y = np.asarray(labels)
    if y.ndim != 1 or len(y) != len(frame) or set(np.unique(y)) - {0, 1}:
        raise ValueError("labels must be an aligned binary vector")
    for name in PARTITIONS:
        if set(np.unique(y[partitions[name]])) != {0, 1}:
            raise ValueError("both classes are required in every frozen partition")
    train, test = prepared["train"], prepared["test"]
    contamination = clip_contamination(float(y[partitions["train"]].mean()))
    result = {
        "protocol": PROTOCOL,
        "exploratory": True,
        "seed": seed,
        "partitions": {name: list(partitions[name]) for name in PARTITIONS},
        "preprocessing": prepared["fit"],
        "calibration": {"policy": "train_prevalence", "value": contamination},
        "prevalence": {name: float(y[partitions[name]].mean()) for name in PARTITIONS},
        "runs": {},
        "errors": [],
        "skipped": [],
    }
    skipped = skipped_detectors(len(train))
    for method in methods:
        if method in skipped:
            result["skipped"].append(method)
            continue
        fit = capped(train, method, seed)
        try:
            detector = build(method, contamination, seed)
            found = detect(test, detector, fit_df=fit)
            result["runs"][method] = {
                "metrics": compute_metrics(found.flags, found.scores),
                "scores": found.scores.tolist(),
                "flags": found.flags.tolist(),
                "fit_rows": len(fit),
            }
        except Exception as error:
            result["errors"].append({"detector": method, "error": repr(error)})
    return result


def x_evaluate_frozen__mutmut_131(
    frame: pd.DataFrame, labels, partitions: dict, *, seed: int, methods: list[str]
) -> dict:
    """Run named detectors on unchanged positions with training-only preparation."""
    if (
        not methods
        or len(set(methods)) != len(methods)
        or set(methods) - set([*DETECTOR_NAMES, *DEEP_NAMES])
    ):
        raise ValueError("detectors must be explicit, unique row-level registry names")
    if type(seed) is not int or not 0 <= seed < 2**32:
        raise ValueError("seed must be a nonnegative 32-bit integer")
    prepared = prepare_frozen(frame, partitions)
    y = np.asarray(labels)
    if y.ndim != 1 or len(y) != len(frame) or set(np.unique(y)) - {0, 1}:
        raise ValueError("labels must be an aligned binary vector")
    for name in PARTITIONS:
        if set(np.unique(y[partitions[name]])) != {0, 1}:
            raise ValueError("both classes are required in every frozen partition")
    train, test = prepared["train"], prepared["test"]
    contamination = clip_contamination(float(y[partitions["train"]].mean()))
    result = {
        "protocol": PROTOCOL,
        "exploratory": True,
        "seed": seed,
        "partitions": {name: list(partitions[name]) for name in PARTITIONS},
        "preprocessing": prepared["fit"],
        "calibration": {"policy": "train_prevalence", "value": contamination},
        "prevalence": {name: float(y[partitions[name]].mean()) for name in PARTITIONS},
        "runs": {},
        "errors": [],
        "skipped": [],
    }
    skipped = skipped_detectors(len(train))
    for method in methods:
        if method in skipped:
            result["skipped"].append(method)
            continue
        fit = capped(train, method, seed)
        try:
            detector = build(method, contamination, seed)
            found = detect(test, detector, fit_df=fit)
            result["runs"][method] = {
                "metrics": compute_metrics(y[partitions["test"]], found.scores),
                "scores": found.scores.tolist(),
                "flags": found.flags.tolist(),
                "fit_rows": len(fit),
            }
        except Exception as error:
            result["errors"].append({"detector": method, "error": repr(error)})
    return result


def x_evaluate_frozen__mutmut_132(
    frame: pd.DataFrame, labels, partitions: dict, *, seed: int, methods: list[str]
) -> dict:
    """Run named detectors on unchanged positions with training-only preparation."""
    if (
        not methods
        or len(set(methods)) != len(methods)
        or set(methods) - set([*DETECTOR_NAMES, *DEEP_NAMES])
    ):
        raise ValueError("detectors must be explicit, unique row-level registry names")
    if type(seed) is not int or not 0 <= seed < 2**32:
        raise ValueError("seed must be a nonnegative 32-bit integer")
    prepared = prepare_frozen(frame, partitions)
    y = np.asarray(labels)
    if y.ndim != 1 or len(y) != len(frame) or set(np.unique(y)) - {0, 1}:
        raise ValueError("labels must be an aligned binary vector")
    for name in PARTITIONS:
        if set(np.unique(y[partitions[name]])) != {0, 1}:
            raise ValueError("both classes are required in every frozen partition")
    train, test = prepared["train"], prepared["test"]
    contamination = clip_contamination(float(y[partitions["train"]].mean()))
    result = {
        "protocol": PROTOCOL,
        "exploratory": True,
        "seed": seed,
        "partitions": {name: list(partitions[name]) for name in PARTITIONS},
        "preprocessing": prepared["fit"],
        "calibration": {"policy": "train_prevalence", "value": contamination},
        "prevalence": {name: float(y[partitions[name]].mean()) for name in PARTITIONS},
        "runs": {},
        "errors": [],
        "skipped": [],
    }
    skipped = skipped_detectors(len(train))
    for method in methods:
        if method in skipped:
            result["skipped"].append(method)
            continue
        fit = capped(train, method, seed)
        try:
            detector = build(method, contamination, seed)
            found = detect(test, detector, fit_df=fit)
            result["runs"][method] = {
                "metrics": compute_metrics(y[partitions["test"]], found.flags, ),
                "scores": found.scores.tolist(),
                "flags": found.flags.tolist(),
                "fit_rows": len(fit),
            }
        except Exception as error:
            result["errors"].append({"detector": method, "error": repr(error)})
    return result


def x_evaluate_frozen__mutmut_133(
    frame: pd.DataFrame, labels, partitions: dict, *, seed: int, methods: list[str]
) -> dict:
    """Run named detectors on unchanged positions with training-only preparation."""
    if (
        not methods
        or len(set(methods)) != len(methods)
        or set(methods) - set([*DETECTOR_NAMES, *DEEP_NAMES])
    ):
        raise ValueError("detectors must be explicit, unique row-level registry names")
    if type(seed) is not int or not 0 <= seed < 2**32:
        raise ValueError("seed must be a nonnegative 32-bit integer")
    prepared = prepare_frozen(frame, partitions)
    y = np.asarray(labels)
    if y.ndim != 1 or len(y) != len(frame) or set(np.unique(y)) - {0, 1}:
        raise ValueError("labels must be an aligned binary vector")
    for name in PARTITIONS:
        if set(np.unique(y[partitions[name]])) != {0, 1}:
            raise ValueError("both classes are required in every frozen partition")
    train, test = prepared["train"], prepared["test"]
    contamination = clip_contamination(float(y[partitions["train"]].mean()))
    result = {
        "protocol": PROTOCOL,
        "exploratory": True,
        "seed": seed,
        "partitions": {name: list(partitions[name]) for name in PARTITIONS},
        "preprocessing": prepared["fit"],
        "calibration": {"policy": "train_prevalence", "value": contamination},
        "prevalence": {name: float(y[partitions[name]].mean()) for name in PARTITIONS},
        "runs": {},
        "errors": [],
        "skipped": [],
    }
    skipped = skipped_detectors(len(train))
    for method in methods:
        if method in skipped:
            result["skipped"].append(method)
            continue
        fit = capped(train, method, seed)
        try:
            detector = build(method, contamination, seed)
            found = detect(test, detector, fit_df=fit)
            result["runs"][method] = {
                "metrics": compute_metrics(y[partitions["XXtestXX"]], found.flags, found.scores),
                "scores": found.scores.tolist(),
                "flags": found.flags.tolist(),
                "fit_rows": len(fit),
            }
        except Exception as error:
            result["errors"].append({"detector": method, "error": repr(error)})
    return result


def x_evaluate_frozen__mutmut_134(
    frame: pd.DataFrame, labels, partitions: dict, *, seed: int, methods: list[str]
) -> dict:
    """Run named detectors on unchanged positions with training-only preparation."""
    if (
        not methods
        or len(set(methods)) != len(methods)
        or set(methods) - set([*DETECTOR_NAMES, *DEEP_NAMES])
    ):
        raise ValueError("detectors must be explicit, unique row-level registry names")
    if type(seed) is not int or not 0 <= seed < 2**32:
        raise ValueError("seed must be a nonnegative 32-bit integer")
    prepared = prepare_frozen(frame, partitions)
    y = np.asarray(labels)
    if y.ndim != 1 or len(y) != len(frame) or set(np.unique(y)) - {0, 1}:
        raise ValueError("labels must be an aligned binary vector")
    for name in PARTITIONS:
        if set(np.unique(y[partitions[name]])) != {0, 1}:
            raise ValueError("both classes are required in every frozen partition")
    train, test = prepared["train"], prepared["test"]
    contamination = clip_contamination(float(y[partitions["train"]].mean()))
    result = {
        "protocol": PROTOCOL,
        "exploratory": True,
        "seed": seed,
        "partitions": {name: list(partitions[name]) for name in PARTITIONS},
        "preprocessing": prepared["fit"],
        "calibration": {"policy": "train_prevalence", "value": contamination},
        "prevalence": {name: float(y[partitions[name]].mean()) for name in PARTITIONS},
        "runs": {},
        "errors": [],
        "skipped": [],
    }
    skipped = skipped_detectors(len(train))
    for method in methods:
        if method in skipped:
            result["skipped"].append(method)
            continue
        fit = capped(train, method, seed)
        try:
            detector = build(method, contamination, seed)
            found = detect(test, detector, fit_df=fit)
            result["runs"][method] = {
                "metrics": compute_metrics(y[partitions["TEST"]], found.flags, found.scores),
                "scores": found.scores.tolist(),
                "flags": found.flags.tolist(),
                "fit_rows": len(fit),
            }
        except Exception as error:
            result["errors"].append({"detector": method, "error": repr(error)})
    return result


def x_evaluate_frozen__mutmut_135(
    frame: pd.DataFrame, labels, partitions: dict, *, seed: int, methods: list[str]
) -> dict:
    """Run named detectors on unchanged positions with training-only preparation."""
    if (
        not methods
        or len(set(methods)) != len(methods)
        or set(methods) - set([*DETECTOR_NAMES, *DEEP_NAMES])
    ):
        raise ValueError("detectors must be explicit, unique row-level registry names")
    if type(seed) is not int or not 0 <= seed < 2**32:
        raise ValueError("seed must be a nonnegative 32-bit integer")
    prepared = prepare_frozen(frame, partitions)
    y = np.asarray(labels)
    if y.ndim != 1 or len(y) != len(frame) or set(np.unique(y)) - {0, 1}:
        raise ValueError("labels must be an aligned binary vector")
    for name in PARTITIONS:
        if set(np.unique(y[partitions[name]])) != {0, 1}:
            raise ValueError("both classes are required in every frozen partition")
    train, test = prepared["train"], prepared["test"]
    contamination = clip_contamination(float(y[partitions["train"]].mean()))
    result = {
        "protocol": PROTOCOL,
        "exploratory": True,
        "seed": seed,
        "partitions": {name: list(partitions[name]) for name in PARTITIONS},
        "preprocessing": prepared["fit"],
        "calibration": {"policy": "train_prevalence", "value": contamination},
        "prevalence": {name: float(y[partitions[name]].mean()) for name in PARTITIONS},
        "runs": {},
        "errors": [],
        "skipped": [],
    }
    skipped = skipped_detectors(len(train))
    for method in methods:
        if method in skipped:
            result["skipped"].append(method)
            continue
        fit = capped(train, method, seed)
        try:
            detector = build(method, contamination, seed)
            found = detect(test, detector, fit_df=fit)
            result["runs"][method] = {
                "metrics": compute_metrics(y[partitions["test"]], found.flags, found.scores),
                "XXscoresXX": found.scores.tolist(),
                "flags": found.flags.tolist(),
                "fit_rows": len(fit),
            }
        except Exception as error:
            result["errors"].append({"detector": method, "error": repr(error)})
    return result


def x_evaluate_frozen__mutmut_136(
    frame: pd.DataFrame, labels, partitions: dict, *, seed: int, methods: list[str]
) -> dict:
    """Run named detectors on unchanged positions with training-only preparation."""
    if (
        not methods
        or len(set(methods)) != len(methods)
        or set(methods) - set([*DETECTOR_NAMES, *DEEP_NAMES])
    ):
        raise ValueError("detectors must be explicit, unique row-level registry names")
    if type(seed) is not int or not 0 <= seed < 2**32:
        raise ValueError("seed must be a nonnegative 32-bit integer")
    prepared = prepare_frozen(frame, partitions)
    y = np.asarray(labels)
    if y.ndim != 1 or len(y) != len(frame) or set(np.unique(y)) - {0, 1}:
        raise ValueError("labels must be an aligned binary vector")
    for name in PARTITIONS:
        if set(np.unique(y[partitions[name]])) != {0, 1}:
            raise ValueError("both classes are required in every frozen partition")
    train, test = prepared["train"], prepared["test"]
    contamination = clip_contamination(float(y[partitions["train"]].mean()))
    result = {
        "protocol": PROTOCOL,
        "exploratory": True,
        "seed": seed,
        "partitions": {name: list(partitions[name]) for name in PARTITIONS},
        "preprocessing": prepared["fit"],
        "calibration": {"policy": "train_prevalence", "value": contamination},
        "prevalence": {name: float(y[partitions[name]].mean()) for name in PARTITIONS},
        "runs": {},
        "errors": [],
        "skipped": [],
    }
    skipped = skipped_detectors(len(train))
    for method in methods:
        if method in skipped:
            result["skipped"].append(method)
            continue
        fit = capped(train, method, seed)
        try:
            detector = build(method, contamination, seed)
            found = detect(test, detector, fit_df=fit)
            result["runs"][method] = {
                "metrics": compute_metrics(y[partitions["test"]], found.flags, found.scores),
                "SCORES": found.scores.tolist(),
                "flags": found.flags.tolist(),
                "fit_rows": len(fit),
            }
        except Exception as error:
            result["errors"].append({"detector": method, "error": repr(error)})
    return result


def x_evaluate_frozen__mutmut_137(
    frame: pd.DataFrame, labels, partitions: dict, *, seed: int, methods: list[str]
) -> dict:
    """Run named detectors on unchanged positions with training-only preparation."""
    if (
        not methods
        or len(set(methods)) != len(methods)
        or set(methods) - set([*DETECTOR_NAMES, *DEEP_NAMES])
    ):
        raise ValueError("detectors must be explicit, unique row-level registry names")
    if type(seed) is not int or not 0 <= seed < 2**32:
        raise ValueError("seed must be a nonnegative 32-bit integer")
    prepared = prepare_frozen(frame, partitions)
    y = np.asarray(labels)
    if y.ndim != 1 or len(y) != len(frame) or set(np.unique(y)) - {0, 1}:
        raise ValueError("labels must be an aligned binary vector")
    for name in PARTITIONS:
        if set(np.unique(y[partitions[name]])) != {0, 1}:
            raise ValueError("both classes are required in every frozen partition")
    train, test = prepared["train"], prepared["test"]
    contamination = clip_contamination(float(y[partitions["train"]].mean()))
    result = {
        "protocol": PROTOCOL,
        "exploratory": True,
        "seed": seed,
        "partitions": {name: list(partitions[name]) for name in PARTITIONS},
        "preprocessing": prepared["fit"],
        "calibration": {"policy": "train_prevalence", "value": contamination},
        "prevalence": {name: float(y[partitions[name]].mean()) for name in PARTITIONS},
        "runs": {},
        "errors": [],
        "skipped": [],
    }
    skipped = skipped_detectors(len(train))
    for method in methods:
        if method in skipped:
            result["skipped"].append(method)
            continue
        fit = capped(train, method, seed)
        try:
            detector = build(method, contamination, seed)
            found = detect(test, detector, fit_df=fit)
            result["runs"][method] = {
                "metrics": compute_metrics(y[partitions["test"]], found.flags, found.scores),
                "scores": found.scores.tolist(),
                "XXflagsXX": found.flags.tolist(),
                "fit_rows": len(fit),
            }
        except Exception as error:
            result["errors"].append({"detector": method, "error": repr(error)})
    return result


def x_evaluate_frozen__mutmut_138(
    frame: pd.DataFrame, labels, partitions: dict, *, seed: int, methods: list[str]
) -> dict:
    """Run named detectors on unchanged positions with training-only preparation."""
    if (
        not methods
        or len(set(methods)) != len(methods)
        or set(methods) - set([*DETECTOR_NAMES, *DEEP_NAMES])
    ):
        raise ValueError("detectors must be explicit, unique row-level registry names")
    if type(seed) is not int or not 0 <= seed < 2**32:
        raise ValueError("seed must be a nonnegative 32-bit integer")
    prepared = prepare_frozen(frame, partitions)
    y = np.asarray(labels)
    if y.ndim != 1 or len(y) != len(frame) or set(np.unique(y)) - {0, 1}:
        raise ValueError("labels must be an aligned binary vector")
    for name in PARTITIONS:
        if set(np.unique(y[partitions[name]])) != {0, 1}:
            raise ValueError("both classes are required in every frozen partition")
    train, test = prepared["train"], prepared["test"]
    contamination = clip_contamination(float(y[partitions["train"]].mean()))
    result = {
        "protocol": PROTOCOL,
        "exploratory": True,
        "seed": seed,
        "partitions": {name: list(partitions[name]) for name in PARTITIONS},
        "preprocessing": prepared["fit"],
        "calibration": {"policy": "train_prevalence", "value": contamination},
        "prevalence": {name: float(y[partitions[name]].mean()) for name in PARTITIONS},
        "runs": {},
        "errors": [],
        "skipped": [],
    }
    skipped = skipped_detectors(len(train))
    for method in methods:
        if method in skipped:
            result["skipped"].append(method)
            continue
        fit = capped(train, method, seed)
        try:
            detector = build(method, contamination, seed)
            found = detect(test, detector, fit_df=fit)
            result["runs"][method] = {
                "metrics": compute_metrics(y[partitions["test"]], found.flags, found.scores),
                "scores": found.scores.tolist(),
                "FLAGS": found.flags.tolist(),
                "fit_rows": len(fit),
            }
        except Exception as error:
            result["errors"].append({"detector": method, "error": repr(error)})
    return result


def x_evaluate_frozen__mutmut_139(
    frame: pd.DataFrame, labels, partitions: dict, *, seed: int, methods: list[str]
) -> dict:
    """Run named detectors on unchanged positions with training-only preparation."""
    if (
        not methods
        or len(set(methods)) != len(methods)
        or set(methods) - set([*DETECTOR_NAMES, *DEEP_NAMES])
    ):
        raise ValueError("detectors must be explicit, unique row-level registry names")
    if type(seed) is not int or not 0 <= seed < 2**32:
        raise ValueError("seed must be a nonnegative 32-bit integer")
    prepared = prepare_frozen(frame, partitions)
    y = np.asarray(labels)
    if y.ndim != 1 or len(y) != len(frame) or set(np.unique(y)) - {0, 1}:
        raise ValueError("labels must be an aligned binary vector")
    for name in PARTITIONS:
        if set(np.unique(y[partitions[name]])) != {0, 1}:
            raise ValueError("both classes are required in every frozen partition")
    train, test = prepared["train"], prepared["test"]
    contamination = clip_contamination(float(y[partitions["train"]].mean()))
    result = {
        "protocol": PROTOCOL,
        "exploratory": True,
        "seed": seed,
        "partitions": {name: list(partitions[name]) for name in PARTITIONS},
        "preprocessing": prepared["fit"],
        "calibration": {"policy": "train_prevalence", "value": contamination},
        "prevalence": {name: float(y[partitions[name]].mean()) for name in PARTITIONS},
        "runs": {},
        "errors": [],
        "skipped": [],
    }
    skipped = skipped_detectors(len(train))
    for method in methods:
        if method in skipped:
            result["skipped"].append(method)
            continue
        fit = capped(train, method, seed)
        try:
            detector = build(method, contamination, seed)
            found = detect(test, detector, fit_df=fit)
            result["runs"][method] = {
                "metrics": compute_metrics(y[partitions["test"]], found.flags, found.scores),
                "scores": found.scores.tolist(),
                "flags": found.flags.tolist(),
                "XXfit_rowsXX": len(fit),
            }
        except Exception as error:
            result["errors"].append({"detector": method, "error": repr(error)})
    return result


def x_evaluate_frozen__mutmut_140(
    frame: pd.DataFrame, labels, partitions: dict, *, seed: int, methods: list[str]
) -> dict:
    """Run named detectors on unchanged positions with training-only preparation."""
    if (
        not methods
        or len(set(methods)) != len(methods)
        or set(methods) - set([*DETECTOR_NAMES, *DEEP_NAMES])
    ):
        raise ValueError("detectors must be explicit, unique row-level registry names")
    if type(seed) is not int or not 0 <= seed < 2**32:
        raise ValueError("seed must be a nonnegative 32-bit integer")
    prepared = prepare_frozen(frame, partitions)
    y = np.asarray(labels)
    if y.ndim != 1 or len(y) != len(frame) or set(np.unique(y)) - {0, 1}:
        raise ValueError("labels must be an aligned binary vector")
    for name in PARTITIONS:
        if set(np.unique(y[partitions[name]])) != {0, 1}:
            raise ValueError("both classes are required in every frozen partition")
    train, test = prepared["train"], prepared["test"]
    contamination = clip_contamination(float(y[partitions["train"]].mean()))
    result = {
        "protocol": PROTOCOL,
        "exploratory": True,
        "seed": seed,
        "partitions": {name: list(partitions[name]) for name in PARTITIONS},
        "preprocessing": prepared["fit"],
        "calibration": {"policy": "train_prevalence", "value": contamination},
        "prevalence": {name: float(y[partitions[name]].mean()) for name in PARTITIONS},
        "runs": {},
        "errors": [],
        "skipped": [],
    }
    skipped = skipped_detectors(len(train))
    for method in methods:
        if method in skipped:
            result["skipped"].append(method)
            continue
        fit = capped(train, method, seed)
        try:
            detector = build(method, contamination, seed)
            found = detect(test, detector, fit_df=fit)
            result["runs"][method] = {
                "metrics": compute_metrics(y[partitions["test"]], found.flags, found.scores),
                "scores": found.scores.tolist(),
                "flags": found.flags.tolist(),
                "FIT_ROWS": len(fit),
            }
        except Exception as error:
            result["errors"].append({"detector": method, "error": repr(error)})
    return result


def x_evaluate_frozen__mutmut_141(
    frame: pd.DataFrame, labels, partitions: dict, *, seed: int, methods: list[str]
) -> dict:
    """Run named detectors on unchanged positions with training-only preparation."""
    if (
        not methods
        or len(set(methods)) != len(methods)
        or set(methods) - set([*DETECTOR_NAMES, *DEEP_NAMES])
    ):
        raise ValueError("detectors must be explicit, unique row-level registry names")
    if type(seed) is not int or not 0 <= seed < 2**32:
        raise ValueError("seed must be a nonnegative 32-bit integer")
    prepared = prepare_frozen(frame, partitions)
    y = np.asarray(labels)
    if y.ndim != 1 or len(y) != len(frame) or set(np.unique(y)) - {0, 1}:
        raise ValueError("labels must be an aligned binary vector")
    for name in PARTITIONS:
        if set(np.unique(y[partitions[name]])) != {0, 1}:
            raise ValueError("both classes are required in every frozen partition")
    train, test = prepared["train"], prepared["test"]
    contamination = clip_contamination(float(y[partitions["train"]].mean()))
    result = {
        "protocol": PROTOCOL,
        "exploratory": True,
        "seed": seed,
        "partitions": {name: list(partitions[name]) for name in PARTITIONS},
        "preprocessing": prepared["fit"],
        "calibration": {"policy": "train_prevalence", "value": contamination},
        "prevalence": {name: float(y[partitions[name]].mean()) for name in PARTITIONS},
        "runs": {},
        "errors": [],
        "skipped": [],
    }
    skipped = skipped_detectors(len(train))
    for method in methods:
        if method in skipped:
            result["skipped"].append(method)
            continue
        fit = capped(train, method, seed)
        try:
            detector = build(method, contamination, seed)
            found = detect(test, detector, fit_df=fit)
            result["runs"][method] = {
                "metrics": compute_metrics(y[partitions["test"]], found.flags, found.scores),
                "scores": found.scores.tolist(),
                "flags": found.flags.tolist(),
                "fit_rows": len(fit),
            }
        except Exception as error:
            result["errors"].append(None)
    return result


def x_evaluate_frozen__mutmut_142(
    frame: pd.DataFrame, labels, partitions: dict, *, seed: int, methods: list[str]
) -> dict:
    """Run named detectors on unchanged positions with training-only preparation."""
    if (
        not methods
        or len(set(methods)) != len(methods)
        or set(methods) - set([*DETECTOR_NAMES, *DEEP_NAMES])
    ):
        raise ValueError("detectors must be explicit, unique row-level registry names")
    if type(seed) is not int or not 0 <= seed < 2**32:
        raise ValueError("seed must be a nonnegative 32-bit integer")
    prepared = prepare_frozen(frame, partitions)
    y = np.asarray(labels)
    if y.ndim != 1 or len(y) != len(frame) or set(np.unique(y)) - {0, 1}:
        raise ValueError("labels must be an aligned binary vector")
    for name in PARTITIONS:
        if set(np.unique(y[partitions[name]])) != {0, 1}:
            raise ValueError("both classes are required in every frozen partition")
    train, test = prepared["train"], prepared["test"]
    contamination = clip_contamination(float(y[partitions["train"]].mean()))
    result = {
        "protocol": PROTOCOL,
        "exploratory": True,
        "seed": seed,
        "partitions": {name: list(partitions[name]) for name in PARTITIONS},
        "preprocessing": prepared["fit"],
        "calibration": {"policy": "train_prevalence", "value": contamination},
        "prevalence": {name: float(y[partitions[name]].mean()) for name in PARTITIONS},
        "runs": {},
        "errors": [],
        "skipped": [],
    }
    skipped = skipped_detectors(len(train))
    for method in methods:
        if method in skipped:
            result["skipped"].append(method)
            continue
        fit = capped(train, method, seed)
        try:
            detector = build(method, contamination, seed)
            found = detect(test, detector, fit_df=fit)
            result["runs"][method] = {
                "metrics": compute_metrics(y[partitions["test"]], found.flags, found.scores),
                "scores": found.scores.tolist(),
                "flags": found.flags.tolist(),
                "fit_rows": len(fit),
            }
        except Exception as error:
            result["XXerrorsXX"].append({"detector": method, "error": repr(error)})
    return result


def x_evaluate_frozen__mutmut_143(
    frame: pd.DataFrame, labels, partitions: dict, *, seed: int, methods: list[str]
) -> dict:
    """Run named detectors on unchanged positions with training-only preparation."""
    if (
        not methods
        or len(set(methods)) != len(methods)
        or set(methods) - set([*DETECTOR_NAMES, *DEEP_NAMES])
    ):
        raise ValueError("detectors must be explicit, unique row-level registry names")
    if type(seed) is not int or not 0 <= seed < 2**32:
        raise ValueError("seed must be a nonnegative 32-bit integer")
    prepared = prepare_frozen(frame, partitions)
    y = np.asarray(labels)
    if y.ndim != 1 or len(y) != len(frame) or set(np.unique(y)) - {0, 1}:
        raise ValueError("labels must be an aligned binary vector")
    for name in PARTITIONS:
        if set(np.unique(y[partitions[name]])) != {0, 1}:
            raise ValueError("both classes are required in every frozen partition")
    train, test = prepared["train"], prepared["test"]
    contamination = clip_contamination(float(y[partitions["train"]].mean()))
    result = {
        "protocol": PROTOCOL,
        "exploratory": True,
        "seed": seed,
        "partitions": {name: list(partitions[name]) for name in PARTITIONS},
        "preprocessing": prepared["fit"],
        "calibration": {"policy": "train_prevalence", "value": contamination},
        "prevalence": {name: float(y[partitions[name]].mean()) for name in PARTITIONS},
        "runs": {},
        "errors": [],
        "skipped": [],
    }
    skipped = skipped_detectors(len(train))
    for method in methods:
        if method in skipped:
            result["skipped"].append(method)
            continue
        fit = capped(train, method, seed)
        try:
            detector = build(method, contamination, seed)
            found = detect(test, detector, fit_df=fit)
            result["runs"][method] = {
                "metrics": compute_metrics(y[partitions["test"]], found.flags, found.scores),
                "scores": found.scores.tolist(),
                "flags": found.flags.tolist(),
                "fit_rows": len(fit),
            }
        except Exception as error:
            result["ERRORS"].append({"detector": method, "error": repr(error)})
    return result


def x_evaluate_frozen__mutmut_144(
    frame: pd.DataFrame, labels, partitions: dict, *, seed: int, methods: list[str]
) -> dict:
    """Run named detectors on unchanged positions with training-only preparation."""
    if (
        not methods
        or len(set(methods)) != len(methods)
        or set(methods) - set([*DETECTOR_NAMES, *DEEP_NAMES])
    ):
        raise ValueError("detectors must be explicit, unique row-level registry names")
    if type(seed) is not int or not 0 <= seed < 2**32:
        raise ValueError("seed must be a nonnegative 32-bit integer")
    prepared = prepare_frozen(frame, partitions)
    y = np.asarray(labels)
    if y.ndim != 1 or len(y) != len(frame) or set(np.unique(y)) - {0, 1}:
        raise ValueError("labels must be an aligned binary vector")
    for name in PARTITIONS:
        if set(np.unique(y[partitions[name]])) != {0, 1}:
            raise ValueError("both classes are required in every frozen partition")
    train, test = prepared["train"], prepared["test"]
    contamination = clip_contamination(float(y[partitions["train"]].mean()))
    result = {
        "protocol": PROTOCOL,
        "exploratory": True,
        "seed": seed,
        "partitions": {name: list(partitions[name]) for name in PARTITIONS},
        "preprocessing": prepared["fit"],
        "calibration": {"policy": "train_prevalence", "value": contamination},
        "prevalence": {name: float(y[partitions[name]].mean()) for name in PARTITIONS},
        "runs": {},
        "errors": [],
        "skipped": [],
    }
    skipped = skipped_detectors(len(train))
    for method in methods:
        if method in skipped:
            result["skipped"].append(method)
            continue
        fit = capped(train, method, seed)
        try:
            detector = build(method, contamination, seed)
            found = detect(test, detector, fit_df=fit)
            result["runs"][method] = {
                "metrics": compute_metrics(y[partitions["test"]], found.flags, found.scores),
                "scores": found.scores.tolist(),
                "flags": found.flags.tolist(),
                "fit_rows": len(fit),
            }
        except Exception as error:
            result["errors"].append({"XXdetectorXX": method, "error": repr(error)})
    return result


def x_evaluate_frozen__mutmut_145(
    frame: pd.DataFrame, labels, partitions: dict, *, seed: int, methods: list[str]
) -> dict:
    """Run named detectors on unchanged positions with training-only preparation."""
    if (
        not methods
        or len(set(methods)) != len(methods)
        or set(methods) - set([*DETECTOR_NAMES, *DEEP_NAMES])
    ):
        raise ValueError("detectors must be explicit, unique row-level registry names")
    if type(seed) is not int or not 0 <= seed < 2**32:
        raise ValueError("seed must be a nonnegative 32-bit integer")
    prepared = prepare_frozen(frame, partitions)
    y = np.asarray(labels)
    if y.ndim != 1 or len(y) != len(frame) or set(np.unique(y)) - {0, 1}:
        raise ValueError("labels must be an aligned binary vector")
    for name in PARTITIONS:
        if set(np.unique(y[partitions[name]])) != {0, 1}:
            raise ValueError("both classes are required in every frozen partition")
    train, test = prepared["train"], prepared["test"]
    contamination = clip_contamination(float(y[partitions["train"]].mean()))
    result = {
        "protocol": PROTOCOL,
        "exploratory": True,
        "seed": seed,
        "partitions": {name: list(partitions[name]) for name in PARTITIONS},
        "preprocessing": prepared["fit"],
        "calibration": {"policy": "train_prevalence", "value": contamination},
        "prevalence": {name: float(y[partitions[name]].mean()) for name in PARTITIONS},
        "runs": {},
        "errors": [],
        "skipped": [],
    }
    skipped = skipped_detectors(len(train))
    for method in methods:
        if method in skipped:
            result["skipped"].append(method)
            continue
        fit = capped(train, method, seed)
        try:
            detector = build(method, contamination, seed)
            found = detect(test, detector, fit_df=fit)
            result["runs"][method] = {
                "metrics": compute_metrics(y[partitions["test"]], found.flags, found.scores),
                "scores": found.scores.tolist(),
                "flags": found.flags.tolist(),
                "fit_rows": len(fit),
            }
        except Exception as error:
            result["errors"].append({"DETECTOR": method, "error": repr(error)})
    return result


def x_evaluate_frozen__mutmut_146(
    frame: pd.DataFrame, labels, partitions: dict, *, seed: int, methods: list[str]
) -> dict:
    """Run named detectors on unchanged positions with training-only preparation."""
    if (
        not methods
        or len(set(methods)) != len(methods)
        or set(methods) - set([*DETECTOR_NAMES, *DEEP_NAMES])
    ):
        raise ValueError("detectors must be explicit, unique row-level registry names")
    if type(seed) is not int or not 0 <= seed < 2**32:
        raise ValueError("seed must be a nonnegative 32-bit integer")
    prepared = prepare_frozen(frame, partitions)
    y = np.asarray(labels)
    if y.ndim != 1 or len(y) != len(frame) or set(np.unique(y)) - {0, 1}:
        raise ValueError("labels must be an aligned binary vector")
    for name in PARTITIONS:
        if set(np.unique(y[partitions[name]])) != {0, 1}:
            raise ValueError("both classes are required in every frozen partition")
    train, test = prepared["train"], prepared["test"]
    contamination = clip_contamination(float(y[partitions["train"]].mean()))
    result = {
        "protocol": PROTOCOL,
        "exploratory": True,
        "seed": seed,
        "partitions": {name: list(partitions[name]) for name in PARTITIONS},
        "preprocessing": prepared["fit"],
        "calibration": {"policy": "train_prevalence", "value": contamination},
        "prevalence": {name: float(y[partitions[name]].mean()) for name in PARTITIONS},
        "runs": {},
        "errors": [],
        "skipped": [],
    }
    skipped = skipped_detectors(len(train))
    for method in methods:
        if method in skipped:
            result["skipped"].append(method)
            continue
        fit = capped(train, method, seed)
        try:
            detector = build(method, contamination, seed)
            found = detect(test, detector, fit_df=fit)
            result["runs"][method] = {
                "metrics": compute_metrics(y[partitions["test"]], found.flags, found.scores),
                "scores": found.scores.tolist(),
                "flags": found.flags.tolist(),
                "fit_rows": len(fit),
            }
        except Exception as error:
            result["errors"].append({"detector": method, "XXerrorXX": repr(error)})
    return result


def x_evaluate_frozen__mutmut_147(
    frame: pd.DataFrame, labels, partitions: dict, *, seed: int, methods: list[str]
) -> dict:
    """Run named detectors on unchanged positions with training-only preparation."""
    if (
        not methods
        or len(set(methods)) != len(methods)
        or set(methods) - set([*DETECTOR_NAMES, *DEEP_NAMES])
    ):
        raise ValueError("detectors must be explicit, unique row-level registry names")
    if type(seed) is not int or not 0 <= seed < 2**32:
        raise ValueError("seed must be a nonnegative 32-bit integer")
    prepared = prepare_frozen(frame, partitions)
    y = np.asarray(labels)
    if y.ndim != 1 or len(y) != len(frame) or set(np.unique(y)) - {0, 1}:
        raise ValueError("labels must be an aligned binary vector")
    for name in PARTITIONS:
        if set(np.unique(y[partitions[name]])) != {0, 1}:
            raise ValueError("both classes are required in every frozen partition")
    train, test = prepared["train"], prepared["test"]
    contamination = clip_contamination(float(y[partitions["train"]].mean()))
    result = {
        "protocol": PROTOCOL,
        "exploratory": True,
        "seed": seed,
        "partitions": {name: list(partitions[name]) for name in PARTITIONS},
        "preprocessing": prepared["fit"],
        "calibration": {"policy": "train_prevalence", "value": contamination},
        "prevalence": {name: float(y[partitions[name]].mean()) for name in PARTITIONS},
        "runs": {},
        "errors": [],
        "skipped": [],
    }
    skipped = skipped_detectors(len(train))
    for method in methods:
        if method in skipped:
            result["skipped"].append(method)
            continue
        fit = capped(train, method, seed)
        try:
            detector = build(method, contamination, seed)
            found = detect(test, detector, fit_df=fit)
            result["runs"][method] = {
                "metrics": compute_metrics(y[partitions["test"]], found.flags, found.scores),
                "scores": found.scores.tolist(),
                "flags": found.flags.tolist(),
                "fit_rows": len(fit),
            }
        except Exception as error:
            result["errors"].append({"detector": method, "ERROR": repr(error)})
    return result


def x_evaluate_frozen__mutmut_148(
    frame: pd.DataFrame, labels, partitions: dict, *, seed: int, methods: list[str]
) -> dict:
    """Run named detectors on unchanged positions with training-only preparation."""
    if (
        not methods
        or len(set(methods)) != len(methods)
        or set(methods) - set([*DETECTOR_NAMES, *DEEP_NAMES])
    ):
        raise ValueError("detectors must be explicit, unique row-level registry names")
    if type(seed) is not int or not 0 <= seed < 2**32:
        raise ValueError("seed must be a nonnegative 32-bit integer")
    prepared = prepare_frozen(frame, partitions)
    y = np.asarray(labels)
    if y.ndim != 1 or len(y) != len(frame) or set(np.unique(y)) - {0, 1}:
        raise ValueError("labels must be an aligned binary vector")
    for name in PARTITIONS:
        if set(np.unique(y[partitions[name]])) != {0, 1}:
            raise ValueError("both classes are required in every frozen partition")
    train, test = prepared["train"], prepared["test"]
    contamination = clip_contamination(float(y[partitions["train"]].mean()))
    result = {
        "protocol": PROTOCOL,
        "exploratory": True,
        "seed": seed,
        "partitions": {name: list(partitions[name]) for name in PARTITIONS},
        "preprocessing": prepared["fit"],
        "calibration": {"policy": "train_prevalence", "value": contamination},
        "prevalence": {name: float(y[partitions[name]].mean()) for name in PARTITIONS},
        "runs": {},
        "errors": [],
        "skipped": [],
    }
    skipped = skipped_detectors(len(train))
    for method in methods:
        if method in skipped:
            result["skipped"].append(method)
            continue
        fit = capped(train, method, seed)
        try:
            detector = build(method, contamination, seed)
            found = detect(test, detector, fit_df=fit)
            result["runs"][method] = {
                "metrics": compute_metrics(y[partitions["test"]], found.flags, found.scores),
                "scores": found.scores.tolist(),
                "flags": found.flags.tolist(),
                "fit_rows": len(fit),
            }
        except Exception as error:
            result["errors"].append({"detector": method, "error": repr(None)})
    return result

mutants_x_evaluate_frozen__mutmut['_mutmut_orig'] = x_evaluate_frozen__mutmut_orig # type: ignore # mutmut generated
mutants_x_evaluate_frozen__mutmut['x_evaluate_frozen__mutmut_1'] = x_evaluate_frozen__mutmut_1 # type: ignore # mutmut generated
mutants_x_evaluate_frozen__mutmut['x_evaluate_frozen__mutmut_2'] = x_evaluate_frozen__mutmut_2 # type: ignore # mutmut generated
mutants_x_evaluate_frozen__mutmut['x_evaluate_frozen__mutmut_3'] = x_evaluate_frozen__mutmut_3 # type: ignore # mutmut generated
mutants_x_evaluate_frozen__mutmut['x_evaluate_frozen__mutmut_4'] = x_evaluate_frozen__mutmut_4 # type: ignore # mutmut generated
mutants_x_evaluate_frozen__mutmut['x_evaluate_frozen__mutmut_5'] = x_evaluate_frozen__mutmut_5 # type: ignore # mutmut generated
mutants_x_evaluate_frozen__mutmut['x_evaluate_frozen__mutmut_6'] = x_evaluate_frozen__mutmut_6 # type: ignore # mutmut generated
mutants_x_evaluate_frozen__mutmut['x_evaluate_frozen__mutmut_7'] = x_evaluate_frozen__mutmut_7 # type: ignore # mutmut generated
mutants_x_evaluate_frozen__mutmut['x_evaluate_frozen__mutmut_8'] = x_evaluate_frozen__mutmut_8 # type: ignore # mutmut generated
mutants_x_evaluate_frozen__mutmut['x_evaluate_frozen__mutmut_9'] = x_evaluate_frozen__mutmut_9 # type: ignore # mutmut generated
mutants_x_evaluate_frozen__mutmut['x_evaluate_frozen__mutmut_10'] = x_evaluate_frozen__mutmut_10 # type: ignore # mutmut generated
mutants_x_evaluate_frozen__mutmut['x_evaluate_frozen__mutmut_11'] = x_evaluate_frozen__mutmut_11 # type: ignore # mutmut generated
mutants_x_evaluate_frozen__mutmut['x_evaluate_frozen__mutmut_12'] = x_evaluate_frozen__mutmut_12 # type: ignore # mutmut generated
mutants_x_evaluate_frozen__mutmut['x_evaluate_frozen__mutmut_13'] = x_evaluate_frozen__mutmut_13 # type: ignore # mutmut generated
mutants_x_evaluate_frozen__mutmut['x_evaluate_frozen__mutmut_14'] = x_evaluate_frozen__mutmut_14 # type: ignore # mutmut generated
mutants_x_evaluate_frozen__mutmut['x_evaluate_frozen__mutmut_15'] = x_evaluate_frozen__mutmut_15 # type: ignore # mutmut generated
mutants_x_evaluate_frozen__mutmut['x_evaluate_frozen__mutmut_16'] = x_evaluate_frozen__mutmut_16 # type: ignore # mutmut generated
mutants_x_evaluate_frozen__mutmut['x_evaluate_frozen__mutmut_17'] = x_evaluate_frozen__mutmut_17 # type: ignore # mutmut generated
mutants_x_evaluate_frozen__mutmut['x_evaluate_frozen__mutmut_18'] = x_evaluate_frozen__mutmut_18 # type: ignore # mutmut generated
mutants_x_evaluate_frozen__mutmut['x_evaluate_frozen__mutmut_19'] = x_evaluate_frozen__mutmut_19 # type: ignore # mutmut generated
mutants_x_evaluate_frozen__mutmut['x_evaluate_frozen__mutmut_20'] = x_evaluate_frozen__mutmut_20 # type: ignore # mutmut generated
mutants_x_evaluate_frozen__mutmut['x_evaluate_frozen__mutmut_21'] = x_evaluate_frozen__mutmut_21 # type: ignore # mutmut generated
mutants_x_evaluate_frozen__mutmut['x_evaluate_frozen__mutmut_22'] = x_evaluate_frozen__mutmut_22 # type: ignore # mutmut generated
mutants_x_evaluate_frozen__mutmut['x_evaluate_frozen__mutmut_23'] = x_evaluate_frozen__mutmut_23 # type: ignore # mutmut generated
mutants_x_evaluate_frozen__mutmut['x_evaluate_frozen__mutmut_24'] = x_evaluate_frozen__mutmut_24 # type: ignore # mutmut generated
mutants_x_evaluate_frozen__mutmut['x_evaluate_frozen__mutmut_25'] = x_evaluate_frozen__mutmut_25 # type: ignore # mutmut generated
mutants_x_evaluate_frozen__mutmut['x_evaluate_frozen__mutmut_26'] = x_evaluate_frozen__mutmut_26 # type: ignore # mutmut generated
mutants_x_evaluate_frozen__mutmut['x_evaluate_frozen__mutmut_27'] = x_evaluate_frozen__mutmut_27 # type: ignore # mutmut generated
mutants_x_evaluate_frozen__mutmut['x_evaluate_frozen__mutmut_28'] = x_evaluate_frozen__mutmut_28 # type: ignore # mutmut generated
mutants_x_evaluate_frozen__mutmut['x_evaluate_frozen__mutmut_29'] = x_evaluate_frozen__mutmut_29 # type: ignore # mutmut generated
mutants_x_evaluate_frozen__mutmut['x_evaluate_frozen__mutmut_30'] = x_evaluate_frozen__mutmut_30 # type: ignore # mutmut generated
mutants_x_evaluate_frozen__mutmut['x_evaluate_frozen__mutmut_31'] = x_evaluate_frozen__mutmut_31 # type: ignore # mutmut generated
mutants_x_evaluate_frozen__mutmut['x_evaluate_frozen__mutmut_32'] = x_evaluate_frozen__mutmut_32 # type: ignore # mutmut generated
mutants_x_evaluate_frozen__mutmut['x_evaluate_frozen__mutmut_33'] = x_evaluate_frozen__mutmut_33 # type: ignore # mutmut generated
mutants_x_evaluate_frozen__mutmut['x_evaluate_frozen__mutmut_34'] = x_evaluate_frozen__mutmut_34 # type: ignore # mutmut generated
mutants_x_evaluate_frozen__mutmut['x_evaluate_frozen__mutmut_35'] = x_evaluate_frozen__mutmut_35 # type: ignore # mutmut generated
mutants_x_evaluate_frozen__mutmut['x_evaluate_frozen__mutmut_36'] = x_evaluate_frozen__mutmut_36 # type: ignore # mutmut generated
mutants_x_evaluate_frozen__mutmut['x_evaluate_frozen__mutmut_37'] = x_evaluate_frozen__mutmut_37 # type: ignore # mutmut generated
mutants_x_evaluate_frozen__mutmut['x_evaluate_frozen__mutmut_38'] = x_evaluate_frozen__mutmut_38 # type: ignore # mutmut generated
mutants_x_evaluate_frozen__mutmut['x_evaluate_frozen__mutmut_39'] = x_evaluate_frozen__mutmut_39 # type: ignore # mutmut generated
mutants_x_evaluate_frozen__mutmut['x_evaluate_frozen__mutmut_40'] = x_evaluate_frozen__mutmut_40 # type: ignore # mutmut generated
mutants_x_evaluate_frozen__mutmut['x_evaluate_frozen__mutmut_41'] = x_evaluate_frozen__mutmut_41 # type: ignore # mutmut generated
mutants_x_evaluate_frozen__mutmut['x_evaluate_frozen__mutmut_42'] = x_evaluate_frozen__mutmut_42 # type: ignore # mutmut generated
mutants_x_evaluate_frozen__mutmut['x_evaluate_frozen__mutmut_43'] = x_evaluate_frozen__mutmut_43 # type: ignore # mutmut generated
mutants_x_evaluate_frozen__mutmut['x_evaluate_frozen__mutmut_44'] = x_evaluate_frozen__mutmut_44 # type: ignore # mutmut generated
mutants_x_evaluate_frozen__mutmut['x_evaluate_frozen__mutmut_45'] = x_evaluate_frozen__mutmut_45 # type: ignore # mutmut generated
mutants_x_evaluate_frozen__mutmut['x_evaluate_frozen__mutmut_46'] = x_evaluate_frozen__mutmut_46 # type: ignore # mutmut generated
mutants_x_evaluate_frozen__mutmut['x_evaluate_frozen__mutmut_47'] = x_evaluate_frozen__mutmut_47 # type: ignore # mutmut generated
mutants_x_evaluate_frozen__mutmut['x_evaluate_frozen__mutmut_48'] = x_evaluate_frozen__mutmut_48 # type: ignore # mutmut generated
mutants_x_evaluate_frozen__mutmut['x_evaluate_frozen__mutmut_49'] = x_evaluate_frozen__mutmut_49 # type: ignore # mutmut generated
mutants_x_evaluate_frozen__mutmut['x_evaluate_frozen__mutmut_50'] = x_evaluate_frozen__mutmut_50 # type: ignore # mutmut generated
mutants_x_evaluate_frozen__mutmut['x_evaluate_frozen__mutmut_51'] = x_evaluate_frozen__mutmut_51 # type: ignore # mutmut generated
mutants_x_evaluate_frozen__mutmut['x_evaluate_frozen__mutmut_52'] = x_evaluate_frozen__mutmut_52 # type: ignore # mutmut generated
mutants_x_evaluate_frozen__mutmut['x_evaluate_frozen__mutmut_53'] = x_evaluate_frozen__mutmut_53 # type: ignore # mutmut generated
mutants_x_evaluate_frozen__mutmut['x_evaluate_frozen__mutmut_54'] = x_evaluate_frozen__mutmut_54 # type: ignore # mutmut generated
mutants_x_evaluate_frozen__mutmut['x_evaluate_frozen__mutmut_55'] = x_evaluate_frozen__mutmut_55 # type: ignore # mutmut generated
mutants_x_evaluate_frozen__mutmut['x_evaluate_frozen__mutmut_56'] = x_evaluate_frozen__mutmut_56 # type: ignore # mutmut generated
mutants_x_evaluate_frozen__mutmut['x_evaluate_frozen__mutmut_57'] = x_evaluate_frozen__mutmut_57 # type: ignore # mutmut generated
mutants_x_evaluate_frozen__mutmut['x_evaluate_frozen__mutmut_58'] = x_evaluate_frozen__mutmut_58 # type: ignore # mutmut generated
mutants_x_evaluate_frozen__mutmut['x_evaluate_frozen__mutmut_59'] = x_evaluate_frozen__mutmut_59 # type: ignore # mutmut generated
mutants_x_evaluate_frozen__mutmut['x_evaluate_frozen__mutmut_60'] = x_evaluate_frozen__mutmut_60 # type: ignore # mutmut generated
mutants_x_evaluate_frozen__mutmut['x_evaluate_frozen__mutmut_61'] = x_evaluate_frozen__mutmut_61 # type: ignore # mutmut generated
mutants_x_evaluate_frozen__mutmut['x_evaluate_frozen__mutmut_62'] = x_evaluate_frozen__mutmut_62 # type: ignore # mutmut generated
mutants_x_evaluate_frozen__mutmut['x_evaluate_frozen__mutmut_63'] = x_evaluate_frozen__mutmut_63 # type: ignore # mutmut generated
mutants_x_evaluate_frozen__mutmut['x_evaluate_frozen__mutmut_64'] = x_evaluate_frozen__mutmut_64 # type: ignore # mutmut generated
mutants_x_evaluate_frozen__mutmut['x_evaluate_frozen__mutmut_65'] = x_evaluate_frozen__mutmut_65 # type: ignore # mutmut generated
mutants_x_evaluate_frozen__mutmut['x_evaluate_frozen__mutmut_66'] = x_evaluate_frozen__mutmut_66 # type: ignore # mutmut generated
mutants_x_evaluate_frozen__mutmut['x_evaluate_frozen__mutmut_67'] = x_evaluate_frozen__mutmut_67 # type: ignore # mutmut generated
mutants_x_evaluate_frozen__mutmut['x_evaluate_frozen__mutmut_68'] = x_evaluate_frozen__mutmut_68 # type: ignore # mutmut generated
mutants_x_evaluate_frozen__mutmut['x_evaluate_frozen__mutmut_69'] = x_evaluate_frozen__mutmut_69 # type: ignore # mutmut generated
mutants_x_evaluate_frozen__mutmut['x_evaluate_frozen__mutmut_70'] = x_evaluate_frozen__mutmut_70 # type: ignore # mutmut generated
mutants_x_evaluate_frozen__mutmut['x_evaluate_frozen__mutmut_71'] = x_evaluate_frozen__mutmut_71 # type: ignore # mutmut generated
mutants_x_evaluate_frozen__mutmut['x_evaluate_frozen__mutmut_72'] = x_evaluate_frozen__mutmut_72 # type: ignore # mutmut generated
mutants_x_evaluate_frozen__mutmut['x_evaluate_frozen__mutmut_73'] = x_evaluate_frozen__mutmut_73 # type: ignore # mutmut generated
mutants_x_evaluate_frozen__mutmut['x_evaluate_frozen__mutmut_74'] = x_evaluate_frozen__mutmut_74 # type: ignore # mutmut generated
mutants_x_evaluate_frozen__mutmut['x_evaluate_frozen__mutmut_75'] = x_evaluate_frozen__mutmut_75 # type: ignore # mutmut generated
mutants_x_evaluate_frozen__mutmut['x_evaluate_frozen__mutmut_76'] = x_evaluate_frozen__mutmut_76 # type: ignore # mutmut generated
mutants_x_evaluate_frozen__mutmut['x_evaluate_frozen__mutmut_77'] = x_evaluate_frozen__mutmut_77 # type: ignore # mutmut generated
mutants_x_evaluate_frozen__mutmut['x_evaluate_frozen__mutmut_78'] = x_evaluate_frozen__mutmut_78 # type: ignore # mutmut generated
mutants_x_evaluate_frozen__mutmut['x_evaluate_frozen__mutmut_79'] = x_evaluate_frozen__mutmut_79 # type: ignore # mutmut generated
mutants_x_evaluate_frozen__mutmut['x_evaluate_frozen__mutmut_80'] = x_evaluate_frozen__mutmut_80 # type: ignore # mutmut generated
mutants_x_evaluate_frozen__mutmut['x_evaluate_frozen__mutmut_81'] = x_evaluate_frozen__mutmut_81 # type: ignore # mutmut generated
mutants_x_evaluate_frozen__mutmut['x_evaluate_frozen__mutmut_82'] = x_evaluate_frozen__mutmut_82 # type: ignore # mutmut generated
mutants_x_evaluate_frozen__mutmut['x_evaluate_frozen__mutmut_83'] = x_evaluate_frozen__mutmut_83 # type: ignore # mutmut generated
mutants_x_evaluate_frozen__mutmut['x_evaluate_frozen__mutmut_84'] = x_evaluate_frozen__mutmut_84 # type: ignore # mutmut generated
mutants_x_evaluate_frozen__mutmut['x_evaluate_frozen__mutmut_85'] = x_evaluate_frozen__mutmut_85 # type: ignore # mutmut generated
mutants_x_evaluate_frozen__mutmut['x_evaluate_frozen__mutmut_86'] = x_evaluate_frozen__mutmut_86 # type: ignore # mutmut generated
mutants_x_evaluate_frozen__mutmut['x_evaluate_frozen__mutmut_87'] = x_evaluate_frozen__mutmut_87 # type: ignore # mutmut generated
mutants_x_evaluate_frozen__mutmut['x_evaluate_frozen__mutmut_88'] = x_evaluate_frozen__mutmut_88 # type: ignore # mutmut generated
mutants_x_evaluate_frozen__mutmut['x_evaluate_frozen__mutmut_89'] = x_evaluate_frozen__mutmut_89 # type: ignore # mutmut generated
mutants_x_evaluate_frozen__mutmut['x_evaluate_frozen__mutmut_90'] = x_evaluate_frozen__mutmut_90 # type: ignore # mutmut generated
mutants_x_evaluate_frozen__mutmut['x_evaluate_frozen__mutmut_91'] = x_evaluate_frozen__mutmut_91 # type: ignore # mutmut generated
mutants_x_evaluate_frozen__mutmut['x_evaluate_frozen__mutmut_92'] = x_evaluate_frozen__mutmut_92 # type: ignore # mutmut generated
mutants_x_evaluate_frozen__mutmut['x_evaluate_frozen__mutmut_93'] = x_evaluate_frozen__mutmut_93 # type: ignore # mutmut generated
mutants_x_evaluate_frozen__mutmut['x_evaluate_frozen__mutmut_94'] = x_evaluate_frozen__mutmut_94 # type: ignore # mutmut generated
mutants_x_evaluate_frozen__mutmut['x_evaluate_frozen__mutmut_95'] = x_evaluate_frozen__mutmut_95 # type: ignore # mutmut generated
mutants_x_evaluate_frozen__mutmut['x_evaluate_frozen__mutmut_96'] = x_evaluate_frozen__mutmut_96 # type: ignore # mutmut generated
mutants_x_evaluate_frozen__mutmut['x_evaluate_frozen__mutmut_97'] = x_evaluate_frozen__mutmut_97 # type: ignore # mutmut generated
mutants_x_evaluate_frozen__mutmut['x_evaluate_frozen__mutmut_98'] = x_evaluate_frozen__mutmut_98 # type: ignore # mutmut generated
mutants_x_evaluate_frozen__mutmut['x_evaluate_frozen__mutmut_99'] = x_evaluate_frozen__mutmut_99 # type: ignore # mutmut generated
mutants_x_evaluate_frozen__mutmut['x_evaluate_frozen__mutmut_100'] = x_evaluate_frozen__mutmut_100 # type: ignore # mutmut generated
mutants_x_evaluate_frozen__mutmut['x_evaluate_frozen__mutmut_101'] = x_evaluate_frozen__mutmut_101 # type: ignore # mutmut generated
mutants_x_evaluate_frozen__mutmut['x_evaluate_frozen__mutmut_102'] = x_evaluate_frozen__mutmut_102 # type: ignore # mutmut generated
mutants_x_evaluate_frozen__mutmut['x_evaluate_frozen__mutmut_103'] = x_evaluate_frozen__mutmut_103 # type: ignore # mutmut generated
mutants_x_evaluate_frozen__mutmut['x_evaluate_frozen__mutmut_104'] = x_evaluate_frozen__mutmut_104 # type: ignore # mutmut generated
mutants_x_evaluate_frozen__mutmut['x_evaluate_frozen__mutmut_105'] = x_evaluate_frozen__mutmut_105 # type: ignore # mutmut generated
mutants_x_evaluate_frozen__mutmut['x_evaluate_frozen__mutmut_106'] = x_evaluate_frozen__mutmut_106 # type: ignore # mutmut generated
mutants_x_evaluate_frozen__mutmut['x_evaluate_frozen__mutmut_107'] = x_evaluate_frozen__mutmut_107 # type: ignore # mutmut generated
mutants_x_evaluate_frozen__mutmut['x_evaluate_frozen__mutmut_108'] = x_evaluate_frozen__mutmut_108 # type: ignore # mutmut generated
mutants_x_evaluate_frozen__mutmut['x_evaluate_frozen__mutmut_109'] = x_evaluate_frozen__mutmut_109 # type: ignore # mutmut generated
mutants_x_evaluate_frozen__mutmut['x_evaluate_frozen__mutmut_110'] = x_evaluate_frozen__mutmut_110 # type: ignore # mutmut generated
mutants_x_evaluate_frozen__mutmut['x_evaluate_frozen__mutmut_111'] = x_evaluate_frozen__mutmut_111 # type: ignore # mutmut generated
mutants_x_evaluate_frozen__mutmut['x_evaluate_frozen__mutmut_112'] = x_evaluate_frozen__mutmut_112 # type: ignore # mutmut generated
mutants_x_evaluate_frozen__mutmut['x_evaluate_frozen__mutmut_113'] = x_evaluate_frozen__mutmut_113 # type: ignore # mutmut generated
mutants_x_evaluate_frozen__mutmut['x_evaluate_frozen__mutmut_114'] = x_evaluate_frozen__mutmut_114 # type: ignore # mutmut generated
mutants_x_evaluate_frozen__mutmut['x_evaluate_frozen__mutmut_115'] = x_evaluate_frozen__mutmut_115 # type: ignore # mutmut generated
mutants_x_evaluate_frozen__mutmut['x_evaluate_frozen__mutmut_116'] = x_evaluate_frozen__mutmut_116 # type: ignore # mutmut generated
mutants_x_evaluate_frozen__mutmut['x_evaluate_frozen__mutmut_117'] = x_evaluate_frozen__mutmut_117 # type: ignore # mutmut generated
mutants_x_evaluate_frozen__mutmut['x_evaluate_frozen__mutmut_118'] = x_evaluate_frozen__mutmut_118 # type: ignore # mutmut generated
mutants_x_evaluate_frozen__mutmut['x_evaluate_frozen__mutmut_119'] = x_evaluate_frozen__mutmut_119 # type: ignore # mutmut generated
mutants_x_evaluate_frozen__mutmut['x_evaluate_frozen__mutmut_120'] = x_evaluate_frozen__mutmut_120 # type: ignore # mutmut generated
mutants_x_evaluate_frozen__mutmut['x_evaluate_frozen__mutmut_121'] = x_evaluate_frozen__mutmut_121 # type: ignore # mutmut generated
mutants_x_evaluate_frozen__mutmut['x_evaluate_frozen__mutmut_122'] = x_evaluate_frozen__mutmut_122 # type: ignore # mutmut generated
mutants_x_evaluate_frozen__mutmut['x_evaluate_frozen__mutmut_123'] = x_evaluate_frozen__mutmut_123 # type: ignore # mutmut generated
mutants_x_evaluate_frozen__mutmut['x_evaluate_frozen__mutmut_124'] = x_evaluate_frozen__mutmut_124 # type: ignore # mutmut generated
mutants_x_evaluate_frozen__mutmut['x_evaluate_frozen__mutmut_125'] = x_evaluate_frozen__mutmut_125 # type: ignore # mutmut generated
mutants_x_evaluate_frozen__mutmut['x_evaluate_frozen__mutmut_126'] = x_evaluate_frozen__mutmut_126 # type: ignore # mutmut generated
mutants_x_evaluate_frozen__mutmut['x_evaluate_frozen__mutmut_127'] = x_evaluate_frozen__mutmut_127 # type: ignore # mutmut generated
mutants_x_evaluate_frozen__mutmut['x_evaluate_frozen__mutmut_128'] = x_evaluate_frozen__mutmut_128 # type: ignore # mutmut generated
mutants_x_evaluate_frozen__mutmut['x_evaluate_frozen__mutmut_129'] = x_evaluate_frozen__mutmut_129 # type: ignore # mutmut generated
mutants_x_evaluate_frozen__mutmut['x_evaluate_frozen__mutmut_130'] = x_evaluate_frozen__mutmut_130 # type: ignore # mutmut generated
mutants_x_evaluate_frozen__mutmut['x_evaluate_frozen__mutmut_131'] = x_evaluate_frozen__mutmut_131 # type: ignore # mutmut generated
mutants_x_evaluate_frozen__mutmut['x_evaluate_frozen__mutmut_132'] = x_evaluate_frozen__mutmut_132 # type: ignore # mutmut generated
mutants_x_evaluate_frozen__mutmut['x_evaluate_frozen__mutmut_133'] = x_evaluate_frozen__mutmut_133 # type: ignore # mutmut generated
mutants_x_evaluate_frozen__mutmut['x_evaluate_frozen__mutmut_134'] = x_evaluate_frozen__mutmut_134 # type: ignore # mutmut generated
mutants_x_evaluate_frozen__mutmut['x_evaluate_frozen__mutmut_135'] = x_evaluate_frozen__mutmut_135 # type: ignore # mutmut generated
mutants_x_evaluate_frozen__mutmut['x_evaluate_frozen__mutmut_136'] = x_evaluate_frozen__mutmut_136 # type: ignore # mutmut generated
mutants_x_evaluate_frozen__mutmut['x_evaluate_frozen__mutmut_137'] = x_evaluate_frozen__mutmut_137 # type: ignore # mutmut generated
mutants_x_evaluate_frozen__mutmut['x_evaluate_frozen__mutmut_138'] = x_evaluate_frozen__mutmut_138 # type: ignore # mutmut generated
mutants_x_evaluate_frozen__mutmut['x_evaluate_frozen__mutmut_139'] = x_evaluate_frozen__mutmut_139 # type: ignore # mutmut generated
mutants_x_evaluate_frozen__mutmut['x_evaluate_frozen__mutmut_140'] = x_evaluate_frozen__mutmut_140 # type: ignore # mutmut generated
mutants_x_evaluate_frozen__mutmut['x_evaluate_frozen__mutmut_141'] = x_evaluate_frozen__mutmut_141 # type: ignore # mutmut generated
mutants_x_evaluate_frozen__mutmut['x_evaluate_frozen__mutmut_142'] = x_evaluate_frozen__mutmut_142 # type: ignore # mutmut generated
mutants_x_evaluate_frozen__mutmut['x_evaluate_frozen__mutmut_143'] = x_evaluate_frozen__mutmut_143 # type: ignore # mutmut generated
mutants_x_evaluate_frozen__mutmut['x_evaluate_frozen__mutmut_144'] = x_evaluate_frozen__mutmut_144 # type: ignore # mutmut generated
mutants_x_evaluate_frozen__mutmut['x_evaluate_frozen__mutmut_145'] = x_evaluate_frozen__mutmut_145 # type: ignore # mutmut generated
mutants_x_evaluate_frozen__mutmut['x_evaluate_frozen__mutmut_146'] = x_evaluate_frozen__mutmut_146 # type: ignore # mutmut generated
mutants_x_evaluate_frozen__mutmut['x_evaluate_frozen__mutmut_147'] = x_evaluate_frozen__mutmut_147 # type: ignore # mutmut generated
mutants_x_evaluate_frozen__mutmut['x_evaluate_frozen__mutmut_148'] = x_evaluate_frozen__mutmut_148 # type: ignore # mutmut generated
mutants_x__sha256__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x__sha256__mutmut)
def _sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def x__sha256__mutmut_orig(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def x__sha256__mutmut_1(path: Path) -> str:
    return hashlib.sha256(None).hexdigest()

mutants_x__sha256__mutmut['_mutmut_orig'] = x__sha256__mutmut_orig # type: ignore # mutmut generated
mutants_x__sha256__mutmut['x__sha256__mutmut_1'] = x__sha256__mutmut_1 # type: ignore # mutmut generated
mutants_x__optional_version__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x__optional_version__mutmut)
def _optional_version(package: str) -> str | None:
    try:
        return version(package)
    except PackageNotFoundError:
        return None


def x__optional_version__mutmut_orig(package: str) -> str | None:
    try:
        return version(package)
    except PackageNotFoundError:
        return None


def x__optional_version__mutmut_1(package: str) -> str | None:
    try:
        return version(None)
    except PackageNotFoundError:
        return None

mutants_x__optional_version__mutmut['_mutmut_orig'] = x__optional_version__mutmut_orig # type: ignore # mutmut generated
mutants_x__optional_version__mutmut['x__optional_version__mutmut_1'] = x__optional_version__mutmut_1 # type: ignore # mutmut generated
mutants_x_main__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_main__mutmut)
def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=Path, required=True)
    parser.add_argument("--partitions", type=Path, required=True)
    parser.add_argument("--label-column", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--detectors", nargs="+", required=True)
    args = parser.parse_args(argv)
    record_path = args.output.with_suffix(".record.json")
    if args.output.exists() or record_path.exists():
        raise FileExistsError("choose unused output and record paths")
    manifest = json.loads(args.partitions.read_text())
    if manifest["schema_version"] != 1 or manifest["input_sha256"] != _sha256(args.csv):
        raise ValueError("partition manifest version or source hash differs")
    with args.csv.open(newline="") as stream:
        header = next(csv.reader(stream))
    if len(set(header)) != len(header):
        raise ValueError("duplicate CSV column names are not accepted")
    frame = pd.read_csv(args.csv, dtype=str)
    if manifest["row_count"] != len(frame):
        raise ValueError("partition manifest row count differs")
    labels = pd.to_numeric(frame.pop(args.label_column), errors="raise").to_numpy()
    result = evaluate_frozen(
        frame, labels, manifest["partitions"], seed=manifest["seed"], methods=args.detectors
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    write_record(
        record_path,
        experiment=PROTOCOL,
        seeds=[manifest["seed"]],
        dataset=args.csv.name,
        data_path=args.csv,
        settings={
            "protocol": PROTOCOL,
            "exploratory": True,
            "label_column": args.label_column,
            "detectors": args.detectors,
            "partition_sha256": _sha256(args.partitions),
            "research_sha256": {name: _sha256(ROOT / name) for name in RESEARCH_SOURCES},
            "torch": _optional_version("torch"),
        },
        outputs=[args.output.name],
    )
    return 1 if result["errors"] or not result["runs"] else 0


def x_main__mutmut_orig(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=Path, required=True)
    parser.add_argument("--partitions", type=Path, required=True)
    parser.add_argument("--label-column", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--detectors", nargs="+", required=True)
    args = parser.parse_args(argv)
    record_path = args.output.with_suffix(".record.json")
    if args.output.exists() or record_path.exists():
        raise FileExistsError("choose unused output and record paths")
    manifest = json.loads(args.partitions.read_text())
    if manifest["schema_version"] != 1 or manifest["input_sha256"] != _sha256(args.csv):
        raise ValueError("partition manifest version or source hash differs")
    with args.csv.open(newline="") as stream:
        header = next(csv.reader(stream))
    if len(set(header)) != len(header):
        raise ValueError("duplicate CSV column names are not accepted")
    frame = pd.read_csv(args.csv, dtype=str)
    if manifest["row_count"] != len(frame):
        raise ValueError("partition manifest row count differs")
    labels = pd.to_numeric(frame.pop(args.label_column), errors="raise").to_numpy()
    result = evaluate_frozen(
        frame, labels, manifest["partitions"], seed=manifest["seed"], methods=args.detectors
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    write_record(
        record_path,
        experiment=PROTOCOL,
        seeds=[manifest["seed"]],
        dataset=args.csv.name,
        data_path=args.csv,
        settings={
            "protocol": PROTOCOL,
            "exploratory": True,
            "label_column": args.label_column,
            "detectors": args.detectors,
            "partition_sha256": _sha256(args.partitions),
            "research_sha256": {name: _sha256(ROOT / name) for name in RESEARCH_SOURCES},
            "torch": _optional_version("torch"),
        },
        outputs=[args.output.name],
    )
    return 1 if result["errors"] or not result["runs"] else 0


def x_main__mutmut_1(argv: list[str] | None = None) -> int:
    parser = None
    parser.add_argument("--csv", type=Path, required=True)
    parser.add_argument("--partitions", type=Path, required=True)
    parser.add_argument("--label-column", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--detectors", nargs="+", required=True)
    args = parser.parse_args(argv)
    record_path = args.output.with_suffix(".record.json")
    if args.output.exists() or record_path.exists():
        raise FileExistsError("choose unused output and record paths")
    manifest = json.loads(args.partitions.read_text())
    if manifest["schema_version"] != 1 or manifest["input_sha256"] != _sha256(args.csv):
        raise ValueError("partition manifest version or source hash differs")
    with args.csv.open(newline="") as stream:
        header = next(csv.reader(stream))
    if len(set(header)) != len(header):
        raise ValueError("duplicate CSV column names are not accepted")
    frame = pd.read_csv(args.csv, dtype=str)
    if manifest["row_count"] != len(frame):
        raise ValueError("partition manifest row count differs")
    labels = pd.to_numeric(frame.pop(args.label_column), errors="raise").to_numpy()
    result = evaluate_frozen(
        frame, labels, manifest["partitions"], seed=manifest["seed"], methods=args.detectors
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    write_record(
        record_path,
        experiment=PROTOCOL,
        seeds=[manifest["seed"]],
        dataset=args.csv.name,
        data_path=args.csv,
        settings={
            "protocol": PROTOCOL,
            "exploratory": True,
            "label_column": args.label_column,
            "detectors": args.detectors,
            "partition_sha256": _sha256(args.partitions),
            "research_sha256": {name: _sha256(ROOT / name) for name in RESEARCH_SOURCES},
            "torch": _optional_version("torch"),
        },
        outputs=[args.output.name],
    )
    return 1 if result["errors"] or not result["runs"] else 0


def x_main__mutmut_2(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=None)
    parser.add_argument("--csv", type=Path, required=True)
    parser.add_argument("--partitions", type=Path, required=True)
    parser.add_argument("--label-column", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--detectors", nargs="+", required=True)
    args = parser.parse_args(argv)
    record_path = args.output.with_suffix(".record.json")
    if args.output.exists() or record_path.exists():
        raise FileExistsError("choose unused output and record paths")
    manifest = json.loads(args.partitions.read_text())
    if manifest["schema_version"] != 1 or manifest["input_sha256"] != _sha256(args.csv):
        raise ValueError("partition manifest version or source hash differs")
    with args.csv.open(newline="") as stream:
        header = next(csv.reader(stream))
    if len(set(header)) != len(header):
        raise ValueError("duplicate CSV column names are not accepted")
    frame = pd.read_csv(args.csv, dtype=str)
    if manifest["row_count"] != len(frame):
        raise ValueError("partition manifest row count differs")
    labels = pd.to_numeric(frame.pop(args.label_column), errors="raise").to_numpy()
    result = evaluate_frozen(
        frame, labels, manifest["partitions"], seed=manifest["seed"], methods=args.detectors
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    write_record(
        record_path,
        experiment=PROTOCOL,
        seeds=[manifest["seed"]],
        dataset=args.csv.name,
        data_path=args.csv,
        settings={
            "protocol": PROTOCOL,
            "exploratory": True,
            "label_column": args.label_column,
            "detectors": args.detectors,
            "partition_sha256": _sha256(args.partitions),
            "research_sha256": {name: _sha256(ROOT / name) for name in RESEARCH_SOURCES},
            "torch": _optional_version("torch"),
        },
        outputs=[args.output.name],
    )
    return 1 if result["errors"] or not result["runs"] else 0


def x_main__mutmut_3(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(None, type=Path, required=True)
    parser.add_argument("--partitions", type=Path, required=True)
    parser.add_argument("--label-column", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--detectors", nargs="+", required=True)
    args = parser.parse_args(argv)
    record_path = args.output.with_suffix(".record.json")
    if args.output.exists() or record_path.exists():
        raise FileExistsError("choose unused output and record paths")
    manifest = json.loads(args.partitions.read_text())
    if manifest["schema_version"] != 1 or manifest["input_sha256"] != _sha256(args.csv):
        raise ValueError("partition manifest version or source hash differs")
    with args.csv.open(newline="") as stream:
        header = next(csv.reader(stream))
    if len(set(header)) != len(header):
        raise ValueError("duplicate CSV column names are not accepted")
    frame = pd.read_csv(args.csv, dtype=str)
    if manifest["row_count"] != len(frame):
        raise ValueError("partition manifest row count differs")
    labels = pd.to_numeric(frame.pop(args.label_column), errors="raise").to_numpy()
    result = evaluate_frozen(
        frame, labels, manifest["partitions"], seed=manifest["seed"], methods=args.detectors
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    write_record(
        record_path,
        experiment=PROTOCOL,
        seeds=[manifest["seed"]],
        dataset=args.csv.name,
        data_path=args.csv,
        settings={
            "protocol": PROTOCOL,
            "exploratory": True,
            "label_column": args.label_column,
            "detectors": args.detectors,
            "partition_sha256": _sha256(args.partitions),
            "research_sha256": {name: _sha256(ROOT / name) for name in RESEARCH_SOURCES},
            "torch": _optional_version("torch"),
        },
        outputs=[args.output.name],
    )
    return 1 if result["errors"] or not result["runs"] else 0


def x_main__mutmut_4(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=None, required=True)
    parser.add_argument("--partitions", type=Path, required=True)
    parser.add_argument("--label-column", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--detectors", nargs="+", required=True)
    args = parser.parse_args(argv)
    record_path = args.output.with_suffix(".record.json")
    if args.output.exists() or record_path.exists():
        raise FileExistsError("choose unused output and record paths")
    manifest = json.loads(args.partitions.read_text())
    if manifest["schema_version"] != 1 or manifest["input_sha256"] != _sha256(args.csv):
        raise ValueError("partition manifest version or source hash differs")
    with args.csv.open(newline="") as stream:
        header = next(csv.reader(stream))
    if len(set(header)) != len(header):
        raise ValueError("duplicate CSV column names are not accepted")
    frame = pd.read_csv(args.csv, dtype=str)
    if manifest["row_count"] != len(frame):
        raise ValueError("partition manifest row count differs")
    labels = pd.to_numeric(frame.pop(args.label_column), errors="raise").to_numpy()
    result = evaluate_frozen(
        frame, labels, manifest["partitions"], seed=manifest["seed"], methods=args.detectors
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    write_record(
        record_path,
        experiment=PROTOCOL,
        seeds=[manifest["seed"]],
        dataset=args.csv.name,
        data_path=args.csv,
        settings={
            "protocol": PROTOCOL,
            "exploratory": True,
            "label_column": args.label_column,
            "detectors": args.detectors,
            "partition_sha256": _sha256(args.partitions),
            "research_sha256": {name: _sha256(ROOT / name) for name in RESEARCH_SOURCES},
            "torch": _optional_version("torch"),
        },
        outputs=[args.output.name],
    )
    return 1 if result["errors"] or not result["runs"] else 0


def x_main__mutmut_5(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=Path, required=None)
    parser.add_argument("--partitions", type=Path, required=True)
    parser.add_argument("--label-column", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--detectors", nargs="+", required=True)
    args = parser.parse_args(argv)
    record_path = args.output.with_suffix(".record.json")
    if args.output.exists() or record_path.exists():
        raise FileExistsError("choose unused output and record paths")
    manifest = json.loads(args.partitions.read_text())
    if manifest["schema_version"] != 1 or manifest["input_sha256"] != _sha256(args.csv):
        raise ValueError("partition manifest version or source hash differs")
    with args.csv.open(newline="") as stream:
        header = next(csv.reader(stream))
    if len(set(header)) != len(header):
        raise ValueError("duplicate CSV column names are not accepted")
    frame = pd.read_csv(args.csv, dtype=str)
    if manifest["row_count"] != len(frame):
        raise ValueError("partition manifest row count differs")
    labels = pd.to_numeric(frame.pop(args.label_column), errors="raise").to_numpy()
    result = evaluate_frozen(
        frame, labels, manifest["partitions"], seed=manifest["seed"], methods=args.detectors
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    write_record(
        record_path,
        experiment=PROTOCOL,
        seeds=[manifest["seed"]],
        dataset=args.csv.name,
        data_path=args.csv,
        settings={
            "protocol": PROTOCOL,
            "exploratory": True,
            "label_column": args.label_column,
            "detectors": args.detectors,
            "partition_sha256": _sha256(args.partitions),
            "research_sha256": {name: _sha256(ROOT / name) for name in RESEARCH_SOURCES},
            "torch": _optional_version("torch"),
        },
        outputs=[args.output.name],
    )
    return 1 if result["errors"] or not result["runs"] else 0


def x_main__mutmut_6(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(type=Path, required=True)
    parser.add_argument("--partitions", type=Path, required=True)
    parser.add_argument("--label-column", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--detectors", nargs="+", required=True)
    args = parser.parse_args(argv)
    record_path = args.output.with_suffix(".record.json")
    if args.output.exists() or record_path.exists():
        raise FileExistsError("choose unused output and record paths")
    manifest = json.loads(args.partitions.read_text())
    if manifest["schema_version"] != 1 or manifest["input_sha256"] != _sha256(args.csv):
        raise ValueError("partition manifest version or source hash differs")
    with args.csv.open(newline="") as stream:
        header = next(csv.reader(stream))
    if len(set(header)) != len(header):
        raise ValueError("duplicate CSV column names are not accepted")
    frame = pd.read_csv(args.csv, dtype=str)
    if manifest["row_count"] != len(frame):
        raise ValueError("partition manifest row count differs")
    labels = pd.to_numeric(frame.pop(args.label_column), errors="raise").to_numpy()
    result = evaluate_frozen(
        frame, labels, manifest["partitions"], seed=manifest["seed"], methods=args.detectors
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    write_record(
        record_path,
        experiment=PROTOCOL,
        seeds=[manifest["seed"]],
        dataset=args.csv.name,
        data_path=args.csv,
        settings={
            "protocol": PROTOCOL,
            "exploratory": True,
            "label_column": args.label_column,
            "detectors": args.detectors,
            "partition_sha256": _sha256(args.partitions),
            "research_sha256": {name: _sha256(ROOT / name) for name in RESEARCH_SOURCES},
            "torch": _optional_version("torch"),
        },
        outputs=[args.output.name],
    )
    return 1 if result["errors"] or not result["runs"] else 0


def x_main__mutmut_7(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", required=True)
    parser.add_argument("--partitions", type=Path, required=True)
    parser.add_argument("--label-column", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--detectors", nargs="+", required=True)
    args = parser.parse_args(argv)
    record_path = args.output.with_suffix(".record.json")
    if args.output.exists() or record_path.exists():
        raise FileExistsError("choose unused output and record paths")
    manifest = json.loads(args.partitions.read_text())
    if manifest["schema_version"] != 1 or manifest["input_sha256"] != _sha256(args.csv):
        raise ValueError("partition manifest version or source hash differs")
    with args.csv.open(newline="") as stream:
        header = next(csv.reader(stream))
    if len(set(header)) != len(header):
        raise ValueError("duplicate CSV column names are not accepted")
    frame = pd.read_csv(args.csv, dtype=str)
    if manifest["row_count"] != len(frame):
        raise ValueError("partition manifest row count differs")
    labels = pd.to_numeric(frame.pop(args.label_column), errors="raise").to_numpy()
    result = evaluate_frozen(
        frame, labels, manifest["partitions"], seed=manifest["seed"], methods=args.detectors
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    write_record(
        record_path,
        experiment=PROTOCOL,
        seeds=[manifest["seed"]],
        dataset=args.csv.name,
        data_path=args.csv,
        settings={
            "protocol": PROTOCOL,
            "exploratory": True,
            "label_column": args.label_column,
            "detectors": args.detectors,
            "partition_sha256": _sha256(args.partitions),
            "research_sha256": {name: _sha256(ROOT / name) for name in RESEARCH_SOURCES},
            "torch": _optional_version("torch"),
        },
        outputs=[args.output.name],
    )
    return 1 if result["errors"] or not result["runs"] else 0


def x_main__mutmut_8(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=Path, )
    parser.add_argument("--partitions", type=Path, required=True)
    parser.add_argument("--label-column", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--detectors", nargs="+", required=True)
    args = parser.parse_args(argv)
    record_path = args.output.with_suffix(".record.json")
    if args.output.exists() or record_path.exists():
        raise FileExistsError("choose unused output and record paths")
    manifest = json.loads(args.partitions.read_text())
    if manifest["schema_version"] != 1 or manifest["input_sha256"] != _sha256(args.csv):
        raise ValueError("partition manifest version or source hash differs")
    with args.csv.open(newline="") as stream:
        header = next(csv.reader(stream))
    if len(set(header)) != len(header):
        raise ValueError("duplicate CSV column names are not accepted")
    frame = pd.read_csv(args.csv, dtype=str)
    if manifest["row_count"] != len(frame):
        raise ValueError("partition manifest row count differs")
    labels = pd.to_numeric(frame.pop(args.label_column), errors="raise").to_numpy()
    result = evaluate_frozen(
        frame, labels, manifest["partitions"], seed=manifest["seed"], methods=args.detectors
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    write_record(
        record_path,
        experiment=PROTOCOL,
        seeds=[manifest["seed"]],
        dataset=args.csv.name,
        data_path=args.csv,
        settings={
            "protocol": PROTOCOL,
            "exploratory": True,
            "label_column": args.label_column,
            "detectors": args.detectors,
            "partition_sha256": _sha256(args.partitions),
            "research_sha256": {name: _sha256(ROOT / name) for name in RESEARCH_SOURCES},
            "torch": _optional_version("torch"),
        },
        outputs=[args.output.name],
    )
    return 1 if result["errors"] or not result["runs"] else 0


def x_main__mutmut_9(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("XX--csvXX", type=Path, required=True)
    parser.add_argument("--partitions", type=Path, required=True)
    parser.add_argument("--label-column", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--detectors", nargs="+", required=True)
    args = parser.parse_args(argv)
    record_path = args.output.with_suffix(".record.json")
    if args.output.exists() or record_path.exists():
        raise FileExistsError("choose unused output and record paths")
    manifest = json.loads(args.partitions.read_text())
    if manifest["schema_version"] != 1 or manifest["input_sha256"] != _sha256(args.csv):
        raise ValueError("partition manifest version or source hash differs")
    with args.csv.open(newline="") as stream:
        header = next(csv.reader(stream))
    if len(set(header)) != len(header):
        raise ValueError("duplicate CSV column names are not accepted")
    frame = pd.read_csv(args.csv, dtype=str)
    if manifest["row_count"] != len(frame):
        raise ValueError("partition manifest row count differs")
    labels = pd.to_numeric(frame.pop(args.label_column), errors="raise").to_numpy()
    result = evaluate_frozen(
        frame, labels, manifest["partitions"], seed=manifest["seed"], methods=args.detectors
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    write_record(
        record_path,
        experiment=PROTOCOL,
        seeds=[manifest["seed"]],
        dataset=args.csv.name,
        data_path=args.csv,
        settings={
            "protocol": PROTOCOL,
            "exploratory": True,
            "label_column": args.label_column,
            "detectors": args.detectors,
            "partition_sha256": _sha256(args.partitions),
            "research_sha256": {name: _sha256(ROOT / name) for name in RESEARCH_SOURCES},
            "torch": _optional_version("torch"),
        },
        outputs=[args.output.name],
    )
    return 1 if result["errors"] or not result["runs"] else 0


def x_main__mutmut_10(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--CSV", type=Path, required=True)
    parser.add_argument("--partitions", type=Path, required=True)
    parser.add_argument("--label-column", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--detectors", nargs="+", required=True)
    args = parser.parse_args(argv)
    record_path = args.output.with_suffix(".record.json")
    if args.output.exists() or record_path.exists():
        raise FileExistsError("choose unused output and record paths")
    manifest = json.loads(args.partitions.read_text())
    if manifest["schema_version"] != 1 or manifest["input_sha256"] != _sha256(args.csv):
        raise ValueError("partition manifest version or source hash differs")
    with args.csv.open(newline="") as stream:
        header = next(csv.reader(stream))
    if len(set(header)) != len(header):
        raise ValueError("duplicate CSV column names are not accepted")
    frame = pd.read_csv(args.csv, dtype=str)
    if manifest["row_count"] != len(frame):
        raise ValueError("partition manifest row count differs")
    labels = pd.to_numeric(frame.pop(args.label_column), errors="raise").to_numpy()
    result = evaluate_frozen(
        frame, labels, manifest["partitions"], seed=manifest["seed"], methods=args.detectors
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    write_record(
        record_path,
        experiment=PROTOCOL,
        seeds=[manifest["seed"]],
        dataset=args.csv.name,
        data_path=args.csv,
        settings={
            "protocol": PROTOCOL,
            "exploratory": True,
            "label_column": args.label_column,
            "detectors": args.detectors,
            "partition_sha256": _sha256(args.partitions),
            "research_sha256": {name: _sha256(ROOT / name) for name in RESEARCH_SOURCES},
            "torch": _optional_version("torch"),
        },
        outputs=[args.output.name],
    )
    return 1 if result["errors"] or not result["runs"] else 0


def x_main__mutmut_11(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=Path, required=False)
    parser.add_argument("--partitions", type=Path, required=True)
    parser.add_argument("--label-column", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--detectors", nargs="+", required=True)
    args = parser.parse_args(argv)
    record_path = args.output.with_suffix(".record.json")
    if args.output.exists() or record_path.exists():
        raise FileExistsError("choose unused output and record paths")
    manifest = json.loads(args.partitions.read_text())
    if manifest["schema_version"] != 1 or manifest["input_sha256"] != _sha256(args.csv):
        raise ValueError("partition manifest version or source hash differs")
    with args.csv.open(newline="") as stream:
        header = next(csv.reader(stream))
    if len(set(header)) != len(header):
        raise ValueError("duplicate CSV column names are not accepted")
    frame = pd.read_csv(args.csv, dtype=str)
    if manifest["row_count"] != len(frame):
        raise ValueError("partition manifest row count differs")
    labels = pd.to_numeric(frame.pop(args.label_column), errors="raise").to_numpy()
    result = evaluate_frozen(
        frame, labels, manifest["partitions"], seed=manifest["seed"], methods=args.detectors
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    write_record(
        record_path,
        experiment=PROTOCOL,
        seeds=[manifest["seed"]],
        dataset=args.csv.name,
        data_path=args.csv,
        settings={
            "protocol": PROTOCOL,
            "exploratory": True,
            "label_column": args.label_column,
            "detectors": args.detectors,
            "partition_sha256": _sha256(args.partitions),
            "research_sha256": {name: _sha256(ROOT / name) for name in RESEARCH_SOURCES},
            "torch": _optional_version("torch"),
        },
        outputs=[args.output.name],
    )
    return 1 if result["errors"] or not result["runs"] else 0


def x_main__mutmut_12(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=Path, required=True)
    parser.add_argument(None, type=Path, required=True)
    parser.add_argument("--label-column", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--detectors", nargs="+", required=True)
    args = parser.parse_args(argv)
    record_path = args.output.with_suffix(".record.json")
    if args.output.exists() or record_path.exists():
        raise FileExistsError("choose unused output and record paths")
    manifest = json.loads(args.partitions.read_text())
    if manifest["schema_version"] != 1 or manifest["input_sha256"] != _sha256(args.csv):
        raise ValueError("partition manifest version or source hash differs")
    with args.csv.open(newline="") as stream:
        header = next(csv.reader(stream))
    if len(set(header)) != len(header):
        raise ValueError("duplicate CSV column names are not accepted")
    frame = pd.read_csv(args.csv, dtype=str)
    if manifest["row_count"] != len(frame):
        raise ValueError("partition manifest row count differs")
    labels = pd.to_numeric(frame.pop(args.label_column), errors="raise").to_numpy()
    result = evaluate_frozen(
        frame, labels, manifest["partitions"], seed=manifest["seed"], methods=args.detectors
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    write_record(
        record_path,
        experiment=PROTOCOL,
        seeds=[manifest["seed"]],
        dataset=args.csv.name,
        data_path=args.csv,
        settings={
            "protocol": PROTOCOL,
            "exploratory": True,
            "label_column": args.label_column,
            "detectors": args.detectors,
            "partition_sha256": _sha256(args.partitions),
            "research_sha256": {name: _sha256(ROOT / name) for name in RESEARCH_SOURCES},
            "torch": _optional_version("torch"),
        },
        outputs=[args.output.name],
    )
    return 1 if result["errors"] or not result["runs"] else 0


def x_main__mutmut_13(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=Path, required=True)
    parser.add_argument("--partitions", type=None, required=True)
    parser.add_argument("--label-column", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--detectors", nargs="+", required=True)
    args = parser.parse_args(argv)
    record_path = args.output.with_suffix(".record.json")
    if args.output.exists() or record_path.exists():
        raise FileExistsError("choose unused output and record paths")
    manifest = json.loads(args.partitions.read_text())
    if manifest["schema_version"] != 1 or manifest["input_sha256"] != _sha256(args.csv):
        raise ValueError("partition manifest version or source hash differs")
    with args.csv.open(newline="") as stream:
        header = next(csv.reader(stream))
    if len(set(header)) != len(header):
        raise ValueError("duplicate CSV column names are not accepted")
    frame = pd.read_csv(args.csv, dtype=str)
    if manifest["row_count"] != len(frame):
        raise ValueError("partition manifest row count differs")
    labels = pd.to_numeric(frame.pop(args.label_column), errors="raise").to_numpy()
    result = evaluate_frozen(
        frame, labels, manifest["partitions"], seed=manifest["seed"], methods=args.detectors
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    write_record(
        record_path,
        experiment=PROTOCOL,
        seeds=[manifest["seed"]],
        dataset=args.csv.name,
        data_path=args.csv,
        settings={
            "protocol": PROTOCOL,
            "exploratory": True,
            "label_column": args.label_column,
            "detectors": args.detectors,
            "partition_sha256": _sha256(args.partitions),
            "research_sha256": {name: _sha256(ROOT / name) for name in RESEARCH_SOURCES},
            "torch": _optional_version("torch"),
        },
        outputs=[args.output.name],
    )
    return 1 if result["errors"] or not result["runs"] else 0


def x_main__mutmut_14(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=Path, required=True)
    parser.add_argument("--partitions", type=Path, required=None)
    parser.add_argument("--label-column", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--detectors", nargs="+", required=True)
    args = parser.parse_args(argv)
    record_path = args.output.with_suffix(".record.json")
    if args.output.exists() or record_path.exists():
        raise FileExistsError("choose unused output and record paths")
    manifest = json.loads(args.partitions.read_text())
    if manifest["schema_version"] != 1 or manifest["input_sha256"] != _sha256(args.csv):
        raise ValueError("partition manifest version or source hash differs")
    with args.csv.open(newline="") as stream:
        header = next(csv.reader(stream))
    if len(set(header)) != len(header):
        raise ValueError("duplicate CSV column names are not accepted")
    frame = pd.read_csv(args.csv, dtype=str)
    if manifest["row_count"] != len(frame):
        raise ValueError("partition manifest row count differs")
    labels = pd.to_numeric(frame.pop(args.label_column), errors="raise").to_numpy()
    result = evaluate_frozen(
        frame, labels, manifest["partitions"], seed=manifest["seed"], methods=args.detectors
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    write_record(
        record_path,
        experiment=PROTOCOL,
        seeds=[manifest["seed"]],
        dataset=args.csv.name,
        data_path=args.csv,
        settings={
            "protocol": PROTOCOL,
            "exploratory": True,
            "label_column": args.label_column,
            "detectors": args.detectors,
            "partition_sha256": _sha256(args.partitions),
            "research_sha256": {name: _sha256(ROOT / name) for name in RESEARCH_SOURCES},
            "torch": _optional_version("torch"),
        },
        outputs=[args.output.name],
    )
    return 1 if result["errors"] or not result["runs"] else 0


def x_main__mutmut_15(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=Path, required=True)
    parser.add_argument(type=Path, required=True)
    parser.add_argument("--label-column", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--detectors", nargs="+", required=True)
    args = parser.parse_args(argv)
    record_path = args.output.with_suffix(".record.json")
    if args.output.exists() or record_path.exists():
        raise FileExistsError("choose unused output and record paths")
    manifest = json.loads(args.partitions.read_text())
    if manifest["schema_version"] != 1 or manifest["input_sha256"] != _sha256(args.csv):
        raise ValueError("partition manifest version or source hash differs")
    with args.csv.open(newline="") as stream:
        header = next(csv.reader(stream))
    if len(set(header)) != len(header):
        raise ValueError("duplicate CSV column names are not accepted")
    frame = pd.read_csv(args.csv, dtype=str)
    if manifest["row_count"] != len(frame):
        raise ValueError("partition manifest row count differs")
    labels = pd.to_numeric(frame.pop(args.label_column), errors="raise").to_numpy()
    result = evaluate_frozen(
        frame, labels, manifest["partitions"], seed=manifest["seed"], methods=args.detectors
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    write_record(
        record_path,
        experiment=PROTOCOL,
        seeds=[manifest["seed"]],
        dataset=args.csv.name,
        data_path=args.csv,
        settings={
            "protocol": PROTOCOL,
            "exploratory": True,
            "label_column": args.label_column,
            "detectors": args.detectors,
            "partition_sha256": _sha256(args.partitions),
            "research_sha256": {name: _sha256(ROOT / name) for name in RESEARCH_SOURCES},
            "torch": _optional_version("torch"),
        },
        outputs=[args.output.name],
    )
    return 1 if result["errors"] or not result["runs"] else 0


def x_main__mutmut_16(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=Path, required=True)
    parser.add_argument("--partitions", required=True)
    parser.add_argument("--label-column", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--detectors", nargs="+", required=True)
    args = parser.parse_args(argv)
    record_path = args.output.with_suffix(".record.json")
    if args.output.exists() or record_path.exists():
        raise FileExistsError("choose unused output and record paths")
    manifest = json.loads(args.partitions.read_text())
    if manifest["schema_version"] != 1 or manifest["input_sha256"] != _sha256(args.csv):
        raise ValueError("partition manifest version or source hash differs")
    with args.csv.open(newline="") as stream:
        header = next(csv.reader(stream))
    if len(set(header)) != len(header):
        raise ValueError("duplicate CSV column names are not accepted")
    frame = pd.read_csv(args.csv, dtype=str)
    if manifest["row_count"] != len(frame):
        raise ValueError("partition manifest row count differs")
    labels = pd.to_numeric(frame.pop(args.label_column), errors="raise").to_numpy()
    result = evaluate_frozen(
        frame, labels, manifest["partitions"], seed=manifest["seed"], methods=args.detectors
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    write_record(
        record_path,
        experiment=PROTOCOL,
        seeds=[manifest["seed"]],
        dataset=args.csv.name,
        data_path=args.csv,
        settings={
            "protocol": PROTOCOL,
            "exploratory": True,
            "label_column": args.label_column,
            "detectors": args.detectors,
            "partition_sha256": _sha256(args.partitions),
            "research_sha256": {name: _sha256(ROOT / name) for name in RESEARCH_SOURCES},
            "torch": _optional_version("torch"),
        },
        outputs=[args.output.name],
    )
    return 1 if result["errors"] or not result["runs"] else 0


def x_main__mutmut_17(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=Path, required=True)
    parser.add_argument("--partitions", type=Path, )
    parser.add_argument("--label-column", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--detectors", nargs="+", required=True)
    args = parser.parse_args(argv)
    record_path = args.output.with_suffix(".record.json")
    if args.output.exists() or record_path.exists():
        raise FileExistsError("choose unused output and record paths")
    manifest = json.loads(args.partitions.read_text())
    if manifest["schema_version"] != 1 or manifest["input_sha256"] != _sha256(args.csv):
        raise ValueError("partition manifest version or source hash differs")
    with args.csv.open(newline="") as stream:
        header = next(csv.reader(stream))
    if len(set(header)) != len(header):
        raise ValueError("duplicate CSV column names are not accepted")
    frame = pd.read_csv(args.csv, dtype=str)
    if manifest["row_count"] != len(frame):
        raise ValueError("partition manifest row count differs")
    labels = pd.to_numeric(frame.pop(args.label_column), errors="raise").to_numpy()
    result = evaluate_frozen(
        frame, labels, manifest["partitions"], seed=manifest["seed"], methods=args.detectors
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    write_record(
        record_path,
        experiment=PROTOCOL,
        seeds=[manifest["seed"]],
        dataset=args.csv.name,
        data_path=args.csv,
        settings={
            "protocol": PROTOCOL,
            "exploratory": True,
            "label_column": args.label_column,
            "detectors": args.detectors,
            "partition_sha256": _sha256(args.partitions),
            "research_sha256": {name: _sha256(ROOT / name) for name in RESEARCH_SOURCES},
            "torch": _optional_version("torch"),
        },
        outputs=[args.output.name],
    )
    return 1 if result["errors"] or not result["runs"] else 0


def x_main__mutmut_18(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=Path, required=True)
    parser.add_argument("XX--partitionsXX", type=Path, required=True)
    parser.add_argument("--label-column", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--detectors", nargs="+", required=True)
    args = parser.parse_args(argv)
    record_path = args.output.with_suffix(".record.json")
    if args.output.exists() or record_path.exists():
        raise FileExistsError("choose unused output and record paths")
    manifest = json.loads(args.partitions.read_text())
    if manifest["schema_version"] != 1 or manifest["input_sha256"] != _sha256(args.csv):
        raise ValueError("partition manifest version or source hash differs")
    with args.csv.open(newline="") as stream:
        header = next(csv.reader(stream))
    if len(set(header)) != len(header):
        raise ValueError("duplicate CSV column names are not accepted")
    frame = pd.read_csv(args.csv, dtype=str)
    if manifest["row_count"] != len(frame):
        raise ValueError("partition manifest row count differs")
    labels = pd.to_numeric(frame.pop(args.label_column), errors="raise").to_numpy()
    result = evaluate_frozen(
        frame, labels, manifest["partitions"], seed=manifest["seed"], methods=args.detectors
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    write_record(
        record_path,
        experiment=PROTOCOL,
        seeds=[manifest["seed"]],
        dataset=args.csv.name,
        data_path=args.csv,
        settings={
            "protocol": PROTOCOL,
            "exploratory": True,
            "label_column": args.label_column,
            "detectors": args.detectors,
            "partition_sha256": _sha256(args.partitions),
            "research_sha256": {name: _sha256(ROOT / name) for name in RESEARCH_SOURCES},
            "torch": _optional_version("torch"),
        },
        outputs=[args.output.name],
    )
    return 1 if result["errors"] or not result["runs"] else 0


def x_main__mutmut_19(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=Path, required=True)
    parser.add_argument("--PARTITIONS", type=Path, required=True)
    parser.add_argument("--label-column", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--detectors", nargs="+", required=True)
    args = parser.parse_args(argv)
    record_path = args.output.with_suffix(".record.json")
    if args.output.exists() or record_path.exists():
        raise FileExistsError("choose unused output and record paths")
    manifest = json.loads(args.partitions.read_text())
    if manifest["schema_version"] != 1 or manifest["input_sha256"] != _sha256(args.csv):
        raise ValueError("partition manifest version or source hash differs")
    with args.csv.open(newline="") as stream:
        header = next(csv.reader(stream))
    if len(set(header)) != len(header):
        raise ValueError("duplicate CSV column names are not accepted")
    frame = pd.read_csv(args.csv, dtype=str)
    if manifest["row_count"] != len(frame):
        raise ValueError("partition manifest row count differs")
    labels = pd.to_numeric(frame.pop(args.label_column), errors="raise").to_numpy()
    result = evaluate_frozen(
        frame, labels, manifest["partitions"], seed=manifest["seed"], methods=args.detectors
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    write_record(
        record_path,
        experiment=PROTOCOL,
        seeds=[manifest["seed"]],
        dataset=args.csv.name,
        data_path=args.csv,
        settings={
            "protocol": PROTOCOL,
            "exploratory": True,
            "label_column": args.label_column,
            "detectors": args.detectors,
            "partition_sha256": _sha256(args.partitions),
            "research_sha256": {name: _sha256(ROOT / name) for name in RESEARCH_SOURCES},
            "torch": _optional_version("torch"),
        },
        outputs=[args.output.name],
    )
    return 1 if result["errors"] or not result["runs"] else 0


def x_main__mutmut_20(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=Path, required=True)
    parser.add_argument("--partitions", type=Path, required=False)
    parser.add_argument("--label-column", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--detectors", nargs="+", required=True)
    args = parser.parse_args(argv)
    record_path = args.output.with_suffix(".record.json")
    if args.output.exists() or record_path.exists():
        raise FileExistsError("choose unused output and record paths")
    manifest = json.loads(args.partitions.read_text())
    if manifest["schema_version"] != 1 or manifest["input_sha256"] != _sha256(args.csv):
        raise ValueError("partition manifest version or source hash differs")
    with args.csv.open(newline="") as stream:
        header = next(csv.reader(stream))
    if len(set(header)) != len(header):
        raise ValueError("duplicate CSV column names are not accepted")
    frame = pd.read_csv(args.csv, dtype=str)
    if manifest["row_count"] != len(frame):
        raise ValueError("partition manifest row count differs")
    labels = pd.to_numeric(frame.pop(args.label_column), errors="raise").to_numpy()
    result = evaluate_frozen(
        frame, labels, manifest["partitions"], seed=manifest["seed"], methods=args.detectors
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    write_record(
        record_path,
        experiment=PROTOCOL,
        seeds=[manifest["seed"]],
        dataset=args.csv.name,
        data_path=args.csv,
        settings={
            "protocol": PROTOCOL,
            "exploratory": True,
            "label_column": args.label_column,
            "detectors": args.detectors,
            "partition_sha256": _sha256(args.partitions),
            "research_sha256": {name: _sha256(ROOT / name) for name in RESEARCH_SOURCES},
            "torch": _optional_version("torch"),
        },
        outputs=[args.output.name],
    )
    return 1 if result["errors"] or not result["runs"] else 0


def x_main__mutmut_21(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=Path, required=True)
    parser.add_argument("--partitions", type=Path, required=True)
    parser.add_argument(None, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--detectors", nargs="+", required=True)
    args = parser.parse_args(argv)
    record_path = args.output.with_suffix(".record.json")
    if args.output.exists() or record_path.exists():
        raise FileExistsError("choose unused output and record paths")
    manifest = json.loads(args.partitions.read_text())
    if manifest["schema_version"] != 1 or manifest["input_sha256"] != _sha256(args.csv):
        raise ValueError("partition manifest version or source hash differs")
    with args.csv.open(newline="") as stream:
        header = next(csv.reader(stream))
    if len(set(header)) != len(header):
        raise ValueError("duplicate CSV column names are not accepted")
    frame = pd.read_csv(args.csv, dtype=str)
    if manifest["row_count"] != len(frame):
        raise ValueError("partition manifest row count differs")
    labels = pd.to_numeric(frame.pop(args.label_column), errors="raise").to_numpy()
    result = evaluate_frozen(
        frame, labels, manifest["partitions"], seed=manifest["seed"], methods=args.detectors
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    write_record(
        record_path,
        experiment=PROTOCOL,
        seeds=[manifest["seed"]],
        dataset=args.csv.name,
        data_path=args.csv,
        settings={
            "protocol": PROTOCOL,
            "exploratory": True,
            "label_column": args.label_column,
            "detectors": args.detectors,
            "partition_sha256": _sha256(args.partitions),
            "research_sha256": {name: _sha256(ROOT / name) for name in RESEARCH_SOURCES},
            "torch": _optional_version("torch"),
        },
        outputs=[args.output.name],
    )
    return 1 if result["errors"] or not result["runs"] else 0


def x_main__mutmut_22(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=Path, required=True)
    parser.add_argument("--partitions", type=Path, required=True)
    parser.add_argument("--label-column", required=None)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--detectors", nargs="+", required=True)
    args = parser.parse_args(argv)
    record_path = args.output.with_suffix(".record.json")
    if args.output.exists() or record_path.exists():
        raise FileExistsError("choose unused output and record paths")
    manifest = json.loads(args.partitions.read_text())
    if manifest["schema_version"] != 1 or manifest["input_sha256"] != _sha256(args.csv):
        raise ValueError("partition manifest version or source hash differs")
    with args.csv.open(newline="") as stream:
        header = next(csv.reader(stream))
    if len(set(header)) != len(header):
        raise ValueError("duplicate CSV column names are not accepted")
    frame = pd.read_csv(args.csv, dtype=str)
    if manifest["row_count"] != len(frame):
        raise ValueError("partition manifest row count differs")
    labels = pd.to_numeric(frame.pop(args.label_column), errors="raise").to_numpy()
    result = evaluate_frozen(
        frame, labels, manifest["partitions"], seed=manifest["seed"], methods=args.detectors
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    write_record(
        record_path,
        experiment=PROTOCOL,
        seeds=[manifest["seed"]],
        dataset=args.csv.name,
        data_path=args.csv,
        settings={
            "protocol": PROTOCOL,
            "exploratory": True,
            "label_column": args.label_column,
            "detectors": args.detectors,
            "partition_sha256": _sha256(args.partitions),
            "research_sha256": {name: _sha256(ROOT / name) for name in RESEARCH_SOURCES},
            "torch": _optional_version("torch"),
        },
        outputs=[args.output.name],
    )
    return 1 if result["errors"] or not result["runs"] else 0


def x_main__mutmut_23(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=Path, required=True)
    parser.add_argument("--partitions", type=Path, required=True)
    parser.add_argument(required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--detectors", nargs="+", required=True)
    args = parser.parse_args(argv)
    record_path = args.output.with_suffix(".record.json")
    if args.output.exists() or record_path.exists():
        raise FileExistsError("choose unused output and record paths")
    manifest = json.loads(args.partitions.read_text())
    if manifest["schema_version"] != 1 or manifest["input_sha256"] != _sha256(args.csv):
        raise ValueError("partition manifest version or source hash differs")
    with args.csv.open(newline="") as stream:
        header = next(csv.reader(stream))
    if len(set(header)) != len(header):
        raise ValueError("duplicate CSV column names are not accepted")
    frame = pd.read_csv(args.csv, dtype=str)
    if manifest["row_count"] != len(frame):
        raise ValueError("partition manifest row count differs")
    labels = pd.to_numeric(frame.pop(args.label_column), errors="raise").to_numpy()
    result = evaluate_frozen(
        frame, labels, manifest["partitions"], seed=manifest["seed"], methods=args.detectors
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    write_record(
        record_path,
        experiment=PROTOCOL,
        seeds=[manifest["seed"]],
        dataset=args.csv.name,
        data_path=args.csv,
        settings={
            "protocol": PROTOCOL,
            "exploratory": True,
            "label_column": args.label_column,
            "detectors": args.detectors,
            "partition_sha256": _sha256(args.partitions),
            "research_sha256": {name: _sha256(ROOT / name) for name in RESEARCH_SOURCES},
            "torch": _optional_version("torch"),
        },
        outputs=[args.output.name],
    )
    return 1 if result["errors"] or not result["runs"] else 0


def x_main__mutmut_24(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=Path, required=True)
    parser.add_argument("--partitions", type=Path, required=True)
    parser.add_argument("--label-column", )
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--detectors", nargs="+", required=True)
    args = parser.parse_args(argv)
    record_path = args.output.with_suffix(".record.json")
    if args.output.exists() or record_path.exists():
        raise FileExistsError("choose unused output and record paths")
    manifest = json.loads(args.partitions.read_text())
    if manifest["schema_version"] != 1 or manifest["input_sha256"] != _sha256(args.csv):
        raise ValueError("partition manifest version or source hash differs")
    with args.csv.open(newline="") as stream:
        header = next(csv.reader(stream))
    if len(set(header)) != len(header):
        raise ValueError("duplicate CSV column names are not accepted")
    frame = pd.read_csv(args.csv, dtype=str)
    if manifest["row_count"] != len(frame):
        raise ValueError("partition manifest row count differs")
    labels = pd.to_numeric(frame.pop(args.label_column), errors="raise").to_numpy()
    result = evaluate_frozen(
        frame, labels, manifest["partitions"], seed=manifest["seed"], methods=args.detectors
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    write_record(
        record_path,
        experiment=PROTOCOL,
        seeds=[manifest["seed"]],
        dataset=args.csv.name,
        data_path=args.csv,
        settings={
            "protocol": PROTOCOL,
            "exploratory": True,
            "label_column": args.label_column,
            "detectors": args.detectors,
            "partition_sha256": _sha256(args.partitions),
            "research_sha256": {name: _sha256(ROOT / name) for name in RESEARCH_SOURCES},
            "torch": _optional_version("torch"),
        },
        outputs=[args.output.name],
    )
    return 1 if result["errors"] or not result["runs"] else 0


def x_main__mutmut_25(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=Path, required=True)
    parser.add_argument("--partitions", type=Path, required=True)
    parser.add_argument("XX--label-columnXX", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--detectors", nargs="+", required=True)
    args = parser.parse_args(argv)
    record_path = args.output.with_suffix(".record.json")
    if args.output.exists() or record_path.exists():
        raise FileExistsError("choose unused output and record paths")
    manifest = json.loads(args.partitions.read_text())
    if manifest["schema_version"] != 1 or manifest["input_sha256"] != _sha256(args.csv):
        raise ValueError("partition manifest version or source hash differs")
    with args.csv.open(newline="") as stream:
        header = next(csv.reader(stream))
    if len(set(header)) != len(header):
        raise ValueError("duplicate CSV column names are not accepted")
    frame = pd.read_csv(args.csv, dtype=str)
    if manifest["row_count"] != len(frame):
        raise ValueError("partition manifest row count differs")
    labels = pd.to_numeric(frame.pop(args.label_column), errors="raise").to_numpy()
    result = evaluate_frozen(
        frame, labels, manifest["partitions"], seed=manifest["seed"], methods=args.detectors
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    write_record(
        record_path,
        experiment=PROTOCOL,
        seeds=[manifest["seed"]],
        dataset=args.csv.name,
        data_path=args.csv,
        settings={
            "protocol": PROTOCOL,
            "exploratory": True,
            "label_column": args.label_column,
            "detectors": args.detectors,
            "partition_sha256": _sha256(args.partitions),
            "research_sha256": {name: _sha256(ROOT / name) for name in RESEARCH_SOURCES},
            "torch": _optional_version("torch"),
        },
        outputs=[args.output.name],
    )
    return 1 if result["errors"] or not result["runs"] else 0


def x_main__mutmut_26(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=Path, required=True)
    parser.add_argument("--partitions", type=Path, required=True)
    parser.add_argument("--LABEL-COLUMN", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--detectors", nargs="+", required=True)
    args = parser.parse_args(argv)
    record_path = args.output.with_suffix(".record.json")
    if args.output.exists() or record_path.exists():
        raise FileExistsError("choose unused output and record paths")
    manifest = json.loads(args.partitions.read_text())
    if manifest["schema_version"] != 1 or manifest["input_sha256"] != _sha256(args.csv):
        raise ValueError("partition manifest version or source hash differs")
    with args.csv.open(newline="") as stream:
        header = next(csv.reader(stream))
    if len(set(header)) != len(header):
        raise ValueError("duplicate CSV column names are not accepted")
    frame = pd.read_csv(args.csv, dtype=str)
    if manifest["row_count"] != len(frame):
        raise ValueError("partition manifest row count differs")
    labels = pd.to_numeric(frame.pop(args.label_column), errors="raise").to_numpy()
    result = evaluate_frozen(
        frame, labels, manifest["partitions"], seed=manifest["seed"], methods=args.detectors
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    write_record(
        record_path,
        experiment=PROTOCOL,
        seeds=[manifest["seed"]],
        dataset=args.csv.name,
        data_path=args.csv,
        settings={
            "protocol": PROTOCOL,
            "exploratory": True,
            "label_column": args.label_column,
            "detectors": args.detectors,
            "partition_sha256": _sha256(args.partitions),
            "research_sha256": {name: _sha256(ROOT / name) for name in RESEARCH_SOURCES},
            "torch": _optional_version("torch"),
        },
        outputs=[args.output.name],
    )
    return 1 if result["errors"] or not result["runs"] else 0


def x_main__mutmut_27(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=Path, required=True)
    parser.add_argument("--partitions", type=Path, required=True)
    parser.add_argument("--label-column", required=False)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--detectors", nargs="+", required=True)
    args = parser.parse_args(argv)
    record_path = args.output.with_suffix(".record.json")
    if args.output.exists() or record_path.exists():
        raise FileExistsError("choose unused output and record paths")
    manifest = json.loads(args.partitions.read_text())
    if manifest["schema_version"] != 1 or manifest["input_sha256"] != _sha256(args.csv):
        raise ValueError("partition manifest version or source hash differs")
    with args.csv.open(newline="") as stream:
        header = next(csv.reader(stream))
    if len(set(header)) != len(header):
        raise ValueError("duplicate CSV column names are not accepted")
    frame = pd.read_csv(args.csv, dtype=str)
    if manifest["row_count"] != len(frame):
        raise ValueError("partition manifest row count differs")
    labels = pd.to_numeric(frame.pop(args.label_column), errors="raise").to_numpy()
    result = evaluate_frozen(
        frame, labels, manifest["partitions"], seed=manifest["seed"], methods=args.detectors
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    write_record(
        record_path,
        experiment=PROTOCOL,
        seeds=[manifest["seed"]],
        dataset=args.csv.name,
        data_path=args.csv,
        settings={
            "protocol": PROTOCOL,
            "exploratory": True,
            "label_column": args.label_column,
            "detectors": args.detectors,
            "partition_sha256": _sha256(args.partitions),
            "research_sha256": {name: _sha256(ROOT / name) for name in RESEARCH_SOURCES},
            "torch": _optional_version("torch"),
        },
        outputs=[args.output.name],
    )
    return 1 if result["errors"] or not result["runs"] else 0


def x_main__mutmut_28(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=Path, required=True)
    parser.add_argument("--partitions", type=Path, required=True)
    parser.add_argument("--label-column", required=True)
    parser.add_argument(None, type=Path, required=True)
    parser.add_argument("--detectors", nargs="+", required=True)
    args = parser.parse_args(argv)
    record_path = args.output.with_suffix(".record.json")
    if args.output.exists() or record_path.exists():
        raise FileExistsError("choose unused output and record paths")
    manifest = json.loads(args.partitions.read_text())
    if manifest["schema_version"] != 1 or manifest["input_sha256"] != _sha256(args.csv):
        raise ValueError("partition manifest version or source hash differs")
    with args.csv.open(newline="") as stream:
        header = next(csv.reader(stream))
    if len(set(header)) != len(header):
        raise ValueError("duplicate CSV column names are not accepted")
    frame = pd.read_csv(args.csv, dtype=str)
    if manifest["row_count"] != len(frame):
        raise ValueError("partition manifest row count differs")
    labels = pd.to_numeric(frame.pop(args.label_column), errors="raise").to_numpy()
    result = evaluate_frozen(
        frame, labels, manifest["partitions"], seed=manifest["seed"], methods=args.detectors
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    write_record(
        record_path,
        experiment=PROTOCOL,
        seeds=[manifest["seed"]],
        dataset=args.csv.name,
        data_path=args.csv,
        settings={
            "protocol": PROTOCOL,
            "exploratory": True,
            "label_column": args.label_column,
            "detectors": args.detectors,
            "partition_sha256": _sha256(args.partitions),
            "research_sha256": {name: _sha256(ROOT / name) for name in RESEARCH_SOURCES},
            "torch": _optional_version("torch"),
        },
        outputs=[args.output.name],
    )
    return 1 if result["errors"] or not result["runs"] else 0


def x_main__mutmut_29(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=Path, required=True)
    parser.add_argument("--partitions", type=Path, required=True)
    parser.add_argument("--label-column", required=True)
    parser.add_argument("--output", type=None, required=True)
    parser.add_argument("--detectors", nargs="+", required=True)
    args = parser.parse_args(argv)
    record_path = args.output.with_suffix(".record.json")
    if args.output.exists() or record_path.exists():
        raise FileExistsError("choose unused output and record paths")
    manifest = json.loads(args.partitions.read_text())
    if manifest["schema_version"] != 1 or manifest["input_sha256"] != _sha256(args.csv):
        raise ValueError("partition manifest version or source hash differs")
    with args.csv.open(newline="") as stream:
        header = next(csv.reader(stream))
    if len(set(header)) != len(header):
        raise ValueError("duplicate CSV column names are not accepted")
    frame = pd.read_csv(args.csv, dtype=str)
    if manifest["row_count"] != len(frame):
        raise ValueError("partition manifest row count differs")
    labels = pd.to_numeric(frame.pop(args.label_column), errors="raise").to_numpy()
    result = evaluate_frozen(
        frame, labels, manifest["partitions"], seed=manifest["seed"], methods=args.detectors
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    write_record(
        record_path,
        experiment=PROTOCOL,
        seeds=[manifest["seed"]],
        dataset=args.csv.name,
        data_path=args.csv,
        settings={
            "protocol": PROTOCOL,
            "exploratory": True,
            "label_column": args.label_column,
            "detectors": args.detectors,
            "partition_sha256": _sha256(args.partitions),
            "research_sha256": {name: _sha256(ROOT / name) for name in RESEARCH_SOURCES},
            "torch": _optional_version("torch"),
        },
        outputs=[args.output.name],
    )
    return 1 if result["errors"] or not result["runs"] else 0


def x_main__mutmut_30(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=Path, required=True)
    parser.add_argument("--partitions", type=Path, required=True)
    parser.add_argument("--label-column", required=True)
    parser.add_argument("--output", type=Path, required=None)
    parser.add_argument("--detectors", nargs="+", required=True)
    args = parser.parse_args(argv)
    record_path = args.output.with_suffix(".record.json")
    if args.output.exists() or record_path.exists():
        raise FileExistsError("choose unused output and record paths")
    manifest = json.loads(args.partitions.read_text())
    if manifest["schema_version"] != 1 or manifest["input_sha256"] != _sha256(args.csv):
        raise ValueError("partition manifest version or source hash differs")
    with args.csv.open(newline="") as stream:
        header = next(csv.reader(stream))
    if len(set(header)) != len(header):
        raise ValueError("duplicate CSV column names are not accepted")
    frame = pd.read_csv(args.csv, dtype=str)
    if manifest["row_count"] != len(frame):
        raise ValueError("partition manifest row count differs")
    labels = pd.to_numeric(frame.pop(args.label_column), errors="raise").to_numpy()
    result = evaluate_frozen(
        frame, labels, manifest["partitions"], seed=manifest["seed"], methods=args.detectors
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    write_record(
        record_path,
        experiment=PROTOCOL,
        seeds=[manifest["seed"]],
        dataset=args.csv.name,
        data_path=args.csv,
        settings={
            "protocol": PROTOCOL,
            "exploratory": True,
            "label_column": args.label_column,
            "detectors": args.detectors,
            "partition_sha256": _sha256(args.partitions),
            "research_sha256": {name: _sha256(ROOT / name) for name in RESEARCH_SOURCES},
            "torch": _optional_version("torch"),
        },
        outputs=[args.output.name],
    )
    return 1 if result["errors"] or not result["runs"] else 0


def x_main__mutmut_31(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=Path, required=True)
    parser.add_argument("--partitions", type=Path, required=True)
    parser.add_argument("--label-column", required=True)
    parser.add_argument(type=Path, required=True)
    parser.add_argument("--detectors", nargs="+", required=True)
    args = parser.parse_args(argv)
    record_path = args.output.with_suffix(".record.json")
    if args.output.exists() or record_path.exists():
        raise FileExistsError("choose unused output and record paths")
    manifest = json.loads(args.partitions.read_text())
    if manifest["schema_version"] != 1 or manifest["input_sha256"] != _sha256(args.csv):
        raise ValueError("partition manifest version or source hash differs")
    with args.csv.open(newline="") as stream:
        header = next(csv.reader(stream))
    if len(set(header)) != len(header):
        raise ValueError("duplicate CSV column names are not accepted")
    frame = pd.read_csv(args.csv, dtype=str)
    if manifest["row_count"] != len(frame):
        raise ValueError("partition manifest row count differs")
    labels = pd.to_numeric(frame.pop(args.label_column), errors="raise").to_numpy()
    result = evaluate_frozen(
        frame, labels, manifest["partitions"], seed=manifest["seed"], methods=args.detectors
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    write_record(
        record_path,
        experiment=PROTOCOL,
        seeds=[manifest["seed"]],
        dataset=args.csv.name,
        data_path=args.csv,
        settings={
            "protocol": PROTOCOL,
            "exploratory": True,
            "label_column": args.label_column,
            "detectors": args.detectors,
            "partition_sha256": _sha256(args.partitions),
            "research_sha256": {name: _sha256(ROOT / name) for name in RESEARCH_SOURCES},
            "torch": _optional_version("torch"),
        },
        outputs=[args.output.name],
    )
    return 1 if result["errors"] or not result["runs"] else 0


def x_main__mutmut_32(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=Path, required=True)
    parser.add_argument("--partitions", type=Path, required=True)
    parser.add_argument("--label-column", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--detectors", nargs="+", required=True)
    args = parser.parse_args(argv)
    record_path = args.output.with_suffix(".record.json")
    if args.output.exists() or record_path.exists():
        raise FileExistsError("choose unused output and record paths")
    manifest = json.loads(args.partitions.read_text())
    if manifest["schema_version"] != 1 or manifest["input_sha256"] != _sha256(args.csv):
        raise ValueError("partition manifest version or source hash differs")
    with args.csv.open(newline="") as stream:
        header = next(csv.reader(stream))
    if len(set(header)) != len(header):
        raise ValueError("duplicate CSV column names are not accepted")
    frame = pd.read_csv(args.csv, dtype=str)
    if manifest["row_count"] != len(frame):
        raise ValueError("partition manifest row count differs")
    labels = pd.to_numeric(frame.pop(args.label_column), errors="raise").to_numpy()
    result = evaluate_frozen(
        frame, labels, manifest["partitions"], seed=manifest["seed"], methods=args.detectors
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    write_record(
        record_path,
        experiment=PROTOCOL,
        seeds=[manifest["seed"]],
        dataset=args.csv.name,
        data_path=args.csv,
        settings={
            "protocol": PROTOCOL,
            "exploratory": True,
            "label_column": args.label_column,
            "detectors": args.detectors,
            "partition_sha256": _sha256(args.partitions),
            "research_sha256": {name: _sha256(ROOT / name) for name in RESEARCH_SOURCES},
            "torch": _optional_version("torch"),
        },
        outputs=[args.output.name],
    )
    return 1 if result["errors"] or not result["runs"] else 0


def x_main__mutmut_33(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=Path, required=True)
    parser.add_argument("--partitions", type=Path, required=True)
    parser.add_argument("--label-column", required=True)
    parser.add_argument("--output", type=Path, )
    parser.add_argument("--detectors", nargs="+", required=True)
    args = parser.parse_args(argv)
    record_path = args.output.with_suffix(".record.json")
    if args.output.exists() or record_path.exists():
        raise FileExistsError("choose unused output and record paths")
    manifest = json.loads(args.partitions.read_text())
    if manifest["schema_version"] != 1 or manifest["input_sha256"] != _sha256(args.csv):
        raise ValueError("partition manifest version or source hash differs")
    with args.csv.open(newline="") as stream:
        header = next(csv.reader(stream))
    if len(set(header)) != len(header):
        raise ValueError("duplicate CSV column names are not accepted")
    frame = pd.read_csv(args.csv, dtype=str)
    if manifest["row_count"] != len(frame):
        raise ValueError("partition manifest row count differs")
    labels = pd.to_numeric(frame.pop(args.label_column), errors="raise").to_numpy()
    result = evaluate_frozen(
        frame, labels, manifest["partitions"], seed=manifest["seed"], methods=args.detectors
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    write_record(
        record_path,
        experiment=PROTOCOL,
        seeds=[manifest["seed"]],
        dataset=args.csv.name,
        data_path=args.csv,
        settings={
            "protocol": PROTOCOL,
            "exploratory": True,
            "label_column": args.label_column,
            "detectors": args.detectors,
            "partition_sha256": _sha256(args.partitions),
            "research_sha256": {name: _sha256(ROOT / name) for name in RESEARCH_SOURCES},
            "torch": _optional_version("torch"),
        },
        outputs=[args.output.name],
    )
    return 1 if result["errors"] or not result["runs"] else 0


def x_main__mutmut_34(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=Path, required=True)
    parser.add_argument("--partitions", type=Path, required=True)
    parser.add_argument("--label-column", required=True)
    parser.add_argument("XX--outputXX", type=Path, required=True)
    parser.add_argument("--detectors", nargs="+", required=True)
    args = parser.parse_args(argv)
    record_path = args.output.with_suffix(".record.json")
    if args.output.exists() or record_path.exists():
        raise FileExistsError("choose unused output and record paths")
    manifest = json.loads(args.partitions.read_text())
    if manifest["schema_version"] != 1 or manifest["input_sha256"] != _sha256(args.csv):
        raise ValueError("partition manifest version or source hash differs")
    with args.csv.open(newline="") as stream:
        header = next(csv.reader(stream))
    if len(set(header)) != len(header):
        raise ValueError("duplicate CSV column names are not accepted")
    frame = pd.read_csv(args.csv, dtype=str)
    if manifest["row_count"] != len(frame):
        raise ValueError("partition manifest row count differs")
    labels = pd.to_numeric(frame.pop(args.label_column), errors="raise").to_numpy()
    result = evaluate_frozen(
        frame, labels, manifest["partitions"], seed=manifest["seed"], methods=args.detectors
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    write_record(
        record_path,
        experiment=PROTOCOL,
        seeds=[manifest["seed"]],
        dataset=args.csv.name,
        data_path=args.csv,
        settings={
            "protocol": PROTOCOL,
            "exploratory": True,
            "label_column": args.label_column,
            "detectors": args.detectors,
            "partition_sha256": _sha256(args.partitions),
            "research_sha256": {name: _sha256(ROOT / name) for name in RESEARCH_SOURCES},
            "torch": _optional_version("torch"),
        },
        outputs=[args.output.name],
    )
    return 1 if result["errors"] or not result["runs"] else 0


def x_main__mutmut_35(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=Path, required=True)
    parser.add_argument("--partitions", type=Path, required=True)
    parser.add_argument("--label-column", required=True)
    parser.add_argument("--OUTPUT", type=Path, required=True)
    parser.add_argument("--detectors", nargs="+", required=True)
    args = parser.parse_args(argv)
    record_path = args.output.with_suffix(".record.json")
    if args.output.exists() or record_path.exists():
        raise FileExistsError("choose unused output and record paths")
    manifest = json.loads(args.partitions.read_text())
    if manifest["schema_version"] != 1 or manifest["input_sha256"] != _sha256(args.csv):
        raise ValueError("partition manifest version or source hash differs")
    with args.csv.open(newline="") as stream:
        header = next(csv.reader(stream))
    if len(set(header)) != len(header):
        raise ValueError("duplicate CSV column names are not accepted")
    frame = pd.read_csv(args.csv, dtype=str)
    if manifest["row_count"] != len(frame):
        raise ValueError("partition manifest row count differs")
    labels = pd.to_numeric(frame.pop(args.label_column), errors="raise").to_numpy()
    result = evaluate_frozen(
        frame, labels, manifest["partitions"], seed=manifest["seed"], methods=args.detectors
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    write_record(
        record_path,
        experiment=PROTOCOL,
        seeds=[manifest["seed"]],
        dataset=args.csv.name,
        data_path=args.csv,
        settings={
            "protocol": PROTOCOL,
            "exploratory": True,
            "label_column": args.label_column,
            "detectors": args.detectors,
            "partition_sha256": _sha256(args.partitions),
            "research_sha256": {name: _sha256(ROOT / name) for name in RESEARCH_SOURCES},
            "torch": _optional_version("torch"),
        },
        outputs=[args.output.name],
    )
    return 1 if result["errors"] or not result["runs"] else 0


def x_main__mutmut_36(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=Path, required=True)
    parser.add_argument("--partitions", type=Path, required=True)
    parser.add_argument("--label-column", required=True)
    parser.add_argument("--output", type=Path, required=False)
    parser.add_argument("--detectors", nargs="+", required=True)
    args = parser.parse_args(argv)
    record_path = args.output.with_suffix(".record.json")
    if args.output.exists() or record_path.exists():
        raise FileExistsError("choose unused output and record paths")
    manifest = json.loads(args.partitions.read_text())
    if manifest["schema_version"] != 1 or manifest["input_sha256"] != _sha256(args.csv):
        raise ValueError("partition manifest version or source hash differs")
    with args.csv.open(newline="") as stream:
        header = next(csv.reader(stream))
    if len(set(header)) != len(header):
        raise ValueError("duplicate CSV column names are not accepted")
    frame = pd.read_csv(args.csv, dtype=str)
    if manifest["row_count"] != len(frame):
        raise ValueError("partition manifest row count differs")
    labels = pd.to_numeric(frame.pop(args.label_column), errors="raise").to_numpy()
    result = evaluate_frozen(
        frame, labels, manifest["partitions"], seed=manifest["seed"], methods=args.detectors
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    write_record(
        record_path,
        experiment=PROTOCOL,
        seeds=[manifest["seed"]],
        dataset=args.csv.name,
        data_path=args.csv,
        settings={
            "protocol": PROTOCOL,
            "exploratory": True,
            "label_column": args.label_column,
            "detectors": args.detectors,
            "partition_sha256": _sha256(args.partitions),
            "research_sha256": {name: _sha256(ROOT / name) for name in RESEARCH_SOURCES},
            "torch": _optional_version("torch"),
        },
        outputs=[args.output.name],
    )
    return 1 if result["errors"] or not result["runs"] else 0


def x_main__mutmut_37(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=Path, required=True)
    parser.add_argument("--partitions", type=Path, required=True)
    parser.add_argument("--label-column", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument(None, nargs="+", required=True)
    args = parser.parse_args(argv)
    record_path = args.output.with_suffix(".record.json")
    if args.output.exists() or record_path.exists():
        raise FileExistsError("choose unused output and record paths")
    manifest = json.loads(args.partitions.read_text())
    if manifest["schema_version"] != 1 or manifest["input_sha256"] != _sha256(args.csv):
        raise ValueError("partition manifest version or source hash differs")
    with args.csv.open(newline="") as stream:
        header = next(csv.reader(stream))
    if len(set(header)) != len(header):
        raise ValueError("duplicate CSV column names are not accepted")
    frame = pd.read_csv(args.csv, dtype=str)
    if manifest["row_count"] != len(frame):
        raise ValueError("partition manifest row count differs")
    labels = pd.to_numeric(frame.pop(args.label_column), errors="raise").to_numpy()
    result = evaluate_frozen(
        frame, labels, manifest["partitions"], seed=manifest["seed"], methods=args.detectors
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    write_record(
        record_path,
        experiment=PROTOCOL,
        seeds=[manifest["seed"]],
        dataset=args.csv.name,
        data_path=args.csv,
        settings={
            "protocol": PROTOCOL,
            "exploratory": True,
            "label_column": args.label_column,
            "detectors": args.detectors,
            "partition_sha256": _sha256(args.partitions),
            "research_sha256": {name: _sha256(ROOT / name) for name in RESEARCH_SOURCES},
            "torch": _optional_version("torch"),
        },
        outputs=[args.output.name],
    )
    return 1 if result["errors"] or not result["runs"] else 0


def x_main__mutmut_38(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=Path, required=True)
    parser.add_argument("--partitions", type=Path, required=True)
    parser.add_argument("--label-column", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--detectors", nargs=None, required=True)
    args = parser.parse_args(argv)
    record_path = args.output.with_suffix(".record.json")
    if args.output.exists() or record_path.exists():
        raise FileExistsError("choose unused output and record paths")
    manifest = json.loads(args.partitions.read_text())
    if manifest["schema_version"] != 1 or manifest["input_sha256"] != _sha256(args.csv):
        raise ValueError("partition manifest version or source hash differs")
    with args.csv.open(newline="") as stream:
        header = next(csv.reader(stream))
    if len(set(header)) != len(header):
        raise ValueError("duplicate CSV column names are not accepted")
    frame = pd.read_csv(args.csv, dtype=str)
    if manifest["row_count"] != len(frame):
        raise ValueError("partition manifest row count differs")
    labels = pd.to_numeric(frame.pop(args.label_column), errors="raise").to_numpy()
    result = evaluate_frozen(
        frame, labels, manifest["partitions"], seed=manifest["seed"], methods=args.detectors
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    write_record(
        record_path,
        experiment=PROTOCOL,
        seeds=[manifest["seed"]],
        dataset=args.csv.name,
        data_path=args.csv,
        settings={
            "protocol": PROTOCOL,
            "exploratory": True,
            "label_column": args.label_column,
            "detectors": args.detectors,
            "partition_sha256": _sha256(args.partitions),
            "research_sha256": {name: _sha256(ROOT / name) for name in RESEARCH_SOURCES},
            "torch": _optional_version("torch"),
        },
        outputs=[args.output.name],
    )
    return 1 if result["errors"] or not result["runs"] else 0


def x_main__mutmut_39(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=Path, required=True)
    parser.add_argument("--partitions", type=Path, required=True)
    parser.add_argument("--label-column", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--detectors", nargs="+", required=None)
    args = parser.parse_args(argv)
    record_path = args.output.with_suffix(".record.json")
    if args.output.exists() or record_path.exists():
        raise FileExistsError("choose unused output and record paths")
    manifest = json.loads(args.partitions.read_text())
    if manifest["schema_version"] != 1 or manifest["input_sha256"] != _sha256(args.csv):
        raise ValueError("partition manifest version or source hash differs")
    with args.csv.open(newline="") as stream:
        header = next(csv.reader(stream))
    if len(set(header)) != len(header):
        raise ValueError("duplicate CSV column names are not accepted")
    frame = pd.read_csv(args.csv, dtype=str)
    if manifest["row_count"] != len(frame):
        raise ValueError("partition manifest row count differs")
    labels = pd.to_numeric(frame.pop(args.label_column), errors="raise").to_numpy()
    result = evaluate_frozen(
        frame, labels, manifest["partitions"], seed=manifest["seed"], methods=args.detectors
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    write_record(
        record_path,
        experiment=PROTOCOL,
        seeds=[manifest["seed"]],
        dataset=args.csv.name,
        data_path=args.csv,
        settings={
            "protocol": PROTOCOL,
            "exploratory": True,
            "label_column": args.label_column,
            "detectors": args.detectors,
            "partition_sha256": _sha256(args.partitions),
            "research_sha256": {name: _sha256(ROOT / name) for name in RESEARCH_SOURCES},
            "torch": _optional_version("torch"),
        },
        outputs=[args.output.name],
    )
    return 1 if result["errors"] or not result["runs"] else 0


def x_main__mutmut_40(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=Path, required=True)
    parser.add_argument("--partitions", type=Path, required=True)
    parser.add_argument("--label-column", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument(nargs="+", required=True)
    args = parser.parse_args(argv)
    record_path = args.output.with_suffix(".record.json")
    if args.output.exists() or record_path.exists():
        raise FileExistsError("choose unused output and record paths")
    manifest = json.loads(args.partitions.read_text())
    if manifest["schema_version"] != 1 or manifest["input_sha256"] != _sha256(args.csv):
        raise ValueError("partition manifest version or source hash differs")
    with args.csv.open(newline="") as stream:
        header = next(csv.reader(stream))
    if len(set(header)) != len(header):
        raise ValueError("duplicate CSV column names are not accepted")
    frame = pd.read_csv(args.csv, dtype=str)
    if manifest["row_count"] != len(frame):
        raise ValueError("partition manifest row count differs")
    labels = pd.to_numeric(frame.pop(args.label_column), errors="raise").to_numpy()
    result = evaluate_frozen(
        frame, labels, manifest["partitions"], seed=manifest["seed"], methods=args.detectors
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    write_record(
        record_path,
        experiment=PROTOCOL,
        seeds=[manifest["seed"]],
        dataset=args.csv.name,
        data_path=args.csv,
        settings={
            "protocol": PROTOCOL,
            "exploratory": True,
            "label_column": args.label_column,
            "detectors": args.detectors,
            "partition_sha256": _sha256(args.partitions),
            "research_sha256": {name: _sha256(ROOT / name) for name in RESEARCH_SOURCES},
            "torch": _optional_version("torch"),
        },
        outputs=[args.output.name],
    )
    return 1 if result["errors"] or not result["runs"] else 0


def x_main__mutmut_41(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=Path, required=True)
    parser.add_argument("--partitions", type=Path, required=True)
    parser.add_argument("--label-column", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--detectors", required=True)
    args = parser.parse_args(argv)
    record_path = args.output.with_suffix(".record.json")
    if args.output.exists() or record_path.exists():
        raise FileExistsError("choose unused output and record paths")
    manifest = json.loads(args.partitions.read_text())
    if manifest["schema_version"] != 1 or manifest["input_sha256"] != _sha256(args.csv):
        raise ValueError("partition manifest version or source hash differs")
    with args.csv.open(newline="") as stream:
        header = next(csv.reader(stream))
    if len(set(header)) != len(header):
        raise ValueError("duplicate CSV column names are not accepted")
    frame = pd.read_csv(args.csv, dtype=str)
    if manifest["row_count"] != len(frame):
        raise ValueError("partition manifest row count differs")
    labels = pd.to_numeric(frame.pop(args.label_column), errors="raise").to_numpy()
    result = evaluate_frozen(
        frame, labels, manifest["partitions"], seed=manifest["seed"], methods=args.detectors
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    write_record(
        record_path,
        experiment=PROTOCOL,
        seeds=[manifest["seed"]],
        dataset=args.csv.name,
        data_path=args.csv,
        settings={
            "protocol": PROTOCOL,
            "exploratory": True,
            "label_column": args.label_column,
            "detectors": args.detectors,
            "partition_sha256": _sha256(args.partitions),
            "research_sha256": {name: _sha256(ROOT / name) for name in RESEARCH_SOURCES},
            "torch": _optional_version("torch"),
        },
        outputs=[args.output.name],
    )
    return 1 if result["errors"] or not result["runs"] else 0


def x_main__mutmut_42(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=Path, required=True)
    parser.add_argument("--partitions", type=Path, required=True)
    parser.add_argument("--label-column", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--detectors", nargs="+", )
    args = parser.parse_args(argv)
    record_path = args.output.with_suffix(".record.json")
    if args.output.exists() or record_path.exists():
        raise FileExistsError("choose unused output and record paths")
    manifest = json.loads(args.partitions.read_text())
    if manifest["schema_version"] != 1 or manifest["input_sha256"] != _sha256(args.csv):
        raise ValueError("partition manifest version or source hash differs")
    with args.csv.open(newline="") as stream:
        header = next(csv.reader(stream))
    if len(set(header)) != len(header):
        raise ValueError("duplicate CSV column names are not accepted")
    frame = pd.read_csv(args.csv, dtype=str)
    if manifest["row_count"] != len(frame):
        raise ValueError("partition manifest row count differs")
    labels = pd.to_numeric(frame.pop(args.label_column), errors="raise").to_numpy()
    result = evaluate_frozen(
        frame, labels, manifest["partitions"], seed=manifest["seed"], methods=args.detectors
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    write_record(
        record_path,
        experiment=PROTOCOL,
        seeds=[manifest["seed"]],
        dataset=args.csv.name,
        data_path=args.csv,
        settings={
            "protocol": PROTOCOL,
            "exploratory": True,
            "label_column": args.label_column,
            "detectors": args.detectors,
            "partition_sha256": _sha256(args.partitions),
            "research_sha256": {name: _sha256(ROOT / name) for name in RESEARCH_SOURCES},
            "torch": _optional_version("torch"),
        },
        outputs=[args.output.name],
    )
    return 1 if result["errors"] or not result["runs"] else 0


def x_main__mutmut_43(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=Path, required=True)
    parser.add_argument("--partitions", type=Path, required=True)
    parser.add_argument("--label-column", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("XX--detectorsXX", nargs="+", required=True)
    args = parser.parse_args(argv)
    record_path = args.output.with_suffix(".record.json")
    if args.output.exists() or record_path.exists():
        raise FileExistsError("choose unused output and record paths")
    manifest = json.loads(args.partitions.read_text())
    if manifest["schema_version"] != 1 or manifest["input_sha256"] != _sha256(args.csv):
        raise ValueError("partition manifest version or source hash differs")
    with args.csv.open(newline="") as stream:
        header = next(csv.reader(stream))
    if len(set(header)) != len(header):
        raise ValueError("duplicate CSV column names are not accepted")
    frame = pd.read_csv(args.csv, dtype=str)
    if manifest["row_count"] != len(frame):
        raise ValueError("partition manifest row count differs")
    labels = pd.to_numeric(frame.pop(args.label_column), errors="raise").to_numpy()
    result = evaluate_frozen(
        frame, labels, manifest["partitions"], seed=manifest["seed"], methods=args.detectors
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    write_record(
        record_path,
        experiment=PROTOCOL,
        seeds=[manifest["seed"]],
        dataset=args.csv.name,
        data_path=args.csv,
        settings={
            "protocol": PROTOCOL,
            "exploratory": True,
            "label_column": args.label_column,
            "detectors": args.detectors,
            "partition_sha256": _sha256(args.partitions),
            "research_sha256": {name: _sha256(ROOT / name) for name in RESEARCH_SOURCES},
            "torch": _optional_version("torch"),
        },
        outputs=[args.output.name],
    )
    return 1 if result["errors"] or not result["runs"] else 0


def x_main__mutmut_44(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=Path, required=True)
    parser.add_argument("--partitions", type=Path, required=True)
    parser.add_argument("--label-column", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--DETECTORS", nargs="+", required=True)
    args = parser.parse_args(argv)
    record_path = args.output.with_suffix(".record.json")
    if args.output.exists() or record_path.exists():
        raise FileExistsError("choose unused output and record paths")
    manifest = json.loads(args.partitions.read_text())
    if manifest["schema_version"] != 1 or manifest["input_sha256"] != _sha256(args.csv):
        raise ValueError("partition manifest version or source hash differs")
    with args.csv.open(newline="") as stream:
        header = next(csv.reader(stream))
    if len(set(header)) != len(header):
        raise ValueError("duplicate CSV column names are not accepted")
    frame = pd.read_csv(args.csv, dtype=str)
    if manifest["row_count"] != len(frame):
        raise ValueError("partition manifest row count differs")
    labels = pd.to_numeric(frame.pop(args.label_column), errors="raise").to_numpy()
    result = evaluate_frozen(
        frame, labels, manifest["partitions"], seed=manifest["seed"], methods=args.detectors
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    write_record(
        record_path,
        experiment=PROTOCOL,
        seeds=[manifest["seed"]],
        dataset=args.csv.name,
        data_path=args.csv,
        settings={
            "protocol": PROTOCOL,
            "exploratory": True,
            "label_column": args.label_column,
            "detectors": args.detectors,
            "partition_sha256": _sha256(args.partitions),
            "research_sha256": {name: _sha256(ROOT / name) for name in RESEARCH_SOURCES},
            "torch": _optional_version("torch"),
        },
        outputs=[args.output.name],
    )
    return 1 if result["errors"] or not result["runs"] else 0


def x_main__mutmut_45(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=Path, required=True)
    parser.add_argument("--partitions", type=Path, required=True)
    parser.add_argument("--label-column", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--detectors", nargs="XX+XX", required=True)
    args = parser.parse_args(argv)
    record_path = args.output.with_suffix(".record.json")
    if args.output.exists() or record_path.exists():
        raise FileExistsError("choose unused output and record paths")
    manifest = json.loads(args.partitions.read_text())
    if manifest["schema_version"] != 1 or manifest["input_sha256"] != _sha256(args.csv):
        raise ValueError("partition manifest version or source hash differs")
    with args.csv.open(newline="") as stream:
        header = next(csv.reader(stream))
    if len(set(header)) != len(header):
        raise ValueError("duplicate CSV column names are not accepted")
    frame = pd.read_csv(args.csv, dtype=str)
    if manifest["row_count"] != len(frame):
        raise ValueError("partition manifest row count differs")
    labels = pd.to_numeric(frame.pop(args.label_column), errors="raise").to_numpy()
    result = evaluate_frozen(
        frame, labels, manifest["partitions"], seed=manifest["seed"], methods=args.detectors
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    write_record(
        record_path,
        experiment=PROTOCOL,
        seeds=[manifest["seed"]],
        dataset=args.csv.name,
        data_path=args.csv,
        settings={
            "protocol": PROTOCOL,
            "exploratory": True,
            "label_column": args.label_column,
            "detectors": args.detectors,
            "partition_sha256": _sha256(args.partitions),
            "research_sha256": {name: _sha256(ROOT / name) for name in RESEARCH_SOURCES},
            "torch": _optional_version("torch"),
        },
        outputs=[args.output.name],
    )
    return 1 if result["errors"] or not result["runs"] else 0


def x_main__mutmut_46(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=Path, required=True)
    parser.add_argument("--partitions", type=Path, required=True)
    parser.add_argument("--label-column", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--detectors", nargs="+", required=False)
    args = parser.parse_args(argv)
    record_path = args.output.with_suffix(".record.json")
    if args.output.exists() or record_path.exists():
        raise FileExistsError("choose unused output and record paths")
    manifest = json.loads(args.partitions.read_text())
    if manifest["schema_version"] != 1 or manifest["input_sha256"] != _sha256(args.csv):
        raise ValueError("partition manifest version or source hash differs")
    with args.csv.open(newline="") as stream:
        header = next(csv.reader(stream))
    if len(set(header)) != len(header):
        raise ValueError("duplicate CSV column names are not accepted")
    frame = pd.read_csv(args.csv, dtype=str)
    if manifest["row_count"] != len(frame):
        raise ValueError("partition manifest row count differs")
    labels = pd.to_numeric(frame.pop(args.label_column), errors="raise").to_numpy()
    result = evaluate_frozen(
        frame, labels, manifest["partitions"], seed=manifest["seed"], methods=args.detectors
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    write_record(
        record_path,
        experiment=PROTOCOL,
        seeds=[manifest["seed"]],
        dataset=args.csv.name,
        data_path=args.csv,
        settings={
            "protocol": PROTOCOL,
            "exploratory": True,
            "label_column": args.label_column,
            "detectors": args.detectors,
            "partition_sha256": _sha256(args.partitions),
            "research_sha256": {name: _sha256(ROOT / name) for name in RESEARCH_SOURCES},
            "torch": _optional_version("torch"),
        },
        outputs=[args.output.name],
    )
    return 1 if result["errors"] or not result["runs"] else 0


def x_main__mutmut_47(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=Path, required=True)
    parser.add_argument("--partitions", type=Path, required=True)
    parser.add_argument("--label-column", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--detectors", nargs="+", required=True)
    args = None
    record_path = args.output.with_suffix(".record.json")
    if args.output.exists() or record_path.exists():
        raise FileExistsError("choose unused output and record paths")
    manifest = json.loads(args.partitions.read_text())
    if manifest["schema_version"] != 1 or manifest["input_sha256"] != _sha256(args.csv):
        raise ValueError("partition manifest version or source hash differs")
    with args.csv.open(newline="") as stream:
        header = next(csv.reader(stream))
    if len(set(header)) != len(header):
        raise ValueError("duplicate CSV column names are not accepted")
    frame = pd.read_csv(args.csv, dtype=str)
    if manifest["row_count"] != len(frame):
        raise ValueError("partition manifest row count differs")
    labels = pd.to_numeric(frame.pop(args.label_column), errors="raise").to_numpy()
    result = evaluate_frozen(
        frame, labels, manifest["partitions"], seed=manifest["seed"], methods=args.detectors
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    write_record(
        record_path,
        experiment=PROTOCOL,
        seeds=[manifest["seed"]],
        dataset=args.csv.name,
        data_path=args.csv,
        settings={
            "protocol": PROTOCOL,
            "exploratory": True,
            "label_column": args.label_column,
            "detectors": args.detectors,
            "partition_sha256": _sha256(args.partitions),
            "research_sha256": {name: _sha256(ROOT / name) for name in RESEARCH_SOURCES},
            "torch": _optional_version("torch"),
        },
        outputs=[args.output.name],
    )
    return 1 if result["errors"] or not result["runs"] else 0


def x_main__mutmut_48(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=Path, required=True)
    parser.add_argument("--partitions", type=Path, required=True)
    parser.add_argument("--label-column", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--detectors", nargs="+", required=True)
    args = parser.parse_args(None)
    record_path = args.output.with_suffix(".record.json")
    if args.output.exists() or record_path.exists():
        raise FileExistsError("choose unused output and record paths")
    manifest = json.loads(args.partitions.read_text())
    if manifest["schema_version"] != 1 or manifest["input_sha256"] != _sha256(args.csv):
        raise ValueError("partition manifest version or source hash differs")
    with args.csv.open(newline="") as stream:
        header = next(csv.reader(stream))
    if len(set(header)) != len(header):
        raise ValueError("duplicate CSV column names are not accepted")
    frame = pd.read_csv(args.csv, dtype=str)
    if manifest["row_count"] != len(frame):
        raise ValueError("partition manifest row count differs")
    labels = pd.to_numeric(frame.pop(args.label_column), errors="raise").to_numpy()
    result = evaluate_frozen(
        frame, labels, manifest["partitions"], seed=manifest["seed"], methods=args.detectors
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    write_record(
        record_path,
        experiment=PROTOCOL,
        seeds=[manifest["seed"]],
        dataset=args.csv.name,
        data_path=args.csv,
        settings={
            "protocol": PROTOCOL,
            "exploratory": True,
            "label_column": args.label_column,
            "detectors": args.detectors,
            "partition_sha256": _sha256(args.partitions),
            "research_sha256": {name: _sha256(ROOT / name) for name in RESEARCH_SOURCES},
            "torch": _optional_version("torch"),
        },
        outputs=[args.output.name],
    )
    return 1 if result["errors"] or not result["runs"] else 0


def x_main__mutmut_49(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=Path, required=True)
    parser.add_argument("--partitions", type=Path, required=True)
    parser.add_argument("--label-column", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--detectors", nargs="+", required=True)
    args = parser.parse_args(argv)
    record_path = None
    if args.output.exists() or record_path.exists():
        raise FileExistsError("choose unused output and record paths")
    manifest = json.loads(args.partitions.read_text())
    if manifest["schema_version"] != 1 or manifest["input_sha256"] != _sha256(args.csv):
        raise ValueError("partition manifest version or source hash differs")
    with args.csv.open(newline="") as stream:
        header = next(csv.reader(stream))
    if len(set(header)) != len(header):
        raise ValueError("duplicate CSV column names are not accepted")
    frame = pd.read_csv(args.csv, dtype=str)
    if manifest["row_count"] != len(frame):
        raise ValueError("partition manifest row count differs")
    labels = pd.to_numeric(frame.pop(args.label_column), errors="raise").to_numpy()
    result = evaluate_frozen(
        frame, labels, manifest["partitions"], seed=manifest["seed"], methods=args.detectors
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    write_record(
        record_path,
        experiment=PROTOCOL,
        seeds=[manifest["seed"]],
        dataset=args.csv.name,
        data_path=args.csv,
        settings={
            "protocol": PROTOCOL,
            "exploratory": True,
            "label_column": args.label_column,
            "detectors": args.detectors,
            "partition_sha256": _sha256(args.partitions),
            "research_sha256": {name: _sha256(ROOT / name) for name in RESEARCH_SOURCES},
            "torch": _optional_version("torch"),
        },
        outputs=[args.output.name],
    )
    return 1 if result["errors"] or not result["runs"] else 0


def x_main__mutmut_50(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=Path, required=True)
    parser.add_argument("--partitions", type=Path, required=True)
    parser.add_argument("--label-column", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--detectors", nargs="+", required=True)
    args = parser.parse_args(argv)
    record_path = args.output.with_suffix(None)
    if args.output.exists() or record_path.exists():
        raise FileExistsError("choose unused output and record paths")
    manifest = json.loads(args.partitions.read_text())
    if manifest["schema_version"] != 1 or manifest["input_sha256"] != _sha256(args.csv):
        raise ValueError("partition manifest version or source hash differs")
    with args.csv.open(newline="") as stream:
        header = next(csv.reader(stream))
    if len(set(header)) != len(header):
        raise ValueError("duplicate CSV column names are not accepted")
    frame = pd.read_csv(args.csv, dtype=str)
    if manifest["row_count"] != len(frame):
        raise ValueError("partition manifest row count differs")
    labels = pd.to_numeric(frame.pop(args.label_column), errors="raise").to_numpy()
    result = evaluate_frozen(
        frame, labels, manifest["partitions"], seed=manifest["seed"], methods=args.detectors
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    write_record(
        record_path,
        experiment=PROTOCOL,
        seeds=[manifest["seed"]],
        dataset=args.csv.name,
        data_path=args.csv,
        settings={
            "protocol": PROTOCOL,
            "exploratory": True,
            "label_column": args.label_column,
            "detectors": args.detectors,
            "partition_sha256": _sha256(args.partitions),
            "research_sha256": {name: _sha256(ROOT / name) for name in RESEARCH_SOURCES},
            "torch": _optional_version("torch"),
        },
        outputs=[args.output.name],
    )
    return 1 if result["errors"] or not result["runs"] else 0


def x_main__mutmut_51(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=Path, required=True)
    parser.add_argument("--partitions", type=Path, required=True)
    parser.add_argument("--label-column", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--detectors", nargs="+", required=True)
    args = parser.parse_args(argv)
    record_path = args.output.with_suffix("XX.record.jsonXX")
    if args.output.exists() or record_path.exists():
        raise FileExistsError("choose unused output and record paths")
    manifest = json.loads(args.partitions.read_text())
    if manifest["schema_version"] != 1 or manifest["input_sha256"] != _sha256(args.csv):
        raise ValueError("partition manifest version or source hash differs")
    with args.csv.open(newline="") as stream:
        header = next(csv.reader(stream))
    if len(set(header)) != len(header):
        raise ValueError("duplicate CSV column names are not accepted")
    frame = pd.read_csv(args.csv, dtype=str)
    if manifest["row_count"] != len(frame):
        raise ValueError("partition manifest row count differs")
    labels = pd.to_numeric(frame.pop(args.label_column), errors="raise").to_numpy()
    result = evaluate_frozen(
        frame, labels, manifest["partitions"], seed=manifest["seed"], methods=args.detectors
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    write_record(
        record_path,
        experiment=PROTOCOL,
        seeds=[manifest["seed"]],
        dataset=args.csv.name,
        data_path=args.csv,
        settings={
            "protocol": PROTOCOL,
            "exploratory": True,
            "label_column": args.label_column,
            "detectors": args.detectors,
            "partition_sha256": _sha256(args.partitions),
            "research_sha256": {name: _sha256(ROOT / name) for name in RESEARCH_SOURCES},
            "torch": _optional_version("torch"),
        },
        outputs=[args.output.name],
    )
    return 1 if result["errors"] or not result["runs"] else 0


def x_main__mutmut_52(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=Path, required=True)
    parser.add_argument("--partitions", type=Path, required=True)
    parser.add_argument("--label-column", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--detectors", nargs="+", required=True)
    args = parser.parse_args(argv)
    record_path = args.output.with_suffix(".RECORD.JSON")
    if args.output.exists() or record_path.exists():
        raise FileExistsError("choose unused output and record paths")
    manifest = json.loads(args.partitions.read_text())
    if manifest["schema_version"] != 1 or manifest["input_sha256"] != _sha256(args.csv):
        raise ValueError("partition manifest version or source hash differs")
    with args.csv.open(newline="") as stream:
        header = next(csv.reader(stream))
    if len(set(header)) != len(header):
        raise ValueError("duplicate CSV column names are not accepted")
    frame = pd.read_csv(args.csv, dtype=str)
    if manifest["row_count"] != len(frame):
        raise ValueError("partition manifest row count differs")
    labels = pd.to_numeric(frame.pop(args.label_column), errors="raise").to_numpy()
    result = evaluate_frozen(
        frame, labels, manifest["partitions"], seed=manifest["seed"], methods=args.detectors
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    write_record(
        record_path,
        experiment=PROTOCOL,
        seeds=[manifest["seed"]],
        dataset=args.csv.name,
        data_path=args.csv,
        settings={
            "protocol": PROTOCOL,
            "exploratory": True,
            "label_column": args.label_column,
            "detectors": args.detectors,
            "partition_sha256": _sha256(args.partitions),
            "research_sha256": {name: _sha256(ROOT / name) for name in RESEARCH_SOURCES},
            "torch": _optional_version("torch"),
        },
        outputs=[args.output.name],
    )
    return 1 if result["errors"] or not result["runs"] else 0


def x_main__mutmut_53(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=Path, required=True)
    parser.add_argument("--partitions", type=Path, required=True)
    parser.add_argument("--label-column", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--detectors", nargs="+", required=True)
    args = parser.parse_args(argv)
    record_path = args.output.with_suffix(".record.json")
    if args.output.exists() and record_path.exists():
        raise FileExistsError("choose unused output and record paths")
    manifest = json.loads(args.partitions.read_text())
    if manifest["schema_version"] != 1 or manifest["input_sha256"] != _sha256(args.csv):
        raise ValueError("partition manifest version or source hash differs")
    with args.csv.open(newline="") as stream:
        header = next(csv.reader(stream))
    if len(set(header)) != len(header):
        raise ValueError("duplicate CSV column names are not accepted")
    frame = pd.read_csv(args.csv, dtype=str)
    if manifest["row_count"] != len(frame):
        raise ValueError("partition manifest row count differs")
    labels = pd.to_numeric(frame.pop(args.label_column), errors="raise").to_numpy()
    result = evaluate_frozen(
        frame, labels, manifest["partitions"], seed=manifest["seed"], methods=args.detectors
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    write_record(
        record_path,
        experiment=PROTOCOL,
        seeds=[manifest["seed"]],
        dataset=args.csv.name,
        data_path=args.csv,
        settings={
            "protocol": PROTOCOL,
            "exploratory": True,
            "label_column": args.label_column,
            "detectors": args.detectors,
            "partition_sha256": _sha256(args.partitions),
            "research_sha256": {name: _sha256(ROOT / name) for name in RESEARCH_SOURCES},
            "torch": _optional_version("torch"),
        },
        outputs=[args.output.name],
    )
    return 1 if result["errors"] or not result["runs"] else 0


def x_main__mutmut_54(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=Path, required=True)
    parser.add_argument("--partitions", type=Path, required=True)
    parser.add_argument("--label-column", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--detectors", nargs="+", required=True)
    args = parser.parse_args(argv)
    record_path = args.output.with_suffix(".record.json")
    if args.output.exists() or record_path.exists():
        raise FileExistsError(None)
    manifest = json.loads(args.partitions.read_text())
    if manifest["schema_version"] != 1 or manifest["input_sha256"] != _sha256(args.csv):
        raise ValueError("partition manifest version or source hash differs")
    with args.csv.open(newline="") as stream:
        header = next(csv.reader(stream))
    if len(set(header)) != len(header):
        raise ValueError("duplicate CSV column names are not accepted")
    frame = pd.read_csv(args.csv, dtype=str)
    if manifest["row_count"] != len(frame):
        raise ValueError("partition manifest row count differs")
    labels = pd.to_numeric(frame.pop(args.label_column), errors="raise").to_numpy()
    result = evaluate_frozen(
        frame, labels, manifest["partitions"], seed=manifest["seed"], methods=args.detectors
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    write_record(
        record_path,
        experiment=PROTOCOL,
        seeds=[manifest["seed"]],
        dataset=args.csv.name,
        data_path=args.csv,
        settings={
            "protocol": PROTOCOL,
            "exploratory": True,
            "label_column": args.label_column,
            "detectors": args.detectors,
            "partition_sha256": _sha256(args.partitions),
            "research_sha256": {name: _sha256(ROOT / name) for name in RESEARCH_SOURCES},
            "torch": _optional_version("torch"),
        },
        outputs=[args.output.name],
    )
    return 1 if result["errors"] or not result["runs"] else 0


def x_main__mutmut_55(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=Path, required=True)
    parser.add_argument("--partitions", type=Path, required=True)
    parser.add_argument("--label-column", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--detectors", nargs="+", required=True)
    args = parser.parse_args(argv)
    record_path = args.output.with_suffix(".record.json")
    if args.output.exists() or record_path.exists():
        raise FileExistsError("XXchoose unused output and record pathsXX")
    manifest = json.loads(args.partitions.read_text())
    if manifest["schema_version"] != 1 or manifest["input_sha256"] != _sha256(args.csv):
        raise ValueError("partition manifest version or source hash differs")
    with args.csv.open(newline="") as stream:
        header = next(csv.reader(stream))
    if len(set(header)) != len(header):
        raise ValueError("duplicate CSV column names are not accepted")
    frame = pd.read_csv(args.csv, dtype=str)
    if manifest["row_count"] != len(frame):
        raise ValueError("partition manifest row count differs")
    labels = pd.to_numeric(frame.pop(args.label_column), errors="raise").to_numpy()
    result = evaluate_frozen(
        frame, labels, manifest["partitions"], seed=manifest["seed"], methods=args.detectors
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    write_record(
        record_path,
        experiment=PROTOCOL,
        seeds=[manifest["seed"]],
        dataset=args.csv.name,
        data_path=args.csv,
        settings={
            "protocol": PROTOCOL,
            "exploratory": True,
            "label_column": args.label_column,
            "detectors": args.detectors,
            "partition_sha256": _sha256(args.partitions),
            "research_sha256": {name: _sha256(ROOT / name) for name in RESEARCH_SOURCES},
            "torch": _optional_version("torch"),
        },
        outputs=[args.output.name],
    )
    return 1 if result["errors"] or not result["runs"] else 0


def x_main__mutmut_56(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=Path, required=True)
    parser.add_argument("--partitions", type=Path, required=True)
    parser.add_argument("--label-column", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--detectors", nargs="+", required=True)
    args = parser.parse_args(argv)
    record_path = args.output.with_suffix(".record.json")
    if args.output.exists() or record_path.exists():
        raise FileExistsError("CHOOSE UNUSED OUTPUT AND RECORD PATHS")
    manifest = json.loads(args.partitions.read_text())
    if manifest["schema_version"] != 1 or manifest["input_sha256"] != _sha256(args.csv):
        raise ValueError("partition manifest version or source hash differs")
    with args.csv.open(newline="") as stream:
        header = next(csv.reader(stream))
    if len(set(header)) != len(header):
        raise ValueError("duplicate CSV column names are not accepted")
    frame = pd.read_csv(args.csv, dtype=str)
    if manifest["row_count"] != len(frame):
        raise ValueError("partition manifest row count differs")
    labels = pd.to_numeric(frame.pop(args.label_column), errors="raise").to_numpy()
    result = evaluate_frozen(
        frame, labels, manifest["partitions"], seed=manifest["seed"], methods=args.detectors
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    write_record(
        record_path,
        experiment=PROTOCOL,
        seeds=[manifest["seed"]],
        dataset=args.csv.name,
        data_path=args.csv,
        settings={
            "protocol": PROTOCOL,
            "exploratory": True,
            "label_column": args.label_column,
            "detectors": args.detectors,
            "partition_sha256": _sha256(args.partitions),
            "research_sha256": {name: _sha256(ROOT / name) for name in RESEARCH_SOURCES},
            "torch": _optional_version("torch"),
        },
        outputs=[args.output.name],
    )
    return 1 if result["errors"] or not result["runs"] else 0


def x_main__mutmut_57(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=Path, required=True)
    parser.add_argument("--partitions", type=Path, required=True)
    parser.add_argument("--label-column", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--detectors", nargs="+", required=True)
    args = parser.parse_args(argv)
    record_path = args.output.with_suffix(".record.json")
    if args.output.exists() or record_path.exists():
        raise FileExistsError("choose unused output and record paths")
    manifest = None
    if manifest["schema_version"] != 1 or manifest["input_sha256"] != _sha256(args.csv):
        raise ValueError("partition manifest version or source hash differs")
    with args.csv.open(newline="") as stream:
        header = next(csv.reader(stream))
    if len(set(header)) != len(header):
        raise ValueError("duplicate CSV column names are not accepted")
    frame = pd.read_csv(args.csv, dtype=str)
    if manifest["row_count"] != len(frame):
        raise ValueError("partition manifest row count differs")
    labels = pd.to_numeric(frame.pop(args.label_column), errors="raise").to_numpy()
    result = evaluate_frozen(
        frame, labels, manifest["partitions"], seed=manifest["seed"], methods=args.detectors
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    write_record(
        record_path,
        experiment=PROTOCOL,
        seeds=[manifest["seed"]],
        dataset=args.csv.name,
        data_path=args.csv,
        settings={
            "protocol": PROTOCOL,
            "exploratory": True,
            "label_column": args.label_column,
            "detectors": args.detectors,
            "partition_sha256": _sha256(args.partitions),
            "research_sha256": {name: _sha256(ROOT / name) for name in RESEARCH_SOURCES},
            "torch": _optional_version("torch"),
        },
        outputs=[args.output.name],
    )
    return 1 if result["errors"] or not result["runs"] else 0


def x_main__mutmut_58(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=Path, required=True)
    parser.add_argument("--partitions", type=Path, required=True)
    parser.add_argument("--label-column", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--detectors", nargs="+", required=True)
    args = parser.parse_args(argv)
    record_path = args.output.with_suffix(".record.json")
    if args.output.exists() or record_path.exists():
        raise FileExistsError("choose unused output and record paths")
    manifest = json.loads(None)
    if manifest["schema_version"] != 1 or manifest["input_sha256"] != _sha256(args.csv):
        raise ValueError("partition manifest version or source hash differs")
    with args.csv.open(newline="") as stream:
        header = next(csv.reader(stream))
    if len(set(header)) != len(header):
        raise ValueError("duplicate CSV column names are not accepted")
    frame = pd.read_csv(args.csv, dtype=str)
    if manifest["row_count"] != len(frame):
        raise ValueError("partition manifest row count differs")
    labels = pd.to_numeric(frame.pop(args.label_column), errors="raise").to_numpy()
    result = evaluate_frozen(
        frame, labels, manifest["partitions"], seed=manifest["seed"], methods=args.detectors
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    write_record(
        record_path,
        experiment=PROTOCOL,
        seeds=[manifest["seed"]],
        dataset=args.csv.name,
        data_path=args.csv,
        settings={
            "protocol": PROTOCOL,
            "exploratory": True,
            "label_column": args.label_column,
            "detectors": args.detectors,
            "partition_sha256": _sha256(args.partitions),
            "research_sha256": {name: _sha256(ROOT / name) for name in RESEARCH_SOURCES},
            "torch": _optional_version("torch"),
        },
        outputs=[args.output.name],
    )
    return 1 if result["errors"] or not result["runs"] else 0


def x_main__mutmut_59(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=Path, required=True)
    parser.add_argument("--partitions", type=Path, required=True)
    parser.add_argument("--label-column", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--detectors", nargs="+", required=True)
    args = parser.parse_args(argv)
    record_path = args.output.with_suffix(".record.json")
    if args.output.exists() or record_path.exists():
        raise FileExistsError("choose unused output and record paths")
    manifest = json.loads(args.partitions.read_text())
    if manifest["schema_version"] != 1 and manifest["input_sha256"] != _sha256(args.csv):
        raise ValueError("partition manifest version or source hash differs")
    with args.csv.open(newline="") as stream:
        header = next(csv.reader(stream))
    if len(set(header)) != len(header):
        raise ValueError("duplicate CSV column names are not accepted")
    frame = pd.read_csv(args.csv, dtype=str)
    if manifest["row_count"] != len(frame):
        raise ValueError("partition manifest row count differs")
    labels = pd.to_numeric(frame.pop(args.label_column), errors="raise").to_numpy()
    result = evaluate_frozen(
        frame, labels, manifest["partitions"], seed=manifest["seed"], methods=args.detectors
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    write_record(
        record_path,
        experiment=PROTOCOL,
        seeds=[manifest["seed"]],
        dataset=args.csv.name,
        data_path=args.csv,
        settings={
            "protocol": PROTOCOL,
            "exploratory": True,
            "label_column": args.label_column,
            "detectors": args.detectors,
            "partition_sha256": _sha256(args.partitions),
            "research_sha256": {name: _sha256(ROOT / name) for name in RESEARCH_SOURCES},
            "torch": _optional_version("torch"),
        },
        outputs=[args.output.name],
    )
    return 1 if result["errors"] or not result["runs"] else 0


def x_main__mutmut_60(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=Path, required=True)
    parser.add_argument("--partitions", type=Path, required=True)
    parser.add_argument("--label-column", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--detectors", nargs="+", required=True)
    args = parser.parse_args(argv)
    record_path = args.output.with_suffix(".record.json")
    if args.output.exists() or record_path.exists():
        raise FileExistsError("choose unused output and record paths")
    manifest = json.loads(args.partitions.read_text())
    if manifest["XXschema_versionXX"] != 1 or manifest["input_sha256"] != _sha256(args.csv):
        raise ValueError("partition manifest version or source hash differs")
    with args.csv.open(newline="") as stream:
        header = next(csv.reader(stream))
    if len(set(header)) != len(header):
        raise ValueError("duplicate CSV column names are not accepted")
    frame = pd.read_csv(args.csv, dtype=str)
    if manifest["row_count"] != len(frame):
        raise ValueError("partition manifest row count differs")
    labels = pd.to_numeric(frame.pop(args.label_column), errors="raise").to_numpy()
    result = evaluate_frozen(
        frame, labels, manifest["partitions"], seed=manifest["seed"], methods=args.detectors
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    write_record(
        record_path,
        experiment=PROTOCOL,
        seeds=[manifest["seed"]],
        dataset=args.csv.name,
        data_path=args.csv,
        settings={
            "protocol": PROTOCOL,
            "exploratory": True,
            "label_column": args.label_column,
            "detectors": args.detectors,
            "partition_sha256": _sha256(args.partitions),
            "research_sha256": {name: _sha256(ROOT / name) for name in RESEARCH_SOURCES},
            "torch": _optional_version("torch"),
        },
        outputs=[args.output.name],
    )
    return 1 if result["errors"] or not result["runs"] else 0


def x_main__mutmut_61(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=Path, required=True)
    parser.add_argument("--partitions", type=Path, required=True)
    parser.add_argument("--label-column", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--detectors", nargs="+", required=True)
    args = parser.parse_args(argv)
    record_path = args.output.with_suffix(".record.json")
    if args.output.exists() or record_path.exists():
        raise FileExistsError("choose unused output and record paths")
    manifest = json.loads(args.partitions.read_text())
    if manifest["SCHEMA_VERSION"] != 1 or manifest["input_sha256"] != _sha256(args.csv):
        raise ValueError("partition manifest version or source hash differs")
    with args.csv.open(newline="") as stream:
        header = next(csv.reader(stream))
    if len(set(header)) != len(header):
        raise ValueError("duplicate CSV column names are not accepted")
    frame = pd.read_csv(args.csv, dtype=str)
    if manifest["row_count"] != len(frame):
        raise ValueError("partition manifest row count differs")
    labels = pd.to_numeric(frame.pop(args.label_column), errors="raise").to_numpy()
    result = evaluate_frozen(
        frame, labels, manifest["partitions"], seed=manifest["seed"], methods=args.detectors
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    write_record(
        record_path,
        experiment=PROTOCOL,
        seeds=[manifest["seed"]],
        dataset=args.csv.name,
        data_path=args.csv,
        settings={
            "protocol": PROTOCOL,
            "exploratory": True,
            "label_column": args.label_column,
            "detectors": args.detectors,
            "partition_sha256": _sha256(args.partitions),
            "research_sha256": {name: _sha256(ROOT / name) for name in RESEARCH_SOURCES},
            "torch": _optional_version("torch"),
        },
        outputs=[args.output.name],
    )
    return 1 if result["errors"] or not result["runs"] else 0


def x_main__mutmut_62(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=Path, required=True)
    parser.add_argument("--partitions", type=Path, required=True)
    parser.add_argument("--label-column", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--detectors", nargs="+", required=True)
    args = parser.parse_args(argv)
    record_path = args.output.with_suffix(".record.json")
    if args.output.exists() or record_path.exists():
        raise FileExistsError("choose unused output and record paths")
    manifest = json.loads(args.partitions.read_text())
    if manifest["schema_version"] == 1 or manifest["input_sha256"] != _sha256(args.csv):
        raise ValueError("partition manifest version or source hash differs")
    with args.csv.open(newline="") as stream:
        header = next(csv.reader(stream))
    if len(set(header)) != len(header):
        raise ValueError("duplicate CSV column names are not accepted")
    frame = pd.read_csv(args.csv, dtype=str)
    if manifest["row_count"] != len(frame):
        raise ValueError("partition manifest row count differs")
    labels = pd.to_numeric(frame.pop(args.label_column), errors="raise").to_numpy()
    result = evaluate_frozen(
        frame, labels, manifest["partitions"], seed=manifest["seed"], methods=args.detectors
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    write_record(
        record_path,
        experiment=PROTOCOL,
        seeds=[manifest["seed"]],
        dataset=args.csv.name,
        data_path=args.csv,
        settings={
            "protocol": PROTOCOL,
            "exploratory": True,
            "label_column": args.label_column,
            "detectors": args.detectors,
            "partition_sha256": _sha256(args.partitions),
            "research_sha256": {name: _sha256(ROOT / name) for name in RESEARCH_SOURCES},
            "torch": _optional_version("torch"),
        },
        outputs=[args.output.name],
    )
    return 1 if result["errors"] or not result["runs"] else 0


def x_main__mutmut_63(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=Path, required=True)
    parser.add_argument("--partitions", type=Path, required=True)
    parser.add_argument("--label-column", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--detectors", nargs="+", required=True)
    args = parser.parse_args(argv)
    record_path = args.output.with_suffix(".record.json")
    if args.output.exists() or record_path.exists():
        raise FileExistsError("choose unused output and record paths")
    manifest = json.loads(args.partitions.read_text())
    if manifest["schema_version"] != 2 or manifest["input_sha256"] != _sha256(args.csv):
        raise ValueError("partition manifest version or source hash differs")
    with args.csv.open(newline="") as stream:
        header = next(csv.reader(stream))
    if len(set(header)) != len(header):
        raise ValueError("duplicate CSV column names are not accepted")
    frame = pd.read_csv(args.csv, dtype=str)
    if manifest["row_count"] != len(frame):
        raise ValueError("partition manifest row count differs")
    labels = pd.to_numeric(frame.pop(args.label_column), errors="raise").to_numpy()
    result = evaluate_frozen(
        frame, labels, manifest["partitions"], seed=manifest["seed"], methods=args.detectors
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    write_record(
        record_path,
        experiment=PROTOCOL,
        seeds=[manifest["seed"]],
        dataset=args.csv.name,
        data_path=args.csv,
        settings={
            "protocol": PROTOCOL,
            "exploratory": True,
            "label_column": args.label_column,
            "detectors": args.detectors,
            "partition_sha256": _sha256(args.partitions),
            "research_sha256": {name: _sha256(ROOT / name) for name in RESEARCH_SOURCES},
            "torch": _optional_version("torch"),
        },
        outputs=[args.output.name],
    )
    return 1 if result["errors"] or not result["runs"] else 0


def x_main__mutmut_64(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=Path, required=True)
    parser.add_argument("--partitions", type=Path, required=True)
    parser.add_argument("--label-column", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--detectors", nargs="+", required=True)
    args = parser.parse_args(argv)
    record_path = args.output.with_suffix(".record.json")
    if args.output.exists() or record_path.exists():
        raise FileExistsError("choose unused output and record paths")
    manifest = json.loads(args.partitions.read_text())
    if manifest["schema_version"] != 1 or manifest["XXinput_sha256XX"] != _sha256(args.csv):
        raise ValueError("partition manifest version or source hash differs")
    with args.csv.open(newline="") as stream:
        header = next(csv.reader(stream))
    if len(set(header)) != len(header):
        raise ValueError("duplicate CSV column names are not accepted")
    frame = pd.read_csv(args.csv, dtype=str)
    if manifest["row_count"] != len(frame):
        raise ValueError("partition manifest row count differs")
    labels = pd.to_numeric(frame.pop(args.label_column), errors="raise").to_numpy()
    result = evaluate_frozen(
        frame, labels, manifest["partitions"], seed=manifest["seed"], methods=args.detectors
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    write_record(
        record_path,
        experiment=PROTOCOL,
        seeds=[manifest["seed"]],
        dataset=args.csv.name,
        data_path=args.csv,
        settings={
            "protocol": PROTOCOL,
            "exploratory": True,
            "label_column": args.label_column,
            "detectors": args.detectors,
            "partition_sha256": _sha256(args.partitions),
            "research_sha256": {name: _sha256(ROOT / name) for name in RESEARCH_SOURCES},
            "torch": _optional_version("torch"),
        },
        outputs=[args.output.name],
    )
    return 1 if result["errors"] or not result["runs"] else 0


def x_main__mutmut_65(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=Path, required=True)
    parser.add_argument("--partitions", type=Path, required=True)
    parser.add_argument("--label-column", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--detectors", nargs="+", required=True)
    args = parser.parse_args(argv)
    record_path = args.output.with_suffix(".record.json")
    if args.output.exists() or record_path.exists():
        raise FileExistsError("choose unused output and record paths")
    manifest = json.loads(args.partitions.read_text())
    if manifest["schema_version"] != 1 or manifest["INPUT_SHA256"] != _sha256(args.csv):
        raise ValueError("partition manifest version or source hash differs")
    with args.csv.open(newline="") as stream:
        header = next(csv.reader(stream))
    if len(set(header)) != len(header):
        raise ValueError("duplicate CSV column names are not accepted")
    frame = pd.read_csv(args.csv, dtype=str)
    if manifest["row_count"] != len(frame):
        raise ValueError("partition manifest row count differs")
    labels = pd.to_numeric(frame.pop(args.label_column), errors="raise").to_numpy()
    result = evaluate_frozen(
        frame, labels, manifest["partitions"], seed=manifest["seed"], methods=args.detectors
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    write_record(
        record_path,
        experiment=PROTOCOL,
        seeds=[manifest["seed"]],
        dataset=args.csv.name,
        data_path=args.csv,
        settings={
            "protocol": PROTOCOL,
            "exploratory": True,
            "label_column": args.label_column,
            "detectors": args.detectors,
            "partition_sha256": _sha256(args.partitions),
            "research_sha256": {name: _sha256(ROOT / name) for name in RESEARCH_SOURCES},
            "torch": _optional_version("torch"),
        },
        outputs=[args.output.name],
    )
    return 1 if result["errors"] or not result["runs"] else 0


def x_main__mutmut_66(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=Path, required=True)
    parser.add_argument("--partitions", type=Path, required=True)
    parser.add_argument("--label-column", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--detectors", nargs="+", required=True)
    args = parser.parse_args(argv)
    record_path = args.output.with_suffix(".record.json")
    if args.output.exists() or record_path.exists():
        raise FileExistsError("choose unused output and record paths")
    manifest = json.loads(args.partitions.read_text())
    if manifest["schema_version"] != 1 or manifest["input_sha256"] == _sha256(args.csv):
        raise ValueError("partition manifest version or source hash differs")
    with args.csv.open(newline="") as stream:
        header = next(csv.reader(stream))
    if len(set(header)) != len(header):
        raise ValueError("duplicate CSV column names are not accepted")
    frame = pd.read_csv(args.csv, dtype=str)
    if manifest["row_count"] != len(frame):
        raise ValueError("partition manifest row count differs")
    labels = pd.to_numeric(frame.pop(args.label_column), errors="raise").to_numpy()
    result = evaluate_frozen(
        frame, labels, manifest["partitions"], seed=manifest["seed"], methods=args.detectors
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    write_record(
        record_path,
        experiment=PROTOCOL,
        seeds=[manifest["seed"]],
        dataset=args.csv.name,
        data_path=args.csv,
        settings={
            "protocol": PROTOCOL,
            "exploratory": True,
            "label_column": args.label_column,
            "detectors": args.detectors,
            "partition_sha256": _sha256(args.partitions),
            "research_sha256": {name: _sha256(ROOT / name) for name in RESEARCH_SOURCES},
            "torch": _optional_version("torch"),
        },
        outputs=[args.output.name],
    )
    return 1 if result["errors"] or not result["runs"] else 0


def x_main__mutmut_67(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=Path, required=True)
    parser.add_argument("--partitions", type=Path, required=True)
    parser.add_argument("--label-column", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--detectors", nargs="+", required=True)
    args = parser.parse_args(argv)
    record_path = args.output.with_suffix(".record.json")
    if args.output.exists() or record_path.exists():
        raise FileExistsError("choose unused output and record paths")
    manifest = json.loads(args.partitions.read_text())
    if manifest["schema_version"] != 1 or manifest["input_sha256"] != _sha256(None):
        raise ValueError("partition manifest version or source hash differs")
    with args.csv.open(newline="") as stream:
        header = next(csv.reader(stream))
    if len(set(header)) != len(header):
        raise ValueError("duplicate CSV column names are not accepted")
    frame = pd.read_csv(args.csv, dtype=str)
    if manifest["row_count"] != len(frame):
        raise ValueError("partition manifest row count differs")
    labels = pd.to_numeric(frame.pop(args.label_column), errors="raise").to_numpy()
    result = evaluate_frozen(
        frame, labels, manifest["partitions"], seed=manifest["seed"], methods=args.detectors
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    write_record(
        record_path,
        experiment=PROTOCOL,
        seeds=[manifest["seed"]],
        dataset=args.csv.name,
        data_path=args.csv,
        settings={
            "protocol": PROTOCOL,
            "exploratory": True,
            "label_column": args.label_column,
            "detectors": args.detectors,
            "partition_sha256": _sha256(args.partitions),
            "research_sha256": {name: _sha256(ROOT / name) for name in RESEARCH_SOURCES},
            "torch": _optional_version("torch"),
        },
        outputs=[args.output.name],
    )
    return 1 if result["errors"] or not result["runs"] else 0


def x_main__mutmut_68(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=Path, required=True)
    parser.add_argument("--partitions", type=Path, required=True)
    parser.add_argument("--label-column", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--detectors", nargs="+", required=True)
    args = parser.parse_args(argv)
    record_path = args.output.with_suffix(".record.json")
    if args.output.exists() or record_path.exists():
        raise FileExistsError("choose unused output and record paths")
    manifest = json.loads(args.partitions.read_text())
    if manifest["schema_version"] != 1 or manifest["input_sha256"] != _sha256(args.csv):
        raise ValueError(None)
    with args.csv.open(newline="") as stream:
        header = next(csv.reader(stream))
    if len(set(header)) != len(header):
        raise ValueError("duplicate CSV column names are not accepted")
    frame = pd.read_csv(args.csv, dtype=str)
    if manifest["row_count"] != len(frame):
        raise ValueError("partition manifest row count differs")
    labels = pd.to_numeric(frame.pop(args.label_column), errors="raise").to_numpy()
    result = evaluate_frozen(
        frame, labels, manifest["partitions"], seed=manifest["seed"], methods=args.detectors
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    write_record(
        record_path,
        experiment=PROTOCOL,
        seeds=[manifest["seed"]],
        dataset=args.csv.name,
        data_path=args.csv,
        settings={
            "protocol": PROTOCOL,
            "exploratory": True,
            "label_column": args.label_column,
            "detectors": args.detectors,
            "partition_sha256": _sha256(args.partitions),
            "research_sha256": {name: _sha256(ROOT / name) for name in RESEARCH_SOURCES},
            "torch": _optional_version("torch"),
        },
        outputs=[args.output.name],
    )
    return 1 if result["errors"] or not result["runs"] else 0


def x_main__mutmut_69(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=Path, required=True)
    parser.add_argument("--partitions", type=Path, required=True)
    parser.add_argument("--label-column", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--detectors", nargs="+", required=True)
    args = parser.parse_args(argv)
    record_path = args.output.with_suffix(".record.json")
    if args.output.exists() or record_path.exists():
        raise FileExistsError("choose unused output and record paths")
    manifest = json.loads(args.partitions.read_text())
    if manifest["schema_version"] != 1 or manifest["input_sha256"] != _sha256(args.csv):
        raise ValueError("XXpartition manifest version or source hash differsXX")
    with args.csv.open(newline="") as stream:
        header = next(csv.reader(stream))
    if len(set(header)) != len(header):
        raise ValueError("duplicate CSV column names are not accepted")
    frame = pd.read_csv(args.csv, dtype=str)
    if manifest["row_count"] != len(frame):
        raise ValueError("partition manifest row count differs")
    labels = pd.to_numeric(frame.pop(args.label_column), errors="raise").to_numpy()
    result = evaluate_frozen(
        frame, labels, manifest["partitions"], seed=manifest["seed"], methods=args.detectors
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    write_record(
        record_path,
        experiment=PROTOCOL,
        seeds=[manifest["seed"]],
        dataset=args.csv.name,
        data_path=args.csv,
        settings={
            "protocol": PROTOCOL,
            "exploratory": True,
            "label_column": args.label_column,
            "detectors": args.detectors,
            "partition_sha256": _sha256(args.partitions),
            "research_sha256": {name: _sha256(ROOT / name) for name in RESEARCH_SOURCES},
            "torch": _optional_version("torch"),
        },
        outputs=[args.output.name],
    )
    return 1 if result["errors"] or not result["runs"] else 0


def x_main__mutmut_70(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=Path, required=True)
    parser.add_argument("--partitions", type=Path, required=True)
    parser.add_argument("--label-column", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--detectors", nargs="+", required=True)
    args = parser.parse_args(argv)
    record_path = args.output.with_suffix(".record.json")
    if args.output.exists() or record_path.exists():
        raise FileExistsError("choose unused output and record paths")
    manifest = json.loads(args.partitions.read_text())
    if manifest["schema_version"] != 1 or manifest["input_sha256"] != _sha256(args.csv):
        raise ValueError("PARTITION MANIFEST VERSION OR SOURCE HASH DIFFERS")
    with args.csv.open(newline="") as stream:
        header = next(csv.reader(stream))
    if len(set(header)) != len(header):
        raise ValueError("duplicate CSV column names are not accepted")
    frame = pd.read_csv(args.csv, dtype=str)
    if manifest["row_count"] != len(frame):
        raise ValueError("partition manifest row count differs")
    labels = pd.to_numeric(frame.pop(args.label_column), errors="raise").to_numpy()
    result = evaluate_frozen(
        frame, labels, manifest["partitions"], seed=manifest["seed"], methods=args.detectors
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    write_record(
        record_path,
        experiment=PROTOCOL,
        seeds=[manifest["seed"]],
        dataset=args.csv.name,
        data_path=args.csv,
        settings={
            "protocol": PROTOCOL,
            "exploratory": True,
            "label_column": args.label_column,
            "detectors": args.detectors,
            "partition_sha256": _sha256(args.partitions),
            "research_sha256": {name: _sha256(ROOT / name) for name in RESEARCH_SOURCES},
            "torch": _optional_version("torch"),
        },
        outputs=[args.output.name],
    )
    return 1 if result["errors"] or not result["runs"] else 0


def x_main__mutmut_71(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=Path, required=True)
    parser.add_argument("--partitions", type=Path, required=True)
    parser.add_argument("--label-column", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--detectors", nargs="+", required=True)
    args = parser.parse_args(argv)
    record_path = args.output.with_suffix(".record.json")
    if args.output.exists() or record_path.exists():
        raise FileExistsError("choose unused output and record paths")
    manifest = json.loads(args.partitions.read_text())
    if manifest["schema_version"] != 1 or manifest["input_sha256"] != _sha256(args.csv):
        raise ValueError("partition manifest version or source hash differs")
    with args.csv.open(newline=None) as stream:
        header = next(csv.reader(stream))
    if len(set(header)) != len(header):
        raise ValueError("duplicate CSV column names are not accepted")
    frame = pd.read_csv(args.csv, dtype=str)
    if manifest["row_count"] != len(frame):
        raise ValueError("partition manifest row count differs")
    labels = pd.to_numeric(frame.pop(args.label_column), errors="raise").to_numpy()
    result = evaluate_frozen(
        frame, labels, manifest["partitions"], seed=manifest["seed"], methods=args.detectors
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    write_record(
        record_path,
        experiment=PROTOCOL,
        seeds=[manifest["seed"]],
        dataset=args.csv.name,
        data_path=args.csv,
        settings={
            "protocol": PROTOCOL,
            "exploratory": True,
            "label_column": args.label_column,
            "detectors": args.detectors,
            "partition_sha256": _sha256(args.partitions),
            "research_sha256": {name: _sha256(ROOT / name) for name in RESEARCH_SOURCES},
            "torch": _optional_version("torch"),
        },
        outputs=[args.output.name],
    )
    return 1 if result["errors"] or not result["runs"] else 0


def x_main__mutmut_72(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=Path, required=True)
    parser.add_argument("--partitions", type=Path, required=True)
    parser.add_argument("--label-column", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--detectors", nargs="+", required=True)
    args = parser.parse_args(argv)
    record_path = args.output.with_suffix(".record.json")
    if args.output.exists() or record_path.exists():
        raise FileExistsError("choose unused output and record paths")
    manifest = json.loads(args.partitions.read_text())
    if manifest["schema_version"] != 1 or manifest["input_sha256"] != _sha256(args.csv):
        raise ValueError("partition manifest version or source hash differs")
    with args.csv.open(newline="XXXX") as stream:
        header = next(csv.reader(stream))
    if len(set(header)) != len(header):
        raise ValueError("duplicate CSV column names are not accepted")
    frame = pd.read_csv(args.csv, dtype=str)
    if manifest["row_count"] != len(frame):
        raise ValueError("partition manifest row count differs")
    labels = pd.to_numeric(frame.pop(args.label_column), errors="raise").to_numpy()
    result = evaluate_frozen(
        frame, labels, manifest["partitions"], seed=manifest["seed"], methods=args.detectors
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    write_record(
        record_path,
        experiment=PROTOCOL,
        seeds=[manifest["seed"]],
        dataset=args.csv.name,
        data_path=args.csv,
        settings={
            "protocol": PROTOCOL,
            "exploratory": True,
            "label_column": args.label_column,
            "detectors": args.detectors,
            "partition_sha256": _sha256(args.partitions),
            "research_sha256": {name: _sha256(ROOT / name) for name in RESEARCH_SOURCES},
            "torch": _optional_version("torch"),
        },
        outputs=[args.output.name],
    )
    return 1 if result["errors"] or not result["runs"] else 0


def x_main__mutmut_73(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=Path, required=True)
    parser.add_argument("--partitions", type=Path, required=True)
    parser.add_argument("--label-column", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--detectors", nargs="+", required=True)
    args = parser.parse_args(argv)
    record_path = args.output.with_suffix(".record.json")
    if args.output.exists() or record_path.exists():
        raise FileExistsError("choose unused output and record paths")
    manifest = json.loads(args.partitions.read_text())
    if manifest["schema_version"] != 1 or manifest["input_sha256"] != _sha256(args.csv):
        raise ValueError("partition manifest version or source hash differs")
    with args.csv.open(newline="") as stream:
        header = None
    if len(set(header)) != len(header):
        raise ValueError("duplicate CSV column names are not accepted")
    frame = pd.read_csv(args.csv, dtype=str)
    if manifest["row_count"] != len(frame):
        raise ValueError("partition manifest row count differs")
    labels = pd.to_numeric(frame.pop(args.label_column), errors="raise").to_numpy()
    result = evaluate_frozen(
        frame, labels, manifest["partitions"], seed=manifest["seed"], methods=args.detectors
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    write_record(
        record_path,
        experiment=PROTOCOL,
        seeds=[manifest["seed"]],
        dataset=args.csv.name,
        data_path=args.csv,
        settings={
            "protocol": PROTOCOL,
            "exploratory": True,
            "label_column": args.label_column,
            "detectors": args.detectors,
            "partition_sha256": _sha256(args.partitions),
            "research_sha256": {name: _sha256(ROOT / name) for name in RESEARCH_SOURCES},
            "torch": _optional_version("torch"),
        },
        outputs=[args.output.name],
    )
    return 1 if result["errors"] or not result["runs"] else 0


def x_main__mutmut_74(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=Path, required=True)
    parser.add_argument("--partitions", type=Path, required=True)
    parser.add_argument("--label-column", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--detectors", nargs="+", required=True)
    args = parser.parse_args(argv)
    record_path = args.output.with_suffix(".record.json")
    if args.output.exists() or record_path.exists():
        raise FileExistsError("choose unused output and record paths")
    manifest = json.loads(args.partitions.read_text())
    if manifest["schema_version"] != 1 or manifest["input_sha256"] != _sha256(args.csv):
        raise ValueError("partition manifest version or source hash differs")
    with args.csv.open(newline="") as stream:
        header = next(None)
    if len(set(header)) != len(header):
        raise ValueError("duplicate CSV column names are not accepted")
    frame = pd.read_csv(args.csv, dtype=str)
    if manifest["row_count"] != len(frame):
        raise ValueError("partition manifest row count differs")
    labels = pd.to_numeric(frame.pop(args.label_column), errors="raise").to_numpy()
    result = evaluate_frozen(
        frame, labels, manifest["partitions"], seed=manifest["seed"], methods=args.detectors
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    write_record(
        record_path,
        experiment=PROTOCOL,
        seeds=[manifest["seed"]],
        dataset=args.csv.name,
        data_path=args.csv,
        settings={
            "protocol": PROTOCOL,
            "exploratory": True,
            "label_column": args.label_column,
            "detectors": args.detectors,
            "partition_sha256": _sha256(args.partitions),
            "research_sha256": {name: _sha256(ROOT / name) for name in RESEARCH_SOURCES},
            "torch": _optional_version("torch"),
        },
        outputs=[args.output.name],
    )
    return 1 if result["errors"] or not result["runs"] else 0


def x_main__mutmut_75(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=Path, required=True)
    parser.add_argument("--partitions", type=Path, required=True)
    parser.add_argument("--label-column", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--detectors", nargs="+", required=True)
    args = parser.parse_args(argv)
    record_path = args.output.with_suffix(".record.json")
    if args.output.exists() or record_path.exists():
        raise FileExistsError("choose unused output and record paths")
    manifest = json.loads(args.partitions.read_text())
    if manifest["schema_version"] != 1 or manifest["input_sha256"] != _sha256(args.csv):
        raise ValueError("partition manifest version or source hash differs")
    with args.csv.open(newline="") as stream:
        header = next(csv.reader(None))
    if len(set(header)) != len(header):
        raise ValueError("duplicate CSV column names are not accepted")
    frame = pd.read_csv(args.csv, dtype=str)
    if manifest["row_count"] != len(frame):
        raise ValueError("partition manifest row count differs")
    labels = pd.to_numeric(frame.pop(args.label_column), errors="raise").to_numpy()
    result = evaluate_frozen(
        frame, labels, manifest["partitions"], seed=manifest["seed"], methods=args.detectors
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    write_record(
        record_path,
        experiment=PROTOCOL,
        seeds=[manifest["seed"]],
        dataset=args.csv.name,
        data_path=args.csv,
        settings={
            "protocol": PROTOCOL,
            "exploratory": True,
            "label_column": args.label_column,
            "detectors": args.detectors,
            "partition_sha256": _sha256(args.partitions),
            "research_sha256": {name: _sha256(ROOT / name) for name in RESEARCH_SOURCES},
            "torch": _optional_version("torch"),
        },
        outputs=[args.output.name],
    )
    return 1 if result["errors"] or not result["runs"] else 0


def x_main__mutmut_76(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=Path, required=True)
    parser.add_argument("--partitions", type=Path, required=True)
    parser.add_argument("--label-column", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--detectors", nargs="+", required=True)
    args = parser.parse_args(argv)
    record_path = args.output.with_suffix(".record.json")
    if args.output.exists() or record_path.exists():
        raise FileExistsError("choose unused output and record paths")
    manifest = json.loads(args.partitions.read_text())
    if manifest["schema_version"] != 1 or manifest["input_sha256"] != _sha256(args.csv):
        raise ValueError("partition manifest version or source hash differs")
    with args.csv.open(newline="") as stream:
        header = next(csv.reader(stream))
    if len(set(header)) == len(header):
        raise ValueError("duplicate CSV column names are not accepted")
    frame = pd.read_csv(args.csv, dtype=str)
    if manifest["row_count"] != len(frame):
        raise ValueError("partition manifest row count differs")
    labels = pd.to_numeric(frame.pop(args.label_column), errors="raise").to_numpy()
    result = evaluate_frozen(
        frame, labels, manifest["partitions"], seed=manifest["seed"], methods=args.detectors
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    write_record(
        record_path,
        experiment=PROTOCOL,
        seeds=[manifest["seed"]],
        dataset=args.csv.name,
        data_path=args.csv,
        settings={
            "protocol": PROTOCOL,
            "exploratory": True,
            "label_column": args.label_column,
            "detectors": args.detectors,
            "partition_sha256": _sha256(args.partitions),
            "research_sha256": {name: _sha256(ROOT / name) for name in RESEARCH_SOURCES},
            "torch": _optional_version("torch"),
        },
        outputs=[args.output.name],
    )
    return 1 if result["errors"] or not result["runs"] else 0


def x_main__mutmut_77(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=Path, required=True)
    parser.add_argument("--partitions", type=Path, required=True)
    parser.add_argument("--label-column", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--detectors", nargs="+", required=True)
    args = parser.parse_args(argv)
    record_path = args.output.with_suffix(".record.json")
    if args.output.exists() or record_path.exists():
        raise FileExistsError("choose unused output and record paths")
    manifest = json.loads(args.partitions.read_text())
    if manifest["schema_version"] != 1 or manifest["input_sha256"] != _sha256(args.csv):
        raise ValueError("partition manifest version or source hash differs")
    with args.csv.open(newline="") as stream:
        header = next(csv.reader(stream))
    if len(set(header)) != len(header):
        raise ValueError(None)
    frame = pd.read_csv(args.csv, dtype=str)
    if manifest["row_count"] != len(frame):
        raise ValueError("partition manifest row count differs")
    labels = pd.to_numeric(frame.pop(args.label_column), errors="raise").to_numpy()
    result = evaluate_frozen(
        frame, labels, manifest["partitions"], seed=manifest["seed"], methods=args.detectors
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    write_record(
        record_path,
        experiment=PROTOCOL,
        seeds=[manifest["seed"]],
        dataset=args.csv.name,
        data_path=args.csv,
        settings={
            "protocol": PROTOCOL,
            "exploratory": True,
            "label_column": args.label_column,
            "detectors": args.detectors,
            "partition_sha256": _sha256(args.partitions),
            "research_sha256": {name: _sha256(ROOT / name) for name in RESEARCH_SOURCES},
            "torch": _optional_version("torch"),
        },
        outputs=[args.output.name],
    )
    return 1 if result["errors"] or not result["runs"] else 0


def x_main__mutmut_78(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=Path, required=True)
    parser.add_argument("--partitions", type=Path, required=True)
    parser.add_argument("--label-column", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--detectors", nargs="+", required=True)
    args = parser.parse_args(argv)
    record_path = args.output.with_suffix(".record.json")
    if args.output.exists() or record_path.exists():
        raise FileExistsError("choose unused output and record paths")
    manifest = json.loads(args.partitions.read_text())
    if manifest["schema_version"] != 1 or manifest["input_sha256"] != _sha256(args.csv):
        raise ValueError("partition manifest version or source hash differs")
    with args.csv.open(newline="") as stream:
        header = next(csv.reader(stream))
    if len(set(header)) != len(header):
        raise ValueError("XXduplicate CSV column names are not acceptedXX")
    frame = pd.read_csv(args.csv, dtype=str)
    if manifest["row_count"] != len(frame):
        raise ValueError("partition manifest row count differs")
    labels = pd.to_numeric(frame.pop(args.label_column), errors="raise").to_numpy()
    result = evaluate_frozen(
        frame, labels, manifest["partitions"], seed=manifest["seed"], methods=args.detectors
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    write_record(
        record_path,
        experiment=PROTOCOL,
        seeds=[manifest["seed"]],
        dataset=args.csv.name,
        data_path=args.csv,
        settings={
            "protocol": PROTOCOL,
            "exploratory": True,
            "label_column": args.label_column,
            "detectors": args.detectors,
            "partition_sha256": _sha256(args.partitions),
            "research_sha256": {name: _sha256(ROOT / name) for name in RESEARCH_SOURCES},
            "torch": _optional_version("torch"),
        },
        outputs=[args.output.name],
    )
    return 1 if result["errors"] or not result["runs"] else 0


def x_main__mutmut_79(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=Path, required=True)
    parser.add_argument("--partitions", type=Path, required=True)
    parser.add_argument("--label-column", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--detectors", nargs="+", required=True)
    args = parser.parse_args(argv)
    record_path = args.output.with_suffix(".record.json")
    if args.output.exists() or record_path.exists():
        raise FileExistsError("choose unused output and record paths")
    manifest = json.loads(args.partitions.read_text())
    if manifest["schema_version"] != 1 or manifest["input_sha256"] != _sha256(args.csv):
        raise ValueError("partition manifest version or source hash differs")
    with args.csv.open(newline="") as stream:
        header = next(csv.reader(stream))
    if len(set(header)) != len(header):
        raise ValueError("duplicate csv column names are not accepted")
    frame = pd.read_csv(args.csv, dtype=str)
    if manifest["row_count"] != len(frame):
        raise ValueError("partition manifest row count differs")
    labels = pd.to_numeric(frame.pop(args.label_column), errors="raise").to_numpy()
    result = evaluate_frozen(
        frame, labels, manifest["partitions"], seed=manifest["seed"], methods=args.detectors
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    write_record(
        record_path,
        experiment=PROTOCOL,
        seeds=[manifest["seed"]],
        dataset=args.csv.name,
        data_path=args.csv,
        settings={
            "protocol": PROTOCOL,
            "exploratory": True,
            "label_column": args.label_column,
            "detectors": args.detectors,
            "partition_sha256": _sha256(args.partitions),
            "research_sha256": {name: _sha256(ROOT / name) for name in RESEARCH_SOURCES},
            "torch": _optional_version("torch"),
        },
        outputs=[args.output.name],
    )
    return 1 if result["errors"] or not result["runs"] else 0


def x_main__mutmut_80(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=Path, required=True)
    parser.add_argument("--partitions", type=Path, required=True)
    parser.add_argument("--label-column", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--detectors", nargs="+", required=True)
    args = parser.parse_args(argv)
    record_path = args.output.with_suffix(".record.json")
    if args.output.exists() or record_path.exists():
        raise FileExistsError("choose unused output and record paths")
    manifest = json.loads(args.partitions.read_text())
    if manifest["schema_version"] != 1 or manifest["input_sha256"] != _sha256(args.csv):
        raise ValueError("partition manifest version or source hash differs")
    with args.csv.open(newline="") as stream:
        header = next(csv.reader(stream))
    if len(set(header)) != len(header):
        raise ValueError("DUPLICATE CSV COLUMN NAMES ARE NOT ACCEPTED")
    frame = pd.read_csv(args.csv, dtype=str)
    if manifest["row_count"] != len(frame):
        raise ValueError("partition manifest row count differs")
    labels = pd.to_numeric(frame.pop(args.label_column), errors="raise").to_numpy()
    result = evaluate_frozen(
        frame, labels, manifest["partitions"], seed=manifest["seed"], methods=args.detectors
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    write_record(
        record_path,
        experiment=PROTOCOL,
        seeds=[manifest["seed"]],
        dataset=args.csv.name,
        data_path=args.csv,
        settings={
            "protocol": PROTOCOL,
            "exploratory": True,
            "label_column": args.label_column,
            "detectors": args.detectors,
            "partition_sha256": _sha256(args.partitions),
            "research_sha256": {name: _sha256(ROOT / name) for name in RESEARCH_SOURCES},
            "torch": _optional_version("torch"),
        },
        outputs=[args.output.name],
    )
    return 1 if result["errors"] or not result["runs"] else 0


def x_main__mutmut_81(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=Path, required=True)
    parser.add_argument("--partitions", type=Path, required=True)
    parser.add_argument("--label-column", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--detectors", nargs="+", required=True)
    args = parser.parse_args(argv)
    record_path = args.output.with_suffix(".record.json")
    if args.output.exists() or record_path.exists():
        raise FileExistsError("choose unused output and record paths")
    manifest = json.loads(args.partitions.read_text())
    if manifest["schema_version"] != 1 or manifest["input_sha256"] != _sha256(args.csv):
        raise ValueError("partition manifest version or source hash differs")
    with args.csv.open(newline="") as stream:
        header = next(csv.reader(stream))
    if len(set(header)) != len(header):
        raise ValueError("duplicate CSV column names are not accepted")
    frame = None
    if manifest["row_count"] != len(frame):
        raise ValueError("partition manifest row count differs")
    labels = pd.to_numeric(frame.pop(args.label_column), errors="raise").to_numpy()
    result = evaluate_frozen(
        frame, labels, manifest["partitions"], seed=manifest["seed"], methods=args.detectors
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    write_record(
        record_path,
        experiment=PROTOCOL,
        seeds=[manifest["seed"]],
        dataset=args.csv.name,
        data_path=args.csv,
        settings={
            "protocol": PROTOCOL,
            "exploratory": True,
            "label_column": args.label_column,
            "detectors": args.detectors,
            "partition_sha256": _sha256(args.partitions),
            "research_sha256": {name: _sha256(ROOT / name) for name in RESEARCH_SOURCES},
            "torch": _optional_version("torch"),
        },
        outputs=[args.output.name],
    )
    return 1 if result["errors"] or not result["runs"] else 0


def x_main__mutmut_82(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=Path, required=True)
    parser.add_argument("--partitions", type=Path, required=True)
    parser.add_argument("--label-column", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--detectors", nargs="+", required=True)
    args = parser.parse_args(argv)
    record_path = args.output.with_suffix(".record.json")
    if args.output.exists() or record_path.exists():
        raise FileExistsError("choose unused output and record paths")
    manifest = json.loads(args.partitions.read_text())
    if manifest["schema_version"] != 1 or manifest["input_sha256"] != _sha256(args.csv):
        raise ValueError("partition manifest version or source hash differs")
    with args.csv.open(newline="") as stream:
        header = next(csv.reader(stream))
    if len(set(header)) != len(header):
        raise ValueError("duplicate CSV column names are not accepted")
    frame = pd.read_csv(None, dtype=str)
    if manifest["row_count"] != len(frame):
        raise ValueError("partition manifest row count differs")
    labels = pd.to_numeric(frame.pop(args.label_column), errors="raise").to_numpy()
    result = evaluate_frozen(
        frame, labels, manifest["partitions"], seed=manifest["seed"], methods=args.detectors
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    write_record(
        record_path,
        experiment=PROTOCOL,
        seeds=[manifest["seed"]],
        dataset=args.csv.name,
        data_path=args.csv,
        settings={
            "protocol": PROTOCOL,
            "exploratory": True,
            "label_column": args.label_column,
            "detectors": args.detectors,
            "partition_sha256": _sha256(args.partitions),
            "research_sha256": {name: _sha256(ROOT / name) for name in RESEARCH_SOURCES},
            "torch": _optional_version("torch"),
        },
        outputs=[args.output.name],
    )
    return 1 if result["errors"] or not result["runs"] else 0


def x_main__mutmut_83(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=Path, required=True)
    parser.add_argument("--partitions", type=Path, required=True)
    parser.add_argument("--label-column", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--detectors", nargs="+", required=True)
    args = parser.parse_args(argv)
    record_path = args.output.with_suffix(".record.json")
    if args.output.exists() or record_path.exists():
        raise FileExistsError("choose unused output and record paths")
    manifest = json.loads(args.partitions.read_text())
    if manifest["schema_version"] != 1 or manifest["input_sha256"] != _sha256(args.csv):
        raise ValueError("partition manifest version or source hash differs")
    with args.csv.open(newline="") as stream:
        header = next(csv.reader(stream))
    if len(set(header)) != len(header):
        raise ValueError("duplicate CSV column names are not accepted")
    frame = pd.read_csv(args.csv, dtype=None)
    if manifest["row_count"] != len(frame):
        raise ValueError("partition manifest row count differs")
    labels = pd.to_numeric(frame.pop(args.label_column), errors="raise").to_numpy()
    result = evaluate_frozen(
        frame, labels, manifest["partitions"], seed=manifest["seed"], methods=args.detectors
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    write_record(
        record_path,
        experiment=PROTOCOL,
        seeds=[manifest["seed"]],
        dataset=args.csv.name,
        data_path=args.csv,
        settings={
            "protocol": PROTOCOL,
            "exploratory": True,
            "label_column": args.label_column,
            "detectors": args.detectors,
            "partition_sha256": _sha256(args.partitions),
            "research_sha256": {name: _sha256(ROOT / name) for name in RESEARCH_SOURCES},
            "torch": _optional_version("torch"),
        },
        outputs=[args.output.name],
    )
    return 1 if result["errors"] or not result["runs"] else 0


def x_main__mutmut_84(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=Path, required=True)
    parser.add_argument("--partitions", type=Path, required=True)
    parser.add_argument("--label-column", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--detectors", nargs="+", required=True)
    args = parser.parse_args(argv)
    record_path = args.output.with_suffix(".record.json")
    if args.output.exists() or record_path.exists():
        raise FileExistsError("choose unused output and record paths")
    manifest = json.loads(args.partitions.read_text())
    if manifest["schema_version"] != 1 or manifest["input_sha256"] != _sha256(args.csv):
        raise ValueError("partition manifest version or source hash differs")
    with args.csv.open(newline="") as stream:
        header = next(csv.reader(stream))
    if len(set(header)) != len(header):
        raise ValueError("duplicate CSV column names are not accepted")
    frame = pd.read_csv(dtype=str)
    if manifest["row_count"] != len(frame):
        raise ValueError("partition manifest row count differs")
    labels = pd.to_numeric(frame.pop(args.label_column), errors="raise").to_numpy()
    result = evaluate_frozen(
        frame, labels, manifest["partitions"], seed=manifest["seed"], methods=args.detectors
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    write_record(
        record_path,
        experiment=PROTOCOL,
        seeds=[manifest["seed"]],
        dataset=args.csv.name,
        data_path=args.csv,
        settings={
            "protocol": PROTOCOL,
            "exploratory": True,
            "label_column": args.label_column,
            "detectors": args.detectors,
            "partition_sha256": _sha256(args.partitions),
            "research_sha256": {name: _sha256(ROOT / name) for name in RESEARCH_SOURCES},
            "torch": _optional_version("torch"),
        },
        outputs=[args.output.name],
    )
    return 1 if result["errors"] or not result["runs"] else 0


def x_main__mutmut_85(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=Path, required=True)
    parser.add_argument("--partitions", type=Path, required=True)
    parser.add_argument("--label-column", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--detectors", nargs="+", required=True)
    args = parser.parse_args(argv)
    record_path = args.output.with_suffix(".record.json")
    if args.output.exists() or record_path.exists():
        raise FileExistsError("choose unused output and record paths")
    manifest = json.loads(args.partitions.read_text())
    if manifest["schema_version"] != 1 or manifest["input_sha256"] != _sha256(args.csv):
        raise ValueError("partition manifest version or source hash differs")
    with args.csv.open(newline="") as stream:
        header = next(csv.reader(stream))
    if len(set(header)) != len(header):
        raise ValueError("duplicate CSV column names are not accepted")
    frame = pd.read_csv(args.csv, )
    if manifest["row_count"] != len(frame):
        raise ValueError("partition manifest row count differs")
    labels = pd.to_numeric(frame.pop(args.label_column), errors="raise").to_numpy()
    result = evaluate_frozen(
        frame, labels, manifest["partitions"], seed=manifest["seed"], methods=args.detectors
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    write_record(
        record_path,
        experiment=PROTOCOL,
        seeds=[manifest["seed"]],
        dataset=args.csv.name,
        data_path=args.csv,
        settings={
            "protocol": PROTOCOL,
            "exploratory": True,
            "label_column": args.label_column,
            "detectors": args.detectors,
            "partition_sha256": _sha256(args.partitions),
            "research_sha256": {name: _sha256(ROOT / name) for name in RESEARCH_SOURCES},
            "torch": _optional_version("torch"),
        },
        outputs=[args.output.name],
    )
    return 1 if result["errors"] or not result["runs"] else 0


def x_main__mutmut_86(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=Path, required=True)
    parser.add_argument("--partitions", type=Path, required=True)
    parser.add_argument("--label-column", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--detectors", nargs="+", required=True)
    args = parser.parse_args(argv)
    record_path = args.output.with_suffix(".record.json")
    if args.output.exists() or record_path.exists():
        raise FileExistsError("choose unused output and record paths")
    manifest = json.loads(args.partitions.read_text())
    if manifest["schema_version"] != 1 or manifest["input_sha256"] != _sha256(args.csv):
        raise ValueError("partition manifest version or source hash differs")
    with args.csv.open(newline="") as stream:
        header = next(csv.reader(stream))
    if len(set(header)) != len(header):
        raise ValueError("duplicate CSV column names are not accepted")
    frame = pd.read_csv(args.csv, dtype=str)
    if manifest["XXrow_countXX"] != len(frame):
        raise ValueError("partition manifest row count differs")
    labels = pd.to_numeric(frame.pop(args.label_column), errors="raise").to_numpy()
    result = evaluate_frozen(
        frame, labels, manifest["partitions"], seed=manifest["seed"], methods=args.detectors
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    write_record(
        record_path,
        experiment=PROTOCOL,
        seeds=[manifest["seed"]],
        dataset=args.csv.name,
        data_path=args.csv,
        settings={
            "protocol": PROTOCOL,
            "exploratory": True,
            "label_column": args.label_column,
            "detectors": args.detectors,
            "partition_sha256": _sha256(args.partitions),
            "research_sha256": {name: _sha256(ROOT / name) for name in RESEARCH_SOURCES},
            "torch": _optional_version("torch"),
        },
        outputs=[args.output.name],
    )
    return 1 if result["errors"] or not result["runs"] else 0


def x_main__mutmut_87(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=Path, required=True)
    parser.add_argument("--partitions", type=Path, required=True)
    parser.add_argument("--label-column", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--detectors", nargs="+", required=True)
    args = parser.parse_args(argv)
    record_path = args.output.with_suffix(".record.json")
    if args.output.exists() or record_path.exists():
        raise FileExistsError("choose unused output and record paths")
    manifest = json.loads(args.partitions.read_text())
    if manifest["schema_version"] != 1 or manifest["input_sha256"] != _sha256(args.csv):
        raise ValueError("partition manifest version or source hash differs")
    with args.csv.open(newline="") as stream:
        header = next(csv.reader(stream))
    if len(set(header)) != len(header):
        raise ValueError("duplicate CSV column names are not accepted")
    frame = pd.read_csv(args.csv, dtype=str)
    if manifest["ROW_COUNT"] != len(frame):
        raise ValueError("partition manifest row count differs")
    labels = pd.to_numeric(frame.pop(args.label_column), errors="raise").to_numpy()
    result = evaluate_frozen(
        frame, labels, manifest["partitions"], seed=manifest["seed"], methods=args.detectors
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    write_record(
        record_path,
        experiment=PROTOCOL,
        seeds=[manifest["seed"]],
        dataset=args.csv.name,
        data_path=args.csv,
        settings={
            "protocol": PROTOCOL,
            "exploratory": True,
            "label_column": args.label_column,
            "detectors": args.detectors,
            "partition_sha256": _sha256(args.partitions),
            "research_sha256": {name: _sha256(ROOT / name) for name in RESEARCH_SOURCES},
            "torch": _optional_version("torch"),
        },
        outputs=[args.output.name],
    )
    return 1 if result["errors"] or not result["runs"] else 0


def x_main__mutmut_88(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=Path, required=True)
    parser.add_argument("--partitions", type=Path, required=True)
    parser.add_argument("--label-column", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--detectors", nargs="+", required=True)
    args = parser.parse_args(argv)
    record_path = args.output.with_suffix(".record.json")
    if args.output.exists() or record_path.exists():
        raise FileExistsError("choose unused output and record paths")
    manifest = json.loads(args.partitions.read_text())
    if manifest["schema_version"] != 1 or manifest["input_sha256"] != _sha256(args.csv):
        raise ValueError("partition manifest version or source hash differs")
    with args.csv.open(newline="") as stream:
        header = next(csv.reader(stream))
    if len(set(header)) != len(header):
        raise ValueError("duplicate CSV column names are not accepted")
    frame = pd.read_csv(args.csv, dtype=str)
    if manifest["row_count"] == len(frame):
        raise ValueError("partition manifest row count differs")
    labels = pd.to_numeric(frame.pop(args.label_column), errors="raise").to_numpy()
    result = evaluate_frozen(
        frame, labels, manifest["partitions"], seed=manifest["seed"], methods=args.detectors
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    write_record(
        record_path,
        experiment=PROTOCOL,
        seeds=[manifest["seed"]],
        dataset=args.csv.name,
        data_path=args.csv,
        settings={
            "protocol": PROTOCOL,
            "exploratory": True,
            "label_column": args.label_column,
            "detectors": args.detectors,
            "partition_sha256": _sha256(args.partitions),
            "research_sha256": {name: _sha256(ROOT / name) for name in RESEARCH_SOURCES},
            "torch": _optional_version("torch"),
        },
        outputs=[args.output.name],
    )
    return 1 if result["errors"] or not result["runs"] else 0


def x_main__mutmut_89(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=Path, required=True)
    parser.add_argument("--partitions", type=Path, required=True)
    parser.add_argument("--label-column", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--detectors", nargs="+", required=True)
    args = parser.parse_args(argv)
    record_path = args.output.with_suffix(".record.json")
    if args.output.exists() or record_path.exists():
        raise FileExistsError("choose unused output and record paths")
    manifest = json.loads(args.partitions.read_text())
    if manifest["schema_version"] != 1 or manifest["input_sha256"] != _sha256(args.csv):
        raise ValueError("partition manifest version or source hash differs")
    with args.csv.open(newline="") as stream:
        header = next(csv.reader(stream))
    if len(set(header)) != len(header):
        raise ValueError("duplicate CSV column names are not accepted")
    frame = pd.read_csv(args.csv, dtype=str)
    if manifest["row_count"] != len(frame):
        raise ValueError(None)
    labels = pd.to_numeric(frame.pop(args.label_column), errors="raise").to_numpy()
    result = evaluate_frozen(
        frame, labels, manifest["partitions"], seed=manifest["seed"], methods=args.detectors
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    write_record(
        record_path,
        experiment=PROTOCOL,
        seeds=[manifest["seed"]],
        dataset=args.csv.name,
        data_path=args.csv,
        settings={
            "protocol": PROTOCOL,
            "exploratory": True,
            "label_column": args.label_column,
            "detectors": args.detectors,
            "partition_sha256": _sha256(args.partitions),
            "research_sha256": {name: _sha256(ROOT / name) for name in RESEARCH_SOURCES},
            "torch": _optional_version("torch"),
        },
        outputs=[args.output.name],
    )
    return 1 if result["errors"] or not result["runs"] else 0


def x_main__mutmut_90(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=Path, required=True)
    parser.add_argument("--partitions", type=Path, required=True)
    parser.add_argument("--label-column", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--detectors", nargs="+", required=True)
    args = parser.parse_args(argv)
    record_path = args.output.with_suffix(".record.json")
    if args.output.exists() or record_path.exists():
        raise FileExistsError("choose unused output and record paths")
    manifest = json.loads(args.partitions.read_text())
    if manifest["schema_version"] != 1 or manifest["input_sha256"] != _sha256(args.csv):
        raise ValueError("partition manifest version or source hash differs")
    with args.csv.open(newline="") as stream:
        header = next(csv.reader(stream))
    if len(set(header)) != len(header):
        raise ValueError("duplicate CSV column names are not accepted")
    frame = pd.read_csv(args.csv, dtype=str)
    if manifest["row_count"] != len(frame):
        raise ValueError("XXpartition manifest row count differsXX")
    labels = pd.to_numeric(frame.pop(args.label_column), errors="raise").to_numpy()
    result = evaluate_frozen(
        frame, labels, manifest["partitions"], seed=manifest["seed"], methods=args.detectors
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    write_record(
        record_path,
        experiment=PROTOCOL,
        seeds=[manifest["seed"]],
        dataset=args.csv.name,
        data_path=args.csv,
        settings={
            "protocol": PROTOCOL,
            "exploratory": True,
            "label_column": args.label_column,
            "detectors": args.detectors,
            "partition_sha256": _sha256(args.partitions),
            "research_sha256": {name: _sha256(ROOT / name) for name in RESEARCH_SOURCES},
            "torch": _optional_version("torch"),
        },
        outputs=[args.output.name],
    )
    return 1 if result["errors"] or not result["runs"] else 0


def x_main__mutmut_91(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=Path, required=True)
    parser.add_argument("--partitions", type=Path, required=True)
    parser.add_argument("--label-column", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--detectors", nargs="+", required=True)
    args = parser.parse_args(argv)
    record_path = args.output.with_suffix(".record.json")
    if args.output.exists() or record_path.exists():
        raise FileExistsError("choose unused output and record paths")
    manifest = json.loads(args.partitions.read_text())
    if manifest["schema_version"] != 1 or manifest["input_sha256"] != _sha256(args.csv):
        raise ValueError("partition manifest version or source hash differs")
    with args.csv.open(newline="") as stream:
        header = next(csv.reader(stream))
    if len(set(header)) != len(header):
        raise ValueError("duplicate CSV column names are not accepted")
    frame = pd.read_csv(args.csv, dtype=str)
    if manifest["row_count"] != len(frame):
        raise ValueError("PARTITION MANIFEST ROW COUNT DIFFERS")
    labels = pd.to_numeric(frame.pop(args.label_column), errors="raise").to_numpy()
    result = evaluate_frozen(
        frame, labels, manifest["partitions"], seed=manifest["seed"], methods=args.detectors
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    write_record(
        record_path,
        experiment=PROTOCOL,
        seeds=[manifest["seed"]],
        dataset=args.csv.name,
        data_path=args.csv,
        settings={
            "protocol": PROTOCOL,
            "exploratory": True,
            "label_column": args.label_column,
            "detectors": args.detectors,
            "partition_sha256": _sha256(args.partitions),
            "research_sha256": {name: _sha256(ROOT / name) for name in RESEARCH_SOURCES},
            "torch": _optional_version("torch"),
        },
        outputs=[args.output.name],
    )
    return 1 if result["errors"] or not result["runs"] else 0


def x_main__mutmut_92(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=Path, required=True)
    parser.add_argument("--partitions", type=Path, required=True)
    parser.add_argument("--label-column", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--detectors", nargs="+", required=True)
    args = parser.parse_args(argv)
    record_path = args.output.with_suffix(".record.json")
    if args.output.exists() or record_path.exists():
        raise FileExistsError("choose unused output and record paths")
    manifest = json.loads(args.partitions.read_text())
    if manifest["schema_version"] != 1 or manifest["input_sha256"] != _sha256(args.csv):
        raise ValueError("partition manifest version or source hash differs")
    with args.csv.open(newline="") as stream:
        header = next(csv.reader(stream))
    if len(set(header)) != len(header):
        raise ValueError("duplicate CSV column names are not accepted")
    frame = pd.read_csv(args.csv, dtype=str)
    if manifest["row_count"] != len(frame):
        raise ValueError("partition manifest row count differs")
    labels = None
    result = evaluate_frozen(
        frame, labels, manifest["partitions"], seed=manifest["seed"], methods=args.detectors
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    write_record(
        record_path,
        experiment=PROTOCOL,
        seeds=[manifest["seed"]],
        dataset=args.csv.name,
        data_path=args.csv,
        settings={
            "protocol": PROTOCOL,
            "exploratory": True,
            "label_column": args.label_column,
            "detectors": args.detectors,
            "partition_sha256": _sha256(args.partitions),
            "research_sha256": {name: _sha256(ROOT / name) for name in RESEARCH_SOURCES},
            "torch": _optional_version("torch"),
        },
        outputs=[args.output.name],
    )
    return 1 if result["errors"] or not result["runs"] else 0


def x_main__mutmut_93(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=Path, required=True)
    parser.add_argument("--partitions", type=Path, required=True)
    parser.add_argument("--label-column", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--detectors", nargs="+", required=True)
    args = parser.parse_args(argv)
    record_path = args.output.with_suffix(".record.json")
    if args.output.exists() or record_path.exists():
        raise FileExistsError("choose unused output and record paths")
    manifest = json.loads(args.partitions.read_text())
    if manifest["schema_version"] != 1 or manifest["input_sha256"] != _sha256(args.csv):
        raise ValueError("partition manifest version or source hash differs")
    with args.csv.open(newline="") as stream:
        header = next(csv.reader(stream))
    if len(set(header)) != len(header):
        raise ValueError("duplicate CSV column names are not accepted")
    frame = pd.read_csv(args.csv, dtype=str)
    if manifest["row_count"] != len(frame):
        raise ValueError("partition manifest row count differs")
    labels = pd.to_numeric(None, errors="raise").to_numpy()
    result = evaluate_frozen(
        frame, labels, manifest["partitions"], seed=manifest["seed"], methods=args.detectors
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    write_record(
        record_path,
        experiment=PROTOCOL,
        seeds=[manifest["seed"]],
        dataset=args.csv.name,
        data_path=args.csv,
        settings={
            "protocol": PROTOCOL,
            "exploratory": True,
            "label_column": args.label_column,
            "detectors": args.detectors,
            "partition_sha256": _sha256(args.partitions),
            "research_sha256": {name: _sha256(ROOT / name) for name in RESEARCH_SOURCES},
            "torch": _optional_version("torch"),
        },
        outputs=[args.output.name],
    )
    return 1 if result["errors"] or not result["runs"] else 0


def x_main__mutmut_94(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=Path, required=True)
    parser.add_argument("--partitions", type=Path, required=True)
    parser.add_argument("--label-column", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--detectors", nargs="+", required=True)
    args = parser.parse_args(argv)
    record_path = args.output.with_suffix(".record.json")
    if args.output.exists() or record_path.exists():
        raise FileExistsError("choose unused output and record paths")
    manifest = json.loads(args.partitions.read_text())
    if manifest["schema_version"] != 1 or manifest["input_sha256"] != _sha256(args.csv):
        raise ValueError("partition manifest version or source hash differs")
    with args.csv.open(newline="") as stream:
        header = next(csv.reader(stream))
    if len(set(header)) != len(header):
        raise ValueError("duplicate CSV column names are not accepted")
    frame = pd.read_csv(args.csv, dtype=str)
    if manifest["row_count"] != len(frame):
        raise ValueError("partition manifest row count differs")
    labels = pd.to_numeric(frame.pop(args.label_column), errors=None).to_numpy()
    result = evaluate_frozen(
        frame, labels, manifest["partitions"], seed=manifest["seed"], methods=args.detectors
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    write_record(
        record_path,
        experiment=PROTOCOL,
        seeds=[manifest["seed"]],
        dataset=args.csv.name,
        data_path=args.csv,
        settings={
            "protocol": PROTOCOL,
            "exploratory": True,
            "label_column": args.label_column,
            "detectors": args.detectors,
            "partition_sha256": _sha256(args.partitions),
            "research_sha256": {name: _sha256(ROOT / name) for name in RESEARCH_SOURCES},
            "torch": _optional_version("torch"),
        },
        outputs=[args.output.name],
    )
    return 1 if result["errors"] or not result["runs"] else 0


def x_main__mutmut_95(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=Path, required=True)
    parser.add_argument("--partitions", type=Path, required=True)
    parser.add_argument("--label-column", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--detectors", nargs="+", required=True)
    args = parser.parse_args(argv)
    record_path = args.output.with_suffix(".record.json")
    if args.output.exists() or record_path.exists():
        raise FileExistsError("choose unused output and record paths")
    manifest = json.loads(args.partitions.read_text())
    if manifest["schema_version"] != 1 or manifest["input_sha256"] != _sha256(args.csv):
        raise ValueError("partition manifest version or source hash differs")
    with args.csv.open(newline="") as stream:
        header = next(csv.reader(stream))
    if len(set(header)) != len(header):
        raise ValueError("duplicate CSV column names are not accepted")
    frame = pd.read_csv(args.csv, dtype=str)
    if manifest["row_count"] != len(frame):
        raise ValueError("partition manifest row count differs")
    labels = pd.to_numeric(errors="raise").to_numpy()
    result = evaluate_frozen(
        frame, labels, manifest["partitions"], seed=manifest["seed"], methods=args.detectors
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    write_record(
        record_path,
        experiment=PROTOCOL,
        seeds=[manifest["seed"]],
        dataset=args.csv.name,
        data_path=args.csv,
        settings={
            "protocol": PROTOCOL,
            "exploratory": True,
            "label_column": args.label_column,
            "detectors": args.detectors,
            "partition_sha256": _sha256(args.partitions),
            "research_sha256": {name: _sha256(ROOT / name) for name in RESEARCH_SOURCES},
            "torch": _optional_version("torch"),
        },
        outputs=[args.output.name],
    )
    return 1 if result["errors"] or not result["runs"] else 0


def x_main__mutmut_96(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=Path, required=True)
    parser.add_argument("--partitions", type=Path, required=True)
    parser.add_argument("--label-column", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--detectors", nargs="+", required=True)
    args = parser.parse_args(argv)
    record_path = args.output.with_suffix(".record.json")
    if args.output.exists() or record_path.exists():
        raise FileExistsError("choose unused output and record paths")
    manifest = json.loads(args.partitions.read_text())
    if manifest["schema_version"] != 1 or manifest["input_sha256"] != _sha256(args.csv):
        raise ValueError("partition manifest version or source hash differs")
    with args.csv.open(newline="") as stream:
        header = next(csv.reader(stream))
    if len(set(header)) != len(header):
        raise ValueError("duplicate CSV column names are not accepted")
    frame = pd.read_csv(args.csv, dtype=str)
    if manifest["row_count"] != len(frame):
        raise ValueError("partition manifest row count differs")
    labels = pd.to_numeric(frame.pop(args.label_column), ).to_numpy()
    result = evaluate_frozen(
        frame, labels, manifest["partitions"], seed=manifest["seed"], methods=args.detectors
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    write_record(
        record_path,
        experiment=PROTOCOL,
        seeds=[manifest["seed"]],
        dataset=args.csv.name,
        data_path=args.csv,
        settings={
            "protocol": PROTOCOL,
            "exploratory": True,
            "label_column": args.label_column,
            "detectors": args.detectors,
            "partition_sha256": _sha256(args.partitions),
            "research_sha256": {name: _sha256(ROOT / name) for name in RESEARCH_SOURCES},
            "torch": _optional_version("torch"),
        },
        outputs=[args.output.name],
    )
    return 1 if result["errors"] or not result["runs"] else 0


def x_main__mutmut_97(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=Path, required=True)
    parser.add_argument("--partitions", type=Path, required=True)
    parser.add_argument("--label-column", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--detectors", nargs="+", required=True)
    args = parser.parse_args(argv)
    record_path = args.output.with_suffix(".record.json")
    if args.output.exists() or record_path.exists():
        raise FileExistsError("choose unused output and record paths")
    manifest = json.loads(args.partitions.read_text())
    if manifest["schema_version"] != 1 or manifest["input_sha256"] != _sha256(args.csv):
        raise ValueError("partition manifest version or source hash differs")
    with args.csv.open(newline="") as stream:
        header = next(csv.reader(stream))
    if len(set(header)) != len(header):
        raise ValueError("duplicate CSV column names are not accepted")
    frame = pd.read_csv(args.csv, dtype=str)
    if manifest["row_count"] != len(frame):
        raise ValueError("partition manifest row count differs")
    labels = pd.to_numeric(frame.pop(None), errors="raise").to_numpy()
    result = evaluate_frozen(
        frame, labels, manifest["partitions"], seed=manifest["seed"], methods=args.detectors
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    write_record(
        record_path,
        experiment=PROTOCOL,
        seeds=[manifest["seed"]],
        dataset=args.csv.name,
        data_path=args.csv,
        settings={
            "protocol": PROTOCOL,
            "exploratory": True,
            "label_column": args.label_column,
            "detectors": args.detectors,
            "partition_sha256": _sha256(args.partitions),
            "research_sha256": {name: _sha256(ROOT / name) for name in RESEARCH_SOURCES},
            "torch": _optional_version("torch"),
        },
        outputs=[args.output.name],
    )
    return 1 if result["errors"] or not result["runs"] else 0


def x_main__mutmut_98(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=Path, required=True)
    parser.add_argument("--partitions", type=Path, required=True)
    parser.add_argument("--label-column", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--detectors", nargs="+", required=True)
    args = parser.parse_args(argv)
    record_path = args.output.with_suffix(".record.json")
    if args.output.exists() or record_path.exists():
        raise FileExistsError("choose unused output and record paths")
    manifest = json.loads(args.partitions.read_text())
    if manifest["schema_version"] != 1 or manifest["input_sha256"] != _sha256(args.csv):
        raise ValueError("partition manifest version or source hash differs")
    with args.csv.open(newline="") as stream:
        header = next(csv.reader(stream))
    if len(set(header)) != len(header):
        raise ValueError("duplicate CSV column names are not accepted")
    frame = pd.read_csv(args.csv, dtype=str)
    if manifest["row_count"] != len(frame):
        raise ValueError("partition manifest row count differs")
    labels = pd.to_numeric(frame.pop(args.label_column), errors="XXraiseXX").to_numpy()
    result = evaluate_frozen(
        frame, labels, manifest["partitions"], seed=manifest["seed"], methods=args.detectors
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    write_record(
        record_path,
        experiment=PROTOCOL,
        seeds=[manifest["seed"]],
        dataset=args.csv.name,
        data_path=args.csv,
        settings={
            "protocol": PROTOCOL,
            "exploratory": True,
            "label_column": args.label_column,
            "detectors": args.detectors,
            "partition_sha256": _sha256(args.partitions),
            "research_sha256": {name: _sha256(ROOT / name) for name in RESEARCH_SOURCES},
            "torch": _optional_version("torch"),
        },
        outputs=[args.output.name],
    )
    return 1 if result["errors"] or not result["runs"] else 0


def x_main__mutmut_99(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=Path, required=True)
    parser.add_argument("--partitions", type=Path, required=True)
    parser.add_argument("--label-column", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--detectors", nargs="+", required=True)
    args = parser.parse_args(argv)
    record_path = args.output.with_suffix(".record.json")
    if args.output.exists() or record_path.exists():
        raise FileExistsError("choose unused output and record paths")
    manifest = json.loads(args.partitions.read_text())
    if manifest["schema_version"] != 1 or manifest["input_sha256"] != _sha256(args.csv):
        raise ValueError("partition manifest version or source hash differs")
    with args.csv.open(newline="") as stream:
        header = next(csv.reader(stream))
    if len(set(header)) != len(header):
        raise ValueError("duplicate CSV column names are not accepted")
    frame = pd.read_csv(args.csv, dtype=str)
    if manifest["row_count"] != len(frame):
        raise ValueError("partition manifest row count differs")
    labels = pd.to_numeric(frame.pop(args.label_column), errors="RAISE").to_numpy()
    result = evaluate_frozen(
        frame, labels, manifest["partitions"], seed=manifest["seed"], methods=args.detectors
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    write_record(
        record_path,
        experiment=PROTOCOL,
        seeds=[manifest["seed"]],
        dataset=args.csv.name,
        data_path=args.csv,
        settings={
            "protocol": PROTOCOL,
            "exploratory": True,
            "label_column": args.label_column,
            "detectors": args.detectors,
            "partition_sha256": _sha256(args.partitions),
            "research_sha256": {name: _sha256(ROOT / name) for name in RESEARCH_SOURCES},
            "torch": _optional_version("torch"),
        },
        outputs=[args.output.name],
    )
    return 1 if result["errors"] or not result["runs"] else 0


def x_main__mutmut_100(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=Path, required=True)
    parser.add_argument("--partitions", type=Path, required=True)
    parser.add_argument("--label-column", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--detectors", nargs="+", required=True)
    args = parser.parse_args(argv)
    record_path = args.output.with_suffix(".record.json")
    if args.output.exists() or record_path.exists():
        raise FileExistsError("choose unused output and record paths")
    manifest = json.loads(args.partitions.read_text())
    if manifest["schema_version"] != 1 or manifest["input_sha256"] != _sha256(args.csv):
        raise ValueError("partition manifest version or source hash differs")
    with args.csv.open(newline="") as stream:
        header = next(csv.reader(stream))
    if len(set(header)) != len(header):
        raise ValueError("duplicate CSV column names are not accepted")
    frame = pd.read_csv(args.csv, dtype=str)
    if manifest["row_count"] != len(frame):
        raise ValueError("partition manifest row count differs")
    labels = pd.to_numeric(frame.pop(args.label_column), errors="raise").to_numpy()
    result = None
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    write_record(
        record_path,
        experiment=PROTOCOL,
        seeds=[manifest["seed"]],
        dataset=args.csv.name,
        data_path=args.csv,
        settings={
            "protocol": PROTOCOL,
            "exploratory": True,
            "label_column": args.label_column,
            "detectors": args.detectors,
            "partition_sha256": _sha256(args.partitions),
            "research_sha256": {name: _sha256(ROOT / name) for name in RESEARCH_SOURCES},
            "torch": _optional_version("torch"),
        },
        outputs=[args.output.name],
    )
    return 1 if result["errors"] or not result["runs"] else 0


def x_main__mutmut_101(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=Path, required=True)
    parser.add_argument("--partitions", type=Path, required=True)
    parser.add_argument("--label-column", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--detectors", nargs="+", required=True)
    args = parser.parse_args(argv)
    record_path = args.output.with_suffix(".record.json")
    if args.output.exists() or record_path.exists():
        raise FileExistsError("choose unused output and record paths")
    manifest = json.loads(args.partitions.read_text())
    if manifest["schema_version"] != 1 or manifest["input_sha256"] != _sha256(args.csv):
        raise ValueError("partition manifest version or source hash differs")
    with args.csv.open(newline="") as stream:
        header = next(csv.reader(stream))
    if len(set(header)) != len(header):
        raise ValueError("duplicate CSV column names are not accepted")
    frame = pd.read_csv(args.csv, dtype=str)
    if manifest["row_count"] != len(frame):
        raise ValueError("partition manifest row count differs")
    labels = pd.to_numeric(frame.pop(args.label_column), errors="raise").to_numpy()
    result = evaluate_frozen(
        None, labels, manifest["partitions"], seed=manifest["seed"], methods=args.detectors
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    write_record(
        record_path,
        experiment=PROTOCOL,
        seeds=[manifest["seed"]],
        dataset=args.csv.name,
        data_path=args.csv,
        settings={
            "protocol": PROTOCOL,
            "exploratory": True,
            "label_column": args.label_column,
            "detectors": args.detectors,
            "partition_sha256": _sha256(args.partitions),
            "research_sha256": {name: _sha256(ROOT / name) for name in RESEARCH_SOURCES},
            "torch": _optional_version("torch"),
        },
        outputs=[args.output.name],
    )
    return 1 if result["errors"] or not result["runs"] else 0


def x_main__mutmut_102(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=Path, required=True)
    parser.add_argument("--partitions", type=Path, required=True)
    parser.add_argument("--label-column", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--detectors", nargs="+", required=True)
    args = parser.parse_args(argv)
    record_path = args.output.with_suffix(".record.json")
    if args.output.exists() or record_path.exists():
        raise FileExistsError("choose unused output and record paths")
    manifest = json.loads(args.partitions.read_text())
    if manifest["schema_version"] != 1 or manifest["input_sha256"] != _sha256(args.csv):
        raise ValueError("partition manifest version or source hash differs")
    with args.csv.open(newline="") as stream:
        header = next(csv.reader(stream))
    if len(set(header)) != len(header):
        raise ValueError("duplicate CSV column names are not accepted")
    frame = pd.read_csv(args.csv, dtype=str)
    if manifest["row_count"] != len(frame):
        raise ValueError("partition manifest row count differs")
    labels = pd.to_numeric(frame.pop(args.label_column), errors="raise").to_numpy()
    result = evaluate_frozen(
        frame, None, manifest["partitions"], seed=manifest["seed"], methods=args.detectors
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    write_record(
        record_path,
        experiment=PROTOCOL,
        seeds=[manifest["seed"]],
        dataset=args.csv.name,
        data_path=args.csv,
        settings={
            "protocol": PROTOCOL,
            "exploratory": True,
            "label_column": args.label_column,
            "detectors": args.detectors,
            "partition_sha256": _sha256(args.partitions),
            "research_sha256": {name: _sha256(ROOT / name) for name in RESEARCH_SOURCES},
            "torch": _optional_version("torch"),
        },
        outputs=[args.output.name],
    )
    return 1 if result["errors"] or not result["runs"] else 0


def x_main__mutmut_103(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=Path, required=True)
    parser.add_argument("--partitions", type=Path, required=True)
    parser.add_argument("--label-column", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--detectors", nargs="+", required=True)
    args = parser.parse_args(argv)
    record_path = args.output.with_suffix(".record.json")
    if args.output.exists() or record_path.exists():
        raise FileExistsError("choose unused output and record paths")
    manifest = json.loads(args.partitions.read_text())
    if manifest["schema_version"] != 1 or manifest["input_sha256"] != _sha256(args.csv):
        raise ValueError("partition manifest version or source hash differs")
    with args.csv.open(newline="") as stream:
        header = next(csv.reader(stream))
    if len(set(header)) != len(header):
        raise ValueError("duplicate CSV column names are not accepted")
    frame = pd.read_csv(args.csv, dtype=str)
    if manifest["row_count"] != len(frame):
        raise ValueError("partition manifest row count differs")
    labels = pd.to_numeric(frame.pop(args.label_column), errors="raise").to_numpy()
    result = evaluate_frozen(
        frame, labels, None, seed=manifest["seed"], methods=args.detectors
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    write_record(
        record_path,
        experiment=PROTOCOL,
        seeds=[manifest["seed"]],
        dataset=args.csv.name,
        data_path=args.csv,
        settings={
            "protocol": PROTOCOL,
            "exploratory": True,
            "label_column": args.label_column,
            "detectors": args.detectors,
            "partition_sha256": _sha256(args.partitions),
            "research_sha256": {name: _sha256(ROOT / name) for name in RESEARCH_SOURCES},
            "torch": _optional_version("torch"),
        },
        outputs=[args.output.name],
    )
    return 1 if result["errors"] or not result["runs"] else 0


def x_main__mutmut_104(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=Path, required=True)
    parser.add_argument("--partitions", type=Path, required=True)
    parser.add_argument("--label-column", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--detectors", nargs="+", required=True)
    args = parser.parse_args(argv)
    record_path = args.output.with_suffix(".record.json")
    if args.output.exists() or record_path.exists():
        raise FileExistsError("choose unused output and record paths")
    manifest = json.loads(args.partitions.read_text())
    if manifest["schema_version"] != 1 or manifest["input_sha256"] != _sha256(args.csv):
        raise ValueError("partition manifest version or source hash differs")
    with args.csv.open(newline="") as stream:
        header = next(csv.reader(stream))
    if len(set(header)) != len(header):
        raise ValueError("duplicate CSV column names are not accepted")
    frame = pd.read_csv(args.csv, dtype=str)
    if manifest["row_count"] != len(frame):
        raise ValueError("partition manifest row count differs")
    labels = pd.to_numeric(frame.pop(args.label_column), errors="raise").to_numpy()
    result = evaluate_frozen(
        frame, labels, manifest["partitions"], seed=None, methods=args.detectors
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    write_record(
        record_path,
        experiment=PROTOCOL,
        seeds=[manifest["seed"]],
        dataset=args.csv.name,
        data_path=args.csv,
        settings={
            "protocol": PROTOCOL,
            "exploratory": True,
            "label_column": args.label_column,
            "detectors": args.detectors,
            "partition_sha256": _sha256(args.partitions),
            "research_sha256": {name: _sha256(ROOT / name) for name in RESEARCH_SOURCES},
            "torch": _optional_version("torch"),
        },
        outputs=[args.output.name],
    )
    return 1 if result["errors"] or not result["runs"] else 0


def x_main__mutmut_105(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=Path, required=True)
    parser.add_argument("--partitions", type=Path, required=True)
    parser.add_argument("--label-column", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--detectors", nargs="+", required=True)
    args = parser.parse_args(argv)
    record_path = args.output.with_suffix(".record.json")
    if args.output.exists() or record_path.exists():
        raise FileExistsError("choose unused output and record paths")
    manifest = json.loads(args.partitions.read_text())
    if manifest["schema_version"] != 1 or manifest["input_sha256"] != _sha256(args.csv):
        raise ValueError("partition manifest version or source hash differs")
    with args.csv.open(newline="") as stream:
        header = next(csv.reader(stream))
    if len(set(header)) != len(header):
        raise ValueError("duplicate CSV column names are not accepted")
    frame = pd.read_csv(args.csv, dtype=str)
    if manifest["row_count"] != len(frame):
        raise ValueError("partition manifest row count differs")
    labels = pd.to_numeric(frame.pop(args.label_column), errors="raise").to_numpy()
    result = evaluate_frozen(
        frame, labels, manifest["partitions"], seed=manifest["seed"], methods=None
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    write_record(
        record_path,
        experiment=PROTOCOL,
        seeds=[manifest["seed"]],
        dataset=args.csv.name,
        data_path=args.csv,
        settings={
            "protocol": PROTOCOL,
            "exploratory": True,
            "label_column": args.label_column,
            "detectors": args.detectors,
            "partition_sha256": _sha256(args.partitions),
            "research_sha256": {name: _sha256(ROOT / name) for name in RESEARCH_SOURCES},
            "torch": _optional_version("torch"),
        },
        outputs=[args.output.name],
    )
    return 1 if result["errors"] or not result["runs"] else 0


def x_main__mutmut_106(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=Path, required=True)
    parser.add_argument("--partitions", type=Path, required=True)
    parser.add_argument("--label-column", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--detectors", nargs="+", required=True)
    args = parser.parse_args(argv)
    record_path = args.output.with_suffix(".record.json")
    if args.output.exists() or record_path.exists():
        raise FileExistsError("choose unused output and record paths")
    manifest = json.loads(args.partitions.read_text())
    if manifest["schema_version"] != 1 or manifest["input_sha256"] != _sha256(args.csv):
        raise ValueError("partition manifest version or source hash differs")
    with args.csv.open(newline="") as stream:
        header = next(csv.reader(stream))
    if len(set(header)) != len(header):
        raise ValueError("duplicate CSV column names are not accepted")
    frame = pd.read_csv(args.csv, dtype=str)
    if manifest["row_count"] != len(frame):
        raise ValueError("partition manifest row count differs")
    labels = pd.to_numeric(frame.pop(args.label_column), errors="raise").to_numpy()
    result = evaluate_frozen(
        labels, manifest["partitions"], seed=manifest["seed"], methods=args.detectors
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    write_record(
        record_path,
        experiment=PROTOCOL,
        seeds=[manifest["seed"]],
        dataset=args.csv.name,
        data_path=args.csv,
        settings={
            "protocol": PROTOCOL,
            "exploratory": True,
            "label_column": args.label_column,
            "detectors": args.detectors,
            "partition_sha256": _sha256(args.partitions),
            "research_sha256": {name: _sha256(ROOT / name) for name in RESEARCH_SOURCES},
            "torch": _optional_version("torch"),
        },
        outputs=[args.output.name],
    )
    return 1 if result["errors"] or not result["runs"] else 0


def x_main__mutmut_107(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=Path, required=True)
    parser.add_argument("--partitions", type=Path, required=True)
    parser.add_argument("--label-column", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--detectors", nargs="+", required=True)
    args = parser.parse_args(argv)
    record_path = args.output.with_suffix(".record.json")
    if args.output.exists() or record_path.exists():
        raise FileExistsError("choose unused output and record paths")
    manifest = json.loads(args.partitions.read_text())
    if manifest["schema_version"] != 1 or manifest["input_sha256"] != _sha256(args.csv):
        raise ValueError("partition manifest version or source hash differs")
    with args.csv.open(newline="") as stream:
        header = next(csv.reader(stream))
    if len(set(header)) != len(header):
        raise ValueError("duplicate CSV column names are not accepted")
    frame = pd.read_csv(args.csv, dtype=str)
    if manifest["row_count"] != len(frame):
        raise ValueError("partition manifest row count differs")
    labels = pd.to_numeric(frame.pop(args.label_column), errors="raise").to_numpy()
    result = evaluate_frozen(
        frame, manifest["partitions"], seed=manifest["seed"], methods=args.detectors
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    write_record(
        record_path,
        experiment=PROTOCOL,
        seeds=[manifest["seed"]],
        dataset=args.csv.name,
        data_path=args.csv,
        settings={
            "protocol": PROTOCOL,
            "exploratory": True,
            "label_column": args.label_column,
            "detectors": args.detectors,
            "partition_sha256": _sha256(args.partitions),
            "research_sha256": {name: _sha256(ROOT / name) for name in RESEARCH_SOURCES},
            "torch": _optional_version("torch"),
        },
        outputs=[args.output.name],
    )
    return 1 if result["errors"] or not result["runs"] else 0


def x_main__mutmut_108(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=Path, required=True)
    parser.add_argument("--partitions", type=Path, required=True)
    parser.add_argument("--label-column", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--detectors", nargs="+", required=True)
    args = parser.parse_args(argv)
    record_path = args.output.with_suffix(".record.json")
    if args.output.exists() or record_path.exists():
        raise FileExistsError("choose unused output and record paths")
    manifest = json.loads(args.partitions.read_text())
    if manifest["schema_version"] != 1 or manifest["input_sha256"] != _sha256(args.csv):
        raise ValueError("partition manifest version or source hash differs")
    with args.csv.open(newline="") as stream:
        header = next(csv.reader(stream))
    if len(set(header)) != len(header):
        raise ValueError("duplicate CSV column names are not accepted")
    frame = pd.read_csv(args.csv, dtype=str)
    if manifest["row_count"] != len(frame):
        raise ValueError("partition manifest row count differs")
    labels = pd.to_numeric(frame.pop(args.label_column), errors="raise").to_numpy()
    result = evaluate_frozen(
        frame, labels, seed=manifest["seed"], methods=args.detectors
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    write_record(
        record_path,
        experiment=PROTOCOL,
        seeds=[manifest["seed"]],
        dataset=args.csv.name,
        data_path=args.csv,
        settings={
            "protocol": PROTOCOL,
            "exploratory": True,
            "label_column": args.label_column,
            "detectors": args.detectors,
            "partition_sha256": _sha256(args.partitions),
            "research_sha256": {name: _sha256(ROOT / name) for name in RESEARCH_SOURCES},
            "torch": _optional_version("torch"),
        },
        outputs=[args.output.name],
    )
    return 1 if result["errors"] or not result["runs"] else 0


def x_main__mutmut_109(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=Path, required=True)
    parser.add_argument("--partitions", type=Path, required=True)
    parser.add_argument("--label-column", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--detectors", nargs="+", required=True)
    args = parser.parse_args(argv)
    record_path = args.output.with_suffix(".record.json")
    if args.output.exists() or record_path.exists():
        raise FileExistsError("choose unused output and record paths")
    manifest = json.loads(args.partitions.read_text())
    if manifest["schema_version"] != 1 or manifest["input_sha256"] != _sha256(args.csv):
        raise ValueError("partition manifest version or source hash differs")
    with args.csv.open(newline="") as stream:
        header = next(csv.reader(stream))
    if len(set(header)) != len(header):
        raise ValueError("duplicate CSV column names are not accepted")
    frame = pd.read_csv(args.csv, dtype=str)
    if manifest["row_count"] != len(frame):
        raise ValueError("partition manifest row count differs")
    labels = pd.to_numeric(frame.pop(args.label_column), errors="raise").to_numpy()
    result = evaluate_frozen(
        frame, labels, manifest["partitions"], methods=args.detectors
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    write_record(
        record_path,
        experiment=PROTOCOL,
        seeds=[manifest["seed"]],
        dataset=args.csv.name,
        data_path=args.csv,
        settings={
            "protocol": PROTOCOL,
            "exploratory": True,
            "label_column": args.label_column,
            "detectors": args.detectors,
            "partition_sha256": _sha256(args.partitions),
            "research_sha256": {name: _sha256(ROOT / name) for name in RESEARCH_SOURCES},
            "torch": _optional_version("torch"),
        },
        outputs=[args.output.name],
    )
    return 1 if result["errors"] or not result["runs"] else 0


def x_main__mutmut_110(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=Path, required=True)
    parser.add_argument("--partitions", type=Path, required=True)
    parser.add_argument("--label-column", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--detectors", nargs="+", required=True)
    args = parser.parse_args(argv)
    record_path = args.output.with_suffix(".record.json")
    if args.output.exists() or record_path.exists():
        raise FileExistsError("choose unused output and record paths")
    manifest = json.loads(args.partitions.read_text())
    if manifest["schema_version"] != 1 or manifest["input_sha256"] != _sha256(args.csv):
        raise ValueError("partition manifest version or source hash differs")
    with args.csv.open(newline="") as stream:
        header = next(csv.reader(stream))
    if len(set(header)) != len(header):
        raise ValueError("duplicate CSV column names are not accepted")
    frame = pd.read_csv(args.csv, dtype=str)
    if manifest["row_count"] != len(frame):
        raise ValueError("partition manifest row count differs")
    labels = pd.to_numeric(frame.pop(args.label_column), errors="raise").to_numpy()
    result = evaluate_frozen(
        frame, labels, manifest["partitions"], seed=manifest["seed"], )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    write_record(
        record_path,
        experiment=PROTOCOL,
        seeds=[manifest["seed"]],
        dataset=args.csv.name,
        data_path=args.csv,
        settings={
            "protocol": PROTOCOL,
            "exploratory": True,
            "label_column": args.label_column,
            "detectors": args.detectors,
            "partition_sha256": _sha256(args.partitions),
            "research_sha256": {name: _sha256(ROOT / name) for name in RESEARCH_SOURCES},
            "torch": _optional_version("torch"),
        },
        outputs=[args.output.name],
    )
    return 1 if result["errors"] or not result["runs"] else 0


def x_main__mutmut_111(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=Path, required=True)
    parser.add_argument("--partitions", type=Path, required=True)
    parser.add_argument("--label-column", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--detectors", nargs="+", required=True)
    args = parser.parse_args(argv)
    record_path = args.output.with_suffix(".record.json")
    if args.output.exists() or record_path.exists():
        raise FileExistsError("choose unused output and record paths")
    manifest = json.loads(args.partitions.read_text())
    if manifest["schema_version"] != 1 or manifest["input_sha256"] != _sha256(args.csv):
        raise ValueError("partition manifest version or source hash differs")
    with args.csv.open(newline="") as stream:
        header = next(csv.reader(stream))
    if len(set(header)) != len(header):
        raise ValueError("duplicate CSV column names are not accepted")
    frame = pd.read_csv(args.csv, dtype=str)
    if manifest["row_count"] != len(frame):
        raise ValueError("partition manifest row count differs")
    labels = pd.to_numeric(frame.pop(args.label_column), errors="raise").to_numpy()
    result = evaluate_frozen(
        frame, labels, manifest["XXpartitionsXX"], seed=manifest["seed"], methods=args.detectors
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    write_record(
        record_path,
        experiment=PROTOCOL,
        seeds=[manifest["seed"]],
        dataset=args.csv.name,
        data_path=args.csv,
        settings={
            "protocol": PROTOCOL,
            "exploratory": True,
            "label_column": args.label_column,
            "detectors": args.detectors,
            "partition_sha256": _sha256(args.partitions),
            "research_sha256": {name: _sha256(ROOT / name) for name in RESEARCH_SOURCES},
            "torch": _optional_version("torch"),
        },
        outputs=[args.output.name],
    )
    return 1 if result["errors"] or not result["runs"] else 0


def x_main__mutmut_112(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=Path, required=True)
    parser.add_argument("--partitions", type=Path, required=True)
    parser.add_argument("--label-column", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--detectors", nargs="+", required=True)
    args = parser.parse_args(argv)
    record_path = args.output.with_suffix(".record.json")
    if args.output.exists() or record_path.exists():
        raise FileExistsError("choose unused output and record paths")
    manifest = json.loads(args.partitions.read_text())
    if manifest["schema_version"] != 1 or manifest["input_sha256"] != _sha256(args.csv):
        raise ValueError("partition manifest version or source hash differs")
    with args.csv.open(newline="") as stream:
        header = next(csv.reader(stream))
    if len(set(header)) != len(header):
        raise ValueError("duplicate CSV column names are not accepted")
    frame = pd.read_csv(args.csv, dtype=str)
    if manifest["row_count"] != len(frame):
        raise ValueError("partition manifest row count differs")
    labels = pd.to_numeric(frame.pop(args.label_column), errors="raise").to_numpy()
    result = evaluate_frozen(
        frame, labels, manifest["PARTITIONS"], seed=manifest["seed"], methods=args.detectors
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    write_record(
        record_path,
        experiment=PROTOCOL,
        seeds=[manifest["seed"]],
        dataset=args.csv.name,
        data_path=args.csv,
        settings={
            "protocol": PROTOCOL,
            "exploratory": True,
            "label_column": args.label_column,
            "detectors": args.detectors,
            "partition_sha256": _sha256(args.partitions),
            "research_sha256": {name: _sha256(ROOT / name) for name in RESEARCH_SOURCES},
            "torch": _optional_version("torch"),
        },
        outputs=[args.output.name],
    )
    return 1 if result["errors"] or not result["runs"] else 0


def x_main__mutmut_113(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=Path, required=True)
    parser.add_argument("--partitions", type=Path, required=True)
    parser.add_argument("--label-column", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--detectors", nargs="+", required=True)
    args = parser.parse_args(argv)
    record_path = args.output.with_suffix(".record.json")
    if args.output.exists() or record_path.exists():
        raise FileExistsError("choose unused output and record paths")
    manifest = json.loads(args.partitions.read_text())
    if manifest["schema_version"] != 1 or manifest["input_sha256"] != _sha256(args.csv):
        raise ValueError("partition manifest version or source hash differs")
    with args.csv.open(newline="") as stream:
        header = next(csv.reader(stream))
    if len(set(header)) != len(header):
        raise ValueError("duplicate CSV column names are not accepted")
    frame = pd.read_csv(args.csv, dtype=str)
    if manifest["row_count"] != len(frame):
        raise ValueError("partition manifest row count differs")
    labels = pd.to_numeric(frame.pop(args.label_column), errors="raise").to_numpy()
    result = evaluate_frozen(
        frame, labels, manifest["partitions"], seed=manifest["XXseedXX"], methods=args.detectors
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    write_record(
        record_path,
        experiment=PROTOCOL,
        seeds=[manifest["seed"]],
        dataset=args.csv.name,
        data_path=args.csv,
        settings={
            "protocol": PROTOCOL,
            "exploratory": True,
            "label_column": args.label_column,
            "detectors": args.detectors,
            "partition_sha256": _sha256(args.partitions),
            "research_sha256": {name: _sha256(ROOT / name) for name in RESEARCH_SOURCES},
            "torch": _optional_version("torch"),
        },
        outputs=[args.output.name],
    )
    return 1 if result["errors"] or not result["runs"] else 0


def x_main__mutmut_114(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=Path, required=True)
    parser.add_argument("--partitions", type=Path, required=True)
    parser.add_argument("--label-column", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--detectors", nargs="+", required=True)
    args = parser.parse_args(argv)
    record_path = args.output.with_suffix(".record.json")
    if args.output.exists() or record_path.exists():
        raise FileExistsError("choose unused output and record paths")
    manifest = json.loads(args.partitions.read_text())
    if manifest["schema_version"] != 1 or manifest["input_sha256"] != _sha256(args.csv):
        raise ValueError("partition manifest version or source hash differs")
    with args.csv.open(newline="") as stream:
        header = next(csv.reader(stream))
    if len(set(header)) != len(header):
        raise ValueError("duplicate CSV column names are not accepted")
    frame = pd.read_csv(args.csv, dtype=str)
    if manifest["row_count"] != len(frame):
        raise ValueError("partition manifest row count differs")
    labels = pd.to_numeric(frame.pop(args.label_column), errors="raise").to_numpy()
    result = evaluate_frozen(
        frame, labels, manifest["partitions"], seed=manifest["SEED"], methods=args.detectors
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    write_record(
        record_path,
        experiment=PROTOCOL,
        seeds=[manifest["seed"]],
        dataset=args.csv.name,
        data_path=args.csv,
        settings={
            "protocol": PROTOCOL,
            "exploratory": True,
            "label_column": args.label_column,
            "detectors": args.detectors,
            "partition_sha256": _sha256(args.partitions),
            "research_sha256": {name: _sha256(ROOT / name) for name in RESEARCH_SOURCES},
            "torch": _optional_version("torch"),
        },
        outputs=[args.output.name],
    )
    return 1 if result["errors"] or not result["runs"] else 0


def x_main__mutmut_115(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=Path, required=True)
    parser.add_argument("--partitions", type=Path, required=True)
    parser.add_argument("--label-column", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--detectors", nargs="+", required=True)
    args = parser.parse_args(argv)
    record_path = args.output.with_suffix(".record.json")
    if args.output.exists() or record_path.exists():
        raise FileExistsError("choose unused output and record paths")
    manifest = json.loads(args.partitions.read_text())
    if manifest["schema_version"] != 1 or manifest["input_sha256"] != _sha256(args.csv):
        raise ValueError("partition manifest version or source hash differs")
    with args.csv.open(newline="") as stream:
        header = next(csv.reader(stream))
    if len(set(header)) != len(header):
        raise ValueError("duplicate CSV column names are not accepted")
    frame = pd.read_csv(args.csv, dtype=str)
    if manifest["row_count"] != len(frame):
        raise ValueError("partition manifest row count differs")
    labels = pd.to_numeric(frame.pop(args.label_column), errors="raise").to_numpy()
    result = evaluate_frozen(
        frame, labels, manifest["partitions"], seed=manifest["seed"], methods=args.detectors
    )
    args.output.parent.mkdir(parents=None, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    write_record(
        record_path,
        experiment=PROTOCOL,
        seeds=[manifest["seed"]],
        dataset=args.csv.name,
        data_path=args.csv,
        settings={
            "protocol": PROTOCOL,
            "exploratory": True,
            "label_column": args.label_column,
            "detectors": args.detectors,
            "partition_sha256": _sha256(args.partitions),
            "research_sha256": {name: _sha256(ROOT / name) for name in RESEARCH_SOURCES},
            "torch": _optional_version("torch"),
        },
        outputs=[args.output.name],
    )
    return 1 if result["errors"] or not result["runs"] else 0


def x_main__mutmut_116(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=Path, required=True)
    parser.add_argument("--partitions", type=Path, required=True)
    parser.add_argument("--label-column", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--detectors", nargs="+", required=True)
    args = parser.parse_args(argv)
    record_path = args.output.with_suffix(".record.json")
    if args.output.exists() or record_path.exists():
        raise FileExistsError("choose unused output and record paths")
    manifest = json.loads(args.partitions.read_text())
    if manifest["schema_version"] != 1 or manifest["input_sha256"] != _sha256(args.csv):
        raise ValueError("partition manifest version or source hash differs")
    with args.csv.open(newline="") as stream:
        header = next(csv.reader(stream))
    if len(set(header)) != len(header):
        raise ValueError("duplicate CSV column names are not accepted")
    frame = pd.read_csv(args.csv, dtype=str)
    if manifest["row_count"] != len(frame):
        raise ValueError("partition manifest row count differs")
    labels = pd.to_numeric(frame.pop(args.label_column), errors="raise").to_numpy()
    result = evaluate_frozen(
        frame, labels, manifest["partitions"], seed=manifest["seed"], methods=args.detectors
    )
    args.output.parent.mkdir(parents=True, exist_ok=None)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    write_record(
        record_path,
        experiment=PROTOCOL,
        seeds=[manifest["seed"]],
        dataset=args.csv.name,
        data_path=args.csv,
        settings={
            "protocol": PROTOCOL,
            "exploratory": True,
            "label_column": args.label_column,
            "detectors": args.detectors,
            "partition_sha256": _sha256(args.partitions),
            "research_sha256": {name: _sha256(ROOT / name) for name in RESEARCH_SOURCES},
            "torch": _optional_version("torch"),
        },
        outputs=[args.output.name],
    )
    return 1 if result["errors"] or not result["runs"] else 0


def x_main__mutmut_117(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=Path, required=True)
    parser.add_argument("--partitions", type=Path, required=True)
    parser.add_argument("--label-column", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--detectors", nargs="+", required=True)
    args = parser.parse_args(argv)
    record_path = args.output.with_suffix(".record.json")
    if args.output.exists() or record_path.exists():
        raise FileExistsError("choose unused output and record paths")
    manifest = json.loads(args.partitions.read_text())
    if manifest["schema_version"] != 1 or manifest["input_sha256"] != _sha256(args.csv):
        raise ValueError("partition manifest version or source hash differs")
    with args.csv.open(newline="") as stream:
        header = next(csv.reader(stream))
    if len(set(header)) != len(header):
        raise ValueError("duplicate CSV column names are not accepted")
    frame = pd.read_csv(args.csv, dtype=str)
    if manifest["row_count"] != len(frame):
        raise ValueError("partition manifest row count differs")
    labels = pd.to_numeric(frame.pop(args.label_column), errors="raise").to_numpy()
    result = evaluate_frozen(
        frame, labels, manifest["partitions"], seed=manifest["seed"], methods=args.detectors
    )
    args.output.parent.mkdir(exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    write_record(
        record_path,
        experiment=PROTOCOL,
        seeds=[manifest["seed"]],
        dataset=args.csv.name,
        data_path=args.csv,
        settings={
            "protocol": PROTOCOL,
            "exploratory": True,
            "label_column": args.label_column,
            "detectors": args.detectors,
            "partition_sha256": _sha256(args.partitions),
            "research_sha256": {name: _sha256(ROOT / name) for name in RESEARCH_SOURCES},
            "torch": _optional_version("torch"),
        },
        outputs=[args.output.name],
    )
    return 1 if result["errors"] or not result["runs"] else 0


def x_main__mutmut_118(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=Path, required=True)
    parser.add_argument("--partitions", type=Path, required=True)
    parser.add_argument("--label-column", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--detectors", nargs="+", required=True)
    args = parser.parse_args(argv)
    record_path = args.output.with_suffix(".record.json")
    if args.output.exists() or record_path.exists():
        raise FileExistsError("choose unused output and record paths")
    manifest = json.loads(args.partitions.read_text())
    if manifest["schema_version"] != 1 or manifest["input_sha256"] != _sha256(args.csv):
        raise ValueError("partition manifest version or source hash differs")
    with args.csv.open(newline="") as stream:
        header = next(csv.reader(stream))
    if len(set(header)) != len(header):
        raise ValueError("duplicate CSV column names are not accepted")
    frame = pd.read_csv(args.csv, dtype=str)
    if manifest["row_count"] != len(frame):
        raise ValueError("partition manifest row count differs")
    labels = pd.to_numeric(frame.pop(args.label_column), errors="raise").to_numpy()
    result = evaluate_frozen(
        frame, labels, manifest["partitions"], seed=manifest["seed"], methods=args.detectors
    )
    args.output.parent.mkdir(parents=True, )
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    write_record(
        record_path,
        experiment=PROTOCOL,
        seeds=[manifest["seed"]],
        dataset=args.csv.name,
        data_path=args.csv,
        settings={
            "protocol": PROTOCOL,
            "exploratory": True,
            "label_column": args.label_column,
            "detectors": args.detectors,
            "partition_sha256": _sha256(args.partitions),
            "research_sha256": {name: _sha256(ROOT / name) for name in RESEARCH_SOURCES},
            "torch": _optional_version("torch"),
        },
        outputs=[args.output.name],
    )
    return 1 if result["errors"] or not result["runs"] else 0


def x_main__mutmut_119(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=Path, required=True)
    parser.add_argument("--partitions", type=Path, required=True)
    parser.add_argument("--label-column", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--detectors", nargs="+", required=True)
    args = parser.parse_args(argv)
    record_path = args.output.with_suffix(".record.json")
    if args.output.exists() or record_path.exists():
        raise FileExistsError("choose unused output and record paths")
    manifest = json.loads(args.partitions.read_text())
    if manifest["schema_version"] != 1 or manifest["input_sha256"] != _sha256(args.csv):
        raise ValueError("partition manifest version or source hash differs")
    with args.csv.open(newline="") as stream:
        header = next(csv.reader(stream))
    if len(set(header)) != len(header):
        raise ValueError("duplicate CSV column names are not accepted")
    frame = pd.read_csv(args.csv, dtype=str)
    if manifest["row_count"] != len(frame):
        raise ValueError("partition manifest row count differs")
    labels = pd.to_numeric(frame.pop(args.label_column), errors="raise").to_numpy()
    result = evaluate_frozen(
        frame, labels, manifest["partitions"], seed=manifest["seed"], methods=args.detectors
    )
    args.output.parent.mkdir(parents=False, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    write_record(
        record_path,
        experiment=PROTOCOL,
        seeds=[manifest["seed"]],
        dataset=args.csv.name,
        data_path=args.csv,
        settings={
            "protocol": PROTOCOL,
            "exploratory": True,
            "label_column": args.label_column,
            "detectors": args.detectors,
            "partition_sha256": _sha256(args.partitions),
            "research_sha256": {name: _sha256(ROOT / name) for name in RESEARCH_SOURCES},
            "torch": _optional_version("torch"),
        },
        outputs=[args.output.name],
    )
    return 1 if result["errors"] or not result["runs"] else 0


def x_main__mutmut_120(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=Path, required=True)
    parser.add_argument("--partitions", type=Path, required=True)
    parser.add_argument("--label-column", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--detectors", nargs="+", required=True)
    args = parser.parse_args(argv)
    record_path = args.output.with_suffix(".record.json")
    if args.output.exists() or record_path.exists():
        raise FileExistsError("choose unused output and record paths")
    manifest = json.loads(args.partitions.read_text())
    if manifest["schema_version"] != 1 or manifest["input_sha256"] != _sha256(args.csv):
        raise ValueError("partition manifest version or source hash differs")
    with args.csv.open(newline="") as stream:
        header = next(csv.reader(stream))
    if len(set(header)) != len(header):
        raise ValueError("duplicate CSV column names are not accepted")
    frame = pd.read_csv(args.csv, dtype=str)
    if manifest["row_count"] != len(frame):
        raise ValueError("partition manifest row count differs")
    labels = pd.to_numeric(frame.pop(args.label_column), errors="raise").to_numpy()
    result = evaluate_frozen(
        frame, labels, manifest["partitions"], seed=manifest["seed"], methods=args.detectors
    )
    args.output.parent.mkdir(parents=True, exist_ok=False)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    write_record(
        record_path,
        experiment=PROTOCOL,
        seeds=[manifest["seed"]],
        dataset=args.csv.name,
        data_path=args.csv,
        settings={
            "protocol": PROTOCOL,
            "exploratory": True,
            "label_column": args.label_column,
            "detectors": args.detectors,
            "partition_sha256": _sha256(args.partitions),
            "research_sha256": {name: _sha256(ROOT / name) for name in RESEARCH_SOURCES},
            "torch": _optional_version("torch"),
        },
        outputs=[args.output.name],
    )
    return 1 if result["errors"] or not result["runs"] else 0


def x_main__mutmut_121(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=Path, required=True)
    parser.add_argument("--partitions", type=Path, required=True)
    parser.add_argument("--label-column", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--detectors", nargs="+", required=True)
    args = parser.parse_args(argv)
    record_path = args.output.with_suffix(".record.json")
    if args.output.exists() or record_path.exists():
        raise FileExistsError("choose unused output and record paths")
    manifest = json.loads(args.partitions.read_text())
    if manifest["schema_version"] != 1 or manifest["input_sha256"] != _sha256(args.csv):
        raise ValueError("partition manifest version or source hash differs")
    with args.csv.open(newline="") as stream:
        header = next(csv.reader(stream))
    if len(set(header)) != len(header):
        raise ValueError("duplicate CSV column names are not accepted")
    frame = pd.read_csv(args.csv, dtype=str)
    if manifest["row_count"] != len(frame):
        raise ValueError("partition manifest row count differs")
    labels = pd.to_numeric(frame.pop(args.label_column), errors="raise").to_numpy()
    result = evaluate_frozen(
        frame, labels, manifest["partitions"], seed=manifest["seed"], methods=args.detectors
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(None) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    write_record(
        record_path,
        experiment=PROTOCOL,
        seeds=[manifest["seed"]],
        dataset=args.csv.name,
        data_path=args.csv,
        settings={
            "protocol": PROTOCOL,
            "exploratory": True,
            "label_column": args.label_column,
            "detectors": args.detectors,
            "partition_sha256": _sha256(args.partitions),
            "research_sha256": {name: _sha256(ROOT / name) for name in RESEARCH_SOURCES},
            "torch": _optional_version("torch"),
        },
        outputs=[args.output.name],
    )
    return 1 if result["errors"] or not result["runs"] else 0


def x_main__mutmut_122(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=Path, required=True)
    parser.add_argument("--partitions", type=Path, required=True)
    parser.add_argument("--label-column", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--detectors", nargs="+", required=True)
    args = parser.parse_args(argv)
    record_path = args.output.with_suffix(".record.json")
    if args.output.exists() or record_path.exists():
        raise FileExistsError("choose unused output and record paths")
    manifest = json.loads(args.partitions.read_text())
    if manifest["schema_version"] != 1 or manifest["input_sha256"] != _sha256(args.csv):
        raise ValueError("partition manifest version or source hash differs")
    with args.csv.open(newline="") as stream:
        header = next(csv.reader(stream))
    if len(set(header)) != len(header):
        raise ValueError("duplicate CSV column names are not accepted")
    frame = pd.read_csv(args.csv, dtype=str)
    if manifest["row_count"] != len(frame):
        raise ValueError("partition manifest row count differs")
    labels = pd.to_numeric(frame.pop(args.label_column), errors="raise").to_numpy()
    result = evaluate_frozen(
        frame, labels, manifest["partitions"], seed=manifest["seed"], methods=args.detectors
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(None)
    write_record(
        record_path,
        experiment=PROTOCOL,
        seeds=[manifest["seed"]],
        dataset=args.csv.name,
        data_path=args.csv,
        settings={
            "protocol": PROTOCOL,
            "exploratory": True,
            "label_column": args.label_column,
            "detectors": args.detectors,
            "partition_sha256": _sha256(args.partitions),
            "research_sha256": {name: _sha256(ROOT / name) for name in RESEARCH_SOURCES},
            "torch": _optional_version("torch"),
        },
        outputs=[args.output.name],
    )
    return 1 if result["errors"] or not result["runs"] else 0


def x_main__mutmut_123(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=Path, required=True)
    parser.add_argument("--partitions", type=Path, required=True)
    parser.add_argument("--label-column", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--detectors", nargs="+", required=True)
    args = parser.parse_args(argv)
    record_path = args.output.with_suffix(".record.json")
    if args.output.exists() or record_path.exists():
        raise FileExistsError("choose unused output and record paths")
    manifest = json.loads(args.partitions.read_text())
    if manifest["schema_version"] != 1 or manifest["input_sha256"] != _sha256(args.csv):
        raise ValueError("partition manifest version or source hash differs")
    with args.csv.open(newline="") as stream:
        header = next(csv.reader(stream))
    if len(set(header)) != len(header):
        raise ValueError("duplicate CSV column names are not accepted")
    frame = pd.read_csv(args.csv, dtype=str)
    if manifest["row_count"] != len(frame):
        raise ValueError("partition manifest row count differs")
    labels = pd.to_numeric(frame.pop(args.label_column), errors="raise").to_numpy()
    result = evaluate_frozen(
        frame, labels, manifest["partitions"], seed=manifest["seed"], methods=args.detectors
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) - "\n")
    write_record(
        record_path,
        experiment=PROTOCOL,
        seeds=[manifest["seed"]],
        dataset=args.csv.name,
        data_path=args.csv,
        settings={
            "protocol": PROTOCOL,
            "exploratory": True,
            "label_column": args.label_column,
            "detectors": args.detectors,
            "partition_sha256": _sha256(args.partitions),
            "research_sha256": {name: _sha256(ROOT / name) for name in RESEARCH_SOURCES},
            "torch": _optional_version("torch"),
        },
        outputs=[args.output.name],
    )
    return 1 if result["errors"] or not result["runs"] else 0


def x_main__mutmut_124(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=Path, required=True)
    parser.add_argument("--partitions", type=Path, required=True)
    parser.add_argument("--label-column", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--detectors", nargs="+", required=True)
    args = parser.parse_args(argv)
    record_path = args.output.with_suffix(".record.json")
    if args.output.exists() or record_path.exists():
        raise FileExistsError("choose unused output and record paths")
    manifest = json.loads(args.partitions.read_text())
    if manifest["schema_version"] != 1 or manifest["input_sha256"] != _sha256(args.csv):
        raise ValueError("partition manifest version or source hash differs")
    with args.csv.open(newline="") as stream:
        header = next(csv.reader(stream))
    if len(set(header)) != len(header):
        raise ValueError("duplicate CSV column names are not accepted")
    frame = pd.read_csv(args.csv, dtype=str)
    if manifest["row_count"] != len(frame):
        raise ValueError("partition manifest row count differs")
    labels = pd.to_numeric(frame.pop(args.label_column), errors="raise").to_numpy()
    result = evaluate_frozen(
        frame, labels, manifest["partitions"], seed=manifest["seed"], methods=args.detectors
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(None, indent=2, sort_keys=True, allow_nan=False) + "\n")
    write_record(
        record_path,
        experiment=PROTOCOL,
        seeds=[manifest["seed"]],
        dataset=args.csv.name,
        data_path=args.csv,
        settings={
            "protocol": PROTOCOL,
            "exploratory": True,
            "label_column": args.label_column,
            "detectors": args.detectors,
            "partition_sha256": _sha256(args.partitions),
            "research_sha256": {name: _sha256(ROOT / name) for name in RESEARCH_SOURCES},
            "torch": _optional_version("torch"),
        },
        outputs=[args.output.name],
    )
    return 1 if result["errors"] or not result["runs"] else 0


def x_main__mutmut_125(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=Path, required=True)
    parser.add_argument("--partitions", type=Path, required=True)
    parser.add_argument("--label-column", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--detectors", nargs="+", required=True)
    args = parser.parse_args(argv)
    record_path = args.output.with_suffix(".record.json")
    if args.output.exists() or record_path.exists():
        raise FileExistsError("choose unused output and record paths")
    manifest = json.loads(args.partitions.read_text())
    if manifest["schema_version"] != 1 or manifest["input_sha256"] != _sha256(args.csv):
        raise ValueError("partition manifest version or source hash differs")
    with args.csv.open(newline="") as stream:
        header = next(csv.reader(stream))
    if len(set(header)) != len(header):
        raise ValueError("duplicate CSV column names are not accepted")
    frame = pd.read_csv(args.csv, dtype=str)
    if manifest["row_count"] != len(frame):
        raise ValueError("partition manifest row count differs")
    labels = pd.to_numeric(frame.pop(args.label_column), errors="raise").to_numpy()
    result = evaluate_frozen(
        frame, labels, manifest["partitions"], seed=manifest["seed"], methods=args.detectors
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=None, sort_keys=True, allow_nan=False) + "\n")
    write_record(
        record_path,
        experiment=PROTOCOL,
        seeds=[manifest["seed"]],
        dataset=args.csv.name,
        data_path=args.csv,
        settings={
            "protocol": PROTOCOL,
            "exploratory": True,
            "label_column": args.label_column,
            "detectors": args.detectors,
            "partition_sha256": _sha256(args.partitions),
            "research_sha256": {name: _sha256(ROOT / name) for name in RESEARCH_SOURCES},
            "torch": _optional_version("torch"),
        },
        outputs=[args.output.name],
    )
    return 1 if result["errors"] or not result["runs"] else 0


def x_main__mutmut_126(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=Path, required=True)
    parser.add_argument("--partitions", type=Path, required=True)
    parser.add_argument("--label-column", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--detectors", nargs="+", required=True)
    args = parser.parse_args(argv)
    record_path = args.output.with_suffix(".record.json")
    if args.output.exists() or record_path.exists():
        raise FileExistsError("choose unused output and record paths")
    manifest = json.loads(args.partitions.read_text())
    if manifest["schema_version"] != 1 or manifest["input_sha256"] != _sha256(args.csv):
        raise ValueError("partition manifest version or source hash differs")
    with args.csv.open(newline="") as stream:
        header = next(csv.reader(stream))
    if len(set(header)) != len(header):
        raise ValueError("duplicate CSV column names are not accepted")
    frame = pd.read_csv(args.csv, dtype=str)
    if manifest["row_count"] != len(frame):
        raise ValueError("partition manifest row count differs")
    labels = pd.to_numeric(frame.pop(args.label_column), errors="raise").to_numpy()
    result = evaluate_frozen(
        frame, labels, manifest["partitions"], seed=manifest["seed"], methods=args.detectors
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=None, allow_nan=False) + "\n")
    write_record(
        record_path,
        experiment=PROTOCOL,
        seeds=[manifest["seed"]],
        dataset=args.csv.name,
        data_path=args.csv,
        settings={
            "protocol": PROTOCOL,
            "exploratory": True,
            "label_column": args.label_column,
            "detectors": args.detectors,
            "partition_sha256": _sha256(args.partitions),
            "research_sha256": {name: _sha256(ROOT / name) for name in RESEARCH_SOURCES},
            "torch": _optional_version("torch"),
        },
        outputs=[args.output.name],
    )
    return 1 if result["errors"] or not result["runs"] else 0


def x_main__mutmut_127(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=Path, required=True)
    parser.add_argument("--partitions", type=Path, required=True)
    parser.add_argument("--label-column", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--detectors", nargs="+", required=True)
    args = parser.parse_args(argv)
    record_path = args.output.with_suffix(".record.json")
    if args.output.exists() or record_path.exists():
        raise FileExistsError("choose unused output and record paths")
    manifest = json.loads(args.partitions.read_text())
    if manifest["schema_version"] != 1 or manifest["input_sha256"] != _sha256(args.csv):
        raise ValueError("partition manifest version or source hash differs")
    with args.csv.open(newline="") as stream:
        header = next(csv.reader(stream))
    if len(set(header)) != len(header):
        raise ValueError("duplicate CSV column names are not accepted")
    frame = pd.read_csv(args.csv, dtype=str)
    if manifest["row_count"] != len(frame):
        raise ValueError("partition manifest row count differs")
    labels = pd.to_numeric(frame.pop(args.label_column), errors="raise").to_numpy()
    result = evaluate_frozen(
        frame, labels, manifest["partitions"], seed=manifest["seed"], methods=args.detectors
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=None) + "\n")
    write_record(
        record_path,
        experiment=PROTOCOL,
        seeds=[manifest["seed"]],
        dataset=args.csv.name,
        data_path=args.csv,
        settings={
            "protocol": PROTOCOL,
            "exploratory": True,
            "label_column": args.label_column,
            "detectors": args.detectors,
            "partition_sha256": _sha256(args.partitions),
            "research_sha256": {name: _sha256(ROOT / name) for name in RESEARCH_SOURCES},
            "torch": _optional_version("torch"),
        },
        outputs=[args.output.name],
    )
    return 1 if result["errors"] or not result["runs"] else 0


def x_main__mutmut_128(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=Path, required=True)
    parser.add_argument("--partitions", type=Path, required=True)
    parser.add_argument("--label-column", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--detectors", nargs="+", required=True)
    args = parser.parse_args(argv)
    record_path = args.output.with_suffix(".record.json")
    if args.output.exists() or record_path.exists():
        raise FileExistsError("choose unused output and record paths")
    manifest = json.loads(args.partitions.read_text())
    if manifest["schema_version"] != 1 or manifest["input_sha256"] != _sha256(args.csv):
        raise ValueError("partition manifest version or source hash differs")
    with args.csv.open(newline="") as stream:
        header = next(csv.reader(stream))
    if len(set(header)) != len(header):
        raise ValueError("duplicate CSV column names are not accepted")
    frame = pd.read_csv(args.csv, dtype=str)
    if manifest["row_count"] != len(frame):
        raise ValueError("partition manifest row count differs")
    labels = pd.to_numeric(frame.pop(args.label_column), errors="raise").to_numpy()
    result = evaluate_frozen(
        frame, labels, manifest["partitions"], seed=manifest["seed"], methods=args.detectors
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(indent=2, sort_keys=True, allow_nan=False) + "\n")
    write_record(
        record_path,
        experiment=PROTOCOL,
        seeds=[manifest["seed"]],
        dataset=args.csv.name,
        data_path=args.csv,
        settings={
            "protocol": PROTOCOL,
            "exploratory": True,
            "label_column": args.label_column,
            "detectors": args.detectors,
            "partition_sha256": _sha256(args.partitions),
            "research_sha256": {name: _sha256(ROOT / name) for name in RESEARCH_SOURCES},
            "torch": _optional_version("torch"),
        },
        outputs=[args.output.name],
    )
    return 1 if result["errors"] or not result["runs"] else 0


def x_main__mutmut_129(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=Path, required=True)
    parser.add_argument("--partitions", type=Path, required=True)
    parser.add_argument("--label-column", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--detectors", nargs="+", required=True)
    args = parser.parse_args(argv)
    record_path = args.output.with_suffix(".record.json")
    if args.output.exists() or record_path.exists():
        raise FileExistsError("choose unused output and record paths")
    manifest = json.loads(args.partitions.read_text())
    if manifest["schema_version"] != 1 or manifest["input_sha256"] != _sha256(args.csv):
        raise ValueError("partition manifest version or source hash differs")
    with args.csv.open(newline="") as stream:
        header = next(csv.reader(stream))
    if len(set(header)) != len(header):
        raise ValueError("duplicate CSV column names are not accepted")
    frame = pd.read_csv(args.csv, dtype=str)
    if manifest["row_count"] != len(frame):
        raise ValueError("partition manifest row count differs")
    labels = pd.to_numeric(frame.pop(args.label_column), errors="raise").to_numpy()
    result = evaluate_frozen(
        frame, labels, manifest["partitions"], seed=manifest["seed"], methods=args.detectors
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, sort_keys=True, allow_nan=False) + "\n")
    write_record(
        record_path,
        experiment=PROTOCOL,
        seeds=[manifest["seed"]],
        dataset=args.csv.name,
        data_path=args.csv,
        settings={
            "protocol": PROTOCOL,
            "exploratory": True,
            "label_column": args.label_column,
            "detectors": args.detectors,
            "partition_sha256": _sha256(args.partitions),
            "research_sha256": {name: _sha256(ROOT / name) for name in RESEARCH_SOURCES},
            "torch": _optional_version("torch"),
        },
        outputs=[args.output.name],
    )
    return 1 if result["errors"] or not result["runs"] else 0


def x_main__mutmut_130(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=Path, required=True)
    parser.add_argument("--partitions", type=Path, required=True)
    parser.add_argument("--label-column", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--detectors", nargs="+", required=True)
    args = parser.parse_args(argv)
    record_path = args.output.with_suffix(".record.json")
    if args.output.exists() or record_path.exists():
        raise FileExistsError("choose unused output and record paths")
    manifest = json.loads(args.partitions.read_text())
    if manifest["schema_version"] != 1 or manifest["input_sha256"] != _sha256(args.csv):
        raise ValueError("partition manifest version or source hash differs")
    with args.csv.open(newline="") as stream:
        header = next(csv.reader(stream))
    if len(set(header)) != len(header):
        raise ValueError("duplicate CSV column names are not accepted")
    frame = pd.read_csv(args.csv, dtype=str)
    if manifest["row_count"] != len(frame):
        raise ValueError("partition manifest row count differs")
    labels = pd.to_numeric(frame.pop(args.label_column), errors="raise").to_numpy()
    result = evaluate_frozen(
        frame, labels, manifest["partitions"], seed=manifest["seed"], methods=args.detectors
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, allow_nan=False) + "\n")
    write_record(
        record_path,
        experiment=PROTOCOL,
        seeds=[manifest["seed"]],
        dataset=args.csv.name,
        data_path=args.csv,
        settings={
            "protocol": PROTOCOL,
            "exploratory": True,
            "label_column": args.label_column,
            "detectors": args.detectors,
            "partition_sha256": _sha256(args.partitions),
            "research_sha256": {name: _sha256(ROOT / name) for name in RESEARCH_SOURCES},
            "torch": _optional_version("torch"),
        },
        outputs=[args.output.name],
    )
    return 1 if result["errors"] or not result["runs"] else 0


def x_main__mutmut_131(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=Path, required=True)
    parser.add_argument("--partitions", type=Path, required=True)
    parser.add_argument("--label-column", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--detectors", nargs="+", required=True)
    args = parser.parse_args(argv)
    record_path = args.output.with_suffix(".record.json")
    if args.output.exists() or record_path.exists():
        raise FileExistsError("choose unused output and record paths")
    manifest = json.loads(args.partitions.read_text())
    if manifest["schema_version"] != 1 or manifest["input_sha256"] != _sha256(args.csv):
        raise ValueError("partition manifest version or source hash differs")
    with args.csv.open(newline="") as stream:
        header = next(csv.reader(stream))
    if len(set(header)) != len(header):
        raise ValueError("duplicate CSV column names are not accepted")
    frame = pd.read_csv(args.csv, dtype=str)
    if manifest["row_count"] != len(frame):
        raise ValueError("partition manifest row count differs")
    labels = pd.to_numeric(frame.pop(args.label_column), errors="raise").to_numpy()
    result = evaluate_frozen(
        frame, labels, manifest["partitions"], seed=manifest["seed"], methods=args.detectors
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True, ) + "\n")
    write_record(
        record_path,
        experiment=PROTOCOL,
        seeds=[manifest["seed"]],
        dataset=args.csv.name,
        data_path=args.csv,
        settings={
            "protocol": PROTOCOL,
            "exploratory": True,
            "label_column": args.label_column,
            "detectors": args.detectors,
            "partition_sha256": _sha256(args.partitions),
            "research_sha256": {name: _sha256(ROOT / name) for name in RESEARCH_SOURCES},
            "torch": _optional_version("torch"),
        },
        outputs=[args.output.name],
    )
    return 1 if result["errors"] or not result["runs"] else 0


def x_main__mutmut_132(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=Path, required=True)
    parser.add_argument("--partitions", type=Path, required=True)
    parser.add_argument("--label-column", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--detectors", nargs="+", required=True)
    args = parser.parse_args(argv)
    record_path = args.output.with_suffix(".record.json")
    if args.output.exists() or record_path.exists():
        raise FileExistsError("choose unused output and record paths")
    manifest = json.loads(args.partitions.read_text())
    if manifest["schema_version"] != 1 or manifest["input_sha256"] != _sha256(args.csv):
        raise ValueError("partition manifest version or source hash differs")
    with args.csv.open(newline="") as stream:
        header = next(csv.reader(stream))
    if len(set(header)) != len(header):
        raise ValueError("duplicate CSV column names are not accepted")
    frame = pd.read_csv(args.csv, dtype=str)
    if manifest["row_count"] != len(frame):
        raise ValueError("partition manifest row count differs")
    labels = pd.to_numeric(frame.pop(args.label_column), errors="raise").to_numpy()
    result = evaluate_frozen(
        frame, labels, manifest["partitions"], seed=manifest["seed"], methods=args.detectors
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=3, sort_keys=True, allow_nan=False) + "\n")
    write_record(
        record_path,
        experiment=PROTOCOL,
        seeds=[manifest["seed"]],
        dataset=args.csv.name,
        data_path=args.csv,
        settings={
            "protocol": PROTOCOL,
            "exploratory": True,
            "label_column": args.label_column,
            "detectors": args.detectors,
            "partition_sha256": _sha256(args.partitions),
            "research_sha256": {name: _sha256(ROOT / name) for name in RESEARCH_SOURCES},
            "torch": _optional_version("torch"),
        },
        outputs=[args.output.name],
    )
    return 1 if result["errors"] or not result["runs"] else 0


def x_main__mutmut_133(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=Path, required=True)
    parser.add_argument("--partitions", type=Path, required=True)
    parser.add_argument("--label-column", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--detectors", nargs="+", required=True)
    args = parser.parse_args(argv)
    record_path = args.output.with_suffix(".record.json")
    if args.output.exists() or record_path.exists():
        raise FileExistsError("choose unused output and record paths")
    manifest = json.loads(args.partitions.read_text())
    if manifest["schema_version"] != 1 or manifest["input_sha256"] != _sha256(args.csv):
        raise ValueError("partition manifest version or source hash differs")
    with args.csv.open(newline="") as stream:
        header = next(csv.reader(stream))
    if len(set(header)) != len(header):
        raise ValueError("duplicate CSV column names are not accepted")
    frame = pd.read_csv(args.csv, dtype=str)
    if manifest["row_count"] != len(frame):
        raise ValueError("partition manifest row count differs")
    labels = pd.to_numeric(frame.pop(args.label_column), errors="raise").to_numpy()
    result = evaluate_frozen(
        frame, labels, manifest["partitions"], seed=manifest["seed"], methods=args.detectors
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=False, allow_nan=False) + "\n")
    write_record(
        record_path,
        experiment=PROTOCOL,
        seeds=[manifest["seed"]],
        dataset=args.csv.name,
        data_path=args.csv,
        settings={
            "protocol": PROTOCOL,
            "exploratory": True,
            "label_column": args.label_column,
            "detectors": args.detectors,
            "partition_sha256": _sha256(args.partitions),
            "research_sha256": {name: _sha256(ROOT / name) for name in RESEARCH_SOURCES},
            "torch": _optional_version("torch"),
        },
        outputs=[args.output.name],
    )
    return 1 if result["errors"] or not result["runs"] else 0


def x_main__mutmut_134(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=Path, required=True)
    parser.add_argument("--partitions", type=Path, required=True)
    parser.add_argument("--label-column", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--detectors", nargs="+", required=True)
    args = parser.parse_args(argv)
    record_path = args.output.with_suffix(".record.json")
    if args.output.exists() or record_path.exists():
        raise FileExistsError("choose unused output and record paths")
    manifest = json.loads(args.partitions.read_text())
    if manifest["schema_version"] != 1 or manifest["input_sha256"] != _sha256(args.csv):
        raise ValueError("partition manifest version or source hash differs")
    with args.csv.open(newline="") as stream:
        header = next(csv.reader(stream))
    if len(set(header)) != len(header):
        raise ValueError("duplicate CSV column names are not accepted")
    frame = pd.read_csv(args.csv, dtype=str)
    if manifest["row_count"] != len(frame):
        raise ValueError("partition manifest row count differs")
    labels = pd.to_numeric(frame.pop(args.label_column), errors="raise").to_numpy()
    result = evaluate_frozen(
        frame, labels, manifest["partitions"], seed=manifest["seed"], methods=args.detectors
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=True) + "\n")
    write_record(
        record_path,
        experiment=PROTOCOL,
        seeds=[manifest["seed"]],
        dataset=args.csv.name,
        data_path=args.csv,
        settings={
            "protocol": PROTOCOL,
            "exploratory": True,
            "label_column": args.label_column,
            "detectors": args.detectors,
            "partition_sha256": _sha256(args.partitions),
            "research_sha256": {name: _sha256(ROOT / name) for name in RESEARCH_SOURCES},
            "torch": _optional_version("torch"),
        },
        outputs=[args.output.name],
    )
    return 1 if result["errors"] or not result["runs"] else 0


def x_main__mutmut_135(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=Path, required=True)
    parser.add_argument("--partitions", type=Path, required=True)
    parser.add_argument("--label-column", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--detectors", nargs="+", required=True)
    args = parser.parse_args(argv)
    record_path = args.output.with_suffix(".record.json")
    if args.output.exists() or record_path.exists():
        raise FileExistsError("choose unused output and record paths")
    manifest = json.loads(args.partitions.read_text())
    if manifest["schema_version"] != 1 or manifest["input_sha256"] != _sha256(args.csv):
        raise ValueError("partition manifest version or source hash differs")
    with args.csv.open(newline="") as stream:
        header = next(csv.reader(stream))
    if len(set(header)) != len(header):
        raise ValueError("duplicate CSV column names are not accepted")
    frame = pd.read_csv(args.csv, dtype=str)
    if manifest["row_count"] != len(frame):
        raise ValueError("partition manifest row count differs")
    labels = pd.to_numeric(frame.pop(args.label_column), errors="raise").to_numpy()
    result = evaluate_frozen(
        frame, labels, manifest["partitions"], seed=manifest["seed"], methods=args.detectors
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "XX\nXX")
    write_record(
        record_path,
        experiment=PROTOCOL,
        seeds=[manifest["seed"]],
        dataset=args.csv.name,
        data_path=args.csv,
        settings={
            "protocol": PROTOCOL,
            "exploratory": True,
            "label_column": args.label_column,
            "detectors": args.detectors,
            "partition_sha256": _sha256(args.partitions),
            "research_sha256": {name: _sha256(ROOT / name) for name in RESEARCH_SOURCES},
            "torch": _optional_version("torch"),
        },
        outputs=[args.output.name],
    )
    return 1 if result["errors"] or not result["runs"] else 0


def x_main__mutmut_136(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=Path, required=True)
    parser.add_argument("--partitions", type=Path, required=True)
    parser.add_argument("--label-column", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--detectors", nargs="+", required=True)
    args = parser.parse_args(argv)
    record_path = args.output.with_suffix(".record.json")
    if args.output.exists() or record_path.exists():
        raise FileExistsError("choose unused output and record paths")
    manifest = json.loads(args.partitions.read_text())
    if manifest["schema_version"] != 1 or manifest["input_sha256"] != _sha256(args.csv):
        raise ValueError("partition manifest version or source hash differs")
    with args.csv.open(newline="") as stream:
        header = next(csv.reader(stream))
    if len(set(header)) != len(header):
        raise ValueError("duplicate CSV column names are not accepted")
    frame = pd.read_csv(args.csv, dtype=str)
    if manifest["row_count"] != len(frame):
        raise ValueError("partition manifest row count differs")
    labels = pd.to_numeric(frame.pop(args.label_column), errors="raise").to_numpy()
    result = evaluate_frozen(
        frame, labels, manifest["partitions"], seed=manifest["seed"], methods=args.detectors
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    write_record(
        None,
        experiment=PROTOCOL,
        seeds=[manifest["seed"]],
        dataset=args.csv.name,
        data_path=args.csv,
        settings={
            "protocol": PROTOCOL,
            "exploratory": True,
            "label_column": args.label_column,
            "detectors": args.detectors,
            "partition_sha256": _sha256(args.partitions),
            "research_sha256": {name: _sha256(ROOT / name) for name in RESEARCH_SOURCES},
            "torch": _optional_version("torch"),
        },
        outputs=[args.output.name],
    )
    return 1 if result["errors"] or not result["runs"] else 0


def x_main__mutmut_137(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=Path, required=True)
    parser.add_argument("--partitions", type=Path, required=True)
    parser.add_argument("--label-column", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--detectors", nargs="+", required=True)
    args = parser.parse_args(argv)
    record_path = args.output.with_suffix(".record.json")
    if args.output.exists() or record_path.exists():
        raise FileExistsError("choose unused output and record paths")
    manifest = json.loads(args.partitions.read_text())
    if manifest["schema_version"] != 1 or manifest["input_sha256"] != _sha256(args.csv):
        raise ValueError("partition manifest version or source hash differs")
    with args.csv.open(newline="") as stream:
        header = next(csv.reader(stream))
    if len(set(header)) != len(header):
        raise ValueError("duplicate CSV column names are not accepted")
    frame = pd.read_csv(args.csv, dtype=str)
    if manifest["row_count"] != len(frame):
        raise ValueError("partition manifest row count differs")
    labels = pd.to_numeric(frame.pop(args.label_column), errors="raise").to_numpy()
    result = evaluate_frozen(
        frame, labels, manifest["partitions"], seed=manifest["seed"], methods=args.detectors
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    write_record(
        record_path,
        experiment=None,
        seeds=[manifest["seed"]],
        dataset=args.csv.name,
        data_path=args.csv,
        settings={
            "protocol": PROTOCOL,
            "exploratory": True,
            "label_column": args.label_column,
            "detectors": args.detectors,
            "partition_sha256": _sha256(args.partitions),
            "research_sha256": {name: _sha256(ROOT / name) for name in RESEARCH_SOURCES},
            "torch": _optional_version("torch"),
        },
        outputs=[args.output.name],
    )
    return 1 if result["errors"] or not result["runs"] else 0


def x_main__mutmut_138(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=Path, required=True)
    parser.add_argument("--partitions", type=Path, required=True)
    parser.add_argument("--label-column", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--detectors", nargs="+", required=True)
    args = parser.parse_args(argv)
    record_path = args.output.with_suffix(".record.json")
    if args.output.exists() or record_path.exists():
        raise FileExistsError("choose unused output and record paths")
    manifest = json.loads(args.partitions.read_text())
    if manifest["schema_version"] != 1 or manifest["input_sha256"] != _sha256(args.csv):
        raise ValueError("partition manifest version or source hash differs")
    with args.csv.open(newline="") as stream:
        header = next(csv.reader(stream))
    if len(set(header)) != len(header):
        raise ValueError("duplicate CSV column names are not accepted")
    frame = pd.read_csv(args.csv, dtype=str)
    if manifest["row_count"] != len(frame):
        raise ValueError("partition manifest row count differs")
    labels = pd.to_numeric(frame.pop(args.label_column), errors="raise").to_numpy()
    result = evaluate_frozen(
        frame, labels, manifest["partitions"], seed=manifest["seed"], methods=args.detectors
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    write_record(
        record_path,
        experiment=PROTOCOL,
        seeds=None,
        dataset=args.csv.name,
        data_path=args.csv,
        settings={
            "protocol": PROTOCOL,
            "exploratory": True,
            "label_column": args.label_column,
            "detectors": args.detectors,
            "partition_sha256": _sha256(args.partitions),
            "research_sha256": {name: _sha256(ROOT / name) for name in RESEARCH_SOURCES},
            "torch": _optional_version("torch"),
        },
        outputs=[args.output.name],
    )
    return 1 if result["errors"] or not result["runs"] else 0


def x_main__mutmut_139(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=Path, required=True)
    parser.add_argument("--partitions", type=Path, required=True)
    parser.add_argument("--label-column", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--detectors", nargs="+", required=True)
    args = parser.parse_args(argv)
    record_path = args.output.with_suffix(".record.json")
    if args.output.exists() or record_path.exists():
        raise FileExistsError("choose unused output and record paths")
    manifest = json.loads(args.partitions.read_text())
    if manifest["schema_version"] != 1 or manifest["input_sha256"] != _sha256(args.csv):
        raise ValueError("partition manifest version or source hash differs")
    with args.csv.open(newline="") as stream:
        header = next(csv.reader(stream))
    if len(set(header)) != len(header):
        raise ValueError("duplicate CSV column names are not accepted")
    frame = pd.read_csv(args.csv, dtype=str)
    if manifest["row_count"] != len(frame):
        raise ValueError("partition manifest row count differs")
    labels = pd.to_numeric(frame.pop(args.label_column), errors="raise").to_numpy()
    result = evaluate_frozen(
        frame, labels, manifest["partitions"], seed=manifest["seed"], methods=args.detectors
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    write_record(
        record_path,
        experiment=PROTOCOL,
        seeds=[manifest["seed"]],
        dataset=None,
        data_path=args.csv,
        settings={
            "protocol": PROTOCOL,
            "exploratory": True,
            "label_column": args.label_column,
            "detectors": args.detectors,
            "partition_sha256": _sha256(args.partitions),
            "research_sha256": {name: _sha256(ROOT / name) for name in RESEARCH_SOURCES},
            "torch": _optional_version("torch"),
        },
        outputs=[args.output.name],
    )
    return 1 if result["errors"] or not result["runs"] else 0


def x_main__mutmut_140(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=Path, required=True)
    parser.add_argument("--partitions", type=Path, required=True)
    parser.add_argument("--label-column", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--detectors", nargs="+", required=True)
    args = parser.parse_args(argv)
    record_path = args.output.with_suffix(".record.json")
    if args.output.exists() or record_path.exists():
        raise FileExistsError("choose unused output and record paths")
    manifest = json.loads(args.partitions.read_text())
    if manifest["schema_version"] != 1 or manifest["input_sha256"] != _sha256(args.csv):
        raise ValueError("partition manifest version or source hash differs")
    with args.csv.open(newline="") as stream:
        header = next(csv.reader(stream))
    if len(set(header)) != len(header):
        raise ValueError("duplicate CSV column names are not accepted")
    frame = pd.read_csv(args.csv, dtype=str)
    if manifest["row_count"] != len(frame):
        raise ValueError("partition manifest row count differs")
    labels = pd.to_numeric(frame.pop(args.label_column), errors="raise").to_numpy()
    result = evaluate_frozen(
        frame, labels, manifest["partitions"], seed=manifest["seed"], methods=args.detectors
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    write_record(
        record_path,
        experiment=PROTOCOL,
        seeds=[manifest["seed"]],
        dataset=args.csv.name,
        data_path=None,
        settings={
            "protocol": PROTOCOL,
            "exploratory": True,
            "label_column": args.label_column,
            "detectors": args.detectors,
            "partition_sha256": _sha256(args.partitions),
            "research_sha256": {name: _sha256(ROOT / name) for name in RESEARCH_SOURCES},
            "torch": _optional_version("torch"),
        },
        outputs=[args.output.name],
    )
    return 1 if result["errors"] or not result["runs"] else 0


def x_main__mutmut_141(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=Path, required=True)
    parser.add_argument("--partitions", type=Path, required=True)
    parser.add_argument("--label-column", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--detectors", nargs="+", required=True)
    args = parser.parse_args(argv)
    record_path = args.output.with_suffix(".record.json")
    if args.output.exists() or record_path.exists():
        raise FileExistsError("choose unused output and record paths")
    manifest = json.loads(args.partitions.read_text())
    if manifest["schema_version"] != 1 or manifest["input_sha256"] != _sha256(args.csv):
        raise ValueError("partition manifest version or source hash differs")
    with args.csv.open(newline="") as stream:
        header = next(csv.reader(stream))
    if len(set(header)) != len(header):
        raise ValueError("duplicate CSV column names are not accepted")
    frame = pd.read_csv(args.csv, dtype=str)
    if manifest["row_count"] != len(frame):
        raise ValueError("partition manifest row count differs")
    labels = pd.to_numeric(frame.pop(args.label_column), errors="raise").to_numpy()
    result = evaluate_frozen(
        frame, labels, manifest["partitions"], seed=manifest["seed"], methods=args.detectors
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    write_record(
        record_path,
        experiment=PROTOCOL,
        seeds=[manifest["seed"]],
        dataset=args.csv.name,
        data_path=args.csv,
        settings=None,
        outputs=[args.output.name],
    )
    return 1 if result["errors"] or not result["runs"] else 0


def x_main__mutmut_142(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=Path, required=True)
    parser.add_argument("--partitions", type=Path, required=True)
    parser.add_argument("--label-column", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--detectors", nargs="+", required=True)
    args = parser.parse_args(argv)
    record_path = args.output.with_suffix(".record.json")
    if args.output.exists() or record_path.exists():
        raise FileExistsError("choose unused output and record paths")
    manifest = json.loads(args.partitions.read_text())
    if manifest["schema_version"] != 1 or manifest["input_sha256"] != _sha256(args.csv):
        raise ValueError("partition manifest version or source hash differs")
    with args.csv.open(newline="") as stream:
        header = next(csv.reader(stream))
    if len(set(header)) != len(header):
        raise ValueError("duplicate CSV column names are not accepted")
    frame = pd.read_csv(args.csv, dtype=str)
    if manifest["row_count"] != len(frame):
        raise ValueError("partition manifest row count differs")
    labels = pd.to_numeric(frame.pop(args.label_column), errors="raise").to_numpy()
    result = evaluate_frozen(
        frame, labels, manifest["partitions"], seed=manifest["seed"], methods=args.detectors
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    write_record(
        record_path,
        experiment=PROTOCOL,
        seeds=[manifest["seed"]],
        dataset=args.csv.name,
        data_path=args.csv,
        settings={
            "protocol": PROTOCOL,
            "exploratory": True,
            "label_column": args.label_column,
            "detectors": args.detectors,
            "partition_sha256": _sha256(args.partitions),
            "research_sha256": {name: _sha256(ROOT / name) for name in RESEARCH_SOURCES},
            "torch": _optional_version("torch"),
        },
        outputs=None,
    )
    return 1 if result["errors"] or not result["runs"] else 0


def x_main__mutmut_143(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=Path, required=True)
    parser.add_argument("--partitions", type=Path, required=True)
    parser.add_argument("--label-column", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--detectors", nargs="+", required=True)
    args = parser.parse_args(argv)
    record_path = args.output.with_suffix(".record.json")
    if args.output.exists() or record_path.exists():
        raise FileExistsError("choose unused output and record paths")
    manifest = json.loads(args.partitions.read_text())
    if manifest["schema_version"] != 1 or manifest["input_sha256"] != _sha256(args.csv):
        raise ValueError("partition manifest version or source hash differs")
    with args.csv.open(newline="") as stream:
        header = next(csv.reader(stream))
    if len(set(header)) != len(header):
        raise ValueError("duplicate CSV column names are not accepted")
    frame = pd.read_csv(args.csv, dtype=str)
    if manifest["row_count"] != len(frame):
        raise ValueError("partition manifest row count differs")
    labels = pd.to_numeric(frame.pop(args.label_column), errors="raise").to_numpy()
    result = evaluate_frozen(
        frame, labels, manifest["partitions"], seed=manifest["seed"], methods=args.detectors
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    write_record(
        experiment=PROTOCOL,
        seeds=[manifest["seed"]],
        dataset=args.csv.name,
        data_path=args.csv,
        settings={
            "protocol": PROTOCOL,
            "exploratory": True,
            "label_column": args.label_column,
            "detectors": args.detectors,
            "partition_sha256": _sha256(args.partitions),
            "research_sha256": {name: _sha256(ROOT / name) for name in RESEARCH_SOURCES},
            "torch": _optional_version("torch"),
        },
        outputs=[args.output.name],
    )
    return 1 if result["errors"] or not result["runs"] else 0


def x_main__mutmut_144(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=Path, required=True)
    parser.add_argument("--partitions", type=Path, required=True)
    parser.add_argument("--label-column", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--detectors", nargs="+", required=True)
    args = parser.parse_args(argv)
    record_path = args.output.with_suffix(".record.json")
    if args.output.exists() or record_path.exists():
        raise FileExistsError("choose unused output and record paths")
    manifest = json.loads(args.partitions.read_text())
    if manifest["schema_version"] != 1 or manifest["input_sha256"] != _sha256(args.csv):
        raise ValueError("partition manifest version or source hash differs")
    with args.csv.open(newline="") as stream:
        header = next(csv.reader(stream))
    if len(set(header)) != len(header):
        raise ValueError("duplicate CSV column names are not accepted")
    frame = pd.read_csv(args.csv, dtype=str)
    if manifest["row_count"] != len(frame):
        raise ValueError("partition manifest row count differs")
    labels = pd.to_numeric(frame.pop(args.label_column), errors="raise").to_numpy()
    result = evaluate_frozen(
        frame, labels, manifest["partitions"], seed=manifest["seed"], methods=args.detectors
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    write_record(
        record_path,
        seeds=[manifest["seed"]],
        dataset=args.csv.name,
        data_path=args.csv,
        settings={
            "protocol": PROTOCOL,
            "exploratory": True,
            "label_column": args.label_column,
            "detectors": args.detectors,
            "partition_sha256": _sha256(args.partitions),
            "research_sha256": {name: _sha256(ROOT / name) for name in RESEARCH_SOURCES},
            "torch": _optional_version("torch"),
        },
        outputs=[args.output.name],
    )
    return 1 if result["errors"] or not result["runs"] else 0


def x_main__mutmut_145(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=Path, required=True)
    parser.add_argument("--partitions", type=Path, required=True)
    parser.add_argument("--label-column", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--detectors", nargs="+", required=True)
    args = parser.parse_args(argv)
    record_path = args.output.with_suffix(".record.json")
    if args.output.exists() or record_path.exists():
        raise FileExistsError("choose unused output and record paths")
    manifest = json.loads(args.partitions.read_text())
    if manifest["schema_version"] != 1 or manifest["input_sha256"] != _sha256(args.csv):
        raise ValueError("partition manifest version or source hash differs")
    with args.csv.open(newline="") as stream:
        header = next(csv.reader(stream))
    if len(set(header)) != len(header):
        raise ValueError("duplicate CSV column names are not accepted")
    frame = pd.read_csv(args.csv, dtype=str)
    if manifest["row_count"] != len(frame):
        raise ValueError("partition manifest row count differs")
    labels = pd.to_numeric(frame.pop(args.label_column), errors="raise").to_numpy()
    result = evaluate_frozen(
        frame, labels, manifest["partitions"], seed=manifest["seed"], methods=args.detectors
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    write_record(
        record_path,
        experiment=PROTOCOL,
        dataset=args.csv.name,
        data_path=args.csv,
        settings={
            "protocol": PROTOCOL,
            "exploratory": True,
            "label_column": args.label_column,
            "detectors": args.detectors,
            "partition_sha256": _sha256(args.partitions),
            "research_sha256": {name: _sha256(ROOT / name) for name in RESEARCH_SOURCES},
            "torch": _optional_version("torch"),
        },
        outputs=[args.output.name],
    )
    return 1 if result["errors"] or not result["runs"] else 0


def x_main__mutmut_146(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=Path, required=True)
    parser.add_argument("--partitions", type=Path, required=True)
    parser.add_argument("--label-column", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--detectors", nargs="+", required=True)
    args = parser.parse_args(argv)
    record_path = args.output.with_suffix(".record.json")
    if args.output.exists() or record_path.exists():
        raise FileExistsError("choose unused output and record paths")
    manifest = json.loads(args.partitions.read_text())
    if manifest["schema_version"] != 1 or manifest["input_sha256"] != _sha256(args.csv):
        raise ValueError("partition manifest version or source hash differs")
    with args.csv.open(newline="") as stream:
        header = next(csv.reader(stream))
    if len(set(header)) != len(header):
        raise ValueError("duplicate CSV column names are not accepted")
    frame = pd.read_csv(args.csv, dtype=str)
    if manifest["row_count"] != len(frame):
        raise ValueError("partition manifest row count differs")
    labels = pd.to_numeric(frame.pop(args.label_column), errors="raise").to_numpy()
    result = evaluate_frozen(
        frame, labels, manifest["partitions"], seed=manifest["seed"], methods=args.detectors
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    write_record(
        record_path,
        experiment=PROTOCOL,
        seeds=[manifest["seed"]],
        data_path=args.csv,
        settings={
            "protocol": PROTOCOL,
            "exploratory": True,
            "label_column": args.label_column,
            "detectors": args.detectors,
            "partition_sha256": _sha256(args.partitions),
            "research_sha256": {name: _sha256(ROOT / name) for name in RESEARCH_SOURCES},
            "torch": _optional_version("torch"),
        },
        outputs=[args.output.name],
    )
    return 1 if result["errors"] or not result["runs"] else 0


def x_main__mutmut_147(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=Path, required=True)
    parser.add_argument("--partitions", type=Path, required=True)
    parser.add_argument("--label-column", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--detectors", nargs="+", required=True)
    args = parser.parse_args(argv)
    record_path = args.output.with_suffix(".record.json")
    if args.output.exists() or record_path.exists():
        raise FileExistsError("choose unused output and record paths")
    manifest = json.loads(args.partitions.read_text())
    if manifest["schema_version"] != 1 or manifest["input_sha256"] != _sha256(args.csv):
        raise ValueError("partition manifest version or source hash differs")
    with args.csv.open(newline="") as stream:
        header = next(csv.reader(stream))
    if len(set(header)) != len(header):
        raise ValueError("duplicate CSV column names are not accepted")
    frame = pd.read_csv(args.csv, dtype=str)
    if manifest["row_count"] != len(frame):
        raise ValueError("partition manifest row count differs")
    labels = pd.to_numeric(frame.pop(args.label_column), errors="raise").to_numpy()
    result = evaluate_frozen(
        frame, labels, manifest["partitions"], seed=manifest["seed"], methods=args.detectors
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    write_record(
        record_path,
        experiment=PROTOCOL,
        seeds=[manifest["seed"]],
        dataset=args.csv.name,
        settings={
            "protocol": PROTOCOL,
            "exploratory": True,
            "label_column": args.label_column,
            "detectors": args.detectors,
            "partition_sha256": _sha256(args.partitions),
            "research_sha256": {name: _sha256(ROOT / name) for name in RESEARCH_SOURCES},
            "torch": _optional_version("torch"),
        },
        outputs=[args.output.name],
    )
    return 1 if result["errors"] or not result["runs"] else 0


def x_main__mutmut_148(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=Path, required=True)
    parser.add_argument("--partitions", type=Path, required=True)
    parser.add_argument("--label-column", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--detectors", nargs="+", required=True)
    args = parser.parse_args(argv)
    record_path = args.output.with_suffix(".record.json")
    if args.output.exists() or record_path.exists():
        raise FileExistsError("choose unused output and record paths")
    manifest = json.loads(args.partitions.read_text())
    if manifest["schema_version"] != 1 or manifest["input_sha256"] != _sha256(args.csv):
        raise ValueError("partition manifest version or source hash differs")
    with args.csv.open(newline="") as stream:
        header = next(csv.reader(stream))
    if len(set(header)) != len(header):
        raise ValueError("duplicate CSV column names are not accepted")
    frame = pd.read_csv(args.csv, dtype=str)
    if manifest["row_count"] != len(frame):
        raise ValueError("partition manifest row count differs")
    labels = pd.to_numeric(frame.pop(args.label_column), errors="raise").to_numpy()
    result = evaluate_frozen(
        frame, labels, manifest["partitions"], seed=manifest["seed"], methods=args.detectors
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    write_record(
        record_path,
        experiment=PROTOCOL,
        seeds=[manifest["seed"]],
        dataset=args.csv.name,
        data_path=args.csv,
        outputs=[args.output.name],
    )
    return 1 if result["errors"] or not result["runs"] else 0


def x_main__mutmut_149(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=Path, required=True)
    parser.add_argument("--partitions", type=Path, required=True)
    parser.add_argument("--label-column", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--detectors", nargs="+", required=True)
    args = parser.parse_args(argv)
    record_path = args.output.with_suffix(".record.json")
    if args.output.exists() or record_path.exists():
        raise FileExistsError("choose unused output and record paths")
    manifest = json.loads(args.partitions.read_text())
    if manifest["schema_version"] != 1 or manifest["input_sha256"] != _sha256(args.csv):
        raise ValueError("partition manifest version or source hash differs")
    with args.csv.open(newline="") as stream:
        header = next(csv.reader(stream))
    if len(set(header)) != len(header):
        raise ValueError("duplicate CSV column names are not accepted")
    frame = pd.read_csv(args.csv, dtype=str)
    if manifest["row_count"] != len(frame):
        raise ValueError("partition manifest row count differs")
    labels = pd.to_numeric(frame.pop(args.label_column), errors="raise").to_numpy()
    result = evaluate_frozen(
        frame, labels, manifest["partitions"], seed=manifest["seed"], methods=args.detectors
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    write_record(
        record_path,
        experiment=PROTOCOL,
        seeds=[manifest["seed"]],
        dataset=args.csv.name,
        data_path=args.csv,
        settings={
            "protocol": PROTOCOL,
            "exploratory": True,
            "label_column": args.label_column,
            "detectors": args.detectors,
            "partition_sha256": _sha256(args.partitions),
            "research_sha256": {name: _sha256(ROOT / name) for name in RESEARCH_SOURCES},
            "torch": _optional_version("torch"),
        },
        )
    return 1 if result["errors"] or not result["runs"] else 0


def x_main__mutmut_150(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=Path, required=True)
    parser.add_argument("--partitions", type=Path, required=True)
    parser.add_argument("--label-column", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--detectors", nargs="+", required=True)
    args = parser.parse_args(argv)
    record_path = args.output.with_suffix(".record.json")
    if args.output.exists() or record_path.exists():
        raise FileExistsError("choose unused output and record paths")
    manifest = json.loads(args.partitions.read_text())
    if manifest["schema_version"] != 1 or manifest["input_sha256"] != _sha256(args.csv):
        raise ValueError("partition manifest version or source hash differs")
    with args.csv.open(newline="") as stream:
        header = next(csv.reader(stream))
    if len(set(header)) != len(header):
        raise ValueError("duplicate CSV column names are not accepted")
    frame = pd.read_csv(args.csv, dtype=str)
    if manifest["row_count"] != len(frame):
        raise ValueError("partition manifest row count differs")
    labels = pd.to_numeric(frame.pop(args.label_column), errors="raise").to_numpy()
    result = evaluate_frozen(
        frame, labels, manifest["partitions"], seed=manifest["seed"], methods=args.detectors
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    write_record(
        record_path,
        experiment=PROTOCOL,
        seeds=[manifest["XXseedXX"]],
        dataset=args.csv.name,
        data_path=args.csv,
        settings={
            "protocol": PROTOCOL,
            "exploratory": True,
            "label_column": args.label_column,
            "detectors": args.detectors,
            "partition_sha256": _sha256(args.partitions),
            "research_sha256": {name: _sha256(ROOT / name) for name in RESEARCH_SOURCES},
            "torch": _optional_version("torch"),
        },
        outputs=[args.output.name],
    )
    return 1 if result["errors"] or not result["runs"] else 0


def x_main__mutmut_151(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=Path, required=True)
    parser.add_argument("--partitions", type=Path, required=True)
    parser.add_argument("--label-column", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--detectors", nargs="+", required=True)
    args = parser.parse_args(argv)
    record_path = args.output.with_suffix(".record.json")
    if args.output.exists() or record_path.exists():
        raise FileExistsError("choose unused output and record paths")
    manifest = json.loads(args.partitions.read_text())
    if manifest["schema_version"] != 1 or manifest["input_sha256"] != _sha256(args.csv):
        raise ValueError("partition manifest version or source hash differs")
    with args.csv.open(newline="") as stream:
        header = next(csv.reader(stream))
    if len(set(header)) != len(header):
        raise ValueError("duplicate CSV column names are not accepted")
    frame = pd.read_csv(args.csv, dtype=str)
    if manifest["row_count"] != len(frame):
        raise ValueError("partition manifest row count differs")
    labels = pd.to_numeric(frame.pop(args.label_column), errors="raise").to_numpy()
    result = evaluate_frozen(
        frame, labels, manifest["partitions"], seed=manifest["seed"], methods=args.detectors
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    write_record(
        record_path,
        experiment=PROTOCOL,
        seeds=[manifest["SEED"]],
        dataset=args.csv.name,
        data_path=args.csv,
        settings={
            "protocol": PROTOCOL,
            "exploratory": True,
            "label_column": args.label_column,
            "detectors": args.detectors,
            "partition_sha256": _sha256(args.partitions),
            "research_sha256": {name: _sha256(ROOT / name) for name in RESEARCH_SOURCES},
            "torch": _optional_version("torch"),
        },
        outputs=[args.output.name],
    )
    return 1 if result["errors"] or not result["runs"] else 0


def x_main__mutmut_152(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=Path, required=True)
    parser.add_argument("--partitions", type=Path, required=True)
    parser.add_argument("--label-column", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--detectors", nargs="+", required=True)
    args = parser.parse_args(argv)
    record_path = args.output.with_suffix(".record.json")
    if args.output.exists() or record_path.exists():
        raise FileExistsError("choose unused output and record paths")
    manifest = json.loads(args.partitions.read_text())
    if manifest["schema_version"] != 1 or manifest["input_sha256"] != _sha256(args.csv):
        raise ValueError("partition manifest version or source hash differs")
    with args.csv.open(newline="") as stream:
        header = next(csv.reader(stream))
    if len(set(header)) != len(header):
        raise ValueError("duplicate CSV column names are not accepted")
    frame = pd.read_csv(args.csv, dtype=str)
    if manifest["row_count"] != len(frame):
        raise ValueError("partition manifest row count differs")
    labels = pd.to_numeric(frame.pop(args.label_column), errors="raise").to_numpy()
    result = evaluate_frozen(
        frame, labels, manifest["partitions"], seed=manifest["seed"], methods=args.detectors
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    write_record(
        record_path,
        experiment=PROTOCOL,
        seeds=[manifest["seed"]],
        dataset=args.csv.name,
        data_path=args.csv,
        settings={
            "XXprotocolXX": PROTOCOL,
            "exploratory": True,
            "label_column": args.label_column,
            "detectors": args.detectors,
            "partition_sha256": _sha256(args.partitions),
            "research_sha256": {name: _sha256(ROOT / name) for name in RESEARCH_SOURCES},
            "torch": _optional_version("torch"),
        },
        outputs=[args.output.name],
    )
    return 1 if result["errors"] or not result["runs"] else 0


def x_main__mutmut_153(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=Path, required=True)
    parser.add_argument("--partitions", type=Path, required=True)
    parser.add_argument("--label-column", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--detectors", nargs="+", required=True)
    args = parser.parse_args(argv)
    record_path = args.output.with_suffix(".record.json")
    if args.output.exists() or record_path.exists():
        raise FileExistsError("choose unused output and record paths")
    manifest = json.loads(args.partitions.read_text())
    if manifest["schema_version"] != 1 or manifest["input_sha256"] != _sha256(args.csv):
        raise ValueError("partition manifest version or source hash differs")
    with args.csv.open(newline="") as stream:
        header = next(csv.reader(stream))
    if len(set(header)) != len(header):
        raise ValueError("duplicate CSV column names are not accepted")
    frame = pd.read_csv(args.csv, dtype=str)
    if manifest["row_count"] != len(frame):
        raise ValueError("partition manifest row count differs")
    labels = pd.to_numeric(frame.pop(args.label_column), errors="raise").to_numpy()
    result = evaluate_frozen(
        frame, labels, manifest["partitions"], seed=manifest["seed"], methods=args.detectors
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    write_record(
        record_path,
        experiment=PROTOCOL,
        seeds=[manifest["seed"]],
        dataset=args.csv.name,
        data_path=args.csv,
        settings={
            "PROTOCOL": PROTOCOL,
            "exploratory": True,
            "label_column": args.label_column,
            "detectors": args.detectors,
            "partition_sha256": _sha256(args.partitions),
            "research_sha256": {name: _sha256(ROOT / name) for name in RESEARCH_SOURCES},
            "torch": _optional_version("torch"),
        },
        outputs=[args.output.name],
    )
    return 1 if result["errors"] or not result["runs"] else 0


def x_main__mutmut_154(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=Path, required=True)
    parser.add_argument("--partitions", type=Path, required=True)
    parser.add_argument("--label-column", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--detectors", nargs="+", required=True)
    args = parser.parse_args(argv)
    record_path = args.output.with_suffix(".record.json")
    if args.output.exists() or record_path.exists():
        raise FileExistsError("choose unused output and record paths")
    manifest = json.loads(args.partitions.read_text())
    if manifest["schema_version"] != 1 or manifest["input_sha256"] != _sha256(args.csv):
        raise ValueError("partition manifest version or source hash differs")
    with args.csv.open(newline="") as stream:
        header = next(csv.reader(stream))
    if len(set(header)) != len(header):
        raise ValueError("duplicate CSV column names are not accepted")
    frame = pd.read_csv(args.csv, dtype=str)
    if manifest["row_count"] != len(frame):
        raise ValueError("partition manifest row count differs")
    labels = pd.to_numeric(frame.pop(args.label_column), errors="raise").to_numpy()
    result = evaluate_frozen(
        frame, labels, manifest["partitions"], seed=manifest["seed"], methods=args.detectors
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    write_record(
        record_path,
        experiment=PROTOCOL,
        seeds=[manifest["seed"]],
        dataset=args.csv.name,
        data_path=args.csv,
        settings={
            "protocol": PROTOCOL,
            "XXexploratoryXX": True,
            "label_column": args.label_column,
            "detectors": args.detectors,
            "partition_sha256": _sha256(args.partitions),
            "research_sha256": {name: _sha256(ROOT / name) for name in RESEARCH_SOURCES},
            "torch": _optional_version("torch"),
        },
        outputs=[args.output.name],
    )
    return 1 if result["errors"] or not result["runs"] else 0


def x_main__mutmut_155(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=Path, required=True)
    parser.add_argument("--partitions", type=Path, required=True)
    parser.add_argument("--label-column", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--detectors", nargs="+", required=True)
    args = parser.parse_args(argv)
    record_path = args.output.with_suffix(".record.json")
    if args.output.exists() or record_path.exists():
        raise FileExistsError("choose unused output and record paths")
    manifest = json.loads(args.partitions.read_text())
    if manifest["schema_version"] != 1 or manifest["input_sha256"] != _sha256(args.csv):
        raise ValueError("partition manifest version or source hash differs")
    with args.csv.open(newline="") as stream:
        header = next(csv.reader(stream))
    if len(set(header)) != len(header):
        raise ValueError("duplicate CSV column names are not accepted")
    frame = pd.read_csv(args.csv, dtype=str)
    if manifest["row_count"] != len(frame):
        raise ValueError("partition manifest row count differs")
    labels = pd.to_numeric(frame.pop(args.label_column), errors="raise").to_numpy()
    result = evaluate_frozen(
        frame, labels, manifest["partitions"], seed=manifest["seed"], methods=args.detectors
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    write_record(
        record_path,
        experiment=PROTOCOL,
        seeds=[manifest["seed"]],
        dataset=args.csv.name,
        data_path=args.csv,
        settings={
            "protocol": PROTOCOL,
            "EXPLORATORY": True,
            "label_column": args.label_column,
            "detectors": args.detectors,
            "partition_sha256": _sha256(args.partitions),
            "research_sha256": {name: _sha256(ROOT / name) for name in RESEARCH_SOURCES},
            "torch": _optional_version("torch"),
        },
        outputs=[args.output.name],
    )
    return 1 if result["errors"] or not result["runs"] else 0


def x_main__mutmut_156(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=Path, required=True)
    parser.add_argument("--partitions", type=Path, required=True)
    parser.add_argument("--label-column", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--detectors", nargs="+", required=True)
    args = parser.parse_args(argv)
    record_path = args.output.with_suffix(".record.json")
    if args.output.exists() or record_path.exists():
        raise FileExistsError("choose unused output and record paths")
    manifest = json.loads(args.partitions.read_text())
    if manifest["schema_version"] != 1 or manifest["input_sha256"] != _sha256(args.csv):
        raise ValueError("partition manifest version or source hash differs")
    with args.csv.open(newline="") as stream:
        header = next(csv.reader(stream))
    if len(set(header)) != len(header):
        raise ValueError("duplicate CSV column names are not accepted")
    frame = pd.read_csv(args.csv, dtype=str)
    if manifest["row_count"] != len(frame):
        raise ValueError("partition manifest row count differs")
    labels = pd.to_numeric(frame.pop(args.label_column), errors="raise").to_numpy()
    result = evaluate_frozen(
        frame, labels, manifest["partitions"], seed=manifest["seed"], methods=args.detectors
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    write_record(
        record_path,
        experiment=PROTOCOL,
        seeds=[manifest["seed"]],
        dataset=args.csv.name,
        data_path=args.csv,
        settings={
            "protocol": PROTOCOL,
            "exploratory": False,
            "label_column": args.label_column,
            "detectors": args.detectors,
            "partition_sha256": _sha256(args.partitions),
            "research_sha256": {name: _sha256(ROOT / name) for name in RESEARCH_SOURCES},
            "torch": _optional_version("torch"),
        },
        outputs=[args.output.name],
    )
    return 1 if result["errors"] or not result["runs"] else 0


def x_main__mutmut_157(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=Path, required=True)
    parser.add_argument("--partitions", type=Path, required=True)
    parser.add_argument("--label-column", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--detectors", nargs="+", required=True)
    args = parser.parse_args(argv)
    record_path = args.output.with_suffix(".record.json")
    if args.output.exists() or record_path.exists():
        raise FileExistsError("choose unused output and record paths")
    manifest = json.loads(args.partitions.read_text())
    if manifest["schema_version"] != 1 or manifest["input_sha256"] != _sha256(args.csv):
        raise ValueError("partition manifest version or source hash differs")
    with args.csv.open(newline="") as stream:
        header = next(csv.reader(stream))
    if len(set(header)) != len(header):
        raise ValueError("duplicate CSV column names are not accepted")
    frame = pd.read_csv(args.csv, dtype=str)
    if manifest["row_count"] != len(frame):
        raise ValueError("partition manifest row count differs")
    labels = pd.to_numeric(frame.pop(args.label_column), errors="raise").to_numpy()
    result = evaluate_frozen(
        frame, labels, manifest["partitions"], seed=manifest["seed"], methods=args.detectors
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    write_record(
        record_path,
        experiment=PROTOCOL,
        seeds=[manifest["seed"]],
        dataset=args.csv.name,
        data_path=args.csv,
        settings={
            "protocol": PROTOCOL,
            "exploratory": True,
            "XXlabel_columnXX": args.label_column,
            "detectors": args.detectors,
            "partition_sha256": _sha256(args.partitions),
            "research_sha256": {name: _sha256(ROOT / name) for name in RESEARCH_SOURCES},
            "torch": _optional_version("torch"),
        },
        outputs=[args.output.name],
    )
    return 1 if result["errors"] or not result["runs"] else 0


def x_main__mutmut_158(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=Path, required=True)
    parser.add_argument("--partitions", type=Path, required=True)
    parser.add_argument("--label-column", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--detectors", nargs="+", required=True)
    args = parser.parse_args(argv)
    record_path = args.output.with_suffix(".record.json")
    if args.output.exists() or record_path.exists():
        raise FileExistsError("choose unused output and record paths")
    manifest = json.loads(args.partitions.read_text())
    if manifest["schema_version"] != 1 or manifest["input_sha256"] != _sha256(args.csv):
        raise ValueError("partition manifest version or source hash differs")
    with args.csv.open(newline="") as stream:
        header = next(csv.reader(stream))
    if len(set(header)) != len(header):
        raise ValueError("duplicate CSV column names are not accepted")
    frame = pd.read_csv(args.csv, dtype=str)
    if manifest["row_count"] != len(frame):
        raise ValueError("partition manifest row count differs")
    labels = pd.to_numeric(frame.pop(args.label_column), errors="raise").to_numpy()
    result = evaluate_frozen(
        frame, labels, manifest["partitions"], seed=manifest["seed"], methods=args.detectors
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    write_record(
        record_path,
        experiment=PROTOCOL,
        seeds=[manifest["seed"]],
        dataset=args.csv.name,
        data_path=args.csv,
        settings={
            "protocol": PROTOCOL,
            "exploratory": True,
            "LABEL_COLUMN": args.label_column,
            "detectors": args.detectors,
            "partition_sha256": _sha256(args.partitions),
            "research_sha256": {name: _sha256(ROOT / name) for name in RESEARCH_SOURCES},
            "torch": _optional_version("torch"),
        },
        outputs=[args.output.name],
    )
    return 1 if result["errors"] or not result["runs"] else 0


def x_main__mutmut_159(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=Path, required=True)
    parser.add_argument("--partitions", type=Path, required=True)
    parser.add_argument("--label-column", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--detectors", nargs="+", required=True)
    args = parser.parse_args(argv)
    record_path = args.output.with_suffix(".record.json")
    if args.output.exists() or record_path.exists():
        raise FileExistsError("choose unused output and record paths")
    manifest = json.loads(args.partitions.read_text())
    if manifest["schema_version"] != 1 or manifest["input_sha256"] != _sha256(args.csv):
        raise ValueError("partition manifest version or source hash differs")
    with args.csv.open(newline="") as stream:
        header = next(csv.reader(stream))
    if len(set(header)) != len(header):
        raise ValueError("duplicate CSV column names are not accepted")
    frame = pd.read_csv(args.csv, dtype=str)
    if manifest["row_count"] != len(frame):
        raise ValueError("partition manifest row count differs")
    labels = pd.to_numeric(frame.pop(args.label_column), errors="raise").to_numpy()
    result = evaluate_frozen(
        frame, labels, manifest["partitions"], seed=manifest["seed"], methods=args.detectors
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    write_record(
        record_path,
        experiment=PROTOCOL,
        seeds=[manifest["seed"]],
        dataset=args.csv.name,
        data_path=args.csv,
        settings={
            "protocol": PROTOCOL,
            "exploratory": True,
            "label_column": args.label_column,
            "XXdetectorsXX": args.detectors,
            "partition_sha256": _sha256(args.partitions),
            "research_sha256": {name: _sha256(ROOT / name) for name in RESEARCH_SOURCES},
            "torch": _optional_version("torch"),
        },
        outputs=[args.output.name],
    )
    return 1 if result["errors"] or not result["runs"] else 0


def x_main__mutmut_160(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=Path, required=True)
    parser.add_argument("--partitions", type=Path, required=True)
    parser.add_argument("--label-column", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--detectors", nargs="+", required=True)
    args = parser.parse_args(argv)
    record_path = args.output.with_suffix(".record.json")
    if args.output.exists() or record_path.exists():
        raise FileExistsError("choose unused output and record paths")
    manifest = json.loads(args.partitions.read_text())
    if manifest["schema_version"] != 1 or manifest["input_sha256"] != _sha256(args.csv):
        raise ValueError("partition manifest version or source hash differs")
    with args.csv.open(newline="") as stream:
        header = next(csv.reader(stream))
    if len(set(header)) != len(header):
        raise ValueError("duplicate CSV column names are not accepted")
    frame = pd.read_csv(args.csv, dtype=str)
    if manifest["row_count"] != len(frame):
        raise ValueError("partition manifest row count differs")
    labels = pd.to_numeric(frame.pop(args.label_column), errors="raise").to_numpy()
    result = evaluate_frozen(
        frame, labels, manifest["partitions"], seed=manifest["seed"], methods=args.detectors
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    write_record(
        record_path,
        experiment=PROTOCOL,
        seeds=[manifest["seed"]],
        dataset=args.csv.name,
        data_path=args.csv,
        settings={
            "protocol": PROTOCOL,
            "exploratory": True,
            "label_column": args.label_column,
            "DETECTORS": args.detectors,
            "partition_sha256": _sha256(args.partitions),
            "research_sha256": {name: _sha256(ROOT / name) for name in RESEARCH_SOURCES},
            "torch": _optional_version("torch"),
        },
        outputs=[args.output.name],
    )
    return 1 if result["errors"] or not result["runs"] else 0


def x_main__mutmut_161(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=Path, required=True)
    parser.add_argument("--partitions", type=Path, required=True)
    parser.add_argument("--label-column", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--detectors", nargs="+", required=True)
    args = parser.parse_args(argv)
    record_path = args.output.with_suffix(".record.json")
    if args.output.exists() or record_path.exists():
        raise FileExistsError("choose unused output and record paths")
    manifest = json.loads(args.partitions.read_text())
    if manifest["schema_version"] != 1 or manifest["input_sha256"] != _sha256(args.csv):
        raise ValueError("partition manifest version or source hash differs")
    with args.csv.open(newline="") as stream:
        header = next(csv.reader(stream))
    if len(set(header)) != len(header):
        raise ValueError("duplicate CSV column names are not accepted")
    frame = pd.read_csv(args.csv, dtype=str)
    if manifest["row_count"] != len(frame):
        raise ValueError("partition manifest row count differs")
    labels = pd.to_numeric(frame.pop(args.label_column), errors="raise").to_numpy()
    result = evaluate_frozen(
        frame, labels, manifest["partitions"], seed=manifest["seed"], methods=args.detectors
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    write_record(
        record_path,
        experiment=PROTOCOL,
        seeds=[manifest["seed"]],
        dataset=args.csv.name,
        data_path=args.csv,
        settings={
            "protocol": PROTOCOL,
            "exploratory": True,
            "label_column": args.label_column,
            "detectors": args.detectors,
            "XXpartition_sha256XX": _sha256(args.partitions),
            "research_sha256": {name: _sha256(ROOT / name) for name in RESEARCH_SOURCES},
            "torch": _optional_version("torch"),
        },
        outputs=[args.output.name],
    )
    return 1 if result["errors"] or not result["runs"] else 0


def x_main__mutmut_162(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=Path, required=True)
    parser.add_argument("--partitions", type=Path, required=True)
    parser.add_argument("--label-column", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--detectors", nargs="+", required=True)
    args = parser.parse_args(argv)
    record_path = args.output.with_suffix(".record.json")
    if args.output.exists() or record_path.exists():
        raise FileExistsError("choose unused output and record paths")
    manifest = json.loads(args.partitions.read_text())
    if manifest["schema_version"] != 1 or manifest["input_sha256"] != _sha256(args.csv):
        raise ValueError("partition manifest version or source hash differs")
    with args.csv.open(newline="") as stream:
        header = next(csv.reader(stream))
    if len(set(header)) != len(header):
        raise ValueError("duplicate CSV column names are not accepted")
    frame = pd.read_csv(args.csv, dtype=str)
    if manifest["row_count"] != len(frame):
        raise ValueError("partition manifest row count differs")
    labels = pd.to_numeric(frame.pop(args.label_column), errors="raise").to_numpy()
    result = evaluate_frozen(
        frame, labels, manifest["partitions"], seed=manifest["seed"], methods=args.detectors
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    write_record(
        record_path,
        experiment=PROTOCOL,
        seeds=[manifest["seed"]],
        dataset=args.csv.name,
        data_path=args.csv,
        settings={
            "protocol": PROTOCOL,
            "exploratory": True,
            "label_column": args.label_column,
            "detectors": args.detectors,
            "PARTITION_SHA256": _sha256(args.partitions),
            "research_sha256": {name: _sha256(ROOT / name) for name in RESEARCH_SOURCES},
            "torch": _optional_version("torch"),
        },
        outputs=[args.output.name],
    )
    return 1 if result["errors"] or not result["runs"] else 0


def x_main__mutmut_163(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=Path, required=True)
    parser.add_argument("--partitions", type=Path, required=True)
    parser.add_argument("--label-column", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--detectors", nargs="+", required=True)
    args = parser.parse_args(argv)
    record_path = args.output.with_suffix(".record.json")
    if args.output.exists() or record_path.exists():
        raise FileExistsError("choose unused output and record paths")
    manifest = json.loads(args.partitions.read_text())
    if manifest["schema_version"] != 1 or manifest["input_sha256"] != _sha256(args.csv):
        raise ValueError("partition manifest version or source hash differs")
    with args.csv.open(newline="") as stream:
        header = next(csv.reader(stream))
    if len(set(header)) != len(header):
        raise ValueError("duplicate CSV column names are not accepted")
    frame = pd.read_csv(args.csv, dtype=str)
    if manifest["row_count"] != len(frame):
        raise ValueError("partition manifest row count differs")
    labels = pd.to_numeric(frame.pop(args.label_column), errors="raise").to_numpy()
    result = evaluate_frozen(
        frame, labels, manifest["partitions"], seed=manifest["seed"], methods=args.detectors
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    write_record(
        record_path,
        experiment=PROTOCOL,
        seeds=[manifest["seed"]],
        dataset=args.csv.name,
        data_path=args.csv,
        settings={
            "protocol": PROTOCOL,
            "exploratory": True,
            "label_column": args.label_column,
            "detectors": args.detectors,
            "partition_sha256": _sha256(None),
            "research_sha256": {name: _sha256(ROOT / name) for name in RESEARCH_SOURCES},
            "torch": _optional_version("torch"),
        },
        outputs=[args.output.name],
    )
    return 1 if result["errors"] or not result["runs"] else 0


def x_main__mutmut_164(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=Path, required=True)
    parser.add_argument("--partitions", type=Path, required=True)
    parser.add_argument("--label-column", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--detectors", nargs="+", required=True)
    args = parser.parse_args(argv)
    record_path = args.output.with_suffix(".record.json")
    if args.output.exists() or record_path.exists():
        raise FileExistsError("choose unused output and record paths")
    manifest = json.loads(args.partitions.read_text())
    if manifest["schema_version"] != 1 or manifest["input_sha256"] != _sha256(args.csv):
        raise ValueError("partition manifest version or source hash differs")
    with args.csv.open(newline="") as stream:
        header = next(csv.reader(stream))
    if len(set(header)) != len(header):
        raise ValueError("duplicate CSV column names are not accepted")
    frame = pd.read_csv(args.csv, dtype=str)
    if manifest["row_count"] != len(frame):
        raise ValueError("partition manifest row count differs")
    labels = pd.to_numeric(frame.pop(args.label_column), errors="raise").to_numpy()
    result = evaluate_frozen(
        frame, labels, manifest["partitions"], seed=manifest["seed"], methods=args.detectors
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    write_record(
        record_path,
        experiment=PROTOCOL,
        seeds=[manifest["seed"]],
        dataset=args.csv.name,
        data_path=args.csv,
        settings={
            "protocol": PROTOCOL,
            "exploratory": True,
            "label_column": args.label_column,
            "detectors": args.detectors,
            "partition_sha256": _sha256(args.partitions),
            "XXresearch_sha256XX": {name: _sha256(ROOT / name) for name in RESEARCH_SOURCES},
            "torch": _optional_version("torch"),
        },
        outputs=[args.output.name],
    )
    return 1 if result["errors"] or not result["runs"] else 0


def x_main__mutmut_165(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=Path, required=True)
    parser.add_argument("--partitions", type=Path, required=True)
    parser.add_argument("--label-column", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--detectors", nargs="+", required=True)
    args = parser.parse_args(argv)
    record_path = args.output.with_suffix(".record.json")
    if args.output.exists() or record_path.exists():
        raise FileExistsError("choose unused output and record paths")
    manifest = json.loads(args.partitions.read_text())
    if manifest["schema_version"] != 1 or manifest["input_sha256"] != _sha256(args.csv):
        raise ValueError("partition manifest version or source hash differs")
    with args.csv.open(newline="") as stream:
        header = next(csv.reader(stream))
    if len(set(header)) != len(header):
        raise ValueError("duplicate CSV column names are not accepted")
    frame = pd.read_csv(args.csv, dtype=str)
    if manifest["row_count"] != len(frame):
        raise ValueError("partition manifest row count differs")
    labels = pd.to_numeric(frame.pop(args.label_column), errors="raise").to_numpy()
    result = evaluate_frozen(
        frame, labels, manifest["partitions"], seed=manifest["seed"], methods=args.detectors
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    write_record(
        record_path,
        experiment=PROTOCOL,
        seeds=[manifest["seed"]],
        dataset=args.csv.name,
        data_path=args.csv,
        settings={
            "protocol": PROTOCOL,
            "exploratory": True,
            "label_column": args.label_column,
            "detectors": args.detectors,
            "partition_sha256": _sha256(args.partitions),
            "RESEARCH_SHA256": {name: _sha256(ROOT / name) for name in RESEARCH_SOURCES},
            "torch": _optional_version("torch"),
        },
        outputs=[args.output.name],
    )
    return 1 if result["errors"] or not result["runs"] else 0


def x_main__mutmut_166(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=Path, required=True)
    parser.add_argument("--partitions", type=Path, required=True)
    parser.add_argument("--label-column", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--detectors", nargs="+", required=True)
    args = parser.parse_args(argv)
    record_path = args.output.with_suffix(".record.json")
    if args.output.exists() or record_path.exists():
        raise FileExistsError("choose unused output and record paths")
    manifest = json.loads(args.partitions.read_text())
    if manifest["schema_version"] != 1 or manifest["input_sha256"] != _sha256(args.csv):
        raise ValueError("partition manifest version or source hash differs")
    with args.csv.open(newline="") as stream:
        header = next(csv.reader(stream))
    if len(set(header)) != len(header):
        raise ValueError("duplicate CSV column names are not accepted")
    frame = pd.read_csv(args.csv, dtype=str)
    if manifest["row_count"] != len(frame):
        raise ValueError("partition manifest row count differs")
    labels = pd.to_numeric(frame.pop(args.label_column), errors="raise").to_numpy()
    result = evaluate_frozen(
        frame, labels, manifest["partitions"], seed=manifest["seed"], methods=args.detectors
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    write_record(
        record_path,
        experiment=PROTOCOL,
        seeds=[manifest["seed"]],
        dataset=args.csv.name,
        data_path=args.csv,
        settings={
            "protocol": PROTOCOL,
            "exploratory": True,
            "label_column": args.label_column,
            "detectors": args.detectors,
            "partition_sha256": _sha256(args.partitions),
            "research_sha256": {name: _sha256(None) for name in RESEARCH_SOURCES},
            "torch": _optional_version("torch"),
        },
        outputs=[args.output.name],
    )
    return 1 if result["errors"] or not result["runs"] else 0


def x_main__mutmut_167(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=Path, required=True)
    parser.add_argument("--partitions", type=Path, required=True)
    parser.add_argument("--label-column", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--detectors", nargs="+", required=True)
    args = parser.parse_args(argv)
    record_path = args.output.with_suffix(".record.json")
    if args.output.exists() or record_path.exists():
        raise FileExistsError("choose unused output and record paths")
    manifest = json.loads(args.partitions.read_text())
    if manifest["schema_version"] != 1 or manifest["input_sha256"] != _sha256(args.csv):
        raise ValueError("partition manifest version or source hash differs")
    with args.csv.open(newline="") as stream:
        header = next(csv.reader(stream))
    if len(set(header)) != len(header):
        raise ValueError("duplicate CSV column names are not accepted")
    frame = pd.read_csv(args.csv, dtype=str)
    if manifest["row_count"] != len(frame):
        raise ValueError("partition manifest row count differs")
    labels = pd.to_numeric(frame.pop(args.label_column), errors="raise").to_numpy()
    result = evaluate_frozen(
        frame, labels, manifest["partitions"], seed=manifest["seed"], methods=args.detectors
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    write_record(
        record_path,
        experiment=PROTOCOL,
        seeds=[manifest["seed"]],
        dataset=args.csv.name,
        data_path=args.csv,
        settings={
            "protocol": PROTOCOL,
            "exploratory": True,
            "label_column": args.label_column,
            "detectors": args.detectors,
            "partition_sha256": _sha256(args.partitions),
            "research_sha256": {name: _sha256(ROOT * name) for name in RESEARCH_SOURCES},
            "torch": _optional_version("torch"),
        },
        outputs=[args.output.name],
    )
    return 1 if result["errors"] or not result["runs"] else 0


def x_main__mutmut_168(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=Path, required=True)
    parser.add_argument("--partitions", type=Path, required=True)
    parser.add_argument("--label-column", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--detectors", nargs="+", required=True)
    args = parser.parse_args(argv)
    record_path = args.output.with_suffix(".record.json")
    if args.output.exists() or record_path.exists():
        raise FileExistsError("choose unused output and record paths")
    manifest = json.loads(args.partitions.read_text())
    if manifest["schema_version"] != 1 or manifest["input_sha256"] != _sha256(args.csv):
        raise ValueError("partition manifest version or source hash differs")
    with args.csv.open(newline="") as stream:
        header = next(csv.reader(stream))
    if len(set(header)) != len(header):
        raise ValueError("duplicate CSV column names are not accepted")
    frame = pd.read_csv(args.csv, dtype=str)
    if manifest["row_count"] != len(frame):
        raise ValueError("partition manifest row count differs")
    labels = pd.to_numeric(frame.pop(args.label_column), errors="raise").to_numpy()
    result = evaluate_frozen(
        frame, labels, manifest["partitions"], seed=manifest["seed"], methods=args.detectors
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    write_record(
        record_path,
        experiment=PROTOCOL,
        seeds=[manifest["seed"]],
        dataset=args.csv.name,
        data_path=args.csv,
        settings={
            "protocol": PROTOCOL,
            "exploratory": True,
            "label_column": args.label_column,
            "detectors": args.detectors,
            "partition_sha256": _sha256(args.partitions),
            "research_sha256": {name: _sha256(ROOT / name) for name in RESEARCH_SOURCES},
            "XXtorchXX": _optional_version("torch"),
        },
        outputs=[args.output.name],
    )
    return 1 if result["errors"] or not result["runs"] else 0


def x_main__mutmut_169(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=Path, required=True)
    parser.add_argument("--partitions", type=Path, required=True)
    parser.add_argument("--label-column", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--detectors", nargs="+", required=True)
    args = parser.parse_args(argv)
    record_path = args.output.with_suffix(".record.json")
    if args.output.exists() or record_path.exists():
        raise FileExistsError("choose unused output and record paths")
    manifest = json.loads(args.partitions.read_text())
    if manifest["schema_version"] != 1 or manifest["input_sha256"] != _sha256(args.csv):
        raise ValueError("partition manifest version or source hash differs")
    with args.csv.open(newline="") as stream:
        header = next(csv.reader(stream))
    if len(set(header)) != len(header):
        raise ValueError("duplicate CSV column names are not accepted")
    frame = pd.read_csv(args.csv, dtype=str)
    if manifest["row_count"] != len(frame):
        raise ValueError("partition manifest row count differs")
    labels = pd.to_numeric(frame.pop(args.label_column), errors="raise").to_numpy()
    result = evaluate_frozen(
        frame, labels, manifest["partitions"], seed=manifest["seed"], methods=args.detectors
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    write_record(
        record_path,
        experiment=PROTOCOL,
        seeds=[manifest["seed"]],
        dataset=args.csv.name,
        data_path=args.csv,
        settings={
            "protocol": PROTOCOL,
            "exploratory": True,
            "label_column": args.label_column,
            "detectors": args.detectors,
            "partition_sha256": _sha256(args.partitions),
            "research_sha256": {name: _sha256(ROOT / name) for name in RESEARCH_SOURCES},
            "TORCH": _optional_version("torch"),
        },
        outputs=[args.output.name],
    )
    return 1 if result["errors"] or not result["runs"] else 0


def x_main__mutmut_170(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=Path, required=True)
    parser.add_argument("--partitions", type=Path, required=True)
    parser.add_argument("--label-column", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--detectors", nargs="+", required=True)
    args = parser.parse_args(argv)
    record_path = args.output.with_suffix(".record.json")
    if args.output.exists() or record_path.exists():
        raise FileExistsError("choose unused output and record paths")
    manifest = json.loads(args.partitions.read_text())
    if manifest["schema_version"] != 1 or manifest["input_sha256"] != _sha256(args.csv):
        raise ValueError("partition manifest version or source hash differs")
    with args.csv.open(newline="") as stream:
        header = next(csv.reader(stream))
    if len(set(header)) != len(header):
        raise ValueError("duplicate CSV column names are not accepted")
    frame = pd.read_csv(args.csv, dtype=str)
    if manifest["row_count"] != len(frame):
        raise ValueError("partition manifest row count differs")
    labels = pd.to_numeric(frame.pop(args.label_column), errors="raise").to_numpy()
    result = evaluate_frozen(
        frame, labels, manifest["partitions"], seed=manifest["seed"], methods=args.detectors
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    write_record(
        record_path,
        experiment=PROTOCOL,
        seeds=[manifest["seed"]],
        dataset=args.csv.name,
        data_path=args.csv,
        settings={
            "protocol": PROTOCOL,
            "exploratory": True,
            "label_column": args.label_column,
            "detectors": args.detectors,
            "partition_sha256": _sha256(args.partitions),
            "research_sha256": {name: _sha256(ROOT / name) for name in RESEARCH_SOURCES},
            "torch": _optional_version(None),
        },
        outputs=[args.output.name],
    )
    return 1 if result["errors"] or not result["runs"] else 0


def x_main__mutmut_171(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=Path, required=True)
    parser.add_argument("--partitions", type=Path, required=True)
    parser.add_argument("--label-column", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--detectors", nargs="+", required=True)
    args = parser.parse_args(argv)
    record_path = args.output.with_suffix(".record.json")
    if args.output.exists() or record_path.exists():
        raise FileExistsError("choose unused output and record paths")
    manifest = json.loads(args.partitions.read_text())
    if manifest["schema_version"] != 1 or manifest["input_sha256"] != _sha256(args.csv):
        raise ValueError("partition manifest version or source hash differs")
    with args.csv.open(newline="") as stream:
        header = next(csv.reader(stream))
    if len(set(header)) != len(header):
        raise ValueError("duplicate CSV column names are not accepted")
    frame = pd.read_csv(args.csv, dtype=str)
    if manifest["row_count"] != len(frame):
        raise ValueError("partition manifest row count differs")
    labels = pd.to_numeric(frame.pop(args.label_column), errors="raise").to_numpy()
    result = evaluate_frozen(
        frame, labels, manifest["partitions"], seed=manifest["seed"], methods=args.detectors
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    write_record(
        record_path,
        experiment=PROTOCOL,
        seeds=[manifest["seed"]],
        dataset=args.csv.name,
        data_path=args.csv,
        settings={
            "protocol": PROTOCOL,
            "exploratory": True,
            "label_column": args.label_column,
            "detectors": args.detectors,
            "partition_sha256": _sha256(args.partitions),
            "research_sha256": {name: _sha256(ROOT / name) for name in RESEARCH_SOURCES},
            "torch": _optional_version("XXtorchXX"),
        },
        outputs=[args.output.name],
    )
    return 1 if result["errors"] or not result["runs"] else 0


def x_main__mutmut_172(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=Path, required=True)
    parser.add_argument("--partitions", type=Path, required=True)
    parser.add_argument("--label-column", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--detectors", nargs="+", required=True)
    args = parser.parse_args(argv)
    record_path = args.output.with_suffix(".record.json")
    if args.output.exists() or record_path.exists():
        raise FileExistsError("choose unused output and record paths")
    manifest = json.loads(args.partitions.read_text())
    if manifest["schema_version"] != 1 or manifest["input_sha256"] != _sha256(args.csv):
        raise ValueError("partition manifest version or source hash differs")
    with args.csv.open(newline="") as stream:
        header = next(csv.reader(stream))
    if len(set(header)) != len(header):
        raise ValueError("duplicate CSV column names are not accepted")
    frame = pd.read_csv(args.csv, dtype=str)
    if manifest["row_count"] != len(frame):
        raise ValueError("partition manifest row count differs")
    labels = pd.to_numeric(frame.pop(args.label_column), errors="raise").to_numpy()
    result = evaluate_frozen(
        frame, labels, manifest["partitions"], seed=manifest["seed"], methods=args.detectors
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    write_record(
        record_path,
        experiment=PROTOCOL,
        seeds=[manifest["seed"]],
        dataset=args.csv.name,
        data_path=args.csv,
        settings={
            "protocol": PROTOCOL,
            "exploratory": True,
            "label_column": args.label_column,
            "detectors": args.detectors,
            "partition_sha256": _sha256(args.partitions),
            "research_sha256": {name: _sha256(ROOT / name) for name in RESEARCH_SOURCES},
            "torch": _optional_version("TORCH"),
        },
        outputs=[args.output.name],
    )
    return 1 if result["errors"] or not result["runs"] else 0


def x_main__mutmut_173(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=Path, required=True)
    parser.add_argument("--partitions", type=Path, required=True)
    parser.add_argument("--label-column", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--detectors", nargs="+", required=True)
    args = parser.parse_args(argv)
    record_path = args.output.with_suffix(".record.json")
    if args.output.exists() or record_path.exists():
        raise FileExistsError("choose unused output and record paths")
    manifest = json.loads(args.partitions.read_text())
    if manifest["schema_version"] != 1 or manifest["input_sha256"] != _sha256(args.csv):
        raise ValueError("partition manifest version or source hash differs")
    with args.csv.open(newline="") as stream:
        header = next(csv.reader(stream))
    if len(set(header)) != len(header):
        raise ValueError("duplicate CSV column names are not accepted")
    frame = pd.read_csv(args.csv, dtype=str)
    if manifest["row_count"] != len(frame):
        raise ValueError("partition manifest row count differs")
    labels = pd.to_numeric(frame.pop(args.label_column), errors="raise").to_numpy()
    result = evaluate_frozen(
        frame, labels, manifest["partitions"], seed=manifest["seed"], methods=args.detectors
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    write_record(
        record_path,
        experiment=PROTOCOL,
        seeds=[manifest["seed"]],
        dataset=args.csv.name,
        data_path=args.csv,
        settings={
            "protocol": PROTOCOL,
            "exploratory": True,
            "label_column": args.label_column,
            "detectors": args.detectors,
            "partition_sha256": _sha256(args.partitions),
            "research_sha256": {name: _sha256(ROOT / name) for name in RESEARCH_SOURCES},
            "torch": _optional_version("torch"),
        },
        outputs=[args.output.name],
    )
    return 1 if (result["errors"] or not result["runs"]) and False else 0


def x_main__mutmut_174(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=Path, required=True)
    parser.add_argument("--partitions", type=Path, required=True)
    parser.add_argument("--label-column", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--detectors", nargs="+", required=True)
    args = parser.parse_args(argv)
    record_path = args.output.with_suffix(".record.json")
    if args.output.exists() or record_path.exists():
        raise FileExistsError("choose unused output and record paths")
    manifest = json.loads(args.partitions.read_text())
    if manifest["schema_version"] != 1 or manifest["input_sha256"] != _sha256(args.csv):
        raise ValueError("partition manifest version or source hash differs")
    with args.csv.open(newline="") as stream:
        header = next(csv.reader(stream))
    if len(set(header)) != len(header):
        raise ValueError("duplicate CSV column names are not accepted")
    frame = pd.read_csv(args.csv, dtype=str)
    if manifest["row_count"] != len(frame):
        raise ValueError("partition manifest row count differs")
    labels = pd.to_numeric(frame.pop(args.label_column), errors="raise").to_numpy()
    result = evaluate_frozen(
        frame, labels, manifest["partitions"], seed=manifest["seed"], methods=args.detectors
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    write_record(
        record_path,
        experiment=PROTOCOL,
        seeds=[manifest["seed"]],
        dataset=args.csv.name,
        data_path=args.csv,
        settings={
            "protocol": PROTOCOL,
            "exploratory": True,
            "label_column": args.label_column,
            "detectors": args.detectors,
            "partition_sha256": _sha256(args.partitions),
            "research_sha256": {name: _sha256(ROOT / name) for name in RESEARCH_SOURCES},
            "torch": _optional_version("torch"),
        },
        outputs=[args.output.name],
    )
    return 1 if (result["errors"] or not result["runs"]) or True else 0


def x_main__mutmut_175(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=Path, required=True)
    parser.add_argument("--partitions", type=Path, required=True)
    parser.add_argument("--label-column", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--detectors", nargs="+", required=True)
    args = parser.parse_args(argv)
    record_path = args.output.with_suffix(".record.json")
    if args.output.exists() or record_path.exists():
        raise FileExistsError("choose unused output and record paths")
    manifest = json.loads(args.partitions.read_text())
    if manifest["schema_version"] != 1 or manifest["input_sha256"] != _sha256(args.csv):
        raise ValueError("partition manifest version or source hash differs")
    with args.csv.open(newline="") as stream:
        header = next(csv.reader(stream))
    if len(set(header)) != len(header):
        raise ValueError("duplicate CSV column names are not accepted")
    frame = pd.read_csv(args.csv, dtype=str)
    if manifest["row_count"] != len(frame):
        raise ValueError("partition manifest row count differs")
    labels = pd.to_numeric(frame.pop(args.label_column), errors="raise").to_numpy()
    result = evaluate_frozen(
        frame, labels, manifest["partitions"], seed=manifest["seed"], methods=args.detectors
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    write_record(
        record_path,
        experiment=PROTOCOL,
        seeds=[manifest["seed"]],
        dataset=args.csv.name,
        data_path=args.csv,
        settings={
            "protocol": PROTOCOL,
            "exploratory": True,
            "label_column": args.label_column,
            "detectors": args.detectors,
            "partition_sha256": _sha256(args.partitions),
            "research_sha256": {name: _sha256(ROOT / name) for name in RESEARCH_SOURCES},
            "torch": _optional_version("torch"),
        },
        outputs=[args.output.name],
    )
    return 2 if result["errors"] or not result["runs"] else 0


def x_main__mutmut_176(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=Path, required=True)
    parser.add_argument("--partitions", type=Path, required=True)
    parser.add_argument("--label-column", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--detectors", nargs="+", required=True)
    args = parser.parse_args(argv)
    record_path = args.output.with_suffix(".record.json")
    if args.output.exists() or record_path.exists():
        raise FileExistsError("choose unused output and record paths")
    manifest = json.loads(args.partitions.read_text())
    if manifest["schema_version"] != 1 or manifest["input_sha256"] != _sha256(args.csv):
        raise ValueError("partition manifest version or source hash differs")
    with args.csv.open(newline="") as stream:
        header = next(csv.reader(stream))
    if len(set(header)) != len(header):
        raise ValueError("duplicate CSV column names are not accepted")
    frame = pd.read_csv(args.csv, dtype=str)
    if manifest["row_count"] != len(frame):
        raise ValueError("partition manifest row count differs")
    labels = pd.to_numeric(frame.pop(args.label_column), errors="raise").to_numpy()
    result = evaluate_frozen(
        frame, labels, manifest["partitions"], seed=manifest["seed"], methods=args.detectors
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    write_record(
        record_path,
        experiment=PROTOCOL,
        seeds=[manifest["seed"]],
        dataset=args.csv.name,
        data_path=args.csv,
        settings={
            "protocol": PROTOCOL,
            "exploratory": True,
            "label_column": args.label_column,
            "detectors": args.detectors,
            "partition_sha256": _sha256(args.partitions),
            "research_sha256": {name: _sha256(ROOT / name) for name in RESEARCH_SOURCES},
            "torch": _optional_version("torch"),
        },
        outputs=[args.output.name],
    )
    return 1 if result["errors"] and not result["runs"] else 0


def x_main__mutmut_177(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=Path, required=True)
    parser.add_argument("--partitions", type=Path, required=True)
    parser.add_argument("--label-column", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--detectors", nargs="+", required=True)
    args = parser.parse_args(argv)
    record_path = args.output.with_suffix(".record.json")
    if args.output.exists() or record_path.exists():
        raise FileExistsError("choose unused output and record paths")
    manifest = json.loads(args.partitions.read_text())
    if manifest["schema_version"] != 1 or manifest["input_sha256"] != _sha256(args.csv):
        raise ValueError("partition manifest version or source hash differs")
    with args.csv.open(newline="") as stream:
        header = next(csv.reader(stream))
    if len(set(header)) != len(header):
        raise ValueError("duplicate CSV column names are not accepted")
    frame = pd.read_csv(args.csv, dtype=str)
    if manifest["row_count"] != len(frame):
        raise ValueError("partition manifest row count differs")
    labels = pd.to_numeric(frame.pop(args.label_column), errors="raise").to_numpy()
    result = evaluate_frozen(
        frame, labels, manifest["partitions"], seed=manifest["seed"], methods=args.detectors
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    write_record(
        record_path,
        experiment=PROTOCOL,
        seeds=[manifest["seed"]],
        dataset=args.csv.name,
        data_path=args.csv,
        settings={
            "protocol": PROTOCOL,
            "exploratory": True,
            "label_column": args.label_column,
            "detectors": args.detectors,
            "partition_sha256": _sha256(args.partitions),
            "research_sha256": {name: _sha256(ROOT / name) for name in RESEARCH_SOURCES},
            "torch": _optional_version("torch"),
        },
        outputs=[args.output.name],
    )
    return 1 if result["XXerrorsXX"] or not result["runs"] else 0


def x_main__mutmut_178(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=Path, required=True)
    parser.add_argument("--partitions", type=Path, required=True)
    parser.add_argument("--label-column", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--detectors", nargs="+", required=True)
    args = parser.parse_args(argv)
    record_path = args.output.with_suffix(".record.json")
    if args.output.exists() or record_path.exists():
        raise FileExistsError("choose unused output and record paths")
    manifest = json.loads(args.partitions.read_text())
    if manifest["schema_version"] != 1 or manifest["input_sha256"] != _sha256(args.csv):
        raise ValueError("partition manifest version or source hash differs")
    with args.csv.open(newline="") as stream:
        header = next(csv.reader(stream))
    if len(set(header)) != len(header):
        raise ValueError("duplicate CSV column names are not accepted")
    frame = pd.read_csv(args.csv, dtype=str)
    if manifest["row_count"] != len(frame):
        raise ValueError("partition manifest row count differs")
    labels = pd.to_numeric(frame.pop(args.label_column), errors="raise").to_numpy()
    result = evaluate_frozen(
        frame, labels, manifest["partitions"], seed=manifest["seed"], methods=args.detectors
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    write_record(
        record_path,
        experiment=PROTOCOL,
        seeds=[manifest["seed"]],
        dataset=args.csv.name,
        data_path=args.csv,
        settings={
            "protocol": PROTOCOL,
            "exploratory": True,
            "label_column": args.label_column,
            "detectors": args.detectors,
            "partition_sha256": _sha256(args.partitions),
            "research_sha256": {name: _sha256(ROOT / name) for name in RESEARCH_SOURCES},
            "torch": _optional_version("torch"),
        },
        outputs=[args.output.name],
    )
    return 1 if result["ERRORS"] or not result["runs"] else 0


def x_main__mutmut_179(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=Path, required=True)
    parser.add_argument("--partitions", type=Path, required=True)
    parser.add_argument("--label-column", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--detectors", nargs="+", required=True)
    args = parser.parse_args(argv)
    record_path = args.output.with_suffix(".record.json")
    if args.output.exists() or record_path.exists():
        raise FileExistsError("choose unused output and record paths")
    manifest = json.loads(args.partitions.read_text())
    if manifest["schema_version"] != 1 or manifest["input_sha256"] != _sha256(args.csv):
        raise ValueError("partition manifest version or source hash differs")
    with args.csv.open(newline="") as stream:
        header = next(csv.reader(stream))
    if len(set(header)) != len(header):
        raise ValueError("duplicate CSV column names are not accepted")
    frame = pd.read_csv(args.csv, dtype=str)
    if manifest["row_count"] != len(frame):
        raise ValueError("partition manifest row count differs")
    labels = pd.to_numeric(frame.pop(args.label_column), errors="raise").to_numpy()
    result = evaluate_frozen(
        frame, labels, manifest["partitions"], seed=manifest["seed"], methods=args.detectors
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    write_record(
        record_path,
        experiment=PROTOCOL,
        seeds=[manifest["seed"]],
        dataset=args.csv.name,
        data_path=args.csv,
        settings={
            "protocol": PROTOCOL,
            "exploratory": True,
            "label_column": args.label_column,
            "detectors": args.detectors,
            "partition_sha256": _sha256(args.partitions),
            "research_sha256": {name: _sha256(ROOT / name) for name in RESEARCH_SOURCES},
            "torch": _optional_version("torch"),
        },
        outputs=[args.output.name],
    )
    return 1 if result["errors"] or result["runs"] else 0


def x_main__mutmut_180(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=Path, required=True)
    parser.add_argument("--partitions", type=Path, required=True)
    parser.add_argument("--label-column", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--detectors", nargs="+", required=True)
    args = parser.parse_args(argv)
    record_path = args.output.with_suffix(".record.json")
    if args.output.exists() or record_path.exists():
        raise FileExistsError("choose unused output and record paths")
    manifest = json.loads(args.partitions.read_text())
    if manifest["schema_version"] != 1 or manifest["input_sha256"] != _sha256(args.csv):
        raise ValueError("partition manifest version or source hash differs")
    with args.csv.open(newline="") as stream:
        header = next(csv.reader(stream))
    if len(set(header)) != len(header):
        raise ValueError("duplicate CSV column names are not accepted")
    frame = pd.read_csv(args.csv, dtype=str)
    if manifest["row_count"] != len(frame):
        raise ValueError("partition manifest row count differs")
    labels = pd.to_numeric(frame.pop(args.label_column), errors="raise").to_numpy()
    result = evaluate_frozen(
        frame, labels, manifest["partitions"], seed=manifest["seed"], methods=args.detectors
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    write_record(
        record_path,
        experiment=PROTOCOL,
        seeds=[manifest["seed"]],
        dataset=args.csv.name,
        data_path=args.csv,
        settings={
            "protocol": PROTOCOL,
            "exploratory": True,
            "label_column": args.label_column,
            "detectors": args.detectors,
            "partition_sha256": _sha256(args.partitions),
            "research_sha256": {name: _sha256(ROOT / name) for name in RESEARCH_SOURCES},
            "torch": _optional_version("torch"),
        },
        outputs=[args.output.name],
    )
    return 1 if result["errors"] or not result["XXrunsXX"] else 0


def x_main__mutmut_181(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=Path, required=True)
    parser.add_argument("--partitions", type=Path, required=True)
    parser.add_argument("--label-column", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--detectors", nargs="+", required=True)
    args = parser.parse_args(argv)
    record_path = args.output.with_suffix(".record.json")
    if args.output.exists() or record_path.exists():
        raise FileExistsError("choose unused output and record paths")
    manifest = json.loads(args.partitions.read_text())
    if manifest["schema_version"] != 1 or manifest["input_sha256"] != _sha256(args.csv):
        raise ValueError("partition manifest version or source hash differs")
    with args.csv.open(newline="") as stream:
        header = next(csv.reader(stream))
    if len(set(header)) != len(header):
        raise ValueError("duplicate CSV column names are not accepted")
    frame = pd.read_csv(args.csv, dtype=str)
    if manifest["row_count"] != len(frame):
        raise ValueError("partition manifest row count differs")
    labels = pd.to_numeric(frame.pop(args.label_column), errors="raise").to_numpy()
    result = evaluate_frozen(
        frame, labels, manifest["partitions"], seed=manifest["seed"], methods=args.detectors
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    write_record(
        record_path,
        experiment=PROTOCOL,
        seeds=[manifest["seed"]],
        dataset=args.csv.name,
        data_path=args.csv,
        settings={
            "protocol": PROTOCOL,
            "exploratory": True,
            "label_column": args.label_column,
            "detectors": args.detectors,
            "partition_sha256": _sha256(args.partitions),
            "research_sha256": {name: _sha256(ROOT / name) for name in RESEARCH_SOURCES},
            "torch": _optional_version("torch"),
        },
        outputs=[args.output.name],
    )
    return 1 if result["errors"] or not result["RUNS"] else 0


def x_main__mutmut_182(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=Path, required=True)
    parser.add_argument("--partitions", type=Path, required=True)
    parser.add_argument("--label-column", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--detectors", nargs="+", required=True)
    args = parser.parse_args(argv)
    record_path = args.output.with_suffix(".record.json")
    if args.output.exists() or record_path.exists():
        raise FileExistsError("choose unused output and record paths")
    manifest = json.loads(args.partitions.read_text())
    if manifest["schema_version"] != 1 or manifest["input_sha256"] != _sha256(args.csv):
        raise ValueError("partition manifest version or source hash differs")
    with args.csv.open(newline="") as stream:
        header = next(csv.reader(stream))
    if len(set(header)) != len(header):
        raise ValueError("duplicate CSV column names are not accepted")
    frame = pd.read_csv(args.csv, dtype=str)
    if manifest["row_count"] != len(frame):
        raise ValueError("partition manifest row count differs")
    labels = pd.to_numeric(frame.pop(args.label_column), errors="raise").to_numpy()
    result = evaluate_frozen(
        frame, labels, manifest["partitions"], seed=manifest["seed"], methods=args.detectors
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    write_record(
        record_path,
        experiment=PROTOCOL,
        seeds=[manifest["seed"]],
        dataset=args.csv.name,
        data_path=args.csv,
        settings={
            "protocol": PROTOCOL,
            "exploratory": True,
            "label_column": args.label_column,
            "detectors": args.detectors,
            "partition_sha256": _sha256(args.partitions),
            "research_sha256": {name: _sha256(ROOT / name) for name in RESEARCH_SOURCES},
            "torch": _optional_version("torch"),
        },
        outputs=[args.output.name],
    )
    return 1 if result["errors"] or not result["runs"] else 1

mutants_x_main__mutmut['_mutmut_orig'] = x_main__mutmut_orig # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_1'] = x_main__mutmut_1 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_2'] = x_main__mutmut_2 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_3'] = x_main__mutmut_3 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_4'] = x_main__mutmut_4 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_5'] = x_main__mutmut_5 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_6'] = x_main__mutmut_6 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_7'] = x_main__mutmut_7 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_8'] = x_main__mutmut_8 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_9'] = x_main__mutmut_9 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_10'] = x_main__mutmut_10 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_11'] = x_main__mutmut_11 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_12'] = x_main__mutmut_12 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_13'] = x_main__mutmut_13 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_14'] = x_main__mutmut_14 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_15'] = x_main__mutmut_15 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_16'] = x_main__mutmut_16 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_17'] = x_main__mutmut_17 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_18'] = x_main__mutmut_18 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_19'] = x_main__mutmut_19 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_20'] = x_main__mutmut_20 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_21'] = x_main__mutmut_21 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_22'] = x_main__mutmut_22 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_23'] = x_main__mutmut_23 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_24'] = x_main__mutmut_24 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_25'] = x_main__mutmut_25 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_26'] = x_main__mutmut_26 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_27'] = x_main__mutmut_27 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_28'] = x_main__mutmut_28 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_29'] = x_main__mutmut_29 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_30'] = x_main__mutmut_30 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_31'] = x_main__mutmut_31 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_32'] = x_main__mutmut_32 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_33'] = x_main__mutmut_33 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_34'] = x_main__mutmut_34 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_35'] = x_main__mutmut_35 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_36'] = x_main__mutmut_36 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_37'] = x_main__mutmut_37 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_38'] = x_main__mutmut_38 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_39'] = x_main__mutmut_39 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_40'] = x_main__mutmut_40 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_41'] = x_main__mutmut_41 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_42'] = x_main__mutmut_42 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_43'] = x_main__mutmut_43 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_44'] = x_main__mutmut_44 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_45'] = x_main__mutmut_45 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_46'] = x_main__mutmut_46 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_47'] = x_main__mutmut_47 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_48'] = x_main__mutmut_48 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_49'] = x_main__mutmut_49 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_50'] = x_main__mutmut_50 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_51'] = x_main__mutmut_51 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_52'] = x_main__mutmut_52 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_53'] = x_main__mutmut_53 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_54'] = x_main__mutmut_54 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_55'] = x_main__mutmut_55 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_56'] = x_main__mutmut_56 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_57'] = x_main__mutmut_57 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_58'] = x_main__mutmut_58 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_59'] = x_main__mutmut_59 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_60'] = x_main__mutmut_60 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_61'] = x_main__mutmut_61 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_62'] = x_main__mutmut_62 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_63'] = x_main__mutmut_63 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_64'] = x_main__mutmut_64 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_65'] = x_main__mutmut_65 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_66'] = x_main__mutmut_66 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_67'] = x_main__mutmut_67 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_68'] = x_main__mutmut_68 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_69'] = x_main__mutmut_69 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_70'] = x_main__mutmut_70 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_71'] = x_main__mutmut_71 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_72'] = x_main__mutmut_72 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_73'] = x_main__mutmut_73 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_74'] = x_main__mutmut_74 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_75'] = x_main__mutmut_75 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_76'] = x_main__mutmut_76 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_77'] = x_main__mutmut_77 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_78'] = x_main__mutmut_78 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_79'] = x_main__mutmut_79 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_80'] = x_main__mutmut_80 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_81'] = x_main__mutmut_81 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_82'] = x_main__mutmut_82 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_83'] = x_main__mutmut_83 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_84'] = x_main__mutmut_84 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_85'] = x_main__mutmut_85 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_86'] = x_main__mutmut_86 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_87'] = x_main__mutmut_87 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_88'] = x_main__mutmut_88 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_89'] = x_main__mutmut_89 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_90'] = x_main__mutmut_90 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_91'] = x_main__mutmut_91 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_92'] = x_main__mutmut_92 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_93'] = x_main__mutmut_93 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_94'] = x_main__mutmut_94 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_95'] = x_main__mutmut_95 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_96'] = x_main__mutmut_96 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_97'] = x_main__mutmut_97 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_98'] = x_main__mutmut_98 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_99'] = x_main__mutmut_99 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_100'] = x_main__mutmut_100 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_101'] = x_main__mutmut_101 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_102'] = x_main__mutmut_102 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_103'] = x_main__mutmut_103 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_104'] = x_main__mutmut_104 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_105'] = x_main__mutmut_105 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_106'] = x_main__mutmut_106 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_107'] = x_main__mutmut_107 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_108'] = x_main__mutmut_108 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_109'] = x_main__mutmut_109 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_110'] = x_main__mutmut_110 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_111'] = x_main__mutmut_111 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_112'] = x_main__mutmut_112 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_113'] = x_main__mutmut_113 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_114'] = x_main__mutmut_114 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_115'] = x_main__mutmut_115 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_116'] = x_main__mutmut_116 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_117'] = x_main__mutmut_117 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_118'] = x_main__mutmut_118 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_119'] = x_main__mutmut_119 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_120'] = x_main__mutmut_120 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_121'] = x_main__mutmut_121 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_122'] = x_main__mutmut_122 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_123'] = x_main__mutmut_123 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_124'] = x_main__mutmut_124 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_125'] = x_main__mutmut_125 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_126'] = x_main__mutmut_126 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_127'] = x_main__mutmut_127 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_128'] = x_main__mutmut_128 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_129'] = x_main__mutmut_129 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_130'] = x_main__mutmut_130 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_131'] = x_main__mutmut_131 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_132'] = x_main__mutmut_132 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_133'] = x_main__mutmut_133 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_134'] = x_main__mutmut_134 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_135'] = x_main__mutmut_135 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_136'] = x_main__mutmut_136 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_137'] = x_main__mutmut_137 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_138'] = x_main__mutmut_138 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_139'] = x_main__mutmut_139 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_140'] = x_main__mutmut_140 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_141'] = x_main__mutmut_141 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_142'] = x_main__mutmut_142 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_143'] = x_main__mutmut_143 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_144'] = x_main__mutmut_144 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_145'] = x_main__mutmut_145 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_146'] = x_main__mutmut_146 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_147'] = x_main__mutmut_147 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_148'] = x_main__mutmut_148 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_149'] = x_main__mutmut_149 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_150'] = x_main__mutmut_150 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_151'] = x_main__mutmut_151 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_152'] = x_main__mutmut_152 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_153'] = x_main__mutmut_153 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_154'] = x_main__mutmut_154 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_155'] = x_main__mutmut_155 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_156'] = x_main__mutmut_156 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_157'] = x_main__mutmut_157 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_158'] = x_main__mutmut_158 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_159'] = x_main__mutmut_159 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_160'] = x_main__mutmut_160 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_161'] = x_main__mutmut_161 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_162'] = x_main__mutmut_162 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_163'] = x_main__mutmut_163 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_164'] = x_main__mutmut_164 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_165'] = x_main__mutmut_165 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_166'] = x_main__mutmut_166 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_167'] = x_main__mutmut_167 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_168'] = x_main__mutmut_168 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_169'] = x_main__mutmut_169 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_170'] = x_main__mutmut_170 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_171'] = x_main__mutmut_171 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_172'] = x_main__mutmut_172 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_173'] = x_main__mutmut_173 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_174'] = x_main__mutmut_174 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_175'] = x_main__mutmut_175 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_176'] = x_main__mutmut_176 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_177'] = x_main__mutmut_177 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_178'] = x_main__mutmut_178 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_179'] = x_main__mutmut_179 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_180'] = x_main__mutmut_180 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_181'] = x_main__mutmut_181 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_182'] = x_main__mutmut_182 # type: ignore # mutmut generated


if __name__ == "__main__":
    raise SystemExit(main())
