"""Write the appendix of the paper that lists the full per-type matrices (all detectors).

Run after ``full_registry_summary.py``; it replaces the section between the markers each time.
"""

from __future__ import annotations

from pathlib import Path

import full_registry_summary as fs
import paper_tables as pt
import typed_summary as ts

ROOT = Path(__file__).resolve().parents[1]
START = "% BEGIN generated matrices\n"
END = "% END generated matrices\n"


from mutmut.mutation.trampoline import wrap_in_trampoline as _mutmut_mutated, MutantDict
mutants_x_section__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_section__mutmut)
def section(evidence: Path) -> str:
    out = evidence / "full_registry"
    customer = fs.synthetic_matrix(evidence, out)
    schemas = fs.schema_matrices(evidence / "multi_schema", out / "schemas_deep")
    typed = fs.merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    median = fs.ordered(ts.pooled(typed)["median"])
    text = [
        r"\section{Full per-type matrices}",
        r"\label{app:matrices}",
        "The tables below give the mean recall of every detector of the registry on each "
        "injected type, over five seeds for the synthetic tables and as the median over the "
        r"$42$ real tables for the last one. The best value of each column among the detectors "
        "of the registry is in bold.",
        "",
        pt.matrix_table(
            customer, "Synthetic customer table, mean recall over five seeds.", "tab:m-customer"
        ),
        "",
        pt.matrix_table(
            schemas["transactions"].drop(index="drift", errors="ignore"),
            "Synthetic card transactions, mean recall over five seeds.",
            "tab:m-transactions",
        ),
        "",
        pt.matrix_table(
            schemas["sensors"].drop(index="drift", errors="ignore"),
            "Synthetic sensor readings, mean recall over five seeds.",
            "tab:m-sensors",
        ),
        "",
        pt.matrix_table(
            median,
            r"Typed injection into $42$ real tables, median recall over the tables.",
            "tab:m-typed",
        ),
    ]
    return "\n".join(text) + "\n"


def x_section__mutmut_orig(evidence: Path) -> str:
    out = evidence / "full_registry"
    customer = fs.synthetic_matrix(evidence, out)
    schemas = fs.schema_matrices(evidence / "multi_schema", out / "schemas_deep")
    typed = fs.merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    median = fs.ordered(ts.pooled(typed)["median"])
    text = [
        r"\section{Full per-type matrices}",
        r"\label{app:matrices}",
        "The tables below give the mean recall of every detector of the registry on each "
        "injected type, over five seeds for the synthetic tables and as the median over the "
        r"$42$ real tables for the last one. The best value of each column among the detectors "
        "of the registry is in bold.",
        "",
        pt.matrix_table(
            customer, "Synthetic customer table, mean recall over five seeds.", "tab:m-customer"
        ),
        "",
        pt.matrix_table(
            schemas["transactions"].drop(index="drift", errors="ignore"),
            "Synthetic card transactions, mean recall over five seeds.",
            "tab:m-transactions",
        ),
        "",
        pt.matrix_table(
            schemas["sensors"].drop(index="drift", errors="ignore"),
            "Synthetic sensor readings, mean recall over five seeds.",
            "tab:m-sensors",
        ),
        "",
        pt.matrix_table(
            median,
            r"Typed injection into $42$ real tables, median recall over the tables.",
            "tab:m-typed",
        ),
    ]
    return "\n".join(text) + "\n"


def x_section__mutmut_1(evidence: Path) -> str:
    out = None
    customer = fs.synthetic_matrix(evidence, out)
    schemas = fs.schema_matrices(evidence / "multi_schema", out / "schemas_deep")
    typed = fs.merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    median = fs.ordered(ts.pooled(typed)["median"])
    text = [
        r"\section{Full per-type matrices}",
        r"\label{app:matrices}",
        "The tables below give the mean recall of every detector of the registry on each "
        "injected type, over five seeds for the synthetic tables and as the median over the "
        r"$42$ real tables for the last one. The best value of each column among the detectors "
        "of the registry is in bold.",
        "",
        pt.matrix_table(
            customer, "Synthetic customer table, mean recall over five seeds.", "tab:m-customer"
        ),
        "",
        pt.matrix_table(
            schemas["transactions"].drop(index="drift", errors="ignore"),
            "Synthetic card transactions, mean recall over five seeds.",
            "tab:m-transactions",
        ),
        "",
        pt.matrix_table(
            schemas["sensors"].drop(index="drift", errors="ignore"),
            "Synthetic sensor readings, mean recall over five seeds.",
            "tab:m-sensors",
        ),
        "",
        pt.matrix_table(
            median,
            r"Typed injection into $42$ real tables, median recall over the tables.",
            "tab:m-typed",
        ),
    ]
    return "\n".join(text) + "\n"


def x_section__mutmut_2(evidence: Path) -> str:
    out = evidence * "full_registry"
    customer = fs.synthetic_matrix(evidence, out)
    schemas = fs.schema_matrices(evidence / "multi_schema", out / "schemas_deep")
    typed = fs.merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    median = fs.ordered(ts.pooled(typed)["median"])
    text = [
        r"\section{Full per-type matrices}",
        r"\label{app:matrices}",
        "The tables below give the mean recall of every detector of the registry on each "
        "injected type, over five seeds for the synthetic tables and as the median over the "
        r"$42$ real tables for the last one. The best value of each column among the detectors "
        "of the registry is in bold.",
        "",
        pt.matrix_table(
            customer, "Synthetic customer table, mean recall over five seeds.", "tab:m-customer"
        ),
        "",
        pt.matrix_table(
            schemas["transactions"].drop(index="drift", errors="ignore"),
            "Synthetic card transactions, mean recall over five seeds.",
            "tab:m-transactions",
        ),
        "",
        pt.matrix_table(
            schemas["sensors"].drop(index="drift", errors="ignore"),
            "Synthetic sensor readings, mean recall over five seeds.",
            "tab:m-sensors",
        ),
        "",
        pt.matrix_table(
            median,
            r"Typed injection into $42$ real tables, median recall over the tables.",
            "tab:m-typed",
        ),
    ]
    return "\n".join(text) + "\n"


def x_section__mutmut_3(evidence: Path) -> str:
    out = evidence / "XXfull_registryXX"
    customer = fs.synthetic_matrix(evidence, out)
    schemas = fs.schema_matrices(evidence / "multi_schema", out / "schemas_deep")
    typed = fs.merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    median = fs.ordered(ts.pooled(typed)["median"])
    text = [
        r"\section{Full per-type matrices}",
        r"\label{app:matrices}",
        "The tables below give the mean recall of every detector of the registry on each "
        "injected type, over five seeds for the synthetic tables and as the median over the "
        r"$42$ real tables for the last one. The best value of each column among the detectors "
        "of the registry is in bold.",
        "",
        pt.matrix_table(
            customer, "Synthetic customer table, mean recall over five seeds.", "tab:m-customer"
        ),
        "",
        pt.matrix_table(
            schemas["transactions"].drop(index="drift", errors="ignore"),
            "Synthetic card transactions, mean recall over five seeds.",
            "tab:m-transactions",
        ),
        "",
        pt.matrix_table(
            schemas["sensors"].drop(index="drift", errors="ignore"),
            "Synthetic sensor readings, mean recall over five seeds.",
            "tab:m-sensors",
        ),
        "",
        pt.matrix_table(
            median,
            r"Typed injection into $42$ real tables, median recall over the tables.",
            "tab:m-typed",
        ),
    ]
    return "\n".join(text) + "\n"


def x_section__mutmut_4(evidence: Path) -> str:
    out = evidence / "FULL_REGISTRY"
    customer = fs.synthetic_matrix(evidence, out)
    schemas = fs.schema_matrices(evidence / "multi_schema", out / "schemas_deep")
    typed = fs.merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    median = fs.ordered(ts.pooled(typed)["median"])
    text = [
        r"\section{Full per-type matrices}",
        r"\label{app:matrices}",
        "The tables below give the mean recall of every detector of the registry on each "
        "injected type, over five seeds for the synthetic tables and as the median over the "
        r"$42$ real tables for the last one. The best value of each column among the detectors "
        "of the registry is in bold.",
        "",
        pt.matrix_table(
            customer, "Synthetic customer table, mean recall over five seeds.", "tab:m-customer"
        ),
        "",
        pt.matrix_table(
            schemas["transactions"].drop(index="drift", errors="ignore"),
            "Synthetic card transactions, mean recall over five seeds.",
            "tab:m-transactions",
        ),
        "",
        pt.matrix_table(
            schemas["sensors"].drop(index="drift", errors="ignore"),
            "Synthetic sensor readings, mean recall over five seeds.",
            "tab:m-sensors",
        ),
        "",
        pt.matrix_table(
            median,
            r"Typed injection into $42$ real tables, median recall over the tables.",
            "tab:m-typed",
        ),
    ]
    return "\n".join(text) + "\n"


def x_section__mutmut_5(evidence: Path) -> str:
    out = evidence / "full_registry"
    customer = None
    schemas = fs.schema_matrices(evidence / "multi_schema", out / "schemas_deep")
    typed = fs.merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    median = fs.ordered(ts.pooled(typed)["median"])
    text = [
        r"\section{Full per-type matrices}",
        r"\label{app:matrices}",
        "The tables below give the mean recall of every detector of the registry on each "
        "injected type, over five seeds for the synthetic tables and as the median over the "
        r"$42$ real tables for the last one. The best value of each column among the detectors "
        "of the registry is in bold.",
        "",
        pt.matrix_table(
            customer, "Synthetic customer table, mean recall over five seeds.", "tab:m-customer"
        ),
        "",
        pt.matrix_table(
            schemas["transactions"].drop(index="drift", errors="ignore"),
            "Synthetic card transactions, mean recall over five seeds.",
            "tab:m-transactions",
        ),
        "",
        pt.matrix_table(
            schemas["sensors"].drop(index="drift", errors="ignore"),
            "Synthetic sensor readings, mean recall over five seeds.",
            "tab:m-sensors",
        ),
        "",
        pt.matrix_table(
            median,
            r"Typed injection into $42$ real tables, median recall over the tables.",
            "tab:m-typed",
        ),
    ]
    return "\n".join(text) + "\n"


def x_section__mutmut_6(evidence: Path) -> str:
    out = evidence / "full_registry"
    customer = fs.synthetic_matrix(None, out)
    schemas = fs.schema_matrices(evidence / "multi_schema", out / "schemas_deep")
    typed = fs.merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    median = fs.ordered(ts.pooled(typed)["median"])
    text = [
        r"\section{Full per-type matrices}",
        r"\label{app:matrices}",
        "The tables below give the mean recall of every detector of the registry on each "
        "injected type, over five seeds for the synthetic tables and as the median over the "
        r"$42$ real tables for the last one. The best value of each column among the detectors "
        "of the registry is in bold.",
        "",
        pt.matrix_table(
            customer, "Synthetic customer table, mean recall over five seeds.", "tab:m-customer"
        ),
        "",
        pt.matrix_table(
            schemas["transactions"].drop(index="drift", errors="ignore"),
            "Synthetic card transactions, mean recall over five seeds.",
            "tab:m-transactions",
        ),
        "",
        pt.matrix_table(
            schemas["sensors"].drop(index="drift", errors="ignore"),
            "Synthetic sensor readings, mean recall over five seeds.",
            "tab:m-sensors",
        ),
        "",
        pt.matrix_table(
            median,
            r"Typed injection into $42$ real tables, median recall over the tables.",
            "tab:m-typed",
        ),
    ]
    return "\n".join(text) + "\n"


def x_section__mutmut_7(evidence: Path) -> str:
    out = evidence / "full_registry"
    customer = fs.synthetic_matrix(evidence, None)
    schemas = fs.schema_matrices(evidence / "multi_schema", out / "schemas_deep")
    typed = fs.merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    median = fs.ordered(ts.pooled(typed)["median"])
    text = [
        r"\section{Full per-type matrices}",
        r"\label{app:matrices}",
        "The tables below give the mean recall of every detector of the registry on each "
        "injected type, over five seeds for the synthetic tables and as the median over the "
        r"$42$ real tables for the last one. The best value of each column among the detectors "
        "of the registry is in bold.",
        "",
        pt.matrix_table(
            customer, "Synthetic customer table, mean recall over five seeds.", "tab:m-customer"
        ),
        "",
        pt.matrix_table(
            schemas["transactions"].drop(index="drift", errors="ignore"),
            "Synthetic card transactions, mean recall over five seeds.",
            "tab:m-transactions",
        ),
        "",
        pt.matrix_table(
            schemas["sensors"].drop(index="drift", errors="ignore"),
            "Synthetic sensor readings, mean recall over five seeds.",
            "tab:m-sensors",
        ),
        "",
        pt.matrix_table(
            median,
            r"Typed injection into $42$ real tables, median recall over the tables.",
            "tab:m-typed",
        ),
    ]
    return "\n".join(text) + "\n"


def x_section__mutmut_8(evidence: Path) -> str:
    out = evidence / "full_registry"
    customer = fs.synthetic_matrix(out)
    schemas = fs.schema_matrices(evidence / "multi_schema", out / "schemas_deep")
    typed = fs.merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    median = fs.ordered(ts.pooled(typed)["median"])
    text = [
        r"\section{Full per-type matrices}",
        r"\label{app:matrices}",
        "The tables below give the mean recall of every detector of the registry on each "
        "injected type, over five seeds for the synthetic tables and as the median over the "
        r"$42$ real tables for the last one. The best value of each column among the detectors "
        "of the registry is in bold.",
        "",
        pt.matrix_table(
            customer, "Synthetic customer table, mean recall over five seeds.", "tab:m-customer"
        ),
        "",
        pt.matrix_table(
            schemas["transactions"].drop(index="drift", errors="ignore"),
            "Synthetic card transactions, mean recall over five seeds.",
            "tab:m-transactions",
        ),
        "",
        pt.matrix_table(
            schemas["sensors"].drop(index="drift", errors="ignore"),
            "Synthetic sensor readings, mean recall over five seeds.",
            "tab:m-sensors",
        ),
        "",
        pt.matrix_table(
            median,
            r"Typed injection into $42$ real tables, median recall over the tables.",
            "tab:m-typed",
        ),
    ]
    return "\n".join(text) + "\n"


def x_section__mutmut_9(evidence: Path) -> str:
    out = evidence / "full_registry"
    customer = fs.synthetic_matrix(evidence, )
    schemas = fs.schema_matrices(evidence / "multi_schema", out / "schemas_deep")
    typed = fs.merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    median = fs.ordered(ts.pooled(typed)["median"])
    text = [
        r"\section{Full per-type matrices}",
        r"\label{app:matrices}",
        "The tables below give the mean recall of every detector of the registry on each "
        "injected type, over five seeds for the synthetic tables and as the median over the "
        r"$42$ real tables for the last one. The best value of each column among the detectors "
        "of the registry is in bold.",
        "",
        pt.matrix_table(
            customer, "Synthetic customer table, mean recall over five seeds.", "tab:m-customer"
        ),
        "",
        pt.matrix_table(
            schemas["transactions"].drop(index="drift", errors="ignore"),
            "Synthetic card transactions, mean recall over five seeds.",
            "tab:m-transactions",
        ),
        "",
        pt.matrix_table(
            schemas["sensors"].drop(index="drift", errors="ignore"),
            "Synthetic sensor readings, mean recall over five seeds.",
            "tab:m-sensors",
        ),
        "",
        pt.matrix_table(
            median,
            r"Typed injection into $42$ real tables, median recall over the tables.",
            "tab:m-typed",
        ),
    ]
    return "\n".join(text) + "\n"


def x_section__mutmut_10(evidence: Path) -> str:
    out = evidence / "full_registry"
    customer = fs.synthetic_matrix(evidence, out)
    schemas = None
    typed = fs.merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    median = fs.ordered(ts.pooled(typed)["median"])
    text = [
        r"\section{Full per-type matrices}",
        r"\label{app:matrices}",
        "The tables below give the mean recall of every detector of the registry on each "
        "injected type, over five seeds for the synthetic tables and as the median over the "
        r"$42$ real tables for the last one. The best value of each column among the detectors "
        "of the registry is in bold.",
        "",
        pt.matrix_table(
            customer, "Synthetic customer table, mean recall over five seeds.", "tab:m-customer"
        ),
        "",
        pt.matrix_table(
            schemas["transactions"].drop(index="drift", errors="ignore"),
            "Synthetic card transactions, mean recall over five seeds.",
            "tab:m-transactions",
        ),
        "",
        pt.matrix_table(
            schemas["sensors"].drop(index="drift", errors="ignore"),
            "Synthetic sensor readings, mean recall over five seeds.",
            "tab:m-sensors",
        ),
        "",
        pt.matrix_table(
            median,
            r"Typed injection into $42$ real tables, median recall over the tables.",
            "tab:m-typed",
        ),
    ]
    return "\n".join(text) + "\n"


def x_section__mutmut_11(evidence: Path) -> str:
    out = evidence / "full_registry"
    customer = fs.synthetic_matrix(evidence, out)
    schemas = fs.schema_matrices(None, out / "schemas_deep")
    typed = fs.merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    median = fs.ordered(ts.pooled(typed)["median"])
    text = [
        r"\section{Full per-type matrices}",
        r"\label{app:matrices}",
        "The tables below give the mean recall of every detector of the registry on each "
        "injected type, over five seeds for the synthetic tables and as the median over the "
        r"$42$ real tables for the last one. The best value of each column among the detectors "
        "of the registry is in bold.",
        "",
        pt.matrix_table(
            customer, "Synthetic customer table, mean recall over five seeds.", "tab:m-customer"
        ),
        "",
        pt.matrix_table(
            schemas["transactions"].drop(index="drift", errors="ignore"),
            "Synthetic card transactions, mean recall over five seeds.",
            "tab:m-transactions",
        ),
        "",
        pt.matrix_table(
            schemas["sensors"].drop(index="drift", errors="ignore"),
            "Synthetic sensor readings, mean recall over five seeds.",
            "tab:m-sensors",
        ),
        "",
        pt.matrix_table(
            median,
            r"Typed injection into $42$ real tables, median recall over the tables.",
            "tab:m-typed",
        ),
    ]
    return "\n".join(text) + "\n"


def x_section__mutmut_12(evidence: Path) -> str:
    out = evidence / "full_registry"
    customer = fs.synthetic_matrix(evidence, out)
    schemas = fs.schema_matrices(evidence / "multi_schema", None)
    typed = fs.merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    median = fs.ordered(ts.pooled(typed)["median"])
    text = [
        r"\section{Full per-type matrices}",
        r"\label{app:matrices}",
        "The tables below give the mean recall of every detector of the registry on each "
        "injected type, over five seeds for the synthetic tables and as the median over the "
        r"$42$ real tables for the last one. The best value of each column among the detectors "
        "of the registry is in bold.",
        "",
        pt.matrix_table(
            customer, "Synthetic customer table, mean recall over five seeds.", "tab:m-customer"
        ),
        "",
        pt.matrix_table(
            schemas["transactions"].drop(index="drift", errors="ignore"),
            "Synthetic card transactions, mean recall over five seeds.",
            "tab:m-transactions",
        ),
        "",
        pt.matrix_table(
            schemas["sensors"].drop(index="drift", errors="ignore"),
            "Synthetic sensor readings, mean recall over five seeds.",
            "tab:m-sensors",
        ),
        "",
        pt.matrix_table(
            median,
            r"Typed injection into $42$ real tables, median recall over the tables.",
            "tab:m-typed",
        ),
    ]
    return "\n".join(text) + "\n"


def x_section__mutmut_13(evidence: Path) -> str:
    out = evidence / "full_registry"
    customer = fs.synthetic_matrix(evidence, out)
    schemas = fs.schema_matrices(out / "schemas_deep")
    typed = fs.merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    median = fs.ordered(ts.pooled(typed)["median"])
    text = [
        r"\section{Full per-type matrices}",
        r"\label{app:matrices}",
        "The tables below give the mean recall of every detector of the registry on each "
        "injected type, over five seeds for the synthetic tables and as the median over the "
        r"$42$ real tables for the last one. The best value of each column among the detectors "
        "of the registry is in bold.",
        "",
        pt.matrix_table(
            customer, "Synthetic customer table, mean recall over five seeds.", "tab:m-customer"
        ),
        "",
        pt.matrix_table(
            schemas["transactions"].drop(index="drift", errors="ignore"),
            "Synthetic card transactions, mean recall over five seeds.",
            "tab:m-transactions",
        ),
        "",
        pt.matrix_table(
            schemas["sensors"].drop(index="drift", errors="ignore"),
            "Synthetic sensor readings, mean recall over five seeds.",
            "tab:m-sensors",
        ),
        "",
        pt.matrix_table(
            median,
            r"Typed injection into $42$ real tables, median recall over the tables.",
            "tab:m-typed",
        ),
    ]
    return "\n".join(text) + "\n"


def x_section__mutmut_14(evidence: Path) -> str:
    out = evidence / "full_registry"
    customer = fs.synthetic_matrix(evidence, out)
    schemas = fs.schema_matrices(evidence / "multi_schema", )
    typed = fs.merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    median = fs.ordered(ts.pooled(typed)["median"])
    text = [
        r"\section{Full per-type matrices}",
        r"\label{app:matrices}",
        "The tables below give the mean recall of every detector of the registry on each "
        "injected type, over five seeds for the synthetic tables and as the median over the "
        r"$42$ real tables for the last one. The best value of each column among the detectors "
        "of the registry is in bold.",
        "",
        pt.matrix_table(
            customer, "Synthetic customer table, mean recall over five seeds.", "tab:m-customer"
        ),
        "",
        pt.matrix_table(
            schemas["transactions"].drop(index="drift", errors="ignore"),
            "Synthetic card transactions, mean recall over five seeds.",
            "tab:m-transactions",
        ),
        "",
        pt.matrix_table(
            schemas["sensors"].drop(index="drift", errors="ignore"),
            "Synthetic sensor readings, mean recall over five seeds.",
            "tab:m-sensors",
        ),
        "",
        pt.matrix_table(
            median,
            r"Typed injection into $42$ real tables, median recall over the tables.",
            "tab:m-typed",
        ),
    ]
    return "\n".join(text) + "\n"


def x_section__mutmut_15(evidence: Path) -> str:
    out = evidence / "full_registry"
    customer = fs.synthetic_matrix(evidence, out)
    schemas = fs.schema_matrices(evidence * "multi_schema", out / "schemas_deep")
    typed = fs.merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    median = fs.ordered(ts.pooled(typed)["median"])
    text = [
        r"\section{Full per-type matrices}",
        r"\label{app:matrices}",
        "The tables below give the mean recall of every detector of the registry on each "
        "injected type, over five seeds for the synthetic tables and as the median over the "
        r"$42$ real tables for the last one. The best value of each column among the detectors "
        "of the registry is in bold.",
        "",
        pt.matrix_table(
            customer, "Synthetic customer table, mean recall over five seeds.", "tab:m-customer"
        ),
        "",
        pt.matrix_table(
            schemas["transactions"].drop(index="drift", errors="ignore"),
            "Synthetic card transactions, mean recall over five seeds.",
            "tab:m-transactions",
        ),
        "",
        pt.matrix_table(
            schemas["sensors"].drop(index="drift", errors="ignore"),
            "Synthetic sensor readings, mean recall over five seeds.",
            "tab:m-sensors",
        ),
        "",
        pt.matrix_table(
            median,
            r"Typed injection into $42$ real tables, median recall over the tables.",
            "tab:m-typed",
        ),
    ]
    return "\n".join(text) + "\n"


def x_section__mutmut_16(evidence: Path) -> str:
    out = evidence / "full_registry"
    customer = fs.synthetic_matrix(evidence, out)
    schemas = fs.schema_matrices(evidence / "XXmulti_schemaXX", out / "schemas_deep")
    typed = fs.merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    median = fs.ordered(ts.pooled(typed)["median"])
    text = [
        r"\section{Full per-type matrices}",
        r"\label{app:matrices}",
        "The tables below give the mean recall of every detector of the registry on each "
        "injected type, over five seeds for the synthetic tables and as the median over the "
        r"$42$ real tables for the last one. The best value of each column among the detectors "
        "of the registry is in bold.",
        "",
        pt.matrix_table(
            customer, "Synthetic customer table, mean recall over five seeds.", "tab:m-customer"
        ),
        "",
        pt.matrix_table(
            schemas["transactions"].drop(index="drift", errors="ignore"),
            "Synthetic card transactions, mean recall over five seeds.",
            "tab:m-transactions",
        ),
        "",
        pt.matrix_table(
            schemas["sensors"].drop(index="drift", errors="ignore"),
            "Synthetic sensor readings, mean recall over five seeds.",
            "tab:m-sensors",
        ),
        "",
        pt.matrix_table(
            median,
            r"Typed injection into $42$ real tables, median recall over the tables.",
            "tab:m-typed",
        ),
    ]
    return "\n".join(text) + "\n"


def x_section__mutmut_17(evidence: Path) -> str:
    out = evidence / "full_registry"
    customer = fs.synthetic_matrix(evidence, out)
    schemas = fs.schema_matrices(evidence / "MULTI_SCHEMA", out / "schemas_deep")
    typed = fs.merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    median = fs.ordered(ts.pooled(typed)["median"])
    text = [
        r"\section{Full per-type matrices}",
        r"\label{app:matrices}",
        "The tables below give the mean recall of every detector of the registry on each "
        "injected type, over five seeds for the synthetic tables and as the median over the "
        r"$42$ real tables for the last one. The best value of each column among the detectors "
        "of the registry is in bold.",
        "",
        pt.matrix_table(
            customer, "Synthetic customer table, mean recall over five seeds.", "tab:m-customer"
        ),
        "",
        pt.matrix_table(
            schemas["transactions"].drop(index="drift", errors="ignore"),
            "Synthetic card transactions, mean recall over five seeds.",
            "tab:m-transactions",
        ),
        "",
        pt.matrix_table(
            schemas["sensors"].drop(index="drift", errors="ignore"),
            "Synthetic sensor readings, mean recall over five seeds.",
            "tab:m-sensors",
        ),
        "",
        pt.matrix_table(
            median,
            r"Typed injection into $42$ real tables, median recall over the tables.",
            "tab:m-typed",
        ),
    ]
    return "\n".join(text) + "\n"


def x_section__mutmut_18(evidence: Path) -> str:
    out = evidence / "full_registry"
    customer = fs.synthetic_matrix(evidence, out)
    schemas = fs.schema_matrices(evidence / "multi_schema", out * "schemas_deep")
    typed = fs.merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    median = fs.ordered(ts.pooled(typed)["median"])
    text = [
        r"\section{Full per-type matrices}",
        r"\label{app:matrices}",
        "The tables below give the mean recall of every detector of the registry on each "
        "injected type, over five seeds for the synthetic tables and as the median over the "
        r"$42$ real tables for the last one. The best value of each column among the detectors "
        "of the registry is in bold.",
        "",
        pt.matrix_table(
            customer, "Synthetic customer table, mean recall over five seeds.", "tab:m-customer"
        ),
        "",
        pt.matrix_table(
            schemas["transactions"].drop(index="drift", errors="ignore"),
            "Synthetic card transactions, mean recall over five seeds.",
            "tab:m-transactions",
        ),
        "",
        pt.matrix_table(
            schemas["sensors"].drop(index="drift", errors="ignore"),
            "Synthetic sensor readings, mean recall over five seeds.",
            "tab:m-sensors",
        ),
        "",
        pt.matrix_table(
            median,
            r"Typed injection into $42$ real tables, median recall over the tables.",
            "tab:m-typed",
        ),
    ]
    return "\n".join(text) + "\n"


def x_section__mutmut_19(evidence: Path) -> str:
    out = evidence / "full_registry"
    customer = fs.synthetic_matrix(evidence, out)
    schemas = fs.schema_matrices(evidence / "multi_schema", out / "XXschemas_deepXX")
    typed = fs.merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    median = fs.ordered(ts.pooled(typed)["median"])
    text = [
        r"\section{Full per-type matrices}",
        r"\label{app:matrices}",
        "The tables below give the mean recall of every detector of the registry on each "
        "injected type, over five seeds for the synthetic tables and as the median over the "
        r"$42$ real tables for the last one. The best value of each column among the detectors "
        "of the registry is in bold.",
        "",
        pt.matrix_table(
            customer, "Synthetic customer table, mean recall over five seeds.", "tab:m-customer"
        ),
        "",
        pt.matrix_table(
            schemas["transactions"].drop(index="drift", errors="ignore"),
            "Synthetic card transactions, mean recall over five seeds.",
            "tab:m-transactions",
        ),
        "",
        pt.matrix_table(
            schemas["sensors"].drop(index="drift", errors="ignore"),
            "Synthetic sensor readings, mean recall over five seeds.",
            "tab:m-sensors",
        ),
        "",
        pt.matrix_table(
            median,
            r"Typed injection into $42$ real tables, median recall over the tables.",
            "tab:m-typed",
        ),
    ]
    return "\n".join(text) + "\n"


def x_section__mutmut_20(evidence: Path) -> str:
    out = evidence / "full_registry"
    customer = fs.synthetic_matrix(evidence, out)
    schemas = fs.schema_matrices(evidence / "multi_schema", out / "SCHEMAS_DEEP")
    typed = fs.merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    median = fs.ordered(ts.pooled(typed)["median"])
    text = [
        r"\section{Full per-type matrices}",
        r"\label{app:matrices}",
        "The tables below give the mean recall of every detector of the registry on each "
        "injected type, over five seeds for the synthetic tables and as the median over the "
        r"$42$ real tables for the last one. The best value of each column among the detectors "
        "of the registry is in bold.",
        "",
        pt.matrix_table(
            customer, "Synthetic customer table, mean recall over five seeds.", "tab:m-customer"
        ),
        "",
        pt.matrix_table(
            schemas["transactions"].drop(index="drift", errors="ignore"),
            "Synthetic card transactions, mean recall over five seeds.",
            "tab:m-transactions",
        ),
        "",
        pt.matrix_table(
            schemas["sensors"].drop(index="drift", errors="ignore"),
            "Synthetic sensor readings, mean recall over five seeds.",
            "tab:m-sensors",
        ),
        "",
        pt.matrix_table(
            median,
            r"Typed injection into $42$ real tables, median recall over the tables.",
            "tab:m-typed",
        ),
    ]
    return "\n".join(text) + "\n"


def x_section__mutmut_21(evidence: Path) -> str:
    out = evidence / "full_registry"
    customer = fs.synthetic_matrix(evidence, out)
    schemas = fs.schema_matrices(evidence / "multi_schema", out / "schemas_deep")
    typed = None
    median = fs.ordered(ts.pooled(typed)["median"])
    text = [
        r"\section{Full per-type matrices}",
        r"\label{app:matrices}",
        "The tables below give the mean recall of every detector of the registry on each "
        "injected type, over five seeds for the synthetic tables and as the median over the "
        r"$42$ real tables for the last one. The best value of each column among the detectors "
        "of the registry is in bold.",
        "",
        pt.matrix_table(
            customer, "Synthetic customer table, mean recall over five seeds.", "tab:m-customer"
        ),
        "",
        pt.matrix_table(
            schemas["transactions"].drop(index="drift", errors="ignore"),
            "Synthetic card transactions, mean recall over five seeds.",
            "tab:m-transactions",
        ),
        "",
        pt.matrix_table(
            schemas["sensors"].drop(index="drift", errors="ignore"),
            "Synthetic sensor readings, mean recall over five seeds.",
            "tab:m-sensors",
        ),
        "",
        pt.matrix_table(
            median,
            r"Typed injection into $42$ real tables, median recall over the tables.",
            "tab:m-typed",
        ),
    ]
    return "\n".join(text) + "\n"


def x_section__mutmut_22(evidence: Path) -> str:
    out = evidence / "full_registry"
    customer = fs.synthetic_matrix(evidence, out)
    schemas = fs.schema_matrices(evidence / "multi_schema", out / "schemas_deep")
    typed = fs.merged_typed(None, out / "typed_deep" / "runs")
    median = fs.ordered(ts.pooled(typed)["median"])
    text = [
        r"\section{Full per-type matrices}",
        r"\label{app:matrices}",
        "The tables below give the mean recall of every detector of the registry on each "
        "injected type, over five seeds for the synthetic tables and as the median over the "
        r"$42$ real tables for the last one. The best value of each column among the detectors "
        "of the registry is in bold.",
        "",
        pt.matrix_table(
            customer, "Synthetic customer table, mean recall over five seeds.", "tab:m-customer"
        ),
        "",
        pt.matrix_table(
            schemas["transactions"].drop(index="drift", errors="ignore"),
            "Synthetic card transactions, mean recall over five seeds.",
            "tab:m-transactions",
        ),
        "",
        pt.matrix_table(
            schemas["sensors"].drop(index="drift", errors="ignore"),
            "Synthetic sensor readings, mean recall over five seeds.",
            "tab:m-sensors",
        ),
        "",
        pt.matrix_table(
            median,
            r"Typed injection into $42$ real tables, median recall over the tables.",
            "tab:m-typed",
        ),
    ]
    return "\n".join(text) + "\n"


def x_section__mutmut_23(evidence: Path) -> str:
    out = evidence / "full_registry"
    customer = fs.synthetic_matrix(evidence, out)
    schemas = fs.schema_matrices(evidence / "multi_schema", out / "schemas_deep")
    typed = fs.merged_typed(evidence / "typed_injection" / "runs", None)
    median = fs.ordered(ts.pooled(typed)["median"])
    text = [
        r"\section{Full per-type matrices}",
        r"\label{app:matrices}",
        "The tables below give the mean recall of every detector of the registry on each "
        "injected type, over five seeds for the synthetic tables and as the median over the "
        r"$42$ real tables for the last one. The best value of each column among the detectors "
        "of the registry is in bold.",
        "",
        pt.matrix_table(
            customer, "Synthetic customer table, mean recall over five seeds.", "tab:m-customer"
        ),
        "",
        pt.matrix_table(
            schemas["transactions"].drop(index="drift", errors="ignore"),
            "Synthetic card transactions, mean recall over five seeds.",
            "tab:m-transactions",
        ),
        "",
        pt.matrix_table(
            schemas["sensors"].drop(index="drift", errors="ignore"),
            "Synthetic sensor readings, mean recall over five seeds.",
            "tab:m-sensors",
        ),
        "",
        pt.matrix_table(
            median,
            r"Typed injection into $42$ real tables, median recall over the tables.",
            "tab:m-typed",
        ),
    ]
    return "\n".join(text) + "\n"


def x_section__mutmut_24(evidence: Path) -> str:
    out = evidence / "full_registry"
    customer = fs.synthetic_matrix(evidence, out)
    schemas = fs.schema_matrices(evidence / "multi_schema", out / "schemas_deep")
    typed = fs.merged_typed(out / "typed_deep" / "runs")
    median = fs.ordered(ts.pooled(typed)["median"])
    text = [
        r"\section{Full per-type matrices}",
        r"\label{app:matrices}",
        "The tables below give the mean recall of every detector of the registry on each "
        "injected type, over five seeds for the synthetic tables and as the median over the "
        r"$42$ real tables for the last one. The best value of each column among the detectors "
        "of the registry is in bold.",
        "",
        pt.matrix_table(
            customer, "Synthetic customer table, mean recall over five seeds.", "tab:m-customer"
        ),
        "",
        pt.matrix_table(
            schemas["transactions"].drop(index="drift", errors="ignore"),
            "Synthetic card transactions, mean recall over five seeds.",
            "tab:m-transactions",
        ),
        "",
        pt.matrix_table(
            schemas["sensors"].drop(index="drift", errors="ignore"),
            "Synthetic sensor readings, mean recall over five seeds.",
            "tab:m-sensors",
        ),
        "",
        pt.matrix_table(
            median,
            r"Typed injection into $42$ real tables, median recall over the tables.",
            "tab:m-typed",
        ),
    ]
    return "\n".join(text) + "\n"


def x_section__mutmut_25(evidence: Path) -> str:
    out = evidence / "full_registry"
    customer = fs.synthetic_matrix(evidence, out)
    schemas = fs.schema_matrices(evidence / "multi_schema", out / "schemas_deep")
    typed = fs.merged_typed(evidence / "typed_injection" / "runs", )
    median = fs.ordered(ts.pooled(typed)["median"])
    text = [
        r"\section{Full per-type matrices}",
        r"\label{app:matrices}",
        "The tables below give the mean recall of every detector of the registry on each "
        "injected type, over five seeds for the synthetic tables and as the median over the "
        r"$42$ real tables for the last one. The best value of each column among the detectors "
        "of the registry is in bold.",
        "",
        pt.matrix_table(
            customer, "Synthetic customer table, mean recall over five seeds.", "tab:m-customer"
        ),
        "",
        pt.matrix_table(
            schemas["transactions"].drop(index="drift", errors="ignore"),
            "Synthetic card transactions, mean recall over five seeds.",
            "tab:m-transactions",
        ),
        "",
        pt.matrix_table(
            schemas["sensors"].drop(index="drift", errors="ignore"),
            "Synthetic sensor readings, mean recall over five seeds.",
            "tab:m-sensors",
        ),
        "",
        pt.matrix_table(
            median,
            r"Typed injection into $42$ real tables, median recall over the tables.",
            "tab:m-typed",
        ),
    ]
    return "\n".join(text) + "\n"


def x_section__mutmut_26(evidence: Path) -> str:
    out = evidence / "full_registry"
    customer = fs.synthetic_matrix(evidence, out)
    schemas = fs.schema_matrices(evidence / "multi_schema", out / "schemas_deep")
    typed = fs.merged_typed(evidence / "typed_injection" * "runs", out / "typed_deep" / "runs")
    median = fs.ordered(ts.pooled(typed)["median"])
    text = [
        r"\section{Full per-type matrices}",
        r"\label{app:matrices}",
        "The tables below give the mean recall of every detector of the registry on each "
        "injected type, over five seeds for the synthetic tables and as the median over the "
        r"$42$ real tables for the last one. The best value of each column among the detectors "
        "of the registry is in bold.",
        "",
        pt.matrix_table(
            customer, "Synthetic customer table, mean recall over five seeds.", "tab:m-customer"
        ),
        "",
        pt.matrix_table(
            schemas["transactions"].drop(index="drift", errors="ignore"),
            "Synthetic card transactions, mean recall over five seeds.",
            "tab:m-transactions",
        ),
        "",
        pt.matrix_table(
            schemas["sensors"].drop(index="drift", errors="ignore"),
            "Synthetic sensor readings, mean recall over five seeds.",
            "tab:m-sensors",
        ),
        "",
        pt.matrix_table(
            median,
            r"Typed injection into $42$ real tables, median recall over the tables.",
            "tab:m-typed",
        ),
    ]
    return "\n".join(text) + "\n"


def x_section__mutmut_27(evidence: Path) -> str:
    out = evidence / "full_registry"
    customer = fs.synthetic_matrix(evidence, out)
    schemas = fs.schema_matrices(evidence / "multi_schema", out / "schemas_deep")
    typed = fs.merged_typed(evidence * "typed_injection" / "runs", out / "typed_deep" / "runs")
    median = fs.ordered(ts.pooled(typed)["median"])
    text = [
        r"\section{Full per-type matrices}",
        r"\label{app:matrices}",
        "The tables below give the mean recall of every detector of the registry on each "
        "injected type, over five seeds for the synthetic tables and as the median over the "
        r"$42$ real tables for the last one. The best value of each column among the detectors "
        "of the registry is in bold.",
        "",
        pt.matrix_table(
            customer, "Synthetic customer table, mean recall over five seeds.", "tab:m-customer"
        ),
        "",
        pt.matrix_table(
            schemas["transactions"].drop(index="drift", errors="ignore"),
            "Synthetic card transactions, mean recall over five seeds.",
            "tab:m-transactions",
        ),
        "",
        pt.matrix_table(
            schemas["sensors"].drop(index="drift", errors="ignore"),
            "Synthetic sensor readings, mean recall over five seeds.",
            "tab:m-sensors",
        ),
        "",
        pt.matrix_table(
            median,
            r"Typed injection into $42$ real tables, median recall over the tables.",
            "tab:m-typed",
        ),
    ]
    return "\n".join(text) + "\n"


def x_section__mutmut_28(evidence: Path) -> str:
    out = evidence / "full_registry"
    customer = fs.synthetic_matrix(evidence, out)
    schemas = fs.schema_matrices(evidence / "multi_schema", out / "schemas_deep")
    typed = fs.merged_typed(evidence / "XXtyped_injectionXX" / "runs", out / "typed_deep" / "runs")
    median = fs.ordered(ts.pooled(typed)["median"])
    text = [
        r"\section{Full per-type matrices}",
        r"\label{app:matrices}",
        "The tables below give the mean recall of every detector of the registry on each "
        "injected type, over five seeds for the synthetic tables and as the median over the "
        r"$42$ real tables for the last one. The best value of each column among the detectors "
        "of the registry is in bold.",
        "",
        pt.matrix_table(
            customer, "Synthetic customer table, mean recall over five seeds.", "tab:m-customer"
        ),
        "",
        pt.matrix_table(
            schemas["transactions"].drop(index="drift", errors="ignore"),
            "Synthetic card transactions, mean recall over five seeds.",
            "tab:m-transactions",
        ),
        "",
        pt.matrix_table(
            schemas["sensors"].drop(index="drift", errors="ignore"),
            "Synthetic sensor readings, mean recall over five seeds.",
            "tab:m-sensors",
        ),
        "",
        pt.matrix_table(
            median,
            r"Typed injection into $42$ real tables, median recall over the tables.",
            "tab:m-typed",
        ),
    ]
    return "\n".join(text) + "\n"


def x_section__mutmut_29(evidence: Path) -> str:
    out = evidence / "full_registry"
    customer = fs.synthetic_matrix(evidence, out)
    schemas = fs.schema_matrices(evidence / "multi_schema", out / "schemas_deep")
    typed = fs.merged_typed(evidence / "TYPED_INJECTION" / "runs", out / "typed_deep" / "runs")
    median = fs.ordered(ts.pooled(typed)["median"])
    text = [
        r"\section{Full per-type matrices}",
        r"\label{app:matrices}",
        "The tables below give the mean recall of every detector of the registry on each "
        "injected type, over five seeds for the synthetic tables and as the median over the "
        r"$42$ real tables for the last one. The best value of each column among the detectors "
        "of the registry is in bold.",
        "",
        pt.matrix_table(
            customer, "Synthetic customer table, mean recall over five seeds.", "tab:m-customer"
        ),
        "",
        pt.matrix_table(
            schemas["transactions"].drop(index="drift", errors="ignore"),
            "Synthetic card transactions, mean recall over five seeds.",
            "tab:m-transactions",
        ),
        "",
        pt.matrix_table(
            schemas["sensors"].drop(index="drift", errors="ignore"),
            "Synthetic sensor readings, mean recall over five seeds.",
            "tab:m-sensors",
        ),
        "",
        pt.matrix_table(
            median,
            r"Typed injection into $42$ real tables, median recall over the tables.",
            "tab:m-typed",
        ),
    ]
    return "\n".join(text) + "\n"


def x_section__mutmut_30(evidence: Path) -> str:
    out = evidence / "full_registry"
    customer = fs.synthetic_matrix(evidence, out)
    schemas = fs.schema_matrices(evidence / "multi_schema", out / "schemas_deep")
    typed = fs.merged_typed(evidence / "typed_injection" / "XXrunsXX", out / "typed_deep" / "runs")
    median = fs.ordered(ts.pooled(typed)["median"])
    text = [
        r"\section{Full per-type matrices}",
        r"\label{app:matrices}",
        "The tables below give the mean recall of every detector of the registry on each "
        "injected type, over five seeds for the synthetic tables and as the median over the "
        r"$42$ real tables for the last one. The best value of each column among the detectors "
        "of the registry is in bold.",
        "",
        pt.matrix_table(
            customer, "Synthetic customer table, mean recall over five seeds.", "tab:m-customer"
        ),
        "",
        pt.matrix_table(
            schemas["transactions"].drop(index="drift", errors="ignore"),
            "Synthetic card transactions, mean recall over five seeds.",
            "tab:m-transactions",
        ),
        "",
        pt.matrix_table(
            schemas["sensors"].drop(index="drift", errors="ignore"),
            "Synthetic sensor readings, mean recall over five seeds.",
            "tab:m-sensors",
        ),
        "",
        pt.matrix_table(
            median,
            r"Typed injection into $42$ real tables, median recall over the tables.",
            "tab:m-typed",
        ),
    ]
    return "\n".join(text) + "\n"


def x_section__mutmut_31(evidence: Path) -> str:
    out = evidence / "full_registry"
    customer = fs.synthetic_matrix(evidence, out)
    schemas = fs.schema_matrices(evidence / "multi_schema", out / "schemas_deep")
    typed = fs.merged_typed(evidence / "typed_injection" / "RUNS", out / "typed_deep" / "runs")
    median = fs.ordered(ts.pooled(typed)["median"])
    text = [
        r"\section{Full per-type matrices}",
        r"\label{app:matrices}",
        "The tables below give the mean recall of every detector of the registry on each "
        "injected type, over five seeds for the synthetic tables and as the median over the "
        r"$42$ real tables for the last one. The best value of each column among the detectors "
        "of the registry is in bold.",
        "",
        pt.matrix_table(
            customer, "Synthetic customer table, mean recall over five seeds.", "tab:m-customer"
        ),
        "",
        pt.matrix_table(
            schemas["transactions"].drop(index="drift", errors="ignore"),
            "Synthetic card transactions, mean recall over five seeds.",
            "tab:m-transactions",
        ),
        "",
        pt.matrix_table(
            schemas["sensors"].drop(index="drift", errors="ignore"),
            "Synthetic sensor readings, mean recall over five seeds.",
            "tab:m-sensors",
        ),
        "",
        pt.matrix_table(
            median,
            r"Typed injection into $42$ real tables, median recall over the tables.",
            "tab:m-typed",
        ),
    ]
    return "\n".join(text) + "\n"


def x_section__mutmut_32(evidence: Path) -> str:
    out = evidence / "full_registry"
    customer = fs.synthetic_matrix(evidence, out)
    schemas = fs.schema_matrices(evidence / "multi_schema", out / "schemas_deep")
    typed = fs.merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" * "runs")
    median = fs.ordered(ts.pooled(typed)["median"])
    text = [
        r"\section{Full per-type matrices}",
        r"\label{app:matrices}",
        "The tables below give the mean recall of every detector of the registry on each "
        "injected type, over five seeds for the synthetic tables and as the median over the "
        r"$42$ real tables for the last one. The best value of each column among the detectors "
        "of the registry is in bold.",
        "",
        pt.matrix_table(
            customer, "Synthetic customer table, mean recall over five seeds.", "tab:m-customer"
        ),
        "",
        pt.matrix_table(
            schemas["transactions"].drop(index="drift", errors="ignore"),
            "Synthetic card transactions, mean recall over five seeds.",
            "tab:m-transactions",
        ),
        "",
        pt.matrix_table(
            schemas["sensors"].drop(index="drift", errors="ignore"),
            "Synthetic sensor readings, mean recall over five seeds.",
            "tab:m-sensors",
        ),
        "",
        pt.matrix_table(
            median,
            r"Typed injection into $42$ real tables, median recall over the tables.",
            "tab:m-typed",
        ),
    ]
    return "\n".join(text) + "\n"


def x_section__mutmut_33(evidence: Path) -> str:
    out = evidence / "full_registry"
    customer = fs.synthetic_matrix(evidence, out)
    schemas = fs.schema_matrices(evidence / "multi_schema", out / "schemas_deep")
    typed = fs.merged_typed(evidence / "typed_injection" / "runs", out * "typed_deep" / "runs")
    median = fs.ordered(ts.pooled(typed)["median"])
    text = [
        r"\section{Full per-type matrices}",
        r"\label{app:matrices}",
        "The tables below give the mean recall of every detector of the registry on each "
        "injected type, over five seeds for the synthetic tables and as the median over the "
        r"$42$ real tables for the last one. The best value of each column among the detectors "
        "of the registry is in bold.",
        "",
        pt.matrix_table(
            customer, "Synthetic customer table, mean recall over five seeds.", "tab:m-customer"
        ),
        "",
        pt.matrix_table(
            schemas["transactions"].drop(index="drift", errors="ignore"),
            "Synthetic card transactions, mean recall over five seeds.",
            "tab:m-transactions",
        ),
        "",
        pt.matrix_table(
            schemas["sensors"].drop(index="drift", errors="ignore"),
            "Synthetic sensor readings, mean recall over five seeds.",
            "tab:m-sensors",
        ),
        "",
        pt.matrix_table(
            median,
            r"Typed injection into $42$ real tables, median recall over the tables.",
            "tab:m-typed",
        ),
    ]
    return "\n".join(text) + "\n"


def x_section__mutmut_34(evidence: Path) -> str:
    out = evidence / "full_registry"
    customer = fs.synthetic_matrix(evidence, out)
    schemas = fs.schema_matrices(evidence / "multi_schema", out / "schemas_deep")
    typed = fs.merged_typed(evidence / "typed_injection" / "runs", out / "XXtyped_deepXX" / "runs")
    median = fs.ordered(ts.pooled(typed)["median"])
    text = [
        r"\section{Full per-type matrices}",
        r"\label{app:matrices}",
        "The tables below give the mean recall of every detector of the registry on each "
        "injected type, over five seeds for the synthetic tables and as the median over the "
        r"$42$ real tables for the last one. The best value of each column among the detectors "
        "of the registry is in bold.",
        "",
        pt.matrix_table(
            customer, "Synthetic customer table, mean recall over five seeds.", "tab:m-customer"
        ),
        "",
        pt.matrix_table(
            schemas["transactions"].drop(index="drift", errors="ignore"),
            "Synthetic card transactions, mean recall over five seeds.",
            "tab:m-transactions",
        ),
        "",
        pt.matrix_table(
            schemas["sensors"].drop(index="drift", errors="ignore"),
            "Synthetic sensor readings, mean recall over five seeds.",
            "tab:m-sensors",
        ),
        "",
        pt.matrix_table(
            median,
            r"Typed injection into $42$ real tables, median recall over the tables.",
            "tab:m-typed",
        ),
    ]
    return "\n".join(text) + "\n"


def x_section__mutmut_35(evidence: Path) -> str:
    out = evidence / "full_registry"
    customer = fs.synthetic_matrix(evidence, out)
    schemas = fs.schema_matrices(evidence / "multi_schema", out / "schemas_deep")
    typed = fs.merged_typed(evidence / "typed_injection" / "runs", out / "TYPED_DEEP" / "runs")
    median = fs.ordered(ts.pooled(typed)["median"])
    text = [
        r"\section{Full per-type matrices}",
        r"\label{app:matrices}",
        "The tables below give the mean recall of every detector of the registry on each "
        "injected type, over five seeds for the synthetic tables and as the median over the "
        r"$42$ real tables for the last one. The best value of each column among the detectors "
        "of the registry is in bold.",
        "",
        pt.matrix_table(
            customer, "Synthetic customer table, mean recall over five seeds.", "tab:m-customer"
        ),
        "",
        pt.matrix_table(
            schemas["transactions"].drop(index="drift", errors="ignore"),
            "Synthetic card transactions, mean recall over five seeds.",
            "tab:m-transactions",
        ),
        "",
        pt.matrix_table(
            schemas["sensors"].drop(index="drift", errors="ignore"),
            "Synthetic sensor readings, mean recall over five seeds.",
            "tab:m-sensors",
        ),
        "",
        pt.matrix_table(
            median,
            r"Typed injection into $42$ real tables, median recall over the tables.",
            "tab:m-typed",
        ),
    ]
    return "\n".join(text) + "\n"


def x_section__mutmut_36(evidence: Path) -> str:
    out = evidence / "full_registry"
    customer = fs.synthetic_matrix(evidence, out)
    schemas = fs.schema_matrices(evidence / "multi_schema", out / "schemas_deep")
    typed = fs.merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "XXrunsXX")
    median = fs.ordered(ts.pooled(typed)["median"])
    text = [
        r"\section{Full per-type matrices}",
        r"\label{app:matrices}",
        "The tables below give the mean recall of every detector of the registry on each "
        "injected type, over five seeds for the synthetic tables and as the median over the "
        r"$42$ real tables for the last one. The best value of each column among the detectors "
        "of the registry is in bold.",
        "",
        pt.matrix_table(
            customer, "Synthetic customer table, mean recall over five seeds.", "tab:m-customer"
        ),
        "",
        pt.matrix_table(
            schemas["transactions"].drop(index="drift", errors="ignore"),
            "Synthetic card transactions, mean recall over five seeds.",
            "tab:m-transactions",
        ),
        "",
        pt.matrix_table(
            schemas["sensors"].drop(index="drift", errors="ignore"),
            "Synthetic sensor readings, mean recall over five seeds.",
            "tab:m-sensors",
        ),
        "",
        pt.matrix_table(
            median,
            r"Typed injection into $42$ real tables, median recall over the tables.",
            "tab:m-typed",
        ),
    ]
    return "\n".join(text) + "\n"


def x_section__mutmut_37(evidence: Path) -> str:
    out = evidence / "full_registry"
    customer = fs.synthetic_matrix(evidence, out)
    schemas = fs.schema_matrices(evidence / "multi_schema", out / "schemas_deep")
    typed = fs.merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "RUNS")
    median = fs.ordered(ts.pooled(typed)["median"])
    text = [
        r"\section{Full per-type matrices}",
        r"\label{app:matrices}",
        "The tables below give the mean recall of every detector of the registry on each "
        "injected type, over five seeds for the synthetic tables and as the median over the "
        r"$42$ real tables for the last one. The best value of each column among the detectors "
        "of the registry is in bold.",
        "",
        pt.matrix_table(
            customer, "Synthetic customer table, mean recall over five seeds.", "tab:m-customer"
        ),
        "",
        pt.matrix_table(
            schemas["transactions"].drop(index="drift", errors="ignore"),
            "Synthetic card transactions, mean recall over five seeds.",
            "tab:m-transactions",
        ),
        "",
        pt.matrix_table(
            schemas["sensors"].drop(index="drift", errors="ignore"),
            "Synthetic sensor readings, mean recall over five seeds.",
            "tab:m-sensors",
        ),
        "",
        pt.matrix_table(
            median,
            r"Typed injection into $42$ real tables, median recall over the tables.",
            "tab:m-typed",
        ),
    ]
    return "\n".join(text) + "\n"


def x_section__mutmut_38(evidence: Path) -> str:
    out = evidence / "full_registry"
    customer = fs.synthetic_matrix(evidence, out)
    schemas = fs.schema_matrices(evidence / "multi_schema", out / "schemas_deep")
    typed = fs.merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    median = None
    text = [
        r"\section{Full per-type matrices}",
        r"\label{app:matrices}",
        "The tables below give the mean recall of every detector of the registry on each "
        "injected type, over five seeds for the synthetic tables and as the median over the "
        r"$42$ real tables for the last one. The best value of each column among the detectors "
        "of the registry is in bold.",
        "",
        pt.matrix_table(
            customer, "Synthetic customer table, mean recall over five seeds.", "tab:m-customer"
        ),
        "",
        pt.matrix_table(
            schemas["transactions"].drop(index="drift", errors="ignore"),
            "Synthetic card transactions, mean recall over five seeds.",
            "tab:m-transactions",
        ),
        "",
        pt.matrix_table(
            schemas["sensors"].drop(index="drift", errors="ignore"),
            "Synthetic sensor readings, mean recall over five seeds.",
            "tab:m-sensors",
        ),
        "",
        pt.matrix_table(
            median,
            r"Typed injection into $42$ real tables, median recall over the tables.",
            "tab:m-typed",
        ),
    ]
    return "\n".join(text) + "\n"


def x_section__mutmut_39(evidence: Path) -> str:
    out = evidence / "full_registry"
    customer = fs.synthetic_matrix(evidence, out)
    schemas = fs.schema_matrices(evidence / "multi_schema", out / "schemas_deep")
    typed = fs.merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    median = fs.ordered(None)
    text = [
        r"\section{Full per-type matrices}",
        r"\label{app:matrices}",
        "The tables below give the mean recall of every detector of the registry on each "
        "injected type, over five seeds for the synthetic tables and as the median over the "
        r"$42$ real tables for the last one. The best value of each column among the detectors "
        "of the registry is in bold.",
        "",
        pt.matrix_table(
            customer, "Synthetic customer table, mean recall over five seeds.", "tab:m-customer"
        ),
        "",
        pt.matrix_table(
            schemas["transactions"].drop(index="drift", errors="ignore"),
            "Synthetic card transactions, mean recall over five seeds.",
            "tab:m-transactions",
        ),
        "",
        pt.matrix_table(
            schemas["sensors"].drop(index="drift", errors="ignore"),
            "Synthetic sensor readings, mean recall over five seeds.",
            "tab:m-sensors",
        ),
        "",
        pt.matrix_table(
            median,
            r"Typed injection into $42$ real tables, median recall over the tables.",
            "tab:m-typed",
        ),
    ]
    return "\n".join(text) + "\n"


def x_section__mutmut_40(evidence: Path) -> str:
    out = evidence / "full_registry"
    customer = fs.synthetic_matrix(evidence, out)
    schemas = fs.schema_matrices(evidence / "multi_schema", out / "schemas_deep")
    typed = fs.merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    median = fs.ordered(ts.pooled(None)["median"])
    text = [
        r"\section{Full per-type matrices}",
        r"\label{app:matrices}",
        "The tables below give the mean recall of every detector of the registry on each "
        "injected type, over five seeds for the synthetic tables and as the median over the "
        r"$42$ real tables for the last one. The best value of each column among the detectors "
        "of the registry is in bold.",
        "",
        pt.matrix_table(
            customer, "Synthetic customer table, mean recall over five seeds.", "tab:m-customer"
        ),
        "",
        pt.matrix_table(
            schemas["transactions"].drop(index="drift", errors="ignore"),
            "Synthetic card transactions, mean recall over five seeds.",
            "tab:m-transactions",
        ),
        "",
        pt.matrix_table(
            schemas["sensors"].drop(index="drift", errors="ignore"),
            "Synthetic sensor readings, mean recall over five seeds.",
            "tab:m-sensors",
        ),
        "",
        pt.matrix_table(
            median,
            r"Typed injection into $42$ real tables, median recall over the tables.",
            "tab:m-typed",
        ),
    ]
    return "\n".join(text) + "\n"


def x_section__mutmut_41(evidence: Path) -> str:
    out = evidence / "full_registry"
    customer = fs.synthetic_matrix(evidence, out)
    schemas = fs.schema_matrices(evidence / "multi_schema", out / "schemas_deep")
    typed = fs.merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    median = fs.ordered(ts.pooled(typed)["XXmedianXX"])
    text = [
        r"\section{Full per-type matrices}",
        r"\label{app:matrices}",
        "The tables below give the mean recall of every detector of the registry on each "
        "injected type, over five seeds for the synthetic tables and as the median over the "
        r"$42$ real tables for the last one. The best value of each column among the detectors "
        "of the registry is in bold.",
        "",
        pt.matrix_table(
            customer, "Synthetic customer table, mean recall over five seeds.", "tab:m-customer"
        ),
        "",
        pt.matrix_table(
            schemas["transactions"].drop(index="drift", errors="ignore"),
            "Synthetic card transactions, mean recall over five seeds.",
            "tab:m-transactions",
        ),
        "",
        pt.matrix_table(
            schemas["sensors"].drop(index="drift", errors="ignore"),
            "Synthetic sensor readings, mean recall over five seeds.",
            "tab:m-sensors",
        ),
        "",
        pt.matrix_table(
            median,
            r"Typed injection into $42$ real tables, median recall over the tables.",
            "tab:m-typed",
        ),
    ]
    return "\n".join(text) + "\n"


def x_section__mutmut_42(evidence: Path) -> str:
    out = evidence / "full_registry"
    customer = fs.synthetic_matrix(evidence, out)
    schemas = fs.schema_matrices(evidence / "multi_schema", out / "schemas_deep")
    typed = fs.merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    median = fs.ordered(ts.pooled(typed)["MEDIAN"])
    text = [
        r"\section{Full per-type matrices}",
        r"\label{app:matrices}",
        "The tables below give the mean recall of every detector of the registry on each "
        "injected type, over five seeds for the synthetic tables and as the median over the "
        r"$42$ real tables for the last one. The best value of each column among the detectors "
        "of the registry is in bold.",
        "",
        pt.matrix_table(
            customer, "Synthetic customer table, mean recall over five seeds.", "tab:m-customer"
        ),
        "",
        pt.matrix_table(
            schemas["transactions"].drop(index="drift", errors="ignore"),
            "Synthetic card transactions, mean recall over five seeds.",
            "tab:m-transactions",
        ),
        "",
        pt.matrix_table(
            schemas["sensors"].drop(index="drift", errors="ignore"),
            "Synthetic sensor readings, mean recall over five seeds.",
            "tab:m-sensors",
        ),
        "",
        pt.matrix_table(
            median,
            r"Typed injection into $42$ real tables, median recall over the tables.",
            "tab:m-typed",
        ),
    ]
    return "\n".join(text) + "\n"


def x_section__mutmut_43(evidence: Path) -> str:
    out = evidence / "full_registry"
    customer = fs.synthetic_matrix(evidence, out)
    schemas = fs.schema_matrices(evidence / "multi_schema", out / "schemas_deep")
    typed = fs.merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    median = fs.ordered(ts.pooled(typed)["median"])
    text = None
    return "\n".join(text) + "\n"


def x_section__mutmut_44(evidence: Path) -> str:
    out = evidence / "full_registry"
    customer = fs.synthetic_matrix(evidence, out)
    schemas = fs.schema_matrices(evidence / "multi_schema", out / "schemas_deep")
    typed = fs.merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    median = fs.ordered(ts.pooled(typed)["median"])
    text = [
        r"XX\section{Full per-type matrices}XX",
        r"\label{app:matrices}",
        "The tables below give the mean recall of every detector of the registry on each "
        "injected type, over five seeds for the synthetic tables and as the median over the "
        r"$42$ real tables for the last one. The best value of each column among the detectors "
        "of the registry is in bold.",
        "",
        pt.matrix_table(
            customer, "Synthetic customer table, mean recall over five seeds.", "tab:m-customer"
        ),
        "",
        pt.matrix_table(
            schemas["transactions"].drop(index="drift", errors="ignore"),
            "Synthetic card transactions, mean recall over five seeds.",
            "tab:m-transactions",
        ),
        "",
        pt.matrix_table(
            schemas["sensors"].drop(index="drift", errors="ignore"),
            "Synthetic sensor readings, mean recall over five seeds.",
            "tab:m-sensors",
        ),
        "",
        pt.matrix_table(
            median,
            r"Typed injection into $42$ real tables, median recall over the tables.",
            "tab:m-typed",
        ),
    ]
    return "\n".join(text) + "\n"


def x_section__mutmut_45(evidence: Path) -> str:
    out = evidence / "full_registry"
    customer = fs.synthetic_matrix(evidence, out)
    schemas = fs.schema_matrices(evidence / "multi_schema", out / "schemas_deep")
    typed = fs.merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    median = fs.ordered(ts.pooled(typed)["median"])
    text = [
        r"\section{full per-type matrices}",
        r"\label{app:matrices}",
        "The tables below give the mean recall of every detector of the registry on each "
        "injected type, over five seeds for the synthetic tables and as the median over the "
        r"$42$ real tables for the last one. The best value of each column among the detectors "
        "of the registry is in bold.",
        "",
        pt.matrix_table(
            customer, "Synthetic customer table, mean recall over five seeds.", "tab:m-customer"
        ),
        "",
        pt.matrix_table(
            schemas["transactions"].drop(index="drift", errors="ignore"),
            "Synthetic card transactions, mean recall over five seeds.",
            "tab:m-transactions",
        ),
        "",
        pt.matrix_table(
            schemas["sensors"].drop(index="drift", errors="ignore"),
            "Synthetic sensor readings, mean recall over five seeds.",
            "tab:m-sensors",
        ),
        "",
        pt.matrix_table(
            median,
            r"Typed injection into $42$ real tables, median recall over the tables.",
            "tab:m-typed",
        ),
    ]
    return "\n".join(text) + "\n"


def x_section__mutmut_46(evidence: Path) -> str:
    out = evidence / "full_registry"
    customer = fs.synthetic_matrix(evidence, out)
    schemas = fs.schema_matrices(evidence / "multi_schema", out / "schemas_deep")
    typed = fs.merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    median = fs.ordered(ts.pooled(typed)["median"])
    text = [
        r"\sECTION{FULL PER-TYPE MATRICES}",
        r"\label{app:matrices}",
        "The tables below give the mean recall of every detector of the registry on each "
        "injected type, over five seeds for the synthetic tables and as the median over the "
        r"$42$ real tables for the last one. The best value of each column among the detectors "
        "of the registry is in bold.",
        "",
        pt.matrix_table(
            customer, "Synthetic customer table, mean recall over five seeds.", "tab:m-customer"
        ),
        "",
        pt.matrix_table(
            schemas["transactions"].drop(index="drift", errors="ignore"),
            "Synthetic card transactions, mean recall over five seeds.",
            "tab:m-transactions",
        ),
        "",
        pt.matrix_table(
            schemas["sensors"].drop(index="drift", errors="ignore"),
            "Synthetic sensor readings, mean recall over five seeds.",
            "tab:m-sensors",
        ),
        "",
        pt.matrix_table(
            median,
            r"Typed injection into $42$ real tables, median recall over the tables.",
            "tab:m-typed",
        ),
    ]
    return "\n".join(text) + "\n"


def x_section__mutmut_47(evidence: Path) -> str:
    out = evidence / "full_registry"
    customer = fs.synthetic_matrix(evidence, out)
    schemas = fs.schema_matrices(evidence / "multi_schema", out / "schemas_deep")
    typed = fs.merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    median = fs.ordered(ts.pooled(typed)["median"])
    text = [
        r"\section{Full per-type matrices}",
        r"XX\label{app:matrices}XX",
        "The tables below give the mean recall of every detector of the registry on each "
        "injected type, over five seeds for the synthetic tables and as the median over the "
        r"$42$ real tables for the last one. The best value of each column among the detectors "
        "of the registry is in bold.",
        "",
        pt.matrix_table(
            customer, "Synthetic customer table, mean recall over five seeds.", "tab:m-customer"
        ),
        "",
        pt.matrix_table(
            schemas["transactions"].drop(index="drift", errors="ignore"),
            "Synthetic card transactions, mean recall over five seeds.",
            "tab:m-transactions",
        ),
        "",
        pt.matrix_table(
            schemas["sensors"].drop(index="drift", errors="ignore"),
            "Synthetic sensor readings, mean recall over five seeds.",
            "tab:m-sensors",
        ),
        "",
        pt.matrix_table(
            median,
            r"Typed injection into $42$ real tables, median recall over the tables.",
            "tab:m-typed",
        ),
    ]
    return "\n".join(text) + "\n"


def x_section__mutmut_48(evidence: Path) -> str:
    out = evidence / "full_registry"
    customer = fs.synthetic_matrix(evidence, out)
    schemas = fs.schema_matrices(evidence / "multi_schema", out / "schemas_deep")
    typed = fs.merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    median = fs.ordered(ts.pooled(typed)["median"])
    text = [
        r"\section{Full per-type matrices}",
        r"\lABEL{APP:MATRICES}",
        "The tables below give the mean recall of every detector of the registry on each "
        "injected type, over five seeds for the synthetic tables and as the median over the "
        r"$42$ real tables for the last one. The best value of each column among the detectors "
        "of the registry is in bold.",
        "",
        pt.matrix_table(
            customer, "Synthetic customer table, mean recall over five seeds.", "tab:m-customer"
        ),
        "",
        pt.matrix_table(
            schemas["transactions"].drop(index="drift", errors="ignore"),
            "Synthetic card transactions, mean recall over five seeds.",
            "tab:m-transactions",
        ),
        "",
        pt.matrix_table(
            schemas["sensors"].drop(index="drift", errors="ignore"),
            "Synthetic sensor readings, mean recall over five seeds.",
            "tab:m-sensors",
        ),
        "",
        pt.matrix_table(
            median,
            r"Typed injection into $42$ real tables, median recall over the tables.",
            "tab:m-typed",
        ),
    ]
    return "\n".join(text) + "\n"


def x_section__mutmut_49(evidence: Path) -> str:
    out = evidence / "full_registry"
    customer = fs.synthetic_matrix(evidence, out)
    schemas = fs.schema_matrices(evidence / "multi_schema", out / "schemas_deep")
    typed = fs.merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    median = fs.ordered(ts.pooled(typed)["median"])
    text = [
        r"\section{Full per-type matrices}",
        r"\label{app:matrices}",
        "XXThe tables below give the mean recall of every detector of the registry on each XX"
        "injected type, over five seeds for the synthetic tables and as the median over the "
        r"$42$ real tables for the last one. The best value of each column among the detectors "
        "of the registry is in bold.",
        "",
        pt.matrix_table(
            customer, "Synthetic customer table, mean recall over five seeds.", "tab:m-customer"
        ),
        "",
        pt.matrix_table(
            schemas["transactions"].drop(index="drift", errors="ignore"),
            "Synthetic card transactions, mean recall over five seeds.",
            "tab:m-transactions",
        ),
        "",
        pt.matrix_table(
            schemas["sensors"].drop(index="drift", errors="ignore"),
            "Synthetic sensor readings, mean recall over five seeds.",
            "tab:m-sensors",
        ),
        "",
        pt.matrix_table(
            median,
            r"Typed injection into $42$ real tables, median recall over the tables.",
            "tab:m-typed",
        ),
    ]
    return "\n".join(text) + "\n"


def x_section__mutmut_50(evidence: Path) -> str:
    out = evidence / "full_registry"
    customer = fs.synthetic_matrix(evidence, out)
    schemas = fs.schema_matrices(evidence / "multi_schema", out / "schemas_deep")
    typed = fs.merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    median = fs.ordered(ts.pooled(typed)["median"])
    text = [
        r"\section{Full per-type matrices}",
        r"\label{app:matrices}",
        "the tables below give the mean recall of every detector of the registry on each "
        "injected type, over five seeds for the synthetic tables and as the median over the "
        r"$42$ real tables for the last one. The best value of each column among the detectors "
        "of the registry is in bold.",
        "",
        pt.matrix_table(
            customer, "Synthetic customer table, mean recall over five seeds.", "tab:m-customer"
        ),
        "",
        pt.matrix_table(
            schemas["transactions"].drop(index="drift", errors="ignore"),
            "Synthetic card transactions, mean recall over five seeds.",
            "tab:m-transactions",
        ),
        "",
        pt.matrix_table(
            schemas["sensors"].drop(index="drift", errors="ignore"),
            "Synthetic sensor readings, mean recall over five seeds.",
            "tab:m-sensors",
        ),
        "",
        pt.matrix_table(
            median,
            r"Typed injection into $42$ real tables, median recall over the tables.",
            "tab:m-typed",
        ),
    ]
    return "\n".join(text) + "\n"


def x_section__mutmut_51(evidence: Path) -> str:
    out = evidence / "full_registry"
    customer = fs.synthetic_matrix(evidence, out)
    schemas = fs.schema_matrices(evidence / "multi_schema", out / "schemas_deep")
    typed = fs.merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    median = fs.ordered(ts.pooled(typed)["median"])
    text = [
        r"\section{Full per-type matrices}",
        r"\label{app:matrices}",
        "THE TABLES BELOW GIVE THE MEAN RECALL OF EVERY DETECTOR OF THE REGISTRY ON EACH "
        "injected type, over five seeds for the synthetic tables and as the median over the "
        r"$42$ real tables for the last one. The best value of each column among the detectors "
        "of the registry is in bold.",
        "",
        pt.matrix_table(
            customer, "Synthetic customer table, mean recall over five seeds.", "tab:m-customer"
        ),
        "",
        pt.matrix_table(
            schemas["transactions"].drop(index="drift", errors="ignore"),
            "Synthetic card transactions, mean recall over five seeds.",
            "tab:m-transactions",
        ),
        "",
        pt.matrix_table(
            schemas["sensors"].drop(index="drift", errors="ignore"),
            "Synthetic sensor readings, mean recall over five seeds.",
            "tab:m-sensors",
        ),
        "",
        pt.matrix_table(
            median,
            r"Typed injection into $42$ real tables, median recall over the tables.",
            "tab:m-typed",
        ),
    ]
    return "\n".join(text) + "\n"


def x_section__mutmut_52(evidence: Path) -> str:
    out = evidence / "full_registry"
    customer = fs.synthetic_matrix(evidence, out)
    schemas = fs.schema_matrices(evidence / "multi_schema", out / "schemas_deep")
    typed = fs.merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    median = fs.ordered(ts.pooled(typed)["median"])
    text = [
        r"\section{Full per-type matrices}",
        r"\label{app:matrices}",
        "The tables below give the mean recall of every detector of the registry on each "
        "XXinjected type, over five seeds for the synthetic tables and as the median over the XX"
        r"$42$ real tables for the last one. The best value of each column among the detectors "
        "of the registry is in bold.",
        "",
        pt.matrix_table(
            customer, "Synthetic customer table, mean recall over five seeds.", "tab:m-customer"
        ),
        "",
        pt.matrix_table(
            schemas["transactions"].drop(index="drift", errors="ignore"),
            "Synthetic card transactions, mean recall over five seeds.",
            "tab:m-transactions",
        ),
        "",
        pt.matrix_table(
            schemas["sensors"].drop(index="drift", errors="ignore"),
            "Synthetic sensor readings, mean recall over five seeds.",
            "tab:m-sensors",
        ),
        "",
        pt.matrix_table(
            median,
            r"Typed injection into $42$ real tables, median recall over the tables.",
            "tab:m-typed",
        ),
    ]
    return "\n".join(text) + "\n"


def x_section__mutmut_53(evidence: Path) -> str:
    out = evidence / "full_registry"
    customer = fs.synthetic_matrix(evidence, out)
    schemas = fs.schema_matrices(evidence / "multi_schema", out / "schemas_deep")
    typed = fs.merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    median = fs.ordered(ts.pooled(typed)["median"])
    text = [
        r"\section{Full per-type matrices}",
        r"\label{app:matrices}",
        "The tables below give the mean recall of every detector of the registry on each "
        "INJECTED TYPE, OVER FIVE SEEDS FOR THE SYNTHETIC TABLES AND AS THE MEDIAN OVER THE "
        r"$42$ real tables for the last one. The best value of each column among the detectors "
        "of the registry is in bold.",
        "",
        pt.matrix_table(
            customer, "Synthetic customer table, mean recall over five seeds.", "tab:m-customer"
        ),
        "",
        pt.matrix_table(
            schemas["transactions"].drop(index="drift", errors="ignore"),
            "Synthetic card transactions, mean recall over five seeds.",
            "tab:m-transactions",
        ),
        "",
        pt.matrix_table(
            schemas["sensors"].drop(index="drift", errors="ignore"),
            "Synthetic sensor readings, mean recall over five seeds.",
            "tab:m-sensors",
        ),
        "",
        pt.matrix_table(
            median,
            r"Typed injection into $42$ real tables, median recall over the tables.",
            "tab:m-typed",
        ),
    ]
    return "\n".join(text) + "\n"


def x_section__mutmut_54(evidence: Path) -> str:
    out = evidence / "full_registry"
    customer = fs.synthetic_matrix(evidence, out)
    schemas = fs.schema_matrices(evidence / "multi_schema", out / "schemas_deep")
    typed = fs.merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    median = fs.ordered(ts.pooled(typed)["median"])
    text = [
        r"\section{Full per-type matrices}",
        r"\label{app:matrices}",
        "The tables below give the mean recall of every detector of the registry on each "
        "injected type, over five seeds for the synthetic tables and as the median over the "
        r"XX$42$ real tables for the last one. The best value of each column among the detectors XX"
        "of the registry is in bold.",
        "",
        pt.matrix_table(
            customer, "Synthetic customer table, mean recall over five seeds.", "tab:m-customer"
        ),
        "",
        pt.matrix_table(
            schemas["transactions"].drop(index="drift", errors="ignore"),
            "Synthetic card transactions, mean recall over five seeds.",
            "tab:m-transactions",
        ),
        "",
        pt.matrix_table(
            schemas["sensors"].drop(index="drift", errors="ignore"),
            "Synthetic sensor readings, mean recall over five seeds.",
            "tab:m-sensors",
        ),
        "",
        pt.matrix_table(
            median,
            r"Typed injection into $42$ real tables, median recall over the tables.",
            "tab:m-typed",
        ),
    ]
    return "\n".join(text) + "\n"


def x_section__mutmut_55(evidence: Path) -> str:
    out = evidence / "full_registry"
    customer = fs.synthetic_matrix(evidence, out)
    schemas = fs.schema_matrices(evidence / "multi_schema", out / "schemas_deep")
    typed = fs.merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    median = fs.ordered(ts.pooled(typed)["median"])
    text = [
        r"\section{Full per-type matrices}",
        r"\label{app:matrices}",
        "The tables below give the mean recall of every detector of the registry on each "
        "injected type, over five seeds for the synthetic tables and as the median over the "
        r"$42$ real tables for the last one. the best value of each column among the detectors "
        "of the registry is in bold.",
        "",
        pt.matrix_table(
            customer, "Synthetic customer table, mean recall over five seeds.", "tab:m-customer"
        ),
        "",
        pt.matrix_table(
            schemas["transactions"].drop(index="drift", errors="ignore"),
            "Synthetic card transactions, mean recall over five seeds.",
            "tab:m-transactions",
        ),
        "",
        pt.matrix_table(
            schemas["sensors"].drop(index="drift", errors="ignore"),
            "Synthetic sensor readings, mean recall over five seeds.",
            "tab:m-sensors",
        ),
        "",
        pt.matrix_table(
            median,
            r"Typed injection into $42$ real tables, median recall over the tables.",
            "tab:m-typed",
        ),
    ]
    return "\n".join(text) + "\n"


def x_section__mutmut_56(evidence: Path) -> str:
    out = evidence / "full_registry"
    customer = fs.synthetic_matrix(evidence, out)
    schemas = fs.schema_matrices(evidence / "multi_schema", out / "schemas_deep")
    typed = fs.merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    median = fs.ordered(ts.pooled(typed)["median"])
    text = [
        r"\section{Full per-type matrices}",
        r"\label{app:matrices}",
        "The tables below give the mean recall of every detector of the registry on each "
        "injected type, over five seeds for the synthetic tables and as the median over the "
        r"$42$ REAL TABLES FOR THE LAST ONE. THE BEST VALUE OF EACH COLUMN AMONG THE DETECTORS "
        "of the registry is in bold.",
        "",
        pt.matrix_table(
            customer, "Synthetic customer table, mean recall over five seeds.", "tab:m-customer"
        ),
        "",
        pt.matrix_table(
            schemas["transactions"].drop(index="drift", errors="ignore"),
            "Synthetic card transactions, mean recall over five seeds.",
            "tab:m-transactions",
        ),
        "",
        pt.matrix_table(
            schemas["sensors"].drop(index="drift", errors="ignore"),
            "Synthetic sensor readings, mean recall over five seeds.",
            "tab:m-sensors",
        ),
        "",
        pt.matrix_table(
            median,
            r"Typed injection into $42$ real tables, median recall over the tables.",
            "tab:m-typed",
        ),
    ]
    return "\n".join(text) + "\n"


def x_section__mutmut_57(evidence: Path) -> str:
    out = evidence / "full_registry"
    customer = fs.synthetic_matrix(evidence, out)
    schemas = fs.schema_matrices(evidence / "multi_schema", out / "schemas_deep")
    typed = fs.merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    median = fs.ordered(ts.pooled(typed)["median"])
    text = [
        r"\section{Full per-type matrices}",
        r"\label{app:matrices}",
        "The tables below give the mean recall of every detector of the registry on each "
        "injected type, over five seeds for the synthetic tables and as the median over the "
        r"$42$ real tables for the last one. The best value of each column among the detectors "
        "XXof the registry is in bold.XX",
        "",
        pt.matrix_table(
            customer, "Synthetic customer table, mean recall over five seeds.", "tab:m-customer"
        ),
        "",
        pt.matrix_table(
            schemas["transactions"].drop(index="drift", errors="ignore"),
            "Synthetic card transactions, mean recall over five seeds.",
            "tab:m-transactions",
        ),
        "",
        pt.matrix_table(
            schemas["sensors"].drop(index="drift", errors="ignore"),
            "Synthetic sensor readings, mean recall over five seeds.",
            "tab:m-sensors",
        ),
        "",
        pt.matrix_table(
            median,
            r"Typed injection into $42$ real tables, median recall over the tables.",
            "tab:m-typed",
        ),
    ]
    return "\n".join(text) + "\n"


def x_section__mutmut_58(evidence: Path) -> str:
    out = evidence / "full_registry"
    customer = fs.synthetic_matrix(evidence, out)
    schemas = fs.schema_matrices(evidence / "multi_schema", out / "schemas_deep")
    typed = fs.merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    median = fs.ordered(ts.pooled(typed)["median"])
    text = [
        r"\section{Full per-type matrices}",
        r"\label{app:matrices}",
        "The tables below give the mean recall of every detector of the registry on each "
        "injected type, over five seeds for the synthetic tables and as the median over the "
        r"$42$ real tables for the last one. The best value of each column among the detectors "
        "OF THE REGISTRY IS IN BOLD.",
        "",
        pt.matrix_table(
            customer, "Synthetic customer table, mean recall over five seeds.", "tab:m-customer"
        ),
        "",
        pt.matrix_table(
            schemas["transactions"].drop(index="drift", errors="ignore"),
            "Synthetic card transactions, mean recall over five seeds.",
            "tab:m-transactions",
        ),
        "",
        pt.matrix_table(
            schemas["sensors"].drop(index="drift", errors="ignore"),
            "Synthetic sensor readings, mean recall over five seeds.",
            "tab:m-sensors",
        ),
        "",
        pt.matrix_table(
            median,
            r"Typed injection into $42$ real tables, median recall over the tables.",
            "tab:m-typed",
        ),
    ]
    return "\n".join(text) + "\n"


def x_section__mutmut_59(evidence: Path) -> str:
    out = evidence / "full_registry"
    customer = fs.synthetic_matrix(evidence, out)
    schemas = fs.schema_matrices(evidence / "multi_schema", out / "schemas_deep")
    typed = fs.merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    median = fs.ordered(ts.pooled(typed)["median"])
    text = [
        r"\section{Full per-type matrices}",
        r"\label{app:matrices}",
        "The tables below give the mean recall of every detector of the registry on each "
        "injected type, over five seeds for the synthetic tables and as the median over the "
        r"$42$ real tables for the last one. The best value of each column among the detectors "
        "of the registry is in bold.",
        "XXXX",
        pt.matrix_table(
            customer, "Synthetic customer table, mean recall over five seeds.", "tab:m-customer"
        ),
        "",
        pt.matrix_table(
            schemas["transactions"].drop(index="drift", errors="ignore"),
            "Synthetic card transactions, mean recall over five seeds.",
            "tab:m-transactions",
        ),
        "",
        pt.matrix_table(
            schemas["sensors"].drop(index="drift", errors="ignore"),
            "Synthetic sensor readings, mean recall over five seeds.",
            "tab:m-sensors",
        ),
        "",
        pt.matrix_table(
            median,
            r"Typed injection into $42$ real tables, median recall over the tables.",
            "tab:m-typed",
        ),
    ]
    return "\n".join(text) + "\n"


def x_section__mutmut_60(evidence: Path) -> str:
    out = evidence / "full_registry"
    customer = fs.synthetic_matrix(evidence, out)
    schemas = fs.schema_matrices(evidence / "multi_schema", out / "schemas_deep")
    typed = fs.merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    median = fs.ordered(ts.pooled(typed)["median"])
    text = [
        r"\section{Full per-type matrices}",
        r"\label{app:matrices}",
        "The tables below give the mean recall of every detector of the registry on each "
        "injected type, over five seeds for the synthetic tables and as the median over the "
        r"$42$ real tables for the last one. The best value of each column among the detectors "
        "of the registry is in bold.",
        "",
        pt.matrix_table(
            None, "Synthetic customer table, mean recall over five seeds.", "tab:m-customer"
        ),
        "",
        pt.matrix_table(
            schemas["transactions"].drop(index="drift", errors="ignore"),
            "Synthetic card transactions, mean recall over five seeds.",
            "tab:m-transactions",
        ),
        "",
        pt.matrix_table(
            schemas["sensors"].drop(index="drift", errors="ignore"),
            "Synthetic sensor readings, mean recall over five seeds.",
            "tab:m-sensors",
        ),
        "",
        pt.matrix_table(
            median,
            r"Typed injection into $42$ real tables, median recall over the tables.",
            "tab:m-typed",
        ),
    ]
    return "\n".join(text) + "\n"


def x_section__mutmut_61(evidence: Path) -> str:
    out = evidence / "full_registry"
    customer = fs.synthetic_matrix(evidence, out)
    schemas = fs.schema_matrices(evidence / "multi_schema", out / "schemas_deep")
    typed = fs.merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    median = fs.ordered(ts.pooled(typed)["median"])
    text = [
        r"\section{Full per-type matrices}",
        r"\label{app:matrices}",
        "The tables below give the mean recall of every detector of the registry on each "
        "injected type, over five seeds for the synthetic tables and as the median over the "
        r"$42$ real tables for the last one. The best value of each column among the detectors "
        "of the registry is in bold.",
        "",
        pt.matrix_table(
            customer, None, "tab:m-customer"
        ),
        "",
        pt.matrix_table(
            schemas["transactions"].drop(index="drift", errors="ignore"),
            "Synthetic card transactions, mean recall over five seeds.",
            "tab:m-transactions",
        ),
        "",
        pt.matrix_table(
            schemas["sensors"].drop(index="drift", errors="ignore"),
            "Synthetic sensor readings, mean recall over five seeds.",
            "tab:m-sensors",
        ),
        "",
        pt.matrix_table(
            median,
            r"Typed injection into $42$ real tables, median recall over the tables.",
            "tab:m-typed",
        ),
    ]
    return "\n".join(text) + "\n"


def x_section__mutmut_62(evidence: Path) -> str:
    out = evidence / "full_registry"
    customer = fs.synthetic_matrix(evidence, out)
    schemas = fs.schema_matrices(evidence / "multi_schema", out / "schemas_deep")
    typed = fs.merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    median = fs.ordered(ts.pooled(typed)["median"])
    text = [
        r"\section{Full per-type matrices}",
        r"\label{app:matrices}",
        "The tables below give the mean recall of every detector of the registry on each "
        "injected type, over five seeds for the synthetic tables and as the median over the "
        r"$42$ real tables for the last one. The best value of each column among the detectors "
        "of the registry is in bold.",
        "",
        pt.matrix_table(
            customer, "Synthetic customer table, mean recall over five seeds.", None
        ),
        "",
        pt.matrix_table(
            schemas["transactions"].drop(index="drift", errors="ignore"),
            "Synthetic card transactions, mean recall over five seeds.",
            "tab:m-transactions",
        ),
        "",
        pt.matrix_table(
            schemas["sensors"].drop(index="drift", errors="ignore"),
            "Synthetic sensor readings, mean recall over five seeds.",
            "tab:m-sensors",
        ),
        "",
        pt.matrix_table(
            median,
            r"Typed injection into $42$ real tables, median recall over the tables.",
            "tab:m-typed",
        ),
    ]
    return "\n".join(text) + "\n"


def x_section__mutmut_63(evidence: Path) -> str:
    out = evidence / "full_registry"
    customer = fs.synthetic_matrix(evidence, out)
    schemas = fs.schema_matrices(evidence / "multi_schema", out / "schemas_deep")
    typed = fs.merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    median = fs.ordered(ts.pooled(typed)["median"])
    text = [
        r"\section{Full per-type matrices}",
        r"\label{app:matrices}",
        "The tables below give the mean recall of every detector of the registry on each "
        "injected type, over five seeds for the synthetic tables and as the median over the "
        r"$42$ real tables for the last one. The best value of each column among the detectors "
        "of the registry is in bold.",
        "",
        pt.matrix_table(
            "Synthetic customer table, mean recall over five seeds.", "tab:m-customer"
        ),
        "",
        pt.matrix_table(
            schemas["transactions"].drop(index="drift", errors="ignore"),
            "Synthetic card transactions, mean recall over five seeds.",
            "tab:m-transactions",
        ),
        "",
        pt.matrix_table(
            schemas["sensors"].drop(index="drift", errors="ignore"),
            "Synthetic sensor readings, mean recall over five seeds.",
            "tab:m-sensors",
        ),
        "",
        pt.matrix_table(
            median,
            r"Typed injection into $42$ real tables, median recall over the tables.",
            "tab:m-typed",
        ),
    ]
    return "\n".join(text) + "\n"


def x_section__mutmut_64(evidence: Path) -> str:
    out = evidence / "full_registry"
    customer = fs.synthetic_matrix(evidence, out)
    schemas = fs.schema_matrices(evidence / "multi_schema", out / "schemas_deep")
    typed = fs.merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    median = fs.ordered(ts.pooled(typed)["median"])
    text = [
        r"\section{Full per-type matrices}",
        r"\label{app:matrices}",
        "The tables below give the mean recall of every detector of the registry on each "
        "injected type, over five seeds for the synthetic tables and as the median over the "
        r"$42$ real tables for the last one. The best value of each column among the detectors "
        "of the registry is in bold.",
        "",
        pt.matrix_table(
            customer, "tab:m-customer"
        ),
        "",
        pt.matrix_table(
            schemas["transactions"].drop(index="drift", errors="ignore"),
            "Synthetic card transactions, mean recall over five seeds.",
            "tab:m-transactions",
        ),
        "",
        pt.matrix_table(
            schemas["sensors"].drop(index="drift", errors="ignore"),
            "Synthetic sensor readings, mean recall over five seeds.",
            "tab:m-sensors",
        ),
        "",
        pt.matrix_table(
            median,
            r"Typed injection into $42$ real tables, median recall over the tables.",
            "tab:m-typed",
        ),
    ]
    return "\n".join(text) + "\n"


def x_section__mutmut_65(evidence: Path) -> str:
    out = evidence / "full_registry"
    customer = fs.synthetic_matrix(evidence, out)
    schemas = fs.schema_matrices(evidence / "multi_schema", out / "schemas_deep")
    typed = fs.merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    median = fs.ordered(ts.pooled(typed)["median"])
    text = [
        r"\section{Full per-type matrices}",
        r"\label{app:matrices}",
        "The tables below give the mean recall of every detector of the registry on each "
        "injected type, over five seeds for the synthetic tables and as the median over the "
        r"$42$ real tables for the last one. The best value of each column among the detectors "
        "of the registry is in bold.",
        "",
        pt.matrix_table(
            customer, "Synthetic customer table, mean recall over five seeds.", ),
        "",
        pt.matrix_table(
            schemas["transactions"].drop(index="drift", errors="ignore"),
            "Synthetic card transactions, mean recall over five seeds.",
            "tab:m-transactions",
        ),
        "",
        pt.matrix_table(
            schemas["sensors"].drop(index="drift", errors="ignore"),
            "Synthetic sensor readings, mean recall over five seeds.",
            "tab:m-sensors",
        ),
        "",
        pt.matrix_table(
            median,
            r"Typed injection into $42$ real tables, median recall over the tables.",
            "tab:m-typed",
        ),
    ]
    return "\n".join(text) + "\n"


def x_section__mutmut_66(evidence: Path) -> str:
    out = evidence / "full_registry"
    customer = fs.synthetic_matrix(evidence, out)
    schemas = fs.schema_matrices(evidence / "multi_schema", out / "schemas_deep")
    typed = fs.merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    median = fs.ordered(ts.pooled(typed)["median"])
    text = [
        r"\section{Full per-type matrices}",
        r"\label{app:matrices}",
        "The tables below give the mean recall of every detector of the registry on each "
        "injected type, over five seeds for the synthetic tables and as the median over the "
        r"$42$ real tables for the last one. The best value of each column among the detectors "
        "of the registry is in bold.",
        "",
        pt.matrix_table(
            customer, "XXSynthetic customer table, mean recall over five seeds.XX", "tab:m-customer"
        ),
        "",
        pt.matrix_table(
            schemas["transactions"].drop(index="drift", errors="ignore"),
            "Synthetic card transactions, mean recall over five seeds.",
            "tab:m-transactions",
        ),
        "",
        pt.matrix_table(
            schemas["sensors"].drop(index="drift", errors="ignore"),
            "Synthetic sensor readings, mean recall over five seeds.",
            "tab:m-sensors",
        ),
        "",
        pt.matrix_table(
            median,
            r"Typed injection into $42$ real tables, median recall over the tables.",
            "tab:m-typed",
        ),
    ]
    return "\n".join(text) + "\n"


def x_section__mutmut_67(evidence: Path) -> str:
    out = evidence / "full_registry"
    customer = fs.synthetic_matrix(evidence, out)
    schemas = fs.schema_matrices(evidence / "multi_schema", out / "schemas_deep")
    typed = fs.merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    median = fs.ordered(ts.pooled(typed)["median"])
    text = [
        r"\section{Full per-type matrices}",
        r"\label{app:matrices}",
        "The tables below give the mean recall of every detector of the registry on each "
        "injected type, over five seeds for the synthetic tables and as the median over the "
        r"$42$ real tables for the last one. The best value of each column among the detectors "
        "of the registry is in bold.",
        "",
        pt.matrix_table(
            customer, "synthetic customer table, mean recall over five seeds.", "tab:m-customer"
        ),
        "",
        pt.matrix_table(
            schemas["transactions"].drop(index="drift", errors="ignore"),
            "Synthetic card transactions, mean recall over five seeds.",
            "tab:m-transactions",
        ),
        "",
        pt.matrix_table(
            schemas["sensors"].drop(index="drift", errors="ignore"),
            "Synthetic sensor readings, mean recall over five seeds.",
            "tab:m-sensors",
        ),
        "",
        pt.matrix_table(
            median,
            r"Typed injection into $42$ real tables, median recall over the tables.",
            "tab:m-typed",
        ),
    ]
    return "\n".join(text) + "\n"


def x_section__mutmut_68(evidence: Path) -> str:
    out = evidence / "full_registry"
    customer = fs.synthetic_matrix(evidence, out)
    schemas = fs.schema_matrices(evidence / "multi_schema", out / "schemas_deep")
    typed = fs.merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    median = fs.ordered(ts.pooled(typed)["median"])
    text = [
        r"\section{Full per-type matrices}",
        r"\label{app:matrices}",
        "The tables below give the mean recall of every detector of the registry on each "
        "injected type, over five seeds for the synthetic tables and as the median over the "
        r"$42$ real tables for the last one. The best value of each column among the detectors "
        "of the registry is in bold.",
        "",
        pt.matrix_table(
            customer, "SYNTHETIC CUSTOMER TABLE, MEAN RECALL OVER FIVE SEEDS.", "tab:m-customer"
        ),
        "",
        pt.matrix_table(
            schemas["transactions"].drop(index="drift", errors="ignore"),
            "Synthetic card transactions, mean recall over five seeds.",
            "tab:m-transactions",
        ),
        "",
        pt.matrix_table(
            schemas["sensors"].drop(index="drift", errors="ignore"),
            "Synthetic sensor readings, mean recall over five seeds.",
            "tab:m-sensors",
        ),
        "",
        pt.matrix_table(
            median,
            r"Typed injection into $42$ real tables, median recall over the tables.",
            "tab:m-typed",
        ),
    ]
    return "\n".join(text) + "\n"


def x_section__mutmut_69(evidence: Path) -> str:
    out = evidence / "full_registry"
    customer = fs.synthetic_matrix(evidence, out)
    schemas = fs.schema_matrices(evidence / "multi_schema", out / "schemas_deep")
    typed = fs.merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    median = fs.ordered(ts.pooled(typed)["median"])
    text = [
        r"\section{Full per-type matrices}",
        r"\label{app:matrices}",
        "The tables below give the mean recall of every detector of the registry on each "
        "injected type, over five seeds for the synthetic tables and as the median over the "
        r"$42$ real tables for the last one. The best value of each column among the detectors "
        "of the registry is in bold.",
        "",
        pt.matrix_table(
            customer, "Synthetic customer table, mean recall over five seeds.", "XXtab:m-customerXX"
        ),
        "",
        pt.matrix_table(
            schemas["transactions"].drop(index="drift", errors="ignore"),
            "Synthetic card transactions, mean recall over five seeds.",
            "tab:m-transactions",
        ),
        "",
        pt.matrix_table(
            schemas["sensors"].drop(index="drift", errors="ignore"),
            "Synthetic sensor readings, mean recall over five seeds.",
            "tab:m-sensors",
        ),
        "",
        pt.matrix_table(
            median,
            r"Typed injection into $42$ real tables, median recall over the tables.",
            "tab:m-typed",
        ),
    ]
    return "\n".join(text) + "\n"


def x_section__mutmut_70(evidence: Path) -> str:
    out = evidence / "full_registry"
    customer = fs.synthetic_matrix(evidence, out)
    schemas = fs.schema_matrices(evidence / "multi_schema", out / "schemas_deep")
    typed = fs.merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    median = fs.ordered(ts.pooled(typed)["median"])
    text = [
        r"\section{Full per-type matrices}",
        r"\label{app:matrices}",
        "The tables below give the mean recall of every detector of the registry on each "
        "injected type, over five seeds for the synthetic tables and as the median over the "
        r"$42$ real tables for the last one. The best value of each column among the detectors "
        "of the registry is in bold.",
        "",
        pt.matrix_table(
            customer, "Synthetic customer table, mean recall over five seeds.", "TAB:M-CUSTOMER"
        ),
        "",
        pt.matrix_table(
            schemas["transactions"].drop(index="drift", errors="ignore"),
            "Synthetic card transactions, mean recall over five seeds.",
            "tab:m-transactions",
        ),
        "",
        pt.matrix_table(
            schemas["sensors"].drop(index="drift", errors="ignore"),
            "Synthetic sensor readings, mean recall over five seeds.",
            "tab:m-sensors",
        ),
        "",
        pt.matrix_table(
            median,
            r"Typed injection into $42$ real tables, median recall over the tables.",
            "tab:m-typed",
        ),
    ]
    return "\n".join(text) + "\n"


def x_section__mutmut_71(evidence: Path) -> str:
    out = evidence / "full_registry"
    customer = fs.synthetic_matrix(evidence, out)
    schemas = fs.schema_matrices(evidence / "multi_schema", out / "schemas_deep")
    typed = fs.merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    median = fs.ordered(ts.pooled(typed)["median"])
    text = [
        r"\section{Full per-type matrices}",
        r"\label{app:matrices}",
        "The tables below give the mean recall of every detector of the registry on each "
        "injected type, over five seeds for the synthetic tables and as the median over the "
        r"$42$ real tables for the last one. The best value of each column among the detectors "
        "of the registry is in bold.",
        "",
        pt.matrix_table(
            customer, "Synthetic customer table, mean recall over five seeds.", "tab:m-customer"
        ),
        "XXXX",
        pt.matrix_table(
            schemas["transactions"].drop(index="drift", errors="ignore"),
            "Synthetic card transactions, mean recall over five seeds.",
            "tab:m-transactions",
        ),
        "",
        pt.matrix_table(
            schemas["sensors"].drop(index="drift", errors="ignore"),
            "Synthetic sensor readings, mean recall over five seeds.",
            "tab:m-sensors",
        ),
        "",
        pt.matrix_table(
            median,
            r"Typed injection into $42$ real tables, median recall over the tables.",
            "tab:m-typed",
        ),
    ]
    return "\n".join(text) + "\n"


def x_section__mutmut_72(evidence: Path) -> str:
    out = evidence / "full_registry"
    customer = fs.synthetic_matrix(evidence, out)
    schemas = fs.schema_matrices(evidence / "multi_schema", out / "schemas_deep")
    typed = fs.merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    median = fs.ordered(ts.pooled(typed)["median"])
    text = [
        r"\section{Full per-type matrices}",
        r"\label{app:matrices}",
        "The tables below give the mean recall of every detector of the registry on each "
        "injected type, over five seeds for the synthetic tables and as the median over the "
        r"$42$ real tables for the last one. The best value of each column among the detectors "
        "of the registry is in bold.",
        "",
        pt.matrix_table(
            customer, "Synthetic customer table, mean recall over five seeds.", "tab:m-customer"
        ),
        "",
        pt.matrix_table(
            None,
            "Synthetic card transactions, mean recall over five seeds.",
            "tab:m-transactions",
        ),
        "",
        pt.matrix_table(
            schemas["sensors"].drop(index="drift", errors="ignore"),
            "Synthetic sensor readings, mean recall over five seeds.",
            "tab:m-sensors",
        ),
        "",
        pt.matrix_table(
            median,
            r"Typed injection into $42$ real tables, median recall over the tables.",
            "tab:m-typed",
        ),
    ]
    return "\n".join(text) + "\n"


def x_section__mutmut_73(evidence: Path) -> str:
    out = evidence / "full_registry"
    customer = fs.synthetic_matrix(evidence, out)
    schemas = fs.schema_matrices(evidence / "multi_schema", out / "schemas_deep")
    typed = fs.merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    median = fs.ordered(ts.pooled(typed)["median"])
    text = [
        r"\section{Full per-type matrices}",
        r"\label{app:matrices}",
        "The tables below give the mean recall of every detector of the registry on each "
        "injected type, over five seeds for the synthetic tables and as the median over the "
        r"$42$ real tables for the last one. The best value of each column among the detectors "
        "of the registry is in bold.",
        "",
        pt.matrix_table(
            customer, "Synthetic customer table, mean recall over five seeds.", "tab:m-customer"
        ),
        "",
        pt.matrix_table(
            schemas["transactions"].drop(index="drift", errors="ignore"),
            None,
            "tab:m-transactions",
        ),
        "",
        pt.matrix_table(
            schemas["sensors"].drop(index="drift", errors="ignore"),
            "Synthetic sensor readings, mean recall over five seeds.",
            "tab:m-sensors",
        ),
        "",
        pt.matrix_table(
            median,
            r"Typed injection into $42$ real tables, median recall over the tables.",
            "tab:m-typed",
        ),
    ]
    return "\n".join(text) + "\n"


def x_section__mutmut_74(evidence: Path) -> str:
    out = evidence / "full_registry"
    customer = fs.synthetic_matrix(evidence, out)
    schemas = fs.schema_matrices(evidence / "multi_schema", out / "schemas_deep")
    typed = fs.merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    median = fs.ordered(ts.pooled(typed)["median"])
    text = [
        r"\section{Full per-type matrices}",
        r"\label{app:matrices}",
        "The tables below give the mean recall of every detector of the registry on each "
        "injected type, over five seeds for the synthetic tables and as the median over the "
        r"$42$ real tables for the last one. The best value of each column among the detectors "
        "of the registry is in bold.",
        "",
        pt.matrix_table(
            customer, "Synthetic customer table, mean recall over five seeds.", "tab:m-customer"
        ),
        "",
        pt.matrix_table(
            schemas["transactions"].drop(index="drift", errors="ignore"),
            "Synthetic card transactions, mean recall over five seeds.",
            None,
        ),
        "",
        pt.matrix_table(
            schemas["sensors"].drop(index="drift", errors="ignore"),
            "Synthetic sensor readings, mean recall over five seeds.",
            "tab:m-sensors",
        ),
        "",
        pt.matrix_table(
            median,
            r"Typed injection into $42$ real tables, median recall over the tables.",
            "tab:m-typed",
        ),
    ]
    return "\n".join(text) + "\n"


def x_section__mutmut_75(evidence: Path) -> str:
    out = evidence / "full_registry"
    customer = fs.synthetic_matrix(evidence, out)
    schemas = fs.schema_matrices(evidence / "multi_schema", out / "schemas_deep")
    typed = fs.merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    median = fs.ordered(ts.pooled(typed)["median"])
    text = [
        r"\section{Full per-type matrices}",
        r"\label{app:matrices}",
        "The tables below give the mean recall of every detector of the registry on each "
        "injected type, over five seeds for the synthetic tables and as the median over the "
        r"$42$ real tables for the last one. The best value of each column among the detectors "
        "of the registry is in bold.",
        "",
        pt.matrix_table(
            customer, "Synthetic customer table, mean recall over five seeds.", "tab:m-customer"
        ),
        "",
        pt.matrix_table(
            "Synthetic card transactions, mean recall over five seeds.",
            "tab:m-transactions",
        ),
        "",
        pt.matrix_table(
            schemas["sensors"].drop(index="drift", errors="ignore"),
            "Synthetic sensor readings, mean recall over five seeds.",
            "tab:m-sensors",
        ),
        "",
        pt.matrix_table(
            median,
            r"Typed injection into $42$ real tables, median recall over the tables.",
            "tab:m-typed",
        ),
    ]
    return "\n".join(text) + "\n"


def x_section__mutmut_76(evidence: Path) -> str:
    out = evidence / "full_registry"
    customer = fs.synthetic_matrix(evidence, out)
    schemas = fs.schema_matrices(evidence / "multi_schema", out / "schemas_deep")
    typed = fs.merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    median = fs.ordered(ts.pooled(typed)["median"])
    text = [
        r"\section{Full per-type matrices}",
        r"\label{app:matrices}",
        "The tables below give the mean recall of every detector of the registry on each "
        "injected type, over five seeds for the synthetic tables and as the median over the "
        r"$42$ real tables for the last one. The best value of each column among the detectors "
        "of the registry is in bold.",
        "",
        pt.matrix_table(
            customer, "Synthetic customer table, mean recall over five seeds.", "tab:m-customer"
        ),
        "",
        pt.matrix_table(
            schemas["transactions"].drop(index="drift", errors="ignore"),
            "tab:m-transactions",
        ),
        "",
        pt.matrix_table(
            schemas["sensors"].drop(index="drift", errors="ignore"),
            "Synthetic sensor readings, mean recall over five seeds.",
            "tab:m-sensors",
        ),
        "",
        pt.matrix_table(
            median,
            r"Typed injection into $42$ real tables, median recall over the tables.",
            "tab:m-typed",
        ),
    ]
    return "\n".join(text) + "\n"


def x_section__mutmut_77(evidence: Path) -> str:
    out = evidence / "full_registry"
    customer = fs.synthetic_matrix(evidence, out)
    schemas = fs.schema_matrices(evidence / "multi_schema", out / "schemas_deep")
    typed = fs.merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    median = fs.ordered(ts.pooled(typed)["median"])
    text = [
        r"\section{Full per-type matrices}",
        r"\label{app:matrices}",
        "The tables below give the mean recall of every detector of the registry on each "
        "injected type, over five seeds for the synthetic tables and as the median over the "
        r"$42$ real tables for the last one. The best value of each column among the detectors "
        "of the registry is in bold.",
        "",
        pt.matrix_table(
            customer, "Synthetic customer table, mean recall over five seeds.", "tab:m-customer"
        ),
        "",
        pt.matrix_table(
            schemas["transactions"].drop(index="drift", errors="ignore"),
            "Synthetic card transactions, mean recall over five seeds.",
            ),
        "",
        pt.matrix_table(
            schemas["sensors"].drop(index="drift", errors="ignore"),
            "Synthetic sensor readings, mean recall over five seeds.",
            "tab:m-sensors",
        ),
        "",
        pt.matrix_table(
            median,
            r"Typed injection into $42$ real tables, median recall over the tables.",
            "tab:m-typed",
        ),
    ]
    return "\n".join(text) + "\n"


def x_section__mutmut_78(evidence: Path) -> str:
    out = evidence / "full_registry"
    customer = fs.synthetic_matrix(evidence, out)
    schemas = fs.schema_matrices(evidence / "multi_schema", out / "schemas_deep")
    typed = fs.merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    median = fs.ordered(ts.pooled(typed)["median"])
    text = [
        r"\section{Full per-type matrices}",
        r"\label{app:matrices}",
        "The tables below give the mean recall of every detector of the registry on each "
        "injected type, over five seeds for the synthetic tables and as the median over the "
        r"$42$ real tables for the last one. The best value of each column among the detectors "
        "of the registry is in bold.",
        "",
        pt.matrix_table(
            customer, "Synthetic customer table, mean recall over five seeds.", "tab:m-customer"
        ),
        "",
        pt.matrix_table(
            schemas["transactions"].drop(index=None, errors="ignore"),
            "Synthetic card transactions, mean recall over five seeds.",
            "tab:m-transactions",
        ),
        "",
        pt.matrix_table(
            schemas["sensors"].drop(index="drift", errors="ignore"),
            "Synthetic sensor readings, mean recall over five seeds.",
            "tab:m-sensors",
        ),
        "",
        pt.matrix_table(
            median,
            r"Typed injection into $42$ real tables, median recall over the tables.",
            "tab:m-typed",
        ),
    ]
    return "\n".join(text) + "\n"


def x_section__mutmut_79(evidence: Path) -> str:
    out = evidence / "full_registry"
    customer = fs.synthetic_matrix(evidence, out)
    schemas = fs.schema_matrices(evidence / "multi_schema", out / "schemas_deep")
    typed = fs.merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    median = fs.ordered(ts.pooled(typed)["median"])
    text = [
        r"\section{Full per-type matrices}",
        r"\label{app:matrices}",
        "The tables below give the mean recall of every detector of the registry on each "
        "injected type, over five seeds for the synthetic tables and as the median over the "
        r"$42$ real tables for the last one. The best value of each column among the detectors "
        "of the registry is in bold.",
        "",
        pt.matrix_table(
            customer, "Synthetic customer table, mean recall over five seeds.", "tab:m-customer"
        ),
        "",
        pt.matrix_table(
            schemas["transactions"].drop(index="drift", errors=None),
            "Synthetic card transactions, mean recall over five seeds.",
            "tab:m-transactions",
        ),
        "",
        pt.matrix_table(
            schemas["sensors"].drop(index="drift", errors="ignore"),
            "Synthetic sensor readings, mean recall over five seeds.",
            "tab:m-sensors",
        ),
        "",
        pt.matrix_table(
            median,
            r"Typed injection into $42$ real tables, median recall over the tables.",
            "tab:m-typed",
        ),
    ]
    return "\n".join(text) + "\n"


def x_section__mutmut_80(evidence: Path) -> str:
    out = evidence / "full_registry"
    customer = fs.synthetic_matrix(evidence, out)
    schemas = fs.schema_matrices(evidence / "multi_schema", out / "schemas_deep")
    typed = fs.merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    median = fs.ordered(ts.pooled(typed)["median"])
    text = [
        r"\section{Full per-type matrices}",
        r"\label{app:matrices}",
        "The tables below give the mean recall of every detector of the registry on each "
        "injected type, over five seeds for the synthetic tables and as the median over the "
        r"$42$ real tables for the last one. The best value of each column among the detectors "
        "of the registry is in bold.",
        "",
        pt.matrix_table(
            customer, "Synthetic customer table, mean recall over five seeds.", "tab:m-customer"
        ),
        "",
        pt.matrix_table(
            schemas["transactions"].drop(errors="ignore"),
            "Synthetic card transactions, mean recall over five seeds.",
            "tab:m-transactions",
        ),
        "",
        pt.matrix_table(
            schemas["sensors"].drop(index="drift", errors="ignore"),
            "Synthetic sensor readings, mean recall over five seeds.",
            "tab:m-sensors",
        ),
        "",
        pt.matrix_table(
            median,
            r"Typed injection into $42$ real tables, median recall over the tables.",
            "tab:m-typed",
        ),
    ]
    return "\n".join(text) + "\n"


def x_section__mutmut_81(evidence: Path) -> str:
    out = evidence / "full_registry"
    customer = fs.synthetic_matrix(evidence, out)
    schemas = fs.schema_matrices(evidence / "multi_schema", out / "schemas_deep")
    typed = fs.merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    median = fs.ordered(ts.pooled(typed)["median"])
    text = [
        r"\section{Full per-type matrices}",
        r"\label{app:matrices}",
        "The tables below give the mean recall of every detector of the registry on each "
        "injected type, over five seeds for the synthetic tables and as the median over the "
        r"$42$ real tables for the last one. The best value of each column among the detectors "
        "of the registry is in bold.",
        "",
        pt.matrix_table(
            customer, "Synthetic customer table, mean recall over five seeds.", "tab:m-customer"
        ),
        "",
        pt.matrix_table(
            schemas["transactions"].drop(index="drift", ),
            "Synthetic card transactions, mean recall over five seeds.",
            "tab:m-transactions",
        ),
        "",
        pt.matrix_table(
            schemas["sensors"].drop(index="drift", errors="ignore"),
            "Synthetic sensor readings, mean recall over five seeds.",
            "tab:m-sensors",
        ),
        "",
        pt.matrix_table(
            median,
            r"Typed injection into $42$ real tables, median recall over the tables.",
            "tab:m-typed",
        ),
    ]
    return "\n".join(text) + "\n"


def x_section__mutmut_82(evidence: Path) -> str:
    out = evidence / "full_registry"
    customer = fs.synthetic_matrix(evidence, out)
    schemas = fs.schema_matrices(evidence / "multi_schema", out / "schemas_deep")
    typed = fs.merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    median = fs.ordered(ts.pooled(typed)["median"])
    text = [
        r"\section{Full per-type matrices}",
        r"\label{app:matrices}",
        "The tables below give the mean recall of every detector of the registry on each "
        "injected type, over five seeds for the synthetic tables and as the median over the "
        r"$42$ real tables for the last one. The best value of each column among the detectors "
        "of the registry is in bold.",
        "",
        pt.matrix_table(
            customer, "Synthetic customer table, mean recall over five seeds.", "tab:m-customer"
        ),
        "",
        pt.matrix_table(
            schemas["XXtransactionsXX"].drop(index="drift", errors="ignore"),
            "Synthetic card transactions, mean recall over five seeds.",
            "tab:m-transactions",
        ),
        "",
        pt.matrix_table(
            schemas["sensors"].drop(index="drift", errors="ignore"),
            "Synthetic sensor readings, mean recall over five seeds.",
            "tab:m-sensors",
        ),
        "",
        pt.matrix_table(
            median,
            r"Typed injection into $42$ real tables, median recall over the tables.",
            "tab:m-typed",
        ),
    ]
    return "\n".join(text) + "\n"


def x_section__mutmut_83(evidence: Path) -> str:
    out = evidence / "full_registry"
    customer = fs.synthetic_matrix(evidence, out)
    schemas = fs.schema_matrices(evidence / "multi_schema", out / "schemas_deep")
    typed = fs.merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    median = fs.ordered(ts.pooled(typed)["median"])
    text = [
        r"\section{Full per-type matrices}",
        r"\label{app:matrices}",
        "The tables below give the mean recall of every detector of the registry on each "
        "injected type, over five seeds for the synthetic tables and as the median over the "
        r"$42$ real tables for the last one. The best value of each column among the detectors "
        "of the registry is in bold.",
        "",
        pt.matrix_table(
            customer, "Synthetic customer table, mean recall over five seeds.", "tab:m-customer"
        ),
        "",
        pt.matrix_table(
            schemas["TRANSACTIONS"].drop(index="drift", errors="ignore"),
            "Synthetic card transactions, mean recall over five seeds.",
            "tab:m-transactions",
        ),
        "",
        pt.matrix_table(
            schemas["sensors"].drop(index="drift", errors="ignore"),
            "Synthetic sensor readings, mean recall over five seeds.",
            "tab:m-sensors",
        ),
        "",
        pt.matrix_table(
            median,
            r"Typed injection into $42$ real tables, median recall over the tables.",
            "tab:m-typed",
        ),
    ]
    return "\n".join(text) + "\n"


def x_section__mutmut_84(evidence: Path) -> str:
    out = evidence / "full_registry"
    customer = fs.synthetic_matrix(evidence, out)
    schemas = fs.schema_matrices(evidence / "multi_schema", out / "schemas_deep")
    typed = fs.merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    median = fs.ordered(ts.pooled(typed)["median"])
    text = [
        r"\section{Full per-type matrices}",
        r"\label{app:matrices}",
        "The tables below give the mean recall of every detector of the registry on each "
        "injected type, over five seeds for the synthetic tables and as the median over the "
        r"$42$ real tables for the last one. The best value of each column among the detectors "
        "of the registry is in bold.",
        "",
        pt.matrix_table(
            customer, "Synthetic customer table, mean recall over five seeds.", "tab:m-customer"
        ),
        "",
        pt.matrix_table(
            schemas["transactions"].drop(index="XXdriftXX", errors="ignore"),
            "Synthetic card transactions, mean recall over five seeds.",
            "tab:m-transactions",
        ),
        "",
        pt.matrix_table(
            schemas["sensors"].drop(index="drift", errors="ignore"),
            "Synthetic sensor readings, mean recall over five seeds.",
            "tab:m-sensors",
        ),
        "",
        pt.matrix_table(
            median,
            r"Typed injection into $42$ real tables, median recall over the tables.",
            "tab:m-typed",
        ),
    ]
    return "\n".join(text) + "\n"


def x_section__mutmut_85(evidence: Path) -> str:
    out = evidence / "full_registry"
    customer = fs.synthetic_matrix(evidence, out)
    schemas = fs.schema_matrices(evidence / "multi_schema", out / "schemas_deep")
    typed = fs.merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    median = fs.ordered(ts.pooled(typed)["median"])
    text = [
        r"\section{Full per-type matrices}",
        r"\label{app:matrices}",
        "The tables below give the mean recall of every detector of the registry on each "
        "injected type, over five seeds for the synthetic tables and as the median over the "
        r"$42$ real tables for the last one. The best value of each column among the detectors "
        "of the registry is in bold.",
        "",
        pt.matrix_table(
            customer, "Synthetic customer table, mean recall over five seeds.", "tab:m-customer"
        ),
        "",
        pt.matrix_table(
            schemas["transactions"].drop(index="DRIFT", errors="ignore"),
            "Synthetic card transactions, mean recall over five seeds.",
            "tab:m-transactions",
        ),
        "",
        pt.matrix_table(
            schemas["sensors"].drop(index="drift", errors="ignore"),
            "Synthetic sensor readings, mean recall over five seeds.",
            "tab:m-sensors",
        ),
        "",
        pt.matrix_table(
            median,
            r"Typed injection into $42$ real tables, median recall over the tables.",
            "tab:m-typed",
        ),
    ]
    return "\n".join(text) + "\n"


def x_section__mutmut_86(evidence: Path) -> str:
    out = evidence / "full_registry"
    customer = fs.synthetic_matrix(evidence, out)
    schemas = fs.schema_matrices(evidence / "multi_schema", out / "schemas_deep")
    typed = fs.merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    median = fs.ordered(ts.pooled(typed)["median"])
    text = [
        r"\section{Full per-type matrices}",
        r"\label{app:matrices}",
        "The tables below give the mean recall of every detector of the registry on each "
        "injected type, over five seeds for the synthetic tables and as the median over the "
        r"$42$ real tables for the last one. The best value of each column among the detectors "
        "of the registry is in bold.",
        "",
        pt.matrix_table(
            customer, "Synthetic customer table, mean recall over five seeds.", "tab:m-customer"
        ),
        "",
        pt.matrix_table(
            schemas["transactions"].drop(index="drift", errors="XXignoreXX"),
            "Synthetic card transactions, mean recall over five seeds.",
            "tab:m-transactions",
        ),
        "",
        pt.matrix_table(
            schemas["sensors"].drop(index="drift", errors="ignore"),
            "Synthetic sensor readings, mean recall over five seeds.",
            "tab:m-sensors",
        ),
        "",
        pt.matrix_table(
            median,
            r"Typed injection into $42$ real tables, median recall over the tables.",
            "tab:m-typed",
        ),
    ]
    return "\n".join(text) + "\n"


def x_section__mutmut_87(evidence: Path) -> str:
    out = evidence / "full_registry"
    customer = fs.synthetic_matrix(evidence, out)
    schemas = fs.schema_matrices(evidence / "multi_schema", out / "schemas_deep")
    typed = fs.merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    median = fs.ordered(ts.pooled(typed)["median"])
    text = [
        r"\section{Full per-type matrices}",
        r"\label{app:matrices}",
        "The tables below give the mean recall of every detector of the registry on each "
        "injected type, over five seeds for the synthetic tables and as the median over the "
        r"$42$ real tables for the last one. The best value of each column among the detectors "
        "of the registry is in bold.",
        "",
        pt.matrix_table(
            customer, "Synthetic customer table, mean recall over five seeds.", "tab:m-customer"
        ),
        "",
        pt.matrix_table(
            schemas["transactions"].drop(index="drift", errors="IGNORE"),
            "Synthetic card transactions, mean recall over five seeds.",
            "tab:m-transactions",
        ),
        "",
        pt.matrix_table(
            schemas["sensors"].drop(index="drift", errors="ignore"),
            "Synthetic sensor readings, mean recall over five seeds.",
            "tab:m-sensors",
        ),
        "",
        pt.matrix_table(
            median,
            r"Typed injection into $42$ real tables, median recall over the tables.",
            "tab:m-typed",
        ),
    ]
    return "\n".join(text) + "\n"


def x_section__mutmut_88(evidence: Path) -> str:
    out = evidence / "full_registry"
    customer = fs.synthetic_matrix(evidence, out)
    schemas = fs.schema_matrices(evidence / "multi_schema", out / "schemas_deep")
    typed = fs.merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    median = fs.ordered(ts.pooled(typed)["median"])
    text = [
        r"\section{Full per-type matrices}",
        r"\label{app:matrices}",
        "The tables below give the mean recall of every detector of the registry on each "
        "injected type, over five seeds for the synthetic tables and as the median over the "
        r"$42$ real tables for the last one. The best value of each column among the detectors "
        "of the registry is in bold.",
        "",
        pt.matrix_table(
            customer, "Synthetic customer table, mean recall over five seeds.", "tab:m-customer"
        ),
        "",
        pt.matrix_table(
            schemas["transactions"].drop(index="drift", errors="ignore"),
            "XXSynthetic card transactions, mean recall over five seeds.XX",
            "tab:m-transactions",
        ),
        "",
        pt.matrix_table(
            schemas["sensors"].drop(index="drift", errors="ignore"),
            "Synthetic sensor readings, mean recall over five seeds.",
            "tab:m-sensors",
        ),
        "",
        pt.matrix_table(
            median,
            r"Typed injection into $42$ real tables, median recall over the tables.",
            "tab:m-typed",
        ),
    ]
    return "\n".join(text) + "\n"


def x_section__mutmut_89(evidence: Path) -> str:
    out = evidence / "full_registry"
    customer = fs.synthetic_matrix(evidence, out)
    schemas = fs.schema_matrices(evidence / "multi_schema", out / "schemas_deep")
    typed = fs.merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    median = fs.ordered(ts.pooled(typed)["median"])
    text = [
        r"\section{Full per-type matrices}",
        r"\label{app:matrices}",
        "The tables below give the mean recall of every detector of the registry on each "
        "injected type, over five seeds for the synthetic tables and as the median over the "
        r"$42$ real tables for the last one. The best value of each column among the detectors "
        "of the registry is in bold.",
        "",
        pt.matrix_table(
            customer, "Synthetic customer table, mean recall over five seeds.", "tab:m-customer"
        ),
        "",
        pt.matrix_table(
            schemas["transactions"].drop(index="drift", errors="ignore"),
            "synthetic card transactions, mean recall over five seeds.",
            "tab:m-transactions",
        ),
        "",
        pt.matrix_table(
            schemas["sensors"].drop(index="drift", errors="ignore"),
            "Synthetic sensor readings, mean recall over five seeds.",
            "tab:m-sensors",
        ),
        "",
        pt.matrix_table(
            median,
            r"Typed injection into $42$ real tables, median recall over the tables.",
            "tab:m-typed",
        ),
    ]
    return "\n".join(text) + "\n"


def x_section__mutmut_90(evidence: Path) -> str:
    out = evidence / "full_registry"
    customer = fs.synthetic_matrix(evidence, out)
    schemas = fs.schema_matrices(evidence / "multi_schema", out / "schemas_deep")
    typed = fs.merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    median = fs.ordered(ts.pooled(typed)["median"])
    text = [
        r"\section{Full per-type matrices}",
        r"\label{app:matrices}",
        "The tables below give the mean recall of every detector of the registry on each "
        "injected type, over five seeds for the synthetic tables and as the median over the "
        r"$42$ real tables for the last one. The best value of each column among the detectors "
        "of the registry is in bold.",
        "",
        pt.matrix_table(
            customer, "Synthetic customer table, mean recall over five seeds.", "tab:m-customer"
        ),
        "",
        pt.matrix_table(
            schemas["transactions"].drop(index="drift", errors="ignore"),
            "SYNTHETIC CARD TRANSACTIONS, MEAN RECALL OVER FIVE SEEDS.",
            "tab:m-transactions",
        ),
        "",
        pt.matrix_table(
            schemas["sensors"].drop(index="drift", errors="ignore"),
            "Synthetic sensor readings, mean recall over five seeds.",
            "tab:m-sensors",
        ),
        "",
        pt.matrix_table(
            median,
            r"Typed injection into $42$ real tables, median recall over the tables.",
            "tab:m-typed",
        ),
    ]
    return "\n".join(text) + "\n"


def x_section__mutmut_91(evidence: Path) -> str:
    out = evidence / "full_registry"
    customer = fs.synthetic_matrix(evidence, out)
    schemas = fs.schema_matrices(evidence / "multi_schema", out / "schemas_deep")
    typed = fs.merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    median = fs.ordered(ts.pooled(typed)["median"])
    text = [
        r"\section{Full per-type matrices}",
        r"\label{app:matrices}",
        "The tables below give the mean recall of every detector of the registry on each "
        "injected type, over five seeds for the synthetic tables and as the median over the "
        r"$42$ real tables for the last one. The best value of each column among the detectors "
        "of the registry is in bold.",
        "",
        pt.matrix_table(
            customer, "Synthetic customer table, mean recall over five seeds.", "tab:m-customer"
        ),
        "",
        pt.matrix_table(
            schemas["transactions"].drop(index="drift", errors="ignore"),
            "Synthetic card transactions, mean recall over five seeds.",
            "XXtab:m-transactionsXX",
        ),
        "",
        pt.matrix_table(
            schemas["sensors"].drop(index="drift", errors="ignore"),
            "Synthetic sensor readings, mean recall over five seeds.",
            "tab:m-sensors",
        ),
        "",
        pt.matrix_table(
            median,
            r"Typed injection into $42$ real tables, median recall over the tables.",
            "tab:m-typed",
        ),
    ]
    return "\n".join(text) + "\n"


def x_section__mutmut_92(evidence: Path) -> str:
    out = evidence / "full_registry"
    customer = fs.synthetic_matrix(evidence, out)
    schemas = fs.schema_matrices(evidence / "multi_schema", out / "schemas_deep")
    typed = fs.merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    median = fs.ordered(ts.pooled(typed)["median"])
    text = [
        r"\section{Full per-type matrices}",
        r"\label{app:matrices}",
        "The tables below give the mean recall of every detector of the registry on each "
        "injected type, over five seeds for the synthetic tables and as the median over the "
        r"$42$ real tables for the last one. The best value of each column among the detectors "
        "of the registry is in bold.",
        "",
        pt.matrix_table(
            customer, "Synthetic customer table, mean recall over five seeds.", "tab:m-customer"
        ),
        "",
        pt.matrix_table(
            schemas["transactions"].drop(index="drift", errors="ignore"),
            "Synthetic card transactions, mean recall over five seeds.",
            "TAB:M-TRANSACTIONS",
        ),
        "",
        pt.matrix_table(
            schemas["sensors"].drop(index="drift", errors="ignore"),
            "Synthetic sensor readings, mean recall over five seeds.",
            "tab:m-sensors",
        ),
        "",
        pt.matrix_table(
            median,
            r"Typed injection into $42$ real tables, median recall over the tables.",
            "tab:m-typed",
        ),
    ]
    return "\n".join(text) + "\n"


def x_section__mutmut_93(evidence: Path) -> str:
    out = evidence / "full_registry"
    customer = fs.synthetic_matrix(evidence, out)
    schemas = fs.schema_matrices(evidence / "multi_schema", out / "schemas_deep")
    typed = fs.merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    median = fs.ordered(ts.pooled(typed)["median"])
    text = [
        r"\section{Full per-type matrices}",
        r"\label{app:matrices}",
        "The tables below give the mean recall of every detector of the registry on each "
        "injected type, over five seeds for the synthetic tables and as the median over the "
        r"$42$ real tables for the last one. The best value of each column among the detectors "
        "of the registry is in bold.",
        "",
        pt.matrix_table(
            customer, "Synthetic customer table, mean recall over five seeds.", "tab:m-customer"
        ),
        "",
        pt.matrix_table(
            schemas["transactions"].drop(index="drift", errors="ignore"),
            "Synthetic card transactions, mean recall over five seeds.",
            "tab:m-transactions",
        ),
        "XXXX",
        pt.matrix_table(
            schemas["sensors"].drop(index="drift", errors="ignore"),
            "Synthetic sensor readings, mean recall over five seeds.",
            "tab:m-sensors",
        ),
        "",
        pt.matrix_table(
            median,
            r"Typed injection into $42$ real tables, median recall over the tables.",
            "tab:m-typed",
        ),
    ]
    return "\n".join(text) + "\n"


def x_section__mutmut_94(evidence: Path) -> str:
    out = evidence / "full_registry"
    customer = fs.synthetic_matrix(evidence, out)
    schemas = fs.schema_matrices(evidence / "multi_schema", out / "schemas_deep")
    typed = fs.merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    median = fs.ordered(ts.pooled(typed)["median"])
    text = [
        r"\section{Full per-type matrices}",
        r"\label{app:matrices}",
        "The tables below give the mean recall of every detector of the registry on each "
        "injected type, over five seeds for the synthetic tables and as the median over the "
        r"$42$ real tables for the last one. The best value of each column among the detectors "
        "of the registry is in bold.",
        "",
        pt.matrix_table(
            customer, "Synthetic customer table, mean recall over five seeds.", "tab:m-customer"
        ),
        "",
        pt.matrix_table(
            schemas["transactions"].drop(index="drift", errors="ignore"),
            "Synthetic card transactions, mean recall over five seeds.",
            "tab:m-transactions",
        ),
        "",
        pt.matrix_table(
            None,
            "Synthetic sensor readings, mean recall over five seeds.",
            "tab:m-sensors",
        ),
        "",
        pt.matrix_table(
            median,
            r"Typed injection into $42$ real tables, median recall over the tables.",
            "tab:m-typed",
        ),
    ]
    return "\n".join(text) + "\n"


def x_section__mutmut_95(evidence: Path) -> str:
    out = evidence / "full_registry"
    customer = fs.synthetic_matrix(evidence, out)
    schemas = fs.schema_matrices(evidence / "multi_schema", out / "schemas_deep")
    typed = fs.merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    median = fs.ordered(ts.pooled(typed)["median"])
    text = [
        r"\section{Full per-type matrices}",
        r"\label{app:matrices}",
        "The tables below give the mean recall of every detector of the registry on each "
        "injected type, over five seeds for the synthetic tables and as the median over the "
        r"$42$ real tables for the last one. The best value of each column among the detectors "
        "of the registry is in bold.",
        "",
        pt.matrix_table(
            customer, "Synthetic customer table, mean recall over five seeds.", "tab:m-customer"
        ),
        "",
        pt.matrix_table(
            schemas["transactions"].drop(index="drift", errors="ignore"),
            "Synthetic card transactions, mean recall over five seeds.",
            "tab:m-transactions",
        ),
        "",
        pt.matrix_table(
            schemas["sensors"].drop(index="drift", errors="ignore"),
            None,
            "tab:m-sensors",
        ),
        "",
        pt.matrix_table(
            median,
            r"Typed injection into $42$ real tables, median recall over the tables.",
            "tab:m-typed",
        ),
    ]
    return "\n".join(text) + "\n"


def x_section__mutmut_96(evidence: Path) -> str:
    out = evidence / "full_registry"
    customer = fs.synthetic_matrix(evidence, out)
    schemas = fs.schema_matrices(evidence / "multi_schema", out / "schemas_deep")
    typed = fs.merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    median = fs.ordered(ts.pooled(typed)["median"])
    text = [
        r"\section{Full per-type matrices}",
        r"\label{app:matrices}",
        "The tables below give the mean recall of every detector of the registry on each "
        "injected type, over five seeds for the synthetic tables and as the median over the "
        r"$42$ real tables for the last one. The best value of each column among the detectors "
        "of the registry is in bold.",
        "",
        pt.matrix_table(
            customer, "Synthetic customer table, mean recall over five seeds.", "tab:m-customer"
        ),
        "",
        pt.matrix_table(
            schemas["transactions"].drop(index="drift", errors="ignore"),
            "Synthetic card transactions, mean recall over five seeds.",
            "tab:m-transactions",
        ),
        "",
        pt.matrix_table(
            schemas["sensors"].drop(index="drift", errors="ignore"),
            "Synthetic sensor readings, mean recall over five seeds.",
            None,
        ),
        "",
        pt.matrix_table(
            median,
            r"Typed injection into $42$ real tables, median recall over the tables.",
            "tab:m-typed",
        ),
    ]
    return "\n".join(text) + "\n"


def x_section__mutmut_97(evidence: Path) -> str:
    out = evidence / "full_registry"
    customer = fs.synthetic_matrix(evidence, out)
    schemas = fs.schema_matrices(evidence / "multi_schema", out / "schemas_deep")
    typed = fs.merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    median = fs.ordered(ts.pooled(typed)["median"])
    text = [
        r"\section{Full per-type matrices}",
        r"\label{app:matrices}",
        "The tables below give the mean recall of every detector of the registry on each "
        "injected type, over five seeds for the synthetic tables and as the median over the "
        r"$42$ real tables for the last one. The best value of each column among the detectors "
        "of the registry is in bold.",
        "",
        pt.matrix_table(
            customer, "Synthetic customer table, mean recall over five seeds.", "tab:m-customer"
        ),
        "",
        pt.matrix_table(
            schemas["transactions"].drop(index="drift", errors="ignore"),
            "Synthetic card transactions, mean recall over five seeds.",
            "tab:m-transactions",
        ),
        "",
        pt.matrix_table(
            "Synthetic sensor readings, mean recall over five seeds.",
            "tab:m-sensors",
        ),
        "",
        pt.matrix_table(
            median,
            r"Typed injection into $42$ real tables, median recall over the tables.",
            "tab:m-typed",
        ),
    ]
    return "\n".join(text) + "\n"


def x_section__mutmut_98(evidence: Path) -> str:
    out = evidence / "full_registry"
    customer = fs.synthetic_matrix(evidence, out)
    schemas = fs.schema_matrices(evidence / "multi_schema", out / "schemas_deep")
    typed = fs.merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    median = fs.ordered(ts.pooled(typed)["median"])
    text = [
        r"\section{Full per-type matrices}",
        r"\label{app:matrices}",
        "The tables below give the mean recall of every detector of the registry on each "
        "injected type, over five seeds for the synthetic tables and as the median over the "
        r"$42$ real tables for the last one. The best value of each column among the detectors "
        "of the registry is in bold.",
        "",
        pt.matrix_table(
            customer, "Synthetic customer table, mean recall over five seeds.", "tab:m-customer"
        ),
        "",
        pt.matrix_table(
            schemas["transactions"].drop(index="drift", errors="ignore"),
            "Synthetic card transactions, mean recall over five seeds.",
            "tab:m-transactions",
        ),
        "",
        pt.matrix_table(
            schemas["sensors"].drop(index="drift", errors="ignore"),
            "tab:m-sensors",
        ),
        "",
        pt.matrix_table(
            median,
            r"Typed injection into $42$ real tables, median recall over the tables.",
            "tab:m-typed",
        ),
    ]
    return "\n".join(text) + "\n"


def x_section__mutmut_99(evidence: Path) -> str:
    out = evidence / "full_registry"
    customer = fs.synthetic_matrix(evidence, out)
    schemas = fs.schema_matrices(evidence / "multi_schema", out / "schemas_deep")
    typed = fs.merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    median = fs.ordered(ts.pooled(typed)["median"])
    text = [
        r"\section{Full per-type matrices}",
        r"\label{app:matrices}",
        "The tables below give the mean recall of every detector of the registry on each "
        "injected type, over five seeds for the synthetic tables and as the median over the "
        r"$42$ real tables for the last one. The best value of each column among the detectors "
        "of the registry is in bold.",
        "",
        pt.matrix_table(
            customer, "Synthetic customer table, mean recall over five seeds.", "tab:m-customer"
        ),
        "",
        pt.matrix_table(
            schemas["transactions"].drop(index="drift", errors="ignore"),
            "Synthetic card transactions, mean recall over five seeds.",
            "tab:m-transactions",
        ),
        "",
        pt.matrix_table(
            schemas["sensors"].drop(index="drift", errors="ignore"),
            "Synthetic sensor readings, mean recall over five seeds.",
            ),
        "",
        pt.matrix_table(
            median,
            r"Typed injection into $42$ real tables, median recall over the tables.",
            "tab:m-typed",
        ),
    ]
    return "\n".join(text) + "\n"


def x_section__mutmut_100(evidence: Path) -> str:
    out = evidence / "full_registry"
    customer = fs.synthetic_matrix(evidence, out)
    schemas = fs.schema_matrices(evidence / "multi_schema", out / "schemas_deep")
    typed = fs.merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    median = fs.ordered(ts.pooled(typed)["median"])
    text = [
        r"\section{Full per-type matrices}",
        r"\label{app:matrices}",
        "The tables below give the mean recall of every detector of the registry on each "
        "injected type, over five seeds for the synthetic tables and as the median over the "
        r"$42$ real tables for the last one. The best value of each column among the detectors "
        "of the registry is in bold.",
        "",
        pt.matrix_table(
            customer, "Synthetic customer table, mean recall over five seeds.", "tab:m-customer"
        ),
        "",
        pt.matrix_table(
            schemas["transactions"].drop(index="drift", errors="ignore"),
            "Synthetic card transactions, mean recall over five seeds.",
            "tab:m-transactions",
        ),
        "",
        pt.matrix_table(
            schemas["sensors"].drop(index=None, errors="ignore"),
            "Synthetic sensor readings, mean recall over five seeds.",
            "tab:m-sensors",
        ),
        "",
        pt.matrix_table(
            median,
            r"Typed injection into $42$ real tables, median recall over the tables.",
            "tab:m-typed",
        ),
    ]
    return "\n".join(text) + "\n"


def x_section__mutmut_101(evidence: Path) -> str:
    out = evidence / "full_registry"
    customer = fs.synthetic_matrix(evidence, out)
    schemas = fs.schema_matrices(evidence / "multi_schema", out / "schemas_deep")
    typed = fs.merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    median = fs.ordered(ts.pooled(typed)["median"])
    text = [
        r"\section{Full per-type matrices}",
        r"\label{app:matrices}",
        "The tables below give the mean recall of every detector of the registry on each "
        "injected type, over five seeds for the synthetic tables and as the median over the "
        r"$42$ real tables for the last one. The best value of each column among the detectors "
        "of the registry is in bold.",
        "",
        pt.matrix_table(
            customer, "Synthetic customer table, mean recall over five seeds.", "tab:m-customer"
        ),
        "",
        pt.matrix_table(
            schemas["transactions"].drop(index="drift", errors="ignore"),
            "Synthetic card transactions, mean recall over five seeds.",
            "tab:m-transactions",
        ),
        "",
        pt.matrix_table(
            schemas["sensors"].drop(index="drift", errors=None),
            "Synthetic sensor readings, mean recall over five seeds.",
            "tab:m-sensors",
        ),
        "",
        pt.matrix_table(
            median,
            r"Typed injection into $42$ real tables, median recall over the tables.",
            "tab:m-typed",
        ),
    ]
    return "\n".join(text) + "\n"


def x_section__mutmut_102(evidence: Path) -> str:
    out = evidence / "full_registry"
    customer = fs.synthetic_matrix(evidence, out)
    schemas = fs.schema_matrices(evidence / "multi_schema", out / "schemas_deep")
    typed = fs.merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    median = fs.ordered(ts.pooled(typed)["median"])
    text = [
        r"\section{Full per-type matrices}",
        r"\label{app:matrices}",
        "The tables below give the mean recall of every detector of the registry on each "
        "injected type, over five seeds for the synthetic tables and as the median over the "
        r"$42$ real tables for the last one. The best value of each column among the detectors "
        "of the registry is in bold.",
        "",
        pt.matrix_table(
            customer, "Synthetic customer table, mean recall over five seeds.", "tab:m-customer"
        ),
        "",
        pt.matrix_table(
            schemas["transactions"].drop(index="drift", errors="ignore"),
            "Synthetic card transactions, mean recall over five seeds.",
            "tab:m-transactions",
        ),
        "",
        pt.matrix_table(
            schemas["sensors"].drop(errors="ignore"),
            "Synthetic sensor readings, mean recall over five seeds.",
            "tab:m-sensors",
        ),
        "",
        pt.matrix_table(
            median,
            r"Typed injection into $42$ real tables, median recall over the tables.",
            "tab:m-typed",
        ),
    ]
    return "\n".join(text) + "\n"


def x_section__mutmut_103(evidence: Path) -> str:
    out = evidence / "full_registry"
    customer = fs.synthetic_matrix(evidence, out)
    schemas = fs.schema_matrices(evidence / "multi_schema", out / "schemas_deep")
    typed = fs.merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    median = fs.ordered(ts.pooled(typed)["median"])
    text = [
        r"\section{Full per-type matrices}",
        r"\label{app:matrices}",
        "The tables below give the mean recall of every detector of the registry on each "
        "injected type, over five seeds for the synthetic tables and as the median over the "
        r"$42$ real tables for the last one. The best value of each column among the detectors "
        "of the registry is in bold.",
        "",
        pt.matrix_table(
            customer, "Synthetic customer table, mean recall over five seeds.", "tab:m-customer"
        ),
        "",
        pt.matrix_table(
            schemas["transactions"].drop(index="drift", errors="ignore"),
            "Synthetic card transactions, mean recall over five seeds.",
            "tab:m-transactions",
        ),
        "",
        pt.matrix_table(
            schemas["sensors"].drop(index="drift", ),
            "Synthetic sensor readings, mean recall over five seeds.",
            "tab:m-sensors",
        ),
        "",
        pt.matrix_table(
            median,
            r"Typed injection into $42$ real tables, median recall over the tables.",
            "tab:m-typed",
        ),
    ]
    return "\n".join(text) + "\n"


def x_section__mutmut_104(evidence: Path) -> str:
    out = evidence / "full_registry"
    customer = fs.synthetic_matrix(evidence, out)
    schemas = fs.schema_matrices(evidence / "multi_schema", out / "schemas_deep")
    typed = fs.merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    median = fs.ordered(ts.pooled(typed)["median"])
    text = [
        r"\section{Full per-type matrices}",
        r"\label{app:matrices}",
        "The tables below give the mean recall of every detector of the registry on each "
        "injected type, over five seeds for the synthetic tables and as the median over the "
        r"$42$ real tables for the last one. The best value of each column among the detectors "
        "of the registry is in bold.",
        "",
        pt.matrix_table(
            customer, "Synthetic customer table, mean recall over five seeds.", "tab:m-customer"
        ),
        "",
        pt.matrix_table(
            schemas["transactions"].drop(index="drift", errors="ignore"),
            "Synthetic card transactions, mean recall over five seeds.",
            "tab:m-transactions",
        ),
        "",
        pt.matrix_table(
            schemas["XXsensorsXX"].drop(index="drift", errors="ignore"),
            "Synthetic sensor readings, mean recall over five seeds.",
            "tab:m-sensors",
        ),
        "",
        pt.matrix_table(
            median,
            r"Typed injection into $42$ real tables, median recall over the tables.",
            "tab:m-typed",
        ),
    ]
    return "\n".join(text) + "\n"


def x_section__mutmut_105(evidence: Path) -> str:
    out = evidence / "full_registry"
    customer = fs.synthetic_matrix(evidence, out)
    schemas = fs.schema_matrices(evidence / "multi_schema", out / "schemas_deep")
    typed = fs.merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    median = fs.ordered(ts.pooled(typed)["median"])
    text = [
        r"\section{Full per-type matrices}",
        r"\label{app:matrices}",
        "The tables below give the mean recall of every detector of the registry on each "
        "injected type, over five seeds for the synthetic tables and as the median over the "
        r"$42$ real tables for the last one. The best value of each column among the detectors "
        "of the registry is in bold.",
        "",
        pt.matrix_table(
            customer, "Synthetic customer table, mean recall over five seeds.", "tab:m-customer"
        ),
        "",
        pt.matrix_table(
            schemas["transactions"].drop(index="drift", errors="ignore"),
            "Synthetic card transactions, mean recall over five seeds.",
            "tab:m-transactions",
        ),
        "",
        pt.matrix_table(
            schemas["SENSORS"].drop(index="drift", errors="ignore"),
            "Synthetic sensor readings, mean recall over five seeds.",
            "tab:m-sensors",
        ),
        "",
        pt.matrix_table(
            median,
            r"Typed injection into $42$ real tables, median recall over the tables.",
            "tab:m-typed",
        ),
    ]
    return "\n".join(text) + "\n"


def x_section__mutmut_106(evidence: Path) -> str:
    out = evidence / "full_registry"
    customer = fs.synthetic_matrix(evidence, out)
    schemas = fs.schema_matrices(evidence / "multi_schema", out / "schemas_deep")
    typed = fs.merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    median = fs.ordered(ts.pooled(typed)["median"])
    text = [
        r"\section{Full per-type matrices}",
        r"\label{app:matrices}",
        "The tables below give the mean recall of every detector of the registry on each "
        "injected type, over five seeds for the synthetic tables and as the median over the "
        r"$42$ real tables for the last one. The best value of each column among the detectors "
        "of the registry is in bold.",
        "",
        pt.matrix_table(
            customer, "Synthetic customer table, mean recall over five seeds.", "tab:m-customer"
        ),
        "",
        pt.matrix_table(
            schemas["transactions"].drop(index="drift", errors="ignore"),
            "Synthetic card transactions, mean recall over five seeds.",
            "tab:m-transactions",
        ),
        "",
        pt.matrix_table(
            schemas["sensors"].drop(index="XXdriftXX", errors="ignore"),
            "Synthetic sensor readings, mean recall over five seeds.",
            "tab:m-sensors",
        ),
        "",
        pt.matrix_table(
            median,
            r"Typed injection into $42$ real tables, median recall over the tables.",
            "tab:m-typed",
        ),
    ]
    return "\n".join(text) + "\n"


def x_section__mutmut_107(evidence: Path) -> str:
    out = evidence / "full_registry"
    customer = fs.synthetic_matrix(evidence, out)
    schemas = fs.schema_matrices(evidence / "multi_schema", out / "schemas_deep")
    typed = fs.merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    median = fs.ordered(ts.pooled(typed)["median"])
    text = [
        r"\section{Full per-type matrices}",
        r"\label{app:matrices}",
        "The tables below give the mean recall of every detector of the registry on each "
        "injected type, over five seeds for the synthetic tables and as the median over the "
        r"$42$ real tables for the last one. The best value of each column among the detectors "
        "of the registry is in bold.",
        "",
        pt.matrix_table(
            customer, "Synthetic customer table, mean recall over five seeds.", "tab:m-customer"
        ),
        "",
        pt.matrix_table(
            schemas["transactions"].drop(index="drift", errors="ignore"),
            "Synthetic card transactions, mean recall over five seeds.",
            "tab:m-transactions",
        ),
        "",
        pt.matrix_table(
            schemas["sensors"].drop(index="DRIFT", errors="ignore"),
            "Synthetic sensor readings, mean recall over five seeds.",
            "tab:m-sensors",
        ),
        "",
        pt.matrix_table(
            median,
            r"Typed injection into $42$ real tables, median recall over the tables.",
            "tab:m-typed",
        ),
    ]
    return "\n".join(text) + "\n"


def x_section__mutmut_108(evidence: Path) -> str:
    out = evidence / "full_registry"
    customer = fs.synthetic_matrix(evidence, out)
    schemas = fs.schema_matrices(evidence / "multi_schema", out / "schemas_deep")
    typed = fs.merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    median = fs.ordered(ts.pooled(typed)["median"])
    text = [
        r"\section{Full per-type matrices}",
        r"\label{app:matrices}",
        "The tables below give the mean recall of every detector of the registry on each "
        "injected type, over five seeds for the synthetic tables and as the median over the "
        r"$42$ real tables for the last one. The best value of each column among the detectors "
        "of the registry is in bold.",
        "",
        pt.matrix_table(
            customer, "Synthetic customer table, mean recall over five seeds.", "tab:m-customer"
        ),
        "",
        pt.matrix_table(
            schemas["transactions"].drop(index="drift", errors="ignore"),
            "Synthetic card transactions, mean recall over five seeds.",
            "tab:m-transactions",
        ),
        "",
        pt.matrix_table(
            schemas["sensors"].drop(index="drift", errors="XXignoreXX"),
            "Synthetic sensor readings, mean recall over five seeds.",
            "tab:m-sensors",
        ),
        "",
        pt.matrix_table(
            median,
            r"Typed injection into $42$ real tables, median recall over the tables.",
            "tab:m-typed",
        ),
    ]
    return "\n".join(text) + "\n"


def x_section__mutmut_109(evidence: Path) -> str:
    out = evidence / "full_registry"
    customer = fs.synthetic_matrix(evidence, out)
    schemas = fs.schema_matrices(evidence / "multi_schema", out / "schemas_deep")
    typed = fs.merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    median = fs.ordered(ts.pooled(typed)["median"])
    text = [
        r"\section{Full per-type matrices}",
        r"\label{app:matrices}",
        "The tables below give the mean recall of every detector of the registry on each "
        "injected type, over five seeds for the synthetic tables and as the median over the "
        r"$42$ real tables for the last one. The best value of each column among the detectors "
        "of the registry is in bold.",
        "",
        pt.matrix_table(
            customer, "Synthetic customer table, mean recall over five seeds.", "tab:m-customer"
        ),
        "",
        pt.matrix_table(
            schemas["transactions"].drop(index="drift", errors="ignore"),
            "Synthetic card transactions, mean recall over five seeds.",
            "tab:m-transactions",
        ),
        "",
        pt.matrix_table(
            schemas["sensors"].drop(index="drift", errors="IGNORE"),
            "Synthetic sensor readings, mean recall over five seeds.",
            "tab:m-sensors",
        ),
        "",
        pt.matrix_table(
            median,
            r"Typed injection into $42$ real tables, median recall over the tables.",
            "tab:m-typed",
        ),
    ]
    return "\n".join(text) + "\n"


def x_section__mutmut_110(evidence: Path) -> str:
    out = evidence / "full_registry"
    customer = fs.synthetic_matrix(evidence, out)
    schemas = fs.schema_matrices(evidence / "multi_schema", out / "schemas_deep")
    typed = fs.merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    median = fs.ordered(ts.pooled(typed)["median"])
    text = [
        r"\section{Full per-type matrices}",
        r"\label{app:matrices}",
        "The tables below give the mean recall of every detector of the registry on each "
        "injected type, over five seeds for the synthetic tables and as the median over the "
        r"$42$ real tables for the last one. The best value of each column among the detectors "
        "of the registry is in bold.",
        "",
        pt.matrix_table(
            customer, "Synthetic customer table, mean recall over five seeds.", "tab:m-customer"
        ),
        "",
        pt.matrix_table(
            schemas["transactions"].drop(index="drift", errors="ignore"),
            "Synthetic card transactions, mean recall over five seeds.",
            "tab:m-transactions",
        ),
        "",
        pt.matrix_table(
            schemas["sensors"].drop(index="drift", errors="ignore"),
            "XXSynthetic sensor readings, mean recall over five seeds.XX",
            "tab:m-sensors",
        ),
        "",
        pt.matrix_table(
            median,
            r"Typed injection into $42$ real tables, median recall over the tables.",
            "tab:m-typed",
        ),
    ]
    return "\n".join(text) + "\n"


def x_section__mutmut_111(evidence: Path) -> str:
    out = evidence / "full_registry"
    customer = fs.synthetic_matrix(evidence, out)
    schemas = fs.schema_matrices(evidence / "multi_schema", out / "schemas_deep")
    typed = fs.merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    median = fs.ordered(ts.pooled(typed)["median"])
    text = [
        r"\section{Full per-type matrices}",
        r"\label{app:matrices}",
        "The tables below give the mean recall of every detector of the registry on each "
        "injected type, over five seeds for the synthetic tables and as the median over the "
        r"$42$ real tables for the last one. The best value of each column among the detectors "
        "of the registry is in bold.",
        "",
        pt.matrix_table(
            customer, "Synthetic customer table, mean recall over five seeds.", "tab:m-customer"
        ),
        "",
        pt.matrix_table(
            schemas["transactions"].drop(index="drift", errors="ignore"),
            "Synthetic card transactions, mean recall over five seeds.",
            "tab:m-transactions",
        ),
        "",
        pt.matrix_table(
            schemas["sensors"].drop(index="drift", errors="ignore"),
            "synthetic sensor readings, mean recall over five seeds.",
            "tab:m-sensors",
        ),
        "",
        pt.matrix_table(
            median,
            r"Typed injection into $42$ real tables, median recall over the tables.",
            "tab:m-typed",
        ),
    ]
    return "\n".join(text) + "\n"


def x_section__mutmut_112(evidence: Path) -> str:
    out = evidence / "full_registry"
    customer = fs.synthetic_matrix(evidence, out)
    schemas = fs.schema_matrices(evidence / "multi_schema", out / "schemas_deep")
    typed = fs.merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    median = fs.ordered(ts.pooled(typed)["median"])
    text = [
        r"\section{Full per-type matrices}",
        r"\label{app:matrices}",
        "The tables below give the mean recall of every detector of the registry on each "
        "injected type, over five seeds for the synthetic tables and as the median over the "
        r"$42$ real tables for the last one. The best value of each column among the detectors "
        "of the registry is in bold.",
        "",
        pt.matrix_table(
            customer, "Synthetic customer table, mean recall over five seeds.", "tab:m-customer"
        ),
        "",
        pt.matrix_table(
            schemas["transactions"].drop(index="drift", errors="ignore"),
            "Synthetic card transactions, mean recall over five seeds.",
            "tab:m-transactions",
        ),
        "",
        pt.matrix_table(
            schemas["sensors"].drop(index="drift", errors="ignore"),
            "SYNTHETIC SENSOR READINGS, MEAN RECALL OVER FIVE SEEDS.",
            "tab:m-sensors",
        ),
        "",
        pt.matrix_table(
            median,
            r"Typed injection into $42$ real tables, median recall over the tables.",
            "tab:m-typed",
        ),
    ]
    return "\n".join(text) + "\n"


def x_section__mutmut_113(evidence: Path) -> str:
    out = evidence / "full_registry"
    customer = fs.synthetic_matrix(evidence, out)
    schemas = fs.schema_matrices(evidence / "multi_schema", out / "schemas_deep")
    typed = fs.merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    median = fs.ordered(ts.pooled(typed)["median"])
    text = [
        r"\section{Full per-type matrices}",
        r"\label{app:matrices}",
        "The tables below give the mean recall of every detector of the registry on each "
        "injected type, over five seeds for the synthetic tables and as the median over the "
        r"$42$ real tables for the last one. The best value of each column among the detectors "
        "of the registry is in bold.",
        "",
        pt.matrix_table(
            customer, "Synthetic customer table, mean recall over five seeds.", "tab:m-customer"
        ),
        "",
        pt.matrix_table(
            schemas["transactions"].drop(index="drift", errors="ignore"),
            "Synthetic card transactions, mean recall over five seeds.",
            "tab:m-transactions",
        ),
        "",
        pt.matrix_table(
            schemas["sensors"].drop(index="drift", errors="ignore"),
            "Synthetic sensor readings, mean recall over five seeds.",
            "XXtab:m-sensorsXX",
        ),
        "",
        pt.matrix_table(
            median,
            r"Typed injection into $42$ real tables, median recall over the tables.",
            "tab:m-typed",
        ),
    ]
    return "\n".join(text) + "\n"


def x_section__mutmut_114(evidence: Path) -> str:
    out = evidence / "full_registry"
    customer = fs.synthetic_matrix(evidence, out)
    schemas = fs.schema_matrices(evidence / "multi_schema", out / "schemas_deep")
    typed = fs.merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    median = fs.ordered(ts.pooled(typed)["median"])
    text = [
        r"\section{Full per-type matrices}",
        r"\label{app:matrices}",
        "The tables below give the mean recall of every detector of the registry on each "
        "injected type, over five seeds for the synthetic tables and as the median over the "
        r"$42$ real tables for the last one. The best value of each column among the detectors "
        "of the registry is in bold.",
        "",
        pt.matrix_table(
            customer, "Synthetic customer table, mean recall over five seeds.", "tab:m-customer"
        ),
        "",
        pt.matrix_table(
            schemas["transactions"].drop(index="drift", errors="ignore"),
            "Synthetic card transactions, mean recall over five seeds.",
            "tab:m-transactions",
        ),
        "",
        pt.matrix_table(
            schemas["sensors"].drop(index="drift", errors="ignore"),
            "Synthetic sensor readings, mean recall over five seeds.",
            "TAB:M-SENSORS",
        ),
        "",
        pt.matrix_table(
            median,
            r"Typed injection into $42$ real tables, median recall over the tables.",
            "tab:m-typed",
        ),
    ]
    return "\n".join(text) + "\n"


def x_section__mutmut_115(evidence: Path) -> str:
    out = evidence / "full_registry"
    customer = fs.synthetic_matrix(evidence, out)
    schemas = fs.schema_matrices(evidence / "multi_schema", out / "schemas_deep")
    typed = fs.merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    median = fs.ordered(ts.pooled(typed)["median"])
    text = [
        r"\section{Full per-type matrices}",
        r"\label{app:matrices}",
        "The tables below give the mean recall of every detector of the registry on each "
        "injected type, over five seeds for the synthetic tables and as the median over the "
        r"$42$ real tables for the last one. The best value of each column among the detectors "
        "of the registry is in bold.",
        "",
        pt.matrix_table(
            customer, "Synthetic customer table, mean recall over five seeds.", "tab:m-customer"
        ),
        "",
        pt.matrix_table(
            schemas["transactions"].drop(index="drift", errors="ignore"),
            "Synthetic card transactions, mean recall over five seeds.",
            "tab:m-transactions",
        ),
        "",
        pt.matrix_table(
            schemas["sensors"].drop(index="drift", errors="ignore"),
            "Synthetic sensor readings, mean recall over five seeds.",
            "tab:m-sensors",
        ),
        "XXXX",
        pt.matrix_table(
            median,
            r"Typed injection into $42$ real tables, median recall over the tables.",
            "tab:m-typed",
        ),
    ]
    return "\n".join(text) + "\n"


def x_section__mutmut_116(evidence: Path) -> str:
    out = evidence / "full_registry"
    customer = fs.synthetic_matrix(evidence, out)
    schemas = fs.schema_matrices(evidence / "multi_schema", out / "schemas_deep")
    typed = fs.merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    median = fs.ordered(ts.pooled(typed)["median"])
    text = [
        r"\section{Full per-type matrices}",
        r"\label{app:matrices}",
        "The tables below give the mean recall of every detector of the registry on each "
        "injected type, over five seeds for the synthetic tables and as the median over the "
        r"$42$ real tables for the last one. The best value of each column among the detectors "
        "of the registry is in bold.",
        "",
        pt.matrix_table(
            customer, "Synthetic customer table, mean recall over five seeds.", "tab:m-customer"
        ),
        "",
        pt.matrix_table(
            schemas["transactions"].drop(index="drift", errors="ignore"),
            "Synthetic card transactions, mean recall over five seeds.",
            "tab:m-transactions",
        ),
        "",
        pt.matrix_table(
            schemas["sensors"].drop(index="drift", errors="ignore"),
            "Synthetic sensor readings, mean recall over five seeds.",
            "tab:m-sensors",
        ),
        "",
        pt.matrix_table(
            None,
            r"Typed injection into $42$ real tables, median recall over the tables.",
            "tab:m-typed",
        ),
    ]
    return "\n".join(text) + "\n"


def x_section__mutmut_117(evidence: Path) -> str:
    out = evidence / "full_registry"
    customer = fs.synthetic_matrix(evidence, out)
    schemas = fs.schema_matrices(evidence / "multi_schema", out / "schemas_deep")
    typed = fs.merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    median = fs.ordered(ts.pooled(typed)["median"])
    text = [
        r"\section{Full per-type matrices}",
        r"\label{app:matrices}",
        "The tables below give the mean recall of every detector of the registry on each "
        "injected type, over five seeds for the synthetic tables and as the median over the "
        r"$42$ real tables for the last one. The best value of each column among the detectors "
        "of the registry is in bold.",
        "",
        pt.matrix_table(
            customer, "Synthetic customer table, mean recall over five seeds.", "tab:m-customer"
        ),
        "",
        pt.matrix_table(
            schemas["transactions"].drop(index="drift", errors="ignore"),
            "Synthetic card transactions, mean recall over five seeds.",
            "tab:m-transactions",
        ),
        "",
        pt.matrix_table(
            schemas["sensors"].drop(index="drift", errors="ignore"),
            "Synthetic sensor readings, mean recall over five seeds.",
            "tab:m-sensors",
        ),
        "",
        pt.matrix_table(
            median,
            None,
            "tab:m-typed",
        ),
    ]
    return "\n".join(text) + "\n"


def x_section__mutmut_118(evidence: Path) -> str:
    out = evidence / "full_registry"
    customer = fs.synthetic_matrix(evidence, out)
    schemas = fs.schema_matrices(evidence / "multi_schema", out / "schemas_deep")
    typed = fs.merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    median = fs.ordered(ts.pooled(typed)["median"])
    text = [
        r"\section{Full per-type matrices}",
        r"\label{app:matrices}",
        "The tables below give the mean recall of every detector of the registry on each "
        "injected type, over five seeds for the synthetic tables and as the median over the "
        r"$42$ real tables for the last one. The best value of each column among the detectors "
        "of the registry is in bold.",
        "",
        pt.matrix_table(
            customer, "Synthetic customer table, mean recall over five seeds.", "tab:m-customer"
        ),
        "",
        pt.matrix_table(
            schemas["transactions"].drop(index="drift", errors="ignore"),
            "Synthetic card transactions, mean recall over five seeds.",
            "tab:m-transactions",
        ),
        "",
        pt.matrix_table(
            schemas["sensors"].drop(index="drift", errors="ignore"),
            "Synthetic sensor readings, mean recall over five seeds.",
            "tab:m-sensors",
        ),
        "",
        pt.matrix_table(
            median,
            r"Typed injection into $42$ real tables, median recall over the tables.",
            None,
        ),
    ]
    return "\n".join(text) + "\n"


def x_section__mutmut_119(evidence: Path) -> str:
    out = evidence / "full_registry"
    customer = fs.synthetic_matrix(evidence, out)
    schemas = fs.schema_matrices(evidence / "multi_schema", out / "schemas_deep")
    typed = fs.merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    median = fs.ordered(ts.pooled(typed)["median"])
    text = [
        r"\section{Full per-type matrices}",
        r"\label{app:matrices}",
        "The tables below give the mean recall of every detector of the registry on each "
        "injected type, over five seeds for the synthetic tables and as the median over the "
        r"$42$ real tables for the last one. The best value of each column among the detectors "
        "of the registry is in bold.",
        "",
        pt.matrix_table(
            customer, "Synthetic customer table, mean recall over five seeds.", "tab:m-customer"
        ),
        "",
        pt.matrix_table(
            schemas["transactions"].drop(index="drift", errors="ignore"),
            "Synthetic card transactions, mean recall over five seeds.",
            "tab:m-transactions",
        ),
        "",
        pt.matrix_table(
            schemas["sensors"].drop(index="drift", errors="ignore"),
            "Synthetic sensor readings, mean recall over five seeds.",
            "tab:m-sensors",
        ),
        "",
        pt.matrix_table(
            r"Typed injection into $42$ real tables, median recall over the tables.",
            "tab:m-typed",
        ),
    ]
    return "\n".join(text) + "\n"


def x_section__mutmut_120(evidence: Path) -> str:
    out = evidence / "full_registry"
    customer = fs.synthetic_matrix(evidence, out)
    schemas = fs.schema_matrices(evidence / "multi_schema", out / "schemas_deep")
    typed = fs.merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    median = fs.ordered(ts.pooled(typed)["median"])
    text = [
        r"\section{Full per-type matrices}",
        r"\label{app:matrices}",
        "The tables below give the mean recall of every detector of the registry on each "
        "injected type, over five seeds for the synthetic tables and as the median over the "
        r"$42$ real tables for the last one. The best value of each column among the detectors "
        "of the registry is in bold.",
        "",
        pt.matrix_table(
            customer, "Synthetic customer table, mean recall over five seeds.", "tab:m-customer"
        ),
        "",
        pt.matrix_table(
            schemas["transactions"].drop(index="drift", errors="ignore"),
            "Synthetic card transactions, mean recall over five seeds.",
            "tab:m-transactions",
        ),
        "",
        pt.matrix_table(
            schemas["sensors"].drop(index="drift", errors="ignore"),
            "Synthetic sensor readings, mean recall over five seeds.",
            "tab:m-sensors",
        ),
        "",
        pt.matrix_table(
            median,
            "tab:m-typed",
        ),
    ]
    return "\n".join(text) + "\n"


def x_section__mutmut_121(evidence: Path) -> str:
    out = evidence / "full_registry"
    customer = fs.synthetic_matrix(evidence, out)
    schemas = fs.schema_matrices(evidence / "multi_schema", out / "schemas_deep")
    typed = fs.merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    median = fs.ordered(ts.pooled(typed)["median"])
    text = [
        r"\section{Full per-type matrices}",
        r"\label{app:matrices}",
        "The tables below give the mean recall of every detector of the registry on each "
        "injected type, over five seeds for the synthetic tables and as the median over the "
        r"$42$ real tables for the last one. The best value of each column among the detectors "
        "of the registry is in bold.",
        "",
        pt.matrix_table(
            customer, "Synthetic customer table, mean recall over five seeds.", "tab:m-customer"
        ),
        "",
        pt.matrix_table(
            schemas["transactions"].drop(index="drift", errors="ignore"),
            "Synthetic card transactions, mean recall over five seeds.",
            "tab:m-transactions",
        ),
        "",
        pt.matrix_table(
            schemas["sensors"].drop(index="drift", errors="ignore"),
            "Synthetic sensor readings, mean recall over five seeds.",
            "tab:m-sensors",
        ),
        "",
        pt.matrix_table(
            median,
            r"Typed injection into $42$ real tables, median recall over the tables.",
            ),
    ]
    return "\n".join(text) + "\n"


def x_section__mutmut_122(evidence: Path) -> str:
    out = evidence / "full_registry"
    customer = fs.synthetic_matrix(evidence, out)
    schemas = fs.schema_matrices(evidence / "multi_schema", out / "schemas_deep")
    typed = fs.merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    median = fs.ordered(ts.pooled(typed)["median"])
    text = [
        r"\section{Full per-type matrices}",
        r"\label{app:matrices}",
        "The tables below give the mean recall of every detector of the registry on each "
        "injected type, over five seeds for the synthetic tables and as the median over the "
        r"$42$ real tables for the last one. The best value of each column among the detectors "
        "of the registry is in bold.",
        "",
        pt.matrix_table(
            customer, "Synthetic customer table, mean recall over five seeds.", "tab:m-customer"
        ),
        "",
        pt.matrix_table(
            schemas["transactions"].drop(index="drift", errors="ignore"),
            "Synthetic card transactions, mean recall over five seeds.",
            "tab:m-transactions",
        ),
        "",
        pt.matrix_table(
            schemas["sensors"].drop(index="drift", errors="ignore"),
            "Synthetic sensor readings, mean recall over five seeds.",
            "tab:m-sensors",
        ),
        "",
        pt.matrix_table(
            median,
            r"XXTyped injection into $42$ real tables, median recall over the tables.XX",
            "tab:m-typed",
        ),
    ]
    return "\n".join(text) + "\n"


def x_section__mutmut_123(evidence: Path) -> str:
    out = evidence / "full_registry"
    customer = fs.synthetic_matrix(evidence, out)
    schemas = fs.schema_matrices(evidence / "multi_schema", out / "schemas_deep")
    typed = fs.merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    median = fs.ordered(ts.pooled(typed)["median"])
    text = [
        r"\section{Full per-type matrices}",
        r"\label{app:matrices}",
        "The tables below give the mean recall of every detector of the registry on each "
        "injected type, over five seeds for the synthetic tables and as the median over the "
        r"$42$ real tables for the last one. The best value of each column among the detectors "
        "of the registry is in bold.",
        "",
        pt.matrix_table(
            customer, "Synthetic customer table, mean recall over five seeds.", "tab:m-customer"
        ),
        "",
        pt.matrix_table(
            schemas["transactions"].drop(index="drift", errors="ignore"),
            "Synthetic card transactions, mean recall over five seeds.",
            "tab:m-transactions",
        ),
        "",
        pt.matrix_table(
            schemas["sensors"].drop(index="drift", errors="ignore"),
            "Synthetic sensor readings, mean recall over five seeds.",
            "tab:m-sensors",
        ),
        "",
        pt.matrix_table(
            median,
            r"typed injection into $42$ real tables, median recall over the tables.",
            "tab:m-typed",
        ),
    ]
    return "\n".join(text) + "\n"


def x_section__mutmut_124(evidence: Path) -> str:
    out = evidence / "full_registry"
    customer = fs.synthetic_matrix(evidence, out)
    schemas = fs.schema_matrices(evidence / "multi_schema", out / "schemas_deep")
    typed = fs.merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    median = fs.ordered(ts.pooled(typed)["median"])
    text = [
        r"\section{Full per-type matrices}",
        r"\label{app:matrices}",
        "The tables below give the mean recall of every detector of the registry on each "
        "injected type, over five seeds for the synthetic tables and as the median over the "
        r"$42$ real tables for the last one. The best value of each column among the detectors "
        "of the registry is in bold.",
        "",
        pt.matrix_table(
            customer, "Synthetic customer table, mean recall over five seeds.", "tab:m-customer"
        ),
        "",
        pt.matrix_table(
            schemas["transactions"].drop(index="drift", errors="ignore"),
            "Synthetic card transactions, mean recall over five seeds.",
            "tab:m-transactions",
        ),
        "",
        pt.matrix_table(
            schemas["sensors"].drop(index="drift", errors="ignore"),
            "Synthetic sensor readings, mean recall over five seeds.",
            "tab:m-sensors",
        ),
        "",
        pt.matrix_table(
            median,
            r"TYPED INJECTION INTO $42$ REAL TABLES, MEDIAN RECALL OVER THE TABLES.",
            "tab:m-typed",
        ),
    ]
    return "\n".join(text) + "\n"


def x_section__mutmut_125(evidence: Path) -> str:
    out = evidence / "full_registry"
    customer = fs.synthetic_matrix(evidence, out)
    schemas = fs.schema_matrices(evidence / "multi_schema", out / "schemas_deep")
    typed = fs.merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    median = fs.ordered(ts.pooled(typed)["median"])
    text = [
        r"\section{Full per-type matrices}",
        r"\label{app:matrices}",
        "The tables below give the mean recall of every detector of the registry on each "
        "injected type, over five seeds for the synthetic tables and as the median over the "
        r"$42$ real tables for the last one. The best value of each column among the detectors "
        "of the registry is in bold.",
        "",
        pt.matrix_table(
            customer, "Synthetic customer table, mean recall over five seeds.", "tab:m-customer"
        ),
        "",
        pt.matrix_table(
            schemas["transactions"].drop(index="drift", errors="ignore"),
            "Synthetic card transactions, mean recall over five seeds.",
            "tab:m-transactions",
        ),
        "",
        pt.matrix_table(
            schemas["sensors"].drop(index="drift", errors="ignore"),
            "Synthetic sensor readings, mean recall over five seeds.",
            "tab:m-sensors",
        ),
        "",
        pt.matrix_table(
            median,
            r"Typed injection into $42$ real tables, median recall over the tables.",
            "XXtab:m-typedXX",
        ),
    ]
    return "\n".join(text) + "\n"


def x_section__mutmut_126(evidence: Path) -> str:
    out = evidence / "full_registry"
    customer = fs.synthetic_matrix(evidence, out)
    schemas = fs.schema_matrices(evidence / "multi_schema", out / "schemas_deep")
    typed = fs.merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    median = fs.ordered(ts.pooled(typed)["median"])
    text = [
        r"\section{Full per-type matrices}",
        r"\label{app:matrices}",
        "The tables below give the mean recall of every detector of the registry on each "
        "injected type, over five seeds for the synthetic tables and as the median over the "
        r"$42$ real tables for the last one. The best value of each column among the detectors "
        "of the registry is in bold.",
        "",
        pt.matrix_table(
            customer, "Synthetic customer table, mean recall over five seeds.", "tab:m-customer"
        ),
        "",
        pt.matrix_table(
            schemas["transactions"].drop(index="drift", errors="ignore"),
            "Synthetic card transactions, mean recall over five seeds.",
            "tab:m-transactions",
        ),
        "",
        pt.matrix_table(
            schemas["sensors"].drop(index="drift", errors="ignore"),
            "Synthetic sensor readings, mean recall over five seeds.",
            "tab:m-sensors",
        ),
        "",
        pt.matrix_table(
            median,
            r"Typed injection into $42$ real tables, median recall over the tables.",
            "TAB:M-TYPED",
        ),
    ]
    return "\n".join(text) + "\n"


def x_section__mutmut_127(evidence: Path) -> str:
    out = evidence / "full_registry"
    customer = fs.synthetic_matrix(evidence, out)
    schemas = fs.schema_matrices(evidence / "multi_schema", out / "schemas_deep")
    typed = fs.merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    median = fs.ordered(ts.pooled(typed)["median"])
    text = [
        r"\section{Full per-type matrices}",
        r"\label{app:matrices}",
        "The tables below give the mean recall of every detector of the registry on each "
        "injected type, over five seeds for the synthetic tables and as the median over the "
        r"$42$ real tables for the last one. The best value of each column among the detectors "
        "of the registry is in bold.",
        "",
        pt.matrix_table(
            customer, "Synthetic customer table, mean recall over five seeds.", "tab:m-customer"
        ),
        "",
        pt.matrix_table(
            schemas["transactions"].drop(index="drift", errors="ignore"),
            "Synthetic card transactions, mean recall over five seeds.",
            "tab:m-transactions",
        ),
        "",
        pt.matrix_table(
            schemas["sensors"].drop(index="drift", errors="ignore"),
            "Synthetic sensor readings, mean recall over five seeds.",
            "tab:m-sensors",
        ),
        "",
        pt.matrix_table(
            median,
            r"Typed injection into $42$ real tables, median recall over the tables.",
            "tab:m-typed",
        ),
    ]
    return "\n".join(text) - "\n"


def x_section__mutmut_128(evidence: Path) -> str:
    out = evidence / "full_registry"
    customer = fs.synthetic_matrix(evidence, out)
    schemas = fs.schema_matrices(evidence / "multi_schema", out / "schemas_deep")
    typed = fs.merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    median = fs.ordered(ts.pooled(typed)["median"])
    text = [
        r"\section{Full per-type matrices}",
        r"\label{app:matrices}",
        "The tables below give the mean recall of every detector of the registry on each "
        "injected type, over five seeds for the synthetic tables and as the median over the "
        r"$42$ real tables for the last one. The best value of each column among the detectors "
        "of the registry is in bold.",
        "",
        pt.matrix_table(
            customer, "Synthetic customer table, mean recall over five seeds.", "tab:m-customer"
        ),
        "",
        pt.matrix_table(
            schemas["transactions"].drop(index="drift", errors="ignore"),
            "Synthetic card transactions, mean recall over five seeds.",
            "tab:m-transactions",
        ),
        "",
        pt.matrix_table(
            schemas["sensors"].drop(index="drift", errors="ignore"),
            "Synthetic sensor readings, mean recall over five seeds.",
            "tab:m-sensors",
        ),
        "",
        pt.matrix_table(
            median,
            r"Typed injection into $42$ real tables, median recall over the tables.",
            "tab:m-typed",
        ),
    ]
    return "\n".join(None) + "\n"


def x_section__mutmut_129(evidence: Path) -> str:
    out = evidence / "full_registry"
    customer = fs.synthetic_matrix(evidence, out)
    schemas = fs.schema_matrices(evidence / "multi_schema", out / "schemas_deep")
    typed = fs.merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    median = fs.ordered(ts.pooled(typed)["median"])
    text = [
        r"\section{Full per-type matrices}",
        r"\label{app:matrices}",
        "The tables below give the mean recall of every detector of the registry on each "
        "injected type, over five seeds for the synthetic tables and as the median over the "
        r"$42$ real tables for the last one. The best value of each column among the detectors "
        "of the registry is in bold.",
        "",
        pt.matrix_table(
            customer, "Synthetic customer table, mean recall over five seeds.", "tab:m-customer"
        ),
        "",
        pt.matrix_table(
            schemas["transactions"].drop(index="drift", errors="ignore"),
            "Synthetic card transactions, mean recall over five seeds.",
            "tab:m-transactions",
        ),
        "",
        pt.matrix_table(
            schemas["sensors"].drop(index="drift", errors="ignore"),
            "Synthetic sensor readings, mean recall over five seeds.",
            "tab:m-sensors",
        ),
        "",
        pt.matrix_table(
            median,
            r"Typed injection into $42$ real tables, median recall over the tables.",
            "tab:m-typed",
        ),
    ]
    return "XX\nXX".join(text) + "\n"


def x_section__mutmut_130(evidence: Path) -> str:
    out = evidence / "full_registry"
    customer = fs.synthetic_matrix(evidence, out)
    schemas = fs.schema_matrices(evidence / "multi_schema", out / "schemas_deep")
    typed = fs.merged_typed(evidence / "typed_injection" / "runs", out / "typed_deep" / "runs")
    median = fs.ordered(ts.pooled(typed)["median"])
    text = [
        r"\section{Full per-type matrices}",
        r"\label{app:matrices}",
        "The tables below give the mean recall of every detector of the registry on each "
        "injected type, over five seeds for the synthetic tables and as the median over the "
        r"$42$ real tables for the last one. The best value of each column among the detectors "
        "of the registry is in bold.",
        "",
        pt.matrix_table(
            customer, "Synthetic customer table, mean recall over five seeds.", "tab:m-customer"
        ),
        "",
        pt.matrix_table(
            schemas["transactions"].drop(index="drift", errors="ignore"),
            "Synthetic card transactions, mean recall over five seeds.",
            "tab:m-transactions",
        ),
        "",
        pt.matrix_table(
            schemas["sensors"].drop(index="drift", errors="ignore"),
            "Synthetic sensor readings, mean recall over five seeds.",
            "tab:m-sensors",
        ),
        "",
        pt.matrix_table(
            median,
            r"Typed injection into $42$ real tables, median recall over the tables.",
            "tab:m-typed",
        ),
    ]
    return "\n".join(text) + "XX\nXX"

mutants_x_section__mutmut['_mutmut_orig'] = x_section__mutmut_orig # type: ignore # mutmut generated
mutants_x_section__mutmut['x_section__mutmut_1'] = x_section__mutmut_1 # type: ignore # mutmut generated
mutants_x_section__mutmut['x_section__mutmut_2'] = x_section__mutmut_2 # type: ignore # mutmut generated
mutants_x_section__mutmut['x_section__mutmut_3'] = x_section__mutmut_3 # type: ignore # mutmut generated
mutants_x_section__mutmut['x_section__mutmut_4'] = x_section__mutmut_4 # type: ignore # mutmut generated
mutants_x_section__mutmut['x_section__mutmut_5'] = x_section__mutmut_5 # type: ignore # mutmut generated
mutants_x_section__mutmut['x_section__mutmut_6'] = x_section__mutmut_6 # type: ignore # mutmut generated
mutants_x_section__mutmut['x_section__mutmut_7'] = x_section__mutmut_7 # type: ignore # mutmut generated
mutants_x_section__mutmut['x_section__mutmut_8'] = x_section__mutmut_8 # type: ignore # mutmut generated
mutants_x_section__mutmut['x_section__mutmut_9'] = x_section__mutmut_9 # type: ignore # mutmut generated
mutants_x_section__mutmut['x_section__mutmut_10'] = x_section__mutmut_10 # type: ignore # mutmut generated
mutants_x_section__mutmut['x_section__mutmut_11'] = x_section__mutmut_11 # type: ignore # mutmut generated
mutants_x_section__mutmut['x_section__mutmut_12'] = x_section__mutmut_12 # type: ignore # mutmut generated
mutants_x_section__mutmut['x_section__mutmut_13'] = x_section__mutmut_13 # type: ignore # mutmut generated
mutants_x_section__mutmut['x_section__mutmut_14'] = x_section__mutmut_14 # type: ignore # mutmut generated
mutants_x_section__mutmut['x_section__mutmut_15'] = x_section__mutmut_15 # type: ignore # mutmut generated
mutants_x_section__mutmut['x_section__mutmut_16'] = x_section__mutmut_16 # type: ignore # mutmut generated
mutants_x_section__mutmut['x_section__mutmut_17'] = x_section__mutmut_17 # type: ignore # mutmut generated
mutants_x_section__mutmut['x_section__mutmut_18'] = x_section__mutmut_18 # type: ignore # mutmut generated
mutants_x_section__mutmut['x_section__mutmut_19'] = x_section__mutmut_19 # type: ignore # mutmut generated
mutants_x_section__mutmut['x_section__mutmut_20'] = x_section__mutmut_20 # type: ignore # mutmut generated
mutants_x_section__mutmut['x_section__mutmut_21'] = x_section__mutmut_21 # type: ignore # mutmut generated
mutants_x_section__mutmut['x_section__mutmut_22'] = x_section__mutmut_22 # type: ignore # mutmut generated
mutants_x_section__mutmut['x_section__mutmut_23'] = x_section__mutmut_23 # type: ignore # mutmut generated
mutants_x_section__mutmut['x_section__mutmut_24'] = x_section__mutmut_24 # type: ignore # mutmut generated
mutants_x_section__mutmut['x_section__mutmut_25'] = x_section__mutmut_25 # type: ignore # mutmut generated
mutants_x_section__mutmut['x_section__mutmut_26'] = x_section__mutmut_26 # type: ignore # mutmut generated
mutants_x_section__mutmut['x_section__mutmut_27'] = x_section__mutmut_27 # type: ignore # mutmut generated
mutants_x_section__mutmut['x_section__mutmut_28'] = x_section__mutmut_28 # type: ignore # mutmut generated
mutants_x_section__mutmut['x_section__mutmut_29'] = x_section__mutmut_29 # type: ignore # mutmut generated
mutants_x_section__mutmut['x_section__mutmut_30'] = x_section__mutmut_30 # type: ignore # mutmut generated
mutants_x_section__mutmut['x_section__mutmut_31'] = x_section__mutmut_31 # type: ignore # mutmut generated
mutants_x_section__mutmut['x_section__mutmut_32'] = x_section__mutmut_32 # type: ignore # mutmut generated
mutants_x_section__mutmut['x_section__mutmut_33'] = x_section__mutmut_33 # type: ignore # mutmut generated
mutants_x_section__mutmut['x_section__mutmut_34'] = x_section__mutmut_34 # type: ignore # mutmut generated
mutants_x_section__mutmut['x_section__mutmut_35'] = x_section__mutmut_35 # type: ignore # mutmut generated
mutants_x_section__mutmut['x_section__mutmut_36'] = x_section__mutmut_36 # type: ignore # mutmut generated
mutants_x_section__mutmut['x_section__mutmut_37'] = x_section__mutmut_37 # type: ignore # mutmut generated
mutants_x_section__mutmut['x_section__mutmut_38'] = x_section__mutmut_38 # type: ignore # mutmut generated
mutants_x_section__mutmut['x_section__mutmut_39'] = x_section__mutmut_39 # type: ignore # mutmut generated
mutants_x_section__mutmut['x_section__mutmut_40'] = x_section__mutmut_40 # type: ignore # mutmut generated
mutants_x_section__mutmut['x_section__mutmut_41'] = x_section__mutmut_41 # type: ignore # mutmut generated
mutants_x_section__mutmut['x_section__mutmut_42'] = x_section__mutmut_42 # type: ignore # mutmut generated
mutants_x_section__mutmut['x_section__mutmut_43'] = x_section__mutmut_43 # type: ignore # mutmut generated
mutants_x_section__mutmut['x_section__mutmut_44'] = x_section__mutmut_44 # type: ignore # mutmut generated
mutants_x_section__mutmut['x_section__mutmut_45'] = x_section__mutmut_45 # type: ignore # mutmut generated
mutants_x_section__mutmut['x_section__mutmut_46'] = x_section__mutmut_46 # type: ignore # mutmut generated
mutants_x_section__mutmut['x_section__mutmut_47'] = x_section__mutmut_47 # type: ignore # mutmut generated
mutants_x_section__mutmut['x_section__mutmut_48'] = x_section__mutmut_48 # type: ignore # mutmut generated
mutants_x_section__mutmut['x_section__mutmut_49'] = x_section__mutmut_49 # type: ignore # mutmut generated
mutants_x_section__mutmut['x_section__mutmut_50'] = x_section__mutmut_50 # type: ignore # mutmut generated
mutants_x_section__mutmut['x_section__mutmut_51'] = x_section__mutmut_51 # type: ignore # mutmut generated
mutants_x_section__mutmut['x_section__mutmut_52'] = x_section__mutmut_52 # type: ignore # mutmut generated
mutants_x_section__mutmut['x_section__mutmut_53'] = x_section__mutmut_53 # type: ignore # mutmut generated
mutants_x_section__mutmut['x_section__mutmut_54'] = x_section__mutmut_54 # type: ignore # mutmut generated
mutants_x_section__mutmut['x_section__mutmut_55'] = x_section__mutmut_55 # type: ignore # mutmut generated
mutants_x_section__mutmut['x_section__mutmut_56'] = x_section__mutmut_56 # type: ignore # mutmut generated
mutants_x_section__mutmut['x_section__mutmut_57'] = x_section__mutmut_57 # type: ignore # mutmut generated
mutants_x_section__mutmut['x_section__mutmut_58'] = x_section__mutmut_58 # type: ignore # mutmut generated
mutants_x_section__mutmut['x_section__mutmut_59'] = x_section__mutmut_59 # type: ignore # mutmut generated
mutants_x_section__mutmut['x_section__mutmut_60'] = x_section__mutmut_60 # type: ignore # mutmut generated
mutants_x_section__mutmut['x_section__mutmut_61'] = x_section__mutmut_61 # type: ignore # mutmut generated
mutants_x_section__mutmut['x_section__mutmut_62'] = x_section__mutmut_62 # type: ignore # mutmut generated
mutants_x_section__mutmut['x_section__mutmut_63'] = x_section__mutmut_63 # type: ignore # mutmut generated
mutants_x_section__mutmut['x_section__mutmut_64'] = x_section__mutmut_64 # type: ignore # mutmut generated
mutants_x_section__mutmut['x_section__mutmut_65'] = x_section__mutmut_65 # type: ignore # mutmut generated
mutants_x_section__mutmut['x_section__mutmut_66'] = x_section__mutmut_66 # type: ignore # mutmut generated
mutants_x_section__mutmut['x_section__mutmut_67'] = x_section__mutmut_67 # type: ignore # mutmut generated
mutants_x_section__mutmut['x_section__mutmut_68'] = x_section__mutmut_68 # type: ignore # mutmut generated
mutants_x_section__mutmut['x_section__mutmut_69'] = x_section__mutmut_69 # type: ignore # mutmut generated
mutants_x_section__mutmut['x_section__mutmut_70'] = x_section__mutmut_70 # type: ignore # mutmut generated
mutants_x_section__mutmut['x_section__mutmut_71'] = x_section__mutmut_71 # type: ignore # mutmut generated
mutants_x_section__mutmut['x_section__mutmut_72'] = x_section__mutmut_72 # type: ignore # mutmut generated
mutants_x_section__mutmut['x_section__mutmut_73'] = x_section__mutmut_73 # type: ignore # mutmut generated
mutants_x_section__mutmut['x_section__mutmut_74'] = x_section__mutmut_74 # type: ignore # mutmut generated
mutants_x_section__mutmut['x_section__mutmut_75'] = x_section__mutmut_75 # type: ignore # mutmut generated
mutants_x_section__mutmut['x_section__mutmut_76'] = x_section__mutmut_76 # type: ignore # mutmut generated
mutants_x_section__mutmut['x_section__mutmut_77'] = x_section__mutmut_77 # type: ignore # mutmut generated
mutants_x_section__mutmut['x_section__mutmut_78'] = x_section__mutmut_78 # type: ignore # mutmut generated
mutants_x_section__mutmut['x_section__mutmut_79'] = x_section__mutmut_79 # type: ignore # mutmut generated
mutants_x_section__mutmut['x_section__mutmut_80'] = x_section__mutmut_80 # type: ignore # mutmut generated
mutants_x_section__mutmut['x_section__mutmut_81'] = x_section__mutmut_81 # type: ignore # mutmut generated
mutants_x_section__mutmut['x_section__mutmut_82'] = x_section__mutmut_82 # type: ignore # mutmut generated
mutants_x_section__mutmut['x_section__mutmut_83'] = x_section__mutmut_83 # type: ignore # mutmut generated
mutants_x_section__mutmut['x_section__mutmut_84'] = x_section__mutmut_84 # type: ignore # mutmut generated
mutants_x_section__mutmut['x_section__mutmut_85'] = x_section__mutmut_85 # type: ignore # mutmut generated
mutants_x_section__mutmut['x_section__mutmut_86'] = x_section__mutmut_86 # type: ignore # mutmut generated
mutants_x_section__mutmut['x_section__mutmut_87'] = x_section__mutmut_87 # type: ignore # mutmut generated
mutants_x_section__mutmut['x_section__mutmut_88'] = x_section__mutmut_88 # type: ignore # mutmut generated
mutants_x_section__mutmut['x_section__mutmut_89'] = x_section__mutmut_89 # type: ignore # mutmut generated
mutants_x_section__mutmut['x_section__mutmut_90'] = x_section__mutmut_90 # type: ignore # mutmut generated
mutants_x_section__mutmut['x_section__mutmut_91'] = x_section__mutmut_91 # type: ignore # mutmut generated
mutants_x_section__mutmut['x_section__mutmut_92'] = x_section__mutmut_92 # type: ignore # mutmut generated
mutants_x_section__mutmut['x_section__mutmut_93'] = x_section__mutmut_93 # type: ignore # mutmut generated
mutants_x_section__mutmut['x_section__mutmut_94'] = x_section__mutmut_94 # type: ignore # mutmut generated
mutants_x_section__mutmut['x_section__mutmut_95'] = x_section__mutmut_95 # type: ignore # mutmut generated
mutants_x_section__mutmut['x_section__mutmut_96'] = x_section__mutmut_96 # type: ignore # mutmut generated
mutants_x_section__mutmut['x_section__mutmut_97'] = x_section__mutmut_97 # type: ignore # mutmut generated
mutants_x_section__mutmut['x_section__mutmut_98'] = x_section__mutmut_98 # type: ignore # mutmut generated
mutants_x_section__mutmut['x_section__mutmut_99'] = x_section__mutmut_99 # type: ignore # mutmut generated
mutants_x_section__mutmut['x_section__mutmut_100'] = x_section__mutmut_100 # type: ignore # mutmut generated
mutants_x_section__mutmut['x_section__mutmut_101'] = x_section__mutmut_101 # type: ignore # mutmut generated
mutants_x_section__mutmut['x_section__mutmut_102'] = x_section__mutmut_102 # type: ignore # mutmut generated
mutants_x_section__mutmut['x_section__mutmut_103'] = x_section__mutmut_103 # type: ignore # mutmut generated
mutants_x_section__mutmut['x_section__mutmut_104'] = x_section__mutmut_104 # type: ignore # mutmut generated
mutants_x_section__mutmut['x_section__mutmut_105'] = x_section__mutmut_105 # type: ignore # mutmut generated
mutants_x_section__mutmut['x_section__mutmut_106'] = x_section__mutmut_106 # type: ignore # mutmut generated
mutants_x_section__mutmut['x_section__mutmut_107'] = x_section__mutmut_107 # type: ignore # mutmut generated
mutants_x_section__mutmut['x_section__mutmut_108'] = x_section__mutmut_108 # type: ignore # mutmut generated
mutants_x_section__mutmut['x_section__mutmut_109'] = x_section__mutmut_109 # type: ignore # mutmut generated
mutants_x_section__mutmut['x_section__mutmut_110'] = x_section__mutmut_110 # type: ignore # mutmut generated
mutants_x_section__mutmut['x_section__mutmut_111'] = x_section__mutmut_111 # type: ignore # mutmut generated
mutants_x_section__mutmut['x_section__mutmut_112'] = x_section__mutmut_112 # type: ignore # mutmut generated
mutants_x_section__mutmut['x_section__mutmut_113'] = x_section__mutmut_113 # type: ignore # mutmut generated
mutants_x_section__mutmut['x_section__mutmut_114'] = x_section__mutmut_114 # type: ignore # mutmut generated
mutants_x_section__mutmut['x_section__mutmut_115'] = x_section__mutmut_115 # type: ignore # mutmut generated
mutants_x_section__mutmut['x_section__mutmut_116'] = x_section__mutmut_116 # type: ignore # mutmut generated
mutants_x_section__mutmut['x_section__mutmut_117'] = x_section__mutmut_117 # type: ignore # mutmut generated
mutants_x_section__mutmut['x_section__mutmut_118'] = x_section__mutmut_118 # type: ignore # mutmut generated
mutants_x_section__mutmut['x_section__mutmut_119'] = x_section__mutmut_119 # type: ignore # mutmut generated
mutants_x_section__mutmut['x_section__mutmut_120'] = x_section__mutmut_120 # type: ignore # mutmut generated
mutants_x_section__mutmut['x_section__mutmut_121'] = x_section__mutmut_121 # type: ignore # mutmut generated
mutants_x_section__mutmut['x_section__mutmut_122'] = x_section__mutmut_122 # type: ignore # mutmut generated
mutants_x_section__mutmut['x_section__mutmut_123'] = x_section__mutmut_123 # type: ignore # mutmut generated
mutants_x_section__mutmut['x_section__mutmut_124'] = x_section__mutmut_124 # type: ignore # mutmut generated
mutants_x_section__mutmut['x_section__mutmut_125'] = x_section__mutmut_125 # type: ignore # mutmut generated
mutants_x_section__mutmut['x_section__mutmut_126'] = x_section__mutmut_126 # type: ignore # mutmut generated
mutants_x_section__mutmut['x_section__mutmut_127'] = x_section__mutmut_127 # type: ignore # mutmut generated
mutants_x_section__mutmut['x_section__mutmut_128'] = x_section__mutmut_128 # type: ignore # mutmut generated
mutants_x_section__mutmut['x_section__mutmut_129'] = x_section__mutmut_129 # type: ignore # mutmut generated
mutants_x_section__mutmut['x_section__mutmut_130'] = x_section__mutmut_130 # type: ignore # mutmut generated
mutants_x_write__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_write__mutmut)
def write(tex: Path, evidence: Path) -> None:
    body = tex.read_text()
    block = START + section(evidence) + END
    if START in body:
        head, rest = body.split(START, 1)
        tail = rest.split(END, 1)[1]
        body = head + block + tail
    else:
        marker = "\\bibliographystyle"
        head, tail = body.split(marker, 1)
        body = head + block + "\n" + marker + tail
    tex.write_text(body)


def x_write__mutmut_orig(tex: Path, evidence: Path) -> None:
    body = tex.read_text()
    block = START + section(evidence) + END
    if START in body:
        head, rest = body.split(START, 1)
        tail = rest.split(END, 1)[1]
        body = head + block + tail
    else:
        marker = "\\bibliographystyle"
        head, tail = body.split(marker, 1)
        body = head + block + "\n" + marker + tail
    tex.write_text(body)


def x_write__mutmut_1(tex: Path, evidence: Path) -> None:
    body = None
    block = START + section(evidence) + END
    if START in body:
        head, rest = body.split(START, 1)
        tail = rest.split(END, 1)[1]
        body = head + block + tail
    else:
        marker = "\\bibliographystyle"
        head, tail = body.split(marker, 1)
        body = head + block + "\n" + marker + tail
    tex.write_text(body)


def x_write__mutmut_2(tex: Path, evidence: Path) -> None:
    body = tex.read_text()
    block = None
    if START in body:
        head, rest = body.split(START, 1)
        tail = rest.split(END, 1)[1]
        body = head + block + tail
    else:
        marker = "\\bibliographystyle"
        head, tail = body.split(marker, 1)
        body = head + block + "\n" + marker + tail
    tex.write_text(body)


def x_write__mutmut_3(tex: Path, evidence: Path) -> None:
    body = tex.read_text()
    block = START + section(evidence) - END
    if START in body:
        head, rest = body.split(START, 1)
        tail = rest.split(END, 1)[1]
        body = head + block + tail
    else:
        marker = "\\bibliographystyle"
        head, tail = body.split(marker, 1)
        body = head + block + "\n" + marker + tail
    tex.write_text(body)


def x_write__mutmut_4(tex: Path, evidence: Path) -> None:
    body = tex.read_text()
    block = START - section(evidence) + END
    if START in body:
        head, rest = body.split(START, 1)
        tail = rest.split(END, 1)[1]
        body = head + block + tail
    else:
        marker = "\\bibliographystyle"
        head, tail = body.split(marker, 1)
        body = head + block + "\n" + marker + tail
    tex.write_text(body)


def x_write__mutmut_5(tex: Path, evidence: Path) -> None:
    body = tex.read_text()
    block = START + section(None) + END
    if START in body:
        head, rest = body.split(START, 1)
        tail = rest.split(END, 1)[1]
        body = head + block + tail
    else:
        marker = "\\bibliographystyle"
        head, tail = body.split(marker, 1)
        body = head + block + "\n" + marker + tail
    tex.write_text(body)


def x_write__mutmut_6(tex: Path, evidence: Path) -> None:
    body = tex.read_text()
    block = START + section(evidence) + END
    if START not in body:
        head, rest = body.split(START, 1)
        tail = rest.split(END, 1)[1]
        body = head + block + tail
    else:
        marker = "\\bibliographystyle"
        head, tail = body.split(marker, 1)
        body = head + block + "\n" + marker + tail
    tex.write_text(body)


def x_write__mutmut_7(tex: Path, evidence: Path) -> None:
    body = tex.read_text()
    block = START + section(evidence) + END
    if START in body:
        head, rest = None
        tail = rest.split(END, 1)[1]
        body = head + block + tail
    else:
        marker = "\\bibliographystyle"
        head, tail = body.split(marker, 1)
        body = head + block + "\n" + marker + tail
    tex.write_text(body)


def x_write__mutmut_8(tex: Path, evidence: Path) -> None:
    body = tex.read_text()
    block = START + section(evidence) + END
    if START in body:
        head, rest = body.split(None, 1)
        tail = rest.split(END, 1)[1]
        body = head + block + tail
    else:
        marker = "\\bibliographystyle"
        head, tail = body.split(marker, 1)
        body = head + block + "\n" + marker + tail
    tex.write_text(body)


def x_write__mutmut_9(tex: Path, evidence: Path) -> None:
    body = tex.read_text()
    block = START + section(evidence) + END
    if START in body:
        head, rest = body.split(START, None)
        tail = rest.split(END, 1)[1]
        body = head + block + tail
    else:
        marker = "\\bibliographystyle"
        head, tail = body.split(marker, 1)
        body = head + block + "\n" + marker + tail
    tex.write_text(body)


def x_write__mutmut_10(tex: Path, evidence: Path) -> None:
    body = tex.read_text()
    block = START + section(evidence) + END
    if START in body:
        head, rest = body.split(1)
        tail = rest.split(END, 1)[1]
        body = head + block + tail
    else:
        marker = "\\bibliographystyle"
        head, tail = body.split(marker, 1)
        body = head + block + "\n" + marker + tail
    tex.write_text(body)


def x_write__mutmut_11(tex: Path, evidence: Path) -> None:
    body = tex.read_text()
    block = START + section(evidence) + END
    if START in body:
        head, rest = body.split(START, )
        tail = rest.split(END, 1)[1]
        body = head + block + tail
    else:
        marker = "\\bibliographystyle"
        head, tail = body.split(marker, 1)
        body = head + block + "\n" + marker + tail
    tex.write_text(body)


def x_write__mutmut_12(tex: Path, evidence: Path) -> None:
    body = tex.read_text()
    block = START + section(evidence) + END
    if START in body:
        head, rest = body.rsplit(START, 1)
        tail = rest.split(END, 1)[1]
        body = head + block + tail
    else:
        marker = "\\bibliographystyle"
        head, tail = body.split(marker, 1)
        body = head + block + "\n" + marker + tail
    tex.write_text(body)


def x_write__mutmut_13(tex: Path, evidence: Path) -> None:
    body = tex.read_text()
    block = START + section(evidence) + END
    if START in body:
        head, rest = body.split(START, 2)
        tail = rest.split(END, 1)[1]
        body = head + block + tail
    else:
        marker = "\\bibliographystyle"
        head, tail = body.split(marker, 1)
        body = head + block + "\n" + marker + tail
    tex.write_text(body)


def x_write__mutmut_14(tex: Path, evidence: Path) -> None:
    body = tex.read_text()
    block = START + section(evidence) + END
    if START in body:
        head, rest = body.split(START, 1)
        tail = None
        body = head + block + tail
    else:
        marker = "\\bibliographystyle"
        head, tail = body.split(marker, 1)
        body = head + block + "\n" + marker + tail
    tex.write_text(body)


def x_write__mutmut_15(tex: Path, evidence: Path) -> None:
    body = tex.read_text()
    block = START + section(evidence) + END
    if START in body:
        head, rest = body.split(START, 1)
        tail = rest.split(None, 1)[1]
        body = head + block + tail
    else:
        marker = "\\bibliographystyle"
        head, tail = body.split(marker, 1)
        body = head + block + "\n" + marker + tail
    tex.write_text(body)


def x_write__mutmut_16(tex: Path, evidence: Path) -> None:
    body = tex.read_text()
    block = START + section(evidence) + END
    if START in body:
        head, rest = body.split(START, 1)
        tail = rest.split(END, None)[1]
        body = head + block + tail
    else:
        marker = "\\bibliographystyle"
        head, tail = body.split(marker, 1)
        body = head + block + "\n" + marker + tail
    tex.write_text(body)


def x_write__mutmut_17(tex: Path, evidence: Path) -> None:
    body = tex.read_text()
    block = START + section(evidence) + END
    if START in body:
        head, rest = body.split(START, 1)
        tail = rest.split(1)[1]
        body = head + block + tail
    else:
        marker = "\\bibliographystyle"
        head, tail = body.split(marker, 1)
        body = head + block + "\n" + marker + tail
    tex.write_text(body)


def x_write__mutmut_18(tex: Path, evidence: Path) -> None:
    body = tex.read_text()
    block = START + section(evidence) + END
    if START in body:
        head, rest = body.split(START, 1)
        tail = rest.split(END, )[1]
        body = head + block + tail
    else:
        marker = "\\bibliographystyle"
        head, tail = body.split(marker, 1)
        body = head + block + "\n" + marker + tail
    tex.write_text(body)


def x_write__mutmut_19(tex: Path, evidence: Path) -> None:
    body = tex.read_text()
    block = START + section(evidence) + END
    if START in body:
        head, rest = body.split(START, 1)
        tail = rest.rsplit(END, 1)[1]
        body = head + block + tail
    else:
        marker = "\\bibliographystyle"
        head, tail = body.split(marker, 1)
        body = head + block + "\n" + marker + tail
    tex.write_text(body)


def x_write__mutmut_20(tex: Path, evidence: Path) -> None:
    body = tex.read_text()
    block = START + section(evidence) + END
    if START in body:
        head, rest = body.split(START, 1)
        tail = rest.split(END, 2)[1]
        body = head + block + tail
    else:
        marker = "\\bibliographystyle"
        head, tail = body.split(marker, 1)
        body = head + block + "\n" + marker + tail
    tex.write_text(body)


def x_write__mutmut_21(tex: Path, evidence: Path) -> None:
    body = tex.read_text()
    block = START + section(evidence) + END
    if START in body:
        head, rest = body.split(START, 1)
        tail = rest.split(END, 1)[2]
        body = head + block + tail
    else:
        marker = "\\bibliographystyle"
        head, tail = body.split(marker, 1)
        body = head + block + "\n" + marker + tail
    tex.write_text(body)


def x_write__mutmut_22(tex: Path, evidence: Path) -> None:
    body = tex.read_text()
    block = START + section(evidence) + END
    if START in body:
        head, rest = body.split(START, 1)
        tail = rest.split(END, 1)[1]
        body = None
    else:
        marker = "\\bibliographystyle"
        head, tail = body.split(marker, 1)
        body = head + block + "\n" + marker + tail
    tex.write_text(body)


def x_write__mutmut_23(tex: Path, evidence: Path) -> None:
    body = tex.read_text()
    block = START + section(evidence) + END
    if START in body:
        head, rest = body.split(START, 1)
        tail = rest.split(END, 1)[1]
        body = head + block - tail
    else:
        marker = "\\bibliographystyle"
        head, tail = body.split(marker, 1)
        body = head + block + "\n" + marker + tail
    tex.write_text(body)


def x_write__mutmut_24(tex: Path, evidence: Path) -> None:
    body = tex.read_text()
    block = START + section(evidence) + END
    if START in body:
        head, rest = body.split(START, 1)
        tail = rest.split(END, 1)[1]
        body = head - block + tail
    else:
        marker = "\\bibliographystyle"
        head, tail = body.split(marker, 1)
        body = head + block + "\n" + marker + tail
    tex.write_text(body)


def x_write__mutmut_25(tex: Path, evidence: Path) -> None:
    body = tex.read_text()
    block = START + section(evidence) + END
    if START in body:
        head, rest = body.split(START, 1)
        tail = rest.split(END, 1)[1]
        body = head + block + tail
    else:
        marker = None
        head, tail = body.split(marker, 1)
        body = head + block + "\n" + marker + tail
    tex.write_text(body)


def x_write__mutmut_26(tex: Path, evidence: Path) -> None:
    body = tex.read_text()
    block = START + section(evidence) + END
    if START in body:
        head, rest = body.split(START, 1)
        tail = rest.split(END, 1)[1]
        body = head + block + tail
    else:
        marker = "XX\\bibliographystyleXX"
        head, tail = body.split(marker, 1)
        body = head + block + "\n" + marker + tail
    tex.write_text(body)


def x_write__mutmut_27(tex: Path, evidence: Path) -> None:
    body = tex.read_text()
    block = START + section(evidence) + END
    if START in body:
        head, rest = body.split(START, 1)
        tail = rest.split(END, 1)[1]
        body = head + block + tail
    else:
        marker = "\\bIBLIOGRAPHYSTYLE"
        head, tail = body.split(marker, 1)
        body = head + block + "\n" + marker + tail
    tex.write_text(body)


def x_write__mutmut_28(tex: Path, evidence: Path) -> None:
    body = tex.read_text()
    block = START + section(evidence) + END
    if START in body:
        head, rest = body.split(START, 1)
        tail = rest.split(END, 1)[1]
        body = head + block + tail
    else:
        marker = "\\bibliographystyle"
        head, tail = None
        body = head + block + "\n" + marker + tail
    tex.write_text(body)


def x_write__mutmut_29(tex: Path, evidence: Path) -> None:
    body = tex.read_text()
    block = START + section(evidence) + END
    if START in body:
        head, rest = body.split(START, 1)
        tail = rest.split(END, 1)[1]
        body = head + block + tail
    else:
        marker = "\\bibliographystyle"
        head, tail = body.split(None, 1)
        body = head + block + "\n" + marker + tail
    tex.write_text(body)


def x_write__mutmut_30(tex: Path, evidence: Path) -> None:
    body = tex.read_text()
    block = START + section(evidence) + END
    if START in body:
        head, rest = body.split(START, 1)
        tail = rest.split(END, 1)[1]
        body = head + block + tail
    else:
        marker = "\\bibliographystyle"
        head, tail = body.split(marker, None)
        body = head + block + "\n" + marker + tail
    tex.write_text(body)


def x_write__mutmut_31(tex: Path, evidence: Path) -> None:
    body = tex.read_text()
    block = START + section(evidence) + END
    if START in body:
        head, rest = body.split(START, 1)
        tail = rest.split(END, 1)[1]
        body = head + block + tail
    else:
        marker = "\\bibliographystyle"
        head, tail = body.split(1)
        body = head + block + "\n" + marker + tail
    tex.write_text(body)


def x_write__mutmut_32(tex: Path, evidence: Path) -> None:
    body = tex.read_text()
    block = START + section(evidence) + END
    if START in body:
        head, rest = body.split(START, 1)
        tail = rest.split(END, 1)[1]
        body = head + block + tail
    else:
        marker = "\\bibliographystyle"
        head, tail = body.split(marker, )
        body = head + block + "\n" + marker + tail
    tex.write_text(body)


def x_write__mutmut_33(tex: Path, evidence: Path) -> None:
    body = tex.read_text()
    block = START + section(evidence) + END
    if START in body:
        head, rest = body.split(START, 1)
        tail = rest.split(END, 1)[1]
        body = head + block + tail
    else:
        marker = "\\bibliographystyle"
        head, tail = body.rsplit(marker, 1)
        body = head + block + "\n" + marker + tail
    tex.write_text(body)


def x_write__mutmut_34(tex: Path, evidence: Path) -> None:
    body = tex.read_text()
    block = START + section(evidence) + END
    if START in body:
        head, rest = body.split(START, 1)
        tail = rest.split(END, 1)[1]
        body = head + block + tail
    else:
        marker = "\\bibliographystyle"
        head, tail = body.split(marker, 2)
        body = head + block + "\n" + marker + tail
    tex.write_text(body)


def x_write__mutmut_35(tex: Path, evidence: Path) -> None:
    body = tex.read_text()
    block = START + section(evidence) + END
    if START in body:
        head, rest = body.split(START, 1)
        tail = rest.split(END, 1)[1]
        body = head + block + tail
    else:
        marker = "\\bibliographystyle"
        head, tail = body.split(marker, 1)
        body = None
    tex.write_text(body)


def x_write__mutmut_36(tex: Path, evidence: Path) -> None:
    body = tex.read_text()
    block = START + section(evidence) + END
    if START in body:
        head, rest = body.split(START, 1)
        tail = rest.split(END, 1)[1]
        body = head + block + tail
    else:
        marker = "\\bibliographystyle"
        head, tail = body.split(marker, 1)
        body = head + block + "\n" + marker - tail
    tex.write_text(body)


def x_write__mutmut_37(tex: Path, evidence: Path) -> None:
    body = tex.read_text()
    block = START + section(evidence) + END
    if START in body:
        head, rest = body.split(START, 1)
        tail = rest.split(END, 1)[1]
        body = head + block + tail
    else:
        marker = "\\bibliographystyle"
        head, tail = body.split(marker, 1)
        body = head + block + "\n" - marker + tail
    tex.write_text(body)


def x_write__mutmut_38(tex: Path, evidence: Path) -> None:
    body = tex.read_text()
    block = START + section(evidence) + END
    if START in body:
        head, rest = body.split(START, 1)
        tail = rest.split(END, 1)[1]
        body = head + block + tail
    else:
        marker = "\\bibliographystyle"
        head, tail = body.split(marker, 1)
        body = head + block - "\n" + marker + tail
    tex.write_text(body)


def x_write__mutmut_39(tex: Path, evidence: Path) -> None:
    body = tex.read_text()
    block = START + section(evidence) + END
    if START in body:
        head, rest = body.split(START, 1)
        tail = rest.split(END, 1)[1]
        body = head + block + tail
    else:
        marker = "\\bibliographystyle"
        head, tail = body.split(marker, 1)
        body = head - block + "\n" + marker + tail
    tex.write_text(body)


def x_write__mutmut_40(tex: Path, evidence: Path) -> None:
    body = tex.read_text()
    block = START + section(evidence) + END
    if START in body:
        head, rest = body.split(START, 1)
        tail = rest.split(END, 1)[1]
        body = head + block + tail
    else:
        marker = "\\bibliographystyle"
        head, tail = body.split(marker, 1)
        body = head + block + "XX\nXX" + marker + tail
    tex.write_text(body)


def x_write__mutmut_41(tex: Path, evidence: Path) -> None:
    body = tex.read_text()
    block = START + section(evidence) + END
    if START in body:
        head, rest = body.split(START, 1)
        tail = rest.split(END, 1)[1]
        body = head + block + tail
    else:
        marker = "\\bibliographystyle"
        head, tail = body.split(marker, 1)
        body = head + block + "\n" + marker + tail
    tex.write_text(None)

mutants_x_write__mutmut['_mutmut_orig'] = x_write__mutmut_orig # type: ignore # mutmut generated
mutants_x_write__mutmut['x_write__mutmut_1'] = x_write__mutmut_1 # type: ignore # mutmut generated
mutants_x_write__mutmut['x_write__mutmut_2'] = x_write__mutmut_2 # type: ignore # mutmut generated
mutants_x_write__mutmut['x_write__mutmut_3'] = x_write__mutmut_3 # type: ignore # mutmut generated
mutants_x_write__mutmut['x_write__mutmut_4'] = x_write__mutmut_4 # type: ignore # mutmut generated
mutants_x_write__mutmut['x_write__mutmut_5'] = x_write__mutmut_5 # type: ignore # mutmut generated
mutants_x_write__mutmut['x_write__mutmut_6'] = x_write__mutmut_6 # type: ignore # mutmut generated
mutants_x_write__mutmut['x_write__mutmut_7'] = x_write__mutmut_7 # type: ignore # mutmut generated
mutants_x_write__mutmut['x_write__mutmut_8'] = x_write__mutmut_8 # type: ignore # mutmut generated
mutants_x_write__mutmut['x_write__mutmut_9'] = x_write__mutmut_9 # type: ignore # mutmut generated
mutants_x_write__mutmut['x_write__mutmut_10'] = x_write__mutmut_10 # type: ignore # mutmut generated
mutants_x_write__mutmut['x_write__mutmut_11'] = x_write__mutmut_11 # type: ignore # mutmut generated
mutants_x_write__mutmut['x_write__mutmut_12'] = x_write__mutmut_12 # type: ignore # mutmut generated
mutants_x_write__mutmut['x_write__mutmut_13'] = x_write__mutmut_13 # type: ignore # mutmut generated
mutants_x_write__mutmut['x_write__mutmut_14'] = x_write__mutmut_14 # type: ignore # mutmut generated
mutants_x_write__mutmut['x_write__mutmut_15'] = x_write__mutmut_15 # type: ignore # mutmut generated
mutants_x_write__mutmut['x_write__mutmut_16'] = x_write__mutmut_16 # type: ignore # mutmut generated
mutants_x_write__mutmut['x_write__mutmut_17'] = x_write__mutmut_17 # type: ignore # mutmut generated
mutants_x_write__mutmut['x_write__mutmut_18'] = x_write__mutmut_18 # type: ignore # mutmut generated
mutants_x_write__mutmut['x_write__mutmut_19'] = x_write__mutmut_19 # type: ignore # mutmut generated
mutants_x_write__mutmut['x_write__mutmut_20'] = x_write__mutmut_20 # type: ignore # mutmut generated
mutants_x_write__mutmut['x_write__mutmut_21'] = x_write__mutmut_21 # type: ignore # mutmut generated
mutants_x_write__mutmut['x_write__mutmut_22'] = x_write__mutmut_22 # type: ignore # mutmut generated
mutants_x_write__mutmut['x_write__mutmut_23'] = x_write__mutmut_23 # type: ignore # mutmut generated
mutants_x_write__mutmut['x_write__mutmut_24'] = x_write__mutmut_24 # type: ignore # mutmut generated
mutants_x_write__mutmut['x_write__mutmut_25'] = x_write__mutmut_25 # type: ignore # mutmut generated
mutants_x_write__mutmut['x_write__mutmut_26'] = x_write__mutmut_26 # type: ignore # mutmut generated
mutants_x_write__mutmut['x_write__mutmut_27'] = x_write__mutmut_27 # type: ignore # mutmut generated
mutants_x_write__mutmut['x_write__mutmut_28'] = x_write__mutmut_28 # type: ignore # mutmut generated
mutants_x_write__mutmut['x_write__mutmut_29'] = x_write__mutmut_29 # type: ignore # mutmut generated
mutants_x_write__mutmut['x_write__mutmut_30'] = x_write__mutmut_30 # type: ignore # mutmut generated
mutants_x_write__mutmut['x_write__mutmut_31'] = x_write__mutmut_31 # type: ignore # mutmut generated
mutants_x_write__mutmut['x_write__mutmut_32'] = x_write__mutmut_32 # type: ignore # mutmut generated
mutants_x_write__mutmut['x_write__mutmut_33'] = x_write__mutmut_33 # type: ignore # mutmut generated
mutants_x_write__mutmut['x_write__mutmut_34'] = x_write__mutmut_34 # type: ignore # mutmut generated
mutants_x_write__mutmut['x_write__mutmut_35'] = x_write__mutmut_35 # type: ignore # mutmut generated
mutants_x_write__mutmut['x_write__mutmut_36'] = x_write__mutmut_36 # type: ignore # mutmut generated
mutants_x_write__mutmut['x_write__mutmut_37'] = x_write__mutmut_37 # type: ignore # mutmut generated
mutants_x_write__mutmut['x_write__mutmut_38'] = x_write__mutmut_38 # type: ignore # mutmut generated
mutants_x_write__mutmut['x_write__mutmut_39'] = x_write__mutmut_39 # type: ignore # mutmut generated
mutants_x_write__mutmut['x_write__mutmut_40'] = x_write__mutmut_40 # type: ignore # mutmut generated
mutants_x_write__mutmut['x_write__mutmut_41'] = x_write__mutmut_41 # type: ignore # mutmut generated


if __name__ == "__main__":
    write(ROOT / "paper" / "main.tex", ROOT / "verification" / "evidence")
