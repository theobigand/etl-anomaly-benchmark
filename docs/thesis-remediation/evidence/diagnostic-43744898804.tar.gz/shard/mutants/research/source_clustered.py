"""Source-clustered paired comparison of detectors on the labelled pool (T139-T148).

Problems derived from the same original data are not independent: 35 of the 36 ADBench problems
come from a UCI source and 15 of those sources are also labelled UCI problems. This post-hoc
re-analysis of the archived per-seed average precision groups every problem by its original source
(``source_id``), averages the five seeds within a problem, and resamples whole sources with
replacement. The comparisons were chosen from those the manuscript already reports, after the
results were known; they are exploratory and no equivalence is claimed.
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any

import numpy as np

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from dataset_registry import UCI_SOURCES  # noqa: E402

COMPARISONS = (
    ("ecod", "isolation_forest"),
    ("copod", "isolation_forest"),
    ("ocsvm", "isolation_forest"),
    ("dif", "ecod"),
    ("zscore", "isolation_forest"),
    ("great_expectations", "isolation_forest"),
)
BOOTSTRAPS = 10_000
SEED = 2026
LEVEL = 0.95


from mutmut.mutation.trampoline import wrap_in_trampoline as _mutmut_mutated, MutantDict
mutants_x_source_id__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_source_id__mutmut)
def source_id(problem: str) -> str:
    """Original source of a problem: the UCI table when an ADBench file is derived from one."""
    kind, _, name = problem.partition(":")
    if kind == "adbench" and name in UCI_SOURCES:
        return f"uci:{UCI_SOURCES[name][0]}"
    return problem


def x_source_id__mutmut_orig(problem: str) -> str:
    """Original source of a problem: the UCI table when an ADBench file is derived from one."""
    kind, _, name = problem.partition(":")
    if kind == "adbench" and name in UCI_SOURCES:
        return f"uci:{UCI_SOURCES[name][0]}"
    return problem


def x_source_id__mutmut_1(problem: str) -> str:
    """Original source of a problem: the UCI table when an ADBench file is derived from one."""
    kind, _, name = None
    if kind == "adbench" and name in UCI_SOURCES:
        return f"uci:{UCI_SOURCES[name][0]}"
    return problem


def x_source_id__mutmut_2(problem: str) -> str:
    """Original source of a problem: the UCI table when an ADBench file is derived from one."""
    kind, _, name = problem.partition(None)
    if kind == "adbench" and name in UCI_SOURCES:
        return f"uci:{UCI_SOURCES[name][0]}"
    return problem


def x_source_id__mutmut_3(problem: str) -> str:
    """Original source of a problem: the UCI table when an ADBench file is derived from one."""
    kind, _, name = problem.rpartition(":")
    if kind == "adbench" and name in UCI_SOURCES:
        return f"uci:{UCI_SOURCES[name][0]}"
    return problem


def x_source_id__mutmut_4(problem: str) -> str:
    """Original source of a problem: the UCI table when an ADBench file is derived from one."""
    kind, _, name = problem.partition("XX:XX")
    if kind == "adbench" and name in UCI_SOURCES:
        return f"uci:{UCI_SOURCES[name][0]}"
    return problem


def x_source_id__mutmut_5(problem: str) -> str:
    """Original source of a problem: the UCI table when an ADBench file is derived from one."""
    kind, _, name = problem.partition(":")
    if kind == "adbench" or name in UCI_SOURCES:
        return f"uci:{UCI_SOURCES[name][0]}"
    return problem


def x_source_id__mutmut_6(problem: str) -> str:
    """Original source of a problem: the UCI table when an ADBench file is derived from one."""
    kind, _, name = problem.partition(":")
    if kind != "adbench" and name in UCI_SOURCES:
        return f"uci:{UCI_SOURCES[name][0]}"
    return problem


def x_source_id__mutmut_7(problem: str) -> str:
    """Original source of a problem: the UCI table when an ADBench file is derived from one."""
    kind, _, name = problem.partition(":")
    if kind == "XXadbenchXX" and name in UCI_SOURCES:
        return f"uci:{UCI_SOURCES[name][0]}"
    return problem


def x_source_id__mutmut_8(problem: str) -> str:
    """Original source of a problem: the UCI table when an ADBench file is derived from one."""
    kind, _, name = problem.partition(":")
    if kind == "ADBENCH" and name in UCI_SOURCES:
        return f"uci:{UCI_SOURCES[name][0]}"
    return problem


def x_source_id__mutmut_9(problem: str) -> str:
    """Original source of a problem: the UCI table when an ADBench file is derived from one."""
    kind, _, name = problem.partition(":")
    if kind == "adbench" and name not in UCI_SOURCES:
        return f"uci:{UCI_SOURCES[name][0]}"
    return problem


def x_source_id__mutmut_10(problem: str) -> str:
    """Original source of a problem: the UCI table when an ADBench file is derived from one."""
    kind, _, name = problem.partition(":")
    if kind == "adbench" and name in UCI_SOURCES:
        return f"uci:{UCI_SOURCES[name][1]}"
    return problem

mutants_x_source_id__mutmut['_mutmut_orig'] = x_source_id__mutmut_orig # type: ignore # mutmut generated
mutants_x_source_id__mutmut['x_source_id__mutmut_1'] = x_source_id__mutmut_1 # type: ignore # mutmut generated
mutants_x_source_id__mutmut['x_source_id__mutmut_2'] = x_source_id__mutmut_2 # type: ignore # mutmut generated
mutants_x_source_id__mutmut['x_source_id__mutmut_3'] = x_source_id__mutmut_3 # type: ignore # mutmut generated
mutants_x_source_id__mutmut['x_source_id__mutmut_4'] = x_source_id__mutmut_4 # type: ignore # mutmut generated
mutants_x_source_id__mutmut['x_source_id__mutmut_5'] = x_source_id__mutmut_5 # type: ignore # mutmut generated
mutants_x_source_id__mutmut['x_source_id__mutmut_6'] = x_source_id__mutmut_6 # type: ignore # mutmut generated
mutants_x_source_id__mutmut['x_source_id__mutmut_7'] = x_source_id__mutmut_7 # type: ignore # mutmut generated
mutants_x_source_id__mutmut['x_source_id__mutmut_8'] = x_source_id__mutmut_8 # type: ignore # mutmut generated
mutants_x_source_id__mutmut['x_source_id__mutmut_9'] = x_source_id__mutmut_9 # type: ignore # mutmut generated
mutants_x_source_id__mutmut['x_source_id__mutmut_10'] = x_source_id__mutmut_10 # type: ignore # mutmut generated
mutants_x_load_ap__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_load_ap__mutmut)
def load_ap(directories: list[Path]) -> tuple[list[str], dict[str, np.ndarray]]:
    """Per-problem mean average precision of every detector (NaN where it did not run)."""
    records: dict[str, dict[str, float]] = {}
    for directory in directories:
        for path in sorted(directory.glob("*.json")):
            run = json.loads(path.read_text())
            if "failed" in run:
                continue
            row = records.setdefault(run["problem"], {})
            for method, seeds in run["metrics"].items():
                if len(seeds) == len(run["seeds"]):
                    row[method] = float(np.mean([item["pr_auc"] for item in seeds]))
    problems = sorted(records)
    methods = sorted({m for row in records.values() for m in row})
    table = {m: np.array([records[p].get(m, np.nan) for p in problems]) for m in methods}
    return problems, table


def x_load_ap__mutmut_orig(directories: list[Path]) -> tuple[list[str], dict[str, np.ndarray]]:
    """Per-problem mean average precision of every detector (NaN where it did not run)."""
    records: dict[str, dict[str, float]] = {}
    for directory in directories:
        for path in sorted(directory.glob("*.json")):
            run = json.loads(path.read_text())
            if "failed" in run:
                continue
            row = records.setdefault(run["problem"], {})
            for method, seeds in run["metrics"].items():
                if len(seeds) == len(run["seeds"]):
                    row[method] = float(np.mean([item["pr_auc"] for item in seeds]))
    problems = sorted(records)
    methods = sorted({m for row in records.values() for m in row})
    table = {m: np.array([records[p].get(m, np.nan) for p in problems]) for m in methods}
    return problems, table


def x_load_ap__mutmut_1(directories: list[Path]) -> tuple[list[str], dict[str, np.ndarray]]:
    """Per-problem mean average precision of every detector (NaN where it did not run)."""
    records: dict[str, dict[str, float]] = None
    for directory in directories:
        for path in sorted(directory.glob("*.json")):
            run = json.loads(path.read_text())
            if "failed" in run:
                continue
            row = records.setdefault(run["problem"], {})
            for method, seeds in run["metrics"].items():
                if len(seeds) == len(run["seeds"]):
                    row[method] = float(np.mean([item["pr_auc"] for item in seeds]))
    problems = sorted(records)
    methods = sorted({m for row in records.values() for m in row})
    table = {m: np.array([records[p].get(m, np.nan) for p in problems]) for m in methods}
    return problems, table


def x_load_ap__mutmut_2(directories: list[Path]) -> tuple[list[str], dict[str, np.ndarray]]:
    """Per-problem mean average precision of every detector (NaN where it did not run)."""
    records: dict[str, dict[str, float]] = {}
    for directory in directories:
        for path in sorted(None):
            run = json.loads(path.read_text())
            if "failed" in run:
                continue
            row = records.setdefault(run["problem"], {})
            for method, seeds in run["metrics"].items():
                if len(seeds) == len(run["seeds"]):
                    row[method] = float(np.mean([item["pr_auc"] for item in seeds]))
    problems = sorted(records)
    methods = sorted({m for row in records.values() for m in row})
    table = {m: np.array([records[p].get(m, np.nan) for p in problems]) for m in methods}
    return problems, table


def x_load_ap__mutmut_3(directories: list[Path]) -> tuple[list[str], dict[str, np.ndarray]]:
    """Per-problem mean average precision of every detector (NaN where it did not run)."""
    records: dict[str, dict[str, float]] = {}
    for directory in directories:
        for path in sorted(directory.glob(None)):
            run = json.loads(path.read_text())
            if "failed" in run:
                continue
            row = records.setdefault(run["problem"], {})
            for method, seeds in run["metrics"].items():
                if len(seeds) == len(run["seeds"]):
                    row[method] = float(np.mean([item["pr_auc"] for item in seeds]))
    problems = sorted(records)
    methods = sorted({m for row in records.values() for m in row})
    table = {m: np.array([records[p].get(m, np.nan) for p in problems]) for m in methods}
    return problems, table


def x_load_ap__mutmut_4(directories: list[Path]) -> tuple[list[str], dict[str, np.ndarray]]:
    """Per-problem mean average precision of every detector (NaN where it did not run)."""
    records: dict[str, dict[str, float]] = {}
    for directory in directories:
        for path in sorted(directory.glob("XX*.jsonXX")):
            run = json.loads(path.read_text())
            if "failed" in run:
                continue
            row = records.setdefault(run["problem"], {})
            for method, seeds in run["metrics"].items():
                if len(seeds) == len(run["seeds"]):
                    row[method] = float(np.mean([item["pr_auc"] for item in seeds]))
    problems = sorted(records)
    methods = sorted({m for row in records.values() for m in row})
    table = {m: np.array([records[p].get(m, np.nan) for p in problems]) for m in methods}
    return problems, table


def x_load_ap__mutmut_5(directories: list[Path]) -> tuple[list[str], dict[str, np.ndarray]]:
    """Per-problem mean average precision of every detector (NaN where it did not run)."""
    records: dict[str, dict[str, float]] = {}
    for directory in directories:
        for path in sorted(directory.glob("*.JSON")):
            run = json.loads(path.read_text())
            if "failed" in run:
                continue
            row = records.setdefault(run["problem"], {})
            for method, seeds in run["metrics"].items():
                if len(seeds) == len(run["seeds"]):
                    row[method] = float(np.mean([item["pr_auc"] for item in seeds]))
    problems = sorted(records)
    methods = sorted({m for row in records.values() for m in row})
    table = {m: np.array([records[p].get(m, np.nan) for p in problems]) for m in methods}
    return problems, table


def x_load_ap__mutmut_6(directories: list[Path]) -> tuple[list[str], dict[str, np.ndarray]]:
    """Per-problem mean average precision of every detector (NaN where it did not run)."""
    records: dict[str, dict[str, float]] = {}
    for directory in directories:
        for path in sorted(directory.glob("*.json")):
            run = None
            if "failed" in run:
                continue
            row = records.setdefault(run["problem"], {})
            for method, seeds in run["metrics"].items():
                if len(seeds) == len(run["seeds"]):
                    row[method] = float(np.mean([item["pr_auc"] for item in seeds]))
    problems = sorted(records)
    methods = sorted({m for row in records.values() for m in row})
    table = {m: np.array([records[p].get(m, np.nan) for p in problems]) for m in methods}
    return problems, table


def x_load_ap__mutmut_7(directories: list[Path]) -> tuple[list[str], dict[str, np.ndarray]]:
    """Per-problem mean average precision of every detector (NaN where it did not run)."""
    records: dict[str, dict[str, float]] = {}
    for directory in directories:
        for path in sorted(directory.glob("*.json")):
            run = json.loads(None)
            if "failed" in run:
                continue
            row = records.setdefault(run["problem"], {})
            for method, seeds in run["metrics"].items():
                if len(seeds) == len(run["seeds"]):
                    row[method] = float(np.mean([item["pr_auc"] for item in seeds]))
    problems = sorted(records)
    methods = sorted({m for row in records.values() for m in row})
    table = {m: np.array([records[p].get(m, np.nan) for p in problems]) for m in methods}
    return problems, table


def x_load_ap__mutmut_8(directories: list[Path]) -> tuple[list[str], dict[str, np.ndarray]]:
    """Per-problem mean average precision of every detector (NaN where it did not run)."""
    records: dict[str, dict[str, float]] = {}
    for directory in directories:
        for path in sorted(directory.glob("*.json")):
            run = json.loads(path.read_text())
            if "XXfailedXX" in run:
                continue
            row = records.setdefault(run["problem"], {})
            for method, seeds in run["metrics"].items():
                if len(seeds) == len(run["seeds"]):
                    row[method] = float(np.mean([item["pr_auc"] for item in seeds]))
    problems = sorted(records)
    methods = sorted({m for row in records.values() for m in row})
    table = {m: np.array([records[p].get(m, np.nan) for p in problems]) for m in methods}
    return problems, table


def x_load_ap__mutmut_9(directories: list[Path]) -> tuple[list[str], dict[str, np.ndarray]]:
    """Per-problem mean average precision of every detector (NaN where it did not run)."""
    records: dict[str, dict[str, float]] = {}
    for directory in directories:
        for path in sorted(directory.glob("*.json")):
            run = json.loads(path.read_text())
            if "FAILED" in run:
                continue
            row = records.setdefault(run["problem"], {})
            for method, seeds in run["metrics"].items():
                if len(seeds) == len(run["seeds"]):
                    row[method] = float(np.mean([item["pr_auc"] for item in seeds]))
    problems = sorted(records)
    methods = sorted({m for row in records.values() for m in row})
    table = {m: np.array([records[p].get(m, np.nan) for p in problems]) for m in methods}
    return problems, table


def x_load_ap__mutmut_10(directories: list[Path]) -> tuple[list[str], dict[str, np.ndarray]]:
    """Per-problem mean average precision of every detector (NaN where it did not run)."""
    records: dict[str, dict[str, float]] = {}
    for directory in directories:
        for path in sorted(directory.glob("*.json")):
            run = json.loads(path.read_text())
            if "failed" not in run:
                continue
            row = records.setdefault(run["problem"], {})
            for method, seeds in run["metrics"].items():
                if len(seeds) == len(run["seeds"]):
                    row[method] = float(np.mean([item["pr_auc"] for item in seeds]))
    problems = sorted(records)
    methods = sorted({m for row in records.values() for m in row})
    table = {m: np.array([records[p].get(m, np.nan) for p in problems]) for m in methods}
    return problems, table


def x_load_ap__mutmut_11(directories: list[Path]) -> tuple[list[str], dict[str, np.ndarray]]:
    """Per-problem mean average precision of every detector (NaN where it did not run)."""
    records: dict[str, dict[str, float]] = {}
    for directory in directories:
        for path in sorted(directory.glob("*.json")):
            run = json.loads(path.read_text())
            if "failed" in run:
                break
            row = records.setdefault(run["problem"], {})
            for method, seeds in run["metrics"].items():
                if len(seeds) == len(run["seeds"]):
                    row[method] = float(np.mean([item["pr_auc"] for item in seeds]))
    problems = sorted(records)
    methods = sorted({m for row in records.values() for m in row})
    table = {m: np.array([records[p].get(m, np.nan) for p in problems]) for m in methods}
    return problems, table


def x_load_ap__mutmut_12(directories: list[Path]) -> tuple[list[str], dict[str, np.ndarray]]:
    """Per-problem mean average precision of every detector (NaN where it did not run)."""
    records: dict[str, dict[str, float]] = {}
    for directory in directories:
        for path in sorted(directory.glob("*.json")):
            run = json.loads(path.read_text())
            if "failed" in run:
                continue
            row = None
            for method, seeds in run["metrics"].items():
                if len(seeds) == len(run["seeds"]):
                    row[method] = float(np.mean([item["pr_auc"] for item in seeds]))
    problems = sorted(records)
    methods = sorted({m for row in records.values() for m in row})
    table = {m: np.array([records[p].get(m, np.nan) for p in problems]) for m in methods}
    return problems, table


def x_load_ap__mutmut_13(directories: list[Path]) -> tuple[list[str], dict[str, np.ndarray]]:
    """Per-problem mean average precision of every detector (NaN where it did not run)."""
    records: dict[str, dict[str, float]] = {}
    for directory in directories:
        for path in sorted(directory.glob("*.json")):
            run = json.loads(path.read_text())
            if "failed" in run:
                continue
            row = records.setdefault(None, {})
            for method, seeds in run["metrics"].items():
                if len(seeds) == len(run["seeds"]):
                    row[method] = float(np.mean([item["pr_auc"] for item in seeds]))
    problems = sorted(records)
    methods = sorted({m for row in records.values() for m in row})
    table = {m: np.array([records[p].get(m, np.nan) for p in problems]) for m in methods}
    return problems, table


def x_load_ap__mutmut_14(directories: list[Path]) -> tuple[list[str], dict[str, np.ndarray]]:
    """Per-problem mean average precision of every detector (NaN where it did not run)."""
    records: dict[str, dict[str, float]] = {}
    for directory in directories:
        for path in sorted(directory.glob("*.json")):
            run = json.loads(path.read_text())
            if "failed" in run:
                continue
            row = records.setdefault(run["problem"], None)
            for method, seeds in run["metrics"].items():
                if len(seeds) == len(run["seeds"]):
                    row[method] = float(np.mean([item["pr_auc"] for item in seeds]))
    problems = sorted(records)
    methods = sorted({m for row in records.values() for m in row})
    table = {m: np.array([records[p].get(m, np.nan) for p in problems]) for m in methods}
    return problems, table


def x_load_ap__mutmut_15(directories: list[Path]) -> tuple[list[str], dict[str, np.ndarray]]:
    """Per-problem mean average precision of every detector (NaN where it did not run)."""
    records: dict[str, dict[str, float]] = {}
    for directory in directories:
        for path in sorted(directory.glob("*.json")):
            run = json.loads(path.read_text())
            if "failed" in run:
                continue
            row = records.setdefault({})
            for method, seeds in run["metrics"].items():
                if len(seeds) == len(run["seeds"]):
                    row[method] = float(np.mean([item["pr_auc"] for item in seeds]))
    problems = sorted(records)
    methods = sorted({m for row in records.values() for m in row})
    table = {m: np.array([records[p].get(m, np.nan) for p in problems]) for m in methods}
    return problems, table


def x_load_ap__mutmut_16(directories: list[Path]) -> tuple[list[str], dict[str, np.ndarray]]:
    """Per-problem mean average precision of every detector (NaN where it did not run)."""
    records: dict[str, dict[str, float]] = {}
    for directory in directories:
        for path in sorted(directory.glob("*.json")):
            run = json.loads(path.read_text())
            if "failed" in run:
                continue
            row = records.setdefault(run["problem"], )
            for method, seeds in run["metrics"].items():
                if len(seeds) == len(run["seeds"]):
                    row[method] = float(np.mean([item["pr_auc"] for item in seeds]))
    problems = sorted(records)
    methods = sorted({m for row in records.values() for m in row})
    table = {m: np.array([records[p].get(m, np.nan) for p in problems]) for m in methods}
    return problems, table


def x_load_ap__mutmut_17(directories: list[Path]) -> tuple[list[str], dict[str, np.ndarray]]:
    """Per-problem mean average precision of every detector (NaN where it did not run)."""
    records: dict[str, dict[str, float]] = {}
    for directory in directories:
        for path in sorted(directory.glob("*.json")):
            run = json.loads(path.read_text())
            if "failed" in run:
                continue
            row = records.setdefault(run["XXproblemXX"], {})
            for method, seeds in run["metrics"].items():
                if len(seeds) == len(run["seeds"]):
                    row[method] = float(np.mean([item["pr_auc"] for item in seeds]))
    problems = sorted(records)
    methods = sorted({m for row in records.values() for m in row})
    table = {m: np.array([records[p].get(m, np.nan) for p in problems]) for m in methods}
    return problems, table


def x_load_ap__mutmut_18(directories: list[Path]) -> tuple[list[str], dict[str, np.ndarray]]:
    """Per-problem mean average precision of every detector (NaN where it did not run)."""
    records: dict[str, dict[str, float]] = {}
    for directory in directories:
        for path in sorted(directory.glob("*.json")):
            run = json.loads(path.read_text())
            if "failed" in run:
                continue
            row = records.setdefault(run["PROBLEM"], {})
            for method, seeds in run["metrics"].items():
                if len(seeds) == len(run["seeds"]):
                    row[method] = float(np.mean([item["pr_auc"] for item in seeds]))
    problems = sorted(records)
    methods = sorted({m for row in records.values() for m in row})
    table = {m: np.array([records[p].get(m, np.nan) for p in problems]) for m in methods}
    return problems, table


def x_load_ap__mutmut_19(directories: list[Path]) -> tuple[list[str], dict[str, np.ndarray]]:
    """Per-problem mean average precision of every detector (NaN where it did not run)."""
    records: dict[str, dict[str, float]] = {}
    for directory in directories:
        for path in sorted(directory.glob("*.json")):
            run = json.loads(path.read_text())
            if "failed" in run:
                continue
            row = records.setdefault(run["problem"], {})
            for method, seeds in run["XXmetricsXX"].items():
                if len(seeds) == len(run["seeds"]):
                    row[method] = float(np.mean([item["pr_auc"] for item in seeds]))
    problems = sorted(records)
    methods = sorted({m for row in records.values() for m in row})
    table = {m: np.array([records[p].get(m, np.nan) for p in problems]) for m in methods}
    return problems, table


def x_load_ap__mutmut_20(directories: list[Path]) -> tuple[list[str], dict[str, np.ndarray]]:
    """Per-problem mean average precision of every detector (NaN where it did not run)."""
    records: dict[str, dict[str, float]] = {}
    for directory in directories:
        for path in sorted(directory.glob("*.json")):
            run = json.loads(path.read_text())
            if "failed" in run:
                continue
            row = records.setdefault(run["problem"], {})
            for method, seeds in run["METRICS"].items():
                if len(seeds) == len(run["seeds"]):
                    row[method] = float(np.mean([item["pr_auc"] for item in seeds]))
    problems = sorted(records)
    methods = sorted({m for row in records.values() for m in row})
    table = {m: np.array([records[p].get(m, np.nan) for p in problems]) for m in methods}
    return problems, table


def x_load_ap__mutmut_21(directories: list[Path]) -> tuple[list[str], dict[str, np.ndarray]]:
    """Per-problem mean average precision of every detector (NaN where it did not run)."""
    records: dict[str, dict[str, float]] = {}
    for directory in directories:
        for path in sorted(directory.glob("*.json")):
            run = json.loads(path.read_text())
            if "failed" in run:
                continue
            row = records.setdefault(run["problem"], {})
            for method, seeds in run["metrics"].items():
                if len(seeds) != len(run["seeds"]):
                    row[method] = float(np.mean([item["pr_auc"] for item in seeds]))
    problems = sorted(records)
    methods = sorted({m for row in records.values() for m in row})
    table = {m: np.array([records[p].get(m, np.nan) for p in problems]) for m in methods}
    return problems, table


def x_load_ap__mutmut_22(directories: list[Path]) -> tuple[list[str], dict[str, np.ndarray]]:
    """Per-problem mean average precision of every detector (NaN where it did not run)."""
    records: dict[str, dict[str, float]] = {}
    for directory in directories:
        for path in sorted(directory.glob("*.json")):
            run = json.loads(path.read_text())
            if "failed" in run:
                continue
            row = records.setdefault(run["problem"], {})
            for method, seeds in run["metrics"].items():
                if len(seeds) == len(run["seeds"]):
                    row[method] = None
    problems = sorted(records)
    methods = sorted({m for row in records.values() for m in row})
    table = {m: np.array([records[p].get(m, np.nan) for p in problems]) for m in methods}
    return problems, table


def x_load_ap__mutmut_23(directories: list[Path]) -> tuple[list[str], dict[str, np.ndarray]]:
    """Per-problem mean average precision of every detector (NaN where it did not run)."""
    records: dict[str, dict[str, float]] = {}
    for directory in directories:
        for path in sorted(directory.glob("*.json")):
            run = json.loads(path.read_text())
            if "failed" in run:
                continue
            row = records.setdefault(run["problem"], {})
            for method, seeds in run["metrics"].items():
                if len(seeds) == len(run["seeds"]):
                    row[method] = float(None)
    problems = sorted(records)
    methods = sorted({m for row in records.values() for m in row})
    table = {m: np.array([records[p].get(m, np.nan) for p in problems]) for m in methods}
    return problems, table


def x_load_ap__mutmut_24(directories: list[Path]) -> tuple[list[str], dict[str, np.ndarray]]:
    """Per-problem mean average precision of every detector (NaN where it did not run)."""
    records: dict[str, dict[str, float]] = {}
    for directory in directories:
        for path in sorted(directory.glob("*.json")):
            run = json.loads(path.read_text())
            if "failed" in run:
                continue
            row = records.setdefault(run["problem"], {})
            for method, seeds in run["metrics"].items():
                if len(seeds) == len(run["seeds"]):
                    row[method] = float(np.mean(None))
    problems = sorted(records)
    methods = sorted({m for row in records.values() for m in row})
    table = {m: np.array([records[p].get(m, np.nan) for p in problems]) for m in methods}
    return problems, table


def x_load_ap__mutmut_25(directories: list[Path]) -> tuple[list[str], dict[str, np.ndarray]]:
    """Per-problem mean average precision of every detector (NaN where it did not run)."""
    records: dict[str, dict[str, float]] = {}
    for directory in directories:
        for path in sorted(directory.glob("*.json")):
            run = json.loads(path.read_text())
            if "failed" in run:
                continue
            row = records.setdefault(run["problem"], {})
            for method, seeds in run["metrics"].items():
                if len(seeds) == len(run["seeds"]):
                    row[method] = float(np.mean([item["XXpr_aucXX"] for item in seeds]))
    problems = sorted(records)
    methods = sorted({m for row in records.values() for m in row})
    table = {m: np.array([records[p].get(m, np.nan) for p in problems]) for m in methods}
    return problems, table


def x_load_ap__mutmut_26(directories: list[Path]) -> tuple[list[str], dict[str, np.ndarray]]:
    """Per-problem mean average precision of every detector (NaN where it did not run)."""
    records: dict[str, dict[str, float]] = {}
    for directory in directories:
        for path in sorted(directory.glob("*.json")):
            run = json.loads(path.read_text())
            if "failed" in run:
                continue
            row = records.setdefault(run["problem"], {})
            for method, seeds in run["metrics"].items():
                if len(seeds) == len(run["seeds"]):
                    row[method] = float(np.mean([item["PR_AUC"] for item in seeds]))
    problems = sorted(records)
    methods = sorted({m for row in records.values() for m in row})
    table = {m: np.array([records[p].get(m, np.nan) for p in problems]) for m in methods}
    return problems, table


def x_load_ap__mutmut_27(directories: list[Path]) -> tuple[list[str], dict[str, np.ndarray]]:
    """Per-problem mean average precision of every detector (NaN where it did not run)."""
    records: dict[str, dict[str, float]] = {}
    for directory in directories:
        for path in sorted(directory.glob("*.json")):
            run = json.loads(path.read_text())
            if "failed" in run:
                continue
            row = records.setdefault(run["problem"], {})
            for method, seeds in run["metrics"].items():
                if len(seeds) == len(run["seeds"]):
                    row[method] = float(np.mean([item["pr_auc"] for item in seeds]))
    problems = None
    methods = sorted({m for row in records.values() for m in row})
    table = {m: np.array([records[p].get(m, np.nan) for p in problems]) for m in methods}
    return problems, table


def x_load_ap__mutmut_28(directories: list[Path]) -> tuple[list[str], dict[str, np.ndarray]]:
    """Per-problem mean average precision of every detector (NaN where it did not run)."""
    records: dict[str, dict[str, float]] = {}
    for directory in directories:
        for path in sorted(directory.glob("*.json")):
            run = json.loads(path.read_text())
            if "failed" in run:
                continue
            row = records.setdefault(run["problem"], {})
            for method, seeds in run["metrics"].items():
                if len(seeds) == len(run["seeds"]):
                    row[method] = float(np.mean([item["pr_auc"] for item in seeds]))
    problems = sorted(None)
    methods = sorted({m for row in records.values() for m in row})
    table = {m: np.array([records[p].get(m, np.nan) for p in problems]) for m in methods}
    return problems, table


def x_load_ap__mutmut_29(directories: list[Path]) -> tuple[list[str], dict[str, np.ndarray]]:
    """Per-problem mean average precision of every detector (NaN where it did not run)."""
    records: dict[str, dict[str, float]] = {}
    for directory in directories:
        for path in sorted(directory.glob("*.json")):
            run = json.loads(path.read_text())
            if "failed" in run:
                continue
            row = records.setdefault(run["problem"], {})
            for method, seeds in run["metrics"].items():
                if len(seeds) == len(run["seeds"]):
                    row[method] = float(np.mean([item["pr_auc"] for item in seeds]))
    problems = sorted(records)
    methods = None
    table = {m: np.array([records[p].get(m, np.nan) for p in problems]) for m in methods}
    return problems, table


def x_load_ap__mutmut_30(directories: list[Path]) -> tuple[list[str], dict[str, np.ndarray]]:
    """Per-problem mean average precision of every detector (NaN where it did not run)."""
    records: dict[str, dict[str, float]] = {}
    for directory in directories:
        for path in sorted(directory.glob("*.json")):
            run = json.loads(path.read_text())
            if "failed" in run:
                continue
            row = records.setdefault(run["problem"], {})
            for method, seeds in run["metrics"].items():
                if len(seeds) == len(run["seeds"]):
                    row[method] = float(np.mean([item["pr_auc"] for item in seeds]))
    problems = sorted(records)
    methods = sorted(None)
    table = {m: np.array([records[p].get(m, np.nan) for p in problems]) for m in methods}
    return problems, table


def x_load_ap__mutmut_31(directories: list[Path]) -> tuple[list[str], dict[str, np.ndarray]]:
    """Per-problem mean average precision of every detector (NaN where it did not run)."""
    records: dict[str, dict[str, float]] = {}
    for directory in directories:
        for path in sorted(directory.glob("*.json")):
            run = json.loads(path.read_text())
            if "failed" in run:
                continue
            row = records.setdefault(run["problem"], {})
            for method, seeds in run["metrics"].items():
                if len(seeds) == len(run["seeds"]):
                    row[method] = float(np.mean([item["pr_auc"] for item in seeds]))
    problems = sorted(records)
    methods = sorted({m for row in records.values() for m in row})
    table = None
    return problems, table


def x_load_ap__mutmut_32(directories: list[Path]) -> tuple[list[str], dict[str, np.ndarray]]:
    """Per-problem mean average precision of every detector (NaN where it did not run)."""
    records: dict[str, dict[str, float]] = {}
    for directory in directories:
        for path in sorted(directory.glob("*.json")):
            run = json.loads(path.read_text())
            if "failed" in run:
                continue
            row = records.setdefault(run["problem"], {})
            for method, seeds in run["metrics"].items():
                if len(seeds) == len(run["seeds"]):
                    row[method] = float(np.mean([item["pr_auc"] for item in seeds]))
    problems = sorted(records)
    methods = sorted({m for row in records.values() for m in row})
    table = {m: np.array(None) for m in methods}
    return problems, table


def x_load_ap__mutmut_33(directories: list[Path]) -> tuple[list[str], dict[str, np.ndarray]]:
    """Per-problem mean average precision of every detector (NaN where it did not run)."""
    records: dict[str, dict[str, float]] = {}
    for directory in directories:
        for path in sorted(directory.glob("*.json")):
            run = json.loads(path.read_text())
            if "failed" in run:
                continue
            row = records.setdefault(run["problem"], {})
            for method, seeds in run["metrics"].items():
                if len(seeds) == len(run["seeds"]):
                    row[method] = float(np.mean([item["pr_auc"] for item in seeds]))
    problems = sorted(records)
    methods = sorted({m for row in records.values() for m in row})
    table = {m: np.array([records[p].get(None, np.nan) for p in problems]) for m in methods}
    return problems, table


def x_load_ap__mutmut_34(directories: list[Path]) -> tuple[list[str], dict[str, np.ndarray]]:
    """Per-problem mean average precision of every detector (NaN where it did not run)."""
    records: dict[str, dict[str, float]] = {}
    for directory in directories:
        for path in sorted(directory.glob("*.json")):
            run = json.loads(path.read_text())
            if "failed" in run:
                continue
            row = records.setdefault(run["problem"], {})
            for method, seeds in run["metrics"].items():
                if len(seeds) == len(run["seeds"]):
                    row[method] = float(np.mean([item["pr_auc"] for item in seeds]))
    problems = sorted(records)
    methods = sorted({m for row in records.values() for m in row})
    table = {m: np.array([records[p].get(m, None) for p in problems]) for m in methods}
    return problems, table


def x_load_ap__mutmut_35(directories: list[Path]) -> tuple[list[str], dict[str, np.ndarray]]:
    """Per-problem mean average precision of every detector (NaN where it did not run)."""
    records: dict[str, dict[str, float]] = {}
    for directory in directories:
        for path in sorted(directory.glob("*.json")):
            run = json.loads(path.read_text())
            if "failed" in run:
                continue
            row = records.setdefault(run["problem"], {})
            for method, seeds in run["metrics"].items():
                if len(seeds) == len(run["seeds"]):
                    row[method] = float(np.mean([item["pr_auc"] for item in seeds]))
    problems = sorted(records)
    methods = sorted({m for row in records.values() for m in row})
    table = {m: np.array([records[p].get(np.nan) for p in problems]) for m in methods}
    return problems, table


def x_load_ap__mutmut_36(directories: list[Path]) -> tuple[list[str], dict[str, np.ndarray]]:
    """Per-problem mean average precision of every detector (NaN where it did not run)."""
    records: dict[str, dict[str, float]] = {}
    for directory in directories:
        for path in sorted(directory.glob("*.json")):
            run = json.loads(path.read_text())
            if "failed" in run:
                continue
            row = records.setdefault(run["problem"], {})
            for method, seeds in run["metrics"].items():
                if len(seeds) == len(run["seeds"]):
                    row[method] = float(np.mean([item["pr_auc"] for item in seeds]))
    problems = sorted(records)
    methods = sorted({m for row in records.values() for m in row})
    table = {m: np.array([records[p].get(m, ) for p in problems]) for m in methods}
    return problems, table

mutants_x_load_ap__mutmut['_mutmut_orig'] = x_load_ap__mutmut_orig # type: ignore # mutmut generated
mutants_x_load_ap__mutmut['x_load_ap__mutmut_1'] = x_load_ap__mutmut_1 # type: ignore # mutmut generated
mutants_x_load_ap__mutmut['x_load_ap__mutmut_2'] = x_load_ap__mutmut_2 # type: ignore # mutmut generated
mutants_x_load_ap__mutmut['x_load_ap__mutmut_3'] = x_load_ap__mutmut_3 # type: ignore # mutmut generated
mutants_x_load_ap__mutmut['x_load_ap__mutmut_4'] = x_load_ap__mutmut_4 # type: ignore # mutmut generated
mutants_x_load_ap__mutmut['x_load_ap__mutmut_5'] = x_load_ap__mutmut_5 # type: ignore # mutmut generated
mutants_x_load_ap__mutmut['x_load_ap__mutmut_6'] = x_load_ap__mutmut_6 # type: ignore # mutmut generated
mutants_x_load_ap__mutmut['x_load_ap__mutmut_7'] = x_load_ap__mutmut_7 # type: ignore # mutmut generated
mutants_x_load_ap__mutmut['x_load_ap__mutmut_8'] = x_load_ap__mutmut_8 # type: ignore # mutmut generated
mutants_x_load_ap__mutmut['x_load_ap__mutmut_9'] = x_load_ap__mutmut_9 # type: ignore # mutmut generated
mutants_x_load_ap__mutmut['x_load_ap__mutmut_10'] = x_load_ap__mutmut_10 # type: ignore # mutmut generated
mutants_x_load_ap__mutmut['x_load_ap__mutmut_11'] = x_load_ap__mutmut_11 # type: ignore # mutmut generated
mutants_x_load_ap__mutmut['x_load_ap__mutmut_12'] = x_load_ap__mutmut_12 # type: ignore # mutmut generated
mutants_x_load_ap__mutmut['x_load_ap__mutmut_13'] = x_load_ap__mutmut_13 # type: ignore # mutmut generated
mutants_x_load_ap__mutmut['x_load_ap__mutmut_14'] = x_load_ap__mutmut_14 # type: ignore # mutmut generated
mutants_x_load_ap__mutmut['x_load_ap__mutmut_15'] = x_load_ap__mutmut_15 # type: ignore # mutmut generated
mutants_x_load_ap__mutmut['x_load_ap__mutmut_16'] = x_load_ap__mutmut_16 # type: ignore # mutmut generated
mutants_x_load_ap__mutmut['x_load_ap__mutmut_17'] = x_load_ap__mutmut_17 # type: ignore # mutmut generated
mutants_x_load_ap__mutmut['x_load_ap__mutmut_18'] = x_load_ap__mutmut_18 # type: ignore # mutmut generated
mutants_x_load_ap__mutmut['x_load_ap__mutmut_19'] = x_load_ap__mutmut_19 # type: ignore # mutmut generated
mutants_x_load_ap__mutmut['x_load_ap__mutmut_20'] = x_load_ap__mutmut_20 # type: ignore # mutmut generated
mutants_x_load_ap__mutmut['x_load_ap__mutmut_21'] = x_load_ap__mutmut_21 # type: ignore # mutmut generated
mutants_x_load_ap__mutmut['x_load_ap__mutmut_22'] = x_load_ap__mutmut_22 # type: ignore # mutmut generated
mutants_x_load_ap__mutmut['x_load_ap__mutmut_23'] = x_load_ap__mutmut_23 # type: ignore # mutmut generated
mutants_x_load_ap__mutmut['x_load_ap__mutmut_24'] = x_load_ap__mutmut_24 # type: ignore # mutmut generated
mutants_x_load_ap__mutmut['x_load_ap__mutmut_25'] = x_load_ap__mutmut_25 # type: ignore # mutmut generated
mutants_x_load_ap__mutmut['x_load_ap__mutmut_26'] = x_load_ap__mutmut_26 # type: ignore # mutmut generated
mutants_x_load_ap__mutmut['x_load_ap__mutmut_27'] = x_load_ap__mutmut_27 # type: ignore # mutmut generated
mutants_x_load_ap__mutmut['x_load_ap__mutmut_28'] = x_load_ap__mutmut_28 # type: ignore # mutmut generated
mutants_x_load_ap__mutmut['x_load_ap__mutmut_29'] = x_load_ap__mutmut_29 # type: ignore # mutmut generated
mutants_x_load_ap__mutmut['x_load_ap__mutmut_30'] = x_load_ap__mutmut_30 # type: ignore # mutmut generated
mutants_x_load_ap__mutmut['x_load_ap__mutmut_31'] = x_load_ap__mutmut_31 # type: ignore # mutmut generated
mutants_x_load_ap__mutmut['x_load_ap__mutmut_32'] = x_load_ap__mutmut_32 # type: ignore # mutmut generated
mutants_x_load_ap__mutmut['x_load_ap__mutmut_33'] = x_load_ap__mutmut_33 # type: ignore # mutmut generated
mutants_x_load_ap__mutmut['x_load_ap__mutmut_34'] = x_load_ap__mutmut_34 # type: ignore # mutmut generated
mutants_x_load_ap__mutmut['x_load_ap__mutmut_35'] = x_load_ap__mutmut_35 # type: ignore # mutmut generated
mutants_x_load_ap__mutmut['x_load_ap__mutmut_36'] = x_load_ap__mutmut_36 # type: ignore # mutmut generated
mutants_x__interval__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x__interval__mutmut)
def _interval(values: np.ndarray) -> tuple[float, float]:
    tail = (1 - LEVEL) / 2
    low, high = np.quantile(values, [tail, 1 - tail])
    return float(low), float(high)


def x__interval__mutmut_orig(values: np.ndarray) -> tuple[float, float]:
    tail = (1 - LEVEL) / 2
    low, high = np.quantile(values, [tail, 1 - tail])
    return float(low), float(high)


def x__interval__mutmut_1(values: np.ndarray) -> tuple[float, float]:
    tail = None
    low, high = np.quantile(values, [tail, 1 - tail])
    return float(low), float(high)


def x__interval__mutmut_2(values: np.ndarray) -> tuple[float, float]:
    tail = (1 - LEVEL) * 2
    low, high = np.quantile(values, [tail, 1 - tail])
    return float(low), float(high)


def x__interval__mutmut_3(values: np.ndarray) -> tuple[float, float]:
    tail = (1 + LEVEL) / 2
    low, high = np.quantile(values, [tail, 1 - tail])
    return float(low), float(high)


def x__interval__mutmut_4(values: np.ndarray) -> tuple[float, float]:
    tail = (2 - LEVEL) / 2
    low, high = np.quantile(values, [tail, 1 - tail])
    return float(low), float(high)


def x__interval__mutmut_5(values: np.ndarray) -> tuple[float, float]:
    tail = (1 - LEVEL) / 3
    low, high = np.quantile(values, [tail, 1 - tail])
    return float(low), float(high)


def x__interval__mutmut_6(values: np.ndarray) -> tuple[float, float]:
    tail = (1 - LEVEL) / 2
    low, high = None
    return float(low), float(high)


def x__interval__mutmut_7(values: np.ndarray) -> tuple[float, float]:
    tail = (1 - LEVEL) / 2
    low, high = np.quantile(None, [tail, 1 - tail])
    return float(low), float(high)


def x__interval__mutmut_8(values: np.ndarray) -> tuple[float, float]:
    tail = (1 - LEVEL) / 2
    low, high = np.quantile(values, None)
    return float(low), float(high)


def x__interval__mutmut_9(values: np.ndarray) -> tuple[float, float]:
    tail = (1 - LEVEL) / 2
    low, high = np.quantile([tail, 1 - tail])
    return float(low), float(high)


def x__interval__mutmut_10(values: np.ndarray) -> tuple[float, float]:
    tail = (1 - LEVEL) / 2
    low, high = np.quantile(values, )
    return float(low), float(high)


def x__interval__mutmut_11(values: np.ndarray) -> tuple[float, float]:
    tail = (1 - LEVEL) / 2
    low, high = np.quantile(values, [tail, 1 + tail])
    return float(low), float(high)


def x__interval__mutmut_12(values: np.ndarray) -> tuple[float, float]:
    tail = (1 - LEVEL) / 2
    low, high = np.quantile(values, [tail, 2 - tail])
    return float(low), float(high)


def x__interval__mutmut_13(values: np.ndarray) -> tuple[float, float]:
    tail = (1 - LEVEL) / 2
    low, high = np.quantile(values, [tail, 1 - tail])
    return float(None), float(high)


def x__interval__mutmut_14(values: np.ndarray) -> tuple[float, float]:
    tail = (1 - LEVEL) / 2
    low, high = np.quantile(values, [tail, 1 - tail])
    return float(low), float(None)

mutants_x__interval__mutmut['_mutmut_orig'] = x__interval__mutmut_orig # type: ignore # mutmut generated
mutants_x__interval__mutmut['x__interval__mutmut_1'] = x__interval__mutmut_1 # type: ignore # mutmut generated
mutants_x__interval__mutmut['x__interval__mutmut_2'] = x__interval__mutmut_2 # type: ignore # mutmut generated
mutants_x__interval__mutmut['x__interval__mutmut_3'] = x__interval__mutmut_3 # type: ignore # mutmut generated
mutants_x__interval__mutmut['x__interval__mutmut_4'] = x__interval__mutmut_4 # type: ignore # mutmut generated
mutants_x__interval__mutmut['x__interval__mutmut_5'] = x__interval__mutmut_5 # type: ignore # mutmut generated
mutants_x__interval__mutmut['x__interval__mutmut_6'] = x__interval__mutmut_6 # type: ignore # mutmut generated
mutants_x__interval__mutmut['x__interval__mutmut_7'] = x__interval__mutmut_7 # type: ignore # mutmut generated
mutants_x__interval__mutmut['x__interval__mutmut_8'] = x__interval__mutmut_8 # type: ignore # mutmut generated
mutants_x__interval__mutmut['x__interval__mutmut_9'] = x__interval__mutmut_9 # type: ignore # mutmut generated
mutants_x__interval__mutmut['x__interval__mutmut_10'] = x__interval__mutmut_10 # type: ignore # mutmut generated
mutants_x__interval__mutmut['x__interval__mutmut_11'] = x__interval__mutmut_11 # type: ignore # mutmut generated
mutants_x__interval__mutmut['x__interval__mutmut_12'] = x__interval__mutmut_12 # type: ignore # mutmut generated
mutants_x__interval__mutmut['x__interval__mutmut_13'] = x__interval__mutmut_13 # type: ignore # mutmut generated
mutants_x__interval__mutmut['x__interval__mutmut_14'] = x__interval__mutmut_14 # type: ignore # mutmut generated
mutants_x_bootstrap__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_bootstrap__mutmut)
def bootstrap(
    differences: np.ndarray, clusters: np.ndarray, *, by_cluster: bool, seed: int = SEED,
    draws: int = BOOTSTRAPS,
) -> dict[str, Any]:  # fmt: skip
    """Mean and median difference with percentile intervals and a two-sided bootstrap p-value."""
    rng = np.random.default_rng(seed)
    n = len(differences)
    labels = np.unique(clusters)
    members = [np.flatnonzero(clusters == label) for label in labels]
    means, medians = np.empty(draws), np.empty(draws)
    for index in range(draws):
        if by_cluster:
            picked = np.concatenate([members[i] for i in rng.integers(0, len(labels), len(labels))])
        else:
            picked = rng.integers(0, n, n)
        sample = differences[picked]
        means[index], medians[index] = sample.mean(), np.median(sample)
    below, above = float((means <= 0).mean()), float((means >= 0).mean())
    return {
        "units": int(len(labels) if by_cluster else n),
        "mean": float(differences.mean()),
        "mean_ci": _interval(means),
        "median": float(np.median(differences)),
        "median_ci": _interval(medians),
        "p_two_sided": float(min(1.0, 2 * min(below, above))),
    }


def x_bootstrap__mutmut_orig(
    differences: np.ndarray, clusters: np.ndarray, *, by_cluster: bool, seed: int = SEED,
    draws: int = BOOTSTRAPS,
) -> dict[str, Any]:  # fmt: skip
    """Mean and median difference with percentile intervals and a two-sided bootstrap p-value."""
    rng = np.random.default_rng(seed)
    n = len(differences)
    labels = np.unique(clusters)
    members = [np.flatnonzero(clusters == label) for label in labels]
    means, medians = np.empty(draws), np.empty(draws)
    for index in range(draws):
        if by_cluster:
            picked = np.concatenate([members[i] for i in rng.integers(0, len(labels), len(labels))])
        else:
            picked = rng.integers(0, n, n)
        sample = differences[picked]
        means[index], medians[index] = sample.mean(), np.median(sample)
    below, above = float((means <= 0).mean()), float((means >= 0).mean())
    return {
        "units": int(len(labels) if by_cluster else n),
        "mean": float(differences.mean()),
        "mean_ci": _interval(means),
        "median": float(np.median(differences)),
        "median_ci": _interval(medians),
        "p_two_sided": float(min(1.0, 2 * min(below, above))),
    }


def x_bootstrap__mutmut_1(
    differences: np.ndarray, clusters: np.ndarray, *, by_cluster: bool, seed: int = SEED,
    draws: int = BOOTSTRAPS,
) -> dict[str, Any]:  # fmt: skip
    """Mean and median difference with percentile intervals and a two-sided bootstrap p-value."""
    rng = None
    n = len(differences)
    labels = np.unique(clusters)
    members = [np.flatnonzero(clusters == label) for label in labels]
    means, medians = np.empty(draws), np.empty(draws)
    for index in range(draws):
        if by_cluster:
            picked = np.concatenate([members[i] for i in rng.integers(0, len(labels), len(labels))])
        else:
            picked = rng.integers(0, n, n)
        sample = differences[picked]
        means[index], medians[index] = sample.mean(), np.median(sample)
    below, above = float((means <= 0).mean()), float((means >= 0).mean())
    return {
        "units": int(len(labels) if by_cluster else n),
        "mean": float(differences.mean()),
        "mean_ci": _interval(means),
        "median": float(np.median(differences)),
        "median_ci": _interval(medians),
        "p_two_sided": float(min(1.0, 2 * min(below, above))),
    }


def x_bootstrap__mutmut_2(
    differences: np.ndarray, clusters: np.ndarray, *, by_cluster: bool, seed: int = SEED,
    draws: int = BOOTSTRAPS,
) -> dict[str, Any]:  # fmt: skip
    """Mean and median difference with percentile intervals and a two-sided bootstrap p-value."""
    rng = np.random.default_rng(None)
    n = len(differences)
    labels = np.unique(clusters)
    members = [np.flatnonzero(clusters == label) for label in labels]
    means, medians = np.empty(draws), np.empty(draws)
    for index in range(draws):
        if by_cluster:
            picked = np.concatenate([members[i] for i in rng.integers(0, len(labels), len(labels))])
        else:
            picked = rng.integers(0, n, n)
        sample = differences[picked]
        means[index], medians[index] = sample.mean(), np.median(sample)
    below, above = float((means <= 0).mean()), float((means >= 0).mean())
    return {
        "units": int(len(labels) if by_cluster else n),
        "mean": float(differences.mean()),
        "mean_ci": _interval(means),
        "median": float(np.median(differences)),
        "median_ci": _interval(medians),
        "p_two_sided": float(min(1.0, 2 * min(below, above))),
    }


def x_bootstrap__mutmut_3(
    differences: np.ndarray, clusters: np.ndarray, *, by_cluster: bool, seed: int = SEED,
    draws: int = BOOTSTRAPS,
) -> dict[str, Any]:  # fmt: skip
    """Mean and median difference with percentile intervals and a two-sided bootstrap p-value."""
    rng = np.random.default_rng(seed)
    n = None
    labels = np.unique(clusters)
    members = [np.flatnonzero(clusters == label) for label in labels]
    means, medians = np.empty(draws), np.empty(draws)
    for index in range(draws):
        if by_cluster:
            picked = np.concatenate([members[i] for i in rng.integers(0, len(labels), len(labels))])
        else:
            picked = rng.integers(0, n, n)
        sample = differences[picked]
        means[index], medians[index] = sample.mean(), np.median(sample)
    below, above = float((means <= 0).mean()), float((means >= 0).mean())
    return {
        "units": int(len(labels) if by_cluster else n),
        "mean": float(differences.mean()),
        "mean_ci": _interval(means),
        "median": float(np.median(differences)),
        "median_ci": _interval(medians),
        "p_two_sided": float(min(1.0, 2 * min(below, above))),
    }


def x_bootstrap__mutmut_4(
    differences: np.ndarray, clusters: np.ndarray, *, by_cluster: bool, seed: int = SEED,
    draws: int = BOOTSTRAPS,
) -> dict[str, Any]:  # fmt: skip
    """Mean and median difference with percentile intervals and a two-sided bootstrap p-value."""
    rng = np.random.default_rng(seed)
    n = len(differences)
    labels = None
    members = [np.flatnonzero(clusters == label) for label in labels]
    means, medians = np.empty(draws), np.empty(draws)
    for index in range(draws):
        if by_cluster:
            picked = np.concatenate([members[i] for i in rng.integers(0, len(labels), len(labels))])
        else:
            picked = rng.integers(0, n, n)
        sample = differences[picked]
        means[index], medians[index] = sample.mean(), np.median(sample)
    below, above = float((means <= 0).mean()), float((means >= 0).mean())
    return {
        "units": int(len(labels) if by_cluster else n),
        "mean": float(differences.mean()),
        "mean_ci": _interval(means),
        "median": float(np.median(differences)),
        "median_ci": _interval(medians),
        "p_two_sided": float(min(1.0, 2 * min(below, above))),
    }


def x_bootstrap__mutmut_5(
    differences: np.ndarray, clusters: np.ndarray, *, by_cluster: bool, seed: int = SEED,
    draws: int = BOOTSTRAPS,
) -> dict[str, Any]:  # fmt: skip
    """Mean and median difference with percentile intervals and a two-sided bootstrap p-value."""
    rng = np.random.default_rng(seed)
    n = len(differences)
    labels = np.unique(None)
    members = [np.flatnonzero(clusters == label) for label in labels]
    means, medians = np.empty(draws), np.empty(draws)
    for index in range(draws):
        if by_cluster:
            picked = np.concatenate([members[i] for i in rng.integers(0, len(labels), len(labels))])
        else:
            picked = rng.integers(0, n, n)
        sample = differences[picked]
        means[index], medians[index] = sample.mean(), np.median(sample)
    below, above = float((means <= 0).mean()), float((means >= 0).mean())
    return {
        "units": int(len(labels) if by_cluster else n),
        "mean": float(differences.mean()),
        "mean_ci": _interval(means),
        "median": float(np.median(differences)),
        "median_ci": _interval(medians),
        "p_two_sided": float(min(1.0, 2 * min(below, above))),
    }


def x_bootstrap__mutmut_6(
    differences: np.ndarray, clusters: np.ndarray, *, by_cluster: bool, seed: int = SEED,
    draws: int = BOOTSTRAPS,
) -> dict[str, Any]:  # fmt: skip
    """Mean and median difference with percentile intervals and a two-sided bootstrap p-value."""
    rng = np.random.default_rng(seed)
    n = len(differences)
    labels = np.unique(clusters)
    members = None
    means, medians = np.empty(draws), np.empty(draws)
    for index in range(draws):
        if by_cluster:
            picked = np.concatenate([members[i] for i in rng.integers(0, len(labels), len(labels))])
        else:
            picked = rng.integers(0, n, n)
        sample = differences[picked]
        means[index], medians[index] = sample.mean(), np.median(sample)
    below, above = float((means <= 0).mean()), float((means >= 0).mean())
    return {
        "units": int(len(labels) if by_cluster else n),
        "mean": float(differences.mean()),
        "mean_ci": _interval(means),
        "median": float(np.median(differences)),
        "median_ci": _interval(medians),
        "p_two_sided": float(min(1.0, 2 * min(below, above))),
    }


def x_bootstrap__mutmut_7(
    differences: np.ndarray, clusters: np.ndarray, *, by_cluster: bool, seed: int = SEED,
    draws: int = BOOTSTRAPS,
) -> dict[str, Any]:  # fmt: skip
    """Mean and median difference with percentile intervals and a two-sided bootstrap p-value."""
    rng = np.random.default_rng(seed)
    n = len(differences)
    labels = np.unique(clusters)
    members = [np.flatnonzero(None) for label in labels]
    means, medians = np.empty(draws), np.empty(draws)
    for index in range(draws):
        if by_cluster:
            picked = np.concatenate([members[i] for i in rng.integers(0, len(labels), len(labels))])
        else:
            picked = rng.integers(0, n, n)
        sample = differences[picked]
        means[index], medians[index] = sample.mean(), np.median(sample)
    below, above = float((means <= 0).mean()), float((means >= 0).mean())
    return {
        "units": int(len(labels) if by_cluster else n),
        "mean": float(differences.mean()),
        "mean_ci": _interval(means),
        "median": float(np.median(differences)),
        "median_ci": _interval(medians),
        "p_two_sided": float(min(1.0, 2 * min(below, above))),
    }


def x_bootstrap__mutmut_8(
    differences: np.ndarray, clusters: np.ndarray, *, by_cluster: bool, seed: int = SEED,
    draws: int = BOOTSTRAPS,
) -> dict[str, Any]:  # fmt: skip
    """Mean and median difference with percentile intervals and a two-sided bootstrap p-value."""
    rng = np.random.default_rng(seed)
    n = len(differences)
    labels = np.unique(clusters)
    members = [np.flatnonzero(clusters != label) for label in labels]
    means, medians = np.empty(draws), np.empty(draws)
    for index in range(draws):
        if by_cluster:
            picked = np.concatenate([members[i] for i in rng.integers(0, len(labels), len(labels))])
        else:
            picked = rng.integers(0, n, n)
        sample = differences[picked]
        means[index], medians[index] = sample.mean(), np.median(sample)
    below, above = float((means <= 0).mean()), float((means >= 0).mean())
    return {
        "units": int(len(labels) if by_cluster else n),
        "mean": float(differences.mean()),
        "mean_ci": _interval(means),
        "median": float(np.median(differences)),
        "median_ci": _interval(medians),
        "p_two_sided": float(min(1.0, 2 * min(below, above))),
    }


def x_bootstrap__mutmut_9(
    differences: np.ndarray, clusters: np.ndarray, *, by_cluster: bool, seed: int = SEED,
    draws: int = BOOTSTRAPS,
) -> dict[str, Any]:  # fmt: skip
    """Mean and median difference with percentile intervals and a two-sided bootstrap p-value."""
    rng = np.random.default_rng(seed)
    n = len(differences)
    labels = np.unique(clusters)
    members = [np.flatnonzero(clusters == label) for label in labels]
    means, medians = None
    for index in range(draws):
        if by_cluster:
            picked = np.concatenate([members[i] for i in rng.integers(0, len(labels), len(labels))])
        else:
            picked = rng.integers(0, n, n)
        sample = differences[picked]
        means[index], medians[index] = sample.mean(), np.median(sample)
    below, above = float((means <= 0).mean()), float((means >= 0).mean())
    return {
        "units": int(len(labels) if by_cluster else n),
        "mean": float(differences.mean()),
        "mean_ci": _interval(means),
        "median": float(np.median(differences)),
        "median_ci": _interval(medians),
        "p_two_sided": float(min(1.0, 2 * min(below, above))),
    }


def x_bootstrap__mutmut_10(
    differences: np.ndarray, clusters: np.ndarray, *, by_cluster: bool, seed: int = SEED,
    draws: int = BOOTSTRAPS,
) -> dict[str, Any]:  # fmt: skip
    """Mean and median difference with percentile intervals and a two-sided bootstrap p-value."""
    rng = np.random.default_rng(seed)
    n = len(differences)
    labels = np.unique(clusters)
    members = [np.flatnonzero(clusters == label) for label in labels]
    means, medians = np.empty(None), np.empty(draws)
    for index in range(draws):
        if by_cluster:
            picked = np.concatenate([members[i] for i in rng.integers(0, len(labels), len(labels))])
        else:
            picked = rng.integers(0, n, n)
        sample = differences[picked]
        means[index], medians[index] = sample.mean(), np.median(sample)
    below, above = float((means <= 0).mean()), float((means >= 0).mean())
    return {
        "units": int(len(labels) if by_cluster else n),
        "mean": float(differences.mean()),
        "mean_ci": _interval(means),
        "median": float(np.median(differences)),
        "median_ci": _interval(medians),
        "p_two_sided": float(min(1.0, 2 * min(below, above))),
    }


def x_bootstrap__mutmut_11(
    differences: np.ndarray, clusters: np.ndarray, *, by_cluster: bool, seed: int = SEED,
    draws: int = BOOTSTRAPS,
) -> dict[str, Any]:  # fmt: skip
    """Mean and median difference with percentile intervals and a two-sided bootstrap p-value."""
    rng = np.random.default_rng(seed)
    n = len(differences)
    labels = np.unique(clusters)
    members = [np.flatnonzero(clusters == label) for label in labels]
    means, medians = np.empty(draws), np.empty(None)
    for index in range(draws):
        if by_cluster:
            picked = np.concatenate([members[i] for i in rng.integers(0, len(labels), len(labels))])
        else:
            picked = rng.integers(0, n, n)
        sample = differences[picked]
        means[index], medians[index] = sample.mean(), np.median(sample)
    below, above = float((means <= 0).mean()), float((means >= 0).mean())
    return {
        "units": int(len(labels) if by_cluster else n),
        "mean": float(differences.mean()),
        "mean_ci": _interval(means),
        "median": float(np.median(differences)),
        "median_ci": _interval(medians),
        "p_two_sided": float(min(1.0, 2 * min(below, above))),
    }


def x_bootstrap__mutmut_12(
    differences: np.ndarray, clusters: np.ndarray, *, by_cluster: bool, seed: int = SEED,
    draws: int = BOOTSTRAPS,
) -> dict[str, Any]:  # fmt: skip
    """Mean and median difference with percentile intervals and a two-sided bootstrap p-value."""
    rng = np.random.default_rng(seed)
    n = len(differences)
    labels = np.unique(clusters)
    members = [np.flatnonzero(clusters == label) for label in labels]
    means, medians = np.empty(draws), np.empty(draws)
    for index in range(None):
        if by_cluster:
            picked = np.concatenate([members[i] for i in rng.integers(0, len(labels), len(labels))])
        else:
            picked = rng.integers(0, n, n)
        sample = differences[picked]
        means[index], medians[index] = sample.mean(), np.median(sample)
    below, above = float((means <= 0).mean()), float((means >= 0).mean())
    return {
        "units": int(len(labels) if by_cluster else n),
        "mean": float(differences.mean()),
        "mean_ci": _interval(means),
        "median": float(np.median(differences)),
        "median_ci": _interval(medians),
        "p_two_sided": float(min(1.0, 2 * min(below, above))),
    }


def x_bootstrap__mutmut_13(
    differences: np.ndarray, clusters: np.ndarray, *, by_cluster: bool, seed: int = SEED,
    draws: int = BOOTSTRAPS,
) -> dict[str, Any]:  # fmt: skip
    """Mean and median difference with percentile intervals and a two-sided bootstrap p-value."""
    rng = np.random.default_rng(seed)
    n = len(differences)
    labels = np.unique(clusters)
    members = [np.flatnonzero(clusters == label) for label in labels]
    means, medians = np.empty(draws), np.empty(draws)
    for index in range(draws):
        if by_cluster:
            picked = None
        else:
            picked = rng.integers(0, n, n)
        sample = differences[picked]
        means[index], medians[index] = sample.mean(), np.median(sample)
    below, above = float((means <= 0).mean()), float((means >= 0).mean())
    return {
        "units": int(len(labels) if by_cluster else n),
        "mean": float(differences.mean()),
        "mean_ci": _interval(means),
        "median": float(np.median(differences)),
        "median_ci": _interval(medians),
        "p_two_sided": float(min(1.0, 2 * min(below, above))),
    }


def x_bootstrap__mutmut_14(
    differences: np.ndarray, clusters: np.ndarray, *, by_cluster: bool, seed: int = SEED,
    draws: int = BOOTSTRAPS,
) -> dict[str, Any]:  # fmt: skip
    """Mean and median difference with percentile intervals and a two-sided bootstrap p-value."""
    rng = np.random.default_rng(seed)
    n = len(differences)
    labels = np.unique(clusters)
    members = [np.flatnonzero(clusters == label) for label in labels]
    means, medians = np.empty(draws), np.empty(draws)
    for index in range(draws):
        if by_cluster:
            picked = np.concatenate(None)
        else:
            picked = rng.integers(0, n, n)
        sample = differences[picked]
        means[index], medians[index] = sample.mean(), np.median(sample)
    below, above = float((means <= 0).mean()), float((means >= 0).mean())
    return {
        "units": int(len(labels) if by_cluster else n),
        "mean": float(differences.mean()),
        "mean_ci": _interval(means),
        "median": float(np.median(differences)),
        "median_ci": _interval(medians),
        "p_two_sided": float(min(1.0, 2 * min(below, above))),
    }


def x_bootstrap__mutmut_15(
    differences: np.ndarray, clusters: np.ndarray, *, by_cluster: bool, seed: int = SEED,
    draws: int = BOOTSTRAPS,
) -> dict[str, Any]:  # fmt: skip
    """Mean and median difference with percentile intervals and a two-sided bootstrap p-value."""
    rng = np.random.default_rng(seed)
    n = len(differences)
    labels = np.unique(clusters)
    members = [np.flatnonzero(clusters == label) for label in labels]
    means, medians = np.empty(draws), np.empty(draws)
    for index in range(draws):
        if by_cluster:
            picked = np.concatenate([members[i] for i in rng.integers(None, len(labels), len(labels))])
        else:
            picked = rng.integers(0, n, n)
        sample = differences[picked]
        means[index], medians[index] = sample.mean(), np.median(sample)
    below, above = float((means <= 0).mean()), float((means >= 0).mean())
    return {
        "units": int(len(labels) if by_cluster else n),
        "mean": float(differences.mean()),
        "mean_ci": _interval(means),
        "median": float(np.median(differences)),
        "median_ci": _interval(medians),
        "p_two_sided": float(min(1.0, 2 * min(below, above))),
    }


def x_bootstrap__mutmut_16(
    differences: np.ndarray, clusters: np.ndarray, *, by_cluster: bool, seed: int = SEED,
    draws: int = BOOTSTRAPS,
) -> dict[str, Any]:  # fmt: skip
    """Mean and median difference with percentile intervals and a two-sided bootstrap p-value."""
    rng = np.random.default_rng(seed)
    n = len(differences)
    labels = np.unique(clusters)
    members = [np.flatnonzero(clusters == label) for label in labels]
    means, medians = np.empty(draws), np.empty(draws)
    for index in range(draws):
        if by_cluster:
            picked = np.concatenate([members[i] for i in rng.integers(0, None, len(labels))])
        else:
            picked = rng.integers(0, n, n)
        sample = differences[picked]
        means[index], medians[index] = sample.mean(), np.median(sample)
    below, above = float((means <= 0).mean()), float((means >= 0).mean())
    return {
        "units": int(len(labels) if by_cluster else n),
        "mean": float(differences.mean()),
        "mean_ci": _interval(means),
        "median": float(np.median(differences)),
        "median_ci": _interval(medians),
        "p_two_sided": float(min(1.0, 2 * min(below, above))),
    }


def x_bootstrap__mutmut_17(
    differences: np.ndarray, clusters: np.ndarray, *, by_cluster: bool, seed: int = SEED,
    draws: int = BOOTSTRAPS,
) -> dict[str, Any]:  # fmt: skip
    """Mean and median difference with percentile intervals and a two-sided bootstrap p-value."""
    rng = np.random.default_rng(seed)
    n = len(differences)
    labels = np.unique(clusters)
    members = [np.flatnonzero(clusters == label) for label in labels]
    means, medians = np.empty(draws), np.empty(draws)
    for index in range(draws):
        if by_cluster:
            picked = np.concatenate([members[i] for i in rng.integers(0, len(labels), None)])
        else:
            picked = rng.integers(0, n, n)
        sample = differences[picked]
        means[index], medians[index] = sample.mean(), np.median(sample)
    below, above = float((means <= 0).mean()), float((means >= 0).mean())
    return {
        "units": int(len(labels) if by_cluster else n),
        "mean": float(differences.mean()),
        "mean_ci": _interval(means),
        "median": float(np.median(differences)),
        "median_ci": _interval(medians),
        "p_two_sided": float(min(1.0, 2 * min(below, above))),
    }


def x_bootstrap__mutmut_18(
    differences: np.ndarray, clusters: np.ndarray, *, by_cluster: bool, seed: int = SEED,
    draws: int = BOOTSTRAPS,
) -> dict[str, Any]:  # fmt: skip
    """Mean and median difference with percentile intervals and a two-sided bootstrap p-value."""
    rng = np.random.default_rng(seed)
    n = len(differences)
    labels = np.unique(clusters)
    members = [np.flatnonzero(clusters == label) for label in labels]
    means, medians = np.empty(draws), np.empty(draws)
    for index in range(draws):
        if by_cluster:
            picked = np.concatenate([members[i] for i in rng.integers(len(labels), len(labels))])
        else:
            picked = rng.integers(0, n, n)
        sample = differences[picked]
        means[index], medians[index] = sample.mean(), np.median(sample)
    below, above = float((means <= 0).mean()), float((means >= 0).mean())
    return {
        "units": int(len(labels) if by_cluster else n),
        "mean": float(differences.mean()),
        "mean_ci": _interval(means),
        "median": float(np.median(differences)),
        "median_ci": _interval(medians),
        "p_two_sided": float(min(1.0, 2 * min(below, above))),
    }


def x_bootstrap__mutmut_19(
    differences: np.ndarray, clusters: np.ndarray, *, by_cluster: bool, seed: int = SEED,
    draws: int = BOOTSTRAPS,
) -> dict[str, Any]:  # fmt: skip
    """Mean and median difference with percentile intervals and a two-sided bootstrap p-value."""
    rng = np.random.default_rng(seed)
    n = len(differences)
    labels = np.unique(clusters)
    members = [np.flatnonzero(clusters == label) for label in labels]
    means, medians = np.empty(draws), np.empty(draws)
    for index in range(draws):
        if by_cluster:
            picked = np.concatenate([members[i] for i in rng.integers(0, len(labels))])
        else:
            picked = rng.integers(0, n, n)
        sample = differences[picked]
        means[index], medians[index] = sample.mean(), np.median(sample)
    below, above = float((means <= 0).mean()), float((means >= 0).mean())
    return {
        "units": int(len(labels) if by_cluster else n),
        "mean": float(differences.mean()),
        "mean_ci": _interval(means),
        "median": float(np.median(differences)),
        "median_ci": _interval(medians),
        "p_two_sided": float(min(1.0, 2 * min(below, above))),
    }


def x_bootstrap__mutmut_20(
    differences: np.ndarray, clusters: np.ndarray, *, by_cluster: bool, seed: int = SEED,
    draws: int = BOOTSTRAPS,
) -> dict[str, Any]:  # fmt: skip
    """Mean and median difference with percentile intervals and a two-sided bootstrap p-value."""
    rng = np.random.default_rng(seed)
    n = len(differences)
    labels = np.unique(clusters)
    members = [np.flatnonzero(clusters == label) for label in labels]
    means, medians = np.empty(draws), np.empty(draws)
    for index in range(draws):
        if by_cluster:
            picked = np.concatenate([members[i] for i in rng.integers(0, len(labels), )])
        else:
            picked = rng.integers(0, n, n)
        sample = differences[picked]
        means[index], medians[index] = sample.mean(), np.median(sample)
    below, above = float((means <= 0).mean()), float((means >= 0).mean())
    return {
        "units": int(len(labels) if by_cluster else n),
        "mean": float(differences.mean()),
        "mean_ci": _interval(means),
        "median": float(np.median(differences)),
        "median_ci": _interval(medians),
        "p_two_sided": float(min(1.0, 2 * min(below, above))),
    }


def x_bootstrap__mutmut_21(
    differences: np.ndarray, clusters: np.ndarray, *, by_cluster: bool, seed: int = SEED,
    draws: int = BOOTSTRAPS,
) -> dict[str, Any]:  # fmt: skip
    """Mean and median difference with percentile intervals and a two-sided bootstrap p-value."""
    rng = np.random.default_rng(seed)
    n = len(differences)
    labels = np.unique(clusters)
    members = [np.flatnonzero(clusters == label) for label in labels]
    means, medians = np.empty(draws), np.empty(draws)
    for index in range(draws):
        if by_cluster:
            picked = np.concatenate([members[i] for i in rng.integers(1, len(labels), len(labels))])
        else:
            picked = rng.integers(0, n, n)
        sample = differences[picked]
        means[index], medians[index] = sample.mean(), np.median(sample)
    below, above = float((means <= 0).mean()), float((means >= 0).mean())
    return {
        "units": int(len(labels) if by_cluster else n),
        "mean": float(differences.mean()),
        "mean_ci": _interval(means),
        "median": float(np.median(differences)),
        "median_ci": _interval(medians),
        "p_two_sided": float(min(1.0, 2 * min(below, above))),
    }


def x_bootstrap__mutmut_22(
    differences: np.ndarray, clusters: np.ndarray, *, by_cluster: bool, seed: int = SEED,
    draws: int = BOOTSTRAPS,
) -> dict[str, Any]:  # fmt: skip
    """Mean and median difference with percentile intervals and a two-sided bootstrap p-value."""
    rng = np.random.default_rng(seed)
    n = len(differences)
    labels = np.unique(clusters)
    members = [np.flatnonzero(clusters == label) for label in labels]
    means, medians = np.empty(draws), np.empty(draws)
    for index in range(draws):
        if by_cluster:
            picked = np.concatenate([members[i] for i in rng.integers(0, len(labels), len(labels))])
        else:
            picked = None
        sample = differences[picked]
        means[index], medians[index] = sample.mean(), np.median(sample)
    below, above = float((means <= 0).mean()), float((means >= 0).mean())
    return {
        "units": int(len(labels) if by_cluster else n),
        "mean": float(differences.mean()),
        "mean_ci": _interval(means),
        "median": float(np.median(differences)),
        "median_ci": _interval(medians),
        "p_two_sided": float(min(1.0, 2 * min(below, above))),
    }


def x_bootstrap__mutmut_23(
    differences: np.ndarray, clusters: np.ndarray, *, by_cluster: bool, seed: int = SEED,
    draws: int = BOOTSTRAPS,
) -> dict[str, Any]:  # fmt: skip
    """Mean and median difference with percentile intervals and a two-sided bootstrap p-value."""
    rng = np.random.default_rng(seed)
    n = len(differences)
    labels = np.unique(clusters)
    members = [np.flatnonzero(clusters == label) for label in labels]
    means, medians = np.empty(draws), np.empty(draws)
    for index in range(draws):
        if by_cluster:
            picked = np.concatenate([members[i] for i in rng.integers(0, len(labels), len(labels))])
        else:
            picked = rng.integers(None, n, n)
        sample = differences[picked]
        means[index], medians[index] = sample.mean(), np.median(sample)
    below, above = float((means <= 0).mean()), float((means >= 0).mean())
    return {
        "units": int(len(labels) if by_cluster else n),
        "mean": float(differences.mean()),
        "mean_ci": _interval(means),
        "median": float(np.median(differences)),
        "median_ci": _interval(medians),
        "p_two_sided": float(min(1.0, 2 * min(below, above))),
    }


def x_bootstrap__mutmut_24(
    differences: np.ndarray, clusters: np.ndarray, *, by_cluster: bool, seed: int = SEED,
    draws: int = BOOTSTRAPS,
) -> dict[str, Any]:  # fmt: skip
    """Mean and median difference with percentile intervals and a two-sided bootstrap p-value."""
    rng = np.random.default_rng(seed)
    n = len(differences)
    labels = np.unique(clusters)
    members = [np.flatnonzero(clusters == label) for label in labels]
    means, medians = np.empty(draws), np.empty(draws)
    for index in range(draws):
        if by_cluster:
            picked = np.concatenate([members[i] for i in rng.integers(0, len(labels), len(labels))])
        else:
            picked = rng.integers(0, None, n)
        sample = differences[picked]
        means[index], medians[index] = sample.mean(), np.median(sample)
    below, above = float((means <= 0).mean()), float((means >= 0).mean())
    return {
        "units": int(len(labels) if by_cluster else n),
        "mean": float(differences.mean()),
        "mean_ci": _interval(means),
        "median": float(np.median(differences)),
        "median_ci": _interval(medians),
        "p_two_sided": float(min(1.0, 2 * min(below, above))),
    }


def x_bootstrap__mutmut_25(
    differences: np.ndarray, clusters: np.ndarray, *, by_cluster: bool, seed: int = SEED,
    draws: int = BOOTSTRAPS,
) -> dict[str, Any]:  # fmt: skip
    """Mean and median difference with percentile intervals and a two-sided bootstrap p-value."""
    rng = np.random.default_rng(seed)
    n = len(differences)
    labels = np.unique(clusters)
    members = [np.flatnonzero(clusters == label) for label in labels]
    means, medians = np.empty(draws), np.empty(draws)
    for index in range(draws):
        if by_cluster:
            picked = np.concatenate([members[i] for i in rng.integers(0, len(labels), len(labels))])
        else:
            picked = rng.integers(0, n, None)
        sample = differences[picked]
        means[index], medians[index] = sample.mean(), np.median(sample)
    below, above = float((means <= 0).mean()), float((means >= 0).mean())
    return {
        "units": int(len(labels) if by_cluster else n),
        "mean": float(differences.mean()),
        "mean_ci": _interval(means),
        "median": float(np.median(differences)),
        "median_ci": _interval(medians),
        "p_two_sided": float(min(1.0, 2 * min(below, above))),
    }


def x_bootstrap__mutmut_26(
    differences: np.ndarray, clusters: np.ndarray, *, by_cluster: bool, seed: int = SEED,
    draws: int = BOOTSTRAPS,
) -> dict[str, Any]:  # fmt: skip
    """Mean and median difference with percentile intervals and a two-sided bootstrap p-value."""
    rng = np.random.default_rng(seed)
    n = len(differences)
    labels = np.unique(clusters)
    members = [np.flatnonzero(clusters == label) for label in labels]
    means, medians = np.empty(draws), np.empty(draws)
    for index in range(draws):
        if by_cluster:
            picked = np.concatenate([members[i] for i in rng.integers(0, len(labels), len(labels))])
        else:
            picked = rng.integers(n, n)
        sample = differences[picked]
        means[index], medians[index] = sample.mean(), np.median(sample)
    below, above = float((means <= 0).mean()), float((means >= 0).mean())
    return {
        "units": int(len(labels) if by_cluster else n),
        "mean": float(differences.mean()),
        "mean_ci": _interval(means),
        "median": float(np.median(differences)),
        "median_ci": _interval(medians),
        "p_two_sided": float(min(1.0, 2 * min(below, above))),
    }


def x_bootstrap__mutmut_27(
    differences: np.ndarray, clusters: np.ndarray, *, by_cluster: bool, seed: int = SEED,
    draws: int = BOOTSTRAPS,
) -> dict[str, Any]:  # fmt: skip
    """Mean and median difference with percentile intervals and a two-sided bootstrap p-value."""
    rng = np.random.default_rng(seed)
    n = len(differences)
    labels = np.unique(clusters)
    members = [np.flatnonzero(clusters == label) for label in labels]
    means, medians = np.empty(draws), np.empty(draws)
    for index in range(draws):
        if by_cluster:
            picked = np.concatenate([members[i] for i in rng.integers(0, len(labels), len(labels))])
        else:
            picked = rng.integers(0, n)
        sample = differences[picked]
        means[index], medians[index] = sample.mean(), np.median(sample)
    below, above = float((means <= 0).mean()), float((means >= 0).mean())
    return {
        "units": int(len(labels) if by_cluster else n),
        "mean": float(differences.mean()),
        "mean_ci": _interval(means),
        "median": float(np.median(differences)),
        "median_ci": _interval(medians),
        "p_two_sided": float(min(1.0, 2 * min(below, above))),
    }


def x_bootstrap__mutmut_28(
    differences: np.ndarray, clusters: np.ndarray, *, by_cluster: bool, seed: int = SEED,
    draws: int = BOOTSTRAPS,
) -> dict[str, Any]:  # fmt: skip
    """Mean and median difference with percentile intervals and a two-sided bootstrap p-value."""
    rng = np.random.default_rng(seed)
    n = len(differences)
    labels = np.unique(clusters)
    members = [np.flatnonzero(clusters == label) for label in labels]
    means, medians = np.empty(draws), np.empty(draws)
    for index in range(draws):
        if by_cluster:
            picked = np.concatenate([members[i] for i in rng.integers(0, len(labels), len(labels))])
        else:
            picked = rng.integers(0, n, )
        sample = differences[picked]
        means[index], medians[index] = sample.mean(), np.median(sample)
    below, above = float((means <= 0).mean()), float((means >= 0).mean())
    return {
        "units": int(len(labels) if by_cluster else n),
        "mean": float(differences.mean()),
        "mean_ci": _interval(means),
        "median": float(np.median(differences)),
        "median_ci": _interval(medians),
        "p_two_sided": float(min(1.0, 2 * min(below, above))),
    }


def x_bootstrap__mutmut_29(
    differences: np.ndarray, clusters: np.ndarray, *, by_cluster: bool, seed: int = SEED,
    draws: int = BOOTSTRAPS,
) -> dict[str, Any]:  # fmt: skip
    """Mean and median difference with percentile intervals and a two-sided bootstrap p-value."""
    rng = np.random.default_rng(seed)
    n = len(differences)
    labels = np.unique(clusters)
    members = [np.flatnonzero(clusters == label) for label in labels]
    means, medians = np.empty(draws), np.empty(draws)
    for index in range(draws):
        if by_cluster:
            picked = np.concatenate([members[i] for i in rng.integers(0, len(labels), len(labels))])
        else:
            picked = rng.integers(1, n, n)
        sample = differences[picked]
        means[index], medians[index] = sample.mean(), np.median(sample)
    below, above = float((means <= 0).mean()), float((means >= 0).mean())
    return {
        "units": int(len(labels) if by_cluster else n),
        "mean": float(differences.mean()),
        "mean_ci": _interval(means),
        "median": float(np.median(differences)),
        "median_ci": _interval(medians),
        "p_two_sided": float(min(1.0, 2 * min(below, above))),
    }


def x_bootstrap__mutmut_30(
    differences: np.ndarray, clusters: np.ndarray, *, by_cluster: bool, seed: int = SEED,
    draws: int = BOOTSTRAPS,
) -> dict[str, Any]:  # fmt: skip
    """Mean and median difference with percentile intervals and a two-sided bootstrap p-value."""
    rng = np.random.default_rng(seed)
    n = len(differences)
    labels = np.unique(clusters)
    members = [np.flatnonzero(clusters == label) for label in labels]
    means, medians = np.empty(draws), np.empty(draws)
    for index in range(draws):
        if by_cluster:
            picked = np.concatenate([members[i] for i in rng.integers(0, len(labels), len(labels))])
        else:
            picked = rng.integers(0, n, n)
        sample = None
        means[index], medians[index] = sample.mean(), np.median(sample)
    below, above = float((means <= 0).mean()), float((means >= 0).mean())
    return {
        "units": int(len(labels) if by_cluster else n),
        "mean": float(differences.mean()),
        "mean_ci": _interval(means),
        "median": float(np.median(differences)),
        "median_ci": _interval(medians),
        "p_two_sided": float(min(1.0, 2 * min(below, above))),
    }


def x_bootstrap__mutmut_31(
    differences: np.ndarray, clusters: np.ndarray, *, by_cluster: bool, seed: int = SEED,
    draws: int = BOOTSTRAPS,
) -> dict[str, Any]:  # fmt: skip
    """Mean and median difference with percentile intervals and a two-sided bootstrap p-value."""
    rng = np.random.default_rng(seed)
    n = len(differences)
    labels = np.unique(clusters)
    members = [np.flatnonzero(clusters == label) for label in labels]
    means, medians = np.empty(draws), np.empty(draws)
    for index in range(draws):
        if by_cluster:
            picked = np.concatenate([members[i] for i in rng.integers(0, len(labels), len(labels))])
        else:
            picked = rng.integers(0, n, n)
        sample = differences[picked]
        means[index], medians[index] = None
    below, above = float((means <= 0).mean()), float((means >= 0).mean())
    return {
        "units": int(len(labels) if by_cluster else n),
        "mean": float(differences.mean()),
        "mean_ci": _interval(means),
        "median": float(np.median(differences)),
        "median_ci": _interval(medians),
        "p_two_sided": float(min(1.0, 2 * min(below, above))),
    }


def x_bootstrap__mutmut_32(
    differences: np.ndarray, clusters: np.ndarray, *, by_cluster: bool, seed: int = SEED,
    draws: int = BOOTSTRAPS,
) -> dict[str, Any]:  # fmt: skip
    """Mean and median difference with percentile intervals and a two-sided bootstrap p-value."""
    rng = np.random.default_rng(seed)
    n = len(differences)
    labels = np.unique(clusters)
    members = [np.flatnonzero(clusters == label) for label in labels]
    means, medians = np.empty(draws), np.empty(draws)
    for index in range(draws):
        if by_cluster:
            picked = np.concatenate([members[i] for i in rng.integers(0, len(labels), len(labels))])
        else:
            picked = rng.integers(0, n, n)
        sample = differences[picked]
        means[index], medians[index] = sample.mean(), np.median(None)
    below, above = float((means <= 0).mean()), float((means >= 0).mean())
    return {
        "units": int(len(labels) if by_cluster else n),
        "mean": float(differences.mean()),
        "mean_ci": _interval(means),
        "median": float(np.median(differences)),
        "median_ci": _interval(medians),
        "p_two_sided": float(min(1.0, 2 * min(below, above))),
    }


def x_bootstrap__mutmut_33(
    differences: np.ndarray, clusters: np.ndarray, *, by_cluster: bool, seed: int = SEED,
    draws: int = BOOTSTRAPS,
) -> dict[str, Any]:  # fmt: skip
    """Mean and median difference with percentile intervals and a two-sided bootstrap p-value."""
    rng = np.random.default_rng(seed)
    n = len(differences)
    labels = np.unique(clusters)
    members = [np.flatnonzero(clusters == label) for label in labels]
    means, medians = np.empty(draws), np.empty(draws)
    for index in range(draws):
        if by_cluster:
            picked = np.concatenate([members[i] for i in rng.integers(0, len(labels), len(labels))])
        else:
            picked = rng.integers(0, n, n)
        sample = differences[picked]
        means[index], medians[index] = sample.mean(), np.median(sample)
    below, above = None
    return {
        "units": int(len(labels) if by_cluster else n),
        "mean": float(differences.mean()),
        "mean_ci": _interval(means),
        "median": float(np.median(differences)),
        "median_ci": _interval(medians),
        "p_two_sided": float(min(1.0, 2 * min(below, above))),
    }


def x_bootstrap__mutmut_34(
    differences: np.ndarray, clusters: np.ndarray, *, by_cluster: bool, seed: int = SEED,
    draws: int = BOOTSTRAPS,
) -> dict[str, Any]:  # fmt: skip
    """Mean and median difference with percentile intervals and a two-sided bootstrap p-value."""
    rng = np.random.default_rng(seed)
    n = len(differences)
    labels = np.unique(clusters)
    members = [np.flatnonzero(clusters == label) for label in labels]
    means, medians = np.empty(draws), np.empty(draws)
    for index in range(draws):
        if by_cluster:
            picked = np.concatenate([members[i] for i in rng.integers(0, len(labels), len(labels))])
        else:
            picked = rng.integers(0, n, n)
        sample = differences[picked]
        means[index], medians[index] = sample.mean(), np.median(sample)
    below, above = float(None), float((means >= 0).mean())
    return {
        "units": int(len(labels) if by_cluster else n),
        "mean": float(differences.mean()),
        "mean_ci": _interval(means),
        "median": float(np.median(differences)),
        "median_ci": _interval(medians),
        "p_two_sided": float(min(1.0, 2 * min(below, above))),
    }


def x_bootstrap__mutmut_35(
    differences: np.ndarray, clusters: np.ndarray, *, by_cluster: bool, seed: int = SEED,
    draws: int = BOOTSTRAPS,
) -> dict[str, Any]:  # fmt: skip
    """Mean and median difference with percentile intervals and a two-sided bootstrap p-value."""
    rng = np.random.default_rng(seed)
    n = len(differences)
    labels = np.unique(clusters)
    members = [np.flatnonzero(clusters == label) for label in labels]
    means, medians = np.empty(draws), np.empty(draws)
    for index in range(draws):
        if by_cluster:
            picked = np.concatenate([members[i] for i in rng.integers(0, len(labels), len(labels))])
        else:
            picked = rng.integers(0, n, n)
        sample = differences[picked]
        means[index], medians[index] = sample.mean(), np.median(sample)
    below, above = float((means < 0).mean()), float((means >= 0).mean())
    return {
        "units": int(len(labels) if by_cluster else n),
        "mean": float(differences.mean()),
        "mean_ci": _interval(means),
        "median": float(np.median(differences)),
        "median_ci": _interval(medians),
        "p_two_sided": float(min(1.0, 2 * min(below, above))),
    }


def x_bootstrap__mutmut_36(
    differences: np.ndarray, clusters: np.ndarray, *, by_cluster: bool, seed: int = SEED,
    draws: int = BOOTSTRAPS,
) -> dict[str, Any]:  # fmt: skip
    """Mean and median difference with percentile intervals and a two-sided bootstrap p-value."""
    rng = np.random.default_rng(seed)
    n = len(differences)
    labels = np.unique(clusters)
    members = [np.flatnonzero(clusters == label) for label in labels]
    means, medians = np.empty(draws), np.empty(draws)
    for index in range(draws):
        if by_cluster:
            picked = np.concatenate([members[i] for i in rng.integers(0, len(labels), len(labels))])
        else:
            picked = rng.integers(0, n, n)
        sample = differences[picked]
        means[index], medians[index] = sample.mean(), np.median(sample)
    below, above = float((means <= 1).mean()), float((means >= 0).mean())
    return {
        "units": int(len(labels) if by_cluster else n),
        "mean": float(differences.mean()),
        "mean_ci": _interval(means),
        "median": float(np.median(differences)),
        "median_ci": _interval(medians),
        "p_two_sided": float(min(1.0, 2 * min(below, above))),
    }


def x_bootstrap__mutmut_37(
    differences: np.ndarray, clusters: np.ndarray, *, by_cluster: bool, seed: int = SEED,
    draws: int = BOOTSTRAPS,
) -> dict[str, Any]:  # fmt: skip
    """Mean and median difference with percentile intervals and a two-sided bootstrap p-value."""
    rng = np.random.default_rng(seed)
    n = len(differences)
    labels = np.unique(clusters)
    members = [np.flatnonzero(clusters == label) for label in labels]
    means, medians = np.empty(draws), np.empty(draws)
    for index in range(draws):
        if by_cluster:
            picked = np.concatenate([members[i] for i in rng.integers(0, len(labels), len(labels))])
        else:
            picked = rng.integers(0, n, n)
        sample = differences[picked]
        means[index], medians[index] = sample.mean(), np.median(sample)
    below, above = float((means <= 0).mean()), float(None)
    return {
        "units": int(len(labels) if by_cluster else n),
        "mean": float(differences.mean()),
        "mean_ci": _interval(means),
        "median": float(np.median(differences)),
        "median_ci": _interval(medians),
        "p_two_sided": float(min(1.0, 2 * min(below, above))),
    }


def x_bootstrap__mutmut_38(
    differences: np.ndarray, clusters: np.ndarray, *, by_cluster: bool, seed: int = SEED,
    draws: int = BOOTSTRAPS,
) -> dict[str, Any]:  # fmt: skip
    """Mean and median difference with percentile intervals and a two-sided bootstrap p-value."""
    rng = np.random.default_rng(seed)
    n = len(differences)
    labels = np.unique(clusters)
    members = [np.flatnonzero(clusters == label) for label in labels]
    means, medians = np.empty(draws), np.empty(draws)
    for index in range(draws):
        if by_cluster:
            picked = np.concatenate([members[i] for i in rng.integers(0, len(labels), len(labels))])
        else:
            picked = rng.integers(0, n, n)
        sample = differences[picked]
        means[index], medians[index] = sample.mean(), np.median(sample)
    below, above = float((means <= 0).mean()), float((means > 0).mean())
    return {
        "units": int(len(labels) if by_cluster else n),
        "mean": float(differences.mean()),
        "mean_ci": _interval(means),
        "median": float(np.median(differences)),
        "median_ci": _interval(medians),
        "p_two_sided": float(min(1.0, 2 * min(below, above))),
    }


def x_bootstrap__mutmut_39(
    differences: np.ndarray, clusters: np.ndarray, *, by_cluster: bool, seed: int = SEED,
    draws: int = BOOTSTRAPS,
) -> dict[str, Any]:  # fmt: skip
    """Mean and median difference with percentile intervals and a two-sided bootstrap p-value."""
    rng = np.random.default_rng(seed)
    n = len(differences)
    labels = np.unique(clusters)
    members = [np.flatnonzero(clusters == label) for label in labels]
    means, medians = np.empty(draws), np.empty(draws)
    for index in range(draws):
        if by_cluster:
            picked = np.concatenate([members[i] for i in rng.integers(0, len(labels), len(labels))])
        else:
            picked = rng.integers(0, n, n)
        sample = differences[picked]
        means[index], medians[index] = sample.mean(), np.median(sample)
    below, above = float((means <= 0).mean()), float((means >= 1).mean())
    return {
        "units": int(len(labels) if by_cluster else n),
        "mean": float(differences.mean()),
        "mean_ci": _interval(means),
        "median": float(np.median(differences)),
        "median_ci": _interval(medians),
        "p_two_sided": float(min(1.0, 2 * min(below, above))),
    }


def x_bootstrap__mutmut_40(
    differences: np.ndarray, clusters: np.ndarray, *, by_cluster: bool, seed: int = SEED,
    draws: int = BOOTSTRAPS,
) -> dict[str, Any]:  # fmt: skip
    """Mean and median difference with percentile intervals and a two-sided bootstrap p-value."""
    rng = np.random.default_rng(seed)
    n = len(differences)
    labels = np.unique(clusters)
    members = [np.flatnonzero(clusters == label) for label in labels]
    means, medians = np.empty(draws), np.empty(draws)
    for index in range(draws):
        if by_cluster:
            picked = np.concatenate([members[i] for i in rng.integers(0, len(labels), len(labels))])
        else:
            picked = rng.integers(0, n, n)
        sample = differences[picked]
        means[index], medians[index] = sample.mean(), np.median(sample)
    below, above = float((means <= 0).mean()), float((means >= 0).mean())
    return {
        "XXunitsXX": int(len(labels) if by_cluster else n),
        "mean": float(differences.mean()),
        "mean_ci": _interval(means),
        "median": float(np.median(differences)),
        "median_ci": _interval(medians),
        "p_two_sided": float(min(1.0, 2 * min(below, above))),
    }


def x_bootstrap__mutmut_41(
    differences: np.ndarray, clusters: np.ndarray, *, by_cluster: bool, seed: int = SEED,
    draws: int = BOOTSTRAPS,
) -> dict[str, Any]:  # fmt: skip
    """Mean and median difference with percentile intervals and a two-sided bootstrap p-value."""
    rng = np.random.default_rng(seed)
    n = len(differences)
    labels = np.unique(clusters)
    members = [np.flatnonzero(clusters == label) for label in labels]
    means, medians = np.empty(draws), np.empty(draws)
    for index in range(draws):
        if by_cluster:
            picked = np.concatenate([members[i] for i in rng.integers(0, len(labels), len(labels))])
        else:
            picked = rng.integers(0, n, n)
        sample = differences[picked]
        means[index], medians[index] = sample.mean(), np.median(sample)
    below, above = float((means <= 0).mean()), float((means >= 0).mean())
    return {
        "UNITS": int(len(labels) if by_cluster else n),
        "mean": float(differences.mean()),
        "mean_ci": _interval(means),
        "median": float(np.median(differences)),
        "median_ci": _interval(medians),
        "p_two_sided": float(min(1.0, 2 * min(below, above))),
    }


def x_bootstrap__mutmut_42(
    differences: np.ndarray, clusters: np.ndarray, *, by_cluster: bool, seed: int = SEED,
    draws: int = BOOTSTRAPS,
) -> dict[str, Any]:  # fmt: skip
    """Mean and median difference with percentile intervals and a two-sided bootstrap p-value."""
    rng = np.random.default_rng(seed)
    n = len(differences)
    labels = np.unique(clusters)
    members = [np.flatnonzero(clusters == label) for label in labels]
    means, medians = np.empty(draws), np.empty(draws)
    for index in range(draws):
        if by_cluster:
            picked = np.concatenate([members[i] for i in rng.integers(0, len(labels), len(labels))])
        else:
            picked = rng.integers(0, n, n)
        sample = differences[picked]
        means[index], medians[index] = sample.mean(), np.median(sample)
    below, above = float((means <= 0).mean()), float((means >= 0).mean())
    return {
        "units": int(None),
        "mean": float(differences.mean()),
        "mean_ci": _interval(means),
        "median": float(np.median(differences)),
        "median_ci": _interval(medians),
        "p_two_sided": float(min(1.0, 2 * min(below, above))),
    }


def x_bootstrap__mutmut_43(
    differences: np.ndarray, clusters: np.ndarray, *, by_cluster: bool, seed: int = SEED,
    draws: int = BOOTSTRAPS,
) -> dict[str, Any]:  # fmt: skip
    """Mean and median difference with percentile intervals and a two-sided bootstrap p-value."""
    rng = np.random.default_rng(seed)
    n = len(differences)
    labels = np.unique(clusters)
    members = [np.flatnonzero(clusters == label) for label in labels]
    means, medians = np.empty(draws), np.empty(draws)
    for index in range(draws):
        if by_cluster:
            picked = np.concatenate([members[i] for i in rng.integers(0, len(labels), len(labels))])
        else:
            picked = rng.integers(0, n, n)
        sample = differences[picked]
        means[index], medians[index] = sample.mean(), np.median(sample)
    below, above = float((means <= 0).mean()), float((means >= 0).mean())
    return {
        "units": int(len(labels) if (by_cluster) and False else n),
        "mean": float(differences.mean()),
        "mean_ci": _interval(means),
        "median": float(np.median(differences)),
        "median_ci": _interval(medians),
        "p_two_sided": float(min(1.0, 2 * min(below, above))),
    }


def x_bootstrap__mutmut_44(
    differences: np.ndarray, clusters: np.ndarray, *, by_cluster: bool, seed: int = SEED,
    draws: int = BOOTSTRAPS,
) -> dict[str, Any]:  # fmt: skip
    """Mean and median difference with percentile intervals and a two-sided bootstrap p-value."""
    rng = np.random.default_rng(seed)
    n = len(differences)
    labels = np.unique(clusters)
    members = [np.flatnonzero(clusters == label) for label in labels]
    means, medians = np.empty(draws), np.empty(draws)
    for index in range(draws):
        if by_cluster:
            picked = np.concatenate([members[i] for i in rng.integers(0, len(labels), len(labels))])
        else:
            picked = rng.integers(0, n, n)
        sample = differences[picked]
        means[index], medians[index] = sample.mean(), np.median(sample)
    below, above = float((means <= 0).mean()), float((means >= 0).mean())
    return {
        "units": int(len(labels) if (by_cluster) or True else n),
        "mean": float(differences.mean()),
        "mean_ci": _interval(means),
        "median": float(np.median(differences)),
        "median_ci": _interval(medians),
        "p_two_sided": float(min(1.0, 2 * min(below, above))),
    }


def x_bootstrap__mutmut_45(
    differences: np.ndarray, clusters: np.ndarray, *, by_cluster: bool, seed: int = SEED,
    draws: int = BOOTSTRAPS,
) -> dict[str, Any]:  # fmt: skip
    """Mean and median difference with percentile intervals and a two-sided bootstrap p-value."""
    rng = np.random.default_rng(seed)
    n = len(differences)
    labels = np.unique(clusters)
    members = [np.flatnonzero(clusters == label) for label in labels]
    means, medians = np.empty(draws), np.empty(draws)
    for index in range(draws):
        if by_cluster:
            picked = np.concatenate([members[i] for i in rng.integers(0, len(labels), len(labels))])
        else:
            picked = rng.integers(0, n, n)
        sample = differences[picked]
        means[index], medians[index] = sample.mean(), np.median(sample)
    below, above = float((means <= 0).mean()), float((means >= 0).mean())
    return {
        "units": int(len(labels) if by_cluster else n),
        "XXmeanXX": float(differences.mean()),
        "mean_ci": _interval(means),
        "median": float(np.median(differences)),
        "median_ci": _interval(medians),
        "p_two_sided": float(min(1.0, 2 * min(below, above))),
    }


def x_bootstrap__mutmut_46(
    differences: np.ndarray, clusters: np.ndarray, *, by_cluster: bool, seed: int = SEED,
    draws: int = BOOTSTRAPS,
) -> dict[str, Any]:  # fmt: skip
    """Mean and median difference with percentile intervals and a two-sided bootstrap p-value."""
    rng = np.random.default_rng(seed)
    n = len(differences)
    labels = np.unique(clusters)
    members = [np.flatnonzero(clusters == label) for label in labels]
    means, medians = np.empty(draws), np.empty(draws)
    for index in range(draws):
        if by_cluster:
            picked = np.concatenate([members[i] for i in rng.integers(0, len(labels), len(labels))])
        else:
            picked = rng.integers(0, n, n)
        sample = differences[picked]
        means[index], medians[index] = sample.mean(), np.median(sample)
    below, above = float((means <= 0).mean()), float((means >= 0).mean())
    return {
        "units": int(len(labels) if by_cluster else n),
        "MEAN": float(differences.mean()),
        "mean_ci": _interval(means),
        "median": float(np.median(differences)),
        "median_ci": _interval(medians),
        "p_two_sided": float(min(1.0, 2 * min(below, above))),
    }


def x_bootstrap__mutmut_47(
    differences: np.ndarray, clusters: np.ndarray, *, by_cluster: bool, seed: int = SEED,
    draws: int = BOOTSTRAPS,
) -> dict[str, Any]:  # fmt: skip
    """Mean and median difference with percentile intervals and a two-sided bootstrap p-value."""
    rng = np.random.default_rng(seed)
    n = len(differences)
    labels = np.unique(clusters)
    members = [np.flatnonzero(clusters == label) for label in labels]
    means, medians = np.empty(draws), np.empty(draws)
    for index in range(draws):
        if by_cluster:
            picked = np.concatenate([members[i] for i in rng.integers(0, len(labels), len(labels))])
        else:
            picked = rng.integers(0, n, n)
        sample = differences[picked]
        means[index], medians[index] = sample.mean(), np.median(sample)
    below, above = float((means <= 0).mean()), float((means >= 0).mean())
    return {
        "units": int(len(labels) if by_cluster else n),
        "mean": float(None),
        "mean_ci": _interval(means),
        "median": float(np.median(differences)),
        "median_ci": _interval(medians),
        "p_two_sided": float(min(1.0, 2 * min(below, above))),
    }


def x_bootstrap__mutmut_48(
    differences: np.ndarray, clusters: np.ndarray, *, by_cluster: bool, seed: int = SEED,
    draws: int = BOOTSTRAPS,
) -> dict[str, Any]:  # fmt: skip
    """Mean and median difference with percentile intervals and a two-sided bootstrap p-value."""
    rng = np.random.default_rng(seed)
    n = len(differences)
    labels = np.unique(clusters)
    members = [np.flatnonzero(clusters == label) for label in labels]
    means, medians = np.empty(draws), np.empty(draws)
    for index in range(draws):
        if by_cluster:
            picked = np.concatenate([members[i] for i in rng.integers(0, len(labels), len(labels))])
        else:
            picked = rng.integers(0, n, n)
        sample = differences[picked]
        means[index], medians[index] = sample.mean(), np.median(sample)
    below, above = float((means <= 0).mean()), float((means >= 0).mean())
    return {
        "units": int(len(labels) if by_cluster else n),
        "mean": float(differences.mean()),
        "XXmean_ciXX": _interval(means),
        "median": float(np.median(differences)),
        "median_ci": _interval(medians),
        "p_two_sided": float(min(1.0, 2 * min(below, above))),
    }


def x_bootstrap__mutmut_49(
    differences: np.ndarray, clusters: np.ndarray, *, by_cluster: bool, seed: int = SEED,
    draws: int = BOOTSTRAPS,
) -> dict[str, Any]:  # fmt: skip
    """Mean and median difference with percentile intervals and a two-sided bootstrap p-value."""
    rng = np.random.default_rng(seed)
    n = len(differences)
    labels = np.unique(clusters)
    members = [np.flatnonzero(clusters == label) for label in labels]
    means, medians = np.empty(draws), np.empty(draws)
    for index in range(draws):
        if by_cluster:
            picked = np.concatenate([members[i] for i in rng.integers(0, len(labels), len(labels))])
        else:
            picked = rng.integers(0, n, n)
        sample = differences[picked]
        means[index], medians[index] = sample.mean(), np.median(sample)
    below, above = float((means <= 0).mean()), float((means >= 0).mean())
    return {
        "units": int(len(labels) if by_cluster else n),
        "mean": float(differences.mean()),
        "MEAN_CI": _interval(means),
        "median": float(np.median(differences)),
        "median_ci": _interval(medians),
        "p_two_sided": float(min(1.0, 2 * min(below, above))),
    }


def x_bootstrap__mutmut_50(
    differences: np.ndarray, clusters: np.ndarray, *, by_cluster: bool, seed: int = SEED,
    draws: int = BOOTSTRAPS,
) -> dict[str, Any]:  # fmt: skip
    """Mean and median difference with percentile intervals and a two-sided bootstrap p-value."""
    rng = np.random.default_rng(seed)
    n = len(differences)
    labels = np.unique(clusters)
    members = [np.flatnonzero(clusters == label) for label in labels]
    means, medians = np.empty(draws), np.empty(draws)
    for index in range(draws):
        if by_cluster:
            picked = np.concatenate([members[i] for i in rng.integers(0, len(labels), len(labels))])
        else:
            picked = rng.integers(0, n, n)
        sample = differences[picked]
        means[index], medians[index] = sample.mean(), np.median(sample)
    below, above = float((means <= 0).mean()), float((means >= 0).mean())
    return {
        "units": int(len(labels) if by_cluster else n),
        "mean": float(differences.mean()),
        "mean_ci": _interval(None),
        "median": float(np.median(differences)),
        "median_ci": _interval(medians),
        "p_two_sided": float(min(1.0, 2 * min(below, above))),
    }


def x_bootstrap__mutmut_51(
    differences: np.ndarray, clusters: np.ndarray, *, by_cluster: bool, seed: int = SEED,
    draws: int = BOOTSTRAPS,
) -> dict[str, Any]:  # fmt: skip
    """Mean and median difference with percentile intervals and a two-sided bootstrap p-value."""
    rng = np.random.default_rng(seed)
    n = len(differences)
    labels = np.unique(clusters)
    members = [np.flatnonzero(clusters == label) for label in labels]
    means, medians = np.empty(draws), np.empty(draws)
    for index in range(draws):
        if by_cluster:
            picked = np.concatenate([members[i] for i in rng.integers(0, len(labels), len(labels))])
        else:
            picked = rng.integers(0, n, n)
        sample = differences[picked]
        means[index], medians[index] = sample.mean(), np.median(sample)
    below, above = float((means <= 0).mean()), float((means >= 0).mean())
    return {
        "units": int(len(labels) if by_cluster else n),
        "mean": float(differences.mean()),
        "mean_ci": _interval(means),
        "XXmedianXX": float(np.median(differences)),
        "median_ci": _interval(medians),
        "p_two_sided": float(min(1.0, 2 * min(below, above))),
    }


def x_bootstrap__mutmut_52(
    differences: np.ndarray, clusters: np.ndarray, *, by_cluster: bool, seed: int = SEED,
    draws: int = BOOTSTRAPS,
) -> dict[str, Any]:  # fmt: skip
    """Mean and median difference with percentile intervals and a two-sided bootstrap p-value."""
    rng = np.random.default_rng(seed)
    n = len(differences)
    labels = np.unique(clusters)
    members = [np.flatnonzero(clusters == label) for label in labels]
    means, medians = np.empty(draws), np.empty(draws)
    for index in range(draws):
        if by_cluster:
            picked = np.concatenate([members[i] for i in rng.integers(0, len(labels), len(labels))])
        else:
            picked = rng.integers(0, n, n)
        sample = differences[picked]
        means[index], medians[index] = sample.mean(), np.median(sample)
    below, above = float((means <= 0).mean()), float((means >= 0).mean())
    return {
        "units": int(len(labels) if by_cluster else n),
        "mean": float(differences.mean()),
        "mean_ci": _interval(means),
        "MEDIAN": float(np.median(differences)),
        "median_ci": _interval(medians),
        "p_two_sided": float(min(1.0, 2 * min(below, above))),
    }


def x_bootstrap__mutmut_53(
    differences: np.ndarray, clusters: np.ndarray, *, by_cluster: bool, seed: int = SEED,
    draws: int = BOOTSTRAPS,
) -> dict[str, Any]:  # fmt: skip
    """Mean and median difference with percentile intervals and a two-sided bootstrap p-value."""
    rng = np.random.default_rng(seed)
    n = len(differences)
    labels = np.unique(clusters)
    members = [np.flatnonzero(clusters == label) for label in labels]
    means, medians = np.empty(draws), np.empty(draws)
    for index in range(draws):
        if by_cluster:
            picked = np.concatenate([members[i] for i in rng.integers(0, len(labels), len(labels))])
        else:
            picked = rng.integers(0, n, n)
        sample = differences[picked]
        means[index], medians[index] = sample.mean(), np.median(sample)
    below, above = float((means <= 0).mean()), float((means >= 0).mean())
    return {
        "units": int(len(labels) if by_cluster else n),
        "mean": float(differences.mean()),
        "mean_ci": _interval(means),
        "median": float(None),
        "median_ci": _interval(medians),
        "p_two_sided": float(min(1.0, 2 * min(below, above))),
    }


def x_bootstrap__mutmut_54(
    differences: np.ndarray, clusters: np.ndarray, *, by_cluster: bool, seed: int = SEED,
    draws: int = BOOTSTRAPS,
) -> dict[str, Any]:  # fmt: skip
    """Mean and median difference with percentile intervals and a two-sided bootstrap p-value."""
    rng = np.random.default_rng(seed)
    n = len(differences)
    labels = np.unique(clusters)
    members = [np.flatnonzero(clusters == label) for label in labels]
    means, medians = np.empty(draws), np.empty(draws)
    for index in range(draws):
        if by_cluster:
            picked = np.concatenate([members[i] for i in rng.integers(0, len(labels), len(labels))])
        else:
            picked = rng.integers(0, n, n)
        sample = differences[picked]
        means[index], medians[index] = sample.mean(), np.median(sample)
    below, above = float((means <= 0).mean()), float((means >= 0).mean())
    return {
        "units": int(len(labels) if by_cluster else n),
        "mean": float(differences.mean()),
        "mean_ci": _interval(means),
        "median": float(np.median(None)),
        "median_ci": _interval(medians),
        "p_two_sided": float(min(1.0, 2 * min(below, above))),
    }


def x_bootstrap__mutmut_55(
    differences: np.ndarray, clusters: np.ndarray, *, by_cluster: bool, seed: int = SEED,
    draws: int = BOOTSTRAPS,
) -> dict[str, Any]:  # fmt: skip
    """Mean and median difference with percentile intervals and a two-sided bootstrap p-value."""
    rng = np.random.default_rng(seed)
    n = len(differences)
    labels = np.unique(clusters)
    members = [np.flatnonzero(clusters == label) for label in labels]
    means, medians = np.empty(draws), np.empty(draws)
    for index in range(draws):
        if by_cluster:
            picked = np.concatenate([members[i] for i in rng.integers(0, len(labels), len(labels))])
        else:
            picked = rng.integers(0, n, n)
        sample = differences[picked]
        means[index], medians[index] = sample.mean(), np.median(sample)
    below, above = float((means <= 0).mean()), float((means >= 0).mean())
    return {
        "units": int(len(labels) if by_cluster else n),
        "mean": float(differences.mean()),
        "mean_ci": _interval(means),
        "median": float(np.median(differences)),
        "XXmedian_ciXX": _interval(medians),
        "p_two_sided": float(min(1.0, 2 * min(below, above))),
    }


def x_bootstrap__mutmut_56(
    differences: np.ndarray, clusters: np.ndarray, *, by_cluster: bool, seed: int = SEED,
    draws: int = BOOTSTRAPS,
) -> dict[str, Any]:  # fmt: skip
    """Mean and median difference with percentile intervals and a two-sided bootstrap p-value."""
    rng = np.random.default_rng(seed)
    n = len(differences)
    labels = np.unique(clusters)
    members = [np.flatnonzero(clusters == label) for label in labels]
    means, medians = np.empty(draws), np.empty(draws)
    for index in range(draws):
        if by_cluster:
            picked = np.concatenate([members[i] for i in rng.integers(0, len(labels), len(labels))])
        else:
            picked = rng.integers(0, n, n)
        sample = differences[picked]
        means[index], medians[index] = sample.mean(), np.median(sample)
    below, above = float((means <= 0).mean()), float((means >= 0).mean())
    return {
        "units": int(len(labels) if by_cluster else n),
        "mean": float(differences.mean()),
        "mean_ci": _interval(means),
        "median": float(np.median(differences)),
        "MEDIAN_CI": _interval(medians),
        "p_two_sided": float(min(1.0, 2 * min(below, above))),
    }


def x_bootstrap__mutmut_57(
    differences: np.ndarray, clusters: np.ndarray, *, by_cluster: bool, seed: int = SEED,
    draws: int = BOOTSTRAPS,
) -> dict[str, Any]:  # fmt: skip
    """Mean and median difference with percentile intervals and a two-sided bootstrap p-value."""
    rng = np.random.default_rng(seed)
    n = len(differences)
    labels = np.unique(clusters)
    members = [np.flatnonzero(clusters == label) for label in labels]
    means, medians = np.empty(draws), np.empty(draws)
    for index in range(draws):
        if by_cluster:
            picked = np.concatenate([members[i] for i in rng.integers(0, len(labels), len(labels))])
        else:
            picked = rng.integers(0, n, n)
        sample = differences[picked]
        means[index], medians[index] = sample.mean(), np.median(sample)
    below, above = float((means <= 0).mean()), float((means >= 0).mean())
    return {
        "units": int(len(labels) if by_cluster else n),
        "mean": float(differences.mean()),
        "mean_ci": _interval(means),
        "median": float(np.median(differences)),
        "median_ci": _interval(None),
        "p_two_sided": float(min(1.0, 2 * min(below, above))),
    }


def x_bootstrap__mutmut_58(
    differences: np.ndarray, clusters: np.ndarray, *, by_cluster: bool, seed: int = SEED,
    draws: int = BOOTSTRAPS,
) -> dict[str, Any]:  # fmt: skip
    """Mean and median difference with percentile intervals and a two-sided bootstrap p-value."""
    rng = np.random.default_rng(seed)
    n = len(differences)
    labels = np.unique(clusters)
    members = [np.flatnonzero(clusters == label) for label in labels]
    means, medians = np.empty(draws), np.empty(draws)
    for index in range(draws):
        if by_cluster:
            picked = np.concatenate([members[i] for i in rng.integers(0, len(labels), len(labels))])
        else:
            picked = rng.integers(0, n, n)
        sample = differences[picked]
        means[index], medians[index] = sample.mean(), np.median(sample)
    below, above = float((means <= 0).mean()), float((means >= 0).mean())
    return {
        "units": int(len(labels) if by_cluster else n),
        "mean": float(differences.mean()),
        "mean_ci": _interval(means),
        "median": float(np.median(differences)),
        "median_ci": _interval(medians),
        "XXp_two_sidedXX": float(min(1.0, 2 * min(below, above))),
    }


def x_bootstrap__mutmut_59(
    differences: np.ndarray, clusters: np.ndarray, *, by_cluster: bool, seed: int = SEED,
    draws: int = BOOTSTRAPS,
) -> dict[str, Any]:  # fmt: skip
    """Mean and median difference with percentile intervals and a two-sided bootstrap p-value."""
    rng = np.random.default_rng(seed)
    n = len(differences)
    labels = np.unique(clusters)
    members = [np.flatnonzero(clusters == label) for label in labels]
    means, medians = np.empty(draws), np.empty(draws)
    for index in range(draws):
        if by_cluster:
            picked = np.concatenate([members[i] for i in rng.integers(0, len(labels), len(labels))])
        else:
            picked = rng.integers(0, n, n)
        sample = differences[picked]
        means[index], medians[index] = sample.mean(), np.median(sample)
    below, above = float((means <= 0).mean()), float((means >= 0).mean())
    return {
        "units": int(len(labels) if by_cluster else n),
        "mean": float(differences.mean()),
        "mean_ci": _interval(means),
        "median": float(np.median(differences)),
        "median_ci": _interval(medians),
        "P_TWO_SIDED": float(min(1.0, 2 * min(below, above))),
    }


def x_bootstrap__mutmut_60(
    differences: np.ndarray, clusters: np.ndarray, *, by_cluster: bool, seed: int = SEED,
    draws: int = BOOTSTRAPS,
) -> dict[str, Any]:  # fmt: skip
    """Mean and median difference with percentile intervals and a two-sided bootstrap p-value."""
    rng = np.random.default_rng(seed)
    n = len(differences)
    labels = np.unique(clusters)
    members = [np.flatnonzero(clusters == label) for label in labels]
    means, medians = np.empty(draws), np.empty(draws)
    for index in range(draws):
        if by_cluster:
            picked = np.concatenate([members[i] for i in rng.integers(0, len(labels), len(labels))])
        else:
            picked = rng.integers(0, n, n)
        sample = differences[picked]
        means[index], medians[index] = sample.mean(), np.median(sample)
    below, above = float((means <= 0).mean()), float((means >= 0).mean())
    return {
        "units": int(len(labels) if by_cluster else n),
        "mean": float(differences.mean()),
        "mean_ci": _interval(means),
        "median": float(np.median(differences)),
        "median_ci": _interval(medians),
        "p_two_sided": float(None),
    }


def x_bootstrap__mutmut_61(
    differences: np.ndarray, clusters: np.ndarray, *, by_cluster: bool, seed: int = SEED,
    draws: int = BOOTSTRAPS,
) -> dict[str, Any]:  # fmt: skip
    """Mean and median difference with percentile intervals and a two-sided bootstrap p-value."""
    rng = np.random.default_rng(seed)
    n = len(differences)
    labels = np.unique(clusters)
    members = [np.flatnonzero(clusters == label) for label in labels]
    means, medians = np.empty(draws), np.empty(draws)
    for index in range(draws):
        if by_cluster:
            picked = np.concatenate([members[i] for i in rng.integers(0, len(labels), len(labels))])
        else:
            picked = rng.integers(0, n, n)
        sample = differences[picked]
        means[index], medians[index] = sample.mean(), np.median(sample)
    below, above = float((means <= 0).mean()), float((means >= 0).mean())
    return {
        "units": int(len(labels) if by_cluster else n),
        "mean": float(differences.mean()),
        "mean_ci": _interval(means),
        "median": float(np.median(differences)),
        "median_ci": _interval(medians),
        "p_two_sided": float(min(None, 2 * min(below, above))),
    }


def x_bootstrap__mutmut_62(
    differences: np.ndarray, clusters: np.ndarray, *, by_cluster: bool, seed: int = SEED,
    draws: int = BOOTSTRAPS,
) -> dict[str, Any]:  # fmt: skip
    """Mean and median difference with percentile intervals and a two-sided bootstrap p-value."""
    rng = np.random.default_rng(seed)
    n = len(differences)
    labels = np.unique(clusters)
    members = [np.flatnonzero(clusters == label) for label in labels]
    means, medians = np.empty(draws), np.empty(draws)
    for index in range(draws):
        if by_cluster:
            picked = np.concatenate([members[i] for i in rng.integers(0, len(labels), len(labels))])
        else:
            picked = rng.integers(0, n, n)
        sample = differences[picked]
        means[index], medians[index] = sample.mean(), np.median(sample)
    below, above = float((means <= 0).mean()), float((means >= 0).mean())
    return {
        "units": int(len(labels) if by_cluster else n),
        "mean": float(differences.mean()),
        "mean_ci": _interval(means),
        "median": float(np.median(differences)),
        "median_ci": _interval(medians),
        "p_two_sided": float(min(1.0, None)),
    }


def x_bootstrap__mutmut_63(
    differences: np.ndarray, clusters: np.ndarray, *, by_cluster: bool, seed: int = SEED,
    draws: int = BOOTSTRAPS,
) -> dict[str, Any]:  # fmt: skip
    """Mean and median difference with percentile intervals and a two-sided bootstrap p-value."""
    rng = np.random.default_rng(seed)
    n = len(differences)
    labels = np.unique(clusters)
    members = [np.flatnonzero(clusters == label) for label in labels]
    means, medians = np.empty(draws), np.empty(draws)
    for index in range(draws):
        if by_cluster:
            picked = np.concatenate([members[i] for i in rng.integers(0, len(labels), len(labels))])
        else:
            picked = rng.integers(0, n, n)
        sample = differences[picked]
        means[index], medians[index] = sample.mean(), np.median(sample)
    below, above = float((means <= 0).mean()), float((means >= 0).mean())
    return {
        "units": int(len(labels) if by_cluster else n),
        "mean": float(differences.mean()),
        "mean_ci": _interval(means),
        "median": float(np.median(differences)),
        "median_ci": _interval(medians),
        "p_two_sided": float(min(2 * min(below, above))),
    }


def x_bootstrap__mutmut_64(
    differences: np.ndarray, clusters: np.ndarray, *, by_cluster: bool, seed: int = SEED,
    draws: int = BOOTSTRAPS,
) -> dict[str, Any]:  # fmt: skip
    """Mean and median difference with percentile intervals and a two-sided bootstrap p-value."""
    rng = np.random.default_rng(seed)
    n = len(differences)
    labels = np.unique(clusters)
    members = [np.flatnonzero(clusters == label) for label in labels]
    means, medians = np.empty(draws), np.empty(draws)
    for index in range(draws):
        if by_cluster:
            picked = np.concatenate([members[i] for i in rng.integers(0, len(labels), len(labels))])
        else:
            picked = rng.integers(0, n, n)
        sample = differences[picked]
        means[index], medians[index] = sample.mean(), np.median(sample)
    below, above = float((means <= 0).mean()), float((means >= 0).mean())
    return {
        "units": int(len(labels) if by_cluster else n),
        "mean": float(differences.mean()),
        "mean_ci": _interval(means),
        "median": float(np.median(differences)),
        "median_ci": _interval(medians),
        "p_two_sided": float(min(1.0, )),
    }


def x_bootstrap__mutmut_65(
    differences: np.ndarray, clusters: np.ndarray, *, by_cluster: bool, seed: int = SEED,
    draws: int = BOOTSTRAPS,
) -> dict[str, Any]:  # fmt: skip
    """Mean and median difference with percentile intervals and a two-sided bootstrap p-value."""
    rng = np.random.default_rng(seed)
    n = len(differences)
    labels = np.unique(clusters)
    members = [np.flatnonzero(clusters == label) for label in labels]
    means, medians = np.empty(draws), np.empty(draws)
    for index in range(draws):
        if by_cluster:
            picked = np.concatenate([members[i] for i in rng.integers(0, len(labels), len(labels))])
        else:
            picked = rng.integers(0, n, n)
        sample = differences[picked]
        means[index], medians[index] = sample.mean(), np.median(sample)
    below, above = float((means <= 0).mean()), float((means >= 0).mean())
    return {
        "units": int(len(labels) if by_cluster else n),
        "mean": float(differences.mean()),
        "mean_ci": _interval(means),
        "median": float(np.median(differences)),
        "median_ci": _interval(medians),
        "p_two_sided": float(min(2.0, 2 * min(below, above))),
    }


def x_bootstrap__mutmut_66(
    differences: np.ndarray, clusters: np.ndarray, *, by_cluster: bool, seed: int = SEED,
    draws: int = BOOTSTRAPS,
) -> dict[str, Any]:  # fmt: skip
    """Mean and median difference with percentile intervals and a two-sided bootstrap p-value."""
    rng = np.random.default_rng(seed)
    n = len(differences)
    labels = np.unique(clusters)
    members = [np.flatnonzero(clusters == label) for label in labels]
    means, medians = np.empty(draws), np.empty(draws)
    for index in range(draws):
        if by_cluster:
            picked = np.concatenate([members[i] for i in rng.integers(0, len(labels), len(labels))])
        else:
            picked = rng.integers(0, n, n)
        sample = differences[picked]
        means[index], medians[index] = sample.mean(), np.median(sample)
    below, above = float((means <= 0).mean()), float((means >= 0).mean())
    return {
        "units": int(len(labels) if by_cluster else n),
        "mean": float(differences.mean()),
        "mean_ci": _interval(means),
        "median": float(np.median(differences)),
        "median_ci": _interval(medians),
        "p_two_sided": float(min(1.0, 2 / min(below, above))),
    }


def x_bootstrap__mutmut_67(
    differences: np.ndarray, clusters: np.ndarray, *, by_cluster: bool, seed: int = SEED,
    draws: int = BOOTSTRAPS,
) -> dict[str, Any]:  # fmt: skip
    """Mean and median difference with percentile intervals and a two-sided bootstrap p-value."""
    rng = np.random.default_rng(seed)
    n = len(differences)
    labels = np.unique(clusters)
    members = [np.flatnonzero(clusters == label) for label in labels]
    means, medians = np.empty(draws), np.empty(draws)
    for index in range(draws):
        if by_cluster:
            picked = np.concatenate([members[i] for i in rng.integers(0, len(labels), len(labels))])
        else:
            picked = rng.integers(0, n, n)
        sample = differences[picked]
        means[index], medians[index] = sample.mean(), np.median(sample)
    below, above = float((means <= 0).mean()), float((means >= 0).mean())
    return {
        "units": int(len(labels) if by_cluster else n),
        "mean": float(differences.mean()),
        "mean_ci": _interval(means),
        "median": float(np.median(differences)),
        "median_ci": _interval(medians),
        "p_two_sided": float(min(1.0, 3 * min(below, above))),
    }


def x_bootstrap__mutmut_68(
    differences: np.ndarray, clusters: np.ndarray, *, by_cluster: bool, seed: int = SEED,
    draws: int = BOOTSTRAPS,
) -> dict[str, Any]:  # fmt: skip
    """Mean and median difference with percentile intervals and a two-sided bootstrap p-value."""
    rng = np.random.default_rng(seed)
    n = len(differences)
    labels = np.unique(clusters)
    members = [np.flatnonzero(clusters == label) for label in labels]
    means, medians = np.empty(draws), np.empty(draws)
    for index in range(draws):
        if by_cluster:
            picked = np.concatenate([members[i] for i in rng.integers(0, len(labels), len(labels))])
        else:
            picked = rng.integers(0, n, n)
        sample = differences[picked]
        means[index], medians[index] = sample.mean(), np.median(sample)
    below, above = float((means <= 0).mean()), float((means >= 0).mean())
    return {
        "units": int(len(labels) if by_cluster else n),
        "mean": float(differences.mean()),
        "mean_ci": _interval(means),
        "median": float(np.median(differences)),
        "median_ci": _interval(medians),
        "p_two_sided": float(min(1.0, 2 * min(None, above))),
    }


def x_bootstrap__mutmut_69(
    differences: np.ndarray, clusters: np.ndarray, *, by_cluster: bool, seed: int = SEED,
    draws: int = BOOTSTRAPS,
) -> dict[str, Any]:  # fmt: skip
    """Mean and median difference with percentile intervals and a two-sided bootstrap p-value."""
    rng = np.random.default_rng(seed)
    n = len(differences)
    labels = np.unique(clusters)
    members = [np.flatnonzero(clusters == label) for label in labels]
    means, medians = np.empty(draws), np.empty(draws)
    for index in range(draws):
        if by_cluster:
            picked = np.concatenate([members[i] for i in rng.integers(0, len(labels), len(labels))])
        else:
            picked = rng.integers(0, n, n)
        sample = differences[picked]
        means[index], medians[index] = sample.mean(), np.median(sample)
    below, above = float((means <= 0).mean()), float((means >= 0).mean())
    return {
        "units": int(len(labels) if by_cluster else n),
        "mean": float(differences.mean()),
        "mean_ci": _interval(means),
        "median": float(np.median(differences)),
        "median_ci": _interval(medians),
        "p_two_sided": float(min(1.0, 2 * min(below, None))),
    }


def x_bootstrap__mutmut_70(
    differences: np.ndarray, clusters: np.ndarray, *, by_cluster: bool, seed: int = SEED,
    draws: int = BOOTSTRAPS,
) -> dict[str, Any]:  # fmt: skip
    """Mean and median difference with percentile intervals and a two-sided bootstrap p-value."""
    rng = np.random.default_rng(seed)
    n = len(differences)
    labels = np.unique(clusters)
    members = [np.flatnonzero(clusters == label) for label in labels]
    means, medians = np.empty(draws), np.empty(draws)
    for index in range(draws):
        if by_cluster:
            picked = np.concatenate([members[i] for i in rng.integers(0, len(labels), len(labels))])
        else:
            picked = rng.integers(0, n, n)
        sample = differences[picked]
        means[index], medians[index] = sample.mean(), np.median(sample)
    below, above = float((means <= 0).mean()), float((means >= 0).mean())
    return {
        "units": int(len(labels) if by_cluster else n),
        "mean": float(differences.mean()),
        "mean_ci": _interval(means),
        "median": float(np.median(differences)),
        "median_ci": _interval(medians),
        "p_two_sided": float(min(1.0, 2 * min(above))),
    }


def x_bootstrap__mutmut_71(
    differences: np.ndarray, clusters: np.ndarray, *, by_cluster: bool, seed: int = SEED,
    draws: int = BOOTSTRAPS,
) -> dict[str, Any]:  # fmt: skip
    """Mean and median difference with percentile intervals and a two-sided bootstrap p-value."""
    rng = np.random.default_rng(seed)
    n = len(differences)
    labels = np.unique(clusters)
    members = [np.flatnonzero(clusters == label) for label in labels]
    means, medians = np.empty(draws), np.empty(draws)
    for index in range(draws):
        if by_cluster:
            picked = np.concatenate([members[i] for i in rng.integers(0, len(labels), len(labels))])
        else:
            picked = rng.integers(0, n, n)
        sample = differences[picked]
        means[index], medians[index] = sample.mean(), np.median(sample)
    below, above = float((means <= 0).mean()), float((means >= 0).mean())
    return {
        "units": int(len(labels) if by_cluster else n),
        "mean": float(differences.mean()),
        "mean_ci": _interval(means),
        "median": float(np.median(differences)),
        "median_ci": _interval(medians),
        "p_two_sided": float(min(1.0, 2 * min(below, ))),
    }

mutants_x_bootstrap__mutmut['_mutmut_orig'] = x_bootstrap__mutmut_orig # type: ignore # mutmut generated
mutants_x_bootstrap__mutmut['x_bootstrap__mutmut_1'] = x_bootstrap__mutmut_1 # type: ignore # mutmut generated
mutants_x_bootstrap__mutmut['x_bootstrap__mutmut_2'] = x_bootstrap__mutmut_2 # type: ignore # mutmut generated
mutants_x_bootstrap__mutmut['x_bootstrap__mutmut_3'] = x_bootstrap__mutmut_3 # type: ignore # mutmut generated
mutants_x_bootstrap__mutmut['x_bootstrap__mutmut_4'] = x_bootstrap__mutmut_4 # type: ignore # mutmut generated
mutants_x_bootstrap__mutmut['x_bootstrap__mutmut_5'] = x_bootstrap__mutmut_5 # type: ignore # mutmut generated
mutants_x_bootstrap__mutmut['x_bootstrap__mutmut_6'] = x_bootstrap__mutmut_6 # type: ignore # mutmut generated
mutants_x_bootstrap__mutmut['x_bootstrap__mutmut_7'] = x_bootstrap__mutmut_7 # type: ignore # mutmut generated
mutants_x_bootstrap__mutmut['x_bootstrap__mutmut_8'] = x_bootstrap__mutmut_8 # type: ignore # mutmut generated
mutants_x_bootstrap__mutmut['x_bootstrap__mutmut_9'] = x_bootstrap__mutmut_9 # type: ignore # mutmut generated
mutants_x_bootstrap__mutmut['x_bootstrap__mutmut_10'] = x_bootstrap__mutmut_10 # type: ignore # mutmut generated
mutants_x_bootstrap__mutmut['x_bootstrap__mutmut_11'] = x_bootstrap__mutmut_11 # type: ignore # mutmut generated
mutants_x_bootstrap__mutmut['x_bootstrap__mutmut_12'] = x_bootstrap__mutmut_12 # type: ignore # mutmut generated
mutants_x_bootstrap__mutmut['x_bootstrap__mutmut_13'] = x_bootstrap__mutmut_13 # type: ignore # mutmut generated
mutants_x_bootstrap__mutmut['x_bootstrap__mutmut_14'] = x_bootstrap__mutmut_14 # type: ignore # mutmut generated
mutants_x_bootstrap__mutmut['x_bootstrap__mutmut_15'] = x_bootstrap__mutmut_15 # type: ignore # mutmut generated
mutants_x_bootstrap__mutmut['x_bootstrap__mutmut_16'] = x_bootstrap__mutmut_16 # type: ignore # mutmut generated
mutants_x_bootstrap__mutmut['x_bootstrap__mutmut_17'] = x_bootstrap__mutmut_17 # type: ignore # mutmut generated
mutants_x_bootstrap__mutmut['x_bootstrap__mutmut_18'] = x_bootstrap__mutmut_18 # type: ignore # mutmut generated
mutants_x_bootstrap__mutmut['x_bootstrap__mutmut_19'] = x_bootstrap__mutmut_19 # type: ignore # mutmut generated
mutants_x_bootstrap__mutmut['x_bootstrap__mutmut_20'] = x_bootstrap__mutmut_20 # type: ignore # mutmut generated
mutants_x_bootstrap__mutmut['x_bootstrap__mutmut_21'] = x_bootstrap__mutmut_21 # type: ignore # mutmut generated
mutants_x_bootstrap__mutmut['x_bootstrap__mutmut_22'] = x_bootstrap__mutmut_22 # type: ignore # mutmut generated
mutants_x_bootstrap__mutmut['x_bootstrap__mutmut_23'] = x_bootstrap__mutmut_23 # type: ignore # mutmut generated
mutants_x_bootstrap__mutmut['x_bootstrap__mutmut_24'] = x_bootstrap__mutmut_24 # type: ignore # mutmut generated
mutants_x_bootstrap__mutmut['x_bootstrap__mutmut_25'] = x_bootstrap__mutmut_25 # type: ignore # mutmut generated
mutants_x_bootstrap__mutmut['x_bootstrap__mutmut_26'] = x_bootstrap__mutmut_26 # type: ignore # mutmut generated
mutants_x_bootstrap__mutmut['x_bootstrap__mutmut_27'] = x_bootstrap__mutmut_27 # type: ignore # mutmut generated
mutants_x_bootstrap__mutmut['x_bootstrap__mutmut_28'] = x_bootstrap__mutmut_28 # type: ignore # mutmut generated
mutants_x_bootstrap__mutmut['x_bootstrap__mutmut_29'] = x_bootstrap__mutmut_29 # type: ignore # mutmut generated
mutants_x_bootstrap__mutmut['x_bootstrap__mutmut_30'] = x_bootstrap__mutmut_30 # type: ignore # mutmut generated
mutants_x_bootstrap__mutmut['x_bootstrap__mutmut_31'] = x_bootstrap__mutmut_31 # type: ignore # mutmut generated
mutants_x_bootstrap__mutmut['x_bootstrap__mutmut_32'] = x_bootstrap__mutmut_32 # type: ignore # mutmut generated
mutants_x_bootstrap__mutmut['x_bootstrap__mutmut_33'] = x_bootstrap__mutmut_33 # type: ignore # mutmut generated
mutants_x_bootstrap__mutmut['x_bootstrap__mutmut_34'] = x_bootstrap__mutmut_34 # type: ignore # mutmut generated
mutants_x_bootstrap__mutmut['x_bootstrap__mutmut_35'] = x_bootstrap__mutmut_35 # type: ignore # mutmut generated
mutants_x_bootstrap__mutmut['x_bootstrap__mutmut_36'] = x_bootstrap__mutmut_36 # type: ignore # mutmut generated
mutants_x_bootstrap__mutmut['x_bootstrap__mutmut_37'] = x_bootstrap__mutmut_37 # type: ignore # mutmut generated
mutants_x_bootstrap__mutmut['x_bootstrap__mutmut_38'] = x_bootstrap__mutmut_38 # type: ignore # mutmut generated
mutants_x_bootstrap__mutmut['x_bootstrap__mutmut_39'] = x_bootstrap__mutmut_39 # type: ignore # mutmut generated
mutants_x_bootstrap__mutmut['x_bootstrap__mutmut_40'] = x_bootstrap__mutmut_40 # type: ignore # mutmut generated
mutants_x_bootstrap__mutmut['x_bootstrap__mutmut_41'] = x_bootstrap__mutmut_41 # type: ignore # mutmut generated
mutants_x_bootstrap__mutmut['x_bootstrap__mutmut_42'] = x_bootstrap__mutmut_42 # type: ignore # mutmut generated
mutants_x_bootstrap__mutmut['x_bootstrap__mutmut_43'] = x_bootstrap__mutmut_43 # type: ignore # mutmut generated
mutants_x_bootstrap__mutmut['x_bootstrap__mutmut_44'] = x_bootstrap__mutmut_44 # type: ignore # mutmut generated
mutants_x_bootstrap__mutmut['x_bootstrap__mutmut_45'] = x_bootstrap__mutmut_45 # type: ignore # mutmut generated
mutants_x_bootstrap__mutmut['x_bootstrap__mutmut_46'] = x_bootstrap__mutmut_46 # type: ignore # mutmut generated
mutants_x_bootstrap__mutmut['x_bootstrap__mutmut_47'] = x_bootstrap__mutmut_47 # type: ignore # mutmut generated
mutants_x_bootstrap__mutmut['x_bootstrap__mutmut_48'] = x_bootstrap__mutmut_48 # type: ignore # mutmut generated
mutants_x_bootstrap__mutmut['x_bootstrap__mutmut_49'] = x_bootstrap__mutmut_49 # type: ignore # mutmut generated
mutants_x_bootstrap__mutmut['x_bootstrap__mutmut_50'] = x_bootstrap__mutmut_50 # type: ignore # mutmut generated
mutants_x_bootstrap__mutmut['x_bootstrap__mutmut_51'] = x_bootstrap__mutmut_51 # type: ignore # mutmut generated
mutants_x_bootstrap__mutmut['x_bootstrap__mutmut_52'] = x_bootstrap__mutmut_52 # type: ignore # mutmut generated
mutants_x_bootstrap__mutmut['x_bootstrap__mutmut_53'] = x_bootstrap__mutmut_53 # type: ignore # mutmut generated
mutants_x_bootstrap__mutmut['x_bootstrap__mutmut_54'] = x_bootstrap__mutmut_54 # type: ignore # mutmut generated
mutants_x_bootstrap__mutmut['x_bootstrap__mutmut_55'] = x_bootstrap__mutmut_55 # type: ignore # mutmut generated
mutants_x_bootstrap__mutmut['x_bootstrap__mutmut_56'] = x_bootstrap__mutmut_56 # type: ignore # mutmut generated
mutants_x_bootstrap__mutmut['x_bootstrap__mutmut_57'] = x_bootstrap__mutmut_57 # type: ignore # mutmut generated
mutants_x_bootstrap__mutmut['x_bootstrap__mutmut_58'] = x_bootstrap__mutmut_58 # type: ignore # mutmut generated
mutants_x_bootstrap__mutmut['x_bootstrap__mutmut_59'] = x_bootstrap__mutmut_59 # type: ignore # mutmut generated
mutants_x_bootstrap__mutmut['x_bootstrap__mutmut_60'] = x_bootstrap__mutmut_60 # type: ignore # mutmut generated
mutants_x_bootstrap__mutmut['x_bootstrap__mutmut_61'] = x_bootstrap__mutmut_61 # type: ignore # mutmut generated
mutants_x_bootstrap__mutmut['x_bootstrap__mutmut_62'] = x_bootstrap__mutmut_62 # type: ignore # mutmut generated
mutants_x_bootstrap__mutmut['x_bootstrap__mutmut_63'] = x_bootstrap__mutmut_63 # type: ignore # mutmut generated
mutants_x_bootstrap__mutmut['x_bootstrap__mutmut_64'] = x_bootstrap__mutmut_64 # type: ignore # mutmut generated
mutants_x_bootstrap__mutmut['x_bootstrap__mutmut_65'] = x_bootstrap__mutmut_65 # type: ignore # mutmut generated
mutants_x_bootstrap__mutmut['x_bootstrap__mutmut_66'] = x_bootstrap__mutmut_66 # type: ignore # mutmut generated
mutants_x_bootstrap__mutmut['x_bootstrap__mutmut_67'] = x_bootstrap__mutmut_67 # type: ignore # mutmut generated
mutants_x_bootstrap__mutmut['x_bootstrap__mutmut_68'] = x_bootstrap__mutmut_68 # type: ignore # mutmut generated
mutants_x_bootstrap__mutmut['x_bootstrap__mutmut_69'] = x_bootstrap__mutmut_69 # type: ignore # mutmut generated
mutants_x_bootstrap__mutmut['x_bootstrap__mutmut_70'] = x_bootstrap__mutmut_70 # type: ignore # mutmut generated
mutants_x_bootstrap__mutmut['x_bootstrap__mutmut_71'] = x_bootstrap__mutmut_71 # type: ignore # mutmut generated
mutants_x_holm__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_holm__mutmut)
def holm(p_values: list[float]) -> list[float]:
    """Holm-Bonferroni adjusted p-values, in the input order."""
    order = np.argsort(p_values)
    adjusted = np.empty(len(p_values))
    running = 0.0
    for rank, index in enumerate(order):
        running = max(running, min(1.0, (len(p_values) - rank) * p_values[index]))
        adjusted[index] = running
    return adjusted.tolist()


def x_holm__mutmut_orig(p_values: list[float]) -> list[float]:
    """Holm-Bonferroni adjusted p-values, in the input order."""
    order = np.argsort(p_values)
    adjusted = np.empty(len(p_values))
    running = 0.0
    for rank, index in enumerate(order):
        running = max(running, min(1.0, (len(p_values) - rank) * p_values[index]))
        adjusted[index] = running
    return adjusted.tolist()


def x_holm__mutmut_1(p_values: list[float]) -> list[float]:
    """Holm-Bonferroni adjusted p-values, in the input order."""
    order = None
    adjusted = np.empty(len(p_values))
    running = 0.0
    for rank, index in enumerate(order):
        running = max(running, min(1.0, (len(p_values) - rank) * p_values[index]))
        adjusted[index] = running
    return adjusted.tolist()


def x_holm__mutmut_2(p_values: list[float]) -> list[float]:
    """Holm-Bonferroni adjusted p-values, in the input order."""
    order = np.argsort(None)
    adjusted = np.empty(len(p_values))
    running = 0.0
    for rank, index in enumerate(order):
        running = max(running, min(1.0, (len(p_values) - rank) * p_values[index]))
        adjusted[index] = running
    return adjusted.tolist()


def x_holm__mutmut_3(p_values: list[float]) -> list[float]:
    """Holm-Bonferroni adjusted p-values, in the input order."""
    order = np.argsort(p_values)
    adjusted = None
    running = 0.0
    for rank, index in enumerate(order):
        running = max(running, min(1.0, (len(p_values) - rank) * p_values[index]))
        adjusted[index] = running
    return adjusted.tolist()


def x_holm__mutmut_4(p_values: list[float]) -> list[float]:
    """Holm-Bonferroni adjusted p-values, in the input order."""
    order = np.argsort(p_values)
    adjusted = np.empty(None)
    running = 0.0
    for rank, index in enumerate(order):
        running = max(running, min(1.0, (len(p_values) - rank) * p_values[index]))
        adjusted[index] = running
    return adjusted.tolist()


def x_holm__mutmut_5(p_values: list[float]) -> list[float]:
    """Holm-Bonferroni adjusted p-values, in the input order."""
    order = np.argsort(p_values)
    adjusted = np.empty(len(p_values))
    running = None
    for rank, index in enumerate(order):
        running = max(running, min(1.0, (len(p_values) - rank) * p_values[index]))
        adjusted[index] = running
    return adjusted.tolist()


def x_holm__mutmut_6(p_values: list[float]) -> list[float]:
    """Holm-Bonferroni adjusted p-values, in the input order."""
    order = np.argsort(p_values)
    adjusted = np.empty(len(p_values))
    running = 1.0
    for rank, index in enumerate(order):
        running = max(running, min(1.0, (len(p_values) - rank) * p_values[index]))
        adjusted[index] = running
    return adjusted.tolist()


def x_holm__mutmut_7(p_values: list[float]) -> list[float]:
    """Holm-Bonferroni adjusted p-values, in the input order."""
    order = np.argsort(p_values)
    adjusted = np.empty(len(p_values))
    running = 0.0
    for rank, index in enumerate(None):
        running = max(running, min(1.0, (len(p_values) - rank) * p_values[index]))
        adjusted[index] = running
    return adjusted.tolist()


def x_holm__mutmut_8(p_values: list[float]) -> list[float]:
    """Holm-Bonferroni adjusted p-values, in the input order."""
    order = np.argsort(p_values)
    adjusted = np.empty(len(p_values))
    running = 0.0
    for rank, index in enumerate(order):
        running = None
        adjusted[index] = running
    return adjusted.tolist()


def x_holm__mutmut_9(p_values: list[float]) -> list[float]:
    """Holm-Bonferroni adjusted p-values, in the input order."""
    order = np.argsort(p_values)
    adjusted = np.empty(len(p_values))
    running = 0.0
    for rank, index in enumerate(order):
        running = max(None, min(1.0, (len(p_values) - rank) * p_values[index]))
        adjusted[index] = running
    return adjusted.tolist()


def x_holm__mutmut_10(p_values: list[float]) -> list[float]:
    """Holm-Bonferroni adjusted p-values, in the input order."""
    order = np.argsort(p_values)
    adjusted = np.empty(len(p_values))
    running = 0.0
    for rank, index in enumerate(order):
        running = max(running, None)
        adjusted[index] = running
    return adjusted.tolist()


def x_holm__mutmut_11(p_values: list[float]) -> list[float]:
    """Holm-Bonferroni adjusted p-values, in the input order."""
    order = np.argsort(p_values)
    adjusted = np.empty(len(p_values))
    running = 0.0
    for rank, index in enumerate(order):
        running = max(min(1.0, (len(p_values) - rank) * p_values[index]))
        adjusted[index] = running
    return adjusted.tolist()


def x_holm__mutmut_12(p_values: list[float]) -> list[float]:
    """Holm-Bonferroni adjusted p-values, in the input order."""
    order = np.argsort(p_values)
    adjusted = np.empty(len(p_values))
    running = 0.0
    for rank, index in enumerate(order):
        running = max(running, )
        adjusted[index] = running
    return adjusted.tolist()


def x_holm__mutmut_13(p_values: list[float]) -> list[float]:
    """Holm-Bonferroni adjusted p-values, in the input order."""
    order = np.argsort(p_values)
    adjusted = np.empty(len(p_values))
    running = 0.0
    for rank, index in enumerate(order):
        running = max(running, min(None, (len(p_values) - rank) * p_values[index]))
        adjusted[index] = running
    return adjusted.tolist()


def x_holm__mutmut_14(p_values: list[float]) -> list[float]:
    """Holm-Bonferroni adjusted p-values, in the input order."""
    order = np.argsort(p_values)
    adjusted = np.empty(len(p_values))
    running = 0.0
    for rank, index in enumerate(order):
        running = max(running, min(1.0, None))
        adjusted[index] = running
    return adjusted.tolist()


def x_holm__mutmut_15(p_values: list[float]) -> list[float]:
    """Holm-Bonferroni adjusted p-values, in the input order."""
    order = np.argsort(p_values)
    adjusted = np.empty(len(p_values))
    running = 0.0
    for rank, index in enumerate(order):
        running = max(running, min((len(p_values) - rank) * p_values[index]))
        adjusted[index] = running
    return adjusted.tolist()


def x_holm__mutmut_16(p_values: list[float]) -> list[float]:
    """Holm-Bonferroni adjusted p-values, in the input order."""
    order = np.argsort(p_values)
    adjusted = np.empty(len(p_values))
    running = 0.0
    for rank, index in enumerate(order):
        running = max(running, min(1.0, ))
        adjusted[index] = running
    return adjusted.tolist()


def x_holm__mutmut_17(p_values: list[float]) -> list[float]:
    """Holm-Bonferroni adjusted p-values, in the input order."""
    order = np.argsort(p_values)
    adjusted = np.empty(len(p_values))
    running = 0.0
    for rank, index in enumerate(order):
        running = max(running, min(2.0, (len(p_values) - rank) * p_values[index]))
        adjusted[index] = running
    return adjusted.tolist()


def x_holm__mutmut_18(p_values: list[float]) -> list[float]:
    """Holm-Bonferroni adjusted p-values, in the input order."""
    order = np.argsort(p_values)
    adjusted = np.empty(len(p_values))
    running = 0.0
    for rank, index in enumerate(order):
        running = max(running, min(1.0, (len(p_values) - rank) / p_values[index]))
        adjusted[index] = running
    return adjusted.tolist()


def x_holm__mutmut_19(p_values: list[float]) -> list[float]:
    """Holm-Bonferroni adjusted p-values, in the input order."""
    order = np.argsort(p_values)
    adjusted = np.empty(len(p_values))
    running = 0.0
    for rank, index in enumerate(order):
        running = max(running, min(1.0, (len(p_values) + rank) * p_values[index]))
        adjusted[index] = running
    return adjusted.tolist()


def x_holm__mutmut_20(p_values: list[float]) -> list[float]:
    """Holm-Bonferroni adjusted p-values, in the input order."""
    order = np.argsort(p_values)
    adjusted = np.empty(len(p_values))
    running = 0.0
    for rank, index in enumerate(order):
        running = max(running, min(1.0, (len(p_values) - rank) * p_values[index]))
        adjusted[index] = None
    return adjusted.tolist()

mutants_x_holm__mutmut['_mutmut_orig'] = x_holm__mutmut_orig # type: ignore # mutmut generated
mutants_x_holm__mutmut['x_holm__mutmut_1'] = x_holm__mutmut_1 # type: ignore # mutmut generated
mutants_x_holm__mutmut['x_holm__mutmut_2'] = x_holm__mutmut_2 # type: ignore # mutmut generated
mutants_x_holm__mutmut['x_holm__mutmut_3'] = x_holm__mutmut_3 # type: ignore # mutmut generated
mutants_x_holm__mutmut['x_holm__mutmut_4'] = x_holm__mutmut_4 # type: ignore # mutmut generated
mutants_x_holm__mutmut['x_holm__mutmut_5'] = x_holm__mutmut_5 # type: ignore # mutmut generated
mutants_x_holm__mutmut['x_holm__mutmut_6'] = x_holm__mutmut_6 # type: ignore # mutmut generated
mutants_x_holm__mutmut['x_holm__mutmut_7'] = x_holm__mutmut_7 # type: ignore # mutmut generated
mutants_x_holm__mutmut['x_holm__mutmut_8'] = x_holm__mutmut_8 # type: ignore # mutmut generated
mutants_x_holm__mutmut['x_holm__mutmut_9'] = x_holm__mutmut_9 # type: ignore # mutmut generated
mutants_x_holm__mutmut['x_holm__mutmut_10'] = x_holm__mutmut_10 # type: ignore # mutmut generated
mutants_x_holm__mutmut['x_holm__mutmut_11'] = x_holm__mutmut_11 # type: ignore # mutmut generated
mutants_x_holm__mutmut['x_holm__mutmut_12'] = x_holm__mutmut_12 # type: ignore # mutmut generated
mutants_x_holm__mutmut['x_holm__mutmut_13'] = x_holm__mutmut_13 # type: ignore # mutmut generated
mutants_x_holm__mutmut['x_holm__mutmut_14'] = x_holm__mutmut_14 # type: ignore # mutmut generated
mutants_x_holm__mutmut['x_holm__mutmut_15'] = x_holm__mutmut_15 # type: ignore # mutmut generated
mutants_x_holm__mutmut['x_holm__mutmut_16'] = x_holm__mutmut_16 # type: ignore # mutmut generated
mutants_x_holm__mutmut['x_holm__mutmut_17'] = x_holm__mutmut_17 # type: ignore # mutmut generated
mutants_x_holm__mutmut['x_holm__mutmut_18'] = x_holm__mutmut_18 # type: ignore # mutmut generated
mutants_x_holm__mutmut['x_holm__mutmut_19'] = x_holm__mutmut_19 # type: ignore # mutmut generated
mutants_x_holm__mutmut['x_holm__mutmut_20'] = x_holm__mutmut_20 # type: ignore # mutmut generated
mutants_x_analyse__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_analyse__mutmut)
def analyse(
    problems: list[str], table: dict[str, np.ndarray], *, draws: int | None = None
) -> dict[str, Any]:
    draws = BOOTSTRAPS if draws is None else draws
    sources = np.array([source_id(p) for p in problems])
    labelled_uci = {p for p in problems if p.startswith("uci:")}
    overlapping = np.array([
        p.startswith("adbench:") and source_id(p) in labelled_uci for p in problems
    ])  # fmt: skip
    results = []
    for first, second in COMPARISONS:
        both = ~np.isnan(table[first]) & ~np.isnan(table[second])
        differences = table[first][both] - table[second][both]
        entry: dict[str, Any] = {"comparison": f"{first} - {second}", "problems": int(both.sum())}
        entry["by_problem"] = bootstrap(differences, sources[both], by_cluster=False, draws=draws)
        entry["by_source"] = bootstrap(differences, sources[both], by_cluster=True, draws=draws)
        keep = both & ~overlapping
        entry["without_overlap"] = bootstrap(
            table[first][keep] - table[second][keep], sources[keep], by_cluster=True, draws=draws
        ) | {"problems": int(keep.sum())}
        results.append(entry)
    adjusted = holm([item["by_source"]["p_two_sided"] for item in results])
    for item, value in zip(results, adjusted, strict=True):
        item["holm_p_by_source"] = value
    return {
        "problems": len(problems),
        "sources": int(len(np.unique(sources))),
        "overlapping_adbench_problems": int(overlapping.sum()),
        "bootstraps": draws,
        "seed": SEED,
        "level": LEVEL,
        "comparisons": results,
    }


def x_analyse__mutmut_orig(
    problems: list[str], table: dict[str, np.ndarray], *, draws: int | None = None
) -> dict[str, Any]:
    draws = BOOTSTRAPS if draws is None else draws
    sources = np.array([source_id(p) for p in problems])
    labelled_uci = {p for p in problems if p.startswith("uci:")}
    overlapping = np.array([
        p.startswith("adbench:") and source_id(p) in labelled_uci for p in problems
    ])  # fmt: skip
    results = []
    for first, second in COMPARISONS:
        both = ~np.isnan(table[first]) & ~np.isnan(table[second])
        differences = table[first][both] - table[second][both]
        entry: dict[str, Any] = {"comparison": f"{first} - {second}", "problems": int(both.sum())}
        entry["by_problem"] = bootstrap(differences, sources[both], by_cluster=False, draws=draws)
        entry["by_source"] = bootstrap(differences, sources[both], by_cluster=True, draws=draws)
        keep = both & ~overlapping
        entry["without_overlap"] = bootstrap(
            table[first][keep] - table[second][keep], sources[keep], by_cluster=True, draws=draws
        ) | {"problems": int(keep.sum())}
        results.append(entry)
    adjusted = holm([item["by_source"]["p_two_sided"] for item in results])
    for item, value in zip(results, adjusted, strict=True):
        item["holm_p_by_source"] = value
    return {
        "problems": len(problems),
        "sources": int(len(np.unique(sources))),
        "overlapping_adbench_problems": int(overlapping.sum()),
        "bootstraps": draws,
        "seed": SEED,
        "level": LEVEL,
        "comparisons": results,
    }


def x_analyse__mutmut_1(
    problems: list[str], table: dict[str, np.ndarray], *, draws: int | None = None
) -> dict[str, Any]:
    draws = None
    sources = np.array([source_id(p) for p in problems])
    labelled_uci = {p for p in problems if p.startswith("uci:")}
    overlapping = np.array([
        p.startswith("adbench:") and source_id(p) in labelled_uci for p in problems
    ])  # fmt: skip
    results = []
    for first, second in COMPARISONS:
        both = ~np.isnan(table[first]) & ~np.isnan(table[second])
        differences = table[first][both] - table[second][both]
        entry: dict[str, Any] = {"comparison": f"{first} - {second}", "problems": int(both.sum())}
        entry["by_problem"] = bootstrap(differences, sources[both], by_cluster=False, draws=draws)
        entry["by_source"] = bootstrap(differences, sources[both], by_cluster=True, draws=draws)
        keep = both & ~overlapping
        entry["without_overlap"] = bootstrap(
            table[first][keep] - table[second][keep], sources[keep], by_cluster=True, draws=draws
        ) | {"problems": int(keep.sum())}
        results.append(entry)
    adjusted = holm([item["by_source"]["p_two_sided"] for item in results])
    for item, value in zip(results, adjusted, strict=True):
        item["holm_p_by_source"] = value
    return {
        "problems": len(problems),
        "sources": int(len(np.unique(sources))),
        "overlapping_adbench_problems": int(overlapping.sum()),
        "bootstraps": draws,
        "seed": SEED,
        "level": LEVEL,
        "comparisons": results,
    }


def x_analyse__mutmut_2(
    problems: list[str], table: dict[str, np.ndarray], *, draws: int | None = None
) -> dict[str, Any]:
    draws = BOOTSTRAPS if (draws is None) and False else draws
    sources = np.array([source_id(p) for p in problems])
    labelled_uci = {p for p in problems if p.startswith("uci:")}
    overlapping = np.array([
        p.startswith("adbench:") and source_id(p) in labelled_uci for p in problems
    ])  # fmt: skip
    results = []
    for first, second in COMPARISONS:
        both = ~np.isnan(table[first]) & ~np.isnan(table[second])
        differences = table[first][both] - table[second][both]
        entry: dict[str, Any] = {"comparison": f"{first} - {second}", "problems": int(both.sum())}
        entry["by_problem"] = bootstrap(differences, sources[both], by_cluster=False, draws=draws)
        entry["by_source"] = bootstrap(differences, sources[both], by_cluster=True, draws=draws)
        keep = both & ~overlapping
        entry["without_overlap"] = bootstrap(
            table[first][keep] - table[second][keep], sources[keep], by_cluster=True, draws=draws
        ) | {"problems": int(keep.sum())}
        results.append(entry)
    adjusted = holm([item["by_source"]["p_two_sided"] for item in results])
    for item, value in zip(results, adjusted, strict=True):
        item["holm_p_by_source"] = value
    return {
        "problems": len(problems),
        "sources": int(len(np.unique(sources))),
        "overlapping_adbench_problems": int(overlapping.sum()),
        "bootstraps": draws,
        "seed": SEED,
        "level": LEVEL,
        "comparisons": results,
    }


def x_analyse__mutmut_3(
    problems: list[str], table: dict[str, np.ndarray], *, draws: int | None = None
) -> dict[str, Any]:
    draws = BOOTSTRAPS if (draws is None) or True else draws
    sources = np.array([source_id(p) for p in problems])
    labelled_uci = {p for p in problems if p.startswith("uci:")}
    overlapping = np.array([
        p.startswith("adbench:") and source_id(p) in labelled_uci for p in problems
    ])  # fmt: skip
    results = []
    for first, second in COMPARISONS:
        both = ~np.isnan(table[first]) & ~np.isnan(table[second])
        differences = table[first][both] - table[second][both]
        entry: dict[str, Any] = {"comparison": f"{first} - {second}", "problems": int(both.sum())}
        entry["by_problem"] = bootstrap(differences, sources[both], by_cluster=False, draws=draws)
        entry["by_source"] = bootstrap(differences, sources[both], by_cluster=True, draws=draws)
        keep = both & ~overlapping
        entry["without_overlap"] = bootstrap(
            table[first][keep] - table[second][keep], sources[keep], by_cluster=True, draws=draws
        ) | {"problems": int(keep.sum())}
        results.append(entry)
    adjusted = holm([item["by_source"]["p_two_sided"] for item in results])
    for item, value in zip(results, adjusted, strict=True):
        item["holm_p_by_source"] = value
    return {
        "problems": len(problems),
        "sources": int(len(np.unique(sources))),
        "overlapping_adbench_problems": int(overlapping.sum()),
        "bootstraps": draws,
        "seed": SEED,
        "level": LEVEL,
        "comparisons": results,
    }


def x_analyse__mutmut_4(
    problems: list[str], table: dict[str, np.ndarray], *, draws: int | None = None
) -> dict[str, Any]:
    draws = BOOTSTRAPS if draws is not None else draws
    sources = np.array([source_id(p) for p in problems])
    labelled_uci = {p for p in problems if p.startswith("uci:")}
    overlapping = np.array([
        p.startswith("adbench:") and source_id(p) in labelled_uci for p in problems
    ])  # fmt: skip
    results = []
    for first, second in COMPARISONS:
        both = ~np.isnan(table[first]) & ~np.isnan(table[second])
        differences = table[first][both] - table[second][both]
        entry: dict[str, Any] = {"comparison": f"{first} - {second}", "problems": int(both.sum())}
        entry["by_problem"] = bootstrap(differences, sources[both], by_cluster=False, draws=draws)
        entry["by_source"] = bootstrap(differences, sources[both], by_cluster=True, draws=draws)
        keep = both & ~overlapping
        entry["without_overlap"] = bootstrap(
            table[first][keep] - table[second][keep], sources[keep], by_cluster=True, draws=draws
        ) | {"problems": int(keep.sum())}
        results.append(entry)
    adjusted = holm([item["by_source"]["p_two_sided"] for item in results])
    for item, value in zip(results, adjusted, strict=True):
        item["holm_p_by_source"] = value
    return {
        "problems": len(problems),
        "sources": int(len(np.unique(sources))),
        "overlapping_adbench_problems": int(overlapping.sum()),
        "bootstraps": draws,
        "seed": SEED,
        "level": LEVEL,
        "comparisons": results,
    }


def x_analyse__mutmut_5(
    problems: list[str], table: dict[str, np.ndarray], *, draws: int | None = None
) -> dict[str, Any]:
    draws = BOOTSTRAPS if draws is None else draws
    sources = None
    labelled_uci = {p for p in problems if p.startswith("uci:")}
    overlapping = np.array([
        p.startswith("adbench:") and source_id(p) in labelled_uci for p in problems
    ])  # fmt: skip
    results = []
    for first, second in COMPARISONS:
        both = ~np.isnan(table[first]) & ~np.isnan(table[second])
        differences = table[first][both] - table[second][both]
        entry: dict[str, Any] = {"comparison": f"{first} - {second}", "problems": int(both.sum())}
        entry["by_problem"] = bootstrap(differences, sources[both], by_cluster=False, draws=draws)
        entry["by_source"] = bootstrap(differences, sources[both], by_cluster=True, draws=draws)
        keep = both & ~overlapping
        entry["without_overlap"] = bootstrap(
            table[first][keep] - table[second][keep], sources[keep], by_cluster=True, draws=draws
        ) | {"problems": int(keep.sum())}
        results.append(entry)
    adjusted = holm([item["by_source"]["p_two_sided"] for item in results])
    for item, value in zip(results, adjusted, strict=True):
        item["holm_p_by_source"] = value
    return {
        "problems": len(problems),
        "sources": int(len(np.unique(sources))),
        "overlapping_adbench_problems": int(overlapping.sum()),
        "bootstraps": draws,
        "seed": SEED,
        "level": LEVEL,
        "comparisons": results,
    }


def x_analyse__mutmut_6(
    problems: list[str], table: dict[str, np.ndarray], *, draws: int | None = None
) -> dict[str, Any]:
    draws = BOOTSTRAPS if draws is None else draws
    sources = np.array(None)
    labelled_uci = {p for p in problems if p.startswith("uci:")}
    overlapping = np.array([
        p.startswith("adbench:") and source_id(p) in labelled_uci for p in problems
    ])  # fmt: skip
    results = []
    for first, second in COMPARISONS:
        both = ~np.isnan(table[first]) & ~np.isnan(table[second])
        differences = table[first][both] - table[second][both]
        entry: dict[str, Any] = {"comparison": f"{first} - {second}", "problems": int(both.sum())}
        entry["by_problem"] = bootstrap(differences, sources[both], by_cluster=False, draws=draws)
        entry["by_source"] = bootstrap(differences, sources[both], by_cluster=True, draws=draws)
        keep = both & ~overlapping
        entry["without_overlap"] = bootstrap(
            table[first][keep] - table[second][keep], sources[keep], by_cluster=True, draws=draws
        ) | {"problems": int(keep.sum())}
        results.append(entry)
    adjusted = holm([item["by_source"]["p_two_sided"] for item in results])
    for item, value in zip(results, adjusted, strict=True):
        item["holm_p_by_source"] = value
    return {
        "problems": len(problems),
        "sources": int(len(np.unique(sources))),
        "overlapping_adbench_problems": int(overlapping.sum()),
        "bootstraps": draws,
        "seed": SEED,
        "level": LEVEL,
        "comparisons": results,
    }


def x_analyse__mutmut_7(
    problems: list[str], table: dict[str, np.ndarray], *, draws: int | None = None
) -> dict[str, Any]:
    draws = BOOTSTRAPS if draws is None else draws
    sources = np.array([source_id(None) for p in problems])
    labelled_uci = {p for p in problems if p.startswith("uci:")}
    overlapping = np.array([
        p.startswith("adbench:") and source_id(p) in labelled_uci for p in problems
    ])  # fmt: skip
    results = []
    for first, second in COMPARISONS:
        both = ~np.isnan(table[first]) & ~np.isnan(table[second])
        differences = table[first][both] - table[second][both]
        entry: dict[str, Any] = {"comparison": f"{first} - {second}", "problems": int(both.sum())}
        entry["by_problem"] = bootstrap(differences, sources[both], by_cluster=False, draws=draws)
        entry["by_source"] = bootstrap(differences, sources[both], by_cluster=True, draws=draws)
        keep = both & ~overlapping
        entry["without_overlap"] = bootstrap(
            table[first][keep] - table[second][keep], sources[keep], by_cluster=True, draws=draws
        ) | {"problems": int(keep.sum())}
        results.append(entry)
    adjusted = holm([item["by_source"]["p_two_sided"] for item in results])
    for item, value in zip(results, adjusted, strict=True):
        item["holm_p_by_source"] = value
    return {
        "problems": len(problems),
        "sources": int(len(np.unique(sources))),
        "overlapping_adbench_problems": int(overlapping.sum()),
        "bootstraps": draws,
        "seed": SEED,
        "level": LEVEL,
        "comparisons": results,
    }


def x_analyse__mutmut_8(
    problems: list[str], table: dict[str, np.ndarray], *, draws: int | None = None
) -> dict[str, Any]:
    draws = BOOTSTRAPS if draws is None else draws
    sources = np.array([source_id(p) for p in problems])
    labelled_uci = None
    overlapping = np.array([
        p.startswith("adbench:") and source_id(p) in labelled_uci for p in problems
    ])  # fmt: skip
    results = []
    for first, second in COMPARISONS:
        both = ~np.isnan(table[first]) & ~np.isnan(table[second])
        differences = table[first][both] - table[second][both]
        entry: dict[str, Any] = {"comparison": f"{first} - {second}", "problems": int(both.sum())}
        entry["by_problem"] = bootstrap(differences, sources[both], by_cluster=False, draws=draws)
        entry["by_source"] = bootstrap(differences, sources[both], by_cluster=True, draws=draws)
        keep = both & ~overlapping
        entry["without_overlap"] = bootstrap(
            table[first][keep] - table[second][keep], sources[keep], by_cluster=True, draws=draws
        ) | {"problems": int(keep.sum())}
        results.append(entry)
    adjusted = holm([item["by_source"]["p_two_sided"] for item in results])
    for item, value in zip(results, adjusted, strict=True):
        item["holm_p_by_source"] = value
    return {
        "problems": len(problems),
        "sources": int(len(np.unique(sources))),
        "overlapping_adbench_problems": int(overlapping.sum()),
        "bootstraps": draws,
        "seed": SEED,
        "level": LEVEL,
        "comparisons": results,
    }


def x_analyse__mutmut_9(
    problems: list[str], table: dict[str, np.ndarray], *, draws: int | None = None
) -> dict[str, Any]:
    draws = BOOTSTRAPS if draws is None else draws
    sources = np.array([source_id(p) for p in problems])
    labelled_uci = {p for p in problems if p.startswith(None)}
    overlapping = np.array([
        p.startswith("adbench:") and source_id(p) in labelled_uci for p in problems
    ])  # fmt: skip
    results = []
    for first, second in COMPARISONS:
        both = ~np.isnan(table[first]) & ~np.isnan(table[second])
        differences = table[first][both] - table[second][both]
        entry: dict[str, Any] = {"comparison": f"{first} - {second}", "problems": int(both.sum())}
        entry["by_problem"] = bootstrap(differences, sources[both], by_cluster=False, draws=draws)
        entry["by_source"] = bootstrap(differences, sources[both], by_cluster=True, draws=draws)
        keep = both & ~overlapping
        entry["without_overlap"] = bootstrap(
            table[first][keep] - table[second][keep], sources[keep], by_cluster=True, draws=draws
        ) | {"problems": int(keep.sum())}
        results.append(entry)
    adjusted = holm([item["by_source"]["p_two_sided"] for item in results])
    for item, value in zip(results, adjusted, strict=True):
        item["holm_p_by_source"] = value
    return {
        "problems": len(problems),
        "sources": int(len(np.unique(sources))),
        "overlapping_adbench_problems": int(overlapping.sum()),
        "bootstraps": draws,
        "seed": SEED,
        "level": LEVEL,
        "comparisons": results,
    }


def x_analyse__mutmut_10(
    problems: list[str], table: dict[str, np.ndarray], *, draws: int | None = None
) -> dict[str, Any]:
    draws = BOOTSTRAPS if draws is None else draws
    sources = np.array([source_id(p) for p in problems])
    labelled_uci = {p for p in problems if p.startswith("XXuci:XX")}
    overlapping = np.array([
        p.startswith("adbench:") and source_id(p) in labelled_uci for p in problems
    ])  # fmt: skip
    results = []
    for first, second in COMPARISONS:
        both = ~np.isnan(table[first]) & ~np.isnan(table[second])
        differences = table[first][both] - table[second][both]
        entry: dict[str, Any] = {"comparison": f"{first} - {second}", "problems": int(both.sum())}
        entry["by_problem"] = bootstrap(differences, sources[both], by_cluster=False, draws=draws)
        entry["by_source"] = bootstrap(differences, sources[both], by_cluster=True, draws=draws)
        keep = both & ~overlapping
        entry["without_overlap"] = bootstrap(
            table[first][keep] - table[second][keep], sources[keep], by_cluster=True, draws=draws
        ) | {"problems": int(keep.sum())}
        results.append(entry)
    adjusted = holm([item["by_source"]["p_two_sided"] for item in results])
    for item, value in zip(results, adjusted, strict=True):
        item["holm_p_by_source"] = value
    return {
        "problems": len(problems),
        "sources": int(len(np.unique(sources))),
        "overlapping_adbench_problems": int(overlapping.sum()),
        "bootstraps": draws,
        "seed": SEED,
        "level": LEVEL,
        "comparisons": results,
    }


def x_analyse__mutmut_11(
    problems: list[str], table: dict[str, np.ndarray], *, draws: int | None = None
) -> dict[str, Any]:
    draws = BOOTSTRAPS if draws is None else draws
    sources = np.array([source_id(p) for p in problems])
    labelled_uci = {p for p in problems if p.startswith("UCI:")}
    overlapping = np.array([
        p.startswith("adbench:") and source_id(p) in labelled_uci for p in problems
    ])  # fmt: skip
    results = []
    for first, second in COMPARISONS:
        both = ~np.isnan(table[first]) & ~np.isnan(table[second])
        differences = table[first][both] - table[second][both]
        entry: dict[str, Any] = {"comparison": f"{first} - {second}", "problems": int(both.sum())}
        entry["by_problem"] = bootstrap(differences, sources[both], by_cluster=False, draws=draws)
        entry["by_source"] = bootstrap(differences, sources[both], by_cluster=True, draws=draws)
        keep = both & ~overlapping
        entry["without_overlap"] = bootstrap(
            table[first][keep] - table[second][keep], sources[keep], by_cluster=True, draws=draws
        ) | {"problems": int(keep.sum())}
        results.append(entry)
    adjusted = holm([item["by_source"]["p_two_sided"] for item in results])
    for item, value in zip(results, adjusted, strict=True):
        item["holm_p_by_source"] = value
    return {
        "problems": len(problems),
        "sources": int(len(np.unique(sources))),
        "overlapping_adbench_problems": int(overlapping.sum()),
        "bootstraps": draws,
        "seed": SEED,
        "level": LEVEL,
        "comparisons": results,
    }


def x_analyse__mutmut_12(
    problems: list[str], table: dict[str, np.ndarray], *, draws: int | None = None
) -> dict[str, Any]:
    draws = BOOTSTRAPS if draws is None else draws
    sources = np.array([source_id(p) for p in problems])
    labelled_uci = {p for p in problems if p.startswith("uci:")}
    overlapping = None  # fmt: skip
    results = []
    for first, second in COMPARISONS:
        both = ~np.isnan(table[first]) & ~np.isnan(table[second])
        differences = table[first][both] - table[second][both]
        entry: dict[str, Any] = {"comparison": f"{first} - {second}", "problems": int(both.sum())}
        entry["by_problem"] = bootstrap(differences, sources[both], by_cluster=False, draws=draws)
        entry["by_source"] = bootstrap(differences, sources[both], by_cluster=True, draws=draws)
        keep = both & ~overlapping
        entry["without_overlap"] = bootstrap(
            table[first][keep] - table[second][keep], sources[keep], by_cluster=True, draws=draws
        ) | {"problems": int(keep.sum())}
        results.append(entry)
    adjusted = holm([item["by_source"]["p_two_sided"] for item in results])
    for item, value in zip(results, adjusted, strict=True):
        item["holm_p_by_source"] = value
    return {
        "problems": len(problems),
        "sources": int(len(np.unique(sources))),
        "overlapping_adbench_problems": int(overlapping.sum()),
        "bootstraps": draws,
        "seed": SEED,
        "level": LEVEL,
        "comparisons": results,
    }


def x_analyse__mutmut_13(
    problems: list[str], table: dict[str, np.ndarray], *, draws: int | None = None
) -> dict[str, Any]:
    draws = BOOTSTRAPS if draws is None else draws
    sources = np.array([source_id(p) for p in problems])
    labelled_uci = {p for p in problems if p.startswith("uci:")}
    overlapping = np.array(None)  # fmt: skip
    results = []
    for first, second in COMPARISONS:
        both = ~np.isnan(table[first]) & ~np.isnan(table[second])
        differences = table[first][both] - table[second][both]
        entry: dict[str, Any] = {"comparison": f"{first} - {second}", "problems": int(both.sum())}
        entry["by_problem"] = bootstrap(differences, sources[both], by_cluster=False, draws=draws)
        entry["by_source"] = bootstrap(differences, sources[both], by_cluster=True, draws=draws)
        keep = both & ~overlapping
        entry["without_overlap"] = bootstrap(
            table[first][keep] - table[second][keep], sources[keep], by_cluster=True, draws=draws
        ) | {"problems": int(keep.sum())}
        results.append(entry)
    adjusted = holm([item["by_source"]["p_two_sided"] for item in results])
    for item, value in zip(results, adjusted, strict=True):
        item["holm_p_by_source"] = value
    return {
        "problems": len(problems),
        "sources": int(len(np.unique(sources))),
        "overlapping_adbench_problems": int(overlapping.sum()),
        "bootstraps": draws,
        "seed": SEED,
        "level": LEVEL,
        "comparisons": results,
    }


def x_analyse__mutmut_14(
    problems: list[str], table: dict[str, np.ndarray], *, draws: int | None = None
) -> dict[str, Any]:
    draws = BOOTSTRAPS if draws is None else draws
    sources = np.array([source_id(p) for p in problems])
    labelled_uci = {p for p in problems if p.startswith("uci:")}
    overlapping = np.array([
        p.startswith("adbench:") or source_id(p) in labelled_uci for p in problems
    ])  # fmt: skip
    results = []
    for first, second in COMPARISONS:
        both = ~np.isnan(table[first]) & ~np.isnan(table[second])
        differences = table[first][both] - table[second][both]
        entry: dict[str, Any] = {"comparison": f"{first} - {second}", "problems": int(both.sum())}
        entry["by_problem"] = bootstrap(differences, sources[both], by_cluster=False, draws=draws)
        entry["by_source"] = bootstrap(differences, sources[both], by_cluster=True, draws=draws)
        keep = both & ~overlapping
        entry["without_overlap"] = bootstrap(
            table[first][keep] - table[second][keep], sources[keep], by_cluster=True, draws=draws
        ) | {"problems": int(keep.sum())}
        results.append(entry)
    adjusted = holm([item["by_source"]["p_two_sided"] for item in results])
    for item, value in zip(results, adjusted, strict=True):
        item["holm_p_by_source"] = value
    return {
        "problems": len(problems),
        "sources": int(len(np.unique(sources))),
        "overlapping_adbench_problems": int(overlapping.sum()),
        "bootstraps": draws,
        "seed": SEED,
        "level": LEVEL,
        "comparisons": results,
    }


def x_analyse__mutmut_15(
    problems: list[str], table: dict[str, np.ndarray], *, draws: int | None = None
) -> dict[str, Any]:
    draws = BOOTSTRAPS if draws is None else draws
    sources = np.array([source_id(p) for p in problems])
    labelled_uci = {p for p in problems if p.startswith("uci:")}
    overlapping = np.array([
        p.startswith(None) and source_id(p) in labelled_uci for p in problems
    ])  # fmt: skip
    results = []
    for first, second in COMPARISONS:
        both = ~np.isnan(table[first]) & ~np.isnan(table[second])
        differences = table[first][both] - table[second][both]
        entry: dict[str, Any] = {"comparison": f"{first} - {second}", "problems": int(both.sum())}
        entry["by_problem"] = bootstrap(differences, sources[both], by_cluster=False, draws=draws)
        entry["by_source"] = bootstrap(differences, sources[both], by_cluster=True, draws=draws)
        keep = both & ~overlapping
        entry["without_overlap"] = bootstrap(
            table[first][keep] - table[second][keep], sources[keep], by_cluster=True, draws=draws
        ) | {"problems": int(keep.sum())}
        results.append(entry)
    adjusted = holm([item["by_source"]["p_two_sided"] for item in results])
    for item, value in zip(results, adjusted, strict=True):
        item["holm_p_by_source"] = value
    return {
        "problems": len(problems),
        "sources": int(len(np.unique(sources))),
        "overlapping_adbench_problems": int(overlapping.sum()),
        "bootstraps": draws,
        "seed": SEED,
        "level": LEVEL,
        "comparisons": results,
    }


def x_analyse__mutmut_16(
    problems: list[str], table: dict[str, np.ndarray], *, draws: int | None = None
) -> dict[str, Any]:
    draws = BOOTSTRAPS if draws is None else draws
    sources = np.array([source_id(p) for p in problems])
    labelled_uci = {p for p in problems if p.startswith("uci:")}
    overlapping = np.array([
        p.startswith("XXadbench:XX") and source_id(p) in labelled_uci for p in problems
    ])  # fmt: skip
    results = []
    for first, second in COMPARISONS:
        both = ~np.isnan(table[first]) & ~np.isnan(table[second])
        differences = table[first][both] - table[second][both]
        entry: dict[str, Any] = {"comparison": f"{first} - {second}", "problems": int(both.sum())}
        entry["by_problem"] = bootstrap(differences, sources[both], by_cluster=False, draws=draws)
        entry["by_source"] = bootstrap(differences, sources[both], by_cluster=True, draws=draws)
        keep = both & ~overlapping
        entry["without_overlap"] = bootstrap(
            table[first][keep] - table[second][keep], sources[keep], by_cluster=True, draws=draws
        ) | {"problems": int(keep.sum())}
        results.append(entry)
    adjusted = holm([item["by_source"]["p_two_sided"] for item in results])
    for item, value in zip(results, adjusted, strict=True):
        item["holm_p_by_source"] = value
    return {
        "problems": len(problems),
        "sources": int(len(np.unique(sources))),
        "overlapping_adbench_problems": int(overlapping.sum()),
        "bootstraps": draws,
        "seed": SEED,
        "level": LEVEL,
        "comparisons": results,
    }


def x_analyse__mutmut_17(
    problems: list[str], table: dict[str, np.ndarray], *, draws: int | None = None
) -> dict[str, Any]:
    draws = BOOTSTRAPS if draws is None else draws
    sources = np.array([source_id(p) for p in problems])
    labelled_uci = {p for p in problems if p.startswith("uci:")}
    overlapping = np.array([
        p.startswith("ADBENCH:") and source_id(p) in labelled_uci for p in problems
    ])  # fmt: skip
    results = []
    for first, second in COMPARISONS:
        both = ~np.isnan(table[first]) & ~np.isnan(table[second])
        differences = table[first][both] - table[second][both]
        entry: dict[str, Any] = {"comparison": f"{first} - {second}", "problems": int(both.sum())}
        entry["by_problem"] = bootstrap(differences, sources[both], by_cluster=False, draws=draws)
        entry["by_source"] = bootstrap(differences, sources[both], by_cluster=True, draws=draws)
        keep = both & ~overlapping
        entry["without_overlap"] = bootstrap(
            table[first][keep] - table[second][keep], sources[keep], by_cluster=True, draws=draws
        ) | {"problems": int(keep.sum())}
        results.append(entry)
    adjusted = holm([item["by_source"]["p_two_sided"] for item in results])
    for item, value in zip(results, adjusted, strict=True):
        item["holm_p_by_source"] = value
    return {
        "problems": len(problems),
        "sources": int(len(np.unique(sources))),
        "overlapping_adbench_problems": int(overlapping.sum()),
        "bootstraps": draws,
        "seed": SEED,
        "level": LEVEL,
        "comparisons": results,
    }


def x_analyse__mutmut_18(
    problems: list[str], table: dict[str, np.ndarray], *, draws: int | None = None
) -> dict[str, Any]:
    draws = BOOTSTRAPS if draws is None else draws
    sources = np.array([source_id(p) for p in problems])
    labelled_uci = {p for p in problems if p.startswith("uci:")}
    overlapping = np.array([
        p.startswith("adbench:") and source_id(None) in labelled_uci for p in problems
    ])  # fmt: skip
    results = []
    for first, second in COMPARISONS:
        both = ~np.isnan(table[first]) & ~np.isnan(table[second])
        differences = table[first][both] - table[second][both]
        entry: dict[str, Any] = {"comparison": f"{first} - {second}", "problems": int(both.sum())}
        entry["by_problem"] = bootstrap(differences, sources[both], by_cluster=False, draws=draws)
        entry["by_source"] = bootstrap(differences, sources[both], by_cluster=True, draws=draws)
        keep = both & ~overlapping
        entry["without_overlap"] = bootstrap(
            table[first][keep] - table[second][keep], sources[keep], by_cluster=True, draws=draws
        ) | {"problems": int(keep.sum())}
        results.append(entry)
    adjusted = holm([item["by_source"]["p_two_sided"] for item in results])
    for item, value in zip(results, adjusted, strict=True):
        item["holm_p_by_source"] = value
    return {
        "problems": len(problems),
        "sources": int(len(np.unique(sources))),
        "overlapping_adbench_problems": int(overlapping.sum()),
        "bootstraps": draws,
        "seed": SEED,
        "level": LEVEL,
        "comparisons": results,
    }


def x_analyse__mutmut_19(
    problems: list[str], table: dict[str, np.ndarray], *, draws: int | None = None
) -> dict[str, Any]:
    draws = BOOTSTRAPS if draws is None else draws
    sources = np.array([source_id(p) for p in problems])
    labelled_uci = {p for p in problems if p.startswith("uci:")}
    overlapping = np.array([
        p.startswith("adbench:") and source_id(p) not in labelled_uci for p in problems
    ])  # fmt: skip
    results = []
    for first, second in COMPARISONS:
        both = ~np.isnan(table[first]) & ~np.isnan(table[second])
        differences = table[first][both] - table[second][both]
        entry: dict[str, Any] = {"comparison": f"{first} - {second}", "problems": int(both.sum())}
        entry["by_problem"] = bootstrap(differences, sources[both], by_cluster=False, draws=draws)
        entry["by_source"] = bootstrap(differences, sources[both], by_cluster=True, draws=draws)
        keep = both & ~overlapping
        entry["without_overlap"] = bootstrap(
            table[first][keep] - table[second][keep], sources[keep], by_cluster=True, draws=draws
        ) | {"problems": int(keep.sum())}
        results.append(entry)
    adjusted = holm([item["by_source"]["p_two_sided"] for item in results])
    for item, value in zip(results, adjusted, strict=True):
        item["holm_p_by_source"] = value
    return {
        "problems": len(problems),
        "sources": int(len(np.unique(sources))),
        "overlapping_adbench_problems": int(overlapping.sum()),
        "bootstraps": draws,
        "seed": SEED,
        "level": LEVEL,
        "comparisons": results,
    }


def x_analyse__mutmut_20(
    problems: list[str], table: dict[str, np.ndarray], *, draws: int | None = None
) -> dict[str, Any]:
    draws = BOOTSTRAPS if draws is None else draws
    sources = np.array([source_id(p) for p in problems])
    labelled_uci = {p for p in problems if p.startswith("uci:")}
    overlapping = np.array([
        p.startswith("adbench:") and source_id(p) in labelled_uci for p in problems
    ])  # fmt: skip
    results = None
    for first, second in COMPARISONS:
        both = ~np.isnan(table[first]) & ~np.isnan(table[second])
        differences = table[first][both] - table[second][both]
        entry: dict[str, Any] = {"comparison": f"{first} - {second}", "problems": int(both.sum())}
        entry["by_problem"] = bootstrap(differences, sources[both], by_cluster=False, draws=draws)
        entry["by_source"] = bootstrap(differences, sources[both], by_cluster=True, draws=draws)
        keep = both & ~overlapping
        entry["without_overlap"] = bootstrap(
            table[first][keep] - table[second][keep], sources[keep], by_cluster=True, draws=draws
        ) | {"problems": int(keep.sum())}
        results.append(entry)
    adjusted = holm([item["by_source"]["p_two_sided"] for item in results])
    for item, value in zip(results, adjusted, strict=True):
        item["holm_p_by_source"] = value
    return {
        "problems": len(problems),
        "sources": int(len(np.unique(sources))),
        "overlapping_adbench_problems": int(overlapping.sum()),
        "bootstraps": draws,
        "seed": SEED,
        "level": LEVEL,
        "comparisons": results,
    }


def x_analyse__mutmut_21(
    problems: list[str], table: dict[str, np.ndarray], *, draws: int | None = None
) -> dict[str, Any]:
    draws = BOOTSTRAPS if draws is None else draws
    sources = np.array([source_id(p) for p in problems])
    labelled_uci = {p for p in problems if p.startswith("uci:")}
    overlapping = np.array([
        p.startswith("adbench:") and source_id(p) in labelled_uci for p in problems
    ])  # fmt: skip
    results = []
    for first, second in COMPARISONS:
        both = None
        differences = table[first][both] - table[second][both]
        entry: dict[str, Any] = {"comparison": f"{first} - {second}", "problems": int(both.sum())}
        entry["by_problem"] = bootstrap(differences, sources[both], by_cluster=False, draws=draws)
        entry["by_source"] = bootstrap(differences, sources[both], by_cluster=True, draws=draws)
        keep = both & ~overlapping
        entry["without_overlap"] = bootstrap(
            table[first][keep] - table[second][keep], sources[keep], by_cluster=True, draws=draws
        ) | {"problems": int(keep.sum())}
        results.append(entry)
    adjusted = holm([item["by_source"]["p_two_sided"] for item in results])
    for item, value in zip(results, adjusted, strict=True):
        item["holm_p_by_source"] = value
    return {
        "problems": len(problems),
        "sources": int(len(np.unique(sources))),
        "overlapping_adbench_problems": int(overlapping.sum()),
        "bootstraps": draws,
        "seed": SEED,
        "level": LEVEL,
        "comparisons": results,
    }


def x_analyse__mutmut_22(
    problems: list[str], table: dict[str, np.ndarray], *, draws: int | None = None
) -> dict[str, Any]:
    draws = BOOTSTRAPS if draws is None else draws
    sources = np.array([source_id(p) for p in problems])
    labelled_uci = {p for p in problems if p.startswith("uci:")}
    overlapping = np.array([
        p.startswith("adbench:") and source_id(p) in labelled_uci for p in problems
    ])  # fmt: skip
    results = []
    for first, second in COMPARISONS:
        both = ~np.isnan(table[first]) | ~np.isnan(table[second])
        differences = table[first][both] - table[second][both]
        entry: dict[str, Any] = {"comparison": f"{first} - {second}", "problems": int(both.sum())}
        entry["by_problem"] = bootstrap(differences, sources[both], by_cluster=False, draws=draws)
        entry["by_source"] = bootstrap(differences, sources[both], by_cluster=True, draws=draws)
        keep = both & ~overlapping
        entry["without_overlap"] = bootstrap(
            table[first][keep] - table[second][keep], sources[keep], by_cluster=True, draws=draws
        ) | {"problems": int(keep.sum())}
        results.append(entry)
    adjusted = holm([item["by_source"]["p_two_sided"] for item in results])
    for item, value in zip(results, adjusted, strict=True):
        item["holm_p_by_source"] = value
    return {
        "problems": len(problems),
        "sources": int(len(np.unique(sources))),
        "overlapping_adbench_problems": int(overlapping.sum()),
        "bootstraps": draws,
        "seed": SEED,
        "level": LEVEL,
        "comparisons": results,
    }


def x_analyse__mutmut_23(
    problems: list[str], table: dict[str, np.ndarray], *, draws: int | None = None
) -> dict[str, Any]:
    draws = BOOTSTRAPS if draws is None else draws
    sources = np.array([source_id(p) for p in problems])
    labelled_uci = {p for p in problems if p.startswith("uci:")}
    overlapping = np.array([
        p.startswith("adbench:") and source_id(p) in labelled_uci for p in problems
    ])  # fmt: skip
    results = []
    for first, second in COMPARISONS:
        both = np.isnan(table[first]) & ~np.isnan(table[second])
        differences = table[first][both] - table[second][both]
        entry: dict[str, Any] = {"comparison": f"{first} - {second}", "problems": int(both.sum())}
        entry["by_problem"] = bootstrap(differences, sources[both], by_cluster=False, draws=draws)
        entry["by_source"] = bootstrap(differences, sources[both], by_cluster=True, draws=draws)
        keep = both & ~overlapping
        entry["without_overlap"] = bootstrap(
            table[first][keep] - table[second][keep], sources[keep], by_cluster=True, draws=draws
        ) | {"problems": int(keep.sum())}
        results.append(entry)
    adjusted = holm([item["by_source"]["p_two_sided"] for item in results])
    for item, value in zip(results, adjusted, strict=True):
        item["holm_p_by_source"] = value
    return {
        "problems": len(problems),
        "sources": int(len(np.unique(sources))),
        "overlapping_adbench_problems": int(overlapping.sum()),
        "bootstraps": draws,
        "seed": SEED,
        "level": LEVEL,
        "comparisons": results,
    }


def x_analyse__mutmut_24(
    problems: list[str], table: dict[str, np.ndarray], *, draws: int | None = None
) -> dict[str, Any]:
    draws = BOOTSTRAPS if draws is None else draws
    sources = np.array([source_id(p) for p in problems])
    labelled_uci = {p for p in problems if p.startswith("uci:")}
    overlapping = np.array([
        p.startswith("adbench:") and source_id(p) in labelled_uci for p in problems
    ])  # fmt: skip
    results = []
    for first, second in COMPARISONS:
        both = ~np.isnan(None) & ~np.isnan(table[second])
        differences = table[first][both] - table[second][both]
        entry: dict[str, Any] = {"comparison": f"{first} - {second}", "problems": int(both.sum())}
        entry["by_problem"] = bootstrap(differences, sources[both], by_cluster=False, draws=draws)
        entry["by_source"] = bootstrap(differences, sources[both], by_cluster=True, draws=draws)
        keep = both & ~overlapping
        entry["without_overlap"] = bootstrap(
            table[first][keep] - table[second][keep], sources[keep], by_cluster=True, draws=draws
        ) | {"problems": int(keep.sum())}
        results.append(entry)
    adjusted = holm([item["by_source"]["p_two_sided"] for item in results])
    for item, value in zip(results, adjusted, strict=True):
        item["holm_p_by_source"] = value
    return {
        "problems": len(problems),
        "sources": int(len(np.unique(sources))),
        "overlapping_adbench_problems": int(overlapping.sum()),
        "bootstraps": draws,
        "seed": SEED,
        "level": LEVEL,
        "comparisons": results,
    }


def x_analyse__mutmut_25(
    problems: list[str], table: dict[str, np.ndarray], *, draws: int | None = None
) -> dict[str, Any]:
    draws = BOOTSTRAPS if draws is None else draws
    sources = np.array([source_id(p) for p in problems])
    labelled_uci = {p for p in problems if p.startswith("uci:")}
    overlapping = np.array([
        p.startswith("adbench:") and source_id(p) in labelled_uci for p in problems
    ])  # fmt: skip
    results = []
    for first, second in COMPARISONS:
        both = ~np.isnan(table[first]) & np.isnan(table[second])
        differences = table[first][both] - table[second][both]
        entry: dict[str, Any] = {"comparison": f"{first} - {second}", "problems": int(both.sum())}
        entry["by_problem"] = bootstrap(differences, sources[both], by_cluster=False, draws=draws)
        entry["by_source"] = bootstrap(differences, sources[both], by_cluster=True, draws=draws)
        keep = both & ~overlapping
        entry["without_overlap"] = bootstrap(
            table[first][keep] - table[second][keep], sources[keep], by_cluster=True, draws=draws
        ) | {"problems": int(keep.sum())}
        results.append(entry)
    adjusted = holm([item["by_source"]["p_two_sided"] for item in results])
    for item, value in zip(results, adjusted, strict=True):
        item["holm_p_by_source"] = value
    return {
        "problems": len(problems),
        "sources": int(len(np.unique(sources))),
        "overlapping_adbench_problems": int(overlapping.sum()),
        "bootstraps": draws,
        "seed": SEED,
        "level": LEVEL,
        "comparisons": results,
    }


def x_analyse__mutmut_26(
    problems: list[str], table: dict[str, np.ndarray], *, draws: int | None = None
) -> dict[str, Any]:
    draws = BOOTSTRAPS if draws is None else draws
    sources = np.array([source_id(p) for p in problems])
    labelled_uci = {p for p in problems if p.startswith("uci:")}
    overlapping = np.array([
        p.startswith("adbench:") and source_id(p) in labelled_uci for p in problems
    ])  # fmt: skip
    results = []
    for first, second in COMPARISONS:
        both = ~np.isnan(table[first]) & ~np.isnan(None)
        differences = table[first][both] - table[second][both]
        entry: dict[str, Any] = {"comparison": f"{first} - {second}", "problems": int(both.sum())}
        entry["by_problem"] = bootstrap(differences, sources[both], by_cluster=False, draws=draws)
        entry["by_source"] = bootstrap(differences, sources[both], by_cluster=True, draws=draws)
        keep = both & ~overlapping
        entry["without_overlap"] = bootstrap(
            table[first][keep] - table[second][keep], sources[keep], by_cluster=True, draws=draws
        ) | {"problems": int(keep.sum())}
        results.append(entry)
    adjusted = holm([item["by_source"]["p_two_sided"] for item in results])
    for item, value in zip(results, adjusted, strict=True):
        item["holm_p_by_source"] = value
    return {
        "problems": len(problems),
        "sources": int(len(np.unique(sources))),
        "overlapping_adbench_problems": int(overlapping.sum()),
        "bootstraps": draws,
        "seed": SEED,
        "level": LEVEL,
        "comparisons": results,
    }


def x_analyse__mutmut_27(
    problems: list[str], table: dict[str, np.ndarray], *, draws: int | None = None
) -> dict[str, Any]:
    draws = BOOTSTRAPS if draws is None else draws
    sources = np.array([source_id(p) for p in problems])
    labelled_uci = {p for p in problems if p.startswith("uci:")}
    overlapping = np.array([
        p.startswith("adbench:") and source_id(p) in labelled_uci for p in problems
    ])  # fmt: skip
    results = []
    for first, second in COMPARISONS:
        both = ~np.isnan(table[first]) & ~np.isnan(table[second])
        differences = None
        entry: dict[str, Any] = {"comparison": f"{first} - {second}", "problems": int(both.sum())}
        entry["by_problem"] = bootstrap(differences, sources[both], by_cluster=False, draws=draws)
        entry["by_source"] = bootstrap(differences, sources[both], by_cluster=True, draws=draws)
        keep = both & ~overlapping
        entry["without_overlap"] = bootstrap(
            table[first][keep] - table[second][keep], sources[keep], by_cluster=True, draws=draws
        ) | {"problems": int(keep.sum())}
        results.append(entry)
    adjusted = holm([item["by_source"]["p_two_sided"] for item in results])
    for item, value in zip(results, adjusted, strict=True):
        item["holm_p_by_source"] = value
    return {
        "problems": len(problems),
        "sources": int(len(np.unique(sources))),
        "overlapping_adbench_problems": int(overlapping.sum()),
        "bootstraps": draws,
        "seed": SEED,
        "level": LEVEL,
        "comparisons": results,
    }


def x_analyse__mutmut_28(
    problems: list[str], table: dict[str, np.ndarray], *, draws: int | None = None
) -> dict[str, Any]:
    draws = BOOTSTRAPS if draws is None else draws
    sources = np.array([source_id(p) for p in problems])
    labelled_uci = {p for p in problems if p.startswith("uci:")}
    overlapping = np.array([
        p.startswith("adbench:") and source_id(p) in labelled_uci for p in problems
    ])  # fmt: skip
    results = []
    for first, second in COMPARISONS:
        both = ~np.isnan(table[first]) & ~np.isnan(table[second])
        differences = table[first][both] + table[second][both]
        entry: dict[str, Any] = {"comparison": f"{first} - {second}", "problems": int(both.sum())}
        entry["by_problem"] = bootstrap(differences, sources[both], by_cluster=False, draws=draws)
        entry["by_source"] = bootstrap(differences, sources[both], by_cluster=True, draws=draws)
        keep = both & ~overlapping
        entry["without_overlap"] = bootstrap(
            table[first][keep] - table[second][keep], sources[keep], by_cluster=True, draws=draws
        ) | {"problems": int(keep.sum())}
        results.append(entry)
    adjusted = holm([item["by_source"]["p_two_sided"] for item in results])
    for item, value in zip(results, adjusted, strict=True):
        item["holm_p_by_source"] = value
    return {
        "problems": len(problems),
        "sources": int(len(np.unique(sources))),
        "overlapping_adbench_problems": int(overlapping.sum()),
        "bootstraps": draws,
        "seed": SEED,
        "level": LEVEL,
        "comparisons": results,
    }


def x_analyse__mutmut_29(
    problems: list[str], table: dict[str, np.ndarray], *, draws: int | None = None
) -> dict[str, Any]:
    draws = BOOTSTRAPS if draws is None else draws
    sources = np.array([source_id(p) for p in problems])
    labelled_uci = {p for p in problems if p.startswith("uci:")}
    overlapping = np.array([
        p.startswith("adbench:") and source_id(p) in labelled_uci for p in problems
    ])  # fmt: skip
    results = []
    for first, second in COMPARISONS:
        both = ~np.isnan(table[first]) & ~np.isnan(table[second])
        differences = table[first][both] - table[second][both]
        entry: dict[str, Any] = None
        entry["by_problem"] = bootstrap(differences, sources[both], by_cluster=False, draws=draws)
        entry["by_source"] = bootstrap(differences, sources[both], by_cluster=True, draws=draws)
        keep = both & ~overlapping
        entry["without_overlap"] = bootstrap(
            table[first][keep] - table[second][keep], sources[keep], by_cluster=True, draws=draws
        ) | {"problems": int(keep.sum())}
        results.append(entry)
    adjusted = holm([item["by_source"]["p_two_sided"] for item in results])
    for item, value in zip(results, adjusted, strict=True):
        item["holm_p_by_source"] = value
    return {
        "problems": len(problems),
        "sources": int(len(np.unique(sources))),
        "overlapping_adbench_problems": int(overlapping.sum()),
        "bootstraps": draws,
        "seed": SEED,
        "level": LEVEL,
        "comparisons": results,
    }


def x_analyse__mutmut_30(
    problems: list[str], table: dict[str, np.ndarray], *, draws: int | None = None
) -> dict[str, Any]:
    draws = BOOTSTRAPS if draws is None else draws
    sources = np.array([source_id(p) for p in problems])
    labelled_uci = {p for p in problems if p.startswith("uci:")}
    overlapping = np.array([
        p.startswith("adbench:") and source_id(p) in labelled_uci for p in problems
    ])  # fmt: skip
    results = []
    for first, second in COMPARISONS:
        both = ~np.isnan(table[first]) & ~np.isnan(table[second])
        differences = table[first][both] - table[second][both]
        entry: dict[str, Any] = {"XXcomparisonXX": f"{first} - {second}", "problems": int(both.sum())}
        entry["by_problem"] = bootstrap(differences, sources[both], by_cluster=False, draws=draws)
        entry["by_source"] = bootstrap(differences, sources[both], by_cluster=True, draws=draws)
        keep = both & ~overlapping
        entry["without_overlap"] = bootstrap(
            table[first][keep] - table[second][keep], sources[keep], by_cluster=True, draws=draws
        ) | {"problems": int(keep.sum())}
        results.append(entry)
    adjusted = holm([item["by_source"]["p_two_sided"] for item in results])
    for item, value in zip(results, adjusted, strict=True):
        item["holm_p_by_source"] = value
    return {
        "problems": len(problems),
        "sources": int(len(np.unique(sources))),
        "overlapping_adbench_problems": int(overlapping.sum()),
        "bootstraps": draws,
        "seed": SEED,
        "level": LEVEL,
        "comparisons": results,
    }


def x_analyse__mutmut_31(
    problems: list[str], table: dict[str, np.ndarray], *, draws: int | None = None
) -> dict[str, Any]:
    draws = BOOTSTRAPS if draws is None else draws
    sources = np.array([source_id(p) for p in problems])
    labelled_uci = {p for p in problems if p.startswith("uci:")}
    overlapping = np.array([
        p.startswith("adbench:") and source_id(p) in labelled_uci for p in problems
    ])  # fmt: skip
    results = []
    for first, second in COMPARISONS:
        both = ~np.isnan(table[first]) & ~np.isnan(table[second])
        differences = table[first][both] - table[second][both]
        entry: dict[str, Any] = {"COMPARISON": f"{first} - {second}", "problems": int(both.sum())}
        entry["by_problem"] = bootstrap(differences, sources[both], by_cluster=False, draws=draws)
        entry["by_source"] = bootstrap(differences, sources[both], by_cluster=True, draws=draws)
        keep = both & ~overlapping
        entry["without_overlap"] = bootstrap(
            table[first][keep] - table[second][keep], sources[keep], by_cluster=True, draws=draws
        ) | {"problems": int(keep.sum())}
        results.append(entry)
    adjusted = holm([item["by_source"]["p_two_sided"] for item in results])
    for item, value in zip(results, adjusted, strict=True):
        item["holm_p_by_source"] = value
    return {
        "problems": len(problems),
        "sources": int(len(np.unique(sources))),
        "overlapping_adbench_problems": int(overlapping.sum()),
        "bootstraps": draws,
        "seed": SEED,
        "level": LEVEL,
        "comparisons": results,
    }


def x_analyse__mutmut_32(
    problems: list[str], table: dict[str, np.ndarray], *, draws: int | None = None
) -> dict[str, Any]:
    draws = BOOTSTRAPS if draws is None else draws
    sources = np.array([source_id(p) for p in problems])
    labelled_uci = {p for p in problems if p.startswith("uci:")}
    overlapping = np.array([
        p.startswith("adbench:") and source_id(p) in labelled_uci for p in problems
    ])  # fmt: skip
    results = []
    for first, second in COMPARISONS:
        both = ~np.isnan(table[first]) & ~np.isnan(table[second])
        differences = table[first][both] - table[second][both]
        entry: dict[str, Any] = {"comparison": f"{first} - {second}", "XXproblemsXX": int(both.sum())}
        entry["by_problem"] = bootstrap(differences, sources[both], by_cluster=False, draws=draws)
        entry["by_source"] = bootstrap(differences, sources[both], by_cluster=True, draws=draws)
        keep = both & ~overlapping
        entry["without_overlap"] = bootstrap(
            table[first][keep] - table[second][keep], sources[keep], by_cluster=True, draws=draws
        ) | {"problems": int(keep.sum())}
        results.append(entry)
    adjusted = holm([item["by_source"]["p_two_sided"] for item in results])
    for item, value in zip(results, adjusted, strict=True):
        item["holm_p_by_source"] = value
    return {
        "problems": len(problems),
        "sources": int(len(np.unique(sources))),
        "overlapping_adbench_problems": int(overlapping.sum()),
        "bootstraps": draws,
        "seed": SEED,
        "level": LEVEL,
        "comparisons": results,
    }


def x_analyse__mutmut_33(
    problems: list[str], table: dict[str, np.ndarray], *, draws: int | None = None
) -> dict[str, Any]:
    draws = BOOTSTRAPS if draws is None else draws
    sources = np.array([source_id(p) for p in problems])
    labelled_uci = {p for p in problems if p.startswith("uci:")}
    overlapping = np.array([
        p.startswith("adbench:") and source_id(p) in labelled_uci for p in problems
    ])  # fmt: skip
    results = []
    for first, second in COMPARISONS:
        both = ~np.isnan(table[first]) & ~np.isnan(table[second])
        differences = table[first][both] - table[second][both]
        entry: dict[str, Any] = {"comparison": f"{first} - {second}", "PROBLEMS": int(both.sum())}
        entry["by_problem"] = bootstrap(differences, sources[both], by_cluster=False, draws=draws)
        entry["by_source"] = bootstrap(differences, sources[both], by_cluster=True, draws=draws)
        keep = both & ~overlapping
        entry["without_overlap"] = bootstrap(
            table[first][keep] - table[second][keep], sources[keep], by_cluster=True, draws=draws
        ) | {"problems": int(keep.sum())}
        results.append(entry)
    adjusted = holm([item["by_source"]["p_two_sided"] for item in results])
    for item, value in zip(results, adjusted, strict=True):
        item["holm_p_by_source"] = value
    return {
        "problems": len(problems),
        "sources": int(len(np.unique(sources))),
        "overlapping_adbench_problems": int(overlapping.sum()),
        "bootstraps": draws,
        "seed": SEED,
        "level": LEVEL,
        "comparisons": results,
    }


def x_analyse__mutmut_34(
    problems: list[str], table: dict[str, np.ndarray], *, draws: int | None = None
) -> dict[str, Any]:
    draws = BOOTSTRAPS if draws is None else draws
    sources = np.array([source_id(p) for p in problems])
    labelled_uci = {p for p in problems if p.startswith("uci:")}
    overlapping = np.array([
        p.startswith("adbench:") and source_id(p) in labelled_uci for p in problems
    ])  # fmt: skip
    results = []
    for first, second in COMPARISONS:
        both = ~np.isnan(table[first]) & ~np.isnan(table[second])
        differences = table[first][both] - table[second][both]
        entry: dict[str, Any] = {"comparison": f"{first} - {second}", "problems": int(None)}
        entry["by_problem"] = bootstrap(differences, sources[both], by_cluster=False, draws=draws)
        entry["by_source"] = bootstrap(differences, sources[both], by_cluster=True, draws=draws)
        keep = both & ~overlapping
        entry["without_overlap"] = bootstrap(
            table[first][keep] - table[second][keep], sources[keep], by_cluster=True, draws=draws
        ) | {"problems": int(keep.sum())}
        results.append(entry)
    adjusted = holm([item["by_source"]["p_two_sided"] for item in results])
    for item, value in zip(results, adjusted, strict=True):
        item["holm_p_by_source"] = value
    return {
        "problems": len(problems),
        "sources": int(len(np.unique(sources))),
        "overlapping_adbench_problems": int(overlapping.sum()),
        "bootstraps": draws,
        "seed": SEED,
        "level": LEVEL,
        "comparisons": results,
    }


def x_analyse__mutmut_35(
    problems: list[str], table: dict[str, np.ndarray], *, draws: int | None = None
) -> dict[str, Any]:
    draws = BOOTSTRAPS if draws is None else draws
    sources = np.array([source_id(p) for p in problems])
    labelled_uci = {p for p in problems if p.startswith("uci:")}
    overlapping = np.array([
        p.startswith("adbench:") and source_id(p) in labelled_uci for p in problems
    ])  # fmt: skip
    results = []
    for first, second in COMPARISONS:
        both = ~np.isnan(table[first]) & ~np.isnan(table[second])
        differences = table[first][both] - table[second][both]
        entry: dict[str, Any] = {"comparison": f"{first} - {second}", "problems": int(both.sum())}
        entry["by_problem"] = None
        entry["by_source"] = bootstrap(differences, sources[both], by_cluster=True, draws=draws)
        keep = both & ~overlapping
        entry["without_overlap"] = bootstrap(
            table[first][keep] - table[second][keep], sources[keep], by_cluster=True, draws=draws
        ) | {"problems": int(keep.sum())}
        results.append(entry)
    adjusted = holm([item["by_source"]["p_two_sided"] for item in results])
    for item, value in zip(results, adjusted, strict=True):
        item["holm_p_by_source"] = value
    return {
        "problems": len(problems),
        "sources": int(len(np.unique(sources))),
        "overlapping_adbench_problems": int(overlapping.sum()),
        "bootstraps": draws,
        "seed": SEED,
        "level": LEVEL,
        "comparisons": results,
    }


def x_analyse__mutmut_36(
    problems: list[str], table: dict[str, np.ndarray], *, draws: int | None = None
) -> dict[str, Any]:
    draws = BOOTSTRAPS if draws is None else draws
    sources = np.array([source_id(p) for p in problems])
    labelled_uci = {p for p in problems if p.startswith("uci:")}
    overlapping = np.array([
        p.startswith("adbench:") and source_id(p) in labelled_uci for p in problems
    ])  # fmt: skip
    results = []
    for first, second in COMPARISONS:
        both = ~np.isnan(table[first]) & ~np.isnan(table[second])
        differences = table[first][both] - table[second][both]
        entry: dict[str, Any] = {"comparison": f"{first} - {second}", "problems": int(both.sum())}
        entry["XXby_problemXX"] = bootstrap(differences, sources[both], by_cluster=False, draws=draws)
        entry["by_source"] = bootstrap(differences, sources[both], by_cluster=True, draws=draws)
        keep = both & ~overlapping
        entry["without_overlap"] = bootstrap(
            table[first][keep] - table[second][keep], sources[keep], by_cluster=True, draws=draws
        ) | {"problems": int(keep.sum())}
        results.append(entry)
    adjusted = holm([item["by_source"]["p_two_sided"] for item in results])
    for item, value in zip(results, adjusted, strict=True):
        item["holm_p_by_source"] = value
    return {
        "problems": len(problems),
        "sources": int(len(np.unique(sources))),
        "overlapping_adbench_problems": int(overlapping.sum()),
        "bootstraps": draws,
        "seed": SEED,
        "level": LEVEL,
        "comparisons": results,
    }


def x_analyse__mutmut_37(
    problems: list[str], table: dict[str, np.ndarray], *, draws: int | None = None
) -> dict[str, Any]:
    draws = BOOTSTRAPS if draws is None else draws
    sources = np.array([source_id(p) for p in problems])
    labelled_uci = {p for p in problems if p.startswith("uci:")}
    overlapping = np.array([
        p.startswith("adbench:") and source_id(p) in labelled_uci for p in problems
    ])  # fmt: skip
    results = []
    for first, second in COMPARISONS:
        both = ~np.isnan(table[first]) & ~np.isnan(table[second])
        differences = table[first][both] - table[second][both]
        entry: dict[str, Any] = {"comparison": f"{first} - {second}", "problems": int(both.sum())}
        entry["BY_PROBLEM"] = bootstrap(differences, sources[both], by_cluster=False, draws=draws)
        entry["by_source"] = bootstrap(differences, sources[both], by_cluster=True, draws=draws)
        keep = both & ~overlapping
        entry["without_overlap"] = bootstrap(
            table[first][keep] - table[second][keep], sources[keep], by_cluster=True, draws=draws
        ) | {"problems": int(keep.sum())}
        results.append(entry)
    adjusted = holm([item["by_source"]["p_two_sided"] for item in results])
    for item, value in zip(results, adjusted, strict=True):
        item["holm_p_by_source"] = value
    return {
        "problems": len(problems),
        "sources": int(len(np.unique(sources))),
        "overlapping_adbench_problems": int(overlapping.sum()),
        "bootstraps": draws,
        "seed": SEED,
        "level": LEVEL,
        "comparisons": results,
    }


def x_analyse__mutmut_38(
    problems: list[str], table: dict[str, np.ndarray], *, draws: int | None = None
) -> dict[str, Any]:
    draws = BOOTSTRAPS if draws is None else draws
    sources = np.array([source_id(p) for p in problems])
    labelled_uci = {p for p in problems if p.startswith("uci:")}
    overlapping = np.array([
        p.startswith("adbench:") and source_id(p) in labelled_uci for p in problems
    ])  # fmt: skip
    results = []
    for first, second in COMPARISONS:
        both = ~np.isnan(table[first]) & ~np.isnan(table[second])
        differences = table[first][both] - table[second][both]
        entry: dict[str, Any] = {"comparison": f"{first} - {second}", "problems": int(both.sum())}
        entry["by_problem"] = bootstrap(None, sources[both], by_cluster=False, draws=draws)
        entry["by_source"] = bootstrap(differences, sources[both], by_cluster=True, draws=draws)
        keep = both & ~overlapping
        entry["without_overlap"] = bootstrap(
            table[first][keep] - table[second][keep], sources[keep], by_cluster=True, draws=draws
        ) | {"problems": int(keep.sum())}
        results.append(entry)
    adjusted = holm([item["by_source"]["p_two_sided"] for item in results])
    for item, value in zip(results, adjusted, strict=True):
        item["holm_p_by_source"] = value
    return {
        "problems": len(problems),
        "sources": int(len(np.unique(sources))),
        "overlapping_adbench_problems": int(overlapping.sum()),
        "bootstraps": draws,
        "seed": SEED,
        "level": LEVEL,
        "comparisons": results,
    }


def x_analyse__mutmut_39(
    problems: list[str], table: dict[str, np.ndarray], *, draws: int | None = None
) -> dict[str, Any]:
    draws = BOOTSTRAPS if draws is None else draws
    sources = np.array([source_id(p) for p in problems])
    labelled_uci = {p for p in problems if p.startswith("uci:")}
    overlapping = np.array([
        p.startswith("adbench:") and source_id(p) in labelled_uci for p in problems
    ])  # fmt: skip
    results = []
    for first, second in COMPARISONS:
        both = ~np.isnan(table[first]) & ~np.isnan(table[second])
        differences = table[first][both] - table[second][both]
        entry: dict[str, Any] = {"comparison": f"{first} - {second}", "problems": int(both.sum())}
        entry["by_problem"] = bootstrap(differences, None, by_cluster=False, draws=draws)
        entry["by_source"] = bootstrap(differences, sources[both], by_cluster=True, draws=draws)
        keep = both & ~overlapping
        entry["without_overlap"] = bootstrap(
            table[first][keep] - table[second][keep], sources[keep], by_cluster=True, draws=draws
        ) | {"problems": int(keep.sum())}
        results.append(entry)
    adjusted = holm([item["by_source"]["p_two_sided"] for item in results])
    for item, value in zip(results, adjusted, strict=True):
        item["holm_p_by_source"] = value
    return {
        "problems": len(problems),
        "sources": int(len(np.unique(sources))),
        "overlapping_adbench_problems": int(overlapping.sum()),
        "bootstraps": draws,
        "seed": SEED,
        "level": LEVEL,
        "comparisons": results,
    }


def x_analyse__mutmut_40(
    problems: list[str], table: dict[str, np.ndarray], *, draws: int | None = None
) -> dict[str, Any]:
    draws = BOOTSTRAPS if draws is None else draws
    sources = np.array([source_id(p) for p in problems])
    labelled_uci = {p for p in problems if p.startswith("uci:")}
    overlapping = np.array([
        p.startswith("adbench:") and source_id(p) in labelled_uci for p in problems
    ])  # fmt: skip
    results = []
    for first, second in COMPARISONS:
        both = ~np.isnan(table[first]) & ~np.isnan(table[second])
        differences = table[first][both] - table[second][both]
        entry: dict[str, Any] = {"comparison": f"{first} - {second}", "problems": int(both.sum())}
        entry["by_problem"] = bootstrap(differences, sources[both], by_cluster=None, draws=draws)
        entry["by_source"] = bootstrap(differences, sources[both], by_cluster=True, draws=draws)
        keep = both & ~overlapping
        entry["without_overlap"] = bootstrap(
            table[first][keep] - table[second][keep], sources[keep], by_cluster=True, draws=draws
        ) | {"problems": int(keep.sum())}
        results.append(entry)
    adjusted = holm([item["by_source"]["p_two_sided"] for item in results])
    for item, value in zip(results, adjusted, strict=True):
        item["holm_p_by_source"] = value
    return {
        "problems": len(problems),
        "sources": int(len(np.unique(sources))),
        "overlapping_adbench_problems": int(overlapping.sum()),
        "bootstraps": draws,
        "seed": SEED,
        "level": LEVEL,
        "comparisons": results,
    }


def x_analyse__mutmut_41(
    problems: list[str], table: dict[str, np.ndarray], *, draws: int | None = None
) -> dict[str, Any]:
    draws = BOOTSTRAPS if draws is None else draws
    sources = np.array([source_id(p) for p in problems])
    labelled_uci = {p for p in problems if p.startswith("uci:")}
    overlapping = np.array([
        p.startswith("adbench:") and source_id(p) in labelled_uci for p in problems
    ])  # fmt: skip
    results = []
    for first, second in COMPARISONS:
        both = ~np.isnan(table[first]) & ~np.isnan(table[second])
        differences = table[first][both] - table[second][both]
        entry: dict[str, Any] = {"comparison": f"{first} - {second}", "problems": int(both.sum())}
        entry["by_problem"] = bootstrap(differences, sources[both], by_cluster=False, draws=None)
        entry["by_source"] = bootstrap(differences, sources[both], by_cluster=True, draws=draws)
        keep = both & ~overlapping
        entry["without_overlap"] = bootstrap(
            table[first][keep] - table[second][keep], sources[keep], by_cluster=True, draws=draws
        ) | {"problems": int(keep.sum())}
        results.append(entry)
    adjusted = holm([item["by_source"]["p_two_sided"] for item in results])
    for item, value in zip(results, adjusted, strict=True):
        item["holm_p_by_source"] = value
    return {
        "problems": len(problems),
        "sources": int(len(np.unique(sources))),
        "overlapping_adbench_problems": int(overlapping.sum()),
        "bootstraps": draws,
        "seed": SEED,
        "level": LEVEL,
        "comparisons": results,
    }


def x_analyse__mutmut_42(
    problems: list[str], table: dict[str, np.ndarray], *, draws: int | None = None
) -> dict[str, Any]:
    draws = BOOTSTRAPS if draws is None else draws
    sources = np.array([source_id(p) for p in problems])
    labelled_uci = {p for p in problems if p.startswith("uci:")}
    overlapping = np.array([
        p.startswith("adbench:") and source_id(p) in labelled_uci for p in problems
    ])  # fmt: skip
    results = []
    for first, second in COMPARISONS:
        both = ~np.isnan(table[first]) & ~np.isnan(table[second])
        differences = table[first][both] - table[second][both]
        entry: dict[str, Any] = {"comparison": f"{first} - {second}", "problems": int(both.sum())}
        entry["by_problem"] = bootstrap(sources[both], by_cluster=False, draws=draws)
        entry["by_source"] = bootstrap(differences, sources[both], by_cluster=True, draws=draws)
        keep = both & ~overlapping
        entry["without_overlap"] = bootstrap(
            table[first][keep] - table[second][keep], sources[keep], by_cluster=True, draws=draws
        ) | {"problems": int(keep.sum())}
        results.append(entry)
    adjusted = holm([item["by_source"]["p_two_sided"] for item in results])
    for item, value in zip(results, adjusted, strict=True):
        item["holm_p_by_source"] = value
    return {
        "problems": len(problems),
        "sources": int(len(np.unique(sources))),
        "overlapping_adbench_problems": int(overlapping.sum()),
        "bootstraps": draws,
        "seed": SEED,
        "level": LEVEL,
        "comparisons": results,
    }


def x_analyse__mutmut_43(
    problems: list[str], table: dict[str, np.ndarray], *, draws: int | None = None
) -> dict[str, Any]:
    draws = BOOTSTRAPS if draws is None else draws
    sources = np.array([source_id(p) for p in problems])
    labelled_uci = {p for p in problems if p.startswith("uci:")}
    overlapping = np.array([
        p.startswith("adbench:") and source_id(p) in labelled_uci for p in problems
    ])  # fmt: skip
    results = []
    for first, second in COMPARISONS:
        both = ~np.isnan(table[first]) & ~np.isnan(table[second])
        differences = table[first][both] - table[second][both]
        entry: dict[str, Any] = {"comparison": f"{first} - {second}", "problems": int(both.sum())}
        entry["by_problem"] = bootstrap(differences, by_cluster=False, draws=draws)
        entry["by_source"] = bootstrap(differences, sources[both], by_cluster=True, draws=draws)
        keep = both & ~overlapping
        entry["without_overlap"] = bootstrap(
            table[first][keep] - table[second][keep], sources[keep], by_cluster=True, draws=draws
        ) | {"problems": int(keep.sum())}
        results.append(entry)
    adjusted = holm([item["by_source"]["p_two_sided"] for item in results])
    for item, value in zip(results, adjusted, strict=True):
        item["holm_p_by_source"] = value
    return {
        "problems": len(problems),
        "sources": int(len(np.unique(sources))),
        "overlapping_adbench_problems": int(overlapping.sum()),
        "bootstraps": draws,
        "seed": SEED,
        "level": LEVEL,
        "comparisons": results,
    }


def x_analyse__mutmut_44(
    problems: list[str], table: dict[str, np.ndarray], *, draws: int | None = None
) -> dict[str, Any]:
    draws = BOOTSTRAPS if draws is None else draws
    sources = np.array([source_id(p) for p in problems])
    labelled_uci = {p for p in problems if p.startswith("uci:")}
    overlapping = np.array([
        p.startswith("adbench:") and source_id(p) in labelled_uci for p in problems
    ])  # fmt: skip
    results = []
    for first, second in COMPARISONS:
        both = ~np.isnan(table[first]) & ~np.isnan(table[second])
        differences = table[first][both] - table[second][both]
        entry: dict[str, Any] = {"comparison": f"{first} - {second}", "problems": int(both.sum())}
        entry["by_problem"] = bootstrap(differences, sources[both], draws=draws)
        entry["by_source"] = bootstrap(differences, sources[both], by_cluster=True, draws=draws)
        keep = both & ~overlapping
        entry["without_overlap"] = bootstrap(
            table[first][keep] - table[second][keep], sources[keep], by_cluster=True, draws=draws
        ) | {"problems": int(keep.sum())}
        results.append(entry)
    adjusted = holm([item["by_source"]["p_two_sided"] for item in results])
    for item, value in zip(results, adjusted, strict=True):
        item["holm_p_by_source"] = value
    return {
        "problems": len(problems),
        "sources": int(len(np.unique(sources))),
        "overlapping_adbench_problems": int(overlapping.sum()),
        "bootstraps": draws,
        "seed": SEED,
        "level": LEVEL,
        "comparisons": results,
    }


def x_analyse__mutmut_45(
    problems: list[str], table: dict[str, np.ndarray], *, draws: int | None = None
) -> dict[str, Any]:
    draws = BOOTSTRAPS if draws is None else draws
    sources = np.array([source_id(p) for p in problems])
    labelled_uci = {p for p in problems if p.startswith("uci:")}
    overlapping = np.array([
        p.startswith("adbench:") and source_id(p) in labelled_uci for p in problems
    ])  # fmt: skip
    results = []
    for first, second in COMPARISONS:
        both = ~np.isnan(table[first]) & ~np.isnan(table[second])
        differences = table[first][both] - table[second][both]
        entry: dict[str, Any] = {"comparison": f"{first} - {second}", "problems": int(both.sum())}
        entry["by_problem"] = bootstrap(differences, sources[both], by_cluster=False, )
        entry["by_source"] = bootstrap(differences, sources[both], by_cluster=True, draws=draws)
        keep = both & ~overlapping
        entry["without_overlap"] = bootstrap(
            table[first][keep] - table[second][keep], sources[keep], by_cluster=True, draws=draws
        ) | {"problems": int(keep.sum())}
        results.append(entry)
    adjusted = holm([item["by_source"]["p_two_sided"] for item in results])
    for item, value in zip(results, adjusted, strict=True):
        item["holm_p_by_source"] = value
    return {
        "problems": len(problems),
        "sources": int(len(np.unique(sources))),
        "overlapping_adbench_problems": int(overlapping.sum()),
        "bootstraps": draws,
        "seed": SEED,
        "level": LEVEL,
        "comparisons": results,
    }


def x_analyse__mutmut_46(
    problems: list[str], table: dict[str, np.ndarray], *, draws: int | None = None
) -> dict[str, Any]:
    draws = BOOTSTRAPS if draws is None else draws
    sources = np.array([source_id(p) for p in problems])
    labelled_uci = {p for p in problems if p.startswith("uci:")}
    overlapping = np.array([
        p.startswith("adbench:") and source_id(p) in labelled_uci for p in problems
    ])  # fmt: skip
    results = []
    for first, second in COMPARISONS:
        both = ~np.isnan(table[first]) & ~np.isnan(table[second])
        differences = table[first][both] - table[second][both]
        entry: dict[str, Any] = {"comparison": f"{first} - {second}", "problems": int(both.sum())}
        entry["by_problem"] = bootstrap(differences, sources[both], by_cluster=True, draws=draws)
        entry["by_source"] = bootstrap(differences, sources[both], by_cluster=True, draws=draws)
        keep = both & ~overlapping
        entry["without_overlap"] = bootstrap(
            table[first][keep] - table[second][keep], sources[keep], by_cluster=True, draws=draws
        ) | {"problems": int(keep.sum())}
        results.append(entry)
    adjusted = holm([item["by_source"]["p_two_sided"] for item in results])
    for item, value in zip(results, adjusted, strict=True):
        item["holm_p_by_source"] = value
    return {
        "problems": len(problems),
        "sources": int(len(np.unique(sources))),
        "overlapping_adbench_problems": int(overlapping.sum()),
        "bootstraps": draws,
        "seed": SEED,
        "level": LEVEL,
        "comparisons": results,
    }


def x_analyse__mutmut_47(
    problems: list[str], table: dict[str, np.ndarray], *, draws: int | None = None
) -> dict[str, Any]:
    draws = BOOTSTRAPS if draws is None else draws
    sources = np.array([source_id(p) for p in problems])
    labelled_uci = {p for p in problems if p.startswith("uci:")}
    overlapping = np.array([
        p.startswith("adbench:") and source_id(p) in labelled_uci for p in problems
    ])  # fmt: skip
    results = []
    for first, second in COMPARISONS:
        both = ~np.isnan(table[first]) & ~np.isnan(table[second])
        differences = table[first][both] - table[second][both]
        entry: dict[str, Any] = {"comparison": f"{first} - {second}", "problems": int(both.sum())}
        entry["by_problem"] = bootstrap(differences, sources[both], by_cluster=False, draws=draws)
        entry["by_source"] = None
        keep = both & ~overlapping
        entry["without_overlap"] = bootstrap(
            table[first][keep] - table[second][keep], sources[keep], by_cluster=True, draws=draws
        ) | {"problems": int(keep.sum())}
        results.append(entry)
    adjusted = holm([item["by_source"]["p_two_sided"] for item in results])
    for item, value in zip(results, adjusted, strict=True):
        item["holm_p_by_source"] = value
    return {
        "problems": len(problems),
        "sources": int(len(np.unique(sources))),
        "overlapping_adbench_problems": int(overlapping.sum()),
        "bootstraps": draws,
        "seed": SEED,
        "level": LEVEL,
        "comparisons": results,
    }


def x_analyse__mutmut_48(
    problems: list[str], table: dict[str, np.ndarray], *, draws: int | None = None
) -> dict[str, Any]:
    draws = BOOTSTRAPS if draws is None else draws
    sources = np.array([source_id(p) for p in problems])
    labelled_uci = {p for p in problems if p.startswith("uci:")}
    overlapping = np.array([
        p.startswith("adbench:") and source_id(p) in labelled_uci for p in problems
    ])  # fmt: skip
    results = []
    for first, second in COMPARISONS:
        both = ~np.isnan(table[first]) & ~np.isnan(table[second])
        differences = table[first][both] - table[second][both]
        entry: dict[str, Any] = {"comparison": f"{first} - {second}", "problems": int(both.sum())}
        entry["by_problem"] = bootstrap(differences, sources[both], by_cluster=False, draws=draws)
        entry["XXby_sourceXX"] = bootstrap(differences, sources[both], by_cluster=True, draws=draws)
        keep = both & ~overlapping
        entry["without_overlap"] = bootstrap(
            table[first][keep] - table[second][keep], sources[keep], by_cluster=True, draws=draws
        ) | {"problems": int(keep.sum())}
        results.append(entry)
    adjusted = holm([item["by_source"]["p_two_sided"] for item in results])
    for item, value in zip(results, adjusted, strict=True):
        item["holm_p_by_source"] = value
    return {
        "problems": len(problems),
        "sources": int(len(np.unique(sources))),
        "overlapping_adbench_problems": int(overlapping.sum()),
        "bootstraps": draws,
        "seed": SEED,
        "level": LEVEL,
        "comparisons": results,
    }


def x_analyse__mutmut_49(
    problems: list[str], table: dict[str, np.ndarray], *, draws: int | None = None
) -> dict[str, Any]:
    draws = BOOTSTRAPS if draws is None else draws
    sources = np.array([source_id(p) for p in problems])
    labelled_uci = {p for p in problems if p.startswith("uci:")}
    overlapping = np.array([
        p.startswith("adbench:") and source_id(p) in labelled_uci for p in problems
    ])  # fmt: skip
    results = []
    for first, second in COMPARISONS:
        both = ~np.isnan(table[first]) & ~np.isnan(table[second])
        differences = table[first][both] - table[second][both]
        entry: dict[str, Any] = {"comparison": f"{first} - {second}", "problems": int(both.sum())}
        entry["by_problem"] = bootstrap(differences, sources[both], by_cluster=False, draws=draws)
        entry["BY_SOURCE"] = bootstrap(differences, sources[both], by_cluster=True, draws=draws)
        keep = both & ~overlapping
        entry["without_overlap"] = bootstrap(
            table[first][keep] - table[second][keep], sources[keep], by_cluster=True, draws=draws
        ) | {"problems": int(keep.sum())}
        results.append(entry)
    adjusted = holm([item["by_source"]["p_two_sided"] for item in results])
    for item, value in zip(results, adjusted, strict=True):
        item["holm_p_by_source"] = value
    return {
        "problems": len(problems),
        "sources": int(len(np.unique(sources))),
        "overlapping_adbench_problems": int(overlapping.sum()),
        "bootstraps": draws,
        "seed": SEED,
        "level": LEVEL,
        "comparisons": results,
    }


def x_analyse__mutmut_50(
    problems: list[str], table: dict[str, np.ndarray], *, draws: int | None = None
) -> dict[str, Any]:
    draws = BOOTSTRAPS if draws is None else draws
    sources = np.array([source_id(p) for p in problems])
    labelled_uci = {p for p in problems if p.startswith("uci:")}
    overlapping = np.array([
        p.startswith("adbench:") and source_id(p) in labelled_uci for p in problems
    ])  # fmt: skip
    results = []
    for first, second in COMPARISONS:
        both = ~np.isnan(table[first]) & ~np.isnan(table[second])
        differences = table[first][both] - table[second][both]
        entry: dict[str, Any] = {"comparison": f"{first} - {second}", "problems": int(both.sum())}
        entry["by_problem"] = bootstrap(differences, sources[both], by_cluster=False, draws=draws)
        entry["by_source"] = bootstrap(None, sources[both], by_cluster=True, draws=draws)
        keep = both & ~overlapping
        entry["without_overlap"] = bootstrap(
            table[first][keep] - table[second][keep], sources[keep], by_cluster=True, draws=draws
        ) | {"problems": int(keep.sum())}
        results.append(entry)
    adjusted = holm([item["by_source"]["p_two_sided"] for item in results])
    for item, value in zip(results, adjusted, strict=True):
        item["holm_p_by_source"] = value
    return {
        "problems": len(problems),
        "sources": int(len(np.unique(sources))),
        "overlapping_adbench_problems": int(overlapping.sum()),
        "bootstraps": draws,
        "seed": SEED,
        "level": LEVEL,
        "comparisons": results,
    }


def x_analyse__mutmut_51(
    problems: list[str], table: dict[str, np.ndarray], *, draws: int | None = None
) -> dict[str, Any]:
    draws = BOOTSTRAPS if draws is None else draws
    sources = np.array([source_id(p) for p in problems])
    labelled_uci = {p for p in problems if p.startswith("uci:")}
    overlapping = np.array([
        p.startswith("adbench:") and source_id(p) in labelled_uci for p in problems
    ])  # fmt: skip
    results = []
    for first, second in COMPARISONS:
        both = ~np.isnan(table[first]) & ~np.isnan(table[second])
        differences = table[first][both] - table[second][both]
        entry: dict[str, Any] = {"comparison": f"{first} - {second}", "problems": int(both.sum())}
        entry["by_problem"] = bootstrap(differences, sources[both], by_cluster=False, draws=draws)
        entry["by_source"] = bootstrap(differences, None, by_cluster=True, draws=draws)
        keep = both & ~overlapping
        entry["without_overlap"] = bootstrap(
            table[first][keep] - table[second][keep], sources[keep], by_cluster=True, draws=draws
        ) | {"problems": int(keep.sum())}
        results.append(entry)
    adjusted = holm([item["by_source"]["p_two_sided"] for item in results])
    for item, value in zip(results, adjusted, strict=True):
        item["holm_p_by_source"] = value
    return {
        "problems": len(problems),
        "sources": int(len(np.unique(sources))),
        "overlapping_adbench_problems": int(overlapping.sum()),
        "bootstraps": draws,
        "seed": SEED,
        "level": LEVEL,
        "comparisons": results,
    }


def x_analyse__mutmut_52(
    problems: list[str], table: dict[str, np.ndarray], *, draws: int | None = None
) -> dict[str, Any]:
    draws = BOOTSTRAPS if draws is None else draws
    sources = np.array([source_id(p) for p in problems])
    labelled_uci = {p for p in problems if p.startswith("uci:")}
    overlapping = np.array([
        p.startswith("adbench:") and source_id(p) in labelled_uci for p in problems
    ])  # fmt: skip
    results = []
    for first, second in COMPARISONS:
        both = ~np.isnan(table[first]) & ~np.isnan(table[second])
        differences = table[first][both] - table[second][both]
        entry: dict[str, Any] = {"comparison": f"{first} - {second}", "problems": int(both.sum())}
        entry["by_problem"] = bootstrap(differences, sources[both], by_cluster=False, draws=draws)
        entry["by_source"] = bootstrap(differences, sources[both], by_cluster=None, draws=draws)
        keep = both & ~overlapping
        entry["without_overlap"] = bootstrap(
            table[first][keep] - table[second][keep], sources[keep], by_cluster=True, draws=draws
        ) | {"problems": int(keep.sum())}
        results.append(entry)
    adjusted = holm([item["by_source"]["p_two_sided"] for item in results])
    for item, value in zip(results, adjusted, strict=True):
        item["holm_p_by_source"] = value
    return {
        "problems": len(problems),
        "sources": int(len(np.unique(sources))),
        "overlapping_adbench_problems": int(overlapping.sum()),
        "bootstraps": draws,
        "seed": SEED,
        "level": LEVEL,
        "comparisons": results,
    }


def x_analyse__mutmut_53(
    problems: list[str], table: dict[str, np.ndarray], *, draws: int | None = None
) -> dict[str, Any]:
    draws = BOOTSTRAPS if draws is None else draws
    sources = np.array([source_id(p) for p in problems])
    labelled_uci = {p for p in problems if p.startswith("uci:")}
    overlapping = np.array([
        p.startswith("adbench:") and source_id(p) in labelled_uci for p in problems
    ])  # fmt: skip
    results = []
    for first, second in COMPARISONS:
        both = ~np.isnan(table[first]) & ~np.isnan(table[second])
        differences = table[first][both] - table[second][both]
        entry: dict[str, Any] = {"comparison": f"{first} - {second}", "problems": int(both.sum())}
        entry["by_problem"] = bootstrap(differences, sources[both], by_cluster=False, draws=draws)
        entry["by_source"] = bootstrap(differences, sources[both], by_cluster=True, draws=None)
        keep = both & ~overlapping
        entry["without_overlap"] = bootstrap(
            table[first][keep] - table[second][keep], sources[keep], by_cluster=True, draws=draws
        ) | {"problems": int(keep.sum())}
        results.append(entry)
    adjusted = holm([item["by_source"]["p_two_sided"] for item in results])
    for item, value in zip(results, adjusted, strict=True):
        item["holm_p_by_source"] = value
    return {
        "problems": len(problems),
        "sources": int(len(np.unique(sources))),
        "overlapping_adbench_problems": int(overlapping.sum()),
        "bootstraps": draws,
        "seed": SEED,
        "level": LEVEL,
        "comparisons": results,
    }


def x_analyse__mutmut_54(
    problems: list[str], table: dict[str, np.ndarray], *, draws: int | None = None
) -> dict[str, Any]:
    draws = BOOTSTRAPS if draws is None else draws
    sources = np.array([source_id(p) for p in problems])
    labelled_uci = {p for p in problems if p.startswith("uci:")}
    overlapping = np.array([
        p.startswith("adbench:") and source_id(p) in labelled_uci for p in problems
    ])  # fmt: skip
    results = []
    for first, second in COMPARISONS:
        both = ~np.isnan(table[first]) & ~np.isnan(table[second])
        differences = table[first][both] - table[second][both]
        entry: dict[str, Any] = {"comparison": f"{first} - {second}", "problems": int(both.sum())}
        entry["by_problem"] = bootstrap(differences, sources[both], by_cluster=False, draws=draws)
        entry["by_source"] = bootstrap(sources[both], by_cluster=True, draws=draws)
        keep = both & ~overlapping
        entry["without_overlap"] = bootstrap(
            table[first][keep] - table[second][keep], sources[keep], by_cluster=True, draws=draws
        ) | {"problems": int(keep.sum())}
        results.append(entry)
    adjusted = holm([item["by_source"]["p_two_sided"] for item in results])
    for item, value in zip(results, adjusted, strict=True):
        item["holm_p_by_source"] = value
    return {
        "problems": len(problems),
        "sources": int(len(np.unique(sources))),
        "overlapping_adbench_problems": int(overlapping.sum()),
        "bootstraps": draws,
        "seed": SEED,
        "level": LEVEL,
        "comparisons": results,
    }


def x_analyse__mutmut_55(
    problems: list[str], table: dict[str, np.ndarray], *, draws: int | None = None
) -> dict[str, Any]:
    draws = BOOTSTRAPS if draws is None else draws
    sources = np.array([source_id(p) for p in problems])
    labelled_uci = {p for p in problems if p.startswith("uci:")}
    overlapping = np.array([
        p.startswith("adbench:") and source_id(p) in labelled_uci for p in problems
    ])  # fmt: skip
    results = []
    for first, second in COMPARISONS:
        both = ~np.isnan(table[first]) & ~np.isnan(table[second])
        differences = table[first][both] - table[second][both]
        entry: dict[str, Any] = {"comparison": f"{first} - {second}", "problems": int(both.sum())}
        entry["by_problem"] = bootstrap(differences, sources[both], by_cluster=False, draws=draws)
        entry["by_source"] = bootstrap(differences, by_cluster=True, draws=draws)
        keep = both & ~overlapping
        entry["without_overlap"] = bootstrap(
            table[first][keep] - table[second][keep], sources[keep], by_cluster=True, draws=draws
        ) | {"problems": int(keep.sum())}
        results.append(entry)
    adjusted = holm([item["by_source"]["p_two_sided"] for item in results])
    for item, value in zip(results, adjusted, strict=True):
        item["holm_p_by_source"] = value
    return {
        "problems": len(problems),
        "sources": int(len(np.unique(sources))),
        "overlapping_adbench_problems": int(overlapping.sum()),
        "bootstraps": draws,
        "seed": SEED,
        "level": LEVEL,
        "comparisons": results,
    }


def x_analyse__mutmut_56(
    problems: list[str], table: dict[str, np.ndarray], *, draws: int | None = None
) -> dict[str, Any]:
    draws = BOOTSTRAPS if draws is None else draws
    sources = np.array([source_id(p) for p in problems])
    labelled_uci = {p for p in problems if p.startswith("uci:")}
    overlapping = np.array([
        p.startswith("adbench:") and source_id(p) in labelled_uci for p in problems
    ])  # fmt: skip
    results = []
    for first, second in COMPARISONS:
        both = ~np.isnan(table[first]) & ~np.isnan(table[second])
        differences = table[first][both] - table[second][both]
        entry: dict[str, Any] = {"comparison": f"{first} - {second}", "problems": int(both.sum())}
        entry["by_problem"] = bootstrap(differences, sources[both], by_cluster=False, draws=draws)
        entry["by_source"] = bootstrap(differences, sources[both], draws=draws)
        keep = both & ~overlapping
        entry["without_overlap"] = bootstrap(
            table[first][keep] - table[second][keep], sources[keep], by_cluster=True, draws=draws
        ) | {"problems": int(keep.sum())}
        results.append(entry)
    adjusted = holm([item["by_source"]["p_two_sided"] for item in results])
    for item, value in zip(results, adjusted, strict=True):
        item["holm_p_by_source"] = value
    return {
        "problems": len(problems),
        "sources": int(len(np.unique(sources))),
        "overlapping_adbench_problems": int(overlapping.sum()),
        "bootstraps": draws,
        "seed": SEED,
        "level": LEVEL,
        "comparisons": results,
    }


def x_analyse__mutmut_57(
    problems: list[str], table: dict[str, np.ndarray], *, draws: int | None = None
) -> dict[str, Any]:
    draws = BOOTSTRAPS if draws is None else draws
    sources = np.array([source_id(p) for p in problems])
    labelled_uci = {p for p in problems if p.startswith("uci:")}
    overlapping = np.array([
        p.startswith("adbench:") and source_id(p) in labelled_uci for p in problems
    ])  # fmt: skip
    results = []
    for first, second in COMPARISONS:
        both = ~np.isnan(table[first]) & ~np.isnan(table[second])
        differences = table[first][both] - table[second][both]
        entry: dict[str, Any] = {"comparison": f"{first} - {second}", "problems": int(both.sum())}
        entry["by_problem"] = bootstrap(differences, sources[both], by_cluster=False, draws=draws)
        entry["by_source"] = bootstrap(differences, sources[both], by_cluster=True, )
        keep = both & ~overlapping
        entry["without_overlap"] = bootstrap(
            table[first][keep] - table[second][keep], sources[keep], by_cluster=True, draws=draws
        ) | {"problems": int(keep.sum())}
        results.append(entry)
    adjusted = holm([item["by_source"]["p_two_sided"] for item in results])
    for item, value in zip(results, adjusted, strict=True):
        item["holm_p_by_source"] = value
    return {
        "problems": len(problems),
        "sources": int(len(np.unique(sources))),
        "overlapping_adbench_problems": int(overlapping.sum()),
        "bootstraps": draws,
        "seed": SEED,
        "level": LEVEL,
        "comparisons": results,
    }


def x_analyse__mutmut_58(
    problems: list[str], table: dict[str, np.ndarray], *, draws: int | None = None
) -> dict[str, Any]:
    draws = BOOTSTRAPS if draws is None else draws
    sources = np.array([source_id(p) for p in problems])
    labelled_uci = {p for p in problems if p.startswith("uci:")}
    overlapping = np.array([
        p.startswith("adbench:") and source_id(p) in labelled_uci for p in problems
    ])  # fmt: skip
    results = []
    for first, second in COMPARISONS:
        both = ~np.isnan(table[first]) & ~np.isnan(table[second])
        differences = table[first][both] - table[second][both]
        entry: dict[str, Any] = {"comparison": f"{first} - {second}", "problems": int(both.sum())}
        entry["by_problem"] = bootstrap(differences, sources[both], by_cluster=False, draws=draws)
        entry["by_source"] = bootstrap(differences, sources[both], by_cluster=False, draws=draws)
        keep = both & ~overlapping
        entry["without_overlap"] = bootstrap(
            table[first][keep] - table[second][keep], sources[keep], by_cluster=True, draws=draws
        ) | {"problems": int(keep.sum())}
        results.append(entry)
    adjusted = holm([item["by_source"]["p_two_sided"] for item in results])
    for item, value in zip(results, adjusted, strict=True):
        item["holm_p_by_source"] = value
    return {
        "problems": len(problems),
        "sources": int(len(np.unique(sources))),
        "overlapping_adbench_problems": int(overlapping.sum()),
        "bootstraps": draws,
        "seed": SEED,
        "level": LEVEL,
        "comparisons": results,
    }


def x_analyse__mutmut_59(
    problems: list[str], table: dict[str, np.ndarray], *, draws: int | None = None
) -> dict[str, Any]:
    draws = BOOTSTRAPS if draws is None else draws
    sources = np.array([source_id(p) for p in problems])
    labelled_uci = {p for p in problems if p.startswith("uci:")}
    overlapping = np.array([
        p.startswith("adbench:") and source_id(p) in labelled_uci for p in problems
    ])  # fmt: skip
    results = []
    for first, second in COMPARISONS:
        both = ~np.isnan(table[first]) & ~np.isnan(table[second])
        differences = table[first][both] - table[second][both]
        entry: dict[str, Any] = {"comparison": f"{first} - {second}", "problems": int(both.sum())}
        entry["by_problem"] = bootstrap(differences, sources[both], by_cluster=False, draws=draws)
        entry["by_source"] = bootstrap(differences, sources[both], by_cluster=True, draws=draws)
        keep = None
        entry["without_overlap"] = bootstrap(
            table[first][keep] - table[second][keep], sources[keep], by_cluster=True, draws=draws
        ) | {"problems": int(keep.sum())}
        results.append(entry)
    adjusted = holm([item["by_source"]["p_two_sided"] for item in results])
    for item, value in zip(results, adjusted, strict=True):
        item["holm_p_by_source"] = value
    return {
        "problems": len(problems),
        "sources": int(len(np.unique(sources))),
        "overlapping_adbench_problems": int(overlapping.sum()),
        "bootstraps": draws,
        "seed": SEED,
        "level": LEVEL,
        "comparisons": results,
    }


def x_analyse__mutmut_60(
    problems: list[str], table: dict[str, np.ndarray], *, draws: int | None = None
) -> dict[str, Any]:
    draws = BOOTSTRAPS if draws is None else draws
    sources = np.array([source_id(p) for p in problems])
    labelled_uci = {p for p in problems if p.startswith("uci:")}
    overlapping = np.array([
        p.startswith("adbench:") and source_id(p) in labelled_uci for p in problems
    ])  # fmt: skip
    results = []
    for first, second in COMPARISONS:
        both = ~np.isnan(table[first]) & ~np.isnan(table[second])
        differences = table[first][both] - table[second][both]
        entry: dict[str, Any] = {"comparison": f"{first} - {second}", "problems": int(both.sum())}
        entry["by_problem"] = bootstrap(differences, sources[both], by_cluster=False, draws=draws)
        entry["by_source"] = bootstrap(differences, sources[both], by_cluster=True, draws=draws)
        keep = both | ~overlapping
        entry["without_overlap"] = bootstrap(
            table[first][keep] - table[second][keep], sources[keep], by_cluster=True, draws=draws
        ) | {"problems": int(keep.sum())}
        results.append(entry)
    adjusted = holm([item["by_source"]["p_two_sided"] for item in results])
    for item, value in zip(results, adjusted, strict=True):
        item["holm_p_by_source"] = value
    return {
        "problems": len(problems),
        "sources": int(len(np.unique(sources))),
        "overlapping_adbench_problems": int(overlapping.sum()),
        "bootstraps": draws,
        "seed": SEED,
        "level": LEVEL,
        "comparisons": results,
    }


def x_analyse__mutmut_61(
    problems: list[str], table: dict[str, np.ndarray], *, draws: int | None = None
) -> dict[str, Any]:
    draws = BOOTSTRAPS if draws is None else draws
    sources = np.array([source_id(p) for p in problems])
    labelled_uci = {p for p in problems if p.startswith("uci:")}
    overlapping = np.array([
        p.startswith("adbench:") and source_id(p) in labelled_uci for p in problems
    ])  # fmt: skip
    results = []
    for first, second in COMPARISONS:
        both = ~np.isnan(table[first]) & ~np.isnan(table[second])
        differences = table[first][both] - table[second][both]
        entry: dict[str, Any] = {"comparison": f"{first} - {second}", "problems": int(both.sum())}
        entry["by_problem"] = bootstrap(differences, sources[both], by_cluster=False, draws=draws)
        entry["by_source"] = bootstrap(differences, sources[both], by_cluster=True, draws=draws)
        keep = both & overlapping
        entry["without_overlap"] = bootstrap(
            table[first][keep] - table[second][keep], sources[keep], by_cluster=True, draws=draws
        ) | {"problems": int(keep.sum())}
        results.append(entry)
    adjusted = holm([item["by_source"]["p_two_sided"] for item in results])
    for item, value in zip(results, adjusted, strict=True):
        item["holm_p_by_source"] = value
    return {
        "problems": len(problems),
        "sources": int(len(np.unique(sources))),
        "overlapping_adbench_problems": int(overlapping.sum()),
        "bootstraps": draws,
        "seed": SEED,
        "level": LEVEL,
        "comparisons": results,
    }


def x_analyse__mutmut_62(
    problems: list[str], table: dict[str, np.ndarray], *, draws: int | None = None
) -> dict[str, Any]:
    draws = BOOTSTRAPS if draws is None else draws
    sources = np.array([source_id(p) for p in problems])
    labelled_uci = {p for p in problems if p.startswith("uci:")}
    overlapping = np.array([
        p.startswith("adbench:") and source_id(p) in labelled_uci for p in problems
    ])  # fmt: skip
    results = []
    for first, second in COMPARISONS:
        both = ~np.isnan(table[first]) & ~np.isnan(table[second])
        differences = table[first][both] - table[second][both]
        entry: dict[str, Any] = {"comparison": f"{first} - {second}", "problems": int(both.sum())}
        entry["by_problem"] = bootstrap(differences, sources[both], by_cluster=False, draws=draws)
        entry["by_source"] = bootstrap(differences, sources[both], by_cluster=True, draws=draws)
        keep = both & ~overlapping
        entry["without_overlap"] = None
        results.append(entry)
    adjusted = holm([item["by_source"]["p_two_sided"] for item in results])
    for item, value in zip(results, adjusted, strict=True):
        item["holm_p_by_source"] = value
    return {
        "problems": len(problems),
        "sources": int(len(np.unique(sources))),
        "overlapping_adbench_problems": int(overlapping.sum()),
        "bootstraps": draws,
        "seed": SEED,
        "level": LEVEL,
        "comparisons": results,
    }


def x_analyse__mutmut_63(
    problems: list[str], table: dict[str, np.ndarray], *, draws: int | None = None
) -> dict[str, Any]:
    draws = BOOTSTRAPS if draws is None else draws
    sources = np.array([source_id(p) for p in problems])
    labelled_uci = {p for p in problems if p.startswith("uci:")}
    overlapping = np.array([
        p.startswith("adbench:") and source_id(p) in labelled_uci for p in problems
    ])  # fmt: skip
    results = []
    for first, second in COMPARISONS:
        both = ~np.isnan(table[first]) & ~np.isnan(table[second])
        differences = table[first][both] - table[second][both]
        entry: dict[str, Any] = {"comparison": f"{first} - {second}", "problems": int(both.sum())}
        entry["by_problem"] = bootstrap(differences, sources[both], by_cluster=False, draws=draws)
        entry["by_source"] = bootstrap(differences, sources[both], by_cluster=True, draws=draws)
        keep = both & ~overlapping
        entry["XXwithout_overlapXX"] = bootstrap(
            table[first][keep] - table[second][keep], sources[keep], by_cluster=True, draws=draws
        ) | {"problems": int(keep.sum())}
        results.append(entry)
    adjusted = holm([item["by_source"]["p_two_sided"] for item in results])
    for item, value in zip(results, adjusted, strict=True):
        item["holm_p_by_source"] = value
    return {
        "problems": len(problems),
        "sources": int(len(np.unique(sources))),
        "overlapping_adbench_problems": int(overlapping.sum()),
        "bootstraps": draws,
        "seed": SEED,
        "level": LEVEL,
        "comparisons": results,
    }


def x_analyse__mutmut_64(
    problems: list[str], table: dict[str, np.ndarray], *, draws: int | None = None
) -> dict[str, Any]:
    draws = BOOTSTRAPS if draws is None else draws
    sources = np.array([source_id(p) for p in problems])
    labelled_uci = {p for p in problems if p.startswith("uci:")}
    overlapping = np.array([
        p.startswith("adbench:") and source_id(p) in labelled_uci for p in problems
    ])  # fmt: skip
    results = []
    for first, second in COMPARISONS:
        both = ~np.isnan(table[first]) & ~np.isnan(table[second])
        differences = table[first][both] - table[second][both]
        entry: dict[str, Any] = {"comparison": f"{first} - {second}", "problems": int(both.sum())}
        entry["by_problem"] = bootstrap(differences, sources[both], by_cluster=False, draws=draws)
        entry["by_source"] = bootstrap(differences, sources[both], by_cluster=True, draws=draws)
        keep = both & ~overlapping
        entry["WITHOUT_OVERLAP"] = bootstrap(
            table[first][keep] - table[second][keep], sources[keep], by_cluster=True, draws=draws
        ) | {"problems": int(keep.sum())}
        results.append(entry)
    adjusted = holm([item["by_source"]["p_two_sided"] for item in results])
    for item, value in zip(results, adjusted, strict=True):
        item["holm_p_by_source"] = value
    return {
        "problems": len(problems),
        "sources": int(len(np.unique(sources))),
        "overlapping_adbench_problems": int(overlapping.sum()),
        "bootstraps": draws,
        "seed": SEED,
        "level": LEVEL,
        "comparisons": results,
    }


def x_analyse__mutmut_65(
    problems: list[str], table: dict[str, np.ndarray], *, draws: int | None = None
) -> dict[str, Any]:
    draws = BOOTSTRAPS if draws is None else draws
    sources = np.array([source_id(p) for p in problems])
    labelled_uci = {p for p in problems if p.startswith("uci:")}
    overlapping = np.array([
        p.startswith("adbench:") and source_id(p) in labelled_uci for p in problems
    ])  # fmt: skip
    results = []
    for first, second in COMPARISONS:
        both = ~np.isnan(table[first]) & ~np.isnan(table[second])
        differences = table[first][both] - table[second][both]
        entry: dict[str, Any] = {"comparison": f"{first} - {second}", "problems": int(both.sum())}
        entry["by_problem"] = bootstrap(differences, sources[both], by_cluster=False, draws=draws)
        entry["by_source"] = bootstrap(differences, sources[both], by_cluster=True, draws=draws)
        keep = both & ~overlapping
        entry["without_overlap"] = bootstrap(
            table[first][keep] - table[second][keep], sources[keep], by_cluster=True, draws=draws
        ) & {"problems": int(keep.sum())}
        results.append(entry)
    adjusted = holm([item["by_source"]["p_two_sided"] for item in results])
    for item, value in zip(results, adjusted, strict=True):
        item["holm_p_by_source"] = value
    return {
        "problems": len(problems),
        "sources": int(len(np.unique(sources))),
        "overlapping_adbench_problems": int(overlapping.sum()),
        "bootstraps": draws,
        "seed": SEED,
        "level": LEVEL,
        "comparisons": results,
    }


def x_analyse__mutmut_66(
    problems: list[str], table: dict[str, np.ndarray], *, draws: int | None = None
) -> dict[str, Any]:
    draws = BOOTSTRAPS if draws is None else draws
    sources = np.array([source_id(p) for p in problems])
    labelled_uci = {p for p in problems if p.startswith("uci:")}
    overlapping = np.array([
        p.startswith("adbench:") and source_id(p) in labelled_uci for p in problems
    ])  # fmt: skip
    results = []
    for first, second in COMPARISONS:
        both = ~np.isnan(table[first]) & ~np.isnan(table[second])
        differences = table[first][both] - table[second][both]
        entry: dict[str, Any] = {"comparison": f"{first} - {second}", "problems": int(both.sum())}
        entry["by_problem"] = bootstrap(differences, sources[both], by_cluster=False, draws=draws)
        entry["by_source"] = bootstrap(differences, sources[both], by_cluster=True, draws=draws)
        keep = both & ~overlapping
        entry["without_overlap"] = bootstrap(
            None, sources[keep], by_cluster=True, draws=draws
        ) | {"problems": int(keep.sum())}
        results.append(entry)
    adjusted = holm([item["by_source"]["p_two_sided"] for item in results])
    for item, value in zip(results, adjusted, strict=True):
        item["holm_p_by_source"] = value
    return {
        "problems": len(problems),
        "sources": int(len(np.unique(sources))),
        "overlapping_adbench_problems": int(overlapping.sum()),
        "bootstraps": draws,
        "seed": SEED,
        "level": LEVEL,
        "comparisons": results,
    }


def x_analyse__mutmut_67(
    problems: list[str], table: dict[str, np.ndarray], *, draws: int | None = None
) -> dict[str, Any]:
    draws = BOOTSTRAPS if draws is None else draws
    sources = np.array([source_id(p) for p in problems])
    labelled_uci = {p for p in problems if p.startswith("uci:")}
    overlapping = np.array([
        p.startswith("adbench:") and source_id(p) in labelled_uci for p in problems
    ])  # fmt: skip
    results = []
    for first, second in COMPARISONS:
        both = ~np.isnan(table[first]) & ~np.isnan(table[second])
        differences = table[first][both] - table[second][both]
        entry: dict[str, Any] = {"comparison": f"{first} - {second}", "problems": int(both.sum())}
        entry["by_problem"] = bootstrap(differences, sources[both], by_cluster=False, draws=draws)
        entry["by_source"] = bootstrap(differences, sources[both], by_cluster=True, draws=draws)
        keep = both & ~overlapping
        entry["without_overlap"] = bootstrap(
            table[first][keep] - table[second][keep], None, by_cluster=True, draws=draws
        ) | {"problems": int(keep.sum())}
        results.append(entry)
    adjusted = holm([item["by_source"]["p_two_sided"] for item in results])
    for item, value in zip(results, adjusted, strict=True):
        item["holm_p_by_source"] = value
    return {
        "problems": len(problems),
        "sources": int(len(np.unique(sources))),
        "overlapping_adbench_problems": int(overlapping.sum()),
        "bootstraps": draws,
        "seed": SEED,
        "level": LEVEL,
        "comparisons": results,
    }


def x_analyse__mutmut_68(
    problems: list[str], table: dict[str, np.ndarray], *, draws: int | None = None
) -> dict[str, Any]:
    draws = BOOTSTRAPS if draws is None else draws
    sources = np.array([source_id(p) for p in problems])
    labelled_uci = {p for p in problems if p.startswith("uci:")}
    overlapping = np.array([
        p.startswith("adbench:") and source_id(p) in labelled_uci for p in problems
    ])  # fmt: skip
    results = []
    for first, second in COMPARISONS:
        both = ~np.isnan(table[first]) & ~np.isnan(table[second])
        differences = table[first][both] - table[second][both]
        entry: dict[str, Any] = {"comparison": f"{first} - {second}", "problems": int(both.sum())}
        entry["by_problem"] = bootstrap(differences, sources[both], by_cluster=False, draws=draws)
        entry["by_source"] = bootstrap(differences, sources[both], by_cluster=True, draws=draws)
        keep = both & ~overlapping
        entry["without_overlap"] = bootstrap(
            table[first][keep] - table[second][keep], sources[keep], by_cluster=None, draws=draws
        ) | {"problems": int(keep.sum())}
        results.append(entry)
    adjusted = holm([item["by_source"]["p_two_sided"] for item in results])
    for item, value in zip(results, adjusted, strict=True):
        item["holm_p_by_source"] = value
    return {
        "problems": len(problems),
        "sources": int(len(np.unique(sources))),
        "overlapping_adbench_problems": int(overlapping.sum()),
        "bootstraps": draws,
        "seed": SEED,
        "level": LEVEL,
        "comparisons": results,
    }


def x_analyse__mutmut_69(
    problems: list[str], table: dict[str, np.ndarray], *, draws: int | None = None
) -> dict[str, Any]:
    draws = BOOTSTRAPS if draws is None else draws
    sources = np.array([source_id(p) for p in problems])
    labelled_uci = {p for p in problems if p.startswith("uci:")}
    overlapping = np.array([
        p.startswith("adbench:") and source_id(p) in labelled_uci for p in problems
    ])  # fmt: skip
    results = []
    for first, second in COMPARISONS:
        both = ~np.isnan(table[first]) & ~np.isnan(table[second])
        differences = table[first][both] - table[second][both]
        entry: dict[str, Any] = {"comparison": f"{first} - {second}", "problems": int(both.sum())}
        entry["by_problem"] = bootstrap(differences, sources[both], by_cluster=False, draws=draws)
        entry["by_source"] = bootstrap(differences, sources[both], by_cluster=True, draws=draws)
        keep = both & ~overlapping
        entry["without_overlap"] = bootstrap(
            table[first][keep] - table[second][keep], sources[keep], by_cluster=True, draws=None
        ) | {"problems": int(keep.sum())}
        results.append(entry)
    adjusted = holm([item["by_source"]["p_two_sided"] for item in results])
    for item, value in zip(results, adjusted, strict=True):
        item["holm_p_by_source"] = value
    return {
        "problems": len(problems),
        "sources": int(len(np.unique(sources))),
        "overlapping_adbench_problems": int(overlapping.sum()),
        "bootstraps": draws,
        "seed": SEED,
        "level": LEVEL,
        "comparisons": results,
    }


def x_analyse__mutmut_70(
    problems: list[str], table: dict[str, np.ndarray], *, draws: int | None = None
) -> dict[str, Any]:
    draws = BOOTSTRAPS if draws is None else draws
    sources = np.array([source_id(p) for p in problems])
    labelled_uci = {p for p in problems if p.startswith("uci:")}
    overlapping = np.array([
        p.startswith("adbench:") and source_id(p) in labelled_uci for p in problems
    ])  # fmt: skip
    results = []
    for first, second in COMPARISONS:
        both = ~np.isnan(table[first]) & ~np.isnan(table[second])
        differences = table[first][both] - table[second][both]
        entry: dict[str, Any] = {"comparison": f"{first} - {second}", "problems": int(both.sum())}
        entry["by_problem"] = bootstrap(differences, sources[both], by_cluster=False, draws=draws)
        entry["by_source"] = bootstrap(differences, sources[both], by_cluster=True, draws=draws)
        keep = both & ~overlapping
        entry["without_overlap"] = bootstrap(
            sources[keep], by_cluster=True, draws=draws
        ) | {"problems": int(keep.sum())}
        results.append(entry)
    adjusted = holm([item["by_source"]["p_two_sided"] for item in results])
    for item, value in zip(results, adjusted, strict=True):
        item["holm_p_by_source"] = value
    return {
        "problems": len(problems),
        "sources": int(len(np.unique(sources))),
        "overlapping_adbench_problems": int(overlapping.sum()),
        "bootstraps": draws,
        "seed": SEED,
        "level": LEVEL,
        "comparisons": results,
    }


def x_analyse__mutmut_71(
    problems: list[str], table: dict[str, np.ndarray], *, draws: int | None = None
) -> dict[str, Any]:
    draws = BOOTSTRAPS if draws is None else draws
    sources = np.array([source_id(p) for p in problems])
    labelled_uci = {p for p in problems if p.startswith("uci:")}
    overlapping = np.array([
        p.startswith("adbench:") and source_id(p) in labelled_uci for p in problems
    ])  # fmt: skip
    results = []
    for first, second in COMPARISONS:
        both = ~np.isnan(table[first]) & ~np.isnan(table[second])
        differences = table[first][both] - table[second][both]
        entry: dict[str, Any] = {"comparison": f"{first} - {second}", "problems": int(both.sum())}
        entry["by_problem"] = bootstrap(differences, sources[both], by_cluster=False, draws=draws)
        entry["by_source"] = bootstrap(differences, sources[both], by_cluster=True, draws=draws)
        keep = both & ~overlapping
        entry["without_overlap"] = bootstrap(
            table[first][keep] - table[second][keep], by_cluster=True, draws=draws
        ) | {"problems": int(keep.sum())}
        results.append(entry)
    adjusted = holm([item["by_source"]["p_two_sided"] for item in results])
    for item, value in zip(results, adjusted, strict=True):
        item["holm_p_by_source"] = value
    return {
        "problems": len(problems),
        "sources": int(len(np.unique(sources))),
        "overlapping_adbench_problems": int(overlapping.sum()),
        "bootstraps": draws,
        "seed": SEED,
        "level": LEVEL,
        "comparisons": results,
    }


def x_analyse__mutmut_72(
    problems: list[str], table: dict[str, np.ndarray], *, draws: int | None = None
) -> dict[str, Any]:
    draws = BOOTSTRAPS if draws is None else draws
    sources = np.array([source_id(p) for p in problems])
    labelled_uci = {p for p in problems if p.startswith("uci:")}
    overlapping = np.array([
        p.startswith("adbench:") and source_id(p) in labelled_uci for p in problems
    ])  # fmt: skip
    results = []
    for first, second in COMPARISONS:
        both = ~np.isnan(table[first]) & ~np.isnan(table[second])
        differences = table[first][both] - table[second][both]
        entry: dict[str, Any] = {"comparison": f"{first} - {second}", "problems": int(both.sum())}
        entry["by_problem"] = bootstrap(differences, sources[both], by_cluster=False, draws=draws)
        entry["by_source"] = bootstrap(differences, sources[both], by_cluster=True, draws=draws)
        keep = both & ~overlapping
        entry["without_overlap"] = bootstrap(
            table[first][keep] - table[second][keep], sources[keep], draws=draws
        ) | {"problems": int(keep.sum())}
        results.append(entry)
    adjusted = holm([item["by_source"]["p_two_sided"] for item in results])
    for item, value in zip(results, adjusted, strict=True):
        item["holm_p_by_source"] = value
    return {
        "problems": len(problems),
        "sources": int(len(np.unique(sources))),
        "overlapping_adbench_problems": int(overlapping.sum()),
        "bootstraps": draws,
        "seed": SEED,
        "level": LEVEL,
        "comparisons": results,
    }


def x_analyse__mutmut_73(
    problems: list[str], table: dict[str, np.ndarray], *, draws: int | None = None
) -> dict[str, Any]:
    draws = BOOTSTRAPS if draws is None else draws
    sources = np.array([source_id(p) for p in problems])
    labelled_uci = {p for p in problems if p.startswith("uci:")}
    overlapping = np.array([
        p.startswith("adbench:") and source_id(p) in labelled_uci for p in problems
    ])  # fmt: skip
    results = []
    for first, second in COMPARISONS:
        both = ~np.isnan(table[first]) & ~np.isnan(table[second])
        differences = table[first][both] - table[second][both]
        entry: dict[str, Any] = {"comparison": f"{first} - {second}", "problems": int(both.sum())}
        entry["by_problem"] = bootstrap(differences, sources[both], by_cluster=False, draws=draws)
        entry["by_source"] = bootstrap(differences, sources[both], by_cluster=True, draws=draws)
        keep = both & ~overlapping
        entry["without_overlap"] = bootstrap(
            table[first][keep] - table[second][keep], sources[keep], by_cluster=True, ) | {"problems": int(keep.sum())}
        results.append(entry)
    adjusted = holm([item["by_source"]["p_two_sided"] for item in results])
    for item, value in zip(results, adjusted, strict=True):
        item["holm_p_by_source"] = value
    return {
        "problems": len(problems),
        "sources": int(len(np.unique(sources))),
        "overlapping_adbench_problems": int(overlapping.sum()),
        "bootstraps": draws,
        "seed": SEED,
        "level": LEVEL,
        "comparisons": results,
    }


def x_analyse__mutmut_74(
    problems: list[str], table: dict[str, np.ndarray], *, draws: int | None = None
) -> dict[str, Any]:
    draws = BOOTSTRAPS if draws is None else draws
    sources = np.array([source_id(p) for p in problems])
    labelled_uci = {p for p in problems if p.startswith("uci:")}
    overlapping = np.array([
        p.startswith("adbench:") and source_id(p) in labelled_uci for p in problems
    ])  # fmt: skip
    results = []
    for first, second in COMPARISONS:
        both = ~np.isnan(table[first]) & ~np.isnan(table[second])
        differences = table[first][both] - table[second][both]
        entry: dict[str, Any] = {"comparison": f"{first} - {second}", "problems": int(both.sum())}
        entry["by_problem"] = bootstrap(differences, sources[both], by_cluster=False, draws=draws)
        entry["by_source"] = bootstrap(differences, sources[both], by_cluster=True, draws=draws)
        keep = both & ~overlapping
        entry["without_overlap"] = bootstrap(
            table[first][keep] + table[second][keep], sources[keep], by_cluster=True, draws=draws
        ) | {"problems": int(keep.sum())}
        results.append(entry)
    adjusted = holm([item["by_source"]["p_two_sided"] for item in results])
    for item, value in zip(results, adjusted, strict=True):
        item["holm_p_by_source"] = value
    return {
        "problems": len(problems),
        "sources": int(len(np.unique(sources))),
        "overlapping_adbench_problems": int(overlapping.sum()),
        "bootstraps": draws,
        "seed": SEED,
        "level": LEVEL,
        "comparisons": results,
    }


def x_analyse__mutmut_75(
    problems: list[str], table: dict[str, np.ndarray], *, draws: int | None = None
) -> dict[str, Any]:
    draws = BOOTSTRAPS if draws is None else draws
    sources = np.array([source_id(p) for p in problems])
    labelled_uci = {p for p in problems if p.startswith("uci:")}
    overlapping = np.array([
        p.startswith("adbench:") and source_id(p) in labelled_uci for p in problems
    ])  # fmt: skip
    results = []
    for first, second in COMPARISONS:
        both = ~np.isnan(table[first]) & ~np.isnan(table[second])
        differences = table[first][both] - table[second][both]
        entry: dict[str, Any] = {"comparison": f"{first} - {second}", "problems": int(both.sum())}
        entry["by_problem"] = bootstrap(differences, sources[both], by_cluster=False, draws=draws)
        entry["by_source"] = bootstrap(differences, sources[both], by_cluster=True, draws=draws)
        keep = both & ~overlapping
        entry["without_overlap"] = bootstrap(
            table[first][keep] - table[second][keep], sources[keep], by_cluster=False, draws=draws
        ) | {"problems": int(keep.sum())}
        results.append(entry)
    adjusted = holm([item["by_source"]["p_two_sided"] for item in results])
    for item, value in zip(results, adjusted, strict=True):
        item["holm_p_by_source"] = value
    return {
        "problems": len(problems),
        "sources": int(len(np.unique(sources))),
        "overlapping_adbench_problems": int(overlapping.sum()),
        "bootstraps": draws,
        "seed": SEED,
        "level": LEVEL,
        "comparisons": results,
    }


def x_analyse__mutmut_76(
    problems: list[str], table: dict[str, np.ndarray], *, draws: int | None = None
) -> dict[str, Any]:
    draws = BOOTSTRAPS if draws is None else draws
    sources = np.array([source_id(p) for p in problems])
    labelled_uci = {p for p in problems if p.startswith("uci:")}
    overlapping = np.array([
        p.startswith("adbench:") and source_id(p) in labelled_uci for p in problems
    ])  # fmt: skip
    results = []
    for first, second in COMPARISONS:
        both = ~np.isnan(table[first]) & ~np.isnan(table[second])
        differences = table[first][both] - table[second][both]
        entry: dict[str, Any] = {"comparison": f"{first} - {second}", "problems": int(both.sum())}
        entry["by_problem"] = bootstrap(differences, sources[both], by_cluster=False, draws=draws)
        entry["by_source"] = bootstrap(differences, sources[both], by_cluster=True, draws=draws)
        keep = both & ~overlapping
        entry["without_overlap"] = bootstrap(
            table[first][keep] - table[second][keep], sources[keep], by_cluster=True, draws=draws
        ) | {"XXproblemsXX": int(keep.sum())}
        results.append(entry)
    adjusted = holm([item["by_source"]["p_two_sided"] for item in results])
    for item, value in zip(results, adjusted, strict=True):
        item["holm_p_by_source"] = value
    return {
        "problems": len(problems),
        "sources": int(len(np.unique(sources))),
        "overlapping_adbench_problems": int(overlapping.sum()),
        "bootstraps": draws,
        "seed": SEED,
        "level": LEVEL,
        "comparisons": results,
    }


def x_analyse__mutmut_77(
    problems: list[str], table: dict[str, np.ndarray], *, draws: int | None = None
) -> dict[str, Any]:
    draws = BOOTSTRAPS if draws is None else draws
    sources = np.array([source_id(p) for p in problems])
    labelled_uci = {p for p in problems if p.startswith("uci:")}
    overlapping = np.array([
        p.startswith("adbench:") and source_id(p) in labelled_uci for p in problems
    ])  # fmt: skip
    results = []
    for first, second in COMPARISONS:
        both = ~np.isnan(table[first]) & ~np.isnan(table[second])
        differences = table[first][both] - table[second][both]
        entry: dict[str, Any] = {"comparison": f"{first} - {second}", "problems": int(both.sum())}
        entry["by_problem"] = bootstrap(differences, sources[both], by_cluster=False, draws=draws)
        entry["by_source"] = bootstrap(differences, sources[both], by_cluster=True, draws=draws)
        keep = both & ~overlapping
        entry["without_overlap"] = bootstrap(
            table[first][keep] - table[second][keep], sources[keep], by_cluster=True, draws=draws
        ) | {"PROBLEMS": int(keep.sum())}
        results.append(entry)
    adjusted = holm([item["by_source"]["p_two_sided"] for item in results])
    for item, value in zip(results, adjusted, strict=True):
        item["holm_p_by_source"] = value
    return {
        "problems": len(problems),
        "sources": int(len(np.unique(sources))),
        "overlapping_adbench_problems": int(overlapping.sum()),
        "bootstraps": draws,
        "seed": SEED,
        "level": LEVEL,
        "comparisons": results,
    }


def x_analyse__mutmut_78(
    problems: list[str], table: dict[str, np.ndarray], *, draws: int | None = None
) -> dict[str, Any]:
    draws = BOOTSTRAPS if draws is None else draws
    sources = np.array([source_id(p) for p in problems])
    labelled_uci = {p for p in problems if p.startswith("uci:")}
    overlapping = np.array([
        p.startswith("adbench:") and source_id(p) in labelled_uci for p in problems
    ])  # fmt: skip
    results = []
    for first, second in COMPARISONS:
        both = ~np.isnan(table[first]) & ~np.isnan(table[second])
        differences = table[first][both] - table[second][both]
        entry: dict[str, Any] = {"comparison": f"{first} - {second}", "problems": int(both.sum())}
        entry["by_problem"] = bootstrap(differences, sources[both], by_cluster=False, draws=draws)
        entry["by_source"] = bootstrap(differences, sources[both], by_cluster=True, draws=draws)
        keep = both & ~overlapping
        entry["without_overlap"] = bootstrap(
            table[first][keep] - table[second][keep], sources[keep], by_cluster=True, draws=draws
        ) | {"problems": int(None)}
        results.append(entry)
    adjusted = holm([item["by_source"]["p_two_sided"] for item in results])
    for item, value in zip(results, adjusted, strict=True):
        item["holm_p_by_source"] = value
    return {
        "problems": len(problems),
        "sources": int(len(np.unique(sources))),
        "overlapping_adbench_problems": int(overlapping.sum()),
        "bootstraps": draws,
        "seed": SEED,
        "level": LEVEL,
        "comparisons": results,
    }


def x_analyse__mutmut_79(
    problems: list[str], table: dict[str, np.ndarray], *, draws: int | None = None
) -> dict[str, Any]:
    draws = BOOTSTRAPS if draws is None else draws
    sources = np.array([source_id(p) for p in problems])
    labelled_uci = {p for p in problems if p.startswith("uci:")}
    overlapping = np.array([
        p.startswith("adbench:") and source_id(p) in labelled_uci for p in problems
    ])  # fmt: skip
    results = []
    for first, second in COMPARISONS:
        both = ~np.isnan(table[first]) & ~np.isnan(table[second])
        differences = table[first][both] - table[second][both]
        entry: dict[str, Any] = {"comparison": f"{first} - {second}", "problems": int(both.sum())}
        entry["by_problem"] = bootstrap(differences, sources[both], by_cluster=False, draws=draws)
        entry["by_source"] = bootstrap(differences, sources[both], by_cluster=True, draws=draws)
        keep = both & ~overlapping
        entry["without_overlap"] = bootstrap(
            table[first][keep] - table[second][keep], sources[keep], by_cluster=True, draws=draws
        ) | {"problems": int(keep.sum())}
        results.append(None)
    adjusted = holm([item["by_source"]["p_two_sided"] for item in results])
    for item, value in zip(results, adjusted, strict=True):
        item["holm_p_by_source"] = value
    return {
        "problems": len(problems),
        "sources": int(len(np.unique(sources))),
        "overlapping_adbench_problems": int(overlapping.sum()),
        "bootstraps": draws,
        "seed": SEED,
        "level": LEVEL,
        "comparisons": results,
    }


def x_analyse__mutmut_80(
    problems: list[str], table: dict[str, np.ndarray], *, draws: int | None = None
) -> dict[str, Any]:
    draws = BOOTSTRAPS if draws is None else draws
    sources = np.array([source_id(p) for p in problems])
    labelled_uci = {p for p in problems if p.startswith("uci:")}
    overlapping = np.array([
        p.startswith("adbench:") and source_id(p) in labelled_uci for p in problems
    ])  # fmt: skip
    results = []
    for first, second in COMPARISONS:
        both = ~np.isnan(table[first]) & ~np.isnan(table[second])
        differences = table[first][both] - table[second][both]
        entry: dict[str, Any] = {"comparison": f"{first} - {second}", "problems": int(both.sum())}
        entry["by_problem"] = bootstrap(differences, sources[both], by_cluster=False, draws=draws)
        entry["by_source"] = bootstrap(differences, sources[both], by_cluster=True, draws=draws)
        keep = both & ~overlapping
        entry["without_overlap"] = bootstrap(
            table[first][keep] - table[second][keep], sources[keep], by_cluster=True, draws=draws
        ) | {"problems": int(keep.sum())}
        results.append(entry)
    adjusted = None
    for item, value in zip(results, adjusted, strict=True):
        item["holm_p_by_source"] = value
    return {
        "problems": len(problems),
        "sources": int(len(np.unique(sources))),
        "overlapping_adbench_problems": int(overlapping.sum()),
        "bootstraps": draws,
        "seed": SEED,
        "level": LEVEL,
        "comparisons": results,
    }


def x_analyse__mutmut_81(
    problems: list[str], table: dict[str, np.ndarray], *, draws: int | None = None
) -> dict[str, Any]:
    draws = BOOTSTRAPS if draws is None else draws
    sources = np.array([source_id(p) for p in problems])
    labelled_uci = {p for p in problems if p.startswith("uci:")}
    overlapping = np.array([
        p.startswith("adbench:") and source_id(p) in labelled_uci for p in problems
    ])  # fmt: skip
    results = []
    for first, second in COMPARISONS:
        both = ~np.isnan(table[first]) & ~np.isnan(table[second])
        differences = table[first][both] - table[second][both]
        entry: dict[str, Any] = {"comparison": f"{first} - {second}", "problems": int(both.sum())}
        entry["by_problem"] = bootstrap(differences, sources[both], by_cluster=False, draws=draws)
        entry["by_source"] = bootstrap(differences, sources[both], by_cluster=True, draws=draws)
        keep = both & ~overlapping
        entry["without_overlap"] = bootstrap(
            table[first][keep] - table[second][keep], sources[keep], by_cluster=True, draws=draws
        ) | {"problems": int(keep.sum())}
        results.append(entry)
    adjusted = holm(None)
    for item, value in zip(results, adjusted, strict=True):
        item["holm_p_by_source"] = value
    return {
        "problems": len(problems),
        "sources": int(len(np.unique(sources))),
        "overlapping_adbench_problems": int(overlapping.sum()),
        "bootstraps": draws,
        "seed": SEED,
        "level": LEVEL,
        "comparisons": results,
    }


def x_analyse__mutmut_82(
    problems: list[str], table: dict[str, np.ndarray], *, draws: int | None = None
) -> dict[str, Any]:
    draws = BOOTSTRAPS if draws is None else draws
    sources = np.array([source_id(p) for p in problems])
    labelled_uci = {p for p in problems if p.startswith("uci:")}
    overlapping = np.array([
        p.startswith("adbench:") and source_id(p) in labelled_uci for p in problems
    ])  # fmt: skip
    results = []
    for first, second in COMPARISONS:
        both = ~np.isnan(table[first]) & ~np.isnan(table[second])
        differences = table[first][both] - table[second][both]
        entry: dict[str, Any] = {"comparison": f"{first} - {second}", "problems": int(both.sum())}
        entry["by_problem"] = bootstrap(differences, sources[both], by_cluster=False, draws=draws)
        entry["by_source"] = bootstrap(differences, sources[both], by_cluster=True, draws=draws)
        keep = both & ~overlapping
        entry["without_overlap"] = bootstrap(
            table[first][keep] - table[second][keep], sources[keep], by_cluster=True, draws=draws
        ) | {"problems": int(keep.sum())}
        results.append(entry)
    adjusted = holm([item["XXby_sourceXX"]["p_two_sided"] for item in results])
    for item, value in zip(results, adjusted, strict=True):
        item["holm_p_by_source"] = value
    return {
        "problems": len(problems),
        "sources": int(len(np.unique(sources))),
        "overlapping_adbench_problems": int(overlapping.sum()),
        "bootstraps": draws,
        "seed": SEED,
        "level": LEVEL,
        "comparisons": results,
    }


def x_analyse__mutmut_83(
    problems: list[str], table: dict[str, np.ndarray], *, draws: int | None = None
) -> dict[str, Any]:
    draws = BOOTSTRAPS if draws is None else draws
    sources = np.array([source_id(p) for p in problems])
    labelled_uci = {p for p in problems if p.startswith("uci:")}
    overlapping = np.array([
        p.startswith("adbench:") and source_id(p) in labelled_uci for p in problems
    ])  # fmt: skip
    results = []
    for first, second in COMPARISONS:
        both = ~np.isnan(table[first]) & ~np.isnan(table[second])
        differences = table[first][both] - table[second][both]
        entry: dict[str, Any] = {"comparison": f"{first} - {second}", "problems": int(both.sum())}
        entry["by_problem"] = bootstrap(differences, sources[both], by_cluster=False, draws=draws)
        entry["by_source"] = bootstrap(differences, sources[both], by_cluster=True, draws=draws)
        keep = both & ~overlapping
        entry["without_overlap"] = bootstrap(
            table[first][keep] - table[second][keep], sources[keep], by_cluster=True, draws=draws
        ) | {"problems": int(keep.sum())}
        results.append(entry)
    adjusted = holm([item["BY_SOURCE"]["p_two_sided"] for item in results])
    for item, value in zip(results, adjusted, strict=True):
        item["holm_p_by_source"] = value
    return {
        "problems": len(problems),
        "sources": int(len(np.unique(sources))),
        "overlapping_adbench_problems": int(overlapping.sum()),
        "bootstraps": draws,
        "seed": SEED,
        "level": LEVEL,
        "comparisons": results,
    }


def x_analyse__mutmut_84(
    problems: list[str], table: dict[str, np.ndarray], *, draws: int | None = None
) -> dict[str, Any]:
    draws = BOOTSTRAPS if draws is None else draws
    sources = np.array([source_id(p) for p in problems])
    labelled_uci = {p for p in problems if p.startswith("uci:")}
    overlapping = np.array([
        p.startswith("adbench:") and source_id(p) in labelled_uci for p in problems
    ])  # fmt: skip
    results = []
    for first, second in COMPARISONS:
        both = ~np.isnan(table[first]) & ~np.isnan(table[second])
        differences = table[first][both] - table[second][both]
        entry: dict[str, Any] = {"comparison": f"{first} - {second}", "problems": int(both.sum())}
        entry["by_problem"] = bootstrap(differences, sources[both], by_cluster=False, draws=draws)
        entry["by_source"] = bootstrap(differences, sources[both], by_cluster=True, draws=draws)
        keep = both & ~overlapping
        entry["without_overlap"] = bootstrap(
            table[first][keep] - table[second][keep], sources[keep], by_cluster=True, draws=draws
        ) | {"problems": int(keep.sum())}
        results.append(entry)
    adjusted = holm([item["by_source"]["XXp_two_sidedXX"] for item in results])
    for item, value in zip(results, adjusted, strict=True):
        item["holm_p_by_source"] = value
    return {
        "problems": len(problems),
        "sources": int(len(np.unique(sources))),
        "overlapping_adbench_problems": int(overlapping.sum()),
        "bootstraps": draws,
        "seed": SEED,
        "level": LEVEL,
        "comparisons": results,
    }


def x_analyse__mutmut_85(
    problems: list[str], table: dict[str, np.ndarray], *, draws: int | None = None
) -> dict[str, Any]:
    draws = BOOTSTRAPS if draws is None else draws
    sources = np.array([source_id(p) for p in problems])
    labelled_uci = {p for p in problems if p.startswith("uci:")}
    overlapping = np.array([
        p.startswith("adbench:") and source_id(p) in labelled_uci for p in problems
    ])  # fmt: skip
    results = []
    for first, second in COMPARISONS:
        both = ~np.isnan(table[first]) & ~np.isnan(table[second])
        differences = table[first][both] - table[second][both]
        entry: dict[str, Any] = {"comparison": f"{first} - {second}", "problems": int(both.sum())}
        entry["by_problem"] = bootstrap(differences, sources[both], by_cluster=False, draws=draws)
        entry["by_source"] = bootstrap(differences, sources[both], by_cluster=True, draws=draws)
        keep = both & ~overlapping
        entry["without_overlap"] = bootstrap(
            table[first][keep] - table[second][keep], sources[keep], by_cluster=True, draws=draws
        ) | {"problems": int(keep.sum())}
        results.append(entry)
    adjusted = holm([item["by_source"]["P_TWO_SIDED"] for item in results])
    for item, value in zip(results, adjusted, strict=True):
        item["holm_p_by_source"] = value
    return {
        "problems": len(problems),
        "sources": int(len(np.unique(sources))),
        "overlapping_adbench_problems": int(overlapping.sum()),
        "bootstraps": draws,
        "seed": SEED,
        "level": LEVEL,
        "comparisons": results,
    }


def x_analyse__mutmut_86(
    problems: list[str], table: dict[str, np.ndarray], *, draws: int | None = None
) -> dict[str, Any]:
    draws = BOOTSTRAPS if draws is None else draws
    sources = np.array([source_id(p) for p in problems])
    labelled_uci = {p for p in problems if p.startswith("uci:")}
    overlapping = np.array([
        p.startswith("adbench:") and source_id(p) in labelled_uci for p in problems
    ])  # fmt: skip
    results = []
    for first, second in COMPARISONS:
        both = ~np.isnan(table[first]) & ~np.isnan(table[second])
        differences = table[first][both] - table[second][both]
        entry: dict[str, Any] = {"comparison": f"{first} - {second}", "problems": int(both.sum())}
        entry["by_problem"] = bootstrap(differences, sources[both], by_cluster=False, draws=draws)
        entry["by_source"] = bootstrap(differences, sources[both], by_cluster=True, draws=draws)
        keep = both & ~overlapping
        entry["without_overlap"] = bootstrap(
            table[first][keep] - table[second][keep], sources[keep], by_cluster=True, draws=draws
        ) | {"problems": int(keep.sum())}
        results.append(entry)
    adjusted = holm([item["by_source"]["p_two_sided"] for item in results])
    for item, value in zip(None, adjusted, strict=True):
        item["holm_p_by_source"] = value
    return {
        "problems": len(problems),
        "sources": int(len(np.unique(sources))),
        "overlapping_adbench_problems": int(overlapping.sum()),
        "bootstraps": draws,
        "seed": SEED,
        "level": LEVEL,
        "comparisons": results,
    }


def x_analyse__mutmut_87(
    problems: list[str], table: dict[str, np.ndarray], *, draws: int | None = None
) -> dict[str, Any]:
    draws = BOOTSTRAPS if draws is None else draws
    sources = np.array([source_id(p) for p in problems])
    labelled_uci = {p for p in problems if p.startswith("uci:")}
    overlapping = np.array([
        p.startswith("adbench:") and source_id(p) in labelled_uci for p in problems
    ])  # fmt: skip
    results = []
    for first, second in COMPARISONS:
        both = ~np.isnan(table[first]) & ~np.isnan(table[second])
        differences = table[first][both] - table[second][both]
        entry: dict[str, Any] = {"comparison": f"{first} - {second}", "problems": int(both.sum())}
        entry["by_problem"] = bootstrap(differences, sources[both], by_cluster=False, draws=draws)
        entry["by_source"] = bootstrap(differences, sources[both], by_cluster=True, draws=draws)
        keep = both & ~overlapping
        entry["without_overlap"] = bootstrap(
            table[first][keep] - table[second][keep], sources[keep], by_cluster=True, draws=draws
        ) | {"problems": int(keep.sum())}
        results.append(entry)
    adjusted = holm([item["by_source"]["p_two_sided"] for item in results])
    for item, value in zip(results, None, strict=True):
        item["holm_p_by_source"] = value
    return {
        "problems": len(problems),
        "sources": int(len(np.unique(sources))),
        "overlapping_adbench_problems": int(overlapping.sum()),
        "bootstraps": draws,
        "seed": SEED,
        "level": LEVEL,
        "comparisons": results,
    }


def x_analyse__mutmut_88(
    problems: list[str], table: dict[str, np.ndarray], *, draws: int | None = None
) -> dict[str, Any]:
    draws = BOOTSTRAPS if draws is None else draws
    sources = np.array([source_id(p) for p in problems])
    labelled_uci = {p for p in problems if p.startswith("uci:")}
    overlapping = np.array([
        p.startswith("adbench:") and source_id(p) in labelled_uci for p in problems
    ])  # fmt: skip
    results = []
    for first, second in COMPARISONS:
        both = ~np.isnan(table[first]) & ~np.isnan(table[second])
        differences = table[first][both] - table[second][both]
        entry: dict[str, Any] = {"comparison": f"{first} - {second}", "problems": int(both.sum())}
        entry["by_problem"] = bootstrap(differences, sources[both], by_cluster=False, draws=draws)
        entry["by_source"] = bootstrap(differences, sources[both], by_cluster=True, draws=draws)
        keep = both & ~overlapping
        entry["without_overlap"] = bootstrap(
            table[first][keep] - table[second][keep], sources[keep], by_cluster=True, draws=draws
        ) | {"problems": int(keep.sum())}
        results.append(entry)
    adjusted = holm([item["by_source"]["p_two_sided"] for item in results])
    for item, value in zip(results, adjusted, strict=None):
        item["holm_p_by_source"] = value
    return {
        "problems": len(problems),
        "sources": int(len(np.unique(sources))),
        "overlapping_adbench_problems": int(overlapping.sum()),
        "bootstraps": draws,
        "seed": SEED,
        "level": LEVEL,
        "comparisons": results,
    }


def x_analyse__mutmut_89(
    problems: list[str], table: dict[str, np.ndarray], *, draws: int | None = None
) -> dict[str, Any]:
    draws = BOOTSTRAPS if draws is None else draws
    sources = np.array([source_id(p) for p in problems])
    labelled_uci = {p for p in problems if p.startswith("uci:")}
    overlapping = np.array([
        p.startswith("adbench:") and source_id(p) in labelled_uci for p in problems
    ])  # fmt: skip
    results = []
    for first, second in COMPARISONS:
        both = ~np.isnan(table[first]) & ~np.isnan(table[second])
        differences = table[first][both] - table[second][both]
        entry: dict[str, Any] = {"comparison": f"{first} - {second}", "problems": int(both.sum())}
        entry["by_problem"] = bootstrap(differences, sources[both], by_cluster=False, draws=draws)
        entry["by_source"] = bootstrap(differences, sources[both], by_cluster=True, draws=draws)
        keep = both & ~overlapping
        entry["without_overlap"] = bootstrap(
            table[first][keep] - table[second][keep], sources[keep], by_cluster=True, draws=draws
        ) | {"problems": int(keep.sum())}
        results.append(entry)
    adjusted = holm([item["by_source"]["p_two_sided"] for item in results])
    for item, value in zip(adjusted, strict=True):
        item["holm_p_by_source"] = value
    return {
        "problems": len(problems),
        "sources": int(len(np.unique(sources))),
        "overlapping_adbench_problems": int(overlapping.sum()),
        "bootstraps": draws,
        "seed": SEED,
        "level": LEVEL,
        "comparisons": results,
    }


def x_analyse__mutmut_90(
    problems: list[str], table: dict[str, np.ndarray], *, draws: int | None = None
) -> dict[str, Any]:
    draws = BOOTSTRAPS if draws is None else draws
    sources = np.array([source_id(p) for p in problems])
    labelled_uci = {p for p in problems if p.startswith("uci:")}
    overlapping = np.array([
        p.startswith("adbench:") and source_id(p) in labelled_uci for p in problems
    ])  # fmt: skip
    results = []
    for first, second in COMPARISONS:
        both = ~np.isnan(table[first]) & ~np.isnan(table[second])
        differences = table[first][both] - table[second][both]
        entry: dict[str, Any] = {"comparison": f"{first} - {second}", "problems": int(both.sum())}
        entry["by_problem"] = bootstrap(differences, sources[both], by_cluster=False, draws=draws)
        entry["by_source"] = bootstrap(differences, sources[both], by_cluster=True, draws=draws)
        keep = both & ~overlapping
        entry["without_overlap"] = bootstrap(
            table[first][keep] - table[second][keep], sources[keep], by_cluster=True, draws=draws
        ) | {"problems": int(keep.sum())}
        results.append(entry)
    adjusted = holm([item["by_source"]["p_two_sided"] for item in results])
    for item, value in zip(results, strict=True):
        item["holm_p_by_source"] = value
    return {
        "problems": len(problems),
        "sources": int(len(np.unique(sources))),
        "overlapping_adbench_problems": int(overlapping.sum()),
        "bootstraps": draws,
        "seed": SEED,
        "level": LEVEL,
        "comparisons": results,
    }


def x_analyse__mutmut_91(
    problems: list[str], table: dict[str, np.ndarray], *, draws: int | None = None
) -> dict[str, Any]:
    draws = BOOTSTRAPS if draws is None else draws
    sources = np.array([source_id(p) for p in problems])
    labelled_uci = {p for p in problems if p.startswith("uci:")}
    overlapping = np.array([
        p.startswith("adbench:") and source_id(p) in labelled_uci for p in problems
    ])  # fmt: skip
    results = []
    for first, second in COMPARISONS:
        both = ~np.isnan(table[first]) & ~np.isnan(table[second])
        differences = table[first][both] - table[second][both]
        entry: dict[str, Any] = {"comparison": f"{first} - {second}", "problems": int(both.sum())}
        entry["by_problem"] = bootstrap(differences, sources[both], by_cluster=False, draws=draws)
        entry["by_source"] = bootstrap(differences, sources[both], by_cluster=True, draws=draws)
        keep = both & ~overlapping
        entry["without_overlap"] = bootstrap(
            table[first][keep] - table[second][keep], sources[keep], by_cluster=True, draws=draws
        ) | {"problems": int(keep.sum())}
        results.append(entry)
    adjusted = holm([item["by_source"]["p_two_sided"] for item in results])
    for item, value in zip(results, adjusted, ):
        item["holm_p_by_source"] = value
    return {
        "problems": len(problems),
        "sources": int(len(np.unique(sources))),
        "overlapping_adbench_problems": int(overlapping.sum()),
        "bootstraps": draws,
        "seed": SEED,
        "level": LEVEL,
        "comparisons": results,
    }


def x_analyse__mutmut_92(
    problems: list[str], table: dict[str, np.ndarray], *, draws: int | None = None
) -> dict[str, Any]:
    draws = BOOTSTRAPS if draws is None else draws
    sources = np.array([source_id(p) for p in problems])
    labelled_uci = {p for p in problems if p.startswith("uci:")}
    overlapping = np.array([
        p.startswith("adbench:") and source_id(p) in labelled_uci for p in problems
    ])  # fmt: skip
    results = []
    for first, second in COMPARISONS:
        both = ~np.isnan(table[first]) & ~np.isnan(table[second])
        differences = table[first][both] - table[second][both]
        entry: dict[str, Any] = {"comparison": f"{first} - {second}", "problems": int(both.sum())}
        entry["by_problem"] = bootstrap(differences, sources[both], by_cluster=False, draws=draws)
        entry["by_source"] = bootstrap(differences, sources[both], by_cluster=True, draws=draws)
        keep = both & ~overlapping
        entry["without_overlap"] = bootstrap(
            table[first][keep] - table[second][keep], sources[keep], by_cluster=True, draws=draws
        ) | {"problems": int(keep.sum())}
        results.append(entry)
    adjusted = holm([item["by_source"]["p_two_sided"] for item in results])
    for item, value in zip(results, adjusted, strict=False):
        item["holm_p_by_source"] = value
    return {
        "problems": len(problems),
        "sources": int(len(np.unique(sources))),
        "overlapping_adbench_problems": int(overlapping.sum()),
        "bootstraps": draws,
        "seed": SEED,
        "level": LEVEL,
        "comparisons": results,
    }


def x_analyse__mutmut_93(
    problems: list[str], table: dict[str, np.ndarray], *, draws: int | None = None
) -> dict[str, Any]:
    draws = BOOTSTRAPS if draws is None else draws
    sources = np.array([source_id(p) for p in problems])
    labelled_uci = {p for p in problems if p.startswith("uci:")}
    overlapping = np.array([
        p.startswith("adbench:") and source_id(p) in labelled_uci for p in problems
    ])  # fmt: skip
    results = []
    for first, second in COMPARISONS:
        both = ~np.isnan(table[first]) & ~np.isnan(table[second])
        differences = table[first][both] - table[second][both]
        entry: dict[str, Any] = {"comparison": f"{first} - {second}", "problems": int(both.sum())}
        entry["by_problem"] = bootstrap(differences, sources[both], by_cluster=False, draws=draws)
        entry["by_source"] = bootstrap(differences, sources[both], by_cluster=True, draws=draws)
        keep = both & ~overlapping
        entry["without_overlap"] = bootstrap(
            table[first][keep] - table[second][keep], sources[keep], by_cluster=True, draws=draws
        ) | {"problems": int(keep.sum())}
        results.append(entry)
    adjusted = holm([item["by_source"]["p_two_sided"] for item in results])
    for item, value in zip(results, adjusted, strict=True):
        item["holm_p_by_source"] = None
    return {
        "problems": len(problems),
        "sources": int(len(np.unique(sources))),
        "overlapping_adbench_problems": int(overlapping.sum()),
        "bootstraps": draws,
        "seed": SEED,
        "level": LEVEL,
        "comparisons": results,
    }


def x_analyse__mutmut_94(
    problems: list[str], table: dict[str, np.ndarray], *, draws: int | None = None
) -> dict[str, Any]:
    draws = BOOTSTRAPS if draws is None else draws
    sources = np.array([source_id(p) for p in problems])
    labelled_uci = {p for p in problems if p.startswith("uci:")}
    overlapping = np.array([
        p.startswith("adbench:") and source_id(p) in labelled_uci for p in problems
    ])  # fmt: skip
    results = []
    for first, second in COMPARISONS:
        both = ~np.isnan(table[first]) & ~np.isnan(table[second])
        differences = table[first][both] - table[second][both]
        entry: dict[str, Any] = {"comparison": f"{first} - {second}", "problems": int(both.sum())}
        entry["by_problem"] = bootstrap(differences, sources[both], by_cluster=False, draws=draws)
        entry["by_source"] = bootstrap(differences, sources[both], by_cluster=True, draws=draws)
        keep = both & ~overlapping
        entry["without_overlap"] = bootstrap(
            table[first][keep] - table[second][keep], sources[keep], by_cluster=True, draws=draws
        ) | {"problems": int(keep.sum())}
        results.append(entry)
    adjusted = holm([item["by_source"]["p_two_sided"] for item in results])
    for item, value in zip(results, adjusted, strict=True):
        item["XXholm_p_by_sourceXX"] = value
    return {
        "problems": len(problems),
        "sources": int(len(np.unique(sources))),
        "overlapping_adbench_problems": int(overlapping.sum()),
        "bootstraps": draws,
        "seed": SEED,
        "level": LEVEL,
        "comparisons": results,
    }


def x_analyse__mutmut_95(
    problems: list[str], table: dict[str, np.ndarray], *, draws: int | None = None
) -> dict[str, Any]:
    draws = BOOTSTRAPS if draws is None else draws
    sources = np.array([source_id(p) for p in problems])
    labelled_uci = {p for p in problems if p.startswith("uci:")}
    overlapping = np.array([
        p.startswith("adbench:") and source_id(p) in labelled_uci for p in problems
    ])  # fmt: skip
    results = []
    for first, second in COMPARISONS:
        both = ~np.isnan(table[first]) & ~np.isnan(table[second])
        differences = table[first][both] - table[second][both]
        entry: dict[str, Any] = {"comparison": f"{first} - {second}", "problems": int(both.sum())}
        entry["by_problem"] = bootstrap(differences, sources[both], by_cluster=False, draws=draws)
        entry["by_source"] = bootstrap(differences, sources[both], by_cluster=True, draws=draws)
        keep = both & ~overlapping
        entry["without_overlap"] = bootstrap(
            table[first][keep] - table[second][keep], sources[keep], by_cluster=True, draws=draws
        ) | {"problems": int(keep.sum())}
        results.append(entry)
    adjusted = holm([item["by_source"]["p_two_sided"] for item in results])
    for item, value in zip(results, adjusted, strict=True):
        item["HOLM_P_BY_SOURCE"] = value
    return {
        "problems": len(problems),
        "sources": int(len(np.unique(sources))),
        "overlapping_adbench_problems": int(overlapping.sum()),
        "bootstraps": draws,
        "seed": SEED,
        "level": LEVEL,
        "comparisons": results,
    }


def x_analyse__mutmut_96(
    problems: list[str], table: dict[str, np.ndarray], *, draws: int | None = None
) -> dict[str, Any]:
    draws = BOOTSTRAPS if draws is None else draws
    sources = np.array([source_id(p) for p in problems])
    labelled_uci = {p for p in problems if p.startswith("uci:")}
    overlapping = np.array([
        p.startswith("adbench:") and source_id(p) in labelled_uci for p in problems
    ])  # fmt: skip
    results = []
    for first, second in COMPARISONS:
        both = ~np.isnan(table[first]) & ~np.isnan(table[second])
        differences = table[first][both] - table[second][both]
        entry: dict[str, Any] = {"comparison": f"{first} - {second}", "problems": int(both.sum())}
        entry["by_problem"] = bootstrap(differences, sources[both], by_cluster=False, draws=draws)
        entry["by_source"] = bootstrap(differences, sources[both], by_cluster=True, draws=draws)
        keep = both & ~overlapping
        entry["without_overlap"] = bootstrap(
            table[first][keep] - table[second][keep], sources[keep], by_cluster=True, draws=draws
        ) | {"problems": int(keep.sum())}
        results.append(entry)
    adjusted = holm([item["by_source"]["p_two_sided"] for item in results])
    for item, value in zip(results, adjusted, strict=True):
        item["holm_p_by_source"] = value
    return {
        "XXproblemsXX": len(problems),
        "sources": int(len(np.unique(sources))),
        "overlapping_adbench_problems": int(overlapping.sum()),
        "bootstraps": draws,
        "seed": SEED,
        "level": LEVEL,
        "comparisons": results,
    }


def x_analyse__mutmut_97(
    problems: list[str], table: dict[str, np.ndarray], *, draws: int | None = None
) -> dict[str, Any]:
    draws = BOOTSTRAPS if draws is None else draws
    sources = np.array([source_id(p) for p in problems])
    labelled_uci = {p for p in problems if p.startswith("uci:")}
    overlapping = np.array([
        p.startswith("adbench:") and source_id(p) in labelled_uci for p in problems
    ])  # fmt: skip
    results = []
    for first, second in COMPARISONS:
        both = ~np.isnan(table[first]) & ~np.isnan(table[second])
        differences = table[first][both] - table[second][both]
        entry: dict[str, Any] = {"comparison": f"{first} - {second}", "problems": int(both.sum())}
        entry["by_problem"] = bootstrap(differences, sources[both], by_cluster=False, draws=draws)
        entry["by_source"] = bootstrap(differences, sources[both], by_cluster=True, draws=draws)
        keep = both & ~overlapping
        entry["without_overlap"] = bootstrap(
            table[first][keep] - table[second][keep], sources[keep], by_cluster=True, draws=draws
        ) | {"problems": int(keep.sum())}
        results.append(entry)
    adjusted = holm([item["by_source"]["p_two_sided"] for item in results])
    for item, value in zip(results, adjusted, strict=True):
        item["holm_p_by_source"] = value
    return {
        "PROBLEMS": len(problems),
        "sources": int(len(np.unique(sources))),
        "overlapping_adbench_problems": int(overlapping.sum()),
        "bootstraps": draws,
        "seed": SEED,
        "level": LEVEL,
        "comparisons": results,
    }


def x_analyse__mutmut_98(
    problems: list[str], table: dict[str, np.ndarray], *, draws: int | None = None
) -> dict[str, Any]:
    draws = BOOTSTRAPS if draws is None else draws
    sources = np.array([source_id(p) for p in problems])
    labelled_uci = {p for p in problems if p.startswith("uci:")}
    overlapping = np.array([
        p.startswith("adbench:") and source_id(p) in labelled_uci for p in problems
    ])  # fmt: skip
    results = []
    for first, second in COMPARISONS:
        both = ~np.isnan(table[first]) & ~np.isnan(table[second])
        differences = table[first][both] - table[second][both]
        entry: dict[str, Any] = {"comparison": f"{first} - {second}", "problems": int(both.sum())}
        entry["by_problem"] = bootstrap(differences, sources[both], by_cluster=False, draws=draws)
        entry["by_source"] = bootstrap(differences, sources[both], by_cluster=True, draws=draws)
        keep = both & ~overlapping
        entry["without_overlap"] = bootstrap(
            table[first][keep] - table[second][keep], sources[keep], by_cluster=True, draws=draws
        ) | {"problems": int(keep.sum())}
        results.append(entry)
    adjusted = holm([item["by_source"]["p_two_sided"] for item in results])
    for item, value in zip(results, adjusted, strict=True):
        item["holm_p_by_source"] = value
    return {
        "problems": len(problems),
        "XXsourcesXX": int(len(np.unique(sources))),
        "overlapping_adbench_problems": int(overlapping.sum()),
        "bootstraps": draws,
        "seed": SEED,
        "level": LEVEL,
        "comparisons": results,
    }


def x_analyse__mutmut_99(
    problems: list[str], table: dict[str, np.ndarray], *, draws: int | None = None
) -> dict[str, Any]:
    draws = BOOTSTRAPS if draws is None else draws
    sources = np.array([source_id(p) for p in problems])
    labelled_uci = {p for p in problems if p.startswith("uci:")}
    overlapping = np.array([
        p.startswith("adbench:") and source_id(p) in labelled_uci for p in problems
    ])  # fmt: skip
    results = []
    for first, second in COMPARISONS:
        both = ~np.isnan(table[first]) & ~np.isnan(table[second])
        differences = table[first][both] - table[second][both]
        entry: dict[str, Any] = {"comparison": f"{first} - {second}", "problems": int(both.sum())}
        entry["by_problem"] = bootstrap(differences, sources[both], by_cluster=False, draws=draws)
        entry["by_source"] = bootstrap(differences, sources[both], by_cluster=True, draws=draws)
        keep = both & ~overlapping
        entry["without_overlap"] = bootstrap(
            table[first][keep] - table[second][keep], sources[keep], by_cluster=True, draws=draws
        ) | {"problems": int(keep.sum())}
        results.append(entry)
    adjusted = holm([item["by_source"]["p_two_sided"] for item in results])
    for item, value in zip(results, adjusted, strict=True):
        item["holm_p_by_source"] = value
    return {
        "problems": len(problems),
        "SOURCES": int(len(np.unique(sources))),
        "overlapping_adbench_problems": int(overlapping.sum()),
        "bootstraps": draws,
        "seed": SEED,
        "level": LEVEL,
        "comparisons": results,
    }


def x_analyse__mutmut_100(
    problems: list[str], table: dict[str, np.ndarray], *, draws: int | None = None
) -> dict[str, Any]:
    draws = BOOTSTRAPS if draws is None else draws
    sources = np.array([source_id(p) for p in problems])
    labelled_uci = {p for p in problems if p.startswith("uci:")}
    overlapping = np.array([
        p.startswith("adbench:") and source_id(p) in labelled_uci for p in problems
    ])  # fmt: skip
    results = []
    for first, second in COMPARISONS:
        both = ~np.isnan(table[first]) & ~np.isnan(table[second])
        differences = table[first][both] - table[second][both]
        entry: dict[str, Any] = {"comparison": f"{first} - {second}", "problems": int(both.sum())}
        entry["by_problem"] = bootstrap(differences, sources[both], by_cluster=False, draws=draws)
        entry["by_source"] = bootstrap(differences, sources[both], by_cluster=True, draws=draws)
        keep = both & ~overlapping
        entry["without_overlap"] = bootstrap(
            table[first][keep] - table[second][keep], sources[keep], by_cluster=True, draws=draws
        ) | {"problems": int(keep.sum())}
        results.append(entry)
    adjusted = holm([item["by_source"]["p_two_sided"] for item in results])
    for item, value in zip(results, adjusted, strict=True):
        item["holm_p_by_source"] = value
    return {
        "problems": len(problems),
        "sources": int(None),
        "overlapping_adbench_problems": int(overlapping.sum()),
        "bootstraps": draws,
        "seed": SEED,
        "level": LEVEL,
        "comparisons": results,
    }


def x_analyse__mutmut_101(
    problems: list[str], table: dict[str, np.ndarray], *, draws: int | None = None
) -> dict[str, Any]:
    draws = BOOTSTRAPS if draws is None else draws
    sources = np.array([source_id(p) for p in problems])
    labelled_uci = {p for p in problems if p.startswith("uci:")}
    overlapping = np.array([
        p.startswith("adbench:") and source_id(p) in labelled_uci for p in problems
    ])  # fmt: skip
    results = []
    for first, second in COMPARISONS:
        both = ~np.isnan(table[first]) & ~np.isnan(table[second])
        differences = table[first][both] - table[second][both]
        entry: dict[str, Any] = {"comparison": f"{first} - {second}", "problems": int(both.sum())}
        entry["by_problem"] = bootstrap(differences, sources[both], by_cluster=False, draws=draws)
        entry["by_source"] = bootstrap(differences, sources[both], by_cluster=True, draws=draws)
        keep = both & ~overlapping
        entry["without_overlap"] = bootstrap(
            table[first][keep] - table[second][keep], sources[keep], by_cluster=True, draws=draws
        ) | {"problems": int(keep.sum())}
        results.append(entry)
    adjusted = holm([item["by_source"]["p_two_sided"] for item in results])
    for item, value in zip(results, adjusted, strict=True):
        item["holm_p_by_source"] = value
    return {
        "problems": len(problems),
        "sources": int(len(np.unique(sources))),
        "XXoverlapping_adbench_problemsXX": int(overlapping.sum()),
        "bootstraps": draws,
        "seed": SEED,
        "level": LEVEL,
        "comparisons": results,
    }


def x_analyse__mutmut_102(
    problems: list[str], table: dict[str, np.ndarray], *, draws: int | None = None
) -> dict[str, Any]:
    draws = BOOTSTRAPS if draws is None else draws
    sources = np.array([source_id(p) for p in problems])
    labelled_uci = {p for p in problems if p.startswith("uci:")}
    overlapping = np.array([
        p.startswith("adbench:") and source_id(p) in labelled_uci for p in problems
    ])  # fmt: skip
    results = []
    for first, second in COMPARISONS:
        both = ~np.isnan(table[first]) & ~np.isnan(table[second])
        differences = table[first][both] - table[second][both]
        entry: dict[str, Any] = {"comparison": f"{first} - {second}", "problems": int(both.sum())}
        entry["by_problem"] = bootstrap(differences, sources[both], by_cluster=False, draws=draws)
        entry["by_source"] = bootstrap(differences, sources[both], by_cluster=True, draws=draws)
        keep = both & ~overlapping
        entry["without_overlap"] = bootstrap(
            table[first][keep] - table[second][keep], sources[keep], by_cluster=True, draws=draws
        ) | {"problems": int(keep.sum())}
        results.append(entry)
    adjusted = holm([item["by_source"]["p_two_sided"] for item in results])
    for item, value in zip(results, adjusted, strict=True):
        item["holm_p_by_source"] = value
    return {
        "problems": len(problems),
        "sources": int(len(np.unique(sources))),
        "OVERLAPPING_ADBENCH_PROBLEMS": int(overlapping.sum()),
        "bootstraps": draws,
        "seed": SEED,
        "level": LEVEL,
        "comparisons": results,
    }


def x_analyse__mutmut_103(
    problems: list[str], table: dict[str, np.ndarray], *, draws: int | None = None
) -> dict[str, Any]:
    draws = BOOTSTRAPS if draws is None else draws
    sources = np.array([source_id(p) for p in problems])
    labelled_uci = {p for p in problems if p.startswith("uci:")}
    overlapping = np.array([
        p.startswith("adbench:") and source_id(p) in labelled_uci for p in problems
    ])  # fmt: skip
    results = []
    for first, second in COMPARISONS:
        both = ~np.isnan(table[first]) & ~np.isnan(table[second])
        differences = table[first][both] - table[second][both]
        entry: dict[str, Any] = {"comparison": f"{first} - {second}", "problems": int(both.sum())}
        entry["by_problem"] = bootstrap(differences, sources[both], by_cluster=False, draws=draws)
        entry["by_source"] = bootstrap(differences, sources[both], by_cluster=True, draws=draws)
        keep = both & ~overlapping
        entry["without_overlap"] = bootstrap(
            table[first][keep] - table[second][keep], sources[keep], by_cluster=True, draws=draws
        ) | {"problems": int(keep.sum())}
        results.append(entry)
    adjusted = holm([item["by_source"]["p_two_sided"] for item in results])
    for item, value in zip(results, adjusted, strict=True):
        item["holm_p_by_source"] = value
    return {
        "problems": len(problems),
        "sources": int(len(np.unique(sources))),
        "overlapping_adbench_problems": int(None),
        "bootstraps": draws,
        "seed": SEED,
        "level": LEVEL,
        "comparisons": results,
    }


def x_analyse__mutmut_104(
    problems: list[str], table: dict[str, np.ndarray], *, draws: int | None = None
) -> dict[str, Any]:
    draws = BOOTSTRAPS if draws is None else draws
    sources = np.array([source_id(p) for p in problems])
    labelled_uci = {p for p in problems if p.startswith("uci:")}
    overlapping = np.array([
        p.startswith("adbench:") and source_id(p) in labelled_uci for p in problems
    ])  # fmt: skip
    results = []
    for first, second in COMPARISONS:
        both = ~np.isnan(table[first]) & ~np.isnan(table[second])
        differences = table[first][both] - table[second][both]
        entry: dict[str, Any] = {"comparison": f"{first} - {second}", "problems": int(both.sum())}
        entry["by_problem"] = bootstrap(differences, sources[both], by_cluster=False, draws=draws)
        entry["by_source"] = bootstrap(differences, sources[both], by_cluster=True, draws=draws)
        keep = both & ~overlapping
        entry["without_overlap"] = bootstrap(
            table[first][keep] - table[second][keep], sources[keep], by_cluster=True, draws=draws
        ) | {"problems": int(keep.sum())}
        results.append(entry)
    adjusted = holm([item["by_source"]["p_two_sided"] for item in results])
    for item, value in zip(results, adjusted, strict=True):
        item["holm_p_by_source"] = value
    return {
        "problems": len(problems),
        "sources": int(len(np.unique(sources))),
        "overlapping_adbench_problems": int(overlapping.sum()),
        "XXbootstrapsXX": draws,
        "seed": SEED,
        "level": LEVEL,
        "comparisons": results,
    }


def x_analyse__mutmut_105(
    problems: list[str], table: dict[str, np.ndarray], *, draws: int | None = None
) -> dict[str, Any]:
    draws = BOOTSTRAPS if draws is None else draws
    sources = np.array([source_id(p) for p in problems])
    labelled_uci = {p for p in problems if p.startswith("uci:")}
    overlapping = np.array([
        p.startswith("adbench:") and source_id(p) in labelled_uci for p in problems
    ])  # fmt: skip
    results = []
    for first, second in COMPARISONS:
        both = ~np.isnan(table[first]) & ~np.isnan(table[second])
        differences = table[first][both] - table[second][both]
        entry: dict[str, Any] = {"comparison": f"{first} - {second}", "problems": int(both.sum())}
        entry["by_problem"] = bootstrap(differences, sources[both], by_cluster=False, draws=draws)
        entry["by_source"] = bootstrap(differences, sources[both], by_cluster=True, draws=draws)
        keep = both & ~overlapping
        entry["without_overlap"] = bootstrap(
            table[first][keep] - table[second][keep], sources[keep], by_cluster=True, draws=draws
        ) | {"problems": int(keep.sum())}
        results.append(entry)
    adjusted = holm([item["by_source"]["p_two_sided"] for item in results])
    for item, value in zip(results, adjusted, strict=True):
        item["holm_p_by_source"] = value
    return {
        "problems": len(problems),
        "sources": int(len(np.unique(sources))),
        "overlapping_adbench_problems": int(overlapping.sum()),
        "BOOTSTRAPS": draws,
        "seed": SEED,
        "level": LEVEL,
        "comparisons": results,
    }


def x_analyse__mutmut_106(
    problems: list[str], table: dict[str, np.ndarray], *, draws: int | None = None
) -> dict[str, Any]:
    draws = BOOTSTRAPS if draws is None else draws
    sources = np.array([source_id(p) for p in problems])
    labelled_uci = {p for p in problems if p.startswith("uci:")}
    overlapping = np.array([
        p.startswith("adbench:") and source_id(p) in labelled_uci for p in problems
    ])  # fmt: skip
    results = []
    for first, second in COMPARISONS:
        both = ~np.isnan(table[first]) & ~np.isnan(table[second])
        differences = table[first][both] - table[second][both]
        entry: dict[str, Any] = {"comparison": f"{first} - {second}", "problems": int(both.sum())}
        entry["by_problem"] = bootstrap(differences, sources[both], by_cluster=False, draws=draws)
        entry["by_source"] = bootstrap(differences, sources[both], by_cluster=True, draws=draws)
        keep = both & ~overlapping
        entry["without_overlap"] = bootstrap(
            table[first][keep] - table[second][keep], sources[keep], by_cluster=True, draws=draws
        ) | {"problems": int(keep.sum())}
        results.append(entry)
    adjusted = holm([item["by_source"]["p_two_sided"] for item in results])
    for item, value in zip(results, adjusted, strict=True):
        item["holm_p_by_source"] = value
    return {
        "problems": len(problems),
        "sources": int(len(np.unique(sources))),
        "overlapping_adbench_problems": int(overlapping.sum()),
        "bootstraps": draws,
        "XXseedXX": SEED,
        "level": LEVEL,
        "comparisons": results,
    }


def x_analyse__mutmut_107(
    problems: list[str], table: dict[str, np.ndarray], *, draws: int | None = None
) -> dict[str, Any]:
    draws = BOOTSTRAPS if draws is None else draws
    sources = np.array([source_id(p) for p in problems])
    labelled_uci = {p for p in problems if p.startswith("uci:")}
    overlapping = np.array([
        p.startswith("adbench:") and source_id(p) in labelled_uci for p in problems
    ])  # fmt: skip
    results = []
    for first, second in COMPARISONS:
        both = ~np.isnan(table[first]) & ~np.isnan(table[second])
        differences = table[first][both] - table[second][both]
        entry: dict[str, Any] = {"comparison": f"{first} - {second}", "problems": int(both.sum())}
        entry["by_problem"] = bootstrap(differences, sources[both], by_cluster=False, draws=draws)
        entry["by_source"] = bootstrap(differences, sources[both], by_cluster=True, draws=draws)
        keep = both & ~overlapping
        entry["without_overlap"] = bootstrap(
            table[first][keep] - table[second][keep], sources[keep], by_cluster=True, draws=draws
        ) | {"problems": int(keep.sum())}
        results.append(entry)
    adjusted = holm([item["by_source"]["p_two_sided"] for item in results])
    for item, value in zip(results, adjusted, strict=True):
        item["holm_p_by_source"] = value
    return {
        "problems": len(problems),
        "sources": int(len(np.unique(sources))),
        "overlapping_adbench_problems": int(overlapping.sum()),
        "bootstraps": draws,
        "SEED": SEED,
        "level": LEVEL,
        "comparisons": results,
    }


def x_analyse__mutmut_108(
    problems: list[str], table: dict[str, np.ndarray], *, draws: int | None = None
) -> dict[str, Any]:
    draws = BOOTSTRAPS if draws is None else draws
    sources = np.array([source_id(p) for p in problems])
    labelled_uci = {p for p in problems if p.startswith("uci:")}
    overlapping = np.array([
        p.startswith("adbench:") and source_id(p) in labelled_uci for p in problems
    ])  # fmt: skip
    results = []
    for first, second in COMPARISONS:
        both = ~np.isnan(table[first]) & ~np.isnan(table[second])
        differences = table[first][both] - table[second][both]
        entry: dict[str, Any] = {"comparison": f"{first} - {second}", "problems": int(both.sum())}
        entry["by_problem"] = bootstrap(differences, sources[both], by_cluster=False, draws=draws)
        entry["by_source"] = bootstrap(differences, sources[both], by_cluster=True, draws=draws)
        keep = both & ~overlapping
        entry["without_overlap"] = bootstrap(
            table[first][keep] - table[second][keep], sources[keep], by_cluster=True, draws=draws
        ) | {"problems": int(keep.sum())}
        results.append(entry)
    adjusted = holm([item["by_source"]["p_two_sided"] for item in results])
    for item, value in zip(results, adjusted, strict=True):
        item["holm_p_by_source"] = value
    return {
        "problems": len(problems),
        "sources": int(len(np.unique(sources))),
        "overlapping_adbench_problems": int(overlapping.sum()),
        "bootstraps": draws,
        "seed": SEED,
        "XXlevelXX": LEVEL,
        "comparisons": results,
    }


def x_analyse__mutmut_109(
    problems: list[str], table: dict[str, np.ndarray], *, draws: int | None = None
) -> dict[str, Any]:
    draws = BOOTSTRAPS if draws is None else draws
    sources = np.array([source_id(p) for p in problems])
    labelled_uci = {p for p in problems if p.startswith("uci:")}
    overlapping = np.array([
        p.startswith("adbench:") and source_id(p) in labelled_uci for p in problems
    ])  # fmt: skip
    results = []
    for first, second in COMPARISONS:
        both = ~np.isnan(table[first]) & ~np.isnan(table[second])
        differences = table[first][both] - table[second][both]
        entry: dict[str, Any] = {"comparison": f"{first} - {second}", "problems": int(both.sum())}
        entry["by_problem"] = bootstrap(differences, sources[both], by_cluster=False, draws=draws)
        entry["by_source"] = bootstrap(differences, sources[both], by_cluster=True, draws=draws)
        keep = both & ~overlapping
        entry["without_overlap"] = bootstrap(
            table[first][keep] - table[second][keep], sources[keep], by_cluster=True, draws=draws
        ) | {"problems": int(keep.sum())}
        results.append(entry)
    adjusted = holm([item["by_source"]["p_two_sided"] for item in results])
    for item, value in zip(results, adjusted, strict=True):
        item["holm_p_by_source"] = value
    return {
        "problems": len(problems),
        "sources": int(len(np.unique(sources))),
        "overlapping_adbench_problems": int(overlapping.sum()),
        "bootstraps": draws,
        "seed": SEED,
        "LEVEL": LEVEL,
        "comparisons": results,
    }


def x_analyse__mutmut_110(
    problems: list[str], table: dict[str, np.ndarray], *, draws: int | None = None
) -> dict[str, Any]:
    draws = BOOTSTRAPS if draws is None else draws
    sources = np.array([source_id(p) for p in problems])
    labelled_uci = {p for p in problems if p.startswith("uci:")}
    overlapping = np.array([
        p.startswith("adbench:") and source_id(p) in labelled_uci for p in problems
    ])  # fmt: skip
    results = []
    for first, second in COMPARISONS:
        both = ~np.isnan(table[first]) & ~np.isnan(table[second])
        differences = table[first][both] - table[second][both]
        entry: dict[str, Any] = {"comparison": f"{first} - {second}", "problems": int(both.sum())}
        entry["by_problem"] = bootstrap(differences, sources[both], by_cluster=False, draws=draws)
        entry["by_source"] = bootstrap(differences, sources[both], by_cluster=True, draws=draws)
        keep = both & ~overlapping
        entry["without_overlap"] = bootstrap(
            table[first][keep] - table[second][keep], sources[keep], by_cluster=True, draws=draws
        ) | {"problems": int(keep.sum())}
        results.append(entry)
    adjusted = holm([item["by_source"]["p_two_sided"] for item in results])
    for item, value in zip(results, adjusted, strict=True):
        item["holm_p_by_source"] = value
    return {
        "problems": len(problems),
        "sources": int(len(np.unique(sources))),
        "overlapping_adbench_problems": int(overlapping.sum()),
        "bootstraps": draws,
        "seed": SEED,
        "level": LEVEL,
        "XXcomparisonsXX": results,
    }


def x_analyse__mutmut_111(
    problems: list[str], table: dict[str, np.ndarray], *, draws: int | None = None
) -> dict[str, Any]:
    draws = BOOTSTRAPS if draws is None else draws
    sources = np.array([source_id(p) for p in problems])
    labelled_uci = {p for p in problems if p.startswith("uci:")}
    overlapping = np.array([
        p.startswith("adbench:") and source_id(p) in labelled_uci for p in problems
    ])  # fmt: skip
    results = []
    for first, second in COMPARISONS:
        both = ~np.isnan(table[first]) & ~np.isnan(table[second])
        differences = table[first][both] - table[second][both]
        entry: dict[str, Any] = {"comparison": f"{first} - {second}", "problems": int(both.sum())}
        entry["by_problem"] = bootstrap(differences, sources[both], by_cluster=False, draws=draws)
        entry["by_source"] = bootstrap(differences, sources[both], by_cluster=True, draws=draws)
        keep = both & ~overlapping
        entry["without_overlap"] = bootstrap(
            table[first][keep] - table[second][keep], sources[keep], by_cluster=True, draws=draws
        ) | {"problems": int(keep.sum())}
        results.append(entry)
    adjusted = holm([item["by_source"]["p_two_sided"] for item in results])
    for item, value in zip(results, adjusted, strict=True):
        item["holm_p_by_source"] = value
    return {
        "problems": len(problems),
        "sources": int(len(np.unique(sources))),
        "overlapping_adbench_problems": int(overlapping.sum()),
        "bootstraps": draws,
        "seed": SEED,
        "level": LEVEL,
        "COMPARISONS": results,
    }

mutants_x_analyse__mutmut['_mutmut_orig'] = x_analyse__mutmut_orig # type: ignore # mutmut generated
mutants_x_analyse__mutmut['x_analyse__mutmut_1'] = x_analyse__mutmut_1 # type: ignore # mutmut generated
mutants_x_analyse__mutmut['x_analyse__mutmut_2'] = x_analyse__mutmut_2 # type: ignore # mutmut generated
mutants_x_analyse__mutmut['x_analyse__mutmut_3'] = x_analyse__mutmut_3 # type: ignore # mutmut generated
mutants_x_analyse__mutmut['x_analyse__mutmut_4'] = x_analyse__mutmut_4 # type: ignore # mutmut generated
mutants_x_analyse__mutmut['x_analyse__mutmut_5'] = x_analyse__mutmut_5 # type: ignore # mutmut generated
mutants_x_analyse__mutmut['x_analyse__mutmut_6'] = x_analyse__mutmut_6 # type: ignore # mutmut generated
mutants_x_analyse__mutmut['x_analyse__mutmut_7'] = x_analyse__mutmut_7 # type: ignore # mutmut generated
mutants_x_analyse__mutmut['x_analyse__mutmut_8'] = x_analyse__mutmut_8 # type: ignore # mutmut generated
mutants_x_analyse__mutmut['x_analyse__mutmut_9'] = x_analyse__mutmut_9 # type: ignore # mutmut generated
mutants_x_analyse__mutmut['x_analyse__mutmut_10'] = x_analyse__mutmut_10 # type: ignore # mutmut generated
mutants_x_analyse__mutmut['x_analyse__mutmut_11'] = x_analyse__mutmut_11 # type: ignore # mutmut generated
mutants_x_analyse__mutmut['x_analyse__mutmut_12'] = x_analyse__mutmut_12 # type: ignore # mutmut generated
mutants_x_analyse__mutmut['x_analyse__mutmut_13'] = x_analyse__mutmut_13 # type: ignore # mutmut generated
mutants_x_analyse__mutmut['x_analyse__mutmut_14'] = x_analyse__mutmut_14 # type: ignore # mutmut generated
mutants_x_analyse__mutmut['x_analyse__mutmut_15'] = x_analyse__mutmut_15 # type: ignore # mutmut generated
mutants_x_analyse__mutmut['x_analyse__mutmut_16'] = x_analyse__mutmut_16 # type: ignore # mutmut generated
mutants_x_analyse__mutmut['x_analyse__mutmut_17'] = x_analyse__mutmut_17 # type: ignore # mutmut generated
mutants_x_analyse__mutmut['x_analyse__mutmut_18'] = x_analyse__mutmut_18 # type: ignore # mutmut generated
mutants_x_analyse__mutmut['x_analyse__mutmut_19'] = x_analyse__mutmut_19 # type: ignore # mutmut generated
mutants_x_analyse__mutmut['x_analyse__mutmut_20'] = x_analyse__mutmut_20 # type: ignore # mutmut generated
mutants_x_analyse__mutmut['x_analyse__mutmut_21'] = x_analyse__mutmut_21 # type: ignore # mutmut generated
mutants_x_analyse__mutmut['x_analyse__mutmut_22'] = x_analyse__mutmut_22 # type: ignore # mutmut generated
mutants_x_analyse__mutmut['x_analyse__mutmut_23'] = x_analyse__mutmut_23 # type: ignore # mutmut generated
mutants_x_analyse__mutmut['x_analyse__mutmut_24'] = x_analyse__mutmut_24 # type: ignore # mutmut generated
mutants_x_analyse__mutmut['x_analyse__mutmut_25'] = x_analyse__mutmut_25 # type: ignore # mutmut generated
mutants_x_analyse__mutmut['x_analyse__mutmut_26'] = x_analyse__mutmut_26 # type: ignore # mutmut generated
mutants_x_analyse__mutmut['x_analyse__mutmut_27'] = x_analyse__mutmut_27 # type: ignore # mutmut generated
mutants_x_analyse__mutmut['x_analyse__mutmut_28'] = x_analyse__mutmut_28 # type: ignore # mutmut generated
mutants_x_analyse__mutmut['x_analyse__mutmut_29'] = x_analyse__mutmut_29 # type: ignore # mutmut generated
mutants_x_analyse__mutmut['x_analyse__mutmut_30'] = x_analyse__mutmut_30 # type: ignore # mutmut generated
mutants_x_analyse__mutmut['x_analyse__mutmut_31'] = x_analyse__mutmut_31 # type: ignore # mutmut generated
mutants_x_analyse__mutmut['x_analyse__mutmut_32'] = x_analyse__mutmut_32 # type: ignore # mutmut generated
mutants_x_analyse__mutmut['x_analyse__mutmut_33'] = x_analyse__mutmut_33 # type: ignore # mutmut generated
mutants_x_analyse__mutmut['x_analyse__mutmut_34'] = x_analyse__mutmut_34 # type: ignore # mutmut generated
mutants_x_analyse__mutmut['x_analyse__mutmut_35'] = x_analyse__mutmut_35 # type: ignore # mutmut generated
mutants_x_analyse__mutmut['x_analyse__mutmut_36'] = x_analyse__mutmut_36 # type: ignore # mutmut generated
mutants_x_analyse__mutmut['x_analyse__mutmut_37'] = x_analyse__mutmut_37 # type: ignore # mutmut generated
mutants_x_analyse__mutmut['x_analyse__mutmut_38'] = x_analyse__mutmut_38 # type: ignore # mutmut generated
mutants_x_analyse__mutmut['x_analyse__mutmut_39'] = x_analyse__mutmut_39 # type: ignore # mutmut generated
mutants_x_analyse__mutmut['x_analyse__mutmut_40'] = x_analyse__mutmut_40 # type: ignore # mutmut generated
mutants_x_analyse__mutmut['x_analyse__mutmut_41'] = x_analyse__mutmut_41 # type: ignore # mutmut generated
mutants_x_analyse__mutmut['x_analyse__mutmut_42'] = x_analyse__mutmut_42 # type: ignore # mutmut generated
mutants_x_analyse__mutmut['x_analyse__mutmut_43'] = x_analyse__mutmut_43 # type: ignore # mutmut generated
mutants_x_analyse__mutmut['x_analyse__mutmut_44'] = x_analyse__mutmut_44 # type: ignore # mutmut generated
mutants_x_analyse__mutmut['x_analyse__mutmut_45'] = x_analyse__mutmut_45 # type: ignore # mutmut generated
mutants_x_analyse__mutmut['x_analyse__mutmut_46'] = x_analyse__mutmut_46 # type: ignore # mutmut generated
mutants_x_analyse__mutmut['x_analyse__mutmut_47'] = x_analyse__mutmut_47 # type: ignore # mutmut generated
mutants_x_analyse__mutmut['x_analyse__mutmut_48'] = x_analyse__mutmut_48 # type: ignore # mutmut generated
mutants_x_analyse__mutmut['x_analyse__mutmut_49'] = x_analyse__mutmut_49 # type: ignore # mutmut generated
mutants_x_analyse__mutmut['x_analyse__mutmut_50'] = x_analyse__mutmut_50 # type: ignore # mutmut generated
mutants_x_analyse__mutmut['x_analyse__mutmut_51'] = x_analyse__mutmut_51 # type: ignore # mutmut generated
mutants_x_analyse__mutmut['x_analyse__mutmut_52'] = x_analyse__mutmut_52 # type: ignore # mutmut generated
mutants_x_analyse__mutmut['x_analyse__mutmut_53'] = x_analyse__mutmut_53 # type: ignore # mutmut generated
mutants_x_analyse__mutmut['x_analyse__mutmut_54'] = x_analyse__mutmut_54 # type: ignore # mutmut generated
mutants_x_analyse__mutmut['x_analyse__mutmut_55'] = x_analyse__mutmut_55 # type: ignore # mutmut generated
mutants_x_analyse__mutmut['x_analyse__mutmut_56'] = x_analyse__mutmut_56 # type: ignore # mutmut generated
mutants_x_analyse__mutmut['x_analyse__mutmut_57'] = x_analyse__mutmut_57 # type: ignore # mutmut generated
mutants_x_analyse__mutmut['x_analyse__mutmut_58'] = x_analyse__mutmut_58 # type: ignore # mutmut generated
mutants_x_analyse__mutmut['x_analyse__mutmut_59'] = x_analyse__mutmut_59 # type: ignore # mutmut generated
mutants_x_analyse__mutmut['x_analyse__mutmut_60'] = x_analyse__mutmut_60 # type: ignore # mutmut generated
mutants_x_analyse__mutmut['x_analyse__mutmut_61'] = x_analyse__mutmut_61 # type: ignore # mutmut generated
mutants_x_analyse__mutmut['x_analyse__mutmut_62'] = x_analyse__mutmut_62 # type: ignore # mutmut generated
mutants_x_analyse__mutmut['x_analyse__mutmut_63'] = x_analyse__mutmut_63 # type: ignore # mutmut generated
mutants_x_analyse__mutmut['x_analyse__mutmut_64'] = x_analyse__mutmut_64 # type: ignore # mutmut generated
mutants_x_analyse__mutmut['x_analyse__mutmut_65'] = x_analyse__mutmut_65 # type: ignore # mutmut generated
mutants_x_analyse__mutmut['x_analyse__mutmut_66'] = x_analyse__mutmut_66 # type: ignore # mutmut generated
mutants_x_analyse__mutmut['x_analyse__mutmut_67'] = x_analyse__mutmut_67 # type: ignore # mutmut generated
mutants_x_analyse__mutmut['x_analyse__mutmut_68'] = x_analyse__mutmut_68 # type: ignore # mutmut generated
mutants_x_analyse__mutmut['x_analyse__mutmut_69'] = x_analyse__mutmut_69 # type: ignore # mutmut generated
mutants_x_analyse__mutmut['x_analyse__mutmut_70'] = x_analyse__mutmut_70 # type: ignore # mutmut generated
mutants_x_analyse__mutmut['x_analyse__mutmut_71'] = x_analyse__mutmut_71 # type: ignore # mutmut generated
mutants_x_analyse__mutmut['x_analyse__mutmut_72'] = x_analyse__mutmut_72 # type: ignore # mutmut generated
mutants_x_analyse__mutmut['x_analyse__mutmut_73'] = x_analyse__mutmut_73 # type: ignore # mutmut generated
mutants_x_analyse__mutmut['x_analyse__mutmut_74'] = x_analyse__mutmut_74 # type: ignore # mutmut generated
mutants_x_analyse__mutmut['x_analyse__mutmut_75'] = x_analyse__mutmut_75 # type: ignore # mutmut generated
mutants_x_analyse__mutmut['x_analyse__mutmut_76'] = x_analyse__mutmut_76 # type: ignore # mutmut generated
mutants_x_analyse__mutmut['x_analyse__mutmut_77'] = x_analyse__mutmut_77 # type: ignore # mutmut generated
mutants_x_analyse__mutmut['x_analyse__mutmut_78'] = x_analyse__mutmut_78 # type: ignore # mutmut generated
mutants_x_analyse__mutmut['x_analyse__mutmut_79'] = x_analyse__mutmut_79 # type: ignore # mutmut generated
mutants_x_analyse__mutmut['x_analyse__mutmut_80'] = x_analyse__mutmut_80 # type: ignore # mutmut generated
mutants_x_analyse__mutmut['x_analyse__mutmut_81'] = x_analyse__mutmut_81 # type: ignore # mutmut generated
mutants_x_analyse__mutmut['x_analyse__mutmut_82'] = x_analyse__mutmut_82 # type: ignore # mutmut generated
mutants_x_analyse__mutmut['x_analyse__mutmut_83'] = x_analyse__mutmut_83 # type: ignore # mutmut generated
mutants_x_analyse__mutmut['x_analyse__mutmut_84'] = x_analyse__mutmut_84 # type: ignore # mutmut generated
mutants_x_analyse__mutmut['x_analyse__mutmut_85'] = x_analyse__mutmut_85 # type: ignore # mutmut generated
mutants_x_analyse__mutmut['x_analyse__mutmut_86'] = x_analyse__mutmut_86 # type: ignore # mutmut generated
mutants_x_analyse__mutmut['x_analyse__mutmut_87'] = x_analyse__mutmut_87 # type: ignore # mutmut generated
mutants_x_analyse__mutmut['x_analyse__mutmut_88'] = x_analyse__mutmut_88 # type: ignore # mutmut generated
mutants_x_analyse__mutmut['x_analyse__mutmut_89'] = x_analyse__mutmut_89 # type: ignore # mutmut generated
mutants_x_analyse__mutmut['x_analyse__mutmut_90'] = x_analyse__mutmut_90 # type: ignore # mutmut generated
mutants_x_analyse__mutmut['x_analyse__mutmut_91'] = x_analyse__mutmut_91 # type: ignore # mutmut generated
mutants_x_analyse__mutmut['x_analyse__mutmut_92'] = x_analyse__mutmut_92 # type: ignore # mutmut generated
mutants_x_analyse__mutmut['x_analyse__mutmut_93'] = x_analyse__mutmut_93 # type: ignore # mutmut generated
mutants_x_analyse__mutmut['x_analyse__mutmut_94'] = x_analyse__mutmut_94 # type: ignore # mutmut generated
mutants_x_analyse__mutmut['x_analyse__mutmut_95'] = x_analyse__mutmut_95 # type: ignore # mutmut generated
mutants_x_analyse__mutmut['x_analyse__mutmut_96'] = x_analyse__mutmut_96 # type: ignore # mutmut generated
mutants_x_analyse__mutmut['x_analyse__mutmut_97'] = x_analyse__mutmut_97 # type: ignore # mutmut generated
mutants_x_analyse__mutmut['x_analyse__mutmut_98'] = x_analyse__mutmut_98 # type: ignore # mutmut generated
mutants_x_analyse__mutmut['x_analyse__mutmut_99'] = x_analyse__mutmut_99 # type: ignore # mutmut generated
mutants_x_analyse__mutmut['x_analyse__mutmut_100'] = x_analyse__mutmut_100 # type: ignore # mutmut generated
mutants_x_analyse__mutmut['x_analyse__mutmut_101'] = x_analyse__mutmut_101 # type: ignore # mutmut generated
mutants_x_analyse__mutmut['x_analyse__mutmut_102'] = x_analyse__mutmut_102 # type: ignore # mutmut generated
mutants_x_analyse__mutmut['x_analyse__mutmut_103'] = x_analyse__mutmut_103 # type: ignore # mutmut generated
mutants_x_analyse__mutmut['x_analyse__mutmut_104'] = x_analyse__mutmut_104 # type: ignore # mutmut generated
mutants_x_analyse__mutmut['x_analyse__mutmut_105'] = x_analyse__mutmut_105 # type: ignore # mutmut generated
mutants_x_analyse__mutmut['x_analyse__mutmut_106'] = x_analyse__mutmut_106 # type: ignore # mutmut generated
mutants_x_analyse__mutmut['x_analyse__mutmut_107'] = x_analyse__mutmut_107 # type: ignore # mutmut generated
mutants_x_analyse__mutmut['x_analyse__mutmut_108'] = x_analyse__mutmut_108 # type: ignore # mutmut generated
mutants_x_analyse__mutmut['x_analyse__mutmut_109'] = x_analyse__mutmut_109 # type: ignore # mutmut generated
mutants_x_analyse__mutmut['x_analyse__mutmut_110'] = x_analyse__mutmut_110 # type: ignore # mutmut generated
mutants_x_analyse__mutmut['x_analyse__mutmut_111'] = x_analyse__mutmut_111 # type: ignore # mutmut generated
mutants_x_main__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_main__mutmut)
def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent / "verification" / "evidence"
    parser.add_argument("--classical", type=Path, default=root / "labelled_pool" / "runs")
    parser.add_argument("--deep", type=Path, default=root / "full_registry" / "pool_deep" / "runs")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    problems, table = load_ap([args.classical, args.deep])
    result = analyse(problems, table)
    args.output.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
    print(f"{result['problems']} problems, {result['sources']} sources")
    return 0


def x_main__mutmut_orig(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent / "verification" / "evidence"
    parser.add_argument("--classical", type=Path, default=root / "labelled_pool" / "runs")
    parser.add_argument("--deep", type=Path, default=root / "full_registry" / "pool_deep" / "runs")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    problems, table = load_ap([args.classical, args.deep])
    result = analyse(problems, table)
    args.output.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
    print(f"{result['problems']} problems, {result['sources']} sources")
    return 0


def x_main__mutmut_1(argv: list[str] | None = None) -> int:
    parser = None
    root = HERE.parent / "verification" / "evidence"
    parser.add_argument("--classical", type=Path, default=root / "labelled_pool" / "runs")
    parser.add_argument("--deep", type=Path, default=root / "full_registry" / "pool_deep" / "runs")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    problems, table = load_ap([args.classical, args.deep])
    result = analyse(problems, table)
    args.output.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
    print(f"{result['problems']} problems, {result['sources']} sources")
    return 0


def x_main__mutmut_2(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=None)
    root = HERE.parent / "verification" / "evidence"
    parser.add_argument("--classical", type=Path, default=root / "labelled_pool" / "runs")
    parser.add_argument("--deep", type=Path, default=root / "full_registry" / "pool_deep" / "runs")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    problems, table = load_ap([args.classical, args.deep])
    result = analyse(problems, table)
    args.output.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
    print(f"{result['problems']} problems, {result['sources']} sources")
    return 0


def x_main__mutmut_3(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = None
    parser.add_argument("--classical", type=Path, default=root / "labelled_pool" / "runs")
    parser.add_argument("--deep", type=Path, default=root / "full_registry" / "pool_deep" / "runs")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    problems, table = load_ap([args.classical, args.deep])
    result = analyse(problems, table)
    args.output.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
    print(f"{result['problems']} problems, {result['sources']} sources")
    return 0


def x_main__mutmut_4(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent / "verification" * "evidence"
    parser.add_argument("--classical", type=Path, default=root / "labelled_pool" / "runs")
    parser.add_argument("--deep", type=Path, default=root / "full_registry" / "pool_deep" / "runs")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    problems, table = load_ap([args.classical, args.deep])
    result = analyse(problems, table)
    args.output.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
    print(f"{result['problems']} problems, {result['sources']} sources")
    return 0


def x_main__mutmut_5(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent * "verification" / "evidence"
    parser.add_argument("--classical", type=Path, default=root / "labelled_pool" / "runs")
    parser.add_argument("--deep", type=Path, default=root / "full_registry" / "pool_deep" / "runs")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    problems, table = load_ap([args.classical, args.deep])
    result = analyse(problems, table)
    args.output.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
    print(f"{result['problems']} problems, {result['sources']} sources")
    return 0


def x_main__mutmut_6(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent / "XXverificationXX" / "evidence"
    parser.add_argument("--classical", type=Path, default=root / "labelled_pool" / "runs")
    parser.add_argument("--deep", type=Path, default=root / "full_registry" / "pool_deep" / "runs")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    problems, table = load_ap([args.classical, args.deep])
    result = analyse(problems, table)
    args.output.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
    print(f"{result['problems']} problems, {result['sources']} sources")
    return 0


def x_main__mutmut_7(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent / "VERIFICATION" / "evidence"
    parser.add_argument("--classical", type=Path, default=root / "labelled_pool" / "runs")
    parser.add_argument("--deep", type=Path, default=root / "full_registry" / "pool_deep" / "runs")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    problems, table = load_ap([args.classical, args.deep])
    result = analyse(problems, table)
    args.output.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
    print(f"{result['problems']} problems, {result['sources']} sources")
    return 0


def x_main__mutmut_8(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent / "verification" / "XXevidenceXX"
    parser.add_argument("--classical", type=Path, default=root / "labelled_pool" / "runs")
    parser.add_argument("--deep", type=Path, default=root / "full_registry" / "pool_deep" / "runs")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    problems, table = load_ap([args.classical, args.deep])
    result = analyse(problems, table)
    args.output.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
    print(f"{result['problems']} problems, {result['sources']} sources")
    return 0


def x_main__mutmut_9(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent / "verification" / "EVIDENCE"
    parser.add_argument("--classical", type=Path, default=root / "labelled_pool" / "runs")
    parser.add_argument("--deep", type=Path, default=root / "full_registry" / "pool_deep" / "runs")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    problems, table = load_ap([args.classical, args.deep])
    result = analyse(problems, table)
    args.output.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
    print(f"{result['problems']} problems, {result['sources']} sources")
    return 0


def x_main__mutmut_10(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent / "verification" / "evidence"
    parser.add_argument(None, type=Path, default=root / "labelled_pool" / "runs")
    parser.add_argument("--deep", type=Path, default=root / "full_registry" / "pool_deep" / "runs")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    problems, table = load_ap([args.classical, args.deep])
    result = analyse(problems, table)
    args.output.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
    print(f"{result['problems']} problems, {result['sources']} sources")
    return 0


def x_main__mutmut_11(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent / "verification" / "evidence"
    parser.add_argument("--classical", type=None, default=root / "labelled_pool" / "runs")
    parser.add_argument("--deep", type=Path, default=root / "full_registry" / "pool_deep" / "runs")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    problems, table = load_ap([args.classical, args.deep])
    result = analyse(problems, table)
    args.output.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
    print(f"{result['problems']} problems, {result['sources']} sources")
    return 0


def x_main__mutmut_12(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent / "verification" / "evidence"
    parser.add_argument("--classical", type=Path, default=None)
    parser.add_argument("--deep", type=Path, default=root / "full_registry" / "pool_deep" / "runs")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    problems, table = load_ap([args.classical, args.deep])
    result = analyse(problems, table)
    args.output.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
    print(f"{result['problems']} problems, {result['sources']} sources")
    return 0


def x_main__mutmut_13(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent / "verification" / "evidence"
    parser.add_argument(type=Path, default=root / "labelled_pool" / "runs")
    parser.add_argument("--deep", type=Path, default=root / "full_registry" / "pool_deep" / "runs")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    problems, table = load_ap([args.classical, args.deep])
    result = analyse(problems, table)
    args.output.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
    print(f"{result['problems']} problems, {result['sources']} sources")
    return 0


def x_main__mutmut_14(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent / "verification" / "evidence"
    parser.add_argument("--classical", default=root / "labelled_pool" / "runs")
    parser.add_argument("--deep", type=Path, default=root / "full_registry" / "pool_deep" / "runs")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    problems, table = load_ap([args.classical, args.deep])
    result = analyse(problems, table)
    args.output.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
    print(f"{result['problems']} problems, {result['sources']} sources")
    return 0


def x_main__mutmut_15(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent / "verification" / "evidence"
    parser.add_argument("--classical", type=Path, )
    parser.add_argument("--deep", type=Path, default=root / "full_registry" / "pool_deep" / "runs")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    problems, table = load_ap([args.classical, args.deep])
    result = analyse(problems, table)
    args.output.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
    print(f"{result['problems']} problems, {result['sources']} sources")
    return 0


def x_main__mutmut_16(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent / "verification" / "evidence"
    parser.add_argument("XX--classicalXX", type=Path, default=root / "labelled_pool" / "runs")
    parser.add_argument("--deep", type=Path, default=root / "full_registry" / "pool_deep" / "runs")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    problems, table = load_ap([args.classical, args.deep])
    result = analyse(problems, table)
    args.output.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
    print(f"{result['problems']} problems, {result['sources']} sources")
    return 0


def x_main__mutmut_17(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent / "verification" / "evidence"
    parser.add_argument("--CLASSICAL", type=Path, default=root / "labelled_pool" / "runs")
    parser.add_argument("--deep", type=Path, default=root / "full_registry" / "pool_deep" / "runs")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    problems, table = load_ap([args.classical, args.deep])
    result = analyse(problems, table)
    args.output.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
    print(f"{result['problems']} problems, {result['sources']} sources")
    return 0


def x_main__mutmut_18(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent / "verification" / "evidence"
    parser.add_argument("--classical", type=Path, default=root / "labelled_pool" * "runs")
    parser.add_argument("--deep", type=Path, default=root / "full_registry" / "pool_deep" / "runs")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    problems, table = load_ap([args.classical, args.deep])
    result = analyse(problems, table)
    args.output.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
    print(f"{result['problems']} problems, {result['sources']} sources")
    return 0


def x_main__mutmut_19(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent / "verification" / "evidence"
    parser.add_argument("--classical", type=Path, default=root * "labelled_pool" / "runs")
    parser.add_argument("--deep", type=Path, default=root / "full_registry" / "pool_deep" / "runs")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    problems, table = load_ap([args.classical, args.deep])
    result = analyse(problems, table)
    args.output.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
    print(f"{result['problems']} problems, {result['sources']} sources")
    return 0


def x_main__mutmut_20(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent / "verification" / "evidence"
    parser.add_argument("--classical", type=Path, default=root / "XXlabelled_poolXX" / "runs")
    parser.add_argument("--deep", type=Path, default=root / "full_registry" / "pool_deep" / "runs")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    problems, table = load_ap([args.classical, args.deep])
    result = analyse(problems, table)
    args.output.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
    print(f"{result['problems']} problems, {result['sources']} sources")
    return 0


def x_main__mutmut_21(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent / "verification" / "evidence"
    parser.add_argument("--classical", type=Path, default=root / "LABELLED_POOL" / "runs")
    parser.add_argument("--deep", type=Path, default=root / "full_registry" / "pool_deep" / "runs")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    problems, table = load_ap([args.classical, args.deep])
    result = analyse(problems, table)
    args.output.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
    print(f"{result['problems']} problems, {result['sources']} sources")
    return 0


def x_main__mutmut_22(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent / "verification" / "evidence"
    parser.add_argument("--classical", type=Path, default=root / "labelled_pool" / "XXrunsXX")
    parser.add_argument("--deep", type=Path, default=root / "full_registry" / "pool_deep" / "runs")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    problems, table = load_ap([args.classical, args.deep])
    result = analyse(problems, table)
    args.output.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
    print(f"{result['problems']} problems, {result['sources']} sources")
    return 0


def x_main__mutmut_23(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent / "verification" / "evidence"
    parser.add_argument("--classical", type=Path, default=root / "labelled_pool" / "RUNS")
    parser.add_argument("--deep", type=Path, default=root / "full_registry" / "pool_deep" / "runs")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    problems, table = load_ap([args.classical, args.deep])
    result = analyse(problems, table)
    args.output.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
    print(f"{result['problems']} problems, {result['sources']} sources")
    return 0


def x_main__mutmut_24(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent / "verification" / "evidence"
    parser.add_argument("--classical", type=Path, default=root / "labelled_pool" / "runs")
    parser.add_argument(None, type=Path, default=root / "full_registry" / "pool_deep" / "runs")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    problems, table = load_ap([args.classical, args.deep])
    result = analyse(problems, table)
    args.output.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
    print(f"{result['problems']} problems, {result['sources']} sources")
    return 0


def x_main__mutmut_25(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent / "verification" / "evidence"
    parser.add_argument("--classical", type=Path, default=root / "labelled_pool" / "runs")
    parser.add_argument("--deep", type=None, default=root / "full_registry" / "pool_deep" / "runs")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    problems, table = load_ap([args.classical, args.deep])
    result = analyse(problems, table)
    args.output.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
    print(f"{result['problems']} problems, {result['sources']} sources")
    return 0


def x_main__mutmut_26(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent / "verification" / "evidence"
    parser.add_argument("--classical", type=Path, default=root / "labelled_pool" / "runs")
    parser.add_argument("--deep", type=Path, default=None)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    problems, table = load_ap([args.classical, args.deep])
    result = analyse(problems, table)
    args.output.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
    print(f"{result['problems']} problems, {result['sources']} sources")
    return 0


def x_main__mutmut_27(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent / "verification" / "evidence"
    parser.add_argument("--classical", type=Path, default=root / "labelled_pool" / "runs")
    parser.add_argument(type=Path, default=root / "full_registry" / "pool_deep" / "runs")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    problems, table = load_ap([args.classical, args.deep])
    result = analyse(problems, table)
    args.output.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
    print(f"{result['problems']} problems, {result['sources']} sources")
    return 0


def x_main__mutmut_28(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent / "verification" / "evidence"
    parser.add_argument("--classical", type=Path, default=root / "labelled_pool" / "runs")
    parser.add_argument("--deep", default=root / "full_registry" / "pool_deep" / "runs")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    problems, table = load_ap([args.classical, args.deep])
    result = analyse(problems, table)
    args.output.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
    print(f"{result['problems']} problems, {result['sources']} sources")
    return 0


def x_main__mutmut_29(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent / "verification" / "evidence"
    parser.add_argument("--classical", type=Path, default=root / "labelled_pool" / "runs")
    parser.add_argument("--deep", type=Path, )
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    problems, table = load_ap([args.classical, args.deep])
    result = analyse(problems, table)
    args.output.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
    print(f"{result['problems']} problems, {result['sources']} sources")
    return 0


def x_main__mutmut_30(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent / "verification" / "evidence"
    parser.add_argument("--classical", type=Path, default=root / "labelled_pool" / "runs")
    parser.add_argument("XX--deepXX", type=Path, default=root / "full_registry" / "pool_deep" / "runs")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    problems, table = load_ap([args.classical, args.deep])
    result = analyse(problems, table)
    args.output.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
    print(f"{result['problems']} problems, {result['sources']} sources")
    return 0


def x_main__mutmut_31(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent / "verification" / "evidence"
    parser.add_argument("--classical", type=Path, default=root / "labelled_pool" / "runs")
    parser.add_argument("--DEEP", type=Path, default=root / "full_registry" / "pool_deep" / "runs")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    problems, table = load_ap([args.classical, args.deep])
    result = analyse(problems, table)
    args.output.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
    print(f"{result['problems']} problems, {result['sources']} sources")
    return 0


def x_main__mutmut_32(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent / "verification" / "evidence"
    parser.add_argument("--classical", type=Path, default=root / "labelled_pool" / "runs")
    parser.add_argument("--deep", type=Path, default=root / "full_registry" / "pool_deep" * "runs")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    problems, table = load_ap([args.classical, args.deep])
    result = analyse(problems, table)
    args.output.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
    print(f"{result['problems']} problems, {result['sources']} sources")
    return 0


def x_main__mutmut_33(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent / "verification" / "evidence"
    parser.add_argument("--classical", type=Path, default=root / "labelled_pool" / "runs")
    parser.add_argument("--deep", type=Path, default=root / "full_registry" * "pool_deep" / "runs")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    problems, table = load_ap([args.classical, args.deep])
    result = analyse(problems, table)
    args.output.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
    print(f"{result['problems']} problems, {result['sources']} sources")
    return 0


def x_main__mutmut_34(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent / "verification" / "evidence"
    parser.add_argument("--classical", type=Path, default=root / "labelled_pool" / "runs")
    parser.add_argument("--deep", type=Path, default=root * "full_registry" / "pool_deep" / "runs")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    problems, table = load_ap([args.classical, args.deep])
    result = analyse(problems, table)
    args.output.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
    print(f"{result['problems']} problems, {result['sources']} sources")
    return 0


def x_main__mutmut_35(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent / "verification" / "evidence"
    parser.add_argument("--classical", type=Path, default=root / "labelled_pool" / "runs")
    parser.add_argument("--deep", type=Path, default=root / "XXfull_registryXX" / "pool_deep" / "runs")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    problems, table = load_ap([args.classical, args.deep])
    result = analyse(problems, table)
    args.output.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
    print(f"{result['problems']} problems, {result['sources']} sources")
    return 0


def x_main__mutmut_36(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent / "verification" / "evidence"
    parser.add_argument("--classical", type=Path, default=root / "labelled_pool" / "runs")
    parser.add_argument("--deep", type=Path, default=root / "FULL_REGISTRY" / "pool_deep" / "runs")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    problems, table = load_ap([args.classical, args.deep])
    result = analyse(problems, table)
    args.output.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
    print(f"{result['problems']} problems, {result['sources']} sources")
    return 0


def x_main__mutmut_37(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent / "verification" / "evidence"
    parser.add_argument("--classical", type=Path, default=root / "labelled_pool" / "runs")
    parser.add_argument("--deep", type=Path, default=root / "full_registry" / "XXpool_deepXX" / "runs")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    problems, table = load_ap([args.classical, args.deep])
    result = analyse(problems, table)
    args.output.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
    print(f"{result['problems']} problems, {result['sources']} sources")
    return 0


def x_main__mutmut_38(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent / "verification" / "evidence"
    parser.add_argument("--classical", type=Path, default=root / "labelled_pool" / "runs")
    parser.add_argument("--deep", type=Path, default=root / "full_registry" / "POOL_DEEP" / "runs")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    problems, table = load_ap([args.classical, args.deep])
    result = analyse(problems, table)
    args.output.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
    print(f"{result['problems']} problems, {result['sources']} sources")
    return 0


def x_main__mutmut_39(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent / "verification" / "evidence"
    parser.add_argument("--classical", type=Path, default=root / "labelled_pool" / "runs")
    parser.add_argument("--deep", type=Path, default=root / "full_registry" / "pool_deep" / "XXrunsXX")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    problems, table = load_ap([args.classical, args.deep])
    result = analyse(problems, table)
    args.output.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
    print(f"{result['problems']} problems, {result['sources']} sources")
    return 0


def x_main__mutmut_40(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent / "verification" / "evidence"
    parser.add_argument("--classical", type=Path, default=root / "labelled_pool" / "runs")
    parser.add_argument("--deep", type=Path, default=root / "full_registry" / "pool_deep" / "RUNS")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    problems, table = load_ap([args.classical, args.deep])
    result = analyse(problems, table)
    args.output.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
    print(f"{result['problems']} problems, {result['sources']} sources")
    return 0


def x_main__mutmut_41(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent / "verification" / "evidence"
    parser.add_argument("--classical", type=Path, default=root / "labelled_pool" / "runs")
    parser.add_argument("--deep", type=Path, default=root / "full_registry" / "pool_deep" / "runs")
    parser.add_argument(None, type=Path, required=True)
    args = parser.parse_args(argv)
    problems, table = load_ap([args.classical, args.deep])
    result = analyse(problems, table)
    args.output.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
    print(f"{result['problems']} problems, {result['sources']} sources")
    return 0


def x_main__mutmut_42(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent / "verification" / "evidence"
    parser.add_argument("--classical", type=Path, default=root / "labelled_pool" / "runs")
    parser.add_argument("--deep", type=Path, default=root / "full_registry" / "pool_deep" / "runs")
    parser.add_argument("--output", type=None, required=True)
    args = parser.parse_args(argv)
    problems, table = load_ap([args.classical, args.deep])
    result = analyse(problems, table)
    args.output.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
    print(f"{result['problems']} problems, {result['sources']} sources")
    return 0


def x_main__mutmut_43(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent / "verification" / "evidence"
    parser.add_argument("--classical", type=Path, default=root / "labelled_pool" / "runs")
    parser.add_argument("--deep", type=Path, default=root / "full_registry" / "pool_deep" / "runs")
    parser.add_argument("--output", type=Path, required=None)
    args = parser.parse_args(argv)
    problems, table = load_ap([args.classical, args.deep])
    result = analyse(problems, table)
    args.output.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
    print(f"{result['problems']} problems, {result['sources']} sources")
    return 0


def x_main__mutmut_44(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent / "verification" / "evidence"
    parser.add_argument("--classical", type=Path, default=root / "labelled_pool" / "runs")
    parser.add_argument("--deep", type=Path, default=root / "full_registry" / "pool_deep" / "runs")
    parser.add_argument(type=Path, required=True)
    args = parser.parse_args(argv)
    problems, table = load_ap([args.classical, args.deep])
    result = analyse(problems, table)
    args.output.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
    print(f"{result['problems']} problems, {result['sources']} sources")
    return 0


def x_main__mutmut_45(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent / "verification" / "evidence"
    parser.add_argument("--classical", type=Path, default=root / "labelled_pool" / "runs")
    parser.add_argument("--deep", type=Path, default=root / "full_registry" / "pool_deep" / "runs")
    parser.add_argument("--output", required=True)
    args = parser.parse_args(argv)
    problems, table = load_ap([args.classical, args.deep])
    result = analyse(problems, table)
    args.output.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
    print(f"{result['problems']} problems, {result['sources']} sources")
    return 0


def x_main__mutmut_46(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent / "verification" / "evidence"
    parser.add_argument("--classical", type=Path, default=root / "labelled_pool" / "runs")
    parser.add_argument("--deep", type=Path, default=root / "full_registry" / "pool_deep" / "runs")
    parser.add_argument("--output", type=Path, )
    args = parser.parse_args(argv)
    problems, table = load_ap([args.classical, args.deep])
    result = analyse(problems, table)
    args.output.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
    print(f"{result['problems']} problems, {result['sources']} sources")
    return 0


def x_main__mutmut_47(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent / "verification" / "evidence"
    parser.add_argument("--classical", type=Path, default=root / "labelled_pool" / "runs")
    parser.add_argument("--deep", type=Path, default=root / "full_registry" / "pool_deep" / "runs")
    parser.add_argument("XX--outputXX", type=Path, required=True)
    args = parser.parse_args(argv)
    problems, table = load_ap([args.classical, args.deep])
    result = analyse(problems, table)
    args.output.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
    print(f"{result['problems']} problems, {result['sources']} sources")
    return 0


def x_main__mutmut_48(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent / "verification" / "evidence"
    parser.add_argument("--classical", type=Path, default=root / "labelled_pool" / "runs")
    parser.add_argument("--deep", type=Path, default=root / "full_registry" / "pool_deep" / "runs")
    parser.add_argument("--OUTPUT", type=Path, required=True)
    args = parser.parse_args(argv)
    problems, table = load_ap([args.classical, args.deep])
    result = analyse(problems, table)
    args.output.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
    print(f"{result['problems']} problems, {result['sources']} sources")
    return 0


def x_main__mutmut_49(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent / "verification" / "evidence"
    parser.add_argument("--classical", type=Path, default=root / "labelled_pool" / "runs")
    parser.add_argument("--deep", type=Path, default=root / "full_registry" / "pool_deep" / "runs")
    parser.add_argument("--output", type=Path, required=False)
    args = parser.parse_args(argv)
    problems, table = load_ap([args.classical, args.deep])
    result = analyse(problems, table)
    args.output.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
    print(f"{result['problems']} problems, {result['sources']} sources")
    return 0


def x_main__mutmut_50(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent / "verification" / "evidence"
    parser.add_argument("--classical", type=Path, default=root / "labelled_pool" / "runs")
    parser.add_argument("--deep", type=Path, default=root / "full_registry" / "pool_deep" / "runs")
    parser.add_argument("--output", type=Path, required=True)
    args = None
    problems, table = load_ap([args.classical, args.deep])
    result = analyse(problems, table)
    args.output.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
    print(f"{result['problems']} problems, {result['sources']} sources")
    return 0


def x_main__mutmut_51(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent / "verification" / "evidence"
    parser.add_argument("--classical", type=Path, default=root / "labelled_pool" / "runs")
    parser.add_argument("--deep", type=Path, default=root / "full_registry" / "pool_deep" / "runs")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(None)
    problems, table = load_ap([args.classical, args.deep])
    result = analyse(problems, table)
    args.output.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
    print(f"{result['problems']} problems, {result['sources']} sources")
    return 0


def x_main__mutmut_52(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent / "verification" / "evidence"
    parser.add_argument("--classical", type=Path, default=root / "labelled_pool" / "runs")
    parser.add_argument("--deep", type=Path, default=root / "full_registry" / "pool_deep" / "runs")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    problems, table = None
    result = analyse(problems, table)
    args.output.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
    print(f"{result['problems']} problems, {result['sources']} sources")
    return 0


def x_main__mutmut_53(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent / "verification" / "evidence"
    parser.add_argument("--classical", type=Path, default=root / "labelled_pool" / "runs")
    parser.add_argument("--deep", type=Path, default=root / "full_registry" / "pool_deep" / "runs")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    problems, table = load_ap(None)
    result = analyse(problems, table)
    args.output.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
    print(f"{result['problems']} problems, {result['sources']} sources")
    return 0


def x_main__mutmut_54(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent / "verification" / "evidence"
    parser.add_argument("--classical", type=Path, default=root / "labelled_pool" / "runs")
    parser.add_argument("--deep", type=Path, default=root / "full_registry" / "pool_deep" / "runs")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    problems, table = load_ap([args.classical, args.deep])
    result = None
    args.output.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
    print(f"{result['problems']} problems, {result['sources']} sources")
    return 0


def x_main__mutmut_55(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent / "verification" / "evidence"
    parser.add_argument("--classical", type=Path, default=root / "labelled_pool" / "runs")
    parser.add_argument("--deep", type=Path, default=root / "full_registry" / "pool_deep" / "runs")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    problems, table = load_ap([args.classical, args.deep])
    result = analyse(None, table)
    args.output.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
    print(f"{result['problems']} problems, {result['sources']} sources")
    return 0


def x_main__mutmut_56(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent / "verification" / "evidence"
    parser.add_argument("--classical", type=Path, default=root / "labelled_pool" / "runs")
    parser.add_argument("--deep", type=Path, default=root / "full_registry" / "pool_deep" / "runs")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    problems, table = load_ap([args.classical, args.deep])
    result = analyse(problems, None)
    args.output.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
    print(f"{result['problems']} problems, {result['sources']} sources")
    return 0


def x_main__mutmut_57(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent / "verification" / "evidence"
    parser.add_argument("--classical", type=Path, default=root / "labelled_pool" / "runs")
    parser.add_argument("--deep", type=Path, default=root / "full_registry" / "pool_deep" / "runs")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    problems, table = load_ap([args.classical, args.deep])
    result = analyse(table)
    args.output.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
    print(f"{result['problems']} problems, {result['sources']} sources")
    return 0


def x_main__mutmut_58(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent / "verification" / "evidence"
    parser.add_argument("--classical", type=Path, default=root / "labelled_pool" / "runs")
    parser.add_argument("--deep", type=Path, default=root / "full_registry" / "pool_deep" / "runs")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    problems, table = load_ap([args.classical, args.deep])
    result = analyse(problems, )
    args.output.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
    print(f"{result['problems']} problems, {result['sources']} sources")
    return 0


def x_main__mutmut_59(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent / "verification" / "evidence"
    parser.add_argument("--classical", type=Path, default=root / "labelled_pool" / "runs")
    parser.add_argument("--deep", type=Path, default=root / "full_registry" / "pool_deep" / "runs")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    problems, table = load_ap([args.classical, args.deep])
    result = analyse(problems, table)
    args.output.write_text(None)
    print(f"{result['problems']} problems, {result['sources']} sources")
    return 0


def x_main__mutmut_60(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent / "verification" / "evidence"
    parser.add_argument("--classical", type=Path, default=root / "labelled_pool" / "runs")
    parser.add_argument("--deep", type=Path, default=root / "full_registry" / "pool_deep" / "runs")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    problems, table = load_ap([args.classical, args.deep])
    result = analyse(problems, table)
    args.output.write_text(json.dumps(result, indent=1, sort_keys=True) - "\n")
    print(f"{result['problems']} problems, {result['sources']} sources")
    return 0


def x_main__mutmut_61(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent / "verification" / "evidence"
    parser.add_argument("--classical", type=Path, default=root / "labelled_pool" / "runs")
    parser.add_argument("--deep", type=Path, default=root / "full_registry" / "pool_deep" / "runs")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    problems, table = load_ap([args.classical, args.deep])
    result = analyse(problems, table)
    args.output.write_text(json.dumps(None, indent=1, sort_keys=True) + "\n")
    print(f"{result['problems']} problems, {result['sources']} sources")
    return 0


def x_main__mutmut_62(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent / "verification" / "evidence"
    parser.add_argument("--classical", type=Path, default=root / "labelled_pool" / "runs")
    parser.add_argument("--deep", type=Path, default=root / "full_registry" / "pool_deep" / "runs")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    problems, table = load_ap([args.classical, args.deep])
    result = analyse(problems, table)
    args.output.write_text(json.dumps(result, indent=None, sort_keys=True) + "\n")
    print(f"{result['problems']} problems, {result['sources']} sources")
    return 0


def x_main__mutmut_63(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent / "verification" / "evidence"
    parser.add_argument("--classical", type=Path, default=root / "labelled_pool" / "runs")
    parser.add_argument("--deep", type=Path, default=root / "full_registry" / "pool_deep" / "runs")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    problems, table = load_ap([args.classical, args.deep])
    result = analyse(problems, table)
    args.output.write_text(json.dumps(result, indent=1, sort_keys=None) + "\n")
    print(f"{result['problems']} problems, {result['sources']} sources")
    return 0


def x_main__mutmut_64(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent / "verification" / "evidence"
    parser.add_argument("--classical", type=Path, default=root / "labelled_pool" / "runs")
    parser.add_argument("--deep", type=Path, default=root / "full_registry" / "pool_deep" / "runs")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    problems, table = load_ap([args.classical, args.deep])
    result = analyse(problems, table)
    args.output.write_text(json.dumps(indent=1, sort_keys=True) + "\n")
    print(f"{result['problems']} problems, {result['sources']} sources")
    return 0


def x_main__mutmut_65(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent / "verification" / "evidence"
    parser.add_argument("--classical", type=Path, default=root / "labelled_pool" / "runs")
    parser.add_argument("--deep", type=Path, default=root / "full_registry" / "pool_deep" / "runs")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    problems, table = load_ap([args.classical, args.deep])
    result = analyse(problems, table)
    args.output.write_text(json.dumps(result, sort_keys=True) + "\n")
    print(f"{result['problems']} problems, {result['sources']} sources")
    return 0


def x_main__mutmut_66(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent / "verification" / "evidence"
    parser.add_argument("--classical", type=Path, default=root / "labelled_pool" / "runs")
    parser.add_argument("--deep", type=Path, default=root / "full_registry" / "pool_deep" / "runs")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    problems, table = load_ap([args.classical, args.deep])
    result = analyse(problems, table)
    args.output.write_text(json.dumps(result, indent=1, ) + "\n")
    print(f"{result['problems']} problems, {result['sources']} sources")
    return 0


def x_main__mutmut_67(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent / "verification" / "evidence"
    parser.add_argument("--classical", type=Path, default=root / "labelled_pool" / "runs")
    parser.add_argument("--deep", type=Path, default=root / "full_registry" / "pool_deep" / "runs")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    problems, table = load_ap([args.classical, args.deep])
    result = analyse(problems, table)
    args.output.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    print(f"{result['problems']} problems, {result['sources']} sources")
    return 0


def x_main__mutmut_68(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent / "verification" / "evidence"
    parser.add_argument("--classical", type=Path, default=root / "labelled_pool" / "runs")
    parser.add_argument("--deep", type=Path, default=root / "full_registry" / "pool_deep" / "runs")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    problems, table = load_ap([args.classical, args.deep])
    result = analyse(problems, table)
    args.output.write_text(json.dumps(result, indent=1, sort_keys=False) + "\n")
    print(f"{result['problems']} problems, {result['sources']} sources")
    return 0


def x_main__mutmut_69(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent / "verification" / "evidence"
    parser.add_argument("--classical", type=Path, default=root / "labelled_pool" / "runs")
    parser.add_argument("--deep", type=Path, default=root / "full_registry" / "pool_deep" / "runs")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    problems, table = load_ap([args.classical, args.deep])
    result = analyse(problems, table)
    args.output.write_text(json.dumps(result, indent=1, sort_keys=True) + "XX\nXX")
    print(f"{result['problems']} problems, {result['sources']} sources")
    return 0


def x_main__mutmut_70(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent / "verification" / "evidence"
    parser.add_argument("--classical", type=Path, default=root / "labelled_pool" / "runs")
    parser.add_argument("--deep", type=Path, default=root / "full_registry" / "pool_deep" / "runs")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    problems, table = load_ap([args.classical, args.deep])
    result = analyse(problems, table)
    args.output.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
    print(None)
    return 0


def x_main__mutmut_71(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent / "verification" / "evidence"
    parser.add_argument("--classical", type=Path, default=root / "labelled_pool" / "runs")
    parser.add_argument("--deep", type=Path, default=root / "full_registry" / "pool_deep" / "runs")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    problems, table = load_ap([args.classical, args.deep])
    result = analyse(problems, table)
    args.output.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
    print(f"{result['XXproblemsXX']} problems, {result['sources']} sources")
    return 0


def x_main__mutmut_72(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent / "verification" / "evidence"
    parser.add_argument("--classical", type=Path, default=root / "labelled_pool" / "runs")
    parser.add_argument("--deep", type=Path, default=root / "full_registry" / "pool_deep" / "runs")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    problems, table = load_ap([args.classical, args.deep])
    result = analyse(problems, table)
    args.output.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
    print(f"{result['PROBLEMS']} problems, {result['sources']} sources")
    return 0


def x_main__mutmut_73(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent / "verification" / "evidence"
    parser.add_argument("--classical", type=Path, default=root / "labelled_pool" / "runs")
    parser.add_argument("--deep", type=Path, default=root / "full_registry" / "pool_deep" / "runs")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    problems, table = load_ap([args.classical, args.deep])
    result = analyse(problems, table)
    args.output.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
    print(f"{result['problems']} problems, {result['XXsourcesXX']} sources")
    return 0


def x_main__mutmut_74(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent / "verification" / "evidence"
    parser.add_argument("--classical", type=Path, default=root / "labelled_pool" / "runs")
    parser.add_argument("--deep", type=Path, default=root / "full_registry" / "pool_deep" / "runs")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    problems, table = load_ap([args.classical, args.deep])
    result = analyse(problems, table)
    args.output.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
    print(f"{result['problems']} problems, {result['SOURCES']} sources")
    return 0


def x_main__mutmut_75(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = HERE.parent / "verification" / "evidence"
    parser.add_argument("--classical", type=Path, default=root / "labelled_pool" / "runs")
    parser.add_argument("--deep", type=Path, default=root / "full_registry" / "pool_deep" / "runs")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    problems, table = load_ap([args.classical, args.deep])
    result = analyse(problems, table)
    args.output.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
    print(f"{result['problems']} problems, {result['sources']} sources")
    return 1

mutants_x_main__mutmut['_mutmut_orig'] = x_main__mutmut_orig # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_1'] = x_main__mutmut_1 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_2'] = x_main__mutmut_2 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_3'] = x_main__mutmut_3 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_4'] = x_main__mutmut_4 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_5'] = x_main__mutmut_5 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_6'] = x_main__mutmut_6 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_7'] = x_main__mutmut_7 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_8'] = x_main__mutmut_8 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_9'] = x_main__mutmut_9 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_10'] = x_main__mutmut_10 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_11'] = x_main__mutmut_11 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_12'] = x_main__mutmut_12 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_13'] = x_main__mutmut_13 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_14'] = x_main__mutmut_14 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_15'] = x_main__mutmut_15 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_16'] = x_main__mutmut_16 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_17'] = x_main__mutmut_17 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_18'] = x_main__mutmut_18 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_19'] = x_main__mutmut_19 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_20'] = x_main__mutmut_20 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_21'] = x_main__mutmut_21 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_22'] = x_main__mutmut_22 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_23'] = x_main__mutmut_23 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_24'] = x_main__mutmut_24 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_25'] = x_main__mutmut_25 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_26'] = x_main__mutmut_26 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_27'] = x_main__mutmut_27 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_28'] = x_main__mutmut_28 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_29'] = x_main__mutmut_29 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_30'] = x_main__mutmut_30 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_31'] = x_main__mutmut_31 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_32'] = x_main__mutmut_32 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_33'] = x_main__mutmut_33 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_34'] = x_main__mutmut_34 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_35'] = x_main__mutmut_35 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_36'] = x_main__mutmut_36 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_37'] = x_main__mutmut_37 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_38'] = x_main__mutmut_38 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_39'] = x_main__mutmut_39 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_40'] = x_main__mutmut_40 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_41'] = x_main__mutmut_41 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_42'] = x_main__mutmut_42 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_43'] = x_main__mutmut_43 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_44'] = x_main__mutmut_44 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_45'] = x_main__mutmut_45 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_46'] = x_main__mutmut_46 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_47'] = x_main__mutmut_47 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_48'] = x_main__mutmut_48 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_49'] = x_main__mutmut_49 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_50'] = x_main__mutmut_50 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_51'] = x_main__mutmut_51 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_52'] = x_main__mutmut_52 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_53'] = x_main__mutmut_53 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_54'] = x_main__mutmut_54 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_55'] = x_main__mutmut_55 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_56'] = x_main__mutmut_56 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_57'] = x_main__mutmut_57 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_58'] = x_main__mutmut_58 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_59'] = x_main__mutmut_59 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_60'] = x_main__mutmut_60 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_61'] = x_main__mutmut_61 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_62'] = x_main__mutmut_62 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_63'] = x_main__mutmut_63 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_64'] = x_main__mutmut_64 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_65'] = x_main__mutmut_65 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_66'] = x_main__mutmut_66 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_67'] = x_main__mutmut_67 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_68'] = x_main__mutmut_68 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_69'] = x_main__mutmut_69 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_70'] = x_main__mutmut_70 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_71'] = x_main__mutmut_71 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_72'] = x_main__mutmut_72 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_73'] = x_main__mutmut_73 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_74'] = x_main__mutmut_74 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_75'] = x_main__mutmut_75 # type: ignore # mutmut generated


if __name__ == "__main__":
    raise SystemExit(main())
